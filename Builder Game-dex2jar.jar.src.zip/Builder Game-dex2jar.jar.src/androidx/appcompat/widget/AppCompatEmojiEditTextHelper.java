package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import androidx.appcompat.R;
import androidx.emoji2.viewsintegration.EmojiEditTextHelper;

class AppCompatEmojiEditTextHelper {
  private final EmojiEditTextHelper mEmojiEditTextHelper;
  
  private final EditText mView;
  
  AppCompatEmojiEditTextHelper(EditText paramEditText) {
    this.mView = paramEditText;
    this.mEmojiEditTextHelper = new EmojiEditTextHelper(paramEditText, false);
  }
  
  KeyListener getKeyListener(KeyListener paramKeyListener) {
    KeyListener keyListener = paramKeyListener;
    if (isEmojiCapableKeyListener(paramKeyListener))
      keyListener = this.mEmojiEditTextHelper.getKeyListener(paramKeyListener); 
    return keyListener;
  }
  
  boolean isEmojiCapableKeyListener(KeyListener paramKeyListener) {
    return paramKeyListener instanceof android.text.method.NumberKeyListener ^ true;
  }
  
  boolean isEnabled() {
    return this.mEmojiEditTextHelper.isEnabled();
  }
  
  void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt) {
    TypedArray typedArray = this.mView.getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.AppCompatTextView, paramInt, 0);
    try {
      boolean bool2 = typedArray.hasValue(R.styleable.AppCompatTextView_emojiCompatEnabled);
      boolean bool1 = true;
      if (bool2)
        bool1 = typedArray.getBoolean(R.styleable.AppCompatTextView_emojiCompatEnabled, true); 
      typedArray.recycle();
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  InputConnection onCreateInputConnection(InputConnection paramInputConnection, EditorInfo paramEditorInfo) {
    return this.mEmojiEditTextHelper.onCreateInputConnection(paramInputConnection, paramEditorInfo);
  }
  
  void setEnabled(boolean paramBoolean) {
    this.mEmojiEditTextHelper.setEnabled(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\appcompat\widget\AppCompatEmojiEditTextHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */