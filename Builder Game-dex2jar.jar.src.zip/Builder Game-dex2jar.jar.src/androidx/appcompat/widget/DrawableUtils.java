package androidx.appcompat.widget;

import android.graphics.Insets;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import androidx.core.graphics.drawable.DrawableCompat;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class DrawableUtils {
  private static final int[] CHECKED_STATE_SET = new int[] { 16842912 };
  
  private static final int[] EMPTY_STATE_SET = new int[0];
  
  public static final Rect INSETS_NONE = new Rect();
  
  public static boolean canSafelyMutateDrawable(Drawable paramDrawable) {
    return true;
  }
  
  static void fixDrawable(Drawable paramDrawable) {
    String str = paramDrawable.getClass().getName();
    if (Build.VERSION.SDK_INT == 21 && "android.graphics.drawable.VectorDrawable".equals(str)) {
      forceDrawableStateChange(paramDrawable);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 29 && Build.VERSION.SDK_INT < 31 && "android.graphics.drawable.ColorStateListDrawable".equals(str))
      forceDrawableStateChange(paramDrawable); 
  }
  
  private static void forceDrawableStateChange(Drawable paramDrawable) {
    int[] arrayOfInt = paramDrawable.getState();
    if (arrayOfInt == null || arrayOfInt.length == 0) {
      paramDrawable.setState(CHECKED_STATE_SET);
    } else {
      paramDrawable.setState(EMPTY_STATE_SET);
    } 
    paramDrawable.setState(arrayOfInt);
  }
  
  public static Rect getOpticalBounds(Drawable paramDrawable) {
    Insets insets;
    if (Build.VERSION.SDK_INT >= 29) {
      insets = Api29Impl.getOpticalInsets(paramDrawable);
      return new Rect(insets.left, insets.top, insets.right, insets.bottom);
    } 
    return Api18Impl.getOpticalInsets(DrawableCompat.unwrap((Drawable)insets));
  }
  
  public static PorterDuff.Mode parseTintMode(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
  
  static class Api18Impl {
    private static final Field sBottom;
    
    private static final Method sGetOpticalInsets;
    
    private static final Field sLeft;
    
    private static final boolean sReflectionSuccessful;
    
    private static final Field sRight;
    
    private static final Field sTop;
    
    static {
      // Byte code:
      //   0: ldc 'android.graphics.Insets'
      //   2: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   5: astore_2
      //   6: ldc android/graphics/drawable/Drawable
      //   8: ldc 'getOpticalInsets'
      //   10: iconst_0
      //   11: anewarray java/lang/Class
      //   14: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   17: astore_1
      //   18: aload_2
      //   19: ldc 'left'
      //   21: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   24: astore_3
      //   25: aload_2
      //   26: ldc 'top'
      //   28: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   31: astore #5
      //   33: aload_2
      //   34: ldc 'right'
      //   36: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   39: astore #4
      //   41: aload_2
      //   42: ldc 'bottom'
      //   44: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   47: astore_2
      //   48: iconst_1
      //   49: istore_0
      //   50: goto -> 154
      //   53: goto -> 150
      //   56: aconst_null
      //   57: astore #4
      //   59: goto -> 150
      //   62: aconst_null
      //   63: astore #4
      //   65: aload_1
      //   66: astore_2
      //   67: aload #4
      //   69: astore_1
      //   70: goto -> 142
      //   73: aconst_null
      //   74: astore #4
      //   76: aload_1
      //   77: astore_2
      //   78: aload #4
      //   80: astore_1
      //   81: goto -> 142
      //   84: aconst_null
      //   85: astore #4
      //   87: aload_1
      //   88: astore_2
      //   89: aload #4
      //   91: astore_1
      //   92: goto -> 142
      //   95: goto -> 108
      //   98: goto -> 123
      //   101: aload_1
      //   102: astore_2
      //   103: goto -> 138
      //   106: aconst_null
      //   107: astore_1
      //   108: aconst_null
      //   109: astore_3
      //   110: aconst_null
      //   111: astore #4
      //   113: aload_1
      //   114: astore_2
      //   115: aload #4
      //   117: astore_1
      //   118: goto -> 142
      //   121: aconst_null
      //   122: astore_1
      //   123: aconst_null
      //   124: astore_3
      //   125: aconst_null
      //   126: astore #4
      //   128: aload_1
      //   129: astore_2
      //   130: aload #4
      //   132: astore_1
      //   133: goto -> 142
      //   136: aconst_null
      //   137: astore_2
      //   138: aconst_null
      //   139: astore_3
      //   140: aconst_null
      //   141: astore_1
      //   142: aload_1
      //   143: astore #4
      //   145: aload_1
      //   146: astore #5
      //   148: aload_2
      //   149: astore_1
      //   150: aconst_null
      //   151: astore_2
      //   152: iconst_0
      //   153: istore_0
      //   154: iload_0
      //   155: ifeq -> 185
      //   158: aload_1
      //   159: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sGetOpticalInsets : Ljava/lang/reflect/Method;
      //   162: aload_3
      //   163: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sLeft : Ljava/lang/reflect/Field;
      //   166: aload #5
      //   168: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sTop : Ljava/lang/reflect/Field;
      //   171: aload #4
      //   173: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sRight : Ljava/lang/reflect/Field;
      //   176: aload_2
      //   177: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sBottom : Ljava/lang/reflect/Field;
      //   180: iconst_1
      //   181: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sReflectionSuccessful : Z
      //   184: return
      //   185: aconst_null
      //   186: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sGetOpticalInsets : Ljava/lang/reflect/Method;
      //   189: aconst_null
      //   190: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sLeft : Ljava/lang/reflect/Field;
      //   193: aconst_null
      //   194: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sTop : Ljava/lang/reflect/Field;
      //   197: aconst_null
      //   198: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sRight : Ljava/lang/reflect/Field;
      //   201: aconst_null
      //   202: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sBottom : Ljava/lang/reflect/Field;
      //   205: iconst_0
      //   206: putstatic androidx/appcompat/widget/DrawableUtils$Api18Impl.sReflectionSuccessful : Z
      //   209: return
      //   210: astore_1
      //   211: goto -> 136
      //   214: astore_1
      //   215: goto -> 121
      //   218: astore_1
      //   219: goto -> 106
      //   222: astore_2
      //   223: goto -> 101
      //   226: astore_2
      //   227: goto -> 98
      //   230: astore_2
      //   231: goto -> 95
      //   234: astore_2
      //   235: goto -> 84
      //   238: astore_2
      //   239: goto -> 73
      //   242: astore_2
      //   243: goto -> 62
      //   246: astore_2
      //   247: goto -> 56
      //   250: astore_2
      //   251: goto -> 53
      // Exception table:
      //   from	to	target	type
      //   0	18	210	java/lang/NoSuchMethodException
      //   0	18	214	java/lang/ClassNotFoundException
      //   0	18	218	java/lang/NoSuchFieldException
      //   18	25	222	java/lang/NoSuchMethodException
      //   18	25	226	java/lang/ClassNotFoundException
      //   18	25	230	java/lang/NoSuchFieldException
      //   25	33	234	java/lang/NoSuchMethodException
      //   25	33	238	java/lang/ClassNotFoundException
      //   25	33	242	java/lang/NoSuchFieldException
      //   33	41	246	java/lang/NoSuchMethodException
      //   33	41	246	java/lang/ClassNotFoundException
      //   33	41	246	java/lang/NoSuchFieldException
      //   41	48	250	java/lang/NoSuchMethodException
      //   41	48	250	java/lang/ClassNotFoundException
      //   41	48	250	java/lang/NoSuchFieldException
    }
    
    static Rect getOpticalInsets(Drawable param1Drawable) {
      if (Build.VERSION.SDK_INT < 29 && sReflectionSuccessful)
        try {
          Object object = sGetOpticalInsets.invoke(param1Drawable, new Object[0]);
          if (object != null)
            return new Rect(sLeft.getInt(object), sTop.getInt(object), sRight.getInt(object), sBottom.getInt(object)); 
        } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {} 
      return DrawableUtils.INSETS_NONE;
    }
  }
  
  static class Api29Impl {
    static Insets getOpticalInsets(Drawable param1Drawable) {
      return param1Drawable.getOpticalInsets();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\appcompat\widget\DrawableUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */