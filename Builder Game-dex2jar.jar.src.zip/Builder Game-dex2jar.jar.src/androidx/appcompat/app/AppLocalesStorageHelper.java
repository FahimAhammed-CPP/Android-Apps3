package androidx.appcompat.app;

import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.Executor;

class AppLocalesStorageHelper {
  static final String APPLICATION_LOCALES_RECORD_FILE = "androidx.appcompat.app.AppCompatDelegate.application_locales_record_file";
  
  static final String APP_LOCALES_META_DATA_HOLDER_SERVICE_NAME = "androidx.appcompat.app.AppLocalesMetadataHolderService";
  
  static final String LOCALE_RECORD_ATTRIBUTE_TAG = "application_locales";
  
  static final String LOCALE_RECORD_FILE_TAG = "locales";
  
  static final String TAG = "AppLocalesStorageHelper";
  
  static void persistLocales(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ldc ''
    //   3: invokevirtual equals : (Ljava/lang/Object;)Z
    //   6: ifeq -> 17
    //   9: aload_0
    //   10: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   12: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   15: pop
    //   16: return
    //   17: aload_0
    //   18: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   20: iconst_0
    //   21: invokevirtual openFileOutput : (Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   24: astore_0
    //   25: invokestatic newSerializer : ()Lorg/xmlpull/v1/XmlSerializer;
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aconst_null
    //   32: invokeinterface setOutput : (Ljava/io/OutputStream;Ljava/lang/String;)V
    //   37: aload_2
    //   38: ldc 'UTF-8'
    //   40: iconst_1
    //   41: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   44: invokeinterface startDocument : (Ljava/lang/String;Ljava/lang/Boolean;)V
    //   49: aload_2
    //   50: aconst_null
    //   51: ldc 'locales'
    //   53: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   58: pop
    //   59: aload_2
    //   60: aconst_null
    //   61: ldc 'application_locales'
    //   63: aload_1
    //   64: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   69: pop
    //   70: aload_2
    //   71: aconst_null
    //   72: ldc 'locales'
    //   74: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   79: pop
    //   80: aload_2
    //   81: invokeinterface endDocument : ()V
    //   86: new java/lang/StringBuilder
    //   89: dup
    //   90: ldc 'Storing App Locales : app-locales: '
    //   92: invokespecial <init> : (Ljava/lang/String;)V
    //   95: astore_2
    //   96: aload_2
    //   97: aload_1
    //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: pop
    //   102: aload_2
    //   103: ldc ' persisted successfully.'
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: pop
    //   109: ldc 'AppLocalesStorageHelper'
    //   111: aload_2
    //   112: invokevirtual toString : ()Ljava/lang/String;
    //   115: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   118: pop
    //   119: aload_0
    //   120: ifnull -> 167
    //   123: aload_0
    //   124: invokevirtual close : ()V
    //   127: return
    //   128: astore_1
    //   129: goto -> 168
    //   132: astore_2
    //   133: new java/lang/StringBuilder
    //   136: dup
    //   137: ldc 'Storing App Locales : Failed to persist app-locales: '
    //   139: invokespecial <init> : (Ljava/lang/String;)V
    //   142: astore_3
    //   143: aload_3
    //   144: aload_1
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: pop
    //   149: ldc 'AppLocalesStorageHelper'
    //   151: aload_3
    //   152: invokevirtual toString : ()Ljava/lang/String;
    //   155: aload_2
    //   156: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   159: pop
    //   160: aload_0
    //   161: ifnull -> 167
    //   164: goto -> 123
    //   167: return
    //   168: aload_0
    //   169: ifnull -> 176
    //   172: aload_0
    //   173: invokevirtual close : ()V
    //   176: aload_1
    //   177: athrow
    //   178: ldc 'AppLocalesStorageHelper'
    //   180: ldc 'Storing App Locales : FileNotFoundException: Cannot open file %s for writing '
    //   182: iconst_1
    //   183: anewarray java/lang/Object
    //   186: dup
    //   187: iconst_0
    //   188: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   190: aastore
    //   191: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   194: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   197: pop
    //   198: return
    //   199: astore_0
    //   200: goto -> 178
    //   203: astore_0
    //   204: return
    //   205: astore_0
    //   206: goto -> 176
    // Exception table:
    //   from	to	target	type
    //   17	25	199	java/io/FileNotFoundException
    //   29	119	132	java/lang/Exception
    //   29	119	128	finally
    //   123	127	203	java/io/IOException
    //   133	160	128	finally
    //   172	176	205	java/io/IOException
  }
  
  static String readLocales(Context paramContext) {
    // Byte code:
    //   0: ldc ''
    //   2: astore #4
    //   4: aload_0
    //   5: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   7: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   10: astore #6
    //   12: invokestatic newPullParser : ()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore #5
    //   17: aload #5
    //   19: aload #6
    //   21: ldc 'UTF-8'
    //   23: invokeinterface setInput : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   28: aload #5
    //   30: invokeinterface getDepth : ()I
    //   35: istore_1
    //   36: aload #5
    //   38: invokeinterface next : ()I
    //   43: istore_2
    //   44: aload #4
    //   46: astore_3
    //   47: iload_2
    //   48: iconst_1
    //   49: if_icmpeq -> 100
    //   52: iload_2
    //   53: iconst_3
    //   54: if_icmpne -> 240
    //   57: aload #4
    //   59: astore_3
    //   60: aload #5
    //   62: invokeinterface getDepth : ()I
    //   67: iload_1
    //   68: if_icmple -> 100
    //   71: goto -> 240
    //   74: aload #5
    //   76: invokeinterface getName : ()Ljava/lang/String;
    //   81: ldc 'locales'
    //   83: invokevirtual equals : (Ljava/lang/Object;)Z
    //   86: ifeq -> 36
    //   89: aload #5
    //   91: aconst_null
    //   92: ldc 'application_locales'
    //   94: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   99: astore_3
    //   100: aload_3
    //   101: astore #5
    //   103: aload #6
    //   105: ifnull -> 152
    //   108: aload #6
    //   110: invokevirtual close : ()V
    //   113: aload_3
    //   114: astore #5
    //   116: goto -> 152
    //   119: aload_3
    //   120: astore #5
    //   122: goto -> 152
    //   125: astore_0
    //   126: goto -> 200
    //   129: ldc 'AppLocalesStorageHelper'
    //   131: ldc 'Reading app Locales : Unable to parse through file :androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   133: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   136: pop
    //   137: aload #4
    //   139: astore #5
    //   141: aload #6
    //   143: ifnull -> 152
    //   146: aload #4
    //   148: astore_3
    //   149: goto -> 108
    //   152: aload #5
    //   154: invokevirtual isEmpty : ()Z
    //   157: ifne -> 190
    //   160: new java/lang/StringBuilder
    //   163: dup
    //   164: ldc 'Reading app Locales : Locales read from file: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file , appLocales: '
    //   166: invokespecial <init> : (Ljava/lang/String;)V
    //   169: astore_0
    //   170: aload_0
    //   171: aload #5
    //   173: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: pop
    //   177: ldc 'AppLocalesStorageHelper'
    //   179: aload_0
    //   180: invokevirtual toString : ()Ljava/lang/String;
    //   183: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   186: pop
    //   187: aload #5
    //   189: areturn
    //   190: aload_0
    //   191: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   193: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   196: pop
    //   197: aload #5
    //   199: areturn
    //   200: aload #6
    //   202: ifnull -> 210
    //   205: aload #6
    //   207: invokevirtual close : ()V
    //   210: aload_0
    //   211: athrow
    //   212: ldc 'AppLocalesStorageHelper'
    //   214: ldc 'Reading app Locales : Locales record file not found: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   216: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   219: pop
    //   220: ldc ''
    //   222: areturn
    //   223: astore_0
    //   224: goto -> 212
    //   227: astore_3
    //   228: goto -> 129
    //   231: astore #4
    //   233: goto -> 119
    //   236: astore_3
    //   237: goto -> 210
    //   240: iload_2
    //   241: iconst_3
    //   242: if_icmpeq -> 36
    //   245: iload_2
    //   246: iconst_4
    //   247: if_icmpne -> 74
    //   250: goto -> 36
    // Exception table:
    //   from	to	target	type
    //   4	12	223	java/io/FileNotFoundException
    //   12	36	227	org/xmlpull/v1/XmlPullParserException
    //   12	36	227	java/io/IOException
    //   12	36	125	finally
    //   36	44	227	org/xmlpull/v1/XmlPullParserException
    //   36	44	227	java/io/IOException
    //   36	44	125	finally
    //   60	71	227	org/xmlpull/v1/XmlPullParserException
    //   60	71	227	java/io/IOException
    //   60	71	125	finally
    //   74	100	227	org/xmlpull/v1/XmlPullParserException
    //   74	100	227	java/io/IOException
    //   74	100	125	finally
    //   108	113	231	java/io/IOException
    //   129	137	125	finally
    //   205	210	236	java/io/IOException
  }
  
  static void syncLocalesToFramework(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 33) {
      ComponentName componentName = new ComponentName(paramContext, "androidx.appcompat.app.AppLocalesMetadataHolderService");
      if (paramContext.getPackageManager().getComponentEnabledSetting(componentName) != 1) {
        if (AppCompatDelegate.getApplicationLocales().isEmpty()) {
          String str = readLocales(paramContext);
          Object object = paramContext.getSystemService("locale");
          if (object != null)
            AppCompatDelegate.Api33Impl.localeManagerSetApplicationLocales(object, AppCompatDelegate.Api24Impl.localeListForLanguageTags(str)); 
        } 
        paramContext.getPackageManager().setComponentEnabledSetting(componentName, 1, 1);
      } 
    } 
  }
  
  static class SerialExecutor implements Executor {
    Runnable mActive;
    
    final Executor mExecutor;
    
    private final Object mLock = new Object();
    
    final Queue<Runnable> mTasks = new ArrayDeque<Runnable>();
    
    SerialExecutor(Executor param1Executor) {
      this.mExecutor = param1Executor;
    }
    
    public void execute(Runnable param1Runnable) {
      synchronized (this.mLock) {
        this.mTasks.add(new AppLocalesStorageHelper$SerialExecutor$$ExternalSyntheticLambda0(this, param1Runnable));
        if (this.mActive == null)
          scheduleNext(); 
        return;
      } 
    }
    
    protected void scheduleNext() {
      synchronized (this.mLock) {
        Runnable runnable = this.mTasks.poll();
        this.mActive = runnable;
        if (runnable != null)
          this.mExecutor.execute(runnable); 
        return;
      } 
    }
  }
  
  static class ThreadPerTaskExecutor implements Executor {
    public void execute(Runnable param1Runnable) {
      (new Thread(param1Runnable)).start();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\appcompat\app\AppLocalesStorageHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */