package androidx.activity;

import android.content.Context;
import androidx.activity.contextaware.OnContextAvailableListener;



/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\activity\ComponentActivity$$ExternalSyntheticLambda2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */