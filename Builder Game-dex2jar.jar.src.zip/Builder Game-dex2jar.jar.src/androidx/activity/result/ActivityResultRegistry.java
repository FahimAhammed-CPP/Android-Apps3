package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.core.app.ActivityOptionsCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class ActivityResultRegistry {
  private static final int INITIAL_REQUEST_CODE_VALUE = 65536;
  
  private static final String KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS = "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS";
  
  private static final String KEY_COMPONENT_ACTIVITY_PENDING_RESULTS = "KEY_COMPONENT_ACTIVITY_PENDING_RESULT";
  
  private static final String KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT = "KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT";
  
  private static final String KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS = "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS";
  
  private static final String KEY_COMPONENT_ACTIVITY_REGISTERED_RCS = "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS";
  
  private static final String LOG_TAG = "ActivityResultRegistry";
  
  final transient Map<String, CallbackAndContract<?>> mKeyToCallback = new HashMap<String, CallbackAndContract<?>>();
  
  private final Map<String, LifecycleContainer> mKeyToLifecycleContainers = new HashMap<String, LifecycleContainer>();
  
  final Map<String, Integer> mKeyToRc = new HashMap<String, Integer>();
  
  ArrayList<String> mLaunchedKeys = new ArrayList<String>();
  
  final Map<String, Object> mParsedPendingResults = new HashMap<String, Object>();
  
  final Bundle mPendingResults = new Bundle();
  
  private Random mRandom = new Random();
  
  private final Map<Integer, String> mRcToKey = new HashMap<Integer, String>();
  
  private void bindRcKey(int paramInt, String paramString) {
    this.mRcToKey.put(Integer.valueOf(paramInt), paramString);
    this.mKeyToRc.put(paramString, Integer.valueOf(paramInt));
  }
  
  private <O> void doDispatch(String paramString, int paramInt, Intent paramIntent, CallbackAndContract<O> paramCallbackAndContract) {
    if (paramCallbackAndContract != null && paramCallbackAndContract.mCallback != null && this.mLaunchedKeys.contains(paramString)) {
      paramCallbackAndContract.mCallback.onActivityResult((O)paramCallbackAndContract.mContract.parseResult(paramInt, paramIntent));
      this.mLaunchedKeys.remove(paramString);
      return;
    } 
    this.mParsedPendingResults.remove(paramString);
    this.mPendingResults.putParcelable(paramString, new ActivityResult(paramInt, paramIntent));
  }
  
  private int generateRandomNumber() {
    int i = this.mRandom.nextInt(2147418112);
    while (true) {
      i += 65536;
      if (this.mRcToKey.containsKey(Integer.valueOf(i))) {
        i = this.mRandom.nextInt(2147418112);
        continue;
      } 
      return i;
    } 
  }
  
  private void registerKey(String paramString) {
    if ((Integer)this.mKeyToRc.get(paramString) != null)
      return; 
    bindRcKey(generateRandomNumber(), paramString);
  }
  
  public final boolean dispatchResult(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = this.mRcToKey.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    doDispatch(str, paramInt2, paramIntent, this.mKeyToCallback.get(str));
    return true;
  }
  
  public final <O> boolean dispatchResult(int paramInt, O paramO) {
    String str = this.mRcToKey.get(Integer.valueOf(paramInt));
    if (str == null)
      return false; 
    CallbackAndContract callbackAndContract = this.mKeyToCallback.get(str);
    if (callbackAndContract == null || callbackAndContract.mCallback == null) {
      this.mPendingResults.remove(str);
      this.mParsedPendingResults.put(str, paramO);
      return true;
    } 
    ActivityResultCallback<O> activityResultCallback = callbackAndContract.mCallback;
    if (this.mLaunchedKeys.remove(str))
      activityResultCallback.onActivityResult(paramO); 
    return true;
  }
  
  public abstract <I, O> void onLaunch(int paramInt, ActivityResultContract<I, O> paramActivityResultContract, I paramI, ActivityOptionsCompat paramActivityOptionsCompat);
  
  public final void onRestoreInstanceState(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    ArrayList<Integer> arrayList = paramBundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
    ArrayList<String> arrayList1 = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
    if (arrayList1 != null) {
      if (arrayList == null)
        return; 
      this.mLaunchedKeys = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
      this.mRandom = (Random)paramBundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
      this.mPendingResults.putAll(paramBundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
      for (int i = 0; i < arrayList1.size(); i++) {
        String str = arrayList1.get(i);
        if (this.mKeyToRc.containsKey(str)) {
          Integer integer = this.mKeyToRc.remove(str);
          if (!this.mPendingResults.containsKey(str))
            this.mRcToKey.remove(integer); 
        } 
        bindRcKey(((Integer)arrayList.get(i)).intValue(), arrayList1.get(i));
      } 
    } 
  }
  
  public final void onSaveInstanceState(Bundle paramBundle) {
    paramBundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.mKeyToRc.values()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.mKeyToRc.keySet()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<String>(this.mLaunchedKeys));
    paramBundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)this.mPendingResults.clone());
    paramBundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.mRandom);
  }
  
  public final <I, O> ActivityResultLauncher<I> register(final String key, final ActivityResultContract<I, O> contract, ActivityResultCallback<O> paramActivityResultCallback) {
    registerKey(key);
    this.mKeyToCallback.put(key, new CallbackAndContract(paramActivityResultCallback, contract));
    if (this.mParsedPendingResults.containsKey(key)) {
      Object object = this.mParsedPendingResults.get(key);
      this.mParsedPendingResults.remove(key);
      paramActivityResultCallback.onActivityResult((O)object);
    } 
    ActivityResult activityResult = (ActivityResult)this.mPendingResults.getParcelable(key);
    if (activityResult != null) {
      this.mPendingResults.remove(key);
      paramActivityResultCallback.onActivityResult((O)contract.parseResult(activityResult.getResultCode(), activityResult.getData()));
    } 
    return new ActivityResultLauncher<I>() {
        public ActivityResultContract<I, ?> getContract() {
          return contract;
        }
        
        public void launch(I param1I, ActivityOptionsCompat param1ActivityOptionsCompat) {
          Integer integer = ActivityResultRegistry.this.mKeyToRc.get(key);
          if (integer != null) {
            ActivityResultRegistry.this.mLaunchedKeys.add(key);
            try {
              ActivityResultRegistry.this.onLaunch(integer.intValue(), contract, param1I, param1ActivityOptionsCompat);
              return;
            } catch (Exception exception) {
              ActivityResultRegistry.this.mLaunchedKeys.remove(key);
              throw exception;
            } 
          } 
          StringBuilder stringBuilder = new StringBuilder("Attempting to launch an unregistered ActivityResultLauncher with contract ");
          stringBuilder.append(contract);
          stringBuilder.append(" and input ");
          stringBuilder.append(exception);
          stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
          throw new IllegalStateException(stringBuilder.toString());
        }
        
        public void unregister() {
          ActivityResultRegistry.this.unregister(key);
        }
      };
  }
  
  public final <I, O> ActivityResultLauncher<I> register(final String key, LifecycleOwner paramLifecycleOwner, final ActivityResultContract<I, O> contract, final ActivityResultCallback<O> callback) {
    LifecycleContainer lifecycleContainer;
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    if (!lifecycle.getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
      registerKey(key);
      LifecycleContainer lifecycleContainer1 = this.mKeyToLifecycleContainers.get(key);
      lifecycleContainer = lifecycleContainer1;
      if (lifecycleContainer1 == null)
        lifecycleContainer = new LifecycleContainer(lifecycle); 
      lifecycleContainer.addObserver(new LifecycleEventObserver() {
            public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
              if (Lifecycle.Event.ON_START.equals(param1Event)) {
                ActivityResultRegistry.this.mKeyToCallback.put(key, new ActivityResultRegistry.CallbackAndContract(callback, contract));
                if (ActivityResultRegistry.this.mParsedPendingResults.containsKey(key)) {
                  param1LifecycleOwner = (LifecycleOwner)ActivityResultRegistry.this.mParsedPendingResults.get(key);
                  ActivityResultRegistry.this.mParsedPendingResults.remove(key);
                  callback.onActivityResult(param1LifecycleOwner);
                } 
                ActivityResult activityResult = (ActivityResult)ActivityResultRegistry.this.mPendingResults.getParcelable(key);
                if (activityResult != null) {
                  ActivityResultRegistry.this.mPendingResults.remove(key);
                  callback.onActivityResult(contract.parseResult(activityResult.getResultCode(), activityResult.getData()));
                  return;
                } 
              } else {
                if (Lifecycle.Event.ON_STOP.equals(param1Event)) {
                  ActivityResultRegistry.this.mKeyToCallback.remove(key);
                  return;
                } 
                if (Lifecycle.Event.ON_DESTROY.equals(param1Event))
                  ActivityResultRegistry.this.unregister(key); 
              } 
            }
          });
      this.mKeyToLifecycleContainers.put(key, lifecycleContainer);
      return new ActivityResultLauncher<I>() {
          public ActivityResultContract<I, ?> getContract() {
            return contract;
          }
          
          public void launch(I param1I, ActivityOptionsCompat param1ActivityOptionsCompat) {
            Integer integer = ActivityResultRegistry.this.mKeyToRc.get(key);
            if (integer != null) {
              ActivityResultRegistry.this.mLaunchedKeys.add(key);
              try {
                ActivityResultRegistry.this.onLaunch(integer.intValue(), contract, param1I, param1ActivityOptionsCompat);
                return;
              } catch (Exception exception) {
                ActivityResultRegistry.this.mLaunchedKeys.remove(key);
                throw exception;
              } 
            } 
            StringBuilder stringBuilder = new StringBuilder("Attempting to launch an unregistered ActivityResultLauncher with contract ");
            stringBuilder.append(contract);
            stringBuilder.append(" and input ");
            stringBuilder.append(exception);
            stringBuilder.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
            throw new IllegalStateException(stringBuilder.toString());
          }
          
          public void unregister() {
            ActivityResultRegistry.this.unregister(key);
          }
        };
    } 
    StringBuilder stringBuilder = new StringBuilder("LifecycleOwner ");
    stringBuilder.append(lifecycleContainer);
    stringBuilder.append(" is attempting to register while current state is ");
    stringBuilder.append(lifecycle.getCurrentState());
    stringBuilder.append(". LifecycleOwners must call register before they are STARTED.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  final void unregister(String paramString) {
    if (!this.mLaunchedKeys.contains(paramString)) {
      Integer integer = this.mKeyToRc.remove(paramString);
      if (integer != null)
        this.mRcToKey.remove(integer); 
    } 
    this.mKeyToCallback.remove(paramString);
    if (this.mParsedPendingResults.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.mParsedPendingResults.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.mParsedPendingResults.remove(paramString);
    } 
    if (this.mPendingResults.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.mPendingResults.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.mPendingResults.remove(paramString);
    } 
    LifecycleContainer lifecycleContainer = this.mKeyToLifecycleContainers.get(paramString);
    if (lifecycleContainer != null) {
      lifecycleContainer.clearObservers();
      this.mKeyToLifecycleContainers.remove(paramString);
    } 
  }
  
  private static class CallbackAndContract<O> {
    final ActivityResultCallback<O> mCallback;
    
    final ActivityResultContract<?, O> mContract;
    
    CallbackAndContract(ActivityResultCallback<O> param1ActivityResultCallback, ActivityResultContract<?, O> param1ActivityResultContract) {
      this.mCallback = param1ActivityResultCallback;
      this.mContract = param1ActivityResultContract;
    }
  }
  
  private static class LifecycleContainer {
    final Lifecycle mLifecycle;
    
    private final ArrayList<LifecycleEventObserver> mObservers;
    
    LifecycleContainer(Lifecycle param1Lifecycle) {
      this.mLifecycle = param1Lifecycle;
      this.mObservers = new ArrayList<LifecycleEventObserver>();
    }
    
    void addObserver(LifecycleEventObserver param1LifecycleEventObserver) {
      this.mLifecycle.addObserver((LifecycleObserver)param1LifecycleEventObserver);
      this.mObservers.add(param1LifecycleEventObserver);
    }
    
    void clearObservers() {
      for (LifecycleEventObserver lifecycleEventObserver : this.mObservers)
        this.mLifecycle.removeObserver((LifecycleObserver)lifecycleEventObserver); 
      this.mObservers.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */