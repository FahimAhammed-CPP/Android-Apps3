package androidx.activity.result;

import androidx.activity.result.contract.ActivityResultContracts;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\007\030\0002\0020\001:\001\nB\007\b\000¢\006\002\020\002R$\020\005\032\0020\0042\006\020\003\032\0020\004@@X\016¢\006\016\n\000\032\004\b\006\020\007\"\004\b\b\020\t¨\006\013"}, d2 = {"Landroidx/activity/result/PickVisualMediaRequest;", "", "()V", "<set-?>", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "mediaType", "getMediaType", "()Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "setMediaType$activity_release", "(Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;)V", "Builder", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
public final class PickVisualMediaRequest {
  private ActivityResultContracts.PickVisualMedia.VisualMediaType mediaType = (ActivityResultContracts.PickVisualMedia.VisualMediaType)ActivityResultContracts.PickVisualMedia.ImageAndVideo.INSTANCE;
  
  public final ActivityResultContracts.PickVisualMedia.VisualMediaType getMediaType() {
    return this.mediaType;
  }
  
  public final void setMediaType$activity_release(ActivityResultContracts.PickVisualMedia.VisualMediaType paramVisualMediaType) {
    Intrinsics.checkNotNullParameter(paramVisualMediaType, "<set-?>");
    this.mediaType = paramVisualMediaType;
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\030\0002\0020\001B\005¢\006\002\020\002J\006\020\005\032\0020\006J\016\020\007\032\0020\0002\006\020\003\032\0020\004R\016\020\003\032\0020\004X\016¢\006\002\n\000¨\006\b"}, d2 = {"Landroidx/activity/result/PickVisualMediaRequest$Builder;", "", "()V", "mediaType", "Landroidx/activity/result/contract/ActivityResultContracts$PickVisualMedia$VisualMediaType;", "build", "Landroidx/activity/result/PickVisualMediaRequest;", "setMediaType", "activity_release"}, k = 1, mv = {1, 7, 1}, xi = 48)
  public static final class Builder {
    private ActivityResultContracts.PickVisualMedia.VisualMediaType mediaType = (ActivityResultContracts.PickVisualMedia.VisualMediaType)ActivityResultContracts.PickVisualMedia.ImageAndVideo.INSTANCE;
    
    public final PickVisualMediaRequest build() {
      PickVisualMediaRequest pickVisualMediaRequest = new PickVisualMediaRequest();
      pickVisualMediaRequest.setMediaType$activity_release(this.mediaType);
      return pickVisualMediaRequest;
    }
    
    public final Builder setMediaType(ActivityResultContracts.PickVisualMedia.VisualMediaType param1VisualMediaType) {
      Intrinsics.checkNotNullParameter(param1VisualMediaType, "mediaType");
      this.mediaType = param1VisualMediaType;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\activity\result\PickVisualMediaRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */