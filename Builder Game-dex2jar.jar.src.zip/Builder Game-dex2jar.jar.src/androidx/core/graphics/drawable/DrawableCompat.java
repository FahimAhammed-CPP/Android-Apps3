package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.InsetDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class DrawableCompat {
  private static final String TAG = "DrawableCompat";
  
  private static Method sGetLayoutDirectionMethod;
  
  private static boolean sGetLayoutDirectionMethodFetched;
  
  private static Method sSetLayoutDirectionMethod;
  
  private static boolean sSetLayoutDirectionMethodFetched;
  
  public static void applyTheme(Drawable paramDrawable, Resources.Theme paramTheme) {
    Api21Impl.applyTheme(paramDrawable, paramTheme);
  }
  
  public static boolean canApplyTheme(Drawable paramDrawable) {
    return Api21Impl.canApplyTheme(paramDrawable);
  }
  
  public static void clearColorFilter(Drawable paramDrawable) {
    if (Build.VERSION.SDK_INT >= 23) {
      paramDrawable.clearColorFilter();
      return;
    } 
    paramDrawable.clearColorFilter();
    if (paramDrawable instanceof InsetDrawable) {
      clearColorFilter(Api19Impl.getDrawable((InsetDrawable)paramDrawable));
      return;
    } 
    if (paramDrawable instanceof WrappedDrawable) {
      clearColorFilter(((WrappedDrawable)paramDrawable).getWrappedDrawable());
      return;
    } 
    if (paramDrawable instanceof DrawableContainer) {
      DrawableContainer.DrawableContainerState drawableContainerState = (DrawableContainer.DrawableContainerState)((DrawableContainer)paramDrawable).getConstantState();
      if (drawableContainerState != null) {
        int j = drawableContainerState.getChildCount();
        for (int i = 0; i < j; i++) {
          Drawable drawable = Api19Impl.getChild(drawableContainerState, i);
          if (drawable != null)
            clearColorFilter(drawable); 
        } 
      } 
    } 
  }
  
  public static int getAlpha(Drawable paramDrawable) {
    return Api19Impl.getAlpha(paramDrawable);
  }
  
  public static ColorFilter getColorFilter(Drawable paramDrawable) {
    return Api21Impl.getColorFilter(paramDrawable);
  }
  
  public static int getLayoutDirection(Drawable paramDrawable) {
    if (Build.VERSION.SDK_INT >= 23)
      return Api23Impl.getLayoutDirection(paramDrawable); 
    if (!sGetLayoutDirectionMethodFetched) {
      try {
        Method method1 = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
        sGetLayoutDirectionMethod = method1;
        method1.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("DrawableCompat", "Failed to retrieve getLayoutDirection() method", noSuchMethodException);
      } 
      sGetLayoutDirectionMethodFetched = true;
    } 
    Method method = sGetLayoutDirectionMethod;
    if (method != null)
      try {
        return ((Integer)method.invoke(paramDrawable, new Object[0])).intValue();
      } catch (Exception exception) {
        Log.i("DrawableCompat", "Failed to invoke getLayoutDirection() via reflection", exception);
        sGetLayoutDirectionMethod = null;
      }  
    return 0;
  }
  
  public static void inflate(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    Api21Impl.inflate(paramDrawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
  }
  
  public static boolean isAutoMirrored(Drawable paramDrawable) {
    return Api19Impl.isAutoMirrored(paramDrawable);
  }
  
  @Deprecated
  public static void jumpToCurrentState(Drawable paramDrawable) {
    paramDrawable.jumpToCurrentState();
  }
  
  public static void setAutoMirrored(Drawable paramDrawable, boolean paramBoolean) {
    Api19Impl.setAutoMirrored(paramDrawable, paramBoolean);
  }
  
  public static void setHotspot(Drawable paramDrawable, float paramFloat1, float paramFloat2) {
    Api21Impl.setHotspot(paramDrawable, paramFloat1, paramFloat2);
  }
  
  public static void setHotspotBounds(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Api21Impl.setHotspotBounds(paramDrawable, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static boolean setLayoutDirection(Drawable paramDrawable, int paramInt) {
    if (Build.VERSION.SDK_INT >= 23)
      return Api23Impl.setLayoutDirection(paramDrawable, paramInt); 
    if (!sSetLayoutDirectionMethodFetched) {
      try {
        Method method1 = Drawable.class.getDeclaredMethod("setLayoutDirection", new Class[] { int.class });
        sSetLayoutDirectionMethod = method1;
        method1.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("DrawableCompat", "Failed to retrieve setLayoutDirection(int) method", noSuchMethodException);
      } 
      sSetLayoutDirectionMethodFetched = true;
    } 
    Method method = sSetLayoutDirectionMethod;
    if (method != null)
      try {
        method.invoke(paramDrawable, new Object[] { Integer.valueOf(paramInt) });
        return true;
      } catch (Exception exception) {
        Log.i("DrawableCompat", "Failed to invoke setLayoutDirection(int) via reflection", exception);
        sSetLayoutDirectionMethod = null;
      }  
    return false;
  }
  
  public static void setTint(Drawable paramDrawable, int paramInt) {
    Api21Impl.setTint(paramDrawable, paramInt);
  }
  
  public static void setTintList(Drawable paramDrawable, ColorStateList paramColorStateList) {
    Api21Impl.setTintList(paramDrawable, paramColorStateList);
  }
  
  public static void setTintMode(Drawable paramDrawable, PorterDuff.Mode paramMode) {
    Api21Impl.setTintMode(paramDrawable, paramMode);
  }
  
  public static <T extends Drawable> T unwrap(Drawable paramDrawable) {
    Drawable drawable = paramDrawable;
    if (paramDrawable instanceof WrappedDrawable)
      drawable = ((WrappedDrawable)paramDrawable).getWrappedDrawable(); 
    return (T)drawable;
  }
  
  public static Drawable wrap(Drawable paramDrawable) {
    return (Build.VERSION.SDK_INT >= 23) ? paramDrawable : (!(paramDrawable instanceof TintAwareDrawable) ? new WrappedDrawableApi21(paramDrawable) : paramDrawable);
  }
  
  static class Api19Impl {
    static int getAlpha(Drawable param1Drawable) {
      return param1Drawable.getAlpha();
    }
    
    static Drawable getChild(DrawableContainer.DrawableContainerState param1DrawableContainerState, int param1Int) {
      return param1DrawableContainerState.getChild(param1Int);
    }
    
    static Drawable getDrawable(InsetDrawable param1InsetDrawable) {
      return param1InsetDrawable.getDrawable();
    }
    
    static boolean isAutoMirrored(Drawable param1Drawable) {
      return param1Drawable.isAutoMirrored();
    }
    
    static void setAutoMirrored(Drawable param1Drawable, boolean param1Boolean) {
      param1Drawable.setAutoMirrored(param1Boolean);
    }
  }
  
  static class Api21Impl {
    static void applyTheme(Drawable param1Drawable, Resources.Theme param1Theme) {
      param1Drawable.applyTheme(param1Theme);
    }
    
    static boolean canApplyTheme(Drawable param1Drawable) {
      return param1Drawable.canApplyTheme();
    }
    
    static ColorFilter getColorFilter(Drawable param1Drawable) {
      return param1Drawable.getColorFilter();
    }
    
    static void inflate(Drawable param1Drawable, Resources param1Resources, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) throws XmlPullParserException, IOException {
      param1Drawable.inflate(param1Resources, param1XmlPullParser, param1AttributeSet, param1Theme);
    }
    
    static void setHotspot(Drawable param1Drawable, float param1Float1, float param1Float2) {
      param1Drawable.setHotspot(param1Float1, param1Float2);
    }
    
    static void setHotspotBounds(Drawable param1Drawable, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1Drawable.setHotspotBounds(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void setTint(Drawable param1Drawable, int param1Int) {
      param1Drawable.setTint(param1Int);
    }
    
    static void setTintList(Drawable param1Drawable, ColorStateList param1ColorStateList) {
      param1Drawable.setTintList(param1ColorStateList);
    }
    
    static void setTintMode(Drawable param1Drawable, PorterDuff.Mode param1Mode) {
      param1Drawable.setTintMode(param1Mode);
    }
  }
  
  static class Api23Impl {
    static int getLayoutDirection(Drawable param1Drawable) {
      return param1Drawable.getLayoutDirection();
    }
    
    static boolean setLayoutDirection(Drawable param1Drawable, int param1Int) {
      return param1Drawable.setLayoutDirection(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\graphics\drawable\DrawableCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */