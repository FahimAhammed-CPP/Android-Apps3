package androidx.core.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Parcelable;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.ActionProvider;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ShareActionProvider;
import androidx.core.util.Preconditions;
import java.util.ArrayList;

public final class ShareCompat {
  public static final String EXTRA_CALLING_ACTIVITY = "androidx.core.app.EXTRA_CALLING_ACTIVITY";
  
  public static final String EXTRA_CALLING_ACTIVITY_INTEROP = "android.support.v4.app.EXTRA_CALLING_ACTIVITY";
  
  public static final String EXTRA_CALLING_PACKAGE = "androidx.core.app.EXTRA_CALLING_PACKAGE";
  
  public static final String EXTRA_CALLING_PACKAGE_INTEROP = "android.support.v4.app.EXTRA_CALLING_PACKAGE";
  
  private static final String HISTORY_FILENAME_PREFIX = ".sharecompat_";
  
  @Deprecated
  public static void configureMenuItem(Menu paramMenu, int paramInt, IntentBuilder paramIntentBuilder) {
    MenuItem menuItem = paramMenu.findItem(paramInt);
    if (menuItem != null) {
      configureMenuItem(menuItem, paramIntentBuilder);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder("Could not find menu item with id ");
    stringBuilder.append(paramInt);
    stringBuilder.append(" in the supplied menu");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  @Deprecated
  public static void configureMenuItem(MenuItem paramMenuItem, IntentBuilder paramIntentBuilder) {
    ShareActionProvider shareActionProvider;
    ActionProvider actionProvider = paramMenuItem.getActionProvider();
    if (!(actionProvider instanceof ShareActionProvider)) {
      shareActionProvider = new ShareActionProvider(paramIntentBuilder.getContext());
    } else {
      shareActionProvider = shareActionProvider;
    } 
    StringBuilder stringBuilder = new StringBuilder(".sharecompat_");
    stringBuilder.append(paramIntentBuilder.getContext().getClass().getName());
    shareActionProvider.setShareHistoryFileName(stringBuilder.toString());
    shareActionProvider.setShareIntent(paramIntentBuilder.getIntent());
    paramMenuItem.setActionProvider((ActionProvider)shareActionProvider);
  }
  
  public static ComponentName getCallingActivity(Activity paramActivity) {
    Intent intent = paramActivity.getIntent();
    ComponentName componentName2 = paramActivity.getCallingActivity();
    ComponentName componentName1 = componentName2;
    if (componentName2 == null)
      componentName1 = getCallingActivity(intent); 
    return componentName1;
  }
  
  static ComponentName getCallingActivity(Intent paramIntent) {
    ComponentName componentName2 = (ComponentName)paramIntent.getParcelableExtra("androidx.core.app.EXTRA_CALLING_ACTIVITY");
    ComponentName componentName1 = componentName2;
    if (componentName2 == null)
      componentName1 = (ComponentName)paramIntent.getParcelableExtra("android.support.v4.app.EXTRA_CALLING_ACTIVITY"); 
    return componentName1;
  }
  
  public static String getCallingPackage(Activity paramActivity) {
    Intent intent = paramActivity.getIntent();
    String str2 = paramActivity.getCallingPackage();
    String str1 = str2;
    if (str2 == null) {
      str1 = str2;
      if (intent != null)
        str1 = getCallingPackage(intent); 
    } 
    return str1;
  }
  
  static String getCallingPackage(Intent paramIntent) {
    String str2 = paramIntent.getStringExtra("androidx.core.app.EXTRA_CALLING_PACKAGE");
    String str1 = str2;
    if (str2 == null)
      str1 = paramIntent.getStringExtra("android.support.v4.app.EXTRA_CALLING_PACKAGE"); 
    return str1;
  }
  
  private static class Api16Impl {
    static String escapeHtml(CharSequence param1CharSequence) {
      return Html.escapeHtml(param1CharSequence);
    }
    
    static void migrateExtraStreamToClipData(Intent param1Intent, ArrayList<Uri> param1ArrayList) {
      CharSequence charSequence = param1Intent.getCharSequenceExtra("android.intent.extra.TEXT");
      String str2 = param1Intent.getStringExtra("android.intent.extra.HTML_TEXT");
      String str1 = param1Intent.getType();
      ClipData.Item item = new ClipData.Item(charSequence, str2, null, param1ArrayList.get(0));
      ClipData clipData = new ClipData(null, new String[] { str1 }, item);
      int j = param1ArrayList.size();
      for (int i = 1; i < j; i++)
        clipData.addItem(new ClipData.Item(param1ArrayList.get(i))); 
      param1Intent.setClipData(clipData);
      param1Intent.addFlags(1);
    }
    
    static void removeClipData(Intent param1Intent) {
      param1Intent.setClipData(null);
      param1Intent.setFlags(param1Intent.getFlags() & 0xFFFFFFFE);
    }
  }
  
  public static class IntentBuilder {
    private ArrayList<String> mBccAddresses;
    
    private ArrayList<String> mCcAddresses;
    
    private CharSequence mChooserTitle;
    
    private final Context mContext;
    
    private final Intent mIntent;
    
    private ArrayList<Uri> mStreams;
    
    private ArrayList<String> mToAddresses;
    
    public IntentBuilder(Context param1Context) {
      this.mContext = (Context)Preconditions.checkNotNull(param1Context);
      Intent intent = (new Intent()).setAction("android.intent.action.SEND");
      this.mIntent = intent;
      intent.putExtra("androidx.core.app.EXTRA_CALLING_PACKAGE", param1Context.getPackageName());
      intent.putExtra("android.support.v4.app.EXTRA_CALLING_PACKAGE", param1Context.getPackageName());
      intent.addFlags(524288);
      while (true) {
        if (param1Context instanceof ContextWrapper) {
          Activity activity;
          if (param1Context instanceof Activity) {
            activity = (Activity)param1Context;
            break;
          } 
          Context context = ((ContextWrapper)activity).getBaseContext();
          continue;
        } 
        param1Context = null;
        break;
      } 
      if (param1Context != null) {
        ComponentName componentName = param1Context.getComponentName();
        this.mIntent.putExtra("androidx.core.app.EXTRA_CALLING_ACTIVITY", (Parcelable)componentName);
        this.mIntent.putExtra("android.support.v4.app.EXTRA_CALLING_ACTIVITY", (Parcelable)componentName);
      } 
    }
    
    private void combineArrayExtra(String param1String, ArrayList<String> param1ArrayList) {
      byte b;
      String[] arrayOfString1 = this.mIntent.getStringArrayExtra(param1String);
      if (arrayOfString1 != null) {
        b = arrayOfString1.length;
      } else {
        b = 0;
      } 
      String[] arrayOfString2 = new String[param1ArrayList.size() + b];
      param1ArrayList.toArray(arrayOfString2);
      if (arrayOfString1 != null)
        System.arraycopy(arrayOfString1, 0, arrayOfString2, param1ArrayList.size(), b); 
      this.mIntent.putExtra(param1String, arrayOfString2);
    }
    
    private void combineArrayExtra(String param1String, String[] param1ArrayOfString) {
      byte b;
      Intent intent = getIntent();
      String[] arrayOfString1 = intent.getStringArrayExtra(param1String);
      if (arrayOfString1 != null) {
        b = arrayOfString1.length;
      } else {
        b = 0;
      } 
      String[] arrayOfString2 = new String[param1ArrayOfString.length + b];
      if (arrayOfString1 != null)
        System.arraycopy(arrayOfString1, 0, arrayOfString2, 0, b); 
      System.arraycopy(param1ArrayOfString, 0, arrayOfString2, b, param1ArrayOfString.length);
      intent.putExtra(param1String, arrayOfString2);
    }
    
    @Deprecated
    public static IntentBuilder from(Activity param1Activity) {
      return new IntentBuilder((Context)param1Activity);
    }
    
    public IntentBuilder addEmailBcc(String param1String) {
      if (this.mBccAddresses == null)
        this.mBccAddresses = new ArrayList<String>(); 
      this.mBccAddresses.add(param1String);
      return this;
    }
    
    public IntentBuilder addEmailBcc(String[] param1ArrayOfString) {
      combineArrayExtra("android.intent.extra.BCC", param1ArrayOfString);
      return this;
    }
    
    public IntentBuilder addEmailCc(String param1String) {
      if (this.mCcAddresses == null)
        this.mCcAddresses = new ArrayList<String>(); 
      this.mCcAddresses.add(param1String);
      return this;
    }
    
    public IntentBuilder addEmailCc(String[] param1ArrayOfString) {
      combineArrayExtra("android.intent.extra.CC", param1ArrayOfString);
      return this;
    }
    
    public IntentBuilder addEmailTo(String param1String) {
      if (this.mToAddresses == null)
        this.mToAddresses = new ArrayList<String>(); 
      this.mToAddresses.add(param1String);
      return this;
    }
    
    public IntentBuilder addEmailTo(String[] param1ArrayOfString) {
      combineArrayExtra("android.intent.extra.EMAIL", param1ArrayOfString);
      return this;
    }
    
    public IntentBuilder addStream(Uri param1Uri) {
      if (this.mStreams == null)
        this.mStreams = new ArrayList<Uri>(); 
      this.mStreams.add(param1Uri);
      return this;
    }
    
    public Intent createChooserIntent() {
      return Intent.createChooser(getIntent(), this.mChooserTitle);
    }
    
    Context getContext() {
      return this.mContext;
    }
    
    public Intent getIntent() {
      // Byte code:
      //   0: aload_0
      //   1: getfield mToAddresses : Ljava/util/ArrayList;
      //   4: astore_3
      //   5: aload_3
      //   6: ifnull -> 21
      //   9: aload_0
      //   10: ldc 'android.intent.extra.EMAIL'
      //   12: aload_3
      //   13: invokespecial combineArrayExtra : (Ljava/lang/String;Ljava/util/ArrayList;)V
      //   16: aload_0
      //   17: aconst_null
      //   18: putfield mToAddresses : Ljava/util/ArrayList;
      //   21: aload_0
      //   22: getfield mCcAddresses : Ljava/util/ArrayList;
      //   25: astore_3
      //   26: aload_3
      //   27: ifnull -> 42
      //   30: aload_0
      //   31: ldc 'android.intent.extra.CC'
      //   33: aload_3
      //   34: invokespecial combineArrayExtra : (Ljava/lang/String;Ljava/util/ArrayList;)V
      //   37: aload_0
      //   38: aconst_null
      //   39: putfield mCcAddresses : Ljava/util/ArrayList;
      //   42: aload_0
      //   43: getfield mBccAddresses : Ljava/util/ArrayList;
      //   46: astore_3
      //   47: aload_3
      //   48: ifnull -> 63
      //   51: aload_0
      //   52: ldc 'android.intent.extra.BCC'
      //   54: aload_3
      //   55: invokespecial combineArrayExtra : (Ljava/lang/String;Ljava/util/ArrayList;)V
      //   58: aload_0
      //   59: aconst_null
      //   60: putfield mBccAddresses : Ljava/util/ArrayList;
      //   63: aload_0
      //   64: getfield mStreams : Ljava/util/ArrayList;
      //   67: astore_3
      //   68: aload_3
      //   69: ifnull -> 87
      //   72: aload_3
      //   73: invokevirtual size : ()I
      //   76: istore_2
      //   77: iconst_1
      //   78: istore_1
      //   79: iload_2
      //   80: iconst_1
      //   81: if_icmple -> 87
      //   84: goto -> 89
      //   87: iconst_0
      //   88: istore_1
      //   89: iload_1
      //   90: ifne -> 173
      //   93: aload_0
      //   94: getfield mIntent : Landroid/content/Intent;
      //   97: ldc 'android.intent.action.SEND'
      //   99: invokevirtual setAction : (Ljava/lang/String;)Landroid/content/Intent;
      //   102: pop
      //   103: aload_0
      //   104: getfield mStreams : Ljava/util/ArrayList;
      //   107: astore_3
      //   108: aload_3
      //   109: ifnull -> 154
      //   112: aload_3
      //   113: invokevirtual isEmpty : ()Z
      //   116: ifne -> 154
      //   119: aload_0
      //   120: getfield mIntent : Landroid/content/Intent;
      //   123: ldc 'android.intent.extra.STREAM'
      //   125: aload_0
      //   126: getfield mStreams : Ljava/util/ArrayList;
      //   129: iconst_0
      //   130: invokevirtual get : (I)Ljava/lang/Object;
      //   133: checkcast android/os/Parcelable
      //   136: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
      //   139: pop
      //   140: aload_0
      //   141: getfield mIntent : Landroid/content/Intent;
      //   144: aload_0
      //   145: getfield mStreams : Ljava/util/ArrayList;
      //   148: invokestatic migrateExtraStreamToClipData : (Landroid/content/Intent;Ljava/util/ArrayList;)V
      //   151: goto -> 208
      //   154: aload_0
      //   155: getfield mIntent : Landroid/content/Intent;
      //   158: ldc 'android.intent.extra.STREAM'
      //   160: invokevirtual removeExtra : (Ljava/lang/String;)V
      //   163: aload_0
      //   164: getfield mIntent : Landroid/content/Intent;
      //   167: invokestatic removeClipData : (Landroid/content/Intent;)V
      //   170: goto -> 208
      //   173: aload_0
      //   174: getfield mIntent : Landroid/content/Intent;
      //   177: ldc 'android.intent.action.SEND_MULTIPLE'
      //   179: invokevirtual setAction : (Ljava/lang/String;)Landroid/content/Intent;
      //   182: pop
      //   183: aload_0
      //   184: getfield mIntent : Landroid/content/Intent;
      //   187: ldc 'android.intent.extra.STREAM'
      //   189: aload_0
      //   190: getfield mStreams : Ljava/util/ArrayList;
      //   193: invokevirtual putParcelableArrayListExtra : (Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;
      //   196: pop
      //   197: aload_0
      //   198: getfield mIntent : Landroid/content/Intent;
      //   201: aload_0
      //   202: getfield mStreams : Ljava/util/ArrayList;
      //   205: invokestatic migrateExtraStreamToClipData : (Landroid/content/Intent;Ljava/util/ArrayList;)V
      //   208: aload_0
      //   209: getfield mIntent : Landroid/content/Intent;
      //   212: areturn
    }
    
    public IntentBuilder setChooserTitle(int param1Int) {
      return setChooserTitle(this.mContext.getText(param1Int));
    }
    
    public IntentBuilder setChooserTitle(CharSequence param1CharSequence) {
      this.mChooserTitle = param1CharSequence;
      return this;
    }
    
    public IntentBuilder setEmailBcc(String[] param1ArrayOfString) {
      this.mIntent.putExtra("android.intent.extra.BCC", param1ArrayOfString);
      return this;
    }
    
    public IntentBuilder setEmailCc(String[] param1ArrayOfString) {
      this.mIntent.putExtra("android.intent.extra.CC", param1ArrayOfString);
      return this;
    }
    
    public IntentBuilder setEmailTo(String[] param1ArrayOfString) {
      if (this.mToAddresses != null)
        this.mToAddresses = null; 
      this.mIntent.putExtra("android.intent.extra.EMAIL", param1ArrayOfString);
      return this;
    }
    
    public IntentBuilder setHtmlText(String param1String) {
      this.mIntent.putExtra("android.intent.extra.HTML_TEXT", param1String);
      if (!this.mIntent.hasExtra("android.intent.extra.TEXT"))
        setText((CharSequence)Html.fromHtml(param1String)); 
      return this;
    }
    
    public IntentBuilder setStream(Uri param1Uri) {
      this.mStreams = null;
      if (param1Uri != null)
        addStream(param1Uri); 
      return this;
    }
    
    public IntentBuilder setSubject(String param1String) {
      this.mIntent.putExtra("android.intent.extra.SUBJECT", param1String);
      return this;
    }
    
    public IntentBuilder setText(CharSequence param1CharSequence) {
      this.mIntent.putExtra("android.intent.extra.TEXT", param1CharSequence);
      return this;
    }
    
    public IntentBuilder setType(String param1String) {
      this.mIntent.setType(param1String);
      return this;
    }
    
    public void startChooser() {
      this.mContext.startActivity(createChooserIntent());
    }
  }
  
  public static class IntentReader {
    private static final String TAG = "IntentReader";
    
    private final ComponentName mCallingActivity;
    
    private final String mCallingPackage;
    
    private final Context mContext;
    
    private final Intent mIntent;
    
    private ArrayList<Uri> mStreams;
    
    public IntentReader(Activity param1Activity) {
      this((Context)Preconditions.checkNotNull(param1Activity), param1Activity.getIntent());
    }
    
    public IntentReader(Context param1Context, Intent param1Intent) {
      this.mContext = (Context)Preconditions.checkNotNull(param1Context);
      this.mIntent = (Intent)Preconditions.checkNotNull(param1Intent);
      this.mCallingPackage = ShareCompat.getCallingPackage(param1Intent);
      this.mCallingActivity = ShareCompat.getCallingActivity(param1Intent);
    }
    
    @Deprecated
    public static IntentReader from(Activity param1Activity) {
      return new IntentReader(param1Activity);
    }
    
    private static void withinStyle(StringBuilder param1StringBuilder, CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      while (param1Int1 < param1Int2) {
        char c = param1CharSequence.charAt(param1Int1);
        if (c == '<') {
          param1StringBuilder.append("&lt;");
        } else if (c == '>') {
          param1StringBuilder.append("&gt;");
        } else if (c == '&') {
          param1StringBuilder.append("&amp;");
        } else if (c > '~' || c < ' ') {
          param1StringBuilder.append("&#");
          param1StringBuilder.append(c);
          param1StringBuilder.append(";");
        } else if (c == ' ') {
          while (true) {
            int i = param1Int1 + 1;
            if (i < param1Int2 && param1CharSequence.charAt(i) == ' ') {
              param1StringBuilder.append("&nbsp;");
              param1Int1 = i;
              continue;
            } 
            break;
          } 
          param1StringBuilder.append(' ');
        } else {
          param1StringBuilder.append(c);
        } 
        param1Int1++;
      } 
    }
    
    public ComponentName getCallingActivity() {
      return this.mCallingActivity;
    }
    
    public Drawable getCallingActivityIcon() {
      if (this.mCallingActivity == null)
        return null; 
      PackageManager packageManager = this.mContext.getPackageManager();
      try {
        return packageManager.getActivityIcon(this.mCallingActivity);
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.e("IntentReader", "Could not retrieve icon for calling activity", (Throwable)nameNotFoundException);
        return null;
      } 
    }
    
    public Drawable getCallingApplicationIcon() {
      if (this.mCallingPackage == null)
        return null; 
      PackageManager packageManager = this.mContext.getPackageManager();
      try {
        return packageManager.getApplicationIcon(this.mCallingPackage);
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.e("IntentReader", "Could not retrieve icon for calling application", (Throwable)nameNotFoundException);
        return null;
      } 
    }
    
    public CharSequence getCallingApplicationLabel() {
      if (this.mCallingPackage == null)
        return null; 
      PackageManager packageManager = this.mContext.getPackageManager();
      try {
        return packageManager.getApplicationLabel(packageManager.getApplicationInfo(this.mCallingPackage, 0));
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.e("IntentReader", "Could not retrieve label for calling application", (Throwable)nameNotFoundException);
        return null;
      } 
    }
    
    public String getCallingPackage() {
      return this.mCallingPackage;
    }
    
    public String[] getEmailBcc() {
      return this.mIntent.getStringArrayExtra("android.intent.extra.BCC");
    }
    
    public String[] getEmailCc() {
      return this.mIntent.getStringArrayExtra("android.intent.extra.CC");
    }
    
    public String[] getEmailTo() {
      return this.mIntent.getStringArrayExtra("android.intent.extra.EMAIL");
    }
    
    public String getHtmlText() {
      String str2 = this.mIntent.getStringExtra("android.intent.extra.HTML_TEXT");
      String str1 = str2;
      if (str2 == null) {
        CharSequence charSequence = getText();
        if (charSequence instanceof Spanned)
          return Html.toHtml((Spanned)charSequence); 
        str1 = str2;
        if (charSequence != null)
          str1 = ShareCompat.Api16Impl.escapeHtml(charSequence); 
      } 
      return str1;
    }
    
    public Uri getStream() {
      return (Uri)this.mIntent.getParcelableExtra("android.intent.extra.STREAM");
    }
    
    public Uri getStream(int param1Int) {
      if (this.mStreams == null && isMultipleShare())
        this.mStreams = this.mIntent.getParcelableArrayListExtra("android.intent.extra.STREAM"); 
      ArrayList<Uri> arrayList = this.mStreams;
      if (arrayList != null)
        return arrayList.get(param1Int); 
      if (param1Int == 0)
        return (Uri)this.mIntent.getParcelableExtra("android.intent.extra.STREAM"); 
      StringBuilder stringBuilder = new StringBuilder("Stream items available: ");
      stringBuilder.append(getStreamCount());
      stringBuilder.append(" index requested: ");
      stringBuilder.append(param1Int);
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    public int getStreamCount() {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public String getSubject() {
      return this.mIntent.getStringExtra("android.intent.extra.SUBJECT");
    }
    
    public CharSequence getText() {
      return this.mIntent.getCharSequenceExtra("android.intent.extra.TEXT");
    }
    
    public String getType() {
      return this.mIntent.getType();
    }
    
    public boolean isMultipleShare() {
      return "android.intent.action.SEND_MULTIPLE".equals(this.mIntent.getAction());
    }
    
    public boolean isShareIntent() {
      String str = this.mIntent.getAction();
      return ("android.intent.action.SEND".equals(str) || "android.intent.action.SEND_MULTIPLE".equals(str));
    }
    
    public boolean isSingleShare() {
      return "android.intent.action.SEND".equals(this.mIntent.getAction());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\app\ShareCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */