package androidx.core.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.Build;

public final class AlarmManagerCompat {
  public static void setAlarmClock(AlarmManager paramAlarmManager, long paramLong, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2) {
    Api21Impl.setAlarmClock(paramAlarmManager, Api21Impl.createAlarmClockInfo(paramLong, paramPendingIntent1), paramPendingIntent2);
  }
  
  public static void setAndAllowWhileIdle(AlarmManager paramAlarmManager, int paramInt, long paramLong, PendingIntent paramPendingIntent) {
    if (Build.VERSION.SDK_INT >= 23) {
      Api23Impl.setAndAllowWhileIdle(paramAlarmManager, paramInt, paramLong, paramPendingIntent);
      return;
    } 
    paramAlarmManager.set(paramInt, paramLong, paramPendingIntent);
  }
  
  public static void setExact(AlarmManager paramAlarmManager, int paramInt, long paramLong, PendingIntent paramPendingIntent) {
    Api19Impl.setExact(paramAlarmManager, paramInt, paramLong, paramPendingIntent);
  }
  
  public static void setExactAndAllowWhileIdle(AlarmManager paramAlarmManager, int paramInt, long paramLong, PendingIntent paramPendingIntent) {
    if (Build.VERSION.SDK_INT >= 23) {
      Api23Impl.setExactAndAllowWhileIdle(paramAlarmManager, paramInt, paramLong, paramPendingIntent);
      return;
    } 
    setExact(paramAlarmManager, paramInt, paramLong, paramPendingIntent);
  }
  
  static class Api19Impl {
    static void setExact(AlarmManager param1AlarmManager, int param1Int, long param1Long, PendingIntent param1PendingIntent) {
      param1AlarmManager.setExact(param1Int, param1Long, param1PendingIntent);
    }
  }
  
  static class Api21Impl {
    static AlarmManager.AlarmClockInfo createAlarmClockInfo(long param1Long, PendingIntent param1PendingIntent) {
      return new AlarmManager.AlarmClockInfo(param1Long, param1PendingIntent);
    }
    
    static void setAlarmClock(AlarmManager param1AlarmManager, Object param1Object, PendingIntent param1PendingIntent) {
      param1AlarmManager.setAlarmClock((AlarmManager.AlarmClockInfo)param1Object, param1PendingIntent);
    }
  }
  
  static class Api23Impl {
    static void setAndAllowWhileIdle(AlarmManager param1AlarmManager, int param1Int, long param1Long, PendingIntent param1PendingIntent) {
      param1AlarmManager.setAndAllowWhileIdle(param1Int, param1Long, param1PendingIntent);
    }
    
    static void setExactAndAllowWhileIdle(AlarmManager param1AlarmManager, int param1Int, long param1Long, PendingIntent param1PendingIntent) {
      param1AlarmManager.setExactAndAllowWhileIdle(param1Int, param1Long, param1PendingIntent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\app\AlarmManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */