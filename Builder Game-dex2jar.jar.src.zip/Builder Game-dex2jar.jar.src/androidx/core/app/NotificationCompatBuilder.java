package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.collection.ArraySet;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

class NotificationCompatBuilder implements NotificationBuilderWithBuilderAccessor {
  private final List<Bundle> mActionExtrasList;
  
  private RemoteViews mBigContentView;
  
  private final Notification.Builder mBuilder;
  
  private final NotificationCompat.Builder mBuilderCompat;
  
  private RemoteViews mContentView;
  
  private final Context mContext;
  
  private final Bundle mExtras;
  
  private int mGroupAlertBehavior;
  
  private RemoteViews mHeadsUpContentView;
  
  NotificationCompatBuilder(NotificationCompat.Builder paramBuilder) {
    boolean bool;
    List<String> list;
    this.mActionExtrasList = new ArrayList<Bundle>();
    this.mExtras = new Bundle();
    this.mBuilderCompat = paramBuilder;
    this.mContext = paramBuilder.mContext;
    if (Build.VERSION.SDK_INT >= 26) {
      this.mBuilder = new Notification.Builder(paramBuilder.mContext, paramBuilder.mChannelId);
    } else {
      this.mBuilder = new Notification.Builder(paramBuilder.mContext);
    } 
    Notification notification = paramBuilder.mNotification;
    Notification.Builder builder = this.mBuilder.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramBuilder.mTickerView).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramBuilder.mContentTitle).setContentText(paramBuilder.mContentText).setContentInfo(paramBuilder.mContentInfo).setContentIntent(paramBuilder.mContentIntent).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramBuilder.mFullScreenIntent;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(paramBuilder.mLargeIcon).setNumber(paramBuilder.mNumber).setProgress(paramBuilder.mProgressMax, paramBuilder.mProgress, paramBuilder.mProgressIndeterminate);
    this.mBuilder.setSubText(paramBuilder.mSubText).setUsesChronometer(paramBuilder.mUseChronometer).setPriority(paramBuilder.mPriority);
    Iterator<NotificationCompat.Action> iterator = paramBuilder.mActions.iterator();
    while (iterator.hasNext())
      addAction(iterator.next()); 
    if (paramBuilder.mExtras != null)
      this.mExtras.putAll(paramBuilder.mExtras); 
    this.mContentView = paramBuilder.mContentView;
    this.mBigContentView = paramBuilder.mBigContentView;
    this.mBuilder.setShowWhen(paramBuilder.mShowWhen);
    this.mBuilder.setLocalOnly(paramBuilder.mLocalOnly).setGroup(paramBuilder.mGroupKey).setGroupSummary(paramBuilder.mGroupSummary).setSortKey(paramBuilder.mSortKey);
    this.mGroupAlertBehavior = paramBuilder.mGroupAlertBehavior;
    this.mBuilder.setCategory(paramBuilder.mCategory).setColor(paramBuilder.mColor).setVisibility(paramBuilder.mVisibility).setPublicVersion(paramBuilder.mPublicVersion).setSound(notification.sound, notification.audioAttributes);
    if (Build.VERSION.SDK_INT < 28) {
      list = combineLists(getPeople(paramBuilder.mPersonList), paramBuilder.mPeople);
    } else {
      list = paramBuilder.mPeople;
    } 
    if (list != null && !list.isEmpty())
      for (String str : list)
        this.mBuilder.addPerson(str);  
    this.mHeadsUpContentView = paramBuilder.mHeadsUpContentView;
    if (paramBuilder.mInvisibleActions.size() > 0) {
      Bundle bundle2 = paramBuilder.getExtras().getBundle("android.car.EXTENSIONS");
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle2 = new Bundle(bundle1);
      Bundle bundle3 = new Bundle();
      for (int i = 0; i < paramBuilder.mInvisibleActions.size(); i++)
        bundle3.putBundle(Integer.toString(i), NotificationCompatJellybean.getBundleForAction(paramBuilder.mInvisibleActions.get(i))); 
      bundle1.putBundle("invisible_actions", bundle3);
      bundle2.putBundle("invisible_actions", bundle3);
      paramBuilder.getExtras().putBundle("android.car.EXTENSIONS", bundle1);
      this.mExtras.putBundle("android.car.EXTENSIONS", bundle2);
    } 
    if (Build.VERSION.SDK_INT >= 23 && paramBuilder.mSmallIcon != null)
      this.mBuilder.setSmallIcon(paramBuilder.mSmallIcon); 
    if (Build.VERSION.SDK_INT >= 24) {
      this.mBuilder.setExtras(paramBuilder.mExtras).setRemoteInputHistory(paramBuilder.mRemoteInputHistory);
      if (paramBuilder.mContentView != null)
        this.mBuilder.setCustomContentView(paramBuilder.mContentView); 
      if (paramBuilder.mBigContentView != null)
        this.mBuilder.setCustomBigContentView(paramBuilder.mBigContentView); 
      if (paramBuilder.mHeadsUpContentView != null)
        this.mBuilder.setCustomHeadsUpContentView(paramBuilder.mHeadsUpContentView); 
    } 
    if (Build.VERSION.SDK_INT >= 26) {
      this.mBuilder.setBadgeIconType(paramBuilder.mBadgeIcon).setSettingsText(paramBuilder.mSettingsText).setShortcutId(paramBuilder.mShortcutId).setTimeoutAfter(paramBuilder.mTimeout).setGroupAlertBehavior(paramBuilder.mGroupAlertBehavior);
      if (paramBuilder.mColorizedSet)
        this.mBuilder.setColorized(paramBuilder.mColorized); 
      if (!TextUtils.isEmpty(paramBuilder.mChannelId))
        this.mBuilder.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (Build.VERSION.SDK_INT >= 28)
      for (Person person : paramBuilder.mPersonList)
        this.mBuilder.addPerson(person.toAndroidPerson());  
    if (Build.VERSION.SDK_INT >= 29) {
      this.mBuilder.setAllowSystemGeneratedContextualActions(paramBuilder.mAllowSystemGeneratedContextualActions);
      this.mBuilder.setBubbleMetadata(NotificationCompat.BubbleMetadata.toPlatform(paramBuilder.mBubbleMetadata));
      if (paramBuilder.mLocusId != null)
        this.mBuilder.setLocusId(paramBuilder.mLocusId.toLocusId()); 
    } 
    if (Build.VERSION.SDK_INT >= 31 && paramBuilder.mFgsDeferBehavior != 0)
      this.mBuilder.setForegroundServiceBehavior(paramBuilder.mFgsDeferBehavior); 
    if (paramBuilder.mSilent) {
      if (this.mBuilderCompat.mGroupSummary) {
        this.mGroupAlertBehavior = 2;
      } else {
        this.mGroupAlertBehavior = 1;
      } 
      this.mBuilder.setVibrate(null);
      this.mBuilder.setSound(null);
      notification.defaults &= 0xFFFFFFFE;
      notification.defaults &= 0xFFFFFFFD;
      this.mBuilder.setDefaults(notification.defaults);
      if (Build.VERSION.SDK_INT >= 26) {
        if (TextUtils.isEmpty(this.mBuilderCompat.mGroupKey))
          this.mBuilder.setGroup("silent"); 
        this.mBuilder.setGroupAlertBehavior(this.mGroupAlertBehavior);
      } 
    } 
  }
  
  private void addAction(NotificationCompat.Action paramAction) {
    Notification.Action.Builder builder;
    Bundle bundle;
    IconCompat iconCompat = paramAction.getIconCompat();
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i >= 23) {
      if (iconCompat != null) {
        Icon icon = iconCompat.toIcon();
      } else {
        iconCompat = null;
      } 
      builder = new Notification.Action.Builder((Icon)iconCompat, paramAction.getTitle(), paramAction.getActionIntent());
    } else {
      if (builder != null) {
        i = builder.getResId();
      } else {
        i = 0;
      } 
      builder = new Notification.Action.Builder(i, paramAction.getTitle(), paramAction.getActionIntent());
    } 
    if (paramAction.getRemoteInputs() != null) {
      RemoteInput[] arrayOfRemoteInput = RemoteInput.fromCompat(paramAction.getRemoteInputs());
      int j = arrayOfRemoteInput.length;
      for (i = bool; i < j; i++)
        builder.addRemoteInput(arrayOfRemoteInput[i]); 
    } 
    if (paramAction.getExtras() != null) {
      bundle = new Bundle(paramAction.getExtras());
    } else {
      bundle = new Bundle();
    } 
    bundle.putBoolean("android.support.allowGeneratedReplies", paramAction.getAllowGeneratedReplies());
    if (Build.VERSION.SDK_INT >= 24)
      builder.setAllowGeneratedReplies(paramAction.getAllowGeneratedReplies()); 
    bundle.putInt("android.support.action.semanticAction", paramAction.getSemanticAction());
    if (Build.VERSION.SDK_INT >= 28)
      builder.setSemanticAction(paramAction.getSemanticAction()); 
    if (Build.VERSION.SDK_INT >= 29)
      builder.setContextual(paramAction.isContextual()); 
    if (Build.VERSION.SDK_INT >= 31)
      builder.setAuthenticationRequired(paramAction.isAuthenticationRequired()); 
    bundle.putBoolean("android.support.action.showsUserInterface", paramAction.getShowsUserInterface());
    builder.addExtras(bundle);
    this.mBuilder.addAction(builder.build());
  }
  
  private static List<String> combineLists(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    ArraySet arraySet = new ArraySet(paramList1.size() + paramList2.size());
    arraySet.addAll(paramList1);
    arraySet.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)arraySet);
  }
  
  private static List<String> getPeople(List<Person> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<Person> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((Person)iterator.next()).resolveToLegacyUri()); 
    return arrayList;
  }
  
  private void removeSoundAndVibration(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults &= 0xFFFFFFFE;
    paramNotification.defaults &= 0xFFFFFFFD;
  }
  
  public Notification build() {
    RemoteViews remoteViews;
    NotificationCompat.Style style = this.mBuilderCompat.mStyle;
    if (style != null)
      style.apply(this); 
    if (style != null) {
      remoteViews = style.makeContentView(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = buildInternal();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else if (this.mBuilderCompat.mContentView != null) {
      notification.contentView = this.mBuilderCompat.mContentView;
    } 
    if (style != null) {
      remoteViews = style.makeBigContentView(this);
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
    } 
    if (style != null) {
      remoteViews = this.mBuilderCompat.mStyle.makeHeadsUpContentView(this);
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
    } 
    if (style != null) {
      Bundle bundle = NotificationCompat.getExtras(notification);
      if (bundle != null)
        style.addCompatExtras(bundle); 
    } 
    return notification;
  }
  
  protected Notification buildInternal() {
    if (Build.VERSION.SDK_INT >= 26)
      return this.mBuilder.build(); 
    if (Build.VERSION.SDK_INT >= 24) {
      Notification notification1 = this.mBuilder.build();
      if (this.mGroupAlertBehavior != 0) {
        if (notification1.getGroup() != null && (notification1.flags & 0x200) != 0 && this.mGroupAlertBehavior == 2)
          removeSoundAndVibration(notification1); 
        if (notification1.getGroup() != null && (notification1.flags & 0x200) == 0 && this.mGroupAlertBehavior == 1)
          removeSoundAndVibration(notification1); 
      } 
      return notification1;
    } 
    this.mBuilder.setExtras(this.mExtras);
    Notification notification = this.mBuilder.build();
    RemoteViews remoteViews = this.mContentView;
    if (remoteViews != null)
      notification.contentView = remoteViews; 
    remoteViews = this.mBigContentView;
    if (remoteViews != null)
      notification.bigContentView = remoteViews; 
    remoteViews = this.mHeadsUpContentView;
    if (remoteViews != null)
      notification.headsUpContentView = remoteViews; 
    if (this.mGroupAlertBehavior != 0) {
      if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.mGroupAlertBehavior == 2)
        removeSoundAndVibration(notification); 
      if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.mGroupAlertBehavior == 1)
        removeSoundAndVibration(notification); 
    } 
    return notification;
  }
  
  public Notification.Builder getBuilder() {
    return this.mBuilder;
  }
  
  Context getContext() {
    return this.mContext;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\app\NotificationCompatBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */