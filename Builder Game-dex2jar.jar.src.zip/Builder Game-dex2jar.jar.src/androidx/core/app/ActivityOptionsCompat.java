package androidx.core.app;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import androidx.core.util.Pair;

public class ActivityOptionsCompat {
  public static final String EXTRA_USAGE_TIME_REPORT = "android.activity.usage_time";
  
  public static final String EXTRA_USAGE_TIME_REPORT_PACKAGES = "android.usage_time_packages";
  
  public static ActivityOptionsCompat makeBasic() {
    return (Build.VERSION.SDK_INT >= 23) ? new ActivityOptionsCompatImpl(Api23Impl.makeBasic()) : new ActivityOptionsCompat();
  }
  
  public static ActivityOptionsCompat makeClipRevealAnimation(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (Build.VERSION.SDK_INT >= 23) ? new ActivityOptionsCompatImpl(Api23Impl.makeClipRevealAnimation(paramView, paramInt1, paramInt2, paramInt3, paramInt4)) : new ActivityOptionsCompat();
  }
  
  public static ActivityOptionsCompat makeCustomAnimation(Context paramContext, int paramInt1, int paramInt2) {
    return new ActivityOptionsCompatImpl(Api16Impl.makeCustomAnimation(paramContext, paramInt1, paramInt2));
  }
  
  public static ActivityOptionsCompat makeScaleUpAnimation(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return new ActivityOptionsCompatImpl(Api16Impl.makeScaleUpAnimation(paramView, paramInt1, paramInt2, paramInt3, paramInt4));
  }
  
  public static ActivityOptionsCompat makeSceneTransitionAnimation(Activity paramActivity, View paramView, String paramString) {
    return new ActivityOptionsCompatImpl(Api21Impl.makeSceneTransitionAnimation(paramActivity, paramView, paramString));
  }
  
  public static ActivityOptionsCompat makeSceneTransitionAnimation(Activity paramActivity, Pair<View, String>... paramVarArgs) {
    Pair[] arrayOfPair;
    if (paramVarArgs != null) {
      Pair[] arrayOfPair1 = new Pair[paramVarArgs.length];
      int i = 0;
      while (true) {
        arrayOfPair = arrayOfPair1;
        if (i < paramVarArgs.length) {
          arrayOfPair1[i] = Pair.create((paramVarArgs[i]).first, (paramVarArgs[i]).second);
          i++;
          continue;
        } 
        break;
      } 
    } else {
      arrayOfPair = null;
    } 
    return new ActivityOptionsCompatImpl(Api21Impl.makeSceneTransitionAnimation(paramActivity, (Pair<View, String>[])arrayOfPair));
  }
  
  public static ActivityOptionsCompat makeTaskLaunchBehind() {
    return new ActivityOptionsCompatImpl(Api21Impl.makeTaskLaunchBehind());
  }
  
  public static ActivityOptionsCompat makeThumbnailScaleUpAnimation(View paramView, Bitmap paramBitmap, int paramInt1, int paramInt2) {
    return new ActivityOptionsCompatImpl(Api16Impl.makeThumbnailScaleUpAnimation(paramView, paramBitmap, paramInt1, paramInt2));
  }
  
  public Rect getLaunchBounds() {
    return null;
  }
  
  public void requestUsageTimeReport(PendingIntent paramPendingIntent) {}
  
  public ActivityOptionsCompat setLaunchBounds(Rect paramRect) {
    return this;
  }
  
  public Bundle toBundle() {
    return null;
  }
  
  public void update(ActivityOptionsCompat paramActivityOptionsCompat) {}
  
  private static class ActivityOptionsCompatImpl extends ActivityOptionsCompat {
    private final ActivityOptions mActivityOptions;
    
    ActivityOptionsCompatImpl(ActivityOptions param1ActivityOptions) {
      this.mActivityOptions = param1ActivityOptions;
    }
    
    public Rect getLaunchBounds() {
      return (Build.VERSION.SDK_INT < 24) ? null : ActivityOptionsCompat.Api24Impl.getLaunchBounds(this.mActivityOptions);
    }
    
    public void requestUsageTimeReport(PendingIntent param1PendingIntent) {
      if (Build.VERSION.SDK_INT >= 23)
        ActivityOptionsCompat.Api23Impl.requestUsageTimeReport(this.mActivityOptions, param1PendingIntent); 
    }
    
    public ActivityOptionsCompat setLaunchBounds(Rect param1Rect) {
      return (Build.VERSION.SDK_INT < 24) ? this : new ActivityOptionsCompatImpl(ActivityOptionsCompat.Api24Impl.setLaunchBounds(this.mActivityOptions, param1Rect));
    }
    
    public Bundle toBundle() {
      return this.mActivityOptions.toBundle();
    }
    
    public void update(ActivityOptionsCompat param1ActivityOptionsCompat) {
      if (param1ActivityOptionsCompat instanceof ActivityOptionsCompatImpl) {
        param1ActivityOptionsCompat = param1ActivityOptionsCompat;
        this.mActivityOptions.update(((ActivityOptionsCompatImpl)param1ActivityOptionsCompat).mActivityOptions);
      } 
    }
  }
  
  static class Api16Impl {
    static ActivityOptions makeCustomAnimation(Context param1Context, int param1Int1, int param1Int2) {
      return ActivityOptions.makeCustomAnimation(param1Context, param1Int1, param1Int2);
    }
    
    static ActivityOptions makeScaleUpAnimation(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return ActivityOptions.makeScaleUpAnimation(param1View, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static ActivityOptions makeThumbnailScaleUpAnimation(View param1View, Bitmap param1Bitmap, int param1Int1, int param1Int2) {
      return ActivityOptions.makeThumbnailScaleUpAnimation(param1View, param1Bitmap, param1Int1, param1Int2);
    }
  }
  
  static class Api21Impl {
    static ActivityOptions makeSceneTransitionAnimation(Activity param1Activity, View param1View, String param1String) {
      return ActivityOptions.makeSceneTransitionAnimation(param1Activity, param1View, param1String);
    }
    
    @SafeVarargs
    static ActivityOptions makeSceneTransitionAnimation(Activity param1Activity, Pair<View, String>... param1VarArgs) {
      return ActivityOptions.makeSceneTransitionAnimation(param1Activity, (Pair[])param1VarArgs);
    }
    
    static ActivityOptions makeTaskLaunchBehind() {
      return ActivityOptions.makeTaskLaunchBehind();
    }
  }
  
  static class Api23Impl {
    static ActivityOptions makeBasic() {
      return ActivityOptions.makeBasic();
    }
    
    static ActivityOptions makeClipRevealAnimation(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return ActivityOptions.makeClipRevealAnimation(param1View, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void requestUsageTimeReport(ActivityOptions param1ActivityOptions, PendingIntent param1PendingIntent) {
      param1ActivityOptions.requestUsageTimeReport(param1PendingIntent);
    }
  }
  
  static class Api24Impl {
    static Rect getLaunchBounds(ActivityOptions param1ActivityOptions) {
      return param1ActivityOptions.getLaunchBounds();
    }
    
    static ActivityOptions setLaunchBounds(ActivityOptions param1ActivityOptions, Rect param1Rect) {
      return param1ActivityOptions.setLaunchBounds(param1Rect);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\app\ActivityOptionsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */