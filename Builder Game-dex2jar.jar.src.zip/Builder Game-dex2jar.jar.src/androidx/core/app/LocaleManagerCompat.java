package androidx.core.app;

import android.app.LocaleManager;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import androidx.core.os.BuildCompat;
import androidx.core.os.LocaleListCompat;
import java.util.Locale;

public final class LocaleManagerCompat {
  static LocaleListCompat getConfigurationLocales(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? Api24Impl.getLocales(paramConfiguration) : LocaleListCompat.forLanguageTags(Api21Impl.toLanguageTag(paramConfiguration.locale));
  }
  
  private static Object getLocaleManagerForApplication(Context paramContext) {
    return paramContext.getSystemService("locale");
  }
  
  public static LocaleListCompat getSystemLocales(Context paramContext) {
    LocaleListCompat localeListCompat1;
    LocaleListCompat localeListCompat2 = LocaleListCompat.getEmptyLocaleList();
    if (BuildCompat.isAtLeastT()) {
      Object object = getLocaleManagerForApplication(paramContext);
      localeListCompat1 = localeListCompat2;
      if (object != null)
        return LocaleListCompat.wrap(Api33Impl.localeManagerGetSystemLocales(object)); 
    } else {
      localeListCompat1 = getConfigurationLocales(localeListCompat1.getApplicationContext().getResources().getConfiguration());
    } 
    return localeListCompat1;
  }
  
  static class Api21Impl {
    static String toLanguageTag(Locale param1Locale) {
      return param1Locale.toLanguageTag();
    }
  }
  
  static class Api24Impl {
    static LocaleListCompat getLocales(Configuration param1Configuration) {
      return LocaleListCompat.forLanguageTags(param1Configuration.getLocales().toLanguageTags());
    }
  }
  
  static class Api33Impl {
    static LocaleList localeManagerGetSystemLocales(Object param1Object) {
      return ((LocaleManager)param1Object).getSystemLocales();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\app\LocaleManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */