package androidx.core.content.res;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import androidx.core.graphics.TypefaceCompat;
import androidx.core.util.ObjectsCompat;
import androidx.core.util.Preconditions;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class ResourcesCompat {
  public static final int ID_NULL = 0;
  
  private static final String TAG = "ResourcesCompat";
  
  private static final Object sColorStateCacheLock;
  
  private static final WeakHashMap<ColorStateListCacheKey, SparseArray<ColorStateListCacheEntry>> sColorStateCaches;
  
  private static final ThreadLocal<TypedValue> sTempTypedValue = new ThreadLocal<TypedValue>();
  
  static {
    sColorStateCaches = new WeakHashMap<ColorStateListCacheKey, SparseArray<ColorStateListCacheEntry>>(0);
    sColorStateCacheLock = new Object();
  }
  
  private static void addColorStateListToCache(ColorStateListCacheKey paramColorStateListCacheKey, int paramInt, ColorStateList paramColorStateList, Resources.Theme paramTheme) {
    synchronized (sColorStateCacheLock) {
      WeakHashMap<ColorStateListCacheKey, SparseArray<ColorStateListCacheEntry>> weakHashMap = sColorStateCaches;
      SparseArray<ColorStateListCacheEntry> sparseArray2 = weakHashMap.get(paramColorStateListCacheKey);
      SparseArray<ColorStateListCacheEntry> sparseArray1 = sparseArray2;
      if (sparseArray2 == null) {
        sparseArray1 = new SparseArray();
        weakHashMap.put(paramColorStateListCacheKey, sparseArray1);
      } 
      sparseArray1.append(paramInt, new ColorStateListCacheEntry(paramColorStateList, paramColorStateListCacheKey.mResources.getConfiguration(), paramTheme));
      return;
    } 
  }
  
  public static void clearCachesForTheme(Resources.Theme paramTheme) {
    synchronized (sColorStateCacheLock) {
      Iterator<ColorStateListCacheKey> iterator = sColorStateCaches.keySet().iterator();
      while (iterator.hasNext()) {
        ColorStateListCacheKey colorStateListCacheKey = iterator.next();
        if (colorStateListCacheKey != null && paramTheme.equals(colorStateListCacheKey.mTheme))
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  private static ColorStateList getCachedColorStateList(ColorStateListCacheKey paramColorStateListCacheKey, int paramInt) {
    synchronized (sColorStateCacheLock) {
      SparseArray sparseArray = sColorStateCaches.get(paramColorStateListCacheKey);
      if (sparseArray != null && sparseArray.size() > 0) {
        ColorStateListCacheEntry colorStateListCacheEntry = (ColorStateListCacheEntry)sparseArray.get(paramInt);
        if (colorStateListCacheEntry != null) {
          if (colorStateListCacheEntry.mConfiguration.equals(paramColorStateListCacheKey.mResources.getConfiguration()) && ((paramColorStateListCacheKey.mTheme == null && colorStateListCacheEntry.mThemeHash == 0) || (paramColorStateListCacheKey.mTheme != null && colorStateListCacheEntry.mThemeHash == paramColorStateListCacheKey.mTheme.hashCode())))
            return colorStateListCacheEntry.mValue; 
          sparseArray.remove(paramInt);
        } 
      } 
      return null;
    } 
  }
  
  public static Typeface getCachedFont(Context paramContext, int paramInt) throws Resources.NotFoundException {
    return paramContext.isRestricted() ? null : loadFont(paramContext, paramInt, new TypedValue(), 0, null, null, false, true);
  }
  
  public static int getColor(Resources paramResources, int paramInt, Resources.Theme paramTheme) throws Resources.NotFoundException {
    return (Build.VERSION.SDK_INT >= 23) ? Api23Impl.getColor(paramResources, paramInt, paramTheme) : paramResources.getColor(paramInt);
  }
  
  public static ColorStateList getColorStateList(Resources paramResources, int paramInt, Resources.Theme paramTheme) throws Resources.NotFoundException {
    ColorStateListCacheKey colorStateListCacheKey = new ColorStateListCacheKey(paramResources, paramTheme);
    ColorStateList colorStateList = getCachedColorStateList(colorStateListCacheKey, paramInt);
    if (colorStateList != null)
      return colorStateList; 
    colorStateList = inflateColorStateList(paramResources, paramInt, paramTheme);
    if (colorStateList != null) {
      addColorStateListToCache(colorStateListCacheKey, paramInt, colorStateList, paramTheme);
      return colorStateList;
    } 
    return (Build.VERSION.SDK_INT >= 23) ? Api23Impl.getColorStateList(paramResources, paramInt, paramTheme) : paramResources.getColorStateList(paramInt);
  }
  
  public static Drawable getDrawable(Resources paramResources, int paramInt, Resources.Theme paramTheme) throws Resources.NotFoundException {
    return Api21Impl.getDrawable(paramResources, paramInt, paramTheme);
  }
  
  public static Drawable getDrawableForDensity(Resources paramResources, int paramInt1, int paramInt2, Resources.Theme paramTheme) throws Resources.NotFoundException {
    return Api21Impl.getDrawableForDensity(paramResources, paramInt1, paramInt2, paramTheme);
  }
  
  public static float getFloat(Resources paramResources, int paramInt) {
    if (Build.VERSION.SDK_INT >= 29)
      return Api29Impl.getFloat(paramResources, paramInt); 
    TypedValue typedValue = getTypedValue();
    paramResources.getValue(paramInt, typedValue, true);
    if (typedValue.type == 4)
      return typedValue.getFloat(); 
    StringBuilder stringBuilder = new StringBuilder("Resource ID #0x");
    stringBuilder.append(Integer.toHexString(paramInt));
    stringBuilder.append(" type #0x");
    stringBuilder.append(Integer.toHexString(typedValue.type));
    stringBuilder.append(" is not valid");
    throw new Resources.NotFoundException(stringBuilder.toString());
  }
  
  public static Typeface getFont(Context paramContext, int paramInt) throws Resources.NotFoundException {
    return paramContext.isRestricted() ? null : loadFont(paramContext, paramInt, new TypedValue(), 0, null, null, false, false);
  }
  
  public static Typeface getFont(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, FontCallback paramFontCallback) throws Resources.NotFoundException {
    return paramContext.isRestricted() ? null : loadFont(paramContext, paramInt1, paramTypedValue, paramInt2, paramFontCallback, null, true, false);
  }
  
  public static void getFont(Context paramContext, int paramInt, FontCallback paramFontCallback, Handler paramHandler) throws Resources.NotFoundException {
    Preconditions.checkNotNull(paramFontCallback);
    if (paramContext.isRestricted()) {
      paramFontCallback.callbackFailAsync(-4, paramHandler);
      return;
    } 
    loadFont(paramContext, paramInt, new TypedValue(), 0, paramFontCallback, paramHandler, false, false);
  }
  
  private static TypedValue getTypedValue() {
    ThreadLocal<TypedValue> threadLocal = sTempTypedValue;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
  
  private static ColorStateList inflateColorStateList(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    if (isColorInt(paramResources, paramInt))
      return null; 
    XmlResourceParser xmlResourceParser = paramResources.getXml(paramInt);
    try {
      return ColorStateListInflaterCompat.createFromXml(paramResources, (XmlPullParser)xmlResourceParser, paramTheme);
    } catch (Exception exception) {
      Log.w("ResourcesCompat", "Failed to inflate ColorStateList, leaving it to the framework", exception);
      return null;
    } 
  }
  
  private static boolean isColorInt(Resources paramResources, int paramInt) {
    TypedValue typedValue = getTypedValue();
    paramResources.getValue(paramInt, typedValue, true);
    return (typedValue.type >= 28 && typedValue.type <= 31);
  }
  
  private static Typeface loadFont(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, FontCallback paramFontCallback, Handler paramHandler, boolean paramBoolean1, boolean paramBoolean2) {
    StringBuilder stringBuilder;
    Resources resources = paramContext.getResources();
    resources.getValue(paramInt1, paramTypedValue, true);
    Typeface typeface = loadFont(paramContext, resources, paramTypedValue, paramInt1, paramInt2, paramFontCallback, paramHandler, paramBoolean1, paramBoolean2);
    if (typeface == null && paramFontCallback == null) {
      if (paramBoolean2)
        return typeface; 
      stringBuilder = new StringBuilder("Font resource ID #0x");
      stringBuilder.append(Integer.toHexString(paramInt1));
      stringBuilder.append(" could not be retrieved.");
      throw new Resources.NotFoundException(stringBuilder.toString());
    } 
    return (Typeface)stringBuilder;
  }
  
  private static Typeface loadFont(Context paramContext, Resources paramResources, TypedValue paramTypedValue, int paramInt1, int paramInt2, FontCallback paramFontCallback, Handler paramHandler, boolean paramBoolean1, boolean paramBoolean2) {
    StringBuilder stringBuilder;
    if (paramTypedValue.string != null) {
      String str = paramTypedValue.string.toString();
      if (!str.startsWith("res/")) {
        if (paramFontCallback != null)
          paramFontCallback.callbackFailAsync(-3, paramHandler); 
        return null;
      } 
      Typeface typeface = TypefaceCompat.findFromCache(paramResources, paramInt1, str, paramTypedValue.assetCookie, paramInt2);
      if (typeface != null) {
        if (paramFontCallback != null)
          paramFontCallback.callbackSuccessAsync(typeface, paramHandler); 
        return typeface;
      } 
      if (paramBoolean2)
        return null; 
      try {
        if (str.toLowerCase().endsWith(".xml")) {
          FontResourcesParserCompat.FamilyResourceEntry familyResourceEntry = FontResourcesParserCompat.parse((XmlPullParser)paramResources.getXml(paramInt1), paramResources);
          if (familyResourceEntry == null) {
            Log.e("ResourcesCompat", "Failed to find font-family tag");
            if (paramFontCallback != null) {
              paramFontCallback.callbackFailAsync(-3, paramHandler);
              return null;
            } 
          } else {
            return TypefaceCompat.createFromResourcesFamilyXml(paramContext, familyResourceEntry, paramResources, paramInt1, str, paramTypedValue.assetCookie, paramInt2, paramFontCallback, paramHandler, paramBoolean1);
          } 
        } else {
          Typeface typeface1 = TypefaceCompat.createFromResourcesFontFile(paramContext, paramResources, paramInt1, str, paramTypedValue.assetCookie, paramInt2);
          if (paramFontCallback != null) {
            if (typeface1 != null) {
              paramFontCallback.callbackSuccessAsync(typeface1, paramHandler);
              return typeface1;
            } 
            paramFontCallback.callbackFailAsync(-3, paramHandler);
          } 
          return typeface1;
        } 
      } catch (XmlPullParserException xmlPullParserException) {
        stringBuilder = new StringBuilder("Failed to parse xml resource ");
        stringBuilder.append(str);
        Log.e("ResourcesCompat", stringBuilder.toString(), (Throwable)xmlPullParserException);
        if (paramFontCallback != null)
          paramFontCallback.callbackFailAsync(-3, paramHandler); 
        return null;
      } catch (IOException iOException) {
        stringBuilder = new StringBuilder("Failed to read xml resource ");
        stringBuilder.append(str);
        Log.e("ResourcesCompat", stringBuilder.toString(), iOException);
      } 
    } else {
      StringBuilder stringBuilder1 = new StringBuilder("Resource \"");
      stringBuilder1.append(stringBuilder.getResourceName(paramInt1));
      stringBuilder1.append("\" (");
      stringBuilder1.append(Integer.toHexString(paramInt1));
      stringBuilder1.append(") is not a Font: ");
      stringBuilder1.append(paramTypedValue);
      throw new Resources.NotFoundException(stringBuilder1.toString());
    } 
    return null;
  }
  
  static class Api15Impl {
    static Drawable getDrawableForDensity(Resources param1Resources, int param1Int1, int param1Int2) {
      return param1Resources.getDrawableForDensity(param1Int1, param1Int2);
    }
  }
  
  static class Api21Impl {
    static Drawable getDrawable(Resources param1Resources, int param1Int, Resources.Theme param1Theme) {
      return param1Resources.getDrawable(param1Int, param1Theme);
    }
    
    static Drawable getDrawableForDensity(Resources param1Resources, int param1Int1, int param1Int2, Resources.Theme param1Theme) {
      return param1Resources.getDrawableForDensity(param1Int1, param1Int2, param1Theme);
    }
  }
  
  static class Api23Impl {
    static int getColor(Resources param1Resources, int param1Int, Resources.Theme param1Theme) {
      return param1Resources.getColor(param1Int, param1Theme);
    }
    
    static ColorStateList getColorStateList(Resources param1Resources, int param1Int, Resources.Theme param1Theme) {
      return param1Resources.getColorStateList(param1Int, param1Theme);
    }
  }
  
  static class Api29Impl {
    static float getFloat(Resources param1Resources, int param1Int) {
      return param1Resources.getFloat(param1Int);
    }
  }
  
  private static class ColorStateListCacheEntry {
    final Configuration mConfiguration;
    
    final int mThemeHash;
    
    final ColorStateList mValue;
    
    ColorStateListCacheEntry(ColorStateList param1ColorStateList, Configuration param1Configuration, Resources.Theme param1Theme) {
      int i;
      this.mValue = param1ColorStateList;
      this.mConfiguration = param1Configuration;
      if (param1Theme == null) {
        i = 0;
      } else {
        i = param1Theme.hashCode();
      } 
      this.mThemeHash = i;
    }
  }
  
  private static final class ColorStateListCacheKey {
    final Resources mResources;
    
    final Resources.Theme mTheme;
    
    ColorStateListCacheKey(Resources param1Resources, Resources.Theme param1Theme) {
      this.mResources = param1Resources;
      this.mTheme = param1Theme;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        return (this.mResources.equals(((ColorStateListCacheKey)param1Object).mResources) && ObjectsCompat.equals(this.mTheme, ((ColorStateListCacheKey)param1Object).mTheme));
      } 
      return false;
    }
    
    public int hashCode() {
      return ObjectsCompat.hash(new Object[] { this.mResources, this.mTheme });
    }
  }
  
  public static abstract class FontCallback {
    public static Handler getHandler(Handler param1Handler) {
      Handler handler = param1Handler;
      if (param1Handler == null)
        handler = new Handler(Looper.getMainLooper()); 
      return handler;
    }
    
    public final void callbackFailAsync(int param1Int, Handler param1Handler) {
      getHandler(param1Handler).post(new ResourcesCompat$FontCallback$$ExternalSyntheticLambda1(this, param1Int));
    }
    
    public final void callbackSuccessAsync(Typeface param1Typeface, Handler param1Handler) {
      getHandler(param1Handler).post(new ResourcesCompat$FontCallback$$ExternalSyntheticLambda0(this, param1Typeface));
    }
    
    public abstract void onFontRetrievalFailed(int param1Int);
    
    public abstract void onFontRetrieved(Typeface param1Typeface);
  }
  
  public static final class ThemeCompat {
    public static void rebase(Resources.Theme param1Theme) {
      if (Build.VERSION.SDK_INT >= 29) {
        Api29Impl.rebase(param1Theme);
        return;
      } 
      if (Build.VERSION.SDK_INT >= 23)
        Api23Impl.rebase(param1Theme); 
    }
    
    static class Api23Impl {
      private static Method sRebaseMethod;
      
      private static boolean sRebaseMethodFetched;
      
      private static final Object sRebaseMethodLock = new Object();
      
      static void rebase(Resources.Theme param2Theme) {
        synchronized (sRebaseMethodLock) {
          boolean bool = sRebaseMethodFetched;
          if (!bool) {
            try {
              Method method1 = Resources.Theme.class.getDeclaredMethod("rebase", new Class[0]);
              sRebaseMethod = method1;
              method1.setAccessible(true);
            } catch (NoSuchMethodException noSuchMethodException) {
              Log.i("ResourcesCompat", "Failed to retrieve rebase() method", noSuchMethodException);
            } 
            sRebaseMethodFetched = true;
          } 
          Method method = sRebaseMethod;
          if (method != null)
            try {
              method.invoke(param2Theme, new Object[0]);
            } catch (IllegalAccessException illegalAccessException) {
              Log.i("ResourcesCompat", "Failed to invoke rebase() method via reflection", illegalAccessException);
              sRebaseMethod = null;
            } catch (InvocationTargetException invocationTargetException) {} 
          return;
        } 
      }
    }
    
    static class Api29Impl {
      static void rebase(Resources.Theme param2Theme) {
        param2Theme.rebase();
      }
    }
  }
  
  static class Api23Impl {
    private static Method sRebaseMethod;
    
    private static boolean sRebaseMethodFetched;
    
    private static final Object sRebaseMethodLock = new Object();
    
    static void rebase(Resources.Theme param1Theme) {
      synchronized (sRebaseMethodLock) {
        boolean bool = sRebaseMethodFetched;
        if (!bool) {
          try {
            Method method1 = Resources.Theme.class.getDeclaredMethod("rebase", new Class[0]);
            sRebaseMethod = method1;
            method1.setAccessible(true);
          } catch (NoSuchMethodException noSuchMethodException) {
            Log.i("ResourcesCompat", "Failed to retrieve rebase() method", noSuchMethodException);
          } 
          sRebaseMethodFetched = true;
        } 
        Method method = sRebaseMethod;
        if (method != null)
          try {
            method.invoke(param1Theme, new Object[0]);
          } catch (IllegalAccessException illegalAccessException) {
            Log.i("ResourcesCompat", "Failed to invoke rebase() method via reflection", illegalAccessException);
            sRebaseMethod = null;
          } catch (InvocationTargetException invocationTargetException) {} 
        return;
      } 
    }
  }
  
  static class Api29Impl {
    static void rebase(Resources.Theme param1Theme) {
      param1Theme.rebase();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\content\res\ResourcesCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */