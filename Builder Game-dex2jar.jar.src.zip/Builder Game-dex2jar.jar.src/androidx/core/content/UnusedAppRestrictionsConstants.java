package androidx.core.content;

public final class UnusedAppRestrictionsConstants {
  public static final int API_30 = 4;
  
  public static final int API_30_BACKPORT = 3;
  
  public static final int API_31 = 5;
  
  public static final int DISABLED = 2;
  
  public static final int ERROR = 0;
  
  public static final int FEATURE_NOT_AVAILABLE = 1;
}


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\content\UnusedAppRestrictionsConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */