package androidx.core.content;


/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\content\PackageManagerCompat$$ExternalSyntheticLambda0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */