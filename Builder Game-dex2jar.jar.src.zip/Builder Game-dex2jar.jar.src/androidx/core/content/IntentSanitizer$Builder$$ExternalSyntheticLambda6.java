package androidx.core.content;

import android.content.ComponentName;
import androidx.core.util.Predicate;



/* Location:              C:\soft\dex2jar-2.0\Builder Game-dex2jar.jar!\androidx\core\content\IntentSanitizer$Builder$$ExternalSyntheticLambda6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */