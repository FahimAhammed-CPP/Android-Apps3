package com.google.android.gms.common.api;

import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.internal.jr;
import com.google.android.gms.internal.jx;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class BaseImplementation {
  static void a(Result paramResult) {
    if (paramResult instanceof Releasable)
      try {
        ((Releasable)paramResult).release();
        return;
      } catch (RuntimeException runtimeException) {
        Log.w("GoogleApi", "Unable to release " + paramResult, runtimeException);
        return;
      }  
  }
  
  public static abstract class AbstractPendingResult<R extends Result> implements b<R>, PendingResult<R> {
    private final Object Jp = new Object();
    
    private final ArrayList<PendingResult.a> Jq = new ArrayList<PendingResult.a>();
    
    private ResultCallback<R> Jr;
    
    private volatile R Js;
    
    private volatile boolean Jt;
    
    private boolean Ju;
    
    private boolean Jv;
    
    private jr Jw;
    
    protected final BaseImplementation.CallbackHandler<R> mHandler;
    
    private final CountDownLatch mr = new CountDownLatch(1);
    
    protected AbstractPendingResult(Looper param1Looper) {
      this.mHandler = new BaseImplementation.CallbackHandler<R>(param1Looper);
    }
    
    protected AbstractPendingResult(BaseImplementation.CallbackHandler<R> param1CallbackHandler) {
      this.mHandler = param1CallbackHandler;
    }
    
    private void c(R param1R) {
      this.Js = param1R;
      this.Jw = null;
      this.mr.countDown();
      Status status = this.Js.getStatus();
      if (this.Jr != null) {
        this.mHandler.removeTimeoutMessages();
        if (!this.Ju)
          this.mHandler.sendResultCallback(this.Jr, gA()); 
      } 
      Iterator<PendingResult.a> iterator = this.Jq.iterator();
      while (iterator.hasNext())
        ((PendingResult.a)iterator.next()).m(status); 
      this.Jq.clear();
    }
    
    private R gA() {
      synchronized (this.Jp) {
        if (!this.Jt) {
          boolean bool1 = true;
          jx.a(bool1, "Result has already been consumed.");
          jx.a(isReady(), "Result is not ready.");
          R r1 = this.Js;
          gB();
          return r1;
        } 
      } 
      boolean bool = false;
      jx.a(bool, "Result has already been consumed.");
      jx.a(isReady(), "Result is not ready.");
      R r = this.Js;
      gB();
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
      return r;
    }
    
    private void gC() {
      synchronized (this.Jp) {
        if (!isReady()) {
          b(c(Status.Kx));
          this.Jv = true;
        } 
        return;
      } 
    }
    
    private void gD() {
      synchronized (this.Jp) {
        if (!isReady()) {
          b(c(Status.Kz));
          this.Jv = true;
        } 
        return;
      } 
    }
    
    public final void a(PendingResult.a param1a) {
      boolean bool;
      if (!this.Jt) {
        bool = true;
      } else {
        bool = false;
      } 
      jx.a(bool, "Result has already been consumed.");
      synchronized (this.Jp) {
        if (isReady()) {
          param1a.m(this.Js.getStatus());
        } else {
          this.Jq.add(param1a);
        } 
        return;
      } 
    }
    
    protected final void a(jr param1jr) {
      synchronized (this.Jp) {
        this.Jw = param1jr;
        return;
      } 
    }
    
    public final R await() {
      boolean bool1;
      boolean bool2 = true;
      if (Looper.myLooper() != Looper.getMainLooper()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      jx.a(bool1, "await must not be called on the UI thread");
      if (!this.Jt) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      jx.a(bool1, "Result has already been consumed");
      try {
        this.mr.await();
      } catch (InterruptedException interruptedException) {
        gC();
      } 
      jx.a(isReady(), "Result is not ready.");
      return gA();
    }
    
    public final R await(long param1Long, TimeUnit param1TimeUnit) {
      boolean bool1;
      boolean bool2 = true;
      if (param1Long <= 0L || Looper.myLooper() != Looper.getMainLooper()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      jx.a(bool1, "await must not be called on the UI thread when time is greater than zero.");
      if (!this.Jt) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      jx.a(bool1, "Result has already been consumed.");
      try {
        if (!this.mr.await(param1Long, param1TimeUnit))
          gD(); 
      } catch (InterruptedException interruptedException) {
        gC();
      } 
      jx.a(isReady(), "Result is not ready.");
      return gA();
    }
    
    public final void b(R param1R) {
      boolean bool = true;
      synchronized (this.Jp) {
        boolean bool1;
        if (this.Jv || this.Ju) {
          BaseImplementation.a((Result)param1R);
          return;
        } 
        if (!isReady()) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        jx.a(bool1, "Results have already been set");
        if (!this.Jt) {
          bool1 = bool;
        } else {
          bool1 = false;
        } 
        jx.a(bool1, "Result has already been consumed");
        c(param1R);
        return;
      } 
    }
    
    protected abstract R c(Status param1Status);
    
    public void cancel() {
      synchronized (this.Jp) {
        if (this.Ju || this.Jt)
          return; 
        jr jr1 = this.Jw;
        if (jr1 != null)
          try {
            this.Jw.cancel();
          } catch (RemoteException remoteException) {} 
        BaseImplementation.a((Result)this.Js);
        this.Jr = null;
        this.Ju = true;
        c(c(Status.KA));
        return;
      } 
    }
    
    protected void gB() {
      this.Jt = true;
      this.Js = null;
      this.Jr = null;
    }
    
    public boolean isCanceled() {
      synchronized (this.Jp) {
        return this.Ju;
      } 
    }
    
    public final boolean isReady() {
      return (this.mr.getCount() == 0L);
    }
    
    public final void setResultCallback(ResultCallback<R> param1ResultCallback) {
      boolean bool;
      if (!this.Jt) {
        bool = true;
      } else {
        bool = false;
      } 
      jx.a(bool, "Result has already been consumed.");
      synchronized (this.Jp) {
        if (isCanceled())
          return; 
        if (isReady()) {
          this.mHandler.sendResultCallback(param1ResultCallback, gA());
        } else {
          this.Jr = param1ResultCallback;
        } 
        return;
      } 
    }
    
    public final void setResultCallback(ResultCallback<R> param1ResultCallback, long param1Long, TimeUnit param1TimeUnit) {
      boolean bool1;
      boolean bool2 = true;
      if (!this.Jt) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      jx.a(bool1, "Result has already been consumed.");
      if (this.mHandler != null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      jx.a(bool1, "CallbackHandler has not been set before calling setResultCallback.");
      synchronized (this.Jp) {
        if (isCanceled())
          return; 
        if (isReady()) {
          this.mHandler.sendResultCallback(param1ResultCallback, gA());
        } else {
          this.Jr = param1ResultCallback;
          this.mHandler.sendTimeoutResultCallback(this, param1TimeUnit.toMillis(param1Long));
        } 
        return;
      } 
    }
  }
  
  public static class CallbackHandler<R extends Result> extends Handler {
    public static final int CALLBACK_ON_COMPLETE = 1;
    
    public static final int CALLBACK_ON_TIMEOUT = 2;
    
    public CallbackHandler() {
      this(Looper.getMainLooper());
    }
    
    public CallbackHandler(Looper param1Looper) {
      super(param1Looper);
    }
    
    protected void deliverResultCallback(ResultCallback<R> param1ResultCallback, R param1R) {
      try {
        param1ResultCallback.onResult(param1R);
        return;
      } catch (RuntimeException runtimeException) {
        BaseImplementation.a((Result)param1R);
        throw runtimeException;
      } 
    }
    
    public void handleMessage(Message param1Message) {
      Pair pair;
      switch (param1Message.what) {
        default:
          Log.wtf("GoogleApi", "Don't know how to handle this message.");
          return;
        case 1:
          pair = (Pair)param1Message.obj;
          deliverResultCallback((ResultCallback<R>)pair.first, (R)pair.second);
          return;
        case 2:
          break;
      } 
      BaseImplementation.AbstractPendingResult.a((BaseImplementation.AbstractPendingResult)((Message)pair).obj);
    }
    
    public void removeTimeoutMessages() {
      removeMessages(2);
    }
    
    public void sendResultCallback(ResultCallback<R> param1ResultCallback, R param1R) {
      sendMessage(obtainMessage(1, new Pair(param1ResultCallback, param1R)));
    }
    
    public void sendTimeoutResultCallback(BaseImplementation.AbstractPendingResult<R> param1AbstractPendingResult, long param1Long) {
      sendMessageDelayed(obtainMessage(2, param1AbstractPendingResult), param1Long);
    }
  }
  
  public static abstract class a<R extends Result, A extends Api.a> extends AbstractPendingResult<R> implements c.d<A> {
    private final Api.c<A> Jn;
    
    private final GoogleApiClient Jx;
    
    private c.b Jy;
    
    protected a(Api.c<A> param1c, GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient.getLooper());
      this.Jn = (Api.c<A>)jx.i(param1c);
      this.Jx = param1GoogleApiClient;
    }
    
    private void a(RemoteException param1RemoteException) {
      l(new Status(8, param1RemoteException.getLocalizedMessage(), null));
    }
    
    protected abstract void a(A param1A) throws RemoteException;
    
    public void a(c.b param1b) {
      this.Jy = param1b;
    }
    
    public final void b(A param1A) throws DeadObjectException {
      try {
        a(param1A);
        return;
      } catch (DeadObjectException deadObjectException) {
        a((RemoteException)deadObjectException);
        throw deadObjectException;
      } catch (RemoteException remoteException) {
        a(remoteException);
        return;
      } 
    }
    
    protected void gB() {
      super.gB();
      if (this.Jy != null) {
        this.Jy.b(this);
        this.Jy = null;
      } 
    }
    
    public final a gE() {
      jx.b(this.Jx, "GoogleApiClient was not set.");
      this.Jx.b(this);
      return this;
    }
    
    public int gF() {
      return 0;
    }
    
    public final Api.c<A> gz() {
      return this.Jn;
    }
    
    public final void l(Status param1Status) {
      boolean bool;
      if (!param1Status.isSuccess()) {
        bool = true;
      } else {
        bool = false;
      } 
      jx.b(bool, "Failed result must not be success");
      b(c(param1Status));
    }
  }
  
  public static interface b<R> {
    void b(R param1R);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\common\api\BaseImplementation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */