package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.IntentSender;
import android.os.Parcel;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.jv;

public final class Status implements Result, SafeParcelable {
  public static final StatusCreator CREATOR;
  
  public static final Status KA;
  
  public static final Status Kw = new Status(0);
  
  public static final Status Kx = new Status(14);
  
  public static final Status Ky = new Status(8);
  
  public static final Status Kz = new Status(15);
  
  private final int CK;
  
  private final int Iv;
  
  private final String KB;
  
  private final PendingIntent mPendingIntent;
  
  static {
    KA = new Status(16);
    CREATOR = new StatusCreator();
  }
  
  public Status(int paramInt) {
    this(paramInt, null);
  }
  
  Status(int paramInt1, int paramInt2, String paramString, PendingIntent paramPendingIntent) {
    this.CK = paramInt1;
    this.Iv = paramInt2;
    this.KB = paramString;
    this.mPendingIntent = paramPendingIntent;
  }
  
  public Status(int paramInt, String paramString) {
    this(1, paramInt, paramString, null);
  }
  
  public Status(int paramInt, String paramString, PendingIntent paramPendingIntent) {
    this(1, paramInt, paramString, paramPendingIntent);
  }
  
  private String gt() {
    return (this.KB != null) ? this.KB : CommonStatusCodes.getStatusCodeString(this.Iv);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof Status) {
      paramObject = paramObject;
      if (this.CK == ((Status)paramObject).CK && this.Iv == ((Status)paramObject).Iv && jv.equal(this.KB, ((Status)paramObject).KB) && jv.equal(this.mPendingIntent, ((Status)paramObject).mPendingIntent))
        return true; 
    } 
    return false;
  }
  
  PendingIntent gP() {
    return this.mPendingIntent;
  }
  
  @Deprecated
  public ConnectionResult gQ() {
    return new ConnectionResult(this.Iv, this.mPendingIntent);
  }
  
  public PendingIntent getResolution() {
    return this.mPendingIntent;
  }
  
  public Status getStatus() {
    return this;
  }
  
  public int getStatusCode() {
    return this.Iv;
  }
  
  public String getStatusMessage() {
    return this.KB;
  }
  
  int getVersionCode() {
    return this.CK;
  }
  
  public boolean hasResolution() {
    return (this.mPendingIntent != null);
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { Integer.valueOf(this.CK), Integer.valueOf(this.Iv), this.KB, this.mPendingIntent });
  }
  
  public boolean isCanceled() {
    return (this.Iv == 16);
  }
  
  public boolean isInterrupted() {
    return (this.Iv == 14);
  }
  
  public boolean isSuccess() {
    return (this.Iv <= 0);
  }
  
  public void startResolutionForResult(Activity paramActivity, int paramInt) throws IntentSender.SendIntentException {
    if (!hasResolution())
      return; 
    paramActivity.startIntentSenderForResult(this.mPendingIntent.getIntentSender(), paramInt, null, 0, 0, 0);
  }
  
  public String toString() {
    return jv.h(this).a("statusCode", gt()).a("resolution", this.mPendingIntent).toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    StatusCreator.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\common\api\Status.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */