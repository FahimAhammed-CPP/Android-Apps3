package com.google.android.gms.common.data;

import java.util.ArrayList;

public abstract class g<T> extends DataBuffer<T> {
  private boolean Lr = false;
  
  private ArrayList<Integer> Ls;
  
  protected g(DataHolder paramDataHolder) {
    super(paramDataHolder);
  }
  
  private void hb() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield Lr : Z
    //   6: ifne -> 193
    //   9: aload_0
    //   10: getfield JG : Lcom/google/android/gms/common/data/DataHolder;
    //   13: invokevirtual getCount : ()I
    //   16: istore_2
    //   17: aload_0
    //   18: new java/util/ArrayList
    //   21: dup
    //   22: invokespecial <init> : ()V
    //   25: putfield Ls : Ljava/util/ArrayList;
    //   28: iload_2
    //   29: ifle -> 188
    //   32: aload_0
    //   33: getfield Ls : Ljava/util/ArrayList;
    //   36: iconst_0
    //   37: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   40: invokevirtual add : (Ljava/lang/Object;)Z
    //   43: pop
    //   44: aload_0
    //   45: invokevirtual ha : ()Ljava/lang/String;
    //   48: astore #6
    //   50: aload_0
    //   51: getfield JG : Lcom/google/android/gms/common/data/DataHolder;
    //   54: iconst_0
    //   55: invokevirtual au : (I)I
    //   58: istore_1
    //   59: aload_0
    //   60: getfield JG : Lcom/google/android/gms/common/data/DataHolder;
    //   63: aload #6
    //   65: iconst_0
    //   66: iload_1
    //   67: invokevirtual c : (Ljava/lang/String;II)Ljava/lang/String;
    //   70: astore #4
    //   72: iconst_1
    //   73: istore_1
    //   74: iload_1
    //   75: iload_2
    //   76: if_icmpge -> 188
    //   79: aload_0
    //   80: getfield JG : Lcom/google/android/gms/common/data/DataHolder;
    //   83: iload_1
    //   84: invokevirtual au : (I)I
    //   87: istore_3
    //   88: aload_0
    //   89: getfield JG : Lcom/google/android/gms/common/data/DataHolder;
    //   92: aload #6
    //   94: iload_1
    //   95: iload_3
    //   96: invokevirtual c : (Ljava/lang/String;II)Ljava/lang/String;
    //   99: astore #5
    //   101: aload #5
    //   103: ifnonnull -> 159
    //   106: new java/lang/NullPointerException
    //   109: dup
    //   110: new java/lang/StringBuilder
    //   113: dup
    //   114: invokespecial <init> : ()V
    //   117: ldc 'Missing value for markerColumn: '
    //   119: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   122: aload #6
    //   124: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   127: ldc ', at row: '
    //   129: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   132: iload_1
    //   133: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   136: ldc ', for window: '
    //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   141: iload_3
    //   142: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   145: invokevirtual toString : ()Ljava/lang/String;
    //   148: invokespecial <init> : (Ljava/lang/String;)V
    //   151: athrow
    //   152: astore #4
    //   154: aload_0
    //   155: monitorexit
    //   156: aload #4
    //   158: athrow
    //   159: aload #5
    //   161: aload #4
    //   163: invokevirtual equals : (Ljava/lang/Object;)Z
    //   166: ifne -> 196
    //   169: aload_0
    //   170: getfield Ls : Ljava/util/ArrayList;
    //   173: iload_1
    //   174: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   177: invokevirtual add : (Ljava/lang/Object;)Z
    //   180: pop
    //   181: aload #5
    //   183: astore #4
    //   185: goto -> 196
    //   188: aload_0
    //   189: iconst_1
    //   190: putfield Lr : Z
    //   193: aload_0
    //   194: monitorexit
    //   195: return
    //   196: iload_1
    //   197: iconst_1
    //   198: iadd
    //   199: istore_1
    //   200: goto -> 74
    // Exception table:
    //   from	to	target	type
    //   2	28	152	finally
    //   32	72	152	finally
    //   79	101	152	finally
    //   106	152	152	finally
    //   154	156	152	finally
    //   159	181	152	finally
    //   188	193	152	finally
    //   193	195	152	finally
  }
  
  int ax(int paramInt) {
    if (paramInt < 0 || paramInt >= this.Ls.size())
      throw new IllegalArgumentException("Position " + paramInt + " is out of bounds for this buffer"); 
    return ((Integer)this.Ls.get(paramInt)).intValue();
  }
  
  protected int ay(int paramInt) {
    int i;
    if (paramInt < 0 || paramInt == this.Ls.size())
      return 0; 
    if (paramInt == this.Ls.size() - 1) {
      i = this.JG.getCount() - ((Integer)this.Ls.get(paramInt)).intValue();
    } else {
      i = ((Integer)this.Ls.get(paramInt + 1)).intValue() - ((Integer)this.Ls.get(paramInt)).intValue();
    } 
    int j = i;
    if (i == 1) {
      paramInt = ax(paramInt);
      int k = this.JG.au(paramInt);
      String str = hc();
      j = i;
      if (str != null) {
        j = i;
        if (this.JG.c(str, paramInt, k) == null)
          return 0; 
      } 
    } 
    return j;
  }
  
  protected abstract T f(int paramInt1, int paramInt2);
  
  public final T get(int paramInt) {
    hb();
    return f(ax(paramInt), ay(paramInt));
  }
  
  public int getCount() {
    hb();
    return this.Ls.size();
  }
  
  protected abstract String ha();
  
  protected String hc() {
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\common\data\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */