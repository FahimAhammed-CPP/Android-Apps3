package com.google.android.gms.common.data;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class e<T extends SafeParcelable> extends DataBuffer<T> {
  private static final String[] Lb = new String[] { "data" };
  
  private final Parcelable.Creator<T> Lc;
  
  public e(DataHolder paramDataHolder, Parcelable.Creator<T> paramCreator) {
    super(paramDataHolder);
    this.Lc = paramCreator;
  }
  
  public T at(int paramInt) {
    byte[] arrayOfByte = this.JG.f("data", paramInt, this.JG.au(paramInt));
    Parcel parcel = Parcel.obtain();
    parcel.unmarshall(arrayOfByte, 0, arrayOfByte.length);
    parcel.setDataPosition(0);
    SafeParcelable safeParcelable = (SafeParcelable)this.Lc.createFromParcel(parcel);
    parcel.recycle();
    return (T)safeParcelable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\common\data\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */