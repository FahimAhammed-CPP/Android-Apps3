package com.google.android.gms.common;

import android.app.Activity;
import android.app.Dialog;
import android.app.FragmentManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.R;
import com.google.android.gms.internal.jf;
import com.google.android.gms.internal.jo;
import com.google.android.gms.internal.jx;
import com.google.android.gms.internal.lc;
import com.google.android.gms.internal.ll;
import java.io.InputStream;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Set;

public final class GooglePlayServicesUtil {
  public static final String GMS_ERROR_DIALOG = "GooglePlayServicesErrorDialog";
  
  public static final String GOOGLE_PLAY_SERVICES_PACKAGE = "com.google.android.gms";
  
  public static final int GOOGLE_PLAY_SERVICES_VERSION_CODE = 6587000;
  
  public static final String GOOGLE_PLAY_STORE_PACKAGE = "com.android.vending";
  
  public static boolean Jg = false;
  
  public static boolean Jh = false;
  
  private static int Ji = -1;
  
  private static final Object Jj = new Object();
  
  public static void C(Context paramContext) throws GooglePlayServicesRepairableException, GooglePlayServicesNotAvailableException {
    int i = isGooglePlayServicesAvailable(paramContext);
    if (i != 0) {
      Intent intent = aj(i);
      Log.e("GooglePlayServicesUtil", "GooglePlayServices not available due to error " + i);
      if (intent == null)
        throw new GooglePlayServicesNotAvailableException(i); 
      throw new GooglePlayServicesRepairableException(i, "Google Play Services not available", intent);
    } 
  }
  
  private static void D(Context paramContext) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   6: aload_0
    //   7: invokevirtual getPackageName : ()Ljava/lang/String;
    //   10: sipush #128
    //   13: invokevirtual getApplicationInfo : (Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    //   16: astore_0
    //   17: aload_0
    //   18: getfield metaData : Landroid/os/Bundle;
    //   21: astore_0
    //   22: aload_0
    //   23: ifnull -> 107
    //   26: aload_0
    //   27: ldc 'com.google.android.gms.version'
    //   29: invokevirtual getInt : (Ljava/lang/String;)I
    //   32: istore_1
    //   33: iload_1
    //   34: ldc 6587000
    //   36: if_icmpne -> 55
    //   39: return
    //   40: astore_0
    //   41: ldc 'GooglePlayServicesUtil'
    //   43: ldc 'This should never happen.'
    //   45: aload_0
    //   46: invokestatic wtf : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   49: pop
    //   50: aload_2
    //   51: astore_0
    //   52: goto -> 17
    //   55: new java/lang/IllegalStateException
    //   58: dup
    //   59: new java/lang/StringBuilder
    //   62: dup
    //   63: invokespecial <init> : ()V
    //   66: ldc 'The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected 6587000 but found '
    //   68: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: iload_1
    //   72: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   75: ldc '.  You must have the'
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: ldc ' following declaration within the <application> element: '
    //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: ldc '    <meta-data android:name="'
    //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: ldc 'com.google.android.gms.version'
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: ldc '" android:value="@integer/google_play_services_version" />'
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: invokevirtual toString : ()Ljava/lang/String;
    //   103: invokespecial <init> : (Ljava/lang/String;)V
    //   106: athrow
    //   107: new java/lang/IllegalStateException
    //   110: dup
    //   111: ldc 'A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name="com.google.android.gms.version" android:value="@integer/google_play_services_version" />'
    //   113: invokespecial <init> : (Ljava/lang/String;)V
    //   116: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	40	android/content/pm/PackageManager$NameNotFoundException
  }
  
  private static void E(Context paramContext) {
    a a = new a(paramContext);
    a.sendMessageDelayed(a.obtainMessage(1), 120000L);
  }
  
  private static String F(Context paramContext) {
    String str2 = (paramContext.getApplicationInfo()).name;
    String str1 = str2;
    if (TextUtils.isEmpty(str2)) {
      str1 = paramContext.getPackageName();
      PackageManager packageManager = paramContext.getApplicationContext().getPackageManager();
      try {
        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(paramContext.getPackageName(), 0);
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        nameNotFoundException = null;
      } 
      if (nameNotFoundException != null)
        str1 = packageManager.getApplicationLabel((ApplicationInfo)nameNotFoundException).toString(); 
    } 
    return str1;
  }
  
  private static Dialog a(int paramInt1, Activity paramActivity, Fragment paramFragment, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener) {
    // Byte code:
    //   0: iload_0
    //   1: istore #5
    //   3: aload_1
    //   4: invokestatic K : (Landroid/content/Context;)Z
    //   7: ifeq -> 22
    //   10: iload_0
    //   11: istore #5
    //   13: iload_0
    //   14: iconst_2
    //   15: if_icmpne -> 22
    //   18: bipush #42
    //   20: istore #5
    //   22: invokestatic ij : ()Z
    //   25: ifeq -> 496
    //   28: new android/util/TypedValue
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: astore #6
    //   37: aload_1
    //   38: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   41: ldc 16843529
    //   43: aload #6
    //   45: iconst_1
    //   46: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   49: pop
    //   50: ldc 'Theme.Dialog.Alert'
    //   52: aload_1
    //   53: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   56: aload #6
    //   58: getfield resourceId : I
    //   61: invokevirtual getResourceEntryName : (I)Ljava/lang/String;
    //   64: invokevirtual equals : (Ljava/lang/Object;)Z
    //   67: ifeq -> 496
    //   70: new android/app/AlertDialog$Builder
    //   73: dup
    //   74: aload_1
    //   75: iconst_5
    //   76: invokespecial <init> : (Landroid/content/Context;I)V
    //   79: astore #6
    //   81: aload #6
    //   83: astore #7
    //   85: aload #6
    //   87: ifnonnull -> 100
    //   90: new android/app/AlertDialog$Builder
    //   93: dup
    //   94: aload_1
    //   95: invokespecial <init> : (Landroid/content/Context;)V
    //   98: astore #7
    //   100: aload #7
    //   102: aload_1
    //   103: iload #5
    //   105: invokestatic b : (Landroid/content/Context;I)Ljava/lang/String;
    //   108: invokevirtual setMessage : (Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    //   111: pop
    //   112: aload #4
    //   114: ifnull -> 125
    //   117: aload #7
    //   119: aload #4
    //   121: invokevirtual setOnCancelListener : (Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;
    //   124: pop
    //   125: iload #5
    //   127: invokestatic aj : (I)Landroid/content/Intent;
    //   130: astore #4
    //   132: aload_2
    //   133: ifnonnull -> 317
    //   136: new com/google/android/gms/internal/jh
    //   139: dup
    //   140: aload_1
    //   141: aload #4
    //   143: iload_3
    //   144: invokespecial <init> : (Landroid/app/Activity;Landroid/content/Intent;I)V
    //   147: astore_2
    //   148: aload_1
    //   149: iload #5
    //   151: invokestatic c : (Landroid/content/Context;I)Ljava/lang/String;
    //   154: astore_1
    //   155: aload_1
    //   156: ifnull -> 167
    //   159: aload #7
    //   161: aload_1
    //   162: aload_2
    //   163: invokevirtual setPositiveButton : (Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    //   166: pop
    //   167: iload #5
    //   169: lookupswitch default -> 284, 0 -> 332, 1 -> 340, 2 -> 364, 3 -> 352, 4 -> 334, 5 -> 460, 6 -> 334, 7 -> 409, 8 -> 430, 9 -> 388, 10 -> 445, 11 -> 481, 42 -> 376
    //   284: ldc 'GooglePlayServicesUtil'
    //   286: new java/lang/StringBuilder
    //   289: dup
    //   290: invokespecial <init> : ()V
    //   293: ldc_w 'Unexpected error code '
    //   296: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   299: iload #5
    //   301: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   304: invokevirtual toString : ()Ljava/lang/String;
    //   307: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   310: pop
    //   311: aload #7
    //   313: invokevirtual create : ()Landroid/app/AlertDialog;
    //   316: areturn
    //   317: new com/google/android/gms/internal/jh
    //   320: dup
    //   321: aload_2
    //   322: aload #4
    //   324: iload_3
    //   325: invokespecial <init> : (Landroid/support/v4/app/Fragment;Landroid/content/Intent;I)V
    //   328: astore_2
    //   329: goto -> 148
    //   332: aconst_null
    //   333: areturn
    //   334: aload #7
    //   336: invokevirtual create : ()Landroid/app/AlertDialog;
    //   339: areturn
    //   340: aload #7
    //   342: getstatic com/google/android/gms/R$string.common_google_play_services_install_title : I
    //   345: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   348: invokevirtual create : ()Landroid/app/AlertDialog;
    //   351: areturn
    //   352: aload #7
    //   354: getstatic com/google/android/gms/R$string.common_google_play_services_enable_title : I
    //   357: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   360: invokevirtual create : ()Landroid/app/AlertDialog;
    //   363: areturn
    //   364: aload #7
    //   366: getstatic com/google/android/gms/R$string.common_google_play_services_update_title : I
    //   369: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   372: invokevirtual create : ()Landroid/app/AlertDialog;
    //   375: areturn
    //   376: aload #7
    //   378: getstatic com/google/android/gms/R$string.common_android_wear_update_title : I
    //   381: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   384: invokevirtual create : ()Landroid/app/AlertDialog;
    //   387: areturn
    //   388: ldc 'GooglePlayServicesUtil'
    //   390: ldc_w 'Google Play services is invalid. Cannot recover.'
    //   393: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   396: pop
    //   397: aload #7
    //   399: getstatic com/google/android/gms/R$string.common_google_play_services_unsupported_title : I
    //   402: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   405: invokevirtual create : ()Landroid/app/AlertDialog;
    //   408: areturn
    //   409: ldc 'GooglePlayServicesUtil'
    //   411: ldc_w 'Network error occurred. Please retry request later.'
    //   414: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   417: pop
    //   418: aload #7
    //   420: getstatic com/google/android/gms/R$string.common_google_play_services_network_error_title : I
    //   423: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   426: invokevirtual create : ()Landroid/app/AlertDialog;
    //   429: areturn
    //   430: ldc 'GooglePlayServicesUtil'
    //   432: ldc_w 'Internal error occurred. Please see logs for detailed information'
    //   435: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   438: pop
    //   439: aload #7
    //   441: invokevirtual create : ()Landroid/app/AlertDialog;
    //   444: areturn
    //   445: ldc 'GooglePlayServicesUtil'
    //   447: ldc_w 'Developer error occurred. Please see logs for detailed information'
    //   450: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   453: pop
    //   454: aload #7
    //   456: invokevirtual create : ()Landroid/app/AlertDialog;
    //   459: areturn
    //   460: ldc 'GooglePlayServicesUtil'
    //   462: ldc_w 'An invalid account was specified when connecting. Please provide a valid account.'
    //   465: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   468: pop
    //   469: aload #7
    //   471: getstatic com/google/android/gms/R$string.common_google_play_services_invalid_account_title : I
    //   474: invokevirtual setTitle : (I)Landroid/app/AlertDialog$Builder;
    //   477: invokevirtual create : ()Landroid/app/AlertDialog;
    //   480: areturn
    //   481: ldc 'GooglePlayServicesUtil'
    //   483: ldc_w 'The application is not licensed to the user.'
    //   486: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   489: pop
    //   490: aload #7
    //   492: invokevirtual create : ()Landroid/app/AlertDialog;
    //   495: areturn
    //   496: aconst_null
    //   497: astore #6
    //   499: goto -> 81
  }
  
  private static void a(int paramInt, Context paramContext) {
    Notification notification;
    Resources resources = paramContext.getResources();
    String str1 = d(paramContext, paramInt);
    String str2 = resources.getString(R.string.common_google_play_services_error_notification_requested_by_msg, new Object[] { F(paramContext) });
    PendingIntent pendingIntent = getErrorPendingIntent(paramInt, paramContext, 0);
    if (lc.K(paramContext)) {
      jx.K(ll.ik());
      notification = (new Notification.Builder(paramContext)).setSmallIcon(R.drawable.common_ic_googleplayservices).setPriority(2).setAutoCancel(true).setStyle((Notification.Style)(new Notification.BigTextStyle()).bigText(str1 + " " + str2)).addAction(R.drawable.common_full_open_on_phone, resources.getString(R.string.common_open_on_phone), pendingIntent).build();
    } else {
      notification = new Notification(17301642, notification.getString(R.string.common_google_play_services_notification_ticker), System.currentTimeMillis());
      notification.flags |= 0x10;
      notification.setLatestEventInfo(paramContext, str1, str2, pendingIntent);
    } 
    ((NotificationManager)paramContext.getSystemService("notification")).notify(ak(paramInt), notification);
  }
  
  public static boolean a(PackageManager paramPackageManager, PackageInfo paramPackageInfo) {
    boolean bool1 = true;
    boolean bool3 = false;
    boolean bool2 = false;
    if (paramPackageInfo != null) {
      if (c(paramPackageManager)) {
        if (a(paramPackageInfo, true) == null)
          bool1 = false; 
        return bool1;
      } 
      bool1 = bool3;
      if (a(paramPackageInfo, false) != null)
        bool1 = true; 
      bool2 = bool1;
      if (!bool1) {
        bool2 = bool1;
        if (a(paramPackageInfo, true) != null) {
          Log.w("GooglePlayServicesUtil", "Test-keys aren't accepted on this build.");
          return bool1;
        } 
      } 
    } 
    return bool2;
  }
  
  public static boolean a(Resources paramResources) {
    if (paramResources != null) {
      boolean bool;
      if (((paramResources.getConfiguration()).screenLayout & 0xF) > 3) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((ll.ig() && bool) || b(paramResources))
        return true; 
    } 
    return false;
  }
  
  private static byte[] a(PackageInfo paramPackageInfo, boolean paramBoolean) {
    Set<byte[]> set;
    if (paramPackageInfo.signatures.length != 1) {
      Log.w("GooglePlayServicesUtil", "Package has more than one signature.");
      return null;
    } 
    byte[] arrayOfByte = paramPackageInfo.signatures[0].toByteArray();
    if (paramBoolean) {
      set = b.gu();
    } else {
      set = b.gv();
    } 
    if (set.contains(arrayOfByte))
      return arrayOfByte; 
    if (Log.isLoggable("GooglePlayServicesUtil", 2))
      Log.v("GooglePlayServicesUtil", "Signature not valid.  Found: \n" + Base64.encodeToString(arrayOfByte, 0)); 
    return null;
  }
  
  private static byte[] a(PackageInfo paramPackageInfo, byte[]... paramVarArgs) {
    if (paramPackageInfo.signatures.length != 1) {
      Log.w("GooglePlayServicesUtil", "Package has more than one signature.");
      return null;
    } 
    byte[] arrayOfByte = paramPackageInfo.signatures[0].toByteArray();
    for (int i = 0; i < paramVarArgs.length; i++) {
      byte[] arrayOfByte1 = paramVarArgs[i];
      if (Arrays.equals(arrayOfByte1, arrayOfByte))
        return arrayOfByte1; 
    } 
    if (Log.isLoggable("GooglePlayServicesUtil", 2))
      Log.v("GooglePlayServicesUtil", "Signature not valid.  Found: \n" + Base64.encodeToString(arrayOfByte, 0)); 
    return null;
  }
  
  public static Intent aj(int paramInt) {
    switch (paramInt) {
      default:
        return null;
      case 1:
      case 2:
        return jo.ba("com.google.android.gms");
      case 42:
        return jo.hE();
      case 3:
        break;
    } 
    return jo.aY("com.google.android.gms");
  }
  
  private static int ak(int paramInt) {
    switch (paramInt) {
      default:
        return 39789;
      case 1:
      case 3:
        break;
    } 
    return 10436;
  }
  
  public static String b(Context paramContext, int paramInt) {
    Resources resources = paramContext.getResources();
    switch (paramInt) {
      default:
        return resources.getString(R.string.common_google_play_services_unknown_issue);
      case 1:
        return a(paramContext.getResources()) ? resources.getString(R.string.common_google_play_services_install_text_tablet) : resources.getString(R.string.common_google_play_services_install_text_phone);
      case 3:
        return resources.getString(R.string.common_google_play_services_enable_text);
      case 2:
        return resources.getString(R.string.common_google_play_services_update_text);
      case 42:
        return resources.getString(R.string.common_android_wear_update_text);
      case 9:
        return resources.getString(R.string.common_google_play_services_unsupported_text);
      case 7:
        return resources.getString(R.string.common_google_play_services_network_error_text);
      case 5:
        break;
    } 
    return resources.getString(R.string.common_google_play_services_invalid_account_text);
  }
  
  public static boolean b(PackageManager paramPackageManager) {
    // Byte code:
    //   0: getstatic com/google/android/gms/common/GooglePlayServicesUtil.Jj : Ljava/lang/Object;
    //   3: astore_2
    //   4: aload_2
    //   5: monitorenter
    //   6: getstatic com/google/android/gms/common/GooglePlayServicesUtil.Ji : I
    //   9: istore_1
    //   10: iload_1
    //   11: iconst_m1
    //   12: if_icmpne -> 45
    //   15: aload_0
    //   16: ldc 'com.google.android.gms'
    //   18: bipush #64
    //   20: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   23: iconst_1
    //   24: anewarray [B
    //   27: dup
    //   28: iconst_0
    //   29: getstatic com/google/android/gms/common/b.Jc : [[B
    //   32: iconst_1
    //   33: aaload
    //   34: aastore
    //   35: invokestatic a : (Landroid/content/pm/PackageInfo;[[B)[B
    //   38: ifnull -> 55
    //   41: iconst_1
    //   42: putstatic com/google/android/gms/common/GooglePlayServicesUtil.Ji : I
    //   45: aload_2
    //   46: monitorexit
    //   47: getstatic com/google/android/gms/common/GooglePlayServicesUtil.Ji : I
    //   50: ifeq -> 75
    //   53: iconst_1
    //   54: ireturn
    //   55: iconst_0
    //   56: putstatic com/google/android/gms/common/GooglePlayServicesUtil.Ji : I
    //   59: goto -> 45
    //   62: astore_0
    //   63: iconst_0
    //   64: putstatic com/google/android/gms/common/GooglePlayServicesUtil.Ji : I
    //   67: goto -> 45
    //   70: astore_0
    //   71: aload_2
    //   72: monitorexit
    //   73: aload_0
    //   74: athrow
    //   75: iconst_0
    //   76: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	10	70	finally
    //   15	45	62	android/content/pm/PackageManager$NameNotFoundException
    //   15	45	70	finally
    //   45	47	70	finally
    //   55	59	62	android/content/pm/PackageManager$NameNotFoundException
    //   55	59	70	finally
    //   63	67	70	finally
    //   71	73	70	finally
  }
  
  public static boolean b(PackageManager paramPackageManager, String paramString) {
    try {
      PackageInfo packageInfo = paramPackageManager.getPackageInfo(paramString, 64);
      return a(paramPackageManager, packageInfo);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      if (Log.isLoggable("GooglePlayServicesUtil", 3))
        Log.d("GooglePlayServicesUtil", "Package manager can't find package " + paramString + ", defaulting to false"); 
      return false;
    } 
  }
  
  private static boolean b(Resources paramResources) {
    boolean bool2 = false;
    Configuration configuration = paramResources.getConfiguration();
    boolean bool1 = bool2;
    if (ll.ii()) {
      bool1 = bool2;
      if ((configuration.screenLayout & 0xF) <= 3) {
        bool1 = bool2;
        if (configuration.smallestScreenWidthDp >= 600)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public static String c(Context paramContext, int paramInt) {
    Resources resources = paramContext.getResources();
    switch (paramInt) {
      default:
        return resources.getString(17039370);
      case 1:
        return resources.getString(R.string.common_google_play_services_install_button);
      case 3:
        return resources.getString(R.string.common_google_play_services_enable_button);
      case 2:
      case 42:
        break;
    } 
    return resources.getString(R.string.common_google_play_services_update_button);
  }
  
  public static boolean c(PackageManager paramPackageManager) {
    return (b(paramPackageManager) || !gw());
  }
  
  public static String d(Context paramContext, int paramInt) {
    Resources resources = paramContext.getResources();
    switch (paramInt) {
      default:
        return resources.getString(R.string.common_google_play_services_unknown_issue);
      case 1:
        return resources.getString(R.string.common_google_play_services_notification_needs_installation_title);
      case 2:
        return resources.getString(R.string.common_google_play_services_notification_needs_update_title);
      case 42:
        return resources.getString(R.string.common_android_wear_notification_needs_update_text);
      case 3:
        return resources.getString(R.string.common_google_play_services_needs_enabling_title);
      case 9:
        return resources.getString(R.string.common_google_play_services_unsupported_text);
      case 7:
        return resources.getString(R.string.common_google_play_services_network_error_text);
      case 5:
        break;
    } 
    return resources.getString(R.string.common_google_play_services_invalid_account_text);
  }
  
  public static boolean e(Context paramContext, int paramInt) {
    if (paramInt == 1) {
      PackageManager packageManager = paramContext.getPackageManager();
      try {
        boolean bool = (packageManager.getApplicationInfo("com.google.android.gms", 8192)).enabled;
        if (bool)
          return true; 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    } 
    return false;
  }
  
  public static Dialog getErrorDialog(int paramInt1, Activity paramActivity, int paramInt2) {
    return getErrorDialog(paramInt1, paramActivity, paramInt2, null);
  }
  
  public static Dialog getErrorDialog(int paramInt1, Activity paramActivity, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener) {
    return a(paramInt1, paramActivity, null, paramInt2, paramOnCancelListener);
  }
  
  public static PendingIntent getErrorPendingIntent(int paramInt1, Context paramContext, int paramInt2) {
    Intent intent = aj(paramInt1);
    return (intent == null) ? null : PendingIntent.getActivity(paramContext, paramInt2, intent, 268435456);
  }
  
  public static String getErrorString(int paramInt) {
    switch (paramInt) {
      default:
        return "UNKNOWN_ERROR_CODE";
      case 0:
        return "SUCCESS";
      case 1:
        return "SERVICE_MISSING";
      case 2:
        return "SERVICE_VERSION_UPDATE_REQUIRED";
      case 3:
        return "SERVICE_DISABLED";
      case 4:
        return "SIGN_IN_REQUIRED";
      case 5:
        return "INVALID_ACCOUNT";
      case 6:
        return "RESOLUTION_REQUIRED";
      case 7:
        return "NETWORK_ERROR";
      case 8:
        return "INTERNAL_ERROR";
      case 9:
        return "SERVICE_INVALID";
      case 10:
        return "DEVELOPER_ERROR";
      case 11:
        break;
    } 
    return "LICENSE_CHECK_FAILED";
  }
  
  public static String getOpenSourceSoftwareLicenseInfo(Context paramContext) {
    Uri uri = (new Uri.Builder()).scheme("android.resource").authority("com.google.android.gms").appendPath("raw").appendPath("oss_notice").build();
    try {
      InputStream inputStream = paramContext.getContentResolver().openInputStream(uri);
      try {
        String str1 = (new Scanner(inputStream)).useDelimiter("\\A").next();
        String str2 = str1;
      } catch (NoSuchElementException noSuchElementException) {
      
      } finally {
        if (inputStream != null)
          inputStream.close(); 
      } 
    } catch (Exception exception) {
      uri = null;
    } 
    return (String)uri;
  }
  
  public static Context getRemoteContext(Context paramContext) {
    try {
      return paramContext.createPackageContext("com.google.android.gms", 3);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return null;
    } 
  }
  
  public static Resources getRemoteResource(Context paramContext) {
    try {
      return paramContext.getPackageManager().getResourcesForApplication("com.google.android.gms");
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return null;
    } 
  }
  
  public static boolean gw() {
    return Jg ? Jh : "user".equals(Build.TYPE);
  }
  
  public static int isGooglePlayServicesAvailable(Context paramContext) {
    PackageManager packageManager = paramContext.getPackageManager();
    if (!jf.Mv)
      try {
        paramContext.getResources().getString(R.string.common_google_play_services_unknown_issue);
      } catch (Throwable throwable) {
        Log.e("GooglePlayServicesUtil", "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included.");
      }  
    if (!jf.Mv)
      D(paramContext); 
    try {
      String str;
      PackageInfo packageInfo = packageManager.getPackageInfo("com.google.android.gms", 64);
      if (lc.aU(packageInfo.versionCode)) {
        boolean bool;
        if (gw()) {
          bool = false;
        } else {
          bool = true;
        } 
        if (a(packageInfo, new byte[][] { b.Ix[bool], b.IE[bool], b.IC[bool] }) == null) {
          Log.w("GooglePlayServicesUtil", "Google Play Services signature invalid on Glass.");
          return 9;
        } 
        str = paramContext.getPackageName();
        try {
          PackageInfo packageInfo1 = packageManager.getPackageInfo(str, 64);
          if (!a(packageManager, packageInfo1)) {
            Log.w("GooglePlayServicesUtil", "Calling package " + packageInfo1.packageName + " signature invalid on Glass.");
            return 9;
          } 
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          Log.w("GooglePlayServicesUtil", "Could not get info for calling package: " + str);
          return 9;
        } 
      } else if (lc.K((Context)str)) {
        if (a(packageInfo, b.Ix) == null) {
          Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
          return 9;
        } 
      } else {
        try {
          PackageInfo packageInfo1 = nameNotFoundException.getPackageInfo("com.android.vending", 64);
          byte[] arrayOfByte = a(packageInfo1, b.Ix);
          if (arrayOfByte == null) {
            Log.w("GooglePlayServicesUtil", "Google Play Store signature invalid.");
            return 9;
          } 
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException1) {
          Log.w("GooglePlayServicesUtil", "Google Play Store is missing.");
          return 9;
        } 
        if (a(packageInfo, new byte[][] { (byte[])nameNotFoundException1 }) == null) {
          Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
          return 9;
        } 
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.w("GooglePlayServicesUtil", "Google Play services is missing.");
      return 1;
    } 
  }
  
  public static boolean isGoogleSignedUid(PackageManager paramPackageManager, int paramInt) {
    if (paramPackageManager == null)
      throw new SecurityException("Unknown error: invalid Package Manager"); 
    String[] arrayOfString = paramPackageManager.getPackagesForUid(paramInt);
    if (arrayOfString.length == 0 || !b(paramPackageManager, arrayOfString[0]))
      throw new SecurityException("Uid is not Google Signed"); 
    return true;
  }
  
  public static boolean isUserRecoverableError(int paramInt) {
    switch (paramInt) {
      default:
        return false;
      case 1:
      case 2:
      case 3:
      case 9:
        break;
    } 
    return true;
  }
  
  public static boolean showErrorDialogFragment(int paramInt1, Activity paramActivity, int paramInt2) {
    return showErrorDialogFragment(paramInt1, paramActivity, paramInt2, null);
  }
  
  public static boolean showErrorDialogFragment(int paramInt1, Activity paramActivity, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener) {
    return showErrorDialogFragment(paramInt1, paramActivity, null, paramInt2, paramOnCancelListener);
  }
  
  public static boolean showErrorDialogFragment(int paramInt1, Activity paramActivity, Fragment paramFragment, int paramInt2, DialogInterface.OnCancelListener paramOnCancelListener) {
    FragmentManager fragmentManager;
    boolean bool = false;
    Dialog dialog = a(paramInt1, paramActivity, paramFragment, paramInt2, paramOnCancelListener);
    if (dialog == null)
      return false; 
    try {
      boolean bool1 = paramActivity instanceof FragmentActivity;
      bool = bool1;
    } catch (NoClassDefFoundError noClassDefFoundError) {}
    if (bool) {
      fragmentManager = ((FragmentActivity)paramActivity).getSupportFragmentManager();
      SupportErrorDialogFragment.newInstance(dialog, paramOnCancelListener).show(fragmentManager, "GooglePlayServicesErrorDialog");
      return true;
    } 
    if (ll.ig()) {
      FragmentManager fragmentManager1 = fragmentManager.getFragmentManager();
      ErrorDialogFragment.newInstance(dialog, paramOnCancelListener).show(fragmentManager1, "GooglePlayServicesErrorDialog");
      return true;
    } 
    throw new RuntimeException("This Activity does not support Fragments.");
  }
  
  public static void showErrorNotification(int paramInt, Context paramContext) {
    int i = paramInt;
    if (lc.K(paramContext)) {
      i = paramInt;
      if (paramInt == 2)
        i = 42; 
    } 
    if (e(paramContext, i)) {
      E(paramContext);
      return;
    } 
    a(i, paramContext);
  }
  
  private static class a extends Handler {
    private final Context mO;
    
    a(Context param1Context) {
      super(looper);
      Looper looper;
      this.mO = param1Context.getApplicationContext();
    }
    
    public void handleMessage(Message param1Message) {
      switch (param1Message.what) {
        default:
          Log.w("GooglePlayServicesUtil", "Don't know how to handle this message: " + param1Message.what);
          return;
        case 1:
          break;
      } 
      int i = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this.mO);
      if (GooglePlayServicesUtil.isUserRecoverableError(i)) {
        GooglePlayServicesUtil.b(i, this.mO);
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\common\GooglePlayServicesUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */