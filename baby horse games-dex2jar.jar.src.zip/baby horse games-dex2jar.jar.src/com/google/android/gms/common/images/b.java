package com.google.android.gms.common.images;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

public class b implements Parcelable.Creator<WebImage> {
  static void a(WebImage paramWebImage, Parcel paramParcel, int paramInt) {
    int i = com.google.android.gms.common.internal.safeparcel.b.H(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramWebImage.getVersionCode());
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 2, (Parcelable)paramWebImage.getUrl(), paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 3, paramWebImage.getWidth());
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 4, paramWebImage.getHeight());
    com.google.android.gms.common.internal.safeparcel.b.H(paramParcel, i);
  }
  
  public WebImage C(Parcel paramParcel) {
    int i = 0;
    int m = a.G(paramParcel);
    Uri uri = null;
    int j = 0;
    int k = 0;
    while (paramParcel.dataPosition() < m) {
      int n = a.F(paramParcel);
      switch (a.aH(n)) {
        case 1:
          k = a.g(paramParcel, n);
          break;
        case 2:
          uri = (Uri)a.a(paramParcel, n, Uri.CREATOR);
          break;
        case 3:
          j = a.g(paramParcel, n);
          break;
        case 4:
          i = a.g(paramParcel, n);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != m)
      throw new a.a("Overread allowed size end=" + m, paramParcel); 
    return new WebImage(k, uri, j, i);
  }
  
  public WebImage[] aA(int paramInt) {
    return new WebImage[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\common\images\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */