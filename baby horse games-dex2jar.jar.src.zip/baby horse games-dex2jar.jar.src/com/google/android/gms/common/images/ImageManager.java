package com.google.android.gms.common.images;

import android.app.ActivityManager;
import android.content.ComponentCallbacks;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.widget.ImageView;
import com.google.android.gms.internal.jc;
import com.google.android.gms.internal.je;
import com.google.android.gms.internal.kj;
import com.google.android.gms.internal.ll;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ImageManager {
  private static final Object Lu = new Object();
  
  private static HashSet<Uri> Lv = new HashSet<Uri>();
  
  private static ImageManager Lw;
  
  private static ImageManager Lx;
  
  private final jc LA;
  
  private final Map<a, ImageReceiver> LB;
  
  private final Map<Uri, ImageReceiver> LC;
  
  private final Map<Uri, Long> LD;
  
  private final ExecutorService Ly;
  
  private final b Lz;
  
  private final Context mContext;
  
  private final Handler mHandler;
  
  private ImageManager(Context paramContext, boolean paramBoolean) {
    this.mContext = paramContext.getApplicationContext();
    this.mHandler = new Handler(Looper.getMainLooper());
    this.Ly = Executors.newFixedThreadPool(4);
    if (paramBoolean) {
      this.Lz = new b(this.mContext);
      if (ll.ij())
        hd(); 
    } else {
      this.Lz = null;
    } 
    this.LA = new jc();
    this.LB = new HashMap<a, ImageReceiver>();
    this.LC = new HashMap<Uri, ImageReceiver>();
    this.LD = new HashMap<Uri, Long>();
  }
  
  private Bitmap a(a.a parama) {
    return (this.Lz == null) ? null : (Bitmap)this.Lz.get(parama);
  }
  
  public static ImageManager c(Context paramContext, boolean paramBoolean) {
    if (paramBoolean) {
      if (Lx == null)
        Lx = new ImageManager(paramContext, true); 
      return Lx;
    } 
    if (Lw == null)
      Lw = new ImageManager(paramContext, false); 
    return Lw;
  }
  
  public static ImageManager create(Context paramContext) {
    return c(paramContext, false);
  }
  
  private void hd() {
    this.mContext.registerComponentCallbacks((ComponentCallbacks)new e(this.Lz));
  }
  
  public void a(a parama) {
    je.aU("ImageManager.loadImage() must be called in the main thread");
    (new d(this, parama)).run();
  }
  
  public void loadImage(ImageView paramImageView, int paramInt) {
    a(new a.b(paramImageView, paramInt));
  }
  
  public void loadImage(ImageView paramImageView, Uri paramUri) {
    a(new a.b(paramImageView, paramUri));
  }
  
  public void loadImage(ImageView paramImageView, Uri paramUri, int paramInt) {
    a.b b1 = new a.b(paramImageView, paramUri);
    b1.az(paramInt);
    a(b1);
  }
  
  public void loadImage(OnImageLoadedListener paramOnImageLoadedListener, Uri paramUri) {
    a(new a.c(paramOnImageLoadedListener, paramUri));
  }
  
  public void loadImage(OnImageLoadedListener paramOnImageLoadedListener, Uri paramUri, int paramInt) {
    a.c c = new a.c(paramOnImageLoadedListener, paramUri);
    c.az(paramInt);
    a(c);
  }
  
  private final class ImageReceiver extends ResultReceiver {
    private final ArrayList<a> LE;
    
    private final Uri mUri;
    
    ImageReceiver(ImageManager this$0, Uri param1Uri) {
      super(new Handler(Looper.getMainLooper()));
      this.mUri = param1Uri;
      this.LE = new ArrayList<a>();
    }
    
    public void b(a param1a) {
      je.aU("ImageReceiver.addImageRequest() must be called in the main thread");
      this.LE.add(param1a);
    }
    
    public void c(a param1a) {
      je.aU("ImageReceiver.removeImageRequest() must be called in the main thread");
      this.LE.remove(param1a);
    }
    
    public void hg() {
      Intent intent = new Intent("com.google.android.gms.common.images.LOAD_IMAGE");
      intent.putExtra("com.google.android.gms.extras.uri", (Parcelable)this.mUri);
      intent.putExtra("com.google.android.gms.extras.resultReceiver", (Parcelable)this);
      intent.putExtra("com.google.android.gms.extras.priority", 3);
      ImageManager.b(this.LF).sendBroadcast(intent);
    }
    
    public void onReceiveResult(int param1Int, Bundle param1Bundle) {
      ParcelFileDescriptor parcelFileDescriptor = (ParcelFileDescriptor)param1Bundle.getParcelable("com.google.android.gms.extra.fileDescriptor");
      ImageManager.f(this.LF).execute(new ImageManager.c(this.LF, this.mUri, parcelFileDescriptor));
    }
  }
  
  public static interface OnImageLoadedListener {
    void onImageLoaded(Uri param1Uri, Drawable param1Drawable, boolean param1Boolean);
  }
  
  private static final class a {
    static int a(ActivityManager param1ActivityManager) {
      return param1ActivityManager.getLargeMemoryClass();
    }
  }
  
  private static final class b extends kj<a.a, Bitmap> {
    public b(Context param1Context) {
      super(I(param1Context));
    }
    
    private static int I(Context param1Context) {
      ActivityManager activityManager = (ActivityManager)param1Context.getSystemService("activity");
      if (((param1Context.getApplicationInfo()).flags & 0x100000) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i && ll.ig()) {
        i = ImageManager.a.a(activityManager);
        return (int)((i * 1048576) * 0.33F);
      } 
      int i = activityManager.getMemoryClass();
      return (int)((i * 1048576) * 0.33F);
    }
    
    protected int a(a.a param1a, Bitmap param1Bitmap) {
      return param1Bitmap.getHeight() * param1Bitmap.getRowBytes();
    }
    
    protected void a(boolean param1Boolean, a.a param1a, Bitmap param1Bitmap1, Bitmap param1Bitmap2) {
      super.entryRemoved(param1Boolean, param1a, param1Bitmap1, param1Bitmap2);
    }
  }
  
  private final class c implements Runnable {
    private final ParcelFileDescriptor LG;
    
    private final Uri mUri;
    
    public c(ImageManager this$0, Uri param1Uri, ParcelFileDescriptor param1ParcelFileDescriptor) {
      this.mUri = param1Uri;
      this.LG = param1ParcelFileDescriptor;
    }
    
    public void run() {
      // Byte code:
      //   0: ldc 'LoadBitmapFromDiskRunnable can't be executed in the main thread'
      //   2: invokestatic aV : (Ljava/lang/String;)V
      //   5: iconst_0
      //   6: istore_1
      //   7: iconst_0
      //   8: istore_2
      //   9: aconst_null
      //   10: astore_3
      //   11: aconst_null
      //   12: astore #4
      //   14: aload_0
      //   15: getfield LG : Landroid/os/ParcelFileDescriptor;
      //   18: ifnull -> 41
      //   21: aload_0
      //   22: getfield LG : Landroid/os/ParcelFileDescriptor;
      //   25: invokevirtual getFileDescriptor : ()Ljava/io/FileDescriptor;
      //   28: invokestatic decodeFileDescriptor : (Ljava/io/FileDescriptor;)Landroid/graphics/Bitmap;
      //   31: astore_3
      //   32: iload_2
      //   33: istore_1
      //   34: aload_0
      //   35: getfield LG : Landroid/os/ParcelFileDescriptor;
      //   38: invokevirtual close : ()V
      //   41: new java/util/concurrent/CountDownLatch
      //   44: dup
      //   45: iconst_1
      //   46: invokespecial <init> : (I)V
      //   49: astore #4
      //   51: aload_0
      //   52: getfield LF : Lcom/google/android/gms/common/images/ImageManager;
      //   55: invokestatic g : (Lcom/google/android/gms/common/images/ImageManager;)Landroid/os/Handler;
      //   58: new com/google/android/gms/common/images/ImageManager$f
      //   61: dup
      //   62: aload_0
      //   63: getfield LF : Lcom/google/android/gms/common/images/ImageManager;
      //   66: aload_0
      //   67: getfield mUri : Landroid/net/Uri;
      //   70: aload_3
      //   71: iload_1
      //   72: aload #4
      //   74: invokespecial <init> : (Lcom/google/android/gms/common/images/ImageManager;Landroid/net/Uri;Landroid/graphics/Bitmap;ZLjava/util/concurrent/CountDownLatch;)V
      //   77: invokevirtual post : (Ljava/lang/Runnable;)Z
      //   80: pop
      //   81: aload #4
      //   83: invokevirtual await : ()V
      //   86: return
      //   87: astore_3
      //   88: ldc 'ImageManager'
      //   90: new java/lang/StringBuilder
      //   93: dup
      //   94: invokespecial <init> : ()V
      //   97: ldc 'OOM while loading bitmap for uri: '
      //   99: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   102: aload_0
      //   103: getfield mUri : Landroid/net/Uri;
      //   106: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   109: invokevirtual toString : ()Ljava/lang/String;
      //   112: aload_3
      //   113: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   116: pop
      //   117: iconst_1
      //   118: istore_1
      //   119: aload #4
      //   121: astore_3
      //   122: goto -> 34
      //   125: astore #4
      //   127: ldc 'ImageManager'
      //   129: ldc 'closed failed'
      //   131: aload #4
      //   133: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   136: pop
      //   137: goto -> 41
      //   140: astore_3
      //   141: ldc 'ImageManager'
      //   143: new java/lang/StringBuilder
      //   146: dup
      //   147: invokespecial <init> : ()V
      //   150: ldc 'Latch interrupted while posting '
      //   152: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   155: aload_0
      //   156: getfield mUri : Landroid/net/Uri;
      //   159: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   162: invokevirtual toString : ()Ljava/lang/String;
      //   165: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
      //   168: pop
      //   169: return
      // Exception table:
      //   from	to	target	type
      //   21	32	87	java/lang/OutOfMemoryError
      //   34	41	125	java/io/IOException
      //   81	86	140	java/lang/InterruptedException
    }
  }
  
  private final class d implements Runnable {
    private final a LH;
    
    public d(ImageManager this$0, a param1a) {
      this.LH = param1a;
    }
    
    public void run() {
      je.aU("LoadImageRunnable must be executed on the main thread");
      ImageManager.ImageReceiver imageReceiver1 = (ImageManager.ImageReceiver)ImageManager.a(this.LF).get(this.LH);
      if (imageReceiver1 != null) {
        ImageManager.a(this.LF).remove(this.LH);
        imageReceiver1.c(this.LH);
      } 
      a.a a1 = this.LH.LJ;
      if (a1.uri == null) {
        this.LH.a(ImageManager.b(this.LF), ImageManager.c(this.LF), true);
        return;
      } 
      Bitmap bitmap = ImageManager.a(this.LF, a1);
      if (bitmap != null) {
        this.LH.a(ImageManager.b(this.LF), bitmap, true);
        return;
      } 
      Long long_ = (Long)ImageManager.d(this.LF).get(a1.uri);
      if (long_ != null) {
        if (SystemClock.elapsedRealtime() - long_.longValue() < 3600000L) {
          this.LH.a(ImageManager.b(this.LF), ImageManager.c(this.LF), true);
          return;
        } 
        ImageManager.d(this.LF).remove(a1.uri);
      } 
      this.LH.a(ImageManager.b(this.LF), ImageManager.c(this.LF));
      ImageManager.ImageReceiver imageReceiver2 = (ImageManager.ImageReceiver)ImageManager.e(this.LF).get(a1.uri);
      null = imageReceiver2;
      if (imageReceiver2 == null) {
        null = new ImageManager.ImageReceiver(this.LF, a1.uri);
        ImageManager.e(this.LF).put(a1.uri, null);
      } 
      null.b(this.LH);
      if (!(this.LH instanceof a.c))
        ImageManager.a(this.LF).put(this.LH, null); 
      synchronized (ImageManager.he()) {
        if (!ImageManager.hf().contains(a1.uri)) {
          ImageManager.hf().add(a1.uri);
          null.hg();
        } 
        return;
      } 
    }
  }
  
  private static final class e implements ComponentCallbacks2 {
    private final ImageManager.b Lz;
    
    public e(ImageManager.b param1b) {
      this.Lz = param1b;
    }
    
    public void onConfigurationChanged(Configuration param1Configuration) {}
    
    public void onLowMemory() {
      this.Lz.evictAll();
    }
    
    public void onTrimMemory(int param1Int) {
      if (param1Int >= 60) {
        this.Lz.evictAll();
        return;
      } 
      if (param1Int >= 20) {
        this.Lz.trimToSize(this.Lz.size() / 2);
        return;
      } 
    }
  }
  
  private final class f implements Runnable {
    private boolean LI;
    
    private final Bitmap mBitmap;
    
    private final Uri mUri;
    
    private final CountDownLatch mr;
    
    public f(ImageManager this$0, Uri param1Uri, Bitmap param1Bitmap, boolean param1Boolean, CountDownLatch param1CountDownLatch) {
      this.mUri = param1Uri;
      this.mBitmap = param1Bitmap;
      this.LI = param1Boolean;
      this.mr = param1CountDownLatch;
    }
    
    private void a(ImageManager.ImageReceiver param1ImageReceiver, boolean param1Boolean) {
      ArrayList<a> arrayList = ImageManager.ImageReceiver.a(param1ImageReceiver);
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        a a = arrayList.get(i);
        if (param1Boolean) {
          a.a(ImageManager.b(this.LF), this.mBitmap, false);
        } else {
          ImageManager.d(this.LF).put(this.mUri, Long.valueOf(SystemClock.elapsedRealtime()));
          a.a(ImageManager.b(this.LF), ImageManager.c(this.LF), false);
        } 
        if (!(a instanceof a.c))
          ImageManager.a(this.LF).remove(a); 
      } 
    }
    
    public void run() {
      boolean bool;
      je.aU("OnBitmapLoadedRunnable must be executed in the main thread");
      if (this.mBitmap != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (ImageManager.h(this.LF) != null) {
        if (this.LI) {
          ImageManager.h(this.LF).evictAll();
          System.gc();
          this.LI = false;
          ImageManager.g(this.LF).post(this);
          return;
        } 
        if (bool)
          ImageManager.h(this.LF).put(new a.a(this.mUri), this.mBitmap); 
      } 
      ImageManager.ImageReceiver imageReceiver = (ImageManager.ImageReceiver)ImageManager.e(this.LF).remove(this.mUri);
      if (imageReceiver != null)
        a(imageReceiver, bool); 
      this.mr.countDown();
      synchronized (ImageManager.he()) {
        ImageManager.hf().remove(this.mUri);
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\common\images\ImageManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */