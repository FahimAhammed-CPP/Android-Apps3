package com.google.android.gms.common.images;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;
import com.google.android.gms.internal.iz;
import com.google.android.gms.internal.ja;
import com.google.android.gms.internal.jb;
import com.google.android.gms.internal.jc;
import com.google.android.gms.internal.je;
import com.google.android.gms.internal.jv;
import java.lang.ref.WeakReference;

public abstract class a {
  final a LJ;
  
  protected int LK = 0;
  
  protected int LL = 0;
  
  protected boolean LM = false;
  
  protected ImageManager.OnImageLoadedListener LN;
  
  private boolean LO = true;
  
  private boolean LP = false;
  
  private boolean LQ = true;
  
  protected int LR;
  
  public a(Uri paramUri, int paramInt) {
    this.LJ = new a(paramUri);
    this.LL = paramInt;
  }
  
  private Drawable a(Context paramContext, jc paramjc, int paramInt) {
    Resources resources = paramContext.getResources();
    if (this.LR > 0) {
      jc.a a1 = new jc.a(paramInt, this.LR);
      Drawable drawable2 = (Drawable)paramjc.get(a1);
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        drawable2 = resources.getDrawable(paramInt);
        drawable1 = drawable2;
        if ((this.LR & 0x1) != 0)
          drawable1 = a(resources, drawable2); 
        paramjc.put(a1, drawable1);
      } 
      return drawable1;
    } 
    return resources.getDrawable(paramInt);
  }
  
  protected Drawable a(Resources paramResources, Drawable paramDrawable) {
    return ja.a(paramResources, paramDrawable);
  }
  
  protected iz a(Drawable paramDrawable1, Drawable paramDrawable2) {
    if (paramDrawable1 != null) {
      Drawable drawable1 = paramDrawable1;
      if (paramDrawable1 instanceof iz)
        drawable1 = ((iz)paramDrawable1).hh(); 
      return new iz(drawable1, paramDrawable2);
    } 
    Drawable drawable = null;
    return new iz(drawable, paramDrawable2);
  }
  
  void a(Context paramContext, Bitmap paramBitmap, boolean paramBoolean) {
    je.f(paramBitmap);
    Bitmap bitmap = paramBitmap;
    if ((this.LR & 0x1) != 0)
      bitmap = ja.a(paramBitmap); 
    BitmapDrawable bitmapDrawable = new BitmapDrawable(paramContext.getResources(), bitmap);
    if (this.LN != null)
      this.LN.onImageLoaded(this.LJ.uri, (Drawable)bitmapDrawable, true); 
    a((Drawable)bitmapDrawable, paramBoolean, false, true);
  }
  
  void a(Context paramContext, jc paramjc) {
    if (this.LQ) {
      Drawable drawable = null;
      if (this.LK != 0)
        drawable = a(paramContext, paramjc, this.LK); 
      a(drawable, false, true, false);
    } 
  }
  
  void a(Context paramContext, jc paramjc, boolean paramBoolean) {
    Drawable drawable = null;
    if (this.LL != 0)
      drawable = a(paramContext, paramjc, this.LL); 
    if (this.LN != null)
      this.LN.onImageLoaded(this.LJ.uri, drawable, false); 
    a(drawable, paramBoolean, false, false);
  }
  
  protected abstract void a(Drawable paramDrawable, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  public void az(int paramInt) {
    this.LL = paramInt;
  }
  
  protected boolean b(boolean paramBoolean1, boolean paramBoolean2) {
    return (this.LO && !paramBoolean2 && (!paramBoolean1 || this.LP));
  }
  
  static final class a {
    public final Uri uri;
    
    public a(Uri param1Uri) {
      this.uri = param1Uri;
    }
    
    public boolean equals(Object param1Object) {
      return !(param1Object instanceof a) ? false : ((this == param1Object) ? true : jv.equal(((a)param1Object).uri, this.uri));
    }
    
    public int hashCode() {
      return jv.hashCode(new Object[] { this.uri });
    }
  }
  
  public static final class b extends a {
    private WeakReference<ImageView> LS;
    
    public b(ImageView param1ImageView, int param1Int) {
      super(null, param1Int);
      je.f(param1ImageView);
      this.LS = new WeakReference<ImageView>(param1ImageView);
    }
    
    public b(ImageView param1ImageView, Uri param1Uri) {
      super(param1Uri, 0);
      je.f(param1ImageView);
      this.LS = new WeakReference<ImageView>(param1ImageView);
    }
    
    private void a(ImageView param1ImageView, Drawable param1Drawable, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
      int i;
      iz iz;
      if (!param1Boolean2 && !param1Boolean3) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i && param1ImageView instanceof jb) {
        int j = ((jb)param1ImageView).hj();
        if (this.LL != 0 && j == this.LL)
          return; 
      } 
      param1Boolean1 = b(param1Boolean1, param1Boolean2);
      if (this.LM && param1Drawable != null)
        param1Drawable = param1Drawable.getConstantState().newDrawable(); 
      Drawable drawable = param1Drawable;
      if (param1Boolean1)
        iz = a(param1ImageView.getDrawable(), param1Drawable); 
      param1ImageView.setImageDrawable((Drawable)iz);
      if (param1ImageView instanceof jb) {
        jb jb = (jb)param1ImageView;
        if (param1Boolean3) {
          Uri uri = this.LJ.uri;
        } else {
          param1ImageView = null;
        } 
        jb.g((Uri)param1ImageView);
        if (i) {
          i = this.LL;
        } else {
          i = 0;
        } 
        jb.aB(i);
      } 
      if (param1Boolean1) {
        iz.startTransition(250);
        return;
      } 
    }
    
    protected void a(Drawable param1Drawable, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
      ImageView imageView = this.LS.get();
      if (imageView != null)
        a(imageView, param1Drawable, param1Boolean1, param1Boolean2, param1Boolean3); 
    }
    
    public boolean equals(Object param1Object) {
      if (!(param1Object instanceof b))
        return false; 
      if (this == param1Object)
        return true; 
      b b1 = (b)param1Object;
      param1Object = this.LS.get();
      ImageView imageView = b1.LS.get();
      return (imageView != null && param1Object != null && jv.equal(imageView, param1Object));
    }
    
    public int hashCode() {
      return 0;
    }
  }
  
  public static final class c extends a {
    private WeakReference<ImageManager.OnImageLoadedListener> LT;
    
    public c(ImageManager.OnImageLoadedListener param1OnImageLoadedListener, Uri param1Uri) {
      super(param1Uri, 0);
      je.f(param1OnImageLoadedListener);
      this.LT = new WeakReference<ImageManager.OnImageLoadedListener>(param1OnImageLoadedListener);
    }
    
    protected void a(Drawable param1Drawable, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
      if (!param1Boolean2) {
        ImageManager.OnImageLoadedListener onImageLoadedListener = this.LT.get();
        if (onImageLoadedListener != null)
          onImageLoadedListener.onImageLoaded(this.LJ.uri, param1Drawable, param1Boolean3); 
      } 
    }
    
    public boolean equals(Object param1Object) {
      if (!(param1Object instanceof c))
        return false; 
      if (this == param1Object)
        return true; 
      param1Object = param1Object;
      ImageManager.OnImageLoadedListener onImageLoadedListener1 = this.LT.get();
      ImageManager.OnImageLoadedListener onImageLoadedListener2 = ((c)param1Object).LT.get();
      return (onImageLoadedListener2 != null && onImageLoadedListener1 != null && jv.equal(onImageLoadedListener2, onImageLoadedListener1) && jv.equal(((c)param1Object).LJ, this.LJ));
    }
    
    public int hashCode() {
      return jv.hashCode(new Object[] { this.LJ });
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\common\images\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */