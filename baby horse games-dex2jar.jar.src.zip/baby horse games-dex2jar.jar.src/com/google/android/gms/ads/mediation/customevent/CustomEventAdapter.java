package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.internal.gr;

public final class CustomEventAdapter implements MediationBannerAdapter, MediationInterstitialAdapter {
  private View n;
  
  private CustomEventBanner xu;
  
  private CustomEventInterstitial xv;
  
  private static <T> T a(String paramString) {
    try {
      return (T)Class.forName(paramString).newInstance();
    } catch (Throwable throwable) {
      gr.W("Could not instantiate custom event adapter: " + paramString + ". " + throwable.getMessage());
      return null;
    } 
  }
  
  private void a(View paramView) {
    this.n = paramView;
  }
  
  public View getBannerView() {
    return this.n;
  }
  
  public void onDestroy() {
    if (this.xu != null)
      this.xu.onDestroy(); 
    if (this.xv != null)
      this.xv.onDestroy(); 
  }
  
  public void onPause() {
    if (this.xu != null)
      this.xu.onPause(); 
    if (this.xv != null)
      this.xv.onPause(); 
  }
  
  public void onResume() {
    if (this.xu != null)
      this.xu.onResume(); 
    if (this.xv != null)
      this.xv.onResume(); 
  }
  
  public void requestBannerAd(Context paramContext, MediationBannerListener paramMediationBannerListener, Bundle paramBundle1, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    this.xu = a(paramBundle1.getString("class_name"));
    if (this.xu == null) {
      paramMediationBannerListener.onAdFailedToLoad(this, 0);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    this.xu.requestBannerAd(paramContext, new a(this, paramMediationBannerListener), paramBundle1.getString("parameter"), paramAdSize, paramMediationAdRequest, paramBundle2);
  }
  
  public void requestInterstitialAd(Context paramContext, MediationInterstitialListener paramMediationInterstitialListener, Bundle paramBundle1, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    this.xv = a(paramBundle1.getString("class_name"));
    if (this.xv == null) {
      paramMediationInterstitialListener.onAdFailedToLoad(this, 0);
      return;
    } 
    if (paramBundle2 == null) {
      paramBundle2 = null;
    } else {
      paramBundle2 = paramBundle2.getBundle(paramBundle1.getString("class_name"));
    } 
    this.xv.requestInterstitialAd(paramContext, new b(this, this, paramMediationInterstitialListener), paramBundle1.getString("parameter"), paramMediationAdRequest, paramBundle2);
  }
  
  public void showInterstitial() {
    this.xv.showInterstitial();
  }
  
  private static final class a implements CustomEventBannerListener {
    private final MediationBannerListener l;
    
    private final CustomEventAdapter xw;
    
    public a(CustomEventAdapter param1CustomEventAdapter, MediationBannerListener param1MediationBannerListener) {
      this.xw = param1CustomEventAdapter;
      this.l = param1MediationBannerListener;
    }
    
    public void onAdClicked() {
      gr.S("Custom event adapter called onAdClicked.");
      this.l.onAdClicked(this.xw);
    }
    
    public void onAdClosed() {
      gr.S("Custom event adapter called onAdClosed.");
      this.l.onAdClosed(this.xw);
    }
    
    public void onAdFailedToLoad(int param1Int) {
      gr.S("Custom event adapter called onAdFailedToLoad.");
      this.l.onAdFailedToLoad(this.xw, param1Int);
    }
    
    public void onAdLeftApplication() {
      gr.S("Custom event adapter called onAdLeftApplication.");
      this.l.onAdLeftApplication(this.xw);
    }
    
    public void onAdLoaded(View param1View) {
      gr.S("Custom event adapter called onAdLoaded.");
      CustomEventAdapter.a(this.xw, param1View);
      this.l.onAdLoaded(this.xw);
    }
    
    public void onAdOpened() {
      gr.S("Custom event adapter called onAdOpened.");
      this.l.onAdOpened(this.xw);
    }
  }
  
  private class b implements CustomEventInterstitialListener {
    private final MediationInterstitialListener m;
    
    private final CustomEventAdapter xw;
    
    public b(CustomEventAdapter this$0, CustomEventAdapter param1CustomEventAdapter1, MediationInterstitialListener param1MediationInterstitialListener) {
      this.xw = param1CustomEventAdapter1;
      this.m = param1MediationInterstitialListener;
    }
    
    public void onAdClicked() {
      gr.S("Custom event adapter called onAdClicked.");
      this.m.onAdClicked(this.xw);
    }
    
    public void onAdClosed() {
      gr.S("Custom event adapter called onAdClosed.");
      this.m.onAdClosed(this.xw);
    }
    
    public void onAdFailedToLoad(int param1Int) {
      gr.S("Custom event adapter called onFailedToReceiveAd.");
      this.m.onAdFailedToLoad(this.xw, param1Int);
    }
    
    public void onAdLeftApplication() {
      gr.S("Custom event adapter called onAdLeftApplication.");
      this.m.onAdLeftApplication(this.xw);
    }
    
    public void onAdLoaded() {
      gr.S("Custom event adapter called onReceivedAd.");
      this.m.onAdLoaded(this.xx);
    }
    
    public void onAdOpened() {
      gr.S("Custom event adapter called onAdOpened.");
      this.m.onAdOpened(this.xw);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */