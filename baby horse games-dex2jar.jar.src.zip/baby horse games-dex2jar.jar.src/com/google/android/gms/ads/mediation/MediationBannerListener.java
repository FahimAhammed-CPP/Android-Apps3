package com.google.android.gms.ads.mediation;

public interface MediationBannerListener {
  void onAdClicked(MediationBannerAdapter paramMediationBannerAdapter);
  
  void onAdClosed(MediationBannerAdapter paramMediationBannerAdapter);
  
  void onAdFailedToLoad(MediationBannerAdapter paramMediationBannerAdapter, int paramInt);
  
  void onAdLeftApplication(MediationBannerAdapter paramMediationBannerAdapter);
  
  void onAdLoaded(MediationBannerAdapter paramMediationBannerAdapter);
  
  void onAdOpened(MediationBannerAdapter paramMediationBannerAdapter);
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\ads\mediation\MediationBannerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */