package com.google.android.gms.ads.mediation.customevent;

import android.view.View;

public interface CustomEventBannerListener extends CustomEventListener {
  void onAdLoaded(View paramView);
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\ads\mediation\customevent\CustomEventBannerListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */