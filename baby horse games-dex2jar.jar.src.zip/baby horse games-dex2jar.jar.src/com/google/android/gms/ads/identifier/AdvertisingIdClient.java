package com.google.android.gms.ads.identifier;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.jx;
import com.google.android.gms.internal.s;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class AdvertisingIdClient {
  com.google.android.gms.common.a ln;
  
  s lo;
  
  boolean lp;
  
  Object lq = new Object();
  
  a lr;
  
  final long ls;
  
  private final Context mContext;
  
  public AdvertisingIdClient(Context paramContext) {
    this(paramContext, 30000L);
  }
  
  public AdvertisingIdClient(Context paramContext, long paramLong) {
    jx.i(paramContext);
    this.mContext = paramContext;
    this.lp = false;
    this.ls = paramLong;
  }
  
  private void Z() {
    synchronized (this.lq) {
      if (this.lr != null) {
        this.lr.cancel();
        try {
          this.lr.join();
        } catch (InterruptedException interruptedException) {}
      } 
      if (this.ls > 0L)
        this.lr = new a(this, this.ls); 
      return;
    } 
  }
  
  static s a(Context paramContext, com.google.android.gms.common.a parama) throws IOException {
    try {
      return s.a.b(parama.gs());
    } catch (InterruptedException interruptedException) {
      throw new IOException("Interrupted exception");
    } 
  }
  
  public static Info getAdvertisingIdInfo(Context paramContext) throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    AdvertisingIdClient advertisingIdClient = new AdvertisingIdClient(paramContext, -1L);
    try {
      advertisingIdClient.b(false);
      return advertisingIdClient.getInfo();
    } finally {
      advertisingIdClient.finish();
    } 
  }
  
  static com.google.android.gms.common.a h(Context paramContext) throws IOException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    try {
      paramContext.getPackageManager().getPackageInfo("com.android.vending", 0);
      try {
        GooglePlayServicesUtil.C(paramContext);
        com.google.android.gms.common.a a1 = new com.google.android.gms.common.a();
        Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        if (paramContext.bindService(intent, (ServiceConnection)a1, 1))
          return a1; 
      } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
        throw new IOException(googlePlayServicesNotAvailableException);
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new GooglePlayServicesNotAvailableException(9);
    } 
  }
  
  protected void b(boolean paramBoolean) throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic aV : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield lp : Z
    //   11: ifeq -> 18
    //   14: aload_0
    //   15: invokevirtual finish : ()V
    //   18: aload_0
    //   19: aload_0
    //   20: getfield mContext : Landroid/content/Context;
    //   23: invokestatic h : (Landroid/content/Context;)Lcom/google/android/gms/common/a;
    //   26: putfield ln : Lcom/google/android/gms/common/a;
    //   29: aload_0
    //   30: aload_0
    //   31: getfield mContext : Landroid/content/Context;
    //   34: aload_0
    //   35: getfield ln : Lcom/google/android/gms/common/a;
    //   38: invokestatic a : (Landroid/content/Context;Lcom/google/android/gms/common/a;)Lcom/google/android/gms/internal/s;
    //   41: putfield lo : Lcom/google/android/gms/internal/s;
    //   44: aload_0
    //   45: iconst_1
    //   46: putfield lp : Z
    //   49: iload_1
    //   50: ifeq -> 57
    //   53: aload_0
    //   54: invokespecial Z : ()V
    //   57: aload_0
    //   58: monitorexit
    //   59: return
    //   60: astore_2
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_2
    //   64: athrow
    // Exception table:
    //   from	to	target	type
    //   7	18	60	finally
    //   18	49	60	finally
    //   53	57	60	finally
    //   57	59	60	finally
    //   61	63	60	finally
  }
  
  protected void finalize() throws Throwable {
    finish();
    super.finalize();
  }
  
  public void finish() {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic aV : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield mContext : Landroid/content/Context;
    //   11: ifnull -> 21
    //   14: aload_0
    //   15: getfield ln : Lcom/google/android/gms/common/a;
    //   18: ifnonnull -> 24
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: aload_0
    //   25: getfield lp : Z
    //   28: ifeq -> 42
    //   31: aload_0
    //   32: getfield mContext : Landroid/content/Context;
    //   35: aload_0
    //   36: getfield ln : Lcom/google/android/gms/common/a;
    //   39: invokevirtual unbindService : (Landroid/content/ServiceConnection;)V
    //   42: aload_0
    //   43: iconst_0
    //   44: putfield lp : Z
    //   47: aload_0
    //   48: aconst_null
    //   49: putfield lo : Lcom/google/android/gms/internal/s;
    //   52: aload_0
    //   53: aconst_null
    //   54: putfield ln : Lcom/google/android/gms/common/a;
    //   57: aload_0
    //   58: monitorexit
    //   59: return
    //   60: astore_1
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_1
    //   64: athrow
    //   65: astore_1
    //   66: ldc 'AdvertisingIdClient'
    //   68: ldc 'AdvertisingIdClient unbindService failed.'
    //   70: aload_1
    //   71: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   74: pop
    //   75: goto -> 42
    // Exception table:
    //   from	to	target	type
    //   7	21	60	finally
    //   21	23	60	finally
    //   24	42	65	java/lang/IllegalArgumentException
    //   24	42	60	finally
    //   42	59	60	finally
    //   61	63	60	finally
    //   66	75	60	finally
  }
  
  public Info getInfo() throws IOException {
    // Byte code:
    //   0: ldc 'Calling this from your main thread can lead to deadlock'
    //   2: invokestatic aV : (Ljava/lang/String;)V
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield lp : Z
    //   11: ifne -> 94
    //   14: aload_0
    //   15: getfield lq : Ljava/lang/Object;
    //   18: astore_1
    //   19: aload_1
    //   20: monitorenter
    //   21: aload_0
    //   22: getfield lr : Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$a;
    //   25: ifnull -> 38
    //   28: aload_0
    //   29: getfield lr : Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$a;
    //   32: invokevirtual aa : ()Z
    //   35: ifne -> 58
    //   38: new java/io/IOException
    //   41: dup
    //   42: ldc 'AdvertisingIdClient is not connected.'
    //   44: invokespecial <init> : (Ljava/lang/String;)V
    //   47: athrow
    //   48: astore_2
    //   49: aload_1
    //   50: monitorexit
    //   51: aload_2
    //   52: athrow
    //   53: astore_1
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_1
    //   57: athrow
    //   58: aload_1
    //   59: monitorexit
    //   60: aload_0
    //   61: iconst_0
    //   62: invokevirtual b : (Z)V
    //   65: aload_0
    //   66: getfield lp : Z
    //   69: ifne -> 94
    //   72: new java/io/IOException
    //   75: dup
    //   76: ldc 'AdvertisingIdClient cannot reconnect.'
    //   78: invokespecial <init> : (Ljava/lang/String;)V
    //   81: athrow
    //   82: astore_1
    //   83: new java/io/IOException
    //   86: dup
    //   87: ldc 'AdvertisingIdClient cannot reconnect.'
    //   89: aload_1
    //   90: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   93: athrow
    //   94: aload_0
    //   95: getfield ln : Lcom/google/android/gms/common/a;
    //   98: invokestatic i : (Ljava/lang/Object;)Ljava/lang/Object;
    //   101: pop
    //   102: aload_0
    //   103: getfield lo : Lcom/google/android/gms/internal/s;
    //   106: invokestatic i : (Ljava/lang/Object;)Ljava/lang/Object;
    //   109: pop
    //   110: new com/google/android/gms/ads/identifier/AdvertisingIdClient$Info
    //   113: dup
    //   114: aload_0
    //   115: getfield lo : Lcom/google/android/gms/internal/s;
    //   118: invokeinterface getId : ()Ljava/lang/String;
    //   123: aload_0
    //   124: getfield lo : Lcom/google/android/gms/internal/s;
    //   127: iconst_1
    //   128: invokeinterface c : (Z)Z
    //   133: invokespecial <init> : (Ljava/lang/String;Z)V
    //   136: astore_1
    //   137: aload_0
    //   138: monitorexit
    //   139: aload_0
    //   140: invokespecial Z : ()V
    //   143: aload_1
    //   144: areturn
    //   145: astore_1
    //   146: ldc 'AdvertisingIdClient'
    //   148: ldc 'GMS remote exception '
    //   150: aload_1
    //   151: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   154: pop
    //   155: new java/io/IOException
    //   158: dup
    //   159: ldc 'Remote exception'
    //   161: invokespecial <init> : (Ljava/lang/String;)V
    //   164: athrow
    // Exception table:
    //   from	to	target	type
    //   7	21	53	finally
    //   21	38	48	finally
    //   38	48	48	finally
    //   49	51	48	finally
    //   51	53	53	finally
    //   54	56	53	finally
    //   58	60	48	finally
    //   60	65	82	java/lang/Exception
    //   60	65	53	finally
    //   65	82	53	finally
    //   83	94	53	finally
    //   94	110	53	finally
    //   110	137	145	android/os/RemoteException
    //   110	137	53	finally
    //   137	139	53	finally
    //   146	165	53	finally
  }
  
  public void start() throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    b(true);
  }
  
  public static final class Info {
    private final String lx;
    
    private final boolean ly;
    
    public Info(String param1String, boolean param1Boolean) {
      this.lx = param1String;
      this.ly = param1Boolean;
    }
    
    public String getId() {
      return this.lx;
    }
    
    public boolean isLimitAdTrackingEnabled() {
      return this.ly;
    }
    
    public String toString() {
      return "{" + this.lx + "}" + this.ly;
    }
  }
  
  static class a extends Thread {
    private WeakReference<AdvertisingIdClient> lt;
    
    private long lu;
    
    CountDownLatch lv;
    
    boolean lw;
    
    public a(AdvertisingIdClient param1AdvertisingIdClient, long param1Long) {
      this.lt = new WeakReference<AdvertisingIdClient>(param1AdvertisingIdClient);
      this.lu = param1Long;
      this.lv = new CountDownLatch(1);
      this.lw = false;
      start();
    }
    
    private void disconnect() {
      AdvertisingIdClient advertisingIdClient = this.lt.get();
      if (advertisingIdClient != null) {
        advertisingIdClient.finish();
        this.lw = true;
      } 
    }
    
    public boolean aa() {
      return this.lw;
    }
    
    public void cancel() {
      this.lv.countDown();
    }
    
    public void run() {
      try {
        if (!this.lv.await(this.lu, TimeUnit.MILLISECONDS))
          disconnect(); 
        return;
      } catch (InterruptedException interruptedException) {
        disconnect();
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\ads\identifier\AdvertisingIdClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */