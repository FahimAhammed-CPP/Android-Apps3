package com.google.android.gms.cast;

import android.text.TextUtils;
import com.google.android.gms.internal.in;
import com.google.android.gms.internal.jv;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaInfo {
  public static final int STREAM_TYPE_BUFFERED = 1;
  
  public static final int STREAM_TYPE_INVALID = -1;
  
  public static final int STREAM_TYPE_LIVE = 2;
  
  public static final int STREAM_TYPE_NONE = 0;
  
  public static final long UNKNOWN_DURATION = -1L;
  
  private final String FT;
  
  private int FU;
  
  private String FV;
  
  private MediaMetadata FW;
  
  private long FX;
  
  private List<MediaTrack> FY;
  
  private TextTrackStyle FZ;
  
  private JSONObject Ga;
  
  MediaInfo(String paramString) throws IllegalArgumentException {
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("content ID cannot be null or empty"); 
    this.FT = paramString;
    this.FU = -1;
  }
  
  MediaInfo(JSONObject paramJSONObject) throws JSONException {
    this.FT = paramJSONObject.getString("contentId");
    String str = paramJSONObject.getString("streamType");
    if ("NONE".equals(str)) {
      this.FU = 0;
    } else if ("BUFFERED".equals(str)) {
      this.FU = 1;
    } else if ("LIVE".equals(str)) {
      this.FU = 2;
    } else {
      this.FU = -1;
    } 
    this.FV = paramJSONObject.getString("contentType");
    if (paramJSONObject.has("metadata")) {
      JSONObject jSONObject = paramJSONObject.getJSONObject("metadata");
      this.FW = new MediaMetadata(jSONObject.getInt("metadataType"));
      this.FW.c(jSONObject);
    } 
    this.FX = -1L;
    if (paramJSONObject.has("duration") && !paramJSONObject.isNull("duration")) {
      double d = paramJSONObject.optDouble("duration", 0.0D);
      if (!Double.isNaN(d) && !Double.isInfinite(d))
        this.FX = in.b(d); 
    } 
    if (paramJSONObject.has("tracks")) {
      this.FY = new ArrayList<MediaTrack>();
      JSONArray jSONArray = paramJSONObject.getJSONArray("tracks");
      while (i < jSONArray.length()) {
        MediaTrack mediaTrack = new MediaTrack(jSONArray.getJSONObject(i));
        this.FY.add(mediaTrack);
        i++;
      } 
    } else {
      this.FY = null;
    } 
    if (paramJSONObject.has("textTrackStyle")) {
      JSONObject jSONObject = paramJSONObject.getJSONObject("textTrackStyle");
      TextTrackStyle textTrackStyle = new TextTrackStyle();
      textTrackStyle.c(jSONObject);
      this.FZ = textTrackStyle;
    } else {
      this.FZ = null;
    } 
    this.Ga = paramJSONObject.optJSONObject("customData");
  }
  
  void a(MediaMetadata paramMediaMetadata) {
    this.FW = paramMediaMetadata;
  }
  
  void d(List<MediaTrack> paramList) {
    this.FY = paramList;
  }
  
  public boolean equals(Object paramObject) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #5
    //   3: iconst_0
    //   4: istore #6
    //   6: aload_0
    //   7: aload_1
    //   8: if_acmpne -> 17
    //   11: iconst_1
    //   12: istore #4
    //   14: iload #4
    //   16: ireturn
    //   17: iload #6
    //   19: istore #4
    //   21: aload_1
    //   22: instanceof com/google/android/gms/cast/MediaInfo
    //   25: ifeq -> 14
    //   28: aload_1
    //   29: checkcast com/google/android/gms/cast/MediaInfo
    //   32: astore_1
    //   33: aload_0
    //   34: getfield Ga : Lorg/json/JSONObject;
    //   37: ifnonnull -> 164
    //   40: iconst_1
    //   41: istore_2
    //   42: aload_1
    //   43: getfield Ga : Lorg/json/JSONObject;
    //   46: ifnonnull -> 169
    //   49: iconst_1
    //   50: istore_3
    //   51: iload #6
    //   53: istore #4
    //   55: iload_2
    //   56: iload_3
    //   57: if_icmpne -> 14
    //   60: aload_0
    //   61: getfield Ga : Lorg/json/JSONObject;
    //   64: ifnull -> 92
    //   67: aload_1
    //   68: getfield Ga : Lorg/json/JSONObject;
    //   71: ifnull -> 92
    //   74: iload #6
    //   76: istore #4
    //   78: aload_0
    //   79: getfield Ga : Lorg/json/JSONObject;
    //   82: aload_1
    //   83: getfield Ga : Lorg/json/JSONObject;
    //   86: invokestatic d : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   89: ifeq -> 14
    //   92: aload_0
    //   93: getfield FT : Ljava/lang/String;
    //   96: aload_1
    //   97: getfield FT : Ljava/lang/String;
    //   100: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   103: ifeq -> 174
    //   106: aload_0
    //   107: getfield FU : I
    //   110: aload_1
    //   111: getfield FU : I
    //   114: if_icmpne -> 174
    //   117: aload_0
    //   118: getfield FV : Ljava/lang/String;
    //   121: aload_1
    //   122: getfield FV : Ljava/lang/String;
    //   125: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   128: ifeq -> 174
    //   131: aload_0
    //   132: getfield FW : Lcom/google/android/gms/cast/MediaMetadata;
    //   135: aload_1
    //   136: getfield FW : Lcom/google/android/gms/cast/MediaMetadata;
    //   139: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   142: ifeq -> 174
    //   145: aload_0
    //   146: getfield FX : J
    //   149: aload_1
    //   150: getfield FX : J
    //   153: lcmp
    //   154: ifne -> 174
    //   157: iload #5
    //   159: istore #4
    //   161: iload #4
    //   163: ireturn
    //   164: iconst_0
    //   165: istore_2
    //   166: goto -> 42
    //   169: iconst_0
    //   170: istore_3
    //   171: goto -> 51
    //   174: iconst_0
    //   175: istore #4
    //   177: goto -> 161
  }
  
  void fQ() throws IllegalArgumentException {
    if (TextUtils.isEmpty(this.FT))
      throw new IllegalArgumentException("content ID cannot be null or empty"); 
    if (TextUtils.isEmpty(this.FV))
      throw new IllegalArgumentException("content type cannot be null or empty"); 
    if (this.FU == -1)
      throw new IllegalArgumentException("a valid stream type must be specified"); 
  }
  
  public String getContentId() {
    return this.FT;
  }
  
  public String getContentType() {
    return this.FV;
  }
  
  public JSONObject getCustomData() {
    return this.Ga;
  }
  
  public List<MediaTrack> getMediaTracks() {
    return this.FY;
  }
  
  public MediaMetadata getMetadata() {
    return this.FW;
  }
  
  public long getStreamDuration() {
    return this.FX;
  }
  
  public int getStreamType() {
    return this.FU;
  }
  
  public TextTrackStyle getTextTrackStyle() {
    return this.FZ;
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { this.FT, Integer.valueOf(this.FU), this.FV, this.FW, Long.valueOf(this.FX), String.valueOf(this.Ga) });
  }
  
  void m(long paramLong) throws IllegalArgumentException {
    if (paramLong < 0L)
      throw new IllegalArgumentException("Stream duration cannot be negative"); 
    this.FX = paramLong;
  }
  
  void setContentType(String paramString) throws IllegalArgumentException {
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("content type cannot be null or empty"); 
    this.FV = paramString;
  }
  
  void setCustomData(JSONObject paramJSONObject) {
    this.Ga = paramJSONObject;
  }
  
  void setStreamType(int paramInt) throws IllegalArgumentException {
    if (paramInt < -1 || paramInt > 2)
      throw new IllegalArgumentException("invalid stream type"); 
    this.FU = paramInt;
  }
  
  public void setTextTrackStyle(TextTrackStyle paramTextTrackStyle) {
    this.FZ = paramTextTrackStyle;
  }
  
  public JSONObject toJson() {
    // Byte code:
    //   0: new org/json/JSONObject
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_2
    //   9: ldc 'contentId'
    //   11: aload_0
    //   12: getfield FT : Ljava/lang/String;
    //   15: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   18: pop
    //   19: aload_0
    //   20: getfield FU : I
    //   23: tableswitch default -> 208, 1 -> 217, 2 -> 223
    //   44: aload_2
    //   45: ldc 'streamType'
    //   47: aload_1
    //   48: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   51: pop
    //   52: aload_0
    //   53: getfield FV : Ljava/lang/String;
    //   56: ifnull -> 70
    //   59: aload_2
    //   60: ldc 'contentType'
    //   62: aload_0
    //   63: getfield FV : Ljava/lang/String;
    //   66: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   69: pop
    //   70: aload_0
    //   71: getfield FW : Lcom/google/android/gms/cast/MediaMetadata;
    //   74: ifnull -> 91
    //   77: aload_2
    //   78: ldc 'metadata'
    //   80: aload_0
    //   81: getfield FW : Lcom/google/android/gms/cast/MediaMetadata;
    //   84: invokevirtual toJson : ()Lorg/json/JSONObject;
    //   87: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   90: pop
    //   91: aload_2
    //   92: ldc 'duration'
    //   94: aload_0
    //   95: getfield FX : J
    //   98: invokestatic o : (J)D
    //   101: invokevirtual put : (Ljava/lang/String;D)Lorg/json/JSONObject;
    //   104: pop
    //   105: aload_0
    //   106: getfield FY : Ljava/util/List;
    //   109: ifnull -> 167
    //   112: new org/json/JSONArray
    //   115: dup
    //   116: invokespecial <init> : ()V
    //   119: astore_1
    //   120: aload_0
    //   121: getfield FY : Ljava/util/List;
    //   124: invokeinterface iterator : ()Ljava/util/Iterator;
    //   129: astore_3
    //   130: aload_3
    //   131: invokeinterface hasNext : ()Z
    //   136: ifeq -> 159
    //   139: aload_1
    //   140: aload_3
    //   141: invokeinterface next : ()Ljava/lang/Object;
    //   146: checkcast com/google/android/gms/cast/MediaTrack
    //   149: invokevirtual toJson : ()Lorg/json/JSONObject;
    //   152: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   155: pop
    //   156: goto -> 130
    //   159: aload_2
    //   160: ldc 'tracks'
    //   162: aload_1
    //   163: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   166: pop
    //   167: aload_0
    //   168: getfield FZ : Lcom/google/android/gms/cast/TextTrackStyle;
    //   171: ifnull -> 188
    //   174: aload_2
    //   175: ldc 'textTrackStyle'
    //   177: aload_0
    //   178: getfield FZ : Lcom/google/android/gms/cast/TextTrackStyle;
    //   181: invokevirtual toJson : ()Lorg/json/JSONObject;
    //   184: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   187: pop
    //   188: aload_0
    //   189: getfield Ga : Lorg/json/JSONObject;
    //   192: ifnull -> 215
    //   195: aload_2
    //   196: ldc 'customData'
    //   198: aload_0
    //   199: getfield Ga : Lorg/json/JSONObject;
    //   202: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   205: pop
    //   206: aload_2
    //   207: areturn
    //   208: ldc 'NONE'
    //   210: astore_1
    //   211: goto -> 44
    //   214: astore_1
    //   215: aload_2
    //   216: areturn
    //   217: ldc 'BUFFERED'
    //   219: astore_1
    //   220: goto -> 44
    //   223: ldc 'LIVE'
    //   225: astore_1
    //   226: goto -> 44
    // Exception table:
    //   from	to	target	type
    //   8	44	214	org/json/JSONException
    //   44	70	214	org/json/JSONException
    //   70	91	214	org/json/JSONException
    //   91	130	214	org/json/JSONException
    //   130	156	214	org/json/JSONException
    //   159	167	214	org/json/JSONException
    //   167	188	214	org/json/JSONException
    //   188	206	214	org/json/JSONException
  }
  
  public static class Builder {
    private final MediaInfo Gb;
    
    public Builder(String param1String) throws IllegalArgumentException {
      if (TextUtils.isEmpty(param1String))
        throw new IllegalArgumentException("Content ID cannot be empty"); 
      this.Gb = new MediaInfo(param1String);
    }
    
    public MediaInfo build() throws IllegalArgumentException {
      this.Gb.fQ();
      return this.Gb;
    }
    
    public Builder setContentType(String param1String) throws IllegalArgumentException {
      this.Gb.setContentType(param1String);
      return this;
    }
    
    public Builder setCustomData(JSONObject param1JSONObject) {
      this.Gb.setCustomData(param1JSONObject);
      return this;
    }
    
    public Builder setMediaTracks(List<MediaTrack> param1List) {
      this.Gb.d(param1List);
      return this;
    }
    
    public Builder setMetadata(MediaMetadata param1MediaMetadata) {
      this.Gb.a(param1MediaMetadata);
      return this;
    }
    
    public Builder setStreamDuration(long param1Long) throws IllegalArgumentException {
      this.Gb.m(param1Long);
      return this;
    }
    
    public Builder setStreamType(int param1Int) throws IllegalArgumentException {
      this.Gb.setStreamType(param1Int);
      return this;
    }
    
    public Builder setTextTrackStyle(TextTrackStyle param1TextTrackStyle) {
      this.Gb.setTextTrackStyle(param1TextTrackStyle);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\cast\MediaInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */