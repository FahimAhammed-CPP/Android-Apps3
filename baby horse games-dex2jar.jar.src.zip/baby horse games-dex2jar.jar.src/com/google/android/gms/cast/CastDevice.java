package com.google.android.gms.cast;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.in;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class CastDevice implements SafeParcelable {
  public static final Parcelable.Creator<CastDevice> CREATOR = new b();
  
  private final int CK;
  
  private String FG;
  
  String FH;
  
  private Inet4Address FI;
  
  private String FJ;
  
  private String FK;
  
  private String FL;
  
  private int FM;
  
  private List<WebImage> FN;
  
  private int FO;
  
  private int FP;
  
  private CastDevice() {
    this(3, null, null, null, null, null, -1, new ArrayList<WebImage>(), 0, -1);
  }
  
  CastDevice(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt2, List<WebImage> paramList, int paramInt3, int paramInt4) {
    this.CK = paramInt1;
    this.FG = paramString1;
    this.FH = paramString2;
    if (this.FH != null)
      try {
        InetAddress inetAddress = InetAddress.getByName(this.FH);
        if (inetAddress instanceof Inet4Address)
          this.FI = (Inet4Address)inetAddress; 
      } catch (UnknownHostException unknownHostException) {
        this.FI = null;
      }  
    this.FJ = paramString3;
    this.FK = paramString4;
    this.FL = paramString5;
    this.FM = paramInt2;
    this.FN = paramList;
    this.FO = paramInt3;
    this.FP = paramInt4;
  }
  
  public static CastDevice getFromBundle(Bundle paramBundle) {
    if (paramBundle == null)
      return null; 
    paramBundle.setClassLoader(CastDevice.class.getClassLoader());
    return (CastDevice)paramBundle.getParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE");
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (!(paramObject instanceof CastDevice))
        return false; 
      paramObject = paramObject;
      if (getDeviceId() == null)
        return !(paramObject.getDeviceId() != null); 
      if (!in.a(this.FG, ((CastDevice)paramObject).FG) || !in.a(this.FI, ((CastDevice)paramObject).FI) || !in.a(this.FK, ((CastDevice)paramObject).FK) || !in.a(this.FJ, ((CastDevice)paramObject).FJ) || !in.a(this.FL, ((CastDevice)paramObject).FL) || this.FM != ((CastDevice)paramObject).FM || !in.a(this.FN, ((CastDevice)paramObject).FN) || this.FO != ((CastDevice)paramObject).FO || this.FP != ((CastDevice)paramObject).FP)
        return false; 
    } 
    return true;
  }
  
  public int getCapabilities() {
    return this.FO;
  }
  
  public String getDeviceId() {
    return this.FG;
  }
  
  public String getDeviceVersion() {
    return this.FL;
  }
  
  public String getFriendlyName() {
    return this.FJ;
  }
  
  public WebImage getIcon(int paramInt1, int paramInt2) {
    WebImage webImage1 = null;
    if (this.FN.isEmpty())
      return null; 
    if (paramInt1 <= 0 || paramInt2 <= 0)
      return this.FN.get(0); 
    Iterator<WebImage> iterator = this.FN.iterator();
    WebImage webImage2 = null;
    while (iterator.hasNext()) {
      WebImage webImage = iterator.next();
      int i = webImage.getWidth();
      int j = webImage.getHeight();
      if (i >= paramInt1 && j >= paramInt2) {
        if (webImage2 == null || (webImage2.getWidth() > i && webImage2.getHeight() > j))
          webImage2 = webImage; 
        continue;
      } 
      if (i < paramInt1 && j < paramInt2 && (webImage1 == null || (webImage1.getWidth() < i && webImage1.getHeight() < j)))
        webImage1 = webImage; 
    } 
    if (webImage2 == null) {
      if (webImage1 != null)
        return webImage1; 
      webImage2 = this.FN.get(0);
    } 
    return webImage2;
  }
  
  public List<WebImage> getIcons() {
    return Collections.unmodifiableList(this.FN);
  }
  
  public Inet4Address getIpAddress() {
    return this.FI;
  }
  
  public String getModelName() {
    return this.FK;
  }
  
  public int getServicePort() {
    return this.FM;
  }
  
  public int getStatus() {
    return this.FP;
  }
  
  int getVersionCode() {
    return this.CK;
  }
  
  public boolean hasIcons() {
    return !this.FN.isEmpty();
  }
  
  public int hashCode() {
    return (this.FG == null) ? 0 : this.FG.hashCode();
  }
  
  public boolean isOnLocalNetwork() {
    return !this.FG.startsWith("__cast_nearby__");
  }
  
  public boolean isSameDevice(CastDevice paramCastDevice) {
    return (paramCastDevice != null) ? ((getDeviceId() == null) ? ((paramCastDevice.getDeviceId() == null)) : in.a(getDeviceId(), paramCastDevice.getDeviceId())) : false;
  }
  
  public void putInBundle(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    paramBundle.putParcelable("com.google.android.gms.cast.EXTRA_CAST_DEVICE", (Parcelable)this);
  }
  
  public String toString() {
    return String.format("\"%s\" (%s)", new Object[] { this.FJ, this.FG });
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\cast\CastDevice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */