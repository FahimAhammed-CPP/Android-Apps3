package com.google.android.gms.cast;

import android.content.Context;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.im;
import com.google.android.gms.internal.jg;
import com.google.android.gms.internal.jx;
import java.io.IOException;

public final class Cast {
  public static final Api<CastOptions> API;
  
  public static final CastApi CastApi;
  
  static final Api.c<im> DQ = new Api.c();
  
  private static final Api.b<im, CastOptions> DR = new Api.b<im, CastOptions>() {
      public im a(Context param1Context, Looper param1Looper, jg param1jg, Cast.CastOptions param1CastOptions, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
        jx.b(param1CastOptions, "Setting the API options is required.");
        return new im(param1Context, param1Looper, param1CastOptions.Fz, Cast.CastOptions.a(param1CastOptions), param1CastOptions.FA, param1ConnectionCallbacks, param1OnConnectionFailedListener);
      }
      
      public int getPriority() {
        return Integer.MAX_VALUE;
      }
    };
  
  public static final String EXTRA_APP_NO_LONGER_RUNNING = "com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING";
  
  public static final int MAX_MESSAGE_LENGTH = 65536;
  
  public static final int MAX_NAMESPACE_LENGTH = 128;
  
  static {
    API = new Api(DR, DQ, new com.google.android.gms.common.api.Scope[0]);
    CastApi = new CastApi.a();
  }
  
  public static interface ApplicationConnectionResult extends Result {
    ApplicationMetadata getApplicationMetadata();
    
    String getApplicationStatus();
    
    String getSessionId();
    
    boolean getWasLaunched();
  }
  
  public static interface CastApi {
    ApplicationMetadata getApplicationMetadata(GoogleApiClient param1GoogleApiClient) throws IllegalStateException;
    
    String getApplicationStatus(GoogleApiClient param1GoogleApiClient) throws IllegalStateException;
    
    double getVolume(GoogleApiClient param1GoogleApiClient) throws IllegalStateException;
    
    boolean isMute(GoogleApiClient param1GoogleApiClient) throws IllegalStateException;
    
    PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient);
    
    PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient, String param1String);
    
    PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2);
    
    PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String);
    
    PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String, LaunchOptions param1LaunchOptions);
    
    @Deprecated
    PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String, boolean param1Boolean);
    
    PendingResult<Status> leaveApplication(GoogleApiClient param1GoogleApiClient);
    
    void removeMessageReceivedCallbacks(GoogleApiClient param1GoogleApiClient, String param1String) throws IOException, IllegalArgumentException;
    
    void requestStatus(GoogleApiClient param1GoogleApiClient) throws IOException, IllegalStateException;
    
    PendingResult<Status> sendMessage(GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2);
    
    void setMessageReceivedCallbacks(GoogleApiClient param1GoogleApiClient, String param1String, Cast.MessageReceivedCallback param1MessageReceivedCallback) throws IOException, IllegalStateException;
    
    void setMute(GoogleApiClient param1GoogleApiClient, boolean param1Boolean) throws IOException, IllegalStateException;
    
    void setVolume(GoogleApiClient param1GoogleApiClient, double param1Double) throws IOException, IllegalArgumentException, IllegalStateException;
    
    PendingResult<Status> stopApplication(GoogleApiClient param1GoogleApiClient);
    
    PendingResult<Status> stopApplication(GoogleApiClient param1GoogleApiClient, String param1String);
    
    public static final class a implements CastApi {
      public ApplicationMetadata getApplicationMetadata(GoogleApiClient param2GoogleApiClient) throws IllegalStateException {
        return ((im)param2GoogleApiClient.a(Cast.DQ)).getApplicationMetadata();
      }
      
      public String getApplicationStatus(GoogleApiClient param2GoogleApiClient) throws IllegalStateException {
        return ((im)param2GoogleApiClient.a(Cast.DQ)).getApplicationStatus();
      }
      
      public double getVolume(GoogleApiClient param2GoogleApiClient) throws IllegalStateException {
        return ((im)param2GoogleApiClient.a(Cast.DQ)).fZ();
      }
      
      public boolean isMute(GoogleApiClient param2GoogleApiClient) throws IllegalStateException {
        return ((im)param2GoogleApiClient.a(Cast.DQ)).isMute();
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param2GoogleApiClient) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2GoogleApiClient) {
              protected void a(im param3im) throws RemoteException {
                try {
                  param3im.b(null, null, (BaseImplementation.b)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param2GoogleApiClient, String param2String) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2GoogleApiClient, param2String) {
              protected void a(im param3im) throws RemoteException {
                try {
                  param3im.b(this.Fw, null, (BaseImplementation.b)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param2GoogleApiClient, String param2String1, String param2String2) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2GoogleApiClient, param2String1, param2String2) {
              protected void a(im param3im) throws RemoteException {
                try {
                  param3im.b(this.Fw, this.Fy, (BaseImplementation.b)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param2GoogleApiClient, String param2String) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2GoogleApiClient, param2String) {
              protected void a(im param3im) throws RemoteException {
                try {
                  param3im.a(this.Fw, false, (BaseImplementation.b)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param2GoogleApiClient, String param2String, LaunchOptions param2LaunchOptions) {
        return (PendingResult<Cast.ApplicationConnectionResult>)param2GoogleApiClient.b(new Cast.c(this, param2GoogleApiClient, param2String, param2LaunchOptions) {
              protected void a(im param3im) throws RemoteException {
                try {
                  param3im.a(this.Fw, this.Fx, (BaseImplementation.b)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
      
      @Deprecated
      public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param2GoogleApiClient, String param2String, boolean param2Boolean) {
        return launchApplication(param2GoogleApiClient, param2String, (new LaunchOptions.Builder()).setRelaunchIfRunning(param2Boolean).build());
      }
      
      public PendingResult<Status> leaveApplication(GoogleApiClient param2GoogleApiClient) {
        return (PendingResult<Status>)param2GoogleApiClient.b(new Cast.b(this, param2GoogleApiClient) {
              protected void a(im param3im) throws RemoteException {
                try {
                  param3im.d((BaseImplementation.b)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
      
      public void removeMessageReceivedCallbacks(GoogleApiClient param2GoogleApiClient, String param2String) throws IOException, IllegalArgumentException {
        try {
          ((im)param2GoogleApiClient.a(Cast.DQ)).aE(param2String);
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public void requestStatus(GoogleApiClient param2GoogleApiClient) throws IOException, IllegalStateException {
        try {
          ((im)param2GoogleApiClient.a(Cast.DQ)).fY();
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public PendingResult<Status> sendMessage(GoogleApiClient param2GoogleApiClient, String param2String1, String param2String2) {
        return (PendingResult<Status>)param2GoogleApiClient.b(new Cast.b(this, param2GoogleApiClient, param2String1, param2String2) {
              protected void a(im param3im) throws RemoteException {
                try {
                  param3im.a(this.Ft, this.Fu, (BaseImplementation.b)this);
                  return;
                } catch (IllegalArgumentException illegalArgumentException) {
                  W(2001);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
      
      public void setMessageReceivedCallbacks(GoogleApiClient param2GoogleApiClient, String param2String, Cast.MessageReceivedCallback param2MessageReceivedCallback) throws IOException, IllegalStateException {
        try {
          ((im)param2GoogleApiClient.a(Cast.DQ)).a(param2String, param2MessageReceivedCallback);
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public void setMute(GoogleApiClient param2GoogleApiClient, boolean param2Boolean) throws IOException, IllegalStateException {
        try {
          ((im)param2GoogleApiClient.a(Cast.DQ)).I(param2Boolean);
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public void setVolume(GoogleApiClient param2GoogleApiClient, double param2Double) throws IOException, IllegalArgumentException, IllegalStateException {
        try {
          ((im)param2GoogleApiClient.a(Cast.DQ)).a(param2Double);
          return;
        } catch (RemoteException remoteException) {
          throw new IOException("service error");
        } 
      }
      
      public PendingResult<Status> stopApplication(GoogleApiClient param2GoogleApiClient) {
        return (PendingResult<Status>)param2GoogleApiClient.b(new Cast.b(this, param2GoogleApiClient) {
              protected void a(im param3im) throws RemoteException {
                try {
                  param3im.a("", (BaseImplementation.b)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
      
      public PendingResult<Status> stopApplication(GoogleApiClient param2GoogleApiClient, String param2String) {
        return (PendingResult<Status>)param2GoogleApiClient.b(new Cast.b(this, param2GoogleApiClient, param2String) {
              protected void a(im param3im) throws RemoteException {
                if (TextUtils.isEmpty(this.Fy)) {
                  e(2001, "IllegalArgument: sessionId cannot be null or empty");
                  return;
                } 
                try {
                  param3im.a(this.Fy, (BaseImplementation.b)this);
                  return;
                } catch (IllegalStateException illegalStateException) {
                  W(2001);
                  return;
                } 
              }
            });
      }
    }
    
    class null extends Cast.b {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient, String param2String1, String param2String2) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        try {
          param2im.a(this.Ft, this.Fu, (BaseImplementation.b)this);
          return;
        } catch (IllegalArgumentException illegalArgumentException) {
          W(2001);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient, String param2String) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        try {
          param2im.a(this.Fw, false, (BaseImplementation.b)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient, String param2String, LaunchOptions param2LaunchOptions) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        try {
          param2im.a(this.Fw, this.Fx, (BaseImplementation.b)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient, String param2String1, String param2String2) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        try {
          param2im.b(this.Fw, this.Fy, (BaseImplementation.b)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient, String param2String) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        try {
          param2im.b(this.Fw, null, (BaseImplementation.b)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
    
    class null extends Cast.c {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        try {
          param2im.b(null, null, (BaseImplementation.b)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
    
    class null extends Cast.b {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        try {
          param2im.d((BaseImplementation.b)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
    
    class null extends Cast.b {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        try {
          param2im.a("", (BaseImplementation.b)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
    
    class null extends Cast.b {
      null(Cast.CastApi this$0, GoogleApiClient param2GoogleApiClient, String param2String) {
        super(param2GoogleApiClient);
      }
      
      protected void a(im param2im) throws RemoteException {
        if (TextUtils.isEmpty(this.Fy)) {
          e(2001, "IllegalArgument: sessionId cannot be null or empty");
          return;
        } 
        try {
          param2im.a(this.Fy, (BaseImplementation.b)this);
          return;
        } catch (IllegalStateException illegalStateException) {
          W(2001);
          return;
        } 
      }
    }
  }
  
  public static final class a implements CastApi {
    public ApplicationMetadata getApplicationMetadata(GoogleApiClient param1GoogleApiClient) throws IllegalStateException {
      return ((im)param1GoogleApiClient.a(Cast.DQ)).getApplicationMetadata();
    }
    
    public String getApplicationStatus(GoogleApiClient param1GoogleApiClient) throws IllegalStateException {
      return ((im)param1GoogleApiClient.a(Cast.DQ)).getApplicationStatus();
    }
    
    public double getVolume(GoogleApiClient param1GoogleApiClient) throws IllegalStateException {
      return ((im)param1GoogleApiClient.a(Cast.DQ)).fZ();
    }
    
    public boolean isMute(GoogleApiClient param1GoogleApiClient) throws IllegalStateException {
      return ((im)param1GoogleApiClient.a(Cast.DQ)).isMute();
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1GoogleApiClient) {
            protected void a(im param3im) throws RemoteException {
              try {
                param3im.b(null, null, (BaseImplementation.b)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient, String param1String) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1GoogleApiClient, param1String) {
            protected void a(im param3im) throws RemoteException {
              try {
                param3im.b(this.Fw, null, (BaseImplementation.b)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> joinApplication(GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1GoogleApiClient, param1String1, param1String2) {
            protected void a(im param3im) throws RemoteException {
              try {
                param3im.b(this.Fw, this.Fy, (BaseImplementation.b)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1GoogleApiClient, param1String) {
            protected void a(im param3im) throws RemoteException {
              try {
                param3im.a(this.Fw, false, (BaseImplementation.b)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String, LaunchOptions param1LaunchOptions) {
      return (PendingResult<Cast.ApplicationConnectionResult>)param1GoogleApiClient.b(new Cast.c(this, param1GoogleApiClient, param1String, param1LaunchOptions) {
            protected void a(im param3im) throws RemoteException {
              try {
                param3im.a(this.Fw, this.Fx, (BaseImplementation.b)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
    
    @Deprecated
    public PendingResult<Cast.ApplicationConnectionResult> launchApplication(GoogleApiClient param1GoogleApiClient, String param1String, boolean param1Boolean) {
      return launchApplication(param1GoogleApiClient, param1String, (new LaunchOptions.Builder()).setRelaunchIfRunning(param1Boolean).build());
    }
    
    public PendingResult<Status> leaveApplication(GoogleApiClient param1GoogleApiClient) {
      return (PendingResult<Status>)param1GoogleApiClient.b(new Cast.b(this, param1GoogleApiClient) {
            protected void a(im param3im) throws RemoteException {
              try {
                param3im.d((BaseImplementation.b)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
    
    public void removeMessageReceivedCallbacks(GoogleApiClient param1GoogleApiClient, String param1String) throws IOException, IllegalArgumentException {
      try {
        ((im)param1GoogleApiClient.a(Cast.DQ)).aE(param1String);
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public void requestStatus(GoogleApiClient param1GoogleApiClient) throws IOException, IllegalStateException {
      try {
        ((im)param1GoogleApiClient.a(Cast.DQ)).fY();
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public PendingResult<Status> sendMessage(GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2) {
      return (PendingResult<Status>)param1GoogleApiClient.b(new Cast.b(this, param1GoogleApiClient, param1String1, param1String2) {
            protected void a(im param3im) throws RemoteException {
              try {
                param3im.a(this.Ft, this.Fu, (BaseImplementation.b)this);
                return;
              } catch (IllegalArgumentException illegalArgumentException) {
                W(2001);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
    
    public void setMessageReceivedCallbacks(GoogleApiClient param1GoogleApiClient, String param1String, Cast.MessageReceivedCallback param1MessageReceivedCallback) throws IOException, IllegalStateException {
      try {
        ((im)param1GoogleApiClient.a(Cast.DQ)).a(param1String, param1MessageReceivedCallback);
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public void setMute(GoogleApiClient param1GoogleApiClient, boolean param1Boolean) throws IOException, IllegalStateException {
      try {
        ((im)param1GoogleApiClient.a(Cast.DQ)).I(param1Boolean);
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public void setVolume(GoogleApiClient param1GoogleApiClient, double param1Double) throws IOException, IllegalArgumentException, IllegalStateException {
      try {
        ((im)param1GoogleApiClient.a(Cast.DQ)).a(param1Double);
        return;
      } catch (RemoteException remoteException) {
        throw new IOException("service error");
      } 
    }
    
    public PendingResult<Status> stopApplication(GoogleApiClient param1GoogleApiClient) {
      return (PendingResult<Status>)param1GoogleApiClient.b(new Cast.b(this, param1GoogleApiClient) {
            protected void a(im param3im) throws RemoteException {
              try {
                param3im.a("", (BaseImplementation.b)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
    
    public PendingResult<Status> stopApplication(GoogleApiClient param1GoogleApiClient, String param1String) {
      return (PendingResult<Status>)param1GoogleApiClient.b(new Cast.b(this, param1GoogleApiClient, param1String) {
            protected void a(im param3im) throws RemoteException {
              if (TextUtils.isEmpty(this.Fy)) {
                e(2001, "IllegalArgument: sessionId cannot be null or empty");
                return;
              } 
              try {
                param3im.a(this.Fy, (BaseImplementation.b)this);
                return;
              } catch (IllegalStateException illegalStateException) {
                W(2001);
                return;
              } 
            }
          });
    }
  }
  
  class null extends b {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      try {
        param1im.a(this.Ft, this.Fu, (BaseImplementation.b)this);
        return;
      } catch (IllegalArgumentException illegalArgumentException) {
        W(2001);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient, String param1String) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      try {
        param1im.a(this.Fw, false, (BaseImplementation.b)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient, String param1String, LaunchOptions param1LaunchOptions) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      try {
        param1im.a(this.Fw, this.Fx, (BaseImplementation.b)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient, String param1String1, String param1String2) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      try {
        param1im.b(this.Fw, this.Fy, (BaseImplementation.b)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient, String param1String) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      try {
        param1im.b(this.Fw, null, (BaseImplementation.b)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  class null extends c {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      try {
        param1im.b(null, null, (BaseImplementation.b)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  class null extends b {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      try {
        param1im.d((BaseImplementation.b)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  class null extends b {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      try {
        param1im.a("", (BaseImplementation.b)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  class null extends b {
    null(Cast this$0, GoogleApiClient param1GoogleApiClient, String param1String) {
      super(param1GoogleApiClient);
    }
    
    protected void a(im param1im) throws RemoteException {
      if (TextUtils.isEmpty(this.Fy)) {
        e(2001, "IllegalArgument: sessionId cannot be null or empty");
        return;
      } 
      try {
        param1im.a(this.Fy, (BaseImplementation.b)this);
        return;
      } catch (IllegalStateException illegalStateException) {
        W(2001);
        return;
      } 
    }
  }
  
  public static final class CastOptions implements Api.ApiOptions.HasOptions {
    final Cast.Listener FA;
    
    private final int FB;
    
    final CastDevice Fz;
    
    private CastOptions(Builder param1Builder) {
      this.Fz = param1Builder.FC;
      this.FA = param1Builder.FD;
      this.FB = Builder.a(param1Builder);
    }
    
    public static Builder builder(CastDevice param1CastDevice, Cast.Listener param1Listener) {
      return new Builder(param1CastDevice, param1Listener);
    }
    
    public static final class Builder {
      CastDevice FC;
      
      Cast.Listener FD;
      
      private int FE;
      
      private Builder(CastDevice param2CastDevice, Cast.Listener param2Listener) {
        jx.b(param2CastDevice, "CastDevice parameter cannot be null");
        jx.b(param2Listener, "CastListener parameter cannot be null");
        this.FC = param2CastDevice;
        this.FD = param2Listener;
        this.FE = 0;
      }
      
      public Cast.CastOptions build() {
        return new Cast.CastOptions(this);
      }
      
      public Builder setVerboseLoggingEnabled(boolean param2Boolean) {
        if (param2Boolean) {
          this.FE |= 0x1;
          return this;
        } 
        this.FE &= 0xFFFFFFFE;
        return this;
      }
    }
  }
  
  public static final class Builder {
    CastDevice FC;
    
    Cast.Listener FD;
    
    private int FE;
    
    private Builder(CastDevice param1CastDevice, Cast.Listener param1Listener) {
      jx.b(param1CastDevice, "CastDevice parameter cannot be null");
      jx.b(param1Listener, "CastListener parameter cannot be null");
      this.FC = param1CastDevice;
      this.FD = param1Listener;
      this.FE = 0;
    }
    
    public Cast.CastOptions build() {
      return new Cast.CastOptions(this);
    }
    
    public Builder setVerboseLoggingEnabled(boolean param1Boolean) {
      if (param1Boolean) {
        this.FE |= 0x1;
        return this;
      } 
      this.FE &= 0xFFFFFFFE;
      return this;
    }
  }
  
  public static class Listener {
    public void X(int param1Int) {}
    
    public void Y(int param1Int) {}
    
    public void onApplicationDisconnected(int param1Int) {}
    
    public void onApplicationMetadataChanged(ApplicationMetadata param1ApplicationMetadata) {}
    
    public void onApplicationStatusChanged() {}
    
    public void onVolumeChanged() {}
  }
  
  public static interface MessageReceivedCallback {
    void onMessageReceived(CastDevice param1CastDevice, String param1String1, String param1String2);
  }
  
  protected static abstract class a<R extends Result> extends BaseImplementation.a<R, im> {
    public a(GoogleApiClient param1GoogleApiClient) {
      super(Cast.DQ, param1GoogleApiClient);
    }
    
    public void W(int param1Int) {
      b(c(new Status(param1Int)));
    }
    
    public void e(int param1Int, String param1String) {
      b(c(new Status(param1Int, param1String, null)));
    }
  }
  
  private static abstract class b extends a<Status> {
    b(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public Status b(Status param1Status) {
      return param1Status;
    }
  }
  
  private static abstract class c extends a<ApplicationConnectionResult> {
    public c(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public Cast.ApplicationConnectionResult i(Status param1Status) {
      return new Cast.ApplicationConnectionResult(this, param1Status) {
          public ApplicationMetadata getApplicationMetadata() {
            return null;
          }
          
          public String getApplicationStatus() {
            return null;
          }
          
          public String getSessionId() {
            return null;
          }
          
          public Status getStatus() {
            return this.DS;
          }
          
          public boolean getWasLaunched() {
            return false;
          }
        };
    }
  }
  
  class null implements ApplicationConnectionResult {
    null(Cast this$0, Status param1Status) {}
    
    public ApplicationMetadata getApplicationMetadata() {
      return null;
    }
    
    public String getApplicationStatus() {
      return null;
    }
    
    public String getSessionId() {
      return null;
    }
    
    public Status getStatus() {
      return this.DS;
    }
    
    public boolean getWasLaunched() {
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\cast\Cast.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */