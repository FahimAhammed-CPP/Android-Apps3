package com.google.android.gms.analytics;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

interface f {
  void dQ();
  
  void dW();
  
  LinkedBlockingQueue<Runnable> dX();
  
  void dY();
  
  void dispatch();
  
  Thread getThread();
  
  void u(Map<String, String> paramMap);
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */