package com.google.android.gms.analytics;

import android.content.Context;
import android.os.Handler;
import android.os.Message;

class v extends aj {
  private static final Object yT = new Object();
  
  private static v zf;
  
  private Context mContext;
  
  private Handler mHandler;
  
  private d yU;
  
  private volatile f yV;
  
  private int yW = 1800;
  
  private boolean yX = true;
  
  private boolean yY;
  
  private String yZ;
  
  private boolean yt = false;
  
  private boolean za = true;
  
  private boolean zb = true;
  
  private e zc = new e(this) {
      public void B(boolean param1Boolean) {
        this.zg.a(param1Boolean, v.a(this.zg));
      }
    };
  
  private u zd;
  
  private boolean ze = false;
  
  public static v eu() {
    if (zf == null)
      zf = new v(); 
    return zf;
  }
  
  private void ev() {
    this.zd = new u(this);
    this.zd.z(this.mContext);
  }
  
  private void ew() {
    this.mHandler = new Handler(this.mContext.getMainLooper(), new Handler.Callback(this) {
          public boolean handleMessage(Message param1Message) {
            if (1 == param1Message.what && v.ez().equals(param1Message.obj)) {
              y.eK().D(true);
              this.zg.dispatchLocalHits();
              y.eK().D(false);
              if (v.b(this.zg) > 0 && !v.c(this.zg))
                v.d(this.zg).sendMessageDelayed(v.d(this.zg).obtainMessage(1, v.ez()), (v.b(this.zg) * 1000)); 
            } 
            return true;
          }
        });
    if (this.yW > 0)
      this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(1, yT), (this.yW * 1000)); 
  }
  
  void C(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield ze : Z
    //   7: iload_1
    //   8: invokevirtual a : (ZZ)V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  void a(Context paramContext, f paramf) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mContext : Landroid/content/Context;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: aload_1
    //   16: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   19: putfield mContext : Landroid/content/Context;
    //   22: aload_0
    //   23: getfield yV : Lcom/google/android/gms/analytics/f;
    //   26: ifnonnull -> 11
    //   29: aload_0
    //   30: aload_2
    //   31: putfield yV : Lcom/google/android/gms/analytics/f;
    //   34: aload_0
    //   35: getfield yX : Z
    //   38: ifeq -> 50
    //   41: aload_0
    //   42: invokevirtual dispatchLocalHits : ()V
    //   45: aload_0
    //   46: iconst_0
    //   47: putfield yX : Z
    //   50: aload_0
    //   51: getfield yY : Z
    //   54: ifeq -> 11
    //   57: aload_0
    //   58: invokevirtual dW : ()V
    //   61: aload_0
    //   62: iconst_0
    //   63: putfield yY : Z
    //   66: goto -> 11
    //   69: astore_1
    //   70: aload_0
    //   71: monitorexit
    //   72: aload_1
    //   73: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	69	finally
    //   14	50	69	finally
    //   50	66	69	finally
  }
  
  void a(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ze : Z
    //   6: iload_1
    //   7: if_icmpne -> 23
    //   10: aload_0
    //   11: getfield za : Z
    //   14: istore_3
    //   15: iload_3
    //   16: iload_2
    //   17: if_icmpne -> 23
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: iload_1
    //   24: ifne -> 31
    //   27: iload_2
    //   28: ifne -> 49
    //   31: aload_0
    //   32: getfield yW : I
    //   35: ifle -> 49
    //   38: aload_0
    //   39: getfield mHandler : Landroid/os/Handler;
    //   42: iconst_1
    //   43: getstatic com/google/android/gms/analytics/v.yT : Ljava/lang/Object;
    //   46: invokevirtual removeMessages : (ILjava/lang/Object;)V
    //   49: iload_1
    //   50: ifne -> 92
    //   53: iload_2
    //   54: ifeq -> 92
    //   57: aload_0
    //   58: getfield yW : I
    //   61: ifle -> 92
    //   64: aload_0
    //   65: getfield mHandler : Landroid/os/Handler;
    //   68: aload_0
    //   69: getfield mHandler : Landroid/os/Handler;
    //   72: iconst_1
    //   73: getstatic com/google/android/gms/analytics/v.yT : Ljava/lang/Object;
    //   76: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   79: aload_0
    //   80: getfield yW : I
    //   83: sipush #1000
    //   86: imul
    //   87: i2l
    //   88: invokevirtual sendMessageDelayed : (Landroid/os/Message;J)Z
    //   91: pop
    //   92: new java/lang/StringBuilder
    //   95: dup
    //   96: invokespecial <init> : ()V
    //   99: ldc 'PowerSaveMode '
    //   101: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: astore #5
    //   106: iload_1
    //   107: ifne -> 157
    //   110: iload_2
    //   111: ifne -> 150
    //   114: goto -> 157
    //   117: aload #5
    //   119: aload #4
    //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: invokevirtual toString : ()Ljava/lang/String;
    //   127: invokestatic V : (Ljava/lang/String;)V
    //   130: aload_0
    //   131: iload_1
    //   132: putfield ze : Z
    //   135: aload_0
    //   136: iload_2
    //   137: putfield za : Z
    //   140: goto -> 20
    //   143: astore #4
    //   145: aload_0
    //   146: monitorexit
    //   147: aload #4
    //   149: athrow
    //   150: ldc 'terminated.'
    //   152: astore #4
    //   154: goto -> 117
    //   157: ldc 'initiated.'
    //   159: astore #4
    //   161: goto -> 117
    // Exception table:
    //   from	to	target	type
    //   2	15	143	finally
    //   31	49	143	finally
    //   57	92	143	finally
    //   92	106	143	finally
    //   117	140	143	finally
  }
  
  void dW() {
    if (this.yV == null) {
      ae.V("setForceLocalDispatch() queued. It will be called once initialization is complete.");
      this.yY = true;
      return;
    } 
    y.eK().a(y.a.Bb);
    this.yV.dW();
  }
  
  void dispatchLocalHits() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield yV : Lcom/google/android/gms/analytics/f;
    //   6: ifnonnull -> 22
    //   9: ldc 'Dispatch call queued. Dispatch will run once initialization is complete.'
    //   11: invokestatic V : (Ljava/lang/String;)V
    //   14: aload_0
    //   15: iconst_1
    //   16: putfield yX : Z
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: invokestatic eK : ()Lcom/google/android/gms/analytics/y;
    //   25: getstatic com/google/android/gms/analytics/y$a.AO : Lcom/google/android/gms/analytics/y$a;
    //   28: invokevirtual a : (Lcom/google/android/gms/analytics/y$a;)V
    //   31: aload_0
    //   32: getfield yV : Lcom/google/android/gms/analytics/f;
    //   35: invokeinterface dispatch : ()V
    //   40: goto -> 19
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	43	finally
    //   22	40	43	finally
  }
  
  d ex() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield yU : Lcom/google/android/gms/analytics/d;
    //   6: ifnonnull -> 100
    //   9: aload_0
    //   10: getfield mContext : Landroid/content/Context;
    //   13: ifnonnull -> 31
    //   16: new java/lang/IllegalStateException
    //   19: dup
    //   20: ldc 'Cant get a store unless we have a context'
    //   22: invokespecial <init> : (Ljava/lang/String;)V
    //   25: athrow
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    //   31: aload_0
    //   32: new com/google/android/gms/analytics/ag
    //   35: dup
    //   36: aload_0
    //   37: getfield zc : Lcom/google/android/gms/analytics/e;
    //   40: aload_0
    //   41: getfield mContext : Landroid/content/Context;
    //   44: new com/google/android/gms/analytics/j
    //   47: dup
    //   48: invokespecial <init> : ()V
    //   51: invokespecial <init> : (Lcom/google/android/gms/analytics/e;Landroid/content/Context;Lcom/google/android/gms/analytics/o;)V
    //   54: putfield yU : Lcom/google/android/gms/analytics/d;
    //   57: aload_0
    //   58: getfield yU : Lcom/google/android/gms/analytics/d;
    //   61: aload_0
    //   62: getfield yt : Z
    //   65: invokeinterface setDryRun : (Z)V
    //   70: aload_0
    //   71: getfield yZ : Ljava/lang/String;
    //   74: ifnull -> 100
    //   77: aload_0
    //   78: getfield yU : Lcom/google/android/gms/analytics/d;
    //   81: invokeinterface dV : ()Lcom/google/android/gms/analytics/r;
    //   86: aload_0
    //   87: getfield yZ : Ljava/lang/String;
    //   90: invokeinterface ad : (Ljava/lang/String;)V
    //   95: aload_0
    //   96: aconst_null
    //   97: putfield yZ : Ljava/lang/String;
    //   100: aload_0
    //   101: getfield mHandler : Landroid/os/Handler;
    //   104: ifnonnull -> 111
    //   107: aload_0
    //   108: invokespecial ew : ()V
    //   111: aload_0
    //   112: getfield zd : Lcom/google/android/gms/analytics/u;
    //   115: ifnonnull -> 129
    //   118: aload_0
    //   119: getfield zb : Z
    //   122: ifeq -> 129
    //   125: aload_0
    //   126: invokespecial ev : ()V
    //   129: aload_0
    //   130: getfield yU : Lcom/google/android/gms/analytics/d;
    //   133: astore_1
    //   134: aload_0
    //   135: monitorexit
    //   136: aload_1
    //   137: areturn
    // Exception table:
    //   from	to	target	type
    //   2	26	26	finally
    //   31	100	26	finally
    //   100	111	26	finally
    //   111	129	26	finally
    //   129	134	26	finally
  }
  
  void ey() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ze : Z
    //   6: ifne -> 53
    //   9: aload_0
    //   10: getfield za : Z
    //   13: ifeq -> 53
    //   16: aload_0
    //   17: getfield yW : I
    //   20: ifle -> 53
    //   23: aload_0
    //   24: getfield mHandler : Landroid/os/Handler;
    //   27: iconst_1
    //   28: getstatic com/google/android/gms/analytics/v.yT : Ljava/lang/Object;
    //   31: invokevirtual removeMessages : (ILjava/lang/Object;)V
    //   34: aload_0
    //   35: getfield mHandler : Landroid/os/Handler;
    //   38: aload_0
    //   39: getfield mHandler : Landroid/os/Handler;
    //   42: iconst_1
    //   43: getstatic com/google/android/gms/analytics/v.yT : Ljava/lang/Object;
    //   46: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   49: invokevirtual sendMessage : (Landroid/os/Message;)Z
    //   52: pop
    //   53: aload_0
    //   54: monitorexit
    //   55: return
    //   56: astore_1
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_1
    //   60: athrow
    // Exception table:
    //   from	to	target	type
    //   2	53	56	finally
  }
  
  void setLocalDispatchPeriod(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mHandler : Landroid/os/Handler;
    //   6: ifnonnull -> 22
    //   9: ldc 'Dispatch period set with null handler. Dispatch will run once initialization is complete.'
    //   11: invokestatic V : (Ljava/lang/String;)V
    //   14: aload_0
    //   15: iload_1
    //   16: putfield yW : I
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: invokestatic eK : ()Lcom/google/android/gms/analytics/y;
    //   25: getstatic com/google/android/gms/analytics/y$a.AP : Lcom/google/android/gms/analytics/y$a;
    //   28: invokevirtual a : (Lcom/google/android/gms/analytics/y$a;)V
    //   31: aload_0
    //   32: getfield ze : Z
    //   35: ifne -> 63
    //   38: aload_0
    //   39: getfield za : Z
    //   42: ifeq -> 63
    //   45: aload_0
    //   46: getfield yW : I
    //   49: ifle -> 63
    //   52: aload_0
    //   53: getfield mHandler : Landroid/os/Handler;
    //   56: iconst_1
    //   57: getstatic com/google/android/gms/analytics/v.yT : Ljava/lang/Object;
    //   60: invokevirtual removeMessages : (ILjava/lang/Object;)V
    //   63: aload_0
    //   64: iload_1
    //   65: putfield yW : I
    //   68: iload_1
    //   69: ifle -> 19
    //   72: aload_0
    //   73: getfield ze : Z
    //   76: ifne -> 19
    //   79: aload_0
    //   80: getfield za : Z
    //   83: ifeq -> 19
    //   86: aload_0
    //   87: getfield mHandler : Landroid/os/Handler;
    //   90: aload_0
    //   91: getfield mHandler : Landroid/os/Handler;
    //   94: iconst_1
    //   95: getstatic com/google/android/gms/analytics/v.yT : Ljava/lang/Object;
    //   98: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   101: iload_1
    //   102: sipush #1000
    //   105: imul
    //   106: i2l
    //   107: invokevirtual sendMessageDelayed : (Landroid/os/Message;J)Z
    //   110: pop
    //   111: goto -> 19
    //   114: astore_2
    //   115: aload_0
    //   116: monitorexit
    //   117: aload_2
    //   118: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	114	finally
    //   22	63	114	finally
    //   63	68	114	finally
    //   72	111	114	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */