package com.google.android.gms.analytics;

import android.text.TextUtils;
import java.util.HashMap;
import java.util.Map;

public class af {
  private final Map<String, Integer> BO = new HashMap<String, Integer>();
  
  private final Map<String, String> BP = new HashMap<String, String>();
  
  private final boolean BQ;
  
  private final String BR;
  
  public af(String paramString, boolean paramBoolean) {
    this.BQ = paramBoolean;
    this.BR = paramString;
  }
  
  public void e(String paramString, int paramInt) {
    if (!this.BQ)
      return; 
    Integer integer2 = this.BO.get(paramString);
    Integer integer1 = integer2;
    if (integer2 == null)
      integer1 = Integer.valueOf(0); 
    this.BO.put(paramString, Integer.valueOf(integer1.intValue() + paramInt));
  }
  
  public String fg() {
    if (!this.BQ)
      return ""; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.BR);
    for (String str : this.BO.keySet())
      stringBuilder.append("&").append(str).append("=").append(this.BO.get(str)); 
    for (String str : this.BP.keySet())
      stringBuilder.append("&").append(str).append("=").append(this.BP.get(str)); 
    return stringBuilder.toString();
  }
  
  public void g(String paramString1, String paramString2) {
    if (!this.BQ || TextUtils.isEmpty(paramString1))
      return; 
    this.BP.put(paramString1, paramString2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */