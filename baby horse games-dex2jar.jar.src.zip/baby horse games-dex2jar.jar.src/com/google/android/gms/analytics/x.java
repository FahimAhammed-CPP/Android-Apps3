package com.google.android.gms.analytics;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.internal.ha;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class x extends Thread implements f {
  private static x zM;
  
  private volatile boolean mClosed = false;
  
  private final Context mContext;
  
  private final LinkedBlockingQueue<Runnable> zJ = new LinkedBlockingQueue<Runnable>();
  
  private volatile boolean zK = false;
  
  private volatile String zL;
  
  private volatile ak zN;
  
  private final Lock zO;
  
  private final List<ha> zP = new ArrayList<ha>();
  
  private x(Context paramContext) {
    super("GAThread");
    if (paramContext != null) {
      this.mContext = paramContext.getApplicationContext();
    } else {
      this.mContext = paramContext;
    } 
    this.zP.add(new ha("appendVersion", "&_v".substring(1), "ma4.0.4"));
    this.zO = new ReentrantLock();
    start();
  }
  
  static x A(Context paramContext) {
    if (zM == null)
      zM = new x(paramContext); 
    return zM;
  }
  
  static String B(Context paramContext) {
    try {
      FileInputStream fileInputStream = paramContext.openFileInput("gaInstallData");
      byte[] arrayOfByte = new byte[8192];
      int i = fileInputStream.read(arrayOfByte, 0, 8192);
      if (fileInputStream.available() > 0) {
        ae.T("Too much campaign data, ignoring it.");
        fileInputStream.close();
        paramContext.deleteFile("gaInstallData");
        return null;
      } 
      fileInputStream.close();
      paramContext.deleteFile("gaInstallData");
      if (i <= 0) {
        ae.W("Campaign file is empty.");
        return null;
      } 
      String str = new String(arrayOfByte, 0, i);
      ae.U("Campaign found: " + str);
      return str;
    } catch (FileNotFoundException fileNotFoundException) {
      ae.U("No campaign data found.");
      return null;
    } catch (IOException iOException) {
      ae.T("Error reading campaign data.");
      fileNotFoundException.deleteFile("gaInstallData");
      return null;
    } 
  }
  
  static int ah(String paramString) {
    int i = 1;
    if (!TextUtils.isEmpty(paramString)) {
      int k = paramString.length();
      int j = 0;
      k--;
      while (true) {
        i = j;
        if (k >= 0) {
          i = paramString.charAt(k);
          i = (j << 6 & 0xFFFFFFF) + i + (i << 14);
          int m = 0xFE00000 & i;
          j = i;
          if (m != 0)
            j = i ^ m >> 21; 
          k--;
          continue;
        } 
        break;
      } 
    } 
    return i;
  }
  
  private void b(Runnable paramRunnable) {
    this.zJ.add(paramRunnable);
  }
  
  private String g(Throwable paramThrowable) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(byteArrayOutputStream);
    paramThrowable.printStackTrace(printStream);
    printStream.flush();
    return new String(byteArrayOutputStream.toByteArray());
  }
  
  public void dQ() {
    b(new a());
  }
  
  public void dW() {
    b(new c());
  }
  
  public LinkedBlockingQueue<Runnable> dX() {
    return this.zJ;
  }
  
  public void dY() {
    init();
    null = new ArrayList();
    this.zJ.drainTo(null);
    this.zO.lock();
    try {
      this.zK = true;
      Iterator<? super Runnable> iterator = null.iterator();
      while (true) {
        if (iterator.hasNext()) {
          Runnable runnable = iterator.next();
          try {
            runnable.run();
            continue;
          } catch (Throwable throwable) {
            ae.T("Error dispatching all events on exit, giving up: " + g(throwable));
          } 
        } else {
          break;
        } 
        return;
      } 
      return;
    } finally {
      this.zO.unlock();
    } 
  }
  
  public void dispatch() {
    b(new b());
  }
  
  public Thread getThread() {
    return this;
  }
  
  protected void init() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zN : Lcom/google/android/gms/analytics/ak;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: new com/google/android/gms/analytics/w
    //   18: dup
    //   19: aload_0
    //   20: getfield mContext : Landroid/content/Context;
    //   23: aload_0
    //   24: invokespecial <init> : (Landroid/content/Context;Lcom/google/android/gms/analytics/f;)V
    //   27: putfield zN : Lcom/google/android/gms/analytics/ak;
    //   30: aload_0
    //   31: getfield zN : Lcom/google/android/gms/analytics/ak;
    //   34: invokeinterface eB : ()V
    //   39: goto -> 11
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	42	finally
    //   14	39	42	finally
  }
  
  public void run() {
    // Byte code:
    //   0: bipush #10
    //   2: invokestatic setThreadPriority : (I)V
    //   5: ldc2_w 5000
    //   8: invokestatic sleep : (J)V
    //   11: aload_0
    //   12: invokevirtual init : ()V
    //   15: aload_0
    //   16: aload_0
    //   17: getfield mContext : Landroid/content/Context;
    //   20: invokestatic B : (Landroid/content/Context;)Ljava/lang/String;
    //   23: putfield zL : Ljava/lang/String;
    //   26: ldc_w 'Initialized GA Thread'
    //   29: invokestatic V : (Ljava/lang/String;)V
    //   32: aload_0
    //   33: getfield mClosed : Z
    //   36: ifne -> 201
    //   39: aload_0
    //   40: getfield zJ : Ljava/util/concurrent/LinkedBlockingQueue;
    //   43: invokevirtual take : ()Ljava/lang/Object;
    //   46: checkcast java/lang/Runnable
    //   49: astore_1
    //   50: aload_0
    //   51: getfield zO : Ljava/util/concurrent/locks/Lock;
    //   54: invokeinterface lock : ()V
    //   59: aload_0
    //   60: getfield zK : Z
    //   63: ifne -> 72
    //   66: aload_1
    //   67: invokeinterface run : ()V
    //   72: aload_0
    //   73: getfield zO : Ljava/util/concurrent/locks/Lock;
    //   76: invokeinterface unlock : ()V
    //   81: goto -> 32
    //   84: astore_1
    //   85: aload_1
    //   86: invokevirtual toString : ()Ljava/lang/String;
    //   89: invokestatic U : (Ljava/lang/String;)V
    //   92: goto -> 32
    //   95: astore_1
    //   96: new java/lang/StringBuilder
    //   99: dup
    //   100: invokespecial <init> : ()V
    //   103: ldc_w 'Error on GAThread: '
    //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: aload_0
    //   110: aload_1
    //   111: invokespecial g : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: invokevirtual toString : ()Ljava/lang/String;
    //   120: invokestatic T : (Ljava/lang/String;)V
    //   123: ldc_w 'Google Analytics is shutting down.'
    //   126: invokestatic T : (Ljava/lang/String;)V
    //   129: aload_0
    //   130: iconst_1
    //   131: putfield zK : Z
    //   134: goto -> 32
    //   137: astore_1
    //   138: ldc_w 'sleep interrupted in GAThread initialize'
    //   141: invokestatic W : (Ljava/lang/String;)V
    //   144: goto -> 11
    //   147: astore_1
    //   148: new java/lang/StringBuilder
    //   151: dup
    //   152: invokespecial <init> : ()V
    //   155: ldc_w 'Error initializing the GAThread: '
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: aload_0
    //   162: aload_1
    //   163: invokespecial g : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   166: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   169: invokevirtual toString : ()Ljava/lang/String;
    //   172: invokestatic T : (Ljava/lang/String;)V
    //   175: ldc_w 'Google Analytics will not start up.'
    //   178: invokestatic T : (Ljava/lang/String;)V
    //   181: aload_0
    //   182: iconst_1
    //   183: putfield zK : Z
    //   186: goto -> 32
    //   189: astore_1
    //   190: aload_0
    //   191: getfield zO : Ljava/util/concurrent/locks/Lock;
    //   194: invokeinterface unlock : ()V
    //   199: aload_1
    //   200: athrow
    //   201: return
    // Exception table:
    //   from	to	target	type
    //   5	11	137	java/lang/InterruptedException
    //   11	32	147	java/lang/Throwable
    //   39	59	84	java/lang/InterruptedException
    //   39	59	95	java/lang/Throwable
    //   59	72	189	finally
    //   72	81	84	java/lang/InterruptedException
    //   72	81	95	java/lang/Throwable
    //   85	92	95	java/lang/Throwable
    //   190	201	84	java/lang/InterruptedException
    //   190	201	95	java/lang/Throwable
  }
  
  public void u(Map<String, String> paramMap) {
    b(new d(this, paramMap));
  }
  
  private class a implements Runnable {
    private a(x this$0) {}
    
    public void run() {
      x.d(this.zQ).dQ();
    }
  }
  
  private class b implements Runnable {
    private b(x this$0) {}
    
    public void run() {
      x.d(this.zQ).dispatch();
    }
  }
  
  private class c implements Runnable {
    private c(x this$0) {}
    
    public void run() {
      x.d(this.zQ).dW();
    }
  }
  
  private class d implements Runnable {
    private final Map<String, String> zR;
    
    d(x this$0, Map<String, String> param1Map) {
      this.zR = new HashMap<String, String>(param1Map);
      String str2 = param1Map.get("&ht");
      String str1 = str2;
      if (str2 != null)
        try {
          Long.valueOf(str2);
          str1 = str2;
        } catch (NumberFormatException numberFormatException) {
          numberFormatException = null;
        }  
      if (numberFormatException == null) {
        long l = System.currentTimeMillis();
        this.zR.put("&ht", Long.toString(l));
      } 
    }
    
    private String v(Map<String, String> param1Map) {
      return param1Map.containsKey("useSecure") ? (an.f(param1Map.get("useSecure"), true) ? "https:" : "http:") : "https:";
    }
    
    private void w(Map<String, String> param1Map) {
      q q = a.w(x.a(this.zQ));
      an.a(param1Map, "&adid", q);
      an.a(param1Map, "&ate", q);
    }
    
    private void x(Map<String, String> param1Map) {
      g g = g.dZ();
      an.a(param1Map, "&an", g);
      an.a(param1Map, "&av", g);
      an.a(param1Map, "&aid", g);
      an.a(param1Map, "&aiid", g);
      param1Map.put("&v", "1");
    }
    
    private boolean y(Map<String, String> param1Map) {
      if (param1Map.get("&sf") == null)
        return false; 
      double d1 = an.a(param1Map.get("&sf"), 100.0D);
      if (d1 >= 100.0D)
        return false; 
      if ((x.ah(param1Map.get("&cid")) % 10000) >= d1 * 100.0D) {
        if (param1Map.get("&t") == null) {
          str = "unknown";
          ae.V(String.format("%s hit sampled out", new Object[] { str }));
          return true;
        } 
        String str = (String)str.get("&t");
        ae.V(String.format("%s hit sampled out", new Object[] { str }));
        return true;
      } 
      return false;
    }
    
    public void run() {
      w(this.zR);
      if (TextUtils.isEmpty(this.zR.get("&cid")))
        this.zR.put("&cid", k.el().getValue("&cid")); 
      if (GoogleAnalytics.getInstance(x.a(this.zQ)).getAppOptOut() || y(this.zR))
        return; 
      if (!TextUtils.isEmpty(x.b(this.zQ))) {
        y.eK().D(true);
        this.zR.putAll((new HitBuilders.HitBuilder<HitBuilders.HitBuilder>()).setCampaignParamsFromUrl(x.b(this.zQ)).build());
        y.eK().D(false);
        x.a(this.zQ, null);
      } 
      x(this.zR);
      Map<String, String> map = ac.z(this.zR);
      x.d(this.zQ).b(map, Long.valueOf(this.zR.get("&ht")).longValue(), v(this.zR), x.c(this.zQ));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */