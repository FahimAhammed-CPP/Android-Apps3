package com.google.android.gms.analytics;

import android.util.Log;

class p implements Logger {
  private int yM = 2;
  
  private String af(String paramString) {
    return Thread.currentThread().toString() + ": " + paramString;
  }
  
  public void error(Exception paramException) {
    if (this.yM <= 3)
      Log.e("GAV4", null, paramException); 
  }
  
  public void error(String paramString) {
    if (this.yM <= 3)
      Log.e("GAV4", af(paramString)); 
  }
  
  public int getLogLevel() {
    return this.yM;
  }
  
  public void info(String paramString) {
    if (this.yM <= 1)
      Log.i("GAV4", af(paramString)); 
  }
  
  public void setLogLevel(int paramInt) {
    this.yM = paramInt;
  }
  
  public void verbose(String paramString) {
    if (this.yM <= 0)
      Log.v("GAV4", af(paramString)); 
  }
  
  public void warn(String paramString) {
    if (this.yM <= 2)
      Log.w("GAV4", af(paramString)); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */