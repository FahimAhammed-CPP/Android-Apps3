package com.google.android.gms.analytics;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.internal.ha;
import com.google.android.gms.internal.hb;
import java.util.List;
import java.util.Map;

class c implements b {
  private Context mContext;
  
  private ServiceConnection xV;
  
  private b xW;
  
  private c xX;
  
  private hb xY;
  
  public c(Context paramContext, b paramb, c paramc) {
    this.mContext = paramContext;
    if (paramb == null)
      throw new IllegalArgumentException("onConnectedListener cannot be null"); 
    this.xW = paramb;
    if (paramc == null)
      throw new IllegalArgumentException("onConnectionFailedListener cannot be null"); 
    this.xX = paramc;
  }
  
  private hb dR() {
    dS();
    return this.xY;
  }
  
  private void dT() {
    dU();
  }
  
  private void dU() {
    this.xW.onConnected();
  }
  
  public void a(Map<String, String> paramMap, long paramLong, String paramString, List<ha> paramList) {
    try {
      dR().a(paramMap, paramLong, paramString, paramList);
      return;
    } catch (RemoteException remoteException) {
      ae.T("sendHit failed: " + remoteException);
      return;
    } 
  }
  
  public void connect() {
    Intent intent = new Intent("com.google.android.gms.analytics.service.START");
    intent.setComponent(new ComponentName("com.google.android.gms", "com.google.android.gms.analytics.service.AnalyticsService"));
    intent.putExtra("app_package_name", this.mContext.getPackageName());
    if (this.xV != null) {
      ae.T("Calling connect() while still connected, missing disconnect().");
      return;
    } 
    this.xV = new a(this);
    boolean bool = this.mContext.bindService(intent, this.xV, 129);
    ae.V("connect: bindService returned " + bool + " for " + intent);
    if (!bool) {
      this.xV = null;
      this.xX.a(1, null);
      return;
    } 
  }
  
  public void dQ() {
    try {
      dR().dQ();
      return;
    } catch (RemoteException remoteException) {
      ae.T("clear hits failed: " + remoteException);
      return;
    } 
  }
  
  protected void dS() {
    if (!isConnected())
      throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called."); 
  }
  
  public void disconnect() {
    this.xY = null;
    if (this.xV != null) {
      try {
        this.mContext.unbindService(this.xV);
      } catch (IllegalStateException illegalStateException) {
      
      } catch (IllegalArgumentException illegalArgumentException) {}
      this.xV = null;
      this.xW.onDisconnected();
    } 
  }
  
  public boolean isConnected() {
    return (this.xY != null);
  }
  
  final class a implements ServiceConnection {
    a(c this$0) {}
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      ae.V("service connected, binder: " + param1IBinder);
      try {
        if ("com.google.android.gms.analytics.internal.IAnalyticsService".equals(param1IBinder.getInterfaceDescriptor())) {
          ae.V("bound to service");
          c.a(this.xZ, hb.a.D(param1IBinder));
          c.a(this.xZ);
          return;
        } 
      } catch (RemoteException remoteException) {}
      try {
        c.b(this.xZ).unbindService(this);
      } catch (IllegalArgumentException illegalArgumentException) {}
      c.a(this.xZ, (ServiceConnection)null);
      c.c(this.xZ).a(2, null);
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      ae.V("service disconnected: " + param1ComponentName);
      c.a(this.xZ, (ServiceConnection)null);
      c.d(this.xZ).onDisconnected();
    }
  }
  
  public static interface b {
    void onConnected();
    
    void onDisconnected();
  }
  
  public static interface c {
    void a(int param1Int, Intent param1Intent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */