package com.google.android.gms.analytics;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

class g implements q {
  private static Object xO = new Object();
  
  private static g ye;
  
  protected String ya;
  
  protected String yb;
  
  protected String yc;
  
  protected String yd;
  
  protected g() {}
  
  private g(Context paramContext) {
    Context context1;
    PackageManager packageManager = paramContext.getPackageManager();
    this.yc = paramContext.getPackageName();
    this.yd = packageManager.getInstallerPackageName(this.yc);
    String str2 = this.yc;
    Context context2 = null;
    String str1 = str2;
    try {
      PackageInfo packageInfo = packageManager.getPackageInfo(paramContext.getPackageName(), 0);
      paramContext = context2;
      str1 = str2;
      if (packageInfo != null) {
        str1 = str2;
        String str = packageManager.getApplicationLabel(packageInfo.applicationInfo).toString();
        str1 = str;
        str2 = packageInfo.versionName;
        str1 = str;
        str = str2;
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      ae.T("Error retrieving package info: appName set to " + str1);
      context1 = context2;
    } 
    this.ya = str1;
    this.yb = (String)context1;
  }
  
  public static g dZ() {
    return ye;
  }
  
  public static void y(Context paramContext) {
    synchronized (xO) {
      if (ye == null)
        ye = new g(paramContext); 
      return;
    } 
  }
  
  public boolean ac(String paramString) {
    return ("&an".equals(paramString) || "&av".equals(paramString) || "&aid".equals(paramString) || "&aiid".equals(paramString));
  }
  
  public String getValue(String paramString) {
    if (paramString != null) {
      if (paramString.equals("&an"))
        return this.ya; 
      if (paramString.equals("&av"))
        return this.yb; 
      if (paramString.equals("&aid"))
        return this.yc; 
      if (paramString.equals("&aiid"))
        return this.yd; 
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */