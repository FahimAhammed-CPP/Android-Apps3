package com.google.android.gms.analytics;

import android.content.Context;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;

class k implements q {
  private static final Object xO = new Object();
  
  private static k yD;
  
  private final Context mContext;
  
  private String yE;
  
  private boolean yF = false;
  
  private final Object yG = new Object();
  
  protected k(Context paramContext) {
    this.mContext = paramContext;
    ep();
  }
  
  private boolean ae(String paramString) {
    try {
      ae.V("Storing clientId.");
      FileOutputStream fileOutputStream = this.mContext.openFileOutput("gaClientId", 0);
      fileOutputStream.write(paramString.getBytes());
      fileOutputStream.close();
      return true;
    } catch (FileNotFoundException fileNotFoundException) {
      ae.T("Error creating clientId file.");
      return false;
    } catch (IOException iOException) {
      ae.T("Error writing to clientId file.");
      return false;
    } 
  }
  
  public static k el() {
    synchronized (xO) {
      return yD;
    } 
  }
  
  private String en() {
    // Byte code:
    //   0: aload_0
    //   1: getfield yF : Z
    //   4: ifne -> 42
    //   7: aload_0
    //   8: getfield yG : Ljava/lang/Object;
    //   11: astore_1
    //   12: aload_1
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield yF : Z
    //   18: ifne -> 40
    //   21: ldc 'Waiting for clientId to load'
    //   23: invokestatic V : (Ljava/lang/String;)V
    //   26: aload_0
    //   27: getfield yG : Ljava/lang/Object;
    //   30: invokevirtual wait : ()V
    //   33: aload_0
    //   34: getfield yF : Z
    //   37: ifeq -> 26
    //   40: aload_1
    //   41: monitorexit
    //   42: ldc 'Loaded clientId'
    //   44: invokestatic V : (Ljava/lang/String;)V
    //   47: aload_0
    //   48: getfield yE : Ljava/lang/String;
    //   51: areturn
    //   52: astore_2
    //   53: new java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: ldc 'Exception while waiting for clientId: '
    //   62: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: aload_2
    //   66: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   69: invokevirtual toString : ()Ljava/lang/String;
    //   72: invokestatic T : (Ljava/lang/String;)V
    //   75: goto -> 33
    //   78: astore_2
    //   79: aload_1
    //   80: monitorexit
    //   81: aload_2
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   14	26	78	finally
    //   26	33	52	java/lang/InterruptedException
    //   26	33	78	finally
    //   33	40	78	finally
    //   40	42	78	finally
    //   53	75	78	finally
    //   79	81	78	finally
  }
  
  private void ep() {
    (new Thread(this, "client_id_fetcher") {
        public void run() {
          synchronized (k.a(this.yH)) {
            k.a(this.yH, this.yH.eq());
            k.a(this.yH, true);
            k.a(this.yH).notifyAll();
            return;
          } 
        }
      }).start();
  }
  
  public static void y(Context paramContext) {
    synchronized (xO) {
      if (yD == null)
        yD = new k(paramContext); 
      return;
    } 
  }
  
  public boolean ac(String paramString) {
    return "&cid".equals(paramString);
  }
  
  String em() {
    synchronized (this.yG) {
      this.yE = eo();
      return this.yE;
    } 
  }
  
  protected String eo() {
    String str2 = UUID.randomUUID().toString().toLowerCase();
    String str1 = str2;
    try {
      if (!ae(str2))
        str1 = "0"; 
      return str1;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  String eq() {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore_3
    //   5: aload_0
    //   6: getfield mContext : Landroid/content/Context;
    //   9: ldc 'gaClientId'
    //   11: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   14: astore #5
    //   16: sipush #128
    //   19: newarray byte
    //   21: astore_2
    //   22: aload #5
    //   24: aload_2
    //   25: iconst_0
    //   26: sipush #128
    //   29: invokevirtual read : ([BII)I
    //   32: istore_1
    //   33: aload #5
    //   35: invokevirtual available : ()I
    //   38: ifle -> 76
    //   41: ldc 'clientId file seems corrupted, deleting it.'
    //   43: invokestatic T : (Ljava/lang/String;)V
    //   46: aload #5
    //   48: invokevirtual close : ()V
    //   51: aload_0
    //   52: getfield mContext : Landroid/content/Context;
    //   55: ldc 'gaClientId'
    //   57: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   60: pop
    //   61: aload_3
    //   62: astore_2
    //   63: aload_2
    //   64: astore_3
    //   65: aload_2
    //   66: ifnonnull -> 74
    //   69: aload_0
    //   70: invokevirtual eo : ()Ljava/lang/String;
    //   73: astore_3
    //   74: aload_3
    //   75: areturn
    //   76: iload_1
    //   77: ifgt -> 105
    //   80: ldc 'clientId file seems empty, deleting it.'
    //   82: invokestatic T : (Ljava/lang/String;)V
    //   85: aload #5
    //   87: invokevirtual close : ()V
    //   90: aload_0
    //   91: getfield mContext : Landroid/content/Context;
    //   94: ldc 'gaClientId'
    //   96: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   99: pop
    //   100: aload_3
    //   101: astore_2
    //   102: goto -> 63
    //   105: new java/lang/String
    //   108: dup
    //   109: aload_2
    //   110: iconst_0
    //   111: iload_1
    //   112: invokespecial <init> : ([BII)V
    //   115: astore_2
    //   116: aload #5
    //   118: invokevirtual close : ()V
    //   121: ldc 'Loaded client id from disk.'
    //   123: invokestatic V : (Ljava/lang/String;)V
    //   126: goto -> 63
    //   129: astore_2
    //   130: aload #4
    //   132: astore_2
    //   133: ldc 'Error reading clientId file, deleting it.'
    //   135: invokestatic T : (Ljava/lang/String;)V
    //   138: aload_0
    //   139: getfield mContext : Landroid/content/Context;
    //   142: ldc 'gaClientId'
    //   144: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   147: pop
    //   148: goto -> 63
    //   151: astore_3
    //   152: goto -> 133
    //   155: astore_3
    //   156: goto -> 63
    //   159: astore_2
    //   160: aload_3
    //   161: astore_2
    //   162: goto -> 63
    // Exception table:
    //   from	to	target	type
    //   5	61	159	java/io/FileNotFoundException
    //   5	61	129	java/io/IOException
    //   80	100	159	java/io/FileNotFoundException
    //   80	100	129	java/io/IOException
    //   105	116	159	java/io/FileNotFoundException
    //   105	116	129	java/io/IOException
    //   116	126	155	java/io/FileNotFoundException
    //   116	126	151	java/io/IOException
  }
  
  public String getValue(String paramString) {
    return "&cid".equals(paramString) ? en() : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */