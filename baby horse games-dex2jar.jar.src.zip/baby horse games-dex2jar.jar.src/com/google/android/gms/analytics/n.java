package com.google.android.gms.analytics;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.text.TextUtils;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;

abstract class n<T extends m> {
  Context mContext;
  
  a<T> yL;
  
  public n(Context paramContext, a<T> parama) {
    this.mContext = paramContext;
    this.yL = parama;
  }
  
  private T a(XmlResourceParser paramXmlResourceParser) {
    try {
      paramXmlResourceParser.next();
      for (int i = paramXmlResourceParser.getEventType();; i = paramXmlResourceParser.next()) {
        if (i != 1) {
          if (paramXmlResourceParser.getEventType() == 2) {
            String str = paramXmlResourceParser.getName().toLowerCase();
            if (str.equals("screenname")) {
              str = paramXmlResourceParser.getAttributeValue(null, "name");
              String str1 = paramXmlResourceParser.nextText().trim();
              if (!TextUtils.isEmpty(str) && !TextUtils.isEmpty(str1))
                this.yL.e(str, str1); 
            } else if (str.equals("string")) {
              str = paramXmlResourceParser.getAttributeValue(null, "name");
              String str1 = paramXmlResourceParser.nextText().trim();
              if (!TextUtils.isEmpty(str) && str1 != null)
                this.yL.f(str, str1); 
            } else if (str.equals("bool")) {
              String str1 = paramXmlResourceParser.getAttributeValue(null, "name");
              str = paramXmlResourceParser.nextText().trim();
              if (!TextUtils.isEmpty(str1)) {
                boolean bool = TextUtils.isEmpty(str);
                if (!bool)
                  try {
                    bool = Boolean.parseBoolean(str);
                    this.yL.e(str1, bool);
                  } catch (NumberFormatException numberFormatException) {} 
              } 
            } else if (str.equals("integer")) {
              String str1 = paramXmlResourceParser.getAttributeValue(null, "name");
              str = paramXmlResourceParser.nextText().trim();
              if (!TextUtils.isEmpty(str1)) {
                boolean bool = TextUtils.isEmpty(str);
                if (!bool)
                  try {
                    i = Integer.parseInt(str);
                    this.yL.c(str1, i);
                  } catch (NumberFormatException numberFormatException) {} 
              } 
            } 
          } 
        } else {
          return this.yL.er();
        } 
      } 
    } catch (XmlPullParserException xmlPullParserException) {
      ae.T("Error parsing tracker configuration file: " + xmlPullParserException);
    } catch (IOException iOException) {
      ae.T("Error parsing tracker configuration file: " + iOException);
    } 
    return this.yL.er();
  }
  
  public T x(int paramInt) {
    try {
      return a(this.mContext.getResources().getXml(paramInt));
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      ae.W("inflate() called with unknown resourceId: " + notFoundException);
      return null;
    } 
  }
  
  public static interface a<U extends m> {
    void c(String param1String, int param1Int);
    
    void e(String param1String1, String param1String2);
    
    void e(String param1String, boolean param1Boolean);
    
    U er();
    
    void f(String param1String1, String param1String2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */