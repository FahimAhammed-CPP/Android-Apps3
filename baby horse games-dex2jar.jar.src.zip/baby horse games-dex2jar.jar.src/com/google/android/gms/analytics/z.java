package com.google.android.gms.analytics;

import android.content.Context;

class z extends n<aa> {
  public z(Context paramContext) {
    super(paramContext, new a());
  }
  
  private static class a implements n.a<aa> {
    private final aa Bi = new aa();
    
    public void c(String param1String, int param1Int) {
      if ("ga_dispatchPeriod".equals(param1String)) {
        this.Bi.Bk = param1Int;
        return;
      } 
      ae.W("int configuration name not recognized:  " + param1String);
    }
    
    public void e(String param1String1, String param1String2) {}
    
    public void e(String param1String, boolean param1Boolean) {
      aa aa1;
      if ("ga_dryRun".equals(param1String)) {
        boolean bool;
        aa1 = this.Bi;
        if (param1Boolean) {
          bool = true;
        } else {
          bool = false;
        } 
        aa1.Bl = bool;
        return;
      } 
      ae.W("bool configuration name not recognized:  " + aa1);
    }
    
    public aa eN() {
      return this.Bi;
    }
    
    public void f(String param1String1, String param1String2) {
      if ("ga_appName".equals(param1String1)) {
        this.Bi.ya = param1String2;
        return;
      } 
      if ("ga_appVersion".equals(param1String1)) {
        this.Bi.yb = param1String2;
        return;
      } 
      if ("ga_logLevel".equals(param1String1)) {
        this.Bi.Bj = param1String2;
        return;
      } 
      ae.W("string configuration name not recognized:  " + param1String1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */