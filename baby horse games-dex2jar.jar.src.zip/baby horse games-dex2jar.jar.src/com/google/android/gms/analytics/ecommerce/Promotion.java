package com.google.android.gms.analytics.ecommerce;

import com.google.android.gms.internal.jx;
import java.util.HashMap;
import java.util.Map;

public class Promotion {
  public static final String ACTION_CLICK = "click";
  
  public static final String ACTION_VIEW = "view";
  
  Map<String, String> CD = new HashMap<String, String>();
  
  public Map<String, String> aq(String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Map.Entry<String, String> entry : this.CD.entrySet())
      hashMap.put(paramString + (String)entry.getKey(), entry.getValue()); 
    return (Map)hashMap;
  }
  
  void put(String paramString1, String paramString2) {
    jx.b(paramString1, "Name should be non-null");
    this.CD.put(paramString1, paramString2);
  }
  
  public Promotion setCreative(String paramString) {
    put("cr", paramString);
    return this;
  }
  
  public Promotion setId(String paramString) {
    put("id", paramString);
    return this;
  }
  
  public Promotion setName(String paramString) {
    put("nm", paramString);
    return this;
  }
  
  public Promotion setPosition(String paramString) {
    put("ps", paramString);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\ecommerce\Promotion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */