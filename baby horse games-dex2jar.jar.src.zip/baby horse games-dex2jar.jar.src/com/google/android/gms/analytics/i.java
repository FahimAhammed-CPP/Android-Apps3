package com.google.android.gms.analytics;

public enum i {
  yA, yB, yw, yx, yy, yz;
  
  static {
    yA = new i("BATCH_BY_COUNT", 4);
    yB = new i("BATCH_BY_SIZE", 5);
    yC = new i[] { yw, yx, yy, yz, yA, yB };
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */