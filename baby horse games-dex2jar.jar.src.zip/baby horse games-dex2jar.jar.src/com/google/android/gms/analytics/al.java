package com.google.android.gms.analytics;

import android.content.Context;

class al extends n<am> {
  public al(Context paramContext) {
    super(paramContext, new a());
  }
  
  private static class a implements n.a<am> {
    private final am Cu = new am();
    
    public void c(String param1String, int param1Int) {
      if ("ga_sessionTimeout".equals(param1String)) {
        this.Cu.Cx = param1Int;
        return;
      } 
      ae.W("int configuration name not recognized:  " + param1String);
    }
    
    public void e(String param1String1, String param1String2) {
      this.Cu.CB.put(param1String1, param1String2);
    }
    
    public void e(String param1String, boolean param1Boolean) {
      am am1;
      boolean bool2 = true;
      boolean bool3 = true;
      boolean bool1 = true;
      if ("ga_autoActivityTracking".equals(param1String)) {
        am1 = this.Cu;
        if (!param1Boolean)
          bool1 = false; 
        am1.Cy = bool1;
        return;
      } 
      if ("ga_anonymizeIp".equals(am1)) {
        am1 = this.Cu;
        if (param1Boolean) {
          bool1 = bool2;
        } else {
          bool1 = false;
        } 
        am1.Cz = bool1;
        return;
      } 
      if ("ga_reportUncaughtExceptions".equals(am1)) {
        am1 = this.Cu;
        if (param1Boolean) {
          bool1 = bool3;
        } else {
          bool1 = false;
        } 
        am1.CA = bool1;
        return;
      } 
      ae.W("bool configuration name not recognized:  " + am1);
    }
    
    public void f(String param1String1, String param1String2) {
      if ("ga_trackingId".equals(param1String1)) {
        this.Cu.Cv = param1String2;
        return;
      } 
      if ("ga_sampleFrequency".equals(param1String1))
        try {
          this.Cu.Cw = Double.parseDouble(param1String2);
          return;
        } catch (NumberFormatException numberFormatException) {
          ae.T("Error parsing ga_sampleFrequency value: " + param1String2);
          return;
        }  
      ae.W("string configuration name not recognized:  " + numberFormatException);
    }
    
    public am fs() {
      return this.Cu;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */