package com.google.android.gms.analytics.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.List;
import java.util.Map;

public interface IAnalyticsService extends IInterface {
  void clearHits() throws RemoteException;
  
  void sendHit(Map paramMap, long paramLong, String paramString, List<Command> paramList) throws RemoteException;
  
  public static abstract class Stub extends Binder implements IAnalyticsService {
    private static final String DESCRIPTOR = "com.google.android.gms.analytics.internal.IAnalyticsService";
    
    static final int TRANSACTION_clearHits = 2;
    
    static final int TRANSACTION_sendHit = 1;
    
    public Stub() {
      attachInterface(this, "com.google.android.gms.analytics.internal.IAnalyticsService");
    }
    
    public static IAnalyticsService asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.analytics.internal.IAnalyticsService");
      return (iInterface != null && iInterface instanceof IAnalyticsService) ? (IAnalyticsService)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.analytics.internal.IAnalyticsService");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.analytics.internal.IAnalyticsService");
          sendHit(param1Parcel1.readHashMap(getClass().getClassLoader()), param1Parcel1.readLong(), param1Parcel1.readString(), param1Parcel1.createTypedArrayList(Command.CREATOR));
          param1Parcel2.writeNoException();
          return true;
        case 2:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.analytics.internal.IAnalyticsService");
      clearHits();
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class Proxy implements IAnalyticsService {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public void clearHits() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.analytics.internal.IAnalyticsService");
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getInterfaceDescriptor() {
        return "com.google.android.gms.analytics.internal.IAnalyticsService";
      }
      
      public void sendHit(Map param2Map, long param2Long, String param2String, List<Command> param2List) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.analytics.internal.IAnalyticsService");
          parcel1.writeMap(param2Map);
          parcel1.writeLong(param2Long);
          parcel1.writeString(param2String);
          parcel1.writeTypedList(param2List);
          this.mRemote.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IAnalyticsService {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public void clearHits() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.analytics.internal.IAnalyticsService");
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getInterfaceDescriptor() {
      return "com.google.android.gms.analytics.internal.IAnalyticsService";
    }
    
    public void sendHit(Map param1Map, long param1Long, String param1String, List<Command> param1List) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.analytics.internal.IAnalyticsService");
        parcel1.writeMap(param1Map);
        parcel1.writeLong(param1Long);
        parcel1.writeString(param1String);
        parcel1.writeTypedList(param1List);
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\internal\IAnalyticsService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */