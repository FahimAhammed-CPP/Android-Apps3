package com.google.android.gms.analytics;

interface ah {
  boolean fe();
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */