package com.google.android.gms.analytics;

import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class an {
  private static final char[] CC = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'A', 'B', 'C', 'D', 'E', 'F' };
  
  static String E(boolean paramBoolean) {
    return paramBoolean ? "1" : "0";
  }
  
  public static double a(String paramString, double paramDouble) {
    if (paramString == null)
      return paramDouble; 
    try {
      return Double.parseDouble(paramString);
    } catch (NumberFormatException numberFormatException) {
      return paramDouble;
    } 
  }
  
  public static String a(Locale paramLocale) {
    if (paramLocale != null && !TextUtils.isEmpty(paramLocale.getLanguage())) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramLocale.getLanguage().toLowerCase());
      if (!TextUtils.isEmpty(paramLocale.getCountry()))
        stringBuilder.append("-").append(paramLocale.getCountry().toLowerCase()); 
      return stringBuilder.toString();
    } 
    return null;
  }
  
  public static void a(Map<String, String> paramMap, String paramString, q paramq) {
    if (!paramMap.containsKey(paramString))
      paramMap.put(paramString, paramq.getValue(paramString)); 
  }
  
  public static void a(Map<String, String> paramMap, String paramString1, String paramString2) {
    if (!paramMap.containsKey(paramString1))
      paramMap.put(paramString1, paramString2); 
  }
  
  public static Map<String, String> an(String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    String[] arrayOfString = paramString.split("&");
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String[] arrayOfString1 = arrayOfString[i].split("=");
      if (arrayOfString1.length > 1) {
        hashMap.put(arrayOfString1[0], arrayOfString1[1]);
      } else if (arrayOfString1.length == 1 && arrayOfString1[0].length() != 0) {
        hashMap.put(arrayOfString1[0], null);
      } 
    } 
    return (Map)hashMap;
  }
  
  public static String ao(String paramString) {
    String[] arrayOfString;
    StringBuilder stringBuilder;
    if (TextUtils.isEmpty(paramString))
      return null; 
    String str = paramString;
    if (paramString.contains("?")) {
      String[] arrayOfString1 = paramString.split("[\\?]");
      str = paramString;
      if (arrayOfString1.length > 1)
        str = arrayOfString1[1]; 
    } 
    if (str.contains("%3D")) {
      try {
        paramString = URLDecoder.decode(str, "UTF-8");
        Map<String, String> map = an(paramString);
        arrayOfString = new String[9];
        arrayOfString[0] = "dclid";
        arrayOfString[1] = "utm_source";
        arrayOfString[2] = "gclid";
        arrayOfString[3] = "utm_campaign";
        arrayOfString[4] = "utm_medium";
        arrayOfString[5] = "utm_term";
        arrayOfString[6] = "utm_content";
        arrayOfString[7] = "utm_id";
        arrayOfString[8] = "gmob_t";
        stringBuilder = new StringBuilder();
        boolean bool = false;
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        return null;
      } 
    } else {
      String[] arrayOfString1 = arrayOfString;
      if (!arrayOfString.contains("="))
        return null; 
      Map<String, String> map = an((String)arrayOfString1);
      arrayOfString = new String[9];
      arrayOfString[0] = "dclid";
      arrayOfString[1] = "utm_source";
      arrayOfString[2] = "gclid";
      arrayOfString[3] = "utm_campaign";
      arrayOfString[4] = "utm_medium";
      arrayOfString[5] = "utm_term";
      arrayOfString[6] = "utm_content";
      arrayOfString[7] = "utm_id";
      arrayOfString[8] = "gmob_t";
      stringBuilder = new StringBuilder();
      boolean bool = false;
    } 
    return stringBuilder.toString();
  }
  
  public static MessageDigest ap(String paramString) {
    for (int i = 0; i < 2; i++) {
      try {
        MessageDigest messageDigest = MessageDigest.getInstance(paramString);
        if (messageDigest != null)
          return messageDigest; 
      } catch (NoSuchAlgorithmException noSuchAlgorithmException) {}
    } 
    return null;
  }
  
  public static boolean f(String paramString, boolean paramBoolean) {
    boolean bool = paramBoolean;
    if (paramString != null) {
      if (paramString.equalsIgnoreCase("true") || paramString.equalsIgnoreCase("yes") || paramString.equalsIgnoreCase("1"))
        return true; 
    } else {
      return bool;
    } 
    if (!paramString.equalsIgnoreCase("false") && !paramString.equalsIgnoreCase("no")) {
      bool = paramBoolean;
      return paramString.equalsIgnoreCase("0") ? false : bool;
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */