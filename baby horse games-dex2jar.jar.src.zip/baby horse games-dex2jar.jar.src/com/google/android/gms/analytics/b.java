package com.google.android.gms.analytics;

import com.google.android.gms.internal.ha;
import java.util.List;
import java.util.Map;

interface b {
  void a(Map<String, String> paramMap, long paramLong, String paramString, List<ha> paramList);
  
  void connect();
  
  void dQ();
  
  void disconnect();
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */