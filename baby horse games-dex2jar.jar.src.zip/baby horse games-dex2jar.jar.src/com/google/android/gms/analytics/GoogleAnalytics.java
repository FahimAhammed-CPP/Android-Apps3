package com.google.android.gms.analytics;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class GoogleAnalytics extends TrackerHandler {
  private static boolean Bm;
  
  private static GoogleAnalytics Bs;
  
  private aj Bn;
  
  private volatile Boolean Bo = Boolean.valueOf(false);
  
  private Logger Bp;
  
  private Set<a> Bq;
  
  private boolean Br = false;
  
  private Context mContext;
  
  private f yV;
  
  private String ya;
  
  private String yb;
  
  private boolean yt;
  
  protected GoogleAnalytics(Context paramContext) {
    this(paramContext, x.A(paramContext), v.eu());
  }
  
  private GoogleAnalytics(Context paramContext, f paramf, aj paramaj) {
    if (paramContext == null)
      throw new IllegalArgumentException("context cannot be null"); 
    this.mContext = paramContext.getApplicationContext();
    this.yV = paramf;
    this.Bn = paramaj;
    g.y(this.mContext);
    ai.y(this.mContext);
    k.y(this.mContext);
    this.Bp = new p();
    this.Bq = new HashSet<a>();
    eZ();
  }
  
  private Tracker a(Tracker paramTracker) {
    if (this.ya != null)
      paramTracker.set("&an", this.ya); 
    if (this.yb != null)
      paramTracker.set("&av", this.yb); 
    return paramTracker;
  }
  
  private int ai(String paramString) {
    paramString = paramString.toLowerCase();
    return "verbose".equals(paramString) ? 0 : ("info".equals(paramString) ? 1 : ("warning".equals(paramString) ? 2 : ("error".equals(paramString) ? 3 : -1)));
  }
  
  static GoogleAnalytics eY() {
    // Byte code:
    //   0: ldc com/google/android/gms/analytics/GoogleAnalytics
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/analytics/GoogleAnalytics.Bs : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   6: astore_0
    //   7: ldc com/google/android/gms/analytics/GoogleAnalytics
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/google/android/gms/analytics/GoogleAnalytics
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	10	12	finally
    //   13	16	12	finally
  }
  
  private void eZ() {
    if (!Bm) {
      try {
        ApplicationInfo applicationInfo = this.mContext.getPackageManager().getApplicationInfo(this.mContext.getPackageName(), 129);
        if (applicationInfo == null) {
          ae.W("Couldn't get ApplicationInfo to load gloabl config.");
          return;
        } 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        ae.V("PackageManager doesn't know about package: " + nameNotFoundException);
        nameNotFoundException = null;
        if (nameNotFoundException == null) {
          ae.W("Couldn't get ApplicationInfo to load gloabl config.");
          return;
        } 
      } 
      Bundle bundle = ((ApplicationInfo)nameNotFoundException).metaData;
      if (bundle != null) {
        int i = bundle.getInt("com.google.android.gms.analytics.globalConfigResource");
        if (i > 0) {
          aa aa = (new z(this.mContext)).x(i);
          if (aa != null) {
            a(aa);
            return;
          } 
        } 
      } 
    } 
  }
  
  public static GoogleAnalytics getInstance(Context paramContext) {
    // Byte code:
    //   0: ldc com/google/android/gms/analytics/GoogleAnalytics
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/analytics/GoogleAnalytics.Bs : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   6: ifnonnull -> 20
    //   9: new com/google/android/gms/analytics/GoogleAnalytics
    //   12: dup
    //   13: aload_0
    //   14: invokespecial <init> : (Landroid/content/Context;)V
    //   17: putstatic com/google/android/gms/analytics/GoogleAnalytics.Bs : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   20: getstatic com/google/android/gms/analytics/GoogleAnalytics.Bs : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   23: astore_0
    //   24: ldc com/google/android/gms/analytics/GoogleAnalytics
    //   26: monitorexit
    //   27: aload_0
    //   28: areturn
    //   29: astore_0
    //   30: ldc com/google/android/gms/analytics/GoogleAnalytics
    //   32: monitorexit
    //   33: aload_0
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   3	20	29	finally
    //   20	27	29	finally
    //   30	33	29	finally
  }
  
  void a(a parama) {
    this.Bq.add(parama);
    if (this.mContext instanceof Application)
      enableAutoActivityReports((Application)this.mContext); 
  }
  
  void a(aa paramaa) {
    ae.V("Loading global config values.");
    if (paramaa.eO()) {
      this.ya = paramaa.eP();
      ae.V("app name loaded: " + this.ya);
    } 
    if (paramaa.eQ()) {
      this.yb = paramaa.eR();
      ae.V("app version loaded: " + this.yb);
    } 
    if (paramaa.eS()) {
      int i = ai(paramaa.eT());
      if (i >= 0) {
        ae.V("log level loaded: " + i);
        getLogger().setLogLevel(i);
      } 
    } 
    if (paramaa.eU())
      this.Bn.setLocalDispatchPeriod(paramaa.eV()); 
    if (paramaa.eW())
      setDryRun(paramaa.eX()); 
  }
  
  void b(a parama) {
    this.Bq.remove(parama);
  }
  
  void dY() {
    this.yV.dY();
  }
  
  @Deprecated
  public void dispatchLocalHits() {
    this.Bn.dispatchLocalHits();
  }
  
  public void enableAutoActivityReports(Application paramApplication) {
    if (Build.VERSION.SDK_INT >= 14 && !this.Br) {
      paramApplication.registerActivityLifecycleCallbacks(new b(this));
      this.Br = true;
    } 
  }
  
  void g(Activity paramActivity) {
    Iterator<a> iterator = this.Bq.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).i(paramActivity); 
  }
  
  public boolean getAppOptOut() {
    y.eK().a(y.a.AN);
    return this.Bo.booleanValue();
  }
  
  public Logger getLogger() {
    return this.Bp;
  }
  
  void h(Activity paramActivity) {
    Iterator<a> iterator = this.Bq.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).j(paramActivity); 
  }
  
  public boolean isDryRunEnabled() {
    y.eK().a(y.a.AZ);
    return this.yt;
  }
  
  public Tracker newTracker(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic eK : ()Lcom/google/android/gms/analytics/y;
    //   5: getstatic com/google/android/gms/analytics/y$a.AJ : Lcom/google/android/gms/analytics/y$a;
    //   8: invokevirtual a : (Lcom/google/android/gms/analytics/y$a;)V
    //   11: new com/google/android/gms/analytics/Tracker
    //   14: dup
    //   15: aconst_null
    //   16: aload_0
    //   17: aload_0
    //   18: getfield mContext : Landroid/content/Context;
    //   21: invokespecial <init> : (Ljava/lang/String;Lcom/google/android/gms/analytics/TrackerHandler;Landroid/content/Context;)V
    //   24: astore_2
    //   25: iload_1
    //   26: ifle -> 57
    //   29: new com/google/android/gms/analytics/al
    //   32: dup
    //   33: aload_0
    //   34: getfield mContext : Landroid/content/Context;
    //   37: invokespecial <init> : (Landroid/content/Context;)V
    //   40: iload_1
    //   41: invokevirtual x : (I)Lcom/google/android/gms/analytics/m;
    //   44: checkcast com/google/android/gms/analytics/am
    //   47: astore_3
    //   48: aload_3
    //   49: ifnull -> 57
    //   52: aload_2
    //   53: aload_3
    //   54: invokevirtual a : (Lcom/google/android/gms/analytics/am;)V
    //   57: aload_0
    //   58: aload_2
    //   59: invokespecial a : (Lcom/google/android/gms/analytics/Tracker;)Lcom/google/android/gms/analytics/Tracker;
    //   62: astore_2
    //   63: aload_0
    //   64: monitorexit
    //   65: aload_2
    //   66: areturn
    //   67: astore_2
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_2
    //   71: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	67	finally
    //   29	48	67	finally
    //   52	57	67	finally
    //   57	65	67	finally
    //   68	70	67	finally
  }
  
  public Tracker newTracker(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic eK : ()Lcom/google/android/gms/analytics/y;
    //   5: getstatic com/google/android/gms/analytics/y$a.AJ : Lcom/google/android/gms/analytics/y$a;
    //   8: invokevirtual a : (Lcom/google/android/gms/analytics/y$a;)V
    //   11: aload_0
    //   12: new com/google/android/gms/analytics/Tracker
    //   15: dup
    //   16: aload_1
    //   17: aload_0
    //   18: aload_0
    //   19: getfield mContext : Landroid/content/Context;
    //   22: invokespecial <init> : (Ljava/lang/String;Lcom/google/android/gms/analytics/TrackerHandler;Landroid/content/Context;)V
    //   25: invokespecial a : (Lcom/google/android/gms/analytics/Tracker;)Lcom/google/android/gms/analytics/Tracker;
    //   28: astore_1
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_1
    //   32: areturn
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	33	finally
    //   34	36	33	finally
  }
  
  public void reportActivityStart(Activity paramActivity) {
    if (!this.Br)
      g(paramActivity); 
  }
  
  public void reportActivityStop(Activity paramActivity) {
    if (!this.Br)
      h(paramActivity); 
  }
  
  public void setAppOptOut(boolean paramBoolean) {
    y.eK().a(y.a.AM);
    this.Bo = Boolean.valueOf(paramBoolean);
    if (this.Bo.booleanValue())
      this.yV.dQ(); 
  }
  
  public void setDryRun(boolean paramBoolean) {
    y.eK().a(y.a.AY);
    this.yt = paramBoolean;
  }
  
  @Deprecated
  public void setLocalDispatchPeriod(int paramInt) {
    this.Bn.setLocalDispatchPeriod(paramInt);
  }
  
  public void setLogger(Logger paramLogger) {
    y.eK().a(y.a.Ba);
    this.Bp = paramLogger;
  }
  
  void u(Map<String, String> paramMap) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 22
    //   6: new java/lang/IllegalArgumentException
    //   9: dup
    //   10: ldc_w 'hit cannot be null'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: athrow
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    //   22: aload_1
    //   23: ldc_w '&ul'
    //   26: invokestatic getDefault : ()Ljava/util/Locale;
    //   29: invokestatic a : (Ljava/util/Locale;)Ljava/lang/String;
    //   32: invokestatic a : (Ljava/util/Map;Ljava/lang/String;Ljava/lang/String;)V
    //   35: aload_1
    //   36: ldc_w '&sr'
    //   39: invokestatic fl : ()Lcom/google/android/gms/analytics/ai;
    //   42: invokestatic a : (Ljava/util/Map;Ljava/lang/String;Lcom/google/android/gms/analytics/q;)V
    //   45: aload_1
    //   46: ldc_w '&_u'
    //   49: invokestatic eK : ()Lcom/google/android/gms/analytics/y;
    //   52: invokevirtual eM : ()Ljava/lang/String;
    //   55: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   60: pop
    //   61: invokestatic eK : ()Lcom/google/android/gms/analytics/y;
    //   64: invokevirtual eL : ()Ljava/lang/String;
    //   67: pop
    //   68: aload_0
    //   69: getfield yV : Lcom/google/android/gms/analytics/f;
    //   72: aload_1
    //   73: invokeinterface u : (Ljava/util/Map;)V
    //   78: aload_0
    //   79: monitorexit
    //   80: return
    // Exception table:
    //   from	to	target	type
    //   6	17	17	finally
    //   18	20	17	finally
    //   22	80	17	finally
  }
  
  static interface a {
    void i(Activity param1Activity);
    
    void j(Activity param1Activity);
  }
  
  class b implements Application.ActivityLifecycleCallbacks {
    b(GoogleAnalytics this$0) {}
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityDestroyed(Activity param1Activity) {}
    
    public void onActivityPaused(Activity param1Activity) {}
    
    public void onActivityResumed(Activity param1Activity) {}
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {
      this.Bt.g(param1Activity);
    }
    
    public void onActivityStopped(Activity param1Activity) {
      this.Bt.h(param1Activity);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\GoogleAnalytics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */