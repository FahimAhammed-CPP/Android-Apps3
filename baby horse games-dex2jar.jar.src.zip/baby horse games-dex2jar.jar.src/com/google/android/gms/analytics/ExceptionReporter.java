package com.google.android.gms.analytics;

import android.content.Context;
import java.util.ArrayList;

public class ExceptionReporter implements Thread.UncaughtExceptionHandler {
  private final Context mContext;
  
  private final Thread.UncaughtExceptionHandler yN;
  
  private final Tracker yO;
  
  private ExceptionParser yP;
  
  private GoogleAnalytics yQ;
  
  public ExceptionReporter(Tracker paramTracker, Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler, Context paramContext) {
    String str;
    if (paramTracker == null)
      throw new NullPointerException("tracker cannot be null"); 
    if (paramContext == null)
      throw new NullPointerException("context cannot be null"); 
    this.yN = paramUncaughtExceptionHandler;
    this.yO = paramTracker;
    this.yP = new StandardExceptionParser(paramContext, new ArrayList<String>());
    this.mContext = paramContext.getApplicationContext();
    StringBuilder stringBuilder = (new StringBuilder()).append("ExceptionReporter created, original handler is ");
    if (paramUncaughtExceptionHandler == null) {
      str = "null";
    } else {
      str = paramUncaughtExceptionHandler.getClass().getName();
    } 
    ae.V(stringBuilder.append(str).toString());
  }
  
  GoogleAnalytics es() {
    if (this.yQ == null)
      this.yQ = GoogleAnalytics.getInstance(this.mContext); 
    return this.yQ;
  }
  
  Thread.UncaughtExceptionHandler et() {
    return this.yN;
  }
  
  public ExceptionParser getExceptionParser() {
    return this.yP;
  }
  
  public void setExceptionParser(ExceptionParser paramExceptionParser) {
    this.yP = paramExceptionParser;
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    String str = "UncaughtException";
    if (this.yP != null) {
      if (paramThread != null) {
        str = paramThread.getName();
      } else {
        str = null;
      } 
      str = this.yP.getDescription(str, paramThrowable);
    } 
    ae.V("Tracking Exception: " + str);
    this.yO.send((new HitBuilders.ExceptionBuilder()).setDescription(str).setFatal(true).build());
    GoogleAnalytics googleAnalytics = es();
    googleAnalytics.dispatchLocalHits();
    googleAnalytics.dY();
    if (this.yN != null) {
      ae.V("Passing exception to original handler.");
      this.yN.uncaughtException(paramThread, paramThrowable);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\ExceptionReporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */