package com.google.android.gms.analytics;

import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class ac {
  public static String a(ab paramab, long paramLong) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramab.fa());
    if (paramab.fc() > 0L) {
      paramLong -= paramab.fc();
      if (paramLong >= 0L)
        stringBuilder.append("&qt").append("=").append(paramLong); 
    } 
    stringBuilder.append("&z").append("=").append(paramab.fb());
    return stringBuilder.toString();
  }
  
  public static String encode(String paramString) {
    try {
      return URLEncoder.encode(paramString, "UTF-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new AssertionError("URL encoding failed for: " + paramString);
    } 
  }
  
  static Map<String, String> z(Map<String, String> paramMap) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      if (((String)entry.getKey()).startsWith("&") && entry.getValue() != null) {
        String str = ((String)entry.getKey()).substring(1);
        if (!TextUtils.isEmpty(str))
          hashMap.put(str, entry.getValue()); 
      } 
    } 
    return (Map)hashMap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\analytics\ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */