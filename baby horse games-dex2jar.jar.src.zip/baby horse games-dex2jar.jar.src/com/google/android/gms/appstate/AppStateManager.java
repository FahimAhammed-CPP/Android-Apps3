package com.google.android.gms.appstate;

import android.content.Context;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.ib;
import com.google.android.gms.internal.jg;
import com.google.android.gms.internal.jx;

@Deprecated
public final class AppStateManager {
  public static final Api<Api.ApiOptions.NoOptions> API;
  
  static final Api.c<ib> DQ = new Api.c();
  
  private static final Api.b<ib, Api.ApiOptions.NoOptions> DR = new Api.b<ib, Api.ApiOptions.NoOptions>() {
      public ib b(Context param1Context, Looper param1Looper, jg param1jg, Api.ApiOptions.NoOptions param1NoOptions, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
        return new ib(param1Context, param1Looper, param1ConnectionCallbacks, param1OnConnectionFailedListener, param1jg.hm(), (String[])param1jg.ho().toArray((Object[])new String[0]));
      }
      
      public int getPriority() {
        return Integer.MAX_VALUE;
      }
    };
  
  public static final Scope SCOPE_APP_STATE = new Scope("https://www.googleapis.com/auth/appstate");
  
  static {
    API = new Api(DR, DQ, new Scope[] { SCOPE_APP_STATE });
  }
  
  public static ib a(GoogleApiClient paramGoogleApiClient) {
    boolean bool2 = true;
    if (paramGoogleApiClient != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    jx.b(bool1, "GoogleApiClient parameter is required.");
    jx.a(paramGoogleApiClient.isConnected(), "GoogleApiClient must be connected.");
    ib ib = (ib)paramGoogleApiClient.a(DQ);
    if (ib != null) {
      bool1 = bool2;
      jx.a(bool1, "GoogleApiClient is not configured to use the AppState API. Pass AppStateManager.API into GoogleApiClient.Builder#addApi() to use this feature.");
      return ib;
    } 
    boolean bool1 = false;
    jx.a(bool1, "GoogleApiClient is not configured to use the AppState API. Pass AppStateManager.API into GoogleApiClient.Builder#addApi() to use this feature.");
    return ib;
  }
  
  private static StateResult d(Status paramStatus) {
    return new StateResult(paramStatus) {
        public AppStateManager.StateConflictResult getConflictResult() {
          return null;
        }
        
        public AppStateManager.StateLoadedResult getLoadedResult() {
          return null;
        }
        
        public Status getStatus() {
          return this.DS;
        }
        
        public void release() {}
      };
  }
  
  public static PendingResult<StateDeletedResult> delete(GoogleApiClient paramGoogleApiClient, int paramInt) {
    return (PendingResult<StateDeletedResult>)paramGoogleApiClient.b(new b(paramGoogleApiClient, paramInt) {
          protected void a(ib param1ib) {
            param1ib.a((BaseImplementation.b)this, this.DT);
          }
          
          public AppStateManager.StateDeletedResult f(Status param1Status) {
            return new AppStateManager.StateDeletedResult(this, param1Status) {
                public int getStateKey() {
                  return this.DV.DT;
                }
                
                public Status getStatus() {
                  return this.DS;
                }
              };
          }
        });
  }
  
  public static int getMaxNumKeys(GoogleApiClient paramGoogleApiClient) {
    return a(paramGoogleApiClient).fM();
  }
  
  public static int getMaxStateSize(GoogleApiClient paramGoogleApiClient) {
    return a(paramGoogleApiClient).fL();
  }
  
  public static PendingResult<StateListResult> list(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<StateListResult>)paramGoogleApiClient.a(new c(paramGoogleApiClient) {
          protected void a(ib param1ib) {
            param1ib.a((BaseImplementation.b)this);
          }
        });
  }
  
  public static PendingResult<StateResult> load(GoogleApiClient paramGoogleApiClient, int paramInt) {
    return (PendingResult<StateResult>)paramGoogleApiClient.a(new e(paramGoogleApiClient, paramInt) {
          protected void a(ib param1ib) {
            param1ib.b((BaseImplementation.b)this, this.DT);
          }
        });
  }
  
  public static PendingResult<StateResult> resolve(GoogleApiClient paramGoogleApiClient, int paramInt, String paramString, byte[] paramArrayOfbyte) {
    return (PendingResult<StateResult>)paramGoogleApiClient.b(new e(paramGoogleApiClient, paramInt, paramString, paramArrayOfbyte) {
          protected void a(ib param1ib) {
            param1ib.a((BaseImplementation.b)this, this.DT, this.DW, this.DX);
          }
        });
  }
  
  public static PendingResult<Status> signOut(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<Status>)paramGoogleApiClient.b(new d(paramGoogleApiClient) {
          protected void a(ib param1ib) {
            param1ib.b((BaseImplementation.b)this);
          }
        });
  }
  
  public static void update(GoogleApiClient paramGoogleApiClient, int paramInt, byte[] paramArrayOfbyte) {
    paramGoogleApiClient.b(new e(paramGoogleApiClient, paramInt, paramArrayOfbyte) {
          protected void a(ib param1ib) {
            param1ib.a(null, this.DT, this.DU);
          }
        });
  }
  
  public static PendingResult<StateResult> updateImmediate(GoogleApiClient paramGoogleApiClient, int paramInt, byte[] paramArrayOfbyte) {
    return (PendingResult<StateResult>)paramGoogleApiClient.b(new e(paramGoogleApiClient, paramInt, paramArrayOfbyte) {
          protected void a(ib param1ib) {
            param1ib.a((BaseImplementation.b)this, this.DT, this.DU);
          }
        });
  }
  
  public static interface StateConflictResult extends Releasable, Result {
    byte[] getLocalData();
    
    String getResolvedVersion();
    
    byte[] getServerData();
    
    int getStateKey();
  }
  
  public static interface StateDeletedResult extends Result {
    int getStateKey();
  }
  
  public static interface StateListResult extends Result {
    AppStateBuffer getStateBuffer();
  }
  
  public static interface StateLoadedResult extends Releasable, Result {
    byte[] getLocalData();
    
    int getStateKey();
  }
  
  public static interface StateResult extends Releasable, Result {
    AppStateManager.StateConflictResult getConflictResult();
    
    AppStateManager.StateLoadedResult getLoadedResult();
  }
  
  public static abstract class a<R extends Result> extends BaseImplementation.a<R, ib> {
    public a(GoogleApiClient param1GoogleApiClient) {
      super(AppStateManager.DQ, param1GoogleApiClient);
    }
  }
  
  private static abstract class b extends a<StateDeletedResult> {
    b(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
  }
  
  private static abstract class c extends a<StateListResult> {
    public c(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public AppStateManager.StateListResult g(Status param1Status) {
      return new AppStateManager.StateListResult(this, param1Status) {
          public AppStateBuffer getStateBuffer() {
            return new AppStateBuffer(null);
          }
          
          public Status getStatus() {
            return this.DS;
          }
        };
    }
  }
  
  class null implements StateListResult {
    null(AppStateManager this$0, Status param1Status) {}
    
    public AppStateBuffer getStateBuffer() {
      return new AppStateBuffer(null);
    }
    
    public Status getStatus() {
      return this.DS;
    }
  }
  
  private static abstract class d extends a<Status> {
    public d(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public Status b(Status param1Status) {
      return param1Status;
    }
  }
  
  private static abstract class e extends a<StateResult> {
    public e(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public AppStateManager.StateResult h(Status param1Status) {
      return AppStateManager.e(param1Status);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\appstate\AppStateManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */