package com.google.android.gms.appindexing;

import android.net.Uri;
import android.text.TextUtils;
import com.google.android.gms.internal.jv;
import java.util.Iterator;
import java.util.List;

public final class AndroidAppUri {
  private final Uri mUri;
  
  private AndroidAppUri(Uri paramUri) {
    this.mUri = paramUri;
  }
  
  private static boolean a(AndroidAppUri paramAndroidAppUri) {
    if (!"android-app".equals(paramAndroidAppUri.mUri.getScheme()))
      throw new IllegalArgumentException("android-app scheme is required."); 
    if (TextUtils.isEmpty(paramAndroidAppUri.getPackageName()))
      throw new IllegalArgumentException("Package name is empty."); 
    Uri uri = newAndroidAppUri(paramAndroidAppUri.getPackageName(), paramAndroidAppUri.getDeepLinkUri()).toUri();
    if (!paramAndroidAppUri.mUri.equals(uri))
      throw new IllegalArgumentException("URI is not canonical."); 
    return true;
  }
  
  public static AndroidAppUri newAndroidAppUri(Uri paramUri) {
    AndroidAppUri androidAppUri = new AndroidAppUri(paramUri);
    if (a(androidAppUri))
      return androidAppUri; 
    throw new IllegalArgumentException("AndroidAppUri validation failed.");
  }
  
  public static AndroidAppUri newAndroidAppUri(String paramString, Uri paramUri) {
    Uri.Builder builder = (new Uri.Builder()).scheme("android-app").authority(paramString);
    if (paramUri != null) {
      builder.appendPath(paramUri.getScheme());
      if (paramUri.getAuthority() != null)
        builder.appendPath(paramUri.getAuthority()); 
      Iterator<String> iterator = paramUri.getPathSegments().iterator();
      while (iterator.hasNext())
        builder.appendPath(iterator.next()); 
      builder.encodedQuery(paramUri.getEncodedQuery()).encodedFragment(paramUri.getEncodedFragment());
    } 
    return new AndroidAppUri(builder.build());
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof AndroidAppUri) ? this.mUri.equals(((AndroidAppUri)paramObject).mUri) : false;
  }
  
  public Uri getDeepLinkUri() {
    List<String> list = this.mUri.getPathSegments();
    if (list.size() > 0) {
      String str = list.get(0);
      Uri.Builder builder = new Uri.Builder();
      builder.scheme(str);
      if (list.size() > 1) {
        builder.authority(list.get(1));
        for (int i = 2; i < list.size(); i++)
          builder.appendPath(list.get(i)); 
      } 
      builder.encodedQuery(this.mUri.getEncodedQuery());
      builder.encodedFragment(this.mUri.getEncodedFragment());
      return builder.build();
    } 
    return null;
  }
  
  public String getPackageName() {
    return this.mUri.getAuthority();
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { this.mUri });
  }
  
  public String toString() {
    return this.mUri.toString();
  }
  
  public Uri toUri() {
    return this.mUri;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\appindexing\AndroidAppUri.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */