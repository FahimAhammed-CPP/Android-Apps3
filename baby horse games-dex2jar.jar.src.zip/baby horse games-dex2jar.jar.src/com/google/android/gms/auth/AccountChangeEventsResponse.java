package com.google.android.gms.auth;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.jx;
import java.util.List;

public class AccountChangeEventsResponse implements SafeParcelable {
  public static final AccountChangeEventsResponseCreator CREATOR = new AccountChangeEventsResponseCreator();
  
  final int Ef;
  
  final List<AccountChangeEvent> mp;
  
  AccountChangeEventsResponse(int paramInt, List<AccountChangeEvent> paramList) {
    this.Ef = paramInt;
    this.mp = (List<AccountChangeEvent>)jx.i(paramList);
  }
  
  public AccountChangeEventsResponse(List<AccountChangeEvent> paramList) {
    this.Ef = 1;
    this.mp = (List<AccountChangeEvent>)jx.i(paramList);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public List<AccountChangeEvent> getEvents() {
    return this.mp;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    AccountChangeEventsResponseCreator.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\auth\AccountChangeEventsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */