package com.google.android.gms.auth;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.jv;
import com.google.android.gms.internal.jx;

public class AccountChangeEvent implements SafeParcelable {
  public static final AccountChangeEventCreator CREATOR = new AccountChangeEventCreator();
  
  final String DZ;
  
  final int Ef;
  
  final long Eg;
  
  final int Eh;
  
  final int Ei;
  
  final String Ej;
  
  AccountChangeEvent(int paramInt1, long paramLong, String paramString1, int paramInt2, int paramInt3, String paramString2) {
    this.Ef = paramInt1;
    this.Eg = paramLong;
    this.DZ = (String)jx.i(paramString1);
    this.Eh = paramInt2;
    this.Ei = paramInt3;
    this.Ej = paramString2;
  }
  
  public AccountChangeEvent(long paramLong, String paramString1, int paramInt1, int paramInt2, String paramString2) {
    this.Ef = 1;
    this.Eg = paramLong;
    this.DZ = (String)jx.i(paramString1);
    this.Eh = paramInt1;
    this.Ei = paramInt2;
    this.Ej = paramString2;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (paramObject instanceof AccountChangeEvent) {
        paramObject = paramObject;
        return !(this.Ef != ((AccountChangeEvent)paramObject).Ef || this.Eg != ((AccountChangeEvent)paramObject).Eg || !jv.equal(this.DZ, ((AccountChangeEvent)paramObject).DZ) || this.Eh != ((AccountChangeEvent)paramObject).Eh || this.Ei != ((AccountChangeEvent)paramObject).Ei || !jv.equal(this.Ej, ((AccountChangeEvent)paramObject).Ej));
      } 
      return false;
    } 
    return true;
  }
  
  public String getAccountName() {
    return this.DZ;
  }
  
  public String getChangeData() {
    return this.Ej;
  }
  
  public int getChangeType() {
    return this.Eh;
  }
  
  public int getEventIndex() {
    return this.Ei;
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { Integer.valueOf(this.Ef), Long.valueOf(this.Eg), this.DZ, Integer.valueOf(this.Eh), Integer.valueOf(this.Ei), this.Ej });
  }
  
  public String toString() {
    String str = "UNKNOWN";
    switch (this.Eh) {
      default:
        return "AccountChangeEvent {accountName = " + this.DZ + ", changeType = " + str + ", changeData = " + this.Ej + ", eventIndex = " + this.Ei + "}";
      case 1:
        str = "ADDED";
      case 2:
        str = "REMOVED";
      case 4:
        str = "RENAMED_TO";
      case 3:
        break;
    } 
    str = "RENAMED_FROM";
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    AccountChangeEventCreator.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\auth\AccountChangeEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */