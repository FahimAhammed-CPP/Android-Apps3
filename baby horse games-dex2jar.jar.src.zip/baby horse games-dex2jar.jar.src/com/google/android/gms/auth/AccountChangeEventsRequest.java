package com.google.android.gms.auth;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class AccountChangeEventsRequest implements SafeParcelable {
  public static final AccountChangeEventsRequestCreator CREATOR = new AccountChangeEventsRequestCreator();
  
  String DZ;
  
  final int Ef = 1;
  
  int Ei;
  
  public AccountChangeEventsRequest() {}
  
  AccountChangeEventsRequest(int paramInt1, int paramInt2, String paramString) {
    this.Ei = paramInt2;
    this.DZ = paramString;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String getAccountName() {
    return this.DZ;
  }
  
  public int getEventIndex() {
    return this.Ei;
  }
  
  public AccountChangeEventsRequest setAccountName(String paramString) {
    this.DZ = paramString;
    return this;
  }
  
  public AccountChangeEventsRequest setEventIndex(int paramInt) {
    this.Ei = paramInt;
    return this;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    AccountChangeEventsRequestCreator.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\auth\AccountChangeEventsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */