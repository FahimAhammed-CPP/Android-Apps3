package com.google.android.gms.auth;

public class UserRecoverableNotifiedException extends GoogleAuthException {
  public UserRecoverableNotifiedException(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\auth\UserRecoverableNotifiedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */