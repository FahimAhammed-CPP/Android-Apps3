package com.google.android.gms.drive.events;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.drive.internal.OnEventResponse;
import com.google.android.gms.drive.internal.ag;
import com.google.android.gms.drive.internal.w;
import java.util.concurrent.CountDownLatch;

public abstract class DriveEventService extends Service implements ChangeListener, CompletionListener {
  public static final String ACTION_HANDLE_EVENT = "com.google.android.gms.drive.events.HANDLE_EVENT";
  
  private CountDownLatch Pg;
  
  a Ph;
  
  boolean Pi = false;
  
  int Pj = -1;
  
  private final String mName;
  
  protected DriveEventService() {
    this("DriveEventService");
  }
  
  protected DriveEventService(String paramString) {
    this.mName = paramString;
  }
  
  private void a(OnEventResponse paramOnEventResponse) {
    DriveEvent driveEvent = paramOnEventResponse.iQ();
    w.m("DriveEventService", "handleEventMessage: " + driveEvent);
    try {
      switch (driveEvent.getType()) {
        case 1:
          onChange((ChangeEvent)driveEvent);
          return;
        case 2:
          onCompletion((CompletionEvent)driveEvent);
          return;
      } 
      w.o(this.mName, "Unhandled event: " + driveEvent);
      return;
    } catch (Exception exception) {
      w.a(this.mName, exception, "Error handling event: " + driveEvent);
      return;
    } 
  }
  
  private boolean bh(int paramInt) {
    boolean bool2 = false;
    String[] arrayOfString = getPackageManager().getPackagesForUid(paramInt);
    boolean bool1 = bool2;
    if (arrayOfString != null) {
      int i = arrayOfString.length;
      for (paramInt = 0;; paramInt++) {
        bool1 = bool2;
        if (paramInt < i) {
          if ("com.google.android.gms".equals(arrayOfString[paramInt]))
            return true; 
        } else {
          return bool1;
        } 
      } 
    } 
    return bool1;
  }
  
  private void iD() throws SecurityException {
    int i = getCallingUid();
    if (i == this.Pj)
      return; 
    if (GooglePlayServicesUtil.b(getPackageManager(), "com.google.android.gms") && bh(i)) {
      this.Pj = i;
      return;
    } 
    throw new SecurityException("Caller is not GooglePlayServices");
  }
  
  protected int getCallingUid() {
    return Binder.getCallingUid();
  }
  
  public final IBinder onBind(Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc 'com.google.android.gms.drive.events.HANDLE_EVENT'
    //   4: aload_1
    //   5: invokevirtual getAction : ()Ljava/lang/String;
    //   8: invokevirtual equals : (Ljava/lang/Object;)Z
    //   11: ifeq -> 119
    //   14: aload_0
    //   15: getfield Ph : Lcom/google/android/gms/drive/events/DriveEventService$a;
    //   18: ifnonnull -> 86
    //   21: aload_0
    //   22: getfield Pi : Z
    //   25: ifne -> 86
    //   28: aload_0
    //   29: iconst_1
    //   30: putfield Pi : Z
    //   33: new java/util/concurrent/CountDownLatch
    //   36: dup
    //   37: iconst_1
    //   38: invokespecial <init> : (I)V
    //   41: astore_1
    //   42: aload_0
    //   43: new java/util/concurrent/CountDownLatch
    //   46: dup
    //   47: iconst_1
    //   48: invokespecial <init> : (I)V
    //   51: putfield Pg : Ljava/util/concurrent/CountDownLatch;
    //   54: new com/google/android/gms/drive/events/DriveEventService$1
    //   57: dup
    //   58: aload_0
    //   59: aload_1
    //   60: invokespecial <init> : (Lcom/google/android/gms/drive/events/DriveEventService;Ljava/util/concurrent/CountDownLatch;)V
    //   63: invokevirtual start : ()V
    //   66: aload_1
    //   67: ldc2_w 5000
    //   70: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   73: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
    //   76: ifne -> 86
    //   79: ldc 'DriveEventService'
    //   81: ldc 'Failed to synchronously initialize event handler.'
    //   83: invokestatic p : (Ljava/lang/String;Ljava/lang/String;)V
    //   86: new com/google/android/gms/drive/events/DriveEventService$b
    //   89: dup
    //   90: aload_0
    //   91: invokespecial <init> : (Lcom/google/android/gms/drive/events/DriveEventService;)V
    //   94: invokevirtual asBinder : ()Landroid/os/IBinder;
    //   97: astore_1
    //   98: aload_0
    //   99: monitorexit
    //   100: aload_1
    //   101: areturn
    //   102: astore_1
    //   103: new java/lang/RuntimeException
    //   106: dup
    //   107: ldc 'Unable to start event handler'
    //   109: aload_1
    //   110: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   113: athrow
    //   114: astore_1
    //   115: aload_0
    //   116: monitorexit
    //   117: aload_1
    //   118: athrow
    //   119: aconst_null
    //   120: astore_1
    //   121: goto -> 98
    // Exception table:
    //   from	to	target	type
    //   2	66	114	finally
    //   66	86	102	java/lang/InterruptedException
    //   66	86	114	finally
    //   86	98	114	finally
    //   103	114	114	finally
  }
  
  public void onChange(ChangeEvent paramChangeEvent) {
    w.o(this.mName, "Unhandled change event: " + paramChangeEvent);
  }
  
  public void onCompletion(CompletionEvent paramCompletionEvent) {
    w.o(this.mName, "Unhandled completion event: " + paramCompletionEvent);
  }
  
  public void onDestroy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc 'DriveEventService'
    //   4: ldc 'onDestroy'
    //   6: invokestatic m : (Ljava/lang/String;Ljava/lang/String;)V
    //   9: aload_0
    //   10: getfield Ph : Lcom/google/android/gms/drive/events/DriveEventService$a;
    //   13: ifnull -> 66
    //   16: aload_0
    //   17: getfield Ph : Lcom/google/android/gms/drive/events/DriveEventService$a;
    //   20: invokestatic a : (Lcom/google/android/gms/drive/events/DriveEventService$a;)Landroid/os/Message;
    //   23: astore_1
    //   24: aload_0
    //   25: getfield Ph : Lcom/google/android/gms/drive/events/DriveEventService$a;
    //   28: aload_1
    //   29: invokevirtual sendMessage : (Landroid/os/Message;)Z
    //   32: pop
    //   33: aload_0
    //   34: aconst_null
    //   35: putfield Ph : Lcom/google/android/gms/drive/events/DriveEventService$a;
    //   38: aload_0
    //   39: getfield Pg : Ljava/util/concurrent/CountDownLatch;
    //   42: ldc2_w 5000
    //   45: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   48: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
    //   51: ifne -> 61
    //   54: ldc 'DriveEventService'
    //   56: ldc 'Failed to synchronously quit event handler. Will quit itself'
    //   58: invokestatic o : (Ljava/lang/String;Ljava/lang/String;)V
    //   61: aload_0
    //   62: aconst_null
    //   63: putfield Pg : Ljava/util/concurrent/CountDownLatch;
    //   66: aload_0
    //   67: invokespecial onDestroy : ()V
    //   70: aload_0
    //   71: monitorexit
    //   72: return
    //   73: astore_1
    //   74: aload_0
    //   75: monitorexit
    //   76: aload_1
    //   77: athrow
    //   78: astore_1
    //   79: goto -> 61
    // Exception table:
    //   from	to	target	type
    //   2	38	73	finally
    //   38	61	78	java/lang/InterruptedException
    //   38	61	73	finally
    //   61	66	73	finally
    //   66	70	73	finally
  }
  
  public boolean onUnbind(Intent paramIntent) {
    return true;
  }
  
  final class a extends Handler {
    a(DriveEventService this$0) {}
    
    private Message b(OnEventResponse param1OnEventResponse) {
      return obtainMessage(1, param1OnEventResponse);
    }
    
    private Message iE() {
      return obtainMessage(2);
    }
    
    public void handleMessage(Message param1Message) {
      w.m("DriveEventService", "handleMessage message type:" + param1Message.what);
      switch (param1Message.what) {
        default:
          w.o("DriveEventService", "Unexpected message type:" + param1Message.what);
          return;
        case 1:
          DriveEventService.a(this.Pl, (OnEventResponse)param1Message.obj);
          return;
        case 2:
          break;
      } 
      getLooper().quit();
    }
  }
  
  final class b extends ag.a {
    b(DriveEventService this$0) {}
    
    public void c(OnEventResponse param1OnEventResponse) throws RemoteException {
      synchronized (this.Pl) {
        w.m("DriveEventService", "onEvent: " + param1OnEventResponse);
        DriveEventService.a(this.Pl);
        if (this.Pl.Ph != null) {
          Message message = DriveEventService.a.a(this.Pl.Ph, param1OnEventResponse);
          this.Pl.Ph.sendMessage(message);
        } else {
          w.p("DriveEventService", "Receiving event before initialize is completed.");
        } 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\events\DriveEventService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */