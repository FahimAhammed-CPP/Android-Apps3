package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import java.util.ArrayList;

public class b implements Parcelable.Creator<CompletionEvent> {
  static void a(CompletionEvent paramCompletionEvent, Parcel paramParcel, int paramInt) {
    int i = com.google.android.gms.common.internal.safeparcel.b.H(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, paramCompletionEvent.CK);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 2, (Parcelable)paramCompletionEvent.Oj, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 3, paramCompletionEvent.DZ, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 4, (Parcelable)paramCompletionEvent.OY, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 5, (Parcelable)paramCompletionEvent.OZ, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 6, (Parcelable)paramCompletionEvent.Pa, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.b(paramParcel, 7, paramCompletionEvent.Pb, false);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 8, paramCompletionEvent.FP);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 9, paramCompletionEvent.Pc, false);
    com.google.android.gms.common.internal.safeparcel.b.H(paramParcel, i);
  }
  
  public CompletionEvent Y(Parcel paramParcel) {
    int i = 0;
    IBinder iBinder = null;
    int k = a.G(paramParcel);
    ArrayList<String> arrayList = null;
    MetadataBundle metadataBundle = null;
    ParcelFileDescriptor parcelFileDescriptor1 = null;
    ParcelFileDescriptor parcelFileDescriptor2 = null;
    String str = null;
    DriveId driveId = null;
    int j = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.F(paramParcel);
      switch (a.aH(m)) {
        case 1:
          j = a.g(paramParcel, m);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, m, DriveId.CREATOR);
          break;
        case 3:
          str = a.o(paramParcel, m);
          break;
        case 4:
          parcelFileDescriptor2 = (ParcelFileDescriptor)a.a(paramParcel, m, ParcelFileDescriptor.CREATOR);
          break;
        case 5:
          parcelFileDescriptor1 = (ParcelFileDescriptor)a.a(paramParcel, m, ParcelFileDescriptor.CREATOR);
          break;
        case 6:
          metadataBundle = (MetadataBundle)a.a(paramParcel, m, MetadataBundle.CREATOR);
          break;
        case 7:
          arrayList = a.C(paramParcel, m);
          break;
        case 8:
          i = a.g(paramParcel, m);
          break;
        case 9:
          iBinder = a.p(paramParcel, m);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new CompletionEvent(j, driveId, str, parcelFileDescriptor2, parcelFileDescriptor1, metadataBundle, arrayList, i, iBinder);
  }
  
  public CompletionEvent[] bg(int paramInt) {
    return new CompletionEvent[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\events\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */