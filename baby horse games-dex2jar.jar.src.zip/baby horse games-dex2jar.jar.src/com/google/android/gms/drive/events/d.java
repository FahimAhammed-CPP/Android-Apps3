package com.google.android.gms.drive.events;

import com.google.android.gms.drive.DriveId;

public class d {
  public static boolean a(int paramInt, DriveId paramDriveId) {
    return (paramDriveId != null || bi(paramInt));
  }
  
  public static boolean bi(int paramInt) {
    return ((0x2L & (1 << paramInt)) != 0L);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\events\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */