package com.google.android.gms.drive.events;

import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.internal.ah;
import com.google.android.gms.drive.internal.w;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.lh;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class CompletionEvent implements SafeParcelable, ResourceEvent {
  public static final Parcelable.Creator<CompletionEvent> CREATOR = new b();
  
  public static final int STATUS_CANCELED = 3;
  
  public static final int STATUS_CONFLICT = 2;
  
  public static final int STATUS_FAILURE = 1;
  
  public static final int STATUS_SUCCESS = 0;
  
  final int CK;
  
  final String DZ;
  
  final int FP;
  
  final ParcelFileDescriptor OY;
  
  final ParcelFileDescriptor OZ;
  
  final DriveId Oj;
  
  final MetadataBundle Pa;
  
  final List<String> Pb;
  
  final IBinder Pc;
  
  private boolean Pd = false;
  
  private boolean Pe = false;
  
  private boolean Pf = false;
  
  CompletionEvent(int paramInt1, DriveId paramDriveId, String paramString, ParcelFileDescriptor paramParcelFileDescriptor1, ParcelFileDescriptor paramParcelFileDescriptor2, MetadataBundle paramMetadataBundle, List<String> paramList, int paramInt2, IBinder paramIBinder) {
    this.CK = paramInt1;
    this.Oj = paramDriveId;
    this.DZ = paramString;
    this.OY = paramParcelFileDescriptor1;
    this.OZ = paramParcelFileDescriptor2;
    this.Pa = paramMetadataBundle;
    this.Pb = paramList;
    this.FP = paramInt2;
    this.Pc = paramIBinder;
  }
  
  private void M(boolean paramBoolean) {
    iC();
    this.Pf = true;
    lh.a(this.OY);
    lh.a(this.OZ);
    if (this.Pc == null) {
      String str;
      StringBuilder stringBuilder = (new StringBuilder()).append("No callback on ");
      if (paramBoolean) {
        str = "snooze";
      } else {
        str = "dismiss";
      } 
      w.p("CompletionEvent", stringBuilder.append(str).toString());
      return;
    } 
    try {
      ah.a.aa(this.Pc).M(paramBoolean);
      return;
    } catch (RemoteException remoteException) {
      String str;
      StringBuilder stringBuilder = (new StringBuilder()).append("RemoteException on ");
      if (paramBoolean) {
        str = "snooze";
      } else {
        str = "dismiss";
      } 
      w.p("CompletionEvent", stringBuilder.append(str).append(": ").append(remoteException).toString());
      return;
    } 
  }
  
  private void iC() {
    if (this.Pf)
      throw new IllegalStateException("Event has already been dismissed or snoozed."); 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void dismiss() {
    M(false);
  }
  
  public String getAccountName() {
    iC();
    return this.DZ;
  }
  
  public InputStream getBaseContentsInputStream() {
    iC();
    if (this.OY == null)
      return null; 
    if (this.Pd)
      throw new IllegalStateException("getBaseInputStream() can only be called once per CompletionEvent instance."); 
    this.Pd = true;
    return new FileInputStream(this.OY.getFileDescriptor());
  }
  
  public DriveId getDriveId() {
    iC();
    return this.Oj;
  }
  
  public InputStream getModifiedContentsInputStream() {
    iC();
    if (this.OZ == null)
      return null; 
    if (this.Pe)
      throw new IllegalStateException("getModifiedInputStream() can only be called once per CompletionEvent instance."); 
    this.Pe = true;
    return new FileInputStream(this.OZ.getFileDescriptor());
  }
  
  public MetadataChangeSet getModifiedMetadataChangeSet() {
    iC();
    return (this.Pa != null) ? new MetadataChangeSet(this.Pa) : null;
  }
  
  public int getStatus() {
    iC();
    return this.FP;
  }
  
  public List<String> getTrackingTags() {
    iC();
    return new ArrayList<String>(this.Pb);
  }
  
  public int getType() {
    return 2;
  }
  
  public void snooze() {
    M(true);
  }
  
  public String toString() {
    if (this.Pb == null) {
      String str1 = "<null>";
      return String.format(Locale.US, "CompletionEvent [id=%s, status=%s, trackingTag=%s]", new Object[] { this.Oj, Integer.valueOf(this.FP), str1 });
    } 
    String str = "'" + TextUtils.join("','", this.Pb) + "'";
    return String.format(Locale.US, "CompletionEvent [id=%s, status=%s, trackingTag=%s]", new Object[] { this.Oj, Integer.valueOf(this.FP), str });
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\events\CompletionEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */