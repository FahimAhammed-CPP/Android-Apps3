package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class g implements Parcelable.Creator<StorageStats> {
  static void a(StorageStats paramStorageStats, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramStorageStats.CK);
    b.a(paramParcel, 2, paramStorageStats.OM);
    b.a(paramParcel, 3, paramStorageStats.ON);
    b.a(paramParcel, 4, paramStorageStats.OO);
    b.a(paramParcel, 5, paramStorageStats.OP);
    b.c(paramParcel, 6, paramStorageStats.OQ);
    b.H(paramParcel, paramInt);
  }
  
  public StorageStats V(Parcel paramParcel) {
    int i = 0;
    long l1 = 0L;
    int k = a.G(paramParcel);
    long l2 = 0L;
    long l3 = 0L;
    long l4 = 0L;
    int j = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.F(paramParcel);
      switch (a.aH(m)) {
        case 1:
          j = a.g(paramParcel, m);
          break;
        case 2:
          l4 = a.i(paramParcel, m);
          break;
        case 3:
          l3 = a.i(paramParcel, m);
          break;
        case 4:
          l2 = a.i(paramParcel, m);
          break;
        case 5:
          l1 = a.i(paramParcel, m);
          break;
        case 6:
          i = a.g(paramParcel, m);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new StorageStats(j, l4, l3, l2, l1, i);
  }
  
  public StorageStats[] bd(int paramInt) {
    return new StorageStats[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */