package com.google.android.gms.drive.internal;

import com.google.android.gms.internal.qo;
import com.google.android.gms.internal.qp;
import com.google.android.gms.internal.qq;
import com.google.android.gms.internal.qv;
import com.google.android.gms.internal.qw;
import java.io.IOException;

public final class ak extends qq<ak> {
  public String QG;
  
  public long QH;
  
  public long QI;
  
  public int versionCode;
  
  public ak() {
    iK();
  }
  
  public static ak g(byte[] paramArrayOfbyte) throws qv {
    return (ak)qw.a((qw)new ak(), paramArrayOfbyte);
  }
  
  public void a(qp paramqp) throws IOException {
    paramqp.t(1, this.versionCode);
    paramqp.b(2, this.QG);
    paramqp.c(3, this.QH);
    paramqp.c(4, this.QI);
    super.a(paramqp);
  }
  
  protected int c() {
    return super.c() + qp.v(1, this.versionCode) + qp.j(2, this.QG) + qp.e(3, this.QH) + qp.e(4, this.QI);
  }
  
  public boolean equals(Object paramObject) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_1
    //   3: aload_0
    //   4: if_acmpne -> 11
    //   7: iconst_1
    //   8: istore_2
    //   9: iload_2
    //   10: ireturn
    //   11: iload_3
    //   12: istore_2
    //   13: aload_1
    //   14: instanceof com/google/android/gms/drive/internal/ak
    //   17: ifeq -> 9
    //   20: aload_1
    //   21: checkcast com/google/android/gms/drive/internal/ak
    //   24: astore_1
    //   25: iload_3
    //   26: istore_2
    //   27: aload_0
    //   28: getfield versionCode : I
    //   31: aload_1
    //   32: getfield versionCode : I
    //   35: if_icmpne -> 9
    //   38: aload_0
    //   39: getfield QG : Ljava/lang/String;
    //   42: ifnonnull -> 88
    //   45: iload_3
    //   46: istore_2
    //   47: aload_1
    //   48: getfield QG : Ljava/lang/String;
    //   51: ifnonnull -> 9
    //   54: iload_3
    //   55: istore_2
    //   56: aload_0
    //   57: getfield QH : J
    //   60: aload_1
    //   61: getfield QH : J
    //   64: lcmp
    //   65: ifne -> 9
    //   68: iload_3
    //   69: istore_2
    //   70: aload_0
    //   71: getfield QI : J
    //   74: aload_1
    //   75: getfield QI : J
    //   78: lcmp
    //   79: ifne -> 9
    //   82: aload_0
    //   83: aload_1
    //   84: invokevirtual a : (Lcom/google/android/gms/internal/qq;)Z
    //   87: ireturn
    //   88: aload_0
    //   89: getfield QG : Ljava/lang/String;
    //   92: aload_1
    //   93: getfield QG : Ljava/lang/String;
    //   96: invokevirtual equals : (Ljava/lang/Object;)Z
    //   99: ifne -> 54
    //   102: iconst_0
    //   103: ireturn
  }
  
  public int hashCode() {
    int j = this.versionCode;
    if (this.QG == null) {
      byte b = 0;
      return (((b + (j + 527) * 31) * 31 + (int)(this.QH ^ this.QH >>> 32L)) * 31 + (int)(this.QI ^ this.QI >>> 32L)) * 31 + rQ();
    } 
    int i = this.QG.hashCode();
    return (((i + (j + 527) * 31) * 31 + (int)(this.QH ^ this.QH >>> 32L)) * 31 + (int)(this.QI ^ this.QI >>> 32L)) * 31 + rQ();
  }
  
  public ak iK() {
    this.versionCode = 1;
    this.QG = "";
    this.QH = -1L;
    this.QI = -1L;
    this.ayW = null;
    this.azh = -1;
    return this;
  }
  
  public ak m(qo paramqo) throws IOException {
    while (true) {
      int i = paramqo.rz();
      switch (i) {
        case 0:
          return this;
        case 8:
          this.versionCode = paramqo.rC();
          break;
        case 18:
          this.QG = paramqo.readString();
          break;
        case 24:
          this.QH = paramqo.rF();
          break;
        case 32:
          this.QI = paramqo.rF();
          break;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\ak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */