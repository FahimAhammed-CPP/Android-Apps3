package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;

public class ba implements Parcelable.Creator<OpenFileIntentSenderRequest> {
  static void a(OpenFileIntentSenderRequest paramOpenFileIntentSenderRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramOpenFileIntentSenderRequest.CK);
    b.a(paramParcel, 2, paramOpenFileIntentSenderRequest.OH, false);
    b.a(paramParcel, 3, paramOpenFileIntentSenderRequest.OI, false);
    b.a(paramParcel, 4, (Parcelable)paramOpenFileIntentSenderRequest.OJ, paramInt, false);
    b.H(paramParcel, i);
  }
  
  public OpenFileIntentSenderRequest aE(Parcel paramParcel) {
    DriveId driveId = null;
    int j = a.G(paramParcel);
    int i = 0;
    String[] arrayOfString = null;
    String str = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          str = a.o(paramParcel, k);
          break;
        case 3:
          arrayOfString = a.A(paramParcel, k);
          break;
        case 4:
          driveId = (DriveId)a.a(paramParcel, k, DriveId.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OpenFileIntentSenderRequest(i, str, arrayOfString, driveId);
  }
  
  public OpenFileIntentSenderRequest[] bT(int paramInt) {
    return new OpenFileIntentSenderRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */