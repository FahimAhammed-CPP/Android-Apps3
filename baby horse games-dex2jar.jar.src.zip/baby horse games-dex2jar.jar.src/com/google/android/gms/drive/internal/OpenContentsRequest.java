package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class OpenContentsRequest implements SafeParcelable {
  public static final Parcelable.Creator<OpenContentsRequest> CREATOR = new ay();
  
  final int CK;
  
  final int Oi;
  
  final DriveId Pp;
  
  final int QT;
  
  OpenContentsRequest(int paramInt1, DriveId paramDriveId, int paramInt2, int paramInt3) {
    this.CK = paramInt1;
    this.Pp = paramDriveId;
    this.Oi = paramInt2;
    this.QT = paramInt3;
  }
  
  public OpenContentsRequest(DriveId paramDriveId, int paramInt1, int paramInt2) {
    this(1, paramDriveId, paramInt1, paramInt2);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ay.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\OpenContentsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */