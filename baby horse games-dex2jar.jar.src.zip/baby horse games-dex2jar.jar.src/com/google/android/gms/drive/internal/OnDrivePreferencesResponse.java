package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DrivePreferences;

public class OnDrivePreferencesResponse implements SafeParcelable {
  public static final Parcelable.Creator<OnDrivePreferencesResponse> CREATOR = new ap();
  
  final int CK;
  
  DrivePreferences QN;
  
  OnDrivePreferencesResponse(int paramInt, DrivePreferences paramDrivePreferences) {
    this.CK = paramInt;
    this.QN = paramDrivePreferences;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ap.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\OnDrivePreferencesResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */