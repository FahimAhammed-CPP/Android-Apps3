package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class GetMetadataRequest implements SafeParcelable {
  public static final Parcelable.Creator<GetMetadataRequest> CREATOR = new ad();
  
  final int CK;
  
  final DriveId Pp;
  
  GetMetadataRequest(int paramInt, DriveId paramDriveId) {
    this.CK = paramInt;
    this.Pp = paramDriveId;
  }
  
  public GetMetadataRequest(DriveId paramDriveId) {
    this(1, paramDriveId);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ad.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\GetMetadataRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */