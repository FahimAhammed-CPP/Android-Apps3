package com.google.android.gms.drive.internal;

import android.content.IntentSender;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.internal.jx;

public class i {
  private String OH;
  
  private DriveId OJ;
  
  protected MetadataChangeSet Pu;
  
  private Integer Pv;
  
  private final int Pw;
  
  public i(int paramInt) {
    this.Pw = paramInt;
  }
  
  public void a(DriveId paramDriveId) {
    this.OJ = (DriveId)jx.i(paramDriveId);
  }
  
  public void a(MetadataChangeSet paramMetadataChangeSet) {
    this.Pu = (MetadataChangeSet)jx.i(paramMetadataChangeSet);
  }
  
  public void bl(String paramString) {
    this.OH = (String)jx.i(paramString);
  }
  
  public void bq(int paramInt) {
    this.Pv = Integer.valueOf(paramInt);
  }
  
  public IntentSender build(GoogleApiClient paramGoogleApiClient) {
    int j;
    jx.b(this.Pu, "Must provide initial metadata to CreateFileActivityBuilder.");
    jx.a(paramGoogleApiClient.isConnected(), "Client must be connected");
    r r = (r)paramGoogleApiClient.a(Drive.DQ);
    this.Pu.iz().setContext(r.getContext());
    if (this.Pv == null) {
      j = -1;
    } else {
      j = this.Pv.intValue();
    } 
    try {
      return r.iG().a(new CreateFileIntentSenderRequest(this.Pu.iz(), j, this.OH, this.OJ, this.Pw));
    } catch (RemoteException remoteException) {
      throw new RuntimeException("Unable to connect Drive Play Service", remoteException);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */