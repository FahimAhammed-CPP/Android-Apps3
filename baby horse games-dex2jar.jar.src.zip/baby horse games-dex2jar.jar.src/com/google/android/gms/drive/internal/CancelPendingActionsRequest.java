package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class CancelPendingActionsRequest implements SafeParcelable {
  public static final Parcelable.Creator<CancelPendingActionsRequest> CREATOR = new d();
  
  final int CK;
  
  final List<String> Pb;
  
  CancelPendingActionsRequest(int paramInt, List<String> paramList) {
    this.CK = paramInt;
    this.Pb = paramList;
  }
  
  public CancelPendingActionsRequest(List<String> paramList) {
    this(1, paramList);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    d.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\CancelPendingActionsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */