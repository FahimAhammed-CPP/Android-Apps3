package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;

public class aj implements Parcelable.Creator<LoadRealtimeRequest> {
  static void a(LoadRealtimeRequest paramLoadRealtimeRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramLoadRealtimeRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramLoadRealtimeRequest.Oj, paramInt, false);
    b.a(paramParcel, 3, paramLoadRealtimeRequest.QF);
    b.H(paramParcel, i);
  }
  
  public LoadRealtimeRequest ap(Parcel paramParcel) {
    boolean bool = false;
    int j = a.G(paramParcel);
    DriveId driveId = null;
    int i = 0;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, k, DriveId.CREATOR);
          break;
        case 3:
          bool = a.c(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new LoadRealtimeRequest(i, driveId, bool);
  }
  
  public LoadRealtimeRequest[] bE(int paramInt) {
    return new LoadRealtimeRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */