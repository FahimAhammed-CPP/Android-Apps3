package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class l implements Parcelable.Creator<CreateFolderRequest> {
  static void a(CreateFolderRequest paramCreateFolderRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramCreateFolderRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramCreateFolderRequest.Pz, paramInt, false);
    b.a(paramParcel, 3, (Parcelable)paramCreateFolderRequest.Px, paramInt, false);
    b.H(paramParcel, i);
  }
  
  public CreateFolderRequest ai(Parcel paramParcel) {
    MetadataBundle metadataBundle = null;
    int j = a.G(paramParcel);
    int i = 0;
    DriveId driveId = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, k, DriveId.CREATOR);
          break;
        case 3:
          metadataBundle = (MetadataBundle)a.a(paramParcel, k, MetadataBundle.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new CreateFolderRequest(i, driveId, metadataBundle);
  }
  
  public CreateFolderRequest[] bt(int paramInt) {
    return new CreateFolderRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */