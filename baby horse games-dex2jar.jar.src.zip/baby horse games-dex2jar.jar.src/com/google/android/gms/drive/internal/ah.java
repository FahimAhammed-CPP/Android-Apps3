package com.google.android.gms.drive.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface ah extends IInterface {
  void M(boolean paramBoolean) throws RemoteException;
  
  public static abstract class a extends Binder implements ah {
    public static ah aa(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.drive.internal.IEventReleaseCallback");
      return (iInterface != null && iInterface instanceof ah) ? (ah)iInterface : new a(param1IBinder);
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.drive.internal.IEventReleaseCallback");
          return true;
        case 1:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IEventReleaseCallback");
      if (param1Parcel1.readInt() != 0) {
        boolean bool1 = true;
        M(bool1);
        return true;
      } 
      boolean bool = false;
      M(bool);
      return true;
    }
    
    private static class a implements ah {
      private IBinder le;
      
      a(IBinder param2IBinder) {
        this.le = param2IBinder;
      }
      
      public void M(boolean param2Boolean) throws RemoteException {
        boolean bool = true;
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("com.google.android.gms.drive.internal.IEventReleaseCallback");
          if (!param2Boolean)
            bool = false; 
          parcel.writeInt(bool);
          this.le.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.le;
      }
    }
  }
  
  private static class a implements ah {
    private IBinder le;
    
    a(IBinder param1IBinder) {
      this.le = param1IBinder;
    }
    
    public void M(boolean param1Boolean) throws RemoteException {
      boolean bool = true;
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("com.google.android.gms.drive.internal.IEventReleaseCallback");
        if (!param1Boolean)
          bool = false; 
        parcel.writeInt(bool);
        this.le.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.le;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */