package com.google.android.gms.drive.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface ag extends IInterface {
  void c(OnEventResponse paramOnEventResponse) throws RemoteException;
  
  public static abstract class a extends Binder implements ag {
    public a() {
      attachInterface(this, "com.google.android.gms.drive.internal.IEventCallback");
    }
    
    public static ag Z(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.drive.internal.IEventCallback");
      return (iInterface != null && iInterface instanceof ag) ? (ag)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.drive.internal.IEventCallback");
          return true;
        case 1:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IEventCallback");
      if (param1Parcel1.readInt() != 0) {
        OnEventResponse onEventResponse = (OnEventResponse)OnEventResponse.CREATOR.createFromParcel(param1Parcel1);
        c(onEventResponse);
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel1 = null;
      c((OnEventResponse)param1Parcel1);
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements ag {
      private IBinder le;
      
      a(IBinder param2IBinder) {
        this.le = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.le;
      }
      
      public void c(OnEventResponse param2OnEventResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IEventCallback");
          if (param2OnEventResponse != null) {
            parcel1.writeInt(1);
            param2OnEventResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements ag {
    private IBinder le;
    
    a(IBinder param1IBinder) {
      this.le = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.le;
    }
    
    public void c(OnEventResponse param1OnEventResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IEventCallback");
        if (param1OnEventResponse != null) {
          parcel1.writeInt(1);
          param1OnEventResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */