package com.google.android.gms.drive.internal;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.c;
import com.google.android.gms.drive.events.d;
import com.google.android.gms.internal.jg;
import com.google.android.gms.internal.jl;
import com.google.android.gms.internal.js;
import com.google.android.gms.internal.jt;
import com.google.android.gms.internal.jx;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class r extends jl<ae> {
  private final String DZ;
  
  private final String JK;
  
  private final Bundle PK;
  
  private final boolean PL;
  
  private DriveId PM;
  
  private DriveId PN;
  
  final GoogleApiClient.ConnectionCallbacks PO;
  
  final Map<DriveId, Map<c, aa>> PP = new HashMap<DriveId, Map<c, aa>>();
  
  public r(Context paramContext, Looper paramLooper, jg paramjg, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener, String[] paramArrayOfString, Bundle paramBundle) {
    super(paramContext, paramLooper, paramConnectionCallbacks, paramOnConnectionFailedListener, paramArrayOfString);
    this.DZ = (String)jx.b(paramjg.hm(), "Must call Api.ClientBuilder.setAccountName()");
    this.JK = paramjg.hq();
    this.PO = paramConnectionCallbacks;
    this.PK = paramBundle;
    Intent intent = new Intent("com.google.android.gms.drive.events.HANDLE_EVENT");
    intent.setPackage(paramContext.getPackageName());
    List list = paramContext.getPackageManager().queryIntentServices(intent, 0);
    switch (list.size()) {
      default:
        throw new IllegalStateException("AndroidManifest.xml can only define one service that handles the " + intent.getAction() + " action");
      case 0:
        this.PL = false;
        return;
      case 1:
        break;
    } 
    ServiceInfo serviceInfo = ((ResolveInfo)list.get(0)).serviceInfo;
    if (!serviceInfo.exported)
      throw new IllegalStateException("Drive event service " + serviceInfo.name + " must be exported in AndroidManifest.xml"); 
    this.PL = true;
  }
  
  protected ae W(IBinder paramIBinder) {
    return ae.a.X(paramIBinder);
  }
  
  PendingResult<Status> a(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId, int paramInt) {
    jx.b(d.a(paramInt, paramDriveId), "id");
    jx.a(isConnected(), "Client must be connected");
    if (!this.PL)
      throw new IllegalStateException("Application must define an exported DriveEventService subclass in AndroidManifest.xml to add event subscriptions"); 
    return (PendingResult<Status>)paramGoogleApiClient.b(new q.a(this, paramGoogleApiClient, paramDriveId, paramInt) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new AddEventListenerRequest(this.PQ, this.PR), (ag)null, (String)null, new bg((BaseImplementation.b<Status>)this));
          }
        });
  }
  
  PendingResult<Status> a(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId, int paramInt, c paramc) {
    aa aa2;
    jx.b(d.a(paramInt, paramDriveId), "id");
    jx.b(paramc, "listener");
    jx.a(isConnected(), "Client must be connected");
    synchronized (this.PP) {
      BaseImplementation.a a1;
      Map<Object, Object> map = (Map)this.PP.get(paramDriveId);
      if (map == null) {
        map = new HashMap<Object, Object>();
        this.PP.put(paramDriveId, map);
      } 
      aa2 = (aa)map.get(paramc);
      if (aa2 == null) {
        aa2 = new aa(getLooper(), getContext(), paramInt, paramc);
        map.put(paramc, aa2);
        aa aa = aa2;
        aa.bw(paramInt);
        a1 = paramGoogleApiClient.b(new q.a(this, paramGoogleApiClient, paramDriveId, paramInt, aa) {
              protected void a(r param1r) throws RemoteException {
                param1r.iG().a(new AddEventListenerRequest(this.PQ, this.PR), this.PS, (String)null, new bg((BaseImplementation.b<Status>)this));
              }
            });
        return (PendingResult<Status>)a1;
      } 
      if (aa2.bx(paramInt)) {
        a1 = new p.j((GoogleApiClient)a1, Status.Kw);
        return (PendingResult<Status>)a1;
      } 
    } 
    aa aa1 = aa2;
    aa1.bw(paramInt);
    BaseImplementation.a a = paramGoogleApiClient.b(new q.a(this, paramGoogleApiClient, paramDriveId, paramInt, aa1) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new AddEventListenerRequest(this.PQ, this.PR), this.PS, (String)null, new bg((BaseImplementation.b<Status>)this));
          }
        });
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_7} */
    return (PendingResult<Status>)a;
  }
  
  protected void a(int paramInt, IBinder paramIBinder, Bundle paramBundle) {
    if (paramBundle != null) {
      paramBundle.setClassLoader(getClass().getClassLoader());
      this.PM = (DriveId)paramBundle.getParcelable("com.google.android.gms.drive.root_id");
      this.PN = (DriveId)paramBundle.getParcelable("com.google.android.gms.drive.appdata_id");
    } 
    super.a(paramInt, paramIBinder, paramBundle);
  }
  
  protected void a(jt paramjt, jl.e parame) throws RemoteException {
    String str = getContext().getPackageName();
    jx.i(parame);
    jx.i(str);
    jx.i(hv());
    Bundle bundle = new Bundle();
    if (!str.equals(this.JK))
      bundle.putString("proxy_package_name", this.JK); 
    bundle.putAll(this.PK);
    paramjt.a((js)parame, 6587000, str, hv(), this.DZ, bundle);
  }
  
  PendingResult<Status> b(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId, int paramInt) {
    jx.b(d.a(paramInt, paramDriveId), "id");
    jx.a(isConnected(), "Client must be connected");
    return (PendingResult<Status>)paramGoogleApiClient.b(new q.a(this, paramGoogleApiClient, paramDriveId, paramInt) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new RemoveEventListenerRequest(this.PQ, this.PR), (ag)null, (String)null, new bg((BaseImplementation.b<Status>)this));
          }
        });
  }
  
  PendingResult<Status> b(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId, int paramInt, c paramc) {
    aa aa;
    Map map;
    jx.b(d.a(paramInt, paramDriveId), "id");
    jx.a(isConnected(), "Client must be connected");
    jx.b(paramc, "listener");
    synchronized (this.PP) {
      p.j j;
      map = this.PP.get(paramDriveId);
      if (map == null) {
        j = new p.j(paramGoogleApiClient, Status.Kw);
        return (PendingResult<Status>)j;
      } 
      aa = (aa)map.remove(paramc);
      if (aa == null) {
        j = new p.j((GoogleApiClient)j, Status.Kw);
        return (PendingResult<Status>)j;
      } 
    } 
    if (map.isEmpty())
      this.PP.remove(paramDriveId); 
    BaseImplementation.a a = paramGoogleApiClient.b(new q.a(this, paramGoogleApiClient, paramDriveId, paramInt, aa) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new RemoveEventListenerRequest(this.PQ, this.PR), this.PU, (String)null, new bg((BaseImplementation.b<Status>)this));
          }
        });
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_5} */
    return (PendingResult<Status>)a;
  }
  
  protected String bK() {
    return "com.google.android.gms.drive.ApiService.START";
  }
  
  protected String bL() {
    return "com.google.android.gms.drive.internal.IDriveService";
  }
  
  PendingResult<Status> cancelPendingActions(GoogleApiClient paramGoogleApiClient, List<String> paramList) {
    boolean bool2 = true;
    if (paramList != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    jx.L(bool1);
    if (!paramList.isEmpty()) {
      bool1 = bool2;
      jx.L(bool1);
      jx.a(isConnected(), "Client must be connected");
      return (PendingResult<Status>)paramGoogleApiClient.b(new q.a(this, paramGoogleApiClient, paramList) {
            protected void a(r param1r) throws RemoteException {
              param1r.iG().a(new CancelPendingActionsRequest(this.PV), new bg((BaseImplementation.b<Status>)this));
            }
          });
    } 
    boolean bool1 = false;
    jx.L(bool1);
    jx.a(isConnected(), "Client must be connected");
    return (PendingResult<Status>)paramGoogleApiClient.b(new q.a(this, paramGoogleApiClient, paramList) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new CancelPendingActionsRequest(this.PV), new bg((BaseImplementation.b<Status>)this));
          }
        });
  }
  
  public void disconnect() {
    if (isConnected())
      try {
        ((ae)hw()).a(new DisconnectRequest());
      } catch (RemoteException remoteException) {} 
    super.disconnect();
    this.PP.clear();
  }
  
  public ae iG() throws DeadObjectException {
    return (ae)hw();
  }
  
  public DriveId iH() {
    return this.PM;
  }
  
  public DriveId iI() {
    return this.PN;
  }
  
  public boolean iJ() {
    return this.PL;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */