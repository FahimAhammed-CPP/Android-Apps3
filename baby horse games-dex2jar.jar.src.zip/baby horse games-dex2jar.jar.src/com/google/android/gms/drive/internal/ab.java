package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class ab implements Parcelable.Creator<FileUploadPreferencesImpl> {
  static void a(FileUploadPreferencesImpl paramFileUploadPreferencesImpl, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramFileUploadPreferencesImpl.CK);
    b.c(paramParcel, 2, paramFileUploadPreferencesImpl.Qz);
    b.c(paramParcel, 3, paramFileUploadPreferencesImpl.QA);
    b.a(paramParcel, 4, paramFileUploadPreferencesImpl.QB);
    b.H(paramParcel, paramInt);
  }
  
  public FileUploadPreferencesImpl al(Parcel paramParcel) {
    boolean bool = false;
    int m = a.G(paramParcel);
    int k = 0;
    int j = 0;
    int i = 0;
    while (paramParcel.dataPosition() < m) {
      int n = a.F(paramParcel);
      switch (a.aH(n)) {
        case 1:
          i = a.g(paramParcel, n);
          break;
        case 2:
          j = a.g(paramParcel, n);
          break;
        case 3:
          k = a.g(paramParcel, n);
          break;
        case 4:
          bool = a.c(paramParcel, n);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != m)
      throw new a.a("Overread allowed size end=" + m, paramParcel); 
    return new FileUploadPreferencesImpl(i, j, k, bool);
  }
  
  public FileUploadPreferencesImpl[] bA(int paramInt) {
    return new FileUploadPreferencesImpl[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */