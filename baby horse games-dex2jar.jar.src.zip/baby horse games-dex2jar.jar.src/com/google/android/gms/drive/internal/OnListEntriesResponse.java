package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.i;

public class OnListEntriesResponse extends i implements SafeParcelable {
  public static final Parcelable.Creator<OnListEntriesResponse> CREATOR = new ar();
  
  final int CK;
  
  final boolean PJ;
  
  final DataHolder QQ;
  
  OnListEntriesResponse(int paramInt, DataHolder paramDataHolder, boolean paramBoolean) {
    this.CK = paramInt;
    this.QQ = paramDataHolder;
    this.PJ = paramBoolean;
  }
  
  protected void I(Parcel paramParcel, int paramInt) {
    ar.a(this, paramParcel, paramInt);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public DataHolder iR() {
    return this.QQ;
  }
  
  public boolean iS() {
    return this.PJ;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\OnListEntriesResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */