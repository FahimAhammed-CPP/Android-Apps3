package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class f implements Parcelable.Creator<CloseContentsAndUpdateMetadataRequest> {
  static void a(CloseContentsAndUpdateMetadataRequest paramCloseContentsAndUpdateMetadataRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramCloseContentsAndUpdateMetadataRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramCloseContentsAndUpdateMetadataRequest.Pp, paramInt, false);
    b.a(paramParcel, 3, (Parcelable)paramCloseContentsAndUpdateMetadataRequest.Pq, paramInt, false);
    b.a(paramParcel, 4, (Parcelable)paramCloseContentsAndUpdateMetadataRequest.Pr, paramInt, false);
    b.a(paramParcel, 5, paramCloseContentsAndUpdateMetadataRequest.Oz);
    b.a(paramParcel, 6, paramCloseContentsAndUpdateMetadataRequest.Oy, false);
    b.c(paramParcel, 7, paramCloseContentsAndUpdateMetadataRequest.Ps);
    b.H(paramParcel, i);
  }
  
  public CloseContentsAndUpdateMetadataRequest ad(Parcel paramParcel) {
    int i = 0;
    String str = null;
    int k = a.G(paramParcel);
    boolean bool = false;
    Contents contents = null;
    MetadataBundle metadataBundle = null;
    DriveId driveId = null;
    int j = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.F(paramParcel);
      switch (a.aH(m)) {
        case 1:
          j = a.g(paramParcel, m);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, m, DriveId.CREATOR);
          break;
        case 3:
          metadataBundle = (MetadataBundle)a.a(paramParcel, m, MetadataBundle.CREATOR);
          break;
        case 4:
          contents = (Contents)a.a(paramParcel, m, Contents.CREATOR);
          break;
        case 5:
          bool = a.c(paramParcel, m);
          break;
        case 6:
          str = a.o(paramParcel, m);
          break;
        case 7:
          i = a.g(paramParcel, m);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new CloseContentsAndUpdateMetadataRequest(j, driveId, metadataBundle, contents, bool, str, i);
  }
  
  public CloseContentsAndUpdateMetadataRequest[] bn(int paramInt) {
    return new CloseContentsAndUpdateMetadataRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */