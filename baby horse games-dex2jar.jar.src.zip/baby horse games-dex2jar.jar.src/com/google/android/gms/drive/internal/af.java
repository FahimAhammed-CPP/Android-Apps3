package com.google.android.gms.drive.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.realtime.internal.m;

public interface af extends IInterface {
  void a(OnContentsResponse paramOnContentsResponse) throws RemoteException;
  
  void a(OnDeviceUsagePreferenceResponse paramOnDeviceUsagePreferenceResponse) throws RemoteException;
  
  void a(OnDownloadProgressResponse paramOnDownloadProgressResponse) throws RemoteException;
  
  void a(OnDriveIdResponse paramOnDriveIdResponse) throws RemoteException;
  
  void a(OnDrivePreferencesResponse paramOnDrivePreferencesResponse) throws RemoteException;
  
  void a(OnListEntriesResponse paramOnListEntriesResponse) throws RemoteException;
  
  void a(OnListParentsResponse paramOnListParentsResponse) throws RemoteException;
  
  void a(OnLoadRealtimeResponse paramOnLoadRealtimeResponse, m paramm) throws RemoteException;
  
  void a(OnMetadataResponse paramOnMetadataResponse) throws RemoteException;
  
  void a(OnResourceIdSetResponse paramOnResourceIdSetResponse) throws RemoteException;
  
  void a(OnStorageStatsResponse paramOnStorageStatsResponse) throws RemoteException;
  
  void a(OnSyncMoreResponse paramOnSyncMoreResponse) throws RemoteException;
  
  void n(Status paramStatus) throws RemoteException;
  
  void onSuccess() throws RemoteException;
  
  public static abstract class a extends Binder implements af {
    public a() {
      attachInterface(this, "com.google.android.gms.drive.internal.IDriveServiceCallbacks");
    }
    
    public static af Y(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
      return (iInterface != null && iInterface instanceof af) ? (af)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      OnListEntriesResponse onListEntriesResponse1;
      OnDriveIdResponse onDriveIdResponse1;
      OnMetadataResponse onMetadataResponse1;
      OnContentsResponse onContentsResponse1;
      Status status1;
      OnListParentsResponse onListParentsResponse1;
      OnSyncMoreResponse onSyncMoreResponse1;
      OnStorageStatsResponse onStorageStatsResponse1;
      OnLoadRealtimeResponse onLoadRealtimeResponse1;
      OnResourceIdSetResponse onResourceIdSetResponse1;
      OnDeviceUsagePreferenceResponse onDeviceUsagePreferenceResponse;
      OnDownloadProgressResponse onDownloadProgressResponse2 = null;
      OnListEntriesResponse onListEntriesResponse2 = null;
      OnDriveIdResponse onDriveIdResponse2 = null;
      OnMetadataResponse onMetadataResponse2 = null;
      OnContentsResponse onContentsResponse2 = null;
      Status status2 = null;
      OnListParentsResponse onListParentsResponse2 = null;
      OnSyncMoreResponse onSyncMoreResponse2 = null;
      OnStorageStatsResponse onStorageStatsResponse2 = null;
      OnLoadRealtimeResponse onLoadRealtimeResponse2 = null;
      OnResourceIdSetResponse onResourceIdSetResponse2 = null;
      OnDrivePreferencesResponse onDrivePreferencesResponse2 = null;
      OnDownloadProgressResponse onDownloadProgressResponse1 = null;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param1Parcel1.readInt() != 0)
            onDownloadProgressResponse1 = (OnDownloadProgressResponse)OnDownloadProgressResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onDownloadProgressResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 2:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onDownloadProgressResponse1 = onDownloadProgressResponse2;
          if (param1Parcel1.readInt() != 0)
            onListEntriesResponse1 = (OnListEntriesResponse)OnListEntriesResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onListEntriesResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 3:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onListEntriesResponse1 = onListEntriesResponse2;
          if (param1Parcel1.readInt() != 0)
            onDriveIdResponse1 = (OnDriveIdResponse)OnDriveIdResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onDriveIdResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 4:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onDriveIdResponse1 = onDriveIdResponse2;
          if (param1Parcel1.readInt() != 0)
            onMetadataResponse1 = (OnMetadataResponse)OnMetadataResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onMetadataResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 5:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onMetadataResponse1 = onMetadataResponse2;
          if (param1Parcel1.readInt() != 0)
            onContentsResponse1 = (OnContentsResponse)OnContentsResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onContentsResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 6:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onContentsResponse1 = onContentsResponse2;
          if (param1Parcel1.readInt() != 0)
            status1 = Status.CREATOR.createFromParcel(param1Parcel1); 
          n(status1);
          param1Parcel2.writeNoException();
          return true;
        case 7:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onSuccess();
          param1Parcel2.writeNoException();
          return true;
        case 8:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          status1 = status2;
          if (param1Parcel1.readInt() != 0)
            onListParentsResponse1 = (OnListParentsResponse)OnListParentsResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onListParentsResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 9:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onListParentsResponse1 = onListParentsResponse2;
          if (param1Parcel1.readInt() != 0)
            onSyncMoreResponse1 = (OnSyncMoreResponse)OnSyncMoreResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onSyncMoreResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 10:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onSyncMoreResponse1 = onSyncMoreResponse2;
          if (param1Parcel1.readInt() != 0)
            onStorageStatsResponse1 = (OnStorageStatsResponse)OnStorageStatsResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onStorageStatsResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 11:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onStorageStatsResponse1 = onStorageStatsResponse2;
          if (param1Parcel1.readInt() != 0)
            onLoadRealtimeResponse1 = (OnLoadRealtimeResponse)OnLoadRealtimeResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onLoadRealtimeResponse1, m.a.al(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 12:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onLoadRealtimeResponse1 = onLoadRealtimeResponse2;
          if (param1Parcel1.readInt() != 0)
            onResourceIdSetResponse1 = (OnResourceIdSetResponse)OnResourceIdSetResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onResourceIdSetResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 13:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          onResourceIdSetResponse1 = onResourceIdSetResponse2;
          if (param1Parcel1.readInt() != 0)
            onDrivePreferencesResponse1 = (OnDrivePreferencesResponse)OnDrivePreferencesResponse.CREATOR.createFromParcel(param1Parcel1); 
          a(onDrivePreferencesResponse1);
          param1Parcel2.writeNoException();
          return true;
        case 14:
          break;
      } 
      param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
      OnDrivePreferencesResponse onDrivePreferencesResponse1 = onDrivePreferencesResponse2;
      if (param1Parcel1.readInt() != 0)
        onDeviceUsagePreferenceResponse = (OnDeviceUsagePreferenceResponse)OnDeviceUsagePreferenceResponse.CREATOR.createFromParcel(param1Parcel1); 
      a(onDeviceUsagePreferenceResponse);
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements af {
      private IBinder le;
      
      a(IBinder param2IBinder) {
        this.le = param2IBinder;
      }
      
      public void a(OnContentsResponse param2OnContentsResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnContentsResponse != null) {
            parcel1.writeInt(1);
            param2OnContentsResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnDeviceUsagePreferenceResponse param2OnDeviceUsagePreferenceResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnDeviceUsagePreferenceResponse != null) {
            parcel1.writeInt(1);
            param2OnDeviceUsagePreferenceResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(14, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnDownloadProgressResponse param2OnDownloadProgressResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnDownloadProgressResponse != null) {
            parcel1.writeInt(1);
            param2OnDownloadProgressResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnDriveIdResponse param2OnDriveIdResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnDriveIdResponse != null) {
            parcel1.writeInt(1);
            param2OnDriveIdResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnDrivePreferencesResponse param2OnDrivePreferencesResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnDrivePreferencesResponse != null) {
            parcel1.writeInt(1);
            param2OnDrivePreferencesResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(13, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnListEntriesResponse param2OnListEntriesResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnListEntriesResponse != null) {
            parcel1.writeInt(1);
            param2OnListEntriesResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnListParentsResponse param2OnListParentsResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnListParentsResponse != null) {
            parcel1.writeInt(1);
            param2OnListParentsResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnLoadRealtimeResponse param2OnLoadRealtimeResponse, m param2m) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnLoadRealtimeResponse != null) {
            parcel1.writeInt(1);
            param2OnLoadRealtimeResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2m != null) {
            IBinder iBinder = param2m.asBinder();
          } else {
            param2OnLoadRealtimeResponse = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2OnLoadRealtimeResponse);
          this.le.transact(11, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnMetadataResponse param2OnMetadataResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnMetadataResponse != null) {
            parcel1.writeInt(1);
            param2OnMetadataResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnResourceIdSetResponse param2OnResourceIdSetResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnResourceIdSetResponse != null) {
            parcel1.writeInt(1);
            param2OnResourceIdSetResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(12, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnStorageStatsResponse param2OnStorageStatsResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnStorageStatsResponse != null) {
            parcel1.writeInt(1);
            param2OnStorageStatsResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(10, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OnSyncMoreResponse param2OnSyncMoreResponse) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2OnSyncMoreResponse != null) {
            parcel1.writeInt(1);
            param2OnSyncMoreResponse.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(9, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.le;
      }
      
      public void n(Status param2Status) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          if (param2Status != null) {
            parcel1.writeInt(1);
            param2Status.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void onSuccess() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
          this.le.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements af {
    private IBinder le;
    
    a(IBinder param1IBinder) {
      this.le = param1IBinder;
    }
    
    public void a(OnContentsResponse param1OnContentsResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnContentsResponse != null) {
          parcel1.writeInt(1);
          param1OnContentsResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnDeviceUsagePreferenceResponse param1OnDeviceUsagePreferenceResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnDeviceUsagePreferenceResponse != null) {
          parcel1.writeInt(1);
          param1OnDeviceUsagePreferenceResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(14, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnDownloadProgressResponse param1OnDownloadProgressResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnDownloadProgressResponse != null) {
          parcel1.writeInt(1);
          param1OnDownloadProgressResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnDriveIdResponse param1OnDriveIdResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnDriveIdResponse != null) {
          parcel1.writeInt(1);
          param1OnDriveIdResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnDrivePreferencesResponse param1OnDrivePreferencesResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnDrivePreferencesResponse != null) {
          parcel1.writeInt(1);
          param1OnDrivePreferencesResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(13, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnListEntriesResponse param1OnListEntriesResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnListEntriesResponse != null) {
          parcel1.writeInt(1);
          param1OnListEntriesResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnListParentsResponse param1OnListParentsResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnListParentsResponse != null) {
          parcel1.writeInt(1);
          param1OnListParentsResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnLoadRealtimeResponse param1OnLoadRealtimeResponse, m param1m) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnLoadRealtimeResponse != null) {
          parcel1.writeInt(1);
          param1OnLoadRealtimeResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1m != null) {
          IBinder iBinder = param1m.asBinder();
        } else {
          param1OnLoadRealtimeResponse = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1OnLoadRealtimeResponse);
        this.le.transact(11, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnMetadataResponse param1OnMetadataResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnMetadataResponse != null) {
          parcel1.writeInt(1);
          param1OnMetadataResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnResourceIdSetResponse param1OnResourceIdSetResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnResourceIdSetResponse != null) {
          parcel1.writeInt(1);
          param1OnResourceIdSetResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(12, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnStorageStatsResponse param1OnStorageStatsResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnStorageStatsResponse != null) {
          parcel1.writeInt(1);
          param1OnStorageStatsResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(10, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OnSyncMoreResponse param1OnSyncMoreResponse) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1OnSyncMoreResponse != null) {
          parcel1.writeInt(1);
          param1OnSyncMoreResponse.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(9, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.le;
    }
    
    public void n(Status param1Status) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        if (param1Status != null) {
          parcel1.writeInt(1);
          param1Status.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void onSuccess() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveServiceCallbacks");
        this.le.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */