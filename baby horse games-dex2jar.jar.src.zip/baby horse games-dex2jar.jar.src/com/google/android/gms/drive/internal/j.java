package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class j implements Parcelable.Creator<CreateFileIntentSenderRequest> {
  static void a(CreateFileIntentSenderRequest paramCreateFileIntentSenderRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramCreateFileIntentSenderRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramCreateFileIntentSenderRequest.Px, paramInt, false);
    b.c(paramParcel, 3, paramCreateFileIntentSenderRequest.ve);
    b.a(paramParcel, 4, paramCreateFileIntentSenderRequest.OH, false);
    b.a(paramParcel, 5, (Parcelable)paramCreateFileIntentSenderRequest.OJ, paramInt, false);
    b.a(paramParcel, 6, paramCreateFileIntentSenderRequest.Py, false);
    b.H(paramParcel, i);
  }
  
  public CreateFileIntentSenderRequest ag(Parcel paramParcel) {
    int i = 0;
    Integer integer = null;
    int m = a.G(paramParcel);
    DriveId driveId = null;
    String str = null;
    MetadataBundle metadataBundle = null;
    int k = 0;
    while (paramParcel.dataPosition() < m) {
      int n = a.F(paramParcel);
      switch (a.aH(n)) {
        case 1:
          k = a.g(paramParcel, n);
          break;
        case 2:
          metadataBundle = (MetadataBundle)a.a(paramParcel, n, MetadataBundle.CREATOR);
          break;
        case 3:
          i = a.g(paramParcel, n);
          break;
        case 4:
          str = a.o(paramParcel, n);
          break;
        case 5:
          driveId = (DriveId)a.a(paramParcel, n, DriveId.CREATOR);
          break;
        case 6:
          integer = a.h(paramParcel, n);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != m)
      throw new a.a("Overread allowed size end=" + m, paramParcel); 
    return new CreateFileIntentSenderRequest(k, metadataBundle, i, str, driveId, integer);
  }
  
  public CreateFileIntentSenderRequest[] br(int paramInt) {
    return new CreateFileIntentSenderRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */