package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.query.Query;

public class bb implements Parcelable.Creator<QueryRequest> {
  static void a(QueryRequest paramQueryRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramQueryRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramQueryRequest.QV, paramInt, false);
    b.H(paramParcel, i);
  }
  
  public QueryRequest aF(Parcel paramParcel) {
    int j = a.G(paramParcel);
    int i = 0;
    Query query = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          query = (Query)a.a(paramParcel, k, Query.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new QueryRequest(i, query);
  }
  
  public QueryRequest[] bU(int paramInt) {
    return new QueryRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\bb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */