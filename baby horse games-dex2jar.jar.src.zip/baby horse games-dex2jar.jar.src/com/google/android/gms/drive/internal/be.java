package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class be implements Parcelable.Creator<SetFileUploadPreferencesRequest> {
  static void a(SetFileUploadPreferencesRequest paramSetFileUploadPreferencesRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramSetFileUploadPreferencesRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramSetFileUploadPreferencesRequest.QK, paramInt, false);
    b.H(paramParcel, i);
  }
  
  public SetFileUploadPreferencesRequest aI(Parcel paramParcel) {
    int j = a.G(paramParcel);
    int i = 0;
    FileUploadPreferencesImpl fileUploadPreferencesImpl = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          fileUploadPreferencesImpl = (FileUploadPreferencesImpl)a.a(paramParcel, k, FileUploadPreferencesImpl.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new SetFileUploadPreferencesRequest(i, fileUploadPreferencesImpl);
  }
  
  public SetFileUploadPreferencesRequest[] bX(int paramInt) {
    return new SetFileUploadPreferencesRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\be.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */