package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class DisconnectRequest implements SafeParcelable {
  public static final Parcelable.Creator<DisconnectRequest> CREATOR = new o();
  
  final int CK;
  
  public DisconnectRequest() {
    this(1);
  }
  
  DisconnectRequest(int paramInt) {
    this.CK = paramInt;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    o.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\DisconnectRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */