package com.google.android.gms.drive.internal;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Pair;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.ChangeListener;
import com.google.android.gms.drive.events.CompletionEvent;
import com.google.android.gms.drive.events.CompletionListener;
import com.google.android.gms.drive.events.DriveEvent;
import com.google.android.gms.drive.events.c;
import com.google.android.gms.internal.jx;
import java.util.ArrayList;
import java.util.List;

public class aa extends ag.a {
  private final int Pm;
  
  private final c Qw;
  
  private final a Qx;
  
  private final List<Integer> Qy = new ArrayList<Integer>();
  
  public aa(Looper paramLooper, Context paramContext, int paramInt, c paramc) {
    this.Pm = paramInt;
    this.Qw = paramc;
    this.Qx = new a(paramLooper, paramContext);
  }
  
  public void bw(int paramInt) {
    this.Qy.add(Integer.valueOf(paramInt));
  }
  
  public boolean bx(int paramInt) {
    return this.Qy.contains(Integer.valueOf(paramInt));
  }
  
  public void c(OnEventResponse paramOnEventResponse) throws RemoteException {
    boolean bool;
    DriveEvent driveEvent = paramOnEventResponse.iQ();
    if (this.Pm == driveEvent.getType()) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.K(bool);
    jx.K(this.Qy.contains(Integer.valueOf(driveEvent.getType())));
    this.Qx.a(this.Qw, driveEvent);
  }
  
  private static class a extends Handler {
    private final Context mContext;
    
    private a(Looper param1Looper, Context param1Context) {
      super(param1Looper);
      this.mContext = param1Context;
    }
    
    public void a(c param1c, DriveEvent param1DriveEvent) {
      sendMessage(obtainMessage(1, new Pair(param1c, param1DriveEvent)));
    }
    
    public void handleMessage(Message param1Message) {
      switch (param1Message.what) {
        default:
          w.e(this.mContext, "EventCallback", "Don't know how to handle this event");
          return;
        case 1:
          break;
      } 
      Pair pair = (Pair)param1Message.obj;
      c c = (c)pair.first;
      DriveEvent driveEvent = (DriveEvent)pair.second;
      switch (driveEvent.getType()) {
        default:
          w.o("EventCallback", "Unexpected event: " + driveEvent);
          return;
        case 1:
          ((ChangeListener)c).onChange((ChangeEvent)driveEvent);
          return;
        case 2:
          break;
      } 
      ((CompletionListener)c).onCompletion((CompletionEvent)driveEvent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */