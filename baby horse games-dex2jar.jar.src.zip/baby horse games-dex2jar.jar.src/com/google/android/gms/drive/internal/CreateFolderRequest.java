package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.internal.jx;

public class CreateFolderRequest implements SafeParcelable {
  public static final Parcelable.Creator<CreateFolderRequest> CREATOR = new l();
  
  final int CK;
  
  final MetadataBundle Px;
  
  final DriveId Pz;
  
  CreateFolderRequest(int paramInt, DriveId paramDriveId, MetadataBundle paramMetadataBundle) {
    this.CK = paramInt;
    this.Pz = (DriveId)jx.i(paramDriveId);
    this.Px = (MetadataBundle)jx.i(paramMetadataBundle);
  }
  
  public CreateFolderRequest(DriveId paramDriveId, MetadataBundle paramMetadataBundle) {
    this(1, paramDriveId, paramMetadataBundle);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    l.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\CreateFolderRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */