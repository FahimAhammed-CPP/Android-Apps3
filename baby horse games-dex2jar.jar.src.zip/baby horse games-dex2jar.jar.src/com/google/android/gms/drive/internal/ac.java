package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class ac implements Parcelable.Creator<GetDriveIdFromUniqueIdentifierRequest> {
  static void a(GetDriveIdFromUniqueIdentifierRequest paramGetDriveIdFromUniqueIdentifierRequest, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramGetDriveIdFromUniqueIdentifierRequest.CK);
    b.a(paramParcel, 2, paramGetDriveIdFromUniqueIdentifierRequest.QC, false);
    b.a(paramParcel, 3, paramGetDriveIdFromUniqueIdentifierRequest.QD);
    b.H(paramParcel, paramInt);
  }
  
  public GetDriveIdFromUniqueIdentifierRequest am(Parcel paramParcel) {
    boolean bool = false;
    int j = a.G(paramParcel);
    String str = null;
    int i = 0;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          str = a.o(paramParcel, k);
          break;
        case 3:
          bool = a.c(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new GetDriveIdFromUniqueIdentifierRequest(i, str, bool);
  }
  
  public GetDriveIdFromUniqueIdentifierRequest[] bB(int paramInt) {
    return new GetDriveIdFromUniqueIdentifierRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */