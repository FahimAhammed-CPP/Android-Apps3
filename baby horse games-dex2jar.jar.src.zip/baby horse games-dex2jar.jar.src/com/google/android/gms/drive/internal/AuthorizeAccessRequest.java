package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class AuthorizeAccessRequest implements SafeParcelable {
  public static final Parcelable.Creator<AuthorizeAccessRequest> CREATOR = new b();
  
  final int CK;
  
  final DriveId Oj;
  
  final long Pn;
  
  AuthorizeAccessRequest(int paramInt, long paramLong, DriveId paramDriveId) {
    this.CK = paramInt;
    this.Pn = paramLong;
    this.Oj = paramDriveId;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\AuthorizeAccessRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */