package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DrivePreferences;

public class bd implements Parcelable.Creator<SetDrivePreferencesRequest> {
  static void a(SetDrivePreferencesRequest paramSetDrivePreferencesRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramSetDrivePreferencesRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramSetDrivePreferencesRequest.QN, paramInt, false);
    b.H(paramParcel, i);
  }
  
  public SetDrivePreferencesRequest aH(Parcel paramParcel) {
    int j = a.G(paramParcel);
    int i = 0;
    DrivePreferences drivePreferences = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          drivePreferences = (DrivePreferences)a.a(paramParcel, k, DrivePreferences.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new SetDrivePreferencesRequest(i, drivePreferences);
  }
  
  public SetDrivePreferencesRequest[] bW(int paramInt) {
    return new SetDrivePreferencesRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\bd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */