package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.List;

public class CheckResourceIdsExistRequest implements SafeParcelable {
  public static final Parcelable.Creator<CheckResourceIdsExistRequest> CREATOR = new e();
  
  private final int CK;
  
  private final List<String> Po;
  
  CheckResourceIdsExistRequest(int paramInt, List<String> paramList) {
    this.CK = paramInt;
    this.Po = paramList;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public int getVersionCode() {
    return this.CK;
  }
  
  public List<String> iF() {
    return this.Po;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    e.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\internal\CheckResourceIdsExistRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */