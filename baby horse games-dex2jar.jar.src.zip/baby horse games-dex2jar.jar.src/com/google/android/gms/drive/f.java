package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class f implements Parcelable.Creator<RealtimeDocumentSyncRequest> {
  static void a(RealtimeDocumentSyncRequest paramRealtimeDocumentSyncRequest, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramRealtimeDocumentSyncRequest.CK);
    b.b(paramParcel, 2, paramRealtimeDocumentSyncRequest.OK, false);
    b.b(paramParcel, 3, paramRealtimeDocumentSyncRequest.OL, false);
    b.H(paramParcel, paramInt);
  }
  
  public RealtimeDocumentSyncRequest U(Parcel paramParcel) {
    ArrayList<String> arrayList2 = null;
    int j = a.G(paramParcel);
    int i = 0;
    ArrayList<String> arrayList1 = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          arrayList1 = a.C(paramParcel, k);
          break;
        case 3:
          arrayList2 = a.C(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new RealtimeDocumentSyncRequest(i, arrayList1, arrayList2);
  }
  
  public RealtimeDocumentSyncRequest[] bc(int paramInt) {
    return new RealtimeDocumentSyncRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */