package com.google.android.gms.drive;

import android.os.ParcelFileDescriptor;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import java.io.InputStream;
import java.io.OutputStream;

public interface DriveContents {
  PendingResult<Status> commit(GoogleApiClient paramGoogleApiClient, MetadataChangeSet paramMetadataChangeSet);
  
  PendingResult<Status> commit(GoogleApiClient paramGoogleApiClient, MetadataChangeSet paramMetadataChangeSet, ExecutionOptions paramExecutionOptions);
  
  void discard(GoogleApiClient paramGoogleApiClient);
  
  DriveId getDriveId();
  
  InputStream getInputStream();
  
  int getMode();
  
  OutputStream getOutputStream();
  
  ParcelFileDescriptor getParcelFileDescriptor();
  
  Contents ir();
  
  void is();
  
  boolean it();
  
  PendingResult<DriveApi.DriveContentsResult> reopenForWrite(GoogleApiClient paramGoogleApiClient);
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\android\gms\drive\DriveContents.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */