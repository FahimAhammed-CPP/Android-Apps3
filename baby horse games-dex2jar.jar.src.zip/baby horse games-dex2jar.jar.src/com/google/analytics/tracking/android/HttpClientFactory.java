package com.google.analytics.tracking.android;

import org.apache.http.client.HttpClient;

interface HttpClientFactory {
  HttpClient newInstance();
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\HttpClientFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */