package com.google.analytics.tracking.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.text.TextUtils;
import com.google.android.gms.analytics.internal.Command;
import com.google.android.gms.common.util.VisibleForTesting;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultHttpClient;

class PersistentAnalyticsStore implements AnalyticsStore {
  @VisibleForTesting
  static final String BACKEND_LIBRARY_VERSION = "";
  
  private static final String CREATE_HITS_TABLE = String.format("CREATE TABLE IF NOT EXISTS %s ( '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, '%s' INTEGER NOT NULL, '%s' TEXT NOT NULL, '%s' TEXT NOT NULL, '%s' INTEGER);", new Object[] { "hits2", "hit_id", "hit_time", "hit_url", "hit_string", "hit_app_id" });
  
  private static final String DATABASE_FILENAME = "google_analytics_v2.db";
  
  @VisibleForTesting
  static final String HITS_TABLE = "hits2";
  
  @VisibleForTesting
  static final String HIT_APP_ID = "hit_app_id";
  
  @VisibleForTesting
  static final String HIT_ID = "hit_id";
  
  @VisibleForTesting
  static final String HIT_STRING = "hit_string";
  
  @VisibleForTesting
  static final String HIT_TIME = "hit_time";
  
  @VisibleForTesting
  static final String HIT_URL = "hit_url";
  
  private Clock mClock;
  
  private final Context mContext;
  
  private final String mDatabaseName;
  
  private final AnalyticsDatabaseHelper mDbHelper;
  
  private volatile Dispatcher mDispatcher;
  
  private long mLastDeleteStaleHitsTime;
  
  private final AnalyticsStoreStateListener mListener;
  
  PersistentAnalyticsStore(AnalyticsStoreStateListener paramAnalyticsStoreStateListener, Context paramContext) {
    this(paramAnalyticsStoreStateListener, paramContext, "google_analytics_v2.db");
  }
  
  @VisibleForTesting
  PersistentAnalyticsStore(AnalyticsStoreStateListener paramAnalyticsStoreStateListener, Context paramContext, String paramString) {
    this.mContext = paramContext.getApplicationContext();
    this.mDatabaseName = paramString;
    this.mListener = paramAnalyticsStoreStateListener;
    this.mClock = new Clock() {
        public long currentTimeMillis() {
          return System.currentTimeMillis();
        }
      };
    this.mDbHelper = new AnalyticsDatabaseHelper(this.mContext, this.mDatabaseName);
    this.mDispatcher = new SimpleNetworkDispatcher(this, createDefaultHttpClientFactory(), this.mContext);
    this.mLastDeleteStaleHitsTime = 0L;
  }
  
  private HttpClientFactory createDefaultHttpClientFactory() {
    return new HttpClientFactory() {
        public HttpClient newInstance() {
          return (HttpClient)new DefaultHttpClient();
        }
      };
  }
  
  private void fillVersionParametersIfNecessary(Map<String, String> paramMap, Collection<Command> paramCollection) {
    Iterator<Command> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      Command command = iterator.next();
      if (command.getId().equals("appendVersion")) {
        String str = command.getValue();
        storeVersion(paramMap, command.getUrlParam(), str);
        break;
      } 
    } 
  }
  
  public static String generateHitString(Map<String, String> paramMap) {
    ArrayList<String> arrayList = new ArrayList(paramMap.size());
    for (Map.Entry<String, String> entry : paramMap.entrySet())
      arrayList.add((String)entry.getKey() + "=" + HitBuilder.encode((String)entry.getValue())); 
    return TextUtils.join("&", arrayList);
  }
  
  private SQLiteDatabase getWritableDatabase(String paramString) {
    try {
      return this.mDbHelper.getWritableDatabase();
    } catch (SQLiteException sQLiteException) {
      Log.w(paramString);
      return null;
    } 
  }
  
  private void removeOldHitIfFull() {
    int i = getNumStoredHits() - 2000 + 1;
    if (i > 0) {
      List<Hit> list = peekHits(i);
      Log.wDebug("Store full, deleting " + list.size() + " hits to make room");
      deleteHits(list);
    } 
  }
  
  private void storeVersion(Map<String, String> paramMap, String paramString1, String paramString2) {
    if (paramString2 == null) {
      paramString2 = "";
    } else {
      paramString2 = paramString2 + "";
    } 
    if (paramString1 != null)
      paramMap.put(paramString1, paramString2); 
  }
  
  private void writeHitToDatabase(Map<String, String> paramMap, long paramLong, String paramString) {
    SQLiteDatabase sQLiteDatabase = getWritableDatabase("Error opening database for putHit");
    if (sQLiteDatabase == null)
      return; 
    ContentValues contentValues = new ContentValues();
    contentValues.put("hit_string", generateHitString(paramMap));
    contentValues.put("hit_time", Long.valueOf(paramLong));
    long l = 0L;
    paramLong = l;
    if (paramMap.containsKey("AppUID"))
      try {
        paramLong = Long.parseLong(paramMap.get("AppUID"));
      } catch (NumberFormatException numberFormatException) {
        paramLong = l;
      }  
    contentValues.put("hit_app_id", Long.valueOf(paramLong));
    String str = paramString;
    if (paramString == null)
      str = "http://www.google-analytics.com/collect"; 
    if (str.length() == 0) {
      Log.w("empty path: not sending hit");
      return;
    } 
    contentValues.put("hit_url", str);
    try {
      sQLiteDatabase.insert("hits2", null, contentValues);
      this.mListener.reportStoreIsEmpty(false);
      return;
    } catch (SQLiteException sQLiteException) {
      Log.w("Error storing hit");
      return;
    } 
  }
  
  public void clearHits(long paramLong) {
    boolean bool = true;
    SQLiteDatabase sQLiteDatabase = getWritableDatabase("Error opening database for clearHits");
    if (sQLiteDatabase != null) {
      if (paramLong == 0L) {
        sQLiteDatabase.delete("hits2", null, null);
      } else {
        sQLiteDatabase.delete("hits2", "hit_app_id = ?", new String[] { Long.valueOf(paramLong).toString() });
      } 
      AnalyticsStoreStateListener analyticsStoreStateListener = this.mListener;
      if (getNumStoredHits() != 0)
        bool = false; 
      analyticsStoreStateListener.reportStoreIsEmpty(bool);
    } 
  }
  
  public void close() {
    try {
      this.mDbHelper.getWritableDatabase().close();
      return;
    } catch (SQLiteException sQLiteException) {
      Log.w("Error opening database for close");
      return;
    } 
  }
  
  public void deleteHits(Collection<Hit> paramCollection) {
    if (paramCollection == null)
      throw new NullPointerException("hits cannot be null"); 
    if (!paramCollection.isEmpty()) {
      SQLiteDatabase sQLiteDatabase = getWritableDatabase("Error opening database for deleteHit");
      if (sQLiteDatabase != null) {
        String[] arrayOfString = new String[paramCollection.size()];
        String str = String.format("HIT_ID in (%s)", new Object[] { TextUtils.join(",", Collections.nCopies(arrayOfString.length, "?")) });
        int i = 0;
        Iterator<Hit> iterator = paramCollection.iterator();
        while (iterator.hasNext()) {
          arrayOfString[i] = Long.toString(((Hit)iterator.next()).getHitId());
          i++;
        } 
        try {
          boolean bool;
          sQLiteDatabase.delete("hits2", str, arrayOfString);
          AnalyticsStoreStateListener analyticsStoreStateListener = this.mListener;
          if (getNumStoredHits() == 0) {
            bool = true;
          } else {
            bool = false;
          } 
          analyticsStoreStateListener.reportStoreIsEmpty(bool);
          return;
        } catch (SQLiteException sQLiteException) {
          Log.w("Error deleting hit " + paramCollection);
          return;
        } 
      } 
    } 
  }
  
  int deleteStaleHits() {
    boolean bool = true;
    long l = this.mClock.currentTimeMillis();
    if (l > this.mLastDeleteStaleHitsTime + 86400000L) {
      this.mLastDeleteStaleHitsTime = l;
      SQLiteDatabase sQLiteDatabase = getWritableDatabase("Error opening database for deleteStaleHits");
      if (sQLiteDatabase != null) {
        int i = sQLiteDatabase.delete("hits2", "HIT_TIME < ?", new String[] { Long.toString(this.mClock.currentTimeMillis() - 2592000000L) });
        AnalyticsStoreStateListener analyticsStoreStateListener = this.mListener;
        if (getNumStoredHits() != 0)
          bool = false; 
        analyticsStoreStateListener.reportStoreIsEmpty(bool);
        return i;
      } 
    } 
    return 0;
  }
  
  public void dispatch() {
    Log.vDebug("dispatch running...");
    if (this.mDispatcher.okToDispatch()) {
      List<Hit> list = peekHits(40);
      if (list.isEmpty()) {
        Log.vDebug("...nothing to dispatch");
        this.mListener.reportStoreIsEmpty(true);
        return;
      } 
      int i = this.mDispatcher.dispatchHits(list);
      Log.vDebug("sent " + i + " of " + list.size() + " hits");
      deleteHits(list.subList(0, Math.min(i, list.size())));
      if (i == list.size() && getNumStoredHits() > 0) {
        GAServiceManager.getInstance().dispatch();
        return;
      } 
    } 
  }
  
  @VisibleForTesting
  public AnalyticsDatabaseHelper getDbHelper() {
    return this.mDbHelper;
  }
  
  @VisibleForTesting
  AnalyticsDatabaseHelper getHelper() {
    return this.mDbHelper;
  }
  
  int getNumStoredHits() {
    boolean bool = false;
    int i = 0;
    SQLiteDatabase sQLiteDatabase = getWritableDatabase("Error opening database for requestNumHitsPending");
    if (sQLiteDatabase == null)
      return 0; 
    Cursor cursor = null;
    null = null;
    try {
      Cursor cursor1 = sQLiteDatabase.rawQuery("SELECT COUNT(*) from hits2", null);
      null = cursor1;
      cursor = cursor1;
      if (cursor1.moveToFirst()) {
        null = cursor1;
        cursor = cursor1;
        long l = cursor1.getLong(0);
        i = (int)l;
      } 
      int j = i;
      return j;
    } catch (SQLiteException sQLiteException) {
      cursor = null;
      Log.w("Error getting numStoredHits");
      boolean bool1 = bool;
      return bool1;
    } finally {
      if (cursor != null)
        cursor.close(); 
    } 
  }
  
  public List<Hit> peekHits(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 'Error opening database for peekHits'
    //   4: invokespecial getWritableDatabase : (Ljava/lang/String;)Landroid/database/sqlite/SQLiteDatabase;
    //   7: astore #8
    //   9: aload #8
    //   11: ifnonnull -> 26
    //   14: new java/util/ArrayList
    //   17: dup
    //   18: invokespecial <init> : ()V
    //   21: astore #5
    //   23: aload #5
    //   25: areturn
    //   26: aconst_null
    //   27: astore #7
    //   29: aconst_null
    //   30: astore #4
    //   32: new java/util/ArrayList
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: pop
    //   40: aload #4
    //   42: astore #6
    //   44: aload #7
    //   46: astore #5
    //   48: ldc_w '%s ASC, %s ASC'
    //   51: iconst_2
    //   52: anewarray java/lang/Object
    //   55: dup
    //   56: iconst_0
    //   57: ldc 'hit_url'
    //   59: aastore
    //   60: dup
    //   61: iconst_1
    //   62: ldc 'hit_id'
    //   64: aastore
    //   65: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   68: astore #9
    //   70: aload #4
    //   72: astore #6
    //   74: aload #7
    //   76: astore #5
    //   78: iload_1
    //   79: invokestatic toString : (I)Ljava/lang/String;
    //   82: astore #10
    //   84: aload #4
    //   86: astore #6
    //   88: aload #7
    //   90: astore #5
    //   92: aload #8
    //   94: ldc 'hits2'
    //   96: iconst_3
    //   97: anewarray java/lang/String
    //   100: dup
    //   101: iconst_0
    //   102: ldc 'hit_id'
    //   104: aastore
    //   105: dup
    //   106: iconst_1
    //   107: ldc 'hit_time'
    //   109: aastore
    //   110: dup
    //   111: iconst_2
    //   112: ldc 'hit_url'
    //   114: aastore
    //   115: aconst_null
    //   116: aconst_null
    //   117: aconst_null
    //   118: aconst_null
    //   119: aload #9
    //   121: aload #10
    //   123: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   126: astore #4
    //   128: aload #4
    //   130: astore #6
    //   132: aload #4
    //   134: astore #5
    //   136: new java/util/ArrayList
    //   139: dup
    //   140: invokespecial <init> : ()V
    //   143: astore #7
    //   145: aload #4
    //   147: invokeinterface moveToFirst : ()Z
    //   152: ifeq -> 216
    //   155: new com/google/analytics/tracking/android/Hit
    //   158: dup
    //   159: aconst_null
    //   160: aload #4
    //   162: iconst_0
    //   163: invokeinterface getLong : (I)J
    //   168: aload #4
    //   170: iconst_1
    //   171: invokeinterface getLong : (I)J
    //   176: invokespecial <init> : (Ljava/lang/String;JJ)V
    //   179: astore #5
    //   181: aload #5
    //   183: aload #4
    //   185: iconst_2
    //   186: invokeinterface getString : (I)Ljava/lang/String;
    //   191: invokevirtual setHitUrl : (Ljava/lang/String;)V
    //   194: aload #7
    //   196: aload #5
    //   198: invokeinterface add : (Ljava/lang/Object;)Z
    //   203: pop
    //   204: aload #4
    //   206: invokeinterface moveToNext : ()Z
    //   211: istore_3
    //   212: iload_3
    //   213: ifne -> 155
    //   216: aload #4
    //   218: ifnull -> 228
    //   221: aload #4
    //   223: invokeinterface close : ()V
    //   228: iconst_0
    //   229: istore_2
    //   230: aload #4
    //   232: astore #6
    //   234: aload #4
    //   236: astore #5
    //   238: ldc_w '%s ASC'
    //   241: iconst_1
    //   242: anewarray java/lang/Object
    //   245: dup
    //   246: iconst_0
    //   247: ldc 'hit_id'
    //   249: aastore
    //   250: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   253: astore #9
    //   255: aload #4
    //   257: astore #6
    //   259: aload #4
    //   261: astore #5
    //   263: iload_1
    //   264: invokestatic toString : (I)Ljava/lang/String;
    //   267: astore #10
    //   269: aload #4
    //   271: astore #6
    //   273: aload #4
    //   275: astore #5
    //   277: aload #8
    //   279: ldc 'hits2'
    //   281: iconst_2
    //   282: anewarray java/lang/String
    //   285: dup
    //   286: iconst_0
    //   287: ldc 'hit_id'
    //   289: aastore
    //   290: dup
    //   291: iconst_1
    //   292: ldc 'hit_string'
    //   294: aastore
    //   295: aconst_null
    //   296: aconst_null
    //   297: aconst_null
    //   298: aconst_null
    //   299: aload #9
    //   301: aload #10
    //   303: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   306: astore #4
    //   308: aload #4
    //   310: astore #6
    //   312: aload #4
    //   314: astore #5
    //   316: aload #4
    //   318: invokeinterface moveToFirst : ()Z
    //   323: ifeq -> 420
    //   326: iload_2
    //   327: istore_1
    //   328: aload #4
    //   330: astore #6
    //   332: aload #4
    //   334: astore #5
    //   336: aload #4
    //   338: instanceof android/database/sqlite/SQLiteCursor
    //   341: ifeq -> 718
    //   344: aload #4
    //   346: astore #6
    //   348: aload #4
    //   350: astore #5
    //   352: aload #4
    //   354: checkcast android/database/sqlite/SQLiteCursor
    //   357: invokevirtual getWindow : ()Landroid/database/CursorWindow;
    //   360: invokevirtual getNumRows : ()I
    //   363: ifle -> 534
    //   366: aload #4
    //   368: astore #6
    //   370: aload #4
    //   372: astore #5
    //   374: aload #7
    //   376: iload_1
    //   377: invokeinterface get : (I)Ljava/lang/Object;
    //   382: checkcast com/google/analytics/tracking/android/Hit
    //   385: aload #4
    //   387: iconst_1
    //   388: invokeinterface getString : (I)Ljava/lang/String;
    //   393: invokevirtual setHitString : (Ljava/lang/String;)V
    //   396: iload_1
    //   397: iconst_1
    //   398: iadd
    //   399: istore_1
    //   400: aload #4
    //   402: astore #6
    //   404: aload #4
    //   406: astore #5
    //   408: aload #4
    //   410: invokeinterface moveToNext : ()Z
    //   415: istore_3
    //   416: iload_3
    //   417: ifne -> 328
    //   420: aload #7
    //   422: astore #5
    //   424: aload #4
    //   426: ifnull -> 23
    //   429: aload #4
    //   431: invokeinterface close : ()V
    //   436: aload #7
    //   438: areturn
    //   439: astore #7
    //   441: aload #6
    //   443: astore #4
    //   445: aload #4
    //   447: astore #5
    //   449: new java/lang/StringBuilder
    //   452: dup
    //   453: invokespecial <init> : ()V
    //   456: ldc_w 'error in peekHits fetching hitIds: '
    //   459: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   462: aload #7
    //   464: invokevirtual getMessage : ()Ljava/lang/String;
    //   467: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   470: invokevirtual toString : ()Ljava/lang/String;
    //   473: invokestatic w : (Ljava/lang/String;)I
    //   476: pop
    //   477: aload #4
    //   479: astore #5
    //   481: new java/util/ArrayList
    //   484: dup
    //   485: invokespecial <init> : ()V
    //   488: astore #6
    //   490: aload #6
    //   492: astore #5
    //   494: aload #4
    //   496: ifnull -> 23
    //   499: aload #4
    //   501: invokeinterface close : ()V
    //   506: aload #6
    //   508: areturn
    //   509: astore #6
    //   511: aload #5
    //   513: astore #4
    //   515: aload #6
    //   517: astore #5
    //   519: aload #4
    //   521: ifnull -> 531
    //   524: aload #4
    //   526: invokeinterface close : ()V
    //   531: aload #5
    //   533: athrow
    //   534: aload #4
    //   536: astore #6
    //   538: aload #4
    //   540: astore #5
    //   542: new java/lang/StringBuilder
    //   545: dup
    //   546: invokespecial <init> : ()V
    //   549: ldc_w 'hitString for hitId '
    //   552: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   555: aload #7
    //   557: iload_1
    //   558: invokeinterface get : (I)Ljava/lang/Object;
    //   563: checkcast com/google/analytics/tracking/android/Hit
    //   566: invokevirtual getHitId : ()J
    //   569: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   572: ldc_w ' too large.  Hit will be deleted.'
    //   575: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   578: invokevirtual toString : ()Ljava/lang/String;
    //   581: invokestatic w : (Ljava/lang/String;)I
    //   584: pop
    //   585: goto -> 396
    //   588: astore #4
    //   590: aload #6
    //   592: astore #5
    //   594: new java/lang/StringBuilder
    //   597: dup
    //   598: invokespecial <init> : ()V
    //   601: ldc_w 'error in peekHits fetching hitString: '
    //   604: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   607: aload #4
    //   609: invokevirtual getMessage : ()Ljava/lang/String;
    //   612: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   615: invokevirtual toString : ()Ljava/lang/String;
    //   618: invokestatic w : (Ljava/lang/String;)I
    //   621: pop
    //   622: aload #6
    //   624: astore #5
    //   626: new java/util/ArrayList
    //   629: dup
    //   630: invokespecial <init> : ()V
    //   633: astore #4
    //   635: iconst_0
    //   636: istore_1
    //   637: aload #6
    //   639: astore #5
    //   641: aload #7
    //   643: invokeinterface iterator : ()Ljava/util/Iterator;
    //   648: astore #7
    //   650: aload #6
    //   652: astore #5
    //   654: aload #7
    //   656: invokeinterface hasNext : ()Z
    //   661: ifeq -> 703
    //   664: aload #6
    //   666: astore #5
    //   668: aload #7
    //   670: invokeinterface next : ()Ljava/lang/Object;
    //   675: checkcast com/google/analytics/tracking/android/Hit
    //   678: astore #8
    //   680: aload #6
    //   682: astore #5
    //   684: aload #8
    //   686: invokevirtual getHitParams : ()Ljava/lang/String;
    //   689: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   692: istore_3
    //   693: iload_1
    //   694: istore_2
    //   695: iload_3
    //   696: ifeq -> 770
    //   699: iload_1
    //   700: ifeq -> 768
    //   703: aload #6
    //   705: ifnull -> 715
    //   708: aload #6
    //   710: invokeinterface close : ()V
    //   715: aload #4
    //   717: areturn
    //   718: aload #4
    //   720: astore #6
    //   722: aload #4
    //   724: astore #5
    //   726: aload #7
    //   728: iload_1
    //   729: invokeinterface get : (I)Ljava/lang/Object;
    //   734: checkcast com/google/analytics/tracking/android/Hit
    //   737: aload #4
    //   739: iconst_1
    //   740: invokeinterface getString : (I)Ljava/lang/String;
    //   745: invokevirtual setHitString : (Ljava/lang/String;)V
    //   748: goto -> 396
    //   751: astore #4
    //   753: aload #5
    //   755: ifnull -> 765
    //   758: aload #5
    //   760: invokeinterface close : ()V
    //   765: aload #4
    //   767: athrow
    //   768: iconst_1
    //   769: istore_2
    //   770: aload #6
    //   772: astore #5
    //   774: aload #4
    //   776: aload #8
    //   778: invokeinterface add : (Ljava/lang/Object;)Z
    //   783: pop
    //   784: iload_2
    //   785: istore_1
    //   786: goto -> 650
    //   789: astore #5
    //   791: goto -> 519
    //   794: astore #7
    //   796: goto -> 445
    // Exception table:
    //   from	to	target	type
    //   48	70	439	android/database/sqlite/SQLiteException
    //   48	70	509	finally
    //   78	84	439	android/database/sqlite/SQLiteException
    //   78	84	509	finally
    //   92	128	439	android/database/sqlite/SQLiteException
    //   92	128	509	finally
    //   136	145	439	android/database/sqlite/SQLiteException
    //   136	145	509	finally
    //   145	155	794	android/database/sqlite/SQLiteException
    //   145	155	789	finally
    //   155	212	794	android/database/sqlite/SQLiteException
    //   155	212	789	finally
    //   238	255	588	android/database/sqlite/SQLiteException
    //   238	255	751	finally
    //   263	269	588	android/database/sqlite/SQLiteException
    //   263	269	751	finally
    //   277	308	588	android/database/sqlite/SQLiteException
    //   277	308	751	finally
    //   316	326	588	android/database/sqlite/SQLiteException
    //   316	326	751	finally
    //   336	344	588	android/database/sqlite/SQLiteException
    //   336	344	751	finally
    //   352	366	588	android/database/sqlite/SQLiteException
    //   352	366	751	finally
    //   374	396	588	android/database/sqlite/SQLiteException
    //   374	396	751	finally
    //   408	416	588	android/database/sqlite/SQLiteException
    //   408	416	751	finally
    //   449	477	509	finally
    //   481	490	509	finally
    //   542	585	588	android/database/sqlite/SQLiteException
    //   542	585	751	finally
    //   594	622	751	finally
    //   626	635	751	finally
    //   641	650	751	finally
    //   654	664	751	finally
    //   668	680	751	finally
    //   684	693	751	finally
    //   726	748	588	android/database/sqlite/SQLiteException
    //   726	748	751	finally
    //   774	784	751	finally
  }
  
  public void putHit(Map<String, String> paramMap, long paramLong, String paramString, Collection<Command> paramCollection) {
    deleteStaleHits();
    fillVersionParametersIfNecessary(paramMap, paramCollection);
    removeOldHitIfFull();
    writeHitToDatabase(paramMap, paramLong, paramString);
  }
  
  @VisibleForTesting
  public void setClock(Clock paramClock) {
    this.mClock = paramClock;
  }
  
  public void setDispatch(boolean paramBoolean) {
    NoopDispatcher noopDispatcher;
    if (paramBoolean) {
      SimpleNetworkDispatcher simpleNetworkDispatcher = new SimpleNetworkDispatcher(this, createDefaultHttpClientFactory(), this.mContext);
    } else {
      noopDispatcher = new NoopDispatcher();
    } 
    this.mDispatcher = noopDispatcher;
  }
  
  @VisibleForTesting
  void setDispatcher(Dispatcher paramDispatcher) {
    this.mDispatcher = paramDispatcher;
  }
  
  @VisibleForTesting
  void setLastDeleteStaleHitsTime(long paramLong) {
    this.mLastDeleteStaleHitsTime = paramLong;
  }
  
  @VisibleForTesting
  class AnalyticsDatabaseHelper extends SQLiteOpenHelper {
    private boolean mBadDatabase;
    
    private long mLastDatabaseCheckTime = 0L;
    
    AnalyticsDatabaseHelper(Context param1Context, String param1String) {
      super(param1Context, param1String, null, 1);
    }
    
    private boolean tablePresent(String param1String, SQLiteDatabase param1SQLiteDatabase) {
      Cursor cursor2 = null;
      Cursor cursor1 = null;
      try {
        Cursor cursor = param1SQLiteDatabase.query("SQLITE_MASTER", new String[] { "name" }, "name=?", new String[] { param1String }, null, null, null);
        cursor1 = cursor;
        cursor2 = cursor;
        return cursor.moveToFirst();
      } catch (SQLiteException sQLiteException) {
        cursor2 = cursor1;
        Log.w("error querying for table " + param1String);
        return false;
      } finally {
        if (cursor2 != null)
          cursor2.close(); 
      } 
    }
    
    private void validateColumnsPresent(SQLiteDatabase param1SQLiteDatabase) {
      boolean bool;
      Cursor cursor = param1SQLiteDatabase.rawQuery("SELECT * FROM hits2 WHERE 0", null);
      HashSet<String> hashSet = new HashSet();
      try {
        String[] arrayOfString = cursor.getColumnNames();
        for (bool = false; bool < arrayOfString.length; bool++)
          hashSet.add(arrayOfString[bool]); 
        cursor.close();
      } finally {
        cursor.close();
      } 
      if (!hashSet.remove("hit_app_id")) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!hashSet.isEmpty())
        throw new SQLiteException("Database has extra columns"); 
      if (bool)
        param1SQLiteDatabase.execSQL("ALTER TABLE hits2 ADD COLUMN hit_app_id"); 
    }
    
    public SQLiteDatabase getWritableDatabase() {
      if (this.mBadDatabase && this.mLastDatabaseCheckTime + 3600000L > PersistentAnalyticsStore.this.mClock.currentTimeMillis())
        throw new SQLiteException("Database creation failed"); 
      SQLiteDatabase sQLiteDatabase1 = null;
      this.mBadDatabase = true;
      this.mLastDatabaseCheckTime = PersistentAnalyticsStore.this.mClock.currentTimeMillis();
      try {
        SQLiteDatabase sQLiteDatabase = super.getWritableDatabase();
        sQLiteDatabase1 = sQLiteDatabase;
      } catch (SQLiteException sQLiteException) {
        PersistentAnalyticsStore.this.mContext.getDatabasePath(PersistentAnalyticsStore.this.mDatabaseName).delete();
      } 
      SQLiteDatabase sQLiteDatabase2 = sQLiteDatabase1;
      if (sQLiteDatabase1 == null)
        sQLiteDatabase2 = super.getWritableDatabase(); 
      this.mBadDatabase = false;
      return sQLiteDatabase2;
    }
    
    boolean isBadDatabase() {
      return this.mBadDatabase;
    }
    
    public void onCreate(SQLiteDatabase param1SQLiteDatabase) {
      FutureApis.setOwnerOnlyReadWrite(param1SQLiteDatabase.getPath());
    }
    
    public void onOpen(SQLiteDatabase param1SQLiteDatabase) {
      if (Build.VERSION.SDK_INT < 15) {
        Cursor cursor = param1SQLiteDatabase.rawQuery("PRAGMA journal_mode=memory", null);
        try {
          cursor.moveToFirst();
          cursor.close();
        } finally {
          cursor.close();
        } 
        validateColumnsPresent(param1SQLiteDatabase);
        return;
      } 
      if (!tablePresent("hits2", param1SQLiteDatabase)) {
        param1SQLiteDatabase.execSQL(PersistentAnalyticsStore.CREATE_HITS_TABLE);
        return;
      } 
    }
    
    public void onUpgrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {}
    
    void setBadDatabase(boolean param1Boolean) {
      this.mBadDatabase = param1Boolean;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\PersistentAnalyticsStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */