package com.google.analytics.tracking.android;

import android.text.TextUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Transaction {
  private final String mAffiliation;
  
  private final String mCurrencyCode;
  
  private final Map<String, Item> mItems;
  
  private final long mShippingCostInMicros;
  
  private final long mTotalCostInMicros;
  
  private final long mTotalTaxInMicros;
  
  private final String mTransactionId;
  
  private Transaction(Builder paramBuilder) {
    this.mTransactionId = paramBuilder.mTransactionId;
    this.mTotalCostInMicros = paramBuilder.mTotalCostInMicros;
    this.mAffiliation = paramBuilder.mAffiliation;
    this.mTotalTaxInMicros = paramBuilder.mTotalTaxInMicros;
    this.mShippingCostInMicros = paramBuilder.mShippingCostInMicros;
    this.mCurrencyCode = paramBuilder.mCurrencyCode;
    this.mItems = new HashMap<String, Item>();
  }
  
  public void addItem(Item paramItem) {
    this.mItems.put(paramItem.getSKU(), paramItem);
  }
  
  public String getAffiliation() {
    return this.mAffiliation;
  }
  
  public String getCurrencyCode() {
    return this.mCurrencyCode;
  }
  
  public List<Item> getItems() {
    return new ArrayList<Item>(this.mItems.values());
  }
  
  public long getShippingCostInMicros() {
    return this.mShippingCostInMicros;
  }
  
  public long getTotalCostInMicros() {
    return this.mTotalCostInMicros;
  }
  
  public long getTotalTaxInMicros() {
    return this.mTotalTaxInMicros;
  }
  
  public String getTransactionId() {
    return this.mTransactionId;
  }
  
  public static final class Builder {
    private String mAffiliation = null;
    
    private String mCurrencyCode = null;
    
    private long mShippingCostInMicros = 0L;
    
    private final long mTotalCostInMicros;
    
    private long mTotalTaxInMicros = 0L;
    
    private final String mTransactionId;
    
    public Builder(String param1String, long param1Long) {
      if (TextUtils.isEmpty(param1String))
        throw new IllegalArgumentException("orderId must not be empty or null"); 
      this.mTransactionId = param1String;
      this.mTotalCostInMicros = param1Long;
    }
    
    public Transaction build() {
      return new Transaction(this);
    }
    
    public Builder setAffiliation(String param1String) {
      this.mAffiliation = param1String;
      return this;
    }
    
    public Builder setCurrencyCode(String param1String) {
      this.mCurrencyCode = param1String;
      return this;
    }
    
    public Builder setShippingCostInMicros(long param1Long) {
      this.mShippingCostInMicros = param1Long;
      return this;
    }
    
    public Builder setTotalTaxInMicros(long param1Long) {
      this.mTotalTaxInMicros = param1Long;
      return this;
    }
  }
  
  public static final class Item {
    private final String mCategory;
    
    private final String mName;
    
    private final long mPriceInMicros;
    
    private final long mQuantity;
    
    private final String mSKU;
    
    private Item(Builder param1Builder) {
      this.mSKU = param1Builder.mSKU;
      this.mPriceInMicros = param1Builder.mPriceInMicros;
      this.mQuantity = param1Builder.mQuantity;
      this.mName = param1Builder.mName;
      this.mCategory = param1Builder.mCategory;
    }
    
    public String getCategory() {
      return this.mCategory;
    }
    
    public String getName() {
      return this.mName;
    }
    
    public long getPriceInMicros() {
      return this.mPriceInMicros;
    }
    
    public long getQuantity() {
      return this.mQuantity;
    }
    
    public String getSKU() {
      return this.mSKU;
    }
    
    public static final class Builder {
      private String mCategory = null;
      
      private final String mName;
      
      private final long mPriceInMicros;
      
      private final long mQuantity;
      
      private final String mSKU;
      
      public Builder(String param2String1, String param2String2, long param2Long1, long param2Long2) {
        if (TextUtils.isEmpty(param2String1))
          throw new IllegalArgumentException("SKU must not be empty or null"); 
        if (TextUtils.isEmpty(param2String2))
          throw new IllegalArgumentException("name must not be empty or null"); 
        this.mSKU = param2String1;
        this.mName = param2String2;
        this.mPriceInMicros = param2Long1;
        this.mQuantity = param2Long2;
      }
      
      public Transaction.Item build() {
        return new Transaction.Item(this);
      }
      
      public Builder setProductCategory(String param2String) {
        this.mCategory = param2String;
        return this;
      }
    }
  }
  
  public static final class Builder {
    private String mCategory = null;
    
    private final String mName;
    
    private final long mPriceInMicros;
    
    private final long mQuantity;
    
    private final String mSKU;
    
    public Builder(String param1String1, String param1String2, long param1Long1, long param1Long2) {
      if (TextUtils.isEmpty(param1String1))
        throw new IllegalArgumentException("SKU must not be empty or null"); 
      if (TextUtils.isEmpty(param1String2))
        throw new IllegalArgumentException("name must not be empty or null"); 
      this.mSKU = param1String1;
      this.mName = param1String2;
      this.mPriceInMicros = param1Long1;
      this.mQuantity = param1Long2;
    }
    
    public Transaction.Item build() {
      return new Transaction.Item(this);
    }
    
    public Builder setProductCategory(String param1String) {
      this.mCategory = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\Transaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */