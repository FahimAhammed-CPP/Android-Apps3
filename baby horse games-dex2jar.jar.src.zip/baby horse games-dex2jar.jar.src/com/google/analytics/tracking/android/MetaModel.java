package com.google.analytics.tracking.android;

import com.google.android.gms.common.util.VisibleForTesting;
import java.util.HashMap;
import java.util.Map;

class MetaModel {
  private Map<String, MetaInfo> mMetaInfos = new HashMap<String, MetaInfo>();
  
  public void addField(String paramString1, String paramString2, String paramString3, Formatter paramFormatter) {
    this.mMetaInfos.put(paramString1, new MetaInfo(paramString2, paramString3, paramFormatter));
  }
  
  MetaInfo getMetaInfo(String paramString) {
    if (paramString.startsWith("&"))
      return new MetaInfo(paramString.substring(1), null, null); 
    String str = paramString;
    if (paramString.contains("*"))
      str = paramString.substring(0, paramString.indexOf("*")); 
    return this.mMetaInfos.get(str);
  }
  
  public static interface Formatter {
    String format(String param1String);
  }
  
  public static class MetaInfo {
    private final String mDefaultValue;
    
    private final MetaModel.Formatter mFormatter;
    
    private final String mUrlParam;
    
    public MetaInfo(String param1String1, String param1String2, MetaModel.Formatter param1Formatter) {
      this.mUrlParam = param1String1;
      this.mDefaultValue = param1String2;
      this.mFormatter = param1Formatter;
    }
    
    public String getDefaultValue() {
      return this.mDefaultValue;
    }
    
    public MetaModel.Formatter getFormatter() {
      return this.mFormatter;
    }
    
    @VisibleForTesting
    String getUrlParam() {
      return this.mUrlParam;
    }
    
    public String getUrlParam(String param1String) {
      String str = null;
      if (param1String.contains("*")) {
        String str1 = this.mUrlParam;
        String[] arrayOfString = param1String.split("\\*");
        param1String = str;
        if (arrayOfString.length > 1)
          try {
            int i = Integer.parseInt(arrayOfString[1]);
            return str1 + i;
          } catch (NumberFormatException numberFormatException) {
            Log.w("Unable to parse slot for url parameter " + str1);
            return null;
          }  
        return (String)numberFormatException;
      } 
      return this.mUrlParam;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\MetaModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */