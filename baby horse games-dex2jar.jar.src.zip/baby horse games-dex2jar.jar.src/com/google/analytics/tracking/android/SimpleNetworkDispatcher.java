package com.google.analytics.tracking.android;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.text.TextUtils;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Locale;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;

class SimpleNetworkDispatcher implements Dispatcher {
  private static final String USER_AGENT_TEMPLATE = "%s/%s (Linux; U; Android %s; %s; %s Build/%s)";
  
  private final Context ctx;
  
  private final HttpClientFactory httpClientFactory;
  
  private final String userAgent;
  
  SimpleNetworkDispatcher(AnalyticsStore paramAnalyticsStore, HttpClientFactory paramHttpClientFactory, Context paramContext) {
    this(paramHttpClientFactory, paramContext);
  }
  
  SimpleNetworkDispatcher(HttpClientFactory paramHttpClientFactory, Context paramContext) {
    this.ctx = paramContext.getApplicationContext();
    this.userAgent = createUserAgentString("GoogleAnalytics", "2.0", Build.VERSION.RELEASE, Utils.getLanguage(Locale.getDefault()), Build.MODEL, Build.ID);
    this.httpClientFactory = paramHttpClientFactory;
  }
  
  private HttpEntityEnclosingRequest buildRequest(String paramString1, String paramString2) {
    BasicHttpEntityEnclosingRequest basicHttpEntityEnclosingRequest1;
    if (TextUtils.isEmpty(paramString1)) {
      Log.w("Empty hit, discarding.");
      return null;
    } 
    String str = paramString2 + "?" + paramString1;
    if (str.length() < 2036) {
      basicHttpEntityEnclosingRequest1 = new BasicHttpEntityEnclosingRequest("GET", str);
      basicHttpEntityEnclosingRequest1.addHeader("User-Agent", this.userAgent);
      return (HttpEntityEnclosingRequest)basicHttpEntityEnclosingRequest1;
    } 
    BasicHttpEntityEnclosingRequest basicHttpEntityEnclosingRequest2 = new BasicHttpEntityEnclosingRequest("POST", paramString2);
    try {
      basicHttpEntityEnclosingRequest2.setEntity((HttpEntity)new StringEntity((String)basicHttpEntityEnclosingRequest1));
      basicHttpEntityEnclosingRequest1 = basicHttpEntityEnclosingRequest2;
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      Log.w("Encoding error, discarding hit");
      return null;
    } 
    unsupportedEncodingException.addHeader("User-Agent", this.userAgent);
    return (HttpEntityEnclosingRequest)unsupportedEncodingException;
  }
  
  private URL getUrl(Hit paramHit) {
    if (TextUtils.isEmpty(paramHit.getHitUrl()))
      return null; 
    try {
      return new URL(paramHit.getHitUrl());
    } catch (MalformedURLException malformedURLException) {
      try {
        return new URL("http://www.google-analytics.com/collect");
      } catch (MalformedURLException malformedURLException1) {
        return null;
      } 
    } 
  }
  
  private void logDebugInformation(boolean paramBoolean, HttpEntityEnclosingRequest paramHttpEntityEnclosingRequest) {
    if (paramBoolean) {
      StringBuffer stringBuffer = new StringBuffer();
      Header[] arrayOfHeader = paramHttpEntityEnclosingRequest.getAllHeaders();
      int j = arrayOfHeader.length;
      int i;
      for (i = 0; i < j; i++)
        stringBuffer.append(arrayOfHeader[i].toString()).append("\n"); 
      stringBuffer.append(paramHttpEntityEnclosingRequest.getRequestLine().toString()).append("\n");
      if (paramHttpEntityEnclosingRequest.getEntity() != null)
        try {
          InputStream inputStream = paramHttpEntityEnclosingRequest.getEntity().getContent();
          if (inputStream != null) {
            i = inputStream.available();
            if (i > 0) {
              byte[] arrayOfByte = new byte[i];
              inputStream.read(arrayOfByte);
              stringBuffer.append("POST:\n");
              stringBuffer.append(new String(arrayOfByte)).append("\n");
            } 
          } 
        } catch (IOException iOException) {
          Log.w("Error Writing hit to log...");
        }  
      Log.i(stringBuffer.toString());
    } 
  }
  
  String createUserAgentString(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6) {
    return String.format("%s/%s (Linux; U; Android %s; %s; %s Build/%s)", new Object[] { paramString1, paramString2, paramString3, paramString4, paramString5, paramString6 });
  }
  
  public int dispatchHits(List<Hit> paramList) {
    int i = 0;
    int k = Math.min(paramList.size(), 40);
    int j = 0;
    while (true) {
      if (j < k) {
        HttpClient httpClient = this.httpClientFactory.newInstance();
        Hit hit = paramList.get(j);
        URL uRL = getUrl(hit);
        if (uRL == null) {
          if (Log.isDebugEnabled()) {
            Log.w("No destination: discarding hit: " + hit.getHitParams());
          } else {
            Log.w("No destination: discarding hit.");
          } 
          i++;
        } else {
          String str1;
          HttpHost httpHost = new HttpHost(uRL.getHost(), uRL.getPort(), uRL.getProtocol());
          String str2 = uRL.getPath();
          if (TextUtils.isEmpty(hit.getHitParams())) {
            str1 = "";
          } else {
            str1 = HitBuilder.postProcessHit((Hit)str1, System.currentTimeMillis());
          } 
          HttpEntityEnclosingRequest httpEntityEnclosingRequest = buildRequest(str1, str2);
          if (httpEntityEnclosingRequest == null) {
            i++;
          } else {
            httpEntityEnclosingRequest.addHeader("Host", httpHost.toHostString());
            logDebugInformation(Log.isDebugEnabled(), httpEntityEnclosingRequest);
            if (str1.length() > 8192) {
              Log.w("Hit too long (> 8192 bytes)--not sent");
            } else {
              try {
                HttpResponse httpResponse = httpClient.execute(httpHost, (HttpRequest)httpEntityEnclosingRequest);
                if (httpResponse.getStatusLine().getStatusCode() != 200) {
                  Log.w("Bad response: " + httpResponse.getStatusLine().getStatusCode());
                  return i;
                } 
                i++;
              } catch (ClientProtocolException clientProtocolException) {
                Log.w("ClientProtocolException sending hit; discarding hit...");
                i++;
              } catch (IOException iOException) {
                Log.w("Exception sending hit: " + iOException.getClass().getSimpleName());
                Log.w(iOException.getMessage());
                return i;
              } 
              continue;
            } 
            i++;
          } 
        } 
        j++;
      } 
      return i;
    } 
  }
  
  public boolean okToDispatch() {
    NetworkInfo networkInfo = ((ConnectivityManager)this.ctx.getSystemService("connectivity")).getActiveNetworkInfo();
    if (networkInfo == null || !networkInfo.isConnected()) {
      Log.vDebug("...no network connectivity");
      return false;
    } 
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\SimpleNetworkDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */