package com.google.analytics.tracking.android;

import java.util.Map;
import java.util.Random;

class AdMobInfo {
  private static final AdMobInfo INSTANCE = new AdMobInfo();
  
  private int mAdHitId;
  
  private Random mRandom = new Random();
  
  static AdMobInfo getInstance() {
    return INSTANCE;
  }
  
  int generateAdHitId() {
    this.mAdHitId = this.mRandom.nextInt(2147483646) + 1;
    return this.mAdHitId;
  }
  
  int getAdHitId() {
    return this.mAdHitId;
  }
  
  Map<String, String> getJoinIds() {
    return null;
  }
  
  void setAdHitId(int paramInt) {
    this.mAdHitId = paramInt;
  }
  
  enum AdMobKey {
    CLIENT_ID_KEY("ga_cid"),
    HIT_ID_KEY("ga_hid"),
    PROPERTY_ID_KEY("ga_wpids"),
    VISITOR_ID_KEY("ga_uid");
    
    private String mBowParameter;
    
    static {
    
    }
    
    AdMobKey(String param1String1) {
      this.mBowParameter = param1String1;
    }
    
    String getBowParameter() {
      return this.mBowParameter;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\AdMobInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */