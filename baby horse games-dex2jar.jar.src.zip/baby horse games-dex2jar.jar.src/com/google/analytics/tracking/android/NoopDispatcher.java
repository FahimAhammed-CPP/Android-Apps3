package com.google.analytics.tracking.android;

import android.text.TextUtils;
import java.util.List;

class NoopDispatcher implements Dispatcher {
  public int dispatchHits(List<Hit> paramList) {
    if (paramList == null)
      return 0; 
    Log.iDebug("Hits not actually being sent as dispatch is false...");
    int j = Math.min(paramList.size(), 40);
    int i = 0;
    while (true) {
      int k = j;
      if (i < j) {
        if (Log.isDebugEnabled()) {
          String str1;
          String str2;
          if (TextUtils.isEmpty(((Hit)paramList.get(i)).getHitParams())) {
            str2 = "";
          } else {
            str2 = HitBuilder.postProcessHit(paramList.get(i), System.currentTimeMillis());
          } 
          if (TextUtils.isEmpty(str2)) {
            str1 = "Hit couldn't be read, wouldn't be sent:";
          } else if (str2.length() <= 2036) {
            str1 = "GET would be sent:";
          } else if (str2.length() > 8192) {
            str1 = "Would be too big:";
          } else {
            str1 = "POST would be sent:";
          } 
          Log.iDebug(str1 + str2);
        } 
        i++;
        continue;
      } 
      return k;
    } 
  }
  
  public boolean okToDispatch() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\NoopDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */