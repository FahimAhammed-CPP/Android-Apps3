package com.google.analytics.tracking.android;

import android.text.TextUtils;
import com.google.android.gms.common.util.VisibleForTesting;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

public class Tracker {
  private static final DecimalFormat DF = new DecimalFormat("0.######", new DecimalFormatSymbols(Locale.US));
  
  static final long MAX_TOKENS = 120000L;
  
  static final long TIME_PER_TOKEN_MILLIS = 2000L;
  
  private volatile ExceptionParser mExceptionParser;
  
  private final TrackerHandler mHandler;
  
  private boolean mIsThrottlingEnabled = true;
  
  private volatile boolean mIsTrackerClosed = false;
  
  private volatile boolean mIsTrackingStarted = false;
  
  private long mLastTrackTime;
  
  private final SimpleModel mModel;
  
  private long mTokens = 120000L;
  
  Tracker() {
    this.mHandler = null;
    this.mModel = null;
  }
  
  Tracker(String paramString, TrackerHandler paramTrackerHandler) {
    if (paramString == null)
      throw new IllegalArgumentException("trackingId cannot be null"); 
    this.mHandler = paramTrackerHandler;
    this.mModel = new SimpleModel();
    this.mModel.set("trackingId", paramString);
    this.mModel.set("sampleRate", "100");
    this.mModel.setForNextHit("sessionControl", "start");
    this.mModel.set("useSecure", Boolean.toString(true));
  }
  
  private void assertTrackerOpen() {
    if (this.mIsTrackerClosed)
      throw new IllegalStateException("Tracker closed"); 
  }
  
  private Map<String, String> constructItem(Transaction.Item paramItem, Transaction paramTransaction) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("transactionId", paramTransaction.getTransactionId());
    hashMap.put("currencyCode", paramTransaction.getCurrencyCode());
    hashMap.put("itemCode", paramItem.getSKU());
    hashMap.put("itemName", paramItem.getName());
    hashMap.put("itemCategory", paramItem.getCategory());
    hashMap.put("itemPrice", microsToCurrencyString(paramItem.getPriceInMicros()));
    hashMap.put("itemQuantity", Long.toString(paramItem.getQuantity()));
    GAUsage.getInstance().setUsage(GAUsage.Field.CONSTRUCT_ITEM);
    return (Map)hashMap;
  }
  
  private void internalSend(String paramString, Map<String, String> paramMap) {
    this.mIsTrackingStarted = true;
    Map<String, String> map = paramMap;
    if (paramMap == null)
      map = new HashMap<String, String>(); 
    map.put("hitType", paramString);
    this.mModel.setAll(map, Boolean.valueOf(true));
    if (!tokensAvailable()) {
      Log.wDebug("Too many hits sent too quickly, throttling invoked.");
    } else {
      this.mHandler.sendHit(this.mModel.getKeysAndValues());
    } 
    this.mModel.clearTemporaryValues();
  }
  
  private static String microsToCurrencyString(long paramLong) {
    return DF.format(paramLong / 1000000.0D);
  }
  
  public void close() {
    this.mIsTrackerClosed = true;
    this.mHandler.closeTracker(this);
  }
  
  public Map<String, String> constructEvent(String paramString1, String paramString2, String paramString3, Long paramLong) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("eventCategory", paramString1);
    hashMap.put("eventAction", paramString2);
    hashMap.put("eventLabel", paramString3);
    if (paramLong != null)
      hashMap.put("eventValue", Long.toString(paramLong.longValue())); 
    GAUsage.getInstance().setUsage(GAUsage.Field.CONSTRUCT_EVENT);
    return (Map)hashMap;
  }
  
  public Map<String, String> constructException(String paramString, boolean paramBoolean) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("exDescription", paramString);
    hashMap.put("exFatal", Boolean.toString(paramBoolean));
    GAUsage.getInstance().setUsage(GAUsage.Field.CONSTRUCT_EXCEPTION);
    return (Map)hashMap;
  }
  
  public Map<String, String> constructRawException(String paramString, Throwable paramThrowable, boolean paramBoolean) throws IOException {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
    objectOutputStream.writeObject(paramThrowable);
    objectOutputStream.close();
    hashMap.put("rawException", Utils.hexEncode(byteArrayOutputStream.toByteArray()));
    if (paramString != null)
      hashMap.put("exceptionThreadName", paramString); 
    hashMap.put("exFatal", Boolean.toString(paramBoolean));
    GAUsage.getInstance().setUsage(GAUsage.Field.CONSTRUCT_RAW_EXCEPTION);
    return (Map)hashMap;
  }
  
  public Map<String, String> constructSocial(String paramString1, String paramString2, String paramString3) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("socialNetwork", paramString1);
    hashMap.put("socialAction", paramString2);
    hashMap.put("socialTarget", paramString3);
    GAUsage.getInstance().setUsage(GAUsage.Field.CONSTRUCT_SOCIAL);
    return (Map)hashMap;
  }
  
  public Map<String, String> constructTiming(String paramString1, long paramLong, String paramString2, String paramString3) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("timingCategory", paramString1);
    hashMap.put("timingValue", Long.toString(paramLong));
    hashMap.put("timingVar", paramString2);
    hashMap.put("timingLabel", paramString3);
    GAUsage.getInstance().setUsage(GAUsage.Field.CONSTRUCT_TIMING);
    return (Map)hashMap;
  }
  
  public Map<String, String> constructTransaction(Transaction paramTransaction) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("transactionId", paramTransaction.getTransactionId());
    hashMap.put("transactionAffiliation", paramTransaction.getAffiliation());
    hashMap.put("transactionShipping", microsToCurrencyString(paramTransaction.getShippingCostInMicros()));
    hashMap.put("transactionTax", microsToCurrencyString(paramTransaction.getTotalTaxInMicros()));
    hashMap.put("transactionTotal", microsToCurrencyString(paramTransaction.getTotalCostInMicros()));
    hashMap.put("currencyCode", paramTransaction.getCurrencyCode());
    GAUsage.getInstance().setUsage(GAUsage.Field.CONSTRUCT_TRANSACTION);
    return (Map)hashMap;
  }
  
  public String get(String paramString) {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET);
    return this.mModel.get(paramString);
  }
  
  public String getAppId() {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_APP_ID);
    return this.mModel.get("appId");
  }
  
  public String getAppInstallerId() {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_APP_INSTALLER_ID);
    return this.mModel.get("appInstallerId");
  }
  
  public ExceptionParser getExceptionParser() {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_EXCEPTION_PARSER);
    return this.mExceptionParser;
  }
  
  public double getSampleRate() {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_SAMPLE_RATE);
    return Utils.safeParseDouble(this.mModel.get("sampleRate"));
  }
  
  public String getTrackingId() {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_TRACKING_ID);
    return this.mModel.get("trackingId");
  }
  
  public boolean isAnonymizeIpEnabled() {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_ANONYMIZE_IP);
    return Utils.safeParseBoolean(this.mModel.get("anonymizeIp"));
  }
  
  public boolean isUseSecure() {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_USE_SECURE);
    return Boolean.parseBoolean(this.mModel.get("useSecure"));
  }
  
  public void send(String paramString, Map<String, String> paramMap) {
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.SEND);
    internalSend(paramString, paramMap);
  }
  
  public void sendEvent(String paramString1, String paramString2, String paramString3, Long paramLong) {
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.TRACK_EVENT);
    GAUsage.getInstance().setDisableUsage(true);
    internalSend("event", constructEvent(paramString1, paramString2, paramString3, paramLong));
    GAUsage.getInstance().setDisableUsage(false);
  }
  
  public void sendException(String paramString, Throwable paramThrowable, boolean paramBoolean) {
    String str;
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.TRACK_EXCEPTION_WITH_THROWABLE);
    if (this.mExceptionParser != null) {
      paramString = this.mExceptionParser.getDescription(paramString, paramThrowable);
    } else {
      try {
        GAUsage.getInstance().setDisableUsage(true);
        internalSend("exception", constructRawException(paramString, paramThrowable, paramBoolean));
        GAUsage.getInstance().setDisableUsage(false);
        return;
      } catch (IOException iOException) {
        Log.w("trackException: couldn't serialize, sending \"Unknown Exception\"");
        str = "Unknown Exception";
      } 
    } 
    GAUsage.getInstance().setDisableUsage(true);
    sendException(str, paramBoolean);
    GAUsage.getInstance().setDisableUsage(false);
  }
  
  public void sendException(String paramString, boolean paramBoolean) {
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.TRACK_EXCEPTION_WITH_DESCRIPTION);
    GAUsage.getInstance().setDisableUsage(true);
    internalSend("exception", constructException(paramString, paramBoolean));
    GAUsage.getInstance().setDisableUsage(false);
  }
  
  public void sendSocial(String paramString1, String paramString2, String paramString3) {
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.TRACK_SOCIAL);
    GAUsage.getInstance().setDisableUsage(true);
    internalSend("social", constructSocial(paramString1, paramString2, paramString3));
    GAUsage.getInstance().setDisableUsage(false);
  }
  
  public void sendTiming(String paramString1, long paramLong, String paramString2, String paramString3) {
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.TRACK_TIMING);
    GAUsage.getInstance().setDisableUsage(true);
    internalSend("timing", constructTiming(paramString1, paramLong, paramString2, paramString3));
    GAUsage.getInstance().setDisableUsage(false);
  }
  
  public void sendTransaction(Transaction paramTransaction) {
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.TRACK_TRANSACTION);
    GAUsage.getInstance().setDisableUsage(true);
    internalSend("tran", constructTransaction(paramTransaction));
    Iterator<Transaction.Item> iterator = paramTransaction.getItems().iterator();
    while (iterator.hasNext())
      internalSend("item", constructItem(iterator.next(), paramTransaction)); 
    GAUsage.getInstance().setDisableUsage(false);
  }
  
  public void sendView() {
    assertTrackerOpen();
    if (TextUtils.isEmpty(this.mModel.get("description")))
      throw new IllegalStateException("trackView requires a appScreen to be set"); 
    GAUsage.getInstance().setUsage(GAUsage.Field.TRACK_VIEW);
    internalSend("appview", null);
  }
  
  public void sendView(String paramString) {
    assertTrackerOpen();
    if (TextUtils.isEmpty(paramString))
      throw new IllegalStateException("trackView requires a appScreen to be set"); 
    GAUsage.getInstance().setUsage(GAUsage.Field.TRACK_VIEW_WITH_APPSCREEN);
    this.mModel.set("description", paramString);
    internalSend("appview", null);
  }
  
  public void set(String paramString1, String paramString2) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET);
    this.mModel.set(paramString1, paramString2);
  }
  
  public void setAnonymizeIp(boolean paramBoolean) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_ANONYMIZE_IP);
    this.mModel.set("anonymizeIp", Boolean.toString(paramBoolean));
  }
  
  public void setAppId(String paramString) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_APP_ID);
    this.mModel.set("appId", paramString);
  }
  
  public void setAppInstallerId(String paramString) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_APP_INSTALLER_ID);
    this.mModel.set("appInstallerId", paramString);
  }
  
  public void setAppName(String paramString) {
    if (this.mIsTrackingStarted) {
      Log.wDebug("Tracking already started, setAppName call ignored");
      return;
    } 
    if (TextUtils.isEmpty(paramString)) {
      Log.wDebug("setting appName to empty value not allowed, call ignored");
      return;
    } 
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_APP_NAME);
    this.mModel.set("appName", paramString);
  }
  
  public void setAppScreen(String paramString) {
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_APP_SCREEN);
    this.mModel.set("description", paramString);
  }
  
  public void setAppVersion(String paramString) {
    if (this.mIsTrackingStarted) {
      Log.wDebug("Tracking already started, setAppVersion call ignored");
      return;
    } 
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_APP_VERSION);
    this.mModel.set("appVersion", paramString);
  }
  
  public void setCampaign(String paramString) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_CAMPAIGN);
    this.mModel.setForNextHit("campaign", paramString);
  }
  
  public void setCustomDimension(int paramInt, String paramString) {
    if (paramInt < 1) {
      Log.w("index must be > 0, ignoring setCustomDimension call for " + paramInt + ", " + paramString);
      return;
    } 
    this.mModel.setForNextHit(Utils.getSlottedModelField("customDimension", paramInt), paramString);
  }
  
  public void setCustomDimensionsAndMetrics(Map<Integer, String> paramMap, Map<Integer, Long> paramMap1) {
    if (paramMap != null)
      for (Integer integer : paramMap.keySet())
        setCustomDimension(integer.intValue(), paramMap.get(integer));  
    if (paramMap1 != null)
      for (Integer integer : paramMap1.keySet())
        setCustomMetric(integer.intValue(), paramMap1.get(integer));  
  }
  
  public void setCustomMetric(int paramInt, Long paramLong) {
    if (paramInt < 1) {
      Log.w("index must be > 0, ignoring setCustomMetric call for " + paramInt + ", " + paramLong);
      return;
    } 
    String str = null;
    if (paramLong != null)
      str = Long.toString(paramLong.longValue()); 
    this.mModel.setForNextHit(Utils.getSlottedModelField("customMetric", paramInt), str);
  }
  
  public void setExceptionParser(ExceptionParser paramExceptionParser) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_EXCEPTION_PARSER);
    this.mExceptionParser = paramExceptionParser;
  }
  
  @VisibleForTesting
  void setLastTrackTime(long paramLong) {
    this.mLastTrackTime = paramLong;
  }
  
  public void setReferrer(String paramString) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_REFERRER);
    this.mModel.setForNextHit("referrer", paramString);
  }
  
  public void setSampleRate(double paramDouble) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_SAMPLE_RATE);
    this.mModel.set("sampleRate", Double.toString(paramDouble));
  }
  
  public void setStartSession(boolean paramBoolean) {
    String str;
    assertTrackerOpen();
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_START_SESSION);
    SimpleModel simpleModel = this.mModel;
    if (paramBoolean) {
      str = "start";
    } else {
      str = null;
    } 
    simpleModel.setForNextHit("sessionControl", str);
  }
  
  @VisibleForTesting
  public void setThrottlingEnabled(boolean paramBoolean) {
    this.mIsThrottlingEnabled = paramBoolean;
  }
  
  @VisibleForTesting
  void setTokens(long paramLong) {
    this.mTokens = paramLong;
  }
  
  public void setUseSecure(boolean paramBoolean) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_USE_SECURE);
    this.mModel.set("useSecure", Boolean.toString(paramBoolean));
  }
  
  @VisibleForTesting
  boolean tokensAvailable() {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield mIsThrottlingEnabled : Z
    //   8: istore_2
    //   9: iload_2
    //   10: ifne -> 17
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_1
    //   16: ireturn
    //   17: invokestatic currentTimeMillis : ()J
    //   20: lstore_3
    //   21: aload_0
    //   22: getfield mTokens : J
    //   25: ldc2_w 120000
    //   28: lcmp
    //   29: ifge -> 64
    //   32: lload_3
    //   33: aload_0
    //   34: getfield mLastTrackTime : J
    //   37: lsub
    //   38: lstore #5
    //   40: lload #5
    //   42: lconst_0
    //   43: lcmp
    //   44: ifle -> 64
    //   47: aload_0
    //   48: ldc2_w 120000
    //   51: aload_0
    //   52: getfield mTokens : J
    //   55: lload #5
    //   57: ladd
    //   58: invokestatic min : (JJ)J
    //   61: putfield mTokens : J
    //   64: aload_0
    //   65: lload_3
    //   66: putfield mLastTrackTime : J
    //   69: aload_0
    //   70: getfield mTokens : J
    //   73: ldc2_w 2000
    //   76: lcmp
    //   77: iflt -> 102
    //   80: aload_0
    //   81: aload_0
    //   82: getfield mTokens : J
    //   85: ldc2_w 2000
    //   88: lsub
    //   89: putfield mTokens : J
    //   92: goto -> 13
    //   95: astore #7
    //   97: aload_0
    //   98: monitorexit
    //   99: aload #7
    //   101: athrow
    //   102: ldc_w 'Excessive tracking detected.  Tracking call ignored.'
    //   105: invokestatic wDebug : (Ljava/lang/String;)I
    //   108: pop
    //   109: iconst_0
    //   110: istore_1
    //   111: goto -> 13
    // Exception table:
    //   from	to	target	type
    //   4	9	95	finally
    //   17	40	95	finally
    //   47	64	95	finally
    //   64	92	95	finally
    //   102	109	95	finally
  }
  
  @Deprecated
  public void trackEvent(String paramString1, String paramString2, String paramString3, Long paramLong) {
    sendEvent(paramString1, paramString2, paramString3, paramLong);
  }
  
  @Deprecated
  public void trackException(String paramString, Throwable paramThrowable, boolean paramBoolean) {
    sendException(paramString, paramThrowable, paramBoolean);
  }
  
  @Deprecated
  public void trackException(String paramString, boolean paramBoolean) {
    sendException(paramString, paramBoolean);
  }
  
  @Deprecated
  public void trackSocial(String paramString1, String paramString2, String paramString3) {
    sendSocial(paramString1, paramString2, paramString3);
  }
  
  @Deprecated
  public void trackTiming(String paramString1, long paramLong, String paramString2, String paramString3) {
    sendTiming(paramString1, paramLong, paramString2, paramString3);
  }
  
  @Deprecated
  public void trackTransaction(Transaction paramTransaction) {
    sendTransaction(paramTransaction);
  }
  
  @Deprecated
  public void trackView() {
    sendView();
  }
  
  @Deprecated
  public void trackView(String paramString) {
    sendView(paramString);
  }
  
  private static class SimpleModel {
    private Map<String, String> permanentMap = new HashMap<String, String>();
    
    private Map<String, String> temporaryMap = new HashMap<String, String>();
    
    private SimpleModel() {}
    
    public void clearTemporaryValues() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield temporaryMap : Ljava/util/Map;
      //   6: invokeinterface clear : ()V
      //   11: aload_0
      //   12: monitorexit
      //   13: return
      //   14: astore_1
      //   15: aload_0
      //   16: monitorexit
      //   17: aload_1
      //   18: athrow
      // Exception table:
      //   from	to	target	type
      //   2	11	14	finally
    }
    
    public String get(String param1String) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield temporaryMap : Ljava/util/Map;
      //   6: aload_1
      //   7: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   12: checkcast java/lang/String
      //   15: astore_2
      //   16: aload_2
      //   17: ifnull -> 26
      //   20: aload_2
      //   21: astore_1
      //   22: aload_0
      //   23: monitorexit
      //   24: aload_1
      //   25: areturn
      //   26: aload_0
      //   27: getfield permanentMap : Ljava/util/Map;
      //   30: aload_1
      //   31: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   36: checkcast java/lang/String
      //   39: astore_1
      //   40: goto -> 22
      //   43: astore_1
      //   44: aload_0
      //   45: monitorexit
      //   46: aload_1
      //   47: athrow
      // Exception table:
      //   from	to	target	type
      //   2	16	43	finally
      //   26	40	43	finally
    }
    
    public Map<String, String> getKeysAndValues() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: new java/util/HashMap
      //   5: dup
      //   6: aload_0
      //   7: getfield permanentMap : Ljava/util/Map;
      //   10: invokespecial <init> : (Ljava/util/Map;)V
      //   13: astore_1
      //   14: aload_1
      //   15: aload_0
      //   16: getfield temporaryMap : Ljava/util/Map;
      //   19: invokeinterface putAll : (Ljava/util/Map;)V
      //   24: aload_0
      //   25: monitorexit
      //   26: aload_1
      //   27: areturn
      //   28: astore_1
      //   29: aload_0
      //   30: monitorexit
      //   31: aload_1
      //   32: athrow
      // Exception table:
      //   from	to	target	type
      //   2	24	28	finally
    }
    
    public void set(String param1String1, String param1String2) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield permanentMap : Ljava/util/Map;
      //   6: aload_1
      //   7: aload_2
      //   8: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   13: pop
      //   14: aload_0
      //   15: monitorexit
      //   16: return
      //   17: astore_1
      //   18: aload_0
      //   19: monitorexit
      //   20: aload_1
      //   21: athrow
      // Exception table:
      //   from	to	target	type
      //   2	14	17	finally
    }
    
    public void setAll(Map<String, String> param1Map, Boolean param1Boolean) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_2
      //   3: invokevirtual booleanValue : ()Z
      //   6: ifeq -> 22
      //   9: aload_0
      //   10: getfield temporaryMap : Ljava/util/Map;
      //   13: aload_1
      //   14: invokeinterface putAll : (Ljava/util/Map;)V
      //   19: aload_0
      //   20: monitorexit
      //   21: return
      //   22: aload_0
      //   23: getfield permanentMap : Ljava/util/Map;
      //   26: aload_1
      //   27: invokeinterface putAll : (Ljava/util/Map;)V
      //   32: goto -> 19
      //   35: astore_1
      //   36: aload_0
      //   37: monitorexit
      //   38: aload_1
      //   39: athrow
      // Exception table:
      //   from	to	target	type
      //   2	19	35	finally
      //   22	32	35	finally
    }
    
    public void setForNextHit(String param1String1, String param1String2) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield temporaryMap : Ljava/util/Map;
      //   6: aload_1
      //   7: aload_2
      //   8: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   13: pop
      //   14: aload_0
      //   15: monitorexit
      //   16: return
      //   17: astore_1
      //   18: aload_0
      //   19: monitorexit
      //   20: aload_1
      //   21: athrow
      // Exception table:
      //   from	to	target	type
      //   2	14	17	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\Tracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */