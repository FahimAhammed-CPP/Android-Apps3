package com.google.analytics.tracking.android;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

class HitBuilder {
  static String encode(String paramString) {
    try {
      return URLEncoder.encode(paramString, "UTF-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new AssertionError("URL encoding failed for: " + paramString);
    } 
  }
  
  static Map<String, String> generateHitParams(MetaModel paramMetaModel, Map<String, String> paramMap) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      MetaModel.MetaInfo metaInfo = paramMetaModel.getMetaInfo((String)entry.getKey());
      if (metaInfo != null) {
        String str = metaInfo.getUrlParam((String)entry.getKey());
        if (str != null) {
          String str2 = (String)entry.getValue();
          String str1 = str2;
          if (metaInfo.getFormatter() != null)
            str1 = metaInfo.getFormatter().format(str2); 
          if (str1 != null && !str1.equals(metaInfo.getDefaultValue()))
            hashMap.put(str, str1); 
        } 
      } 
    } 
    return (Map)hashMap;
  }
  
  static String postProcessHit(Hit paramHit, long paramLong) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramHit.getHitParams());
    if (paramHit.getHitTime() > 0L) {
      paramLong -= paramHit.getHitTime();
      if (paramLong >= 0L)
        stringBuilder.append("&").append("qt").append("=").append(paramLong); 
    } 
    stringBuilder.append("&").append("z").append("=").append(paramHit.getHitId());
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\HitBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */