package com.google.analytics.tracking.android;

import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

class Utils {
  private static final char[] HEXBYTES = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'A', 'B', 'C', 'D', 'E', 'F' };
  
  public static String filterCampaign(String paramString) {
    String[] arrayOfString;
    StringBuilder stringBuilder;
    if (TextUtils.isEmpty(paramString))
      return null; 
    String str = paramString;
    if (paramString.contains("?"))
      str = paramString.split("[\\?]")[1]; 
    if (str.contains("%3D")) {
      try {
        paramString = URLDecoder.decode(str, "UTF-8");
        Map<String, String> map = parseURLParameters(paramString);
        arrayOfString = new String[9];
        arrayOfString[0] = "dclid";
        arrayOfString[1] = "utm_source";
        arrayOfString[2] = "gclid";
        arrayOfString[3] = "utm_campaign";
        arrayOfString[4] = "utm_medium";
        arrayOfString[5] = "utm_term";
        arrayOfString[6] = "utm_content";
        arrayOfString[7] = "utm_id";
        arrayOfString[8] = "gmob_t";
        stringBuilder = new StringBuilder();
        boolean bool = false;
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        return null;
      } 
    } else {
      String[] arrayOfString1 = arrayOfString;
      if (!arrayOfString.contains("="))
        return null; 
      Map<String, String> map = parseURLParameters((String)arrayOfString1);
      arrayOfString = new String[9];
      arrayOfString[0] = "dclid";
      arrayOfString[1] = "utm_source";
      arrayOfString[2] = "gclid";
      arrayOfString[3] = "utm_campaign";
      arrayOfString[4] = "utm_medium";
      arrayOfString[5] = "utm_term";
      arrayOfString[6] = "utm_content";
      arrayOfString[7] = "utm_id";
      arrayOfString[8] = "gmob_t";
      stringBuilder = new StringBuilder();
      boolean bool = false;
    } 
    return stringBuilder.toString();
  }
  
  static int fromHexDigit(char paramChar) {
    int j = paramChar - 48;
    int i = j;
    if (j > 9)
      i = j - 7; 
    return i;
  }
  
  static String getLanguage(Locale paramLocale) {
    if (paramLocale != null && !TextUtils.isEmpty(paramLocale.getLanguage())) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramLocale.getLanguage().toLowerCase());
      if (!TextUtils.isEmpty(paramLocale.getCountry()))
        stringBuilder.append("-").append(paramLocale.getCountry().toLowerCase()); 
      return stringBuilder.toString();
    } 
    return null;
  }
  
  static String getSlottedModelField(String paramString, int paramInt) {
    return paramString + "*" + paramInt;
  }
  
  static byte[] hexDecode(String paramString) {
    byte[] arrayOfByte = new byte[paramString.length() / 2];
    for (int i = 0; i < arrayOfByte.length; i++)
      arrayOfByte[i] = (byte)(fromHexDigit(paramString.charAt(i * 2)) << 4 | fromHexDigit(paramString.charAt(i * 2 + 1))); 
    return arrayOfByte;
  }
  
  static String hexEncode(byte[] paramArrayOfbyte) {
    char[] arrayOfChar = new char[paramArrayOfbyte.length * 2];
    for (int i = 0; i < paramArrayOfbyte.length; i++) {
      int j = paramArrayOfbyte[i] & 0xFF;
      arrayOfChar[i * 2] = HEXBYTES[j >> 4];
      arrayOfChar[i * 2 + 1] = HEXBYTES[j & 0xF];
    } 
    return new String(arrayOfChar);
  }
  
  public static Map<String, String> parseURLParameters(String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    String[] arrayOfString = paramString.split("&");
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String[] arrayOfString1 = arrayOfString[i].split("=");
      if (arrayOfString1.length > 1) {
        hashMap.put(arrayOfString1[0], arrayOfString1[1]);
      } else if (arrayOfString1.length == 1 && arrayOfString1[0].length() != 0) {
        hashMap.put(arrayOfString1[0], null);
      } 
    } 
    return (Map)hashMap;
  }
  
  public static boolean safeParseBoolean(String paramString) {
    return Boolean.parseBoolean(paramString);
  }
  
  public static double safeParseDouble(String paramString) {
    if (paramString == null)
      return 0.0D; 
    try {
      return Double.parseDouble(paramString);
    } catch (NumberFormatException numberFormatException) {
      return 0.0D;
    } 
  }
  
  public static long safeParseLong(String paramString) {
    if (paramString == null)
      return 0L; 
    try {
      return Long.parseLong(paramString);
    } catch (NumberFormatException numberFormatException) {
      return 0L;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */