package com.google.analytics.tracking.android;

import com.google.android.gms.analytics.internal.Command;
import java.util.Collection;
import java.util.Map;

interface AnalyticsStore {
  void clearHits(long paramLong);
  
  void close();
  
  void dispatch();
  
  void putHit(Map<String, String> paramMap, long paramLong, String paramString, Collection<Command> paramCollection);
  
  void setDispatch(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\AnalyticsStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */