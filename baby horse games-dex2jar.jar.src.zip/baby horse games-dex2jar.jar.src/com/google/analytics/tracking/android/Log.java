package com.google.analytics.tracking.android;

import com.google.android.gms.common.util.VisibleForTesting;

public class Log {
  @VisibleForTesting
  static final String LOG_TAG = "GAV2";
  
  private static boolean sDebug;
  
  public static int d(String paramString) {
    return android.util.Log.d("GAV2", formatMessage(paramString));
  }
  
  public static int dDebug(String paramString) {
    return sDebug ? d(paramString) : 0;
  }
  
  public static int e(String paramString) {
    return android.util.Log.e("GAV2", formatMessage(paramString));
  }
  
  public static int eDebug(String paramString) {
    return sDebug ? e(paramString) : 0;
  }
  
  private static String formatMessage(String paramString) {
    return Thread.currentThread().toString() + ": " + paramString;
  }
  
  public static int i(String paramString) {
    return android.util.Log.i("GAV2", formatMessage(paramString));
  }
  
  public static int iDebug(String paramString) {
    return sDebug ? i(paramString) : 0;
  }
  
  public static boolean isDebugEnabled() {
    return sDebug;
  }
  
  public static void setDebug(boolean paramBoolean) {
    sDebug = paramBoolean;
  }
  
  public static int v(String paramString) {
    return android.util.Log.v("GAV2", formatMessage(paramString));
  }
  
  public static int vDebug(String paramString) {
    return sDebug ? v(paramString) : 0;
  }
  
  public static int w(String paramString) {
    return android.util.Log.w("GAV2", formatMessage(paramString));
  }
  
  public static int wDebug(String paramString) {
    return sDebug ? w(paramString) : 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\analytics\tracking\android\Log.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */