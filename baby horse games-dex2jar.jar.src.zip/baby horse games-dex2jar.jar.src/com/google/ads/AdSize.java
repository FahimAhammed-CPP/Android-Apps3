package com.google.ads;

import android.content.Context;

@Deprecated
public final class AdSize {
  public static final int AUTO_HEIGHT = -2;
  
  public static final AdSize BANNER;
  
  public static final int FULL_WIDTH = -1;
  
  public static final AdSize IAB_BANNER;
  
  public static final AdSize IAB_LEADERBOARD;
  
  public static final AdSize IAB_MRECT;
  
  public static final AdSize IAB_WIDE_SKYSCRAPER;
  
  public static final int LANDSCAPE_AD_HEIGHT = 32;
  
  public static final int LARGE_AD_HEIGHT = 90;
  
  public static final int PORTRAIT_AD_HEIGHT = 50;
  
  public static final AdSize SMART_BANNER = new AdSize(-1, -2, "mb");
  
  private final com.google.android.gms.ads.AdSize c;
  
  static {
    BANNER = new AdSize(320, 50, "mb");
    IAB_MRECT = new AdSize(300, 250, "as");
    IAB_BANNER = new AdSize(468, 60, "as");
    IAB_LEADERBOARD = new AdSize(728, 90, "as");
    IAB_WIDE_SKYSCRAPER = new AdSize(160, 600, "as");
  }
  
  public AdSize(int paramInt1, int paramInt2) {
    this(new com.google.android.gms.ads.AdSize(paramInt1, paramInt2));
  }
  
  private AdSize(int paramInt1, int paramInt2, String paramString) {
    this(new com.google.android.gms.ads.AdSize(paramInt1, paramInt2));
  }
  
  public AdSize(com.google.android.gms.ads.AdSize paramAdSize) {
    this.c = paramAdSize;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof AdSize))
      return false; 
    paramObject = paramObject;
    return this.c.equals(((AdSize)paramObject).c);
  }
  
  public AdSize findBestSize(AdSize... paramVarArgs) {
    AdSize adSize1 = null;
    AdSize adSize2 = null;
    if (paramVarArgs != null) {
      Object object;
      float f = 0.0F;
      int j = getWidth();
      int k = getHeight();
      int m = paramVarArgs.length;
      int i = 0;
      while (true) {
        adSize2 = adSize1;
        if (i < m) {
          adSize2 = paramVarArgs[i];
          int n = adSize2.getWidth();
          int i1 = adSize2.getHeight();
          if (isSizeAppropriate(n, i1)) {
            float f2 = (n * i1) / (j * k);
            float f1 = f2;
            if (f2 > 1.0F)
              f1 = 1.0F / f2; 
            if (f1 > object) {
              adSize1 = adSize2;
              continue;
            } 
          } 
          Object object1 = object;
          continue;
        } 
        return adSize2;
        i++;
        object = SYNTHETIC_LOCAL_VARIABLE_3;
      } 
    } 
    return adSize2;
  }
  
  public int getHeight() {
    return this.c.getHeight();
  }
  
  public int getHeightInPixels(Context paramContext) {
    return this.c.getHeightInPixels(paramContext);
  }
  
  public int getWidth() {
    return this.c.getWidth();
  }
  
  public int getWidthInPixels(Context paramContext) {
    return this.c.getWidthInPixels(paramContext);
  }
  
  public int hashCode() {
    return this.c.hashCode();
  }
  
  public boolean isAutoHeight() {
    return this.c.isAutoHeight();
  }
  
  public boolean isCustomAdSize() {
    return false;
  }
  
  public boolean isFullWidth() {
    return this.c.isFullWidth();
  }
  
  public boolean isSizeAppropriate(int paramInt1, int paramInt2) {
    int i = getWidth();
    int j = getHeight();
    return (paramInt1 <= i * 1.25F && paramInt1 >= i * 0.8F && paramInt2 <= j * 1.25F && paramInt2 >= j * 0.8F);
  }
  
  public String toString() {
    return this.c.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\ads\AdSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */