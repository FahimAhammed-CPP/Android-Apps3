package com.google.ads.mediation.customevent;

@Deprecated
public interface CustomEventInterstitialListener extends CustomEventListener {
  void onReceivedAd();
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\ads\mediation\customevent\CustomEventInterstitialListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */