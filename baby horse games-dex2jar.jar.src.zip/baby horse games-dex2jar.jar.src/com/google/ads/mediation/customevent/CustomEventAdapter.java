package com.google.ads.mediation.customevent;

import android.app.Activity;
import android.view.View;
import com.google.ads.AdRequest;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEventExtras;
import com.google.android.gms.internal.gr;

public final class CustomEventAdapter implements MediationBannerAdapter<CustomEventExtras, CustomEventServerParameters>, MediationInterstitialAdapter<CustomEventExtras, CustomEventServerParameters> {
  private View n;
  
  private CustomEventBanner o;
  
  private CustomEventInterstitial p;
  
  private static <T> T a(String paramString) {
    try {
      return (T)Class.forName(paramString).newInstance();
    } catch (Throwable throwable) {
      gr.W("Could not instantiate custom event adapter: " + paramString + ". " + throwable.getMessage());
      return null;
    } 
  }
  
  private void a(View paramView) {
    this.n = paramView;
  }
  
  public void destroy() {
    if (this.o != null)
      this.o.destroy(); 
    if (this.p != null)
      this.p.destroy(); 
  }
  
  public Class<CustomEventExtras> getAdditionalParametersType() {
    return CustomEventExtras.class;
  }
  
  public View getBannerView() {
    return this.n;
  }
  
  public Class<CustomEventServerParameters> getServerParametersType() {
    return CustomEventServerParameters.class;
  }
  
  public void requestBannerAd(MediationBannerListener paramMediationBannerListener, Activity paramActivity, CustomEventServerParameters paramCustomEventServerParameters, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, CustomEventExtras paramCustomEventExtras) {
    Object object;
    this.o = a(paramCustomEventServerParameters.className);
    if (this.o == null) {
      paramMediationBannerListener.onFailedToReceiveAd(this, AdRequest.ErrorCode.INTERNAL_ERROR);
      return;
    } 
    if (paramCustomEventExtras == null) {
      paramCustomEventExtras = null;
    } else {
      object = paramCustomEventExtras.getExtra(paramCustomEventServerParameters.label);
    } 
    this.o.requestBannerAd(new a(this, paramMediationBannerListener), paramActivity, paramCustomEventServerParameters.label, paramCustomEventServerParameters.parameter, paramAdSize, paramMediationAdRequest, object);
  }
  
  public void requestInterstitialAd(MediationInterstitialListener paramMediationInterstitialListener, Activity paramActivity, CustomEventServerParameters paramCustomEventServerParameters, MediationAdRequest paramMediationAdRequest, CustomEventExtras paramCustomEventExtras) {
    Object object;
    this.p = a(paramCustomEventServerParameters.className);
    if (this.p == null) {
      paramMediationInterstitialListener.onFailedToReceiveAd(this, AdRequest.ErrorCode.INTERNAL_ERROR);
      return;
    } 
    if (paramCustomEventExtras == null) {
      paramCustomEventExtras = null;
    } else {
      object = paramCustomEventExtras.getExtra(paramCustomEventServerParameters.label);
    } 
    this.p.requestInterstitialAd(new b(this, this, paramMediationInterstitialListener), paramActivity, paramCustomEventServerParameters.label, paramCustomEventServerParameters.parameter, paramMediationAdRequest, object);
  }
  
  public void showInterstitial() {
    this.p.showInterstitial();
  }
  
  private static final class a implements CustomEventBannerListener {
    private final CustomEventAdapter q;
    
    private final MediationBannerListener r;
    
    public a(CustomEventAdapter param1CustomEventAdapter, MediationBannerListener param1MediationBannerListener) {
      this.q = param1CustomEventAdapter;
      this.r = param1MediationBannerListener;
    }
    
    public void onClick() {
      gr.S("Custom event adapter called onFailedToReceiveAd.");
      this.r.onClick(this.q);
    }
    
    public void onDismissScreen() {
      gr.S("Custom event adapter called onFailedToReceiveAd.");
      this.r.onDismissScreen(this.q);
    }
    
    public void onFailedToReceiveAd() {
      gr.S("Custom event adapter called onFailedToReceiveAd.");
      this.r.onFailedToReceiveAd(this.q, AdRequest.ErrorCode.NO_FILL);
    }
    
    public void onLeaveApplication() {
      gr.S("Custom event adapter called onFailedToReceiveAd.");
      this.r.onLeaveApplication(this.q);
    }
    
    public void onPresentScreen() {
      gr.S("Custom event adapter called onFailedToReceiveAd.");
      this.r.onPresentScreen(this.q);
    }
    
    public void onReceivedAd(View param1View) {
      gr.S("Custom event adapter called onReceivedAd.");
      CustomEventAdapter.a(this.q, param1View);
      this.r.onReceivedAd(this.q);
    }
  }
  
  private class b implements CustomEventInterstitialListener {
    private final CustomEventAdapter q;
    
    private final MediationInterstitialListener s;
    
    public b(CustomEventAdapter this$0, CustomEventAdapter param1CustomEventAdapter1, MediationInterstitialListener param1MediationInterstitialListener) {
      this.q = param1CustomEventAdapter1;
      this.s = param1MediationInterstitialListener;
    }
    
    public void onDismissScreen() {
      gr.S("Custom event adapter called onDismissScreen.");
      this.s.onDismissScreen(this.q);
    }
    
    public void onFailedToReceiveAd() {
      gr.S("Custom event adapter called onFailedToReceiveAd.");
      this.s.onFailedToReceiveAd(this.q, AdRequest.ErrorCode.NO_FILL);
    }
    
    public void onLeaveApplication() {
      gr.S("Custom event adapter called onLeaveApplication.");
      this.s.onLeaveApplication(this.q);
    }
    
    public void onPresentScreen() {
      gr.S("Custom event adapter called onPresentScreen.");
      this.s.onPresentScreen(this.q);
    }
    
    public void onReceivedAd() {
      gr.S("Custom event adapter called onReceivedAd.");
      this.s.onReceivedAd(this.t);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\google\ads\mediation\customevent\CustomEventAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */