package com.BabyHorseGames;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ImageUtil {
  public static String SaveImage(Bitmap paramBitmap, Activity paramActivity) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyy-mm-dd-hh-mm-ss");
    String str = "Horse - " + simpleDateFormat.format(new Date());
    try {
      File file2 = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Horse Care");
      file2.mkdir();
      File file1 = new File(file2, String.valueOf(str) + ".jpg");
      file1.createNewFile();
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      paramBitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      FileOutputStream fileOutputStream = new FileOutputStream(file1);
      fileOutputStream.write(arrayOfByte);
      fileOutputStream.close();
      paramActivity.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file1)));
      Toast.makeText(paramActivity.getApplicationContext(), "Image saved in gallery!", 0).show();
      return file1.getPath();
    } catch (FileNotFoundException fileNotFoundException) {
      fileNotFoundException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    return "";
  }
  
  public static Bitmap combineImages(Bitmap paramBitmap1, Bitmap paramBitmap2, int paramInt) {
    Bitmap bitmap1;
    int i;
    Bitmap bitmap5 = null;
    if (paramInt < paramBitmap1.getWidth()) {
      float f = paramBitmap1.getHeight() / paramBitmap1.getWidth();
      i = (int)(paramInt * f);
    } else {
      paramInt = paramBitmap1.getWidth();
      i = paramBitmap1.getHeight();
    } 
    Bitmap bitmap3 = null;
    Bitmap bitmap6 = null;
    Bitmap bitmap2 = bitmap5;
    Bitmap bitmap4 = bitmap6;
    try {
      int j;
      Bitmap bitmap = Bitmap.createScaledBitmap(paramBitmap1, paramInt, i, false);
      bitmap2 = bitmap5;
      bitmap3 = bitmap;
      bitmap4 = bitmap6;
      paramBitmap2 = Bitmap.createScaledBitmap(paramBitmap2, paramInt, i, false);
      bitmap2 = bitmap5;
      bitmap3 = bitmap;
      bitmap4 = paramBitmap2;
      if (bitmap.getWidth() > paramBitmap2.getWidth()) {
        bitmap2 = bitmap5;
        bitmap3 = bitmap;
        bitmap4 = paramBitmap2;
        j = bitmap.getWidth() + paramBitmap2.getWidth();
        bitmap2 = bitmap5;
        bitmap3 = bitmap;
        bitmap4 = paramBitmap2;
        i = bitmap.getHeight();
      } else {
        bitmap2 = bitmap5;
        bitmap3 = bitmap;
        bitmap4 = paramBitmap2;
        j = paramBitmap2.getWidth() + paramBitmap2.getWidth();
        bitmap2 = bitmap5;
        bitmap3 = bitmap;
        bitmap4 = paramBitmap2;
        i = bitmap.getHeight();
      } 
      bitmap2 = bitmap5;
      bitmap3 = bitmap;
      bitmap4 = paramBitmap2;
      paramBitmap1 = Bitmap.createBitmap(j, i, Bitmap.Config.RGB_565);
      bitmap2 = paramBitmap1;
      bitmap3 = bitmap;
      bitmap4 = paramBitmap2;
      Canvas canvas = new Canvas(paramBitmap1);
      bitmap2 = paramBitmap1;
      bitmap3 = bitmap;
      bitmap4 = paramBitmap2;
      canvas.drawBitmap(bitmap, 0.0F, 0.0F, null);
      bitmap2 = paramBitmap1;
      bitmap3 = bitmap;
      bitmap4 = paramBitmap2;
      canvas.drawBitmap(paramBitmap2, bitmap.getWidth(), 0.0F, null);
    } catch (Exception exception) {
      bitmap1 = bitmap2;
    } 
    return bitmap1;
  }
  
  public static String encodeToString(Bitmap paramBitmap) {
    paramBitmap = Bitmap.createScaledBitmap(paramBitmap, 360, (int)(360.0D / paramBitmap.getWidth() / paramBitmap.getHeight()), false);
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    paramBitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
    String str = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
    return "data:image/jpg;base64," + str;
  }
  
  public static String encodeToString(String paramString) {
    Bitmap bitmap = BitmapFactory.decodeFile(paramString);
    bitmap = Bitmap.createScaledBitmap(bitmap, 360, (int)(360.0D / bitmap.getWidth() / bitmap.getHeight()), false);
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
    String str = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
    return "data:image/jpg;base64," + str;
  }
  
  public static Bitmap flip(Bitmap paramBitmap, boolean paramBoolean, int paramInt) {
    Matrix matrix = new Matrix();
    if (!paramBoolean) {
      matrix.preScale(-1.0F, 1.0F);
    } else {
      matrix.preScale(1.0F, -1.0F);
    } 
    Bitmap bitmap4 = null;
    Bitmap bitmap3 = null;
    Bitmap bitmap2 = bitmap4;
    Bitmap bitmap1 = bitmap3;
    int i = paramInt;
    try {
      int j;
      if (paramInt < paramBitmap.getWidth()) {
        bitmap2 = bitmap4;
        bitmap1 = bitmap3;
        i = paramInt;
        float f = paramBitmap.getHeight() / paramBitmap.getWidth();
        j = (int)(paramInt * f);
      } else {
        bitmap2 = bitmap4;
        bitmap1 = bitmap3;
        i = paramInt;
        paramInt = paramBitmap.getWidth();
        bitmap2 = bitmap4;
        bitmap1 = bitmap3;
        i = paramInt;
        j = paramBitmap.getHeight();
      } 
      bitmap2 = bitmap4;
      bitmap1 = bitmap3;
      i = paramInt;
      bitmap4 = Bitmap.createScaledBitmap(paramBitmap, paramInt, j, false);
      bitmap2 = bitmap4;
      bitmap1 = bitmap3;
      i = paramInt;
      paramBitmap = Bitmap.createBitmap(bitmap4, 0, 0, bitmap4.getWidth(), bitmap4.getHeight(), matrix, false);
      bitmap1 = paramBitmap;
      if (!paramBoolean) {
        bitmap2 = bitmap4;
        bitmap1 = paramBitmap;
        i = paramInt;
        paramBitmap = combineImages(bitmap4, paramBitmap, 1000);
        bitmap1 = paramBitmap;
      } 
    } catch (Exception exception) {}
    return bitmap1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\BabyHorseGames\ImageUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */