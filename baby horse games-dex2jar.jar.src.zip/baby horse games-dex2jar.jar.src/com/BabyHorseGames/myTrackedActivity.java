package com.BabyHorseGames;

import android.app.Activity;
import android.content.Context;
import android.content.IntentSender;
import android.os.Bundle;
import android.util.Log;
import com.google.analytics.tracking.android.EasyTracker;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.games.Games;
import com.google.android.gms.plus.Plus;

public class myTrackedActivity extends Activity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
  private static String LEADERBOARD_ID;
  
  private static final int REQUEST_ACHIEVEMENTS = 5;
  
  protected static final int REQUEST_CODE_RESOLVE_ERR = 0;
  
  protected static final int REQUEST_LEADERBOARD = 4;
  
  public boolean IsLeaderBoardConnect = false;
  
  public int currentRecord = 0;
  
  ConnectionResult mConnectionResult = null;
  
  public GoogleApiClient mGoogleApiClient;
  
  public void ShowkAchivments() {
    unlockAchivments();
    startActivityForResult(Games.Achievements.getAchievementsIntent(this.mGoogleApiClient), 5);
  }
  
  public boolean isGoogleGamesApi(int paramInt1, int paramInt2) {
    if (paramInt1 == 0 && paramInt2 == -1) {
      this.mConnectionResult = null;
      this.mGoogleApiClient.connect();
      return true;
    } 
    return !(paramInt1 != 0 && paramInt1 != 4 && paramInt1 != 5);
  }
  
  public void onConnected(Bundle paramBundle) {
    if (this.IsLeaderBoardConnect) {
      setGooglePlayLeadboradScore();
      return;
    } 
    ShowkAchivments();
  }
  
  public void onConnectionFailed(ConnectionResult paramConnectionResult) {
    if (paramConnectionResult.hasResolution())
      try {
        paramConnectionResult.startResolutionForResult(this, 0);
      } catch (android.content.IntentSender.SendIntentException sendIntentException) {
        this.mGoogleApiClient.connect();
      }  
    this.mConnectionResult = paramConnectionResult;
  }
  
  public void onConnectionSuspended(int paramInt) {
    Log.v("hi", "onConnectionSuspended: " + paramInt);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    EasyTracker.getInstance().setContext((Context)this);
    this.mGoogleApiClient = (new GoogleApiClient.Builder((Context)this)).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(Plus.API).addScope(Plus.SCOPE_PLUS_LOGIN).addApi(Games.API).addScope(Games.SCOPE_GAMES).build();
  }
  
  protected void onStart() {
    super.onStart();
    EasyTracker.getInstance().activityStart(this);
  }
  
  protected void onStop() {
    super.onStop();
    EasyTracker.getInstance().activityStop(this);
  }
  
  public void setGooglePlayLeadboradScore() {
    LEADERBOARD_ID = getResources().getString(2131099690);
    unlockAchivments();
    Games.Leaderboards.submitScore(this.mGoogleApiClient, LEADERBOARD_ID, this.currentRecord);
    startActivityForResult(Games.Leaderboards.getLeaderboardIntent(this.mGoogleApiClient, LEADERBOARD_ID), 4);
  }
  
  public void unlockAchivments() {
    String[] arrayOfString = new String[5];
    arrayOfString[0] = getResources().getString(2131099685);
    arrayOfString[1] = getResources().getString(2131099686);
    arrayOfString[2] = getResources().getString(2131099687);
    arrayOfString[3] = getResources().getString(2131099688);
    arrayOfString[4] = getResources().getString(2131099689);
    int[] arrayOfInt = new int[5];
    arrayOfInt[0] = 150;
    arrayOfInt[1] = 300;
    arrayOfInt[2] = 600;
    arrayOfInt[3] = 1200;
    arrayOfInt[4] = 2400;
    int i = 0;
    int j = 0;
    while (true) {
      if (j >= arrayOfInt.length) {
        if (i < arrayOfString.length) {
          for (j = 0;; j++) {
            if (j >= i)
              return; 
            Games.Achievements.unlock(this.mGoogleApiClient, arrayOfString[j]);
          } 
          break;
        } 
        continue;
      } 
      int k = i;
      if (this.currentRecord > arrayOfInt[j])
        k = i + 1; 
      j++;
      i = k;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\BabyHorseGames\myTrackedActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */