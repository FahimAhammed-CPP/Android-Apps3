package com.BabyHorseGames;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

public class JsInterface {
  MainActivity act;
  
  public JsInterface(MainActivity paramMainActivity) {
    this.act = paramMainActivity;
  }
  
  private String Load_pref(String paramString) {
    return this.act.getPreferences(0).getString(paramString, "");
  }
  
  private void Save_pref(String paramString1, String paramString2) {
    SharedPreferences.Editor editor = this.act.getPreferences(0).edit();
    editor.putString(paramString1, paramString2);
    editor.commit();
  }
  
  public String GetRecord() {
    String str2 = Load_pref("record");
    String str1 = str2;
    if (str2.length() == 0)
      str1 = "0"; 
    return str1;
  }
  
  public void HideImageFromGallery() {
    this.act.hideGalleryBtn();
  }
  
  public void HideSave() {
    this.act.hideSaveBtn();
  }
  
  public void SaveImg() {
    this.act.saveToGallery();
  }
  
  public String SetRecord(String paramString) {
    String str = GetRecord();
    if (Integer.parseInt(paramString) > Integer.parseInt(str)) {
      Save_pref("record", paramString);
      return paramString;
    } 
    return str;
  }
  
  public void ShowSave() {
    this.act.showSaveBtn();
  }
  
  public void getImageFromGallery() {
    this.act.showGalleryBtn();
  }
  
  public String getPackName() {
    return this.act.getPackageName();
  }
  
  public void openMarket(String paramString) {
    try {
      this.act.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + paramString)));
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      this.act.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + paramString)));
      return;
    } 
  }
  
  public void setPlayServicesAch() {
    this.act.IsLeaderBoardConnect = false;
    this.act.currentRecord = Integer.parseInt(GetRecord());
    if (this.act.mGoogleApiClient.isConnected()) {
      this.act.ShowkAchivments();
      return;
    } 
    this.act.mGoogleApiClient.connect();
  }
  
  public void setPlayServicesScore() {
    this.act.currentRecord = Integer.parseInt(GetRecord());
    this.act.IsLeaderBoardConnect = true;
    if (this.act.mGoogleApiClient.isConnected()) {
      this.act.setGooglePlayLeadboradScore();
      return;
    } 
    this.act.mGoogleApiClient.connect();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\BabyHorseGames\JsInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */