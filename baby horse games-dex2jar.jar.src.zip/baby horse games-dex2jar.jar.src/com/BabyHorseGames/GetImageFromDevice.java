package com.BabyHorseGames;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.graphics.Xfermode;
import android.net.Uri;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.MediaStore;
import java.io.File;
import java.io.IOException;

public class GetImageFromDevice {
  public static final int REQ_CODE_PICK_IMAGE = 2;
  
  static final String TEMP_PHOTO_FILE = "temporary_holder.jpg";
  
  public static Bitmap changeColor(Bitmap paramBitmap) {
    int j = paramBitmap.getWidth();
    int k = paramBitmap.getHeight();
    Bitmap bitmap = Bitmap.createBitmap(j, k, paramBitmap.getConfig());
    int i = 1;
    label23: while (true) {
      if (i >= j)
        return bitmap; 
      int m = 1;
      label21: while (true) {
        if (m >= k) {
          i++;
          continue label23;
        } 
        int n = paramBitmap.getPixel(i, m);
        int i1 = Color.alpha(n);
        int i2 = Color.red(n);
        int i3 = Color.green(n);
        int i4 = Color.blue(n);
        n = 200;
        while (true) {
          if (n >= 0)
            if (i2 > n && i3 > n && i4 > n) {
              bitmap.setPixel(i, m, Color.argb(i1, n + 55, n + 55, n + 55));
            } else {
              n -= 20;
              continue;
            }  
          m++;
          continue label21;
        } 
        break;
      } 
      break;
    } 
  }
  
  public static Bitmap changeToDarken(Bitmap paramBitmap, int paramInt, Context paramContext) {
    Bitmap bitmap = Bitmap.createBitmap(paramBitmap);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint();
    paint.setDither(false);
    paint.setAntiAlias(false);
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inPreferredConfig = Bitmap.Config.ARGB_8888;
    BitmapFactory.decodeResource(paramContext.getResources(), 2130837532, options);
    paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY));
    paint.setShader((Shader)new BitmapShader(paramBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
    canvas.setBitmap(bitmap);
    canvas.drawBitmap(paramBitmap, 0.0F, 0.0F, null);
    canvas.drawRect(0.0F, 0.0F, paramBitmap.getWidth(), paramBitmap.getHeight(), paint);
    return bitmap;
  }
  
  public static Bitmap changeToOverlay(Bitmap paramBitmap, int paramInt, Context paramContext) {
    Bitmap bitmap = Bitmap.createBitmap(paramBitmap);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint();
    paint.setDither(false);
    paint.setAntiAlias(false);
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inPreferredConfig = Bitmap.Config.ARGB_8888;
    BitmapFactory.decodeResource(paramContext.getResources(), 2130837532, options);
    paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.DARKEN));
    paint.setShader((Shader)new BitmapShader(paramBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
    canvas.setBitmap(bitmap);
    canvas.drawBitmap(paramBitmap, 0.0F, 0.0F, null);
    canvas.drawRect(0.0F, 0.0F, paramBitmap.getWidth(), paramBitmap.getHeight(), paint);
    return bitmap;
  }
  
  public static Bitmap changeToScreen(Bitmap paramBitmap, int paramInt, Context paramContext) {
    Bitmap bitmap = Bitmap.createBitmap(paramBitmap);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint();
    paint.setDither(false);
    paint.setAntiAlias(false);
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inPreferredConfig = Bitmap.Config.ARGB_8888;
    BitmapFactory.decodeResource(paramContext.getResources(), 2130837532, options);
    paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
    paint.setShader((Shader)new BitmapShader(paramBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
    canvas.setBitmap(bitmap);
    canvas.drawBitmap(paramBitmap, 0.0F, 0.0F, null);
    canvas.drawRect(0.0F, 0.0F, paramBitmap.getWidth(), paramBitmap.getHeight(), paint);
    return bitmap;
  }
  
  public static Bitmap doBrightness(Bitmap paramBitmap, int paramInt) {
    Bitmap bitmap = Bitmap.createBitmap(paramBitmap);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint();
    ColorMatrix colorMatrix = new ColorMatrix();
    float f = paramInt;
    colorMatrix.set(new float[] { 
          1.0F, 0.0F, 0.0F, 0.0F, f, 0.0F, 1.0F, 0.0F, 0.0F, f, 
          0.0F, 0.0F, 1.0F, 0.0F, f, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F });
    paint.setColorFilter((ColorFilter)new ColorMatrixColorFilter(colorMatrix));
    canvas.drawBitmap(paramBitmap, new Matrix(), paint);
    return bitmap;
  }
  
  public static Bitmap fastsmooth(Bitmap paramBitmap) {
    int j = paramBitmap.getWidth();
    int k = paramBitmap.getHeight();
    Bitmap bitmap = Bitmap.createBitmap(j, k, paramBitmap.getConfig());
    int i = 1;
    label24: while (true) {
      if (i >= j)
        return bitmap; 
      for (int m = 1;; m++) {
        if (m >= k) {
          i++;
          continue label24;
        } 
        int n = paramBitmap.getPixel(i, m);
        int i1 = Color.alpha(n);
        int i2 = Color.red(n);
        int i3 = Color.green(n);
        int i4 = Color.blue(n);
        if (i > 1) {
          n = bitmap.getPixel(i - 1, m - 1);
        } else {
          n = paramBitmap.getPixel(i - 1, m - 1);
        } 
        int i5 = Color.red(n);
        int i6 = Color.green(n);
        n = Color.blue(n);
        if (Math.abs(i5 - i2) < 10 && Math.abs(i6 - i3) < 10 && Math.abs(n - i4) < 10) {
          bitmap.setPixel(i, m, Color.argb(i1, i5, i6, n));
        } else {
          bitmap.setPixel(i, m, Color.argb(i1, i2, i3, i4));
        } 
      } 
      break;
    } 
  }
  
  public static void getImageInterface(Activity paramActivity) {
    Intent intent = new Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    intent.setType("image/*");
    intent.putExtra("crop", "true");
    intent.putExtra("output", (Parcelable)getTempUri());
    intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
    paramActivity.startActivityForResult(intent, 2);
  }
  
  public static File getTempFile() {
    if (Environment.getExternalStorageState().equals("mounted")) {
      File file = new File(Environment.getExternalStorageDirectory(), "temporary_holder.jpg");
      try {
        file.createNewFile();
        return file;
      } catch (IOException iOException) {
        return file;
      } 
    } 
    return null;
  }
  
  private static Uri getTempUri() {
    return Uri.fromFile(getTempFile());
  }
  
  public static String onActivityResult(int paramInt1, int paramInt2, Intent paramIntent, MainActivity paramMainActivity) {
    switch (paramInt1) {
      default:
        return "";
      case 2:
        break;
    } 
    if (paramInt2 == -1 && paramIntent != null) {
      File file = getTempFile();
      Bitmap bitmap = BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() + "/" + "temporary_holder.jpg");
      MainActivity.workImage = bitmap;
      String str2 = ImageUtil.encodeToString(bitmap);
      String str1 = str2;
      if (file.exists()) {
        file.delete();
        return str2;
      } 
      return str1;
    } 
  }
  
  public static Bitmap toGrayscale(Bitmap paramBitmap) {
    int i = paramBitmap.getHeight();
    Bitmap bitmap = Bitmap.createBitmap(paramBitmap.getWidth(), i, Bitmap.Config.RGB_565);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint();
    ColorMatrix colorMatrix = new ColorMatrix();
    colorMatrix.setSaturation(0.0F);
    paint.setColorFilter((ColorFilter)new ColorMatrixColorFilter(colorMatrix));
    canvas.drawBitmap(paramBitmap, 0.0F, 0.0F, paint);
    return bitmap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\BabyHorseGames\GetImageFromDevice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */