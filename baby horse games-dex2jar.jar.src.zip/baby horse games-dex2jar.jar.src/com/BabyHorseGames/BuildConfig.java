package com.BabyHorseGames;

public final class BuildConfig {
  public static final boolean DEBUG = true;
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\com\BabyHorseGames\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */