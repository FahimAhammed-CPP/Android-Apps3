package android.support.v4.view;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

public class GestureDetectorCompat {
  private final GestureDetectorCompatImpl mImpl;
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener) {
    this(paramContext, paramOnGestureListener, null);
  }
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler) {
    if (Build.VERSION.SDK_INT >= 17) {
      this.mImpl = new GestureDetectorCompatImplJellybeanMr1(paramContext, paramOnGestureListener, paramHandler);
      return;
    } 
    this.mImpl = new GestureDetectorCompatImplBase(paramContext, paramOnGestureListener, paramHandler);
  }
  
  public boolean isLongpressEnabled() {
    return this.mImpl.isLongpressEnabled();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return this.mImpl.onTouchEvent(paramMotionEvent);
  }
  
  public void setIsLongpressEnabled(boolean paramBoolean) {
    this.mImpl.setIsLongpressEnabled(paramBoolean);
  }
  
  public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener) {
    this.mImpl.setOnDoubleTapListener(paramOnDoubleTapListener);
  }
  
  static interface GestureDetectorCompatImpl {
    boolean isLongpressEnabled();
    
    boolean onTouchEvent(MotionEvent param1MotionEvent);
    
    void setIsLongpressEnabled(boolean param1Boolean);
    
    void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener);
  }
  
  static class GestureDetectorCompatImplBase implements GestureDetectorCompatImpl {
    private static final int DOUBLE_TAP_TIMEOUT = ViewConfiguration.getDoubleTapTimeout();
    
    private static final int LONGPRESS_TIMEOUT = ViewConfiguration.getLongPressTimeout();
    
    private static final int LONG_PRESS = 2;
    
    private static final int SHOW_PRESS = 1;
    
    private static final int TAP = 3;
    
    private static final int TAP_TIMEOUT = ViewConfiguration.getTapTimeout();
    
    private boolean mAlwaysInBiggerTapRegion;
    
    private boolean mAlwaysInTapRegion;
    
    private MotionEvent mCurrentDownEvent;
    
    private GestureDetector.OnDoubleTapListener mDoubleTapListener;
    
    private int mDoubleTapSlopSquare;
    
    private float mDownFocusX;
    
    private float mDownFocusY;
    
    private final Handler mHandler;
    
    private boolean mInLongPress;
    
    private boolean mIsDoubleTapping;
    
    private boolean mIsLongpressEnabled;
    
    private float mLastFocusX;
    
    private float mLastFocusY;
    
    private final GestureDetector.OnGestureListener mListener;
    
    private int mMaximumFlingVelocity;
    
    private int mMinimumFlingVelocity;
    
    private MotionEvent mPreviousUpEvent;
    
    private boolean mStillDown;
    
    private int mTouchSlopSquare;
    
    private VelocityTracker mVelocityTracker;
    
    static {
    
    }
    
    public GestureDetectorCompatImplBase(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      if (param1Handler != null) {
        this.mHandler = new GestureHandler(param1Handler);
      } else {
        this.mHandler = new GestureHandler();
      } 
      this.mListener = param1OnGestureListener;
      if (param1OnGestureListener instanceof GestureDetector.OnDoubleTapListener)
        setOnDoubleTapListener((GestureDetector.OnDoubleTapListener)param1OnGestureListener); 
      init(param1Context);
    }
    
    private void cancel() {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
      this.mHandler.removeMessages(3);
      this.mVelocityTracker.recycle();
      this.mVelocityTracker = null;
      this.mIsDoubleTapping = false;
      this.mStillDown = false;
      this.mAlwaysInTapRegion = false;
      this.mAlwaysInBiggerTapRegion = false;
      if (this.mInLongPress)
        this.mInLongPress = false; 
    }
    
    private void cancelTaps() {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
      this.mHandler.removeMessages(3);
      this.mIsDoubleTapping = false;
      this.mAlwaysInTapRegion = false;
      this.mAlwaysInBiggerTapRegion = false;
      if (this.mInLongPress)
        this.mInLongPress = false; 
    }
    
    private void dispatchLongPress() {
      this.mHandler.removeMessages(3);
      this.mInLongPress = true;
      this.mListener.onLongPress(this.mCurrentDownEvent);
    }
    
    private void init(Context param1Context) {
      if (param1Context == null)
        throw new IllegalArgumentException("Context must not be null"); 
      if (this.mListener == null)
        throw new IllegalArgumentException("OnGestureListener must not be null"); 
      this.mIsLongpressEnabled = true;
      ViewConfiguration viewConfiguration = ViewConfiguration.get(param1Context);
      int i = viewConfiguration.getScaledTouchSlop();
      int j = viewConfiguration.getScaledDoubleTapSlop();
      this.mMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
      this.mMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
      this.mTouchSlopSquare = i * i;
      this.mDoubleTapSlopSquare = j * j;
    }
    
    private boolean isConsideredDoubleTap(MotionEvent param1MotionEvent1, MotionEvent param1MotionEvent2, MotionEvent param1MotionEvent3) {
      if (this.mAlwaysInBiggerTapRegion && param1MotionEvent3.getEventTime() - param1MotionEvent2.getEventTime() <= DOUBLE_TAP_TIMEOUT) {
        int i = (int)param1MotionEvent1.getX() - (int)param1MotionEvent3.getX();
        int j = (int)param1MotionEvent1.getY() - (int)param1MotionEvent3.getY();
        if (i * i + j * j < this.mDoubleTapSlopSquare)
          return true; 
      } 
      return false;
    }
    
    public boolean isLongpressEnabled() {
      return this.mIsLongpressEnabled;
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getAction : ()I
      //   4: istore #10
      //   6: aload_0
      //   7: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   10: ifnonnull -> 20
      //   13: aload_0
      //   14: invokestatic obtain : ()Landroid/view/VelocityTracker;
      //   17: putfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   20: aload_0
      //   21: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   24: aload_1
      //   25: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
      //   28: iload #10
      //   30: sipush #255
      //   33: iand
      //   34: bipush #6
      //   36: if_icmpne -> 89
      //   39: iconst_1
      //   40: istore #6
      //   42: iload #6
      //   44: ifeq -> 95
      //   47: aload_1
      //   48: invokestatic getActionIndex : (Landroid/view/MotionEvent;)I
      //   51: istore #7
      //   53: fconst_0
      //   54: fstore_3
      //   55: fconst_0
      //   56: fstore_2
      //   57: aload_1
      //   58: invokestatic getPointerCount : (Landroid/view/MotionEvent;)I
      //   61: istore #9
      //   63: iconst_0
      //   64: istore #8
      //   66: iload #8
      //   68: iload #9
      //   70: if_icmpge -> 122
      //   73: iload #7
      //   75: iload #8
      //   77: if_icmpne -> 101
      //   80: iload #8
      //   82: iconst_1
      //   83: iadd
      //   84: istore #8
      //   86: goto -> 66
      //   89: iconst_0
      //   90: istore #6
      //   92: goto -> 42
      //   95: iconst_m1
      //   96: istore #7
      //   98: goto -> 53
      //   101: fload_3
      //   102: aload_1
      //   103: iload #8
      //   105: invokestatic getX : (Landroid/view/MotionEvent;I)F
      //   108: fadd
      //   109: fstore_3
      //   110: fload_2
      //   111: aload_1
      //   112: iload #8
      //   114: invokestatic getY : (Landroid/view/MotionEvent;I)F
      //   117: fadd
      //   118: fstore_2
      //   119: goto -> 80
      //   122: iload #6
      //   124: ifeq -> 215
      //   127: iload #9
      //   129: iconst_1
      //   130: isub
      //   131: istore #6
      //   133: fload_3
      //   134: iload #6
      //   136: i2f
      //   137: fdiv
      //   138: fstore_3
      //   139: fload_2
      //   140: iload #6
      //   142: i2f
      //   143: fdiv
      //   144: fstore_2
      //   145: iconst_0
      //   146: istore #7
      //   148: iconst_0
      //   149: istore #13
      //   151: iconst_0
      //   152: istore #14
      //   154: iconst_0
      //   155: istore #11
      //   157: iload #11
      //   159: istore #12
      //   161: iload #10
      //   163: sipush #255
      //   166: iand
      //   167: tableswitch default -> 208, 0 -> 392, 1 -> 887, 2 -> 652, 3 -> 1124, 4 -> 212, 5 -> 222, 6 -> 248
      //   208: iload #11
      //   210: istore #12
      //   212: iload #12
      //   214: ireturn
      //   215: iload #9
      //   217: istore #6
      //   219: goto -> 133
      //   222: aload_0
      //   223: fload_3
      //   224: putfield mLastFocusX : F
      //   227: aload_0
      //   228: fload_3
      //   229: putfield mDownFocusX : F
      //   232: aload_0
      //   233: fload_2
      //   234: putfield mLastFocusY : F
      //   237: aload_0
      //   238: fload_2
      //   239: putfield mDownFocusY : F
      //   242: aload_0
      //   243: invokespecial cancelTaps : ()V
      //   246: iconst_0
      //   247: ireturn
      //   248: aload_0
      //   249: fload_3
      //   250: putfield mLastFocusX : F
      //   253: aload_0
      //   254: fload_3
      //   255: putfield mDownFocusX : F
      //   258: aload_0
      //   259: fload_2
      //   260: putfield mLastFocusY : F
      //   263: aload_0
      //   264: fload_2
      //   265: putfield mDownFocusY : F
      //   268: aload_0
      //   269: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   272: sipush #1000
      //   275: aload_0
      //   276: getfield mMaximumFlingVelocity : I
      //   279: i2f
      //   280: invokevirtual computeCurrentVelocity : (IF)V
      //   283: aload_1
      //   284: invokestatic getActionIndex : (Landroid/view/MotionEvent;)I
      //   287: istore #7
      //   289: aload_1
      //   290: iload #7
      //   292: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   295: istore #6
      //   297: aload_0
      //   298: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   301: iload #6
      //   303: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   306: fstore_2
      //   307: aload_0
      //   308: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   311: iload #6
      //   313: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   316: fstore_3
      //   317: iconst_0
      //   318: istore #6
      //   320: iload #11
      //   322: istore #12
      //   324: iload #6
      //   326: iload #9
      //   328: if_icmpge -> 212
      //   331: iload #6
      //   333: iload #7
      //   335: if_icmpne -> 347
      //   338: iload #6
      //   340: iconst_1
      //   341: iadd
      //   342: istore #6
      //   344: goto -> 320
      //   347: aload_1
      //   348: iload #6
      //   350: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   353: istore #8
      //   355: fload_2
      //   356: aload_0
      //   357: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   360: iload #8
      //   362: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   365: fmul
      //   366: fload_3
      //   367: aload_0
      //   368: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   371: iload #8
      //   373: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   376: fmul
      //   377: fadd
      //   378: fconst_0
      //   379: fcmpg
      //   380: ifge -> 338
      //   383: aload_0
      //   384: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   387: invokevirtual clear : ()V
      //   390: iconst_0
      //   391: ireturn
      //   392: iload #7
      //   394: istore #6
      //   396: aload_0
      //   397: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   400: ifnull -> 494
      //   403: aload_0
      //   404: getfield mHandler : Landroid/os/Handler;
      //   407: iconst_3
      //   408: invokevirtual hasMessages : (I)Z
      //   411: istore #11
      //   413: iload #11
      //   415: ifeq -> 426
      //   418: aload_0
      //   419: getfield mHandler : Landroid/os/Handler;
      //   422: iconst_3
      //   423: invokevirtual removeMessages : (I)V
      //   426: aload_0
      //   427: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   430: ifnull -> 632
      //   433: aload_0
      //   434: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   437: ifnull -> 632
      //   440: iload #11
      //   442: ifeq -> 632
      //   445: aload_0
      //   446: aload_0
      //   447: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   450: aload_0
      //   451: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   454: aload_1
      //   455: invokespecial isConsideredDoubleTap : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;Landroid/view/MotionEvent;)Z
      //   458: ifeq -> 632
      //   461: aload_0
      //   462: iconst_1
      //   463: putfield mIsDoubleTapping : Z
      //   466: iconst_0
      //   467: aload_0
      //   468: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   471: aload_0
      //   472: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   475: invokeinterface onDoubleTap : (Landroid/view/MotionEvent;)Z
      //   480: ior
      //   481: aload_0
      //   482: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   485: aload_1
      //   486: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   491: ior
      //   492: istore #6
      //   494: aload_0
      //   495: fload_3
      //   496: putfield mLastFocusX : F
      //   499: aload_0
      //   500: fload_3
      //   501: putfield mDownFocusX : F
      //   504: aload_0
      //   505: fload_2
      //   506: putfield mLastFocusY : F
      //   509: aload_0
      //   510: fload_2
      //   511: putfield mDownFocusY : F
      //   514: aload_0
      //   515: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   518: ifnull -> 528
      //   521: aload_0
      //   522: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   525: invokevirtual recycle : ()V
      //   528: aload_0
      //   529: aload_1
      //   530: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
      //   533: putfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   536: aload_0
      //   537: iconst_1
      //   538: putfield mAlwaysInTapRegion : Z
      //   541: aload_0
      //   542: iconst_1
      //   543: putfield mAlwaysInBiggerTapRegion : Z
      //   546: aload_0
      //   547: iconst_1
      //   548: putfield mStillDown : Z
      //   551: aload_0
      //   552: iconst_0
      //   553: putfield mInLongPress : Z
      //   556: aload_0
      //   557: getfield mIsLongpressEnabled : Z
      //   560: ifeq -> 597
      //   563: aload_0
      //   564: getfield mHandler : Landroid/os/Handler;
      //   567: iconst_2
      //   568: invokevirtual removeMessages : (I)V
      //   571: aload_0
      //   572: getfield mHandler : Landroid/os/Handler;
      //   575: iconst_2
      //   576: aload_0
      //   577: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   580: invokevirtual getDownTime : ()J
      //   583: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.TAP_TIMEOUT : I
      //   586: i2l
      //   587: ladd
      //   588: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.LONGPRESS_TIMEOUT : I
      //   591: i2l
      //   592: ladd
      //   593: invokevirtual sendEmptyMessageAtTime : (IJ)Z
      //   596: pop
      //   597: aload_0
      //   598: getfield mHandler : Landroid/os/Handler;
      //   601: iconst_1
      //   602: aload_0
      //   603: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   606: invokevirtual getDownTime : ()J
      //   609: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.TAP_TIMEOUT : I
      //   612: i2l
      //   613: ladd
      //   614: invokevirtual sendEmptyMessageAtTime : (IJ)Z
      //   617: pop
      //   618: iload #6
      //   620: aload_0
      //   621: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   624: aload_1
      //   625: invokeinterface onDown : (Landroid/view/MotionEvent;)Z
      //   630: ior
      //   631: ireturn
      //   632: aload_0
      //   633: getfield mHandler : Landroid/os/Handler;
      //   636: iconst_3
      //   637: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.DOUBLE_TAP_TIMEOUT : I
      //   640: i2l
      //   641: invokevirtual sendEmptyMessageDelayed : (IJ)Z
      //   644: pop
      //   645: iload #7
      //   647: istore #6
      //   649: goto -> 494
      //   652: iload #11
      //   654: istore #12
      //   656: aload_0
      //   657: getfield mInLongPress : Z
      //   660: ifne -> 212
      //   663: aload_0
      //   664: getfield mLastFocusX : F
      //   667: fload_3
      //   668: fsub
      //   669: fstore #4
      //   671: aload_0
      //   672: getfield mLastFocusY : F
      //   675: fload_2
      //   676: fsub
      //   677: fstore #5
      //   679: aload_0
      //   680: getfield mIsDoubleTapping : Z
      //   683: ifeq -> 699
      //   686: iconst_0
      //   687: aload_0
      //   688: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   691: aload_1
      //   692: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   697: ior
      //   698: ireturn
      //   699: aload_0
      //   700: getfield mAlwaysInTapRegion : Z
      //   703: ifeq -> 830
      //   706: fload_3
      //   707: aload_0
      //   708: getfield mDownFocusX : F
      //   711: fsub
      //   712: f2i
      //   713: istore #6
      //   715: fload_2
      //   716: aload_0
      //   717: getfield mDownFocusY : F
      //   720: fsub
      //   721: f2i
      //   722: istore #7
      //   724: iload #6
      //   726: iload #6
      //   728: imul
      //   729: iload #7
      //   731: iload #7
      //   733: imul
      //   734: iadd
      //   735: istore #6
      //   737: iload #13
      //   739: istore #11
      //   741: iload #6
      //   743: aload_0
      //   744: getfield mTouchSlopSquare : I
      //   747: if_icmple -> 809
      //   750: aload_0
      //   751: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   754: aload_0
      //   755: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   758: aload_1
      //   759: fload #4
      //   761: fload #5
      //   763: invokeinterface onScroll : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   768: istore #11
      //   770: aload_0
      //   771: fload_3
      //   772: putfield mLastFocusX : F
      //   775: aload_0
      //   776: fload_2
      //   777: putfield mLastFocusY : F
      //   780: aload_0
      //   781: iconst_0
      //   782: putfield mAlwaysInTapRegion : Z
      //   785: aload_0
      //   786: getfield mHandler : Landroid/os/Handler;
      //   789: iconst_3
      //   790: invokevirtual removeMessages : (I)V
      //   793: aload_0
      //   794: getfield mHandler : Landroid/os/Handler;
      //   797: iconst_1
      //   798: invokevirtual removeMessages : (I)V
      //   801: aload_0
      //   802: getfield mHandler : Landroid/os/Handler;
      //   805: iconst_2
      //   806: invokevirtual removeMessages : (I)V
      //   809: iload #11
      //   811: istore #12
      //   813: iload #6
      //   815: aload_0
      //   816: getfield mTouchSlopSquare : I
      //   819: if_icmple -> 212
      //   822: aload_0
      //   823: iconst_0
      //   824: putfield mAlwaysInBiggerTapRegion : Z
      //   827: iload #11
      //   829: ireturn
      //   830: fload #4
      //   832: invokestatic abs : (F)F
      //   835: fconst_1
      //   836: fcmpl
      //   837: ifge -> 854
      //   840: iload #11
      //   842: istore #12
      //   844: fload #5
      //   846: invokestatic abs : (F)F
      //   849: fconst_1
      //   850: fcmpl
      //   851: iflt -> 212
      //   854: aload_0
      //   855: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   858: aload_0
      //   859: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   862: aload_1
      //   863: fload #4
      //   865: fload #5
      //   867: invokeinterface onScroll : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   872: istore #11
      //   874: aload_0
      //   875: fload_3
      //   876: putfield mLastFocusX : F
      //   879: aload_0
      //   880: fload_2
      //   881: putfield mLastFocusY : F
      //   884: iload #11
      //   886: ireturn
      //   887: aload_0
      //   888: iconst_0
      //   889: putfield mStillDown : Z
      //   892: aload_1
      //   893: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
      //   896: astore #15
      //   898: aload_0
      //   899: getfield mIsDoubleTapping : Z
      //   902: ifeq -> 982
      //   905: iconst_0
      //   906: aload_0
      //   907: getfield mDoubleTapListener : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   910: aload_1
      //   911: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   916: ior
      //   917: istore #11
      //   919: aload_0
      //   920: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   923: ifnull -> 933
      //   926: aload_0
      //   927: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   930: invokevirtual recycle : ()V
      //   933: aload_0
      //   934: aload #15
      //   936: putfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   939: aload_0
      //   940: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   943: ifnull -> 958
      //   946: aload_0
      //   947: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   950: invokevirtual recycle : ()V
      //   953: aload_0
      //   954: aconst_null
      //   955: putfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   958: aload_0
      //   959: iconst_0
      //   960: putfield mIsDoubleTapping : Z
      //   963: aload_0
      //   964: getfield mHandler : Landroid/os/Handler;
      //   967: iconst_1
      //   968: invokevirtual removeMessages : (I)V
      //   971: aload_0
      //   972: getfield mHandler : Landroid/os/Handler;
      //   975: iconst_2
      //   976: invokevirtual removeMessages : (I)V
      //   979: iload #11
      //   981: ireturn
      //   982: aload_0
      //   983: getfield mInLongPress : Z
      //   986: ifeq -> 1009
      //   989: aload_0
      //   990: getfield mHandler : Landroid/os/Handler;
      //   993: iconst_3
      //   994: invokevirtual removeMessages : (I)V
      //   997: aload_0
      //   998: iconst_0
      //   999: putfield mInLongPress : Z
      //   1002: iload #14
      //   1004: istore #11
      //   1006: goto -> 919
      //   1009: aload_0
      //   1010: getfield mAlwaysInTapRegion : Z
      //   1013: ifeq -> 1031
      //   1016: aload_0
      //   1017: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   1020: aload_1
      //   1021: invokeinterface onSingleTapUp : (Landroid/view/MotionEvent;)Z
      //   1026: istore #11
      //   1028: goto -> 919
      //   1031: aload_0
      //   1032: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   1035: astore #16
      //   1037: aload_1
      //   1038: iconst_0
      //   1039: invokestatic getPointerId : (Landroid/view/MotionEvent;I)I
      //   1042: istore #6
      //   1044: aload #16
      //   1046: sipush #1000
      //   1049: aload_0
      //   1050: getfield mMaximumFlingVelocity : I
      //   1053: i2f
      //   1054: invokevirtual computeCurrentVelocity : (IF)V
      //   1057: aload #16
      //   1059: iload #6
      //   1061: invokestatic getYVelocity : (Landroid/view/VelocityTracker;I)F
      //   1064: fstore_2
      //   1065: aload #16
      //   1067: iload #6
      //   1069: invokestatic getXVelocity : (Landroid/view/VelocityTracker;I)F
      //   1072: fstore_3
      //   1073: fload_2
      //   1074: invokestatic abs : (F)F
      //   1077: aload_0
      //   1078: getfield mMinimumFlingVelocity : I
      //   1081: i2f
      //   1082: fcmpl
      //   1083: ifgt -> 1103
      //   1086: iload #14
      //   1088: istore #11
      //   1090: fload_3
      //   1091: invokestatic abs : (F)F
      //   1094: aload_0
      //   1095: getfield mMinimumFlingVelocity : I
      //   1098: i2f
      //   1099: fcmpl
      //   1100: ifle -> 919
      //   1103: aload_0
      //   1104: getfield mListener : Landroid/view/GestureDetector$OnGestureListener;
      //   1107: aload_0
      //   1108: getfield mCurrentDownEvent : Landroid/view/MotionEvent;
      //   1111: aload_1
      //   1112: fload_3
      //   1113: fload_2
      //   1114: invokeinterface onFling : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   1119: istore #11
      //   1121: goto -> 919
      //   1124: aload_0
      //   1125: invokespecial cancel : ()V
      //   1128: iconst_0
      //   1129: ireturn
    }
    
    public void setIsLongpressEnabled(boolean param1Boolean) {
      this.mIsLongpressEnabled = param1Boolean;
    }
    
    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener) {
      this.mDoubleTapListener = param1OnDoubleTapListener;
    }
    
    private class GestureHandler extends Handler {
      GestureHandler() {}
      
      GestureHandler(Handler param2Handler) {
        super(param2Handler.getLooper());
      }
      
      public void handleMessage(Message param2Message) {
        switch (param2Message.what) {
          default:
            throw new RuntimeException("Unknown message " + param2Message);
          case 1:
            GestureDetectorCompat.GestureDetectorCompatImplBase.this.mListener.onShowPress(GestureDetectorCompat.GestureDetectorCompatImplBase.this.mCurrentDownEvent);
            return;
          case 2:
            GestureDetectorCompat.GestureDetectorCompatImplBase.this.dispatchLongPress();
            return;
          case 3:
            break;
        } 
        if (GestureDetectorCompat.GestureDetectorCompatImplBase.this.mDoubleTapListener != null && !GestureDetectorCompat.GestureDetectorCompatImplBase.this.mStillDown) {
          GestureDetectorCompat.GestureDetectorCompatImplBase.this.mDoubleTapListener.onSingleTapConfirmed(GestureDetectorCompat.GestureDetectorCompatImplBase.this.mCurrentDownEvent);
          return;
        } 
      }
    }
  }
  
  private class GestureHandler extends Handler {
    GestureHandler() {}
    
    GestureHandler(Handler param1Handler) {
      super(param1Handler.getLooper());
    }
    
    public void handleMessage(Message param1Message) {
      switch (param1Message.what) {
        default:
          throw new RuntimeException("Unknown message " + param1Message);
        case 1:
          this.this$0.mListener.onShowPress(this.this$0.mCurrentDownEvent);
          return;
        case 2:
          this.this$0.dispatchLongPress();
          return;
        case 3:
          break;
      } 
      if (this.this$0.mDoubleTapListener != null && !this.this$0.mStillDown) {
        this.this$0.mDoubleTapListener.onSingleTapConfirmed(this.this$0.mCurrentDownEvent);
        return;
      } 
    }
  }
  
  static class GestureDetectorCompatImplJellybeanMr1 implements GestureDetectorCompatImpl {
    private final GestureDetector mDetector;
    
    public GestureDetectorCompatImplJellybeanMr1(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      this.mDetector = new GestureDetector(param1Context, param1OnGestureListener, param1Handler);
    }
    
    public boolean isLongpressEnabled() {
      return this.mDetector.isLongpressEnabled();
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      return this.mDetector.onTouchEvent(param1MotionEvent);
    }
    
    public void setIsLongpressEnabled(boolean param1Boolean) {
      this.mDetector.setIsLongpressEnabled(param1Boolean);
    }
    
    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener) {
      this.mDetector.setOnDoubleTapListener(param1OnDoubleTapListener);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\android\support\v4\view\GestureDetectorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */