package android.support.v4.view;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public class ViewGroupCompat {
  static final ViewGroupCompatImpl IMPL = new ViewGroupCompatStubImpl();
  
  public static boolean onRequestSendAccessibilityEvent(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return IMPL.onRequestSendAccessibilityEvent(paramViewGroup, paramView, paramAccessibilityEvent);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 14) {
      IMPL = new ViewGroupCompatIcsImpl();
      return;
    } 
  }
  
  static class ViewGroupCompatIcsImpl extends ViewGroupCompatStubImpl {
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return ViewGroupCompatIcs.onRequestSendAccessibilityEvent(param1ViewGroup, param1View, param1AccessibilityEvent);
    }
  }
  
  static interface ViewGroupCompatImpl {
    boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent);
  }
  
  static class ViewGroupCompatStubImpl implements ViewGroupCompatImpl {
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\android\support\v4\view\ViewGroupCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */