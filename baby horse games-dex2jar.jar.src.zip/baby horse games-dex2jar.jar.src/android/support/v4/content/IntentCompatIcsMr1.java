package android.support.v4.content;

import android.content.Intent;

class IntentCompatIcsMr1 {
  public static Intent makeMainSelectorActivity(String paramString1, String paramString2) {
    return Intent.makeMainSelectorActivity(paramString1, paramString2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\android\support\v4\content\IntentCompatIcsMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */