package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.widget.RemoteViews;
import java.util.ArrayList;

public class NotificationCompat {
  public static final int FLAG_HIGH_PRIORITY = 128;
  
  private static final NotificationCompatImpl IMPL = new NotificationCompatImplBase();
  
  public static final int PRIORITY_DEFAULT = 0;
  
  public static final int PRIORITY_HIGH = 1;
  
  public static final int PRIORITY_LOW = -1;
  
  public static final int PRIORITY_MAX = 2;
  
  public static final int PRIORITY_MIN = -2;
  
  static {
    if (Build.VERSION.SDK_INT >= 16) {
      IMPL = new NotificationCompatImplJellybean();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 14) {
      IMPL = new NotificationCompatImplIceCreamSandwich();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 11) {
      IMPL = new NotificationCompatImplHoneycomb();
      return;
    } 
  }
  
  public static class Action {
    public PendingIntent actionIntent;
    
    public int icon;
    
    public CharSequence title;
    
    public Action(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.icon = param1Int;
      this.title = param1CharSequence;
      this.actionIntent = param1PendingIntent;
    }
  }
  
  public static class BigPictureStyle extends Style {
    Bitmap mPicture;
    
    public BigPictureStyle() {}
    
    public BigPictureStyle(NotificationCompat.Builder param1Builder) {
      setBuilder(param1Builder);
    }
    
    public BigPictureStyle bigPicture(Bitmap param1Bitmap) {
      this.mPicture = param1Bitmap;
      return this;
    }
    
    public BigPictureStyle setBigContentTitle(CharSequence param1CharSequence) {
      this.mBigContentTitle = param1CharSequence;
      return this;
    }
    
    public BigPictureStyle setSummaryText(CharSequence param1CharSequence) {
      this.mSummaryText = param1CharSequence;
      this.mSummaryTextSet = true;
      return this;
    }
  }
  
  public static class BigTextStyle extends Style {
    CharSequence mBigText;
    
    public BigTextStyle() {}
    
    public BigTextStyle(NotificationCompat.Builder param1Builder) {
      setBuilder(param1Builder);
    }
    
    public BigTextStyle bigText(CharSequence param1CharSequence) {
      this.mBigText = param1CharSequence;
      return this;
    }
    
    public BigTextStyle setBigContentTitle(CharSequence param1CharSequence) {
      this.mBigContentTitle = param1CharSequence;
      return this;
    }
    
    public BigTextStyle setSummaryText(CharSequence param1CharSequence) {
      this.mSummaryText = param1CharSequence;
      this.mSummaryTextSet = true;
      return this;
    }
  }
  
  public static class Builder {
    ArrayList<NotificationCompat.Action> mActions = new ArrayList<NotificationCompat.Action>();
    
    CharSequence mContentInfo;
    
    PendingIntent mContentIntent;
    
    CharSequence mContentText;
    
    CharSequence mContentTitle;
    
    Context mContext;
    
    PendingIntent mFullScreenIntent;
    
    Bitmap mLargeIcon;
    
    Notification mNotification = new Notification();
    
    int mNumber;
    
    int mPriority;
    
    int mProgress;
    
    boolean mProgressIndeterminate;
    
    int mProgressMax;
    
    NotificationCompat.Style mStyle;
    
    CharSequence mSubText;
    
    RemoteViews mTickerView;
    
    boolean mUseChronometer;
    
    public Builder(Context param1Context) {
      this.mContext = param1Context;
      this.mNotification.when = System.currentTimeMillis();
      this.mNotification.audioStreamType = -1;
      this.mPriority = 0;
    }
    
    private void setFlag(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        Notification notification1 = this.mNotification;
        notification1.flags |= param1Int;
        return;
      } 
      Notification notification = this.mNotification;
      notification.flags &= param1Int ^ 0xFFFFFFFF;
    }
    
    public Builder addAction(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.mActions.add(new NotificationCompat.Action(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    public Notification build() {
      return NotificationCompat.IMPL.build(this);
    }
    
    @Deprecated
    public Notification getNotification() {
      return NotificationCompat.IMPL.build(this);
    }
    
    public Builder setAutoCancel(boolean param1Boolean) {
      setFlag(16, param1Boolean);
      return this;
    }
    
    public Builder setContent(RemoteViews param1RemoteViews) {
      this.mNotification.contentView = param1RemoteViews;
      return this;
    }
    
    public Builder setContentInfo(CharSequence param1CharSequence) {
      this.mContentInfo = param1CharSequence;
      return this;
    }
    
    public Builder setContentIntent(PendingIntent param1PendingIntent) {
      this.mContentIntent = param1PendingIntent;
      return this;
    }
    
    public Builder setContentText(CharSequence param1CharSequence) {
      this.mContentText = param1CharSequence;
      return this;
    }
    
    public Builder setContentTitle(CharSequence param1CharSequence) {
      this.mContentTitle = param1CharSequence;
      return this;
    }
    
    public Builder setDefaults(int param1Int) {
      this.mNotification.defaults = param1Int;
      if ((param1Int & 0x4) != 0) {
        Notification notification = this.mNotification;
        notification.flags |= 0x1;
      } 
      return this;
    }
    
    public Builder setDeleteIntent(PendingIntent param1PendingIntent) {
      this.mNotification.deleteIntent = param1PendingIntent;
      return this;
    }
    
    public Builder setFullScreenIntent(PendingIntent param1PendingIntent, boolean param1Boolean) {
      this.mFullScreenIntent = param1PendingIntent;
      setFlag(128, param1Boolean);
      return this;
    }
    
    public Builder setLargeIcon(Bitmap param1Bitmap) {
      this.mLargeIcon = param1Bitmap;
      return this;
    }
    
    public Builder setLights(int param1Int1, int param1Int2, int param1Int3) {
      boolean bool = true;
      this.mNotification.ledARGB = param1Int1;
      this.mNotification.ledOnMS = param1Int2;
      this.mNotification.ledOffMS = param1Int3;
      if (this.mNotification.ledOnMS != 0 && this.mNotification.ledOffMS != 0) {
        param1Int1 = 1;
      } else {
        param1Int1 = 0;
      } 
      Notification notification = this.mNotification;
      param1Int2 = this.mNotification.flags;
      if (param1Int1 != 0) {
        param1Int1 = bool;
        notification.flags = param1Int1 | param1Int2 & 0xFFFFFFFE;
        return this;
      } 
      param1Int1 = 0;
      notification.flags = param1Int1 | param1Int2 & 0xFFFFFFFE;
      return this;
    }
    
    public Builder setNumber(int param1Int) {
      this.mNumber = param1Int;
      return this;
    }
    
    public Builder setOngoing(boolean param1Boolean) {
      setFlag(2, param1Boolean);
      return this;
    }
    
    public Builder setOnlyAlertOnce(boolean param1Boolean) {
      setFlag(8, param1Boolean);
      return this;
    }
    
    public Builder setPriority(int param1Int) {
      this.mPriority = param1Int;
      return this;
    }
    
    public Builder setProgress(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.mProgressMax = param1Int1;
      this.mProgress = param1Int2;
      this.mProgressIndeterminate = param1Boolean;
      return this;
    }
    
    public Builder setSmallIcon(int param1Int) {
      this.mNotification.icon = param1Int;
      return this;
    }
    
    public Builder setSmallIcon(int param1Int1, int param1Int2) {
      this.mNotification.icon = param1Int1;
      this.mNotification.iconLevel = param1Int2;
      return this;
    }
    
    public Builder setSound(Uri param1Uri) {
      this.mNotification.sound = param1Uri;
      this.mNotification.audioStreamType = -1;
      return this;
    }
    
    public Builder setSound(Uri param1Uri, int param1Int) {
      this.mNotification.sound = param1Uri;
      this.mNotification.audioStreamType = param1Int;
      return this;
    }
    
    public Builder setStyle(NotificationCompat.Style param1Style) {
      if (this.mStyle != param1Style) {
        this.mStyle = param1Style;
        if (this.mStyle != null)
          this.mStyle.setBuilder(this); 
      } 
      return this;
    }
    
    public Builder setSubText(CharSequence param1CharSequence) {
      this.mSubText = param1CharSequence;
      return this;
    }
    
    public Builder setTicker(CharSequence param1CharSequence) {
      this.mNotification.tickerText = param1CharSequence;
      return this;
    }
    
    public Builder setTicker(CharSequence param1CharSequence, RemoteViews param1RemoteViews) {
      this.mNotification.tickerText = param1CharSequence;
      this.mTickerView = param1RemoteViews;
      return this;
    }
    
    public Builder setUsesChronometer(boolean param1Boolean) {
      this.mUseChronometer = param1Boolean;
      return this;
    }
    
    public Builder setVibrate(long[] param1ArrayOflong) {
      this.mNotification.vibrate = param1ArrayOflong;
      return this;
    }
    
    public Builder setWhen(long param1Long) {
      this.mNotification.when = param1Long;
      return this;
    }
  }
  
  public static class InboxStyle extends Style {
    ArrayList<CharSequence> mTexts = new ArrayList<CharSequence>();
    
    public InboxStyle() {}
    
    public InboxStyle(NotificationCompat.Builder param1Builder) {
      setBuilder(param1Builder);
    }
    
    public InboxStyle addLine(CharSequence param1CharSequence) {
      this.mTexts.add(param1CharSequence);
      return this;
    }
    
    public InboxStyle setBigContentTitle(CharSequence param1CharSequence) {
      this.mBigContentTitle = param1CharSequence;
      return this;
    }
    
    public InboxStyle setSummaryText(CharSequence param1CharSequence) {
      this.mSummaryText = param1CharSequence;
      this.mSummaryTextSet = true;
      return this;
    }
  }
  
  static interface NotificationCompatImpl {
    Notification build(NotificationCompat.Builder param1Builder);
  }
  
  static class NotificationCompatImplBase implements NotificationCompatImpl {
    public Notification build(NotificationCompat.Builder param1Builder) {
      Notification notification = param1Builder.mNotification;
      notification.setLatestEventInfo(param1Builder.mContext, param1Builder.mContentTitle, param1Builder.mContentText, param1Builder.mContentIntent);
      if (param1Builder.mPriority > 0)
        notification.flags |= 0x80; 
      return notification;
    }
  }
  
  static class NotificationCompatImplHoneycomb implements NotificationCompatImpl {
    public Notification build(NotificationCompat.Builder param1Builder) {
      return NotificationCompatHoneycomb.add(param1Builder.mContext, param1Builder.mNotification, param1Builder.mContentTitle, param1Builder.mContentText, param1Builder.mContentInfo, param1Builder.mTickerView, param1Builder.mNumber, param1Builder.mContentIntent, param1Builder.mFullScreenIntent, param1Builder.mLargeIcon);
    }
  }
  
  static class NotificationCompatImplIceCreamSandwich implements NotificationCompatImpl {
    public Notification build(NotificationCompat.Builder param1Builder) {
      return NotificationCompatIceCreamSandwich.add(param1Builder.mContext, param1Builder.mNotification, param1Builder.mContentTitle, param1Builder.mContentText, param1Builder.mContentInfo, param1Builder.mTickerView, param1Builder.mNumber, param1Builder.mContentIntent, param1Builder.mFullScreenIntent, param1Builder.mLargeIcon, param1Builder.mProgressMax, param1Builder.mProgress, param1Builder.mProgressIndeterminate);
    }
  }
  
  static class NotificationCompatImplJellybean implements NotificationCompatImpl {
    public Notification build(NotificationCompat.Builder param1Builder) {
      NotificationCompat.BigTextStyle bigTextStyle;
      NotificationCompat.InboxStyle inboxStyle;
      NotificationCompatJellybean notificationCompatJellybean = new NotificationCompatJellybean(param1Builder.mContext, param1Builder.mNotification, param1Builder.mContentTitle, param1Builder.mContentText, param1Builder.mContentInfo, param1Builder.mTickerView, param1Builder.mNumber, param1Builder.mContentIntent, param1Builder.mFullScreenIntent, param1Builder.mLargeIcon, param1Builder.mProgressMax, param1Builder.mProgress, param1Builder.mProgressIndeterminate, param1Builder.mUseChronometer, param1Builder.mPriority, param1Builder.mSubText);
      for (NotificationCompat.Action action : param1Builder.mActions)
        notificationCompatJellybean.addAction(action.icon, action.title, action.actionIntent); 
      if (param1Builder.mStyle != null) {
        if (param1Builder.mStyle instanceof NotificationCompat.BigTextStyle) {
          bigTextStyle = (NotificationCompat.BigTextStyle)param1Builder.mStyle;
          notificationCompatJellybean.addBigTextStyle(bigTextStyle.mBigContentTitle, bigTextStyle.mSummaryTextSet, bigTextStyle.mSummaryText, bigTextStyle.mBigText);
          return notificationCompatJellybean.build();
        } 
      } else {
        return notificationCompatJellybean.build();
      } 
      if (((NotificationCompat.Builder)bigTextStyle).mStyle instanceof NotificationCompat.InboxStyle) {
        inboxStyle = (NotificationCompat.InboxStyle)((NotificationCompat.Builder)bigTextStyle).mStyle;
        notificationCompatJellybean.addInboxStyle(inboxStyle.mBigContentTitle, inboxStyle.mSummaryTextSet, inboxStyle.mSummaryText, inboxStyle.mTexts);
        return notificationCompatJellybean.build();
      } 
      if (((NotificationCompat.Builder)inboxStyle).mStyle instanceof NotificationCompat.BigPictureStyle) {
        NotificationCompat.BigPictureStyle bigPictureStyle = (NotificationCompat.BigPictureStyle)((NotificationCompat.Builder)inboxStyle).mStyle;
        notificationCompatJellybean.addBigPictureStyle(bigPictureStyle.mBigContentTitle, bigPictureStyle.mSummaryTextSet, bigPictureStyle.mSummaryText, bigPictureStyle.mPicture);
      } 
      return notificationCompatJellybean.build();
    }
  }
  
  public static abstract class Style {
    CharSequence mBigContentTitle;
    
    NotificationCompat.Builder mBuilder;
    
    CharSequence mSummaryText;
    
    boolean mSummaryTextSet = false;
    
    public Notification build() {
      Notification notification = null;
      if (this.mBuilder != null)
        notification = this.mBuilder.build(); 
      return notification;
    }
    
    public void setBuilder(NotificationCompat.Builder param1Builder) {
      if (this.mBuilder != param1Builder) {
        this.mBuilder = param1Builder;
        if (this.mBuilder != null)
          this.mBuilder.setStyle(this); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby horse games-dex2jar.jar!\android\support\v4\app\NotificationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */