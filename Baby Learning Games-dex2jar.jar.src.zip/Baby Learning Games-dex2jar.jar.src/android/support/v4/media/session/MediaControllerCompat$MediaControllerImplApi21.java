package android.support.v4.media.session;

import android.os.Bundle;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaMetadataCompat;
import android.util.Log;
import androidx.core.app.e;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

class MediaControllerCompat$MediaControllerImplApi21 {
  final Object a;
  
  private final List<c> b;
  
  private HashMap<c, a> c;
  
  final MediaSessionCompat.Token d;
  
  void a() {
    if (this.d.a() == null)
      return; 
    Iterator<c> iterator = this.b.iterator();
    while (iterator.hasNext()) {
      c c = iterator.next();
      a a = new a(c);
      this.c.put(c, a);
      c.b = a;
      try {
        this.d.a().c1(a);
        c.i(13, null, null);
      } catch (RemoteException remoteException) {
        Log.e("MediaControllerCompat", "Dead object in registerCallback.", (Throwable)remoteException);
        break;
      } 
    } 
    this.b.clear();
  }
  
  private static class ExtraBinderRequestResultReceiver extends ResultReceiver {
    private WeakReference<MediaControllerCompat$MediaControllerImplApi21> f;
    
    protected void onReceiveResult(int param1Int, Bundle param1Bundle) {
      MediaControllerCompat$MediaControllerImplApi21 mediaControllerCompat$MediaControllerImplApi21 = this.f.get();
      if (mediaControllerCompat$MediaControllerImplApi21 != null) {
        if (param1Bundle == null)
          return; 
        synchronized (mediaControllerCompat$MediaControllerImplApi21.a) {
          mediaControllerCompat$MediaControllerImplApi21.d.c(b.a.D(e.a(param1Bundle, "android.support.v4.media.session.EXTRA_BINDER")));
          mediaControllerCompat$MediaControllerImplApi21.d.k(m1.a.b(param1Bundle, "android.support.v4.media.session.SESSION_TOKEN2"));
          mediaControllerCompat$MediaControllerImplApi21.a();
          return;
        } 
      } 
    }
  }
  
  private static class a extends c.b {
    a(c param1c) {
      super(param1c);
    }
    
    public void M2(Bundle param1Bundle) throws RemoteException {
      throw new AssertionError();
    }
    
    public void P0(CharSequence param1CharSequence) throws RemoteException {
      throw new AssertionError();
    }
    
    public void Y5(ParcelableVolumeInfo param1ParcelableVolumeInfo) throws RemoteException {
      throw new AssertionError();
    }
    
    public void f1() throws RemoteException {
      throw new AssertionError();
    }
    
    public void i1(MediaMetadataCompat param1MediaMetadataCompat) throws RemoteException {
      throw new AssertionError();
    }
    
    public void m3(List<MediaSessionCompat.QueueItem> param1List) throws RemoteException {
      throw new AssertionError();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\android\support\v4\media\session\MediaControllerCompat$MediaControllerImplApi21.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */