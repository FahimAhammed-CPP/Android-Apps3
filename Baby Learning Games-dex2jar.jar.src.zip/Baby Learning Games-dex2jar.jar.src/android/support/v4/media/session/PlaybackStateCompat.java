package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@SuppressLint({"BanParcelableUsage"})
public final class PlaybackStateCompat implements Parcelable {
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  final int f;
  
  final long g;
  
  final long h;
  
  final float i;
  
  final long j;
  
  final int k;
  
  final CharSequence l;
  
  final long m;
  
  List<CustomAction> n;
  
  final long o;
  
  final Bundle p;
  
  private PlaybackState q;
  
  PlaybackStateCompat(int paramInt1, long paramLong1, long paramLong2, float paramFloat, long paramLong3, int paramInt2, CharSequence paramCharSequence, long paramLong4, List<CustomAction> paramList, long paramLong5, Bundle paramBundle) {
    this.f = paramInt1;
    this.g = paramLong1;
    this.h = paramLong2;
    this.i = paramFloat;
    this.j = paramLong3;
    this.k = paramInt2;
    this.l = paramCharSequence;
    this.m = paramLong4;
    this.n = new ArrayList<CustomAction>(paramList);
    this.o = paramLong5;
    this.p = paramBundle;
  }
  
  PlaybackStateCompat(Parcel paramParcel) {
    this.f = paramParcel.readInt();
    this.g = paramParcel.readLong();
    this.i = paramParcel.readFloat();
    this.m = paramParcel.readLong();
    this.h = paramParcel.readLong();
    this.j = paramParcel.readLong();
    this.l = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.n = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.o = paramParcel.readLong();
    this.p = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.k = paramParcel.readInt();
  }
  
  public static PlaybackStateCompat a(Object<PlaybackState.CustomAction> paramObject) {
    PlaybackStateCompat playbackStateCompat;
    ArrayList<CustomAction> arrayList = null;
    Iterator<PlaybackState.CustomAction> iterator = null;
    if (paramObject != null) {
      PlaybackState playbackState = (PlaybackState)paramObject;
      List<PlaybackState.CustomAction> list = b.j(playbackState);
      paramObject = (Object<PlaybackState.CustomAction>)iterator;
      if (list != null) {
        arrayList = new ArrayList(list.size());
        iterator = list.iterator();
        while (true) {
          paramObject = (Object)arrayList;
          if (iterator.hasNext()) {
            arrayList.add(CustomAction.a(iterator.next()));
            continue;
          } 
          break;
        } 
      } 
      Bundle bundle = c.a(playbackState);
      MediaSessionCompat.a(bundle);
      playbackStateCompat = new PlaybackStateCompat(b.r(playbackState), b.q(playbackState), b.i(playbackState), b.p(playbackState), b.g(playbackState), 0, b.k(playbackState), b.n(playbackState), (List)paramObject, b.h(playbackState), bundle);
      playbackStateCompat.q = playbackState;
    } 
    return playbackStateCompat;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.f);
    stringBuilder.append(", position=");
    stringBuilder.append(this.g);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.h);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.i);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.m);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.j);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.k);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.l);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.n);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.o);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.f);
    paramParcel.writeLong(this.g);
    paramParcel.writeFloat(this.i);
    paramParcel.writeLong(this.m);
    paramParcel.writeLong(this.h);
    paramParcel.writeLong(this.j);
    TextUtils.writeToParcel(this.l, paramParcel, paramInt);
    paramParcel.writeTypedList(this.n);
    paramParcel.writeLong(this.o);
    paramParcel.writeBundle(this.p);
    paramParcel.writeInt(this.k);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    private final String f;
    
    private final CharSequence g;
    
    private final int h;
    
    private final Bundle i;
    
    private PlaybackState.CustomAction j;
    
    CustomAction(Parcel param1Parcel) {
      this.f = param1Parcel.readString();
      this.g = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.h = param1Parcel.readInt();
      this.i = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    CustomAction(String param1String, CharSequence param1CharSequence, int param1Int, Bundle param1Bundle) {
      this.f = param1String;
      this.g = param1CharSequence;
      this.h = param1Int;
      this.i = param1Bundle;
    }
    
    public static CustomAction a(Object param1Object) {
      if (param1Object != null) {
        param1Object = param1Object;
        Bundle bundle = PlaybackStateCompat.b.l((PlaybackState.CustomAction)param1Object);
        MediaSessionCompat.a(bundle);
        CustomAction customAction = new CustomAction(PlaybackStateCompat.b.f((PlaybackState.CustomAction)param1Object), PlaybackStateCompat.b.o((PlaybackState.CustomAction)param1Object), PlaybackStateCompat.b.m((PlaybackState.CustomAction)param1Object), bundle);
        customAction.j = (PlaybackState.CustomAction)param1Object;
        return customAction;
      } 
      return null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Action:mName='");
      stringBuilder.append(this.g);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.h);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.i);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.f);
      TextUtils.writeToParcel(this.g, param1Parcel, param1Int);
      param1Parcel.writeInt(this.h);
      param1Parcel.writeBundle(this.i);
    }
    
    class a implements Parcelable.Creator<CustomAction> {
      public PlaybackStateCompat.CustomAction a(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public PlaybackStateCompat.CustomAction[] b(int param2Int) {
        return new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<CustomAction> {
    public PlaybackStateCompat.CustomAction a(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public PlaybackStateCompat.CustomAction[] b(int param1Int) {
      return new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  class a implements Parcelable.Creator<PlaybackStateCompat> {
    public PlaybackStateCompat a(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public PlaybackStateCompat[] b(int param1Int) {
      return new PlaybackStateCompat[param1Int];
    }
  }
  
  private static class b {
    static void a(PlaybackState.Builder param1Builder, PlaybackState.CustomAction param1CustomAction) {
      param1Builder.addCustomAction(param1CustomAction);
    }
    
    static PlaybackState.CustomAction b(PlaybackState.CustomAction.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static PlaybackState c(PlaybackState.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static PlaybackState.Builder d() {
      return new PlaybackState.Builder();
    }
    
    static PlaybackState.CustomAction.Builder e(String param1String, CharSequence param1CharSequence, int param1Int) {
      return new PlaybackState.CustomAction.Builder(param1String, param1CharSequence, param1Int);
    }
    
    static String f(PlaybackState.CustomAction param1CustomAction) {
      return param1CustomAction.getAction();
    }
    
    static long g(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getActions();
    }
    
    static long h(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getActiveQueueItemId();
    }
    
    static long i(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getBufferedPosition();
    }
    
    static List<PlaybackState.CustomAction> j(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getCustomActions();
    }
    
    static CharSequence k(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getErrorMessage();
    }
    
    static Bundle l(PlaybackState.CustomAction param1CustomAction) {
      return param1CustomAction.getExtras();
    }
    
    static int m(PlaybackState.CustomAction param1CustomAction) {
      return param1CustomAction.getIcon();
    }
    
    static long n(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getLastPositionUpdateTime();
    }
    
    static CharSequence o(PlaybackState.CustomAction param1CustomAction) {
      return param1CustomAction.getName();
    }
    
    static float p(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getPlaybackSpeed();
    }
    
    static long q(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getPosition();
    }
    
    static int r(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getState();
    }
    
    static void s(PlaybackState.Builder param1Builder, long param1Long) {
      param1Builder.setActions(param1Long);
    }
    
    static void t(PlaybackState.Builder param1Builder, long param1Long) {
      param1Builder.setActiveQueueItemId(param1Long);
    }
    
    static void u(PlaybackState.Builder param1Builder, long param1Long) {
      param1Builder.setBufferedPosition(param1Long);
    }
    
    static void v(PlaybackState.Builder param1Builder, CharSequence param1CharSequence) {
      param1Builder.setErrorMessage(param1CharSequence);
    }
    
    static void w(PlaybackState.CustomAction.Builder param1Builder, Bundle param1Bundle) {
      param1Builder.setExtras(param1Bundle);
    }
    
    static void x(PlaybackState.Builder param1Builder, int param1Int, long param1Long1, float param1Float, long param1Long2) {
      param1Builder.setState(param1Int, param1Long1, param1Float, param1Long2);
    }
  }
  
  private static class c {
    static Bundle a(PlaybackState param1PlaybackState) {
      return param1PlaybackState.getExtras();
    }
    
    static void b(PlaybackState.Builder param1Builder, Bundle param1Bundle) {
      param1Builder.setExtras(param1Bundle);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */