package android.support.v4.media.session;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface b extends IInterface {
  void c1(a parama) throws RemoteException;
  
  public static abstract class a extends Binder implements b {
    public static b D(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.v4.media.session.IMediaSession");
      return (iInterface != null && iInterface instanceof b) ? (b)iInterface : new a(param1IBinder);
    }
    
    public static b l0() {
      return a.g;
    }
    
    private static class a implements b {
      public static b g;
      
      private IBinder f;
      
      a(IBinder param2IBinder) {
        this.f = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.f;
      }
      
      public void c1(a param2a) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (param2a != null) {
            iBinder = param2a.asBinder();
          } else {
            iBinder = null;
          } 
          parcel1.writeStrongBinder(iBinder);
          if (!this.f.transact(3, parcel1, parcel2, 0) && b.a.l0() != null) {
            b.a.l0().c1(param2a);
            return;
          } 
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements b {
    public static b g;
    
    private IBinder f;
    
    a(IBinder param1IBinder) {
      this.f = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.f;
    }
    
    public void c1(a param1a) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
        if (param1a != null) {
          iBinder = param1a.asBinder();
        } else {
          iBinder = null;
        } 
        parcel1.writeStrongBinder(iBinder);
        if (!this.f.transact(3, parcel1, parcel2, 0) && b.a.l0() != null) {
          b.a.l0().c1(param1a);
          return;
        } 
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\android\support\v4\media\session\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */