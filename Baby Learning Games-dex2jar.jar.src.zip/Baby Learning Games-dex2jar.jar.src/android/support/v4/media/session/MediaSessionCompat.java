package android.support.v4.media.session;

import android.annotation.SuppressLint;
import android.media.MediaDescription;
import android.media.session.MediaSession;
import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MediaSessionCompat {
  public static void a(Bundle paramBundle) {
    if (paramBundle != null)
      paramBundle.setClassLoader(MediaSessionCompat.class.getClassLoader()); 
  }
  
  public static Bundle b(Bundle paramBundle) {
    if (paramBundle == null)
      return null; 
    a(paramBundle);
    try {
      paramBundle.isEmpty();
      return paramBundle;
    } catch (BadParcelableException badParcelableException) {
      Log.e("MediaSessionCompat", "Could not unparcel the data.");
      return null;
    } 
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static final class QueueItem implements Parcelable {
    public static final Parcelable.Creator<QueueItem> CREATOR = new a();
    
    private final MediaDescriptionCompat f;
    
    private final long g;
    
    private MediaSession.QueueItem h;
    
    private QueueItem(MediaSession.QueueItem param1QueueItem, MediaDescriptionCompat param1MediaDescriptionCompat, long param1Long) {
      if (param1MediaDescriptionCompat != null) {
        if (param1Long != -1L) {
          this.f = param1MediaDescriptionCompat;
          this.g = param1Long;
          this.h = param1QueueItem;
          return;
        } 
        throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
      } 
      throw new IllegalArgumentException("Description cannot be null");
    }
    
    QueueItem(Parcel param1Parcel) {
      this.f = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
      this.g = param1Parcel.readLong();
    }
    
    public static QueueItem a(Object param1Object) {
      if (param1Object != null) {
        param1Object = param1Object;
        return new QueueItem((MediaSession.QueueItem)param1Object, MediaDescriptionCompat.a(b.b((MediaSession.QueueItem)param1Object)), b.c((MediaSession.QueueItem)param1Object));
      } 
      return null;
    }
    
    public static List<QueueItem> c(List<?> param1List) {
      if (param1List != null) {
        ArrayList<QueueItem> arrayList = new ArrayList(param1List.size());
        Iterator<?> iterator = param1List.iterator();
        while (iterator.hasNext())
          arrayList.add(a(iterator.next())); 
        return arrayList;
      } 
      return null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("MediaSession.QueueItem {Description=");
      stringBuilder.append(this.f);
      stringBuilder.append(", Id=");
      stringBuilder.append(this.g);
      stringBuilder.append(" }");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.f.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeLong(this.g);
    }
    
    class a implements Parcelable.Creator<QueueItem> {
      public MediaSessionCompat.QueueItem a(Parcel param2Parcel) {
        return new MediaSessionCompat.QueueItem(param2Parcel);
      }
      
      public MediaSessionCompat.QueueItem[] b(int param2Int) {
        return new MediaSessionCompat.QueueItem[param2Int];
      }
    }
    
    private static class b {
      static MediaSession.QueueItem a(MediaDescription param2MediaDescription, long param2Long) {
        return new MediaSession.QueueItem(param2MediaDescription, param2Long);
      }
      
      static MediaDescription b(MediaSession.QueueItem param2QueueItem) {
        return param2QueueItem.getDescription();
      }
      
      static long c(MediaSession.QueueItem param2QueueItem) {
        return param2QueueItem.getQueueId();
      }
    }
  }
  
  class a implements Parcelable.Creator<QueueItem> {
    public MediaSessionCompat.QueueItem a(Parcel param1Parcel) {
      return new MediaSessionCompat.QueueItem(param1Parcel);
    }
    
    public MediaSessionCompat.QueueItem[] b(int param1Int) {
      return new MediaSessionCompat.QueueItem[param1Int];
    }
  }
  
  private static class b {
    static MediaSession.QueueItem a(MediaDescription param1MediaDescription, long param1Long) {
      return new MediaSession.QueueItem(param1MediaDescription, param1Long);
    }
    
    static MediaDescription b(MediaSession.QueueItem param1QueueItem) {
      return param1QueueItem.getDescription();
    }
    
    static long c(MediaSession.QueueItem param1QueueItem) {
      return param1QueueItem.getQueueId();
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  static final class ResultReceiverWrapper implements Parcelable {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new a();
    
    ResultReceiver f;
    
    ResultReceiverWrapper(Parcel param1Parcel) {
      this.f = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(param1Parcel);
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.f.writeToParcel(param1Parcel, param1Int);
    }
    
    class a implements Parcelable.Creator<ResultReceiverWrapper> {
      public MediaSessionCompat.ResultReceiverWrapper a(Parcel param2Parcel) {
        return new MediaSessionCompat.ResultReceiverWrapper(param2Parcel);
      }
      
      public MediaSessionCompat.ResultReceiverWrapper[] b(int param2Int) {
        return new MediaSessionCompat.ResultReceiverWrapper[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<ResultReceiverWrapper> {
    public MediaSessionCompat.ResultReceiverWrapper a(Parcel param1Parcel) {
      return new MediaSessionCompat.ResultReceiverWrapper(param1Parcel);
    }
    
    public MediaSessionCompat.ResultReceiverWrapper[] b(int param1Int) {
      return new MediaSessionCompat.ResultReceiverWrapper[param1Int];
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static final class Token implements Parcelable {
    public static final Parcelable.Creator<Token> CREATOR = new a();
    
    private final Object f = new Object();
    
    private final Object g;
    
    private b h;
    
    private m1.b i;
    
    Token(Object param1Object) {
      this(param1Object, null, null);
    }
    
    Token(Object param1Object, b param1b, m1.b param1b1) {
      this.g = param1Object;
      this.h = param1b;
      this.i = param1b1;
    }
    
    public b a() {
      synchronized (this.f) {
        return this.h;
      } 
    }
    
    public void c(b param1b) {
      synchronized (this.f) {
        this.h = param1b;
        return;
      } 
    }
    
    public int describeContents() {
      return 0;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Token))
        return false; 
      Token token = (Token)param1Object;
      param1Object = this.g;
      if (param1Object == null)
        return (token.g == null); 
      Object object = token.g;
      return (object == null) ? false : param1Object.equals(object);
    }
    
    public int hashCode() {
      Object object = this.g;
      return (object == null) ? 0 : object.hashCode();
    }
    
    public void k(m1.b param1b) {
      synchronized (this.f) {
        this.i = param1b;
        return;
      } 
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeParcelable((Parcelable)this.g, param1Int);
    }
    
    class a implements Parcelable.Creator<Token> {
      public MediaSessionCompat.Token a(Parcel param2Parcel) {
        return new MediaSessionCompat.Token(param2Parcel.readParcelable(null));
      }
      
      public MediaSessionCompat.Token[] b(int param2Int) {
        return new MediaSessionCompat.Token[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<Token> {
    public MediaSessionCompat.Token a(Parcel param1Parcel) {
      return new MediaSessionCompat.Token(param1Parcel.readParcelable(null));
    }
    
    public MediaSessionCompat.Token[] b(int param1Int) {
      return new MediaSessionCompat.Token[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\android\support\v4\media\session\MediaSessionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */