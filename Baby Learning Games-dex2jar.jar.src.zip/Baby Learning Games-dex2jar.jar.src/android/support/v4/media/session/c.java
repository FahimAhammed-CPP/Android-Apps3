package android.support.v4.media.session;

import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v4.media.MediaMetadataCompat;
import androidx.media.AudioAttributesCompat;
import java.lang.ref.WeakReference;
import java.util.List;

public abstract class c implements IBinder.DeathRecipient {
  final MediaController.Callback a = new a(this);
  
  a b;
  
  public void a(d paramd) {}
  
  public void b(Bundle paramBundle) {}
  
  public void binderDied() {
    i(8, null, null);
  }
  
  public void c(MediaMetadataCompat paramMediaMetadataCompat) {}
  
  public void d(PlaybackStateCompat paramPlaybackStateCompat) {}
  
  public void e(List<MediaSessionCompat.QueueItem> paramList) {}
  
  public void f(CharSequence paramCharSequence) {}
  
  public void g() {}
  
  public void h(String paramString, Bundle paramBundle) {}
  
  void i(int paramInt, Object paramObject, Bundle paramBundle) {}
  
  private static class a extends MediaController.Callback {
    private final WeakReference<c> a;
    
    a(c param1c) {
      this.a = new WeakReference<c>(param1c);
    }
    
    public void onAudioInfoChanged(MediaController.PlaybackInfo param1PlaybackInfo) {
      c c = this.a.get();
      if (c != null)
        c.a(new d(param1PlaybackInfo.getPlaybackType(), AudioAttributesCompat.c(param1PlaybackInfo.getAudioAttributes()), param1PlaybackInfo.getVolumeControl(), param1PlaybackInfo.getMaxVolume(), param1PlaybackInfo.getCurrentVolume())); 
    }
    
    public void onExtrasChanged(Bundle param1Bundle) {
      MediaSessionCompat.a(param1Bundle);
      c c = this.a.get();
      if (c != null)
        c.b(param1Bundle); 
    }
    
    public void onMetadataChanged(MediaMetadata param1MediaMetadata) {
      c c = this.a.get();
      if (c != null)
        c.c(MediaMetadataCompat.a(param1MediaMetadata)); 
    }
    
    public void onPlaybackStateChanged(PlaybackState param1PlaybackState) {
      c c = this.a.get();
      if (c != null) {
        if (c.b != null)
          return; 
        c.d(PlaybackStateCompat.a(param1PlaybackState));
      } 
    }
    
    public void onQueueChanged(List<MediaSession.QueueItem> param1List) {
      c c = this.a.get();
      if (c != null)
        c.e(MediaSessionCompat.QueueItem.c(param1List)); 
    }
    
    public void onQueueTitleChanged(CharSequence param1CharSequence) {
      c c = this.a.get();
      if (c != null)
        c.f(param1CharSequence); 
    }
    
    public void onSessionDestroyed() {
      c c = this.a.get();
      if (c != null)
        c.g(); 
    }
    
    public void onSessionEvent(String param1String, Bundle param1Bundle) {
      MediaSessionCompat.a(param1Bundle);
      c c = this.a.get();
      if (c != null) {
        a a1 = c.b;
        c.h(param1String, param1Bundle);
      } 
    }
  }
  
  private static class b extends a.a {
    private final WeakReference<c> f;
    
    b(c param1c) {
      this.f = new WeakReference<c>(param1c);
    }
    
    public void D5(PlaybackStateCompat param1PlaybackStateCompat) throws RemoteException {
      c c = this.f.get();
      if (c != null)
        c.i(2, param1PlaybackStateCompat, null); 
    }
    
    public void E5(String param1String, Bundle param1Bundle) throws RemoteException {
      c c = this.f.get();
      if (c != null)
        c.i(1, param1String, param1Bundle); 
    }
    
    public void I2(int param1Int) throws RemoteException {
      c c = this.f.get();
      if (c != null)
        c.i(12, Integer.valueOf(param1Int), null); 
    }
    
    public void J2() throws RemoteException {
      c c = this.f.get();
      if (c != null)
        c.i(13, null, null); 
    }
    
    public void K1(int param1Int) throws RemoteException {
      c c = this.f.get();
      if (c != null)
        c.i(9, Integer.valueOf(param1Int), null); 
    }
    
    public void M0(boolean param1Boolean) throws RemoteException {}
    
    public void X4(boolean param1Boolean) throws RemoteException {
      c c = this.f.get();
      if (c != null)
        c.i(11, Boolean.valueOf(param1Boolean), null); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\android\support\v4\media\session\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */