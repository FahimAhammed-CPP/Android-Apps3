package android.support.v4.media;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;

@SuppressLint({"BanParcelableUsage"})
public final class MediaDescriptionCompat implements Parcelable {
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  private final String f;
  
  private final CharSequence g;
  
  private final CharSequence h;
  
  private final CharSequence i;
  
  private final Bitmap j;
  
  private final Uri k;
  
  private final Bundle l;
  
  private final Uri m;
  
  private MediaDescription n;
  
  MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.f = paramString;
    this.g = paramCharSequence1;
    this.h = paramCharSequence2;
    this.i = paramCharSequence3;
    this.j = paramBitmap;
    this.k = paramUri1;
    this.l = paramBundle;
    this.m = paramUri2;
  }
  
  public static MediaDescriptionCompat a(Object paramObject) {
    MediaDescriptionCompat mediaDescriptionCompat;
    Bundle bundle = null;
    Object object = null;
    if (paramObject != null) {
      d d = new d();
      MediaDescription mediaDescription = (MediaDescription)paramObject;
      d.f(b.g(mediaDescription));
      d.i(b.i(mediaDescription));
      d.h(b.h(mediaDescription));
      d.b(b.c(mediaDescription));
      d.d(b.e(mediaDescription));
      d.e(b.f(mediaDescription));
      bundle = b.d(mediaDescription);
      paramObject = bundle;
      if (bundle != null)
        paramObject = MediaSessionCompat.b(bundle); 
      if (paramObject != null) {
        Uri uri = (Uri)paramObject.getParcelable("android.support.v4.media.description.MEDIA_URI");
      } else {
        bundle = null;
      } 
      if (bundle != null)
        if (paramObject.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG") && paramObject.size() == 2) {
          paramObject = object;
        } else {
          paramObject.remove("android.support.v4.media.description.MEDIA_URI");
          paramObject.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
        }  
      d.c((Bundle)paramObject);
      if (bundle != null) {
        d.g((Uri)bundle);
      } else {
        d.g(c.a(mediaDescription));
      } 
      mediaDescriptionCompat = d.a();
      mediaDescriptionCompat.n = mediaDescription;
    } 
    return mediaDescriptionCompat;
  }
  
  public Object c() {
    MediaDescription mediaDescription2 = this.n;
    MediaDescription mediaDescription1 = mediaDescription2;
    if (mediaDescription2 == null) {
      MediaDescription.Builder builder = b.b();
      b.n(builder, this.f);
      b.p(builder, this.g);
      b.o(builder, this.h);
      b.j(builder, this.i);
      b.l(builder, this.j);
      b.m(builder, this.k);
      b.k(builder, this.l);
      c.b(builder, this.m);
      mediaDescription1 = b.a(builder);
      this.n = mediaDescription1;
    } 
    return mediaDescription1;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.g);
    stringBuilder.append(", ");
    stringBuilder.append(this.h);
    stringBuilder.append(", ");
    stringBuilder.append(this.i);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ((MediaDescription)c()).writeToParcel(paramParcel, paramInt);
  }
  
  class a implements Parcelable.Creator<MediaDescriptionCompat> {
    public MediaDescriptionCompat a(Parcel param1Parcel) {
      return MediaDescriptionCompat.a(MediaDescription.CREATOR.createFromParcel(param1Parcel));
    }
    
    public MediaDescriptionCompat[] b(int param1Int) {
      return new MediaDescriptionCompat[param1Int];
    }
  }
  
  private static class b {
    static MediaDescription a(MediaDescription.Builder param1Builder) {
      return param1Builder.build();
    }
    
    static MediaDescription.Builder b() {
      return new MediaDescription.Builder();
    }
    
    static CharSequence c(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getDescription();
    }
    
    static Bundle d(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getExtras();
    }
    
    static Bitmap e(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getIconBitmap();
    }
    
    static Uri f(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getIconUri();
    }
    
    static String g(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getMediaId();
    }
    
    static CharSequence h(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getSubtitle();
    }
    
    static CharSequence i(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getTitle();
    }
    
    static void j(MediaDescription.Builder param1Builder, CharSequence param1CharSequence) {
      param1Builder.setDescription(param1CharSequence);
    }
    
    static void k(MediaDescription.Builder param1Builder, Bundle param1Bundle) {
      param1Builder.setExtras(param1Bundle);
    }
    
    static void l(MediaDescription.Builder param1Builder, Bitmap param1Bitmap) {
      param1Builder.setIconBitmap(param1Bitmap);
    }
    
    static void m(MediaDescription.Builder param1Builder, Uri param1Uri) {
      param1Builder.setIconUri(param1Uri);
    }
    
    static void n(MediaDescription.Builder param1Builder, String param1String) {
      param1Builder.setMediaId(param1String);
    }
    
    static void o(MediaDescription.Builder param1Builder, CharSequence param1CharSequence) {
      param1Builder.setSubtitle(param1CharSequence);
    }
    
    static void p(MediaDescription.Builder param1Builder, CharSequence param1CharSequence) {
      param1Builder.setTitle(param1CharSequence);
    }
  }
  
  private static class c {
    static Uri a(MediaDescription param1MediaDescription) {
      return param1MediaDescription.getMediaUri();
    }
    
    static void b(MediaDescription.Builder param1Builder, Uri param1Uri) {
      param1Builder.setMediaUri(param1Uri);
    }
  }
  
  public static final class d {
    private String a;
    
    private CharSequence b;
    
    private CharSequence c;
    
    private CharSequence d;
    
    private Bitmap e;
    
    private Uri f;
    
    private Bundle g;
    
    private Uri h;
    
    public MediaDescriptionCompat a() {
      return new MediaDescriptionCompat(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }
    
    public d b(CharSequence param1CharSequence) {
      this.d = param1CharSequence;
      return this;
    }
    
    public d c(Bundle param1Bundle) {
      this.g = param1Bundle;
      return this;
    }
    
    public d d(Bitmap param1Bitmap) {
      this.e = param1Bitmap;
      return this;
    }
    
    public d e(Uri param1Uri) {
      this.f = param1Uri;
      return this;
    }
    
    public d f(String param1String) {
      this.a = param1String;
      return this;
    }
    
    public d g(Uri param1Uri) {
      this.h = param1Uri;
      return this;
    }
    
    public d h(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
      return this;
    }
    
    public d i(CharSequence param1CharSequence) {
      this.b = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */