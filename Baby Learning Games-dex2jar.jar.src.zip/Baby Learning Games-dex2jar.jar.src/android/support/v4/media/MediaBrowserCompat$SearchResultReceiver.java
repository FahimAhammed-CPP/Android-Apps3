package android.support.v4.media;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.media.session.MediaSessionCompat;
import b.b;
import java.util.ArrayList;
import java.util.Objects;

class MediaBrowserCompat$SearchResultReceiver extends b {
  protected void a(int paramInt, Bundle paramBundle) {
    Bundle bundle = paramBundle;
    if (paramBundle != null)
      bundle = MediaSessionCompat.b(paramBundle); 
    if (paramInt == 0 && bundle != null && bundle.containsKey("search_results")) {
      Parcelable[] arrayOfParcelable = bundle.getParcelableArray("search_results");
      Objects.requireNonNull(arrayOfParcelable);
      ArrayList<MediaBrowserCompat$MediaItem> arrayList = new ArrayList(arrayOfParcelable.length);
      int i = arrayOfParcelable.length;
      for (paramInt = 0; paramInt < i; paramInt++)
        arrayList.add((MediaBrowserCompat$MediaItem)arrayOfParcelable[paramInt]); 
      throw null;
    } 
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\android\support\v4\media\MediaBrowserCompat$SearchResultReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */