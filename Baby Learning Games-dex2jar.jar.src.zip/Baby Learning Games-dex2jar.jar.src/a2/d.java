package a2;

public final class d {
  public static final int a = 2131296436;
  
  public static final int b = 2131296437;
  
  public static final int c = 2131296438;
  
  public static final int d = 2131296439;
  
  public static final int e = 2131296440;
  
  public static final int f = 2131296441;
  
  public static final int g = 2131296442;
  
  public static final int h = 2131296443;
  
  public static final int i = 2131296444;
  
  public static final int j = 2131296445;
  
  public static final int k = 2131296446;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a2\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */