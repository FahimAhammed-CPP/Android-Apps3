package a2;

public final class f {
  public static final int a = 2131886306;
  
  public static final int b = 2131886307;
  
  public static final int c = 2131886308;
  
  public static final int d = 2131886309;
  
  public static final int e = 2131886310;
  
  public static final int f = 2131886311;
  
  public static final int g = 2131886312;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a2\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */