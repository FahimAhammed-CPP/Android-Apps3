package a2;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import f.b;

public class g extends b implements RatingBar.OnRatingBarChangeListener, View.OnClickListener {
  private String h = "RatingDialog";
  
  private SharedPreferences i;
  
  private Context j;
  
  private c k;
  
  private TextView l;
  
  private TextView m;
  
  private TextView n;
  
  private TextView o;
  
  private TextView p;
  
  private TextView q;
  
  private RatingBar r;
  
  private ImageView s;
  
  private EditText t;
  
  private LinearLayout u;
  
  private LinearLayout v;
  
  private float w;
  
  private int x;
  
  private boolean y = true;
  
  public g(Context paramContext, c paramc) {
    super(paramContext);
    this.j = paramContext;
    this.k = paramc;
    this.x = c.a(paramc);
    this.w = c.b(paramc);
  }
  
  private void A() {
    SharedPreferences sharedPreferences = this.j.getSharedPreferences(this.h, 0);
    this.i = sharedPreferences;
    SharedPreferences.Editor editor = sharedPreferences.edit();
    editor.putBoolean("show_never", true);
    editor.commit();
  }
  
  private boolean u(int paramInt) {
    if (paramInt == 1)
      return true; 
    SharedPreferences sharedPreferences = this.j.getSharedPreferences(this.h, 0);
    this.i = sharedPreferences;
    if (sharedPreferences.getBoolean("show_never", false))
      return false; 
    int i = this.i.getInt("session_count", 1);
    if (paramInt == i) {
      SharedPreferences.Editor editor1 = this.i.edit();
      editor1.putInt("session_count", 1);
      editor1.commit();
      return true;
    } 
    if (paramInt > i) {
      SharedPreferences.Editor editor1 = this.i.edit();
      editor1.putInt("session_count", i + 1);
      editor1.commit();
      return false;
    } 
    SharedPreferences.Editor editor = this.i.edit();
    editor.putInt("session_count", 2);
    editor.commit();
    return false;
  }
  
  private void v() {
    int j;
    Context context3;
    Context context2;
    Context context1;
    this.l.setText(c.n(this.k));
    this.n.setText(c.s(this.k));
    this.m.setText(c.t(this.k));
    this.o.setText(c.u(this.k));
    this.p.setText(c.v(this.k));
    this.q.setText(c.w(this.k));
    this.t.setHint(c.x(this.k));
    TypedValue typedValue = new TypedValue();
    this.j.getTheme().resolveAttribute(b.a, typedValue, true);
    int i = typedValue.data;
    TextView textView3 = this.l;
    if (c.y(this.k) != 0) {
      context3 = this.j;
      j = c.y(this.k);
    } else {
      context3 = this.j;
      j = c.a;
    } 
    textView3.setTextColor(androidx.core.content.a.a(context3, j));
    TextView textView2 = this.n;
    if (c.c(this.k) != 0) {
      j = androidx.core.content.a.a(this.j, c.c(this.k));
    } else {
      j = i;
    } 
    textView2.setTextColor(j);
    textView3 = this.m;
    if (c.d(this.k) != 0) {
      context2 = this.j;
      j = c.d(this.k);
    } else {
      context2 = this.j;
      j = c.c;
    } 
    textView3.setTextColor(androidx.core.content.a.a(context2, j));
    textView3 = this.o;
    if (c.y(this.k) != 0) {
      context2 = this.j;
      j = c.y(this.k);
    } else {
      context2 = this.j;
      j = c.a;
    } 
    textView3.setTextColor(androidx.core.content.a.a(context2, j));
    TextView textView1 = this.p;
    if (c.c(this.k) != 0)
      i = androidx.core.content.a.a(this.j, c.c(this.k)); 
    textView1.setTextColor(i);
    textView3 = this.q;
    if (c.d(this.k) != 0) {
      context1 = this.j;
      i = c.d(this.k);
    } else {
      context1 = this.j;
      i = c.c;
    } 
    textView3.setTextColor(androidx.core.content.a.a(context1, i));
    if (c.e(this.k) != 0)
      this.t.setTextColor(androidx.core.content.a.a(this.j, c.e(this.k))); 
    if (c.f(this.k) != 0) {
      this.n.setBackgroundResource(c.f(this.k));
      this.p.setBackgroundResource(c.f(this.k));
    } 
    if (c.g(this.k) != 0) {
      this.m.setBackgroundResource(c.g(this.k));
      this.q.setBackgroundResource(c.g(this.k));
    } 
    if (c.h(this.k) != 0) {
      LayerDrawable layerDrawable = (LayerDrawable)this.r.getProgressDrawable();
      layerDrawable.getDrawable(2).setColorFilter(androidx.core.content.a.a(this.j, c.h(this.k)), PorterDuff.Mode.SRC_ATOP);
      layerDrawable.getDrawable(1).setColorFilter(androidx.core.content.a.a(this.j, c.h(this.k)), PorterDuff.Mode.SRC_ATOP);
      if (c.i(this.k) != 0) {
        i = c.i(this.k);
      } else {
        i = c.b;
      } 
      layerDrawable.getDrawable(0).setColorFilter(androidx.core.content.a.a(this.j, i), PorterDuff.Mode.SRC_ATOP);
    } 
    Drawable drawable = this.j.getPackageManager().getApplicationIcon(this.j.getApplicationInfo());
    ImageView imageView = this.s;
    if (c.j(this.k) != null)
      drawable = c.j(this.k); 
    imageView.setImageDrawable(drawable);
    this.r.setOnRatingBarChangeListener(this);
    this.n.setOnClickListener(this);
    this.m.setOnClickListener(this);
    this.p.setOnClickListener(this);
    this.q.setOnClickListener(this);
    if (this.x == 1)
      this.m.setVisibility(8); 
  }
  
  private void w() {
    this.o.setVisibility(0);
    this.t.setVisibility(0);
    this.v.setVisibility(0);
    this.u.setVisibility(8);
    this.s.setVisibility(8);
    this.l.setVisibility(8);
    this.r.setVisibility(8);
  }
  
  private void x(Context paramContext) {
    Uri uri = Uri.parse(c.r(this.k));
    try {
      paramContext.startActivity(new Intent("android.intent.action.VIEW", uri));
      return;
    } catch (ActivityNotFoundException activityNotFoundException) {
      Toast.makeText(paramContext, "Couldn't find PlayStore on this device", 0).show();
      return;
    } 
  }
  
  private void y() {
    c.m(this.k, new a(this));
  }
  
  private void z() {
    c.p(this.k, new b(this));
  }
  
  public void onClick(View paramView) {
    Animation animation;
    if (paramView.getId() == d.c) {
      dismiss();
      A();
      return;
    } 
    if (paramView.getId() == d.d) {
      dismiss();
      return;
    } 
    if (paramView.getId() == d.b) {
      String str = this.t.getText().toString().trim();
      if (TextUtils.isEmpty(str)) {
        animation = AnimationUtils.loadAnimation(this.j, a.a);
        this.t.startAnimation(animation);
        return;
      } 
      if (c.k(this.k) != null)
        c.k(this.k).a((String)animation); 
      dismiss();
      A();
      return;
    } 
    if (animation.getId() == d.a)
      dismiss(); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    requestWindowFeature(1);
    getWindow().setBackgroundDrawable((Drawable)new ColorDrawable(0));
    setContentView(e.a);
    this.l = (TextView)findViewById(d.k);
    this.m = (TextView)findViewById(d.c);
    this.n = (TextView)findViewById(d.d);
    this.o = (TextView)findViewById(d.h);
    this.p = (TextView)findViewById(d.b);
    this.q = (TextView)findViewById(d.a);
    this.r = (RatingBar)findViewById(d.j);
    this.s = (ImageView)findViewById(d.i);
    this.t = (EditText)findViewById(d.f);
    this.u = (LinearLayout)findViewById(d.e);
    this.v = (LinearLayout)findViewById(d.g);
    v();
  }
  
  public void onRatingChanged(RatingBar paramRatingBar, float paramFloat, boolean paramBoolean) {
    if (paramRatingBar.getRating() >= this.w) {
      this.y = true;
      if (c.l(this.k) == null)
        y(); 
      c.l(this.k).a(this, paramRatingBar.getRating(), this.y);
    } else {
      this.y = false;
      if (c.o(this.k) == null)
        z(); 
      c.o(this.k).a(this, paramRatingBar.getRating(), this.y);
    } 
    if (c.q(this.k) != null)
      c.q(this.k).a(paramRatingBar.getRating(), this.y); 
    A();
  }
  
  public void show() {
    if (u(this.x))
      super.show(); 
  }
  
  class a implements c.c {
    a(g this$0) {}
    
    public void a(g param1g, float param1Float, boolean param1Boolean) {
      param1g = this.a;
      g.s(param1g, g.r(param1g));
      this.a.dismiss();
    }
  }
  
  class b implements c.d {
    b(g this$0) {}
    
    public void a(g param1g, float param1Float, boolean param1Boolean) {
      g.t(this.a);
    }
  }
  
  public static class c {
    private final Context a;
    
    private String b;
    
    private String c;
    
    private String d;
    
    private String e;
    
    private String f;
    
    private String g;
    
    private String h;
    
    private String i;
    
    private int j;
    
    private int k;
    
    private int l;
    
    private int m;
    
    private int n;
    
    private int o;
    
    private int p;
    
    private int q;
    
    private c r;
    
    private d s;
    
    private a t;
    
    private b u;
    
    private Drawable v;
    
    private int w = 1;
    
    private float x = 1.0F;
    
    public c(Context param1Context) {
      this.a = param1Context;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("market://details?id=");
      stringBuilder.append(param1Context.getPackageName());
      this.e = stringBuilder.toString();
      E();
    }
    
    private void E() {
      this.b = this.a.getString(f.b);
      this.c = this.a.getString(f.d);
      this.d = this.a.getString(f.e);
      this.f = this.a.getString(f.c);
      this.g = this.a.getString(f.f);
      this.h = this.a.getString(f.a);
      this.i = this.a.getString(f.g);
    }
    
    public c A(String param1String) {
      this.h = param1String;
      return this;
    }
    
    public c B(String param1String) {
      this.i = param1String;
      return this;
    }
    
    public c C(String param1String) {
      this.g = param1String;
      return this;
    }
    
    public c D(String param1String) {
      this.f = param1String;
      return this;
    }
    
    public c F(String param1String) {
      this.d = param1String;
      return this;
    }
    
    public c G(a param1a) {
      this.t = param1a;
      return this;
    }
    
    public c H(String param1String) {
      this.c = param1String;
      return this;
    }
    
    public c I(int param1Int) {
      this.n = param1Int;
      return this;
    }
    
    public c J(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    public c K(int param1Int) {
      this.w = param1Int;
      return this;
    }
    
    public c L(float param1Float) {
      this.x = param1Float;
      return this;
    }
    
    public c M(String param1String) {
      this.b = param1String;
      return this;
    }
    
    public g z() {
      return new g(this.a, this);
    }
    
    public static interface a {
      void a(String param2String);
    }
    
    public static interface b {
      void a(float param2Float, boolean param2Boolean);
    }
    
    public static interface c {
      void a(g param2g, float param2Float, boolean param2Boolean);
    }
    
    public static interface d {
      void a(g param2g, float param2Float, boolean param2Boolean);
    }
  }
  
  public static interface a {
    void a(String param1String);
  }
  
  public static interface b {
    void a(float param1Float, boolean param1Boolean);
  }
  
  public static interface c {
    void a(g param1g, float param1Float, boolean param1Boolean);
  }
  
  public static interface d {
    void a(g param1g, float param1Float, boolean param1Boolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a2\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */