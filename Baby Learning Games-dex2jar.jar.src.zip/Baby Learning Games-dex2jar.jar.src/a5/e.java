package a5;

import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import p5.d;
import v5.c;

public final class e {
  public static final e a = new e();
  
  private static final String b = "IABUtil/Security";
  
  private static final String c = "RSA";
  
  private static final String d = "SHA1withRSA";
  
  private final PublicKey a(String paramString) throws IOException {
    try {
      byte[] arrayOfByte = Base64.decode(paramString, 0);
      PublicKey publicKey = KeyFactory.getInstance(c).generatePublic(new X509EncodedKeySpec(arrayOfByte));
      d.d(publicKey, "keyFactory.generatePubli…codedKeySpec(decodedKey))");
      return publicKey;
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      throw new RuntimeException(noSuchAlgorithmException);
    } catch (InvalidKeySpecException invalidKeySpecException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid key specification: ");
      stringBuilder.append(invalidKeySpecException);
      String str = stringBuilder.toString();
      Log.w(b, str);
      throw new IOException(str);
    } 
  }
  
  private final boolean b(PublicKey paramPublicKey, String paramString1, String paramString2) {
    try {
      byte[] arrayOfByte = Base64.decode(paramString2, 0);
      d.d(arrayOfByte, "decode(signature, Base64.DEFAULT)");
      try {
        Signature signature = Signature.getInstance(d);
        signature.initVerify(paramPublicKey);
        byte[] arrayOfByte1 = paramString1.getBytes(c.b);
        d.d(arrayOfByte1, "this as java.lang.String).getBytes(charset)");
        signature.update(arrayOfByte1);
        if (!signature.verify(arrayOfByte)) {
          Log.w(b, "Signature verification failed...");
          return false;
        } 
        return true;
      } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
        throw new RuntimeException(noSuchAlgorithmException);
      } catch (InvalidKeyException invalidKeyException) {
        Log.w(b, "Invalid key specification.");
        return false;
      } catch (SignatureException signatureException) {}
      Log.w(b, "Signature exception.");
      return false;
    } catch (IllegalArgumentException illegalArgumentException) {
      Log.w(b, "Base64 decoding failed.");
      return false;
    } 
  }
  
  public final boolean c(String paramString1, String paramString2, String paramString3) throws IOException {
    d.e(paramString1, "base64PublicKey");
    d.e(paramString2, "signedData");
    d.e(paramString3, "signature");
    if (TextUtils.isEmpty(paramString2) || TextUtils.isEmpty(paramString1) || TextUtils.isEmpty(paramString3)) {
      Log.w(b, "Purchase verification failed: missing data.");
      return false;
    } 
    return b(a(paramString1), paramString2, paramString3);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a5\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */