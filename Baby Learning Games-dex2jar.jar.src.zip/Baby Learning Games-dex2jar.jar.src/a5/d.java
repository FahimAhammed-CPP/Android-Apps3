package a5;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.util.Log;
import androidx.lifecycle.LiveData;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.SkuDetails;
import com.kotlin.trivialdrive.billingrepo.localdb.LocalBillingDb;
import e5.q;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import o5.p;
import w5.c0;
import w5.d0;
import w5.d1;
import w5.l0;
import w5.z0;
import y1.c;
import y1.f;
import y4.n;

public final class d implements f, c {
  public static final a i = new a(null);
  
  private static volatile d j;
  
  private final Application a;
  
  private com.android.billingclient.api.a b;
  
  private LocalBillingDb c;
  
  private final e5.e d;
  
  private final e5.e e;
  
  private final e5.e f;
  
  private final e5.e g;
  
  private final e5.e h;
  
  private d(Application paramApplication) {
    this.a = paramApplication;
    this.d = e5.f.a(new l(this));
    this.e = e5.f.a(new g(this));
    this.f = e5.f.a(new e(this));
    this.g = e5.f.a(new k(this));
    this.h = e5.f.a(new f(this));
  }
  
  private final void A(List<? extends Purchase> paramList) {
    Log.d("BillingRepository", "handleConsumablePurchasesAsync called");
    for (Purchase purchase : paramList) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("handleConsumablePurchasesAsync foreach it is ");
      stringBuilder.append(purchase);
      Log.d("BillingRepository", stringBuilder.toString());
      y1.d d1 = y1.d.b().b(purchase.c()).a();
      p5.d.d(d1, "newBuilder().setPurchase…it.purchaseToken).build()");
      com.android.billingclient.api.a a2 = this.b;
      com.android.billingclient.api.a a1 = a2;
      if (a2 == null) {
        p5.d.p("playStoreBillingClient");
        a1 = null;
      } 
      a1.b(d1, new b(this, purchase));
    } 
  }
  
  private static final void B(d paramd, Purchase paramPurchase, com.android.billingclient.api.e parame, String paramString) {
    p5.d.e(paramd, "this$0");
    p5.d.e(paramPurchase, "$it");
    p5.d.e(parame, "billingResult");
    p5.d.e(paramString, "purchaseToken");
    if (parame.b() == 0) {
      paramd.s(paramPurchase);
      return;
    } 
    Log.w("BillingRepository", parame.a());
  }
  
  private final Object C(b5.e parame, h5.d<? super q> paramd) {
    Object object = w5.e.c((h5.g)l0.b(), new h(this, parame, null), paramd);
    return (object == i5.b.c()) ? object : q.a;
  }
  
  private final void D() {
    com.android.billingclient.api.a a1 = com.android.billingclient.api.a.g(this.a.getApplicationContext()).b().c(this).a();
    p5.d.d(a1, "newBuilder(application.a…setListener(this).build()");
    this.b = a1;
    r();
  }
  
  private final boolean E(Purchase paramPurchase) {
    e e1 = e.a;
    String str2 = this.a.getString(n.c);
    p5.d.d(str2, "application.getString(R.string.base64)");
    String str3 = paramPurchase.a();
    p5.d.d(str3, "purchase.originalJson");
    String str1 = paramPurchase.d();
    p5.d.d(str1, "purchase.signature");
    return e1.c(str2, str3, str1);
  }
  
  private final boolean F() {
    com.android.billingclient.api.a a2 = this.b;
    com.android.billingclient.api.a a1 = a2;
    if (a2 == null) {
      p5.d.p("playStoreBillingClient");
      a1 = null;
    } 
    com.android.billingclient.api.e e1 = a1.d("subscriptions");
    p5.d.d(e1, "playStoreBillingClient.i…eatureType.SUBSCRIPTIONS)");
    int i = e1.b();
    if (i != -1) {
      if (i != 0) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("isSubscriptionSupported() error: ");
        stringBuilder.append(e1.a());
        Log.w("BillingRepository", stringBuilder.toString());
        return false;
      } 
      return true;
    } 
    r();
    return false;
  }
  
  private final z0 I(Set<? extends Purchase> paramSet) {
    return w5.e.b(d0.a(d1.b(null, 1, null).plus((h5.g)l0.b())), null, null, new i(paramSet, this, null), 3, null);
  }
  
  private final void K(String paramString, List<String> paramList) {
    com.android.billingclient.api.f f1 = com.android.billingclient.api.f.c().b(paramList).c(paramString).a();
    p5.d.d(f1, "newBuilder().setSkusList….setType(skuType).build()");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("querySkuDetailsAsync for ");
    stringBuilder.append(paramString);
    Log.d("BillingRepository", stringBuilder.toString());
    com.android.billingclient.api.a a2 = this.b;
    com.android.billingclient.api.a a1 = a2;
    if (a2 == null) {
      p5.d.p("playStoreBillingClient");
      a1 = null;
    } 
    a1.i(f1, new c(this));
  }
  
  private static final void L(d paramd, com.android.billingclient.api.e parame, List paramList) {
    p5.d.e(paramd, "this$0");
    p5.d.e(parame, "billingResult");
    if (parame.b() == 0) {
      List list;
      if (paramList == null) {
        list = f5.g.b();
      } else {
        list = paramList;
      } 
      if ((list.isEmpty() ^ true) != 0 && paramList != null)
        for (SkuDetails skuDetails : paramList)
          w5.e.b(d0.a(d1.b(null, 1, null).plus((h5.g)l0.b())), null, null, new j(paramd, skuDetails, null), 3, null);  
    } else {
      Log.e("BillingRepository", parame.a());
    } 
  }
  
  private final void p(List<? extends Purchase> paramList) {
    for (Purchase purchase : paramList) {
      y1.a a3 = y1.a.b().b(purchase.c()).a();
      p5.d.d(a3, "newBuilder().setPurchase…  .purchaseToken).build()");
      com.android.billingclient.api.a a2 = this.b;
      com.android.billingclient.api.a a1 = a2;
      if (a2 == null) {
        p5.d.p("playStoreBillingClient");
        a1 = null;
      } 
      a1.a(a3, new a(this, purchase));
    } 
  }
  
  private static final void q(d paramd, Purchase paramPurchase, com.android.billingclient.api.e parame) {
    p5.d.e(paramd, "this$0");
    p5.d.e(paramPurchase, "$purchase");
    p5.d.e(parame, "billingResult");
    if (parame.b() == 0) {
      paramd.t(paramPurchase);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("acknowledgeNonConsumablePurchasesAsync response is ");
    stringBuilder.append(parame.a());
    Log.d("BillingRepository", stringBuilder.toString());
  }
  
  private final boolean r() {
    Log.d("BillingRepository", "connectToPlayBillingService");
    com.android.billingclient.api.a a3 = this.b;
    com.android.billingclient.api.a a2 = null;
    com.android.billingclient.api.a a1 = a3;
    if (a3 == null) {
      p5.d.p("playStoreBillingClient");
      a1 = null;
    } 
    if (!a1.e()) {
      a1 = this.b;
      if (a1 == null) {
        p5.d.p("playStoreBillingClient");
        a1 = a2;
      } 
      a1.j(this);
      return true;
    } 
    return false;
  }
  
  private final z0 s(Purchase paramPurchase) {
    return w5.e.b(d0.a(d1.b(null, 1, null).plus((h5.g)l0.b())), null, null, new c(paramPurchase, this, null), 3, null);
  }
  
  private final z0 t(Purchase paramPurchase) {
    return w5.e.b(d0.a(d1.b(null, 1, null).plus((h5.g)l0.b())), null, null, new d(paramPurchase, this, null), 3, null);
  }
  
  public final void G(Activity paramActivity, b5.a parama) {
    p5.d.e(paramActivity, "activity");
    p5.d.e(parama, "augmentedSkuDetails");
    String str = parama.f();
    p5.d.c(str);
    H(paramActivity, new SkuDetails(str));
  }
  
  public final void H(Activity paramActivity, SkuDetails paramSkuDetails) {
    p5.d.e(paramActivity, "activity");
    p5.d.e(paramSkuDetails, "skuDetails");
    com.android.billingclient.api.c c1 = com.android.billingclient.api.c.b().b(paramSkuDetails).a();
    p5.d.d(c1, "newBuilder().setSkuDetails(skuDetails).build()");
    com.android.billingclient.api.a a2 = this.b;
    com.android.billingclient.api.a a1 = a2;
    if (a2 == null) {
      p5.d.p("playStoreBillingClient");
      a1 = null;
    } 
    a1.f(paramActivity, c1);
  }
  
  public final void J() {
    Log.d("BillingRepository", "queryPurchasesAsync called");
    HashSet<? extends Purchase> hashSet = new HashSet();
    com.android.billingclient.api.a a4 = this.b;
    Purchase.a a2 = null;
    com.android.billingclient.api.a a1 = a4;
    if (a4 == null) {
      p5.d.p("playStoreBillingClient");
      a1 = null;
    } 
    Purchase.a a3 = a1.h("inapp");
    p5.d.d(a3, "playStoreBillingClient.q…lingClient.SkuType.INAPP)");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("queryPurchasesAsync INAPP results: ");
    List list = a3.a();
    if (list != null) {
      Integer integer = Integer.valueOf(list.size());
    } else {
      list = null;
    } 
    stringBuilder.append(list);
    Log.d("BillingRepository", stringBuilder.toString());
    list = a3.a();
    if (list != null)
      hashSet.addAll(list); 
    if (F()) {
      Integer integer;
      com.android.billingclient.api.a a7 = this.b;
      com.android.billingclient.api.a a6 = a7;
      if (a7 == null) {
        p5.d.p("playStoreBillingClient");
        a6 = null;
      } 
      Purchase.a a5 = a6.h("subs");
      p5.d.d(a5, "playStoreBillingClient.q…llingClient.SkuType.SUBS)");
      List list1 = a5.a();
      if (list1 != null)
        hashSet.addAll(list1); 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("queryPurchasesAsync SUBS results: ");
      List list2 = a5.a();
      a5 = a2;
      if (list2 != null)
        integer = Integer.valueOf(list2.size()); 
      stringBuilder1.append(integer);
      Log.d("BillingRepository", stringBuilder1.toString());
    } 
    I(hashSet);
  }
  
  public final void M() {
    Log.d("BillingRepository", "startDataSourceConnections");
    D();
    this.c = LocalBillingDb.l.b((Context)this.a);
  }
  
  public final Object N(b5.h paramh, h5.d<? super Integer> paramd) {
    return w5.e.c((h5.g)l0.b(), new m(paramh, this, null), paramd);
  }
  
  public void a(com.android.billingclient.api.e parame, List<Purchase> paramList) {
    p5.d.e(parame, "billingResult");
    int i = parame.b();
    if (i != -1) {
      if (i != 0) {
        if (i != 7) {
          Log.i("BillingRepository", parame.a());
          return;
        } 
        Log.d("BillingRepository", parame.a());
        J();
        return;
      } 
      if (paramList != null) {
        I(f5.g.m(paramList));
        return;
      } 
    } else {
      r();
    } 
  }
  
  public void b(com.android.billingclient.api.e parame) {
    p5.d.e(parame, "billingResult");
    int i = parame.b();
    if (i != 0) {
      if (i != 3) {
        Log.d("BillingRepository", parame.a());
        return;
      } 
      Log.d("BillingRepository", parame.a());
      return;
    } 
    Log.d("BillingRepository", "onBillingSetupFinished successfully");
    b b = b.a;
    K("inapp", b.g());
    K("subs", b.i());
    J();
  }
  
  public void c() {
    Log.d("BillingRepository", "onBillingServiceDisconnected");
    r();
  }
  
  public final void u() {
    com.android.billingclient.api.a a2 = this.b;
    com.android.billingclient.api.a a1 = a2;
    if (a2 == null) {
      p5.d.p("playStoreBillingClient");
      a1 = null;
    } 
    a1.c();
    Log.d("BillingRepository", "startDataSourceConnections");
  }
  
  public final LiveData<b5.h> v() {
    return (LiveData<b5.h>)this.f.getValue();
  }
  
  public final LiveData<b5.i> w() {
    return (LiveData<b5.i>)this.h.getValue();
  }
  
  public final LiveData<List<b5.a>> x() {
    return (LiveData<List<b5.a>>)this.e.getValue();
  }
  
  public final LiveData<b5.m> y() {
    return (LiveData<b5.m>)this.g.getValue();
  }
  
  public final LiveData<List<b5.a>> z() {
    return (LiveData<List<b5.a>>)this.d.getValue();
  }
  
  public static final class a {
    private a() {}
    
    public final d a(Application param1Application) {
      // Byte code:
      //   0: aload_1
      //   1: ldc 'application'
      //   3: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
      //   6: invokestatic i : ()La5/d;
      //   9: astore_2
      //   10: aload_2
      //   11: ifnonnull -> 53
      //   14: aload_0
      //   15: monitorenter
      //   16: invokestatic i : ()La5/d;
      //   19: astore_3
      //   20: aload_3
      //   21: astore_2
      //   22: aload_3
      //   23: ifnonnull -> 44
      //   26: new a5/d
      //   29: dup
      //   30: aload_1
      //   31: aconst_null
      //   32: invokespecial <init> : (Landroid/app/Application;Lp5/b;)V
      //   35: astore_2
      //   36: getstatic a5/d.i : La5/d$a;
      //   39: astore_1
      //   40: aload_2
      //   41: invokestatic n : (La5/d;)V
      //   44: aload_0
      //   45: monitorexit
      //   46: aload_2
      //   47: areturn
      //   48: astore_1
      //   49: aload_0
      //   50: monitorexit
      //   51: aload_1
      //   52: athrow
      //   53: aload_2
      //   54: areturn
      // Exception table:
      //   from	to	target	type
      //   16	20	48	finally
      //   26	44	48	finally
    }
  }
  
  private static final class b {
    public static final b a = new b();
    
    private static final String b = "gas";
    
    private static final String c = "remove_ads";
    
    private static final String d = "gold_weekly";
    
    private static final String e = "gold_monthly";
    
    private static final String f = "gold_yearly";
    
    private static final List<String> g = f5.g.c((Object[])new String[] { "gas", "remove_ads" });
    
    private static final List<String> h;
    
    private static final List<String> i = f5.g.a("gas");
    
    private static final List<String> j;
    
    static {
      j = list;
    }
    
    public final List<String> a() {
      return i;
    }
    
    public final String b() {
      return b;
    }
    
    public final String c() {
      return e;
    }
    
    public final List<String> d() {
      return j;
    }
    
    public final String e() {
      return d;
    }
    
    public final String f() {
      return f;
    }
    
    public final List<String> g() {
      return g;
    }
    
    public final String h() {
      return c;
    }
    
    public final List<String> i() {
      return h;
    }
    
    static {
      List<String> list = f5.g.c((Object[])new String[] { "gold_weekly", "gold_monthly", "gold_yearly" });
      h = list;
    }
  }
  
  @j5.f(c = "com.kotlin.trivialdrive.billingrepo.BillingRepository$disburseConsumableEntitlements$1", f = "BillingRepository.kt", l = {839}, m = "invokeSuspend")
  static final class c extends j5.k implements p<c0, h5.d<? super q>, Object> {
    int j;
    
    c(Purchase param1Purchase, d param1d, h5.d<? super c> param1d1) {
      super(2, param1d1);
    }
    
    public final h5.d<q> d(Object param1Object, h5.d<?> param1d) {
      return (h5.d<q>)new c(this.k, this.l, (h5.d)param1d);
    }
    
    public final Object j(Object param1Object) {
      Object object = i5.b.c();
      int i = this.j;
      if (i != 0) {
        if (i == 1) {
          e5.l.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        e5.l.b(param1Object);
        if (p5.d.a(this.k.e().get(0), d.b.a.b())) {
          param1Object = this.l;
          b5.h h = new b5.h(1);
          this.j = 1;
          if (param1Object.N(h, (h5.d<? super Integer>)this) == object)
            return object; 
        } else {
          return q.a;
        } 
      } 
      object = d.j(this.l);
      param1Object = object;
      if (object == null) {
        p5.d.p("localCacheBillingClient");
        param1Object = null;
      } 
      param1Object.y().b(this.k);
      return q.a;
    }
    
    public final Object m(c0 param1c0, h5.d<? super q> param1d) {
      return ((c)d(param1c0, param1d)).j(q.a);
    }
  }
  
  @j5.f(c = "com.kotlin.trivialdrive.billingrepo.BillingRepository$disburseNonConsumableEntitlement$1", f = "BillingRepository.kt", l = {692, 698}, m = "invokeSuspend")
  static final class d extends j5.k implements p<c0, h5.d<? super q>, Object> {
    Object j;
    
    int k;
    
    d(Purchase param1Purchase, d param1d, h5.d<? super d> param1d1) {
      super(2, param1d1);
    }
    
    public final h5.d<q> d(Object param1Object, h5.d<?> param1d) {
      return (h5.d<q>)new d(this.l, this.m, (h5.d)param1d);
    }
    
    public final Object j(Object param1Object) {
      // Byte code:
      //   0: invokestatic c : ()Ljava/lang/Object;
      //   3: astore #4
      //   5: aload_0
      //   6: getfield k : I
      //   9: istore_2
      //   10: aconst_null
      //   11: astore #5
      //   13: iload_2
      //   14: ifeq -> 75
      //   17: iload_2
      //   18: iconst_1
      //   19: if_icmpeq -> 56
      //   22: iload_2
      //   23: iconst_2
      //   24: if_icmpne -> 46
      //   27: aload_0
      //   28: getfield j : Ljava/lang/Object;
      //   31: checkcast b5/i
      //   34: astore #4
      //   36: aload_1
      //   37: invokestatic b : (Ljava/lang/Object;)V
      //   40: aload #4
      //   42: astore_1
      //   43: goto -> 313
      //   46: new java/lang/IllegalStateException
      //   49: dup
      //   50: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   52: invokespecial <init> : (Ljava/lang/String;)V
      //   55: athrow
      //   56: aload_0
      //   57: getfield j : Ljava/lang/Object;
      //   60: checkcast b5/m
      //   63: astore #4
      //   65: aload_1
      //   66: invokestatic b : (Ljava/lang/Object;)V
      //   69: aload #4
      //   71: astore_1
      //   72: goto -> 151
      //   75: aload_1
      //   76: invokestatic b : (Ljava/lang/Object;)V
      //   79: aload_0
      //   80: getfield l : Lcom/android/billingclient/api/Purchase;
      //   83: invokevirtual e : ()Ljava/util/ArrayList;
      //   86: iconst_0
      //   87: invokevirtual get : (I)Ljava/lang/Object;
      //   90: checkcast java/lang/String
      //   93: astore_1
      //   94: getstatic a5/d$b.a : La5/d$b;
      //   97: astore #6
      //   99: aload_1
      //   100: aload #6
      //   102: invokevirtual h : ()Ljava/lang/String;
      //   105: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   108: ifeq -> 223
      //   111: new b5/m
      //   114: dup
      //   115: iconst_1
      //   116: invokespecial <init> : (Z)V
      //   119: astore_1
      //   120: aload_0
      //   121: getfield m : La5/d;
      //   124: astore #6
      //   126: aload_0
      //   127: aload_1
      //   128: putfield j : Ljava/lang/Object;
      //   131: aload_0
      //   132: iconst_1
      //   133: putfield k : I
      //   136: aload #6
      //   138: aload_1
      //   139: aload_0
      //   140: invokestatic l : (La5/d;Lb5/e;Lh5/d;)Ljava/lang/Object;
      //   143: aload #4
      //   145: if_acmpne -> 151
      //   148: aload #4
      //   150: areturn
      //   151: aload_0
      //   152: getfield m : La5/d;
      //   155: invokestatic j : (La5/d;)Lcom/kotlin/trivialdrive/billingrepo/localdb/LocalBillingDb;
      //   158: astore #6
      //   160: aload #6
      //   162: astore #4
      //   164: aload #6
      //   166: ifnonnull -> 177
      //   169: ldc 'localCacheBillingClient'
      //   171: invokestatic p : (Ljava/lang/String;)V
      //   174: aconst_null
      //   175: astore #4
      //   177: aload #4
      //   179: invokevirtual z : ()Lb5/b;
      //   182: astore #4
      //   184: aload_0
      //   185: getfield l : Lcom/android/billingclient/api/Purchase;
      //   188: invokevirtual e : ()Ljava/util/ArrayList;
      //   191: iconst_0
      //   192: invokevirtual get : (I)Ljava/lang/Object;
      //   195: astore #6
      //   197: aload #6
      //   199: ldc 'purchase.skus[0]'
      //   201: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
      //   204: aload #4
      //   206: aload #6
      //   208: checkcast java/lang/String
      //   211: aload_1
      //   212: invokevirtual d : ()Z
      //   215: invokeinterface d : (Ljava/lang/String;Z)V
      //   220: goto -> 495
      //   223: aload_1
      //   224: aload #6
      //   226: invokevirtual e : ()Ljava/lang/String;
      //   229: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   232: ifeq -> 240
      //   235: iconst_1
      //   236: istore_3
      //   237: goto -> 250
      //   240: aload_1
      //   241: aload #6
      //   243: invokevirtual c : ()Ljava/lang/String;
      //   246: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   249: istore_3
      //   250: iload_3
      //   251: ifeq -> 259
      //   254: iconst_1
      //   255: istore_3
      //   256: goto -> 269
      //   259: aload_1
      //   260: aload #6
      //   262: invokevirtual f : ()Ljava/lang/String;
      //   265: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   268: istore_3
      //   269: iload_3
      //   270: ifeq -> 495
      //   273: new b5/i
      //   276: dup
      //   277: iconst_1
      //   278: invokespecial <init> : (Z)V
      //   281: astore_1
      //   282: aload_0
      //   283: getfield m : La5/d;
      //   286: astore #6
      //   288: aload_0
      //   289: aload_1
      //   290: putfield j : Ljava/lang/Object;
      //   293: aload_0
      //   294: iconst_2
      //   295: putfield k : I
      //   298: aload #6
      //   300: aload_1
      //   301: aload_0
      //   302: invokestatic l : (La5/d;Lb5/e;Lh5/d;)Ljava/lang/Object;
      //   305: aload #4
      //   307: if_acmpne -> 313
      //   310: aload #4
      //   312: areturn
      //   313: aload_0
      //   314: getfield m : La5/d;
      //   317: invokestatic j : (La5/d;)Lcom/kotlin/trivialdrive/billingrepo/localdb/LocalBillingDb;
      //   320: astore #6
      //   322: aload #6
      //   324: astore #4
      //   326: aload #6
      //   328: ifnonnull -> 339
      //   331: ldc 'localCacheBillingClient'
      //   333: invokestatic p : (Ljava/lang/String;)V
      //   336: aconst_null
      //   337: astore #4
      //   339: aload #4
      //   341: invokevirtual z : ()Lb5/b;
      //   344: astore #4
      //   346: aload_0
      //   347: getfield l : Lcom/android/billingclient/api/Purchase;
      //   350: invokevirtual e : ()Ljava/util/ArrayList;
      //   353: iconst_0
      //   354: invokevirtual get : (I)Ljava/lang/Object;
      //   357: astore #6
      //   359: aload #6
      //   361: ldc 'purchase.skus[0]'
      //   363: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
      //   366: aload #4
      //   368: aload #6
      //   370: checkcast java/lang/String
      //   373: aload_1
      //   374: invokevirtual d : ()Z
      //   377: invokeinterface d : (Ljava/lang/String;Z)V
      //   382: getstatic a5/d$b.a : La5/d$b;
      //   385: invokevirtual d : ()Ljava/util/List;
      //   388: astore #4
      //   390: aload_0
      //   391: getfield l : Lcom/android/billingclient/api/Purchase;
      //   394: astore #7
      //   396: aload_0
      //   397: getfield m : La5/d;
      //   400: astore #8
      //   402: aload #4
      //   404: invokeinterface iterator : ()Ljava/util/Iterator;
      //   409: astore #9
      //   411: aload #9
      //   413: invokeinterface hasNext : ()Z
      //   418: ifeq -> 495
      //   421: aload #9
      //   423: invokeinterface next : ()Ljava/lang/Object;
      //   428: checkcast java/lang/String
      //   431: astore #10
      //   433: aload #10
      //   435: aload #7
      //   437: invokevirtual e : ()Ljava/util/ArrayList;
      //   440: iconst_0
      //   441: invokevirtual get : (I)Ljava/lang/Object;
      //   444: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   447: ifne -> 411
      //   450: aload #8
      //   452: invokestatic j : (La5/d;)Lcom/kotlin/trivialdrive/billingrepo/localdb/LocalBillingDb;
      //   455: astore #6
      //   457: aload #6
      //   459: astore #4
      //   461: aload #6
      //   463: ifnonnull -> 474
      //   466: ldc 'localCacheBillingClient'
      //   468: invokestatic p : (Ljava/lang/String;)V
      //   471: aconst_null
      //   472: astore #4
      //   474: aload #4
      //   476: invokevirtual z : ()Lb5/b;
      //   479: aload #10
      //   481: aload_1
      //   482: invokevirtual d : ()Z
      //   485: iconst_1
      //   486: ixor
      //   487: invokeinterface d : (Ljava/lang/String;Z)V
      //   492: goto -> 411
      //   495: aload_0
      //   496: getfield m : La5/d;
      //   499: invokestatic j : (La5/d;)Lcom/kotlin/trivialdrive/billingrepo/localdb/LocalBillingDb;
      //   502: astore_1
      //   503: aload_1
      //   504: ifnonnull -> 518
      //   507: ldc 'localCacheBillingClient'
      //   509: invokestatic p : (Ljava/lang/String;)V
      //   512: aload #5
      //   514: astore_1
      //   515: goto -> 518
      //   518: aload_1
      //   519: invokevirtual y : ()Lb5/j;
      //   522: aload_0
      //   523: getfield l : Lcom/android/billingclient/api/Purchase;
      //   526: invokeinterface b : (Lcom/android/billingclient/api/Purchase;)V
      //   531: getstatic e5/q.a : Le5/q;
      //   534: areturn
    }
    
    public final Object m(c0 param1c0, h5.d<? super q> param1d) {
      return ((d)d(param1c0, param1d)).j(q.a);
    }
  }
  
  static final class e extends p5.e implements o5.a<LiveData<b5.h>> {
    e(d param1d) {
      super(0);
    }
    
    public final LiveData<b5.h> c() {
      boolean bool;
      if (d.j(this.g) != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        d d1 = this.g;
        d.o(d1, LocalBillingDb.l.b((Context)d.h(d1)));
      } 
      LocalBillingDb localBillingDb2 = d.j(this.g);
      LocalBillingDb localBillingDb1 = localBillingDb2;
      if (localBillingDb2 == null) {
        p5.d.p("localCacheBillingClient");
        localBillingDb1 = null;
      } 
      return localBillingDb1.x().f();
    }
  }
  
  static final class f extends p5.e implements o5.a<LiveData<b5.i>> {
    f(d param1d) {
      super(0);
    }
    
    public final LiveData<b5.i> c() {
      boolean bool;
      if (d.j(this.g) != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        d d1 = this.g;
        d.o(d1, LocalBillingDb.l.b((Context)d.h(d1)));
      } 
      LocalBillingDb localBillingDb2 = d.j(this.g);
      LocalBillingDb localBillingDb1 = localBillingDb2;
      if (localBillingDb2 == null) {
        p5.d.p("localCacheBillingClient");
        localBillingDb1 = null;
      } 
      return localBillingDb1.x().g();
    }
  }
  
  static final class g extends p5.e implements o5.a<LiveData<List<? extends b5.a>>> {
    g(d param1d) {
      super(0);
    }
    
    public final LiveData<List<b5.a>> c() {
      boolean bool;
      if (d.j(this.g) != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        d d1 = this.g;
        d.o(d1, LocalBillingDb.l.b((Context)d.h(d1)));
      } 
      LocalBillingDb localBillingDb2 = d.j(this.g);
      LocalBillingDb localBillingDb1 = localBillingDb2;
      if (localBillingDb2 == null) {
        p5.d.p("localCacheBillingClient");
        localBillingDb1 = null;
      } 
      return localBillingDb1.z().f();
    }
  }
  
  @j5.f(c = "com.kotlin.trivialdrive.billingrepo.BillingRepository$insert$2", f = "BillingRepository.kt", l = {}, m = "invokeSuspend")
  static final class h extends j5.k implements p<c0, h5.d<? super q>, Object> {
    int j;
    
    h(d param1d, b5.e param1e, h5.d<? super h> param1d1) {
      super(2, param1d1);
    }
    
    public final h5.d<q> d(Object param1Object, h5.d<?> param1d) {
      return (h5.d<q>)new h(this.k, this.l, (h5.d)param1d);
    }
    
    public final Object j(Object param1Object) {
      i5.b.c();
      if (this.j == 0) {
        e5.l.b(param1Object);
        LocalBillingDb localBillingDb = d.j(this.k);
        param1Object = localBillingDb;
        if (localBillingDb == null) {
          p5.d.p("localCacheBillingClient");
          param1Object = null;
        } 
        param1Object.x().c(new b5.e[] { this.l });
        return q.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    public final Object m(c0 param1c0, h5.d<? super q> param1d) {
      return ((h)d(param1c0, param1d)).j(q.a);
    }
  }
  
  @j5.f(c = "com.kotlin.trivialdrive.billingrepo.BillingRepository$processPurchases$1", f = "BillingRepository.kt", l = {}, m = "invokeSuspend")
  static final class i extends j5.k implements p<c0, h5.d<? super q>, Object> {
    int j;
    
    i(Set<? extends Purchase> param1Set, d param1d, h5.d<? super i> param1d1) {
      super(2, param1d1);
    }
    
    public final h5.d<q> d(Object param1Object, h5.d<?> param1d) {
      return (h5.d<q>)new i(this.k, this.l, (h5.d)param1d);
    }
    
    public final Object j(Object<Purchase> param1Object) {
      // Byte code:
      //   0: invokestatic c : ()Ljava/lang/Object;
      //   3: pop
      //   4: aload_0
      //   5: getfield j : I
      //   8: ifne -> 536
      //   11: aload_1
      //   12: invokestatic b : (Ljava/lang/Object;)V
      //   15: ldc 'BillingRepository'
      //   17: ldc 'processPurchases called'
      //   19: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   22: pop
      //   23: new java/util/HashSet
      //   26: dup
      //   27: aload_0
      //   28: getfield k : Ljava/util/Set;
      //   31: invokeinterface size : ()I
      //   36: invokespecial <init> : (I)V
      //   39: astore #4
      //   41: new java/lang/StringBuilder
      //   44: dup
      //   45: invokespecial <init> : ()V
      //   48: astore_1
      //   49: aload_1
      //   50: ldc 'processPurchases newBatch content '
      //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   55: pop
      //   56: aload_1
      //   57: aload_0
      //   58: getfield k : Ljava/util/Set;
      //   61: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   64: pop
      //   65: ldc 'BillingRepository'
      //   67: aload_1
      //   68: invokevirtual toString : ()Ljava/lang/String;
      //   71: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   74: pop
      //   75: aload_0
      //   76: getfield k : Ljava/util/Set;
      //   79: astore_2
      //   80: aload_0
      //   81: getfield l : La5/d;
      //   84: astore_1
      //   85: aload_2
      //   86: invokeinterface iterator : ()Ljava/util/Iterator;
      //   91: astore_2
      //   92: aload_2
      //   93: invokeinterface hasNext : ()Z
      //   98: ifeq -> 193
      //   101: aload_2
      //   102: invokeinterface next : ()Ljava/lang/Object;
      //   107: checkcast com/android/billingclient/api/Purchase
      //   110: astore_3
      //   111: aload_3
      //   112: invokevirtual b : ()I
      //   115: iconst_1
      //   116: if_icmpne -> 137
      //   119: aload_1
      //   120: aload_3
      //   121: invokestatic m : (La5/d;Lcom/android/billingclient/api/Purchase;)Z
      //   124: ifeq -> 92
      //   127: aload #4
      //   129: aload_3
      //   130: invokevirtual add : (Ljava/lang/Object;)Z
      //   133: pop
      //   134: goto -> 92
      //   137: aload_3
      //   138: invokevirtual b : ()I
      //   141: iconst_2
      //   142: if_icmpne -> 92
      //   145: new java/lang/StringBuilder
      //   148: dup
      //   149: invokespecial <init> : ()V
      //   152: astore #5
      //   154: aload #5
      //   156: ldc 'Received a pending purchase of SKU: '
      //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   161: pop
      //   162: aload #5
      //   164: aload_3
      //   165: invokevirtual e : ()Ljava/util/ArrayList;
      //   168: iconst_0
      //   169: invokevirtual get : (I)Ljava/lang/Object;
      //   172: checkcast java/lang/String
      //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   178: pop
      //   179: ldc 'BillingRepository'
      //   181: aload #5
      //   183: invokevirtual toString : ()Ljava/lang/String;
      //   186: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   189: pop
      //   190: goto -> 92
      //   193: new java/util/ArrayList
      //   196: dup
      //   197: invokespecial <init> : ()V
      //   200: astore_1
      //   201: new java/util/ArrayList
      //   204: dup
      //   205: invokespecial <init> : ()V
      //   208: astore_2
      //   209: aload #4
      //   211: invokeinterface iterator : ()Ljava/util/Iterator;
      //   216: astore_3
      //   217: aload_3
      //   218: invokeinterface hasNext : ()Z
      //   223: ifeq -> 284
      //   226: aload_3
      //   227: invokeinterface next : ()Ljava/lang/Object;
      //   232: astore #5
      //   234: aload #5
      //   236: checkcast com/android/billingclient/api/Purchase
      //   239: astore #6
      //   241: getstatic a5/d$b.a : La5/d$b;
      //   244: invokevirtual a : ()Ljava/util/List;
      //   247: aload #6
      //   249: invokevirtual e : ()Ljava/util/ArrayList;
      //   252: iconst_0
      //   253: invokevirtual get : (I)Ljava/lang/Object;
      //   256: invokeinterface contains : (Ljava/lang/Object;)Z
      //   261: ifeq -> 274
      //   264: aload_1
      //   265: aload #5
      //   267: invokevirtual add : (Ljava/lang/Object;)Z
      //   270: pop
      //   271: goto -> 217
      //   274: aload_2
      //   275: aload #5
      //   277: invokevirtual add : (Ljava/lang/Object;)Z
      //   280: pop
      //   281: goto -> 217
      //   284: new e5/j
      //   287: dup
      //   288: aload_1
      //   289: aload_2
      //   290: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   293: astore_1
      //   294: aload_1
      //   295: invokevirtual a : ()Ljava/lang/Object;
      //   298: checkcast java/util/List
      //   301: astore #5
      //   303: aload_1
      //   304: invokevirtual b : ()Ljava/lang/Object;
      //   307: checkcast java/util/List
      //   310: astore #6
      //   312: new java/lang/StringBuilder
      //   315: dup
      //   316: invokespecial <init> : ()V
      //   319: astore_1
      //   320: aload_1
      //   321: ldc 'processPurchases consumables content '
      //   323: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   326: pop
      //   327: aload_1
      //   328: aload #5
      //   330: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   333: pop
      //   334: ldc 'BillingRepository'
      //   336: aload_1
      //   337: invokevirtual toString : ()Ljava/lang/String;
      //   340: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   343: pop
      //   344: new java/lang/StringBuilder
      //   347: dup
      //   348: invokespecial <init> : ()V
      //   351: astore_1
      //   352: aload_1
      //   353: ldc 'processPurchases non-consumables content '
      //   355: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   358: pop
      //   359: aload_1
      //   360: aload #6
      //   362: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   365: pop
      //   366: ldc 'BillingRepository'
      //   368: aload_1
      //   369: invokevirtual toString : ()Ljava/lang/String;
      //   372: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   375: pop
      //   376: aload_0
      //   377: getfield l : La5/d;
      //   380: invokestatic j : (La5/d;)Lcom/kotlin/trivialdrive/billingrepo/localdb/LocalBillingDb;
      //   383: astore_3
      //   384: aconst_null
      //   385: astore_2
      //   386: aload_3
      //   387: astore_1
      //   388: aload_3
      //   389: ifnonnull -> 399
      //   392: ldc 'localCacheBillingClient'
      //   394: invokestatic p : (Ljava/lang/String;)V
      //   397: aconst_null
      //   398: astore_1
      //   399: aload_1
      //   400: invokevirtual y : ()Lb5/j;
      //   403: invokeinterface a : ()Ljava/util/List;
      //   408: astore_1
      //   409: new java/lang/StringBuilder
      //   412: dup
      //   413: invokespecial <init> : ()V
      //   416: astore_3
      //   417: aload_3
      //   418: ldc 'processPurchases purchases in the lcl db '
      //   420: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   423: pop
      //   424: aload_3
      //   425: aload_1
      //   426: invokeinterface size : ()I
      //   431: invokestatic a : (I)Ljava/lang/Integer;
      //   434: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   437: pop
      //   438: ldc 'BillingRepository'
      //   440: aload_3
      //   441: invokevirtual toString : ()Ljava/lang/String;
      //   444: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   447: pop
      //   448: aload_0
      //   449: getfield l : La5/d;
      //   452: invokestatic j : (La5/d;)Lcom/kotlin/trivialdrive/billingrepo/localdb/LocalBillingDb;
      //   455: astore_1
      //   456: aload_1
      //   457: ifnonnull -> 470
      //   460: ldc 'localCacheBillingClient'
      //   462: invokestatic p : (Ljava/lang/String;)V
      //   465: aload_2
      //   466: astore_1
      //   467: goto -> 470
      //   470: aload_1
      //   471: invokevirtual y : ()Lb5/j;
      //   474: astore_1
      //   475: aload #4
      //   477: iconst_0
      //   478: anewarray com/android/billingclient/api/Purchase
      //   481: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
      //   486: astore_2
      //   487: aload_2
      //   488: ldc 'null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>'
      //   490: invokestatic requireNonNull : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
      //   493: pop
      //   494: aload_2
      //   495: checkcast [Lcom/android/billingclient/api/Purchase;
      //   498: astore_2
      //   499: aload_1
      //   500: aload_2
      //   501: aload_2
      //   502: arraylength
      //   503: invokestatic copyOf : ([Ljava/lang/Object;I)[Ljava/lang/Object;
      //   506: checkcast [Lcom/android/billingclient/api/Purchase;
      //   509: invokeinterface d : ([Lcom/android/billingclient/api/Purchase;)V
      //   514: aload_0
      //   515: getfield l : La5/d;
      //   518: aload #5
      //   520: invokestatic k : (La5/d;Ljava/util/List;)V
      //   523: aload_0
      //   524: getfield l : La5/d;
      //   527: aload #6
      //   529: invokestatic g : (La5/d;Ljava/util/List;)V
      //   532: getstatic e5/q.a : Le5/q;
      //   535: areturn
      //   536: new java/lang/IllegalStateException
      //   539: dup
      //   540: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   542: invokespecial <init> : (Ljava/lang/String;)V
      //   545: athrow
    }
    
    public final Object m(c0 param1c0, h5.d<? super q> param1d) {
      return ((i)d(param1c0, param1d)).j(q.a);
    }
  }
  
  @j5.f(c = "com.kotlin.trivialdrive.billingrepo.BillingRepository$querySkuDetailsAsync$1$1$1", f = "BillingRepository.kt", l = {}, m = "invokeSuspend")
  static final class j extends j5.k implements p<c0, h5.d<? super q>, Object> {
    int j;
    
    j(d param1d, SkuDetails param1SkuDetails, h5.d<? super j> param1d1) {
      super(2, param1d1);
    }
    
    public final h5.d<q> d(Object param1Object, h5.d<?> param1d) {
      return (h5.d<q>)new j(this.k, this.l, (h5.d)param1d);
    }
    
    public final Object j(Object param1Object) {
      i5.b.c();
      if (this.j == 0) {
        e5.l.b(param1Object);
        LocalBillingDb localBillingDb = d.j(this.k);
        param1Object = localBillingDb;
        if (localBillingDb == null) {
          p5.d.p("localCacheBillingClient");
          param1Object = null;
        } 
        param1Object = param1Object.z();
        SkuDetails skuDetails = this.l;
        p5.d.d(skuDetails, "it");
        param1Object.c(skuDetails);
        return q.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    public final Object m(c0 param1c0, h5.d<? super q> param1d) {
      return ((j)d(param1c0, param1d)).j(q.a);
    }
  }
  
  static final class k extends p5.e implements o5.a<LiveData<b5.m>> {
    k(d param1d) {
      super(0);
    }
    
    public final LiveData<b5.m> c() {
      boolean bool;
      if (d.j(this.g) != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        d d1 = this.g;
        d.o(d1, LocalBillingDb.l.b((Context)d.h(d1)));
      } 
      LocalBillingDb localBillingDb2 = d.j(this.g);
      LocalBillingDb localBillingDb1 = localBillingDb2;
      if (localBillingDb2 == null) {
        p5.d.p("localCacheBillingClient");
        localBillingDb1 = null;
      } 
      return localBillingDb1.x().b();
    }
  }
  
  static final class l extends p5.e implements o5.a<LiveData<List<? extends b5.a>>> {
    l(d param1d) {
      super(0);
    }
    
    public final LiveData<List<b5.a>> c() {
      boolean bool;
      if (d.j(this.g) != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        d d1 = this.g;
        d.o(d1, LocalBillingDb.l.b((Context)d.h(d1)));
      } 
      LocalBillingDb localBillingDb2 = d.j(this.g);
      LocalBillingDb localBillingDb1 = localBillingDb2;
      if (localBillingDb2 == null) {
        p5.d.p("localCacheBillingClient");
        localBillingDb1 = null;
      } 
      return localBillingDb1.z().b();
    }
  }
  
  @j5.f(c = "com.kotlin.trivialdrive.billingrepo.BillingRepository$updateGasTank$2", f = "BillingRepository.kt", l = {}, m = "invokeSuspend")
  static final class m extends j5.k implements p<c0, h5.d<? super Integer>, Object> {
    int j;
    
    m(b5.h param1h, d param1d, h5.d<? super m> param1d1) {
      super(2, param1d1);
    }
    
    public final h5.d<q> d(Object param1Object, h5.d<?> param1d) {
      return (h5.d<q>)new m(this.k, this.l, (h5.d)param1d);
    }
    
    public final Object j(Object param1Object) {
      i5.b.c();
      if (this.j == 0) {
        e5.l.b(param1Object);
        Log.d("BillingRepository", "updateGasTank");
        p5.f f = new p5.f();
        f.f = this.k;
        b5.h h1 = (b5.h)this.l.v().e();
        Object object = null;
        if (h1 != null) {
          param1Object = this.k;
          synchronized (this.l) {
            if (!p5.d.a(h1, param1Object))
              f.f = new b5.h(h1.e() + param1Object.e()); 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("New purchase level is ");
            stringBuilder.append(param1Object.e());
            stringBuilder.append("; existing level is ");
            stringBuilder.append(h1.e());
            stringBuilder.append("; so the final result is ");
            stringBuilder.append(((b5.h)f.f).e());
            Log.d("BillingRepository", stringBuilder.toString());
            LocalBillingDb localBillingDb = d.j(null);
            param1Object = localBillingDb;
            if (localBillingDb == null) {
              p5.d.p("localCacheBillingClient");
              param1Object = null;
            } 
            param1Object.x().h((b5.h)f.f);
            param1Object = q.a;
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{b5/h}, name=null} */
          } 
        } 
        if (this.l.v().e() == null) {
          LocalBillingDb localBillingDb = d.j(this.l);
          param1Object = localBillingDb;
          if (localBillingDb == null) {
            p5.d.p("localCacheBillingClient");
            param1Object = null;
          } 
          param1Object.x().a((b5.h)f.f);
          param1Object = new StringBuilder();
          param1Object.append("No we just added from null gas with level: ");
          param1Object.append(this.k.e());
          Log.d("BillingRepository", param1Object.toString());
        } 
        param1Object = d.j(this.l);
        if (param1Object == null) {
          p5.d.p("localCacheBillingClient");
          param1Object = object;
        } 
        param1Object.z().d(d.b.a.b(), ((b5.h)f.f).f());
        return j5.b.a(Log.d("BillingRepository", "updated AugmentedSkuDetails as well"));
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
    
    public final Object m(c0 param1c0, h5.d<? super Integer> param1d) {
      return ((m)d(param1c0, param1d)).j(q.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a5\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */