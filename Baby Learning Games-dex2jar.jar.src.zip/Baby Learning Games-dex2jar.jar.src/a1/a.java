package a1;

public final class a {
  public static final int[] a = new int[] { 16843173, 16843551, 16844359, 2130968630, 2130969164 };
  
  public static final int[] b = new int[] { 2130969058, 2130969059, 2130969060, 2130969061, 2130969062, 2130969063, 2130969064 };
  
  public static final int[] c = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130969056, 2130969065, 2130969066, 2130969067, 2130969742 };
  
  public static final int[] d = new int[] { 
      16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
      16844050, 16844051 };
  
  public static final int[] e = new int[] { 16843173, 16844052 };
  
  public static final int[] f = new int[] { 16842960, 2130968922, 2130968983, 2130968993, 2130969170, 2130969421, 2130969422, 2130969423, 2130969424 };
  
  public static final int[] g = new int[] { 16842755, 16843245, 2130968640, 2130969376 };
  
  public static final int[] h = new int[] { 16844014, 2130969745 };
  
  public static final int[] i = new int[] { 2130969538 };
  
  public static final int j = 0;
  
  public static final int[] k = new int[] { 16842753, 16842960 };
  
  public static final int l = 0;
  
  public static final int m = 1;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a1\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */