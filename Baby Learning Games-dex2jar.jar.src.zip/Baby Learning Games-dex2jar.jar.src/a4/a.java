package a4;

import android.content.Context;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.View;
import i4.b;

public class a {
  public static int a(int paramInt1, int paramInt2) {
    return c0.a.j(paramInt1, Color.alpha(paramInt1) * paramInt2 / 255);
  }
  
  public static int b(Context paramContext, int paramInt1, int paramInt2) {
    TypedValue typedValue = b.a(paramContext, paramInt1);
    return (typedValue != null) ? typedValue.data : paramInt2;
  }
  
  public static int c(Context paramContext, int paramInt, String paramString) {
    return b.d(paramContext, paramInt, paramString);
  }
  
  public static int d(View paramView, int paramInt) {
    return b.e(paramView, paramInt);
  }
  
  public static int e(View paramView, int paramInt1, int paramInt2) {
    return b(paramView.getContext(), paramInt1, paramInt2);
  }
  
  public static boolean f(int paramInt) {
    return (paramInt != 0 && c0.a.c(paramInt) > 0.5D);
  }
  
  public static int g(int paramInt1, int paramInt2) {
    return c0.a.f(paramInt2, paramInt1);
  }
  
  public static int h(int paramInt1, int paramInt2, float paramFloat) {
    return g(paramInt1, c0.a.j(paramInt2, Math.round(Color.alpha(paramInt2) * paramFloat)));
  }
  
  public static int i(View paramView, int paramInt1, int paramInt2, float paramFloat) {
    return h(d(paramView, paramInt1), d(paramView, paramInt2), paramFloat);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */