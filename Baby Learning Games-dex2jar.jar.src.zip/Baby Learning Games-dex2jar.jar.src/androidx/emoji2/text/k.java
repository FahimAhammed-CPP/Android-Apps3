package androidx.emoji2.text;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

class k {
  private static b a(c paramc) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: iconst_4
    //   2: invokeinterface a : (I)V
    //   7: aload_0
    //   8: invokeinterface b : ()I
    //   13: istore_3
    //   14: iload_3
    //   15: bipush #100
    //   17: if_icmpgt -> 210
    //   20: aload_0
    //   21: bipush #6
    //   23: invokeinterface a : (I)V
    //   28: iconst_0
    //   29: istore_2
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: iload_3
    //   34: if_icmpge -> 84
    //   37: aload_0
    //   38: invokeinterface d : ()I
    //   43: istore #4
    //   45: aload_0
    //   46: iconst_4
    //   47: invokeinterface a : (I)V
    //   52: aload_0
    //   53: invokeinterface c : ()J
    //   58: lstore #5
    //   60: aload_0
    //   61: iconst_4
    //   62: invokeinterface a : (I)V
    //   67: ldc 1835365473
    //   69: iload #4
    //   71: if_icmpne -> 77
    //   74: goto -> 89
    //   77: iload_1
    //   78: iconst_1
    //   79: iadd
    //   80: istore_1
    //   81: goto -> 32
    //   84: ldc2_w -1
    //   87: lstore #5
    //   89: lload #5
    //   91: ldc2_w -1
    //   94: lcmp
    //   95: ifeq -> 200
    //   98: aload_0
    //   99: lload #5
    //   101: aload_0
    //   102: invokeinterface e : ()J
    //   107: lsub
    //   108: l2i
    //   109: invokeinterface a : (I)V
    //   114: aload_0
    //   115: bipush #12
    //   117: invokeinterface a : (I)V
    //   122: aload_0
    //   123: invokeinterface c : ()J
    //   128: lstore #7
    //   130: iload_2
    //   131: istore_1
    //   132: iload_1
    //   133: i2l
    //   134: lload #7
    //   136: lcmp
    //   137: ifge -> 200
    //   140: aload_0
    //   141: invokeinterface d : ()I
    //   146: istore_2
    //   147: aload_0
    //   148: invokeinterface c : ()J
    //   153: lstore #9
    //   155: aload_0
    //   156: invokeinterface c : ()J
    //   161: lstore #11
    //   163: ldc 1164798569
    //   165: iload_2
    //   166: if_icmpeq -> 185
    //   169: ldc 1701669481
    //   171: iload_2
    //   172: if_icmpne -> 178
    //   175: goto -> 185
    //   178: iload_1
    //   179: iconst_1
    //   180: iadd
    //   181: istore_1
    //   182: goto -> 132
    //   185: new androidx/emoji2/text/k$b
    //   188: dup
    //   189: lload #9
    //   191: lload #5
    //   193: ladd
    //   194: lload #11
    //   196: invokespecial <init> : (JJ)V
    //   199: areturn
    //   200: new java/io/IOException
    //   203: dup
    //   204: ldc 'Cannot read metadata.'
    //   206: invokespecial <init> : (Ljava/lang/String;)V
    //   209: athrow
    //   210: new java/io/IOException
    //   213: dup
    //   214: ldc 'Cannot read metadata.'
    //   216: invokespecial <init> : (Ljava/lang/String;)V
    //   219: athrow
  }
  
  static s0.b b(ByteBuffer paramByteBuffer) throws IOException {
    paramByteBuffer = paramByteBuffer.duplicate();
    paramByteBuffer.position((int)a(new a(paramByteBuffer)).a());
    return s0.b.h(paramByteBuffer);
  }
  
  static long c(int paramInt) {
    return paramInt & 0xFFFFFFFFL;
  }
  
  static int d(short paramShort) {
    return paramShort & 0xFFFF;
  }
  
  private static class a implements c {
    private final ByteBuffer a;
    
    a(ByteBuffer param1ByteBuffer) {
      this.a = param1ByteBuffer;
      param1ByteBuffer.order(ByteOrder.BIG_ENDIAN);
    }
    
    public void a(int param1Int) throws IOException {
      ByteBuffer byteBuffer = this.a;
      byteBuffer.position(byteBuffer.position() + param1Int);
    }
    
    public int b() throws IOException {
      return k.d(this.a.getShort());
    }
    
    public long c() throws IOException {
      return k.c(this.a.getInt());
    }
    
    public int d() throws IOException {
      return this.a.getInt();
    }
    
    public long e() {
      return this.a.position();
    }
  }
  
  private static class b {
    private final long a;
    
    private final long b;
    
    b(long param1Long1, long param1Long2) {
      this.a = param1Long1;
      this.b = param1Long2;
    }
    
    long a() {
      return this.a;
    }
  }
  
  private static interface c {
    void a(int param1Int) throws IOException;
    
    int b() throws IOException;
    
    long c() throws IOException;
    
    int d() throws IOException;
    
    long e();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\emoji2\text\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */