package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.TextPaint;

public final class n extends h {
  private static Paint k;
  
  public n(f paramf) {
    super(paramf);
  }
  
  private static Paint c() {
    if (k == null) {
      TextPaint textPaint = new TextPaint();
      k = (Paint)textPaint;
      textPaint.setColor(d.b().c());
      k.setStyle(Paint.Style.FILL);
    } 
    return k;
  }
  
  public void draw(Canvas paramCanvas, @SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2, float paramFloat, int paramInt3, int paramInt4, int paramInt5, Paint paramPaint) {
    if (d.b().i())
      paramCanvas.drawRect(paramFloat, paramInt3, paramFloat + b(), paramInt5, c()); 
    a().a(paramCanvas, paramFloat, paramInt4, paramPaint);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\emoji2\text\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */