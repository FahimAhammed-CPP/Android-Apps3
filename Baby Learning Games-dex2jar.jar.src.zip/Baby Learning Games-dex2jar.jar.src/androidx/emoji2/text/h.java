package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.graphics.Paint;
import android.text.style.ReplacementSpan;

public abstract class h extends ReplacementSpan {
  private final Paint.FontMetricsInt f = new Paint.FontMetricsInt();
  
  private final f g;
  
  private short h = -1;
  
  private short i = -1;
  
  private float j = 1.0F;
  
  h(f paramf) {
    k0.h.g(paramf, "metadata cannot be null");
    this.g = paramf;
  }
  
  public final f a() {
    return this.g;
  }
  
  final int b() {
    return this.h;
  }
  
  public int getSize(Paint paramPaint, @SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2, Paint.FontMetricsInt paramFontMetricsInt) {
    paramPaint.getFontMetricsInt(this.f);
    Paint.FontMetricsInt fontMetricsInt = this.f;
    this.j = Math.abs(fontMetricsInt.descent - fontMetricsInt.ascent) * 1.0F / this.g.e();
    this.i = (short)(int)(this.g.e() * this.j);
    short s = (short)(int)(this.g.i() * this.j);
    this.h = s;
    if (paramFontMetricsInt != null) {
      fontMetricsInt = this.f;
      paramFontMetricsInt.ascent = fontMetricsInt.ascent;
      paramFontMetricsInt.descent = fontMetricsInt.descent;
      paramFontMetricsInt.top = fontMetricsInt.top;
      paramFontMetricsInt.bottom = fontMetricsInt.bottom;
    } 
    return s;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\emoji2\text\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */