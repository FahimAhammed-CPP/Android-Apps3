package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Handler;
import c0.l;
import i0.d;
import i0.f;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import k0.h;

public class i extends d.c {
  private static final a j = new a();
  
  public i(Context paramContext, d paramd) {
    super(new b(paramContext, paramd, j));
  }
  
  public i c(Executor paramExecutor) {
    ((b)a()).f(paramExecutor);
    return this;
  }
  
  public static class a {
    public Typeface a(Context param1Context, f.b param1b) throws PackageManager.NameNotFoundException {
      return f.a(param1Context, null, new f.b[] { param1b });
    }
    
    public f.a b(Context param1Context, d param1d) throws PackageManager.NameNotFoundException {
      return f.b(param1Context, null, param1d);
    }
    
    public void c(Context param1Context, ContentObserver param1ContentObserver) {
      param1Context.getContentResolver().unregisterContentObserver(param1ContentObserver);
    }
  }
  
  private static class b implements d.g {
    private final Context a;
    
    private final d b;
    
    private final i.a c;
    
    private final Object d = new Object();
    
    private Handler e;
    
    private Executor f;
    
    private ThreadPoolExecutor g;
    
    d.h h;
    
    private ContentObserver i;
    
    private Runnable j;
    
    b(Context param1Context, d param1d, i.a param1a) {
      h.g(param1Context, "Context cannot be null");
      h.g(param1d, "FontRequest cannot be null");
      this.a = param1Context.getApplicationContext();
      this.b = param1d;
      this.c = param1a;
    }
    
    private void b() {
      synchronized (this.d) {
        this.h = null;
        ContentObserver contentObserver = this.i;
        if (contentObserver != null) {
          this.c.c(this.a, contentObserver);
          this.i = null;
        } 
        Handler handler = this.e;
        if (handler != null)
          handler.removeCallbacks(this.j); 
        this.e = null;
        ThreadPoolExecutor threadPoolExecutor = this.g;
        if (threadPoolExecutor != null)
          threadPoolExecutor.shutdown(); 
        this.f = null;
        this.g = null;
        return;
      } 
    }
    
    private f.b e() {
      try {
        f.b[] arrayOfB;
        f.a a1 = this.c.b(this.a, this.b);
        if (a1.c() == 0) {
          arrayOfB = a1.b();
          if (arrayOfB != null && arrayOfB.length != 0)
            return arrayOfB[0]; 
          throw new RuntimeException("fetchFonts failed (empty result)");
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("fetchFonts failed (");
        stringBuilder.append(arrayOfB.c());
        stringBuilder.append(")");
        throw new RuntimeException(stringBuilder.toString());
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        throw new RuntimeException("provider not found", nameNotFoundException);
      } 
    }
    
    public void a(d.h param1h) {
      h.g(param1h, "LoaderCallback cannot be null");
      synchronized (this.d) {
        this.h = param1h;
        d();
        return;
      } 
    }
    
    void c() {
      synchronized (this.d) {
        if (this.h == null)
          return; 
        try {
          null = e();
          int i = null.b();
          if (i == 2)
            synchronized (this.d) {
            
            }  
          if (i == 0)
            try {
              h0.i.a("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
              Typeface typeface = this.c.a(this.a, (f.b)null);
              null = l.f(this.a, null, null.d());
              if (null != null && typeface != null) {
                null = l.b(typeface, (ByteBuffer)null);
                h0.i.b();
                synchronized (this.d) {
                  d.h h1 = this.h;
                  return;
                } 
              } 
              throw new RuntimeException("Unable to open file.");
            } finally {
              h0.i.b();
            }  
          null = new StringBuilder();
          null.append("fetchFonts result is not OK. (");
          null.append(i);
          null.append(")");
          throw new RuntimeException(null.toString());
        } finally {
          null = null;
        } 
      } 
    }
    
    void d() {
      synchronized (this.d) {
        if (this.h == null)
          return; 
        if (this.f == null) {
          ThreadPoolExecutor threadPoolExecutor = b.b("emojiCompat");
          this.g = threadPoolExecutor;
          this.f = threadPoolExecutor;
        } 
        this.f.execute(new j(this));
        return;
      } 
    }
    
    public void f(Executor param1Executor) {
      synchronized (this.d) {
        this.f = param1Executor;
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\emoji2\text\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */