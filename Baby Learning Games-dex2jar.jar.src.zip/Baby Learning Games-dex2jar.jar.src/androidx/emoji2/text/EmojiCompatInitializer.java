package androidx.emoji2.text;

import android.content.Context;
import androidx.lifecycle.ProcessLifecycleInitializer;
import androidx.lifecycle.d;
import androidx.lifecycle.j;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import h0.i;
import j1.a;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

public class EmojiCompatInitializer implements a<Boolean> {
  public List<Class<? extends a<?>>> a() {
    return (List)Collections.singletonList(ProcessLifecycleInitializer.class);
  }
  
  public Boolean c(Context paramContext) {
    d.g(new a(paramContext));
    d(paramContext);
    return Boolean.TRUE;
  }
  
  void d(Context paramContext) {
    j j = ((q)androidx.startup.a.c(paramContext).d(ProcessLifecycleInitializer.class)).a();
    j.a((p)new d(this, j) {
          public void a(q param1q) {
            this.g.e();
            this.f.c((p)this);
          }
        });
  }
  
  void e() {
    b.d().postDelayed(new c(), 500L);
  }
  
  static class a extends d.c {
    protected a(Context param1Context) {
      super(new EmojiCompatInitializer.b(param1Context));
      b(1);
    }
  }
  
  static class b implements d.g {
    private final Context a;
    
    b(Context param1Context) {
      this.a = param1Context.getApplicationContext();
    }
    
    public void a(d.h param1h) {
      ThreadPoolExecutor threadPoolExecutor = b.b("EmojiCompatInitializer");
      threadPoolExecutor.execute(new e(this, param1h, threadPoolExecutor));
    }
    
    void c(d.h param1h, ThreadPoolExecutor param1ThreadPoolExecutor) {
      try {
        i i = c.a(this.a);
        if (i != null)
          return; 
        throw new RuntimeException("EmojiCompat font provider not available on this device.");
      } finally {
        Exception exception = null;
        param1h.a(exception);
        param1ThreadPoolExecutor.shutdown();
      } 
    }
    
    class a extends d.h {
      a(EmojiCompatInitializer.b this$0, d.h param2h, ThreadPoolExecutor param2ThreadPoolExecutor) {}
      
      public void a(Throwable param2Throwable) {
        try {
          this.a.a(param2Throwable);
          return;
        } finally {
          this.b.shutdown();
        } 
      }
      
      public void b(l param2l) {
        try {
          this.a.b(param2l);
          return;
        } finally {
          this.b.shutdown();
        } 
      }
    }
  }
  
  class a extends d.h {
    a(EmojiCompatInitializer this$0, d.h param1h, ThreadPoolExecutor param1ThreadPoolExecutor) {}
    
    public void a(Throwable param1Throwable) {
      try {
        this.a.a(param1Throwable);
        return;
      } finally {
        this.b.shutdown();
      } 
    }
    
    public void b(l param1l) {
      try {
        this.a.b(param1l);
        return;
      } finally {
        this.b.shutdown();
      } 
    }
  }
  
  static class c implements Runnable {
    public void run() {
      try {
        i.a("EmojiCompat.EmojiCompatInitializer.run");
        if (d.h())
          d.b().k(); 
        return;
      } finally {
        i.b();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */