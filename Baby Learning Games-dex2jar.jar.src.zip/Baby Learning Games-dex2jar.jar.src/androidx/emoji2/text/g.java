package androidx.emoji2.text;

import android.graphics.Paint;
import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.TextPaint;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.inputmethod.InputConnection;
import java.util.Arrays;

final class g {
  private final d.i a;
  
  private final l b;
  
  private d.d c;
  
  private final boolean d;
  
  private final int[] e;
  
  g(l paraml, d.i parami, d.d paramd, boolean paramBoolean, int[] paramArrayOfint) {
    this.a = parami;
    this.b = paraml;
    this.c = paramd;
    this.d = paramBoolean;
    this.e = paramArrayOfint;
  }
  
  private void a(Spannable paramSpannable, f paramf, int paramInt1, int paramInt2) {
    paramSpannable.setSpan(this.a.a(paramf), paramInt1, paramInt2, 33);
  }
  
  private static boolean b(Editable paramEditable, KeyEvent paramKeyEvent, boolean paramBoolean) {
    if (g(paramKeyEvent))
      return false; 
    int k = Selection.getSelectionStart((CharSequence)paramEditable);
    int j = Selection.getSelectionEnd((CharSequence)paramEditable);
    if (f(k, j))
      return false; 
    h[] arrayOfH = (h[])paramEditable.getSpans(k, j, h.class);
    if (arrayOfH != null && arrayOfH.length > 0) {
      int m = arrayOfH.length;
      for (j = 0; j < m; j++) {
        h h = arrayOfH[j];
        int n = paramEditable.getSpanStart(h);
        int i1 = paramEditable.getSpanEnd(h);
        if ((paramBoolean && n == k) || (!paramBoolean && i1 == k) || (k > n && k < i1)) {
          paramEditable.delete(n, i1);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  static boolean c(InputConnection paramInputConnection, Editable paramEditable, int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramEditable != null) {
      if (paramInputConnection == null)
        return false; 
      if (paramInt1 >= 0) {
        if (paramInt2 < 0)
          return false; 
        int k = Selection.getSelectionStart((CharSequence)paramEditable);
        int j = Selection.getSelectionEnd((CharSequence)paramEditable);
        if (f(k, j))
          return false; 
        if (paramBoolean) {
          paramInt1 = a.a((CharSequence)paramEditable, k, Math.max(paramInt1, 0));
          j = a.b((CharSequence)paramEditable, j, Math.max(paramInt2, 0));
          if (paramInt1 != -1) {
            paramInt2 = j;
            if (j == -1)
              return false; 
          } else {
            return false;
          } 
        } else {
          paramInt1 = Math.max(k - paramInt1, 0);
          paramInt2 = Math.min(j + paramInt2, paramEditable.length());
        } 
        h[] arrayOfH = (h[])paramEditable.getSpans(paramInt1, paramInt2, h.class);
        if (arrayOfH != null && arrayOfH.length > 0) {
          int m = arrayOfH.length;
          k = 0;
          j = paramInt1;
          for (paramInt1 = k; paramInt1 < m; paramInt1++) {
            h h = arrayOfH[paramInt1];
            int n = paramEditable.getSpanStart(h);
            k = paramEditable.getSpanEnd(h);
            j = Math.min(n, j);
            paramInt2 = Math.max(k, paramInt2);
          } 
          paramInt1 = Math.max(j, 0);
          paramInt2 = Math.min(paramInt2, paramEditable.length());
          paramInputConnection.beginBatchEdit();
          paramEditable.delete(paramInt1, paramInt2);
          paramInputConnection.endBatchEdit();
          return true;
        } 
      } 
    } 
    return false;
  }
  
  static boolean d(Editable paramEditable, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    if (paramInt != 67) {
      if (paramInt != 112) {
        bool = false;
      } else {
        bool = b(paramEditable, paramKeyEvent, true);
      } 
    } else {
      bool = b(paramEditable, paramKeyEvent, false);
    } 
    if (bool) {
      MetaKeyKeyListener.adjustMetaAfterKeypress((Spannable)paramEditable);
      return true;
    } 
    return false;
  }
  
  private boolean e(CharSequence paramCharSequence, int paramInt1, int paramInt2, f paramf) {
    if (paramf.d() == 0)
      paramf.k(this.c.a(paramCharSequence, paramInt1, paramInt2, paramf.h())); 
    return (paramf.d() == 2);
  }
  
  private static boolean f(int paramInt1, int paramInt2) {
    return (paramInt1 == -1 || paramInt2 == -1 || paramInt1 != paramInt2);
  }
  
  private static boolean g(KeyEvent paramKeyEvent) {
    return KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) ^ true;
  }
  
  CharSequence h(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/emoji2/text/m
    //   4: istore #11
    //   6: iload #11
    //   8: ifeq -> 18
    //   11: aload_1
    //   12: checkcast androidx/emoji2/text/m
    //   15: invokevirtual a : ()V
    //   18: aconst_null
    //   19: astore #13
    //   21: iload #11
    //   23: ifne -> 85
    //   26: aload_1
    //   27: instanceof android/text/Spannable
    //   30: ifeq -> 36
    //   33: goto -> 85
    //   36: aload #13
    //   38: astore #12
    //   40: aload_1
    //   41: instanceof android/text/Spanned
    //   44: ifeq -> 91
    //   47: aload #13
    //   49: astore #12
    //   51: aload_1
    //   52: checkcast android/text/Spanned
    //   55: iload_2
    //   56: iconst_1
    //   57: isub
    //   58: iload_3
    //   59: iconst_1
    //   60: iadd
    //   61: ldc androidx/emoji2/text/h
    //   63: invokeinterface nextSpanTransition : (IILjava/lang/Class;)I
    //   68: iload_3
    //   69: if_icmpgt -> 91
    //   72: new android/text/SpannableString
    //   75: dup
    //   76: aload_1
    //   77: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   80: astore #12
    //   82: goto -> 91
    //   85: aload_1
    //   86: checkcast android/text/Spannable
    //   89: astore #12
    //   91: iload_2
    //   92: istore #6
    //   94: iload_3
    //   95: istore #7
    //   97: aload #12
    //   99: ifnull -> 229
    //   102: aload #12
    //   104: iload_2
    //   105: iload_3
    //   106: ldc androidx/emoji2/text/h
    //   108: invokeinterface getSpans : (IILjava/lang/Class;)[Ljava/lang/Object;
    //   113: checkcast [Landroidx/emoji2/text/h;
    //   116: astore #13
    //   118: iload_2
    //   119: istore #6
    //   121: iload_3
    //   122: istore #7
    //   124: aload #13
    //   126: ifnull -> 229
    //   129: iload_2
    //   130: istore #6
    //   132: iload_3
    //   133: istore #7
    //   135: aload #13
    //   137: arraylength
    //   138: ifle -> 229
    //   141: aload #13
    //   143: arraylength
    //   144: istore #9
    //   146: iconst_0
    //   147: istore #8
    //   149: iload_2
    //   150: istore #6
    //   152: iload_3
    //   153: istore #7
    //   155: iload #8
    //   157: iload #9
    //   159: if_icmpge -> 229
    //   162: aload #13
    //   164: iload #8
    //   166: aaload
    //   167: astore #14
    //   169: aload #12
    //   171: aload #14
    //   173: invokeinterface getSpanStart : (Ljava/lang/Object;)I
    //   178: istore #7
    //   180: aload #12
    //   182: aload #14
    //   184: invokeinterface getSpanEnd : (Ljava/lang/Object;)I
    //   189: istore #6
    //   191: iload #7
    //   193: iload_3
    //   194: if_icmpeq -> 206
    //   197: aload #12
    //   199: aload #14
    //   201: invokeinterface removeSpan : (Ljava/lang/Object;)V
    //   206: iload #7
    //   208: iload_2
    //   209: invokestatic min : (II)I
    //   212: istore_2
    //   213: iload #6
    //   215: iload_3
    //   216: invokestatic max : (II)I
    //   219: istore_3
    //   220: iload #8
    //   222: iconst_1
    //   223: iadd
    //   224: istore #8
    //   226: goto -> 149
    //   229: iload #6
    //   231: iload #7
    //   233: if_icmpeq -> 625
    //   236: iload #6
    //   238: aload_1
    //   239: invokeinterface length : ()I
    //   244: if_icmplt -> 250
    //   247: goto -> 625
    //   250: iload #4
    //   252: istore #8
    //   254: iload #4
    //   256: ldc 2147483647
    //   258: if_icmpeq -> 296
    //   261: iload #4
    //   263: istore #8
    //   265: aload #12
    //   267: ifnull -> 296
    //   270: iload #4
    //   272: aload #12
    //   274: iconst_0
    //   275: aload #12
    //   277: invokeinterface length : ()I
    //   282: ldc androidx/emoji2/text/h
    //   284: invokeinterface getSpans : (IILjava/lang/Class;)[Ljava/lang/Object;
    //   289: checkcast [Landroidx/emoji2/text/h;
    //   292: arraylength
    //   293: isub
    //   294: istore #8
    //   296: new androidx/emoji2/text/g$c
    //   299: dup
    //   300: aload_0
    //   301: getfield b : Landroidx/emoji2/text/l;
    //   304: invokevirtual f : ()Landroidx/emoji2/text/l$a;
    //   307: aload_0
    //   308: getfield d : Z
    //   311: aload_0
    //   312: getfield e : [I
    //   315: invokespecial <init> : (Landroidx/emoji2/text/l$a;Z[I)V
    //   318: astore #14
    //   320: aload_1
    //   321: iload #6
    //   323: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
    //   326: istore #10
    //   328: iconst_0
    //   329: istore #4
    //   331: goto -> 656
    //   334: iload_3
    //   335: iload #7
    //   337: if_icmpge -> 517
    //   340: iload #4
    //   342: iload #8
    //   344: if_icmpge -> 517
    //   347: aload #14
    //   349: iload_2
    //   350: invokevirtual a : (I)I
    //   353: istore #6
    //   355: iload #6
    //   357: iconst_1
    //   358: if_icmpeq -> 486
    //   361: iload #6
    //   363: iconst_2
    //   364: if_icmpeq -> 455
    //   367: iload #6
    //   369: iconst_3
    //   370: if_icmpeq -> 376
    //   373: goto -> 334
    //   376: iload #5
    //   378: ifne -> 403
    //   381: iload_2
    //   382: istore #10
    //   384: iload_3
    //   385: istore #6
    //   387: aload_0
    //   388: aload_1
    //   389: iload #9
    //   391: iload_3
    //   392: aload #14
    //   394: invokevirtual c : ()Landroidx/emoji2/text/f;
    //   397: invokespecial e : (Ljava/lang/CharSequence;IILandroidx/emoji2/text/f;)Z
    //   400: ifne -> 656
    //   403: aload #12
    //   405: astore #13
    //   407: aload #12
    //   409: ifnonnull -> 422
    //   412: new android/text/SpannableString
    //   415: dup
    //   416: aload_1
    //   417: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   420: astore #13
    //   422: aload_0
    //   423: aload #13
    //   425: aload #14
    //   427: invokevirtual c : ()Landroidx/emoji2/text/f;
    //   430: iload #9
    //   432: iload_3
    //   433: invokespecial a : (Landroid/text/Spannable;Landroidx/emoji2/text/f;II)V
    //   436: iload #4
    //   438: iconst_1
    //   439: iadd
    //   440: istore #4
    //   442: aload #13
    //   444: astore #12
    //   446: iload_2
    //   447: istore #10
    //   449: iload_3
    //   450: istore #6
    //   452: goto -> 656
    //   455: iload_3
    //   456: iload_2
    //   457: invokestatic charCount : (I)I
    //   460: iadd
    //   461: istore #6
    //   463: iload #6
    //   465: istore_3
    //   466: iload #6
    //   468: iload #7
    //   470: if_icmpge -> 334
    //   473: aload_1
    //   474: iload #6
    //   476: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
    //   479: istore_2
    //   480: iload #6
    //   482: istore_3
    //   483: goto -> 334
    //   486: iload #9
    //   488: aload_1
    //   489: iload #9
    //   491: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
    //   494: invokestatic charCount : (I)I
    //   497: iadd
    //   498: istore #9
    //   500: iload #9
    //   502: iload #7
    //   504: if_icmpge -> 669
    //   507: aload_1
    //   508: iload #9
    //   510: invokestatic codePointAt : (Ljava/lang/CharSequence;I)I
    //   513: istore_2
    //   514: goto -> 669
    //   517: aload #12
    //   519: astore #13
    //   521: aload #14
    //   523: invokevirtual e : ()Z
    //   526: ifeq -> 598
    //   529: aload #12
    //   531: astore #13
    //   533: iload #4
    //   535: iload #8
    //   537: if_icmpge -> 598
    //   540: iload #5
    //   542: ifne -> 565
    //   545: aload #12
    //   547: astore #13
    //   549: aload_0
    //   550: aload_1
    //   551: iload #9
    //   553: iload_3
    //   554: aload #14
    //   556: invokevirtual b : ()Landroidx/emoji2/text/f;
    //   559: invokespecial e : (Ljava/lang/CharSequence;IILandroidx/emoji2/text/f;)Z
    //   562: ifne -> 598
    //   565: aload #12
    //   567: astore #13
    //   569: aload #12
    //   571: ifnonnull -> 584
    //   574: new android/text/SpannableString
    //   577: dup
    //   578: aload_1
    //   579: invokespecial <init> : (Ljava/lang/CharSequence;)V
    //   582: astore #13
    //   584: aload_0
    //   585: aload #13
    //   587: aload #14
    //   589: invokevirtual b : ()Landroidx/emoji2/text/f;
    //   592: iload #9
    //   594: iload_3
    //   595: invokespecial a : (Landroid/text/Spannable;Landroidx/emoji2/text/f;II)V
    //   598: aload #13
    //   600: astore #12
    //   602: aload #13
    //   604: ifnonnull -> 610
    //   607: aload_1
    //   608: astore #12
    //   610: iload #11
    //   612: ifeq -> 622
    //   615: aload_1
    //   616: checkcast androidx/emoji2/text/m
    //   619: invokevirtual d : ()V
    //   622: aload #12
    //   624: areturn
    //   625: iload #11
    //   627: ifeq -> 637
    //   630: aload_1
    //   631: checkcast androidx/emoji2/text/m
    //   634: invokevirtual d : ()V
    //   637: aload_1
    //   638: areturn
    //   639: astore #12
    //   641: iload #11
    //   643: ifeq -> 653
    //   646: aload_1
    //   647: checkcast androidx/emoji2/text/m
    //   650: invokevirtual d : ()V
    //   653: aload #12
    //   655: athrow
    //   656: iload #6
    //   658: istore #9
    //   660: iload #10
    //   662: istore_2
    //   663: iload #6
    //   665: istore_3
    //   666: goto -> 334
    //   669: iload #9
    //   671: istore_3
    //   672: goto -> 334
    // Exception table:
    //   from	to	target	type
    //   26	33	639	finally
    //   40	47	639	finally
    //   51	82	639	finally
    //   85	91	639	finally
    //   102	118	639	finally
    //   135	146	639	finally
    //   169	191	639	finally
    //   197	206	639	finally
    //   206	220	639	finally
    //   236	247	639	finally
    //   270	296	639	finally
    //   296	328	639	finally
    //   347	355	639	finally
    //   387	403	639	finally
    //   412	422	639	finally
    //   422	436	639	finally
    //   455	463	639	finally
    //   473	480	639	finally
    //   486	500	639	finally
    //   507	514	639	finally
    //   521	529	639	finally
    //   549	565	639	finally
    //   574	584	639	finally
    //   584	598	639	finally
  }
  
  private static final class a {
    static int a(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      int i = param1CharSequence.length();
      if (param1Int1 >= 0) {
        if (i < param1Int1)
          return -1; 
        if (param1Int2 < 0)
          return -1; 
        label31: while (true) {
          for (i = 0;; i = 1) {
            if (param1Int2 == 0)
              return param1Int1; 
            if (--param1Int1 < 0)
              return (i != 0) ? -1 : 0; 
            char c = param1CharSequence.charAt(param1Int1);
            if (i != 0) {
              if (!Character.isHighSurrogate(c))
                return -1; 
              param1Int2--;
              continue label31;
            } 
            if (!Character.isSurrogate(c)) {
              param1Int2--;
              continue;
            } 
            if (Character.isHighSurrogate(c))
              return -1; 
          } 
          break;
        } 
      } 
      return -1;
    }
    
    static int b(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      int i = param1CharSequence.length();
      if (param1Int1 >= 0) {
        if (i < param1Int1)
          return -1; 
        if (param1Int2 < 0)
          return -1; 
        label30: while (true) {
          boolean bool;
          for (bool = false;; bool = true) {
            if (param1Int2 == 0)
              return param1Int1; 
            if (param1Int1 >= i)
              return bool ? -1 : i; 
            char c = param1CharSequence.charAt(param1Int1);
            if (bool) {
              if (!Character.isLowSurrogate(c))
                return -1; 
              param1Int2--;
              param1Int1++;
              continue label30;
            } 
            if (!Character.isSurrogate(c)) {
              param1Int2--;
              param1Int1++;
              continue;
            } 
            if (Character.isLowSurrogate(c))
              return -1; 
            param1Int1++;
          } 
          break;
        } 
      } 
      return -1;
    }
  }
  
  public static class b implements d.d {
    private static final ThreadLocal<StringBuilder> b = new ThreadLocal<StringBuilder>();
    
    private final TextPaint a;
    
    b() {
      TextPaint textPaint = new TextPaint();
      this.a = textPaint;
      textPaint.setTextSize(10.0F);
    }
    
    private static StringBuilder b() {
      ThreadLocal<StringBuilder> threadLocal = b;
      if (threadLocal.get() == null)
        threadLocal.set(new StringBuilder()); 
      return threadLocal.get();
    }
    
    public boolean a(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      StringBuilder stringBuilder = b();
      stringBuilder.setLength(0);
      while (param1Int1 < param1Int2) {
        stringBuilder.append(param1CharSequence.charAt(param1Int1));
        param1Int1++;
      } 
      return c0.c.a((Paint)this.a, stringBuilder.toString());
    }
  }
  
  static final class c {
    private int a = 1;
    
    private final l.a b;
    
    private l.a c;
    
    private l.a d;
    
    private int e;
    
    private int f;
    
    private final boolean g;
    
    private final int[] h;
    
    c(l.a param1a, boolean param1Boolean, int[] param1ArrayOfint) {
      this.b = param1a;
      this.c = param1a;
      this.g = param1Boolean;
      this.h = param1ArrayOfint;
    }
    
    private static boolean d(int param1Int) {
      return (param1Int == 65039);
    }
    
    private static boolean f(int param1Int) {
      return (param1Int == 65038);
    }
    
    private int g() {
      this.a = 1;
      this.c = this.b;
      this.f = 0;
      return 1;
    }
    
    private boolean h() {
      if (this.c.b().j())
        return true; 
      if (d(this.e))
        return true; 
      if (this.g) {
        if (this.h == null)
          return true; 
        int i = this.c.b().b(0);
        if (Arrays.binarySearch(this.h, i) < 0)
          return true; 
      } 
      return false;
    }
    
    int a(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield c : Landroidx/emoji2/text/l$a;
      //   4: iload_1
      //   5: invokevirtual a : (I)Landroidx/emoji2/text/l$a;
      //   8: astore #4
      //   10: aload_0
      //   11: getfield a : I
      //   14: istore_3
      //   15: iconst_3
      //   16: istore_2
      //   17: iload_3
      //   18: iconst_2
      //   19: if_icmpeq -> 56
      //   22: aload #4
      //   24: ifnonnull -> 35
      //   27: aload_0
      //   28: invokespecial g : ()I
      //   31: istore_2
      //   32: goto -> 175
      //   35: aload_0
      //   36: iconst_2
      //   37: putfield a : I
      //   40: aload_0
      //   41: aload #4
      //   43: putfield c : Landroidx/emoji2/text/l$a;
      //   46: aload_0
      //   47: iconst_1
      //   48: putfield f : I
      //   51: iconst_2
      //   52: istore_2
      //   53: goto -> 175
      //   56: aload #4
      //   58: ifnull -> 80
      //   61: aload_0
      //   62: aload #4
      //   64: putfield c : Landroidx/emoji2/text/l$a;
      //   67: aload_0
      //   68: aload_0
      //   69: getfield f : I
      //   72: iconst_1
      //   73: iadd
      //   74: putfield f : I
      //   77: goto -> 51
      //   80: iload_1
      //   81: invokestatic f : (I)Z
      //   84: ifeq -> 95
      //   87: aload_0
      //   88: invokespecial g : ()I
      //   91: istore_2
      //   92: goto -> 175
      //   95: iload_1
      //   96: invokestatic d : (I)Z
      //   99: ifeq -> 105
      //   102: goto -> 51
      //   105: aload_0
      //   106: getfield c : Landroidx/emoji2/text/l$a;
      //   109: invokevirtual b : ()Landroidx/emoji2/text/f;
      //   112: ifnull -> 170
      //   115: aload_0
      //   116: getfield f : I
      //   119: iconst_1
      //   120: if_icmpne -> 154
      //   123: aload_0
      //   124: invokespecial h : ()Z
      //   127: ifeq -> 146
      //   130: aload_0
      //   131: aload_0
      //   132: getfield c : Landroidx/emoji2/text/l$a;
      //   135: putfield d : Landroidx/emoji2/text/l$a;
      //   138: aload_0
      //   139: invokespecial g : ()I
      //   142: pop
      //   143: goto -> 175
      //   146: aload_0
      //   147: invokespecial g : ()I
      //   150: istore_2
      //   151: goto -> 175
      //   154: aload_0
      //   155: aload_0
      //   156: getfield c : Landroidx/emoji2/text/l$a;
      //   159: putfield d : Landroidx/emoji2/text/l$a;
      //   162: aload_0
      //   163: invokespecial g : ()I
      //   166: pop
      //   167: goto -> 175
      //   170: aload_0
      //   171: invokespecial g : ()I
      //   174: istore_2
      //   175: aload_0
      //   176: iload_1
      //   177: putfield e : I
      //   180: iload_2
      //   181: ireturn
    }
    
    f b() {
      return this.c.b();
    }
    
    f c() {
      return this.d.b();
    }
    
    boolean e() {
      int i = this.a;
      null = true;
      if (i == 2 && this.c.b() != null)
        if (this.f <= 1) {
          if (h())
            return true; 
        } else {
          return null;
        }  
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\emoji2\text\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */