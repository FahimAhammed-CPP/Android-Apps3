package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.text.Editable;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import k0.h;

public final class m extends SpannableStringBuilder {
  private final Class<?> f;
  
  private final List<a> g = new ArrayList<a>();
  
  m(Class<?> paramClass, CharSequence paramCharSequence) {
    super(paramCharSequence);
    h.g(paramClass, "watcherClass cannot be null");
    this.f = paramClass;
  }
  
  m(Class<?> paramClass, CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    super(paramCharSequence, paramInt1, paramInt2);
    h.g(paramClass, "watcherClass cannot be null");
    this.f = paramClass;
  }
  
  private void b() {
    for (int i = 0; i < this.g.size(); i++)
      ((a)this.g.get(i)).a(); 
  }
  
  public static m c(Class<?> paramClass, CharSequence paramCharSequence) {
    return new m(paramClass, paramCharSequence);
  }
  
  private void e() {
    for (int i = 0; i < this.g.size(); i++)
      ((a)this.g.get(i)).onTextChanged((CharSequence)this, 0, length(), length()); 
  }
  
  private a f(Object paramObject) {
    for (int i = 0; i < this.g.size(); i++) {
      a a = this.g.get(i);
      if (a.f == paramObject)
        return a; 
    } 
    return null;
  }
  
  private boolean g(Class<?> paramClass) {
    return (this.f == paramClass);
  }
  
  private boolean h(Object paramObject) {
    return (paramObject != null && g(paramObject.getClass()));
  }
  
  private void i() {
    for (int i = 0; i < this.g.size(); i++)
      ((a)this.g.get(i)).c(); 
  }
  
  public void a() {
    b();
  }
  
  public SpannableStringBuilder append(char paramChar) {
    super.append(paramChar);
    return this;
  }
  
  public SpannableStringBuilder append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence) {
    super.append(paramCharSequence);
    return this;
  }
  
  public SpannableStringBuilder append(@SuppressLint({"UnknownNullness"}) CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    super.append(paramCharSequence, paramInt1, paramInt2);
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder append(CharSequence paramCharSequence, Object paramObject, int paramInt) {
    super.append(paramCharSequence, paramObject, paramInt);
    return this;
  }
  
  public void d() {
    i();
    e();
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder delete(int paramInt1, int paramInt2) {
    super.delete(paramInt1, paramInt2);
    return this;
  }
  
  public int getSpanEnd(Object paramObject) {
    Object object = paramObject;
    if (h(paramObject)) {
      a a = f(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanEnd(object);
  }
  
  public int getSpanFlags(Object paramObject) {
    Object object = paramObject;
    if (h(paramObject)) {
      a a = f(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanFlags(object);
  }
  
  public int getSpanStart(Object paramObject) {
    Object object = paramObject;
    if (h(paramObject)) {
      a a = f(paramObject);
      object = paramObject;
      if (a != null)
        object = a; 
    } 
    return super.getSpanStart(object);
  }
  
  @SuppressLint({"UnknownNullness"})
  public <T> T[] getSpans(int paramInt1, int paramInt2, Class<T> paramClass) {
    Object[] arrayOfObject;
    if (g(paramClass)) {
      a[] arrayOfA = (a[])super.getSpans(paramInt1, paramInt2, a.class);
      arrayOfObject = (Object[])Array.newInstance(paramClass, arrayOfA.length);
      for (paramInt1 = 0; paramInt1 < arrayOfA.length; paramInt1++)
        arrayOfObject[paramInt1] = (arrayOfA[paramInt1]).f; 
      return (T[])arrayOfObject;
    } 
    return (T[])super.getSpans(paramInt1, paramInt2, (Class)arrayOfObject);
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder insert(int paramInt, CharSequence paramCharSequence) {
    super.insert(paramInt, paramCharSequence);
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder insert(int paramInt1, CharSequence paramCharSequence, int paramInt2, int paramInt3) {
    super.insert(paramInt1, paramCharSequence, paramInt2, paramInt3);
    return this;
  }
  
  public int nextSpanTransition(int paramInt1, int paramInt2, Class<?> paramClass) {
    if (paramClass != null) {
      Class<?> clazz1 = paramClass;
      if (g(paramClass)) {
        clazz1 = a.class;
        return super.nextSpanTransition(paramInt1, paramInt2, clazz1);
      } 
      return super.nextSpanTransition(paramInt1, paramInt2, clazz1);
    } 
    Class<a> clazz = a.class;
    return super.nextSpanTransition(paramInt1, paramInt2, clazz);
  }
  
  public void removeSpan(Object paramObject) {
    Object object;
    if (h(paramObject)) {
      a a = f(paramObject);
      object = a;
      if (a != null) {
        paramObject = a;
        object = a;
      } 
    } else {
      object = null;
    } 
    super.removeSpan(paramObject);
    if (object != null)
      this.g.remove(object); 
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder replace(int paramInt1, int paramInt2, CharSequence paramCharSequence) {
    b();
    super.replace(paramInt1, paramInt2, paramCharSequence);
    i();
    return this;
  }
  
  @SuppressLint({"UnknownNullness"})
  public SpannableStringBuilder replace(int paramInt1, int paramInt2, CharSequence paramCharSequence, int paramInt3, int paramInt4) {
    b();
    super.replace(paramInt1, paramInt2, paramCharSequence, paramInt3, paramInt4);
    i();
    return this;
  }
  
  public void setSpan(Object paramObject, int paramInt1, int paramInt2, int paramInt3) {
    Object object = paramObject;
    if (h(paramObject)) {
      object = new a(paramObject);
      this.g.add(object);
    } 
    super.setSpan(object, paramInt1, paramInt2, paramInt3);
  }
  
  @SuppressLint({"UnknownNullness"})
  public CharSequence subSequence(int paramInt1, int paramInt2) {
    return (CharSequence)new m(this.f, (CharSequence)this, paramInt1, paramInt2);
  }
  
  private static class a implements TextWatcher, SpanWatcher {
    final Object f;
    
    private final AtomicInteger g = new AtomicInteger(0);
    
    a(Object param1Object) {
      this.f = param1Object;
    }
    
    private boolean b(Object param1Object) {
      return param1Object instanceof h;
    }
    
    final void a() {
      this.g.incrementAndGet();
    }
    
    public void afterTextChanged(Editable param1Editable) {
      ((TextWatcher)this.f).afterTextChanged(param1Editable);
    }
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      ((TextWatcher)this.f).beforeTextChanged(param1CharSequence, param1Int1, param1Int2, param1Int3);
    }
    
    final void c() {
      this.g.decrementAndGet();
    }
    
    public void onSpanAdded(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2) {
      if (this.g.get() > 0 && b(param1Object))
        return; 
      ((SpanWatcher)this.f).onSpanAdded(param1Spannable, param1Object, param1Int1, param1Int2);
    }
    
    public void onSpanChanged(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.g.get() > 0 && b(param1Object))
        return; 
      ((SpanWatcher)this.f).onSpanChanged(param1Spannable, param1Object, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void onSpanRemoved(Spannable param1Spannable, Object param1Object, int param1Int1, int param1Int2) {
      if (this.g.get() > 0 && b(param1Object))
        return; 
      ((SpanWatcher)this.f).onSpanRemoved(param1Spannable, param1Object, param1Int1, param1Int2);
    }
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      ((TextWatcher)this.f).onTextChanged(param1CharSequence, param1Int1, param1Int2, param1Int3);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\emoji2\text\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */