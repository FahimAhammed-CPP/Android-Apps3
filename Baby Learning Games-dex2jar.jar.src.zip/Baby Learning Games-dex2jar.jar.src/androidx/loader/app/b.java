package androidx.loader.app;

import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.e0;
import androidx.lifecycle.f0;
import androidx.lifecycle.h0;
import androidx.lifecycle.q;
import androidx.lifecycle.w;
import androidx.lifecycle.x;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import s.h;

class b extends a {
  static boolean c = false;
  
  private final q a;
  
  private final b b;
  
  b(q paramq, h0 paramh0) {
    this.a = paramq;
    this.b = b.g(paramh0);
  }
  
  @Deprecated
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    this.b.f(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public void c() {
    this.b.h();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("LoaderManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    k0.b.a(this.a, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public static class a<D> extends w<D> {
    private final int l;
    
    private final Bundle m;
    
    private q n;
    
    protected void i() {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Starting: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      throw null;
    }
    
    protected void j() {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Stopping: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      throw null;
    }
    
    public void l(x<? super D> param1x) {
      super.l(param1x);
      this.n = null;
    }
    
    public void m(D param1D) {
      super.m(param1D);
    }
    
    y0.a<D> n(boolean param1Boolean) {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Destroying: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      throw null;
    }
    
    public void o(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mId=");
      param1PrintWriter.print(this.l);
      param1PrintWriter.print(" mArgs=");
      param1PrintWriter.println(this.m);
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mLoader=");
      param1PrintWriter.println((Object)null);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append("  ");
      throw null;
    }
    
    void p() {}
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(64);
      stringBuilder.append("LoaderInfo{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" #");
      stringBuilder.append(this.l);
      stringBuilder.append(" : ");
      k0.b.a(null, stringBuilder);
      stringBuilder.append("}}");
      return stringBuilder.toString();
    }
  }
  
  static class b extends e0 {
    private static final f0.b e = new a();
    
    private h<b.a> c = new h();
    
    private boolean d = false;
    
    static b g(h0 param1h0) {
      return (b)(new f0(param1h0, e)).a(b.class);
    }
    
    protected void d() {
      super.d();
      int j = this.c.m();
      for (int i = 0; i < j; i++)
        ((b.a)this.c.n(i)).n(true); 
      this.c.b();
    }
    
    public void f(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      if (this.c.m() > 0) {
        param1PrintWriter.print(param1String);
        param1PrintWriter.println("Loaders:");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1String);
        stringBuilder.append("    ");
        String str = stringBuilder.toString();
        int i;
        for (i = 0; i < this.c.m(); i++) {
          b.a a = (b.a)this.c.n(i);
          param1PrintWriter.print(param1String);
          param1PrintWriter.print("  #");
          param1PrintWriter.print(this.c.i(i));
          param1PrintWriter.print(": ");
          param1PrintWriter.println(a.toString());
          a.o(str, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
        } 
      } 
    }
    
    void h() {
      int j = this.c.m();
      for (int i = 0; i < j; i++)
        ((b.a)this.c.n(i)).p(); 
    }
    
    static final class a implements f0.b {
      public <T extends e0> T a(Class<T> param2Class) {
        return (T)new b.b();
      }
    }
  }
  
  static final class a implements f0.b {
    public <T extends e0> T a(Class<T> param1Class) {
      return (T)new b.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\loader\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */