package androidx.loader.app;

import androidx.lifecycle.i0;
import androidx.lifecycle.q;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class a {
  public static <T extends q & i0> a b(T paramT) {
    return new b((q)paramT, ((i0)paramT).k());
  }
  
  @Deprecated
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract void c();
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\loader\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */