package androidx.room;

import androidx.lifecycle.LiveData;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.concurrent.Callable;

class d {
  final Set<LiveData> a = Collections.newSetFromMap(new IdentityHashMap<LiveData, Boolean>());
  
  private final h b;
  
  d(h paramh) {
    this.b = paramh;
  }
  
  <T> LiveData<T> a(String[] paramArrayOfString, boolean paramBoolean, Callable<T> paramCallable) {
    return new j<T>(this.b, this, paramBoolean, paramCallable, paramArrayOfString);
  }
  
  void b(LiveData paramLiveData) {
    this.a.add(paramLiveData);
  }
  
  void c(LiveData paramLiveData) {
    this.a.remove(paramLiveData);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\room\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */