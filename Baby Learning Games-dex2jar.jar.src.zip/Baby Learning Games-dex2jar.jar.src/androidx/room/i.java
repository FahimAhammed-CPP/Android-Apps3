package androidx.room;

import android.database.Cursor;
import e1.c;
import h1.c;
import h1.e;

public class i extends c.a {
  private a b;
  
  private final a c;
  
  private final String d;
  
  private final String e;
  
  public i(a parama, a parama1, String paramString1, String paramString2) {
    super(parama1.a);
    this.b = parama;
    this.c = parama1;
    this.d = paramString1;
    this.e = paramString2;
  }
  
  private void h(h1.b paramb) {
    if (k(paramb)) {
      h1.b b1 = null;
      Cursor cursor = paramb.p((e)new h1.a("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"));
      paramb = b1;
      try {
        String str;
        if (cursor.moveToFirst())
          str = cursor.getString(0); 
        cursor.close();
      } finally {
        cursor.close();
      } 
    } else {
      b b1 = this.c.g(paramb);
      if (b1.a) {
        this.c.e(paramb);
        l(paramb);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Pre-packaged database has an invalid schema: ");
      stringBuilder.append(b1.b);
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  private void i(h1.b paramb) {
    paramb.i("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
  }
  
  private static boolean j(h1.b paramb) {
    Cursor cursor = paramb.N("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
    try {
      boolean bool = cursor.moveToFirst();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        int j = cursor.getInt(0);
        bool1 = bool2;
        if (j == 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
    } 
  }
  
  private static boolean k(h1.b paramb) {
    Cursor cursor = paramb.N("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
    try {
      boolean bool = cursor.moveToFirst();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        int j = cursor.getInt(0);
        bool1 = bool2;
        if (j != 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
    } 
  }
  
  private void l(h1.b paramb) {
    i(paramb);
    paramb.i(c.a(this.d));
  }
  
  public void b(h1.b paramb) {
    super.b(paramb);
  }
  
  public void d(h1.b paramb) {
    StringBuilder stringBuilder;
    boolean bool = j(paramb);
    this.c.a(paramb);
    if (!bool) {
      b b1 = this.c.g(paramb);
      if (!b1.a) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Pre-packaged database has an invalid schema: ");
        stringBuilder.append(b1.b);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
    l((h1.b)stringBuilder);
    this.c.c((h1.b)stringBuilder);
  }
  
  public void e(h1.b paramb, int paramInt1, int paramInt2) {
    g(paramb, paramInt1, paramInt2);
  }
  
  public void f(h1.b paramb) {
    super.f(paramb);
    h(paramb);
    this.c.d(paramb);
    this.b = null;
  }
  
  public void g(h1.b paramb, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Landroidx/room/a;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnull -> 146
    //   11: aload #5
    //   13: getfield d : Landroidx/room/h$d;
    //   16: iload_2
    //   17: iload_3
    //   18: invokevirtual c : (II)Ljava/util/List;
    //   21: astore #5
    //   23: aload #5
    //   25: ifnull -> 146
    //   28: aload_0
    //   29: getfield c : Landroidx/room/i$a;
    //   32: aload_1
    //   33: invokevirtual f : (Lh1/b;)V
    //   36: aload #5
    //   38: invokeinterface iterator : ()Ljava/util/Iterator;
    //   43: astore #5
    //   45: aload #5
    //   47: invokeinterface hasNext : ()Z
    //   52: ifeq -> 72
    //   55: aload #5
    //   57: invokeinterface next : ()Ljava/lang/Object;
    //   62: checkcast f1/a
    //   65: aload_1
    //   66: invokevirtual a : (Lh1/b;)V
    //   69: goto -> 45
    //   72: aload_0
    //   73: getfield c : Landroidx/room/i$a;
    //   76: aload_1
    //   77: invokevirtual g : (Lh1/b;)Landroidx/room/i$b;
    //   80: astore #5
    //   82: aload #5
    //   84: getfield a : Z
    //   87: ifeq -> 109
    //   90: aload_0
    //   91: getfield c : Landroidx/room/i$a;
    //   94: aload_1
    //   95: invokevirtual e : (Lh1/b;)V
    //   98: aload_0
    //   99: aload_1
    //   100: invokespecial l : (Lh1/b;)V
    //   103: iconst_1
    //   104: istore #4
    //   106: goto -> 149
    //   109: new java/lang/StringBuilder
    //   112: dup
    //   113: invokespecial <init> : ()V
    //   116: astore_1
    //   117: aload_1
    //   118: ldc 'Migration didn't properly handle: '
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: pop
    //   124: aload_1
    //   125: aload #5
    //   127: getfield b : Ljava/lang/String;
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: pop
    //   134: new java/lang/IllegalStateException
    //   137: dup
    //   138: aload_1
    //   139: invokevirtual toString : ()Ljava/lang/String;
    //   142: invokespecial <init> : (Ljava/lang/String;)V
    //   145: athrow
    //   146: iconst_0
    //   147: istore #4
    //   149: iload #4
    //   151: ifne -> 245
    //   154: aload_0
    //   155: getfield b : Landroidx/room/a;
    //   158: astore #5
    //   160: aload #5
    //   162: ifnull -> 192
    //   165: aload #5
    //   167: iload_2
    //   168: iload_3
    //   169: invokevirtual a : (II)Z
    //   172: ifne -> 192
    //   175: aload_0
    //   176: getfield c : Landroidx/room/i$a;
    //   179: aload_1
    //   180: invokevirtual b : (Lh1/b;)V
    //   183: aload_0
    //   184: getfield c : Landroidx/room/i$a;
    //   187: aload_1
    //   188: invokevirtual a : (Lh1/b;)V
    //   191: return
    //   192: new java/lang/StringBuilder
    //   195: dup
    //   196: invokespecial <init> : ()V
    //   199: astore_1
    //   200: aload_1
    //   201: ldc 'A migration from '
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: pop
    //   207: aload_1
    //   208: iload_2
    //   209: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   212: pop
    //   213: aload_1
    //   214: ldc ' to '
    //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: pop
    //   220: aload_1
    //   221: iload_3
    //   222: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload_1
    //   227: ldc ' was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.'
    //   229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: new java/lang/IllegalStateException
    //   236: dup
    //   237: aload_1
    //   238: invokevirtual toString : ()Ljava/lang/String;
    //   241: invokespecial <init> : (Ljava/lang/String;)V
    //   244: athrow
    //   245: return
  }
  
  public static abstract class a {
    public final int a;
    
    public a(int param1Int) {
      this.a = param1Int;
    }
    
    protected abstract void a(h1.b param1b);
    
    protected abstract void b(h1.b param1b);
    
    protected abstract void c(h1.b param1b);
    
    protected abstract void d(h1.b param1b);
    
    protected abstract void e(h1.b param1b);
    
    protected abstract void f(h1.b param1b);
    
    protected abstract i.b g(h1.b param1b);
  }
  
  public static class b {
    public final boolean a;
    
    public final String b;
    
    public b(boolean param1Boolean, String param1String) {
      this.a = param1Boolean;
      this.b = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\room\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */