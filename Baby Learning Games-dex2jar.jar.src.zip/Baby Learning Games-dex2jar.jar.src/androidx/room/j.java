package androidx.room;

import android.annotation.SuppressLint;
import androidx.lifecycle.LiveData;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

class j<T> extends LiveData<T> {
  final h l;
  
  final boolean m;
  
  final Callable<T> n;
  
  private final d o;
  
  final e.c p;
  
  final AtomicBoolean q = new AtomicBoolean(true);
  
  final AtomicBoolean r = new AtomicBoolean(false);
  
  final AtomicBoolean s = new AtomicBoolean(false);
  
  final Runnable t = new a(this);
  
  final Runnable u = new b(this);
  
  @SuppressLint({"RestrictedApi"})
  j(h paramh, d paramd, boolean paramBoolean, Callable<T> paramCallable, String[] paramArrayOfString) {
    this.l = paramh;
    this.m = paramBoolean;
    this.n = paramCallable;
    this.o = paramd;
    this.p = new c(this, paramArrayOfString);
  }
  
  protected void i() {
    super.i();
    this.o.b(this);
    o().execute(this.t);
  }
  
  protected void j() {
    super.j();
    this.o.c(this);
  }
  
  Executor o() {
    return this.m ? this.l.l() : this.l.k();
  }
  
  class a implements Runnable {
    a(j this$0) {}
    
    public void run() {
      if (this.f.s.compareAndSet(false, true))
        this.f.l.i().b(this.f.p); 
      while (true) {
        if (this.f.r.compareAndSet(false, true)) {
          null = null;
          boolean bool1 = false;
          try {
            while (true) {
              boolean bool2 = this.f.q.compareAndSet(true, false);
              if (bool2) {
                try {
                  null = (Exception)this.f.n.call();
                  bool1 = true;
                } catch (Exception exception) {
                  throw new RuntimeException("Exception while computing database live data.", exception);
                } 
                continue;
              } 
              if (bool1)
                j.n(this.f, exception); 
              this.f.r.set(false);
              if (!bool1 || !this.f.q.get())
                break; 
            } 
          } finally {
            this.f.r.set(false);
          } 
          break;
        } 
        boolean bool = false;
        continue;
      } 
    }
  }
  
  class b implements Runnable {
    b(j this$0) {}
    
    public void run() {
      boolean bool = this.f.f();
      if (this.f.q.compareAndSet(false, true) && bool)
        this.f.o().execute(this.f.t); 
    }
  }
  
  class c extends e.c {
    c(j this$0, String[] param1ArrayOfString) {
      super(param1ArrayOfString);
    }
    
    public void b(Set<String> param1Set) {
      m.a.f().b(this.b.u);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\room\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */