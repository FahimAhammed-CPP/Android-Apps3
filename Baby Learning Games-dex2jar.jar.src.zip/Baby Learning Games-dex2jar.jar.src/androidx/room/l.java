package androidx.room;

import h1.c;
import java.io.File;

class l implements c.c {
  private final String a;
  
  private final File b;
  
  private final c.c c;
  
  l(String paramString, File paramFile, c.c paramc) {
    this.a = paramString;
    this.b = paramFile;
    this.c = paramc;
  }
  
  public c a(c.b paramb) {
    return new k(paramb.a, this.a, this.b, paramb.c.a, this.c.a(paramb));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\room\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */