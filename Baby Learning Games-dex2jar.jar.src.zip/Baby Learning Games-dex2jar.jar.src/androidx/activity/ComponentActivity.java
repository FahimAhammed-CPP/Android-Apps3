package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.d;
import androidx.activity.result.e;
import androidx.core.app.f;
import androidx.lifecycle.a0;
import androidx.lifecycle.c0;
import androidx.lifecycle.f0;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.j;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import androidx.lifecycle.r;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.c;
import java.util.concurrent.atomic.AtomicInteger;

public class ComponentActivity extends f implements i0, i, c, c, e {
  final c.a h = new c.a();
  
  private final r i = new r(this);
  
  final androidx.savedstate.b j = androidx.savedstate.b.a(this);
  
  private h0 k;
  
  private f0.b l;
  
  private final OnBackPressedDispatcher m = new OnBackPressedDispatcher(new a(this));
  
  private int n;
  
  private final AtomicInteger o = new AtomicInteger();
  
  private final d p = new b(this);
  
  public ComponentActivity() {
    if (a() != null) {
      int j = Build.VERSION.SDK_INT;
      a().a((p)new o(this) {
            public void d(q param1q, j.b param1b) {
              if (param1b == j.b.ON_STOP) {
                Window window = this.f.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  window.cancelPendingInputEvents(); 
              } 
            }
          });
      a().a((p)new o(this) {
            public void d(q param1q, j.b param1b) {
              if (param1b == j.b.ON_DESTROY) {
                this.f.h.b();
                if (!this.f.isChangingConfigurations())
                  this.f.k().a(); 
              } 
            }
          });
      a().a((p)new o(this) {
            public void d(q param1q, j.b param1b) {
              this.f.o();
              this.f.a().c((p)this);
            }
          });
      if (j <= 23)
        a().a((p)new ImmLeaksCleaner((Activity)this)); 
      c().d("android:support:activity-result", new c(this));
      n(new d(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  private void r() {
    j0.a(getWindow().getDecorView(), this);
    k0.a(getWindow().getDecorView(), this);
    androidx.savedstate.d.a(getWindow().getDecorView(), this);
  }
  
  public j a() {
    return (j)this.i;
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    r();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public final OnBackPressedDispatcher b() {
    return this.m;
  }
  
  public final SavedStateRegistry c() {
    return this.j.b();
  }
  
  public f0.b h() {
    if (getApplication() != null) {
      if (this.l == null) {
        Bundle bundle;
        Application application = getApplication();
        if (getIntent() != null) {
          bundle = getIntent().getExtras();
        } else {
          bundle = null;
        } 
        this.l = (f0.b)new c0(application, this, bundle);
      } 
      return this.l;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public final d i() {
    return this.p;
  }
  
  public h0 k() {
    if (getApplication() != null) {
      o();
      return this.k;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public final void n(c.b paramb) {
    this.h.a(paramb);
  }
  
  void o() {
    if (this.k == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      if (e1 != null)
        this.k = e1.b; 
      if (this.k == null)
        this.k = new h0(); 
    } 
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.p.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.m.c();
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.j.c(paramBundle);
    this.h.c((Context)this);
    super.onCreate(paramBundle);
    a0.g((Activity)this);
    int j = this.n;
    if (j != 0)
      setContentView(j); 
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.p.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)))
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = s();
    h0 h02 = this.k;
    h0 h01 = h02;
    if (h02 == null) {
      e e2 = (e)getLastNonConfigurationInstance();
      h01 = h02;
      if (e2 != null)
        h01 = e2.b; 
    } 
    if (h01 == null && object == null)
      return null; 
    e e1 = new e();
    e1.a = object;
    e1.b = h01;
    return e1;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    j j = a();
    if (j instanceof r)
      ((r)j).o(j.c.h); 
    super.onSaveInstanceState(paramBundle);
    this.j.d(paramBundle);
  }
  
  public void reportFullyDrawn() {
    try {
      if (k1.a.d()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("reportFullyDrawn() for ");
        stringBuilder.append(getComponentName());
        k1.a.a(stringBuilder.toString());
      } 
      super.reportFullyDrawn();
      return;
    } finally {
      k1.a.b();
    } 
  }
  
  @Deprecated
  public Object s() {
    return null;
  }
  
  public void setContentView(int paramInt) {
    r();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    r();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    r();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        ComponentActivity.l(this.f);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends d {
    b(ComponentActivity this$0) {}
  }
  
  class c implements SavedStateRegistry.b {
    c(ComponentActivity this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public Bundle a() {
      Bundle bundle = new Bundle();
      ComponentActivity.m(this.a).f(bundle);
      return bundle;
    }
  }
  
  class d implements c.b {
    d(ComponentActivity this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void a(Context param1Context) {
      Bundle bundle = this.a.c().a("android:support:activity-result");
      if (bundle != null)
        ComponentActivity.m(this.a).e(bundle); 
    }
  }
  
  static final class e {
    Object a;
    
    h0 b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */