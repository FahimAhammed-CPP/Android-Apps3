package androidx.activity.result;

import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import d.a;

class ActivityResultRegistry$1 implements o {
  public void d(q paramq, j.b paramb) {
    if (j.b.ON_START.equals(paramb)) {
      this.i.f.put(this.f, new d.b(this.g, this.h));
      if (this.i.g.containsKey(this.f)) {
        paramq = (q)this.i.g.get(this.f);
        this.i.g.remove(this.f);
        this.g.a(paramq);
      } 
      a a1 = (a)this.i.h.getParcelable(this.f);
      if (a1 != null) {
        this.i.h.remove(this.f);
        this.g.a(this.h.a(a1.c(), a1.a()));
        return;
      } 
    } else {
      if (j.b.ON_STOP.equals(paramb)) {
        this.i.f.remove(this.f);
        return;
      } 
      if (j.b.ON_DESTROY.equals(paramb))
        this.i.i(this.f); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */