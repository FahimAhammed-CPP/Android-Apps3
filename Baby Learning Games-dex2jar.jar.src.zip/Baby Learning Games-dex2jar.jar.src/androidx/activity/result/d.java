package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class d {
  private Random a = new Random();
  
  private final Map<Integer, String> b = new HashMap<Integer, String>();
  
  final Map<String, Integer> c = new HashMap<String, Integer>();
  
  private final Map<String, c> d = new HashMap<String, c>();
  
  ArrayList<String> e = new ArrayList<String>();
  
  final transient Map<String, b<?>> f = new HashMap<String, b<?>>();
  
  final Map<String, Object> g = new HashMap<String, Object>();
  
  final Bundle h = new Bundle();
  
  private void a(int paramInt, String paramString) {
    this.b.put(Integer.valueOf(paramInt), paramString);
    this.c.put(paramString, Integer.valueOf(paramInt));
  }
  
  private <O> void c(String paramString, int paramInt, Intent paramIntent, b<O> paramb) {
    if (paramb != null) {
      b<O> b1 = paramb.a;
      if (b1 != null) {
        b1.a((O)paramb.b.a(paramInt, paramIntent));
        return;
      } 
    } 
    this.g.remove(paramString);
    this.h.putParcelable(paramString, new a(paramInt, paramIntent));
  }
  
  private int d() {
    int i = this.a.nextInt(2147418112);
    while (true) {
      i += 65536;
      if (this.b.containsKey(Integer.valueOf(i))) {
        i = this.a.nextInt(2147418112);
        continue;
      } 
      return i;
    } 
  }
  
  private int h(String paramString) {
    Integer integer = this.c.get(paramString);
    if (integer != null)
      return integer.intValue(); 
    int i = d();
    a(i, paramString);
    return i;
  }
  
  public final boolean b(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    this.e.remove(str);
    c(str, paramInt2, paramIntent, this.f.get(str));
    return true;
  }
  
  public final void e(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    ArrayList<Integer> arrayList = paramBundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
    ArrayList<String> arrayList1 = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
    if (arrayList1 != null) {
      if (arrayList == null)
        return; 
      this.e = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
      this.a = (Random)paramBundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
      this.h.putAll(paramBundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
      for (int i = 0; i < arrayList1.size(); i++) {
        String str = arrayList1.get(i);
        if (this.c.containsKey(str)) {
          Integer integer = this.c.remove(str);
          if (!this.h.containsKey(str))
            this.b.remove(integer); 
        } 
        a(((Integer)arrayList.get(i)).intValue(), arrayList1.get(i));
      } 
    } 
  }
  
  public final void f(Bundle paramBundle) {
    paramBundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.c.values()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.c.keySet()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<String>(this.e));
    paramBundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)this.h.clone());
    paramBundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.a);
  }
  
  public final <I, O> c<I> g(String paramString, d.a<I, O> parama, b<O> paramb) {
    int i = h(paramString);
    this.f.put(paramString, new b(paramb, parama));
    if (this.g.containsKey(paramString)) {
      Object object = this.g.get(paramString);
      this.g.remove(paramString);
      paramb.a((O)object);
    } 
    a a1 = (a)this.h.getParcelable(paramString);
    if (a1 != null) {
      this.h.remove(paramString);
      paramb.a((O)parama.a(a1.c(), a1.a()));
    } 
    return new a(this, paramString, i, parama);
  }
  
  final void i(String paramString) {
    if (!this.e.contains(paramString)) {
      Integer integer = this.c.remove(paramString);
      if (integer != null)
        this.b.remove(integer); 
    } 
    this.f.remove(paramString);
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.g.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.g.remove(paramString);
    } 
    if (this.h.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.h.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.h.remove(paramString);
    } 
    c c = this.d.get(paramString);
    if (c != null) {
      c.a();
      this.d.remove(paramString);
    } 
  }
  
  class a extends c<I> {
    a(d this$0, String param1String, int param1Int, d.a param1a) {}
    
    public void a() {
      this.d.i(this.a);
    }
  }
  
  private static class b<O> {
    final b<O> a;
    
    final d.a<?, O> b;
    
    b(b<O> param1b, d.a<?, O> param1a) {
      this.a = param1b;
      this.b = param1a;
    }
  }
  
  private static class c {
    final j a;
    
    private final ArrayList<o> b;
    
    void a() {
      for (o o : this.b)
        this.a.c((p)o); 
      this.b.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\activity\result\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */