package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import java.lang.reflect.Field;

final class ImmLeaksCleaner implements o {
  private static int g;
  
  private static Field h;
  
  private static Field i;
  
  private static Field j;
  
  private Activity f;
  
  ImmLeaksCleaner(Activity paramActivity) {
    this.f = paramActivity;
  }
  
  private static void e() {
    try {
      g = 2;
      Field field = InputMethodManager.class.getDeclaredField("mServedView");
      i = field;
      field.setAccessible(true);
      field = InputMethodManager.class.getDeclaredField("mNextServedView");
      j = field;
      field.setAccessible(true);
      field = InputMethodManager.class.getDeclaredField("mH");
      h = field;
      field.setAccessible(true);
      g = 1;
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      return;
    } 
  }
  
  public void d(q paramq, j.b paramb) {
    if (paramb != j.b.ON_DESTROY)
      return; 
    if (g == 0)
      e(); 
    if (g == 1) {
      InputMethodManager inputMethodManager = (InputMethodManager)this.f.getSystemService("input_method");
      try {
        Object object = h.get(inputMethodManager);
        if (object == null)
          return; 
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          View view = (View)i.get(inputMethodManager);
          if (view == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          if (view.isAttachedToWindow()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          try {
            j.set(inputMethodManager, null);
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            inputMethodManager.isActive();
            return;
          } catch (IllegalAccessException illegalAccessException) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
        } catch (IllegalAccessException illegalAccessException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } catch (ClassCastException classCastException) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        throw inputMethodManager;
      } catch (IllegalAccessException illegalAccessException) {
        return;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\activity\ImmLeaksCleaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */