package androidx.activity;

import android.annotation.SuppressLint;
import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  final ArrayDeque<b> b = new ArrayDeque<b>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  @SuppressLint({"LambdaLast"})
  public void a(q paramq, b paramb) {
    j j = paramq.a();
    if (j.b() == j.c.f)
      return; 
    paramb.a(new LifecycleOnBackPressedCancellable(this, j, paramb));
  }
  
  a b(b paramb) {
    this.b.add(paramb);
    a a = new a(this, paramb);
    paramb.a(a);
    return a;
  }
  
  public void c() {
    Iterator<b> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      b b = iterator.next();
      if (b.c()) {
        b.b();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  private class LifecycleOnBackPressedCancellable implements o, a {
    private final j f;
    
    private final b g;
    
    private a h;
    
    LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, j param1j, b param1b) {
      this.f = param1j;
      this.g = param1b;
      param1j.a((p)this);
    }
    
    public void cancel() {
      this.f.c((p)this);
      this.g.e(this);
      a a1 = this.h;
      if (a1 != null) {
        a1.cancel();
        this.h = null;
      } 
    }
    
    public void d(q param1q, j.b param1b) {
      if (param1b == j.b.ON_START) {
        this.h = this.i.b(this.g);
        return;
      } 
      if (param1b == j.b.ON_STOP) {
        a a1 = this.h;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1b == j.b.ON_DESTROY) {
        cancel();
      } 
    }
  }
  
  private class a implements a {
    private final b f;
    
    a(OnBackPressedDispatcher this$0, b param1b) {
      this.f = param1b;
    }
    
    public void cancel() {
      this.g.b.remove(this.f);
      this.f.e(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */