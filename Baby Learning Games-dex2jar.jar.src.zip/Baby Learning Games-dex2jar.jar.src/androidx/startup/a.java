package androidx.startup;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import j1.b;
import j1.c;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class a {
  private static volatile a d;
  
  private static final Object e = new Object();
  
  final Map<Class<?>, Object> a;
  
  final Set<Class<? extends j1.a<?>>> b;
  
  final Context c;
  
  a(Context paramContext) {
    this.c = paramContext.getApplicationContext();
    this.b = new HashSet<Class<? extends j1.a<?>>>();
    this.a = new HashMap<Class<?>, Object>();
  }
  
  public static a c(Context paramContext) {
    if (d == null)
      synchronized (e) {
        if (d == null)
          d = new a(paramContext); 
      }  
    return d;
  }
  
  void a() {
    Exception exception;
    try {
      k1.a.a("Startup");
      ComponentName componentName = new ComponentName(this.c.getPackageName(), InitializationProvider.class.getName());
      Bundle bundle = (this.c.getPackageManager().getProviderInfo(componentName, 128)).metaData;
      String str = this.c.getString(b.a);
      if (bundle != null) {
        HashSet<Class<?>> hashSet = new HashSet();
        for (String str1 : bundle.keySet()) {
          if (str.equals(bundle.getString(str1, null))) {
            Class<?> clazz = Class.forName(str1);
            if (j1.a.class.isAssignableFrom(clazz)) {
              this.b.add(clazz);
              b((Class)clazz, hashSet);
            } 
          } 
        } 
      } 
      k1.a.b();
      return;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
    
    } catch (ClassNotFoundException null) {
    
    } finally {}
    throw new c(exception);
  }
  
  <T> T b(Class<? extends j1.a<?>> paramClass, Set<Class<?>> paramSet) {
    // Byte code:
    //   0: getstatic androidx/startup/a.e : Ljava/lang/Object;
    //   3: astore #5
    //   5: aload #5
    //   7: monitorenter
    //   8: invokestatic d : ()Z
    //   11: istore_3
    //   12: iload_3
    //   13: ifeq -> 23
    //   16: aload_1
    //   17: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   20: invokestatic a : (Ljava/lang/String;)V
    //   23: aload_2
    //   24: aload_1
    //   25: invokeinterface contains : (Ljava/lang/Object;)Z
    //   30: ifne -> 218
    //   33: aload_0
    //   34: getfield a : Ljava/util/Map;
    //   37: aload_1
    //   38: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   43: ifne -> 199
    //   46: aload_2
    //   47: aload_1
    //   48: invokeinterface add : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload_1
    //   55: iconst_0
    //   56: anewarray java/lang/Class
    //   59: invokevirtual getDeclaredConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   62: iconst_0
    //   63: anewarray java/lang/Object
    //   66: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   69: checkcast j1/a
    //   72: astore #4
    //   74: aload #4
    //   76: invokeinterface a : ()Ljava/util/List;
    //   81: astore #6
    //   83: aload #6
    //   85: invokeinterface isEmpty : ()Z
    //   90: ifne -> 149
    //   93: aload #6
    //   95: invokeinterface iterator : ()Ljava/util/Iterator;
    //   100: astore #6
    //   102: aload #6
    //   104: invokeinterface hasNext : ()Z
    //   109: ifeq -> 149
    //   112: aload #6
    //   114: invokeinterface next : ()Ljava/lang/Object;
    //   119: checkcast java/lang/Class
    //   122: astore #7
    //   124: aload_0
    //   125: getfield a : Ljava/util/Map;
    //   128: aload #7
    //   130: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   135: ifne -> 102
    //   138: aload_0
    //   139: aload #7
    //   141: aload_2
    //   142: invokevirtual b : (Ljava/lang/Class;Ljava/util/Set;)Ljava/lang/Object;
    //   145: pop
    //   146: goto -> 102
    //   149: aload #4
    //   151: aload_0
    //   152: getfield c : Landroid/content/Context;
    //   155: invokeinterface b : (Landroid/content/Context;)Ljava/lang/Object;
    //   160: astore #4
    //   162: aload_2
    //   163: aload_1
    //   164: invokeinterface remove : (Ljava/lang/Object;)Z
    //   169: pop
    //   170: aload_0
    //   171: getfield a : Ljava/util/Map;
    //   174: aload_1
    //   175: aload #4
    //   177: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   182: pop
    //   183: aload #4
    //   185: astore_1
    //   186: goto -> 210
    //   189: astore_1
    //   190: new j1/c
    //   193: dup
    //   194: aload_1
    //   195: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   198: athrow
    //   199: aload_0
    //   200: getfield a : Ljava/util/Map;
    //   203: aload_1
    //   204: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   209: astore_1
    //   210: invokestatic b : ()V
    //   213: aload #5
    //   215: monitorexit
    //   216: aload_1
    //   217: areturn
    //   218: new java/lang/IllegalStateException
    //   221: dup
    //   222: ldc 'Cannot initialize %s. Cycle detected.'
    //   224: iconst_1
    //   225: anewarray java/lang/Object
    //   228: dup
    //   229: iconst_0
    //   230: aload_1
    //   231: invokevirtual getName : ()Ljava/lang/String;
    //   234: aastore
    //   235: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   238: invokespecial <init> : (Ljava/lang/String;)V
    //   241: athrow
    //   242: astore_1
    //   243: invokestatic b : ()V
    //   246: aload_1
    //   247: athrow
    //   248: astore_1
    //   249: aload #5
    //   251: monitorexit
    //   252: aload_1
    //   253: athrow
    // Exception table:
    //   from	to	target	type
    //   8	12	248	finally
    //   16	23	242	finally
    //   23	54	242	finally
    //   54	102	189	finally
    //   102	146	189	finally
    //   149	183	189	finally
    //   190	199	242	finally
    //   199	210	242	finally
    //   210	216	248	finally
    //   218	242	242	finally
    //   243	248	248	finally
    //   249	252	248	finally
  }
  
  public <T> T d(Class<? extends j1.a<T>> paramClass) {
    return b(paramClass, new HashSet<Class<?>>());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\startup\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */