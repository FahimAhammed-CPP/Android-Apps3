package androidx.viewpager2.adapter;

import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.q;

class FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3 implements o {
  public void d(q paramq, j.b paramb) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$FragmentMaxLifecycleEnforcer$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */