package androidx.viewpager2.adapter;

import android.os.Handler;
import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import androidx.lifecycle.q;

class FragmentStateAdapter$5 implements o {
  public void d(q paramq, j.b paramb) {
    if (paramb == j.b.ON_DESTROY) {
      this.f.removeCallbacks(this.g);
      paramq.a().c((p)this);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\viewpager2\adapter\FragmentStateAdapter$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */