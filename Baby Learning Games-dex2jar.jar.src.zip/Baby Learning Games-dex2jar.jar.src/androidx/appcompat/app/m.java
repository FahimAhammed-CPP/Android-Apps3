package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.e0;
import androidx.appcompat.widget.p0;
import androidx.core.view.b0;
import androidx.core.view.c0;
import androidx.core.view.d0;
import androidx.core.view.e0;
import androidx.core.view.w;
import e.f;
import e.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import k.g;
import k.h;

public class m extends a implements ActionBarOverlayLayout.d {
  private static final Interpolator E = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator F = (Interpolator)new DecelerateInterpolator();
  
  boolean A;
  
  final c0 B = (c0)new a(this);
  
  final c0 C = (c0)new b(this);
  
  final e0 D = new c(this);
  
  Context a;
  
  private Context b;
  
  private Activity c;
  
  ActionBarOverlayLayout d;
  
  ActionBarContainer e;
  
  e0 f;
  
  ActionBarContextView g;
  
  View h;
  
  p0 i;
  
  private ArrayList<Object> j = new ArrayList();
  
  private int k = -1;
  
  private boolean l;
  
  d m;
  
  k.b n;
  
  k.b.a o;
  
  private boolean p;
  
  private ArrayList<a.b> q = new ArrayList<a.b>();
  
  private boolean r;
  
  private int s = 0;
  
  boolean t = true;
  
  boolean u;
  
  boolean v;
  
  private boolean w;
  
  private boolean x = true;
  
  h y;
  
  private boolean z;
  
  public m(Activity paramActivity, boolean paramBoolean) {
    this.c = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    E(view);
    if (!paramBoolean)
      this.h = view.findViewById(16908290); 
  }
  
  public m(Dialog paramDialog) {
    E(paramDialog.getWindow().getDecorView());
  }
  
  private e0 B(View paramView) {
    String str;
    if (paramView instanceof e0)
      return (e0)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void D() {
    if (this.w) {
      this.w = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      N(false);
    } 
  }
  
  private void E(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.p);
    this.d = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.f = B(paramView.findViewById(f.a));
    this.g = (ActionBarContextView)paramView.findViewById(f.f);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.c);
    this.e = actionBarContainer;
    e0 e01 = this.f;
    if (e01 != null && this.g != null && actionBarContainer != null) {
      boolean bool;
      this.a = e01.getContext();
      if ((this.f.p() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.l = true; 
      k.a a1 = k.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      K(bool);
      I(a1.g());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.a, e.a.c, 0);
      if (typedArray.getBoolean(j.k, false))
        J(true); 
      int i = typedArray.getDimensionPixelSize(j.i, 0);
      if (i != 0)
        H(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void I(boolean paramBoolean) {
    this.r = paramBoolean;
    if (!paramBoolean) {
      this.f.k(null);
      this.e.setTabContainer(this.i);
    } else {
      this.e.setTabContainer(null);
      this.f.k(this.i);
    } 
    int i = C();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    p0 p01 = this.i;
    if (p01 != null) {
      ActionBarOverlayLayout actionBarOverlayLayout1;
      if (i != 0) {
        p01.setVisibility(0);
        actionBarOverlayLayout1 = this.d;
        if (actionBarOverlayLayout1 != null)
          w.l0((View)actionBarOverlayLayout1); 
      } else {
        actionBarOverlayLayout1.setVisibility(8);
      } 
    } 
    e0 e01 = this.f;
    if (!this.r && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    e01.y(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (!this.r && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  private boolean L() {
    return w.S((View)this.e);
  }
  
  private void M() {
    if (!this.w) {
      this.w = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      N(false);
    } 
  }
  
  private void N(boolean paramBoolean) {
    if (x(this.u, this.v, this.w)) {
      if (!this.x) {
        this.x = true;
        A(paramBoolean);
        return;
      } 
    } else if (this.x) {
      this.x = false;
      z(paramBoolean);
    } 
  }
  
  static boolean x(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  public void A(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    this.e.setVisibility(0);
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setTranslationY(0.0F);
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.e.setTranslationY(f1);
      h1 = new h();
      b0 b0 = w.e((View)this.e).k(0.0F);
      b0.i(this.D);
      h1.c(b0);
      if (this.t) {
        View view = this.h;
        if (view != null) {
          view.setTranslationY(f1);
          h1.c(w.e(this.h).k(0.0F));
        } 
      } 
      h1.f(F);
      h1.e(250L);
      h1.g(this.C);
      this.y = h1;
      h1.h();
    } else {
      this.e.setAlpha(1.0F);
      this.e.setTranslationY(0.0F);
      if (this.t) {
        View view = this.h;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.C.b(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (actionBarOverlayLayout != null)
      w.l0((View)actionBarOverlayLayout); 
  }
  
  public int C() {
    return this.f.t();
  }
  
  public void F(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    G(bool, 4);
  }
  
  public void G(int paramInt1, int paramInt2) {
    int i = this.f.p();
    if ((paramInt2 & 0x4) != 0)
      this.l = true; 
    this.f.o(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public void H(float paramFloat) {
    w.w0((View)this.e, paramFloat);
  }
  
  public void J(boolean paramBoolean) {
    if (!paramBoolean || this.d.w()) {
      this.A = paramBoolean;
      this.d.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void K(boolean paramBoolean) {
    this.f.m(paramBoolean);
  }
  
  public void a() {
    if (this.v) {
      this.v = false;
      N(true);
    } 
  }
  
  public void b() {
    h h1 = this.y;
    if (h1 != null) {
      h1.a();
      this.y = null;
    } 
  }
  
  public void c() {}
  
  public void d(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public void e() {
    if (!this.v) {
      this.v = true;
      N(true);
    } 
  }
  
  public boolean g() {
    e0 e01 = this.f;
    if (e01 != null && e01.n()) {
      this.f.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void h(boolean paramBoolean) {
    if (paramBoolean == this.p)
      return; 
    this.p = paramBoolean;
    int j = this.q.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.q.get(i)).a(paramBoolean); 
  }
  
  public int i() {
    return this.f.p();
  }
  
  public Context j() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(e.a.g, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void l(Configuration paramConfiguration) {
    I(k.a.b(this.a).g());
  }
  
  public boolean n(int paramInt, KeyEvent paramKeyEvent) {
    d d1 = this.m;
    if (d1 == null)
      return false; 
    Menu menu = d1.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    this.s = paramInt;
  }
  
  public void q(boolean paramBoolean) {
    if (!this.l)
      F(paramBoolean); 
  }
  
  public void r(int paramInt) {
    this.f.s(paramInt);
  }
  
  public void s(Drawable paramDrawable) {
    this.f.x(paramDrawable);
  }
  
  public void t(boolean paramBoolean) {
    this.z = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.y;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void u(CharSequence paramCharSequence) {
    this.f.setWindowTitle(paramCharSequence);
  }
  
  public k.b v(k.b.a parama) {
    d d2 = this.m;
    if (d2 != null)
      d2.c(); 
    this.d.setHideOnContentScrollEnabled(false);
    this.g.k();
    d d1 = new d(this, this.g.getContext(), parama);
    if (d1.t()) {
      this.m = d1;
      d1.k();
      this.g.h(d1);
      w(true);
      return d1;
    } 
    return null;
  }
  
  public void w(boolean paramBoolean) {
    if (paramBoolean) {
      M();
    } else {
      D();
    } 
    if (L()) {
      b0 b01;
      b0 b02;
      if (paramBoolean) {
        b02 = this.f.u(4, 100L);
        b01 = this.g.f(0, 200L);
      } else {
        b01 = this.f.u(0, 200L);
        b02 = this.g.f(8, 100L);
      } 
      h h1 = new h();
      h1.d(b02, b01);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.f.j(4);
      this.g.setVisibility(0);
      return;
    } 
    this.f.j(0);
    this.g.setVisibility(8);
  }
  
  void y() {
    k.b.a a1 = this.o;
    if (a1 != null) {
      a1.d(this.n);
      this.n = null;
      this.o = null;
    } 
  }
  
  public void z(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setAlpha(1.0F);
      this.e.setTransitioning(true);
      h1 = new h();
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      b0 b0 = w.e((View)this.e).k(f1);
      b0.i(this.D);
      h1.c(b0);
      if (this.t) {
        View view = this.h;
        if (view != null)
          h1.c(w.e(view).k(f1)); 
      } 
      h1.f(E);
      h1.e(250L);
      h1.g(this.B);
      this.y = h1;
      h1.h();
      return;
    } 
    this.B.b(null);
  }
  
  class a extends d0 {
    a(m this$0) {}
    
    public void b(View param1View) {
      m m1 = this.a;
      if (m1.t) {
        View view = m1.h;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.e.setTranslationY(0.0F);
        } 
      } 
      this.a.e.setVisibility(8);
      this.a.e.setTransitioning(false);
      m1 = this.a;
      m1.y = null;
      m1.y();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.d;
      if (actionBarOverlayLayout != null)
        w.l0((View)actionBarOverlayLayout); 
    }
  }
  
  class b extends d0 {
    b(m this$0) {}
    
    public void b(View param1View) {
      m m1 = this.a;
      m1.y = null;
      m1.e.requestLayout();
    }
  }
  
  class c implements e0 {
    c(m this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.e.getParent()).invalidate();
    }
  }
  
  public class d extends k.b implements e.a {
    private final Context h;
    
    private final e i;
    
    private k.b.a j;
    
    private WeakReference<View> k;
    
    public d(m this$0, Context param1Context, k.b.a param1a) {
      this.h = param1Context;
      this.j = param1a;
      e e1 = (new e(param1Context)).W(1);
      this.i = e1;
      e1.V(this);
    }
    
    public boolean a(e param1e, MenuItem param1MenuItem) {
      k.b.a a1 = this.j;
      return (a1 != null) ? a1.a(this, param1MenuItem) : false;
    }
    
    public void b(e param1e) {
      if (this.j == null)
        return; 
      k();
      this.l.g.l();
    }
    
    public void c() {
      m m1 = this.l;
      if (m1.m != this)
        return; 
      if (!m.x(m1.u, m1.v, false)) {
        m1 = this.l;
        m1.n = this;
        m1.o = this.j;
      } else {
        this.j.d(this);
      } 
      this.j = null;
      this.l.w(false);
      this.l.g.g();
      m1 = this.l;
      m1.d.setHideOnContentScrollEnabled(m1.A);
      this.l.m = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.k;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.i;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.h);
    }
    
    public CharSequence g() {
      return this.l.g.getSubtitle();
    }
    
    public CharSequence i() {
      return this.l.g.getTitle();
    }
    
    public void k() {
      if (this.l.m != this)
        return; 
      this.i.h0();
      try {
        this.j.c(this, (Menu)this.i);
        return;
      } finally {
        this.i.g0();
      } 
    }
    
    public boolean l() {
      return this.l.g.j();
    }
    
    public void m(View param1View) {
      this.l.g.setCustomView(param1View);
      this.k = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.l.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.l.g.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.l.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.l.g.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.l.g.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.i.h0();
      try {
        return this.j.b(this, (Menu)this.i);
      } finally {
        this.i.g0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\app\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */