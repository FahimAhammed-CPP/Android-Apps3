package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.c1;
import androidx.appcompat.widget.d0;
import androidx.appcompat.widget.d1;
import androidx.appcompat.widget.w0;
import androidx.core.view.b0;
import androidx.core.view.c0;
import androidx.core.view.d0;
import androidx.core.view.g0;
import androidx.core.view.w;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

class f extends e implements e.a, LayoutInflater.Factory2 {
  private static final s.g<String, Integer> g0 = new s.g();
  
  private static final boolean h0 = false;
  
  private static final int[] i0 = new int[] { 16842836 };
  
  private static final boolean j0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  private static final boolean k0 = true;
  
  ViewGroup A;
  
  private TextView B;
  
  private View C;
  
  private boolean D;
  
  private boolean E;
  
  boolean F;
  
  boolean G;
  
  boolean H;
  
  boolean I;
  
  boolean J;
  
  private boolean K;
  
  private t[] L;
  
  private t M;
  
  private boolean N;
  
  private boolean O;
  
  private boolean P;
  
  boolean Q;
  
  private Configuration R;
  
  private int S = -100;
  
  private int T;
  
  private boolean U;
  
  private boolean V;
  
  private p W;
  
  private p X;
  
  boolean Y;
  
  int Z;
  
  private final Runnable a0 = new a(this);
  
  private boolean b0;
  
  private Rect c0;
  
  private Rect d0;
  
  private g e0;
  
  private h f0;
  
  final Object i;
  
  final Context j;
  
  Window k;
  
  private n l;
  
  final f.a m;
  
  a n;
  
  MenuInflater o;
  
  private CharSequence p;
  
  private d0 q;
  
  private h r;
  
  private u s;
  
  k.b t;
  
  ActionBarContextView u;
  
  PopupWindow v;
  
  Runnable w;
  
  b0 x = null;
  
  private boolean y = true;
  
  private boolean z;
  
  f(Activity paramActivity, f.a parama) {
    this((Context)paramActivity, null, parama, paramActivity);
  }
  
  f(Dialog paramDialog, f.a parama) {
    this(paramDialog.getContext(), paramDialog.getWindow(), parama, paramDialog);
  }
  
  private f(Context paramContext, Window paramWindow, f.a parama, Object paramObject) {
    this.j = paramContext;
    this.m = parama;
    this.i = paramObject;
    if (this.S == -100 && paramObject instanceof Dialog) {
      d d = K0();
      if (d != null)
        this.S = d.C().l(); 
    } 
    if (this.S == -100) {
      s.g<String, Integer> g1 = g0;
      Integer integer = (Integer)g1.get(paramObject.getClass().getName());
      if (integer != null) {
        this.S = integer.intValue();
        g1.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      K(paramWindow); 
    androidx.appcompat.widget.j.h();
  }
  
  private boolean B0(t paramt, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokespecial C0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/e;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield q : Landroidx/appcompat/widget/d0;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual Q : (Landroidx/appcompat/app/f$t;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  private boolean C0(t paramt, KeyEvent paramKeyEvent) {
    d0 d01;
    if (this.Q)
      return false; 
    if (paramt.m)
      return true; 
    t t1 = this.M;
    if (t1 != null && t1 != paramt)
      Q(t1, false); 
    Window.Callback callback = h0();
    if (callback != null)
      paramt.i = callback.onCreatePanelView(paramt.a); 
    int i = paramt.a;
    if (i == 0 || i == 108) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      d0 d02 = this.q;
      if (d02 != null)
        d02.c(); 
    } 
    if (paramt.i == null && (i == 0 || !(A0() instanceof j))) {
      d0 d02;
      boolean bool;
      e e1 = paramt.j;
      if (e1 == null || paramt.r) {
        if (e1 == null && (!l0(paramt) || paramt.j == null))
          return false; 
        if (i != 0 && this.q != null) {
          if (this.r == null)
            this.r = new h(this); 
          this.q.a((Menu)paramt.j, this.r);
        } 
        paramt.j.h0();
        if (!callback.onCreatePanelMenu(paramt.a, (Menu)paramt.j)) {
          paramt.c(null);
          if (i != 0) {
            d01 = this.q;
            if (d01 != null)
              d01.a(null, this.r); 
          } 
          return false;
        } 
        ((t)d01).r = false;
      } 
      ((t)d01).j.h0();
      Bundle bundle = ((t)d01).s;
      if (bundle != null) {
        ((t)d01).j.R(bundle);
        ((t)d01).s = null;
      } 
      if (!callback.onPreparePanel(0, ((t)d01).i, (Menu)((t)d01).j)) {
        if (i != 0) {
          d02 = this.q;
          if (d02 != null)
            d02.a(null, this.r); 
        } 
        ((t)d01).j.g0();
        return false;
      } 
      if (d02 != null) {
        i = d02.getDeviceId();
      } else {
        i = -1;
      } 
      if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((t)d01).p = bool;
      ((t)d01).j.setQwertyMode(bool);
      ((t)d01).j.g0();
    } 
    ((t)d01).m = true;
    ((t)d01).n = false;
    this.M = (t)d01;
    return true;
  }
  
  private void D0(boolean paramBoolean) {
    d0 d01 = this.q;
    if (d01 != null && d01.g() && (!ViewConfiguration.get(this.j).hasPermanentMenuKey() || this.q.d())) {
      Window.Callback callback = h0();
      if (!this.q.b() || !paramBoolean) {
        if (callback != null && !this.Q) {
          if (this.Y && (this.Z & 0x1) != 0) {
            this.k.getDecorView().removeCallbacks(this.a0);
            this.a0.run();
          } 
          t t2 = f0(0, true);
          e e1 = t2.j;
          if (e1 != null && !t2.r && callback.onPreparePanel(0, t2.i, (Menu)e1)) {
            callback.onMenuOpened(108, (Menu)t2.j);
            this.q.f();
          } 
        } 
        return;
      } 
      this.q.e();
      if (!this.Q) {
        callback.onPanelClosed(108, (Menu)(f0(0, true)).j);
        return;
      } 
      return;
    } 
    t t1 = f0(0, true);
    t1.q = true;
    Q(t1, false);
    z0(t1, null);
  }
  
  private int E0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int i = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      i = 109;
    } 
    return i;
  }
  
  private boolean G0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.k.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (w.R((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private boolean I(boolean paramBoolean) {
    if (this.Q)
      return false; 
    int i = L();
    paramBoolean = L0(p0(this.j, i), paramBoolean);
    if (i == 0) {
      e0(this.j).e();
    } else {
      p p2 = this.W;
      if (p2 != null)
        p2.a(); 
    } 
    if (i == 3) {
      d0(this.j).e();
      return paramBoolean;
    } 
    p p1 = this.X;
    if (p1 != null)
      p1.a(); 
    return paramBoolean;
  }
  
  private void J() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.A.findViewById(16908290);
    View view = this.k.getDecorView();
    contentFrameLayout.a(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.j.obtainStyledAttributes(e.j.y0);
    typedArray.getValue(e.j.K0, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(e.j.L0, contentFrameLayout.getMinWidthMinor());
    int i = e.j.I0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMajor()); 
    i = e.j.J0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMinor()); 
    i = e.j.G0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMajor()); 
    i = e.j.H0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private void J0() {
    if (!this.z)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private void K(Window paramWindow) {
    if (this.k == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof n)) {
        n n1 = new n(this, callback);
        this.l = n1;
        paramWindow.setCallback((Window.Callback)n1);
        w0 w0 = w0.u(this.j, null, i0);
        Drawable drawable = w0.h(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        w0.w();
        this.k = paramWindow;
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private d K0() {
    Context context = this.j;
    while (context != null) {
      if (context instanceof d)
        return (d)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  private int L() {
    int i = this.S;
    return (i != -100) ? i : e.j();
  }
  
  private boolean L0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield j : Landroid/content/Context;
    //   5: iload_1
    //   6: aconst_null
    //   7: invokespecial R : (Landroid/content/Context;ILandroid/content/res/Configuration;)Landroid/content/res/Configuration;
    //   10: astore #9
    //   12: aload_0
    //   13: invokespecial n0 : ()Z
    //   16: istore #6
    //   18: aload_0
    //   19: getfield R : Landroid/content/res/Configuration;
    //   22: astore #8
    //   24: aload #8
    //   26: astore #7
    //   28: aload #8
    //   30: ifnonnull -> 45
    //   33: aload_0
    //   34: getfield j : Landroid/content/Context;
    //   37: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   40: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   43: astore #7
    //   45: aload #7
    //   47: getfield uiMode : I
    //   50: bipush #48
    //   52: iand
    //   53: istore_3
    //   54: aload #9
    //   56: getfield uiMode : I
    //   59: bipush #48
    //   61: iand
    //   62: istore #4
    //   64: iconst_1
    //   65: istore #5
    //   67: iload_3
    //   68: iload #4
    //   70: if_icmpeq -> 142
    //   73: iload_2
    //   74: ifeq -> 142
    //   77: iload #6
    //   79: ifne -> 142
    //   82: aload_0
    //   83: getfield O : Z
    //   86: ifeq -> 142
    //   89: getstatic androidx/appcompat/app/f.j0 : Z
    //   92: ifne -> 102
    //   95: aload_0
    //   96: getfield P : Z
    //   99: ifeq -> 142
    //   102: aload_0
    //   103: getfield i : Ljava/lang/Object;
    //   106: astore #7
    //   108: aload #7
    //   110: instanceof android/app/Activity
    //   113: ifeq -> 142
    //   116: aload #7
    //   118: checkcast android/app/Activity
    //   121: invokevirtual isChild : ()Z
    //   124: ifne -> 142
    //   127: aload_0
    //   128: getfield i : Ljava/lang/Object;
    //   131: checkcast android/app/Activity
    //   134: invokestatic h : (Landroid/app/Activity;)V
    //   137: iconst_1
    //   138: istore_2
    //   139: goto -> 144
    //   142: iconst_0
    //   143: istore_2
    //   144: iload_2
    //   145: ifne -> 169
    //   148: iload_3
    //   149: iload #4
    //   151: if_icmpeq -> 169
    //   154: aload_0
    //   155: iload #4
    //   157: iload #6
    //   159: aconst_null
    //   160: invokespecial M0 : (IZLandroid/content/res/Configuration;)V
    //   163: iload #5
    //   165: istore_2
    //   166: goto -> 169
    //   169: iload_2
    //   170: ifeq -> 196
    //   173: aload_0
    //   174: getfield i : Ljava/lang/Object;
    //   177: astore #7
    //   179: aload #7
    //   181: instanceof androidx/appcompat/app/d
    //   184: ifeq -> 196
    //   187: aload #7
    //   189: checkcast androidx/appcompat/app/d
    //   192: iload_1
    //   193: invokevirtual G : (I)V
    //   196: iload_2
    //   197: ireturn
  }
  
  private void M0(int paramInt, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.j.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    resources.updateConfiguration(configuration, null);
    if (Build.VERSION.SDK_INT < 26)
      i.a(resources); 
    paramInt = this.T;
    if (paramInt != 0) {
      this.j.setTheme(paramInt);
      this.j.getTheme().applyStyle(this.T, true);
    } 
    if (paramBoolean) {
      Object object = this.i;
      if (object instanceof Activity) {
        object = object;
        if (object instanceof androidx.lifecycle.q) {
          if (((androidx.lifecycle.q)object).a().b().b(androidx.lifecycle.j.c.h)) {
            object.onConfigurationChanged(configuration);
            return;
          } 
        } else if (this.P && !this.Q) {
          object.onConfigurationChanged(configuration);
        } 
      } 
    } 
  }
  
  private void O() {
    p p1 = this.W;
    if (p1 != null)
      p1.a(); 
    p1 = this.X;
    if (p1 != null)
      p1.a(); 
  }
  
  private void O0(View paramView) {
    int i;
    if ((w.L(paramView) & 0x2000) != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      i = androidx.core.content.a.a(this.j, e.c.b);
    } else {
      i = androidx.core.content.a.a(this.j, e.c.a);
    } 
    paramView.setBackgroundColor(i);
  }
  
  private Configuration R(Context paramContext, int paramInt, Configuration paramConfiguration) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    return configuration;
  }
  
  private ViewGroup S() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.j.obtainStyledAttributes(e.j.y0);
    int i = e.j.D0;
    if (typedArray.hasValue(i)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(e.j.M0, false)) {
        A(1);
      } else if (typedArray.getBoolean(i, false)) {
        A(108);
      } 
      if (typedArray.getBoolean(e.j.E0, false))
        A(109); 
      if (typedArray.getBoolean(e.j.F0, false))
        A(10); 
      this.I = typedArray.getBoolean(e.j.z0, false);
      typedArray.recycle();
      Z();
      this.k.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.j);
      if (!this.J) {
        if (this.I) {
          viewGroup = (ViewGroup)layoutInflater.inflate(e.g.f, null);
          this.G = false;
          this.F = false;
        } else if (this.F) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.j.getTheme().resolveAttribute(e.a.f, typedValue, true);
          if (typedValue.resourceId != 0) {
            k.d d = new k.d(this.j, typedValue.resourceId);
          } else {
            context = this.j;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(e.g.p, null);
          d0 d01 = (d0)viewGroup1.findViewById(e.f.p);
          this.q = d01;
          d01.setWindowCallback(h0());
          if (this.G)
            this.q.k(109); 
          if (this.D)
            this.q.k(2); 
          viewGroup = viewGroup1;
          if (this.E) {
            this.q.k(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else if (this.H) {
        viewGroup = (ViewGroup)layoutInflater.inflate(e.g.o, null);
      } else {
        viewGroup = (ViewGroup)viewGroup.inflate(e.g.n, null);
      } 
      if (viewGroup != null) {
        w.A0((View)viewGroup, new b(this));
        if (this.q == null)
          this.B = (TextView)viewGroup.findViewById(e.f.M); 
        d1.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(e.f.b);
        ViewGroup viewGroup1 = (ViewGroup)this.k.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.k.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new c(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.F);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.G);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.I);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.H);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.J);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  private void Y() {
    if (!this.z) {
      this.A = S();
      CharSequence charSequence = g0();
      if (!TextUtils.isEmpty(charSequence)) {
        d0 d01 = this.q;
        if (d01 != null) {
          d01.setWindowTitle(charSequence);
        } else if (A0() != null) {
          A0().u(charSequence);
        } else {
          TextView textView = this.B;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      J();
      y0(this.A);
      this.z = true;
      t t1 = f0(0, false);
      if (!this.Q && (t1 == null || t1.j == null))
        m0(108); 
    } 
  }
  
  private void Z() {
    if (this.k == null) {
      Object object = this.i;
      if (object instanceof Activity)
        K(((Activity)object).getWindow()); 
    } 
    if (this.k != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  private static Configuration b0(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null) {
      if (paramConfiguration1.diff(paramConfiguration2) == 0)
        return configuration; 
      float f1 = paramConfiguration1.fontScale;
      float f2 = paramConfiguration2.fontScale;
      if (f1 != f2)
        configuration.fontScale = f2; 
      int i = paramConfiguration1.mcc;
      int j = paramConfiguration2.mcc;
      if (i != j)
        configuration.mcc = j; 
      i = paramConfiguration1.mnc;
      j = paramConfiguration2.mnc;
      if (i != j)
        configuration.mnc = j; 
      i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        l.a(paramConfiguration1, paramConfiguration2, configuration);
      } else if (!k0.c.a(paramConfiguration1.locale, paramConfiguration2.locale)) {
        configuration.locale = paramConfiguration2.locale;
      } 
      j = paramConfiguration1.touchscreen;
      int k = paramConfiguration2.touchscreen;
      if (j != k)
        configuration.touchscreen = k; 
      j = paramConfiguration1.keyboard;
      k = paramConfiguration2.keyboard;
      if (j != k)
        configuration.keyboard = k; 
      j = paramConfiguration1.keyboardHidden;
      k = paramConfiguration2.keyboardHidden;
      if (j != k)
        configuration.keyboardHidden = k; 
      j = paramConfiguration1.navigation;
      k = paramConfiguration2.navigation;
      if (j != k)
        configuration.navigation = k; 
      j = paramConfiguration1.navigationHidden;
      k = paramConfiguration2.navigationHidden;
      if (j != k)
        configuration.navigationHidden = k; 
      j = paramConfiguration1.orientation;
      k = paramConfiguration2.orientation;
      if (j != k)
        configuration.orientation = k; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xF) != (k & 0xF))
        configuration.screenLayout |= k & 0xF; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xC0) != (k & 0xC0))
        configuration.screenLayout |= k & 0xC0; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x30) != (k & 0x30))
        configuration.screenLayout |= k & 0x30; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x300) != (k & 0x300))
        configuration.screenLayout |= k & 0x300; 
      if (i >= 26)
        m.a(paramConfiguration1, paramConfiguration2, configuration); 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0xF) != (j & 0xF))
        configuration.uiMode |= j & 0xF; 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0x30) != (j & 0x30))
        configuration.uiMode |= j & 0x30; 
      i = paramConfiguration1.screenWidthDp;
      j = paramConfiguration2.screenWidthDp;
      if (i != j)
        configuration.screenWidthDp = j; 
      i = paramConfiguration1.screenHeightDp;
      j = paramConfiguration2.screenHeightDp;
      if (i != j)
        configuration.screenHeightDp = j; 
      i = paramConfiguration1.smallestScreenWidthDp;
      j = paramConfiguration2.smallestScreenWidthDp;
      if (i != j)
        configuration.smallestScreenWidthDp = j; 
      j.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  private p d0(Context paramContext) {
    if (this.X == null)
      this.X = new o(this, paramContext); 
    return this.X;
  }
  
  private p e0(Context paramContext) {
    if (this.W == null)
      this.W = new q(this, l.a(paramContext)); 
    return this.W;
  }
  
  private void i0() {
    Y();
    if (this.F) {
      if (this.n != null)
        return; 
      Object object = this.i;
      if (object instanceof Activity) {
        this.n = new m((Activity)this.i, this.G);
      } else if (object instanceof Dialog) {
        this.n = new m((Dialog)this.i);
      } 
      object = this.n;
      if (object != null)
        object.q(this.b0); 
    } 
  }
  
  private boolean j0(t paramt) {
    View view = paramt.i;
    if (view != null) {
      paramt.h = view;
      return true;
    } 
    if (paramt.j == null)
      return false; 
    if (this.s == null)
      this.s = new u(this); 
    view = (View)paramt.a(this.s);
    paramt.h = view;
    return (view != null);
  }
  
  private boolean k0(t paramt) {
    paramt.d(c0());
    paramt.g = (ViewGroup)new s(this, paramt.l);
    paramt.c = 81;
    return true;
  }
  
  private boolean l0(t paramt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield q : Landroidx/appcompat/widget/d0;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic e/a.f : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aconst_null
    //   63: astore_3
    //   64: aload #6
    //   66: getfield resourceId : I
    //   69: ifeq -> 111
    //   72: aload #5
    //   74: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   77: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   80: astore_3
    //   81: aload_3
    //   82: aload #7
    //   84: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   87: aload_3
    //   88: aload #6
    //   90: getfield resourceId : I
    //   93: iconst_1
    //   94: invokevirtual applyStyle : (IZ)V
    //   97: aload_3
    //   98: getstatic e/a.g : I
    //   101: aload #6
    //   103: iconst_1
    //   104: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   107: pop
    //   108: goto -> 123
    //   111: aload #7
    //   113: getstatic e/a.g : I
    //   116: aload #6
    //   118: iconst_1
    //   119: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   122: pop
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new k/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/e
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual V : (Landroidx/appcompat/view/menu/e$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/e;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private void m0(int paramInt) {
    this.Z = 1 << paramInt | this.Z;
    if (!this.Y) {
      w.g0(this.k.getDecorView(), this.a0);
      this.Y = true;
    } 
  }
  
  private boolean n0() {
    if (!this.V && this.i instanceof Activity) {
      PackageManager packageManager = this.j.getPackageManager();
      if (packageManager == null)
        return false; 
      try {
        boolean bool;
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
          i = 269221888;
        } else if (i >= 24) {
          i = 786432;
        } else {
          i = 0;
        } 
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(this.j, this.i.getClass()), i);
        if (activityInfo != null && (activityInfo.configChanges & 0x200) != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.U = bool;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        this.U = false;
      } 
    } 
    this.V = true;
    return this.U;
  }
  
  private boolean s0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      t t1 = f0(paramInt, true);
      if (!t1.o)
        return C0(t1, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean v0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield t : Lk/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual f0 : (IZ)Landroidx/appcompat/app/f$t;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield q : Landroidx/appcompat/widget/d0;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface g : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield j : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield q : Landroidx/appcompat/widget/d0;
    //   62: invokeinterface b : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield Q : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokespecial C0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield q : Landroidx/appcompat/widget/d0;
    //   91: invokeinterface f : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield q : Landroidx/appcompat/widget/d0;
    //   104: invokeinterface e : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokespecial C0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokespecial z0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual Q : (Landroidx/appcompat/app/f$t;Z)V
    //   198: iload_3
    //   199: ifeq -> 240
    //   202: aload_0
    //   203: getfield j : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 230
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: iload_3
    //   229: ireturn
    //   230: ldc_w 'AppCompatDelegate'
    //   233: ldc_w 'Couldn't get audio manager'
    //   236: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: iload_3
    //   241: ireturn
  }
  
  private void z0(t paramt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 405
    //   7: aload_0
    //   8: getfield Q : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield j : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual h0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroidx/appcompat/view/menu/e;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual Q : (Landroidx/appcompat/app/f$t;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield j : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial C0 : (Landroidx/appcompat/app/f$t;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 331
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 331
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 331
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 334
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial k0 : (Landroidx/appcompat/app/f$t;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokespecial j0 : (Landroidx/appcompat/app/f$t;)Z
    //   217: ifeq -> 400
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 230
    //   227: goto -> 400
    //   230: aload_1
    //   231: getfield h : Landroid/view/View;
    //   234: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   237: astore #4
    //   239: aload #4
    //   241: astore_2
    //   242: aload #4
    //   244: ifnonnull -> 259
    //   247: new android/view/ViewGroup$LayoutParams
    //   250: dup
    //   251: bipush #-2
    //   253: bipush #-2
    //   255: invokespecial <init> : (II)V
    //   258: astore_2
    //   259: aload_1
    //   260: getfield b : I
    //   263: istore_3
    //   264: aload_1
    //   265: getfield g : Landroid/view/ViewGroup;
    //   268: iload_3
    //   269: invokevirtual setBackgroundResource : (I)V
    //   272: aload_1
    //   273: getfield h : Landroid/view/View;
    //   276: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   279: astore #4
    //   281: aload #4
    //   283: instanceof android/view/ViewGroup
    //   286: ifeq -> 301
    //   289: aload #4
    //   291: checkcast android/view/ViewGroup
    //   294: aload_1
    //   295: getfield h : Landroid/view/View;
    //   298: invokevirtual removeView : (Landroid/view/View;)V
    //   301: aload_1
    //   302: getfield g : Landroid/view/ViewGroup;
    //   305: aload_1
    //   306: getfield h : Landroid/view/View;
    //   309: aload_2
    //   310: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   313: aload_1
    //   314: getfield h : Landroid/view/View;
    //   317: invokevirtual hasFocus : ()Z
    //   320: ifne -> 331
    //   323: aload_1
    //   324: getfield h : Landroid/view/View;
    //   327: invokevirtual requestFocus : ()Z
    //   330: pop
    //   331: bipush #-2
    //   333: istore_3
    //   334: aload_1
    //   335: iconst_0
    //   336: putfield n : Z
    //   339: new android/view/WindowManager$LayoutParams
    //   342: dup
    //   343: iload_3
    //   344: bipush #-2
    //   346: aload_1
    //   347: getfield d : I
    //   350: aload_1
    //   351: getfield e : I
    //   354: sipush #1002
    //   357: ldc_w 8519680
    //   360: bipush #-3
    //   362: invokespecial <init> : (IIIIIII)V
    //   365: astore_2
    //   366: aload_2
    //   367: aload_1
    //   368: getfield c : I
    //   371: putfield gravity : I
    //   374: aload_2
    //   375: aload_1
    //   376: getfield f : I
    //   379: putfield windowAnimations : I
    //   382: aload #5
    //   384: aload_1
    //   385: getfield g : Landroid/view/ViewGroup;
    //   388: aload_2
    //   389: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   394: aload_1
    //   395: iconst_1
    //   396: putfield o : Z
    //   399: return
    //   400: aload_1
    //   401: iconst_1
    //   402: putfield q : Z
    //   405: return
  }
  
  public boolean A(int paramInt) {
    paramInt = E0(paramInt);
    if (this.J && paramInt == 108)
      return false; 
    if (this.F && paramInt == 1)
      this.F = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.k.requestFeature(paramInt); 
              J0();
              this.G = true;
              return true;
            } 
            J0();
            this.F = true;
            return true;
          } 
          J0();
          this.H = true;
          return true;
        } 
        J0();
        this.E = true;
        return true;
      } 
      J0();
      this.D = true;
      return true;
    } 
    J0();
    this.J = true;
    return true;
  }
  
  final a A0() {
    return this.n;
  }
  
  public void B(int paramInt) {
    Y();
    ViewGroup viewGroup = (ViewGroup)this.A.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.j).inflate(paramInt, viewGroup);
    this.l.a().onContentChanged();
  }
  
  public void C(View paramView) {
    Y();
    ViewGroup viewGroup = (ViewGroup)this.A.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.l.a().onContentChanged();
  }
  
  public void D(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    Y();
    ViewGroup viewGroup = (ViewGroup)this.A.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.l.a().onContentChanged();
  }
  
  public void E(Toolbar paramToolbar) {
    if (!(this.i instanceof Activity))
      return; 
    a a1 = n();
    if (!(a1 instanceof m)) {
      this.o = null;
      if (a1 != null)
        a1.m(); 
      this.n = null;
      if (paramToolbar != null) {
        j j = new j(paramToolbar, g0(), (Window.Callback)this.l);
        this.n = j;
        this.l.b(j.c);
      } else {
        this.l.b(null);
      } 
      p();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  public void F(int paramInt) {
    this.T = paramInt;
  }
  
  final boolean F0() {
    if (this.z) {
      ViewGroup viewGroup = this.A;
      if (viewGroup != null && w.S((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  public final void G(CharSequence paramCharSequence) {
    this.p = paramCharSequence;
    d0 d01 = this.q;
    if (d01 != null) {
      d01.setWindowTitle(paramCharSequence);
      return;
    } 
    if (A0() != null) {
      A0().u(paramCharSequence);
      return;
    } 
    TextView textView = this.B;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public boolean H() {
    return I(true);
  }
  
  public k.b H0(k.b.a parama) {
    if (parama != null) {
      k.b b1 = this.t;
      if (b1 != null)
        b1.c(); 
      parama = new i(this, parama);
      a a1 = n();
      if (a1 != null) {
        k.b b2 = a1.v(parama);
        this.t = b2;
        if (b2 != null) {
          f.a a2 = this.m;
          if (a2 != null)
            a2.q(b2); 
        } 
      } 
      if (this.t == null)
        this.t = I0(parama); 
      return this.t;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  k.b I0(k.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual X : ()V
    //   4: aload_0
    //   5: getfield t : Lk/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/f$i
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/f$i
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/f;Lk/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield m : Lf/a;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield Q : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface p : (Lk/b$a;)Lk/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield t : Lk/b;
    //   80: goto -> 565
    //   83: aload_0
    //   84: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield I : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield j : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic e/a.f : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield j : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new k/d
    //   169: dup
    //   170: aload_0
    //   171: getfield j : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield j : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic e/a.i : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield v : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield v : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield v : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic e/a.b : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield v : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/f$d
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/f;)V
    //   309: putfield w : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield A : Landroid/view/ViewGroup;
    //   319: getstatic e/f.h : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual c0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 565
    //   362: aload_0
    //   363: invokevirtual X : ()V
    //   366: aload_0
    //   367: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield v : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new k/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Lk/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface b : (Lk/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 560
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Lk/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield t : Lk/b;
    //   445: aload_0
    //   446: invokevirtual F0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic e : (Landroid/view/View;)Landroidx/core/view/b0;
    //   467: fconst_1
    //   468: invokevirtual a : (F)Landroidx/core/view/b0;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield x : Landroidx/core/view/b0;
    //   477: aload_1
    //   478: new androidx/appcompat/app/f$e
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/f;)V
    //   486: invokevirtual f : (Landroidx/core/view/c0;)Landroidx/core/view/b0;
    //   489: pop
    //   490: goto -> 535
    //   493: aload_0
    //   494: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   516: instanceof android/view/View
    //   519: ifeq -> 535
    //   522: aload_0
    //   523: getfield u : Landroidx/appcompat/widget/ActionBarContextView;
    //   526: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   529: checkcast android/view/View
    //   532: invokestatic l0 : (Landroid/view/View;)V
    //   535: aload_0
    //   536: getfield v : Landroid/widget/PopupWindow;
    //   539: ifnull -> 565
    //   542: aload_0
    //   543: getfield k : Landroid/view/Window;
    //   546: invokevirtual getDecorView : ()Landroid/view/View;
    //   549: aload_0
    //   550: getfield w : Ljava/lang/Runnable;
    //   553: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   556: pop
    //   557: goto -> 565
    //   560: aload_0
    //   561: aconst_null
    //   562: putfield t : Lk/b;
    //   565: aload_0
    //   566: getfield t : Lk/b;
    //   569: astore_1
    //   570: aload_1
    //   571: ifnull -> 593
    //   574: aload_0
    //   575: getfield m : Lf/a;
    //   578: astore #4
    //   580: aload #4
    //   582: ifnull -> 593
    //   585: aload #4
    //   587: aload_1
    //   588: invokeinterface q : (Lk/b;)V
    //   593: aload_0
    //   594: getfield t : Lk/b;
    //   597: areturn
    //   598: astore_1
    //   599: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	598	java/lang/AbstractMethodError
  }
  
  void M(int paramInt, t paramt, Menu paramMenu) {
    e e1;
    t t1 = paramt;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      t t2 = paramt;
      if (paramt == null) {
        t2 = paramt;
        if (paramInt >= 0) {
          t[] arrayOfT = this.L;
          t2 = paramt;
          if (paramInt < arrayOfT.length)
            t2 = arrayOfT[paramInt]; 
        } 
      } 
      t1 = t2;
      menu = paramMenu;
      if (t2 != null) {
        e1 = t2.j;
        t1 = t2;
      } 
    } 
    if (t1 != null && !t1.o)
      return; 
    if (!this.Q)
      this.l.a().onPanelClosed(paramInt, (Menu)e1); 
  }
  
  void N(e parame) {
    if (this.K)
      return; 
    this.K = true;
    this.q.l();
    Window.Callback callback = h0();
    if (callback != null && !this.Q)
      callback.onPanelClosed(108, (Menu)parame); 
    this.K = false;
  }
  
  final int N0(g0 paramg0, Rect paramRect) {
    int i;
    int j;
    boolean bool1;
    boolean bool2 = false;
    if (paramg0 != null) {
      i = paramg0.l();
    } else if (paramRect != null) {
      i = paramRect.top;
    } else {
      i = 0;
    } 
    ActionBarContextView actionBarContextView = this.u;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.u.getLayoutParams();
      boolean bool3 = this.u.isShown();
      int k = 1;
      bool1 = true;
      if (bool3) {
        int m;
        if (this.c0 == null) {
          this.c0 = new Rect();
          this.d0 = new Rect();
        } 
        Rect rect1 = this.c0;
        Rect rect2 = this.d0;
        if (paramg0 == null) {
          rect1.set(paramRect);
        } else {
          rect1.set(paramg0.j(), paramg0.l(), paramg0.k(), paramg0.i());
        } 
        d1.a((View)this.A, rect1, rect2);
        int i1 = rect1.top;
        bool = rect1.left;
        int i2 = rect1.right;
        paramg0 = w.I((View)this.A);
        if (paramg0 == null) {
          k = 0;
        } else {
          k = paramg0.j();
        } 
        if (paramg0 == null) {
          m = 0;
        } else {
          m = paramg0.k();
        } 
        if (marginLayoutParams.topMargin != i1 || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i2) {
          marginLayoutParams.topMargin = i1;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i2;
          bool = true;
        } else {
          bool = false;
        } 
        if (i1 > 0 && this.C == null) {
          View view2 = new View(this.j);
          this.C = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = k;
          layoutParams.rightMargin = m;
          this.A.addView(this.C, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.C;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            i1 = marginLayoutParams1.height;
            i2 = marginLayoutParams.topMargin;
            if (i1 != i2 || marginLayoutParams1.leftMargin != k || marginLayoutParams1.rightMargin != m) {
              marginLayoutParams1.height = i2;
              marginLayoutParams1.leftMargin = k;
              marginLayoutParams1.rightMargin = m;
              this.C.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.C;
        if (view1 != null) {
          m = bool1;
        } else {
          m = 0;
        } 
        if (m != 0 && view1.getVisibility() != 0)
          O0(this.C); 
        k = i;
        if (!this.H) {
          k = i;
          if (m != 0)
            k = 0; 
        } 
        i = k;
        k = bool;
        bool = m;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        k = bool;
      } 
      j = i;
      bool1 = bool;
      if (k != 0) {
        this.u.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        j = i;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      j = i;
    } 
    View view = this.C;
    if (view != null) {
      if (bool1) {
        i = bool2;
      } else {
        i = 8;
      } 
      view.setVisibility(i);
    } 
    return j;
  }
  
  void P(int paramInt) {
    Q(f0(paramInt, true), true);
  }
  
  void Q(t paramt, boolean paramBoolean) {
    if (paramBoolean && paramt.a == 0) {
      d0 d01 = this.q;
      if (d01 != null && d01.b()) {
        N(paramt.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.j.getSystemService("window");
    if (windowManager != null && paramt.o) {
      ViewGroup viewGroup = paramt.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          M(paramt.a, paramt, null); 
      } 
    } 
    paramt.m = false;
    paramt.n = false;
    paramt.o = false;
    paramt.h = null;
    paramt.q = true;
    if (this.M == paramt)
      this.M = null; 
  }
  
  public View T(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    g g1 = this.e0;
    boolean bool2 = false;
    if (g1 == null) {
      String str = this.j.obtainStyledAttributes(e.j.y0).getString(e.j.C0);
      if (str == null) {
        this.e0 = new g();
      } else {
        try {
          this.e0 = this.j.getClassLoader().loadClass(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), exception);
        } 
      } 
    } 
    boolean bool4 = h0;
    boolean bool3 = true;
    boolean bool1 = bool2;
    if (bool4) {
      if (this.f0 == null)
        this.f0 = new h(); 
      if (this.f0.a(paramAttributeSet)) {
        bool1 = true;
      } else if (paramAttributeSet instanceof XmlPullParser) {
        bool1 = bool2;
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = bool3; 
      } else {
        bool1 = G0((ViewParent)paramView);
      } 
    } 
    return this.e0.r(paramView, paramString, paramContext, paramAttributeSet, bool1, bool4, true, c1.c());
  }
  
  void U() {
    d0 d01 = this.q;
    if (d01 != null)
      d01.l(); 
    if (this.v != null) {
      this.k.getDecorView().removeCallbacks(this.w);
      if (this.v.isShowing())
        try {
          this.v.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.v = null;
    } 
    X();
    t t1 = f0(0, false);
    if (t1 != null) {
      e e1 = t1.j;
      if (e1 != null)
        e1.close(); 
    } 
  }
  
  boolean V(KeyEvent paramKeyEvent) {
    Object object = this.i;
    boolean bool1 = object instanceof androidx.core.view.f.a;
    boolean bool = true;
    if (bool1 || object instanceof f.b) {
      object = this.k.getDecorView();
      if (object != null && androidx.core.view.f.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.l.a().dispatchKeyEvent(paramKeyEvent))
      return true; 
    int i = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? r0(i, paramKeyEvent) : u0(i, paramKeyEvent);
  }
  
  void W(int paramInt) {
    t t1 = f0(paramInt, true);
    if (t1.j != null) {
      Bundle bundle = new Bundle();
      t1.j.T(bundle);
      if (bundle.size() > 0)
        t1.s = bundle; 
      t1.j.h0();
      t1.j.clear();
    } 
    t1.r = true;
    t1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.q != null) {
      t1 = f0(0, false);
      if (t1 != null) {
        t1.m = false;
        C0(t1, null);
      } 
    } 
  }
  
  void X() {
    b0 b01 = this.x;
    if (b01 != null)
      b01.b(); 
  }
  
  public boolean a(e parame, MenuItem paramMenuItem) {
    Window.Callback callback = h0();
    if (callback != null && !this.Q) {
      t t1 = a0((Menu)parame.F());
      if (t1 != null)
        return callback.onMenuItemSelected(t1.a, paramMenuItem); 
    } 
    return false;
  }
  
  t a0(Menu paramMenu) {
    byte b1;
    t[] arrayOfT = this.L;
    int i = 0;
    if (arrayOfT != null) {
      b1 = arrayOfT.length;
    } else {
      b1 = 0;
    } 
    while (i < b1) {
      t t1 = arrayOfT[i];
      if (t1 != null && t1.j == paramMenu)
        return t1; 
      i++;
    } 
    return null;
  }
  
  public void b(e parame) {
    D0(true);
  }
  
  final Context c0() {
    Context context;
    a a1 = n();
    if (a1 != null) {
      Context context1 = a1.j();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.j; 
    return context;
  }
  
  public void d(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    Y();
    ((ViewGroup)this.A.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.l.a().onContentChanged();
  }
  
  public Context f(Context paramContext) {
    int i = 1;
    this.O = true;
    int j = p0(paramContext, L());
    boolean bool = k0;
    Configuration configuration1 = null;
    if (bool && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = R(paramContext, j, null);
      try {
        r.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof k.d) {
      Configuration configuration = R(paramContext, j, null);
      try {
        ((k.d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!j0)
      return super.f(paramContext); 
    Configuration configuration2 = new Configuration();
    configuration2.uiMode = -1;
    configuration2.fontScale = 0.0F;
    configuration2 = j.a(paramContext, configuration2).getResources().getConfiguration();
    Configuration configuration3 = paramContext.getResources().getConfiguration();
    configuration2.uiMode = configuration3.uiMode;
    if (!configuration2.equals(configuration3))
      configuration1 = b0(configuration2, configuration3); 
    configuration2 = R(paramContext, j, configuration1);
    k.d d = new k.d(paramContext, e.i.d);
    d.a(configuration2);
    j = 0;
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme == null)
        i = 0; 
    } catch (NullPointerException nullPointerException) {
      i = j;
    } 
    if (i != 0)
      b0.h.e.a(d.getTheme()); 
    return super.f((Context)d);
  }
  
  protected t f0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield L : [Landroidx/appcompat/app/f$t;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/f$t
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield L : [Landroidx/appcompat/app/f$t;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/f$t
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  final CharSequence g0() {
    Object object = this.i;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.p;
  }
  
  final Window.Callback h0() {
    return this.k.getCallback();
  }
  
  public <T extends View> T i(int paramInt) {
    Y();
    return (T)this.k.findViewById(paramInt);
  }
  
  public final b.b k() {
    return new f(this);
  }
  
  public int l() {
    return this.S;
  }
  
  public MenuInflater m() {
    if (this.o == null) {
      Context context;
      i0();
      a a1 = this.n;
      if (a1 != null) {
        context = a1.j();
      } else {
        context = this.j;
      } 
      this.o = (MenuInflater)new k.g(context);
    } 
    return this.o;
  }
  
  public a n() {
    i0();
    return this.n;
  }
  
  public void o() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.j);
    if (layoutInflater.getFactory() == null) {
      androidx.core.view.g.a(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof f))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  public boolean o0() {
    return this.y;
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return T(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void p() {
    a a1 = n();
    if (a1 != null && a1.k())
      return; 
    m0(0);
  }
  
  int p0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3)
              return d0(paramContext).c(); 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (((UiModeManager)paramContext.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) ? -1 : e0(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public void q(Configuration paramConfiguration) {
    if (this.F && this.z) {
      a a1 = n();
      if (a1 != null)
        a1.l(paramConfiguration); 
    } 
    androidx.appcompat.widget.j.b().g(this.j);
    this.R = new Configuration(this.j.getResources().getConfiguration());
    I(false);
  }
  
  boolean q0() {
    k.b b1 = this.t;
    if (b1 != null) {
      b1.c();
      return true;
    } 
    a a1 = n();
    return (a1 != null && a1.g());
  }
  
  public void r(Bundle paramBundle) {
    this.O = true;
    I(false);
    Z();
    Object object = this.i;
    if (object instanceof Activity) {
      Object object1;
      paramBundle = null;
      try {
        object = androidx.core.app.g.c((Activity)object);
        object1 = object;
      } catch (IllegalArgumentException illegalArgumentException) {}
      if (object1 != null) {
        object1 = A0();
        if (object1 == null) {
          this.b0 = true;
        } else {
          object1.q(true);
        } 
      } 
      e.c(this);
    } 
    this.R = new Configuration(this.j.getResources().getConfiguration());
    this.P = true;
  }
  
  boolean r0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      s0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.N = bool;
    return false;
  }
  
  public void s() {
    // Byte code:
    //   0: aload_0
    //   1: getfield i : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic y : (Landroidx/appcompat/app/e;)V
    //   14: aload_0
    //   15: getfield Y : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield k : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield a0 : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_1
    //   38: putfield Q : Z
    //   41: aload_0
    //   42: getfield S : I
    //   45: bipush #-100
    //   47: if_icmpeq -> 99
    //   50: aload_0
    //   51: getfield i : Ljava/lang/Object;
    //   54: astore_1
    //   55: aload_1
    //   56: instanceof android/app/Activity
    //   59: ifeq -> 99
    //   62: aload_1
    //   63: checkcast android/app/Activity
    //   66: invokevirtual isChangingConfigurations : ()Z
    //   69: ifeq -> 99
    //   72: getstatic androidx/appcompat/app/f.g0 : Ls/g;
    //   75: aload_0
    //   76: getfield i : Ljava/lang/Object;
    //   79: invokevirtual getClass : ()Ljava/lang/Class;
    //   82: invokevirtual getName : ()Ljava/lang/String;
    //   85: aload_0
    //   86: getfield S : I
    //   89: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   92: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   95: pop
    //   96: goto -> 116
    //   99: getstatic androidx/appcompat/app/f.g0 : Ls/g;
    //   102: aload_0
    //   103: getfield i : Ljava/lang/Object;
    //   106: invokevirtual getClass : ()Ljava/lang/Class;
    //   109: invokevirtual getName : ()Ljava/lang/String;
    //   112: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   115: pop
    //   116: aload_0
    //   117: getfield n : Landroidx/appcompat/app/a;
    //   120: astore_1
    //   121: aload_1
    //   122: ifnull -> 129
    //   125: aload_1
    //   126: invokevirtual m : ()V
    //   129: aload_0
    //   130: invokespecial O : ()V
    //   133: return
  }
  
  public void t(Bundle paramBundle) {
    Y();
  }
  
  boolean t0(int paramInt, KeyEvent paramKeyEvent) {
    t t1;
    a a1 = n();
    if (a1 != null && a1.n(paramInt, paramKeyEvent))
      return true; 
    t t2 = this.M;
    if (t2 != null && B0(t2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      t1 = this.M;
      if (t1 != null)
        t1.n = true; 
      return true;
    } 
    if (this.M == null) {
      t2 = f0(0, true);
      C0(t2, (KeyEvent)t1);
      boolean bool = B0(t2, t1.getKeyCode(), (KeyEvent)t1, 1);
      t2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void u() {
    a a1 = n();
    if (a1 != null)
      a1.t(true); 
  }
  
  boolean u0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      v0(0, paramKeyEvent);
      return true;
    } 
    boolean bool = this.N;
    this.N = false;
    t t1 = f0(0, false);
    if (t1 != null && t1.o) {
      if (!bool)
        Q(t1, true); 
      return true;
    } 
    return q0();
  }
  
  public void v(Bundle paramBundle) {}
  
  public void w() {
    H();
  }
  
  void w0(int paramInt) {
    if (paramInt == 108) {
      a a1 = n();
      if (a1 != null)
        a1.h(true); 
    } 
  }
  
  public void x() {
    a a1 = n();
    if (a1 != null)
      a1.t(false); 
  }
  
  void x0(int paramInt) {
    if (paramInt == 108) {
      a a1 = n();
      if (a1 != null) {
        a1.h(false);
        return;
      } 
    } else if (paramInt == 0) {
      t t1 = f0(paramInt, true);
      if (t1.o)
        Q(t1, false); 
    } 
  }
  
  void y0(ViewGroup paramViewGroup) {}
  
  class a implements Runnable {
    a(f this$0) {}
    
    public void run() {
      f f1 = this.f;
      if ((f1.Z & 0x1) != 0)
        f1.W(0); 
      f1 = this.f;
      if ((f1.Z & 0x1000) != 0)
        f1.W(108); 
      f1 = this.f;
      f1.Y = false;
      f1.Z = 0;
    }
  }
  
  class b implements androidx.core.view.r {
    b(f this$0) {}
    
    public g0 a(View param1View, g0 param1g0) {
      int i = param1g0.l();
      int j = this.a.N0(param1g0, null);
      g0 g01 = param1g0;
      if (i != j)
        g01 = param1g0.q(param1g0.j(), j, param1g0.k(), param1g0.i()); 
      return w.a0(param1View, g01);
    }
  }
  
  class c implements ContentFrameLayout.a {
    c(f this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.U();
    }
  }
  
  class d implements Runnable {
    d(f this$0) {}
    
    public void run() {
      f f1 = this.f;
      f1.v.showAtLocation((View)f1.u, 55, 0, 0);
      this.f.X();
      if (this.f.F0()) {
        this.f.u.setAlpha(0.0F);
        f1 = this.f;
        f1.x = w.e((View)f1.u).a(1.0F);
        this.f.x.f((c0)new a(this));
        return;
      } 
      this.f.u.setAlpha(1.0F);
      this.f.u.setVisibility(0);
    }
    
    class a extends d0 {
      a(f.d this$0) {}
      
      public void b(View param2View) {
        this.a.f.u.setAlpha(1.0F);
        this.a.f.x.f(null);
        this.a.f.x = null;
      }
      
      public void c(View param2View) {
        this.a.f.u.setVisibility(0);
      }
    }
  }
  
  class a extends d0 {
    a(f this$0) {}
    
    public void b(View param1View) {
      this.a.f.u.setAlpha(1.0F);
      this.a.f.x.f(null);
      this.a.f.x = null;
    }
    
    public void c(View param1View) {
      this.a.f.u.setVisibility(0);
    }
  }
  
  class e extends d0 {
    e(f this$0) {}
    
    public void b(View param1View) {
      this.a.u.setAlpha(1.0F);
      this.a.x.f(null);
      this.a.x = null;
    }
    
    public void c(View param1View) {
      this.a.u.setVisibility(0);
      if (this.a.u.getParent() instanceof View)
        w.l0((View)this.a.u.getParent()); 
    }
  }
  
  private class f implements b.b {
    f(f this$0) {}
    
    public void a(Drawable param1Drawable, int param1Int) {
      a a = this.a.n();
      if (a != null) {
        a.s(param1Drawable);
        a.r(param1Int);
      } 
    }
    
    public boolean b() {
      a a = this.a.n();
      return (a != null && (a.i() & 0x4) != 0);
    }
    
    public Drawable c() {
      w0 w0 = w0.u(e(), null, new int[] { e.a.E });
      Drawable drawable = w0.g(0);
      w0.w();
      return drawable;
    }
    
    public void d(int param1Int) {
      a a = this.a.n();
      if (a != null)
        a.r(param1Int); 
    }
    
    public Context e() {
      return this.a.c0();
    }
  }
  
  static interface g {
    boolean a(int param1Int);
    
    View onCreatePanelView(int param1Int);
  }
  
  private final class h implements androidx.appcompat.view.menu.j.a {
    h(f this$0) {}
    
    public void b(e param1e, boolean param1Boolean) {
      this.f.N(param1e);
    }
    
    public boolean c(e param1e) {
      Window.Callback callback = this.f.h0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1e); 
      return true;
    }
  }
  
  class i implements k.b.a {
    private k.b.a a;
    
    public i(f this$0, k.b.a param1a) {
      this.a = param1a;
    }
    
    public boolean a(k.b param1b, MenuItem param1MenuItem) {
      return this.a.a(param1b, param1MenuItem);
    }
    
    public boolean b(k.b param1b, Menu param1Menu) {
      return this.a.b(param1b, param1Menu);
    }
    
    public boolean c(k.b param1b, Menu param1Menu) {
      w.l0((View)this.b.A);
      return this.a.c(param1b, param1Menu);
    }
    
    public void d(k.b param1b) {
      this.a.d(param1b);
      f f1 = this.b;
      if (f1.v != null)
        f1.k.getDecorView().removeCallbacks(this.b.w); 
      f1 = this.b;
      if (f1.u != null) {
        f1.X();
        f1 = this.b;
        f1.x = w.e((View)f1.u).a(0.0F);
        this.b.x.f((c0)new a(this));
      } 
      f1 = this.b;
      f.a a1 = f1.m;
      if (a1 != null)
        a1.e(f1.t); 
      f1 = this.b;
      f1.t = null;
      w.l0((View)f1.A);
    }
    
    class a extends d0 {
      a(f.i this$0) {}
      
      public void b(View param2View) {
        this.a.b.u.setVisibility(8);
        f f = this.a.b;
        PopupWindow popupWindow = f.v;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (f.u.getParent() instanceof View) {
          w.l0((View)this.a.b.u.getParent());
        } 
        this.a.b.u.k();
        this.a.b.x.f(null);
        f = this.a.b;
        f.x = null;
        w.l0((View)f.A);
      }
    }
  }
  
  class a extends d0 {
    a(f this$0) {}
    
    public void b(View param1View) {
      this.a.b.u.setVisibility(8);
      f f = this.a.b;
      PopupWindow popupWindow = f.v;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (f.u.getParent() instanceof View) {
        w.l0((View)this.a.b.u.getParent());
      } 
      this.a.b.u.k();
      this.a.b.x.f(null);
      f = this.a.b;
      f.x = null;
      w.l0((View)f.A);
    }
  }
  
  static class j {
    static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.densityDpi;
      int k = param1Configuration2.densityDpi;
      if (i != k)
        param1Configuration3.densityDpi = k; 
    }
  }
  
  static class k {
    static boolean a(PowerManager param1PowerManager) {
      return param1PowerManager.isPowerSaveMode();
    }
  }
  
  static class l {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList1 = param1Configuration1.getLocales();
      LocaleList localeList2 = param1Configuration2.getLocales();
      if (!localeList1.equals(localeList2)) {
        param1Configuration3.setLocales(localeList2);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
  }
  
  static class m {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.colorMode;
      int j = param1Configuration2.colorMode;
      if ((i & 0x3) != (j & 0x3))
        param1Configuration3.colorMode |= j & 0x3; 
      i = param1Configuration1.colorMode;
      j = param1Configuration2.colorMode;
      if ((i & 0xC) != (j & 0xC))
        param1Configuration3.colorMode |= j & 0xC; 
    }
  }
  
  class n extends k.i {
    private f.g g;
    
    n(f this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    void b(f.g param1g) {
      this.g = param1g;
    }
    
    final ActionMode c(ActionMode.Callback param1Callback) {
      k.f.a a = new k.f.a(this.h.j, param1Callback);
      k.b b = this.h.H0((k.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.h.V(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.h.t0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    public void onContentChanged() {}
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof e)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public View onCreatePanelView(int param1Int) {
      f.g g1 = this.g;
      if (g1 != null) {
        View view = g1.onCreatePanelView(param1Int);
        if (view != null)
          return view; 
      } 
      return super.onCreatePanelView(param1Int);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.h.w0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      super.onPanelClosed(param1Int, param1Menu);
      this.h.x0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      e e;
      if (param1Menu instanceof e) {
        e = (e)param1Menu;
      } else {
        e = null;
      } 
      if (param1Int == 0 && e == null)
        return false; 
      boolean bool1 = true;
      if (e != null)
        e.e0(true); 
      f.g g1 = this.g;
      if (g1 == null || !g1.a(param1Int))
        bool1 = false; 
      boolean bool2 = bool1;
      if (!bool1)
        bool2 = super.onPreparePanel(param1Int, param1View, param1Menu); 
      if (e != null)
        e.e0(false); 
      return bool2;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      f.t t = this.h.f0(0, true);
      if (t != null) {
        e e = t.j;
        if (e != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)e, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return null;
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.h.o0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : c(param1Callback);
    }
  }
  
  private class o extends p {
    private final PowerManager c;
    
    o(f this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getApplicationContext().getSystemService("power");
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
      return intentFilter;
    }
    
    public int c() {
      return f.k.a(this.c) ? 2 : 1;
    }
    
    public void d() {
      this.d.H();
    }
  }
  
  abstract class p {
    private BroadcastReceiver a;
    
    p(f this$0) {}
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.j.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    abstract IntentFilter b();
    
    abstract int c();
    
    abstract void d();
    
    void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.j.registerReceiver(this.a, intentFilter);
      } 
    }
    
    class a extends BroadcastReceiver {
      a(f.p this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    a(f this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  private class q extends p {
    private final l c;
    
    q(f this$0, l param1l) {
      super(this$0);
      this.c = param1l;
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.H();
    }
  }
  
  private static class r {
    static void a(ContextThemeWrapper param1ContextThemeWrapper, Configuration param1Configuration) {
      param1ContextThemeWrapper.applyOverrideConfiguration(param1Configuration);
    }
  }
  
  private class s extends ContentFrameLayout {
    public s(f this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean b(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.n.V(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && b((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.n.P(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(g.a.b(getContext(), param1Int));
    }
  }
  
  protected static final class t {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    e j;
    
    androidx.appcompat.view.menu.c k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    t(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    androidx.appcompat.view.menu.k a(androidx.appcompat.view.menu.j.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.c c1 = new androidx.appcompat.view.menu.c(this.l, e.g.j);
        this.k = c1;
        c1.m(param1a);
        this.j.b((androidx.appcompat.view.menu.j)this.k);
      } 
      return this.k.c(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    void c(e param1e) {
      e e1 = this.j;
      if (param1e == e1)
        return; 
      if (e1 != null)
        e1.Q((androidx.appcompat.view.menu.j)this.k); 
      this.j = param1e;
      if (param1e != null) {
        androidx.appcompat.view.menu.c c1 = this.k;
        if (c1 != null)
          param1e.b((androidx.appcompat.view.menu.j)c1); 
      } 
    }
    
    void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(e.a.a, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(e.a.I, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(e.i.c, true);
      } 
      k.d d = new k.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(e.j.y0);
      this.b = typedArray.getResourceId(e.j.B0, 0);
      this.f = typedArray.getResourceId(e.j.A0, 0);
      typedArray.recycle();
    }
  }
  
  private final class u implements androidx.appcompat.view.menu.j.a {
    u(f this$0) {}
    
    public void b(e param1e, boolean param1Boolean) {
      boolean bool;
      e e1 = param1e.F();
      if (e1 != param1e) {
        bool = true;
      } else {
        bool = false;
      } 
      f f1 = this.f;
      if (bool)
        param1e = e1; 
      f.t t = f1.a0((Menu)param1e);
      if (t != null) {
        if (bool) {
          this.f.M(t.a, t, (Menu)e1);
          this.f.Q(t, true);
          return;
        } 
        this.f.Q(t, param1Boolean);
      } 
    }
    
    public boolean c(e param1e) {
      if (param1e == param1e.F()) {
        f f1 = this.f;
        if (f1.F) {
          Window.Callback callback = f1.h0();
          if (callback != null && !this.f.Q)
            callback.onMenuOpened(108, (Menu)param1e); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */