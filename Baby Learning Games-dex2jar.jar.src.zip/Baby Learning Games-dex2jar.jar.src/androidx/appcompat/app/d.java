package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.c1;
import androidx.core.app.g;
import androidx.core.app.p;
import androidx.fragment.app.e;
import androidx.lifecycle.i0;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.q;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.c;
import f.a;

public class d extends e implements a, p.a, b.c {
  private e v;
  
  private Resources w;
  
  public d() {
    E();
  }
  
  private void E() {
    c().d("androidx:appcompat", new a(this));
    n(new b(this));
  }
  
  private boolean K(KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  private void r() {
    j0.a(getWindow().getDecorView(), (q)this);
    k0.a(getWindow().getDecorView(), (i0)this);
    androidx.savedstate.d.a(getWindow().getDecorView(), (c)this);
  }
  
  public void B() {
    C().p();
  }
  
  public e C() {
    if (this.v == null)
      this.v = e.g((Activity)this, this); 
    return this.v;
  }
  
  public a D() {
    return C().n();
  }
  
  public void F(p paramp) {
    paramp.j((Activity)this);
  }
  
  protected void G(int paramInt) {}
  
  public void H(p paramp) {}
  
  @Deprecated
  public void I() {}
  
  public boolean J() {
    Intent intent = j();
    if (intent != null) {
      if (N(intent)) {
        p p = p.l((Context)this);
        F(p);
        H(p);
        p.m();
        try {
          androidx.core.app.a.g((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        M((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  public void L(Toolbar paramToolbar) {
    C().E(paramToolbar);
  }
  
  public void M(Intent paramIntent) {
    g.e((Activity)this, paramIntent);
  }
  
  public boolean N(Intent paramIntent) {
    return g.f((Activity)this, paramIntent);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    r();
    C().d(paramView, paramLayoutParams);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(C().f(paramContext));
  }
  
  public void closeOptionsMenu() {
    a a1 = D();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.f()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a1 = D();
    return (i == 82 && a1 != null && a1.o(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public void e(k.b paramb) {}
  
  public <T extends View> T findViewById(int paramInt) {
    return C().i(paramInt);
  }
  
  public b.b g() {
    return C().k();
  }
  
  public MenuInflater getMenuInflater() {
    return C().m();
  }
  
  public Resources getResources() {
    if (this.w == null && c1.c())
      this.w = (Resources)new c1((Context)this, super.getResources()); 
    Resources resources2 = this.w;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public void invalidateOptionsMenu() {
    C().p();
  }
  
  public Intent j() {
    return g.a((Activity)this);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (this.w != null) {
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.w.updateConfiguration(paramConfiguration, displayMetrics);
    } 
    C().q(paramConfiguration);
  }
  
  public void onContentChanged() {
    I();
  }
  
  protected void onDestroy() {
    super.onDestroy();
    C().s();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return K(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a1 = D();
    return (paramMenuItem.getItemId() == 16908332 && a1 != null && (a1.i() & 0x4) != 0) ? J() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    C().t(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    C().u();
  }
  
  protected void onStart() {
    super.onStart();
    C().w();
  }
  
  protected void onStop() {
    super.onStop();
    C().x();
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    C().G(paramCharSequence);
  }
  
  public void openOptionsMenu() {
    a a1 = D();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.p()))
      super.openOptionsMenu(); 
  }
  
  public k.b p(k.b.a parama) {
    return null;
  }
  
  public void q(k.b paramb) {}
  
  public void setContentView(int paramInt) {
    r();
    C().B(paramInt);
  }
  
  public void setContentView(View paramView) {
    r();
    C().C(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    r();
    C().D(paramView, paramLayoutParams);
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    C().F(paramInt);
  }
  
  class a implements SavedStateRegistry.b {
    a(d this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.C().v(bundle);
      return bundle;
    }
  }
  
  class b implements c.b {
    b(d this$0) {}
    
    public void a(Context param1Context) {
      e e = this.a.C();
      e.o();
      e.r(this.a.c().a("androidx:appcompat"));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */