package androidx.appcompat.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;
import androidx.core.content.b;
import java.util.Calendar;

class l {
  private static l d;
  
  private final Context a;
  
  private final LocationManager b;
  
  private final a c = new a();
  
  l(Context paramContext, LocationManager paramLocationManager) {
    this.a = paramContext;
    this.b = paramLocationManager;
  }
  
  static l a(Context paramContext) {
    if (d == null) {
      paramContext = paramContext.getApplicationContext();
      d = new l(paramContext, (LocationManager)paramContext.getSystemService("location"));
    } 
    return d;
  }
  
  @SuppressLint({"MissingPermission"})
  private Location b() {
    Location location1;
    int i = b.b(this.a, "android.permission.ACCESS_COARSE_LOCATION");
    Location location2 = null;
    if (i == 0) {
      location1 = c("network");
    } else {
      location1 = null;
    } 
    if (b.b(this.a, "android.permission.ACCESS_FINE_LOCATION") == 0)
      location2 = c("gps"); 
    if (location2 != null && location1 != null) {
      Location location = location1;
      if (location2.getTime() > location1.getTime())
        location = location2; 
      return location;
    } 
    if (location2 != null)
      location1 = location2; 
    return location1;
  }
  
  private Location c(String paramString) {
    try {
      if (this.b.isProviderEnabled(paramString))
        return this.b.getLastKnownLocation(paramString); 
    } catch (Exception exception) {
      Log.d("TwilightManager", "Failed to get last known location", exception);
    } 
    return null;
  }
  
  private boolean e() {
    return (this.c.f > System.currentTimeMillis());
  }
  
  private void f(Location paramLocation) {
    a a1 = this.c;
    long l1 = System.currentTimeMillis();
    k k = k.b();
    k.a(l1 - 86400000L, paramLocation.getLatitude(), paramLocation.getLongitude());
    long l2 = k.a;
    k.a(l1, paramLocation.getLatitude(), paramLocation.getLongitude());
    int i = k.c;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    long l3 = k.b;
    long l4 = k.a;
    k.a(86400000L + l1, paramLocation.getLatitude(), paramLocation.getLongitude());
    long l5 = k.b;
    if (l3 == -1L || l4 == -1L) {
      l1 = 43200000L + l1;
    } else {
      if (l1 > l4) {
        l1 = 0L + l5;
      } else if (l1 > l3) {
        l1 = 0L + l4;
      } else {
        l1 = 0L + l3;
      } 
      l1 += 60000L;
    } 
    a1.a = bool;
    a1.b = l2;
    a1.c = l3;
    a1.d = l4;
    a1.e = l5;
    a1.f = l1;
  }
  
  boolean d() {
    a a1 = this.c;
    if (e())
      return a1.a; 
    Location location = b();
    if (location != null) {
      f(location);
      return a1.a;
    } 
    Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
    int i = Calendar.getInstance().get(11);
    return (i < 6 || i >= 22);
  }
  
  private static class a {
    boolean a;
    
    long b;
    
    long c;
    
    long d;
    
    long e;
    
    long f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\app\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */