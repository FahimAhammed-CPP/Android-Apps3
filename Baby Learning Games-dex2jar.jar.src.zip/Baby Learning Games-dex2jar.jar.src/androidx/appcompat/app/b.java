package androidx.appcompat.app;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

public class b implements DrawerLayout.e {
  private final b a;
  
  private final DrawerLayout b;
  
  private h.d c;
  
  private boolean d = true;
  
  private Drawable e;
  
  boolean f = true;
  
  private final int g;
  
  private final int h;
  
  View.OnClickListener i;
  
  private boolean j = false;
  
  b(Activity paramActivity, Toolbar paramToolbar, DrawerLayout paramDrawerLayout, h.d paramd, int paramInt1, int paramInt2) {
    if (paramToolbar != null) {
      this.a = new e(paramToolbar);
      paramToolbar.setNavigationOnClickListener(new a(this));
    } else if (paramActivity instanceof c) {
      this.a = ((c)paramActivity).g();
    } else {
      this.a = new d(paramActivity);
    } 
    this.b = paramDrawerLayout;
    this.g = paramInt1;
    this.h = paramInt2;
    if (paramd == null) {
      this.c = new h.d(this.a.e());
    } else {
      this.c = paramd;
    } 
    this.e = e();
  }
  
  public b(Activity paramActivity, DrawerLayout paramDrawerLayout, Toolbar paramToolbar, int paramInt1, int paramInt2) {
    this(paramActivity, paramToolbar, paramDrawerLayout, null, paramInt1, paramInt2);
  }
  
  private void h(float paramFloat) {
    if (paramFloat == 1.0F) {
      this.c.g(true);
    } else if (paramFloat == 0.0F) {
      this.c.g(false);
    } 
    this.c.e(paramFloat);
  }
  
  public void a(int paramInt) {}
  
  public void b(View paramView, float paramFloat) {
    if (this.d) {
      h(Math.min(1.0F, Math.max(0.0F, paramFloat)));
      return;
    } 
    h(0.0F);
  }
  
  public void c(View paramView) {
    h(1.0F);
    if (this.f)
      f(this.h); 
  }
  
  public void d(View paramView) {
    h(0.0F);
    if (this.f)
      f(this.g); 
  }
  
  Drawable e() {
    return this.a.c();
  }
  
  void f(int paramInt) {
    this.a.d(paramInt);
  }
  
  void g(Drawable paramDrawable, int paramInt) {
    if (!this.j && !this.a.b()) {
      Log.w("ActionBarDrawerToggle", "DrawerToggle may not show up because NavigationIcon is not visible. You may need to call actionbar.setDisplayHomeAsUpEnabled(true);");
      this.j = true;
    } 
    this.a.a(paramDrawable, paramInt);
  }
  
  public void i() {
    if (this.b.C(8388611)) {
      h(1.0F);
    } else {
      h(0.0F);
    } 
    if (this.f) {
      int i;
      h.d d1 = this.c;
      if (this.b.C(8388611)) {
        i = this.h;
      } else {
        i = this.g;
      } 
      g((Drawable)d1, i);
    } 
  }
  
  void j() {
    int i = this.b.q(8388611);
    if (this.b.F(8388611) && i != 2) {
      this.b.d(8388611);
      return;
    } 
    if (i != 1)
      this.b.K(8388611); 
  }
  
  class a implements View.OnClickListener {
    a(b this$0) {}
    
    public void onClick(View param1View) {
      b b1 = this.f;
      if (b1.f) {
        b1.j();
        return;
      } 
      View.OnClickListener onClickListener = b1.i;
      if (onClickListener != null)
        onClickListener.onClick(param1View); 
    }
  }
  
  public static interface b {
    void a(Drawable param1Drawable, int param1Int);
    
    boolean b();
    
    Drawable c();
    
    void d(int param1Int);
    
    Context e();
  }
  
  public static interface c {
    b.b g();
  }
  
  private static class d implements b {
    private final Activity a;
    
    d(Activity param1Activity) {
      this.a = param1Activity;
    }
    
    public void a(Drawable param1Drawable, int param1Int) {
      ActionBar actionBar = this.a.getActionBar();
      if (actionBar != null) {
        actionBar.setHomeAsUpIndicator(param1Drawable);
        actionBar.setHomeActionContentDescription(param1Int);
      } 
    }
    
    public boolean b() {
      ActionBar actionBar = this.a.getActionBar();
      return (actionBar != null && (actionBar.getDisplayOptions() & 0x4) != 0);
    }
    
    public Drawable c() {
      TypedArray typedArray = e().obtainStyledAttributes(null, new int[] { 16843531 }, 16843470, 0);
      Drawable drawable = typedArray.getDrawable(0);
      typedArray.recycle();
      return drawable;
    }
    
    public void d(int param1Int) {
      ActionBar actionBar = this.a.getActionBar();
      if (actionBar != null)
        actionBar.setHomeActionContentDescription(param1Int); 
    }
    
    public Context e() {
      ActionBar actionBar = this.a.getActionBar();
      return (Context)((actionBar != null) ? actionBar.getThemedContext() : this.a);
    }
  }
  
  static class e implements b {
    final Toolbar a;
    
    final Drawable b;
    
    final CharSequence c;
    
    e(Toolbar param1Toolbar) {
      this.a = param1Toolbar;
      this.b = param1Toolbar.getNavigationIcon();
      this.c = param1Toolbar.getNavigationContentDescription();
    }
    
    public void a(Drawable param1Drawable, int param1Int) {
      this.a.setNavigationIcon(param1Drawable);
      d(param1Int);
    }
    
    public boolean b() {
      return true;
    }
    
    public Drawable c() {
      return this.b;
    }
    
    public void d(int param1Int) {
      if (param1Int == 0) {
        this.a.setNavigationContentDescription(this.c);
        return;
      } 
      this.a.setNavigationContentDescription(param1Int);
    }
    
    public Context e() {
      return this.a.getContext();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */