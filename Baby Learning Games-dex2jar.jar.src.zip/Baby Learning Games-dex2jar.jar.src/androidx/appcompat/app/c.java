package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import f.b;

public class c extends b {
  final AlertController h = new AlertController(getContext(), this, getWindow());
  
  protected c(Context paramContext, int paramInt) {
    super(paramContext, s(paramContext, paramInt));
  }
  
  static int s(Context paramContext, int paramInt) {
    if ((paramInt >>> 24 & 0xFF) >= 1)
      return paramInt; 
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(e.a.o, typedValue, true);
    return typedValue.resourceId;
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.h.e();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return this.h.f(paramInt, paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    return this.h.g(paramInt, paramKeyEvent) ? true : super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public ListView r() {
    return this.h.d();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    this.h.p(paramCharSequence);
  }
  
  public static class a {
    private final AlertController.b a;
    
    private final int b;
    
    public a(Context param1Context) {
      this(param1Context, c.s(param1Context, 0));
    }
    
    public a(Context param1Context, int param1Int) {
      this.a = new AlertController.b((Context)new ContextThemeWrapper(param1Context, c.s(param1Context, param1Int)));
      this.b = param1Int;
    }
    
    public c a() {
      c c = new c(this.a.a, this.b);
      this.a.a(c.h);
      c.setCancelable(this.a.r);
      if (this.a.r)
        c.setCanceledOnTouchOutside(true); 
      c.setOnCancelListener(this.a.s);
      c.setOnDismissListener(this.a.t);
      DialogInterface.OnKeyListener onKeyListener = this.a.u;
      if (onKeyListener != null)
        c.setOnKeyListener(onKeyListener); 
      return c;
    }
    
    public Context b() {
      return this.a.a;
    }
    
    public a c(ListAdapter param1ListAdapter, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.a;
      b1.w = param1ListAdapter;
      b1.x = param1OnClickListener;
      return this;
    }
    
    public a d(View param1View) {
      this.a.g = param1View;
      return this;
    }
    
    public a e(Drawable param1Drawable) {
      this.a.d = param1Drawable;
      return this;
    }
    
    public a f(DialogInterface.OnKeyListener param1OnKeyListener) {
      this.a.u = param1OnKeyListener;
      return this;
    }
    
    public a g(ListAdapter param1ListAdapter, int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.a;
      b1.w = param1ListAdapter;
      b1.x = param1OnClickListener;
      b1.I = param1Int;
      b1.H = true;
      return this;
    }
    
    public a h(CharSequence param1CharSequence) {
      this.a.f = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */