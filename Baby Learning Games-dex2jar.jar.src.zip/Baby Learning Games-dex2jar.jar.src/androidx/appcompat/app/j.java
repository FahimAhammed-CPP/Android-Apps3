package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.e0;
import androidx.appcompat.widget.y0;
import androidx.core.view.w;
import java.util.ArrayList;
import k0.h;

class j extends a {
  final e0 a;
  
  final Window.Callback b;
  
  final f.g c;
  
  boolean d;
  
  private boolean e;
  
  private boolean f;
  
  private ArrayList<a.b> g = new ArrayList<a.b>();
  
  private final Runnable h = new a(this);
  
  private final Toolbar.f i;
  
  j(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    b b = new b(this);
    this.i = b;
    h.f(paramToolbar);
    y0 y0 = new y0(paramToolbar, false);
    this.a = (e0)y0;
    this.b = (Window.Callback)h.f(paramCallback);
    y0.setWindowCallback(paramCallback);
    paramToolbar.setOnMenuItemClickListener(b);
    y0.setWindowTitle(paramCharSequence);
    this.c = new e(this);
  }
  
  private Menu w() {
    if (!this.e) {
      this.a.i(new c(this), new d(this));
      this.e = true;
    } 
    return this.a.q();
  }
  
  public boolean f() {
    return this.a.e();
  }
  
  public boolean g() {
    if (this.a.n()) {
      this.a.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void h(boolean paramBoolean) {
    if (paramBoolean == this.f)
      return; 
    this.f = paramBoolean;
    int k = this.g.size();
    for (int i = 0; i < k; i++)
      ((a.b)this.g.get(i)).a(paramBoolean); 
  }
  
  public int i() {
    return this.a.p();
  }
  
  public Context j() {
    return this.a.getContext();
  }
  
  public boolean k() {
    this.a.l().removeCallbacks(this.h);
    w.g0((View)this.a.l(), this.h);
    return true;
  }
  
  public void l(Configuration paramConfiguration) {
    super.l(paramConfiguration);
  }
  
  void m() {
    this.a.l().removeCallbacks(this.h);
  }
  
  public boolean n(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = w();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean o(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      p(); 
    return true;
  }
  
  public boolean p() {
    return this.a.f();
  }
  
  public void q(boolean paramBoolean) {}
  
  public void r(int paramInt) {
    this.a.s(paramInt);
  }
  
  public void s(Drawable paramDrawable) {
    this.a.x(paramDrawable);
  }
  
  public void t(boolean paramBoolean) {}
  
  public void u(CharSequence paramCharSequence) {
    this.a.setWindowTitle(paramCharSequence);
  }
  
  void x() {
    androidx.appcompat.view.menu.e e;
    null = w();
    if (null instanceof androidx.appcompat.view.menu.e) {
      e = (androidx.appcompat.view.menu.e)null;
    } else {
      e = null;
    } 
    if (e != null)
      e.h0(); 
    try {
      null.clear();
      if (!this.b.onCreatePanelMenu(0, null) || !this.b.onPreparePanel(0, null, null))
        null.clear(); 
      return;
    } finally {
      if (e != null)
        e.g0(); 
    } 
  }
  
  class a implements Runnable {
    a(j this$0) {}
    
    public void run() {
      this.f.x();
    }
  }
  
  class b implements Toolbar.f {
    b(j this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return this.a.b.onMenuItemSelected(0, param1MenuItem);
    }
  }
  
  private final class c implements androidx.appcompat.view.menu.j.a {
    private boolean f;
    
    c(j this$0) {}
    
    public void b(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {
      if (this.f)
        return; 
      this.f = true;
      this.g.a.h();
      this.g.b.onPanelClosed(108, (Menu)param1e);
      this.f = false;
    }
    
    public boolean c(androidx.appcompat.view.menu.e param1e) {
      this.g.b.onMenuOpened(108, (Menu)param1e);
      return true;
    }
  }
  
  private final class d implements androidx.appcompat.view.menu.e.a {
    d(j this$0) {}
    
    public boolean a(androidx.appcompat.view.menu.e param1e, MenuItem param1MenuItem) {
      return false;
    }
    
    public void b(androidx.appcompat.view.menu.e param1e) {
      if (this.f.a.b()) {
        this.f.b.onPanelClosed(108, (Menu)param1e);
        return;
      } 
      if (this.f.b.onPreparePanel(0, null, (Menu)param1e))
        this.f.b.onMenuOpened(108, (Menu)param1e); 
    }
  }
  
  private class e implements f.g {
    e(j this$0) {}
    
    public boolean a(int param1Int) {
      if (param1Int == 0) {
        j j1 = this.a;
        if (!j1.d) {
          j1.a.c();
          this.a.d = true;
        } 
      } 
      return false;
    }
    
    public View onCreatePanelView(int param1Int) {
      return (param1Int == 0) ? new View(this.a.a.getContext()) : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */