package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import e.g;
import java.util.ArrayList;

public class c implements j, AdapterView.OnItemClickListener {
  Context f;
  
  LayoutInflater g;
  
  e h;
  
  ExpandedMenuView i;
  
  int j;
  
  int k;
  
  int l;
  
  private j.a m;
  
  a n;
  
  private int o;
  
  public c(int paramInt1, int paramInt2) {
    this.l = paramInt1;
    this.k = paramInt2;
  }
  
  public c(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.f = paramContext;
    this.g = LayoutInflater.from(paramContext);
  }
  
  public ListAdapter a() {
    if (this.n == null)
      this.n = new a(this); 
    return (ListAdapter)this.n;
  }
  
  public void b(e parame, boolean paramBoolean) {
    j.a a1 = this.m;
    if (a1 != null)
      a1.b(parame, paramBoolean); 
  }
  
  public k c(ViewGroup paramViewGroup) {
    if (this.i == null) {
      this.i = (ExpandedMenuView)this.g.inflate(g.g, paramViewGroup, false);
      if (this.n == null)
        this.n = new a(this); 
      this.i.setAdapter((ListAdapter)this.n);
      this.i.setOnItemClickListener(this);
    } 
    return this.i;
  }
  
  public void d(Context paramContext, e parame) {
    ContextThemeWrapper contextThemeWrapper;
    if (this.k != 0) {
      contextThemeWrapper = new ContextThemeWrapper(paramContext, this.k);
      this.f = (Context)contextThemeWrapper;
      this.g = LayoutInflater.from((Context)contextThemeWrapper);
    } else if (this.f != null) {
      this.f = (Context)contextThemeWrapper;
      if (this.g == null)
        this.g = LayoutInflater.from((Context)contextThemeWrapper); 
    } 
    this.h = parame;
    a a1 = this.n;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public void e(Parcelable paramParcelable) {
    h((Bundle)paramParcelable);
  }
  
  public boolean f(m paramm) {
    if (!paramm.hasVisibleItems())
      return false; 
    (new f(paramm)).d(null);
    j.a a1 = this.m;
    if (a1 != null)
      a1.c(paramm); 
    return true;
  }
  
  public void g(boolean paramBoolean) {
    a a1 = this.n;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public int getId() {
    return this.o;
  }
  
  public void h(Bundle paramBundle) {
    SparseArray sparseArray = paramBundle.getSparseParcelableArray("android:menu:list");
    if (sparseArray != null)
      this.i.restoreHierarchyState(sparseArray); 
  }
  
  public boolean i() {
    return false;
  }
  
  public Parcelable j() {
    if (this.i == null)
      return null; 
    Bundle bundle = new Bundle();
    n(bundle);
    return (Parcelable)bundle;
  }
  
  public boolean k(e parame, g paramg) {
    return false;
  }
  
  public boolean l(e parame, g paramg) {
    return false;
  }
  
  public void m(j.a parama) {
    this.m = parama;
  }
  
  public void n(Bundle paramBundle) {
    SparseArray sparseArray = new SparseArray();
    ExpandedMenuView expandedMenuView = this.i;
    if (expandedMenuView != null)
      expandedMenuView.saveHierarchyState(sparseArray); 
    paramBundle.putSparseParcelableArray("android:menu:list", sparseArray);
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.h.O((MenuItem)this.n.b(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int f = -1;
    
    public a(c this$0) {
      a();
    }
    
    void a() {
      g g = this.g.h.x();
      if (g != null) {
        ArrayList<g> arrayList = this.g.h.B();
        int j = arrayList.size();
        for (int i = 0; i < j; i++) {
          if ((g)arrayList.get(i) == g) {
            this.f = i;
            return;
          } 
        } 
      } 
      this.f = -1;
    }
    
    public g b(int param1Int) {
      ArrayList<g> arrayList = this.g.h.B();
      int i = param1Int + this.g.j;
      int j = this.f;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      int i = this.g.h.B().size() - this.g.j;
      return (this.f < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        c c1 = this.g;
        view = c1.g.inflate(c1.l, param1ViewGroup, false);
      } 
      ((k.a)view).g(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */