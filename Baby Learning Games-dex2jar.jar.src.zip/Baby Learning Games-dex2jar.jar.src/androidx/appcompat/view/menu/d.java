package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class d extends BaseAdapter {
  e f;
  
  private int g = -1;
  
  private boolean h;
  
  private final boolean i;
  
  private final LayoutInflater j;
  
  private final int k;
  
  public d(e parame, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.i = paramBoolean;
    this.j = paramLayoutInflater;
    this.f = parame;
    this.k = paramInt;
    a();
  }
  
  void a() {
    g g = this.f.x();
    if (g != null) {
      ArrayList<g> arrayList = this.f.B();
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        if ((g)arrayList.get(i) == g) {
          this.g = i;
          return;
        } 
      } 
    } 
    this.g = -1;
  }
  
  public e b() {
    return this.f;
  }
  
  public g c(int paramInt) {
    ArrayList<g> arrayList;
    if (this.i) {
      arrayList = this.f.B();
    } else {
      arrayList = this.f.G();
    } 
    int j = this.g;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public void d(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  public int getCount() {
    ArrayList<g> arrayList;
    if (this.i) {
      arrayList = this.f.B();
    } else {
      arrayList = this.f.G();
    } 
    return (this.g < 0) ? arrayList.size() : (arrayList.size() - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.j.inflate(this.k, paramViewGroup, false); 
    int j = c(paramInt).getGroupId();
    int i = paramInt - 1;
    if (i >= 0) {
      i = c(i).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.f.H() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    k.a a = (k.a)view;
    if (this.h)
      listMenuItemView.setForceShowIcon(true); 
    a.g(c(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */