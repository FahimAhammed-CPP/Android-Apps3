package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.w0;
import androidx.core.view.w;
import e.a;
import e.f;
import e.g;
import e.j;

public class ListMenuItemView extends LinearLayout implements k.a, AbsListView.SelectionBoundsAdjuster {
  private g f;
  
  private ImageView g;
  
  private RadioButton h;
  
  private TextView i;
  
  private CheckBox j;
  
  private TextView k;
  
  private ImageView l;
  
  private ImageView m;
  
  private LinearLayout n;
  
  private Drawable o;
  
  private int p;
  
  private Context q;
  
  private boolean r;
  
  private Drawable s;
  
  private boolean t;
  
  private LayoutInflater u;
  
  private boolean v;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.G);
  }
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    w0 w0 = w0.v(getContext(), paramAttributeSet, j.b2, paramInt, 0);
    this.o = w0.g(j.d2);
    this.p = w0.n(j.c2, -1);
    this.r = w0.a(j.e2, false);
    this.q = paramContext;
    this.s = w0.g(j.f2);
    Resources.Theme theme = paramContext.getTheme();
    paramInt = a.C;
    TypedArray typedArray = theme.obtainStyledAttributes(null, new int[] { 16843049 }, paramInt, 0);
    this.t = typedArray.hasValue(0);
    w0.w();
    typedArray.recycle();
  }
  
  private void a(View paramView) {
    b(paramView, -1);
  }
  
  private void b(View paramView, int paramInt) {
    LinearLayout linearLayout = this.n;
    if (linearLayout != null) {
      linearLayout.addView(paramView, paramInt);
      return;
    } 
    addView(paramView, paramInt);
  }
  
  private void c() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(g.h, (ViewGroup)this, false);
    this.j = checkBox;
    a((View)checkBox);
  }
  
  private void d() {
    ImageView imageView = (ImageView)getInflater().inflate(g.i, (ViewGroup)this, false);
    this.g = imageView;
    b((View)imageView, 0);
  }
  
  private void f() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(g.k, (ViewGroup)this, false);
    this.h = radioButton;
    a((View)radioButton);
  }
  
  private LayoutInflater getInflater() {
    if (this.u == null)
      this.u = LayoutInflater.from(getContext()); 
    return this.u;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.l;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.m;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.m.getLayoutParams();
      paramRect.top += this.m.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    } 
  }
  
  public boolean e() {
    return false;
  }
  
  public void g(g paramg, int paramInt) {
    this.f = paramg;
    if (paramg.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(paramg.i(this));
    setCheckable(paramg.isCheckable());
    h(paramg.A(), paramg.g());
    setIcon(paramg.getIcon());
    setEnabled(paramg.isEnabled());
    setSubMenuArrowVisible(paramg.hasSubMenu());
    setContentDescription(paramg.getContentDescription());
  }
  
  public g getItemData() {
    return this.f;
  }
  
  public void h(boolean paramBoolean, char paramChar) {
    if (paramBoolean && this.f.A()) {
      paramChar = Character.MIN_VALUE;
    } else {
      paramChar = '\b';
    } 
    if (paramChar == '\000')
      this.k.setText(this.f.h()); 
    if (this.k.getVisibility() != paramChar)
      this.k.setVisibility(paramChar); 
  }
  
  protected void onFinishInflate() {
    super.onFinishInflate();
    w.s0((View)this, this.o);
    TextView textView = (TextView)findViewById(f.M);
    this.i = textView;
    int i = this.p;
    if (i != -1)
      textView.setTextAppearance(this.q, i); 
    this.k = (TextView)findViewById(f.F);
    ImageView imageView = (ImageView)findViewById(f.I);
    this.l = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.s); 
    this.m = (ImageView)findViewById(f.r);
    this.n = (LinearLayout)findViewById(f.l);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.g != null && this.r) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.g.getLayoutParams();
      int i = layoutParams.height;
      if (i > 0 && layoutParams1.width <= 0)
        layoutParams1.width = i; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.h == null && this.j == null)
      return; 
    if (this.f.m()) {
      if (this.h == null)
        f(); 
      RadioButton radioButton1 = this.h;
      CheckBox checkBox1 = this.j;
    } else {
      if (this.j == null)
        c(); 
      checkBox = this.j;
      radioButton = this.h;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.f.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.j;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.h;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.f.m()) {
      if (this.h == null)
        f(); 
      RadioButton radioButton = this.h;
    } else {
      if (this.j == null)
        c(); 
      checkBox = this.j;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.v = paramBoolean;
    this.r = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.m;
    if (imageView != null) {
      byte b;
      if (!this.t && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    if (this.f.z() || this.v) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.r)
      return; 
    ImageView imageView = this.g;
    if (imageView == null && paramDrawable == null && !this.r)
      return; 
    if (imageView == null)
      d(); 
    if (paramDrawable != null || this.r) {
      imageView = this.g;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.g.getVisibility() != 0)
        this.g.setVisibility(0); 
      return;
    } 
    this.g.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.i.setText(paramCharSequence);
      if (this.i.getVisibility() != 0) {
        this.i.setVisibility(0);
        return;
      } 
    } else if (this.i.getVisibility() != 8) {
      this.i.setVisibility(8);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */