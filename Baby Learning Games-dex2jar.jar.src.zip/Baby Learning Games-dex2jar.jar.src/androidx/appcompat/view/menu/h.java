package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import l.e;

abstract class h implements e, j, AdapterView.OnItemClickListener {
  private Rect f;
  
  protected static d A(ListAdapter paramListAdapter) {
    return (paramListAdapter instanceof HeaderViewListAdapter) ? (d)((HeaderViewListAdapter)paramListAdapter).getWrappedAdapter() : (d)paramListAdapter;
  }
  
  protected static int q(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt) {
    int i = 0;
    int n = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i1 = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i2 = paramListAdapter.getCount();
    int k = 0;
    int m = k;
    ViewGroup viewGroup2 = null;
    ViewGroup viewGroup1 = paramViewGroup;
    paramViewGroup = viewGroup2;
    while (i < i2) {
      FrameLayout frameLayout2;
      int i4 = paramListAdapter.getItemViewType(i);
      int i3 = m;
      if (i4 != m) {
        paramViewGroup = null;
        i3 = i4;
      } 
      viewGroup2 = viewGroup1;
      if (viewGroup1 == null)
        frameLayout2 = new FrameLayout(paramContext); 
      View view = paramListAdapter.getView(i, (View)paramViewGroup, (ViewGroup)frameLayout2);
      view.measure(n, i1);
      i4 = view.getMeasuredWidth();
      if (i4 >= paramInt)
        return paramInt; 
      m = k;
      if (i4 > k)
        m = i4; 
      i++;
      k = m;
      m = i3;
      FrameLayout frameLayout1 = frameLayout2;
    } 
    return k;
  }
  
  protected static boolean z(e parame) {
    int k = parame.size();
    for (int i = 0; i < k; i++) {
      MenuItem menuItem = parame.getItem(i);
      if (menuItem.isVisible() && menuItem.getIcon() != null)
        return true; 
    } 
    return false;
  }
  
  public void d(Context paramContext, e parame) {}
  
  public int getId() {
    return 0;
  }
  
  public boolean k(e parame, g paramg) {
    return false;
  }
  
  public boolean l(e parame, g paramg) {
    return false;
  }
  
  public abstract void n(e parame);
  
  protected boolean o() {
    return true;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ListAdapter listAdapter = (ListAdapter)paramAdapterView.getAdapter();
    e e1 = (A(listAdapter)).f;
    MenuItem menuItem = (MenuItem)listAdapter.getItem(paramInt);
    if (o()) {
      paramInt = 0;
    } else {
      paramInt = 4;
    } 
    e1.O(menuItem, this, paramInt);
  }
  
  public Rect p() {
    return this.f;
  }
  
  public abstract void r(View paramView);
  
  public void s(Rect paramRect) {
    this.f = paramRect;
  }
  
  public abstract void t(boolean paramBoolean);
  
  public abstract void u(int paramInt);
  
  public abstract void v(int paramInt);
  
  public abstract void w(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public abstract void x(boolean paramBoolean);
  
  public abstract void y(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */