package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Parcelable;

public interface j {
  void b(e parame, boolean paramBoolean);
  
  void d(Context paramContext, e parame);
  
  void e(Parcelable paramParcelable);
  
  boolean f(m paramm);
  
  void g(boolean paramBoolean);
  
  int getId();
  
  boolean i();
  
  Parcelable j();
  
  boolean k(e parame, g paramg);
  
  boolean l(e parame, g paramg);
  
  void m(a parama);
  
  public static interface a {
    void b(e param1e, boolean param1Boolean);
    
    boolean c(e param1e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */