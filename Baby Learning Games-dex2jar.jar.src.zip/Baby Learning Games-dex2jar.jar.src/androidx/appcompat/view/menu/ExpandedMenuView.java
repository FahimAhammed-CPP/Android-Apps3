package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.widget.w0;

public final class ExpandedMenuView extends ListView implements e.b, k, AdapterView.OnItemClickListener {
  private static final int[] h = new int[] { 16842964, 16843049 };
  
  private e f;
  
  private int g;
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842868);
  }
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    setOnItemClickListener(this);
    w0 w0 = w0.v(paramContext, paramAttributeSet, h, paramInt, 0);
    if (w0.s(0))
      setBackgroundDrawable(w0.g(0)); 
    if (w0.s(1))
      setDivider(w0.g(1)); 
    w0.w();
  }
  
  public boolean a(g paramg) {
    return this.f.N((MenuItem)paramg, 0);
  }
  
  public void b(e parame) {
    this.f = parame;
  }
  
  public int getWindowAnimations() {
    return this.g;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    setChildrenDrawingCacheEnabled(false);
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    a((g)getAdapter().getItem(paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\ExpandedMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */