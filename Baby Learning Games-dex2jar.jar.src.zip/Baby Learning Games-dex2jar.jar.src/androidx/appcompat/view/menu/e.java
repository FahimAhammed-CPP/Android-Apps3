package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.core.view.y;
import e0.a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class e implements a {
  private static final int[] A = new int[] { 1, 4, 5, 3, 2, 0 };
  
  private final Context a;
  
  private final Resources b;
  
  private boolean c;
  
  private boolean d;
  
  private a e;
  
  private ArrayList<g> f;
  
  private ArrayList<g> g;
  
  private boolean h;
  
  private ArrayList<g> i;
  
  private ArrayList<g> j;
  
  private boolean k;
  
  private int l = 0;
  
  private ContextMenu.ContextMenuInfo m;
  
  CharSequence n;
  
  Drawable o;
  
  View p;
  
  private boolean q = false;
  
  private boolean r = false;
  
  private boolean s = false;
  
  private boolean t = false;
  
  private boolean u = false;
  
  private ArrayList<g> v = new ArrayList<g>();
  
  private CopyOnWriteArrayList<WeakReference<j>> w = new CopyOnWriteArrayList<WeakReference<j>>();
  
  private g x;
  
  private boolean y = false;
  
  private boolean z;
  
  public e(Context paramContext) {
    this.a = paramContext;
    this.b = paramContext.getResources();
    this.f = new ArrayList<g>();
    this.g = new ArrayList<g>();
    this.h = true;
    this.i = new ArrayList<g>();
    this.j = new ArrayList<g>();
    this.k = true;
    f0(true);
  }
  
  private static int D(int paramInt) {
    int i = (0xFFFF0000 & paramInt) >> 16;
    if (i >= 0) {
      int[] arrayOfInt = A;
      if (i < arrayOfInt.length)
        return paramInt & 0xFFFF | arrayOfInt[i] << 16; 
    } 
    throw new IllegalArgumentException("order does not contain a valid category.");
  }
  
  private void P(int paramInt, boolean paramBoolean) {
    if (paramInt >= 0) {
      if (paramInt >= this.f.size())
        return; 
      this.f.remove(paramInt);
      if (paramBoolean)
        M(true); 
    } 
  }
  
  private void a0(int paramInt1, CharSequence paramCharSequence, int paramInt2, Drawable paramDrawable, View paramView) {
    Resources resources = E();
    if (paramView != null) {
      this.p = paramView;
      this.n = null;
      this.o = null;
    } else {
      if (paramInt1 > 0) {
        this.n = resources.getText(paramInt1);
      } else if (paramCharSequence != null) {
        this.n = paramCharSequence;
      } 
      if (paramInt2 > 0) {
        this.o = androidx.core.content.a.c(w(), paramInt2);
      } else if (paramDrawable != null) {
        this.o = paramDrawable;
      } 
      this.p = null;
    } 
    M(false);
  }
  
  private void f0(boolean paramBoolean) {
    boolean bool = true;
    if (paramBoolean && (this.b.getConfiguration()).keyboard != 1 && y.e(ViewConfiguration.get(this.a), this.a)) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    this.d = paramBoolean;
  }
  
  private g g(int paramInt1, int paramInt2, int paramInt3, int paramInt4, CharSequence paramCharSequence, int paramInt5) {
    return new g(this, paramInt1, paramInt2, paramInt3, paramInt4, paramCharSequence, paramInt5);
  }
  
  private void i(boolean paramBoolean) {
    if (this.w.isEmpty())
      return; 
    h0();
    for (WeakReference<j> weakReference : this.w) {
      j j = weakReference.get();
      if (j == null) {
        this.w.remove(weakReference);
        continue;
      } 
      j.g(paramBoolean);
    } 
    g0();
  }
  
  private void j(Bundle paramBundle) {
    SparseArray sparseArray = paramBundle.getSparseParcelableArray("android:menu:presenters");
    if (sparseArray != null) {
      if (this.w.isEmpty())
        return; 
      for (WeakReference<j> weakReference : this.w) {
        j j = weakReference.get();
        if (j == null) {
          this.w.remove(weakReference);
          continue;
        } 
        int i = j.getId();
        if (i > 0) {
          Parcelable parcelable = (Parcelable)sparseArray.get(i);
          if (parcelable != null)
            j.e(parcelable); 
        } 
      } 
    } 
  }
  
  private void k(Bundle paramBundle) {
    if (this.w.isEmpty())
      return; 
    SparseArray sparseArray = new SparseArray();
    for (WeakReference<j> weakReference : this.w) {
      j j = weakReference.get();
      if (j == null) {
        this.w.remove(weakReference);
        continue;
      } 
      int i = j.getId();
      if (i > 0) {
        Parcelable parcelable = j.j();
        if (parcelable != null)
          sparseArray.put(i, parcelable); 
      } 
    } 
    paramBundle.putSparseParcelableArray("android:menu:presenters", sparseArray);
  }
  
  private boolean l(m paramm, j paramj) {
    boolean bool2 = this.w.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    if (paramj != null)
      bool1 = paramj.f(paramm); 
    for (WeakReference<j> weakReference : this.w) {
      j j1 = weakReference.get();
      if (j1 == null) {
        this.w.remove(weakReference);
        continue;
      } 
      if (!bool1)
        bool1 = j1.f(paramm); 
    } 
    return bool1;
  }
  
  private static int p(ArrayList<g> paramArrayList, int paramInt) {
    for (int i = paramArrayList.size() - 1; i >= 0; i--) {
      if (((g)paramArrayList.get(i)).f() <= paramInt)
        return i + 1; 
    } 
    return 0;
  }
  
  public View A() {
    return this.p;
  }
  
  public ArrayList<g> B() {
    t();
    return this.j;
  }
  
  boolean C() {
    return this.t;
  }
  
  Resources E() {
    return this.b;
  }
  
  public e F() {
    return this;
  }
  
  public ArrayList<g> G() {
    if (!this.h)
      return this.g; 
    this.g.clear();
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.isVisible())
        this.g.add(g1); 
    } 
    this.h = false;
    this.k = true;
    return this.g;
  }
  
  public boolean H() {
    return this.y;
  }
  
  boolean I() {
    return this.c;
  }
  
  public boolean J() {
    return this.d;
  }
  
  void K(g paramg) {
    this.k = true;
    M(true);
  }
  
  void L(g paramg) {
    this.h = true;
    M(true);
  }
  
  public void M(boolean paramBoolean) {
    if (!this.q) {
      if (paramBoolean) {
        this.h = true;
        this.k = true;
      } 
      i(paramBoolean);
      return;
    } 
    this.r = true;
    if (paramBoolean)
      this.s = true; 
  }
  
  public boolean N(MenuItem paramMenuItem, int paramInt) {
    return O(paramMenuItem, null, paramInt);
  }
  
  public boolean O(MenuItem paramMenuItem, j paramj, int paramInt) {
    g g1 = (g)paramMenuItem;
    if (g1 != null) {
      boolean bool;
      boolean bool1;
      if (!g1.isEnabled())
        return false; 
      boolean bool2 = g1.k();
      androidx.core.view.b b = g1.b();
      if (b != null && b.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (g1.j()) {
        bool2 |= g1.expandActionView();
        bool1 = bool2;
        if (bool2) {
          e(true);
          return bool2;
        } 
      } else {
        if (g1.hasSubMenu() || bool) {
          if ((paramInt & 0x4) == 0)
            e(false); 
          if (!g1.hasSubMenu())
            g1.x(new m(w(), this, g1)); 
          m m = (m)g1.getSubMenu();
          if (bool)
            b.f(m); 
          bool2 |= l(m, paramj);
          boolean bool3 = bool2;
          if (!bool2) {
            e(true);
            bool3 = bool2;
          } 
          return bool3;
        } 
        bool1 = bool2;
        if ((paramInt & 0x1) == 0) {
          e(true);
          return bool2;
        } 
      } 
      return bool1;
    } 
    return false;
  }
  
  public void Q(j paramj) {
    for (WeakReference<j> weakReference : this.w) {
      j j1 = weakReference.get();
      if (j1 == null || j1 == paramj)
        this.w.remove(weakReference); 
    } 
  }
  
  public void R(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    SparseArray sparseArray = paramBundle.getSparseParcelableArray(v());
    int j = size();
    int i;
    for (i = 0; i < j; i++) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      if (view != null && view.getId() != -1)
        view.restoreHierarchyState(sparseArray); 
      if (menuItem.hasSubMenu())
        ((m)menuItem.getSubMenu()).R(paramBundle); 
    } 
    i = paramBundle.getInt("android:menu:expandedactionview");
    if (i > 0) {
      MenuItem menuItem = findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
  }
  
  public void S(Bundle paramBundle) {
    j(paramBundle);
  }
  
  public void T(Bundle paramBundle) {
    int j = size();
    SparseArray sparseArray = null;
    int i = 0;
    while (i < j) {
      MenuItem menuItem = getItem(i);
      View view = menuItem.getActionView();
      SparseArray sparseArray1 = sparseArray;
      if (view != null) {
        sparseArray1 = sparseArray;
        if (view.getId() != -1) {
          SparseArray sparseArray2 = sparseArray;
          if (sparseArray == null)
            sparseArray2 = new SparseArray(); 
          view.saveHierarchyState(sparseArray2);
          sparseArray1 = sparseArray2;
          if (menuItem.isActionViewExpanded()) {
            paramBundle.putInt("android:menu:expandedactionview", menuItem.getItemId());
            sparseArray1 = sparseArray2;
          } 
        } 
      } 
      if (menuItem.hasSubMenu())
        ((m)menuItem.getSubMenu()).T(paramBundle); 
      i++;
      sparseArray = sparseArray1;
    } 
    if (sparseArray != null)
      paramBundle.putSparseParcelableArray(v(), sparseArray); 
  }
  
  public void U(Bundle paramBundle) {
    k(paramBundle);
  }
  
  public void V(a parama) {
    this.e = parama;
  }
  
  public e W(int paramInt) {
    this.l = paramInt;
    return this;
  }
  
  void X(MenuItem paramMenuItem) {
    int j = paramMenuItem.getGroupId();
    int k = this.f.size();
    h0();
    for (int i = 0; i < k; i++) {
      g g1 = this.f.get(i);
      if (g1.getGroupId() == j && g1.m() && g1.isCheckable()) {
        boolean bool;
        if (g1 == paramMenuItem) {
          bool = true;
        } else {
          bool = false;
        } 
        g1.s(bool);
      } 
    } 
    g0();
  }
  
  protected e Y(int paramInt) {
    a0(0, null, paramInt, null, null);
    return this;
  }
  
  protected e Z(Drawable paramDrawable) {
    a0(0, null, 0, paramDrawable, null);
    return this;
  }
  
  protected MenuItem a(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    int i = D(paramInt3);
    g g1 = g(paramInt1, paramInt2, paramInt3, i, paramCharSequence, this.l);
    ContextMenu.ContextMenuInfo contextMenuInfo = this.m;
    if (contextMenuInfo != null)
      g1.v(contextMenuInfo); 
    ArrayList<g> arrayList = this.f;
    arrayList.add(p(arrayList, i), g1);
    M(true);
    return (MenuItem)g1;
  }
  
  public MenuItem add(int paramInt) {
    return a(0, 0, 0, this.b.getString(paramInt));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return a(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return a(paramInt1, paramInt2, paramInt3, paramCharSequence);
  }
  
  public MenuItem add(CharSequence paramCharSequence) {
    return a(0, 0, 0, paramCharSequence);
  }
  
  public int addIntentOptions(int paramInt1, int paramInt2, int paramInt3, ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt4, MenuItem[] paramArrayOfMenuItem) {
    byte b1;
    PackageManager packageManager = this.a.getPackageManager();
    byte b2 = 0;
    List<ResolveInfo> list = packageManager.queryIntentActivityOptions(paramComponentName, paramArrayOfIntent, paramIntent, 0);
    if (list != null) {
      b1 = list.size();
    } else {
      b1 = 0;
    } 
    int i = b2;
    if ((paramInt4 & 0x1) == 0) {
      removeGroup(paramInt1);
      i = b2;
    } 
    while (i < b1) {
      ResolveInfo resolveInfo = list.get(i);
      paramInt4 = resolveInfo.specificIndex;
      if (paramInt4 < 0) {
        intent = paramIntent;
      } else {
        intent = paramArrayOfIntent[paramInt4];
      } 
      Intent intent = new Intent(intent);
      ActivityInfo activityInfo = resolveInfo.activityInfo;
      intent.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
      MenuItem menuItem = add(paramInt1, paramInt2, paramInt3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent);
      if (paramArrayOfMenuItem != null) {
        paramInt4 = resolveInfo.specificIndex;
        if (paramInt4 >= 0)
          paramArrayOfMenuItem[paramInt4] = menuItem; 
      } 
      i++;
    } 
    return b1;
  }
  
  public SubMenu addSubMenu(int paramInt) {
    return addSubMenu(0, 0, 0, this.b.getString(paramInt));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return addSubMenu(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    g g1 = (g)a(paramInt1, paramInt2, paramInt3, paramCharSequence);
    m m = new m(this.a, this, g1);
    g1.x(m);
    return m;
  }
  
  public SubMenu addSubMenu(CharSequence paramCharSequence) {
    return addSubMenu(0, 0, 0, paramCharSequence);
  }
  
  public void b(j paramj) {
    c(paramj, this.a);
  }
  
  protected e b0(int paramInt) {
    a0(paramInt, null, 0, null, null);
    return this;
  }
  
  public void c(j paramj, Context paramContext) {
    this.w.add(new WeakReference<j>(paramj));
    paramj.d(paramContext, this);
    this.k = true;
  }
  
  protected e c0(CharSequence paramCharSequence) {
    a0(0, paramCharSequence, 0, null, null);
    return this;
  }
  
  public void clear() {
    g g1 = this.x;
    if (g1 != null)
      f(g1); 
    this.f.clear();
    M(true);
  }
  
  public void clearHeader() {
    this.o = null;
    this.n = null;
    this.p = null;
    M(false);
  }
  
  public void close() {
    e(true);
  }
  
  public void d() {
    a a1 = this.e;
    if (a1 != null)
      a1.b(this); 
  }
  
  protected e d0(View paramView) {
    a0(0, null, 0, null, paramView);
    return this;
  }
  
  public final void e(boolean paramBoolean) {
    if (this.u)
      return; 
    this.u = true;
    for (WeakReference<j> weakReference : this.w) {
      j j = weakReference.get();
      if (j == null) {
        this.w.remove(weakReference);
        continue;
      } 
      j.b(this, paramBoolean);
    } 
    this.u = false;
  }
  
  public void e0(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public boolean f(g paramg) {
    boolean bool3 = this.w.isEmpty();
    boolean bool1 = false;
    boolean bool2 = false;
    if (!bool3) {
      if (this.x != paramg)
        return false; 
      h0();
      Iterator<WeakReference<j>> iterator = this.w.iterator();
      bool1 = bool2;
      while (true) {
        bool2 = bool1;
        if (iterator.hasNext()) {
          WeakReference<j> weakReference = iterator.next();
          j j = weakReference.get();
          if (j == null) {
            this.w.remove(weakReference);
            continue;
          } 
          bool2 = j.k(this, paramg);
          bool1 = bool2;
          if (bool2)
            break; 
          continue;
        } 
        break;
      } 
      g0();
      bool1 = bool2;
      if (bool2) {
        this.x = null;
        bool1 = bool2;
      } 
    } 
    return bool1;
  }
  
  public MenuItem findItem(int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.getItemId() == paramInt)
        return (MenuItem)g1; 
      if (g1.hasSubMenu()) {
        MenuItem menuItem = g1.getSubMenu().findItem(paramInt);
        if (menuItem != null)
          return menuItem; 
      } 
    } 
    return null;
  }
  
  public void g0() {
    this.q = false;
    if (this.r) {
      this.r = false;
      M(this.s);
    } 
  }
  
  public MenuItem getItem(int paramInt) {
    return (MenuItem)this.f.get(paramInt);
  }
  
  boolean h(e parame, MenuItem paramMenuItem) {
    a a1 = this.e;
    return (a1 != null && a1.a(parame, paramMenuItem));
  }
  
  public void h0() {
    if (!this.q) {
      this.q = true;
      this.r = false;
      this.s = false;
    } 
  }
  
  public boolean hasVisibleItems() {
    if (this.z)
      return true; 
    int j = size();
    for (int i = 0; i < j; i++) {
      if (((g)this.f.get(i)).isVisible())
        return true; 
    } 
    return false;
  }
  
  public boolean isShortcutKey(int paramInt, KeyEvent paramKeyEvent) {
    return (r(paramInt, paramKeyEvent) != null);
  }
  
  public boolean m(g paramg) {
    boolean bool2 = this.w.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    h0();
    Iterator<WeakReference<j>> iterator = this.w.iterator();
    while (true) {
      bool2 = bool1;
      if (iterator.hasNext()) {
        WeakReference<j> weakReference = iterator.next();
        j j = weakReference.get();
        if (j == null) {
          this.w.remove(weakReference);
          continue;
        } 
        bool2 = j.l(this, paramg);
        bool1 = bool2;
        if (bool2)
          break; 
        continue;
      } 
      break;
    } 
    g0();
    if (bool2)
      this.x = paramg; 
    return bool2;
  }
  
  public int n(int paramInt) {
    return o(paramInt, 0);
  }
  
  public int o(int paramInt1, int paramInt2) {
    int j = size();
    int i = paramInt2;
    if (paramInt2 < 0)
      i = 0; 
    while (i < j) {
      if (((g)this.f.get(i)).getGroupId() == paramInt1)
        return i; 
      i++;
    } 
    return -1;
  }
  
  public boolean performIdentifierAction(int paramInt1, int paramInt2) {
    return N(findItem(paramInt1), paramInt2);
  }
  
  public boolean performShortcut(int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    boolean bool;
    g g1 = r(paramInt1, paramKeyEvent);
    if (g1 != null) {
      bool = N((MenuItem)g1, paramInt2);
    } else {
      bool = false;
    } 
    if ((paramInt2 & 0x2) != 0)
      e(true); 
    return bool;
  }
  
  public int q(int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++) {
      if (((g)this.f.get(i)).getItemId() == paramInt)
        return i; 
    } 
    return -1;
  }
  
  g r(int paramInt, KeyEvent paramKeyEvent) {
    ArrayList<g> arrayList = this.v;
    arrayList.clear();
    s(arrayList, paramInt, paramKeyEvent);
    if (arrayList.isEmpty())
      return null; 
    int j = paramKeyEvent.getMetaState();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    paramKeyEvent.getKeyData(keyData);
    int k = arrayList.size();
    if (k == 1)
      return arrayList.get(0); 
    boolean bool = I();
    for (int i = 0; i < k; i++) {
      char c;
      g g1 = arrayList.get(i);
      if (bool) {
        c = g1.getAlphabeticShortcut();
      } else {
        c = g1.getNumericShortcut();
      } 
      char[] arrayOfChar = keyData.meta;
      if ((c == arrayOfChar[0] && (j & 0x2) == 0) || (c == arrayOfChar[2] && (j & 0x2) != 0) || (bool && c == '\b' && paramInt == 67))
        return g1; 
    } 
    return null;
  }
  
  public void removeGroup(int paramInt) {
    int i = n(paramInt);
    if (i >= 0) {
      int k = this.f.size();
      for (int j = 0; j < k - i && ((g)this.f.get(i)).getGroupId() == paramInt; j++)
        P(i, false); 
      M(true);
    } 
  }
  
  public void removeItem(int paramInt) {
    P(q(paramInt), true);
  }
  
  void s(List<g> paramList, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = I();
    int j = paramKeyEvent.getModifiers();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    if (!paramKeyEvent.getKeyData(keyData) && paramInt != 67)
      return; 
    int k = this.f.size();
    int i;
    for (i = 0; i < k; i++) {
      char c;
      int m;
      g g1 = this.f.get(i);
      if (g1.hasSubMenu())
        ((e)g1.getSubMenu()).s(paramList, paramInt, paramKeyEvent); 
      if (bool) {
        c = g1.getAlphabeticShortcut();
      } else {
        c = g1.getNumericShortcut();
      } 
      if (bool) {
        m = g1.getAlphabeticModifiers();
      } else {
        m = g1.getNumericModifiers();
      } 
      if ((j & 0x1100F) == (m & 0x1100F)) {
        m = 1;
      } else {
        m = 0;
      } 
      if (m != 0 && c != '\000') {
        char[] arrayOfChar = keyData.meta;
        if ((c == arrayOfChar[0] || c == arrayOfChar[2] || (bool && c == '\b' && paramInt == 67)) && g1.isEnabled())
          paramList.add(g1); 
      } 
    } 
  }
  
  public void setGroupCheckable(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    int j = this.f.size();
    int i;
    for (i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.getGroupId() == paramInt) {
        g1.t(paramBoolean2);
        g1.setCheckable(paramBoolean1);
      } 
    } 
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void setGroupEnabled(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    for (int i = 0; i < j; i++) {
      g g1 = this.f.get(i);
      if (g1.getGroupId() == paramInt)
        g1.setEnabled(paramBoolean); 
    } 
  }
  
  public void setGroupVisible(int paramInt, boolean paramBoolean) {
    int j = this.f.size();
    int i = 0;
    boolean bool;
    for (bool = false; i < j; bool = bool1) {
      g g1 = this.f.get(i);
      boolean bool1 = bool;
      if (g1.getGroupId() == paramInt) {
        bool1 = bool;
        if (g1.y(paramBoolean))
          bool1 = true; 
      } 
      i++;
    } 
    if (bool)
      M(true); 
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.c = paramBoolean;
    M(false);
  }
  
  public int size() {
    return this.f.size();
  }
  
  public void t() {
    ArrayList<g> arrayList = G();
    if (!this.k)
      return; 
    Iterator<WeakReference<j>> iterator = this.w.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= j.i()) {
      WeakReference<j> weakReference = iterator.next();
      j j = weakReference.get();
      if (j == null) {
        this.w.remove(weakReference);
        continue;
      } 
    } 
    if (bool) {
      this.i.clear();
      this.j.clear();
      int i = arrayList.size();
      bool = false;
      while (bool < i) {
        g g1 = arrayList.get(bool);
        if (g1.l()) {
          this.i.add(g1);
        } else {
          this.j.add(g1);
        } 
        int j = bool + 1;
      } 
    } else {
      this.i.clear();
      this.j.clear();
      this.j.addAll(G());
    } 
    this.k = false;
  }
  
  public ArrayList<g> u() {
    t();
    return this.i;
  }
  
  protected String v() {
    return "android:menu:actionviewstates";
  }
  
  public Context w() {
    return this.a;
  }
  
  public g x() {
    return this.x;
  }
  
  public Drawable y() {
    return this.o;
  }
  
  public CharSequence z() {
    return this.n;
  }
  
  public static interface a {
    boolean a(e param1e, MenuItem param1MenuItem);
    
    void b(e param1e);
  }
  
  public static interface b {
    boolean a(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */