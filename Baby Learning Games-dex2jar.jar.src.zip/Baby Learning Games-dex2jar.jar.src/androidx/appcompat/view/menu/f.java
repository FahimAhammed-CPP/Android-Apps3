package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.c;
import e.g;

class f implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, j.a {
  private e f;
  
  private c g;
  
  c h;
  
  private j.a i;
  
  public f(e parame) {
    this.f = parame;
  }
  
  public void a() {
    c c1 = this.g;
    if (c1 != null)
      c1.dismiss(); 
  }
  
  public void b(e parame, boolean paramBoolean) {
    if (paramBoolean || parame == this.f)
      a(); 
    j.a a1 = this.i;
    if (a1 != null)
      a1.b(parame, paramBoolean); 
  }
  
  public boolean c(e parame) {
    j.a a1 = this.i;
    return (a1 != null) ? a1.c(parame) : false;
  }
  
  public void d(IBinder paramIBinder) {
    e e1 = this.f;
    c.a a1 = new c.a(e1.w());
    c c2 = new c(a1.b(), g.j);
    this.h = c2;
    c2.m(this);
    this.f.b(this.h);
    a1.c(this.h.a(), this);
    View view = e1.A();
    if (view != null) {
      a1.d(view);
    } else {
      a1.e(e1.y()).h(e1.z());
    } 
    a1.f(this);
    c c1 = a1.a();
    this.g = c1;
    c1.setOnDismissListener(this);
    WindowManager.LayoutParams layoutParams = this.g.getWindow().getAttributes();
    layoutParams.type = 1003;
    if (paramIBinder != null)
      layoutParams.token = paramIBinder; 
    layoutParams.flags |= 0x20000;
    this.g.show();
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.f.N((MenuItem)this.h.a().getItem(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    this.h.b(this.f, true);
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.g.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.g.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.f.e(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.f.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */