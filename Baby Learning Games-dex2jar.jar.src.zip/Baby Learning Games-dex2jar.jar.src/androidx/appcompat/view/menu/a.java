package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class a implements j {
  protected Context f;
  
  protected Context g;
  
  protected e h;
  
  protected LayoutInflater i;
  
  protected LayoutInflater j;
  
  private j.a k;
  
  private int l;
  
  private int m;
  
  protected k n;
  
  private int o;
  
  public a(Context paramContext, int paramInt1, int paramInt2) {
    this.f = paramContext;
    this.i = LayoutInflater.from(paramContext);
    this.l = paramInt1;
    this.m = paramInt2;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.n).addView(paramView, paramInt);
  }
  
  public void b(e parame, boolean paramBoolean) {
    j.a a1 = this.k;
    if (a1 != null)
      a1.b(parame, paramBoolean); 
  }
  
  public abstract void c(g paramg, k.a parama);
  
  public void d(Context paramContext, e parame) {
    this.g = paramContext;
    this.j = LayoutInflater.from(paramContext);
    this.h = parame;
  }
  
  public boolean f(m paramm) {
    j.a a1 = this.k;
    if (a1 != null) {
      e e1;
      if (paramm == null)
        e1 = this.h; 
      return a1.c(e1);
    } 
    return false;
  }
  
  public void g(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.n;
    if (viewGroup == null)
      return; 
    e e1 = this.h;
    int i = 0;
    if (e1 != null) {
      e1.t();
      ArrayList<g> arrayList = this.h.G();
      int n = arrayList.size();
      int m = 0;
      for (i = m; m < n; i = i1) {
        g g = arrayList.get(m);
        int i1 = i;
        if (s(i, g)) {
          View view1 = viewGroup.getChildAt(i);
          if (view1 instanceof k.a) {
            g g1 = ((k.a)view1).getItemData();
          } else {
            e1 = null;
          } 
          View view2 = p(g, view1, viewGroup);
          if (g != e1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            a(view2, i); 
          i1 = i + 1;
        } 
        m++;
      } 
    } 
    while (i < viewGroup.getChildCount()) {
      if (!n(viewGroup, i))
        i++; 
    } 
  }
  
  public int getId() {
    return this.o;
  }
  
  public k.a h(ViewGroup paramViewGroup) {
    return (k.a)this.i.inflate(this.m, paramViewGroup, false);
  }
  
  public boolean k(e parame, g paramg) {
    return false;
  }
  
  public boolean l(e parame, g paramg) {
    return false;
  }
  
  public void m(j.a parama) {
    this.k = parama;
  }
  
  protected boolean n(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public j.a o() {
    return this.k;
  }
  
  public View p(g paramg, View paramView, ViewGroup paramViewGroup) {
    k.a a1;
    if (paramView instanceof k.a) {
      a1 = (k.a)paramView;
    } else {
      a1 = h(paramViewGroup);
    } 
    c(paramg, a1);
    return (View)a1;
  }
  
  public k q(ViewGroup paramViewGroup) {
    if (this.n == null) {
      k k1 = (k)this.i.inflate(this.l, paramViewGroup, false);
      this.n = k1;
      k1.b(this.h);
      g(true);
    } 
    return this.n;
  }
  
  public void r(int paramInt) {
    this.o = paramInt;
  }
  
  public abstract boolean s(int paramInt, g paramg);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */