package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.l0;
import androidx.core.view.w;
import e.d;
import e.g;

final class l extends h implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int A = g.m;
  
  private final Context g;
  
  private final e h;
  
  private final d i;
  
  private final boolean j;
  
  private final int k;
  
  private final int l;
  
  private final int m;
  
  final l0 n;
  
  final ViewTreeObserver.OnGlobalLayoutListener o = new a(this);
  
  private final View.OnAttachStateChangeListener p = new b(this);
  
  private PopupWindow.OnDismissListener q;
  
  private View r;
  
  View s;
  
  private j.a t;
  
  ViewTreeObserver u;
  
  private boolean v;
  
  private boolean w;
  
  private int x;
  
  private int y = 0;
  
  private boolean z;
  
  public l(Context paramContext, e parame, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.g = paramContext;
    this.h = parame;
    this.j = paramBoolean;
    this.i = new d(parame, LayoutInflater.from(paramContext), paramBoolean, A);
    this.l = paramInt1;
    this.m = paramInt2;
    Resources resources = paramContext.getResources();
    this.k = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.r = paramView;
    this.n = new l0(paramContext, null, paramInt1, paramInt2);
    parame.c(this, paramContext);
  }
  
  private boolean B() {
    if (c())
      return true; 
    if (!this.v) {
      boolean bool;
      View view = this.r;
      if (view == null)
        return false; 
      this.s = view;
      this.n.K(this);
      this.n.L(this);
      this.n.J(true);
      view = this.s;
      if (this.u == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.u = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.o); 
      view.addOnAttachStateChangeListener(this.p);
      this.n.D(view);
      this.n.G(this.y);
      if (!this.w) {
        this.x = h.q((ListAdapter)this.i, null, this.g, this.k);
        this.w = true;
      } 
      this.n.F(this.x);
      this.n.I(2);
      this.n.H(p());
      this.n.a();
      ListView listView = this.n.h();
      listView.setOnKeyListener(this);
      if (this.z && this.h.z() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.g).inflate(g.l, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.h.z()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.n.p((ListAdapter)this.i);
      this.n.a();
      return true;
    } 
    return false;
  }
  
  public void a() {
    if (B())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void b(e parame, boolean paramBoolean) {
    if (parame != this.h)
      return; 
    dismiss();
    j.a a1 = this.t;
    if (a1 != null)
      a1.b(parame, paramBoolean); 
  }
  
  public boolean c() {
    return (!this.v && this.n.c());
  }
  
  public void dismiss() {
    if (c())
      this.n.dismiss(); 
  }
  
  public void e(Parcelable paramParcelable) {}
  
  public boolean f(m paramm) {
    if (paramm.hasVisibleItems()) {
      i i1 = new i(this.g, paramm, this.s, this.j, this.l, this.m);
      i1.j(this.t);
      i1.g(h.z(paramm));
      i1.i(this.q);
      this.q = null;
      this.h.e(false);
      int j = this.n.d();
      int k = this.n.n();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.y, w.B(this.r)) & 0x7) == 5)
        i = j + this.r.getWidth(); 
      if (i1.n(i, k)) {
        j.a a1 = this.t;
        if (a1 != null)
          a1.c(paramm); 
        return true;
      } 
    } 
    return false;
  }
  
  public void g(boolean paramBoolean) {
    this.w = false;
    d d1 = this.i;
    if (d1 != null)
      d1.notifyDataSetChanged(); 
  }
  
  public ListView h() {
    return this.n.h();
  }
  
  public boolean i() {
    return false;
  }
  
  public Parcelable j() {
    return null;
  }
  
  public void m(j.a parama) {
    this.t = parama;
  }
  
  public void n(e parame) {}
  
  public void onDismiss() {
    this.v = true;
    this.h.close();
    ViewTreeObserver viewTreeObserver = this.u;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.u = this.s.getViewTreeObserver(); 
      this.u.removeGlobalOnLayoutListener(this.o);
      this.u = null;
    } 
    this.s.removeOnAttachStateChangeListener(this.p);
    PopupWindow.OnDismissListener onDismissListener = this.q;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void r(View paramView) {
    this.r = paramView;
  }
  
  public void t(boolean paramBoolean) {
    this.i.d(paramBoolean);
  }
  
  public void u(int paramInt) {
    this.y = paramInt;
  }
  
  public void v(int paramInt) {
    this.n.l(paramInt);
  }
  
  public void w(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.q = paramOnDismissListener;
  }
  
  public void x(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public void y(int paramInt) {
    this.n.j(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(l this$0) {}
    
    public void onGlobalLayout() {
      if (this.f.c() && !this.f.n.B()) {
        View view = this.f.s;
        if (view == null || !view.isShown()) {
          this.f.dismiss();
          return;
        } 
        this.f.n.a();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(l this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.f.u;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.f.u = param1View.getViewTreeObserver(); 
        l l1 = this.f;
        l1.u.removeGlobalOnLayoutListener(l1.o);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\view\menu\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */