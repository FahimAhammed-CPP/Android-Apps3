package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class p0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  private static final Interpolator o = (Interpolator)new DecelerateInterpolator();
  
  Runnable f;
  
  private c g;
  
  LinearLayoutCompat h;
  
  private Spinner i;
  
  private boolean j;
  
  int k;
  
  int l;
  
  private int m;
  
  private int n;
  
  private Spinner b() {
    y y = new y(getContext(), null, e.a.h);
    y.setLayoutParams((ViewGroup.LayoutParams)new LinearLayoutCompat.a(-2, -1));
    y.setOnItemSelectedListener(this);
    return y;
  }
  
  private boolean d() {
    Spinner spinner = this.i;
    return (spinner != null && spinner.getParent() == this);
  }
  
  private void e() {
    if (d())
      return; 
    if (this.i == null)
      this.i = b(); 
    removeView((View)this.h);
    addView((View)this.i, new ViewGroup.LayoutParams(-2, -1));
    if (this.i.getAdapter() == null)
      this.i.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.f;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.f = null;
    } 
    this.i.setSelection(this.n);
  }
  
  private boolean f() {
    if (!d())
      return false; 
    removeView((View)this.i);
    addView((View)this.h, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.i.getSelectedItemPosition());
    return false;
  }
  
  public void a(int paramInt) {
    View view = this.h.getChildAt(paramInt);
    Runnable runnable = this.f;
    if (runnable != null)
      removeCallbacks(runnable); 
    a a = new a(this, view);
    this.f = a;
    post(a);
  }
  
  d c(androidx.appcompat.app.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.m));
      return d;
    } 
    d.setFocusable(true);
    if (this.g == null)
      this.g = new c(this); 
    d.setOnClickListener(this.g);
    return d;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.f;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    k.a a = k.a.b(getContext());
    setContentHeight(a.f());
    this.l = a.e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.f;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).b().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt2 = 1;
    if (i == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    int j = this.h.getChildCount();
    if (j > 1 && (i == 1073741824 || i == Integer.MIN_VALUE)) {
      if (j > 2) {
        this.k = (int)(View.MeasureSpec.getSize(paramInt1) * 0.4F);
      } else {
        this.k = View.MeasureSpec.getSize(paramInt1) / 2;
      } 
      this.k = Math.min(this.k, this.l);
    } else {
      this.k = -1;
    } 
    i = View.MeasureSpec.makeMeasureSpec(this.m, 1073741824);
    if (bool || !this.j)
      paramInt2 = 0; 
    if (paramInt2 != 0) {
      this.h.measure(0, i);
      if (this.h.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1)) {
        e();
      } else {
        f();
      } 
    } else {
      f();
    } 
    paramInt2 = getMeasuredWidth();
    super.onMeasure(paramInt1, i);
    paramInt1 = getMeasuredWidth();
    if (bool && paramInt2 != paramInt1)
      setTabSelected(this.n); 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.j = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.m = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.n = paramInt;
    int j = this.h.getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      View view = this.h.getChildAt(i);
      if (i == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        a(paramInt); 
    } 
    Spinner spinner = this.i;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  class a implements Runnable {
    a(p0 this$0, View param1View) {}
    
    public void run() {
      int i = this.f.getLeft();
      int j = (this.g.getWidth() - this.f.getWidth()) / 2;
      this.g.smoothScrollTo(i - j, 0);
      this.g.f = null;
    }
  }
  
  private class b extends BaseAdapter {
    b(p0 this$0) {}
    
    public int getCount() {
      return this.f.h.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((p0.d)this.f.h.getChildAt(param1Int)).b();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        return (View)this.f.c((androidx.appcompat.app.a.c)getItem(param1Int), true); 
      ((p0.d)param1View).a((androidx.appcompat.app.a.c)getItem(param1Int));
      return param1View;
    }
  }
  
  private class c implements View.OnClickListener {
    c(p0 this$0) {}
    
    public void onClick(View param1View) {
      ((p0.d)param1View).b().e();
      int j = this.f.h.getChildCount();
      for (int i = 0; i < j; i++) {
        boolean bool;
        View view = this.f.h.getChildAt(i);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] f;
    
    private androidx.appcompat.app.a.c g;
    
    private TextView h;
    
    private ImageView i;
    
    private View j;
    
    public d(p0 this$0, Context param1Context, androidx.appcompat.app.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, i);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 16842964;
      this.f = arrayOfInt;
      this.g = param1c;
      w0 w0 = w0.v(param1Context, null, arrayOfInt, i, 0);
      if (w0.s(0))
        setBackgroundDrawable(w0.g(0)); 
      w0.w();
      if (param1Boolean)
        setGravity(8388627); 
      c();
    }
    
    public void a(androidx.appcompat.app.a.c param1c) {
      this.g = param1c;
      c();
    }
    
    public androidx.appcompat.app.a.c b() {
      return this.g;
    }
    
    public void c() {
      androidx.appcompat.app.a.c c1 = this.g;
      View view = c1.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.j = view;
        TextView textView = this.h;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.i;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.i.setImageDrawable(null);
          return;
        } 
      } else {
        CharSequence charSequence1;
        view = this.j;
        if (view != null) {
          removeView(view);
          this.j = null;
        } 
        Drawable drawable = c1.c();
        CharSequence charSequence2 = c1.d();
        if (drawable != null) {
          if (this.i == null) {
            AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatImageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatImageView, 0);
            this.i = appCompatImageView;
          } 
          this.i.setImageDrawable(drawable);
          this.i.setVisibility(0);
        } else {
          ImageView imageView1 = this.i;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.i.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.h == null) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, e.a.e);
            appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatTextView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatTextView);
            this.h = appCompatTextView;
          } 
          this.h.setText(charSequence2);
          this.h.setVisibility(0);
        } else {
          TextView textView = this.h;
          if (textView != null) {
            textView.setVisibility(8);
            this.h.setText(null);
          } 
        } 
        ImageView imageView = this.i;
        if (imageView != null)
          imageView.setContentDescription(c1.a()); 
        if (i == 0)
          charSequence1 = c1.a(); 
        z0.a((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.k.k > 0) {
        param1Int1 = getMeasuredWidth();
        int i = this.k.k;
        if (param1Int1 > i)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */