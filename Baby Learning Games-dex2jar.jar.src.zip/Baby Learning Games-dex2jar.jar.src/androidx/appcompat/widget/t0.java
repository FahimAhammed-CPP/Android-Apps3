package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class t0 extends ContextWrapper {
  private static final Object c = new Object();
  
  private static ArrayList<WeakReference<t0>> d;
  
  private final Resources a;
  
  private final Resources.Theme b;
  
  private t0(Context paramContext) {
    super(paramContext);
    if (c1.c()) {
      c1 c1 = new c1((Context)this, paramContext.getResources());
      this.a = c1;
      Resources.Theme theme = c1.newTheme();
      this.b = theme;
      theme.setTo(paramContext.getTheme());
      return;
    } 
    this.a = new v0((Context)this, paramContext.getResources());
    this.b = null;
  }
  
  private static boolean a(Context paramContext) {
    boolean bool = paramContext instanceof t0;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      bool1 = bool2;
      if (!(paramContext.getResources() instanceof v0)) {
        if (paramContext.getResources() instanceof c1)
          return false; 
        bool1 = bool2;
        if (c1.c())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public static Context b(Context paramContext) {
    if (a(paramContext))
      synchronized (c) {
        ArrayList<WeakReference<t0>> arrayList = d;
        if (arrayList == null) {
          d = new ArrayList<WeakReference<t0>>();
        } else {
          for (int i = arrayList.size() - 1;; i--) {
            if (i >= 0) {
              WeakReference weakReference = d.get(i);
              if (weakReference == null || weakReference.get() == null)
                d.remove(i); 
            } else {
              for (i = d.size() - 1;; i--) {
                if (i >= 0) {
                  WeakReference<t0> weakReference = d.get(i);
                  if (weakReference != null) {
                    t0 t02 = weakReference.get();
                  } else {
                    weakReference = null;
                  } 
                  if (weakReference != null && weakReference.getBaseContext() == paramContext)
                    return (Context)weakReference; 
                } else {
                  t01 = new t0(paramContext);
                  d.add(new WeakReference<t0>(t01));
                  return (Context)t01;
                } 
              } 
            } 
          } 
          i--;
        } 
        t0 t01 = new t0((Context)t01);
        d.add(new WeakReference<t0>(t01));
        return (Context)t01;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.a.getAssets();
  }
  
  public Resources getResources() {
    return this.a;
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme2 = this.b;
    Resources.Theme theme1 = theme2;
    if (theme2 == null)
      theme1 = super.getTheme(); 
    return theme1;
  }
  
  public void setTheme(int paramInt) {
    Resources.Theme theme = this.b;
    if (theme == null) {
      super.setTheme(paramInt);
      return;
    } 
    theme.applyStyle(paramInt, true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */