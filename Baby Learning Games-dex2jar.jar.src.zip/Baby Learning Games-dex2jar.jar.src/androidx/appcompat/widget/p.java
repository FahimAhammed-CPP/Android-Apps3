package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.core.view.w;
import androidx.core.widget.f;
import e.j;
import g.a;

public class p {
  private final ImageView a;
  
  private u0 b;
  
  private u0 c;
  
  private u0 d;
  
  private int e = 0;
  
  public p(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.d == null)
      this.d = new u0(); 
    u0 u01 = this.d;
    u01.a();
    ColorStateList colorStateList = f.a(this.a);
    if (colorStateList != null) {
      u01.d = true;
      u01.a = colorStateList;
    } 
    PorterDuff.Mode mode = f.b(this.a);
    if (mode != null) {
      u01.c = true;
      u01.b = mode;
    } 
    if (u01.d || u01.c) {
      j.i(paramDrawable, u01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean l() {
    return (this.b != null);
  }
  
  void b() {
    if (this.a.getDrawable() != null)
      this.a.getDrawable().setLevel(this.e); 
  }
  
  void c() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      f0.b(drawable); 
    if (drawable != null) {
      if (l() && a(drawable))
        return; 
      u0 u01 = this.c;
      if (u01 != null) {
        j.i(drawable, u01, this.a.getDrawableState());
        return;
      } 
      u01 = this.b;
      if (u01 != null)
        j.i(drawable, u01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList d() {
    u0 u01 = this.c;
    return (u01 != null) ? u01.a : null;
  }
  
  PorterDuff.Mode e() {
    u0 u01 = this.c;
    return (u01 != null) ? u01.b : null;
  }
  
  boolean f() {
    return !(this.a.getBackground() instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void g(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.P;
    w0 w0 = w0.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    w.m0((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, w0.r(), paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = w0.n(j.Q, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.b(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        f0.b(drawable1); 
      paramInt = j.R;
      if (w0.s(paramInt))
        f.c(this.a, w0.c(paramInt)); 
      paramInt = j.S;
      if (w0.s(paramInt))
        f.d(this.a, f0.e(w0.k(paramInt, -1), null)); 
      return;
    } finally {
      w0.w();
    } 
  }
  
  void h(Drawable paramDrawable) {
    this.e = paramDrawable.getLevel();
  }
  
  public void i(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.b(this.a.getContext(), paramInt);
      if (drawable != null)
        f0.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    c();
  }
  
  void j(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new u0(); 
    u0 u01 = this.c;
    u01.a = paramColorStateList;
    u01.d = true;
    c();
  }
  
  void k(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new u0(); 
    u0 u01 = this.c;
    u01.b = paramMode;
    u01.c = true;
    c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */