package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import e.a;

public class o extends ImageButton {
  private final e f;
  
  private final p g;
  
  private boolean h = false;
  
  public o(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.F);
  }
  
  public o(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(t0.b(paramContext), paramAttributeSet, paramInt);
    r0.a((View)this, getContext());
    e e1 = new e((View)this);
    this.f = e1;
    e1.e(paramAttributeSet, paramInt);
    p p1 = new p((ImageView)this);
    this.g = p1;
    p1.g(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.f;
    if (e1 != null)
      e1.b(); 
    p p1 = this.g;
    if (p1 != null)
      p1.c(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.f;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.f;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    p p1 = this.g;
    return (p1 != null) ? p1.d() : null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    p p1 = this.g;
    return (p1 != null) ? p1.e() : null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.g.f() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.f;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.f;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    p p1 = this.g;
    if (p1 != null)
      p1.c(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    p p2 = this.g;
    if (p2 != null && paramDrawable != null && !this.h)
      p2.h(paramDrawable); 
    super.setImageDrawable(paramDrawable);
    p p1 = this.g;
    if (p1 != null) {
      p1.c();
      if (!this.h)
        this.g.b(); 
    } 
  }
  
  public void setImageLevel(int paramInt) {
    super.setImageLevel(paramInt);
    this.h = true;
  }
  
  public void setImageResource(int paramInt) {
    this.g.i(paramInt);
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    p p1 = this.g;
    if (p1 != null)
      p1.c(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.f;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.f;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    p p1 = this.g;
    if (p1 != null)
      p1.j(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    p p1 = this.g;
    if (p1 != null)
      p1.k(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */