package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.core.view.b0;

public interface e0 {
  void a(Menu paramMenu, j.a parama);
  
  boolean b();
  
  void c();
  
  void collapseActionView();
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  Context getContext();
  
  CharSequence getTitle();
  
  void h();
  
  void i(j.a parama, e.a parama1);
  
  void j(int paramInt);
  
  void k(p0 paramp0);
  
  ViewGroup l();
  
  void m(boolean paramBoolean);
  
  boolean n();
  
  void o(int paramInt);
  
  int p();
  
  Menu q();
  
  void r(int paramInt);
  
  void s(int paramInt);
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
  
  int t();
  
  b0 u(int paramInt, long paramLong);
  
  void v();
  
  void w();
  
  void x(Drawable paramDrawable);
  
  void y(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */