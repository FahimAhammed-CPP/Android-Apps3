package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.core.view.b0;
import androidx.core.widget.g;
import h.c;
import java.lang.reflect.Field;

class g0 extends ListView {
  private final Rect f = new Rect();
  
  private int g = 0;
  
  private int h = 0;
  
  private int i = 0;
  
  private int j = 0;
  
  private int k;
  
  private Field l;
  
  private a m;
  
  private boolean n;
  
  private boolean o;
  
  private boolean p;
  
  private b0 q;
  
  private g r;
  
  b s;
  
  g0(Context paramContext, boolean paramBoolean) {
    super(paramContext, null, e.a.C);
    this.o = paramBoolean;
    setCacheColorHint(0);
    try {
      Field field = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      this.l = field;
      field.setAccessible(true);
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      noSuchFieldException.printStackTrace();
      return;
    } 
  }
  
  private void a() {
    this.p = false;
    setPressed(false);
    drawableStateChanged();
    View view = getChildAt(this.k - getFirstVisiblePosition());
    if (view != null)
      view.setPressed(false); 
    b0 b01 = this.q;
    if (b01 != null) {
      b01.b();
      this.q = null;
    } 
  }
  
  private void b(View paramView, int paramInt) {
    performItemClick(paramView, paramInt, getItemIdAtPosition(paramInt));
  }
  
  private void c(Canvas paramCanvas) {
    if (!this.f.isEmpty()) {
      Drawable drawable = getSelector();
      if (drawable != null) {
        drawable.setBounds(this.f);
        drawable.draw(paramCanvas);
      } 
    } 
  }
  
  private void f(int paramInt, View paramView) {
    Rect rect = this.f;
    rect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    rect.left -= this.g;
    rect.top -= this.h;
    rect.right += this.i;
    rect.bottom += this.j;
    try {
      boolean bool = this.l.getBoolean(this);
      if (paramView.isEnabled() != bool) {
        Field field = this.l;
        if (!bool) {
          bool = true;
        } else {
          bool = false;
        } 
        field.set(this, Boolean.valueOf(bool));
        if (paramInt != -1) {
          refreshDrawableState();
          return;
        } 
      } 
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
    } 
  }
  
  private void g(int paramInt, View paramView) {
    boolean bool1;
    Drawable drawable = getSelector();
    boolean bool2 = true;
    if (drawable != null && paramInt != -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1)
      drawable.setVisible(false, false); 
    f(paramInt, paramView);
    if (bool1) {
      Rect rect = this.f;
      float f1 = rect.exactCenterX();
      float f2 = rect.exactCenterY();
      if (getVisibility() != 0)
        bool2 = false; 
      drawable.setVisible(bool2, false);
      d0.a.k(drawable, f1, f2);
    } 
  }
  
  private void h(int paramInt, View paramView, float paramFloat1, float paramFloat2) {
    g(paramInt, paramView);
    Drawable drawable = getSelector();
    if (drawable != null && paramInt != -1)
      d0.a.k(drawable, paramFloat1, paramFloat2); 
  }
  
  private void i(View paramView, int paramInt, float paramFloat1, float paramFloat2) {
    this.p = true;
    drawableHotspotChanged(paramFloat1, paramFloat2);
    if (!isPressed())
      setPressed(true); 
    layoutChildren();
    int i = this.k;
    if (i != -1) {
      View view = getChildAt(i - getFirstVisiblePosition());
      if (view != null && view != paramView && view.isPressed())
        view.setPressed(false); 
    } 
    this.k = paramInt;
    paramView.drawableHotspotChanged(paramFloat1 - paramView.getLeft(), paramFloat2 - paramView.getTop());
    if (!paramView.isPressed())
      paramView.setPressed(true); 
    h(paramInt, paramView, paramFloat1, paramFloat2);
    setSelectorEnabled(false);
    refreshDrawableState();
  }
  
  private boolean j() {
    return this.p;
  }
  
  private void k() {
    Drawable drawable = getSelector();
    if (drawable != null && j() && isPressed())
      drawable.setState(getDrawableState()); 
  }
  
  private void setSelectorEnabled(boolean paramBoolean) {
    a a1 = this.m;
    if (a1 != null)
      a1.c(paramBoolean); 
  }
  
  public int d(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    paramInt2 = getListPaddingTop();
    paramInt3 = getListPaddingBottom();
    int j = getDividerHeight();
    Drawable drawable = getDivider();
    ListAdapter listAdapter = getAdapter();
    if (listAdapter == null)
      return paramInt2 + paramInt3; 
    paramInt3 = paramInt2 + paramInt3;
    if (j <= 0 || drawable == null)
      j = 0; 
    int n = listAdapter.getCount();
    int k = 0;
    int i = k;
    paramInt2 = i;
    drawable = null;
    int m = i;
    i = k;
    while (i < n) {
      int i1 = listAdapter.getItemViewType(i);
      k = m;
      if (i1 != m) {
        drawable = null;
        k = i1;
      } 
      View view2 = listAdapter.getView(i, (View)drawable, (ViewGroup)this);
      ViewGroup.LayoutParams layoutParams2 = view2.getLayoutParams();
      ViewGroup.LayoutParams layoutParams1 = layoutParams2;
      if (layoutParams2 == null) {
        layoutParams1 = generateDefaultLayoutParams();
        view2.setLayoutParams(layoutParams1);
      } 
      m = layoutParams1.height;
      if (m > 0) {
        m = View.MeasureSpec.makeMeasureSpec(m, 1073741824);
      } else {
        m = View.MeasureSpec.makeMeasureSpec(0, 0);
      } 
      view2.measure(paramInt1, m);
      view2.forceLayout();
      m = paramInt3;
      if (i > 0)
        m = paramInt3 + j; 
      paramInt3 = m + view2.getMeasuredHeight();
      if (paramInt3 >= paramInt4) {
        paramInt1 = paramInt4;
        if (paramInt5 >= 0) {
          paramInt1 = paramInt4;
          if (i > paramInt5) {
            paramInt1 = paramInt4;
            if (paramInt2 > 0) {
              paramInt1 = paramInt4;
              if (paramInt3 != paramInt4)
                paramInt1 = paramInt2; 
            } 
          } 
        } 
        return paramInt1;
      } 
      i1 = paramInt2;
      if (paramInt5 >= 0) {
        i1 = paramInt2;
        if (i >= paramInt5)
          i1 = paramInt3; 
      } 
      i++;
      m = k;
      View view1 = view2;
      paramInt2 = i1;
    } 
    return paramInt3;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    c(paramCanvas);
    super.dispatchDraw(paramCanvas);
  }
  
  protected void drawableStateChanged() {
    if (this.s != null)
      return; 
    super.drawableStateChanged();
    setSelectorEnabled(true);
    k();
  }
  
  public boolean e(MotionEvent paramMotionEvent, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_3
    //   5: iload_3
    //   6: iconst_1
    //   7: if_icmpeq -> 45
    //   10: iload_3
    //   11: iconst_2
    //   12: if_icmpeq -> 39
    //   15: iload_3
    //   16: iconst_3
    //   17: if_icmpeq -> 29
    //   20: iconst_0
    //   21: istore #7
    //   23: iconst_1
    //   24: istore #6
    //   26: goto -> 143
    //   29: iconst_0
    //   30: istore #7
    //   32: iload #7
    //   34: istore #6
    //   36: goto -> 143
    //   39: iconst_1
    //   40: istore #6
    //   42: goto -> 48
    //   45: iconst_0
    //   46: istore #6
    //   48: aload_1
    //   49: iload_2
    //   50: invokevirtual findPointerIndex : (I)I
    //   53: istore #4
    //   55: iload #4
    //   57: ifge -> 63
    //   60: goto -> 29
    //   63: aload_1
    //   64: iload #4
    //   66: invokevirtual getX : (I)F
    //   69: f2i
    //   70: istore_2
    //   71: aload_1
    //   72: iload #4
    //   74: invokevirtual getY : (I)F
    //   77: f2i
    //   78: istore #4
    //   80: aload_0
    //   81: iload_2
    //   82: iload #4
    //   84: invokevirtual pointToPosition : (II)I
    //   87: istore #5
    //   89: iload #5
    //   91: iconst_m1
    //   92: if_icmpne -> 101
    //   95: iconst_1
    //   96: istore #7
    //   98: goto -> 143
    //   101: aload_0
    //   102: iload #5
    //   104: aload_0
    //   105: invokevirtual getFirstVisiblePosition : ()I
    //   108: isub
    //   109: invokevirtual getChildAt : (I)Landroid/view/View;
    //   112: astore #8
    //   114: aload_0
    //   115: aload #8
    //   117: iload #5
    //   119: iload_2
    //   120: i2f
    //   121: iload #4
    //   123: i2f
    //   124: invokespecial i : (Landroid/view/View;IFF)V
    //   127: iload_3
    //   128: iconst_1
    //   129: if_icmpne -> 20
    //   132: aload_0
    //   133: aload #8
    //   135: iload #5
    //   137: invokespecial b : (Landroid/view/View;I)V
    //   140: goto -> 20
    //   143: iload #6
    //   145: ifeq -> 153
    //   148: iload #7
    //   150: ifeq -> 157
    //   153: aload_0
    //   154: invokespecial a : ()V
    //   157: iload #6
    //   159: ifeq -> 203
    //   162: aload_0
    //   163: getfield r : Landroidx/core/widget/g;
    //   166: ifnonnull -> 181
    //   169: aload_0
    //   170: new androidx/core/widget/g
    //   173: dup
    //   174: aload_0
    //   175: invokespecial <init> : (Landroid/widget/ListView;)V
    //   178: putfield r : Landroidx/core/widget/g;
    //   181: aload_0
    //   182: getfield r : Landroidx/core/widget/g;
    //   185: iconst_1
    //   186: invokevirtual w : (Z)Landroidx/core/widget/a;
    //   189: pop
    //   190: aload_0
    //   191: getfield r : Landroidx/core/widget/g;
    //   194: aload_0
    //   195: aload_1
    //   196: invokevirtual onTouch : (Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   199: pop
    //   200: iload #6
    //   202: ireturn
    //   203: aload_0
    //   204: getfield r : Landroidx/core/widget/g;
    //   207: astore_1
    //   208: aload_1
    //   209: ifnull -> 218
    //   212: aload_1
    //   213: iconst_0
    //   214: invokevirtual w : (Z)Landroidx/core/widget/a;
    //   217: pop
    //   218: iload #6
    //   220: ireturn
  }
  
  public boolean hasFocus() {
    return (this.o || super.hasFocus());
  }
  
  public boolean hasWindowFocus() {
    return (this.o || super.hasWindowFocus());
  }
  
  public boolean isFocused() {
    return (this.o || super.isFocused());
  }
  
  public boolean isInTouchMode() {
    return ((this.o && this.n) || super.isInTouchMode());
  }
  
  protected void onDetachedFromWindow() {
    this.s = null;
    super.onDetachedFromWindow();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    if (Build.VERSION.SDK_INT < 26)
      return super.onHoverEvent(paramMotionEvent); 
    int i = paramMotionEvent.getActionMasked();
    if (i == 10 && this.s == null) {
      b b1 = new b(this);
      this.s = b1;
      b1.b();
    } 
    boolean bool = super.onHoverEvent(paramMotionEvent);
    if (i == 9 || i == 7) {
      i = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
      if (i != -1 && i != getSelectedItemPosition()) {
        View view = getChildAt(i - getFirstVisiblePosition());
        if (view.isEnabled())
          setSelectionFromTop(i, view.getTop() - getTop()); 
        k();
      } 
      return bool;
    } 
    setSelection(-1);
    return bool;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 0)
      this.k = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()); 
    b b1 = this.s;
    if (b1 != null)
      b1.a(); 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  void setListSelectionHidden(boolean paramBoolean) {
    this.n = paramBoolean;
  }
  
  public void setSelector(Drawable paramDrawable) {
    a a1;
    if (paramDrawable != null) {
      a1 = new a(paramDrawable);
    } else {
      a1 = null;
    } 
    this.m = a1;
    super.setSelector((Drawable)a1);
    Rect rect = new Rect();
    if (paramDrawable != null)
      paramDrawable.getPadding(rect); 
    this.g = rect.left;
    this.h = rect.top;
    this.i = rect.right;
    this.j = rect.bottom;
  }
  
  private static class a extends c {
    private boolean g = true;
    
    a(Drawable param1Drawable) {
      super(param1Drawable);
    }
    
    void c(boolean param1Boolean) {
      this.g = param1Boolean;
    }
    
    public void draw(Canvas param1Canvas) {
      if (this.g)
        super.draw(param1Canvas); 
    }
    
    public void setHotspot(float param1Float1, float param1Float2) {
      if (this.g)
        super.setHotspot(param1Float1, param1Float2); 
    }
    
    public void setHotspotBounds(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.g)
        super.setHotspotBounds(param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public boolean setState(int[] param1ArrayOfint) {
      return this.g ? super.setState(param1ArrayOfint) : false;
    }
    
    public boolean setVisible(boolean param1Boolean1, boolean param1Boolean2) {
      return this.g ? super.setVisible(param1Boolean1, param1Boolean2) : false;
    }
  }
  
  private class b implements Runnable {
    b(g0 this$0) {}
    
    public void a() {
      g0 g01 = this.f;
      g01.s = null;
      g01.removeCallbacks(this);
    }
    
    public void b() {
      this.f.post(this);
    }
    
    public void run() {
      g0 g01 = this.f;
      g01.s = null;
      g01.drawableStateChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */