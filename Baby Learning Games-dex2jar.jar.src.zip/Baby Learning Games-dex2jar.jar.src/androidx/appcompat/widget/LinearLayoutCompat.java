package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import androidx.core.view.e;
import androidx.core.view.w;
import e.j;

public class LinearLayoutCompat extends ViewGroup {
  private boolean f = true;
  
  private int g = -1;
  
  private int h = 0;
  
  private int i;
  
  private int j = 8388659;
  
  private int k;
  
  private float l;
  
  private boolean m;
  
  private int[] n;
  
  private int[] o;
  
  private Drawable p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private int t;
  
  public LinearLayoutCompat(Context paramContext) {
    this(paramContext, null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    int[] arrayOfInt = j.i1;
    w0 w0 = w0.v(paramContext, paramAttributeSet, arrayOfInt, paramInt, 0);
    w.m0((View)this, paramContext, arrayOfInt, paramAttributeSet, w0.r(), paramInt, 0);
    paramInt = w0.k(j.k1, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = w0.k(j.j1, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = w0.a(j.l1, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.l = w0.i(j.n1, -1.0F);
    this.g = w0.k(j.m1, -1);
    this.m = w0.a(j.q1, false);
    setDividerDrawable(w0.g(j.o1));
    this.s = w0.k(j.r1, 0);
    this.t = w0.f(j.p1, 0);
    w0.w();
  }
  
  private void A(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  private void k(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = s(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.height == -1) {
          int k = a.width;
          a.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          a.width = k;
        } 
      } 
    } 
  }
  
  private void l(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = s(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.width == -1) {
          int k = a.height;
          a.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          a.height = k;
        } 
      } 
    } 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  void f(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = d1.b((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = s(i);
      if (view != null && view.getVisibility() != 8 && t(i)) {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + a.rightMargin;
        } else {
          k = view.getLeft() - a.leftMargin - this.q;
        } 
        j(paramCanvas, k);
      } 
    } 
    if (t(j)) {
      View view = s(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.q;
          i -= k;
        } 
      } else {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - a.leftMargin;
          k = this.q;
        } else {
          i = view.getRight() + a.rightMargin;
          j(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    j(paramCanvas, i);
  }
  
  public int getBaseline() {
    if (this.g < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.g;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.g == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.h;
      i = j;
      if (this.i == 1) {
        int m = this.j & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.k;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.k) / 2;
          }  
      } 
      return i + ((a)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.g;
  }
  
  public Drawable getDividerDrawable() {
    return this.p;
  }
  
  public int getDividerPadding() {
    return this.t;
  }
  
  public int getDividerWidth() {
    return this.q;
  }
  
  public int getGravity() {
    return this.j;
  }
  
  public int getOrientation() {
    return this.i;
  }
  
  public int getShowDividers() {
    return this.s;
  }
  
  int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.l;
  }
  
  void h(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = s(i);
      if (view != null && view.getVisibility() != 8 && t(i)) {
        a a = (a)view.getLayoutParams();
        i(paramCanvas, view.getTop() - a.topMargin - this.r);
      } 
    } 
    if (t(j)) {
      View view = s(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.r;
      } else {
        a a = (a)view.getLayoutParams();
        i = view.getBottom() + a.bottomMargin;
      } 
      i(paramCanvas, i);
    } 
  }
  
  void i(Canvas paramCanvas, int paramInt) {
    this.p.setBounds(getPaddingLeft() + this.t, paramInt, getWidth() - getPaddingRight() - this.t, this.r + paramInt);
    this.p.draw(paramCanvas);
  }
  
  void j(Canvas paramCanvas, int paramInt) {
    this.p.setBounds(paramInt, getPaddingTop() + this.t, this.q + paramInt, getHeight() - getPaddingBottom() - this.t);
    this.p.draw(paramCanvas);
  }
  
  protected a m() {
    int i = this.i;
    return (i == 0) ? new a(-2, -2) : ((i == 1) ? new a(-1, -2) : null);
  }
  
  public a n(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  protected a o(ViewGroup.LayoutParams paramLayoutParams) {
    return new a(paramLayoutParams);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.p == null)
      return; 
    if (this.i == 1) {
      h(paramCanvas);
      return;
    } 
    f(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.i == 1) {
      v(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    u(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.i == 1) {
      z(paramInt1, paramInt2);
      return;
    } 
    x(paramInt1, paramInt2);
  }
  
  int p(View paramView, int paramInt) {
    return 0;
  }
  
  int q(View paramView) {
    return 0;
  }
  
  int r(View paramView) {
    return 0;
  }
  
  View s(int paramInt) {
    return getChildAt(paramInt);
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.g = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.p)
      return; 
    this.p = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.q = paramDrawable.getIntrinsicWidth();
      this.r = paramDrawable.getIntrinsicHeight();
    } else {
      this.q = 0;
      this.r = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.t = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.j != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.j = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.j;
    if ((0x800007 & i) != paramInt) {
      this.j = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.m = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.i != paramInt) {
      this.i = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.s)
      requestLayout(); 
    this.s = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.j;
    if ((i & 0x70) != paramInt) {
      this.j = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.l = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  protected boolean t(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.s & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.s & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.s & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  void u(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool2 = d1.b((View)this);
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2;
    int n = getPaddingBottom();
    int i1 = getPaddingBottom();
    int j = getVirtualChildCount();
    paramInt2 = this.j;
    paramInt4 = paramInt2 & 0x70;
    boolean bool1 = this.f;
    int[] arrayOfInt1 = this.n;
    int[] arrayOfInt2 = this.o;
    paramInt2 = e.b(0x800007 & paramInt2, w.B((View)this));
    boolean bool = true;
    if (paramInt2 != 1) {
      if (paramInt2 != 5) {
        paramInt2 = getPaddingLeft();
      } else {
        paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.k;
      } 
    } else {
      paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.k) / 2;
    } 
    if (bool2) {
      b1 = j - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    int i = 0;
    paramInt3 = paramInt4;
    paramInt4 = k;
    while (i < j) {
      int i2 = b1 + b2 * i;
      View view = s(i2);
      if (view == null) {
        paramInt2 += y(i2);
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        a a = (a)view.getLayoutParams();
        if (bool1 && a.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = a.gravity;
        paramInt1 = i4;
        if (i4 < 0)
          paramInt1 = paramInt3; 
        paramInt1 &= 0x70;
        if (paramInt1 != 16) {
          if (paramInt1 != 48) {
            if (paramInt1 != 80) {
              paramInt1 = paramInt4;
            } else {
              i4 = m - n - i6 - a.bottomMargin;
              paramInt1 = i4;
              if (i3 != -1) {
                paramInt1 = view.getMeasuredHeight();
                paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
              } 
            } 
          } else {
            i4 = a.topMargin + paramInt4;
            paramInt1 = i4;
            if (i3 != -1)
              paramInt1 = i4 + arrayOfInt1[1] - i3; 
          } 
        } else {
          paramInt1 = (m - k - i1 - i6) / 2 + paramInt4 + a.topMargin - a.bottomMargin;
        } 
        bool = true;
        int i3 = paramInt2;
        if (t(i2))
          i3 = paramInt2 + this.q; 
        paramInt2 = a.leftMargin + i3;
        A(view, paramInt2 + q(view), paramInt1, i5, i6);
        paramInt1 = a.rightMargin;
        i3 = r(view);
        i += p(view, i2);
        paramInt2 += i5 + paramInt1 + i3;
      } else {
        bool = true;
      } 
      i++;
    } 
  }
  
  void v(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.j;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.k;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.k) / 2;
    } 
    for (paramInt2 = 0; paramInt2 < n; paramInt2++) {
      View view = s(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + y(paramInt2);
      } else {
        paramInt3 = paramInt1;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          a a = (a)view.getLayoutParams();
          paramInt4 = a.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          paramInt3 = e.b(paramInt3, w.B((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = a.leftMargin + i;
            } else {
              paramInt3 = j - k - i3;
              paramInt4 = a.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (j - i - m - i3) / 2 + i + a.leftMargin;
            paramInt4 = a.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (t(paramInt2))
            paramInt4 = paramInt1 + this.r; 
          paramInt1 = paramInt4 + a.topMargin;
          A(view, paramInt3, paramInt1 + q(view), i3, i2);
          paramInt3 = a.bottomMargin;
          paramInt4 = r(view);
          paramInt2 += p(view, paramInt2);
          paramInt1 += i2 + paramInt3 + paramInt4;
          continue;
        } 
      } 
      paramInt1 = paramInt3;
      continue;
    } 
  }
  
  void w(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  void x(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield k : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #23
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #22
    //   23: aload_0
    //   24: getfield n : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield o : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield n : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield o : [I
    //   51: aload_0
    //   52: getfield n : [I
    //   55: astore #29
    //   57: aload_0
    //   58: getfield o : [I
    //   61: astore #27
    //   63: aload #29
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #29
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #29
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #29
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #27
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #27
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #27
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #27
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield f : Z
    //   107: istore #25
    //   109: aload_0
    //   110: getfield m : Z
    //   113: istore #26
    //   115: ldc 1073741824
    //   117: istore #14
    //   119: iload #23
    //   121: ldc 1073741824
    //   123: if_icmpne -> 132
    //   126: iconst_1
    //   127: istore #15
    //   129: goto -> 135
    //   132: iconst_0
    //   133: istore #15
    //   135: iconst_0
    //   136: istore #8
    //   138: iload #8
    //   140: istore #7
    //   142: iload #7
    //   144: istore #13
    //   146: iload #13
    //   148: istore #6
    //   150: iload #6
    //   152: istore #11
    //   154: iload #11
    //   156: istore #12
    //   158: iload #12
    //   160: istore #9
    //   162: iload #9
    //   164: istore #10
    //   166: iconst_1
    //   167: istore #5
    //   169: fconst_0
    //   170: fstore_3
    //   171: iload #8
    //   173: iload #16
    //   175: if_icmpge -> 881
    //   178: aload_0
    //   179: iload #8
    //   181: invokevirtual s : (I)Landroid/view/View;
    //   184: astore #28
    //   186: aload #28
    //   188: ifnonnull -> 221
    //   191: aload_0
    //   192: aload_0
    //   193: getfield k : I
    //   196: aload_0
    //   197: iload #8
    //   199: invokevirtual y : (I)I
    //   202: iadd
    //   203: putfield k : I
    //   206: iload #8
    //   208: istore #17
    //   210: iload #14
    //   212: istore #8
    //   214: iload #17
    //   216: istore #14
    //   218: goto -> 864
    //   221: aload #28
    //   223: invokevirtual getVisibility : ()I
    //   226: bipush #8
    //   228: if_icmpne -> 247
    //   231: iload #8
    //   233: aload_0
    //   234: aload #28
    //   236: iload #8
    //   238: invokevirtual p : (Landroid/view/View;I)I
    //   241: iadd
    //   242: istore #8
    //   244: goto -> 206
    //   247: aload_0
    //   248: iload #8
    //   250: invokevirtual t : (I)Z
    //   253: ifeq -> 269
    //   256: aload_0
    //   257: aload_0
    //   258: getfield k : I
    //   261: aload_0
    //   262: getfield q : I
    //   265: iadd
    //   266: putfield k : I
    //   269: aload #28
    //   271: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   274: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   277: astore #30
    //   279: aload #30
    //   281: getfield weight : F
    //   284: fstore #4
    //   286: fload_3
    //   287: fload #4
    //   289: fadd
    //   290: fstore_3
    //   291: iload #23
    //   293: iload #14
    //   295: if_icmpne -> 404
    //   298: aload #30
    //   300: getfield width : I
    //   303: ifne -> 404
    //   306: fload #4
    //   308: fconst_0
    //   309: fcmpl
    //   310: ifle -> 404
    //   313: iload #15
    //   315: ifeq -> 341
    //   318: aload_0
    //   319: aload_0
    //   320: getfield k : I
    //   323: aload #30
    //   325: getfield leftMargin : I
    //   328: aload #30
    //   330: getfield rightMargin : I
    //   333: iadd
    //   334: iadd
    //   335: putfield k : I
    //   338: goto -> 370
    //   341: aload_0
    //   342: getfield k : I
    //   345: istore #14
    //   347: aload_0
    //   348: iload #14
    //   350: aload #30
    //   352: getfield leftMargin : I
    //   355: iload #14
    //   357: iadd
    //   358: aload #30
    //   360: getfield rightMargin : I
    //   363: iadd
    //   364: invokestatic max : (II)I
    //   367: putfield k : I
    //   370: iload #25
    //   372: ifeq -> 398
    //   375: iconst_0
    //   376: iconst_0
    //   377: invokestatic makeMeasureSpec : (II)I
    //   380: istore #14
    //   382: aload #28
    //   384: iload #14
    //   386: iload #14
    //   388: invokevirtual measure : (II)V
    //   391: iload #7
    //   393: istore #14
    //   395: goto -> 585
    //   398: iconst_1
    //   399: istore #12
    //   401: goto -> 589
    //   404: aload #30
    //   406: getfield width : I
    //   409: ifne -> 432
    //   412: fload #4
    //   414: fconst_0
    //   415: fcmpl
    //   416: ifle -> 432
    //   419: aload #30
    //   421: bipush #-2
    //   423: putfield width : I
    //   426: iconst_0
    //   427: istore #14
    //   429: goto -> 437
    //   432: ldc_w -2147483648
    //   435: istore #14
    //   437: fload_3
    //   438: fconst_0
    //   439: fcmpl
    //   440: ifne -> 452
    //   443: aload_0
    //   444: getfield k : I
    //   447: istore #17
    //   449: goto -> 455
    //   452: iconst_0
    //   453: istore #17
    //   455: aload_0
    //   456: aload #28
    //   458: iload #8
    //   460: iload_1
    //   461: iload #17
    //   463: iload_2
    //   464: iconst_0
    //   465: invokevirtual w : (Landroid/view/View;IIIII)V
    //   468: iload #14
    //   470: ldc_w -2147483648
    //   473: if_icmpeq -> 483
    //   476: aload #30
    //   478: iload #14
    //   480: putfield width : I
    //   483: aload #28
    //   485: invokevirtual getMeasuredWidth : ()I
    //   488: istore #17
    //   490: iload #15
    //   492: ifeq -> 528
    //   495: aload_0
    //   496: aload_0
    //   497: getfield k : I
    //   500: aload #30
    //   502: getfield leftMargin : I
    //   505: iload #17
    //   507: iadd
    //   508: aload #30
    //   510: getfield rightMargin : I
    //   513: iadd
    //   514: aload_0
    //   515: aload #28
    //   517: invokevirtual r : (Landroid/view/View;)I
    //   520: iadd
    //   521: iadd
    //   522: putfield k : I
    //   525: goto -> 567
    //   528: aload_0
    //   529: getfield k : I
    //   532: istore #14
    //   534: aload_0
    //   535: iload #14
    //   537: iload #14
    //   539: iload #17
    //   541: iadd
    //   542: aload #30
    //   544: getfield leftMargin : I
    //   547: iadd
    //   548: aload #30
    //   550: getfield rightMargin : I
    //   553: iadd
    //   554: aload_0
    //   555: aload #28
    //   557: invokevirtual r : (Landroid/view/View;)I
    //   560: iadd
    //   561: invokestatic max : (II)I
    //   564: putfield k : I
    //   567: iload #7
    //   569: istore #14
    //   571: iload #26
    //   573: ifeq -> 585
    //   576: iload #17
    //   578: iload #7
    //   580: invokestatic max : (II)I
    //   583: istore #14
    //   585: iload #14
    //   587: istore #7
    //   589: iload #8
    //   591: istore #19
    //   593: ldc 1073741824
    //   595: istore #18
    //   597: iload #22
    //   599: ldc 1073741824
    //   601: if_icmpeq -> 623
    //   604: aload #30
    //   606: getfield height : I
    //   609: iconst_m1
    //   610: if_icmpne -> 623
    //   613: iconst_1
    //   614: istore #8
    //   616: iload #8
    //   618: istore #10
    //   620: goto -> 626
    //   623: iconst_0
    //   624: istore #8
    //   626: aload #30
    //   628: getfield topMargin : I
    //   631: aload #30
    //   633: getfield bottomMargin : I
    //   636: iadd
    //   637: istore #14
    //   639: aload #28
    //   641: invokevirtual getMeasuredHeight : ()I
    //   644: iload #14
    //   646: iadd
    //   647: istore #17
    //   649: iload #9
    //   651: aload #28
    //   653: invokevirtual getMeasuredState : ()I
    //   656: invokestatic combineMeasuredStates : (II)I
    //   659: istore #20
    //   661: iload #25
    //   663: ifeq -> 748
    //   666: aload #28
    //   668: invokevirtual getBaseline : ()I
    //   671: istore #24
    //   673: iload #24
    //   675: iconst_m1
    //   676: if_icmpeq -> 748
    //   679: aload #30
    //   681: getfield gravity : I
    //   684: istore #21
    //   686: iload #21
    //   688: istore #9
    //   690: iload #21
    //   692: ifge -> 701
    //   695: aload_0
    //   696: getfield j : I
    //   699: istore #9
    //   701: iload #9
    //   703: bipush #112
    //   705: iand
    //   706: iconst_4
    //   707: ishr
    //   708: bipush #-2
    //   710: iand
    //   711: iconst_1
    //   712: ishr
    //   713: istore #9
    //   715: aload #29
    //   717: iload #9
    //   719: aload #29
    //   721: iload #9
    //   723: iaload
    //   724: iload #24
    //   726: invokestatic max : (II)I
    //   729: iastore
    //   730: aload #27
    //   732: iload #9
    //   734: aload #27
    //   736: iload #9
    //   738: iaload
    //   739: iload #17
    //   741: iload #24
    //   743: isub
    //   744: invokestatic max : (II)I
    //   747: iastore
    //   748: iload #13
    //   750: iload #17
    //   752: invokestatic max : (II)I
    //   755: istore #13
    //   757: iload #5
    //   759: ifeq -> 777
    //   762: aload #30
    //   764: getfield height : I
    //   767: iconst_m1
    //   768: if_icmpne -> 777
    //   771: iconst_1
    //   772: istore #5
    //   774: goto -> 780
    //   777: iconst_0
    //   778: istore #5
    //   780: aload #30
    //   782: getfield weight : F
    //   785: fconst_0
    //   786: fcmpl
    //   787: ifle -> 814
    //   790: iload #8
    //   792: ifeq -> 798
    //   795: goto -> 802
    //   798: iload #17
    //   800: istore #14
    //   802: iload #11
    //   804: iload #14
    //   806: invokestatic max : (II)I
    //   809: istore #8
    //   811: goto -> 839
    //   814: iload #8
    //   816: ifeq -> 822
    //   819: goto -> 826
    //   822: iload #17
    //   824: istore #14
    //   826: iload #6
    //   828: iload #14
    //   830: invokestatic max : (II)I
    //   833: istore #6
    //   835: iload #11
    //   837: istore #8
    //   839: aload_0
    //   840: aload #28
    //   842: iload #19
    //   844: invokevirtual p : (Landroid/view/View;I)I
    //   847: iload #19
    //   849: iadd
    //   850: istore #14
    //   852: iload #20
    //   854: istore #9
    //   856: iload #8
    //   858: istore #11
    //   860: iload #18
    //   862: istore #8
    //   864: iload #8
    //   866: istore #17
    //   868: iload #14
    //   870: iconst_1
    //   871: iadd
    //   872: istore #8
    //   874: iload #17
    //   876: istore #14
    //   878: goto -> 171
    //   881: aload_0
    //   882: getfield k : I
    //   885: ifle -> 910
    //   888: aload_0
    //   889: iload #16
    //   891: invokevirtual t : (I)Z
    //   894: ifeq -> 910
    //   897: aload_0
    //   898: aload_0
    //   899: getfield k : I
    //   902: aload_0
    //   903: getfield q : I
    //   906: iadd
    //   907: putfield k : I
    //   910: aload #29
    //   912: iconst_1
    //   913: iaload
    //   914: iconst_m1
    //   915: if_icmpne -> 952
    //   918: aload #29
    //   920: iconst_0
    //   921: iaload
    //   922: iconst_m1
    //   923: if_icmpne -> 952
    //   926: aload #29
    //   928: iconst_2
    //   929: iaload
    //   930: iconst_m1
    //   931: if_icmpne -> 952
    //   934: aload #29
    //   936: iconst_3
    //   937: iaload
    //   938: iconst_m1
    //   939: if_icmpeq -> 945
    //   942: goto -> 952
    //   945: iload #13
    //   947: istore #8
    //   949: goto -> 1010
    //   952: iload #13
    //   954: aload #29
    //   956: iconst_3
    //   957: iaload
    //   958: aload #29
    //   960: iconst_0
    //   961: iaload
    //   962: aload #29
    //   964: iconst_1
    //   965: iaload
    //   966: aload #29
    //   968: iconst_2
    //   969: iaload
    //   970: invokestatic max : (II)I
    //   973: invokestatic max : (II)I
    //   976: invokestatic max : (II)I
    //   979: aload #27
    //   981: iconst_3
    //   982: iaload
    //   983: aload #27
    //   985: iconst_0
    //   986: iaload
    //   987: aload #27
    //   989: iconst_1
    //   990: iaload
    //   991: aload #27
    //   993: iconst_2
    //   994: iaload
    //   995: invokestatic max : (II)I
    //   998: invokestatic max : (II)I
    //   1001: invokestatic max : (II)I
    //   1004: iadd
    //   1005: invokestatic max : (II)I
    //   1008: istore #8
    //   1010: iload #9
    //   1012: istore #13
    //   1014: iload #8
    //   1016: istore #14
    //   1018: iload #26
    //   1020: ifeq -> 1212
    //   1023: iload #23
    //   1025: ldc_w -2147483648
    //   1028: if_icmpeq -> 1040
    //   1031: iload #8
    //   1033: istore #14
    //   1035: iload #23
    //   1037: ifne -> 1212
    //   1040: aload_0
    //   1041: iconst_0
    //   1042: putfield k : I
    //   1045: iconst_0
    //   1046: istore #9
    //   1048: iload #8
    //   1050: istore #14
    //   1052: iload #9
    //   1054: iload #16
    //   1056: if_icmpge -> 1212
    //   1059: aload_0
    //   1060: iload #9
    //   1062: invokevirtual s : (I)Landroid/view/View;
    //   1065: astore #28
    //   1067: aload #28
    //   1069: ifnonnull -> 1090
    //   1072: aload_0
    //   1073: aload_0
    //   1074: getfield k : I
    //   1077: aload_0
    //   1078: iload #9
    //   1080: invokevirtual y : (I)I
    //   1083: iadd
    //   1084: putfield k : I
    //   1087: goto -> 1113
    //   1090: aload #28
    //   1092: invokevirtual getVisibility : ()I
    //   1095: bipush #8
    //   1097: if_icmpne -> 1116
    //   1100: iload #9
    //   1102: aload_0
    //   1103: aload #28
    //   1105: iload #9
    //   1107: invokevirtual p : (Landroid/view/View;I)I
    //   1110: iadd
    //   1111: istore #9
    //   1113: goto -> 1203
    //   1116: aload #28
    //   1118: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1121: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1124: astore #30
    //   1126: iload #15
    //   1128: ifeq -> 1164
    //   1131: aload_0
    //   1132: aload_0
    //   1133: getfield k : I
    //   1136: aload #30
    //   1138: getfield leftMargin : I
    //   1141: iload #7
    //   1143: iadd
    //   1144: aload #30
    //   1146: getfield rightMargin : I
    //   1149: iadd
    //   1150: aload_0
    //   1151: aload #28
    //   1153: invokevirtual r : (Landroid/view/View;)I
    //   1156: iadd
    //   1157: iadd
    //   1158: putfield k : I
    //   1161: goto -> 1113
    //   1164: aload_0
    //   1165: getfield k : I
    //   1168: istore #14
    //   1170: aload_0
    //   1171: iload #14
    //   1173: iload #14
    //   1175: iload #7
    //   1177: iadd
    //   1178: aload #30
    //   1180: getfield leftMargin : I
    //   1183: iadd
    //   1184: aload #30
    //   1186: getfield rightMargin : I
    //   1189: iadd
    //   1190: aload_0
    //   1191: aload #28
    //   1193: invokevirtual r : (Landroid/view/View;)I
    //   1196: iadd
    //   1197: invokestatic max : (II)I
    //   1200: putfield k : I
    //   1203: iload #9
    //   1205: iconst_1
    //   1206: iadd
    //   1207: istore #9
    //   1209: goto -> 1048
    //   1212: aload_0
    //   1213: getfield k : I
    //   1216: aload_0
    //   1217: invokevirtual getPaddingLeft : ()I
    //   1220: aload_0
    //   1221: invokevirtual getPaddingRight : ()I
    //   1224: iadd
    //   1225: iadd
    //   1226: istore #8
    //   1228: aload_0
    //   1229: iload #8
    //   1231: putfield k : I
    //   1234: iload #8
    //   1236: aload_0
    //   1237: invokevirtual getSuggestedMinimumWidth : ()I
    //   1240: invokestatic max : (II)I
    //   1243: iload_1
    //   1244: iconst_0
    //   1245: invokestatic resolveSizeAndState : (III)I
    //   1248: istore #18
    //   1250: ldc_w 16777215
    //   1253: iload #18
    //   1255: iand
    //   1256: aload_0
    //   1257: getfield k : I
    //   1260: isub
    //   1261: istore #17
    //   1263: iload #12
    //   1265: ifne -> 1401
    //   1268: iload #17
    //   1270: ifeq -> 1282
    //   1273: fload_3
    //   1274: fconst_0
    //   1275: fcmpl
    //   1276: ifle -> 1282
    //   1279: goto -> 1401
    //   1282: iload #6
    //   1284: iload #11
    //   1286: invokestatic max : (II)I
    //   1289: istore #9
    //   1291: iload #26
    //   1293: ifeq -> 1386
    //   1296: iload #23
    //   1298: ldc 1073741824
    //   1300: if_icmpeq -> 1386
    //   1303: iconst_0
    //   1304: istore #6
    //   1306: iload #6
    //   1308: iload #16
    //   1310: if_icmpge -> 1386
    //   1313: aload_0
    //   1314: iload #6
    //   1316: invokevirtual s : (I)Landroid/view/View;
    //   1319: astore #27
    //   1321: aload #27
    //   1323: ifnull -> 1377
    //   1326: aload #27
    //   1328: invokevirtual getVisibility : ()I
    //   1331: bipush #8
    //   1333: if_icmpne -> 1339
    //   1336: goto -> 1377
    //   1339: aload #27
    //   1341: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1344: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1347: getfield weight : F
    //   1350: fconst_0
    //   1351: fcmpl
    //   1352: ifle -> 1377
    //   1355: aload #27
    //   1357: iload #7
    //   1359: ldc 1073741824
    //   1361: invokestatic makeMeasureSpec : (II)I
    //   1364: aload #27
    //   1366: invokevirtual getMeasuredHeight : ()I
    //   1369: ldc 1073741824
    //   1371: invokestatic makeMeasureSpec : (II)I
    //   1374: invokevirtual measure : (II)V
    //   1377: iload #6
    //   1379: iconst_1
    //   1380: iadd
    //   1381: istore #6
    //   1383: goto -> 1306
    //   1386: iload #16
    //   1388: istore #8
    //   1390: iload #14
    //   1392: istore #7
    //   1394: iload #9
    //   1396: istore #6
    //   1398: goto -> 2142
    //   1401: aload_0
    //   1402: getfield l : F
    //   1405: fstore #4
    //   1407: fload #4
    //   1409: fconst_0
    //   1410: fcmpl
    //   1411: ifle -> 1417
    //   1414: fload #4
    //   1416: fstore_3
    //   1417: aload #29
    //   1419: iconst_3
    //   1420: iconst_m1
    //   1421: iastore
    //   1422: aload #29
    //   1424: iconst_2
    //   1425: iconst_m1
    //   1426: iastore
    //   1427: aload #29
    //   1429: iconst_1
    //   1430: iconst_m1
    //   1431: iastore
    //   1432: aload #29
    //   1434: iconst_0
    //   1435: iconst_m1
    //   1436: iastore
    //   1437: aload #27
    //   1439: iconst_3
    //   1440: iconst_m1
    //   1441: iastore
    //   1442: aload #27
    //   1444: iconst_2
    //   1445: iconst_m1
    //   1446: iastore
    //   1447: aload #27
    //   1449: iconst_1
    //   1450: iconst_m1
    //   1451: iastore
    //   1452: aload #27
    //   1454: iconst_0
    //   1455: iconst_m1
    //   1456: iastore
    //   1457: aload_0
    //   1458: iconst_0
    //   1459: putfield k : I
    //   1462: iconst_m1
    //   1463: istore #11
    //   1465: iload #13
    //   1467: istore #9
    //   1469: iconst_0
    //   1470: istore #13
    //   1472: iload #5
    //   1474: istore #8
    //   1476: iload #16
    //   1478: istore #7
    //   1480: iload #9
    //   1482: istore #5
    //   1484: iload #6
    //   1486: istore #9
    //   1488: iload #17
    //   1490: istore #6
    //   1492: iload #13
    //   1494: iload #7
    //   1496: if_icmpge -> 2004
    //   1499: aload_0
    //   1500: iload #13
    //   1502: invokevirtual s : (I)Landroid/view/View;
    //   1505: astore #28
    //   1507: aload #28
    //   1509: ifnull -> 1995
    //   1512: aload #28
    //   1514: invokevirtual getVisibility : ()I
    //   1517: bipush #8
    //   1519: if_icmpne -> 1525
    //   1522: goto -> 1995
    //   1525: aload #28
    //   1527: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1530: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1533: astore #30
    //   1535: aload #30
    //   1537: getfield weight : F
    //   1540: fstore #4
    //   1542: fload #4
    //   1544: fconst_0
    //   1545: fcmpl
    //   1546: ifle -> 1709
    //   1549: iload #6
    //   1551: i2f
    //   1552: fload #4
    //   1554: fmul
    //   1555: fload_3
    //   1556: fdiv
    //   1557: f2i
    //   1558: istore #14
    //   1560: iload_2
    //   1561: aload_0
    //   1562: invokevirtual getPaddingTop : ()I
    //   1565: aload_0
    //   1566: invokevirtual getPaddingBottom : ()I
    //   1569: iadd
    //   1570: aload #30
    //   1572: getfield topMargin : I
    //   1575: iadd
    //   1576: aload #30
    //   1578: getfield bottomMargin : I
    //   1581: iadd
    //   1582: aload #30
    //   1584: getfield height : I
    //   1587: invokestatic getChildMeasureSpec : (III)I
    //   1590: istore #17
    //   1592: aload #30
    //   1594: getfield width : I
    //   1597: ifne -> 1642
    //   1600: iload #23
    //   1602: ldc 1073741824
    //   1604: if_icmpeq -> 1610
    //   1607: goto -> 1642
    //   1610: iload #14
    //   1612: ifle -> 1622
    //   1615: iload #14
    //   1617: istore #12
    //   1619: goto -> 1625
    //   1622: iconst_0
    //   1623: istore #12
    //   1625: aload #28
    //   1627: iload #12
    //   1629: ldc 1073741824
    //   1631: invokestatic makeMeasureSpec : (II)I
    //   1634: iload #17
    //   1636: invokevirtual measure : (II)V
    //   1639: goto -> 1678
    //   1642: aload #28
    //   1644: invokevirtual getMeasuredWidth : ()I
    //   1647: iload #14
    //   1649: iadd
    //   1650: istore #16
    //   1652: iload #16
    //   1654: istore #12
    //   1656: iload #16
    //   1658: ifge -> 1664
    //   1661: iconst_0
    //   1662: istore #12
    //   1664: aload #28
    //   1666: iload #12
    //   1668: ldc 1073741824
    //   1670: invokestatic makeMeasureSpec : (II)I
    //   1673: iload #17
    //   1675: invokevirtual measure : (II)V
    //   1678: iload #5
    //   1680: aload #28
    //   1682: invokevirtual getMeasuredState : ()I
    //   1685: ldc_w -16777216
    //   1688: iand
    //   1689: invokestatic combineMeasuredStates : (II)I
    //   1692: istore #5
    //   1694: fload_3
    //   1695: fload #4
    //   1697: fsub
    //   1698: fstore_3
    //   1699: iload #6
    //   1701: iload #14
    //   1703: isub
    //   1704: istore #6
    //   1706: goto -> 1709
    //   1709: iload #15
    //   1711: ifeq -> 1750
    //   1714: aload_0
    //   1715: aload_0
    //   1716: getfield k : I
    //   1719: aload #28
    //   1721: invokevirtual getMeasuredWidth : ()I
    //   1724: aload #30
    //   1726: getfield leftMargin : I
    //   1729: iadd
    //   1730: aload #30
    //   1732: getfield rightMargin : I
    //   1735: iadd
    //   1736: aload_0
    //   1737: aload #28
    //   1739: invokevirtual r : (Landroid/view/View;)I
    //   1742: iadd
    //   1743: iadd
    //   1744: putfield k : I
    //   1747: goto -> 1792
    //   1750: aload_0
    //   1751: getfield k : I
    //   1754: istore #12
    //   1756: aload_0
    //   1757: iload #12
    //   1759: aload #28
    //   1761: invokevirtual getMeasuredWidth : ()I
    //   1764: iload #12
    //   1766: iadd
    //   1767: aload #30
    //   1769: getfield leftMargin : I
    //   1772: iadd
    //   1773: aload #30
    //   1775: getfield rightMargin : I
    //   1778: iadd
    //   1779: aload_0
    //   1780: aload #28
    //   1782: invokevirtual r : (Landroid/view/View;)I
    //   1785: iadd
    //   1786: invokestatic max : (II)I
    //   1789: putfield k : I
    //   1792: iload #22
    //   1794: ldc 1073741824
    //   1796: if_icmpeq -> 1814
    //   1799: aload #30
    //   1801: getfield height : I
    //   1804: iconst_m1
    //   1805: if_icmpne -> 1814
    //   1808: iconst_1
    //   1809: istore #12
    //   1811: goto -> 1817
    //   1814: iconst_0
    //   1815: istore #12
    //   1817: aload #30
    //   1819: getfield topMargin : I
    //   1822: aload #30
    //   1824: getfield bottomMargin : I
    //   1827: iadd
    //   1828: istore #17
    //   1830: aload #28
    //   1832: invokevirtual getMeasuredHeight : ()I
    //   1835: iload #17
    //   1837: iadd
    //   1838: istore #16
    //   1840: iload #11
    //   1842: iload #16
    //   1844: invokestatic max : (II)I
    //   1847: istore #14
    //   1849: iload #12
    //   1851: ifeq -> 1861
    //   1854: iload #17
    //   1856: istore #11
    //   1858: goto -> 1865
    //   1861: iload #16
    //   1863: istore #11
    //   1865: iload #9
    //   1867: iload #11
    //   1869: invokestatic max : (II)I
    //   1872: istore #11
    //   1874: iload #8
    //   1876: ifeq -> 1894
    //   1879: aload #30
    //   1881: getfield height : I
    //   1884: iconst_m1
    //   1885: if_icmpne -> 1894
    //   1888: iconst_1
    //   1889: istore #8
    //   1891: goto -> 1897
    //   1894: iconst_0
    //   1895: istore #8
    //   1897: iload #25
    //   1899: ifeq -> 1984
    //   1902: aload #28
    //   1904: invokevirtual getBaseline : ()I
    //   1907: istore #17
    //   1909: iload #17
    //   1911: iconst_m1
    //   1912: if_icmpeq -> 1984
    //   1915: aload #30
    //   1917: getfield gravity : I
    //   1920: istore #12
    //   1922: iload #12
    //   1924: istore #9
    //   1926: iload #12
    //   1928: ifge -> 1937
    //   1931: aload_0
    //   1932: getfield j : I
    //   1935: istore #9
    //   1937: iload #9
    //   1939: bipush #112
    //   1941: iand
    //   1942: iconst_4
    //   1943: ishr
    //   1944: bipush #-2
    //   1946: iand
    //   1947: iconst_1
    //   1948: ishr
    //   1949: istore #9
    //   1951: aload #29
    //   1953: iload #9
    //   1955: aload #29
    //   1957: iload #9
    //   1959: iaload
    //   1960: iload #17
    //   1962: invokestatic max : (II)I
    //   1965: iastore
    //   1966: aload #27
    //   1968: iload #9
    //   1970: aload #27
    //   1972: iload #9
    //   1974: iaload
    //   1975: iload #16
    //   1977: iload #17
    //   1979: isub
    //   1980: invokestatic max : (II)I
    //   1983: iastore
    //   1984: iload #11
    //   1986: istore #9
    //   1988: iload #14
    //   1990: istore #11
    //   1992: goto -> 1995
    //   1995: iload #13
    //   1997: iconst_1
    //   1998: iadd
    //   1999: istore #13
    //   2001: goto -> 1492
    //   2004: aload_0
    //   2005: aload_0
    //   2006: getfield k : I
    //   2009: aload_0
    //   2010: invokevirtual getPaddingLeft : ()I
    //   2013: aload_0
    //   2014: invokevirtual getPaddingRight : ()I
    //   2017: iadd
    //   2018: iadd
    //   2019: putfield k : I
    //   2022: aload #29
    //   2024: iconst_1
    //   2025: iaload
    //   2026: iconst_m1
    //   2027: if_icmpne -> 2064
    //   2030: aload #29
    //   2032: iconst_0
    //   2033: iaload
    //   2034: iconst_m1
    //   2035: if_icmpne -> 2064
    //   2038: aload #29
    //   2040: iconst_2
    //   2041: iaload
    //   2042: iconst_m1
    //   2043: if_icmpne -> 2064
    //   2046: aload #29
    //   2048: iconst_3
    //   2049: iaload
    //   2050: iconst_m1
    //   2051: if_icmpeq -> 2057
    //   2054: goto -> 2064
    //   2057: iload #11
    //   2059: istore #6
    //   2061: goto -> 2122
    //   2064: iload #11
    //   2066: aload #29
    //   2068: iconst_3
    //   2069: iaload
    //   2070: aload #29
    //   2072: iconst_0
    //   2073: iaload
    //   2074: aload #29
    //   2076: iconst_1
    //   2077: iaload
    //   2078: aload #29
    //   2080: iconst_2
    //   2081: iaload
    //   2082: invokestatic max : (II)I
    //   2085: invokestatic max : (II)I
    //   2088: invokestatic max : (II)I
    //   2091: aload #27
    //   2093: iconst_3
    //   2094: iaload
    //   2095: aload #27
    //   2097: iconst_0
    //   2098: iaload
    //   2099: aload #27
    //   2101: iconst_1
    //   2102: iaload
    //   2103: aload #27
    //   2105: iconst_2
    //   2106: iaload
    //   2107: invokestatic max : (II)I
    //   2110: invokestatic max : (II)I
    //   2113: invokestatic max : (II)I
    //   2116: iadd
    //   2117: invokestatic max : (II)I
    //   2120: istore #6
    //   2122: iload #5
    //   2124: istore #13
    //   2126: iload #8
    //   2128: istore #5
    //   2130: iload #7
    //   2132: istore #8
    //   2134: iload #6
    //   2136: istore #7
    //   2138: iload #9
    //   2140: istore #6
    //   2142: iload #5
    //   2144: ifne -> 2157
    //   2147: iload #22
    //   2149: ldc 1073741824
    //   2151: if_icmpeq -> 2157
    //   2154: goto -> 2161
    //   2157: iload #7
    //   2159: istore #6
    //   2161: aload_0
    //   2162: iload #18
    //   2164: iload #13
    //   2166: ldc_w -16777216
    //   2169: iand
    //   2170: ior
    //   2171: iload #6
    //   2173: aload_0
    //   2174: invokevirtual getPaddingTop : ()I
    //   2177: aload_0
    //   2178: invokevirtual getPaddingBottom : ()I
    //   2181: iadd
    //   2182: iadd
    //   2183: aload_0
    //   2184: invokevirtual getSuggestedMinimumHeight : ()I
    //   2187: invokestatic max : (II)I
    //   2190: iload_2
    //   2191: iload #13
    //   2193: bipush #16
    //   2195: ishl
    //   2196: invokestatic resolveSizeAndState : (III)I
    //   2199: invokevirtual setMeasuredDimension : (II)V
    //   2202: iload #10
    //   2204: ifeq -> 2214
    //   2207: aload_0
    //   2208: iload #8
    //   2210: iload_1
    //   2211: invokespecial k : (II)V
    //   2214: return
  }
  
  int y(int paramInt) {
    return 0;
  }
  
  void z(int paramInt1, int paramInt2) {
    this.k = 0;
    int i3 = getVirtualChildCount();
    int i8 = View.MeasureSpec.getMode(paramInt1);
    int i6 = View.MeasureSpec.getMode(paramInt2);
    int i9 = this.g;
    boolean bool = this.m;
    int i = 0;
    int i5 = i;
    int n = i5;
    int j = n;
    int m = j;
    int i1 = m;
    int i4 = i1;
    int i2 = i4;
    float f = 0.0F;
    int k = 1;
    while (i1 < i3) {
      View view = s(i1);
      if (view == null) {
        this.k += y(i1);
      } else if (view.getVisibility() == 8) {
        i1 += p(view, i1);
      } else {
        if (t(i1))
          this.k += this.r; 
        a a = (a)view.getLayoutParams();
        float f1 = a.weight;
        f += f1;
        if (i6 == 1073741824 && a.height == 0 && f1 > 0.0F) {
          i4 = this.k;
          this.k = Math.max(i4, a.topMargin + i4 + a.bottomMargin);
          i4 = 1;
        } else {
          if (a.height == 0 && f1 > 0.0F) {
            a.height = -2;
            i11 = 0;
          } else {
            i11 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i12 = this.k;
          } else {
            i12 = 0;
          } 
          w(view, i1, paramInt1, 0, paramInt2, i12);
          if (i11 != Integer.MIN_VALUE)
            a.height = i11; 
          int i11 = view.getMeasuredHeight();
          int i12 = this.k;
          this.k = Math.max(i12, i12 + i11 + a.topMargin + a.bottomMargin + r(view));
          if (bool)
            n = Math.max(i11, n); 
        } 
        int i10 = i1;
        if (i9 >= 0 && i9 == i10 + 1)
          this.h = this.k; 
        if (i10 >= i9 || a.weight <= 0.0F) {
          if (i8 != 1073741824 && a.width == -1) {
            i1 = 1;
            i2 = i1;
          } else {
            i1 = 0;
          } 
          int i11 = a.leftMargin + a.rightMargin;
          int i12 = view.getMeasuredWidth() + i11;
          i5 = Math.max(i5, i12);
          int i13 = View.combineMeasuredStates(i, view.getMeasuredState());
          if (k && a.width == -1) {
            i = 1;
          } else {
            i = 0;
          } 
          if (a.weight > 0.0F) {
            if (i1 == 0)
              i11 = i12; 
            j = Math.max(j, i11);
            k = m;
          } else {
            if (i1 == 0)
              i11 = i12; 
            k = Math.max(m, i11);
          } 
          i1 = p(view, i10);
          m = k;
          i11 = i13;
          i1 += i10;
          k = i;
          i = i11;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i1++;
    } 
    if (this.k > 0 && t(i3))
      this.k += this.r; 
    if (bool && (i6 == Integer.MIN_VALUE || i6 == 0)) {
      this.k = 0;
      for (i1 = 0; i1 < i3; i1++) {
        View view = s(i1);
        if (view == null) {
          this.k += y(i1);
        } else if (view.getVisibility() == 8) {
          i1 += p(view, i1);
        } else {
          a a = (a)view.getLayoutParams();
          int i10 = this.k;
          this.k = Math.max(i10, i10 + n + a.topMargin + a.bottomMargin + r(view));
        } 
      } 
    } 
    i1 = this.k + getPaddingTop() + getPaddingBottom();
    this.k = i1;
    int i7 = View.resolveSizeAndState(Math.max(i1, getSuggestedMinimumHeight()), paramInt2, 0);
    i1 = (0xFFFFFF & i7) - this.k;
    if (i4 != 0 || (i1 != 0 && f > 0.0F)) {
      float f1 = this.l;
      if (f1 > 0.0F)
        f = f1; 
      this.k = 0;
      j = i1;
      i1 = 0;
      n = i5;
      while (i1 < i3) {
        View view = s(i1);
        if (view.getVisibility() != 8) {
          a a = (a)view.getLayoutParams();
          f1 = a.weight;
          if (f1 > 0.0F) {
            i5 = (int)(j * f1 / f);
            int i11 = getPaddingLeft();
            int i12 = getPaddingRight();
            int i13 = a.leftMargin;
            i9 = a.rightMargin;
            int i14 = a.width;
            i4 = j - i5;
            i11 = ViewGroup.getChildMeasureSpec(paramInt1, i11 + i12 + i13 + i9, i14);
            if (a.height != 0 || i6 != 1073741824) {
              i5 = view.getMeasuredHeight() + i5;
              j = i5;
              if (i5 < 0)
                j = 0; 
              view.measure(i11, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } else {
              if (i5 > 0) {
                j = i5;
              } else {
                j = 0;
              } 
              view.measure(i11, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } 
            i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFFFFFF00);
            f -= f1;
            j = i4;
          } 
          i5 = a.leftMargin + a.rightMargin;
          int i10 = view.getMeasuredWidth() + i5;
          i4 = Math.max(n, i10);
          if (i8 != 1073741824 && a.width == -1) {
            n = 1;
          } else {
            n = 0;
          } 
          if (n != 0) {
            n = i5;
          } else {
            n = i10;
          } 
          m = Math.max(m, n);
          if (k != 0 && a.width == -1) {
            k = 1;
          } else {
            k = 0;
          } 
          n = this.k;
          this.k = Math.max(n, view.getMeasuredHeight() + n + a.topMargin + a.bottomMargin + r(view));
          n = i4;
        } 
        i1++;
      } 
      this.k += getPaddingTop() + getPaddingBottom();
      j = i;
      i = m;
    } else {
      m = Math.max(m, j);
      if (bool && i6 != 1073741824)
        for (j = 0; j < i3; j++) {
          View view = s(j);
          if (view != null && view.getVisibility() != 8 && ((a)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824)); 
        }  
      j = i;
      i = m;
      n = i5;
    } 
    if (k != 0 || i8 == 1073741824)
      i = n; 
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, j), i7);
    if (i2 != 0)
      l(i3, paramInt2); 
  }
  
  public static class a extends LinearLayout.LayoutParams {
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */