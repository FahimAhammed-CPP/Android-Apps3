package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.core.view.w;
import b0.h;
import e.j;
import java.lang.ref.WeakReference;

class a0 {
  private final TextView a;
  
  private u0 b;
  
  private u0 c;
  
  private u0 d;
  
  private u0 e;
  
  private u0 f;
  
  private u0 g;
  
  private u0 h;
  
  private final b0 i;
  
  private int j = 0;
  
  private int k = -1;
  
  private Typeface l;
  
  private boolean m;
  
  a0(TextView paramTextView) {
    this.a = paramTextView;
    this.i = new b0(paramTextView);
  }
  
  private void B(int paramInt, float paramFloat) {
    this.i.u(paramInt, paramFloat);
  }
  
  private void C(Context paramContext, w0 paramw0) {
    this.j = paramw0.k(j.d3, this.j);
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 28) {
      int k = paramw0.k(j.g3, -1);
      this.k = k;
      if (k != -1)
        this.j = this.j & 0x2 | 0x0; 
    } 
    int i = j.f3;
    if (paramw0.s(i) || paramw0.s(j.h3)) {
      this.l = null;
      int k = j.h3;
      if (paramw0.s(k))
        i = k; 
      k = this.k;
      int m = this.j;
      if (!paramContext.isRestricted()) {
        a a = new a(this, k, m, new WeakReference<TextView>(this.a));
        try {
          boolean bool1;
          Typeface typeface = paramw0.j(i, this.j, a);
          if (typeface != null)
            if (j >= 28 && this.k != -1) {
              typeface = Typeface.create(typeface, 0);
              k = this.k;
              if ((this.j & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.l = Typeface.create(typeface, k, bool1);
            } else {
              this.l = typeface;
            }  
          if (this.l == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.m = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.l == null) {
        String str = paramw0.o(i);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
            typeface = Typeface.create(str, 0);
            i = this.k;
            boolean bool1 = bool;
            if ((this.j & 0x2) != 0)
              bool1 = true; 
            this.l = Typeface.create(typeface, i, bool1);
            return;
          } 
          this.l = Typeface.create((String)typeface, this.j);
        } 
      } 
      return;
    } 
    i = j.c3;
    if (paramw0.s(i)) {
      this.m = false;
      i = paramw0.k(i, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.l = Typeface.MONOSPACE;
          return;
        } 
        this.l = Typeface.SERIF;
        return;
      } 
      this.l = Typeface.SANS_SERIF;
    } 
  }
  
  private void a(Drawable paramDrawable, u0 paramu0) {
    if (paramDrawable != null && paramu0 != null)
      j.i(paramDrawable, paramu0, this.a.getDrawableState()); 
  }
  
  private static u0 d(Context paramContext, j paramj, int paramInt) {
    ColorStateList colorStateList = paramj.f(paramContext, paramInt);
    if (colorStateList != null) {
      u0 u01 = new u0();
      u01.d = true;
      u01.a = colorStateList;
      return u01;
    } 
    return null;
  }
  
  private void y(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6) {
    TextView textView;
    Drawable[] arrayOfDrawable;
    if (paramDrawable5 != null || paramDrawable6 != null) {
      arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      textView = this.a;
      if (paramDrawable5 == null)
        paramDrawable5 = arrayOfDrawable[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable[1]; 
      if (paramDrawable6 == null)
        paramDrawable6 = arrayOfDrawable[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable[3]; 
      textView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable5, paramDrawable2, paramDrawable6, paramDrawable4);
      return;
    } 
    if (textView != null || paramDrawable2 != null || arrayOfDrawable != null || paramDrawable4 != null) {
      Drawable drawable1;
      Drawable drawable2;
      Drawable[] arrayOfDrawable1 = this.a.getCompoundDrawablesRelative();
      if (arrayOfDrawable1[0] != null || arrayOfDrawable1[2] != null) {
        textView = this.a;
        drawable2 = arrayOfDrawable1[0];
        if (paramDrawable2 == null)
          paramDrawable2 = arrayOfDrawable1[1]; 
        paramDrawable6 = arrayOfDrawable1[2];
        if (paramDrawable4 == null)
          paramDrawable4 = arrayOfDrawable1[3]; 
        textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable2, paramDrawable2, paramDrawable6, paramDrawable4);
        return;
      } 
      Drawable[] arrayOfDrawable2 = this.a.getCompoundDrawables();
      TextView textView1 = this.a;
      if (textView == null)
        drawable1 = arrayOfDrawable2[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable2[1]; 
      if (drawable2 == null)
        drawable2 = arrayOfDrawable2[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable2[3]; 
      textView1.setCompoundDrawablesWithIntrinsicBounds(drawable1, paramDrawable2, drawable2, paramDrawable4);
      return;
    } 
  }
  
  private void z() {
    u0 u01 = this.h;
    this.b = u01;
    this.c = u01;
    this.d = u01;
    this.e = u01;
    this.f = u01;
    this.g = u01;
  }
  
  void A(int paramInt, float paramFloat) {
    if (!androidx.core.widget.b.a && !l())
      B(paramInt, paramFloat); 
  }
  
  void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (this.f != null || this.g != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  void c() {
    this.i.a();
  }
  
  int e() {
    return this.i.g();
  }
  
  int f() {
    return this.i.h();
  }
  
  int g() {
    return this.i.i();
  }
  
  int[] h() {
    return this.i.j();
  }
  
  int i() {
    return this.i.k();
  }
  
  ColorStateList j() {
    u0 u01 = this.h;
    return (u01 != null) ? u01.a : null;
  }
  
  PorterDuff.Mode k() {
    u0 u01 = this.h;
    return (u01 != null) ? u01.b : null;
  }
  
  boolean l() {
    return this.i.o();
  }
  
  @SuppressLint({"NewApi"})
  void m(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #13
    //   9: invokestatic b : ()Landroidx/appcompat/widget/j;
    //   12: astore #14
    //   14: getstatic e/j.Y : [I
    //   17: astore #9
    //   19: aload #13
    //   21: aload_1
    //   22: aload #9
    //   24: iload_2
    //   25: iconst_0
    //   26: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/w0;
    //   29: astore #10
    //   31: aload_0
    //   32: getfield a : Landroid/widget/TextView;
    //   35: astore #11
    //   37: aload #11
    //   39: aload #11
    //   41: invokevirtual getContext : ()Landroid/content/Context;
    //   44: aload #9
    //   46: aload_1
    //   47: aload #10
    //   49: invokevirtual r : ()Landroid/content/res/TypedArray;
    //   52: iload_2
    //   53: iconst_0
    //   54: invokestatic m0 : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   57: aload #10
    //   59: getstatic e/j.Z : I
    //   62: iconst_m1
    //   63: invokevirtual n : (II)I
    //   66: istore #4
    //   68: getstatic e/j.c0 : I
    //   71: istore_3
    //   72: aload #10
    //   74: iload_3
    //   75: invokevirtual s : (I)Z
    //   78: ifeq -> 99
    //   81: aload_0
    //   82: aload #13
    //   84: aload #14
    //   86: aload #10
    //   88: iload_3
    //   89: iconst_0
    //   90: invokevirtual n : (II)I
    //   93: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/u0;
    //   96: putfield b : Landroidx/appcompat/widget/u0;
    //   99: getstatic e/j.a0 : I
    //   102: istore_3
    //   103: aload #10
    //   105: iload_3
    //   106: invokevirtual s : (I)Z
    //   109: ifeq -> 130
    //   112: aload_0
    //   113: aload #13
    //   115: aload #14
    //   117: aload #10
    //   119: iload_3
    //   120: iconst_0
    //   121: invokevirtual n : (II)I
    //   124: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/u0;
    //   127: putfield c : Landroidx/appcompat/widget/u0;
    //   130: getstatic e/j.d0 : I
    //   133: istore_3
    //   134: aload #10
    //   136: iload_3
    //   137: invokevirtual s : (I)Z
    //   140: ifeq -> 161
    //   143: aload_0
    //   144: aload #13
    //   146: aload #14
    //   148: aload #10
    //   150: iload_3
    //   151: iconst_0
    //   152: invokevirtual n : (II)I
    //   155: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/u0;
    //   158: putfield d : Landroidx/appcompat/widget/u0;
    //   161: getstatic e/j.b0 : I
    //   164: istore_3
    //   165: aload #10
    //   167: iload_3
    //   168: invokevirtual s : (I)Z
    //   171: ifeq -> 192
    //   174: aload_0
    //   175: aload #13
    //   177: aload #14
    //   179: aload #10
    //   181: iload_3
    //   182: iconst_0
    //   183: invokevirtual n : (II)I
    //   186: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/u0;
    //   189: putfield e : Landroidx/appcompat/widget/u0;
    //   192: getstatic android/os/Build$VERSION.SDK_INT : I
    //   195: istore_3
    //   196: getstatic e/j.e0 : I
    //   199: istore #5
    //   201: aload #10
    //   203: iload #5
    //   205: invokevirtual s : (I)Z
    //   208: ifeq -> 230
    //   211: aload_0
    //   212: aload #13
    //   214: aload #14
    //   216: aload #10
    //   218: iload #5
    //   220: iconst_0
    //   221: invokevirtual n : (II)I
    //   224: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/u0;
    //   227: putfield f : Landroidx/appcompat/widget/u0;
    //   230: getstatic e/j.f0 : I
    //   233: istore #5
    //   235: aload #10
    //   237: iload #5
    //   239: invokevirtual s : (I)Z
    //   242: ifeq -> 264
    //   245: aload_0
    //   246: aload #13
    //   248: aload #14
    //   250: aload #10
    //   252: iload #5
    //   254: iconst_0
    //   255: invokevirtual n : (II)I
    //   258: invokestatic d : (Landroid/content/Context;Landroidx/appcompat/widget/j;I)Landroidx/appcompat/widget/u0;
    //   261: putfield g : Landroidx/appcompat/widget/u0;
    //   264: aload #10
    //   266: invokevirtual w : ()V
    //   269: aload_0
    //   270: getfield a : Landroid/widget/TextView;
    //   273: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   276: instanceof android/text/method/PasswordTransformationMethod
    //   279: istore #8
    //   281: iload #4
    //   283: iconst_m1
    //   284: if_icmpeq -> 424
    //   287: aload #13
    //   289: iload #4
    //   291: getstatic e/j.a3 : [I
    //   294: invokestatic t : (Landroid/content/Context;I[I)Landroidx/appcompat/widget/w0;
    //   297: astore #11
    //   299: iload #8
    //   301: ifne -> 335
    //   304: getstatic e/j.j3 : I
    //   307: istore #4
    //   309: aload #11
    //   311: iload #4
    //   313: invokevirtual s : (I)Z
    //   316: ifeq -> 335
    //   319: aload #11
    //   321: iload #4
    //   323: iconst_0
    //   324: invokevirtual a : (IZ)Z
    //   327: istore #6
    //   329: iconst_1
    //   330: istore #7
    //   332: goto -> 342
    //   335: iconst_0
    //   336: istore #6
    //   338: iload #6
    //   340: istore #7
    //   342: aload_0
    //   343: aload #13
    //   345: aload #11
    //   347: invokespecial C : (Landroid/content/Context;Landroidx/appcompat/widget/w0;)V
    //   350: getstatic e/j.k3 : I
    //   353: istore #4
    //   355: aload #11
    //   357: iload #4
    //   359: invokevirtual s : (I)Z
    //   362: ifeq -> 377
    //   365: aload #11
    //   367: iload #4
    //   369: invokevirtual o : (I)Ljava/lang/String;
    //   372: astore #10
    //   374: goto -> 380
    //   377: aconst_null
    //   378: astore #10
    //   380: iload_3
    //   381: bipush #26
    //   383: if_icmplt -> 413
    //   386: getstatic e/j.i3 : I
    //   389: istore #4
    //   391: aload #11
    //   393: iload #4
    //   395: invokevirtual s : (I)Z
    //   398: ifeq -> 413
    //   401: aload #11
    //   403: iload #4
    //   405: invokevirtual o : (I)Ljava/lang/String;
    //   408: astore #9
    //   410: goto -> 416
    //   413: aconst_null
    //   414: astore #9
    //   416: aload #11
    //   418: invokevirtual w : ()V
    //   421: goto -> 437
    //   424: iconst_0
    //   425: istore #6
    //   427: iload #6
    //   429: istore #7
    //   431: aconst_null
    //   432: astore #9
    //   434: aconst_null
    //   435: astore #10
    //   437: aload #13
    //   439: aload_1
    //   440: getstatic e/j.a3 : [I
    //   443: iload_2
    //   444: iconst_0
    //   445: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/w0;
    //   448: astore #12
    //   450: iload #8
    //   452: ifne -> 486
    //   455: getstatic e/j.j3 : I
    //   458: istore #4
    //   460: aload #12
    //   462: iload #4
    //   464: invokevirtual s : (I)Z
    //   467: ifeq -> 486
    //   470: aload #12
    //   472: iload #4
    //   474: iconst_0
    //   475: invokevirtual a : (IZ)Z
    //   478: istore #6
    //   480: iconst_1
    //   481: istore #7
    //   483: goto -> 486
    //   486: getstatic e/j.k3 : I
    //   489: istore #4
    //   491: aload #12
    //   493: iload #4
    //   495: invokevirtual s : (I)Z
    //   498: ifeq -> 510
    //   501: aload #12
    //   503: iload #4
    //   505: invokevirtual o : (I)Ljava/lang/String;
    //   508: astore #10
    //   510: aload #9
    //   512: astore #11
    //   514: iload_3
    //   515: bipush #26
    //   517: if_icmplt -> 548
    //   520: getstatic e/j.i3 : I
    //   523: istore #4
    //   525: aload #9
    //   527: astore #11
    //   529: aload #12
    //   531: iload #4
    //   533: invokevirtual s : (I)Z
    //   536: ifeq -> 548
    //   539: aload #12
    //   541: iload #4
    //   543: invokevirtual o : (I)Ljava/lang/String;
    //   546: astore #11
    //   548: iload_3
    //   549: bipush #28
    //   551: if_icmplt -> 589
    //   554: getstatic e/j.b3 : I
    //   557: istore #4
    //   559: aload #12
    //   561: iload #4
    //   563: invokevirtual s : (I)Z
    //   566: ifeq -> 589
    //   569: aload #12
    //   571: iload #4
    //   573: iconst_m1
    //   574: invokevirtual f : (II)I
    //   577: ifne -> 589
    //   580: aload_0
    //   581: getfield a : Landroid/widget/TextView;
    //   584: iconst_0
    //   585: fconst_0
    //   586: invokevirtual setTextSize : (IF)V
    //   589: aload_0
    //   590: aload #13
    //   592: aload #12
    //   594: invokespecial C : (Landroid/content/Context;Landroidx/appcompat/widget/w0;)V
    //   597: aload #12
    //   599: invokevirtual w : ()V
    //   602: iload #8
    //   604: ifne -> 618
    //   607: iload #7
    //   609: ifeq -> 618
    //   612: aload_0
    //   613: iload #6
    //   615: invokevirtual s : (Z)V
    //   618: aload_0
    //   619: getfield l : Landroid/graphics/Typeface;
    //   622: astore #9
    //   624: aload #9
    //   626: ifnull -> 662
    //   629: aload_0
    //   630: getfield k : I
    //   633: iconst_m1
    //   634: if_icmpne -> 653
    //   637: aload_0
    //   638: getfield a : Landroid/widget/TextView;
    //   641: aload #9
    //   643: aload_0
    //   644: getfield j : I
    //   647: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   650: goto -> 662
    //   653: aload_0
    //   654: getfield a : Landroid/widget/TextView;
    //   657: aload #9
    //   659: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   662: aload #11
    //   664: ifnull -> 677
    //   667: aload_0
    //   668: getfield a : Landroid/widget/TextView;
    //   671: aload #11
    //   673: invokevirtual setFontVariationSettings : (Ljava/lang/String;)Z
    //   676: pop
    //   677: aload #10
    //   679: ifnull -> 730
    //   682: iload_3
    //   683: bipush #24
    //   685: if_icmplt -> 703
    //   688: aload_0
    //   689: getfield a : Landroid/widget/TextView;
    //   692: aload #10
    //   694: invokestatic forLanguageTags : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   697: invokevirtual setTextLocales : (Landroid/os/LocaleList;)V
    //   700: goto -> 730
    //   703: aload #10
    //   705: iconst_0
    //   706: aload #10
    //   708: bipush #44
    //   710: invokevirtual indexOf : (I)I
    //   713: invokevirtual substring : (II)Ljava/lang/String;
    //   716: astore #9
    //   718: aload_0
    //   719: getfield a : Landroid/widget/TextView;
    //   722: aload #9
    //   724: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   727: invokevirtual setTextLocale : (Ljava/util/Locale;)V
    //   730: aload_0
    //   731: getfield i : Landroidx/appcompat/widget/b0;
    //   734: aload_1
    //   735: iload_2
    //   736: invokevirtual p : (Landroid/util/AttributeSet;I)V
    //   739: getstatic androidx/core/widget/b.a : Z
    //   742: ifeq -> 827
    //   745: aload_0
    //   746: getfield i : Landroidx/appcompat/widget/b0;
    //   749: invokevirtual k : ()I
    //   752: ifeq -> 827
    //   755: aload_0
    //   756: getfield i : Landroidx/appcompat/widget/b0;
    //   759: invokevirtual j : ()[I
    //   762: astore #9
    //   764: aload #9
    //   766: arraylength
    //   767: ifle -> 827
    //   770: aload_0
    //   771: getfield a : Landroid/widget/TextView;
    //   774: invokevirtual getAutoSizeStepGranularity : ()I
    //   777: i2f
    //   778: ldc_w -1.0
    //   781: fcmpl
    //   782: ifeq -> 817
    //   785: aload_0
    //   786: getfield a : Landroid/widget/TextView;
    //   789: aload_0
    //   790: getfield i : Landroidx/appcompat/widget/b0;
    //   793: invokevirtual h : ()I
    //   796: aload_0
    //   797: getfield i : Landroidx/appcompat/widget/b0;
    //   800: invokevirtual g : ()I
    //   803: aload_0
    //   804: getfield i : Landroidx/appcompat/widget/b0;
    //   807: invokevirtual i : ()I
    //   810: iconst_0
    //   811: invokevirtual setAutoSizeTextTypeUniformWithConfiguration : (IIII)V
    //   814: goto -> 827
    //   817: aload_0
    //   818: getfield a : Landroid/widget/TextView;
    //   821: aload #9
    //   823: iconst_0
    //   824: invokevirtual setAutoSizeTextTypeUniformWithPresetSizes : ([II)V
    //   827: aload #13
    //   829: aload_1
    //   830: getstatic e/j.g0 : [I
    //   833: invokestatic u : (Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroidx/appcompat/widget/w0;
    //   836: astore #15
    //   838: aload #15
    //   840: getstatic e/j.o0 : I
    //   843: iconst_m1
    //   844: invokevirtual n : (II)I
    //   847: istore_2
    //   848: iload_2
    //   849: iconst_m1
    //   850: if_icmpeq -> 865
    //   853: aload #14
    //   855: aload #13
    //   857: iload_2
    //   858: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   861: astore_1
    //   862: goto -> 867
    //   865: aconst_null
    //   866: astore_1
    //   867: aload #15
    //   869: getstatic e/j.t0 : I
    //   872: iconst_m1
    //   873: invokevirtual n : (II)I
    //   876: istore_2
    //   877: iload_2
    //   878: iconst_m1
    //   879: if_icmpeq -> 895
    //   882: aload #14
    //   884: aload #13
    //   886: iload_2
    //   887: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   890: astore #9
    //   892: goto -> 898
    //   895: aconst_null
    //   896: astore #9
    //   898: aload #15
    //   900: getstatic e/j.p0 : I
    //   903: iconst_m1
    //   904: invokevirtual n : (II)I
    //   907: istore_2
    //   908: iload_2
    //   909: iconst_m1
    //   910: if_icmpeq -> 926
    //   913: aload #14
    //   915: aload #13
    //   917: iload_2
    //   918: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   921: astore #10
    //   923: goto -> 929
    //   926: aconst_null
    //   927: astore #10
    //   929: aload #15
    //   931: getstatic e/j.m0 : I
    //   934: iconst_m1
    //   935: invokevirtual n : (II)I
    //   938: istore_2
    //   939: iload_2
    //   940: iconst_m1
    //   941: if_icmpeq -> 957
    //   944: aload #14
    //   946: aload #13
    //   948: iload_2
    //   949: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   952: astore #11
    //   954: goto -> 960
    //   957: aconst_null
    //   958: astore #11
    //   960: aload #15
    //   962: getstatic e/j.q0 : I
    //   965: iconst_m1
    //   966: invokevirtual n : (II)I
    //   969: istore_2
    //   970: iload_2
    //   971: iconst_m1
    //   972: if_icmpeq -> 988
    //   975: aload #14
    //   977: aload #13
    //   979: iload_2
    //   980: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   983: astore #12
    //   985: goto -> 991
    //   988: aconst_null
    //   989: astore #12
    //   991: aload #15
    //   993: getstatic e/j.n0 : I
    //   996: iconst_m1
    //   997: invokevirtual n : (II)I
    //   1000: istore_2
    //   1001: iload_2
    //   1002: iconst_m1
    //   1003: if_icmpeq -> 1019
    //   1006: aload #14
    //   1008: aload #13
    //   1010: iload_2
    //   1011: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1014: astore #13
    //   1016: goto -> 1022
    //   1019: aconst_null
    //   1020: astore #13
    //   1022: aload_0
    //   1023: aload_1
    //   1024: aload #9
    //   1026: aload #10
    //   1028: aload #11
    //   1030: aload #12
    //   1032: aload #13
    //   1034: invokespecial y : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1037: getstatic e/j.r0 : I
    //   1040: istore_2
    //   1041: aload #15
    //   1043: iload_2
    //   1044: invokevirtual s : (I)Z
    //   1047: ifeq -> 1065
    //   1050: aload #15
    //   1052: iload_2
    //   1053: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   1056: astore_1
    //   1057: aload_0
    //   1058: getfield a : Landroid/widget/TextView;
    //   1061: aload_1
    //   1062: invokestatic g : (Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V
    //   1065: getstatic e/j.s0 : I
    //   1068: istore_2
    //   1069: aload #15
    //   1071: iload_2
    //   1072: invokevirtual s : (I)Z
    //   1075: ifeq -> 1098
    //   1078: aload #15
    //   1080: iload_2
    //   1081: iconst_m1
    //   1082: invokevirtual k : (II)I
    //   1085: aconst_null
    //   1086: invokestatic e : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   1089: astore_1
    //   1090: aload_0
    //   1091: getfield a : Landroid/widget/TextView;
    //   1094: aload_1
    //   1095: invokestatic h : (Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V
    //   1098: aload #15
    //   1100: getstatic e/j.v0 : I
    //   1103: iconst_m1
    //   1104: invokevirtual f : (II)I
    //   1107: istore_2
    //   1108: aload #15
    //   1110: getstatic e/j.w0 : I
    //   1113: iconst_m1
    //   1114: invokevirtual f : (II)I
    //   1117: istore_3
    //   1118: aload #15
    //   1120: getstatic e/j.x0 : I
    //   1123: iconst_m1
    //   1124: invokevirtual f : (II)I
    //   1127: istore #4
    //   1129: aload #15
    //   1131: invokevirtual w : ()V
    //   1134: iload_2
    //   1135: iconst_m1
    //   1136: if_icmpeq -> 1147
    //   1139: aload_0
    //   1140: getfield a : Landroid/widget/TextView;
    //   1143: iload_2
    //   1144: invokestatic j : (Landroid/widget/TextView;I)V
    //   1147: iload_3
    //   1148: iconst_m1
    //   1149: if_icmpeq -> 1160
    //   1152: aload_0
    //   1153: getfield a : Landroid/widget/TextView;
    //   1156: iload_3
    //   1157: invokestatic k : (Landroid/widget/TextView;I)V
    //   1160: iload #4
    //   1162: iconst_m1
    //   1163: if_icmpeq -> 1175
    //   1166: aload_0
    //   1167: getfield a : Landroid/widget/TextView;
    //   1170: iload #4
    //   1172: invokestatic l : (Landroid/widget/TextView;I)V
    //   1175: return
  }
  
  void n(WeakReference<TextView> paramWeakReference, Typeface paramTypeface) {
    if (this.m) {
      this.l = paramTypeface;
      TextView textView = paramWeakReference.get();
      if (textView != null) {
        if (w.R((View)textView)) {
          textView.post(new b(this, textView, paramTypeface, this.j));
          return;
        } 
        textView.setTypeface(paramTypeface, this.j);
      } 
    } 
  }
  
  void o(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!androidx.core.widget.b.a)
      c(); 
  }
  
  void p() {
    b();
  }
  
  void q(Context paramContext, int paramInt) {
    w0 w0 = w0.t(paramContext, paramInt, j.a3);
    paramInt = j.j3;
    if (w0.s(paramInt))
      s(w0.a(paramInt, false)); 
    paramInt = Build.VERSION.SDK_INT;
    int i = j.b3;
    if (w0.s(i) && w0.f(i, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    C(paramContext, w0);
    if (paramInt >= 26) {
      paramInt = j.i3;
      if (w0.s(paramInt)) {
        String str = w0.o(paramInt);
        if (str != null)
          this.a.setFontVariationSettings(str); 
      } 
    } 
    w0.w();
    Typeface typeface = this.l;
    if (typeface != null)
      this.a.setTypeface(typeface, this.j); 
  }
  
  void r(TextView paramTextView, InputConnection paramInputConnection, EditorInfo paramEditorInfo) {
    if (Build.VERSION.SDK_INT < 30 && paramInputConnection != null)
      n0.a.f(paramEditorInfo, paramTextView.getText()); 
  }
  
  void s(boolean paramBoolean) {
    this.a.setAllCaps(paramBoolean);
  }
  
  void t(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    this.i.q(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void u(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    this.i.r(paramArrayOfint, paramInt);
  }
  
  void v(int paramInt) {
    this.i.s(paramInt);
  }
  
  void w(ColorStateList paramColorStateList) {
    boolean bool;
    if (this.h == null)
      this.h = new u0(); 
    u0 u01 = this.h;
    u01.a = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    u01.d = bool;
    z();
  }
  
  void x(PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.h == null)
      this.h = new u0(); 
    u0 u01 = this.h;
    u01.b = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    u01.c = bool;
    z();
  }
  
  class a extends h.d {
    a(a0 this$0, int param1Int1, int param1Int2, WeakReference param1WeakReference) {}
    
    public void d(int param1Int) {}
    
    public void e(Typeface param1Typeface) {
      Typeface typeface = param1Typeface;
      if (Build.VERSION.SDK_INT >= 28) {
        int i = this.a;
        typeface = param1Typeface;
        if (i != -1) {
          boolean bool;
          if ((this.b & 0x2) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          typeface = Typeface.create(param1Typeface, i, bool);
        } 
      } 
      this.d.n(this.c, typeface);
    }
  }
  
  class b implements Runnable {
    b(a0 this$0, TextView param1TextView, Typeface param1Typeface, int param1Int) {}
    
    public void run() {
      this.f.setTypeface(this.g, this.h);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */