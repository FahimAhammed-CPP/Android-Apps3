package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import e.a;
import g.a;

public class q extends MultiAutoCompleteTextView {
  private static final int[] i = new int[] { 16843126 };
  
  private final e f;
  
  private final a0 g;
  
  private final l h;
  
  public q(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.p);
  }
  
  public q(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(t0.b(paramContext), paramAttributeSet, paramInt);
    r0.a((View)this, getContext());
    w0 w0 = w0.v(getContext(), paramAttributeSet, i, paramInt, 0);
    if (w0.s(0))
      setDropDownBackgroundDrawable(w0.g(0)); 
    w0.w();
    e e1 = new e((View)this);
    this.f = e1;
    e1.e(paramAttributeSet, paramInt);
    a0 a01 = new a0((TextView)this);
    this.g = a01;
    a01.m(paramAttributeSet, paramInt);
    a01.b();
    l l1 = new l((EditText)this);
    this.h = l1;
    l1.c(paramAttributeSet, paramInt);
    a(l1);
  }
  
  void a(l paraml) {
    KeyListener keyListener = getKeyListener();
    if (paraml.b(keyListener)) {
      boolean bool = isFocusable();
      int i = getInputType();
      KeyListener keyListener1 = paraml.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool);
    } 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.f;
    if (e1 != null)
      e1.b(); 
    a0 a01 = this.g;
    if (a01 != null)
      a01.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.f;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.f;
    return (e1 != null) ? e1.d() : null;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = n.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
    return this.h.d(inputConnection, paramEditorInfo);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.f;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.f;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.b(getContext(), paramInt));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.h.e(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.h.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.f;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.f;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    a0 a01 = this.g;
    if (a01 != null)
      a01.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */