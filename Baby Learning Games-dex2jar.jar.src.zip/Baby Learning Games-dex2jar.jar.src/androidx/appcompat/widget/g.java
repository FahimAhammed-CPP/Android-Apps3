package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import androidx.core.widget.j;
import e.a;
import g.a;

public class g extends CheckedTextView {
  private final h f;
  
  private final e g;
  
  private final a0 h;
  
  private m i;
  
  public g(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.s);
  }
  
  public g(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(t0.b(paramContext), paramAttributeSet, paramInt);
    r0.a((View)this, getContext());
    a0 a01 = new a0((TextView)this);
    this.h = a01;
    a01.m(paramAttributeSet, paramInt);
    a01.b();
    e e1 = new e((View)this);
    this.g = e1;
    e1.e(paramAttributeSet, paramInt);
    h h1 = new h(this);
    this.f = h1;
    h1.d(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private m getEmojiTextViewHelper() {
    if (this.i == null)
      this.i = new m((TextView)this); 
    return this.i;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    a0 a01 = this.h;
    if (a01 != null)
      a01.b(); 
    e e1 = this.g;
    if (e1 != null)
      e1.b(); 
    h h1 = this.f;
    if (h1 != null)
      h1.a(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.p(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.g;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.g;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportCheckMarkTintList() {
    h h1 = this.f;
    return (h1 != null) ? h1.b() : null;
  }
  
  public PorterDuff.Mode getSupportCheckMarkTintMode() {
    h h1 = this.f;
    return (h1 != null) ? h1.c() : null;
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return n.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.g;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.g;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(a.b(getContext(), paramInt));
  }
  
  public void setCheckMarkDrawable(Drawable paramDrawable) {
    super.setCheckMarkDrawable(paramDrawable);
    h h1 = this.f;
    if (h1 != null)
      h1.e(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.q((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.g;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.g;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportCheckMarkTintList(ColorStateList paramColorStateList) {
    h h1 = this.f;
    if (h1 != null)
      h1.f(paramColorStateList); 
  }
  
  public void setSupportCheckMarkTintMode(PorterDuff.Mode paramMode) {
    h h1 = this.f;
    if (h1 != null)
      h1.g(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    a0 a01 = this.h;
    if (a01 != null)
      a01.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */