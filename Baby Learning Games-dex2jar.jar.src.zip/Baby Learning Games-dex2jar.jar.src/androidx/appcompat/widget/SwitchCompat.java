package androidx.appcompat.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.core.view.w;
import androidx.core.widget.j;
import androidx.emoji2.text.d;
import e.h;
import e.j;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

public class SwitchCompat extends CompoundButton {
  private static final Property<SwitchCompat, Float> W = new a(Float.class, "thumbPos");
  
  private static final int[] a0 = new int[] { 16842912 };
  
  private float A;
  
  private float B;
  
  private VelocityTracker C = VelocityTracker.obtain();
  
  private int D;
  
  float E;
  
  private int F;
  
  private int G;
  
  private int H;
  
  private int I;
  
  private int J;
  
  private int K;
  
  private int L;
  
  private final TextPaint M;
  
  private ColorStateList N;
  
  private Layout O;
  
  private Layout P;
  
  private TransformationMethod Q;
  
  ObjectAnimator R;
  
  private final a0 S;
  
  private m T;
  
  private b U;
  
  private final Rect V = new Rect();
  
  private Drawable f;
  
  private ColorStateList g = null;
  
  private PorterDuff.Mode h = null;
  
  private boolean i = false;
  
  private boolean j = false;
  
  private Drawable k;
  
  private ColorStateList l = null;
  
  private PorterDuff.Mode m = null;
  
  private boolean n = false;
  
  private boolean o = false;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private boolean s;
  
  private CharSequence t;
  
  private CharSequence u;
  
  private CharSequence v;
  
  private CharSequence w;
  
  private boolean x;
  
  private int y;
  
  private int z;
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.O);
  }
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    r0.a((View)this, getContext());
    TextPaint textPaint = new TextPaint(1);
    this.M = textPaint;
    textPaint.density = (getResources().getDisplayMetrics()).density;
    int[] arrayOfInt = j.L2;
    w0 w0 = w0.v(paramContext, paramAttributeSet, arrayOfInt, paramInt, 0);
    w.m0((View)this, paramContext, arrayOfInt, paramAttributeSet, w0.r(), paramInt, 0);
    Drawable drawable = w0.g(j.O2);
    this.f = drawable;
    if (drawable != null)
      drawable.setCallback((Drawable.Callback)this); 
    drawable = w0.g(j.X2);
    this.k = drawable;
    if (drawable != null)
      drawable.setCallback((Drawable.Callback)this); 
    setTextOnInternal(w0.p(j.M2));
    setTextOffInternal(w0.p(j.N2));
    this.x = w0.a(j.P2, true);
    this.p = w0.f(j.U2, 0);
    this.q = w0.f(j.R2, 0);
    this.r = w0.f(j.S2, 0);
    this.s = w0.a(j.Q2, false);
    ColorStateList colorStateList2 = w0.c(j.V2);
    if (colorStateList2 != null) {
      this.g = colorStateList2;
      this.i = true;
    } 
    PorterDuff.Mode mode2 = f0.e(w0.k(j.W2, -1), null);
    if (this.h != mode2) {
      this.h = mode2;
      this.j = true;
    } 
    if (this.i || this.j)
      b(); 
    ColorStateList colorStateList1 = w0.c(j.Y2);
    if (colorStateList1 != null) {
      this.l = colorStateList1;
      this.n = true;
    } 
    PorterDuff.Mode mode1 = f0.e(w0.k(j.Z2, -1), null);
    if (this.m != mode1) {
      this.m = mode1;
      this.o = true;
    } 
    if (this.n || this.o)
      c(); 
    int i = w0.n(j.T2, 0);
    if (i != 0)
      m(paramContext, i); 
    a0 a01 = new a0((TextView)this);
    this.S = a01;
    a01.m(paramAttributeSet, paramInt);
    w0.w();
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    this.z = viewConfiguration.getScaledTouchSlop();
    this.D = viewConfiguration.getScaledMinimumFlingVelocity();
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
    refreshDrawableState();
    setChecked(isChecked());
  }
  
  private void a(boolean paramBoolean) {
    float f;
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(this, W, new float[] { f });
    this.R = objectAnimator;
    objectAnimator.setDuration(250L);
    this.R.setAutoCancel(true);
    this.R.start();
  }
  
  private void b() {
    Drawable drawable = this.f;
    if (drawable != null && (this.i || this.j)) {
      drawable = d0.a.r(drawable).mutate();
      this.f = drawable;
      if (this.i)
        d0.a.o(drawable, this.g); 
      if (this.j)
        d0.a.p(this.f, this.h); 
      if (this.f.isStateful())
        this.f.setState(getDrawableState()); 
    } 
  }
  
  private void c() {
    Drawable drawable = this.k;
    if (drawable != null && (this.n || this.o)) {
      drawable = d0.a.r(drawable).mutate();
      this.k = drawable;
      if (this.n)
        d0.a.o(drawable, this.l); 
      if (this.o)
        d0.a.p(this.k, this.m); 
      if (this.k.isStateful())
        this.k.setState(getDrawableState()); 
    } 
  }
  
  private void d() {
    ObjectAnimator objectAnimator = this.R;
    if (objectAnimator != null)
      objectAnimator.cancel(); 
  }
  
  private void e(MotionEvent paramMotionEvent) {
    paramMotionEvent = MotionEvent.obtain(paramMotionEvent);
    paramMotionEvent.setAction(3);
    super.onTouchEvent(paramMotionEvent);
    paramMotionEvent.recycle();
  }
  
  private static float f(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat1 < paramFloat2)
      return paramFloat2; 
    paramFloat2 = paramFloat1;
    if (paramFloat1 > paramFloat3)
      paramFloat2 = paramFloat3; 
    return paramFloat2;
  }
  
  private CharSequence g(CharSequence paramCharSequence) {
    TransformationMethod transformationMethod = getEmojiTextViewHelper().f(this.Q);
    CharSequence charSequence = paramCharSequence;
    if (transformationMethod != null)
      charSequence = transformationMethod.getTransformation(paramCharSequence, (View)this); 
    return charSequence;
  }
  
  private m getEmojiTextViewHelper() {
    if (this.T == null)
      this.T = new m((TextView)this); 
    return this.T;
  }
  
  private boolean getTargetCheckedState() {
    return (this.E > 0.5F);
  }
  
  private int getThumbOffset() {
    float f;
    if (d1.b((View)this)) {
      f = 1.0F - this.E;
    } else {
      f = this.E;
    } 
    return (int)(f * getThumbScrollRange() + 0.5F);
  }
  
  private int getThumbScrollRange() {
    Drawable drawable = this.k;
    if (drawable != null) {
      Rect rect1;
      Rect rect2 = this.V;
      drawable.getPadding(rect2);
      drawable = this.f;
      if (drawable != null) {
        rect1 = f0.d(drawable);
      } else {
        rect1 = f0.c;
      } 
      return this.F - this.H - rect2.left - rect2.right - rect1.left - rect1.right;
    } 
    return 0;
  }
  
  private boolean h(float paramFloat1, float paramFloat2) {
    Drawable drawable = this.f;
    boolean bool2 = false;
    if (drawable == null)
      return false; 
    int k = getThumbOffset();
    this.f.getPadding(this.V);
    int i = this.J;
    int j = this.z;
    k = this.I + k - j;
    int n = this.H;
    Rect rect = this.V;
    int i1 = rect.left;
    int i2 = rect.right;
    int i3 = this.L;
    boolean bool1 = bool2;
    if (paramFloat1 > k) {
      bool1 = bool2;
      if (paramFloat1 < (n + k + i1 + i2 + j)) {
        bool1 = bool2;
        if (paramFloat2 > (i - j)) {
          bool1 = bool2;
          if (paramFloat2 < (i3 + j))
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  private Layout i(CharSequence paramCharSequence) {
    boolean bool;
    TextPaint textPaint = this.M;
    if (paramCharSequence != null) {
      bool = (int)Math.ceil(Layout.getDesiredWidth(paramCharSequence, textPaint));
    } else {
      bool = false;
    } 
    return (Layout)new StaticLayout(paramCharSequence, textPaint, bool, Layout.Alignment.ALIGN_NORMAL, 1.0F, 0.0F, true);
  }
  
  private void k() {
    if (Build.VERSION.SDK_INT >= 30) {
      CharSequence charSequence2 = this.v;
      CharSequence charSequence1 = charSequence2;
      if (charSequence2 == null)
        charSequence1 = getResources().getString(h.b); 
      w.E0((View)this, charSequence1);
    } 
  }
  
  private void l() {
    if (Build.VERSION.SDK_INT >= 30) {
      CharSequence charSequence2 = this.t;
      CharSequence charSequence1 = charSequence2;
      if (charSequence2 == null)
        charSequence1 = getResources().getString(h.c); 
      w.E0((View)this, charSequence1);
    } 
  }
  
  private void o(int paramInt1, int paramInt2) {
    Typeface typeface;
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3) {
          typeface = null;
        } else {
          typeface = Typeface.MONOSPACE;
        } 
      } else {
        typeface = Typeface.SERIF;
      } 
    } else {
      typeface = Typeface.SANS_SERIF;
    } 
    n(typeface, paramInt2);
  }
  
  private void p() {
    if (this.U == null) {
      if (!this.T.b())
        return; 
      if (d.h()) {
        d d = d.b();
        int i = d.d();
        if (i == 3 || i == 0) {
          b b1 = new b(this);
          this.U = b1;
          d.s(b1);
        } 
      } 
    } 
  }
  
  private void q(MotionEvent paramMotionEvent) {
    this.y = 0;
    int i = paramMotionEvent.getAction();
    boolean bool1 = true;
    if (i == 1 && isEnabled()) {
      i = 1;
    } else {
      i = 0;
    } 
    boolean bool2 = isChecked();
    if (i != 0) {
      this.C.computeCurrentVelocity(1000);
      float f = this.C.getXVelocity();
      if (Math.abs(f) > this.D) {
        if (d1.b((View)this) ? (f < 0.0F) : (f > 0.0F))
          bool1 = false; 
      } else {
        bool1 = getTargetCheckedState();
      } 
    } else {
      bool1 = bool2;
    } 
    if (bool1 != bool2)
      playSoundEffect(0); 
    setChecked(bool1);
    e(paramMotionEvent);
  }
  
  private void setTextOffInternal(CharSequence paramCharSequence) {
    this.v = paramCharSequence;
    this.w = g(paramCharSequence);
    this.P = null;
    if (this.x)
      p(); 
  }
  
  private void setTextOnInternal(CharSequence paramCharSequence) {
    this.t = paramCharSequence;
    this.u = g(paramCharSequence);
    this.O = null;
    if (this.x)
      p(); 
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: getfield V : Landroid/graphics/Rect;
    //   4: astore #14
    //   6: aload_0
    //   7: getfield I : I
    //   10: istore #5
    //   12: aload_0
    //   13: getfield J : I
    //   16: istore #8
    //   18: aload_0
    //   19: getfield K : I
    //   22: istore #6
    //   24: aload_0
    //   25: getfield L : I
    //   28: istore #9
    //   30: aload_0
    //   31: invokespecial getThumbOffset : ()I
    //   34: iload #5
    //   36: iadd
    //   37: istore_3
    //   38: aload_0
    //   39: getfield f : Landroid/graphics/drawable/Drawable;
    //   42: astore #13
    //   44: aload #13
    //   46: ifnull -> 59
    //   49: aload #13
    //   51: invokestatic d : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Rect;
    //   54: astore #13
    //   56: goto -> 64
    //   59: getstatic androidx/appcompat/widget/f0.c : Landroid/graphics/Rect;
    //   62: astore #13
    //   64: aload_0
    //   65: getfield k : Landroid/graphics/drawable/Drawable;
    //   68: astore #15
    //   70: iload_3
    //   71: istore_2
    //   72: aload #15
    //   74: ifnull -> 274
    //   77: aload #15
    //   79: aload #14
    //   81: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   84: pop
    //   85: aload #14
    //   87: getfield left : I
    //   90: istore #4
    //   92: iload_3
    //   93: iload #4
    //   95: iadd
    //   96: istore #10
    //   98: aload #13
    //   100: ifnull -> 238
    //   103: aload #13
    //   105: getfield left : I
    //   108: istore_3
    //   109: iload #5
    //   111: istore_2
    //   112: iload_3
    //   113: iload #4
    //   115: if_icmple -> 126
    //   118: iload #5
    //   120: iload_3
    //   121: iload #4
    //   123: isub
    //   124: iadd
    //   125: istore_2
    //   126: aload #13
    //   128: getfield top : I
    //   131: istore_3
    //   132: aload #14
    //   134: getfield top : I
    //   137: istore #4
    //   139: iload_3
    //   140: iload #4
    //   142: if_icmple -> 156
    //   145: iload_3
    //   146: iload #4
    //   148: isub
    //   149: iload #8
    //   151: iadd
    //   152: istore_3
    //   153: goto -> 159
    //   156: iload #8
    //   158: istore_3
    //   159: aload #13
    //   161: getfield right : I
    //   164: istore #5
    //   166: aload #14
    //   168: getfield right : I
    //   171: istore #7
    //   173: iload #6
    //   175: istore #4
    //   177: iload #5
    //   179: iload #7
    //   181: if_icmple -> 194
    //   184: iload #6
    //   186: iload #5
    //   188: iload #7
    //   190: isub
    //   191: isub
    //   192: istore #4
    //   194: aload #13
    //   196: getfield bottom : I
    //   199: istore #11
    //   201: aload #14
    //   203: getfield bottom : I
    //   206: istore #12
    //   208: iload_2
    //   209: istore #5
    //   211: iload #4
    //   213: istore #6
    //   215: iload_3
    //   216: istore #7
    //   218: iload #11
    //   220: iload #12
    //   222: if_icmple -> 242
    //   225: iload #9
    //   227: iload #11
    //   229: iload #12
    //   231: isub
    //   232: isub
    //   233: istore #7
    //   235: goto -> 258
    //   238: iload #8
    //   240: istore #7
    //   242: iload #9
    //   244: istore_2
    //   245: iload #7
    //   247: istore_3
    //   248: iload_2
    //   249: istore #7
    //   251: iload #6
    //   253: istore #4
    //   255: iload #5
    //   257: istore_2
    //   258: aload_0
    //   259: getfield k : Landroid/graphics/drawable/Drawable;
    //   262: iload_2
    //   263: iload_3
    //   264: iload #4
    //   266: iload #7
    //   268: invokevirtual setBounds : (IIII)V
    //   271: iload #10
    //   273: istore_2
    //   274: aload_0
    //   275: getfield f : Landroid/graphics/drawable/Drawable;
    //   278: astore #13
    //   280: aload #13
    //   282: ifnull -> 349
    //   285: aload #13
    //   287: aload #14
    //   289: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   292: pop
    //   293: iload_2
    //   294: aload #14
    //   296: getfield left : I
    //   299: isub
    //   300: istore_3
    //   301: iload_2
    //   302: aload_0
    //   303: getfield H : I
    //   306: iadd
    //   307: aload #14
    //   309: getfield right : I
    //   312: iadd
    //   313: istore_2
    //   314: aload_0
    //   315: getfield f : Landroid/graphics/drawable/Drawable;
    //   318: iload_3
    //   319: iload #8
    //   321: iload_2
    //   322: iload #9
    //   324: invokevirtual setBounds : (IIII)V
    //   327: aload_0
    //   328: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   331: astore #13
    //   333: aload #13
    //   335: ifnull -> 349
    //   338: aload #13
    //   340: iload_3
    //   341: iload #8
    //   343: iload_2
    //   344: iload #9
    //   346: invokestatic l : (Landroid/graphics/drawable/Drawable;IIII)V
    //   349: aload_0
    //   350: aload_1
    //   351: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   354: return
  }
  
  public void drawableHotspotChanged(float paramFloat1, float paramFloat2) {
    super.drawableHotspotChanged(paramFloat1, paramFloat2);
    Drawable drawable = this.f;
    if (drawable != null)
      d0.a.k(drawable, paramFloat1, paramFloat2); 
    drawable = this.k;
    if (drawable != null)
      d0.a.k(drawable, paramFloat1, paramFloat2); 
  }
  
  protected void drawableStateChanged() {
    boolean bool;
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.f;
    int j = 0;
    int i = j;
    if (drawable != null) {
      i = j;
      if (drawable.isStateful())
        i = false | drawable.setState(arrayOfInt); 
    } 
    drawable = this.k;
    j = i;
    if (drawable != null) {
      j = i;
      if (drawable.isStateful())
        bool = i | drawable.setState(arrayOfInt); 
    } 
    if (bool)
      invalidate(); 
  }
  
  public int getCompoundPaddingLeft() {
    if (!d1.b((View)this))
      return super.getCompoundPaddingLeft(); 
    int j = super.getCompoundPaddingLeft() + this.F;
    int i = j;
    if (!TextUtils.isEmpty(getText()))
      i = j + this.r; 
    return i;
  }
  
  public int getCompoundPaddingRight() {
    if (d1.b((View)this))
      return super.getCompoundPaddingRight(); 
    int j = super.getCompoundPaddingRight() + this.F;
    int i = j;
    if (!TextUtils.isEmpty(getText()))
      i = j + this.r; 
    return i;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.p(super.getCustomSelectionActionModeCallback());
  }
  
  public boolean getShowText() {
    return this.x;
  }
  
  public boolean getSplitTrack() {
    return this.s;
  }
  
  public int getSwitchMinWidth() {
    return this.q;
  }
  
  public int getSwitchPadding() {
    return this.r;
  }
  
  public CharSequence getTextOff() {
    return this.v;
  }
  
  public CharSequence getTextOn() {
    return this.t;
  }
  
  public Drawable getThumbDrawable() {
    return this.f;
  }
  
  public int getThumbTextPadding() {
    return this.p;
  }
  
  public ColorStateList getThumbTintList() {
    return this.g;
  }
  
  public PorterDuff.Mode getThumbTintMode() {
    return this.h;
  }
  
  public Drawable getTrackDrawable() {
    return this.k;
  }
  
  public ColorStateList getTrackTintList() {
    return this.l;
  }
  
  public PorterDuff.Mode getTrackTintMode() {
    return this.m;
  }
  
  void j() {
    setTextOnInternal(this.t);
    setTextOffInternal(this.v);
    requestLayout();
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    Drawable drawable = this.f;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    drawable = this.k;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    ObjectAnimator objectAnimator = this.R;
    if (objectAnimator != null && objectAnimator.isStarted()) {
      this.R.end();
      this.R = null;
    } 
  }
  
  public void m(Context paramContext, int paramInt) {
    w0 w0 = w0.t(paramContext, paramInt, j.a3);
    ColorStateList colorStateList = w0.c(j.e3);
    if (colorStateList != null) {
      this.N = colorStateList;
    } else {
      this.N = getTextColors();
    } 
    paramInt = w0.f(j.b3, 0);
    if (paramInt != 0) {
      float f = paramInt;
      if (f != this.M.getTextSize()) {
        this.M.setTextSize(f);
        requestLayout();
      } 
    } 
    o(w0.k(j.c3, -1), w0.k(j.d3, -1));
    if (w0.a(j.j3, false)) {
      this.Q = (TransformationMethod)new j.a(getContext());
    } else {
      this.Q = null;
    } 
    setTextOnInternal(this.t);
    setTextOffInternal(this.v);
    w0.w();
  }
  
  public void n(Typeface paramTypeface, int paramInt) {
    TextPaint textPaint;
    float f = 0.0F;
    boolean bool = false;
    if (paramInt > 0) {
      int i;
      if (paramTypeface == null) {
        paramTypeface = Typeface.defaultFromStyle(paramInt);
      } else {
        paramTypeface = Typeface.create(paramTypeface, paramInt);
      } 
      setSwitchTypeface(paramTypeface);
      if (paramTypeface != null) {
        i = paramTypeface.getStyle();
      } else {
        i = 0;
      } 
      paramInt = i & paramInt;
      textPaint = this.M;
      if ((paramInt & 0x1) != 0)
        bool = true; 
      textPaint.setFakeBoldText(bool);
      textPaint = this.M;
      if ((paramInt & 0x2) != 0)
        f = -0.25F; 
      textPaint.setTextSkewX(f);
      return;
    } 
    this.M.setFakeBoldText(false);
    this.M.setTextSkewX(0.0F);
    setSwitchTypeface((Typeface)textPaint);
  }
  
  protected int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 1);
    if (isChecked())
      CompoundButton.mergeDrawableStates(arrayOfInt, a0); 
    return arrayOfInt;
  }
  
  protected void onDraw(Canvas paramCanvas) {
    Layout layout;
    super.onDraw(paramCanvas);
    Rect rect = this.V;
    Drawable drawable2 = this.k;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
    } else {
      rect.setEmpty();
    } 
    int j = this.J;
    int k = this.L;
    int n = rect.top;
    int i1 = rect.bottom;
    Drawable drawable1 = this.f;
    if (drawable2 != null)
      if (this.s && drawable1 != null) {
        Rect rect1 = f0.d(drawable1);
        drawable1.copyBounds(rect);
        rect.left += rect1.left;
        rect.right -= rect1.right;
        int i2 = paramCanvas.save();
        paramCanvas.clipRect(rect, Region.Op.DIFFERENCE);
        drawable2.draw(paramCanvas);
        paramCanvas.restoreToCount(i2);
      } else {
        drawable2.draw(paramCanvas);
      }  
    int i = paramCanvas.save();
    if (drawable1 != null)
      drawable1.draw(paramCanvas); 
    if (getTargetCheckedState()) {
      layout = this.O;
    } else {
      layout = this.P;
    } 
    if (layout != null) {
      int i2;
      int[] arrayOfInt = getDrawableState();
      ColorStateList colorStateList = this.N;
      if (colorStateList != null)
        this.M.setColor(colorStateList.getColorForState(arrayOfInt, 0)); 
      this.M.drawableState = arrayOfInt;
      if (drawable1 != null) {
        Rect rect1 = drawable1.getBounds();
        i2 = rect1.left + rect1.right;
      } else {
        i2 = getWidth();
      } 
      i2 /= 2;
      int i3 = layout.getWidth() / 2;
      j = (j + n + k - i1) / 2;
      k = layout.getHeight() / 2;
      paramCanvas.translate((i2 - i3), (j - k));
      layout.draw(paramCanvas);
    } 
    paramCanvas.restoreToCount(i);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("android.widget.Switch");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("android.widget.Switch");
    if (Build.VERSION.SDK_INT < 30) {
      CharSequence charSequence;
      if (isChecked()) {
        charSequence = this.t;
      } else {
        charSequence = this.v;
      } 
      if (!TextUtils.isEmpty(charSequence)) {
        CharSequence charSequence1 = paramAccessibilityNodeInfo.getText();
        if (TextUtils.isEmpty(charSequence1)) {
          paramAccessibilityNodeInfo.setText(charSequence);
          return;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(charSequence1);
        stringBuilder.append(' ');
        stringBuilder.append(charSequence);
        paramAccessibilityNodeInfo.setText(stringBuilder);
      } 
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    Drawable drawable = this.f;
    paramInt1 = 0;
    if (drawable != null) {
      Rect rect1 = this.V;
      Drawable drawable1 = this.k;
      if (drawable1 != null) {
        drawable1.getPadding(rect1);
      } else {
        rect1.setEmpty();
      } 
      Rect rect2 = f0.d(this.f);
      paramInt2 = Math.max(0, rect2.left - rect1.left);
      paramInt1 = Math.max(0, rect2.right - rect1.right);
    } else {
      paramInt2 = 0;
    } 
    if (d1.b((View)this)) {
      paramInt3 = getPaddingLeft() + paramInt2;
      paramInt1 = this.F + paramInt3 - paramInt2 - paramInt1;
      paramInt2 = paramInt3;
      paramInt3 = paramInt1;
    } else {
      paramInt3 = getWidth() - getPaddingRight() - paramInt1;
      paramInt2 = paramInt3 - this.F + paramInt2 + paramInt1;
    } 
    paramInt1 = getGravity() & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
        paramInt4 = this.G;
      } else {
        paramInt4 = getHeight() - getPaddingBottom();
        paramInt1 = paramInt4 - this.G;
        this.I = paramInt2;
        this.J = paramInt1;
        this.L = paramInt4;
        this.K = paramInt3;
      } 
    } else {
      paramInt1 = (getPaddingTop() + getHeight() - getPaddingBottom()) / 2;
      paramInt4 = this.G;
      paramInt1 -= paramInt4 / 2;
    } 
    paramInt4 += paramInt1;
    this.I = paramInt2;
    this.J = paramInt1;
    this.L = paramInt4;
    this.K = paramInt3;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int j;
    if (this.x) {
      if (this.O == null)
        this.O = i(this.u); 
      if (this.P == null)
        this.P = i(this.w); 
    } 
    Rect rect = this.V;
    Drawable drawable2 = this.f;
    int n = 0;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
      j = this.f.getIntrinsicWidth() - rect.left - rect.right;
      i = this.f.getIntrinsicHeight();
    } else {
      j = 0;
      i = j;
    } 
    if (this.x) {
      k = Math.max(this.O.getWidth(), this.P.getWidth()) + this.p * 2;
    } else {
      k = 0;
    } 
    this.H = Math.max(k, j);
    drawable2 = this.k;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
      j = this.k.getIntrinsicHeight();
    } else {
      rect.setEmpty();
      j = n;
    } 
    int i2 = rect.left;
    int i1 = rect.right;
    Drawable drawable1 = this.f;
    n = i1;
    int k = i2;
    if (drawable1 != null) {
      Rect rect1 = f0.d(drawable1);
      k = Math.max(i2, rect1.left);
      n = Math.max(i1, rect1.right);
    } 
    k = Math.max(this.q, this.H * 2 + k + n);
    int i = Math.max(j, i);
    this.F = k;
    this.G = i;
    super.onMeasure(paramInt1, paramInt2);
    if (getMeasuredHeight() < i)
      setMeasuredDimension(getMeasuredWidthAndState(), i); 
  }
  
  public void onPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    CharSequence charSequence;
    super.onPopulateAccessibilityEvent(paramAccessibilityEvent);
    if (isChecked()) {
      charSequence = this.t;
    } else {
      charSequence = this.v;
    } 
    if (charSequence != null)
      paramAccessibilityEvent.getText().add(charSequence); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    this.C.addMovement(paramMotionEvent);
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3)
            return super.onTouchEvent(paramMotionEvent); 
        } else {
          i = this.y;
          if (i != 1) {
            if (i == 2) {
              float f3 = paramMotionEvent.getX();
              i = getThumbScrollRange();
              float f1 = f3 - this.A;
              if (i != 0) {
                f1 /= i;
              } else if (f1 > 0.0F) {
                f1 = 1.0F;
              } else {
                f1 = -1.0F;
              } 
              float f2 = f1;
              if (d1.b((View)this))
                f2 = -f1; 
              f1 = f(this.E + f2, 0.0F, 1.0F);
              if (f1 != this.E) {
                this.A = f3;
                setThumbPosition(f1);
              } 
              return true;
            } 
          } else {
            float f1 = paramMotionEvent.getX();
            float f2 = paramMotionEvent.getY();
            if (Math.abs(f1 - this.A) > this.z || Math.abs(f2 - this.B) > this.z) {
              this.y = 2;
              getParent().requestDisallowInterceptTouchEvent(true);
              this.A = f1;
              this.B = f2;
              return true;
            } 
          } 
          return super.onTouchEvent(paramMotionEvent);
        }  
      if (this.y == 2) {
        q(paramMotionEvent);
        super.onTouchEvent(paramMotionEvent);
        return true;
      } 
      this.y = 0;
      this.C.clear();
    } else {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      if (isEnabled() && h(f1, f2)) {
        this.y = 1;
        this.A = f1;
        this.B = f2;
      } 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setChecked(boolean paramBoolean) {
    float f;
    super.setChecked(paramBoolean);
    paramBoolean = isChecked();
    if (paramBoolean) {
      l();
    } else {
      k();
    } 
    if (getWindowToken() != null && w.S((View)this)) {
      a(paramBoolean);
      return;
    } 
    d();
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    setThumbPosition(f);
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.q((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
    setTextOnInternal(this.t);
    setTextOffInternal(this.v);
    requestLayout();
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setShowText(boolean paramBoolean) {
    if (this.x != paramBoolean) {
      this.x = paramBoolean;
      requestLayout();
      if (paramBoolean)
        p(); 
    } 
  }
  
  public void setSplitTrack(boolean paramBoolean) {
    this.s = paramBoolean;
    invalidate();
  }
  
  public void setSwitchMinWidth(int paramInt) {
    this.q = paramInt;
    requestLayout();
  }
  
  public void setSwitchPadding(int paramInt) {
    this.r = paramInt;
    requestLayout();
  }
  
  public void setSwitchTypeface(Typeface paramTypeface) {
    if ((this.M.getTypeface() != null && !this.M.getTypeface().equals(paramTypeface)) || (this.M.getTypeface() == null && paramTypeface != null)) {
      this.M.setTypeface(paramTypeface);
      requestLayout();
      invalidate();
    } 
  }
  
  public void setTextOff(CharSequence paramCharSequence) {
    setTextOffInternal(paramCharSequence);
    requestLayout();
    if (!isChecked())
      k(); 
  }
  
  public void setTextOn(CharSequence paramCharSequence) {
    setTextOnInternal(paramCharSequence);
    requestLayout();
    if (isChecked())
      l(); 
  }
  
  public void setThumbDrawable(Drawable paramDrawable) {
    Drawable drawable = this.f;
    if (drawable != null)
      drawable.setCallback(null); 
    this.f = paramDrawable;
    if (paramDrawable != null)
      paramDrawable.setCallback((Drawable.Callback)this); 
    requestLayout();
  }
  
  void setThumbPosition(float paramFloat) {
    this.E = paramFloat;
    invalidate();
  }
  
  public void setThumbResource(int paramInt) {
    setThumbDrawable(g.a.b(getContext(), paramInt));
  }
  
  public void setThumbTextPadding(int paramInt) {
    this.p = paramInt;
    requestLayout();
  }
  
  public void setThumbTintList(ColorStateList paramColorStateList) {
    this.g = paramColorStateList;
    this.i = true;
    b();
  }
  
  public void setThumbTintMode(PorterDuff.Mode paramMode) {
    this.h = paramMode;
    this.j = true;
    b();
  }
  
  public void setTrackDrawable(Drawable paramDrawable) {
    Drawable drawable = this.k;
    if (drawable != null)
      drawable.setCallback(null); 
    this.k = paramDrawable;
    if (paramDrawable != null)
      paramDrawable.setCallback((Drawable.Callback)this); 
    requestLayout();
  }
  
  public void setTrackResource(int paramInt) {
    setTrackDrawable(g.a.b(getContext(), paramInt));
  }
  
  public void setTrackTintList(ColorStateList paramColorStateList) {
    this.l = paramColorStateList;
    this.n = true;
    c();
  }
  
  public void setTrackTintMode(PorterDuff.Mode paramMode) {
    this.m = paramMode;
    this.o = true;
    c();
  }
  
  public void toggle() {
    setChecked(isChecked() ^ true);
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.f || paramDrawable == this.k);
  }
  
  class a extends Property<SwitchCompat, Float> {
    a(SwitchCompat this$0, String param1String) {
      super((Class)this$0, param1String);
    }
    
    public Float a(SwitchCompat param1SwitchCompat) {
      return Float.valueOf(param1SwitchCompat.E);
    }
    
    public void b(SwitchCompat param1SwitchCompat, Float param1Float) {
      param1SwitchCompat.setThumbPosition(param1Float.floatValue());
    }
  }
  
  static class b extends d.e {
    private final Reference<SwitchCompat> a;
    
    b(SwitchCompat param1SwitchCompat) {
      this.a = new WeakReference<SwitchCompat>(param1SwitchCompat);
    }
    
    public void a(Throwable param1Throwable) {
      SwitchCompat switchCompat = this.a.get();
      if (switchCompat != null)
        switchCompat.j(); 
    }
    
    public void b() {
      SwitchCompat switchCompat = this.a.get();
      if (switchCompat != null)
        switchCompat.j(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\SwitchCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */