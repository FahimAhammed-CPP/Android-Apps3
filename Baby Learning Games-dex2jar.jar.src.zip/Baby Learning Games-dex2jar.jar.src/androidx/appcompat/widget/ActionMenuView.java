package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;

public class ActionMenuView extends LinearLayoutCompat implements e.b, k {
  e.a A;
  
  private boolean B;
  
  private int C;
  
  private int D;
  
  private int E;
  
  e F;
  
  private e u;
  
  private Context v;
  
  private int w;
  
  private boolean x;
  
  private c y;
  
  private j.a z;
  
  public ActionMenuView(Context paramContext) {
    this(paramContext, null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.D = (int)(56.0F * f);
    this.E = (int)(f * 4.0F);
    this.v = paramContext;
    this.w = 0;
  }
  
  static int L(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ActionMenuItemView actionMenuItemView;
    c c1 = (c)paramView.getLayoutParams();
    int i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt3) - paramInt4, View.MeasureSpec.getMode(paramInt3));
    if (paramView instanceof ActionMenuItemView) {
      actionMenuItemView = (ActionMenuItemView)paramView;
    } else {
      actionMenuItemView = null;
    } 
    boolean bool = true;
    if (actionMenuItemView != null && actionMenuItemView.p()) {
      paramInt3 = 1;
    } else {
      paramInt3 = 0;
    } 
    paramInt4 = 2;
    if (paramInt2 > 0 && (paramInt3 == 0 || paramInt2 >= 2)) {
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt2 * paramInt1, -2147483648), i);
      int m = paramView.getMeasuredWidth();
      int j = m / paramInt1;
      paramInt2 = j;
      if (m % paramInt1 != 0)
        paramInt2 = j + 1; 
      if (paramInt3 != 0 && paramInt2 < 2)
        paramInt2 = paramInt4; 
    } else {
      paramInt2 = 0;
    } 
    if (c1.a || paramInt3 == 0)
      bool = false; 
    c1.d = bool;
    c1.b = paramInt2;
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1 * paramInt2, 1073741824), i);
    return paramInt2;
  }
  
  private void M(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic getMode : (I)I
    //   4: istore #12
    //   6: iload_1
    //   7: invokestatic getSize : (I)I
    //   10: istore_1
    //   11: iload_2
    //   12: invokestatic getSize : (I)I
    //   15: istore #13
    //   17: aload_0
    //   18: invokevirtual getPaddingLeft : ()I
    //   21: istore #5
    //   23: aload_0
    //   24: invokevirtual getPaddingRight : ()I
    //   27: istore #6
    //   29: aload_0
    //   30: invokevirtual getPaddingTop : ()I
    //   33: aload_0
    //   34: invokevirtual getPaddingBottom : ()I
    //   37: iadd
    //   38: istore #16
    //   40: iload_2
    //   41: iload #16
    //   43: bipush #-2
    //   45: invokestatic getChildMeasureSpec : (III)I
    //   48: istore #20
    //   50: iload_1
    //   51: iload #5
    //   53: iload #6
    //   55: iadd
    //   56: isub
    //   57: istore #14
    //   59: aload_0
    //   60: getfield D : I
    //   63: istore_1
    //   64: iload #14
    //   66: iload_1
    //   67: idiv
    //   68: istore #15
    //   70: iload #15
    //   72: ifne -> 83
    //   75: aload_0
    //   76: iload #14
    //   78: iconst_0
    //   79: invokevirtual setMeasuredDimension : (II)V
    //   82: return
    //   83: iload_1
    //   84: iload #14
    //   86: iload_1
    //   87: irem
    //   88: iload #15
    //   90: idiv
    //   91: iadd
    //   92: istore #21
    //   94: aload_0
    //   95: invokevirtual getChildCount : ()I
    //   98: istore #22
    //   100: iconst_0
    //   101: istore #6
    //   103: iload #6
    //   105: istore_1
    //   106: iload_1
    //   107: istore #7
    //   109: iload #7
    //   111: istore_2
    //   112: iload_2
    //   113: istore #5
    //   115: iload #5
    //   117: istore #8
    //   119: lconst_0
    //   120: lstore #23
    //   122: iload #5
    //   124: istore #10
    //   126: iload_2
    //   127: istore #11
    //   129: iload_1
    //   130: istore #9
    //   132: iload #6
    //   134: istore #5
    //   136: iload #15
    //   138: istore_1
    //   139: iload #13
    //   141: istore #6
    //   143: iload #9
    //   145: iload #22
    //   147: if_icmpge -> 400
    //   150: aload_0
    //   151: iload #9
    //   153: invokevirtual getChildAt : (I)Landroid/view/View;
    //   156: astore #32
    //   158: aload #32
    //   160: invokevirtual getVisibility : ()I
    //   163: bipush #8
    //   165: if_icmpne -> 174
    //   168: iload #8
    //   170: istore_2
    //   171: goto -> 388
    //   174: aload #32
    //   176: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   179: istore #31
    //   181: iload #11
    //   183: iconst_1
    //   184: iadd
    //   185: istore #11
    //   187: iload #31
    //   189: ifeq -> 209
    //   192: aload_0
    //   193: getfield E : I
    //   196: istore_2
    //   197: aload #32
    //   199: iload_2
    //   200: iconst_0
    //   201: iload_2
    //   202: iconst_0
    //   203: invokevirtual setPadding : (IIII)V
    //   206: goto -> 209
    //   209: aload #32
    //   211: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   214: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   217: astore #33
    //   219: aload #33
    //   221: iconst_0
    //   222: putfield f : Z
    //   225: aload #33
    //   227: iconst_0
    //   228: putfield c : I
    //   231: aload #33
    //   233: iconst_0
    //   234: putfield b : I
    //   237: aload #33
    //   239: iconst_0
    //   240: putfield d : Z
    //   243: aload #33
    //   245: iconst_0
    //   246: putfield leftMargin : I
    //   249: aload #33
    //   251: iconst_0
    //   252: putfield rightMargin : I
    //   255: iload #31
    //   257: ifeq -> 277
    //   260: aload #32
    //   262: checkcast androidx/appcompat/view/menu/ActionMenuItemView
    //   265: invokevirtual p : ()Z
    //   268: ifeq -> 277
    //   271: iconst_1
    //   272: istore #31
    //   274: goto -> 280
    //   277: iconst_0
    //   278: istore #31
    //   280: aload #33
    //   282: iload #31
    //   284: putfield e : Z
    //   287: aload #33
    //   289: getfield a : Z
    //   292: ifeq -> 300
    //   295: iconst_1
    //   296: istore_2
    //   297: goto -> 302
    //   300: iload_1
    //   301: istore_2
    //   302: aload #32
    //   304: iload #21
    //   306: iload_2
    //   307: iload #20
    //   309: iload #16
    //   311: invokestatic L : (Landroid/view/View;IIII)I
    //   314: istore #13
    //   316: iload #10
    //   318: iload #13
    //   320: invokestatic max : (II)I
    //   323: istore #10
    //   325: iload #8
    //   327: istore_2
    //   328: aload #33
    //   330: getfield d : Z
    //   333: ifeq -> 341
    //   336: iload #8
    //   338: iconst_1
    //   339: iadd
    //   340: istore_2
    //   341: aload #33
    //   343: getfield a : Z
    //   346: ifeq -> 352
    //   349: iconst_1
    //   350: istore #7
    //   352: iload_1
    //   353: iload #13
    //   355: isub
    //   356: istore_1
    //   357: iload #5
    //   359: aload #32
    //   361: invokevirtual getMeasuredHeight : ()I
    //   364: invokestatic max : (II)I
    //   367: istore #5
    //   369: iload #13
    //   371: iconst_1
    //   372: if_icmpne -> 388
    //   375: lload #23
    //   377: iconst_1
    //   378: iload #9
    //   380: ishl
    //   381: i2l
    //   382: lor
    //   383: lstore #23
    //   385: goto -> 388
    //   388: iload #9
    //   390: iconst_1
    //   391: iadd
    //   392: istore #9
    //   394: iload_2
    //   395: istore #8
    //   397: goto -> 143
    //   400: iload #7
    //   402: ifeq -> 417
    //   405: iload #11
    //   407: iconst_2
    //   408: if_icmpne -> 417
    //   411: iconst_1
    //   412: istore #9
    //   414: goto -> 420
    //   417: iconst_0
    //   418: istore #9
    //   420: iconst_0
    //   421: istore_2
    //   422: iload_1
    //   423: istore #13
    //   425: iload #9
    //   427: istore #15
    //   429: iload #14
    //   431: istore #9
    //   433: iload #8
    //   435: ifle -> 758
    //   438: iload #13
    //   440: ifle -> 758
    //   443: ldc 2147483647
    //   445: istore #14
    //   447: iconst_0
    //   448: istore #17
    //   450: iconst_0
    //   451: istore #16
    //   453: lconst_0
    //   454: lstore #27
    //   456: iload #16
    //   458: iload #22
    //   460: if_icmpge -> 584
    //   463: aload_0
    //   464: iload #16
    //   466: invokevirtual getChildAt : (I)Landroid/view/View;
    //   469: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   472: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   475: astore #32
    //   477: aload #32
    //   479: getfield d : Z
    //   482: ifne -> 499
    //   485: iload #17
    //   487: istore_1
    //   488: iload #14
    //   490: istore #18
    //   492: lload #27
    //   494: lstore #25
    //   496: goto -> 564
    //   499: aload #32
    //   501: getfield b : I
    //   504: istore #19
    //   506: iload #19
    //   508: iload #14
    //   510: if_icmpge -> 528
    //   513: lconst_1
    //   514: iload #16
    //   516: lshl
    //   517: lstore #25
    //   519: iload #19
    //   521: istore #18
    //   523: iconst_1
    //   524: istore_1
    //   525: goto -> 564
    //   528: iload #17
    //   530: istore_1
    //   531: iload #14
    //   533: istore #18
    //   535: lload #27
    //   537: lstore #25
    //   539: iload #19
    //   541: iload #14
    //   543: if_icmpne -> 564
    //   546: iload #17
    //   548: iconst_1
    //   549: iadd
    //   550: istore_1
    //   551: lload #27
    //   553: lconst_1
    //   554: iload #16
    //   556: lshl
    //   557: lor
    //   558: lstore #25
    //   560: iload #14
    //   562: istore #18
    //   564: iload #16
    //   566: iconst_1
    //   567: iadd
    //   568: istore #16
    //   570: iload_1
    //   571: istore #17
    //   573: iload #18
    //   575: istore #14
    //   577: lload #25
    //   579: lstore #27
    //   581: goto -> 456
    //   584: iload_2
    //   585: istore_1
    //   586: iload #5
    //   588: istore_2
    //   589: lload #23
    //   591: lload #27
    //   593: lor
    //   594: lstore #23
    //   596: iload #17
    //   598: iload #13
    //   600: if_icmple -> 606
    //   603: goto -> 763
    //   606: iconst_0
    //   607: istore_1
    //   608: iload_1
    //   609: iload #22
    //   611: if_icmpge -> 750
    //   614: aload_0
    //   615: iload_1
    //   616: invokevirtual getChildAt : (I)Landroid/view/View;
    //   619: astore #32
    //   621: aload #32
    //   623: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   626: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   629: astore #33
    //   631: iconst_1
    //   632: iload_1
    //   633: ishl
    //   634: i2l
    //   635: lstore #29
    //   637: lload #27
    //   639: lload #29
    //   641: land
    //   642: lconst_0
    //   643: lcmp
    //   644: ifne -> 677
    //   647: lload #23
    //   649: lstore #25
    //   651: aload #33
    //   653: getfield b : I
    //   656: iload #14
    //   658: iconst_1
    //   659: iadd
    //   660: if_icmpne -> 670
    //   663: lload #23
    //   665: lload #29
    //   667: lor
    //   668: lstore #25
    //   670: lload #25
    //   672: lstore #23
    //   674: goto -> 743
    //   677: iload #15
    //   679: ifeq -> 719
    //   682: aload #33
    //   684: getfield e : Z
    //   687: ifeq -> 719
    //   690: iload #13
    //   692: iconst_1
    //   693: if_icmpne -> 719
    //   696: aload_0
    //   697: getfield E : I
    //   700: istore #5
    //   702: aload #32
    //   704: iload #5
    //   706: iload #21
    //   708: iadd
    //   709: iconst_0
    //   710: iload #5
    //   712: iconst_0
    //   713: invokevirtual setPadding : (IIII)V
    //   716: goto -> 719
    //   719: aload #33
    //   721: aload #33
    //   723: getfield b : I
    //   726: iconst_1
    //   727: iadd
    //   728: putfield b : I
    //   731: aload #33
    //   733: iconst_1
    //   734: putfield f : Z
    //   737: iload #13
    //   739: iconst_1
    //   740: isub
    //   741: istore #13
    //   743: iload_1
    //   744: iconst_1
    //   745: iadd
    //   746: istore_1
    //   747: goto -> 608
    //   750: iload_2
    //   751: istore #5
    //   753: iconst_1
    //   754: istore_2
    //   755: goto -> 433
    //   758: iload_2
    //   759: istore_1
    //   760: iload #5
    //   762: istore_2
    //   763: iload #7
    //   765: ifne -> 780
    //   768: iload #11
    //   770: iconst_1
    //   771: if_icmpne -> 780
    //   774: iconst_1
    //   775: istore #5
    //   777: goto -> 783
    //   780: iconst_0
    //   781: istore #5
    //   783: iload #13
    //   785: ifle -> 1133
    //   788: lload #23
    //   790: lconst_0
    //   791: lcmp
    //   792: ifeq -> 1133
    //   795: iload #13
    //   797: iload #11
    //   799: iconst_1
    //   800: isub
    //   801: if_icmplt -> 815
    //   804: iload #5
    //   806: ifne -> 815
    //   809: iload #10
    //   811: iconst_1
    //   812: if_icmple -> 1133
    //   815: lload #23
    //   817: invokestatic bitCount : (J)I
    //   820: i2f
    //   821: fstore #4
    //   823: iload #5
    //   825: ifne -> 918
    //   828: fload #4
    //   830: fstore_3
    //   831: lload #23
    //   833: lconst_1
    //   834: land
    //   835: lconst_0
    //   836: lcmp
    //   837: ifeq -> 866
    //   840: fload #4
    //   842: fstore_3
    //   843: aload_0
    //   844: iconst_0
    //   845: invokevirtual getChildAt : (I)Landroid/view/View;
    //   848: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   851: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   854: getfield e : Z
    //   857: ifne -> 866
    //   860: fload #4
    //   862: ldc 0.5
    //   864: fsub
    //   865: fstore_3
    //   866: iload #22
    //   868: iconst_1
    //   869: isub
    //   870: istore #5
    //   872: fload_3
    //   873: fstore #4
    //   875: lload #23
    //   877: iconst_1
    //   878: iload #5
    //   880: ishl
    //   881: i2l
    //   882: land
    //   883: lconst_0
    //   884: lcmp
    //   885: ifeq -> 918
    //   888: fload_3
    //   889: fstore #4
    //   891: aload_0
    //   892: iload #5
    //   894: invokevirtual getChildAt : (I)Landroid/view/View;
    //   897: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   900: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   903: getfield e : Z
    //   906: ifne -> 918
    //   909: fload_3
    //   910: ldc 0.5
    //   912: fsub
    //   913: fstore #4
    //   915: goto -> 918
    //   918: fload #4
    //   920: fconst_0
    //   921: fcmpl
    //   922: ifle -> 940
    //   925: iload #13
    //   927: iload #21
    //   929: imul
    //   930: i2f
    //   931: fload #4
    //   933: fdiv
    //   934: f2i
    //   935: istore #7
    //   937: goto -> 943
    //   940: iconst_0
    //   941: istore #7
    //   943: iconst_0
    //   944: istore #8
    //   946: iload_1
    //   947: istore #5
    //   949: iload #8
    //   951: iload #22
    //   953: if_icmpge -> 1136
    //   956: lload #23
    //   958: iconst_1
    //   959: iload #8
    //   961: ishl
    //   962: i2l
    //   963: land
    //   964: lconst_0
    //   965: lcmp
    //   966: ifne -> 975
    //   969: iload_1
    //   970: istore #5
    //   972: goto -> 1121
    //   975: aload_0
    //   976: iload #8
    //   978: invokevirtual getChildAt : (I)Landroid/view/View;
    //   981: astore #32
    //   983: aload #32
    //   985: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   988: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   991: astore #33
    //   993: aload #32
    //   995: instanceof androidx/appcompat/view/menu/ActionMenuItemView
    //   998: ifeq -> 1046
    //   1001: aload #33
    //   1003: iload #7
    //   1005: putfield c : I
    //   1008: aload #33
    //   1010: iconst_1
    //   1011: putfield f : Z
    //   1014: iload #8
    //   1016: ifne -> 1040
    //   1019: aload #33
    //   1021: getfield e : Z
    //   1024: ifne -> 1040
    //   1027: aload #33
    //   1029: iload #7
    //   1031: ineg
    //   1032: iconst_2
    //   1033: idiv
    //   1034: putfield leftMargin : I
    //   1037: goto -> 1040
    //   1040: iconst_1
    //   1041: istore #5
    //   1043: goto -> 1121
    //   1046: aload #33
    //   1048: getfield a : Z
    //   1051: ifeq -> 1083
    //   1054: aload #33
    //   1056: iload #7
    //   1058: putfield c : I
    //   1061: aload #33
    //   1063: iconst_1
    //   1064: putfield f : Z
    //   1067: aload #33
    //   1069: iload #7
    //   1071: ineg
    //   1072: iconst_2
    //   1073: idiv
    //   1074: putfield rightMargin : I
    //   1077: iconst_1
    //   1078: istore #5
    //   1080: goto -> 1121
    //   1083: iload #8
    //   1085: ifeq -> 1097
    //   1088: aload #33
    //   1090: iload #7
    //   1092: iconst_2
    //   1093: idiv
    //   1094: putfield leftMargin : I
    //   1097: iload_1
    //   1098: istore #5
    //   1100: iload #8
    //   1102: iload #22
    //   1104: iconst_1
    //   1105: isub
    //   1106: if_icmpeq -> 1121
    //   1109: aload #33
    //   1111: iload #7
    //   1113: iconst_2
    //   1114: idiv
    //   1115: putfield rightMargin : I
    //   1118: iload_1
    //   1119: istore #5
    //   1121: iload #8
    //   1123: iconst_1
    //   1124: iadd
    //   1125: istore #8
    //   1127: iload #5
    //   1129: istore_1
    //   1130: goto -> 946
    //   1133: iload_1
    //   1134: istore #5
    //   1136: iload #5
    //   1138: ifeq -> 1210
    //   1141: iconst_0
    //   1142: istore_1
    //   1143: iload_1
    //   1144: iload #22
    //   1146: if_icmpge -> 1210
    //   1149: aload_0
    //   1150: iload_1
    //   1151: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1154: astore #32
    //   1156: aload #32
    //   1158: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1161: checkcast androidx/appcompat/widget/ActionMenuView$c
    //   1164: astore #33
    //   1166: aload #33
    //   1168: getfield f : Z
    //   1171: ifne -> 1177
    //   1174: goto -> 1203
    //   1177: aload #32
    //   1179: aload #33
    //   1181: getfield b : I
    //   1184: iload #21
    //   1186: imul
    //   1187: aload #33
    //   1189: getfield c : I
    //   1192: iadd
    //   1193: ldc 1073741824
    //   1195: invokestatic makeMeasureSpec : (II)I
    //   1198: iload #20
    //   1200: invokevirtual measure : (II)V
    //   1203: iload_1
    //   1204: iconst_1
    //   1205: iadd
    //   1206: istore_1
    //   1207: goto -> 1143
    //   1210: iload #12
    //   1212: ldc 1073741824
    //   1214: if_icmpeq -> 1220
    //   1217: goto -> 1223
    //   1220: iload #6
    //   1222: istore_2
    //   1223: aload_0
    //   1224: iload #9
    //   1226: iload_2
    //   1227: invokevirtual setMeasuredDimension : (II)V
    //   1230: return
  }
  
  public void B() {
    c c1 = this.y;
    if (c1 != null)
      c1.A(); 
  }
  
  protected c C() {
    c c1 = new c(-2, -2);
    c1.gravity = 16;
    return c1;
  }
  
  public c D(AttributeSet paramAttributeSet) {
    return new c(getContext(), paramAttributeSet);
  }
  
  protected c E(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      c c1;
      if (paramLayoutParams instanceof c) {
        c1 = new c((c)paramLayoutParams);
      } else {
        c1 = new c((ViewGroup.LayoutParams)c1);
      } 
      if (c1.gravity <= 0)
        c1.gravity = 16; 
      return c1;
    } 
    return C();
  }
  
  public c F() {
    c c1 = C();
    c1.a = true;
    return c1;
  }
  
  protected boolean G(int paramInt) {
    boolean bool;
    int j = 0;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = j;
    if (paramInt < getChildCount()) {
      i = j;
      if (view1 instanceof a)
        i = false | ((a)view1).a(); 
    } 
    j = i;
    if (paramInt > 0) {
      j = i;
      if (view2 instanceof a)
        bool = i | ((a)view2).b(); 
    } 
    return bool;
  }
  
  public boolean H() {
    c c1 = this.y;
    return (c1 != null && c1.D());
  }
  
  public boolean I() {
    c c1 = this.y;
    return (c1 != null && c1.F());
  }
  
  public boolean J() {
    c c1 = this.y;
    return (c1 != null && c1.G());
  }
  
  public boolean K() {
    return this.x;
  }
  
  public e N() {
    return this.u;
  }
  
  public void O(j.a parama, e.a parama1) {
    this.z = parama;
    this.A = parama1;
  }
  
  public boolean P() {
    c c1 = this.y;
    return (c1 != null && c1.M());
  }
  
  public boolean a(g paramg) {
    return this.u.N((MenuItem)paramg, 0);
  }
  
  public void b(e parame) {
    this.u = parame;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof c;
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  public Menu getMenu() {
    if (this.u == null) {
      Context context = getContext();
      e e1 = new e(context);
      this.u = e1;
      e1.V(new d(this));
      c c1 = new c(context);
      this.y = c1;
      c1.L(true);
      c c2 = this.y;
      j.a a1 = this.z;
      if (a1 == null)
        a1 = new b(); 
      c2.m(a1);
      this.u.c((j)this.y, this.v);
      this.y.J(this);
    } 
    return (Menu)this.u;
  }
  
  public Drawable getOverflowIcon() {
    getMenu();
    return this.y.C();
  }
  
  public int getPopupTheme() {
    return this.w;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    c c1 = this.y;
    if (c1 != null) {
      c1.g(false);
      if (this.y.G()) {
        this.y.D();
        this.y.M();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    B();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.B) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int j = getChildCount();
    int i = (paramInt4 - paramInt2) / 2;
    int m = getDividerWidth();
    int n = paramInt3 - paramInt1;
    paramInt1 = n - getPaddingRight() - getPaddingLeft();
    paramBoolean = d1.b((View)this);
    paramInt2 = 0;
    paramInt4 = 0;
    paramInt3 = 0;
    while (paramInt2 < j) {
      View view = getChildAt(paramInt2);
      if (view.getVisibility() != 8) {
        c c1 = (c)view.getLayoutParams();
        if (c1.a) {
          int i2;
          int i1 = view.getMeasuredWidth();
          paramInt4 = i1;
          if (G(paramInt2))
            paramInt4 = i1 + m; 
          int i3 = view.getMeasuredHeight();
          if (paramBoolean) {
            i2 = getPaddingLeft() + c1.leftMargin;
            i1 = i2 + paramInt4;
          } else {
            i1 = getWidth() - getPaddingRight() - c1.rightMargin;
            i2 = i1 - paramInt4;
          } 
          int i4 = i - i3 / 2;
          view.layout(i2, i4, i1, i3 + i4);
          paramInt1 -= paramInt4;
          paramInt4 = 1;
        } else {
          paramInt1 -= view.getMeasuredWidth() + c1.leftMargin + c1.rightMargin;
          G(paramInt2);
          paramInt3++;
        } 
      } 
      paramInt2++;
    } 
    if (j == 1 && paramInt4 == 0) {
      View view = getChildAt(0);
      paramInt1 = view.getMeasuredWidth();
      paramInt2 = view.getMeasuredHeight();
      paramInt3 = n / 2 - paramInt1 / 2;
      paramInt4 = i - paramInt2 / 2;
      view.layout(paramInt3, paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
      return;
    } 
    paramInt2 = paramInt3 - (paramInt4 ^ 0x1);
    if (paramInt2 > 0) {
      paramInt1 /= paramInt2;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = Math.max(0, paramInt1);
    if (paramBoolean) {
      paramInt2 = getWidth() - getPaddingRight();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        c c1 = (c)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (c1.a) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 -= c1.rightMargin;
            paramInt3 = view.getMeasuredWidth();
            int i1 = view.getMeasuredHeight();
            int i2 = i - i1 / 2;
            view.layout(paramInt2 - paramInt3, i2, paramInt2, i1 + i2);
            paramInt3 = paramInt2 - paramInt3 + c1.leftMargin + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } else {
      paramInt2 = getPaddingLeft();
      paramInt1 = 0;
      while (paramInt1 < j) {
        View view = getChildAt(paramInt1);
        c c1 = (c)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (c1.a) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 += c1.leftMargin;
            paramInt3 = view.getMeasuredWidth();
            int i1 = view.getMeasuredHeight();
            int i2 = i - i1 / 2;
            view.layout(paramInt2, i2, paramInt2 + paramInt3, i1 + i2);
            paramInt3 = paramInt2 + paramInt3 + c1.rightMargin + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool1;
    boolean bool2 = this.B;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.B = bool1;
    if (bool2 != bool1)
      this.C = 0; 
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.B) {
      e e1 = this.u;
      if (e1 != null && i != this.C) {
        this.C = i;
        e1.M(true);
      } 
    } 
    int j = getChildCount();
    if (this.B && j > 0) {
      M(paramInt1, paramInt2);
      return;
    } 
    for (i = 0; i < j; i++) {
      c c1 = (c)getChildAt(i).getLayoutParams();
      c1.rightMargin = 0;
      c1.leftMargin = 0;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.y.I(paramBoolean);
  }
  
  public void setOnMenuItemClickListener(e parame) {
    this.F = parame;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    getMenu();
    this.y.K(paramDrawable);
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.x = paramBoolean;
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.w != paramInt) {
      this.w = paramInt;
      if (paramInt == 0) {
        this.v = getContext();
        return;
      } 
      this.v = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setPresenter(c paramc) {
    this.y = paramc;
    paramc.J(this);
  }
  
  public static interface a {
    boolean a();
    
    boolean b();
  }
  
  private static class b implements j.a {
    public void b(e param1e, boolean param1Boolean) {}
    
    public boolean c(e param1e) {
      return false;
    }
  }
  
  public static class c extends LinearLayoutCompat.a {
    @ExportedProperty
    public boolean a;
    
    @ExportedProperty
    public int b;
    
    @ExportedProperty
    public int c;
    
    @ExportedProperty
    public boolean d;
    
    @ExportedProperty
    public boolean e;
    
    boolean f;
    
    public c(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = false;
    }
    
    public c(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public c(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public c(c param1c) {
      super((ViewGroup.LayoutParams)param1c);
      this.a = param1c.a;
    }
  }
  
  private class d implements e.a {
    d(ActionMenuView this$0) {}
    
    public boolean a(e param1e, MenuItem param1MenuItem) {
      ActionMenuView.e e1 = this.f.F;
      return (e1 != null && e1.onMenuItemClick(param1MenuItem));
    }
    
    public void b(e param1e) {
      e.a a1 = this.f.A;
      if (a1 != null)
        a1.b(param1e); 
    }
  }
  
  public static interface e {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */