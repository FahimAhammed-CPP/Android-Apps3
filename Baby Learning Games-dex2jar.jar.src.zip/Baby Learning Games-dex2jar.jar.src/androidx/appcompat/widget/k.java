package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import androidx.core.view.c;
import androidx.core.view.t;
import androidx.core.view.w;
import androidx.core.widget.j;
import e.a;
import n0.a;
import n0.b;

public class k extends EditText implements t {
  private final e f;
  
  private final a0 g;
  
  private final z h;
  
  private final androidx.core.widget.k i;
  
  private final l j;
  
  public k(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.D);
  }
  
  public k(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(t0.b(paramContext), paramAttributeSet, paramInt);
    r0.a((View)this, getContext());
    e e1 = new e((View)this);
    this.f = e1;
    e1.e(paramAttributeSet, paramInt);
    a0 a01 = new a0((TextView)this);
    this.g = a01;
    a01.m(paramAttributeSet, paramInt);
    a01.b();
    this.h = new z((TextView)this);
    this.i = new androidx.core.widget.k();
    l l1 = new l(this);
    this.j = l1;
    l1.c(paramAttributeSet, paramInt);
    b(l1);
  }
  
  public c a(c paramc) {
    return this.i.a((View)this, paramc);
  }
  
  void b(l paraml) {
    KeyListener keyListener = getKeyListener();
    if (paraml.b(keyListener)) {
      boolean bool = isFocusable();
      int i = getInputType();
      KeyListener keyListener1 = paraml.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool);
    } 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.f;
    if (e1 != null)
      e1.b(); 
    a0 a01 = this.g;
    if (a01 != null)
      a01.b(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return j.p(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.f;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.f;
    return (e1 != null) ? e1.d() : null;
  }
  
  public Editable getText() {
    return (Build.VERSION.SDK_INT >= 28) ? super.getText() : getEditableText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      z z1 = this.h;
      if (z1 != null)
        return z1.a(); 
    } 
    return super.getTextClassifier();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection1 = super.onCreateInputConnection(paramEditorInfo);
    this.g.r((TextView)this, inputConnection1, paramEditorInfo);
    InputConnection inputConnection2 = n.a(inputConnection1, paramEditorInfo, (View)this);
    inputConnection1 = inputConnection2;
    if (inputConnection2 != null) {
      inputConnection1 = inputConnection2;
      if (Build.VERSION.SDK_INT <= 30) {
        String[] arrayOfString = w.E((View)this);
        inputConnection1 = inputConnection2;
        if (arrayOfString != null) {
          a.d(paramEditorInfo, arrayOfString);
          inputConnection1 = b.b((View)this, inputConnection2, paramEditorInfo);
        } 
      } 
    } 
    return this.j.d(inputConnection1, paramEditorInfo);
  }
  
  public boolean onDragEvent(DragEvent paramDragEvent) {
    return v.a((View)this, paramDragEvent) ? true : super.onDragEvent(paramDragEvent);
  }
  
  public boolean onTextContextMenuItem(int paramInt) {
    return v.b((TextView)this, paramInt) ? true : super.onTextContextMenuItem(paramInt);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.f;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.f;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(j.q((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.j.e(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.j.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.f;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.f;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    a0 a01 = this.g;
    if (a01 != null)
      a01.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      z z1 = this.h;
      if (z1 != null) {
        z1.b(paramTextClassifier);
        return;
      } 
    } 
    super.setTextClassifier(paramTextClassifier);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */