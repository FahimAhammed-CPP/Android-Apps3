package androidx.appcompat.widget;

import android.graphics.Insets;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.ScaleDrawable;
import android.os.Build;
import h.c;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class f0 {
  private static final int[] a = new int[] { 16842912 };
  
  private static final int[] b = new int[0];
  
  public static final Rect c = new Rect();
  
  public static boolean a(Drawable paramDrawable) {
    Drawable[] arrayOfDrawable;
    if (paramDrawable instanceof DrawableContainer) {
      Drawable.ConstantState constantState = paramDrawable.getConstantState();
      if (constantState instanceof DrawableContainer.DrawableContainerState) {
        arrayOfDrawable = ((DrawableContainer.DrawableContainerState)constantState).getChildren();
        int j = arrayOfDrawable.length;
        for (int i = 0; i < j; i++) {
          if (!a(arrayOfDrawable[i]))
            return false; 
        } 
      } 
    } else {
      if (arrayOfDrawable instanceof d0.b)
        return a(((d0.b)arrayOfDrawable).b()); 
      if (arrayOfDrawable instanceof c)
        return a(((c)arrayOfDrawable).a()); 
      if (arrayOfDrawable instanceof ScaleDrawable)
        return a(((ScaleDrawable)arrayOfDrawable).getDrawable()); 
    } 
    return true;
  }
  
  static void b(Drawable paramDrawable) {
    String str = paramDrawable.getClass().getName();
    int i = Build.VERSION.SDK_INT;
    if (i >= 29 && i < 31 && "android.graphics.drawable.ColorStateListDrawable".equals(str))
      c(paramDrawable); 
  }
  
  private static void c(Drawable paramDrawable) {
    int[] arrayOfInt = paramDrawable.getState();
    if (arrayOfInt == null || arrayOfInt.length == 0) {
      paramDrawable.setState(a);
    } else {
      paramDrawable.setState(b);
    } 
    paramDrawable.setState(arrayOfInt);
  }
  
  public static Rect d(Drawable paramDrawable) {
    Insets insets;
    if (Build.VERSION.SDK_INT >= 29) {
      insets = b.a(paramDrawable);
      return new Rect(insets.left, insets.top, insets.right, insets.bottom);
    } 
    return a.a(d0.a.q((Drawable)insets));
  }
  
  public static PorterDuff.Mode e(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
  
  static class a {
    private static final boolean a;
    
    private static final Method b;
    
    private static final Field c;
    
    private static final Field d;
    
    private static final Field e;
    
    private static final Field f;
    
    static {
      // Byte code:
      //   0: ldc 'android.graphics.Insets'
      //   2: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   5: astore_2
      //   6: ldc android/graphics/drawable/Drawable
      //   8: ldc 'getOpticalInsets'
      //   10: iconst_0
      //   11: anewarray java/lang/Class
      //   14: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   17: astore_1
      //   18: aload_2
      //   19: ldc 'left'
      //   21: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   24: astore_3
      //   25: aload_2
      //   26: ldc 'top'
      //   28: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   31: astore #5
      //   33: aload_2
      //   34: ldc 'right'
      //   36: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   39: astore #4
      //   41: aload_2
      //   42: ldc 'bottom'
      //   44: invokevirtual getField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
      //   47: astore_2
      //   48: iconst_1
      //   49: istore_0
      //   50: goto -> 151
      //   53: aconst_null
      //   54: astore #4
      //   56: goto -> 147
      //   59: aconst_null
      //   60: astore #4
      //   62: aload_1
      //   63: astore_2
      //   64: aload #4
      //   66: astore_1
      //   67: goto -> 139
      //   70: aconst_null
      //   71: astore #4
      //   73: aload_1
      //   74: astore_2
      //   75: aload #4
      //   77: astore_1
      //   78: goto -> 139
      //   81: aconst_null
      //   82: astore #4
      //   84: aload_1
      //   85: astore_2
      //   86: aload #4
      //   88: astore_1
      //   89: goto -> 139
      //   92: goto -> 105
      //   95: goto -> 120
      //   98: aload_1
      //   99: astore_2
      //   100: goto -> 135
      //   103: aconst_null
      //   104: astore_1
      //   105: aconst_null
      //   106: astore_3
      //   107: aconst_null
      //   108: astore #4
      //   110: aload_1
      //   111: astore_2
      //   112: aload #4
      //   114: astore_1
      //   115: goto -> 139
      //   118: aconst_null
      //   119: astore_1
      //   120: aconst_null
      //   121: astore_3
      //   122: aconst_null
      //   123: astore #4
      //   125: aload_1
      //   126: astore_2
      //   127: aload #4
      //   129: astore_1
      //   130: goto -> 139
      //   133: aconst_null
      //   134: astore_2
      //   135: aconst_null
      //   136: astore_3
      //   137: aconst_null
      //   138: astore_1
      //   139: aload_1
      //   140: astore #4
      //   142: aload_1
      //   143: astore #5
      //   145: aload_2
      //   146: astore_1
      //   147: iconst_0
      //   148: istore_0
      //   149: aconst_null
      //   150: astore_2
      //   151: iload_0
      //   152: ifeq -> 182
      //   155: aload_1
      //   156: putstatic androidx/appcompat/widget/f0$a.b : Ljava/lang/reflect/Method;
      //   159: aload_3
      //   160: putstatic androidx/appcompat/widget/f0$a.c : Ljava/lang/reflect/Field;
      //   163: aload #5
      //   165: putstatic androidx/appcompat/widget/f0$a.d : Ljava/lang/reflect/Field;
      //   168: aload #4
      //   170: putstatic androidx/appcompat/widget/f0$a.e : Ljava/lang/reflect/Field;
      //   173: aload_2
      //   174: putstatic androidx/appcompat/widget/f0$a.f : Ljava/lang/reflect/Field;
      //   177: iconst_1
      //   178: putstatic androidx/appcompat/widget/f0$a.a : Z
      //   181: return
      //   182: aconst_null
      //   183: putstatic androidx/appcompat/widget/f0$a.b : Ljava/lang/reflect/Method;
      //   186: aconst_null
      //   187: putstatic androidx/appcompat/widget/f0$a.c : Ljava/lang/reflect/Field;
      //   190: aconst_null
      //   191: putstatic androidx/appcompat/widget/f0$a.d : Ljava/lang/reflect/Field;
      //   194: aconst_null
      //   195: putstatic androidx/appcompat/widget/f0$a.e : Ljava/lang/reflect/Field;
      //   198: aconst_null
      //   199: putstatic androidx/appcompat/widget/f0$a.f : Ljava/lang/reflect/Field;
      //   202: iconst_0
      //   203: putstatic androidx/appcompat/widget/f0$a.a : Z
      //   206: return
      //   207: astore_1
      //   208: goto -> 133
      //   211: astore_1
      //   212: goto -> 118
      //   215: astore_1
      //   216: goto -> 103
      //   219: astore_2
      //   220: goto -> 98
      //   223: astore_2
      //   224: goto -> 95
      //   227: astore_2
      //   228: goto -> 92
      //   231: astore_2
      //   232: goto -> 81
      //   235: astore_2
      //   236: goto -> 70
      //   239: astore_2
      //   240: goto -> 59
      //   243: astore_2
      //   244: goto -> 53
      //   247: astore_2
      //   248: goto -> 147
      // Exception table:
      //   from	to	target	type
      //   0	18	207	java/lang/NoSuchMethodException
      //   0	18	211	java/lang/ClassNotFoundException
      //   0	18	215	java/lang/NoSuchFieldException
      //   18	25	219	java/lang/NoSuchMethodException
      //   18	25	223	java/lang/ClassNotFoundException
      //   18	25	227	java/lang/NoSuchFieldException
      //   25	33	231	java/lang/NoSuchMethodException
      //   25	33	235	java/lang/ClassNotFoundException
      //   25	33	239	java/lang/NoSuchFieldException
      //   33	41	243	java/lang/NoSuchMethodException
      //   33	41	243	java/lang/ClassNotFoundException
      //   33	41	243	java/lang/NoSuchFieldException
      //   41	48	247	java/lang/NoSuchMethodException
      //   41	48	247	java/lang/ClassNotFoundException
      //   41	48	247	java/lang/NoSuchFieldException
    }
    
    static Rect a(Drawable param1Drawable) {
      if (Build.VERSION.SDK_INT < 29 && a)
        try {
          Object object = b.invoke(param1Drawable, new Object[0]);
          if (object != null)
            return new Rect(c.getInt(object), d.getInt(object), e.getInt(object), f.getInt(object)); 
        } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {} 
      return f0.c;
    }
  }
  
  static class b {
    static Insets a(Drawable param1Drawable) {
      return param1Drawable.getOpticalInsets();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */