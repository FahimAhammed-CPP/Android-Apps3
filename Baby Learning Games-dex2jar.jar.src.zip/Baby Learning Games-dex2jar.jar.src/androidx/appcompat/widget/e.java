package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.w;
import e.j;

class e {
  private final View a;
  
  private final j b;
  
  private int c = -1;
  
  private u0 d;
  
  private u0 e;
  
  private u0 f;
  
  e(View paramView) {
    this.a = paramView;
    this.b = j.b();
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new u0(); 
    u0 u01 = this.f;
    u01.a();
    ColorStateList colorStateList = w.s(this.a);
    if (colorStateList != null) {
      u01.d = true;
      u01.a = colorStateList;
    } 
    PorterDuff.Mode mode = w.t(this.a);
    if (mode != null) {
      u01.c = true;
      u01.b = mode;
    } 
    if (u01.d || u01.c) {
      j.i(paramDrawable, u01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    return (this.d != null);
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      u0 u01 = this.e;
      if (u01 != null) {
        j.i(drawable, u01, this.a.getDrawableState());
        return;
      } 
      u01 = this.d;
      if (u01 != null)
        j.i(drawable, u01, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    u0 u01 = this.e;
    return (u01 != null) ? u01.a : null;
  }
  
  PorterDuff.Mode d() {
    u0 u01 = this.e;
    return (u01 != null) ? u01.b : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.S3;
    w0 w0 = w0.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    w.m0(view, view.getContext(), arrayOfInt, paramAttributeSet, w0.r(), paramInt, 0);
    try {
      paramInt = j.T3;
      if (w0.s(paramInt)) {
        this.c = w0.n(paramInt, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.U3;
      if (w0.s(paramInt))
        w.t0(this.a, w0.c(paramInt)); 
      paramInt = j.V3;
      if (w0.s(paramInt))
        w.u0(this.a, f0.e(w0.k(paramInt, -1), null)); 
      return;
    } finally {
      w0.w();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    j j1 = this.b;
    if (j1 != null) {
      ColorStateList colorStateList = j1.f(this.a.getContext(), paramInt);
    } else {
      j1 = null;
    } 
    h((ColorStateList)j1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new u0(); 
      u0 u01 = this.d;
      u01.a = paramColorStateList;
      u01.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new u0(); 
    u0 u01 = this.e;
    u01.a = paramColorStateList;
    u01.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new u0(); 
    u0 u01 = this.e;
    u01.b = paramMode;
    u01.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */