package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.view.menu.d;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.g;
import java.lang.reflect.Method;

public class l0 extends j0 implements k0 {
  private static Method P;
  
  private k0 O;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        P = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public l0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void R(Object paramObject) {
    this.K.setEnterTransition((Transition)paramObject);
  }
  
  public void S(Object paramObject) {
    this.K.setExitTransition((Transition)paramObject);
  }
  
  public void T(k0 paramk0) {
    this.O = paramk0;
  }
  
  public void U(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = P;
      if (method != null)
        try {
          method.invoke(this.K, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      this.K.setTouchModal(paramBoolean);
    } 
  }
  
  public void e(e parame, MenuItem paramMenuItem) {
    k0 k01 = this.O;
    if (k01 != null)
      k01.e(parame, paramMenuItem); 
  }
  
  public void f(e parame, MenuItem paramMenuItem) {
    k0 k01 = this.O;
    if (k01 != null)
      k01.f(parame, paramMenuItem); 
  }
  
  g0 s(Context paramContext, boolean paramBoolean) {
    a a = new a(paramContext, paramBoolean);
    a.setHoverListener(this);
    return a;
  }
  
  public static class a extends g0 {
    final int t;
    
    final int u;
    
    private k0 v;
    
    private MenuItem w;
    
    public a(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      if (1 == param1Context.getResources().getConfiguration().getLayoutDirection()) {
        this.t = 21;
        this.u = 22;
        return;
      } 
      this.t = 22;
      this.u = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      if (this.v != null) {
        int i;
        d d;
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter;
          i = headerViewListAdapter.getHeadersCount();
          d = (d)headerViewListAdapter.getWrappedAdapter();
        } else {
          i = 0;
          d = d;
        } 
        g g2 = null;
        g g1 = g2;
        if (param1MotionEvent.getAction() != 10) {
          int j = pointToPosition((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY());
          g1 = g2;
          if (j != -1) {
            i = j - i;
            g1 = g2;
            if (i >= 0) {
              g1 = g2;
              if (i < d.getCount())
                g1 = d.c(i); 
            } 
          } 
        } 
        MenuItem menuItem = this.w;
        if (menuItem != g1) {
          e e = d.b();
          if (menuItem != null)
            this.v.f(e, menuItem); 
          this.w = (MenuItem)g1;
          if (g1 != null)
            this.v.e(e, (MenuItem)g1); 
        } 
      } 
      return super.onHoverEvent(param1MotionEvent);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      d d;
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.t) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.u) {
        setSelection(-1);
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          d = (d)((HeaderViewListAdapter)listAdapter).getWrappedAdapter();
        } else {
          d = d;
        } 
        d.b().e(false);
        return true;
      } 
      return super.onKeyDown(param1Int, (KeyEvent)d);
    }
    
    public void setHoverListener(k0 param1k0) {
      this.v = param1k0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */