package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.e;

public interface k0 {
  void e(e parame, MenuItem paramMenuItem);
  
  void f(e parame, MenuItem paramMenuItem);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */