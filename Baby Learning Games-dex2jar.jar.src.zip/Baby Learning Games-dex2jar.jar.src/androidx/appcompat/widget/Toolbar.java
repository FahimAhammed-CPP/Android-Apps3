package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.m;
import androidx.core.view.h;
import androidx.core.view.i;
import androidx.core.view.w;
import e.j;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
  private int A;
  
  private int B = 8388627;
  
  private CharSequence C;
  
  private CharSequence D;
  
  private ColorStateList E;
  
  private ColorStateList F;
  
  private boolean G;
  
  private boolean H;
  
  private final ArrayList<View> I = new ArrayList<View>();
  
  private final ArrayList<View> J = new ArrayList<View>();
  
  private final int[] K = new int[2];
  
  final i L = new i(new x0(this));
  
  private ArrayList<MenuItem> M = new ArrayList<MenuItem>();
  
  f N;
  
  private final ActionMenuView.e O = new a(this);
  
  private y0 P;
  
  private c Q;
  
  private d R;
  
  private j.a S;
  
  private androidx.appcompat.view.menu.e.a T;
  
  private boolean U;
  
  private final Runnable V = new b(this);
  
  private ActionMenuView f;
  
  private TextView g;
  
  private TextView h;
  
  private ImageButton i;
  
  private ImageView j;
  
  private Drawable k;
  
  private CharSequence l;
  
  ImageButton m;
  
  View n;
  
  private Context o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  int s;
  
  private int t;
  
  private int u;
  
  private int v;
  
  private int w;
  
  private int x;
  
  private o0 y;
  
  private int z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.R);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = j.l3;
    w0 w0 = w0.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    w.m0((View)this, paramContext, arrayOfInt, paramAttributeSet, w0.r(), paramInt, 0);
    this.q = w0.n(j.N3, 0);
    this.r = w0.n(j.E3, 0);
    this.B = w0.l(j.m3, this.B);
    this.s = w0.l(j.n3, 48);
    int j = w0.e(j.H3, 0);
    int k = j.M3;
    paramInt = j;
    if (w0.s(k))
      paramInt = w0.e(k, j); 
    this.x = paramInt;
    this.w = paramInt;
    this.v = paramInt;
    this.u = paramInt;
    paramInt = w0.e(j.K3, -1);
    if (paramInt >= 0)
      this.u = paramInt; 
    paramInt = w0.e(j.J3, -1);
    if (paramInt >= 0)
      this.v = paramInt; 
    paramInt = w0.e(j.L3, -1);
    if (paramInt >= 0)
      this.w = paramInt; 
    paramInt = w0.e(j.I3, -1);
    if (paramInt >= 0)
      this.x = paramInt; 
    this.t = w0.f(j.y3, -1);
    paramInt = w0.e(j.u3, -2147483648);
    j = w0.e(j.q3, -2147483648);
    k = w0.f(j.s3, 0);
    int m = w0.f(j.t3, 0);
    h();
    this.y.e(k, m);
    if (paramInt != Integer.MIN_VALUE || j != Integer.MIN_VALUE)
      this.y.g(paramInt, j); 
    this.z = w0.e(j.v3, -2147483648);
    this.A = w0.e(j.r3, -2147483648);
    this.k = w0.g(j.p3);
    this.l = w0.p(j.o3);
    CharSequence charSequence3 = w0.p(j.G3);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = w0.p(j.D3);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.o = getContext();
    setPopupTheme(w0.n(j.C3, 0));
    Drawable drawable2 = w0.g(j.B3);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = w0.p(j.A3);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = w0.g(j.w3);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = w0.p(j.x3);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = j.O3;
    if (w0.s(paramInt))
      setTitleTextColor(w0.c(paramInt)); 
    paramInt = j.F3;
    if (w0.s(paramInt))
      setSubtitleTextColor(w0.c(paramInt)); 
    paramInt = j.z3;
    if (w0.s(paramInt))
      x(w0.n(paramInt, 0)); 
    w0.w();
  }
  
  private int C(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int j = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, j);
    paramArrayOfint[0] = Math.max(0, -j);
    paramInt2 = q(paramView, paramInt2);
    j = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + j, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + j + ((ViewGroup.MarginLayoutParams)e1).rightMargin;
  }
  
  private int D(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int j = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, j);
    paramArrayOfint[1] = Math.max(0, -j);
    paramInt2 = q(paramView, paramInt2);
    j = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - j, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - j + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  private int E(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int j = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int k = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int m = Math.max(0, j) + Math.max(0, k);
    paramArrayOfint[0] = Math.max(0, -j);
    paramArrayOfint[1] = Math.max(0, -k);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + m + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + m;
  }
  
  private void F(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int j = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(j, paramInt1);
  }
  
  private void G() {
    ArrayList<MenuItem> arrayList1 = getCurrentMenuItems();
    this.L.a(getMenu(), getMenuInflater());
    ArrayList<MenuItem> arrayList2 = getCurrentMenuItems();
    arrayList2.removeAll(arrayList1);
    this.M = arrayList2;
  }
  
  private void H() {
    removeCallbacks(this.V);
    post(this.V);
  }
  
  private boolean O() {
    if (!this.U)
      return false; 
    int k = getChildCount();
    for (int j = 0; j < k; j++) {
      View view = getChildAt(j);
      if (P(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean P(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  private void b(List<View> paramList, int paramInt) {
    int j = w.B((View)this);
    boolean bool = false;
    if (j == 1) {
      j = 1;
    } else {
      j = 0;
    } 
    int m = getChildCount();
    int k = androidx.core.view.e.b(paramInt, w.B((View)this));
    paramList.clear();
    paramInt = bool;
    if (j != 0) {
      for (paramInt = m - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && P(view) && p(e1.a) == k)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < m) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && P(view) && p(e1.a) == k)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = m();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = o((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.n != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.J.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  private ArrayList<MenuItem> getCurrentMenuItems() {
    ArrayList<MenuItem> arrayList = new ArrayList();
    Menu menu = getMenu();
    for (int j = 0; j < menu.size(); j++)
      arrayList.add(menu.getItem(j)); 
    return arrayList;
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new k.g(getContext());
  }
  
  private void h() {
    if (this.y == null)
      this.y = new o0(); 
  }
  
  private void i() {
    if (this.j == null)
      this.j = new AppCompatImageView(getContext()); 
  }
  
  private void j() {
    k();
    if (this.f.N() == null) {
      androidx.appcompat.view.menu.e e1 = (androidx.appcompat.view.menu.e)this.f.getMenu();
      if (this.R == null)
        this.R = new d(this); 
      this.f.setExpandedActionViewsExclusive(true);
      e1.c(this.R, this.o);
    } 
  }
  
  private void k() {
    if (this.f == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.f = actionMenuView;
      actionMenuView.setPopupTheme(this.p);
      this.f.setOnMenuItemClickListener(this.O);
      this.f.O(this.S, this.T);
      e e1 = m();
      e1.a = 0x800005 | this.s & 0x70;
      this.f.setLayoutParams((ViewGroup.LayoutParams)e1);
      c((View)this.f, false);
    } 
  }
  
  private void l() {
    if (this.i == null) {
      this.i = new o(getContext(), null, e.a.Q);
      e e1 = m();
      e1.a = 0x800003 | this.s & 0x70;
      this.i.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  private int p(int paramInt) {
    int j = w.B((View)this);
    int k = androidx.core.view.e.b(paramInt, j) & 0x7;
    if (k != 1) {
      paramInt = 3;
      if (k != 3 && k != 5) {
        if (j == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return k;
  }
  
  private int q(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int k = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (k - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int j = r(e1.a);
    if (j != 48) {
      if (j != 80) {
        int m = getPaddingTop();
        int n = getPaddingBottom();
        int i1 = getHeight();
        j = (i1 - m - n - k) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (j >= paramInt) {
          k = i1 - n - k - j - m;
          n = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = j;
          if (k < n)
            paramInt = Math.max(0, j - n - k); 
        } 
        return m + paramInt;
      } 
      return getHeight() - getPaddingBottom() - k - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int r(int paramInt) {
    int j = paramInt & 0x70;
    paramInt = j;
    if (j != 16) {
      paramInt = j;
      if (j != 48) {
        paramInt = j;
        if (j != 80)
          paramInt = this.B & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private int s(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return h.b(marginLayoutParams) + h.a(marginLayoutParams);
  }
  
  private int t(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int u(List<View> paramList, int[] paramArrayOfint) {
    int n = paramArrayOfint[0];
    int m = paramArrayOfint[1];
    int i1 = paramList.size();
    int j = 0;
    int k = j;
    while (j < i1) {
      View view = paramList.get(j);
      e e1 = (e)view.getLayoutParams();
      n = ((ViewGroup.MarginLayoutParams)e1).leftMargin - n;
      m = ((ViewGroup.MarginLayoutParams)e1).rightMargin - m;
      int i2 = Math.max(0, n);
      int i3 = Math.max(0, m);
      n = Math.max(0, -n);
      m = Math.max(0, -m);
      k += i2 + view.getMeasuredWidth() + i3;
      j++;
    } 
    return k;
  }
  
  private boolean z(View paramView) {
    return (paramView.getParent() == this || this.J.contains(paramView));
  }
  
  public boolean A() {
    ActionMenuView actionMenuView = this.f;
    return (actionMenuView != null && actionMenuView.I());
  }
  
  public boolean B() {
    ActionMenuView actionMenuView = this.f;
    return (actionMenuView != null && actionMenuView.J());
  }
  
  void I() {
    for (int j = getChildCount() - 1; j >= 0; j--) {
      View view = getChildAt(j);
      if (((e)view.getLayoutParams()).b != 2 && view != this.f) {
        removeViewAt(j);
        this.J.add(view);
      } 
    } 
  }
  
  public void J(int paramInt1, int paramInt2) {
    h();
    this.y.g(paramInt1, paramInt2);
  }
  
  public void K(androidx.appcompat.view.menu.e parame, c paramc) {
    if (parame == null && this.f == null)
      return; 
    k();
    androidx.appcompat.view.menu.e e1 = this.f.N();
    if (e1 == parame)
      return; 
    if (e1 != null) {
      e1.Q((j)this.Q);
      e1.Q(this.R);
    } 
    if (this.R == null)
      this.R = new d(this); 
    paramc.I(true);
    if (parame != null) {
      parame.c((j)paramc, this.o);
      parame.c(this.R, this.o);
    } else {
      paramc.d(this.o, null);
      this.R.d(this.o, null);
      paramc.g(true);
      this.R.g(true);
    } 
    this.f.setPopupTheme(this.p);
    this.f.setPresenter(paramc);
    this.Q = paramc;
  }
  
  public void L(j.a parama, androidx.appcompat.view.menu.e.a parama1) {
    this.S = parama;
    this.T = parama1;
    ActionMenuView actionMenuView = this.f;
    if (actionMenuView != null)
      actionMenuView.O(parama, parama1); 
  }
  
  public void M(Context paramContext, int paramInt) {
    this.r = paramInt;
    TextView textView = this.h;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void N(Context paramContext, int paramInt) {
    this.q = paramInt;
    TextView textView = this.g;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean Q() {
    ActionMenuView actionMenuView = this.f;
    return (actionMenuView != null && actionMenuView.P());
  }
  
  void a() {
    for (int j = this.J.size() - 1; j >= 0; j--)
      addView(this.J.get(j)); 
    this.J.clear();
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public boolean d() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.f;
      if (actionMenuView != null && actionMenuView.K())
        return true; 
    } 
    return false;
  }
  
  public void e() {
    androidx.appcompat.view.menu.g g;
    d d1 = this.R;
    if (d1 == null) {
      d1 = null;
    } else {
      g = d1.g;
    } 
    if (g != null)
      g.collapseActionView(); 
  }
  
  public void f() {
    ActionMenuView actionMenuView = this.f;
    if (actionMenuView != null)
      actionMenuView.B(); 
  }
  
  void g() {
    if (this.m == null) {
      o o = new o(getContext(), null, e.a.Q);
      this.m = o;
      o.setImageDrawable(this.k);
      this.m.setContentDescription(this.l);
      e e1 = m();
      e1.a = 0x800003 | this.s & 0x70;
      e1.b = 2;
      this.m.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.m.setOnClickListener(new c(this));
    } 
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.m;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.m;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    o0 o01 = this.y;
    return (o01 != null) ? o01.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int j = this.A;
    return (j != Integer.MIN_VALUE) ? j : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    o0 o01 = this.y;
    return (o01 != null) ? o01.b() : 0;
  }
  
  public int getContentInsetRight() {
    o0 o01 = this.y;
    return (o01 != null) ? o01.c() : 0;
  }
  
  public int getContentInsetStart() {
    o0 o01 = this.y;
    return (o01 != null) ? o01.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int j = this.z;
    return (j != Integer.MIN_VALUE) ? j : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual N : ()Landroidx/appcompat/view/menu/e;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield A : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (w.B((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (w.B((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.z, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.j;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.j;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    j();
    return this.f.getMenu();
  }
  
  View getNavButtonView() {
    return (View)this.i;
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.i;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.i;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  c getOuterActionMenuPresenter() {
    return this.Q;
  }
  
  public Drawable getOverflowIcon() {
    j();
    return this.f.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.o;
  }
  
  public int getPopupTheme() {
    return this.p;
  }
  
  public CharSequence getSubtitle() {
    return this.D;
  }
  
  final TextView getSubtitleTextView() {
    return this.h;
  }
  
  public CharSequence getTitle() {
    return this.C;
  }
  
  public int getTitleMarginBottom() {
    return this.x;
  }
  
  public int getTitleMarginEnd() {
    return this.v;
  }
  
  public int getTitleMarginStart() {
    return this.u;
  }
  
  public int getTitleMarginTop() {
    return this.w;
  }
  
  final TextView getTitleTextView() {
    return this.g;
  }
  
  public e0 getWrapper() {
    if (this.P == null)
      this.P = new y0(this, true); 
    return this.P;
  }
  
  protected e m() {
    return new e(-2, -2);
  }
  
  public e n(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  protected e o(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof androidx.appcompat.app.a.a) ? new e((androidx.appcompat.app.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.V);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getActionMasked();
    if (j == 9)
      this.H = false; 
    if (!this.H) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (j == 9 && !bool)
        this.H = true; 
    } 
    if (j == 10 || j == 3)
      this.H = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (w.B((View)this) == 1) {
      m = 1;
    } else {
      m = 0;
    } 
    int i1 = getWidth();
    int i4 = getHeight();
    int j = getPaddingLeft();
    int i2 = getPaddingRight();
    int i3 = getPaddingTop();
    int i5 = getPaddingBottom();
    int n = i1 - i2;
    int[] arrayOfInt = this.K;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = w.C((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (P((View)this.i)) {
      if (m) {
        k = D((View)this.i, n, arrayOfInt, paramInt4);
        paramInt3 = j;
      } else {
        paramInt3 = C((View)this.i, j, arrayOfInt, paramInt4);
        k = n;
      } 
    } else {
      paramInt3 = j;
      k = n;
    } 
    paramInt1 = paramInt3;
    paramInt2 = k;
    if (P((View)this.m))
      if (m) {
        paramInt2 = D((View)this.m, k, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = C((View)this.m, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = k;
      }  
    int k = paramInt1;
    paramInt3 = paramInt2;
    if (P((View)this.f))
      if (m) {
        k = C((View)this.f, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = D((View)this.f, paramInt2, arrayOfInt, paramInt4);
        k = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - k);
    arrayOfInt[1] = Math.max(0, paramInt1 - n - paramInt3);
    paramInt2 = Math.max(k, paramInt2);
    paramInt3 = Math.min(paramInt3, n - paramInt1);
    paramInt1 = paramInt2;
    k = paramInt3;
    if (P(this.n))
      if (m) {
        k = D(this.n, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = C(this.n, paramInt2, arrayOfInt, paramInt4);
        k = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = k;
    if (P((View)this.j))
      if (m) {
        paramInt2 = D((View)this.j, k, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = C((View)this.j, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = k;
      }  
    paramBoolean = P((View)this.g);
    boolean bool = P((View)this.h);
    if (paramBoolean) {
      e e1 = (e)this.g.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin + this.g.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.h.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)e1).topMargin + this.h.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.g;
      } else {
        textView1 = this.h;
      } 
      if (bool) {
        textView2 = this.h;
      } else {
        textView2 = this.g;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.g.getMeasuredWidth() > 0) || (bool && this.h.getMeasuredWidth() > 0)) {
        k = 1;
      } else {
        k = 0;
      } 
      n = this.B & 0x70;
      if (n != 48) {
        if (n != 80) {
          n = (i4 - i3 - i5 - paramInt1) / 2;
          int i6 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i7 = this.w;
          if (n < i6 + i7) {
            paramInt1 = i6 + i7;
          } else {
            i4 = i4 - i5 - paramInt1 - n - i3;
            i5 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i6 = this.x;
            paramInt1 = n;
            if (i4 < i5 + i6)
              paramInt1 = Math.max(0, n - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i6 - i4); 
          } 
          paramInt1 = i3 + paramInt1;
        } else {
          paramInt1 = i4 - i5 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.x - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.w;
      } 
      if (m) {
        if (k != 0) {
          m = this.u;
        } else {
          m = 0;
        } 
        m -= arrayOfInt[1];
        paramInt2 -= Math.max(0, m);
        arrayOfInt[1] = Math.max(0, -m);
        if (paramBoolean) {
          e1 = (e)this.g.getLayoutParams();
          n = paramInt2 - this.g.getMeasuredWidth();
          m = this.g.getMeasuredHeight() + paramInt1;
          this.g.layout(n, paramInt1, paramInt2, m);
          paramInt1 = n - this.v;
          n = m + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          m = paramInt2;
          n = paramInt1;
          paramInt1 = m;
        } 
        if (bool) {
          m = n + ((ViewGroup.MarginLayoutParams)this.h.getLayoutParams()).topMargin;
          n = this.h.getMeasuredWidth();
          i3 = this.h.getMeasuredHeight();
          this.h.layout(paramInt2 - n, m, paramInt2, i3 + m);
          m = paramInt2 - this.v;
        } else {
          m = paramInt2;
        } 
        if (k != 0)
          paramInt2 = Math.min(paramInt1, m); 
        paramInt1 = paramInt3;
      } else {
        if (k != 0) {
          m = this.u;
        } else {
          m = 0;
        } 
        m -= arrayOfInt[0];
        paramInt3 += Math.max(0, m);
        arrayOfInt[0] = Math.max(0, -m);
        if (paramBoolean) {
          e1 = (e)this.g.getLayoutParams();
          m = this.g.getMeasuredWidth() + paramInt3;
          n = this.g.getMeasuredHeight() + paramInt1;
          this.g.layout(paramInt3, paramInt1, m, n);
          m += this.v;
          paramInt1 = n + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          m = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.h.getLayoutParams()).topMargin;
          n = this.h.getMeasuredWidth() + paramInt3;
          i3 = this.h.getMeasuredHeight();
          this.h.layout(paramInt3, paramInt1, n, i3 + paramInt1);
          n += this.v;
        } else {
          n = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (k != 0) {
          paramInt1 = Math.max(m, n);
          paramInt3 = paramInt2;
        } 
        k = j;
        j = 0;
        b(this.I, 3);
        m = this.I.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    k = j;
    j = 0;
    b(this.I, 3);
    int m = this.I.size();
    paramInt2 = 0;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.a());
    ActionMenuView actionMenuView = this.f;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.e e1 = actionMenuView.N();
    } else {
      actionMenuView = null;
    } 
    int j = g.h;
    if (j != 0 && this.R != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(j);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.i)
      H(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    h();
    o0 o01 = this.y;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    o01.f(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.R;
    if (d1 != null) {
      androidx.appcompat.view.menu.g g1 = d1.g;
      if (g1 != null)
        g.h = g1.getItemId(); 
    } 
    g.i = B();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int j = paramMotionEvent.getActionMasked();
    if (j == 0)
      this.G = false; 
    if (!this.G) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (j == 0 && !bool)
        this.G = true; 
    } 
    if (j == 1 || j == 3)
      this.G = false; 
    return true;
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.m;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(g.a.b(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      this.m.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.m;
    if (imageButton != null)
      imageButton.setImageDrawable(this.k); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.U = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int j = paramInt;
    if (paramInt < 0)
      j = Integer.MIN_VALUE; 
    if (j != this.A) {
      this.A = j;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int j = paramInt;
    if (paramInt < 0)
      j = Integer.MIN_VALUE; 
    if (j != this.z) {
      this.z = j;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(g.a.b(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      i();
      if (!z((View)this.j))
        c((View)this.j, true); 
    } else {
      ImageView imageView1 = this.j;
      if (imageView1 != null && z((View)imageView1)) {
        removeView((View)this.j);
        this.J.remove(this.j);
      } 
    } 
    ImageView imageView = this.j;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      i(); 
    ImageView imageView = this.j;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      l(); 
    ImageButton imageButton = this.i;
    if (imageButton != null) {
      imageButton.setContentDescription(paramCharSequence);
      z0.a((View)this.i, paramCharSequence);
    } 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(g.a.b(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      l();
      if (!z((View)this.i))
        c((View)this.i, true); 
    } else {
      ImageButton imageButton1 = this.i;
      if (imageButton1 != null && z((View)imageButton1)) {
        removeView((View)this.i);
        this.J.remove(this.i);
      } 
    } 
    ImageButton imageButton = this.i;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    l();
    this.i.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.N = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    j();
    this.f.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.p != paramInt) {
      this.p = paramInt;
      if (paramInt == 0) {
        this.o = getContext();
        return;
      } 
      this.o = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.h == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.h = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.h.setEllipsize(TextUtils.TruncateAt.END);
        int j = this.r;
        if (j != 0)
          this.h.setTextAppearance(context, j); 
        ColorStateList colorStateList = this.F;
        if (colorStateList != null)
          this.h.setTextColor(colorStateList); 
      } 
      if (!z((View)this.h))
        c((View)this.h, true); 
    } else {
      TextView textView1 = this.h;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.h);
        this.J.remove(this.h);
      } 
    } 
    TextView textView = this.h;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.D = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.F = paramColorStateList;
    TextView textView = this.h;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.g == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.g = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.g.setEllipsize(TextUtils.TruncateAt.END);
        int j = this.q;
        if (j != 0)
          this.g.setTextAppearance(context, j); 
        ColorStateList colorStateList = this.E;
        if (colorStateList != null)
          this.g.setTextColor(colorStateList); 
      } 
      if (!z((View)this.g))
        c((View)this.g, true); 
    } else {
      TextView textView1 = this.g;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.g);
        this.J.remove(this.g);
      } 
    } 
    TextView textView = this.g;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.C = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.x = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.v = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.u = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.w = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.E = paramColorStateList;
    TextView textView = this.g;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public boolean v() {
    d d1 = this.R;
    return (d1 != null && d1.g != null);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.f;
    return (actionMenuView != null && actionMenuView.H());
  }
  
  public void x(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public void y() {
    for (MenuItem menuItem : this.M)
      getMenu().removeItem(menuItem.getItemId()); 
    G();
  }
  
  class a implements ActionMenuView.e {
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      if (this.a.L.b(param1MenuItem))
        return true; 
      Toolbar.f f = this.a.N;
      return (f != null) ? f.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    b(Toolbar this$0) {}
    
    public void run() {
      this.f.Q();
    }
  }
  
  class c implements View.OnClickListener {
    c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.f.e();
    }
  }
  
  private class d implements j {
    androidx.appcompat.view.menu.e f;
    
    androidx.appcompat.view.menu.g g;
    
    d(Toolbar this$0) {}
    
    public void b(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {}
    
    public void d(Context param1Context, androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = this.f;
      if (e1 != null) {
        androidx.appcompat.view.menu.g g1 = this.g;
        if (g1 != null)
          e1.f(g1); 
      } 
      this.f = param1e;
    }
    
    public void e(Parcelable param1Parcelable) {}
    
    public boolean f(m param1m) {
      return false;
    }
    
    public void g(boolean param1Boolean) {
      if (this.g != null) {
        androidx.appcompat.view.menu.e e1 = this.f;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (e1 != null) {
          int k = e1.size();
          int i = 0;
          while (true) {
            bool1 = bool2;
            if (i < k) {
              if (this.f.getItem(i) == this.g) {
                bool1 = true;
                break;
              } 
              i++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          k(this.f, this.g); 
      } 
    }
    
    public int getId() {
      return 0;
    }
    
    public boolean i() {
      return false;
    }
    
    public Parcelable j() {
      return null;
    }
    
    public boolean k(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      View view = this.h.n;
      if (view instanceof k.c)
        ((k.c)view).d(); 
      Toolbar toolbar = this.h;
      toolbar.removeView(toolbar.n);
      toolbar = this.h;
      toolbar.removeView((View)toolbar.m);
      toolbar = this.h;
      toolbar.n = null;
      toolbar.a();
      this.g = null;
      this.h.requestLayout();
      param1g.r(false);
      return true;
    }
    
    public boolean l(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      this.h.g();
      ViewParent viewParent = this.h.m.getParent();
      Toolbar toolbar = this.h;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.m); 
        Toolbar toolbar1 = this.h;
        toolbar1.addView((View)toolbar1.m);
      } 
      this.h.n = param1g.getActionView();
      this.g = param1g;
      viewParent = this.h.n.getParent();
      toolbar = this.h;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.n); 
        Toolbar.e e1 = this.h.m();
        toolbar = this.h;
        e1.a = 0x800003 | toolbar.s & 0x70;
        e1.b = 2;
        toolbar.n.setLayoutParams((ViewGroup.LayoutParams)e1);
        Toolbar toolbar1 = this.h;
        toolbar1.addView(toolbar1.n);
      } 
      this.h.I();
      this.h.requestLayout();
      param1g.r(true);
      View view = this.h.n;
      if (view instanceof k.c)
        ((k.c)view).c(); 
      return true;
    }
  }
  
  public static class e extends androidx.appcompat.app.a.a {
    int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public e(androidx.appcompat.app.a.a param1a) {
      super(param1a);
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class g extends p0.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    int h;
    
    boolean i;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.h = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.i = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    class a implements Parcelable.ClassLoaderCreator<g> {
      public Toolbar.g a(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Toolbar.g b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.g[] c(int param2Int) {
        return new Toolbar.g[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator<g> {
    public Toolbar.g a(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Toolbar.g b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.g[] c(int param1Int) {
      return new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */