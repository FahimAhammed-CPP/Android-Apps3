package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.b0;
import androidx.core.view.c0;
import androidx.core.view.w;
import e.j;

abstract class a extends ViewGroup {
  protected final a f = new a(this);
  
  protected final Context g;
  
  protected ActionMenuView h;
  
  protected c i;
  
  protected int j;
  
  protected b0 k;
  
  private boolean l;
  
  private boolean m;
  
  a(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  a(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue typedValue = new TypedValue();
    if (paramContext.getTheme().resolveAttribute(e.a.a, typedValue, true) && typedValue.resourceId != 0) {
      this.g = (Context)new ContextThemeWrapper(paramContext, typedValue.resourceId);
      return;
    } 
    this.g = paramContext;
  }
  
  protected static int d(int paramInt1, int paramInt2, boolean paramBoolean) {
    return paramBoolean ? (paramInt1 - paramInt2) : (paramInt1 + paramInt2);
  }
  
  protected int c(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3);
  }
  
  protected int e(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 += (paramInt3 - j) / 2;
    if (paramBoolean) {
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    } else {
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    } 
    paramInt1 = i;
    if (paramBoolean)
      paramInt1 = -i; 
    return paramInt1;
  }
  
  public b0 f(int paramInt, long paramLong) {
    b0 b01 = this.k;
    if (b01 != null)
      b01.b(); 
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      b01 = w.e((View)this).a(1.0F);
      b01.d(paramLong);
      b01.f(this.f.d(b01, paramInt));
      return b01;
    } 
    b01 = w.e((View)this).a(0.0F);
    b01.d(paramLong);
    b01.f(this.f.d(b01, paramInt));
    return b01;
  }
  
  public int getAnimatedVisibility() {
    return (this.k != null) ? this.f.b : getVisibility();
  }
  
  public int getContentHeight() {
    return this.j;
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray typedArray = getContext().obtainStyledAttributes(null, j.a, e.a.c, 0);
    setContentHeight(typedArray.getLayoutDimension(j.j, 0));
    typedArray.recycle();
    c c1 = this.i;
    if (c1 != null)
      c1.H(paramConfiguration); 
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.m = false; 
    if (!this.m) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.m = true; 
    } 
    if (i == 10 || i == 3)
      this.m = false; 
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.l = false; 
    if (!this.l) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.l = true; 
    } 
    if (i == 1 || i == 3)
      this.l = false; 
    return true;
  }
  
  public void setContentHeight(int paramInt) {
    this.j = paramInt;
    requestLayout();
  }
  
  public void setVisibility(int paramInt) {
    if (paramInt != getVisibility()) {
      b0 b01 = this.k;
      if (b01 != null)
        b01.b(); 
      super.setVisibility(paramInt);
    } 
  }
  
  protected class a implements c0 {
    private boolean a = false;
    
    int b;
    
    protected a(a this$0) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (this.a)
        return; 
      a a1 = this.c;
      a1.k = null;
      a.b(a1, this.b);
    }
    
    public void c(View param1View) {
      a.a(this.c, 0);
      this.a = false;
    }
    
    public a d(b0 param1b0, int param1Int) {
      this.c.k = param1b0;
      this.b = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */