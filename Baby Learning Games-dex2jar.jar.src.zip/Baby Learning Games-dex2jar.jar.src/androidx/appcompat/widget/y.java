package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.core.view.w;

public class y extends Spinner {
  private static final int[] n = new int[] { 16843505 };
  
  private final e f;
  
  private final Context g;
  
  private i0 h;
  
  private SpinnerAdapter i;
  
  private final boolean j;
  
  private g k;
  
  int l;
  
  final Rect m;
  
  public y(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.N);
  }
  
  public y(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public y(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public y(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield m : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic e/j.F2 : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/w0;
    //   36: astore #9
    //   38: aload_0
    //   39: new androidx/appcompat/widget/e
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield f : Landroidx/appcompat/widget/e;
    //   50: aload #5
    //   52: ifnull -> 72
    //   55: aload_0
    //   56: new k/d
    //   59: dup
    //   60: aload_1
    //   61: aload #5
    //   63: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/Resources$Theme;)V
    //   66: putfield g : Landroid/content/Context;
    //   69: goto -> 110
    //   72: aload #9
    //   74: getstatic e/j.K2 : I
    //   77: iconst_0
    //   78: invokevirtual n : (II)I
    //   81: istore #6
    //   83: iload #6
    //   85: ifeq -> 105
    //   88: aload_0
    //   89: new k/d
    //   92: dup
    //   93: aload_1
    //   94: iload #6
    //   96: invokespecial <init> : (Landroid/content/Context;I)V
    //   99: putfield g : Landroid/content/Context;
    //   102: goto -> 110
    //   105: aload_0
    //   106: aload_1
    //   107: putfield g : Landroid/content/Context;
    //   110: aconst_null
    //   111: astore #7
    //   113: iload #4
    //   115: istore #6
    //   117: iload #4
    //   119: iconst_m1
    //   120: if_icmpne -> 242
    //   123: aload_1
    //   124: aload_2
    //   125: getstatic androidx/appcompat/widget/y.n : [I
    //   128: iload_3
    //   129: iconst_0
    //   130: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   133: astore #5
    //   135: iload #4
    //   137: istore #6
    //   139: aload #5
    //   141: astore #8
    //   143: aload #5
    //   145: astore #7
    //   147: aload #5
    //   149: iconst_0
    //   150: invokevirtual hasValue : (I)Z
    //   153: ifeq -> 173
    //   156: aload #5
    //   158: astore #7
    //   160: aload #5
    //   162: iconst_0
    //   163: iconst_0
    //   164: invokevirtual getInt : (II)I
    //   167: istore #6
    //   169: aload #5
    //   171: astore #8
    //   173: aload #8
    //   175: invokevirtual recycle : ()V
    //   178: goto -> 242
    //   181: astore #8
    //   183: goto -> 195
    //   186: astore_1
    //   187: goto -> 230
    //   190: astore #8
    //   192: aconst_null
    //   193: astore #5
    //   195: aload #5
    //   197: astore #7
    //   199: ldc 'AppCompatSpinner'
    //   201: ldc 'Could not read android:spinnerMode'
    //   203: aload #8
    //   205: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   208: pop
    //   209: iload #4
    //   211: istore #6
    //   213: aload #5
    //   215: ifnull -> 242
    //   218: iload #4
    //   220: istore #6
    //   222: aload #5
    //   224: astore #8
    //   226: goto -> 173
    //   229: astore_1
    //   230: aload #7
    //   232: ifnull -> 240
    //   235: aload #7
    //   237: invokevirtual recycle : ()V
    //   240: aload_1
    //   241: athrow
    //   242: iload #6
    //   244: ifeq -> 356
    //   247: iload #6
    //   249: iconst_1
    //   250: if_icmpeq -> 256
    //   253: goto -> 387
    //   256: new androidx/appcompat/widget/y$e
    //   259: dup
    //   260: aload_0
    //   261: aload_0
    //   262: getfield g : Landroid/content/Context;
    //   265: aload_2
    //   266: iload_3
    //   267: invokespecial <init> : (Landroidx/appcompat/widget/y;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   270: astore #5
    //   272: aload_0
    //   273: getfield g : Landroid/content/Context;
    //   276: aload_2
    //   277: getstatic e/j.F2 : [I
    //   280: iload_3
    //   281: iconst_0
    //   282: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/w0;
    //   285: astore #7
    //   287: aload_0
    //   288: aload #7
    //   290: getstatic e/j.J2 : I
    //   293: bipush #-2
    //   295: invokevirtual m : (II)I
    //   298: putfield l : I
    //   301: aload #5
    //   303: aload #7
    //   305: getstatic e/j.H2 : I
    //   308: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   311: invokevirtual b : (Landroid/graphics/drawable/Drawable;)V
    //   314: aload #5
    //   316: aload #9
    //   318: getstatic e/j.I2 : I
    //   321: invokevirtual o : (I)Ljava/lang/String;
    //   324: invokevirtual i : (Ljava/lang/CharSequence;)V
    //   327: aload #7
    //   329: invokevirtual w : ()V
    //   332: aload_0
    //   333: aload #5
    //   335: putfield k : Landroidx/appcompat/widget/y$g;
    //   338: aload_0
    //   339: new androidx/appcompat/widget/y$a
    //   342: dup
    //   343: aload_0
    //   344: aload_0
    //   345: aload #5
    //   347: invokespecial <init> : (Landroidx/appcompat/widget/y;Landroid/view/View;Landroidx/appcompat/widget/y$e;)V
    //   350: putfield h : Landroidx/appcompat/widget/i0;
    //   353: goto -> 387
    //   356: new androidx/appcompat/widget/y$c
    //   359: dup
    //   360: aload_0
    //   361: invokespecial <init> : (Landroidx/appcompat/widget/y;)V
    //   364: astore #5
    //   366: aload_0
    //   367: aload #5
    //   369: putfield k : Landroidx/appcompat/widget/y$g;
    //   372: aload #5
    //   374: aload #9
    //   376: getstatic e/j.I2 : I
    //   379: invokevirtual o : (I)Ljava/lang/String;
    //   382: invokeinterface i : (Ljava/lang/CharSequence;)V
    //   387: aload #9
    //   389: getstatic e/j.G2 : I
    //   392: invokevirtual q : (I)[Ljava/lang/CharSequence;
    //   395: astore #5
    //   397: aload #5
    //   399: ifnull -> 427
    //   402: new android/widget/ArrayAdapter
    //   405: dup
    //   406: aload_1
    //   407: ldc 17367048
    //   409: aload #5
    //   411: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   414: astore_1
    //   415: aload_1
    //   416: getstatic e/g.t : I
    //   419: invokevirtual setDropDownViewResource : (I)V
    //   422: aload_0
    //   423: aload_1
    //   424: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   427: aload #9
    //   429: invokevirtual w : ()V
    //   432: aload_0
    //   433: iconst_1
    //   434: putfield j : Z
    //   437: aload_0
    //   438: getfield i : Landroid/widget/SpinnerAdapter;
    //   441: astore_1
    //   442: aload_1
    //   443: ifnull -> 456
    //   446: aload_0
    //   447: aload_1
    //   448: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   451: aload_0
    //   452: aconst_null
    //   453: putfield i : Landroid/widget/SpinnerAdapter;
    //   456: aload_0
    //   457: getfield f : Landroidx/appcompat/widget/e;
    //   460: aload_2
    //   461: iload_3
    //   462: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   465: return
    // Exception table:
    //   from	to	target	type
    //   123	135	190	java/lang/Exception
    //   123	135	186	finally
    //   147	156	181	java/lang/Exception
    //   147	156	229	finally
    //   160	169	181	java/lang/Exception
    //   160	169	229	finally
    //   199	209	229	finally
  }
  
  int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int k = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int m = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i1 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int j = Math.max(0, i - 15 - i1 - i);
    View view = null;
    i = 0;
    while (j < i1) {
      int i3 = paramSpinnerAdapter.getItemViewType(j);
      int i2 = k;
      if (i3 != k) {
        view = null;
        i2 = i3;
      } 
      view = paramSpinnerAdapter.getView(j, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(m, n);
      i = Math.max(i, view.getMeasuredWidth());
      j++;
      k = i2;
    } 
    j = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.m);
      Rect rect = this.m;
      j = i + rect.left + rect.right;
    } 
    return j;
  }
  
  void b() {
    this.k.m(getTextDirection(), getTextAlignment());
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.f;
    if (e1 != null)
      e1.b(); 
  }
  
  public int getDropDownHorizontalOffset() {
    g g1 = this.k;
    return (g1 != null) ? g1.d() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    g g1 = this.k;
    return (g1 != null) ? g1.n() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.k != null) ? this.l : super.getDropDownWidth();
  }
  
  final g getInternalPopup() {
    return this.k;
  }
  
  public Drawable getPopupBackground() {
    g g1 = this.k;
    return (g1 != null) ? g1.g() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.g;
  }
  
  public CharSequence getPrompt() {
    g g1 = this.k;
    return (g1 != null) ? g1.o() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.f;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.f;
    return (e1 != null) ? e1.d() : null;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    g g1 = this.k;
    if (g1 != null && g1.c())
      this.k.dismiss(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.k != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    f f = (f)paramParcelable;
    super.onRestoreInstanceState(f.getSuperState());
    if (f.f) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new b(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    f f = new f(super.onSaveInstanceState());
    g g1 = this.k;
    if (g1 != null && g1.c()) {
      bool = true;
    } else {
      bool = false;
    } 
    f.f = bool;
    return (Parcelable)f;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    i0 i01 = this.h;
    return (i01 != null && i01.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    g g1 = this.k;
    if (g1 != null) {
      if (!g1.c())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.j) {
      this.i = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.k != null) {
      Context context2 = this.g;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.k.p(new d(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.f;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.f;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    g g1 = this.k;
    if (g1 != null) {
      g1.k(paramInt);
      this.k.l(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    g g1 = this.k;
    if (g1 != null) {
      g1.j(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.k != null) {
      this.l = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    g g1 = this.k;
    if (g1 != null) {
      g1.b(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(g.a.b(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    g g1 = this.k;
    if (g1 != null) {
      g1.i(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.f;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.f;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  class a extends i0 {
    a(y this$0, View param1View, y.e param1e) {
      super(param1View);
    }
    
    public l.e b() {
      return this.o;
    }
    
    @SuppressLint({"SyntheticAccessor"})
    public boolean c() {
      if (!this.p.getInternalPopup().c())
        this.p.b(); 
      return true;
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(y this$0) {}
    
    public void onGlobalLayout() {
      if (!this.f.getInternalPopup().c())
        this.f.b(); 
      ViewTreeObserver viewTreeObserver = this.f.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeOnGlobalLayoutListener(this); 
    }
  }
  
  class c implements g, DialogInterface.OnClickListener {
    androidx.appcompat.app.c f;
    
    private ListAdapter g;
    
    private CharSequence h;
    
    c(y this$0) {}
    
    public void b(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public boolean c() {
      androidx.appcompat.app.c c1 = this.f;
      return (c1 != null) ? c1.isShowing() : false;
    }
    
    public int d() {
      return 0;
    }
    
    public void dismiss() {
      androidx.appcompat.app.c c1 = this.f;
      if (c1 != null) {
        c1.dismiss();
        this.f = null;
      } 
    }
    
    public Drawable g() {
      return null;
    }
    
    public void i(CharSequence param1CharSequence) {
      this.h = param1CharSequence;
    }
    
    public void j(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
    
    public void k(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void l(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public void m(int param1Int1, int param1Int2) {
      if (this.g == null)
        return; 
      androidx.appcompat.app.c.a a = new androidx.appcompat.app.c.a(this.i.getPopupContext());
      CharSequence charSequence = this.h;
      if (charSequence != null)
        a.h(charSequence); 
      androidx.appcompat.app.c c1 = a.g(this.g, this.i.getSelectedItemPosition(), this).a();
      this.f = c1;
      ListView listView = c1.r();
      listView.setTextDirection(param1Int1);
      listView.setTextAlignment(param1Int2);
      this.f.show();
    }
    
    public int n() {
      return 0;
    }
    
    public CharSequence o() {
      return this.h;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.i.setSelection(param1Int);
      if (this.i.getOnItemClickListener() != null)
        this.i.performItemClick(null, param1Int, this.g.getItemId(param1Int)); 
      dismiss();
    }
    
    public void p(ListAdapter param1ListAdapter) {
      this.g = param1ListAdapter;
    }
  }
  
  private static class d implements ListAdapter, SpinnerAdapter {
    private SpinnerAdapter f;
    
    private ListAdapter g;
    
    public d(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.f = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.g = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        ThemedSpinnerAdapter themedSpinnerAdapter;
        if (param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          themedSpinnerAdapter = (ThemedSpinnerAdapter)param1SpinnerAdapter;
          if (themedSpinnerAdapter.getDropDownViewTheme() != param1Theme) {
            themedSpinnerAdapter.setDropDownViewTheme(param1Theme);
            return;
          } 
        } else if (themedSpinnerAdapter instanceof s0) {
          s0 s0 = (s0)themedSpinnerAdapter;
          if (s0.getDropDownViewTheme() == null)
            s0.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.g;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.f;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.g;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.f;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.f;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  class e extends j0 implements g {
    private CharSequence O;
    
    ListAdapter P;
    
    private final Rect Q = new Rect();
    
    private int R;
    
    public e(y this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      D((View)this$0);
      J(true);
      O(0);
      L(new a(this, this$0));
    }
    
    void S() {
      Drawable drawable = g();
      int i = 0;
      if (drawable != null) {
        drawable.getPadding(this.S.m);
        if (d1.b((View)this.S)) {
          i = this.S.m.right;
        } else {
          i = -this.S.m.left;
        } 
      } else {
        Rect rect = this.S.m;
        rect.right = 0;
        rect.left = 0;
      } 
      int k = this.S.getPaddingLeft();
      int m = this.S.getPaddingRight();
      int n = this.S.getWidth();
      y y1 = this.S;
      int j = y1.l;
      if (j == -2) {
        int i1 = y1.a((SpinnerAdapter)this.P, g());
        j = (this.S.getContext().getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.S.m;
        int i2 = j - rect.left - rect.right;
        j = i1;
        if (i1 > i2)
          j = i2; 
        F(Math.max(j, n - k - m));
      } else if (j == -1) {
        F(n - k - m);
      } else {
        F(j);
      } 
      if (d1.b((View)this.S)) {
        i += n - m - z() - T();
      } else {
        i += k + T();
      } 
      l(i);
    }
    
    public int T() {
      return this.R;
    }
    
    boolean U(View param1View) {
      return (w.R(param1View) && param1View.getGlobalVisibleRect(this.Q));
    }
    
    public void i(CharSequence param1CharSequence) {
      this.O = param1CharSequence;
    }
    
    public void k(int param1Int) {
      this.R = param1Int;
    }
    
    public void m(int param1Int1, int param1Int2) {
      boolean bool = c();
      S();
      I(2);
      a();
      ListView listView = h();
      listView.setChoiceMode(1);
      listView.setTextDirection(param1Int1);
      listView.setTextAlignment(param1Int2);
      P(this.S.getSelectedItemPosition());
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.S.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        K(new c(this, b));
      } 
    }
    
    public CharSequence o() {
      return this.O;
    }
    
    public void p(ListAdapter param1ListAdapter) {
      super.p(param1ListAdapter);
      this.P = param1ListAdapter;
    }
    
    class a implements AdapterView.OnItemClickListener {
      a(y.e this$0, y param2y) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.g.S.setSelection(param2Int);
        if (this.g.S.getOnItemClickListener() != null) {
          y.e e1 = this.g;
          e1.S.performItemClick(param2View, param2Int, e1.P.getItemId(param2Int));
        } 
        this.g.dismiss();
      }
    }
    
    class b implements ViewTreeObserver.OnGlobalLayoutListener {
      b(y.e this$0) {}
      
      public void onGlobalLayout() {
        y.e e1 = this.f;
        if (!e1.U((View)e1.S)) {
          this.f.dismiss();
          return;
        } 
        this.f.S();
        y.e.R(this.f);
      }
    }
    
    class c implements PopupWindow.OnDismissListener {
      c(y.e this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.g.S.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.f); 
      }
    }
  }
  
  class a implements AdapterView.OnItemClickListener {
    a(y this$0, y param1y) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.g.S.setSelection(param1Int);
      if (this.g.S.getOnItemClickListener() != null) {
        y.e e1 = this.g;
        e1.S.performItemClick(param1View, param1Int, e1.P.getItemId(param1Int));
      } 
      this.g.dismiss();
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(y this$0) {}
    
    public void onGlobalLayout() {
      y.e e1 = this.f;
      if (!e1.U((View)e1.S)) {
        this.f.dismiss();
        return;
      } 
      this.f.S();
      y.e.R(this.f);
    }
  }
  
  class c implements PopupWindow.OnDismissListener {
    c(y this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.g.S.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.f); 
    }
  }
  
  static class f extends View.BaseSavedState {
    public static final Parcelable.Creator<f> CREATOR = new a();
    
    boolean f;
    
    f(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = bool;
    }
    
    f(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.f);
    }
    
    class a implements Parcelable.Creator<f> {
      public y.f a(Parcel param2Parcel) {
        return new y.f(param2Parcel);
      }
      
      public y.f[] b(int param2Int) {
        return new y.f[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<f> {
    public y.f a(Parcel param1Parcel) {
      return new y.f(param1Parcel);
    }
    
    public y.f[] b(int param1Int) {
      return new y.f[param1Int];
    }
  }
  
  static interface g {
    void b(Drawable param1Drawable);
    
    boolean c();
    
    int d();
    
    void dismiss();
    
    Drawable g();
    
    void i(CharSequence param1CharSequence);
    
    void j(int param1Int);
    
    void k(int param1Int);
    
    void l(int param1Int);
    
    void m(int param1Int1, int param1Int2);
    
    int n();
    
    CharSequence o();
    
    void p(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */