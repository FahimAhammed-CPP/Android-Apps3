package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.core.view.w;
import androidx.core.widget.i;
import e.j;
import java.lang.reflect.Method;
import l.e;

public class j0 implements e {
  private static Method L;
  
  private static Method M;
  
  private static Method N;
  
  private AdapterView.OnItemSelectedListener A;
  
  final g B = new g(this);
  
  private final f C = new f(this);
  
  private final e D = new e(this);
  
  private final c E = new c(this);
  
  private Runnable F;
  
  final Handler G;
  
  private final Rect H = new Rect();
  
  private Rect I;
  
  private boolean J;
  
  PopupWindow K;
  
  private Context f;
  
  private ListAdapter g;
  
  g0 h;
  
  private int i = -2;
  
  private int j = -2;
  
  private int k;
  
  private int l;
  
  private int m = 1002;
  
  private boolean n;
  
  private boolean o;
  
  private boolean p;
  
  private int q = 0;
  
  private boolean r = false;
  
  private boolean s = false;
  
  int t = Integer.MAX_VALUE;
  
  private View u;
  
  private int v = 0;
  
  private DataSetObserver w;
  
  private View x;
  
  private Drawable y;
  
  private AdapterView.OnItemClickListener z;
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        L = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        N = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        M = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public j0(Context paramContext) {
    this(paramContext, null, e.a.H);
  }
  
  public j0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public j0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.f = paramContext;
    this.G = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.t1, paramInt1, paramInt2);
    this.k = typedArray.getDimensionPixelOffset(j.u1, 0);
    int i = typedArray.getDimensionPixelOffset(j.v1, 0);
    this.l = i;
    if (i != 0)
      this.n = true; 
    typedArray.recycle();
    r r = new r(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.K = r;
    r.setInputMethodMode(1);
  }
  
  private void C() {
    View view = this.u;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.u); 
    } 
  }
  
  private void N(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = L;
      if (method != null)
        try {
          method.invoke(this.K, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      this.K.setIsClippedToScreen(paramBoolean);
    } 
  }
  
  private int q() {
    byte b1;
    byte b2;
    g0 g01 = this.h;
    boolean bool = true;
    if (g01 == null) {
      LinearLayout.LayoutParams layoutParams1;
      LinearLayout.LayoutParams layoutParams2;
      Context context = this.f;
      this.F = new a(this);
      g0 g03 = s(context, this.J ^ true);
      this.h = g03;
      Drawable drawable1 = this.y;
      if (drawable1 != null)
        g03.setSelector(drawable1); 
      this.h.setAdapter(this.g);
      this.h.setOnItemClickListener(this.z);
      this.h.setFocusable(true);
      this.h.setFocusableInTouchMode(true);
      this.h.setOnItemSelectedListener(new b(this));
      this.h.setOnScrollListener(this.D);
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.A;
      if (onItemSelectedListener != null)
        this.h.setOnItemSelectedListener(onItemSelectedListener); 
      g0 g02 = this.h;
      View view = this.u;
      if (view != null) {
        int k;
        StringBuilder stringBuilder;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        b1 = this.v;
        if (b1 != 0) {
          if (b1 != 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid hint position ");
            stringBuilder.append(this.v);
            Log.e("ListPopupWindow", stringBuilder.toString());
          } else {
            linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
            linearLayout.addView(view);
          } 
        } else {
          linearLayout.addView(view);
          linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
        } 
        b1 = this.j;
        if (b1 >= 0) {
          k = Integer.MIN_VALUE;
        } else {
          b1 = 0;
          k = b1;
        } 
        view.measure(View.MeasureSpec.makeMeasureSpec(b1, k), 0);
        layoutParams2 = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
      } else {
        b1 = 0;
        layoutParams1 = layoutParams2;
      } 
      this.K.setContentView((View)layoutParams1);
    } else {
      ViewGroup viewGroup = (ViewGroup)this.K.getContentView();
      View view = this.u;
      if (view != null) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        b1 = 0;
      } 
    } 
    Drawable drawable = this.K.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.H);
      Rect rect = this.H;
      int m = rect.top;
      int k = rect.bottom + m;
      b2 = k;
      if (!this.n) {
        this.l = -m;
        b2 = k;
      } 
    } else {
      this.H.setEmpty();
      b2 = 0;
    } 
    if (this.K.getInputMethodMode() != 2)
      bool = false; 
    int j = u(t(), this.l, bool);
    if (this.r || this.i == -1)
      return j + b2; 
    int i = this.j;
    if (i != -2) {
      if (i != -1) {
        i = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
      } else {
        i = (this.f.getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.H;
        i = View.MeasureSpec.makeMeasureSpec(i - rect.left + rect.right, 1073741824);
      } 
    } else {
      i = (this.f.getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.H;
      i = View.MeasureSpec.makeMeasureSpec(i - rect.left + rect.right, -2147483648);
    } 
    j = this.h.d(i, 0, -1, j - b1, -1);
    i = b1;
    if (j > 0)
      i = b1 + b2 + this.h.getPaddingTop() + this.h.getPaddingBottom(); 
    return j + i;
  }
  
  private int u(View paramView, int paramInt, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 23) {
      Method method = M;
      if (method != null)
        try {
          return ((Integer)method.invoke(this.K, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
        }  
      return this.K.getMaxAvailableHeight(paramView, paramInt);
    } 
    return this.K.getMaxAvailableHeight(paramView, paramInt, paramBoolean);
  }
  
  public boolean A() {
    return (this.K.getInputMethodMode() == 2);
  }
  
  public boolean B() {
    return this.J;
  }
  
  public void D(View paramView) {
    this.x = paramView;
  }
  
  public void E(int paramInt) {
    this.K.setAnimationStyle(paramInt);
  }
  
  public void F(int paramInt) {
    Drawable drawable = this.K.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.H);
      Rect rect = this.H;
      this.j = rect.left + rect.right + paramInt;
      return;
    } 
    Q(paramInt);
  }
  
  public void G(int paramInt) {
    this.q = paramInt;
  }
  
  public void H(Rect paramRect) {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    } 
    this.I = paramRect;
  }
  
  public void I(int paramInt) {
    this.K.setInputMethodMode(paramInt);
  }
  
  public void J(boolean paramBoolean) {
    this.J = paramBoolean;
    this.K.setFocusable(paramBoolean);
  }
  
  public void K(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.K.setOnDismissListener(paramOnDismissListener);
  }
  
  public void L(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.z = paramOnItemClickListener;
  }
  
  public void M(boolean paramBoolean) {
    this.p = true;
    this.o = paramBoolean;
  }
  
  public void O(int paramInt) {
    this.v = paramInt;
  }
  
  public void P(int paramInt) {
    g0 g01 = this.h;
    if (c() && g01 != null) {
      g01.setListSelectionHidden(false);
      g01.setSelection(paramInt);
      if (g01.getChoiceMode() != 0)
        g01.setItemChecked(paramInt, true); 
    } 
  }
  
  public void Q(int paramInt) {
    this.j = paramInt;
  }
  
  public void a() {
    int i;
    int j = q();
    boolean bool1 = A();
    i.b(this.K, this.m);
    boolean bool2 = this.K.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!w.R(t()))
        return; 
      int m = this.j;
      if (m == -1) {
        i = -1;
      } else {
        i = m;
        if (m == -2)
          i = t().getWidth(); 
      } 
      m = this.i;
      if (m == -1) {
        if (!bool1)
          j = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.K;
          if (this.j == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.K.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.K;
          if (this.j == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.K.setHeight(-1);
        } 
      } else if (m != -2) {
        j = m;
      } 
      PopupWindow popupWindow1 = this.K;
      if (this.s || this.r)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.K;
      View view = t();
      m = this.k;
      int n = this.l;
      if (i < 0)
        i = -1; 
      if (j < 0)
        j = -1; 
      popupWindow1.update(view, m, n, i, j);
      return;
    } 
    int k = this.j;
    if (k == -1) {
      i = -1;
    } else {
      i = k;
      if (k == -2)
        i = t().getWidth(); 
    } 
    k = this.i;
    if (k == -1) {
      j = -1;
    } else if (k != -2) {
      j = k;
    } 
    this.K.setWidth(i);
    this.K.setHeight(j);
    N(true);
    PopupWindow popupWindow = this.K;
    if (!this.s && !this.r) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.K.setTouchInterceptor(this.C);
    if (this.p)
      i.a(this.K, this.o); 
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = N;
      if (method != null)
        try {
          method.invoke(this.K, new Object[] { this.I });
        } catch (Exception exception) {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", exception);
        }  
    } else {
      this.K.setEpicenterBounds(this.I);
    } 
    i.c(this.K, t(), this.k, this.l, this.q);
    this.h.setSelection(-1);
    if (!this.J || this.h.isInTouchMode())
      r(); 
    if (!this.J)
      this.G.post(this.E); 
  }
  
  public void b(Drawable paramDrawable) {
    this.K.setBackgroundDrawable(paramDrawable);
  }
  
  public boolean c() {
    return this.K.isShowing();
  }
  
  public int d() {
    return this.k;
  }
  
  public void dismiss() {
    this.K.dismiss();
    C();
    this.K.setContentView(null);
    this.h = null;
    this.G.removeCallbacks(this.B);
  }
  
  public Drawable g() {
    return this.K.getBackground();
  }
  
  public ListView h() {
    return this.h;
  }
  
  public void j(int paramInt) {
    this.l = paramInt;
    this.n = true;
  }
  
  public void l(int paramInt) {
    this.k = paramInt;
  }
  
  public int n() {
    return !this.n ? 0 : this.l;
  }
  
  public void p(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.w;
    if (dataSetObserver == null) {
      this.w = new d(this);
    } else {
      ListAdapter listAdapter = this.g;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.g = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.w); 
    g0 g01 = this.h;
    if (g01 != null)
      g01.setAdapter(this.g); 
  }
  
  public void r() {
    g0 g01 = this.h;
    if (g01 != null) {
      g01.setListSelectionHidden(true);
      g01.requestLayout();
    } 
  }
  
  g0 s(Context paramContext, boolean paramBoolean) {
    return new g0(paramContext, paramBoolean);
  }
  
  public View t() {
    return this.x;
  }
  
  public Object v() {
    return !c() ? null : this.h.getSelectedItem();
  }
  
  public long w() {
    return !c() ? Long.MIN_VALUE : this.h.getSelectedItemId();
  }
  
  public int x() {
    return !c() ? -1 : this.h.getSelectedItemPosition();
  }
  
  public View y() {
    return !c() ? null : this.h.getSelectedView();
  }
  
  public int z() {
    return this.j;
  }
  
  class a implements Runnable {
    a(j0 this$0) {}
    
    public void run() {
      View view = this.f.t();
      if (view != null && view.getWindowToken() != null)
        this.f.a(); 
    }
  }
  
  class b implements AdapterView.OnItemSelectedListener {
    b(j0 this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        g0 g0 = this.f.h;
        if (g0 != null)
          g0.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  private class c implements Runnable {
    c(j0 this$0) {}
    
    public void run() {
      this.f.r();
    }
  }
  
  private class d extends DataSetObserver {
    d(j0 this$0) {}
    
    public void onChanged() {
      if (this.a.c())
        this.a.a(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  private class e implements AbsListView.OnScrollListener {
    e(j0 this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.A() && this.a.K.getContentView() != null) {
        j0 j01 = this.a;
        j01.G.removeCallbacks(j01.B);
        this.a.B.run();
      } 
    }
  }
  
  private class f implements View.OnTouchListener {
    f(j0 this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.f.K;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.f.K.getWidth() && k >= 0 && k < this.f.K.getHeight()) {
          j0 j01 = this.f;
          j01.G.postDelayed(j01.B, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        j0 j01 = this.f;
        j01.G.removeCallbacks(j01.B);
      } 
      return false;
    }
  }
  
  private class g implements Runnable {
    g(j0 this$0) {}
    
    public void run() {
      g0 g0 = this.f.h;
      if (g0 != null && w.R((View)g0) && this.f.h.getCount() > this.f.h.getChildCount()) {
        int i = this.f.h.getChildCount();
        j0 j01 = this.f;
        if (i <= j01.t) {
          j01.K.setInputMethodMode(2);
          this.f.a();
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */