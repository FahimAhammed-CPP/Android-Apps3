package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.core.view.w;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import k.c;

public class SearchView extends LinearLayoutCompat implements c {
  static final n v0;
  
  final ImageView A;
  
  final ImageView B;
  
  private final View C;
  
  private p D;
  
  private Rect E = new Rect();
  
  private Rect F = new Rect();
  
  private int[] G = new int[2];
  
  private int[] H = new int[2];
  
  private final ImageView I;
  
  private final Drawable J;
  
  private final int K;
  
  private final int L;
  
  private final Intent M;
  
  private final Intent N;
  
  private final CharSequence O;
  
  private l P;
  
  private k Q;
  
  View.OnFocusChangeListener R;
  
  private m S;
  
  private View.OnClickListener T;
  
  private boolean U;
  
  private boolean V;
  
  o0.a W;
  
  private boolean a0;
  
  private CharSequence b0;
  
  private boolean c0;
  
  private boolean d0;
  
  private int e0;
  
  private boolean f0;
  
  private CharSequence g0;
  
  private CharSequence h0;
  
  private boolean i0;
  
  private int j0;
  
  SearchableInfo k0;
  
  private Bundle l0;
  
  private final Runnable m0 = new b(this);
  
  private Runnable n0 = new c(this);
  
  private final WeakHashMap<String, Drawable.ConstantState> o0 = new WeakHashMap<String, Drawable.ConstantState>();
  
  private final View.OnClickListener p0;
  
  View.OnKeyListener q0;
  
  private final TextView.OnEditorActionListener r0;
  
  private final AdapterView.OnItemClickListener s0;
  
  private final AdapterView.OnItemSelectedListener t0;
  
  final SearchAutoComplete u;
  
  private TextWatcher u0;
  
  private final View v;
  
  private final View w;
  
  private final View x;
  
  final ImageView y;
  
  final ImageView z;
  
  static {
    n n1;
    if (Build.VERSION.SDK_INT < 29) {
      n1 = new n();
    } else {
      n1 = null;
    } 
    v0 = n1;
  }
  
  public SearchView(Context paramContext) {
    this(paramContext, null);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.L);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    f f = new f(this);
    this.p0 = f;
    this.q0 = new g(this);
    h h = new h(this);
    this.r0 = h;
    i i = new i(this);
    this.s0 = i;
    j j = new j(this);
    this.t0 = j;
    this.u0 = new a(this);
    int[] arrayOfInt = e.j.n2;
    w0 w0 = w0.v(paramContext, paramAttributeSet, arrayOfInt, paramInt, 0);
    w.m0((View)this, paramContext, arrayOfInt, paramAttributeSet, w0.r(), paramInt, 0);
    LayoutInflater.from(paramContext).inflate(w0.n(e.j.x2, e.g.r), this, true);
    SearchAutoComplete searchAutoComplete = (SearchAutoComplete)findViewById(e.f.D);
    this.u = searchAutoComplete;
    searchAutoComplete.setSearchView(this);
    this.v = findViewById(e.f.z);
    View view2 = findViewById(e.f.C);
    this.w = view2;
    View view3 = findViewById(e.f.J);
    this.x = view3;
    ImageView imageView1 = (ImageView)findViewById(e.f.x);
    this.y = imageView1;
    ImageView imageView2 = (ImageView)findViewById(e.f.A);
    this.z = imageView2;
    ImageView imageView3 = (ImageView)findViewById(e.f.y);
    this.A = imageView3;
    ImageView imageView4 = (ImageView)findViewById(e.f.E);
    this.B = imageView4;
    ImageView imageView5 = (ImageView)findViewById(e.f.B);
    this.I = imageView5;
    w.s0(view2, w0.g(e.j.y2));
    w.s0(view3, w0.g(e.j.C2));
    paramInt = e.j.B2;
    imageView1.setImageDrawable(w0.g(paramInt));
    imageView2.setImageDrawable(w0.g(e.j.v2));
    imageView3.setImageDrawable(w0.g(e.j.s2));
    imageView4.setImageDrawable(w0.g(e.j.E2));
    imageView5.setImageDrawable(w0.g(paramInt));
    this.J = w0.g(e.j.A2);
    z0.a((View)imageView1, getResources().getString(e.h.n));
    this.K = w0.n(e.j.D2, e.g.q);
    this.L = w0.n(e.j.t2, 0);
    imageView1.setOnClickListener(f);
    imageView3.setOnClickListener(f);
    imageView2.setOnClickListener(f);
    imageView4.setOnClickListener(f);
    searchAutoComplete.setOnClickListener(f);
    searchAutoComplete.addTextChangedListener(this.u0);
    searchAutoComplete.setOnEditorActionListener(h);
    searchAutoComplete.setOnItemClickListener(i);
    searchAutoComplete.setOnItemSelectedListener(j);
    searchAutoComplete.setOnKeyListener(this.q0);
    searchAutoComplete.setOnFocusChangeListener(new d(this));
    setIconifiedByDefault(w0.a(e.j.w2, true));
    paramInt = w0.f(e.j.p2, -1);
    if (paramInt != -1)
      setMaxWidth(paramInt); 
    this.O = w0.p(e.j.u2);
    this.b0 = w0.p(e.j.z2);
    paramInt = w0.k(e.j.r2, -1);
    if (paramInt != -1)
      setImeOptions(paramInt); 
    paramInt = w0.k(e.j.q2, -1);
    if (paramInt != -1)
      setInputType(paramInt); 
    setFocusable(w0.a(e.j.o2, true));
    w0.w();
    Intent intent = new Intent("android.speech.action.WEB_SEARCH");
    this.M = intent;
    intent.addFlags(268435456);
    intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
    intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
    this.N = intent;
    intent.addFlags(268435456);
    View view1 = findViewById(searchAutoComplete.getDropDownAnchor());
    this.C = view1;
    if (view1 != null)
      view1.addOnLayoutChangeListener(new e(this)); 
    k0(this.U);
    g0();
  }
  
  private Intent C(String paramString1, Uri paramUri, String paramString2, String paramString3, int paramInt, String paramString4) {
    Intent intent = new Intent(paramString1);
    intent.addFlags(268435456);
    if (paramUri != null)
      intent.setData(paramUri); 
    intent.putExtra("user_query", this.h0);
    if (paramString3 != null)
      intent.putExtra("query", paramString3); 
    if (paramString2 != null)
      intent.putExtra("intent_extra_data_key", paramString2); 
    Bundle bundle = this.l0;
    if (bundle != null)
      intent.putExtra("app_data", bundle); 
    if (paramInt != 0) {
      intent.putExtra("action_key", paramInt);
      intent.putExtra("action_msg", paramString4);
    } 
    intent.setComponent(this.k0.getSearchActivity());
    return intent;
  }
  
  private Intent D(Cursor paramCursor, int paramInt, String paramString) {
    StringBuilder stringBuilder;
    try {
      String str = q0.y(paramCursor, "suggest_intent_action");
      str1 = str;
      if (str == null)
        str1 = this.k0.getSuggestIntentAction(); 
    } catch (RuntimeException runtimeException) {
      try {
        paramInt = paramCursor.getPosition();
      } catch (RuntimeException runtimeException1) {
        paramInt = -1;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Search suggestions cursor at row ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" returned exception.");
      Log.w("SearchView", stringBuilder.toString(), runtimeException);
      return null;
    } 
    String str2 = str1;
    if (str1 == null)
      str2 = "android.intent.action.SEARCH"; 
    String str3 = q0.y((Cursor)stringBuilder, "suggest_intent_data");
    String str1 = str3;
    if (str3 == null)
      str1 = this.k0.getSuggestIntentData(); 
    str3 = str1;
    if (str1 != null) {
      String str = q0.y((Cursor)stringBuilder, "suggest_intent_data_id");
      str3 = str1;
      if (str != null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str1);
        stringBuilder1.append("/");
        stringBuilder1.append(Uri.encode(str));
        str3 = stringBuilder1.toString();
      } 
    } 
    if (str3 == null) {
      str1 = null;
      str3 = q0.y((Cursor)stringBuilder, "suggest_intent_query");
      return C(str2, (Uri)str1, q0.y((Cursor)stringBuilder, "suggest_intent_extra_data"), str3, paramInt, (String)runtimeException);
    } 
    Uri uri = Uri.parse(str3);
    str3 = q0.y((Cursor)stringBuilder, "suggest_intent_query");
    return C(str2, uri, q0.y((Cursor)stringBuilder, "suggest_intent_extra_data"), str3, paramInt, (String)runtimeException);
  }
  
  private Intent E(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str1;
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    Intent intent1 = new Intent("android.intent.action.SEARCH");
    intent1.setComponent(componentName);
    PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent1, 1107296256);
    Bundle bundle2 = new Bundle();
    Bundle bundle1 = this.l0;
    if (bundle1 != null)
      bundle2.putParcelable("app_data", (Parcelable)bundle1); 
    Intent intent2 = new Intent(paramIntent);
    int i = 1;
    Resources resources = getResources();
    if (paramSearchableInfo.getVoiceLanguageModeId() != 0) {
      str1 = resources.getString(paramSearchableInfo.getVoiceLanguageModeId());
    } else {
      str1 = "free_form";
    } 
    int j = paramSearchableInfo.getVoicePromptTextId();
    String str2 = null;
    if (j != 0) {
      String str = resources.getString(paramSearchableInfo.getVoicePromptTextId());
    } else {
      bundle1 = null;
    } 
    if (paramSearchableInfo.getVoiceLanguageId() != 0) {
      String str = resources.getString(paramSearchableInfo.getVoiceLanguageId());
    } else {
      resources = null;
    } 
    if (paramSearchableInfo.getVoiceMaxResults() != 0)
      i = paramSearchableInfo.getVoiceMaxResults(); 
    intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", str1);
    intent2.putExtra("android.speech.extra.PROMPT", (String)bundle1);
    intent2.putExtra("android.speech.extra.LANGUAGE", (String)resources);
    intent2.putExtra("android.speech.extra.MAX_RESULTS", i);
    if (componentName == null) {
      str1 = str2;
    } else {
      str1 = componentName.flattenToShortString();
    } 
    intent2.putExtra("calling_package", str1);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle2);
    return intent2;
  }
  
  private Intent F(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str;
    Intent intent = new Intent(paramIntent);
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    if (componentName == null) {
      componentName = null;
    } else {
      str = componentName.flattenToShortString();
    } 
    intent.putExtra("calling_package", str);
    return intent;
  }
  
  private void G() {
    this.u.dismissDropDown();
  }
  
  private void I(View paramView, Rect paramRect) {
    paramView.getLocationInWindow(this.G);
    getLocationInWindow(this.H);
    int[] arrayOfInt1 = this.G;
    int i = arrayOfInt1[1];
    int[] arrayOfInt2 = this.H;
    i -= arrayOfInt2[1];
    int j = arrayOfInt1[0] - arrayOfInt2[0];
    paramRect.set(j, i, paramView.getWidth() + j, paramView.getHeight() + i);
  }
  
  private CharSequence J(CharSequence paramCharSequence) {
    if (this.U) {
      if (this.J == null)
        return paramCharSequence; 
      int i = (int)(this.u.getTextSize() * 1.25D);
      this.J.setBounds(0, 0, i, i);
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
      spannableStringBuilder.setSpan(new ImageSpan(this.J), 1, 2, 33);
      spannableStringBuilder.append(paramCharSequence);
      return (CharSequence)spannableStringBuilder;
    } 
    return paramCharSequence;
  }
  
  private boolean K() {
    SearchableInfo searchableInfo = this.k0;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (searchableInfo != null) {
      bool1 = bool2;
      if (searchableInfo.getVoiceSearchEnabled()) {
        Intent intent;
        searchableInfo = null;
        if (this.k0.getVoiceSearchLaunchWebSearch()) {
          intent = this.M;
        } else if (this.k0.getVoiceSearchLaunchRecognizer()) {
          intent = this.N;
        } 
        bool1 = bool2;
        if (intent != null) {
          bool1 = bool2;
          if (getContext().getPackageManager().resolveActivity(intent, 65536) != null)
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  static boolean M(Context paramContext) {
    return ((paramContext.getResources().getConfiguration()).orientation == 2);
  }
  
  private boolean N() {
    return ((this.a0 || this.f0) && !L());
  }
  
  private void O(Intent paramIntent) {
    if (paramIntent == null)
      return; 
    try {
      getContext().startActivity(paramIntent);
      return;
    } catch (RuntimeException runtimeException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed launch activity: ");
      stringBuilder.append(paramIntent);
      Log.e("SearchView", stringBuilder.toString(), runtimeException);
      return;
    } 
  }
  
  private boolean Q(int paramInt1, int paramInt2, String paramString) {
    Cursor cursor = this.W.b();
    if (cursor != null && cursor.moveToPosition(paramInt1)) {
      O(D(cursor, paramInt2, paramString));
      return true;
    } 
    return false;
  }
  
  private void b0() {
    post(this.m0);
  }
  
  private void c0(int paramInt) {
    Editable editable = this.u.getText();
    Cursor cursor = this.W.b();
    if (cursor == null)
      return; 
    if (cursor.moveToPosition(paramInt)) {
      CharSequence charSequence = this.W.c(cursor);
      if (charSequence != null) {
        setQuery(charSequence);
        return;
      } 
      setQuery((CharSequence)editable);
      return;
    } 
    setQuery((CharSequence)editable);
  }
  
  private void e0() {
    boolean bool = TextUtils.isEmpty((CharSequence)this.u.getText());
    byte b3 = 1;
    int i = bool ^ true;
    byte b2 = 0;
    byte b1 = b3;
    if (i == 0)
      if (this.U && !this.i0) {
        b1 = b3;
      } else {
        b1 = 0;
      }  
    ImageView imageView = this.A;
    if (b1) {
      b1 = b2;
    } else {
      b1 = 8;
    } 
    imageView.setVisibility(b1);
    Drawable drawable = this.A.getDrawable();
    if (drawable != null) {
      int[] arrayOfInt;
      if (i != 0) {
        arrayOfInt = ViewGroup.ENABLED_STATE_SET;
      } else {
        arrayOfInt = ViewGroup.EMPTY_STATE_SET;
      } 
      drawable.setState(arrayOfInt);
    } 
  }
  
  private void g0() {
    CharSequence charSequence2 = getQueryHint();
    SearchAutoComplete searchAutoComplete = this.u;
    CharSequence charSequence1 = charSequence2;
    if (charSequence2 == null)
      charSequence1 = ""; 
    searchAutoComplete.setHint(J(charSequence1));
  }
  
  private int getPreferredHeight() {
    return getContext().getResources().getDimensionPixelSize(e.d.g);
  }
  
  private int getPreferredWidth() {
    return getContext().getResources().getDimensionPixelSize(e.d.h);
  }
  
  private void h0() {
    this.u.setThreshold(this.k0.getSuggestThreshold());
    this.u.setImeOptions(this.k0.getImeOptions());
    int j = this.k0.getInputType();
    boolean bool = true;
    int i = j;
    if ((j & 0xF) == 1) {
      j &= 0xFFFEFFFF;
      i = j;
      if (this.k0.getSuggestAuthority() != null)
        i = j | 0x10000 | 0x80000; 
    } 
    this.u.setInputType(i);
    o0.a a1 = this.W;
    if (a1 != null)
      a1.a(null); 
    if (this.k0.getSuggestAuthority() != null) {
      q0 q0 = new q0(getContext(), this, this.k0, this.o0);
      this.W = (o0.a)q0;
      this.u.setAdapter((ListAdapter)q0);
      q0 = (q0)this.W;
      i = bool;
      if (this.c0)
        i = 2; 
      q0.H(i);
    } 
  }
  
  private void i0() {
    byte b;
    if (N() && (this.z.getVisibility() == 0 || this.B.getVisibility() == 0)) {
      b = 0;
    } else {
      b = 8;
    } 
    this.x.setVisibility(b);
  }
  
  private void j0(boolean paramBoolean) {
    byte b;
    if (this.a0 && N() && hasFocus() && (paramBoolean || !this.f0)) {
      b = 0;
    } else {
      b = 8;
    } 
    this.z.setVisibility(b);
  }
  
  private void k0(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: putfield V : Z
    //   5: iconst_0
    //   6: istore_3
    //   7: iload_1
    //   8: ifeq -> 16
    //   11: iconst_0
    //   12: istore_2
    //   13: goto -> 19
    //   16: bipush #8
    //   18: istore_2
    //   19: aload_0
    //   20: getfield u : Landroidx/appcompat/widget/SearchView$SearchAutoComplete;
    //   23: invokevirtual getText : ()Landroid/text/Editable;
    //   26: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   29: iconst_1
    //   30: ixor
    //   31: istore #4
    //   33: aload_0
    //   34: getfield y : Landroid/widget/ImageView;
    //   37: iload_2
    //   38: invokevirtual setVisibility : (I)V
    //   41: aload_0
    //   42: iload #4
    //   44: invokespecial j0 : (Z)V
    //   47: aload_0
    //   48: getfield v : Landroid/view/View;
    //   51: astore #5
    //   53: iload_1
    //   54: ifeq -> 63
    //   57: bipush #8
    //   59: istore_2
    //   60: goto -> 65
    //   63: iconst_0
    //   64: istore_2
    //   65: aload #5
    //   67: iload_2
    //   68: invokevirtual setVisibility : (I)V
    //   71: aload_0
    //   72: getfield I : Landroid/widget/ImageView;
    //   75: invokevirtual getDrawable : ()Landroid/graphics/drawable/Drawable;
    //   78: ifnull -> 90
    //   81: iload_3
    //   82: istore_2
    //   83: aload_0
    //   84: getfield U : Z
    //   87: ifeq -> 93
    //   90: bipush #8
    //   92: istore_2
    //   93: aload_0
    //   94: getfield I : Landroid/widget/ImageView;
    //   97: iload_2
    //   98: invokevirtual setVisibility : (I)V
    //   101: aload_0
    //   102: invokespecial e0 : ()V
    //   105: aload_0
    //   106: iload #4
    //   108: iconst_1
    //   109: ixor
    //   110: invokespecial l0 : (Z)V
    //   113: aload_0
    //   114: invokespecial i0 : ()V
    //   117: return
  }
  
  private void l0(boolean paramBoolean) {
    boolean bool = this.f0;
    byte b2 = 8;
    byte b1 = b2;
    if (bool) {
      b1 = b2;
      if (!L()) {
        b1 = b2;
        if (paramBoolean) {
          this.z.setVisibility(8);
          b1 = 0;
        } 
      } 
    } 
    this.B.setVisibility(b1);
  }
  
  private void setQuery(CharSequence paramCharSequence) {
    int i;
    this.u.setText(paramCharSequence);
    SearchAutoComplete searchAutoComplete = this.u;
    if (TextUtils.isEmpty(paramCharSequence)) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    searchAutoComplete.setSelection(i);
  }
  
  void B() {
    if (this.C.getWidth() > 1) {
      byte b;
      Resources resources = getContext().getResources();
      int j = this.w.getPaddingLeft();
      Rect rect = new Rect();
      boolean bool = d1.b((View)this);
      if (this.U) {
        b = resources.getDimensionPixelSize(e.d.e) + resources.getDimensionPixelSize(e.d.f);
      } else {
        b = 0;
      } 
      this.u.getDropDownBackground().getPadding(rect);
      if (bool) {
        i = -rect.left;
      } else {
        i = j - rect.left + b;
      } 
      this.u.setDropDownHorizontalOffset(i);
      int i = this.C.getWidth();
      int i1 = rect.left;
      int i2 = rect.right;
      this.u.setDropDownWidth(i + i1 + i2 + b - j);
    } 
  }
  
  void H() {
    if (Build.VERSION.SDK_INT >= 29) {
      this.u.refreshAutoCompleteResults();
      return;
    } 
    n n1 = v0;
    n1.b(this.u);
    n1.a(this.u);
  }
  
  public boolean L() {
    return this.V;
  }
  
  void P(int paramInt, String paramString1, String paramString2) {
    Intent intent = C("android.intent.action.SEARCH", null, null, paramString2, paramInt, paramString1);
    getContext().startActivity(intent);
  }
  
  void R() {
    if (TextUtils.isEmpty((CharSequence)this.u.getText())) {
      if (this.U) {
        k k1 = this.Q;
        if (k1 == null || !k1.a()) {
          clearFocus();
          k0(true);
          return;
        } 
      } 
    } else {
      this.u.setText("");
      this.u.requestFocus();
      this.u.setImeVisibility(true);
    } 
  }
  
  boolean S(int paramInt1, int paramInt2, String paramString) {
    m m1 = this.S;
    if (m1 == null || !m1.b(paramInt1)) {
      Q(paramInt1, 0, null);
      this.u.setImeVisibility(false);
      G();
      return true;
    } 
    return false;
  }
  
  boolean T(int paramInt) {
    m m1 = this.S;
    if (m1 == null || !m1.a(paramInt)) {
      c0(paramInt);
      return true;
    } 
    return false;
  }
  
  void U(CharSequence paramCharSequence) {
    setQuery(paramCharSequence);
  }
  
  void V() {
    k0(false);
    this.u.requestFocus();
    this.u.setImeVisibility(true);
    View.OnClickListener onClickListener = this.T;
    if (onClickListener != null)
      onClickListener.onClick((View)this); 
  }
  
  void W() {
    Editable editable = this.u.getText();
    if (editable != null && TextUtils.getTrimmedLength((CharSequence)editable) > 0) {
      l l1 = this.P;
      if (l1 == null || !l1.b(editable.toString())) {
        if (this.k0 != null)
          P(0, null, editable.toString()); 
        this.u.setImeVisibility(false);
        G();
      } 
    } 
  }
  
  boolean X(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (this.k0 == null)
      return false; 
    if (this.W == null)
      return false; 
    if (paramKeyEvent.getAction() == 0 && paramKeyEvent.hasNoModifiers()) {
      if (paramInt == 66 || paramInt == 84 || paramInt == 61)
        return S(this.u.getListSelection(), 0, null); 
      if (paramInt == 21 || paramInt == 22) {
        if (paramInt == 21) {
          paramInt = 0;
        } else {
          paramInt = this.u.length();
        } 
        this.u.setSelection(paramInt);
        this.u.setListSelection(0);
        this.u.clearListSelection();
        this.u.b();
        return true;
      } 
      if (paramInt == 19) {
        this.u.getListSelection();
        return false;
      } 
    } 
    return false;
  }
  
  void Y(CharSequence paramCharSequence) {
    Editable editable = this.u.getText();
    this.h0 = (CharSequence)editable;
    int i = TextUtils.isEmpty((CharSequence)editable) ^ true;
    j0(i);
    l0(i ^ 0x1);
    e0();
    i0();
    if (this.P != null && !TextUtils.equals(paramCharSequence, this.g0))
      this.P.a(paramCharSequence.toString()); 
    this.g0 = paramCharSequence.toString();
  }
  
  void Z() {
    k0(L());
    b0();
    if (this.u.hasFocus())
      H(); 
  }
  
  void a0() {
    SearchableInfo searchableInfo = this.k0;
    if (searchableInfo == null)
      return; 
    try {
      Intent intent;
      if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
        intent = F(this.M, searchableInfo);
        getContext().startActivity(intent);
        return;
      } 
      if (intent.getVoiceSearchLaunchRecognizer()) {
        intent = E(this.N, (SearchableInfo)intent);
        getContext().startActivity(intent);
        return;
      } 
    } catch (ActivityNotFoundException activityNotFoundException) {
      Log.w("SearchView", "Could not find voice search activity");
    } 
  }
  
  public void c() {
    if (this.i0)
      return; 
    this.i0 = true;
    int i = this.u.getImeOptions();
    this.j0 = i;
    this.u.setImeOptions(i | 0x2000000);
    this.u.setText("");
    setIconified(false);
  }
  
  public void clearFocus() {
    this.d0 = true;
    super.clearFocus();
    this.u.clearFocus();
    this.u.setImeVisibility(false);
    this.d0 = false;
  }
  
  public void d() {
    d0("", false);
    clearFocus();
    k0(true);
    this.u.setImeOptions(this.j0);
    this.i0 = false;
  }
  
  public void d0(CharSequence paramCharSequence, boolean paramBoolean) {
    this.u.setText(paramCharSequence);
    if (paramCharSequence != null) {
      SearchAutoComplete searchAutoComplete = this.u;
      searchAutoComplete.setSelection(searchAutoComplete.length());
      this.h0 = paramCharSequence;
    } 
    if (paramBoolean && !TextUtils.isEmpty(paramCharSequence))
      W(); 
  }
  
  void f0() {
    int[] arrayOfInt;
    if (this.u.hasFocus()) {
      arrayOfInt = ViewGroup.FOCUSED_STATE_SET;
    } else {
      arrayOfInt = ViewGroup.EMPTY_STATE_SET;
    } 
    Drawable drawable = this.w.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    drawable = this.x.getBackground();
    if (drawable != null)
      drawable.setState(arrayOfInt); 
    invalidate();
  }
  
  public int getImeOptions() {
    return this.u.getImeOptions();
  }
  
  public int getInputType() {
    return this.u.getInputType();
  }
  
  public int getMaxWidth() {
    return this.e0;
  }
  
  public CharSequence getQuery() {
    return (CharSequence)this.u.getText();
  }
  
  public CharSequence getQueryHint() {
    CharSequence charSequence = this.b0;
    if (charSequence != null)
      return charSequence; 
    SearchableInfo searchableInfo = this.k0;
    return (searchableInfo != null && searchableInfo.getHintId() != 0) ? getContext().getText(this.k0.getHintId()) : this.O;
  }
  
  int getSuggestionCommitIconResId() {
    return this.L;
  }
  
  int getSuggestionRowLayout() {
    return this.K;
  }
  
  public o0.a getSuggestionsAdapter() {
    return this.W;
  }
  
  protected void onDetachedFromWindow() {
    removeCallbacks(this.m0);
    post(this.n0);
    super.onDetachedFromWindow();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramBoolean) {
      I((View)this.u, this.E);
      Rect rect1 = this.F;
      Rect rect2 = this.E;
      rect1.set(rect2.left, 0, rect2.right, paramInt4 - paramInt2);
      p p1 = this.D;
      if (p1 == null) {
        p1 = new p(this.F, this.E, (View)this.u);
        this.D = p1;
        setTouchDelegate(p1);
        return;
      } 
      p1.a(this.F, this.E);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (L()) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int j = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getSize(paramInt1);
    if (j != Integer.MIN_VALUE) {
      if (j != 0) {
        if (j != 1073741824) {
          paramInt1 = i;
        } else {
          j = this.e0;
          paramInt1 = i;
          if (j > 0)
            paramInt1 = Math.min(j, i); 
        } 
      } else {
        paramInt1 = this.e0;
        if (paramInt1 <= 0)
          paramInt1 = getPreferredWidth(); 
      } 
    } else {
      paramInt1 = this.e0;
      if (paramInt1 > 0) {
        paramInt1 = Math.min(paramInt1, i);
      } else {
        paramInt1 = Math.min(getPreferredWidth(), i);
      } 
    } 
    i = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != Integer.MIN_VALUE) {
      if (i == 0)
        paramInt2 = getPreferredHeight(); 
    } else {
      paramInt2 = Math.min(getPreferredHeight(), paramInt2);
    } 
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824));
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof o)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    o o = (o)paramParcelable;
    super.onRestoreInstanceState(o.a());
    k0(o.h);
    requestLayout();
  }
  
  protected Parcelable onSaveInstanceState() {
    o o = new o(super.onSaveInstanceState());
    o.h = L();
    return (Parcelable)o;
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    b0();
  }
  
  public boolean requestFocus(int paramInt, Rect paramRect) {
    if (this.d0)
      return false; 
    if (!isFocusable())
      return false; 
    if (!L()) {
      boolean bool = this.u.requestFocus(paramInt, paramRect);
      if (bool)
        k0(false); 
      return bool;
    } 
    return super.requestFocus(paramInt, paramRect);
  }
  
  public void setAppSearchData(Bundle paramBundle) {
    this.l0 = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean) {
    if (paramBoolean) {
      R();
      return;
    } 
    V();
  }
  
  public void setIconifiedByDefault(boolean paramBoolean) {
    if (this.U == paramBoolean)
      return; 
    this.U = paramBoolean;
    k0(paramBoolean);
    g0();
  }
  
  public void setImeOptions(int paramInt) {
    this.u.setImeOptions(paramInt);
  }
  
  public void setInputType(int paramInt) {
    this.u.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt) {
    this.e0 = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(k paramk) {
    this.Q = paramk;
  }
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener) {
    this.R = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(l paraml) {
    this.P = paraml;
  }
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener) {
    this.T = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(m paramm) {
    this.S = paramm;
  }
  
  public void setQueryHint(CharSequence paramCharSequence) {
    this.b0 = paramCharSequence;
    g0();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean) {
    this.c0 = paramBoolean;
    o0.a a1 = this.W;
    if (a1 instanceof q0) {
      boolean bool;
      q0 q0 = (q0)a1;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = true;
      } 
      q0.H(bool);
    } 
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo) {
    this.k0 = paramSearchableInfo;
    if (paramSearchableInfo != null) {
      h0();
      g0();
    } 
    boolean bool = K();
    this.f0 = bool;
    if (bool)
      this.u.setPrivateImeOptions("nm"); 
    k0(L());
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean) {
    this.a0 = paramBoolean;
    k0(L());
  }
  
  public void setSuggestionsAdapter(o0.a parama) {
    this.W = parama;
    this.u.setAdapter((ListAdapter)parama);
  }
  
  public static class SearchAutoComplete extends d {
    private int j = getThreshold();
    
    private SearchView k;
    
    private boolean l;
    
    final Runnable m = new a(this);
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet) {
      this(param1Context, param1AttributeSet, e.a.p);
    }
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
    }
    
    private int getSearchViewTextMinWidthDp() {
      Configuration configuration = getResources().getConfiguration();
      int i = configuration.screenWidthDp;
      int j = configuration.screenHeightDp;
      return (i >= 960 && j >= 720 && configuration.orientation == 2) ? 256 : ((i >= 600 || (i >= 640 && j >= 480)) ? 192 : 160);
    }
    
    void b() {
      if (Build.VERSION.SDK_INT >= 29) {
        setInputMethodMode(1);
        if (enoughToFilter()) {
          showDropDown();
          return;
        } 
      } else {
        SearchView.v0.c(this);
      } 
    }
    
    boolean c() {
      return (TextUtils.getTrimmedLength((CharSequence)getText()) == 0);
    }
    
    void d() {
      if (this.l) {
        ((InputMethodManager)getContext().getSystemService("input_method")).showSoftInput((View)this, 0);
        this.l = false;
      } 
    }
    
    public boolean enoughToFilter() {
      return (this.j <= 0 || super.enoughToFilter());
    }
    
    public InputConnection onCreateInputConnection(EditorInfo param1EditorInfo) {
      InputConnection inputConnection = super.onCreateInputConnection(param1EditorInfo);
      if (this.l) {
        removeCallbacks(this.m);
        post(this.m);
      } 
      return inputConnection;
    }
    
    protected void onFinishInflate() {
      super.onFinishInflate();
      DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
      setMinWidth((int)TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), displayMetrics));
    }
    
    protected void onFocusChanged(boolean param1Boolean, int param1Int, Rect param1Rect) {
      super.onFocusChanged(param1Boolean, param1Int, param1Rect);
      this.k.Z();
    }
    
    public boolean onKeyPreIme(int param1Int, KeyEvent param1KeyEvent) {
      if (param1Int == 4) {
        if (param1KeyEvent.getAction() == 0 && param1KeyEvent.getRepeatCount() == 0) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.startTracking(param1KeyEvent, this); 
          return true;
        } 
        if (param1KeyEvent.getAction() == 1) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.handleUpEvent(param1KeyEvent); 
          if (param1KeyEvent.isTracking() && !param1KeyEvent.isCanceled()) {
            this.k.clearFocus();
            setImeVisibility(false);
            return true;
          } 
        } 
      } 
      return super.onKeyPreIme(param1Int, param1KeyEvent);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      super.onWindowFocusChanged(param1Boolean);
      if (param1Boolean && this.k.hasFocus() && getVisibility() == 0) {
        this.l = true;
        if (SearchView.M(getContext()))
          b(); 
      } 
    }
    
    public void performCompletion() {}
    
    protected void replaceText(CharSequence param1CharSequence) {}
    
    void setImeVisibility(boolean param1Boolean) {
      InputMethodManager inputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
      if (!param1Boolean) {
        this.l = false;
        removeCallbacks(this.m);
        inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        return;
      } 
      if (inputMethodManager.isActive((View)this)) {
        this.l = false;
        removeCallbacks(this.m);
        inputMethodManager.showSoftInput((View)this, 0);
        return;
      } 
      this.l = true;
    }
    
    void setSearchView(SearchView param1SearchView) {
      this.k = param1SearchView;
    }
    
    public void setThreshold(int param1Int) {
      super.setThreshold(param1Int);
      this.j = param1Int;
    }
    
    class a implements Runnable {
      a(SearchView.SearchAutoComplete this$0) {}
      
      public void run() {
        this.f.d();
      }
    }
  }
  
  class a implements Runnable {
    a(SearchView this$0) {}
    
    public void run() {
      this.f.d();
    }
  }
  
  class a implements TextWatcher {
    a(SearchView this$0) {}
    
    public void afterTextChanged(Editable param1Editable) {}
    
    public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
      this.f.Y(param1CharSequence);
    }
  }
  
  class b implements Runnable {
    b(SearchView this$0) {}
    
    public void run() {
      this.f.f0();
    }
  }
  
  class c implements Runnable {
    c(SearchView this$0) {}
    
    public void run() {
      o0.a a = this.f.W;
      if (a instanceof q0)
        a.a(null); 
    }
  }
  
  class d implements View.OnFocusChangeListener {
    d(SearchView this$0) {}
    
    public void onFocusChange(View param1View, boolean param1Boolean) {
      SearchView searchView = this.a;
      View.OnFocusChangeListener onFocusChangeListener = searchView.R;
      if (onFocusChangeListener != null)
        onFocusChangeListener.onFocusChange((View)searchView, param1Boolean); 
    }
  }
  
  class e implements View.OnLayoutChangeListener {
    e(SearchView this$0) {}
    
    public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      this.a.B();
    }
  }
  
  class f implements View.OnClickListener {
    f(SearchView this$0) {}
    
    public void onClick(View param1View) {
      SearchView searchView = this.f;
      if (param1View == searchView.y) {
        searchView.V();
        return;
      } 
      if (param1View == searchView.A) {
        searchView.R();
        return;
      } 
      if (param1View == searchView.z) {
        searchView.W();
        return;
      } 
      if (param1View == searchView.B) {
        searchView.a0();
        return;
      } 
      if (param1View == searchView.u)
        searchView.H(); 
    }
  }
  
  class g implements View.OnKeyListener {
    g(SearchView this$0) {}
    
    public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
      SearchView searchView = this.f;
      if (searchView.k0 == null)
        return false; 
      if (searchView.u.isPopupShowing() && this.f.u.getListSelection() != -1)
        return this.f.X(param1View, param1Int, param1KeyEvent); 
      if (!this.f.u.c() && param1KeyEvent.hasNoModifiers() && param1KeyEvent.getAction() == 1 && param1Int == 66) {
        param1View.cancelLongPress();
        SearchView searchView1 = this.f;
        searchView1.P(0, null, searchView1.u.getText().toString());
        return true;
      } 
      return false;
    }
  }
  
  class h implements TextView.OnEditorActionListener {
    h(SearchView this$0) {}
    
    public boolean onEditorAction(TextView param1TextView, int param1Int, KeyEvent param1KeyEvent) {
      this.a.W();
      return true;
    }
  }
  
  class i implements AdapterView.OnItemClickListener {
    i(SearchView this$0) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.f.S(param1Int, 0, null);
    }
  }
  
  class j implements AdapterView.OnItemSelectedListener {
    j(SearchView this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.f.T(param1Int);
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  public static interface k {
    boolean a();
  }
  
  public static interface l {
    boolean a(String param1String);
    
    boolean b(String param1String);
  }
  
  public static interface m {
    boolean a(int param1Int);
    
    boolean b(int param1Int);
  }
  
  private static class n {
    private Method a = null;
    
    private Method b = null;
    
    private Method c = null;
    
    @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
    n() {
      d();
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
        this.a = method;
        method.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        Method method = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
        this.b = method;
        method.setAccessible(true);
        try {
          method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException) {}
      } catch (NoSuchMethodException noSuchMethodException) {
        try {
          Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
          this.c = method;
          method.setAccessible(true);
          return;
        } catch (NoSuchMethodException noSuchMethodException1) {}
      } 
    }
    
    private static void d() {
      if (Build.VERSION.SDK_INT < 29)
        return; 
      throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
    }
    
    void a(AutoCompleteTextView param1AutoCompleteTextView) {
      d();
      Method method = this.b;
      if (method != null)
        try {
          method.invoke(param1AutoCompleteTextView, new Object[0]);
          return;
        } catch (Exception exception) {
          return;
        }  
    }
    
    void b(AutoCompleteTextView param1AutoCompleteTextView) {
      d();
      Method method = this.a;
      if (method != null)
        try {
          method.invoke(param1AutoCompleteTextView, new Object[0]);
          return;
        } catch (Exception exception) {
          return;
        }  
    }
    
    void c(AutoCompleteTextView param1AutoCompleteTextView) {
      d();
      Method method = this.c;
      if (method != null)
        try {
          method.invoke(param1AutoCompleteTextView, new Object[] { Boolean.TRUE });
          return;
        } catch (Exception exception) {
          return;
        }  
    }
  }
  
  static class o extends p0.a {
    public static final Parcelable.Creator<o> CREATOR = (Parcelable.Creator<o>)new a();
    
    boolean h;
    
    public o(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.h = ((Boolean)param1Parcel.readValue(null)).booleanValue();
    }
    
    o(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SearchView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" isIconified=");
      stringBuilder.append(this.h);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeValue(Boolean.valueOf(this.h));
    }
    
    class a implements Parcelable.ClassLoaderCreator<o> {
      public SearchView.o a(Parcel param2Parcel) {
        return new SearchView.o(param2Parcel, null);
      }
      
      public SearchView.o b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new SearchView.o(param2Parcel, param2ClassLoader);
      }
      
      public SearchView.o[] c(int param2Int) {
        return new SearchView.o[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator<o> {
    public SearchView.o a(Parcel param1Parcel) {
      return new SearchView.o(param1Parcel, null);
    }
    
    public SearchView.o b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new SearchView.o(param1Parcel, param1ClassLoader);
    }
    
    public SearchView.o[] c(int param1Int) {
      return new SearchView.o[param1Int];
    }
  }
  
  private static class p extends TouchDelegate {
    private final View a;
    
    private final Rect b;
    
    private final Rect c;
    
    private final Rect d;
    
    private final int e;
    
    private boolean f;
    
    public p(Rect param1Rect1, Rect param1Rect2, View param1View) {
      super(param1Rect1, param1View);
      this.e = ViewConfiguration.get(param1View.getContext()).getScaledTouchSlop();
      this.b = new Rect();
      this.d = new Rect();
      this.c = new Rect();
      a(param1Rect1, param1Rect2);
      this.a = param1View;
    }
    
    public void a(Rect param1Rect1, Rect param1Rect2) {
      this.b.set(param1Rect1);
      this.d.set(param1Rect1);
      param1Rect1 = this.d;
      int i = this.e;
      param1Rect1.inset(-i, -i);
      this.c.set(param1Rect2);
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getX : ()F
      //   4: f2i
      //   5: istore_3
      //   6: aload_1
      //   7: invokevirtual getY : ()F
      //   10: f2i
      //   11: istore #4
      //   13: aload_1
      //   14: invokevirtual getAction : ()I
      //   17: istore_2
      //   18: iconst_1
      //   19: istore #5
      //   21: iconst_0
      //   22: istore #7
      //   24: iload_2
      //   25: ifeq -> 106
      //   28: iload_2
      //   29: iconst_1
      //   30: if_icmpeq -> 60
      //   33: iload_2
      //   34: iconst_2
      //   35: if_icmpeq -> 60
      //   38: iload_2
      //   39: iconst_3
      //   40: if_icmpeq -> 46
      //   43: goto -> 129
      //   46: aload_0
      //   47: getfield f : Z
      //   50: istore #5
      //   52: aload_0
      //   53: iconst_0
      //   54: putfield f : Z
      //   57: goto -> 101
      //   60: aload_0
      //   61: getfield f : Z
      //   64: istore #6
      //   66: iload #6
      //   68: istore #5
      //   70: iload #6
      //   72: ifeq -> 101
      //   75: iload #6
      //   77: istore #5
      //   79: aload_0
      //   80: getfield d : Landroid/graphics/Rect;
      //   83: iload_3
      //   84: iload #4
      //   86: invokevirtual contains : (II)Z
      //   89: ifne -> 101
      //   92: iload #6
      //   94: istore #5
      //   96: iconst_0
      //   97: istore_2
      //   98: goto -> 134
      //   101: iconst_1
      //   102: istore_2
      //   103: goto -> 134
      //   106: aload_0
      //   107: getfield b : Landroid/graphics/Rect;
      //   110: iload_3
      //   111: iload #4
      //   113: invokevirtual contains : (II)Z
      //   116: ifeq -> 129
      //   119: aload_0
      //   120: iconst_1
      //   121: putfield f : Z
      //   124: iconst_1
      //   125: istore_2
      //   126: goto -> 134
      //   129: iconst_1
      //   130: istore_2
      //   131: iconst_0
      //   132: istore #5
      //   134: iload #7
      //   136: istore #6
      //   138: iload #5
      //   140: ifeq -> 224
      //   143: iload_2
      //   144: ifeq -> 187
      //   147: aload_0
      //   148: getfield c : Landroid/graphics/Rect;
      //   151: iload_3
      //   152: iload #4
      //   154: invokevirtual contains : (II)Z
      //   157: ifne -> 187
      //   160: aload_1
      //   161: aload_0
      //   162: getfield a : Landroid/view/View;
      //   165: invokevirtual getWidth : ()I
      //   168: iconst_2
      //   169: idiv
      //   170: i2f
      //   171: aload_0
      //   172: getfield a : Landroid/view/View;
      //   175: invokevirtual getHeight : ()I
      //   178: iconst_2
      //   179: idiv
      //   180: i2f
      //   181: invokevirtual setLocation : (FF)V
      //   184: goto -> 214
      //   187: aload_0
      //   188: getfield c : Landroid/graphics/Rect;
      //   191: astore #8
      //   193: aload_1
      //   194: iload_3
      //   195: aload #8
      //   197: getfield left : I
      //   200: isub
      //   201: i2f
      //   202: iload #4
      //   204: aload #8
      //   206: getfield top : I
      //   209: isub
      //   210: i2f
      //   211: invokevirtual setLocation : (FF)V
      //   214: aload_0
      //   215: getfield a : Landroid/view/View;
      //   218: aload_1
      //   219: invokevirtual dispatchTouchEvent : (Landroid/view/MotionEvent;)Z
      //   222: istore #6
      //   224: iload #6
      //   226: ireturn
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */