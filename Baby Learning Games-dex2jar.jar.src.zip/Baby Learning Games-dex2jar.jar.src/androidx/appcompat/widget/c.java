package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.a;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.k;
import androidx.appcompat.view.menu.m;
import androidx.core.view.b;
import java.util.ArrayList;

class c extends a implements b.a {
  private boolean A;
  
  private int B;
  
  private final SparseBooleanArray C = new SparseBooleanArray();
  
  e D;
  
  a E;
  
  c F;
  
  private b G;
  
  final f H = new f(this);
  
  int I;
  
  d p;
  
  private Drawable q;
  
  private boolean r;
  
  private boolean s;
  
  private boolean t;
  
  private int u;
  
  private int v;
  
  private int w;
  
  private boolean x;
  
  private boolean y;
  
  private boolean z;
  
  public c(Context paramContext) {
    super(paramContext, e.g.c, e.g.b);
  }
  
  private View B(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.n;
    if (viewGroup == null)
      return null; 
    int j = viewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = viewGroup.getChildAt(i);
      if (view instanceof k.a && ((k.a)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public boolean A() {
    return D() | E();
  }
  
  public Drawable C() {
    d d1 = this.p;
    return (d1 != null) ? d1.getDrawable() : (this.r ? this.q : null);
  }
  
  public boolean D() {
    c c1 = this.F;
    if (c1 != null) {
      k k = this.n;
      if (k != null) {
        ((View)k).removeCallbacks(c1);
        this.F = null;
        return true;
      } 
    } 
    e e1 = this.D;
    if (e1 != null) {
      e1.b();
      return true;
    } 
    return false;
  }
  
  public boolean E() {
    a a1 = this.E;
    if (a1 != null) {
      a1.b();
      return true;
    } 
    return false;
  }
  
  public boolean F() {
    return (this.F != null || G());
  }
  
  public boolean G() {
    e e1 = this.D;
    return (e1 != null && e1.d());
  }
  
  public void H(Configuration paramConfiguration) {
    if (!this.x)
      this.w = k.a.b(this.g).d(); 
    androidx.appcompat.view.menu.e e1 = this.h;
    if (e1 != null)
      e1.M(true); 
  }
  
  public void I(boolean paramBoolean) {
    this.A = paramBoolean;
  }
  
  public void J(ActionMenuView paramActionMenuView) {
    this.n = paramActionMenuView;
    paramActionMenuView.b(this.h);
  }
  
  public void K(Drawable paramDrawable) {
    d d1 = this.p;
    if (d1 != null) {
      d1.setImageDrawable(paramDrawable);
      return;
    } 
    this.r = true;
    this.q = paramDrawable;
  }
  
  public void L(boolean paramBoolean) {
    this.s = paramBoolean;
    this.t = true;
  }
  
  public boolean M() {
    if (this.s && !G()) {
      androidx.appcompat.view.menu.e e1 = this.h;
      if (e1 != null && this.n != null && this.F == null && !e1.B().isEmpty()) {
        c c1 = new c(this, new e(this, this.g, this.h, (View)this.p, true));
        this.F = c1;
        ((View)this.n).post(c1);
        return true;
      } 
    } 
    return false;
  }
  
  public void b(androidx.appcompat.view.menu.e parame, boolean paramBoolean) {
    A();
    super.b(parame, paramBoolean);
  }
  
  public void c(androidx.appcompat.view.menu.g paramg, k.a parama) {
    parama.g(paramg, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.n;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)parama;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.G == null)
      this.G = new b(this); 
    actionMenuItemView.setPopupCallback(this.G);
  }
  
  public void d(Context paramContext, androidx.appcompat.view.menu.e parame) {
    super.d(paramContext, parame);
    Resources resources = paramContext.getResources();
    k.a a1 = k.a.b(paramContext);
    if (!this.t)
      this.s = a1.h(); 
    if (!this.z)
      this.u = a1.c(); 
    if (!this.x)
      this.w = a1.d(); 
    int i = this.u;
    if (this.s) {
      if (this.p == null) {
        d d1 = new d(this, this.f);
        this.p = d1;
        if (this.r) {
          d1.setImageDrawable(this.q);
          this.q = null;
          this.r = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.p.measure(j, j);
      } 
      i -= this.p.getMeasuredWidth();
    } else {
      this.p = null;
    } 
    this.v = i;
    this.B = (int)((resources.getDisplayMetrics()).density * 56.0F);
  }
  
  public void e(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g))
      return; 
    int i = ((g)paramParcelable).f;
    if (i > 0) {
      MenuItem menuItem = this.h.findItem(i);
      if (menuItem != null)
        f((m)menuItem.getSubMenu()); 
    } 
  }
  
  public boolean f(m paramm) {
    boolean bool = paramm.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    m m1;
    for (m1 = paramm; m1.i0() != this.h; m1 = (m)m1.i0());
    View view = B(m1.getItem());
    if (view == null)
      return false; 
    this.I = paramm.getItem().getItemId();
    int j = paramm.size();
    int i = 0;
    while (true) {
      bool = bool1;
      if (i < j) {
        MenuItem menuItem = paramm.getItem(i);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    a a1 = new a(this, this.g, paramm, view);
    this.E = a1;
    a1.g(bool);
    this.E.k();
    super.f(paramm);
    return true;
  }
  
  public void g(boolean paramBoolean) {
    super.g(paramBoolean);
    ((View)this.n).requestLayout();
    androidx.appcompat.view.menu.e<androidx.appcompat.view.menu.g> e1 = this.h;
    byte b1 = 0;
    if (e1 != null) {
      ArrayList<androidx.appcompat.view.menu.g> arrayList = e1.u();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        b b2 = ((androidx.appcompat.view.menu.g)arrayList.get(j)).b();
        if (b2 != null)
          b2.i(this); 
      } 
    } 
    e1 = this.h;
    if (e1 != null) {
      ArrayList arrayList = e1.B();
    } else {
      e1 = null;
    } 
    int i = b1;
    if (this.s) {
      i = b1;
      if (e1 != null) {
        int j = e1.size();
        if (j == 1) {
          i = ((androidx.appcompat.view.menu.g)e1.get(0)).isActionViewExpanded() ^ true;
        } else {
          i = b1;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.p == null)
        this.p = new d(this, this.f); 
      ViewGroup viewGroup = (ViewGroup)this.p.getParent();
      if (viewGroup != this.n) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.p); 
        viewGroup = (ActionMenuView)this.n;
        viewGroup.addView((View)this.p, (ViewGroup.LayoutParams)viewGroup.F());
      } 
    } else {
      d d1 = this.p;
      if (d1 != null) {
        ViewParent viewParent = d1.getParent();
        k k = this.n;
        if (viewParent == k)
          ((ViewGroup)k).removeView((View)this.p); 
      } 
    } 
    ((ActionMenuView)this.n).setOverflowReserved(this.s);
  }
  
  public boolean i() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge Z and I\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public Parcelable j() {
    g g = new g();
    g.f = this.I;
    return g;
  }
  
  public boolean n(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.p) ? false : super.n(paramViewGroup, paramInt);
  }
  
  public View p(androidx.appcompat.view.menu.g paramg, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramg.getActionView();
    if (view == null || paramg.j())
      view = super.p(paramg, paramView, paramViewGroup); 
    if (paramg.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.E(layoutParams)); 
    return view;
  }
  
  public k q(ViewGroup paramViewGroup) {
    k k2 = this.n;
    k k1 = super.q(paramViewGroup);
    if (k2 != k1)
      ((ActionMenuView)k1).setPresenter(this); 
    return k1;
  }
  
  public boolean s(int paramInt, androidx.appcompat.view.menu.g paramg) {
    return paramg.l();
  }
  
  private class a extends i {
    public a(c this$0, Context param1Context, m param1m, View param1View) {
      super(param1Context, (androidx.appcompat.view.menu.e)param1m, param1View, false, e.a.l);
      if (!((androidx.appcompat.view.menu.g)param1m.getItem()).l()) {
        View view;
        c.d d2 = this$0.p;
        c.d d1 = d2;
        if (d2 == null)
          view = (View)c.v(this$0); 
        f(view);
      } 
      j(this$0.H);
    }
    
    protected void e() {
      c c1 = this.m;
      c1.E = null;
      c1.I = 0;
      super.e();
    }
  }
  
  private class b extends ActionMenuItemView.b {
    b(c this$0) {}
    
    public l.e a() {
      c.a a = this.a.E;
      return (l.e)((a != null) ? a.c() : null);
    }
  }
  
  private class c implements Runnable {
    private c.e f;
    
    public c(c this$0, c.e param1e) {
      this.f = param1e;
    }
    
    public void run() {
      if (c.x(this.g) != null)
        c.y(this.g).d(); 
      View view = (View)c.z(this.g);
      if (view != null && view.getWindowToken() != null && this.f.m())
        this.g.D = this.f; 
      this.g.F = null;
    }
  }
  
  private class d extends AppCompatImageView implements ActionMenuView.a {
    public d(c this$0, Context param1Context) {
      super(param1Context, null, e.a.k);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      z0.a((View)this, getContentDescription());
      setOnTouchListener(new a(this, (View)this, this$0));
    }
    
    public boolean a() {
      return false;
    }
    
    public boolean b() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      this.i.M();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(i, param1Int2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        param1Int3 = getPaddingTop();
        param1Int4 = getPaddingBottom();
        i = (i + j - k) / 2;
        param1Int2 = (param1Int2 + param1Int3 - param1Int4) / 2;
        d0.a.l(drawable2, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
    
    class a extends i0 {
      a(c.d this$0, View param2View, c param2c) {
        super(param2View);
      }
      
      public l.e b() {
        c.e e = this.p.i.D;
        return (l.e)((e == null) ? null : e.c());
      }
      
      public boolean c() {
        this.p.i.M();
        return true;
      }
      
      public boolean e() {
        c c1 = this.p.i;
        if (c1.F != null)
          return false; 
        c1.D();
        return true;
      }
    }
  }
  
  class a extends i0 {
    a(c this$0, View param1View, c param1c) {
      super(param1View);
    }
    
    public l.e b() {
      c.e e = this.p.i.D;
      return (l.e)((e == null) ? null : e.c());
    }
    
    public boolean c() {
      this.p.i.M();
      return true;
    }
    
    public boolean e() {
      c c1 = this.p.i;
      if (c1.F != null)
        return false; 
      c1.D();
      return true;
    }
  }
  
  private class e extends i {
    public e(c this$0, Context param1Context, androidx.appcompat.view.menu.e param1e, View param1View, boolean param1Boolean) {
      super(param1Context, param1e, param1View, param1Boolean, e.a.l);
      h(8388613);
      j(this$0.H);
    }
    
    protected void e() {
      if (c.t(this.m) != null)
        c.u(this.m).close(); 
      this.m.D = null;
      super.e();
    }
  }
  
  private class f implements j.a {
    f(c this$0) {}
    
    public void b(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {
      if (param1e instanceof m)
        param1e.F().e(false); 
      j.a a1 = this.f.o();
      if (a1 != null)
        a1.b(param1e, param1Boolean); 
    }
    
    public boolean c(androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = c.w(this.f);
      boolean bool = false;
      if (param1e == e1)
        return false; 
      this.f.I = ((m)param1e).getItem().getItemId();
      j.a a1 = this.f.o();
      if (a1 != null)
        bool = a1.c(param1e); 
      return bool;
    }
  }
  
  @SuppressLint({"BanParcelableUsage"})
  private static class g implements Parcelable {
    public static final Parcelable.Creator<g> CREATOR = new a();
    
    public int f;
    
    g() {}
    
    g(Parcel param1Parcel) {
      this.f = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.f);
    }
    
    class a implements Parcelable.Creator<g> {
      public c.g a(Parcel param2Parcel) {
        return new c.g(param2Parcel);
      }
      
      public c.g[] b(int param2Int) {
        return new c.g[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<g> {
    public c.g a(Parcel param1Parcel) {
      return new c.g(param1Parcel);
    }
    
    public c.g[] b(int param1Int) {
      return new c.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */