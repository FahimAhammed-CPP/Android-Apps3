package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.w;
import androidx.core.view.y;

class a1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  private static a1 o;
  
  private static a1 p;
  
  private final View f;
  
  private final CharSequence g;
  
  private final int h;
  
  private final Runnable i = new a(this);
  
  private final Runnable j = new b(this);
  
  private int k;
  
  private int l;
  
  private b1 m;
  
  private boolean n;
  
  private a1(View paramView, CharSequence paramCharSequence) {
    this.f = paramView;
    this.g = paramCharSequence;
    this.h = y.c(ViewConfiguration.get(paramView.getContext()));
    b();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  private void a() {
    this.f.removeCallbacks(this.i);
  }
  
  private void b() {
    this.k = Integer.MAX_VALUE;
    this.l = Integer.MAX_VALUE;
  }
  
  private void d() {
    this.f.postDelayed(this.i, ViewConfiguration.getLongPressTimeout());
  }
  
  private static void e(a1 parama1) {
    a1 a11 = o;
    if (a11 != null)
      a11.a(); 
    o = parama1;
    if (parama1 != null)
      parama1.d(); 
  }
  
  public static void f(View paramView, CharSequence paramCharSequence) {
    a1 a11;
    a1 a12 = o;
    if (a12 != null && a12.f == paramView)
      e(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      a11 = p;
      if (a11 != null && a11.f == paramView)
        a11.c(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new a1(paramView, (CharSequence)a11);
  }
  
  private boolean h(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (Math.abs(i - this.k) <= this.h && Math.abs(j - this.l) <= this.h)
      return false; 
    this.k = i;
    this.l = j;
    return true;
  }
  
  void c() {
    if (p == this) {
      p = null;
      b1 b11 = this.m;
      if (b11 != null) {
        b11.c();
        this.m = null;
        b();
        this.f.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (o == this)
      e(null); 
    this.f.removeCallbacks(this.j);
  }
  
  void g(boolean paramBoolean) {
    long l;
    if (!w.R(this.f))
      return; 
    e(null);
    a1 a11 = p;
    if (a11 != null)
      a11.c(); 
    p = this;
    this.n = paramBoolean;
    b1 b11 = new b1(this.f.getContext());
    this.m = b11;
    b11.e(this.f, this.k, this.l, this.n, this.g);
    this.f.addOnAttachStateChangeListener(this);
    if (this.n) {
      l = 2500L;
    } else {
      int i;
      if ((w.L(this.f) & 0x1) == 1) {
        l = 3000L;
        i = ViewConfiguration.getLongPressTimeout();
      } else {
        l = 15000L;
        i = ViewConfiguration.getLongPressTimeout();
      } 
      l -= i;
    } 
    this.f.removeCallbacks(this.j);
    this.f.postDelayed(this.j, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.m != null && this.n)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.f.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      b();
      c();
      return false;
    } 
    if (this.f.isEnabled() && this.m == null && h(paramMotionEvent))
      e(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.k = paramView.getWidth() / 2;
    this.l = paramView.getHeight() / 2;
    g(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    c();
  }
  
  class a implements Runnable {
    a(a1 this$0) {}
    
    public void run() {
      this.f.g(false);
    }
  }
  
  class b implements Runnable {
    b(a1 this$0) {}
    
    public void run() {
      this.f.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\appcompat\widget\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */