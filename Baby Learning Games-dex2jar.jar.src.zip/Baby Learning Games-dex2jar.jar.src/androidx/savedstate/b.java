package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.j;
import androidx.lifecycle.p;

public final class b {
  private final c a;
  
  private final SavedStateRegistry b;
  
  private b(c paramc) {
    this.a = paramc;
    this.b = new SavedStateRegistry();
  }
  
  public static b a(c paramc) {
    return new b(paramc);
  }
  
  public SavedStateRegistry b() {
    return this.b;
  }
  
  public void c(Bundle paramBundle) {
    j j = this.a.a();
    if (j.b() == j.c.g) {
      j.a((p)new Recreator(this.a));
      this.b.b(j, paramBundle);
      return;
    } 
    throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
  }
  
  public void d(Bundle paramBundle) {
    this.b.c(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\savedstate\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */