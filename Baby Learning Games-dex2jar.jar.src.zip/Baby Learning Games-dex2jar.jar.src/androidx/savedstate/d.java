package androidx.savedstate;

import android.view.View;

public final class d {
  public static void a(View paramView, c paramc) {
    paramView.setTag(a.a, paramc);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\savedstate\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */