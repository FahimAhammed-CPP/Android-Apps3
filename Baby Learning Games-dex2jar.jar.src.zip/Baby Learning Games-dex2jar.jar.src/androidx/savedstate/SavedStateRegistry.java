package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import java.util.Map;

@SuppressLint({"RestrictedApi"})
public final class SavedStateRegistry {
  private n.b<String, b> a = new n.b();
  
  private Bundle b;
  
  private boolean c;
  
  private Recreator.a d;
  
  boolean e = true;
  
  public Bundle a(String paramString) {
    if (this.c) {
      Bundle bundle = this.b;
      if (bundle != null) {
        bundle = bundle.getBundle(paramString);
        this.b.remove(paramString);
        if (this.b.isEmpty())
          this.b = null; 
        return bundle;
      } 
      return null;
    } 
    throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
  }
  
  void b(j paramj, Bundle paramBundle) {
    if (!this.c) {
      if (paramBundle != null)
        this.b = paramBundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key"); 
      paramj.a((p)new o(this) {
            public void d(q param1q, j.b param1b) {
              if (param1b == j.b.ON_START) {
                this.f.e = true;
                return;
              } 
              if (param1b == j.b.ON_STOP)
                this.f.e = false; 
            }
          });
      this.c = true;
      return;
    } 
    throw new IllegalStateException("SavedStateRegistry was already restored.");
  }
  
  void c(Bundle paramBundle) {
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = this.b;
    if (bundle2 != null)
      bundle1.putAll(bundle2); 
    n.b.d<Map.Entry> d = this.a.j();
    while (d.hasNext()) {
      Map.Entry entry = d.next();
      bundle1.putBundle((String)entry.getKey(), ((b)entry.getValue()).a());
    } 
    paramBundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle1);
  }
  
  public void d(String paramString, b paramb) {
    if ((b)this.a.m(paramString, paramb) == null)
      return; 
    throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
  }
  
  public void e(Class<? extends a> paramClass) {
    if (this.e) {
      if (this.d == null)
        this.d = new Recreator.a(this); 
      try {
        paramClass.getDeclaredConstructor(new Class[0]);
        this.d.b(paramClass.getName());
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Class");
        stringBuilder.append(paramClass.getSimpleName());
        stringBuilder.append(" must have default constructor in order to be automatically recreated");
        throw new IllegalArgumentException(stringBuilder.toString(), noSuchMethodException);
      } 
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  public static interface a {
    void a(c param1c);
  }
  
  public static interface b {
    Bundle a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\savedstate\SavedStateRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */