package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import androidx.versionedparcelable.a;

public class AudioAttributesImplApi26Parcelizer {
  public static AudioAttributesImplApi26 read(a parama) {
    AudioAttributesImplApi26 audioAttributesImplApi26 = new AudioAttributesImplApi26();
    audioAttributesImplApi26.a = (AudioAttributes)parama.r((Parcelable)audioAttributesImplApi26.a, 1);
    audioAttributesImplApi26.b = parama.p(audioAttributesImplApi26.b, 2);
    return audioAttributesImplApi26;
  }
  
  public static void write(AudioAttributesImplApi26 paramAudioAttributesImplApi26, a parama) {
    parama.x(false, false);
    parama.H((Parcelable)paramAudioAttributesImplApi26.a, 1);
    parama.F(paramAudioAttributesImplApi26.b, 2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\media\AudioAttributesImplApi26Parcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */