package androidx.media;

import android.media.AudioAttributes;

public class AudioAttributesImplApi26 extends AudioAttributesImplApi21 {
  public AudioAttributesImplApi26() {}
  
  AudioAttributesImplApi26(AudioAttributes paramAudioAttributes) {
    super(paramAudioAttributes, -1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\media\AudioAttributesImplApi26.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */