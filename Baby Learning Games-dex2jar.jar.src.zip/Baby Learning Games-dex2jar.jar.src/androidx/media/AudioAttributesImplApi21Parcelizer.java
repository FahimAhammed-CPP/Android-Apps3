package androidx.media;

import android.media.AudioAttributes;
import android.os.Parcelable;
import androidx.versionedparcelable.a;

public class AudioAttributesImplApi21Parcelizer {
  public static AudioAttributesImplApi21 read(a parama) {
    AudioAttributesImplApi21 audioAttributesImplApi21 = new AudioAttributesImplApi21();
    audioAttributesImplApi21.a = (AudioAttributes)parama.r((Parcelable)audioAttributesImplApi21.a, 1);
    audioAttributesImplApi21.b = parama.p(audioAttributesImplApi21.b, 2);
    return audioAttributesImplApi21;
  }
  
  public static void write(AudioAttributesImplApi21 paramAudioAttributesImplApi21, a parama) {
    parama.x(false, false);
    parama.H((Parcelable)paramAudioAttributesImplApi21.a, 1);
    parama.F(paramAudioAttributesImplApi21.b, 2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\media\AudioAttributesImplApi21Parcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */