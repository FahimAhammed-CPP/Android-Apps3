package androidx.navigation.fragment;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.m;
import androidx.fragment.app.v;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import z0.g;
import z0.k;
import z0.n;
import z0.n.b;

@b("fragment")
public class a extends n<a.b> {
  private final Context b;
  
  final m c;
  
  private final int d;
  
  ArrayDeque<Integer> e = new ArrayDeque<Integer>();
  
  boolean f = false;
  
  private final m.n g = new a(this);
  
  public a(Context paramContext, m paramm, int paramInt) {
    this.b = paramContext;
    this.c = paramm;
    this.d = paramInt;
  }
  
  private String l(int paramInt1, int paramInt2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramInt1);
    stringBuilder.append("-");
    stringBuilder.append(paramInt2);
    return stringBuilder.toString();
  }
  
  private int m(String paramString) {
    String[] arrayOfString;
    if (paramString != null) {
      arrayOfString = paramString.split("-");
    } else {
      arrayOfString = new String[0];
    } 
    if (arrayOfString.length == 2)
      try {
        Integer.parseInt(arrayOfString[0]);
        return Integer.parseInt(arrayOfString[1]);
      } catch (NumberFormatException numberFormatException) {
        throw new IllegalStateException("Invalid back stack entry on the NavHostFragment's back stack - use getChildFragmentManager() if you need to do custom FragmentTransactions from within Fragments created via your navigation graph.");
      }  
    throw new IllegalStateException("Invalid back stack entry on the NavHostFragment's back stack - use getChildFragmentManager() if you need to do custom FragmentTransactions from within Fragments created via your navigation graph.");
  }
  
  protected void e() {
    this.c.i(this.g);
  }
  
  protected void f() {
    this.c.c1(this.g);
  }
  
  public void g(Bundle paramBundle) {
    if (paramBundle != null) {
      int[] arrayOfInt = paramBundle.getIntArray("androidx-nav-fragment:navigator:backStackIds");
      if (arrayOfInt != null) {
        this.e.clear();
        int j = arrayOfInt.length;
        for (int i = 0; i < j; i++) {
          int k = arrayOfInt[i];
          this.e.add(Integer.valueOf(k));
        } 
      } 
    } 
  }
  
  public Bundle h() {
    Bundle bundle = new Bundle();
    int[] arrayOfInt = new int[this.e.size()];
    Iterator<Integer> iterator = this.e.iterator();
    for (int i = 0; iterator.hasNext(); i++)
      arrayOfInt[i] = ((Integer)iterator.next()).intValue(); 
    bundle.putIntArray("androidx-nav-fragment:navigator:backStackIds", arrayOfInt);
    return bundle;
  }
  
  public boolean i() {
    if (this.e.isEmpty())
      return false; 
    if (this.c.L0()) {
      Log.i("FragmentNavigator", "Ignoring popBackStack() call: FragmentManager has already saved its state");
      return false;
    } 
    if (this.c.n0() > 0) {
      this.c.V0(l(this.e.size(), ((Integer)this.e.peekLast()).intValue()), 1);
      this.f = true;
    } 
    this.e.removeLast();
    return true;
  }
  
  public b k() {
    return new b(this);
  }
  
  public Fragment n(Context paramContext, m paramm, String paramString, Bundle paramBundle) {
    return Fragment.X(paramContext, paramString, paramBundle);
  }
  
  boolean o() {
    int i = this.c.n0();
    if (this.e.size() != i + 1)
      return false; 
    Iterator<Integer> iterator = this.e.descendingIterator();
    i--;
    while (true) {
      if (iterator.hasNext() && i >= 0) {
        int j = ((Integer)iterator.next()).intValue();
        try {
          int k = m(this.c.m0(i).a());
          if (j != k)
            return false; 
          i--;
        } catch (NumberFormatException numberFormatException) {
          throw new IllegalStateException("Invalid back stack entry on the NavHostFragment's back stack - use getChildFragmentManager() if you need to do custom FragmentTransactions from within Fragments created via your navigation graph.");
        } 
        continue;
      } 
      return true;
    } 
  }
  
  public g p(b paramb, Bundle paramBundle, k paramk, n.a parama) {
    byte b2;
    byte b3;
    if (this.c.L0()) {
      Log.i("FragmentNavigator", "Ignoring navigate() call: FragmentManager has already saved its state");
      return null;
    } 
    String str2 = paramb.B();
    boolean bool = false;
    String str1 = str2;
    if (str2.charAt(0) == '.') {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.b.getPackageName());
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    Fragment fragment = n(this.b, this.c, str1, paramBundle);
    fragment.v1(paramBundle);
    v v = this.c.m();
    if (paramk != null) {
      b1 = paramk.a();
    } else {
      b1 = -1;
    } 
    if (paramk != null) {
      i = paramk.b();
    } else {
      i = -1;
    } 
    if (paramk != null) {
      b2 = paramk.c();
    } else {
      b2 = -1;
    } 
    if (paramk != null) {
      b3 = paramk.d();
    } else {
      b3 = -1;
    } 
    if (b1 != -1 || i != -1 || b2 != -1 || b3 != -1) {
      if (b1 == -1)
        b1 = 0; 
      if (i == -1)
        i = 0; 
      if (b2 == -1)
        b2 = 0; 
      if (b3 == -1)
        b3 = 0; 
      v.r(b1, i, b2, b3);
    } 
    v.p(this.d, fragment);
    v.s(fragment);
    int i = paramb.p();
    boolean bool1 = this.e.isEmpty();
    if (paramk != null && !bool1 && paramk.g() && ((Integer)this.e.peekLast()).intValue() == i) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    if (!bool1) {
      if (b1 != 0) {
        b1 = bool;
        if (this.e.size() > 1) {
          this.c.V0(l(this.e.size(), ((Integer)this.e.peekLast()).intValue()), 1);
          v.h(l(this.e.size(), i));
          this.f = true;
          b1 = bool;
        } 
      } else {
        v.h(l(this.e.size() + 1, i));
        this.f = true;
        b1 = 1;
      } 
      if (parama instanceof c)
        for (Map.Entry<View, String> entry : ((c)parama).a().entrySet())
          v.g((View)entry.getKey(), (String)entry.getValue());  
      v.t(true);
      v.i();
      if (b1 != 0) {
        this.e.add(Integer.valueOf(i));
        return paramb;
      } 
      return null;
    } 
    byte b1 = 1;
  }
  
  class a implements m.n {
    a(a this$0) {}
    
    public void a() {
      a a1 = this.a;
      if (a1.f) {
        a1.f = a1.o() ^ true;
        return;
      } 
      int i = a1.c.n0() + 1;
      if (i < this.a.e.size()) {
        while (this.a.e.size() > i)
          this.a.e.removeLast(); 
        this.a.c();
      } 
    }
  }
  
  public static class b extends g {
    private String o;
    
    public b(n<? extends b> param1n) {
      super(param1n);
    }
    
    public final String B() {
      String str = this.o;
      if (str != null)
        return str; 
      throw new IllegalStateException("Fragment class was not set");
    }
    
    public final b C(String param1String) {
      this.o = param1String;
      return this;
    }
    
    public void t(Context param1Context, AttributeSet param1AttributeSet) {
      super.t(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.getResources().obtainAttributes(param1AttributeSet, b1.a.g);
      String str = typedArray.getString(b1.a.h);
      if (str != null)
        C(str); 
      typedArray.recycle();
    }
  }
  
  public static final class c implements n.a {
    private final LinkedHashMap<View, String> a;
    
    public Map<View, String> a() {
      return Collections.unmodifiableMap(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\navigation\fragment\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */