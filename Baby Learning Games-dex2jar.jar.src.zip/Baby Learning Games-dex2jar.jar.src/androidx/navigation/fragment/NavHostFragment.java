package androidx.navigation.fragment;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.fragment.app.Fragment;
import b1.a;
import z0.e;
import z0.m;
import z0.n;

public class NavHostFragment extends Fragment {
  private e g0;
  
  private int h0;
  
  private boolean i0;
  
  protected n<? extends a.b> E1() {
    return new a(m1(), q(), A());
  }
  
  public void I0(Bundle paramBundle) {
    super.I0(paramBundle);
    Bundle bundle = this.g0.p();
    if (bundle != null)
      paramBundle.putBundle("android-support-nav:fragment:navControllerState", bundle); 
    if (this.i0)
      paramBundle.putBoolean("android-support-nav:fragment:defaultHost", true); 
  }
  
  public void L0(View paramView, Bundle paramBundle) {
    super.L0(paramView, paramBundle);
    if (paramView instanceof ViewGroup) {
      View view = paramView;
      if (paramView.getParent() != null)
        view = (View)paramView.getParent(); 
      m.d(view, this.g0);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("created host view ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a ViewGroup");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void j0(Context paramContext) {
    super.j0(paramContext);
    if (this.i0)
      n1().m().s(this).i(); 
  }
  
  public void m0(Bundle paramBundle) {
    super.m0(paramBundle);
    e e1 = new e(m1());
    this.g0 = e1;
    e1.e().b(E1());
    int i = 0;
    Bundle bundle2 = null;
    if (paramBundle != null) {
      Bundle bundle4 = paramBundle.getBundle("android-support-nav:fragment:navControllerState");
      Bundle bundle3 = bundle4;
      if (paramBundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
        this.i0 = true;
        n1().m().s(this).i();
        bundle3 = bundle4;
      } 
    } else {
      e1 = null;
    } 
    if (e1 != null)
      this.g0.o((Bundle)e1); 
    int j = this.h0;
    if (j != 0) {
      this.g0.q(j);
      return;
    } 
    Bundle bundle1 = p();
    if (bundle1 != null)
      i = bundle1.getInt("android-support-nav:fragment:graphId"); 
    paramBundle = bundle2;
    if (bundle1 != null)
      paramBundle = bundle1.getBundle("android-support-nav:fragment:startDestinationArgs"); 
    if (i != 0)
      this.g0.r(i, paramBundle); 
  }
  
  public View q0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    FrameLayout frameLayout = new FrameLayout(paramLayoutInflater.getContext());
    frameLayout.setId(A());
    return (View)frameLayout;
  }
  
  public void y0(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    super.y0(paramContext, paramAttributeSet, paramBundle);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, a.o);
    int i = typedArray.getResourceId(a.q, 0);
    boolean bool = typedArray.getBoolean(a.p, false);
    if (i != 0)
      this.h0 = i; 
    if (bool)
      this.i0 = true; 
    typedArray.recycle();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\navigation\fragment\NavHostFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */