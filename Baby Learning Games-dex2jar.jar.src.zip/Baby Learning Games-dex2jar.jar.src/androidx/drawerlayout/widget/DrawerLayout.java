package androidx.drawerlayout.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import androidx.core.view.g0;
import androidx.core.view.w;
import java.util.ArrayList;
import java.util.List;

public class DrawerLayout extends ViewGroup {
  private static final int[] Q = new int[] { 16843828 };
  
  static final int[] R = new int[] { 16842931 };
  
  static final boolean S = true;
  
  private static final boolean T = true;
  
  private static boolean U;
  
  private float A;
  
  private Drawable B;
  
  private Drawable C;
  
  private Drawable D;
  
  private CharSequence E;
  
  private CharSequence F;
  
  private Object G;
  
  private boolean H;
  
  private Drawable I = null;
  
  private Drawable J = null;
  
  private Drawable K = null;
  
  private Drawable L = null;
  
  private final ArrayList<View> M;
  
  private Rect N;
  
  private Matrix O;
  
  private final l0.f P = new a(this);
  
  private final d f = new d();
  
  private float g;
  
  private int h;
  
  private int i = -1728053248;
  
  private float j;
  
  private Paint k = new Paint();
  
  private final q0.c l;
  
  private final q0.c m;
  
  private final h n;
  
  private final h o;
  
  private int p;
  
  private boolean q;
  
  private boolean r = true;
  
  private int s = 3;
  
  private int t = 3;
  
  private int u = 3;
  
  private int v = 3;
  
  private boolean w;
  
  private e x;
  
  private List<e> y;
  
  private float z;
  
  static {
    if (i < 29)
      bool = false; 
    U = bool;
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, r0.a.a);
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setDescendantFocusability(262144);
    float f1 = (getResources().getDisplayMetrics()).density;
    this.h = (int)(64.0F * f1 + 0.5F);
    f1 *= 400.0F;
    h h2 = new h(this, 3);
    this.n = h2;
    h h1 = new h(this, 5);
    this.o = h1;
    q0.c c2 = q0.c.n(this, 1.0F, h2);
    this.l = c2;
    c2.M(1);
    c2.N(f1);
    h2.q(c2);
    q0.c c1 = q0.c.n(this, 1.0F, h1);
    this.m = c1;
    c1.M(2);
    c1.N(f1);
    h1.q(c1);
    setFocusableInTouchMode(true);
    w.y0((View)this, 1);
    w.o0((View)this, new c(this));
    setMotionEventSplittingEnabled(false);
    if (w.y((View)this)) {
      setOnApplyWindowInsetsListener(new b(this));
      setSystemUiVisibility(1280);
      TypedArray typedArray1 = paramContext.obtainStyledAttributes(Q);
      try {
        this.B = typedArray1.getDrawable(0);
      } finally {
        typedArray1.recycle();
      } 
    } 
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, r0.c.b, paramInt, 0);
    try {
      paramInt = r0.c.c;
      if (typedArray.hasValue(paramInt)) {
        this.g = typedArray.getDimension(paramInt, 0.0F);
      } else {
        this.g = getResources().getDimension(r0.b.a);
      } 
      typedArray.recycle();
      return;
    } finally {
      typedArray.recycle();
    } 
  }
  
  static boolean A(View paramView) {
    return (w.z(paramView) != 4 && w.z(paramView) != 2);
  }
  
  private boolean H(float paramFloat1, float paramFloat2, View paramView) {
    if (this.N == null)
      this.N = new Rect(); 
    paramView.getHitRect(this.N);
    return this.N.contains((int)paramFloat1, (int)paramFloat2);
  }
  
  private void I(Drawable paramDrawable, int paramInt) {
    if (paramDrawable != null && d0.a.h(paramDrawable))
      d0.a.m(paramDrawable, paramInt); 
  }
  
  private Drawable P() {
    int i = w.B((View)this);
    if (i == 0) {
      Drawable drawable = this.I;
      if (drawable != null) {
        I(drawable, i);
        return this.I;
      } 
    } else {
      Drawable drawable = this.J;
      if (drawable != null) {
        I(drawable, i);
        return this.J;
      } 
    } 
    return this.K;
  }
  
  private Drawable Q() {
    int i = w.B((View)this);
    if (i == 0) {
      Drawable drawable = this.J;
      if (drawable != null) {
        I(drawable, i);
        return this.J;
      } 
    } else {
      Drawable drawable = this.I;
      if (drawable != null) {
        I(drawable, i);
        return this.I;
      } 
    } 
    return this.L;
  }
  
  private void R() {
    if (T)
      return; 
    this.C = P();
    this.D = Q();
  }
  
  private void V(View paramView) {
    l0.c.a a = l0.c.a.y;
    w.i0(paramView, a.b());
    if (D(paramView) && r(paramView) != 2)
      w.k0(paramView, a, null, this.P); 
  }
  
  private void W(View paramView, boolean paramBoolean) {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if ((!paramBoolean && !E(view)) || (paramBoolean && view == paramView)) {
        w.y0(view, 1);
      } else {
        w.y0(view, 4);
      } 
    } 
  }
  
  private boolean m(MotionEvent paramMotionEvent, View paramView) {
    if (!paramView.getMatrix().isIdentity()) {
      paramMotionEvent = v(paramMotionEvent, paramView);
      boolean bool1 = paramView.dispatchGenericMotionEvent(paramMotionEvent);
      paramMotionEvent.recycle();
      return bool1;
    } 
    float f1 = (getScrollX() - paramView.getLeft());
    float f2 = (getScrollY() - paramView.getTop());
    paramMotionEvent.offsetLocation(f1, f2);
    boolean bool = paramView.dispatchGenericMotionEvent(paramMotionEvent);
    paramMotionEvent.offsetLocation(-f1, -f2);
    return bool;
  }
  
  private MotionEvent v(MotionEvent paramMotionEvent, View paramView) {
    float f1 = (getScrollX() - paramView.getLeft());
    float f2 = (getScrollY() - paramView.getTop());
    paramMotionEvent = MotionEvent.obtain(paramMotionEvent);
    paramMotionEvent.offsetLocation(f1, f2);
    Matrix matrix = paramView.getMatrix();
    if (!matrix.isIdentity()) {
      if (this.O == null)
        this.O = new Matrix(); 
      matrix.invert(this.O);
      paramMotionEvent.transform(this.O);
    } 
    return paramMotionEvent;
  }
  
  static String w(int paramInt) {
    return ((paramInt & 0x3) == 3) ? "LEFT" : (((paramInt & 0x5) == 5) ? "RIGHT" : Integer.toHexString(paramInt));
  }
  
  private static boolean x(View paramView) {
    Drawable drawable = paramView.getBackground();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (drawable != null) {
      bool1 = bool2;
      if (drawable.getOpacity() == -1)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private boolean y() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      if (((f)getChildAt(i).getLayoutParams()).c)
        return true; 
    } 
    return false;
  }
  
  private boolean z() {
    return (p() != null);
  }
  
  boolean B(View paramView) {
    return (((f)paramView.getLayoutParams()).a == 0);
  }
  
  public boolean C(int paramInt) {
    View view = n(paramInt);
    return (view != null) ? D(view) : false;
  }
  
  public boolean D(View paramView) {
    if (E(paramView))
      return ((((f)paramView.getLayoutParams()).d & 0x1) == 1); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  boolean E(View paramView) {
    int i = androidx.core.view.e.b(((f)paramView.getLayoutParams()).a, w.B(paramView));
    return ((i & 0x3) != 0) ? true : (((i & 0x5) != 0));
  }
  
  public boolean F(int paramInt) {
    View view = n(paramInt);
    return (view != null) ? G(view) : false;
  }
  
  public boolean G(View paramView) {
    if (E(paramView))
      return (((f)paramView.getLayoutParams()).b > 0.0F); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  void J(View paramView, float paramFloat) {
    float f1 = u(paramView);
    float f2 = paramView.getWidth();
    int i = (int)(f1 * f2);
    i = (int)(f2 * paramFloat) - i;
    if (!c(paramView, 3))
      i = -i; 
    paramView.offsetLeftAndRight(i);
    U(paramView, paramFloat);
  }
  
  public void K(int paramInt) {
    L(paramInt, true);
  }
  
  public void L(int paramInt, boolean paramBoolean) {
    View view = n(paramInt);
    if (view != null) {
      N(view, paramBoolean);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No drawer view found with gravity ");
    stringBuilder.append(w(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void M(View paramView) {
    N(paramView, true);
  }
  
  public void N(View paramView, boolean paramBoolean) {
    if (E(paramView)) {
      f f1 = (f)paramView.getLayoutParams();
      if (this.r) {
        f1.b = 1.0F;
        f1.d = 1;
        W(paramView, true);
        V(paramView);
      } else if (paramBoolean) {
        f1.d |= 0x2;
        if (c(paramView, 3)) {
          this.l.Q(paramView, 0, paramView.getTop());
        } else {
          this.m.Q(paramView, getWidth() - paramView.getWidth(), paramView.getTop());
        } 
      } else {
        J(paramView, 1.0F);
        X(0, paramView);
        paramView.setVisibility(0);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void O(e parame) {
    if (parame == null)
      return; 
    List<e> list = this.y;
    if (list == null)
      return; 
    list.remove(parame);
  }
  
  public void S(Object paramObject, boolean paramBoolean) {
    this.G = paramObject;
    this.H = paramBoolean;
    if (!paramBoolean && getBackground() == null) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    setWillNotDraw(paramBoolean);
    requestLayout();
  }
  
  public void T(int paramInt1, int paramInt2) {
    int i = androidx.core.view.e.b(paramInt2, w.B((View)this));
    if (paramInt2 != 3) {
      if (paramInt2 != 5) {
        if (paramInt2 != 8388611) {
          if (paramInt2 == 8388613)
            this.v = paramInt1; 
        } else {
          this.u = paramInt1;
        } 
      } else {
        this.t = paramInt1;
      } 
    } else {
      this.s = paramInt1;
    } 
    if (paramInt1 != 0) {
      q0.c c1;
      if (i == 3) {
        c1 = this.l;
      } else {
        c1 = this.m;
      } 
      c1.a();
    } 
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return; 
      View view = n(i);
      if (view != null) {
        M(view);
        return;
      } 
    } else {
      View view = n(i);
      if (view != null)
        f(view); 
    } 
  }
  
  void U(View paramView, float paramFloat) {
    f f1 = (f)paramView.getLayoutParams();
    if (paramFloat == f1.b)
      return; 
    f1.b = paramFloat;
    l(paramView, paramFloat);
  }
  
  void X(int paramInt, View paramView) {
    byte b1;
    int i = this.l.A();
    int j = this.m.A();
    byte b2 = 2;
    if (i == 1 || j == 1) {
      b1 = 1;
    } else {
      b1 = b2;
      if (i != 2)
        if (j == 2) {
          b1 = b2;
        } else {
          b1 = 0;
        }  
    } 
    if (paramView != null && paramInt == 0) {
      float f1 = ((f)paramView.getLayoutParams()).b;
      if (f1 == 0.0F) {
        j(paramView);
      } else if (f1 == 1.0F) {
        k(paramView);
      } 
    } 
    if (b1 != this.p) {
      this.p = b1;
      List<e> list = this.y;
      if (list != null)
        for (paramInt = list.size() - 1; paramInt >= 0; paramInt--)
          ((e)this.y.get(paramInt)).a(b1);  
    } 
  }
  
  public void a(e parame) {
    if (parame == null)
      return; 
    if (this.y == null)
      this.y = new ArrayList<e>(); 
    this.y.add(parame);
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    if (getDescendantFocusability() == 393216)
      return; 
    int k = getChildCount();
    boolean bool = false;
    int i = 0;
    int j = i;
    while (i < k) {
      View view = getChildAt(i);
      if (E(view)) {
        if (D(view)) {
          view.addFocusables(paramArrayList, paramInt1, paramInt2);
          j = 1;
        } 
      } else {
        this.M.add(view);
      } 
      i++;
    } 
    if (j == 0) {
      j = this.M.size();
      for (i = bool; i < j; i++) {
        View view = this.M.get(i);
        if (view.getVisibility() == 0)
          view.addFocusables(paramArrayList, paramInt1, paramInt2); 
      } 
    } 
    this.M.clear();
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (o() != null || E(paramView)) {
      w.y0(paramView, 4);
    } else {
      w.y0(paramView, 1);
    } 
    if (!S)
      w.o0(paramView, this.f); 
  }
  
  void b() {
    if (!this.w) {
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      int j = getChildCount();
      for (int i = 0; i < j; i++)
        getChildAt(i).dispatchTouchEvent(motionEvent); 
      motionEvent.recycle();
      this.w = true;
    } 
  }
  
  boolean c(View paramView, int paramInt) {
    return ((t(paramView) & paramInt) == paramInt);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof f && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll() {
    int j = getChildCount();
    float f1 = 0.0F;
    for (int i = 0; i < j; i++)
      f1 = Math.max(f1, ((f)getChildAt(i).getLayoutParams()).b); 
    this.j = f1;
    boolean bool1 = this.l.m(true);
    boolean bool2 = this.m.m(true);
    if (bool1 || bool2)
      w.f0((View)this); 
  }
  
  public void d(int paramInt) {
    e(paramInt, true);
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) == 0 || paramMotionEvent.getAction() == 10 || this.j <= 0.0F)
      return super.dispatchGenericMotionEvent(paramMotionEvent); 
    int i = getChildCount();
    if (i != 0) {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      while (--i >= 0) {
        View view = getChildAt(i);
        if (H(f1, f2, view) && !B(view) && m(paramMotionEvent, view))
          return true; 
        i--;
      } 
    } 
    return false;
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    int n = getHeight();
    boolean bool1 = B(paramView);
    int i = getWidth();
    int m = paramCanvas.save();
    int k = 0;
    int j = i;
    if (bool1) {
      int i1 = getChildCount();
      k = 0;
      for (j = k; k < i1; j = i3) {
        View view = getChildAt(k);
        int i2 = i;
        int i3 = j;
        if (view != paramView) {
          i2 = i;
          i3 = j;
          if (view.getVisibility() == 0) {
            i2 = i;
            i3 = j;
            if (x(view)) {
              i2 = i;
              i3 = j;
              if (E(view))
                if (view.getHeight() < n) {
                  i2 = i;
                  i3 = j;
                } else if (c(view, 3)) {
                  int i4 = view.getRight();
                  i2 = i;
                  i3 = j;
                  if (i4 > j) {
                    i3 = i4;
                    i2 = i;
                  } 
                } else {
                  int i4 = view.getLeft();
                  i2 = i;
                  i3 = j;
                  if (i4 < i) {
                    i2 = i4;
                    i3 = j;
                  } 
                }  
            } 
          } 
        } 
        k++;
        i = i2;
      } 
      paramCanvas.clipRect(j, 0, i, getHeight());
      k = j;
      j = i;
    } 
    boolean bool2 = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(m);
    float f1 = this.j;
    if (f1 > 0.0F && bool1) {
      i = this.i;
      int i1 = (int)(((0xFF000000 & i) >>> 24) * f1);
      this.k.setColor(i & 0xFFFFFF | i1 << 24);
      paramCanvas.drawRect(k, 0.0F, j, getHeight(), this.k);
      return bool2;
    } 
    if (this.C != null && c(paramView, 3)) {
      i = this.C.getIntrinsicWidth();
      j = paramView.getRight();
      k = this.l.x();
      f1 = Math.max(0.0F, Math.min(j / k, 1.0F));
      this.C.setBounds(j, paramView.getTop(), i + j, paramView.getBottom());
      this.C.setAlpha((int)(f1 * 255.0F));
      this.C.draw(paramCanvas);
      return bool2;
    } 
    if (this.D != null && c(paramView, 5)) {
      i = this.D.getIntrinsicWidth();
      j = paramView.getLeft();
      k = getWidth();
      int i1 = this.m.x();
      f1 = Math.max(0.0F, Math.min((k - j) / i1, 1.0F));
      this.D.setBounds(j - i, paramView.getTop(), j, paramView.getBottom());
      this.D.setAlpha((int)(f1 * 255.0F));
      this.D.draw(paramCanvas);
    } 
    return bool2;
  }
  
  public void e(int paramInt, boolean paramBoolean) {
    View view = n(paramInt);
    if (view != null) {
      g(view, paramBoolean);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No drawer view found with gravity ");
    stringBuilder.append(w(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void f(View paramView) {
    g(paramView, true);
  }
  
  public void g(View paramView, boolean paramBoolean) {
    if (E(paramView)) {
      f f1 = (f)paramView.getLayoutParams();
      if (this.r) {
        f1.b = 0.0F;
        f1.d = 0;
      } else if (paramBoolean) {
        f1.d |= 0x4;
        if (c(paramView, 3)) {
          this.l.Q(paramView, -paramView.getWidth(), paramView.getTop());
        } else {
          this.m.Q(paramView, getWidth(), paramView.getTop());
        } 
      } else {
        J(paramView, 0.0F);
        X(0, paramView);
        paramView.setVisibility(4);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new f(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new f(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof f) ? new f((f)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new f((ViewGroup.MarginLayoutParams)paramLayoutParams) : new f(paramLayoutParams)));
  }
  
  public float getDrawerElevation() {
    return T ? this.g : 0.0F;
  }
  
  public Drawable getStatusBarBackgroundDrawable() {
    return this.B;
  }
  
  public void h() {
    i(false);
  }
  
  void i(boolean paramBoolean) {
    int j;
    int m = getChildCount();
    int i = 0;
    int k = i;
    while (i < m) {
      int i1;
      View view = getChildAt(i);
      f f1 = (f)view.getLayoutParams();
      int i2 = k;
      if (E(view))
        if (paramBoolean && !f1.c) {
          i2 = k;
        } else {
          int i3;
          i2 = view.getWidth();
          if (c(view, 3)) {
            i3 = this.l.Q(view, -i2, view.getTop());
          } else {
            i3 = this.m.Q(view, getWidth(), view.getTop());
          } 
          i1 = k | i3;
          f1.c = false;
        }  
      int n = i + 1;
      j = i1;
    } 
    this.n.p();
    this.o.p();
    if (j != 0)
      invalidate(); 
  }
  
  void j(View paramView) {
    f f1 = (f)paramView.getLayoutParams();
    if ((f1.d & 0x1) == 1) {
      f1.d = 0;
      List<e> list = this.y;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--)
          ((e)this.y.get(i)).d(paramView);  
      W(paramView, false);
      V(paramView);
      if (hasWindowFocus()) {
        paramView = getRootView();
        if (paramView != null)
          paramView.sendAccessibilityEvent(32); 
      } 
    } 
  }
  
  void k(View paramView) {
    f f1 = (f)paramView.getLayoutParams();
    if ((f1.d & 0x1) == 0) {
      f1.d = 1;
      List<e> list = this.y;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--)
          ((e)this.y.get(i)).c(paramView);  
      W(paramView, true);
      V(paramView);
      if (hasWindowFocus())
        sendAccessibilityEvent(32); 
    } 
  }
  
  void l(View paramView, float paramFloat) {
    List<e> list = this.y;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((e)this.y.get(i)).b(paramView, paramFloat);  
  }
  
  View n(int paramInt) {
    int i = androidx.core.view.e.b(paramInt, w.B((View)this));
    int j = getChildCount();
    for (paramInt = 0; paramInt < j; paramInt++) {
      View view = getChildAt(paramInt);
      if ((t(view) & 0x7) == (i & 0x7))
        return view; 
    } 
    return null;
  }
  
  View o() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if ((((f)view.getLayoutParams()).d & 0x1) == 1)
        return view; 
    } 
    return null;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.r = true;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.r = true;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.H && this.B != null) {
      boolean bool;
      Object object = this.G;
      if (object != null) {
        bool = ((WindowInsets)object).getSystemWindowInsetTop();
      } else {
        bool = false;
      } 
      if (bool) {
        this.B.setBounds(0, 0, getWidth(), bool);
        this.B.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: getfield l : Lq0/c;
    //   10: aload_1
    //   11: invokevirtual P : (Landroid/view/MotionEvent;)Z
    //   14: istore #7
    //   16: aload_0
    //   17: getfield m : Lq0/c;
    //   20: aload_1
    //   21: invokevirtual P : (Landroid/view/MotionEvent;)Z
    //   24: istore #8
    //   26: iconst_1
    //   27: istore #6
    //   29: iload #4
    //   31: ifeq -> 99
    //   34: iload #4
    //   36: iconst_1
    //   37: if_icmpeq -> 83
    //   40: iload #4
    //   42: iconst_2
    //   43: if_icmpeq -> 55
    //   46: iload #4
    //   48: iconst_3
    //   49: if_icmpeq -> 83
    //   52: goto -> 93
    //   55: aload_0
    //   56: getfield l : Lq0/c;
    //   59: iconst_3
    //   60: invokevirtual d : (I)Z
    //   63: ifeq -> 93
    //   66: aload_0
    //   67: getfield n : Landroidx/drawerlayout/widget/DrawerLayout$h;
    //   70: invokevirtual p : ()V
    //   73: aload_0
    //   74: getfield o : Landroidx/drawerlayout/widget/DrawerLayout$h;
    //   77: invokevirtual p : ()V
    //   80: goto -> 93
    //   83: aload_0
    //   84: iconst_1
    //   85: invokevirtual i : (Z)V
    //   88: aload_0
    //   89: iconst_0
    //   90: putfield w : Z
    //   93: iconst_0
    //   94: istore #4
    //   96: goto -> 166
    //   99: aload_1
    //   100: invokevirtual getX : ()F
    //   103: fstore_2
    //   104: aload_1
    //   105: invokevirtual getY : ()F
    //   108: fstore_3
    //   109: aload_0
    //   110: fload_2
    //   111: putfield z : F
    //   114: aload_0
    //   115: fload_3
    //   116: putfield A : F
    //   119: aload_0
    //   120: getfield j : F
    //   123: fconst_0
    //   124: fcmpl
    //   125: ifle -> 158
    //   128: aload_0
    //   129: getfield l : Lq0/c;
    //   132: fload_2
    //   133: f2i
    //   134: fload_3
    //   135: f2i
    //   136: invokevirtual t : (II)Landroid/view/View;
    //   139: astore_1
    //   140: aload_1
    //   141: ifnull -> 158
    //   144: aload_0
    //   145: aload_1
    //   146: invokevirtual B : (Landroid/view/View;)Z
    //   149: ifeq -> 158
    //   152: iconst_1
    //   153: istore #4
    //   155: goto -> 161
    //   158: iconst_0
    //   159: istore #4
    //   161: aload_0
    //   162: iconst_0
    //   163: putfield w : Z
    //   166: iload #6
    //   168: istore #5
    //   170: iload #7
    //   172: iload #8
    //   174: ior
    //   175: ifne -> 210
    //   178: iload #6
    //   180: istore #5
    //   182: iload #4
    //   184: ifne -> 210
    //   187: iload #6
    //   189: istore #5
    //   191: aload_0
    //   192: invokespecial y : ()Z
    //   195: ifne -> 210
    //   198: aload_0
    //   199: getfield w : Z
    //   202: ifeq -> 207
    //   205: iconst_1
    //   206: ireturn
    //   207: iconst_0
    //   208: istore #5
    //   210: iload #5
    //   212: ireturn
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4 && z()) {
      paramKeyEvent.startTracking();
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    View view;
    if (paramInt == 4) {
      view = p();
      if (view != null && r(view) == 0)
        h(); 
      return (view != null);
    } 
    return super.onKeyUp(paramInt, (KeyEvent)view);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.q = true;
    int i = paramInt3 - paramInt1;
    int j = getChildCount();
    for (paramInt3 = 0; paramInt3 < j; paramInt3++) {
      View view = getChildAt(paramInt3);
      if (view.getVisibility() != 8) {
        f f1 = (f)view.getLayoutParams();
        if (B(view)) {
          paramInt1 = f1.leftMargin;
          view.layout(paramInt1, f1.topMargin, view.getMeasuredWidth() + paramInt1, f1.topMargin + view.getMeasuredHeight());
        } else {
          float f2;
          int k;
          boolean bool;
          int m = view.getMeasuredWidth();
          int n = view.getMeasuredHeight();
          if (c(view, 3)) {
            paramInt1 = -m;
            f2 = m;
            k = paramInt1 + (int)(f1.b * f2);
            f2 = (m + k) / f2;
          } else {
            f2 = m;
            k = i - (int)(f1.b * f2);
            f2 = (i - k) / f2;
          } 
          if (f2 != f1.b) {
            bool = true;
          } else {
            bool = false;
          } 
          paramInt1 = f1.a & 0x70;
          if (paramInt1 != 16) {
            if (paramInt1 != 80) {
              paramInt1 = f1.topMargin;
              view.layout(k, paramInt1, m + k, n + paramInt1);
            } else {
              paramInt1 = paramInt4 - paramInt2;
              view.layout(k, paramInt1 - f1.bottomMargin - view.getMeasuredHeight(), m + k, paramInt1 - f1.bottomMargin);
            } 
          } else {
            int i2 = paramInt4 - paramInt2;
            int i1 = (i2 - n) / 2;
            paramInt1 = f1.topMargin;
            if (i1 >= paramInt1) {
              int i3 = f1.bottomMargin;
              paramInt1 = i1;
              if (i1 + n > i2 - i3)
                paramInt1 = i2 - i3 - n; 
            } 
            view.layout(k, paramInt1, m + k, n + paramInt1);
          } 
          if (bool)
            U(view, f2); 
          if (f1.b > 0.0F) {
            paramInt1 = 0;
          } else {
            paramInt1 = 4;
          } 
          if (view.getVisibility() != paramInt1)
            view.setVisibility(paramInt1); 
        } 
      } 
    } 
    if (U) {
      WindowInsets windowInsets = getRootWindowInsets();
      if (windowInsets != null) {
        c0.b b = g0.w(windowInsets).h();
        q0.c c1 = this.l;
        c1.L(Math.max(c1.w(), b.a));
        c1 = this.m;
        c1.L(Math.max(c1.w(), b.c));
      } 
    } 
    this.q = false;
    this.r = false;
  }
  
  @SuppressLint({"WrongConstant"})
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore #10
    //   6: iload_2
    //   7: invokestatic getMode : (I)I
    //   10: istore #9
    //   12: iload_1
    //   13: invokestatic getSize : (I)I
    //   16: istore #5
    //   18: iload_2
    //   19: invokestatic getSize : (I)I
    //   22: istore #6
    //   24: iload #10
    //   26: ldc_w 1073741824
    //   29: if_icmpne -> 48
    //   32: iload #5
    //   34: istore #7
    //   36: iload #6
    //   38: istore #8
    //   40: iload #9
    //   42: ldc_w 1073741824
    //   45: if_icmpeq -> 87
    //   48: aload_0
    //   49: invokevirtual isInEditMode : ()Z
    //   52: ifeq -> 758
    //   55: iload #10
    //   57: ifne -> 65
    //   60: sipush #300
    //   63: istore #5
    //   65: iload #5
    //   67: istore #7
    //   69: iload #6
    //   71: istore #8
    //   73: iload #9
    //   75: ifne -> 87
    //   78: sipush #300
    //   81: istore #8
    //   83: iload #5
    //   85: istore #7
    //   87: aload_0
    //   88: iload #7
    //   90: iload #8
    //   92: invokevirtual setMeasuredDimension : (II)V
    //   95: aload_0
    //   96: getfield G : Ljava/lang/Object;
    //   99: ifnull -> 115
    //   102: aload_0
    //   103: invokestatic y : (Landroid/view/View;)Z
    //   106: ifeq -> 115
    //   109: iconst_1
    //   110: istore #9
    //   112: goto -> 118
    //   115: iconst_0
    //   116: istore #9
    //   118: aload_0
    //   119: invokestatic B : (Landroid/view/View;)I
    //   122: istore #12
    //   124: aload_0
    //   125: invokevirtual getChildCount : ()I
    //   128: istore #13
    //   130: iconst_0
    //   131: istore #10
    //   133: iload #10
    //   135: istore #6
    //   137: iload #6
    //   139: istore #5
    //   141: iload #10
    //   143: iload #13
    //   145: if_icmpge -> 757
    //   148: aload_0
    //   149: iload #10
    //   151: invokevirtual getChildAt : (I)Landroid/view/View;
    //   154: astore #17
    //   156: aload #17
    //   158: invokevirtual getVisibility : ()I
    //   161: bipush #8
    //   163: if_icmpne -> 169
    //   166: goto -> 457
    //   169: aload #17
    //   171: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   174: checkcast androidx/drawerlayout/widget/DrawerLayout$f
    //   177: astore #18
    //   179: iload #9
    //   181: ifeq -> 403
    //   184: aload #18
    //   186: getfield a : I
    //   189: iload #12
    //   191: invokestatic b : (II)I
    //   194: istore #11
    //   196: aload #17
    //   198: invokestatic y : (Landroid/view/View;)Z
    //   201: ifeq -> 289
    //   204: aload_0
    //   205: getfield G : Ljava/lang/Object;
    //   208: checkcast android/view/WindowInsets
    //   211: astore #16
    //   213: iload #11
    //   215: iconst_3
    //   216: if_icmpne -> 245
    //   219: aload #16
    //   221: aload #16
    //   223: invokevirtual getSystemWindowInsetLeft : ()I
    //   226: aload #16
    //   228: invokevirtual getSystemWindowInsetTop : ()I
    //   231: iconst_0
    //   232: aload #16
    //   234: invokevirtual getSystemWindowInsetBottom : ()I
    //   237: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   240: astore #15
    //   242: goto -> 278
    //   245: aload #16
    //   247: astore #15
    //   249: iload #11
    //   251: iconst_5
    //   252: if_icmpne -> 278
    //   255: aload #16
    //   257: iconst_0
    //   258: aload #16
    //   260: invokevirtual getSystemWindowInsetTop : ()I
    //   263: aload #16
    //   265: invokevirtual getSystemWindowInsetRight : ()I
    //   268: aload #16
    //   270: invokevirtual getSystemWindowInsetBottom : ()I
    //   273: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   276: astore #15
    //   278: aload #17
    //   280: aload #15
    //   282: invokevirtual dispatchApplyWindowInsets : (Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    //   285: pop
    //   286: goto -> 403
    //   289: aload_0
    //   290: getfield G : Ljava/lang/Object;
    //   293: checkcast android/view/WindowInsets
    //   296: astore #16
    //   298: iload #11
    //   300: iconst_3
    //   301: if_icmpne -> 330
    //   304: aload #16
    //   306: aload #16
    //   308: invokevirtual getSystemWindowInsetLeft : ()I
    //   311: aload #16
    //   313: invokevirtual getSystemWindowInsetTop : ()I
    //   316: iconst_0
    //   317: aload #16
    //   319: invokevirtual getSystemWindowInsetBottom : ()I
    //   322: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   325: astore #15
    //   327: goto -> 363
    //   330: aload #16
    //   332: astore #15
    //   334: iload #11
    //   336: iconst_5
    //   337: if_icmpne -> 363
    //   340: aload #16
    //   342: iconst_0
    //   343: aload #16
    //   345: invokevirtual getSystemWindowInsetTop : ()I
    //   348: aload #16
    //   350: invokevirtual getSystemWindowInsetRight : ()I
    //   353: aload #16
    //   355: invokevirtual getSystemWindowInsetBottom : ()I
    //   358: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   361: astore #15
    //   363: aload #18
    //   365: aload #15
    //   367: invokevirtual getSystemWindowInsetLeft : ()I
    //   370: putfield leftMargin : I
    //   373: aload #18
    //   375: aload #15
    //   377: invokevirtual getSystemWindowInsetTop : ()I
    //   380: putfield topMargin : I
    //   383: aload #18
    //   385: aload #15
    //   387: invokevirtual getSystemWindowInsetRight : ()I
    //   390: putfield rightMargin : I
    //   393: aload #18
    //   395: aload #15
    //   397: invokevirtual getSystemWindowInsetBottom : ()I
    //   400: putfield bottomMargin : I
    //   403: aload_0
    //   404: aload #17
    //   406: invokevirtual B : (Landroid/view/View;)Z
    //   409: ifeq -> 460
    //   412: aload #17
    //   414: iload #7
    //   416: aload #18
    //   418: getfield leftMargin : I
    //   421: isub
    //   422: aload #18
    //   424: getfield rightMargin : I
    //   427: isub
    //   428: ldc_w 1073741824
    //   431: invokestatic makeMeasureSpec : (II)I
    //   434: iload #8
    //   436: aload #18
    //   438: getfield topMargin : I
    //   441: isub
    //   442: aload #18
    //   444: getfield bottomMargin : I
    //   447: isub
    //   448: ldc_w 1073741824
    //   451: invokestatic makeMeasureSpec : (II)I
    //   454: invokevirtual measure : (II)V
    //   457: goto -> 683
    //   460: aload_0
    //   461: aload #17
    //   463: invokevirtual E : (Landroid/view/View;)Z
    //   466: ifeq -> 692
    //   469: getstatic androidx/drawerlayout/widget/DrawerLayout.T : Z
    //   472: ifeq -> 501
    //   475: aload #17
    //   477: invokestatic w : (Landroid/view/View;)F
    //   480: fstore_3
    //   481: aload_0
    //   482: getfield g : F
    //   485: fstore #4
    //   487: fload_3
    //   488: fload #4
    //   490: fcmpl
    //   491: ifeq -> 501
    //   494: aload #17
    //   496: fload #4
    //   498: invokestatic w0 : (Landroid/view/View;F)V
    //   501: aload_0
    //   502: aload #17
    //   504: invokevirtual t : (Landroid/view/View;)I
    //   507: bipush #7
    //   509: iand
    //   510: istore #14
    //   512: iload #14
    //   514: iconst_3
    //   515: if_icmpne -> 524
    //   518: iconst_1
    //   519: istore #11
    //   521: goto -> 527
    //   524: iconst_0
    //   525: istore #11
    //   527: iload #11
    //   529: ifeq -> 537
    //   532: iload #6
    //   534: ifne -> 550
    //   537: iload #11
    //   539: ifne -> 619
    //   542: iload #5
    //   544: ifne -> 550
    //   547: goto -> 619
    //   550: new java/lang/StringBuilder
    //   553: dup
    //   554: invokespecial <init> : ()V
    //   557: astore #15
    //   559: aload #15
    //   561: ldc_w 'Child drawer has absolute gravity '
    //   564: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   567: pop
    //   568: aload #15
    //   570: iload #14
    //   572: invokestatic w : (I)Ljava/lang/String;
    //   575: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   578: pop
    //   579: aload #15
    //   581: ldc_w ' but this '
    //   584: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   587: pop
    //   588: aload #15
    //   590: ldc_w 'DrawerLayout'
    //   593: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   596: pop
    //   597: aload #15
    //   599: ldc_w ' already has a drawer view along that edge'
    //   602: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   605: pop
    //   606: new java/lang/IllegalStateException
    //   609: dup
    //   610: aload #15
    //   612: invokevirtual toString : ()Ljava/lang/String;
    //   615: invokespecial <init> : (Ljava/lang/String;)V
    //   618: athrow
    //   619: iload #11
    //   621: ifeq -> 630
    //   624: iconst_1
    //   625: istore #6
    //   627: goto -> 633
    //   630: iconst_1
    //   631: istore #5
    //   633: aload #17
    //   635: iload_1
    //   636: aload_0
    //   637: getfield h : I
    //   640: aload #18
    //   642: getfield leftMargin : I
    //   645: iadd
    //   646: aload #18
    //   648: getfield rightMargin : I
    //   651: iadd
    //   652: aload #18
    //   654: getfield width : I
    //   657: invokestatic getChildMeasureSpec : (III)I
    //   660: iload_2
    //   661: aload #18
    //   663: getfield topMargin : I
    //   666: aload #18
    //   668: getfield bottomMargin : I
    //   671: iadd
    //   672: aload #18
    //   674: getfield height : I
    //   677: invokestatic getChildMeasureSpec : (III)I
    //   680: invokevirtual measure : (II)V
    //   683: iload #10
    //   685: iconst_1
    //   686: iadd
    //   687: istore #10
    //   689: goto -> 141
    //   692: new java/lang/StringBuilder
    //   695: dup
    //   696: invokespecial <init> : ()V
    //   699: astore #15
    //   701: aload #15
    //   703: ldc_w 'Child '
    //   706: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   709: pop
    //   710: aload #15
    //   712: aload #17
    //   714: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   717: pop
    //   718: aload #15
    //   720: ldc_w ' at index '
    //   723: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   726: pop
    //   727: aload #15
    //   729: iload #10
    //   731: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   734: pop
    //   735: aload #15
    //   737: ldc_w ' does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY'
    //   740: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   743: pop
    //   744: new java/lang/IllegalStateException
    //   747: dup
    //   748: aload #15
    //   750: invokevirtual toString : ()Ljava/lang/String;
    //   753: invokespecial <init> : (Ljava/lang/String;)V
    //   756: athrow
    //   757: return
    //   758: new java/lang/IllegalArgumentException
    //   761: dup
    //   762: ldc_w 'DrawerLayout must be measured with MeasureSpec.EXACTLY.'
    //   765: invokespecial <init> : (Ljava/lang/String;)V
    //   768: athrow
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.a());
    int i = g.h;
    if (i != 0) {
      View view = n(i);
      if (view != null)
        M(view); 
    } 
    i = g.i;
    if (i != 3)
      T(i, 3); 
    i = g.j;
    if (i != 3)
      T(i, 5); 
    i = g.k;
    if (i != 3)
      T(i, 8388611); 
    i = g.l;
    if (i != 3)
      T(i, 8388613); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    R();
  }
  
  protected Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool1;
      f f1 = (f)getChildAt(i).getLayoutParams();
      int k = f1.d;
      boolean bool2 = true;
      if (k == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (k != 2)
        bool2 = false; 
      if (bool1 || bool2) {
        g.h = f1.a;
        break;
      } 
    } 
    g.i = this.s;
    g.j = this.t;
    g.k = this.u;
    g.l = this.v;
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    View view;
    this.l.F(paramMotionEvent);
    this.m.F(paramMotionEvent);
    int i = paramMotionEvent.getAction() & 0xFF;
    boolean bool = false;
    if (i != 0) {
      if (i != 1) {
        if (i != 3)
          return true; 
        i(true);
        this.w = false;
        return true;
      } 
      float f2 = paramMotionEvent.getX();
      float f1 = paramMotionEvent.getY();
      view = this.l.t((int)f2, (int)f1);
      if (view != null && B(view)) {
        f2 -= this.z;
        f1 -= this.A;
        i = this.l.z();
        if (f2 * f2 + f1 * f1 < (i * i)) {
          view = o();
          if (view == null || r(view) == 2) {
            bool = true;
            i(bool);
            return true;
          } 
          i(bool);
          return true;
        } 
      } 
    } else {
      float f1 = view.getX();
      float f2 = view.getY();
      this.z = f1;
      this.A = f2;
      this.w = false;
      return true;
    } 
    bool = true;
    i(bool);
    return true;
  }
  
  View p() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (E(view) && G(view))
        return view; 
    } 
    return null;
  }
  
  public int q(int paramInt) {
    int i = w.B((View)this);
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 8388611) {
          if (paramInt == 8388613) {
            paramInt = this.v;
            if (paramInt != 3)
              return paramInt; 
            if (i == 0) {
              paramInt = this.t;
            } else {
              paramInt = this.s;
            } 
            if (paramInt != 3)
              return paramInt; 
          } 
        } else {
          paramInt = this.u;
          if (paramInt != 3)
            return paramInt; 
          if (i == 0) {
            paramInt = this.s;
          } else {
            paramInt = this.t;
          } 
          if (paramInt != 3)
            return paramInt; 
        } 
      } else {
        paramInt = this.t;
        if (paramInt != 3)
          return paramInt; 
        if (i == 0) {
          paramInt = this.v;
        } else {
          paramInt = this.u;
        } 
        if (paramInt != 3)
          return paramInt; 
      } 
    } else {
      paramInt = this.s;
      if (paramInt != 3)
        return paramInt; 
      if (i == 0) {
        paramInt = this.u;
      } else {
        paramInt = this.v;
      } 
      if (paramInt != 3)
        return paramInt; 
    } 
    return 0;
  }
  
  public int r(View paramView) {
    if (E(paramView))
      return q(((f)paramView.getLayoutParams()).a); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean)
      i(true); 
  }
  
  public void requestLayout() {
    if (!this.q)
      super.requestLayout(); 
  }
  
  public CharSequence s(int paramInt) {
    paramInt = androidx.core.view.e.b(paramInt, w.B((View)this));
    return (paramInt == 3) ? this.E : ((paramInt == 5) ? this.F : null);
  }
  
  public void setDrawerElevation(float paramFloat) {
    this.g = paramFloat;
    for (int i = 0; i < getChildCount(); i++) {
      View view = getChildAt(i);
      if (E(view))
        w.w0(view, this.g); 
    } 
  }
  
  @Deprecated
  public void setDrawerListener(e parame) {
    e e1 = this.x;
    if (e1 != null)
      O(e1); 
    if (parame != null)
      a(parame); 
    this.x = parame;
  }
  
  public void setDrawerLockMode(int paramInt) {
    T(paramInt, 3);
    T(paramInt, 5);
  }
  
  public void setScrimColor(int paramInt) {
    this.i = paramInt;
    invalidate();
  }
  
  public void setStatusBarBackground(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = androidx.core.content.a.c(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    this.B = drawable;
    invalidate();
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    this.B = paramDrawable;
    invalidate();
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    this.B = (Drawable)new ColorDrawable(paramInt);
    invalidate();
  }
  
  int t(View paramView) {
    return androidx.core.view.e.b(((f)paramView.getLayoutParams()).a, w.B((View)this));
  }
  
  float u(View paramView) {
    return ((f)paramView.getLayoutParams()).b;
  }
  
  static {
    boolean bool = true;
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
  }
  
  class a implements l0.f {
    a(DrawerLayout this$0) {}
    
    public boolean a(View param1View, l0.f.a param1a) {
      if (this.a.D(param1View) && this.a.r(param1View) != 2) {
        this.a.f(param1View);
        return true;
      } 
      return false;
    }
  }
  
  class b implements View.OnApplyWindowInsetsListener {
    b(DrawerLayout this$0) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      boolean bool;
      DrawerLayout drawerLayout = (DrawerLayout)param1View;
      if (param1WindowInsets.getSystemWindowInsetTop() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      drawerLayout.S(param1WindowInsets, bool);
      return param1WindowInsets.consumeSystemWindowInsets();
    }
  }
  
  class c extends androidx.core.view.a {
    private final Rect d = new Rect();
    
    c(DrawerLayout this$0) {}
    
    private void n(l0.c param1c, ViewGroup param1ViewGroup) {
      int j = param1ViewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = param1ViewGroup.getChildAt(i);
        if (DrawerLayout.A(view))
          param1c.c(view); 
      } 
    }
    
    private void o(l0.c param1c1, l0.c param1c2) {
      Rect rect = this.d;
      param1c2.n(rect);
      param1c1.X(rect);
      param1c1.A0(param1c2.M());
      param1c1.n0(param1c2.u());
      param1c1.a0(param1c2.p());
      param1c1.e0(param1c2.r());
      param1c1.f0(param1c2.E());
      param1c1.i0(param1c2.G());
      param1c1.U(param1c2.A());
      param1c1.t0(param1c2.K());
      param1c1.a(param1c2.k());
    }
    
    public boolean a(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      List<CharSequence> list;
      CharSequence charSequence;
      if (param1AccessibilityEvent.getEventType() == 32) {
        list = param1AccessibilityEvent.getText();
        View view = this.e.p();
        if (view != null) {
          int i = this.e.t(view);
          charSequence = this.e.s(i);
          if (charSequence != null)
            list.add(charSequence); 
        } 
        return true;
      } 
      return super.a((View)list, (AccessibilityEvent)charSequence);
    }
    
    public void f(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.f(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.drawerlayout.widget.DrawerLayout");
    }
    
    public void g(View param1View, l0.c param1c) {
      if (DrawerLayout.S) {
        super.g(param1View, param1c);
      } else {
        l0.c c1 = l0.c.P(param1c);
        super.g(param1View, c1);
        param1c.v0(param1View);
        ViewParent viewParent = w.H(param1View);
        if (viewParent instanceof View)
          param1c.p0((View)viewParent); 
        o(param1c, c1);
        c1.R();
        n(param1c, (ViewGroup)param1View);
      } 
      param1c.a0("androidx.drawerlayout.widget.DrawerLayout");
      param1c.h0(false);
      param1c.i0(false);
      param1c.S(l0.c.a.e);
      param1c.S(l0.c.a.f);
    }
    
    public boolean i(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return (DrawerLayout.S || DrawerLayout.A(param1View)) ? super.i(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
  }
  
  static final class d extends androidx.core.view.a {
    public void g(View param1View, l0.c param1c) {
      super.g(param1View, param1c);
      if (!DrawerLayout.A(param1View))
        param1c.p0(null); 
    }
  }
  
  public static interface e {
    void a(int param1Int);
    
    void b(View param1View, float param1Float);
    
    void c(View param1View);
    
    void d(View param1View);
  }
  
  public static class f extends ViewGroup.MarginLayoutParams {
    public int a = 0;
    
    float b;
    
    boolean c;
    
    int d;
    
    public f(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public f(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, DrawerLayout.R);
      this.a = typedArray.getInt(0, 0);
      typedArray.recycle();
    }
    
    public f(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public f(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public f(f param1f) {
      super(param1f);
      this.a = param1f.a;
    }
  }
  
  protected static class g extends p0.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    int h = 0;
    
    int i;
    
    int j;
    
    int k;
    
    int l;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.h = param1Parcel.readInt();
      this.i = param1Parcel.readInt();
      this.j = param1Parcel.readInt();
      this.k = param1Parcel.readInt();
      this.l = param1Parcel.readInt();
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.h);
      param1Parcel.writeInt(this.i);
      param1Parcel.writeInt(this.j);
      param1Parcel.writeInt(this.k);
      param1Parcel.writeInt(this.l);
    }
    
    class a implements Parcelable.ClassLoaderCreator<g> {
      public DrawerLayout.g a(Parcel param2Parcel) {
        return new DrawerLayout.g(param2Parcel, null);
      }
      
      public DrawerLayout.g b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new DrawerLayout.g(param2Parcel, param2ClassLoader);
      }
      
      public DrawerLayout.g[] c(int param2Int) {
        return new DrawerLayout.g[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator<g> {
    public DrawerLayout.g a(Parcel param1Parcel) {
      return new DrawerLayout.g(param1Parcel, null);
    }
    
    public DrawerLayout.g b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new DrawerLayout.g(param1Parcel, param1ClassLoader);
    }
    
    public DrawerLayout.g[] c(int param1Int) {
      return new DrawerLayout.g[param1Int];
    }
  }
  
  private class h extends q0.c.c {
    private final int a;
    
    private q0.c b;
    
    private final Runnable c = new a(this);
    
    h(DrawerLayout this$0, int param1Int) {
      this.a = param1Int;
    }
    
    private void n() {
      int i = this.a;
      byte b = 3;
      if (i == 3)
        b = 5; 
      View view = this.d.n(b);
      if (view != null)
        this.d.f(view); 
    }
    
    public int a(View param1View, int param1Int1, int param1Int2) {
      if (this.d.c(param1View, 3))
        return Math.max(-param1View.getWidth(), Math.min(param1Int1, 0)); 
      param1Int2 = this.d.getWidth();
      return Math.max(param1Int2 - param1View.getWidth(), Math.min(param1Int1, param1Int2));
    }
    
    public int b(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public int d(View param1View) {
      return this.d.E(param1View) ? param1View.getWidth() : 0;
    }
    
    public void f(int param1Int1, int param1Int2) {
      View view;
      if ((param1Int1 & 0x1) == 1) {
        view = this.d.n(3);
      } else {
        view = this.d.n(5);
      } 
      if (view != null && this.d.r(view) == 0)
        this.b.b(view, param1Int2); 
    }
    
    public boolean g(int param1Int) {
      return false;
    }
    
    public void h(int param1Int1, int param1Int2) {
      this.d.postDelayed(this.c, 160L);
    }
    
    public void i(View param1View, int param1Int) {
      ((DrawerLayout.f)param1View.getLayoutParams()).c = false;
      n();
    }
    
    public void j(int param1Int) {
      this.d.X(param1Int, this.b.v());
    }
    
    public void k(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      float f;
      param1Int2 = param1View.getWidth();
      if (this.d.c(param1View, 3)) {
        f = (param1Int1 + param1Int2);
      } else {
        f = (this.d.getWidth() - param1Int1);
      } 
      f /= param1Int2;
      this.d.U(param1View, f);
      if (f == 0.0F) {
        param1Int1 = 4;
      } else {
        param1Int1 = 0;
      } 
      param1View.setVisibility(param1Int1);
      this.d.invalidate();
    }
    
    public void l(View param1View, float param1Float1, float param1Float2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   4: aload_1
      //   5: invokevirtual u : (Landroid/view/View;)F
      //   8: fstore_3
      //   9: aload_1
      //   10: invokevirtual getWidth : ()I
      //   13: istore #6
      //   15: aload_0
      //   16: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   19: aload_1
      //   20: iconst_3
      //   21: invokevirtual c : (Landroid/view/View;I)Z
      //   24: ifeq -> 66
      //   27: fload_2
      //   28: fconst_0
      //   29: fcmpl
      //   30: istore #4
      //   32: iload #4
      //   34: ifgt -> 60
      //   37: iload #4
      //   39: ifne -> 52
      //   42: fload_3
      //   43: ldc 0.5
      //   45: fcmpl
      //   46: ifle -> 52
      //   49: goto -> 60
      //   52: iload #6
      //   54: ineg
      //   55: istore #4
      //   57: goto -> 109
      //   60: iconst_0
      //   61: istore #4
      //   63: goto -> 109
      //   66: aload_0
      //   67: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   70: invokevirtual getWidth : ()I
      //   73: istore #5
      //   75: fload_2
      //   76: fconst_0
      //   77: fcmpg
      //   78: iflt -> 102
      //   81: iload #5
      //   83: istore #4
      //   85: fload_2
      //   86: fconst_0
      //   87: fcmpl
      //   88: ifne -> 109
      //   91: iload #5
      //   93: istore #4
      //   95: fload_3
      //   96: ldc 0.5
      //   98: fcmpl
      //   99: ifle -> 109
      //   102: iload #5
      //   104: iload #6
      //   106: isub
      //   107: istore #4
      //   109: aload_0
      //   110: getfield b : Lq0/c;
      //   113: iload #4
      //   115: aload_1
      //   116: invokevirtual getTop : ()I
      //   119: invokevirtual O : (II)Z
      //   122: pop
      //   123: aload_0
      //   124: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   127: invokevirtual invalidate : ()V
      //   130: return
    }
    
    public boolean m(View param1View, int param1Int) {
      return (this.d.E(param1View) && this.d.c(param1View, this.a) && this.d.r(param1View) == 0);
    }
    
    void o() {
      View view;
      int k = this.b.x();
      int i = this.a;
      int j = 0;
      if (i == 3) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        view = this.d.n(3);
        if (view != null)
          j = -view.getWidth(); 
        j += k;
      } else {
        view = this.d.n(5);
        j = this.d.getWidth() - k;
      } 
      if (view != null && ((i != 0 && view.getLeft() < j) || (i == 0 && view.getLeft() > j)) && this.d.r(view) == 0) {
        DrawerLayout.f f = (DrawerLayout.f)view.getLayoutParams();
        this.b.Q(view, j, view.getTop());
        f.c = true;
        this.d.invalidate();
        n();
        this.d.b();
      } 
    }
    
    public void p() {
      this.d.removeCallbacks(this.c);
    }
    
    public void q(q0.c param1c) {
      this.b = param1c;
    }
    
    class a implements Runnable {
      a(DrawerLayout.h this$0) {}
      
      public void run() {
        this.f.o();
      }
    }
  }
  
  class a implements Runnable {
    a(DrawerLayout this$0) {}
    
    public void run() {
      this.f.o();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\drawerlayout\widget\DrawerLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */