package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

public class z implements q {
  private static final z n = new z();
  
  private int f = 0;
  
  private int g = 0;
  
  private boolean h = true;
  
  private boolean i = true;
  
  private Handler j;
  
  private final r k = new r(this);
  
  private Runnable l = new a(this);
  
  a0.a m = new b(this);
  
  public static q k() {
    return n;
  }
  
  static void l(Context paramContext) {
    n.h(paramContext);
  }
  
  public j a() {
    return this.k;
  }
  
  void d() {
    int i = this.g - 1;
    this.g = i;
    if (i == 0)
      this.j.postDelayed(this.l, 700L); 
  }
  
  void e() {
    int i = this.g + 1;
    this.g = i;
    if (i == 1) {
      if (this.h) {
        this.k.h(j.b.ON_RESUME);
        this.h = false;
        return;
      } 
      this.j.removeCallbacks(this.l);
    } 
  }
  
  void f() {
    int i = this.f + 1;
    this.f = i;
    if (i == 1 && this.i) {
      this.k.h(j.b.ON_START);
      this.i = false;
    } 
  }
  
  void g() {
    this.f--;
    j();
  }
  
  void h(Context paramContext) {
    this.j = new Handler();
    this.k.h(j.b.ON_CREATE);
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(new c());
  }
  
  void i() {
    if (this.g == 0) {
      this.h = true;
      this.k.h(j.b.ON_PAUSE);
    } 
  }
  
  void j() {
    if (this.f == 0 && this.h) {
      this.k.h(j.b.ON_STOP);
      this.i = true;
    } 
  }
  
  class a implements Runnable {
    a(z this$0) {}
    
    public void run() {
      this.f.i();
      this.f.j();
    }
  }
  
  class b implements a0.a {
    b(z this$0) {}
    
    public void a() {}
    
    public void b() {
      this.a.f();
    }
    
    public void onResume() {
      this.a.e();
    }
  }
  
  class c extends f {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      if (Build.VERSION.SDK_INT < 29)
        a0.f(param1Activity).h(z.this.m); 
    }
    
    public void onActivityPaused(Activity param1Activity) {
      z.this.d();
    }
    
    public void onActivityPreCreated(Activity param1Activity, Bundle param1Bundle) {
      param1Activity.registerActivityLifecycleCallbacks(new a());
    }
    
    public void onActivityStopped(Activity param1Activity) {
      z.this.g();
    }
    
    class a extends f {
      public void onActivityPostResumed(Activity param2Activity) {
        z.this.e();
      }
      
      public void onActivityPostStarted(Activity param2Activity) {
        z.this.f();
      }
    }
  }
  
  class a extends f {
    public void onActivityPostResumed(Activity param1Activity) {
      z.this.e();
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      z.this.f();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */