package androidx.lifecycle;

import android.annotation.SuppressLint;
import android.app.Application;

public class a extends e0 {
  @SuppressLint({"StaticFieldLeak"})
  private Application c;
  
  public a(Application paramApplication) {
    this.c = paramApplication;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */