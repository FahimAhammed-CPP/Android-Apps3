package androidx.lifecycle;

class FullLifecycleObserverAdapter implements o {
  private final g f;
  
  private final o g;
  
  FullLifecycleObserverAdapter(g paramg, o paramo) {
    this.f = paramg;
    this.g = paramo;
  }
  
  public void d(q paramq, j.b paramb) {
    switch (a.a[paramb.ordinal()]) {
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.f.b(paramq);
        break;
      case 5:
        this.f.h(paramq);
        break;
      case 4:
        this.f.f(paramq);
        break;
      case 3:
        this.f.a(paramq);
        break;
      case 2:
        this.f.g(paramq);
        break;
      case 1:
        this.f.c(paramq);
        break;
    } 
    o o1 = this.g;
    if (o1 != null)
      o1.d(paramq, paramb); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */