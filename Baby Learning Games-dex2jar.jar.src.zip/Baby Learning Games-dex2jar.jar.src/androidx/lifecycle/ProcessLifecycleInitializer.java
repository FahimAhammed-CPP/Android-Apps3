package androidx.lifecycle;

import android.content.Context;
import j1.a;
import java.util.Collections;
import java.util.List;

public final class ProcessLifecycleInitializer implements a<q> {
  public List<Class<? extends a<?>>> a() {
    return Collections.emptyList();
  }
  
  public q c(Context paramContext) {
    n.a(paramContext);
    z.l(paramContext);
    return z.k();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */