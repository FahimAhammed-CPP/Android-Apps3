package androidx.lifecycle;

import android.app.Application;
import java.lang.reflect.InvocationTargetException;

public class f0 {
  private final b a;
  
  private final h0 b;
  
  public f0(h0 paramh0, b paramb) {
    this.a = paramb;
    this.b = paramh0;
  }
  
  public f0(i0 parami0) {
    this(h01, b1);
  }
  
  public <T extends e0> T a(Class<T> paramClass) {
    String str = paramClass.getCanonicalName();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      stringBuilder.append(str);
      return b(stringBuilder.toString(), paramClass);
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public <T extends e0> T b(String paramString, Class<T> paramClass) {
    b b1;
    e0 e0 = this.b.b(paramString);
    if (paramClass.isInstance(e0)) {
      b1 = this.a;
      if (b1 instanceof e)
        ((e)b1).b(e0); 
      return (T)e0;
    } 
    b b2 = this.a;
    if (b2 instanceof c) {
      paramClass = ((c)b2).c((String)b1, (Class)paramClass);
    } else {
      paramClass = b2.a((Class)paramClass);
    } 
    this.b.d((String)b1, (e0)paramClass);
    return (T)paramClass;
  }
  
  public static class a extends d {
    private static a c;
    
    private Application b;
    
    public a(Application param1Application) {
      this.b = param1Application;
    }
    
    public static a c(Application param1Application) {
      if (c == null)
        c = new a(param1Application); 
      return c;
    }
    
    public <T extends e0> T a(Class<T> param1Class) {
      if (a.class.isAssignableFrom(param1Class))
        try {
          return (T)param1Class.getConstructor(new Class[] { Application.class }).newInstance(new Object[] { this.b });
        } catch (NoSuchMethodException noSuchMethodException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot create an instance of ");
          stringBuilder.append(param1Class);
          throw new RuntimeException(stringBuilder.toString(), noSuchMethodException);
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot create an instance of ");
          stringBuilder.append(param1Class);
          throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
        } catch (InstantiationException instantiationException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot create an instance of ");
          stringBuilder.append(param1Class);
          throw new RuntimeException(stringBuilder.toString(), instantiationException);
        } catch (InvocationTargetException invocationTargetException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot create an instance of ");
          stringBuilder.append(param1Class);
          throw new RuntimeException(stringBuilder.toString(), invocationTargetException);
        }  
      return super.a(param1Class);
    }
  }
  
  public static interface b {
    <T extends e0> T a(Class<T> param1Class);
  }
  
  static abstract class c extends e implements b {
    public <T extends e0> T a(Class<T> param1Class) {
      throw new UnsupportedOperationException("create(String, Class<?>) must be called on implementaions of KeyedFactory");
    }
    
    public abstract <T extends e0> T c(String param1String, Class<T> param1Class);
  }
  
  public static class d implements b {
    private static d a;
    
    static d b() {
      if (a == null)
        a = new d(); 
      return a;
    }
    
    public <T extends e0> T a(Class<T> param1Class) {
      try {
        return param1Class.newInstance();
      } catch (InstantiationException instantiationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot create an instance of ");
        stringBuilder.append(param1Class);
        throw new RuntimeException(stringBuilder.toString(), instantiationException);
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot create an instance of ");
        stringBuilder.append(param1Class);
        throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
      } 
    }
  }
  
  static class e {
    void b(e0 param1e0) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */