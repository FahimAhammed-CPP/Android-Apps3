package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;

public class v {
  private Map<String, Integer> a = new HashMap<String, Integer>();
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */