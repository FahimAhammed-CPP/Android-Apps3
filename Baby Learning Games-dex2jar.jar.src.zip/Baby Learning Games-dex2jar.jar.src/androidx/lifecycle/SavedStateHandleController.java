package androidx.lifecycle;

import android.os.Bundle;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.c;
import java.util.Iterator;

final class SavedStateHandleController implements o {
  private final String f;
  
  private boolean g = false;
  
  private final b0 h;
  
  SavedStateHandleController(String paramString, b0 paramb0) {
    this.f = paramString;
    this.h = paramb0;
  }
  
  static void e(e0 parame0, SavedStateRegistry paramSavedStateRegistry, j paramj) {
    SavedStateHandleController savedStateHandleController = parame0.<SavedStateHandleController>c("androidx.lifecycle.savedstate.vm.tag");
    if (savedStateHandleController != null && !savedStateHandleController.l()) {
      savedStateHandleController.i(paramSavedStateRegistry, paramj);
      m(paramSavedStateRegistry, paramj);
    } 
  }
  
  static SavedStateHandleController j(SavedStateRegistry paramSavedStateRegistry, j paramj, String paramString, Bundle paramBundle) {
    SavedStateHandleController savedStateHandleController = new SavedStateHandleController(paramString, b0.a(paramSavedStateRegistry.a(paramString), paramBundle));
    savedStateHandleController.i(paramSavedStateRegistry, paramj);
    m(paramSavedStateRegistry, paramj);
    return savedStateHandleController;
  }
  
  private static void m(SavedStateRegistry paramSavedStateRegistry, j paramj) {
    j.c c = paramj.b();
    if (c == j.c.g || c.b(j.c.i)) {
      paramSavedStateRegistry.e(a.class);
      return;
    } 
    paramj.a(new o(paramj, paramSavedStateRegistry) {
          public void d(q param1q, j.b param1b) {
            if (param1b == j.b.ON_START) {
              this.f.c(this);
              this.g.e(SavedStateHandleController.a.class);
            } 
          }
        });
  }
  
  public void d(q paramq, j.b paramb) {
    if (paramb == j.b.ON_DESTROY) {
      this.g = false;
      paramq.a().c(this);
    } 
  }
  
  void i(SavedStateRegistry paramSavedStateRegistry, j paramj) {
    if (!this.g) {
      this.g = true;
      paramj.a(this);
      paramSavedStateRegistry.d(this.f, this.h.b());
      return;
    } 
    throw new IllegalStateException("Already attached to lifecycleOwner");
  }
  
  b0 k() {
    return this.h;
  }
  
  boolean l() {
    return this.g;
  }
  
  static final class a implements SavedStateRegistry.a {
    public void a(c param1c) {
      if (param1c instanceof i0) {
        h0 h0 = ((i0)param1c).k();
        SavedStateRegistry savedStateRegistry = param1c.c();
        Iterator<String> iterator = h0.c().iterator();
        while (iterator.hasNext())
          SavedStateHandleController.e(h0.b(iterator.next()), savedStateRegistry, param1c.a()); 
        if (!h0.c().isEmpty())
          savedStateRegistry.e(a.class); 
        return;
      } 
      throw new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */