package androidx.lifecycle;

import androidx.fragment.app.Fragment;

@Deprecated
public class g0 {
  @Deprecated
  public static f0 a(Fragment paramFragment) {
    return new f0((i0)paramFragment);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */