package androidx.lifecycle;

public class w<T> extends LiveData<T> {
  public void k(T paramT) {
    super.k(paramT);
  }
  
  public void m(T paramT) {
    super.m(paramT);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */