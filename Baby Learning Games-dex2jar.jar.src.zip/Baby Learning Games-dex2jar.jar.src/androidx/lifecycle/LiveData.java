package androidx.lifecycle;

import java.util.Map;

public abstract class LiveData<T> {
  static final Object k = new Object();
  
  final Object a = new Object();
  
  private n.b<x<? super T>, c> b = new n.b();
  
  int c = 0;
  
  private boolean d;
  
  private volatile Object e;
  
  volatile Object f;
  
  private int g;
  
  private boolean h;
  
  private boolean i;
  
  private final Runnable j;
  
  public LiveData() {
    Object object = k;
    this.f = object;
    this.j = new a(this);
    this.e = object;
    this.g = -1;
  }
  
  static void a(String paramString) {
    if (m.a.f().c())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void c(c paramc) {
    if (!paramc.g)
      return; 
    if (!paramc.k()) {
      paramc.e(false);
      return;
    } 
    int i = paramc.h;
    int j = this.g;
    if (i >= j)
      return; 
    paramc.h = j;
    paramc.f.a((T)this.e);
  }
  
  void b(int paramInt) {
    int i = this.c;
    this.c = paramInt + i;
    if (this.d)
      return; 
    this.d = true;
    while (true) {
      int j;
      try {
        j = this.c;
      } finally {
        this.d = false;
      } 
      if (i > 0 && j == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (paramInt != 0) {
        i();
      } else if (i != 0) {
        j();
      } 
      i = j;
    } 
  }
  
  void d(c paramc) {
    if (this.h) {
      this.i = true;
      return;
    } 
    this.h = true;
    while (true) {
      c c1;
      this.i = false;
      if (paramc != null) {
        c(paramc);
        c1 = null;
      } else {
        n.b.d<Map.Entry> d = this.b.j();
        while (true) {
          c1 = paramc;
          if (d.hasNext()) {
            c((c)((Map.Entry)d.next()).getValue());
            if (this.i) {
              c1 = paramc;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramc = c1;
      if (!this.i) {
        this.h = false;
        return;
      } 
    } 
  }
  
  public T e() {
    Object object = this.e;
    return (T)((object != k) ? object : null);
  }
  
  public boolean f() {
    return (this.c > 0);
  }
  
  public void g(q paramq, x<? super T> paramx) {
    a("observe");
    if (paramq.a().b() == j.c.f)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, paramq, paramx);
    c c = (c)this.b.m(paramx, lifecycleBoundObserver);
    if (c == null || c.j(paramq)) {
      if (c != null)
        return; 
      paramq.a().a(lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void h(x<? super T> paramx) {
    a("observeForever");
    b b1 = new b(this, paramx);
    c c = (c)this.b.m(paramx, b1);
    if (!(c instanceof LifecycleBoundObserver)) {
      if (c != null)
        return; 
      b1.e(true);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  protected void i() {}
  
  protected void j() {}
  
  protected void k(T paramT) {
    synchronized (this.a) {
      boolean bool;
      if (this.f == k) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = paramT;
      if (!bool)
        return; 
      m.a.f().d(this.j);
      return;
    } 
  }
  
  public void l(x<? super T> paramx) {
    a("removeObserver");
    c c = (c)this.b.n(paramx);
    if (c == null)
      return; 
    c.i();
    c.e(false);
  }
  
  protected void m(T paramT) {
    a("setValue");
    this.g++;
    this.e = paramT;
    d(null);
  }
  
  class LifecycleBoundObserver extends c implements o {
    final q j;
    
    LifecycleBoundObserver(LiveData this$0, q param1q, x<? super T> param1x) {
      super(this$0, param1x);
      this.j = param1q;
    }
    
    public void d(q param1q, j.b param1b) {
      j.c c1 = this.j.a().b();
      if (c1 == j.c.f) {
        this.k.l(this.f);
        return;
      } 
      param1b = null;
      while (param1b != c1) {
        e(k());
        j.c c3 = this.j.a().b();
        j.c c2 = c1;
        c1 = c3;
      } 
    }
    
    void i() {
      this.j.a().c(this);
    }
    
    boolean j(q param1q) {
      return (this.j == param1q);
    }
    
    boolean k() {
      return this.j.a().b().b(j.c.i);
    }
  }
  
  class a implements Runnable {
    a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.f.a) {
        Object object = this.f.f;
        this.f.f = LiveData.k;
        this.f.m(object);
        return;
      } 
    }
  }
  
  private class b extends c {
    b(LiveData this$0, x<? super T> param1x) {
      super(this$0, param1x);
    }
    
    boolean k() {
      return true;
    }
  }
  
  private abstract class c {
    final x<? super T> f;
    
    boolean g;
    
    int h = -1;
    
    c(LiveData this$0, x<? super T> param1x) {
      this.f = param1x;
    }
    
    void e(boolean param1Boolean) {
      byte b;
      if (param1Boolean == this.g)
        return; 
      this.g = param1Boolean;
      LiveData liveData = this.i;
      if (param1Boolean) {
        b = 1;
      } else {
        b = -1;
      } 
      liveData.b(b);
      if (this.g)
        this.i.d(this); 
    }
    
    void i() {}
    
    boolean j(q param1q) {
      return false;
    }
    
    abstract boolean k();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */