package androidx.lifecycle;

import w5.c0;

public abstract class l implements c0 {}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */