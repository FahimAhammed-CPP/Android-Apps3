package androidx.lifecycle;

import android.os.Handler;

public class d0 {
  private final r a;
  
  private final Handler b;
  
  private a c;
  
  public d0(q paramq) {
    this.a = new r(paramq);
    this.b = new Handler();
  }
  
  private void f(j.b paramb) {
    a a2 = this.c;
    if (a2 != null)
      a2.run(); 
    a a1 = new a(this.a, paramb);
    this.c = a1;
    this.b.postAtFrontOfQueue(a1);
  }
  
  public j a() {
    return this.a;
  }
  
  public void b() {
    f(j.b.ON_START);
  }
  
  public void c() {
    f(j.b.ON_CREATE);
  }
  
  public void d() {
    f(j.b.ON_STOP);
    f(j.b.ON_DESTROY);
  }
  
  public void e() {
    f(j.b.ON_START);
  }
  
  static class a implements Runnable {
    private final r f;
    
    final j.b g;
    
    private boolean h = false;
    
    a(r param1r, j.b param1b) {
      this.f = param1r;
      this.g = param1b;
    }
    
    public void run() {
      if (!this.h) {
        this.f.h(this.g);
        this.h = true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */