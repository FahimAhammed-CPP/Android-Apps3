package androidx.lifecycle;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class h0 {
  private final HashMap<String, e0> a = new HashMap<String, e0>();
  
  public final void a() {
    Iterator<e0> iterator = this.a.values().iterator();
    while (iterator.hasNext())
      ((e0)iterator.next()).a(); 
    this.a.clear();
  }
  
  final e0 b(String paramString) {
    return this.a.get(paramString);
  }
  
  Set<String> c() {
    return new HashSet<String>(this.a.keySet());
  }
  
  final void d(String paramString, e0 parame0) {
    e0 e01 = this.a.put(paramString, parame0);
    if (e01 != null)
      e01.d(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */