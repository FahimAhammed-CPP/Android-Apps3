package androidx.lifecycle;

import android.annotation.SuppressLint;
import android.app.Application;
import android.os.Bundle;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.c;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

public final class c0 extends f0.c {
  private static final Class<?>[] f = new Class[] { Application.class, b0.class };
  
  private static final Class<?>[] g = new Class[] { b0.class };
  
  private final Application a;
  
  private final f0.b b;
  
  private final Bundle c;
  
  private final j d;
  
  private final SavedStateRegistry e;
  
  @SuppressLint({"LambdaLast"})
  public c0(Application paramApplication, c paramc, Bundle paramBundle) {
    f0.d d;
    this.e = paramc.c();
    this.d = paramc.a();
    this.c = paramBundle;
    this.a = paramApplication;
    if (paramApplication != null) {
      d = f0.a.c(paramApplication);
    } else {
      d = f0.d.b();
    } 
    this.b = d;
  }
  
  private static <T> Constructor<T> d(Class<T> paramClass, Class<?>[] paramArrayOfClass) {
    for (Constructor<T> constructor : paramClass.getConstructors()) {
      if (Arrays.equals((Object[])paramArrayOfClass, (Object[])constructor.getParameterTypes()))
        return constructor; 
    } 
    return null;
  }
  
  public <T extends e0> T a(Class<T> paramClass) {
    String str = paramClass.getCanonicalName();
    if (str != null)
      return c(str, paramClass); 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  void b(e0 parame0) {
    SavedStateHandleController.e(parame0, this.e, this.d);
  }
  
  public <T extends e0> T c(String paramString, Class<T> paramClass) {
    Constructor<T> constructor;
    StringBuilder stringBuilder;
    boolean bool = a.class.isAssignableFrom(paramClass);
    if (bool && this.a != null) {
      constructor = d(paramClass, f);
    } else {
      constructor = d(paramClass, g);
    } 
    if (constructor == null)
      return this.b.a(paramClass); 
    SavedStateHandleController savedStateHandleController = SavedStateHandleController.j(this.e, this.d, paramString, this.c);
    if (bool)
      try {
        Application application = this.a;
        if (application != null) {
          e0 e02 = (e0)constructor.newInstance(new Object[] { application, savedStateHandleController.k() });
          e02.e("androidx.lifecycle.savedstate.vm.tag", savedStateHandleController);
          return (T)e02;
        } 
        e0 e01 = (e0)constructor.newInstance(new Object[] { savedStateHandleController.k() });
        e01.e("androidx.lifecycle.savedstate.vm.tag", savedStateHandleController);
        return (T)e01;
      } catch (IllegalAccessException illegalAccessException) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to access ");
        stringBuilder.append(paramClass);
        throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
      } catch (InstantiationException instantiationException) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("A ");
        stringBuilder.append(paramClass);
        stringBuilder.append(" cannot be instantiated.");
        throw new RuntimeException(stringBuilder.toString(), instantiationException);
      } catch (InvocationTargetException invocationTargetException) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("An exception happened in constructor of ");
        stringBuilder.append(paramClass);
        throw new RuntimeException(stringBuilder.toString(), invocationTargetException.getCause());
      }  
    e0 e0 = stringBuilder.newInstance(new Object[] { savedStateHandleController.k() });
    e0.e("androidx.lifecycle.savedstate.vm.tag", savedStateHandleController);
    return (T)e0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */