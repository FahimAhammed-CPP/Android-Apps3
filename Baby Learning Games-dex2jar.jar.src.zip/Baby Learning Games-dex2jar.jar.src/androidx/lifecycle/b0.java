package androidx.lifecycle;

import android.os.Binder;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import androidx.savedstate.SavedStateRegistry;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class b0 {
  private static final Class[] e = new Class[] { 
      boolean.class, boolean[].class, double.class, double[].class, int.class, int[].class, long.class, long[].class, String.class, String[].class, 
      Binder.class, Bundle.class, byte.class, byte[].class, char.class, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, float.class, 
      float[].class, Parcelable.class, Parcelable[].class, Serializable.class, short.class, short[].class, SparseArray.class, Size.class, SizeF.class };
  
  final Map<String, Object> a = new HashMap<String, Object>();
  
  final Map<String, SavedStateRegistry.b> b = new HashMap<String, SavedStateRegistry.b>();
  
  private final Map<String, Object> c = new HashMap<String, Object>();
  
  private final SavedStateRegistry.b d = new a(this);
  
  public b0() {}
  
  public b0(Map<String, Object> paramMap) {}
  
  static b0 a(Bundle paramBundle1, Bundle paramBundle2) {
    if (paramBundle1 == null && paramBundle2 == null)
      return new b0(); 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (paramBundle2 != null)
      for (String str : paramBundle2.keySet())
        hashMap.put(str, paramBundle2.get(str));  
    if (paramBundle1 == null)
      return new b0((Map)hashMap); 
    ArrayList<String> arrayList1 = paramBundle1.getParcelableArrayList("keys");
    ArrayList arrayList = paramBundle1.getParcelableArrayList("values");
    if (arrayList1 != null && arrayList != null && arrayList1.size() == arrayList.size()) {
      for (int i = 0; i < arrayList1.size(); i++)
        hashMap.put(arrayList1.get(i), arrayList.get(i)); 
      return new b0((Map)hashMap);
    } 
    throw new IllegalStateException("Invalid bundle passed as restored state");
  }
  
  private static void d(Object paramObject) {
    if (paramObject == null)
      return; 
    Class[] arrayOfClass = e;
    int j = arrayOfClass.length;
    for (int i = 0; i < j; i++) {
      if (arrayOfClass[i].isInstance(paramObject))
        return; 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't put value with type ");
    stringBuilder.append(paramObject.getClass());
    stringBuilder.append(" into saved state");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  SavedStateRegistry.b b() {
    return this.d;
  }
  
  public <T> void c(String paramString, T paramT) {
    d(paramT);
    w<T> w = (w)this.c.get(paramString);
    if (w != null) {
      w.m(paramT);
      return;
    } 
    this.a.put(paramString, paramT);
  }
  
  class a implements SavedStateRegistry.b {
    a(b0 this$0) {}
    
    public Bundle a() {
      for (Map.Entry<?, ?> entry : (new HashMap<Object, Object>(this.a.b)).entrySet()) {
        Bundle bundle1 = ((SavedStateRegistry.b)entry.getValue()).a();
        this.a.c((String)entry.getKey(), bundle1);
      } 
      Set<String> set = this.a.a.keySet();
      ArrayList<String> arrayList = new ArrayList(set.size());
      ArrayList arrayList1 = new ArrayList(arrayList.size());
      for (String str : set) {
        arrayList.add(str);
        arrayList1.add(this.a.a.get(str));
      } 
      Bundle bundle = new Bundle();
      bundle.putParcelableArrayList("keys", arrayList);
      bundle.putParcelableArrayList("values", arrayList1);
      return bundle;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */