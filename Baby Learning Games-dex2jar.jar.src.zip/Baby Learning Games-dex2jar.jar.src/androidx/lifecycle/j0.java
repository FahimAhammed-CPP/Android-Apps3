package androidx.lifecycle;

import android.view.View;
import w0.a;

public class j0 {
  public static void a(View paramView, q paramq) {
    paramView.setTag(a.a, paramq);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */