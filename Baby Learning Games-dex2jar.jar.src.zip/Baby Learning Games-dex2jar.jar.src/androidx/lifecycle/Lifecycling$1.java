package androidx.lifecycle;

class Lifecycling$1 implements o {
  public void d(q paramq, j.b paramb) {
    this.f.d(paramq, paramb);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\Lifecycling$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */