package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;

public class a0 extends Fragment {
  private a f;
  
  static void a(Activity paramActivity, j.b paramb) {
    if (paramActivity instanceof s) {
      ((s)paramActivity).a().h(paramb);
      return;
    } 
    if (paramActivity instanceof q) {
      j j = ((q)paramActivity).a();
      if (j instanceof r)
        ((r)j).h(paramb); 
    } 
  }
  
  private void b(j.b paramb) {
    if (Build.VERSION.SDK_INT < 29)
      a(getActivity(), paramb); 
  }
  
  private void c(a parama) {
    if (parama != null)
      parama.a(); 
  }
  
  private void d(a parama) {
    if (parama != null)
      parama.onResume(); 
  }
  
  private void e(a parama) {
    if (parama != null)
      parama.b(); 
  }
  
  static a0 f(Activity paramActivity) {
    return (a0)paramActivity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
  }
  
  public static void g(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 29)
      b.registerIn(paramActivity); 
    FragmentManager fragmentManager = paramActivity.getFragmentManager();
    if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
      fragmentManager.beginTransaction().add(new a0(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
      fragmentManager.executePendingTransactions();
    } 
  }
  
  void h(a parama) {
    this.f = parama;
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
    c(this.f);
    b(j.b.ON_CREATE);
  }
  
  public void onDestroy() {
    super.onDestroy();
    b(j.b.ON_DESTROY);
    this.f = null;
  }
  
  public void onPause() {
    super.onPause();
    b(j.b.ON_PAUSE);
  }
  
  public void onResume() {
    super.onResume();
    d(this.f);
    b(j.b.ON_RESUME);
  }
  
  public void onStart() {
    super.onStart();
    e(this.f);
    b(j.b.ON_START);
  }
  
  public void onStop() {
    super.onStop();
    b(j.b.ON_STOP);
  }
  
  static interface a {
    void a();
    
    void b();
    
    void onResume();
  }
  
  static class b implements Application.ActivityLifecycleCallbacks {
    static void registerIn(Activity param1Activity) {
      param1Activity.registerActivityLifecycleCallbacks(new b());
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityDestroyed(Activity param1Activity) {}
    
    public void onActivityPaused(Activity param1Activity) {}
    
    public void onActivityPostCreated(Activity param1Activity, Bundle param1Bundle) {
      a0.a(param1Activity, j.b.ON_CREATE);
    }
    
    public void onActivityPostResumed(Activity param1Activity) {
      a0.a(param1Activity, j.b.ON_RESUME);
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      a0.a(param1Activity, j.b.ON_START);
    }
    
    public void onActivityPreDestroyed(Activity param1Activity) {
      a0.a(param1Activity, j.b.ON_DESTROY);
    }
    
    public void onActivityPrePaused(Activity param1Activity) {
      a0.a(param1Activity, j.b.ON_PAUSE);
    }
    
    public void onActivityPreStopped(Activity param1Activity) {
      a0.a(param1Activity, j.b.ON_STOP);
    }
    
    public void onActivityResumed(Activity param1Activity) {}
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {}
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */