package androidx.lifecycle;

import e5.k;
import e5.l;
import o5.a;
import p5.d;
import w5.i;

public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 implements o {
  public void d(q paramq, j.b paramb) {
    i i1;
    d.e(paramq, "source");
    d.e(paramb, "event");
    if (paramb == j.b.f(this.h)) {
      this.g.c(this);
      i1 = this.f;
      Object object = this.i;
      try {
        k.a a1 = k.f;
        Object object1 = k.a(object.a());
      } finally {
        object = null;
        k.a a1 = k.f;
      } 
    } 
    if (i1 == j.b.ON_DESTROY) {
      this.g.c(this);
      i i2 = this.f;
      m m = new m();
      k.a a1 = k.f;
      i2.f(k.a(l.a(m)));
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */