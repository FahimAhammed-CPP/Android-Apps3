package androidx.lifecycle;

import p5.d;
import w5.z0;

final class LifecycleController$observer$1 implements o {
  public final void d(q paramq, j.b paramb) {
    d.e(paramq, "source");
    d.e(paramb, "<anonymous parameter 1>");
    j j = paramq.a();
    d.d(j, "source.lifecycle");
    if (j.b() != j.c.f) {
      j j1 = paramq.a();
      d.d(j1, "source.lifecycle");
      if (j1.b().compareTo(k.b(null)) < 0) {
        k.a(null);
        throw null;
      } 
      k.a(null);
      throw null;
    } 
    z0.a.a(this.f, null, 1, null);
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\LifecycleController$observer$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */