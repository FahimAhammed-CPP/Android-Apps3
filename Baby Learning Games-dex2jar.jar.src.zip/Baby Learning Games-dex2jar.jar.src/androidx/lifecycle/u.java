package androidx.lifecycle;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class u {
  private static Map<Class<?>, Integer> a = new HashMap<Class<?>, Integer>();
  
  private static Map<Class<?>, List<Constructor<? extends h>>> b = new HashMap<Class<?>, List<Constructor<? extends h>>>();
  
  private static h a(Constructor<? extends h> paramConstructor, Object paramObject) {
    try {
      return paramConstructor.newInstance(new Object[] { paramObject });
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw new RuntimeException(instantiationException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } 
  }
  
  private static Constructor<? extends h> b(Class<?> paramClass) {
    try {
      String str1;
      Package package_ = paramClass.getPackage();
      String str2 = paramClass.getCanonicalName();
      if (package_ != null) {
        str1 = package_.getName();
      } else {
        str1 = "";
      } 
      if (!str1.isEmpty())
        str2 = str2.substring(str1.length() + 1); 
      str2 = c(str2);
      if (str1.isEmpty()) {
        str1 = str2;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str1);
        stringBuilder.append(".");
        stringBuilder.append(str2);
        str1 = stringBuilder.toString();
      } 
      Constructor<?> constructor = Class.forName(str1).getDeclaredConstructor(new Class[] { paramClass });
      if (!constructor.isAccessible())
        constructor.setAccessible(true); 
      return (Constructor)constructor;
    } catch (ClassNotFoundException classNotFoundException) {
      return null;
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new RuntimeException(noSuchMethodException);
    } 
  }
  
  public static String c(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString.replace(".", "_"));
    stringBuilder.append("_LifecycleAdapter");
    return stringBuilder.toString();
  }
  
  private static int d(Class<?> paramClass) {
    Integer integer = a.get(paramClass);
    if (integer != null)
      return integer.intValue(); 
    int i = g(paramClass);
    a.put(paramClass, Integer.valueOf(i));
    return i;
  }
  
  private static boolean e(Class<?> paramClass) {
    return (paramClass != null && p.class.isAssignableFrom(paramClass));
  }
  
  static o f(Object paramObject) {
    boolean bool1 = paramObject instanceof o;
    boolean bool2 = paramObject instanceof g;
    if (bool1 && bool2)
      return new FullLifecycleObserverAdapter((g)paramObject, (o)paramObject); 
    if (bool2)
      return new FullLifecycleObserverAdapter((g)paramObject, null); 
    if (bool1)
      return (o)paramObject; 
    Class<?> clazz = paramObject.getClass();
    if (d(clazz) == 2) {
      List<Constructor<? extends h>> list = b.get(clazz);
      int j = list.size();
      int i = 0;
      if (j == 1)
        return new SingleGeneratedAdapterObserver(a(list.get(0), paramObject)); 
      h[] arrayOfH = new h[list.size()];
      while (i < list.size()) {
        arrayOfH[i] = a(list.get(i), paramObject);
        i++;
      } 
      return new CompositeGeneratedAdaptersObserver(arrayOfH);
    } 
    return new ReflectiveGenericLifecycleObserver(paramObject);
  }
  
  private static int g(Class<?> paramClass) {
    ArrayList<Constructor<? extends h>> arrayList;
    if (paramClass.getCanonicalName() == null)
      return 1; 
    Constructor<? extends h> constructor = b(paramClass);
    if (constructor != null) {
      b.put(paramClass, Collections.singletonList(constructor));
      return 2;
    } 
    if (b.c.d(paramClass))
      return 1; 
    Class<?> clazz = paramClass.getSuperclass();
    constructor = null;
    if (e(clazz)) {
      if (d(clazz) == 1)
        return 1; 
      arrayList = new ArrayList(b.get(clazz));
    } 
    for (Class<?> clazz1 : paramClass.getInterfaces()) {
      if (e(clazz1)) {
        if (d(clazz1) == 1)
          return 1; 
        ArrayList<Constructor<? extends h>> arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList1.addAll(b.get(clazz1));
        arrayList = arrayList1;
      } 
    } 
    if (arrayList != null) {
      b.put(paramClass, arrayList);
      return 2;
    } 
    return 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycl\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */