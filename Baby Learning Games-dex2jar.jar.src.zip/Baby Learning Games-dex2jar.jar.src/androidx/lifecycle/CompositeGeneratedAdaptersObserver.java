package androidx.lifecycle;

class CompositeGeneratedAdaptersObserver implements o {
  private final h[] f;
  
  CompositeGeneratedAdaptersObserver(h[] paramArrayOfh) {
    this.f = paramArrayOfh;
  }
  
  public void d(q paramq, j.b paramb) {
    v v = new v();
    h[] arrayOfH = this.f;
    int j = arrayOfH.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++)
      arrayOfH[i].a(paramq, paramb, false, v); 
    arrayOfH = this.f;
    j = arrayOfH.length;
    for (i = bool; i < j; i++)
      arrayOfH[i].a(paramq, paramb, true, v); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */