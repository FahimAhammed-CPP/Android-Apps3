package androidx.lifecycle;

@Deprecated
class ReflectiveGenericLifecycleObserver implements o {
  private final Object f;
  
  private final b.a g;
  
  ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.f = paramObject;
    this.g = b.c.c(paramObject.getClass());
  }
  
  public void d(q paramq, j.b paramb) {
    this.g.a(paramq, paramb, this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */