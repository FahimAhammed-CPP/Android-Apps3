package androidx.lifecycle;

import android.annotation.SuppressLint;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import n.b;

public class r extends j {
  private n.a<p, a> b = new n.a();
  
  private j.c c;
  
  private final WeakReference<q> d;
  
  private int e = 0;
  
  private boolean f = false;
  
  private boolean g = false;
  
  private ArrayList<j.c> h = new ArrayList<j.c>();
  
  private final boolean i;
  
  public r(q paramq) {
    this(paramq, true);
  }
  
  private r(q paramq, boolean paramBoolean) {
    this.d = new WeakReference<q>(paramq);
    this.c = j.c.g;
    this.i = paramBoolean;
  }
  
  private void d(q paramq) {
    Iterator<Map.Entry> iterator = this.b.descendingIterator();
    while (iterator.hasNext() && !this.g) {
      Map.Entry entry = iterator.next();
      a a1 = (a)entry.getValue();
      while (a1.a.compareTo(this.c) > 0 && !this.g && this.b.contains(entry.getKey())) {
        j.b b = j.b.b(a1.a);
        if (b != null) {
          n(b.d());
          a1.a(paramq, b);
          m();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event down from ");
        stringBuilder.append(a1.a);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  private j.c e(p paramp) {
    j.c c1;
    Map.Entry entry = this.b.o(paramp);
    ArrayList<j.c> arrayList = null;
    if (entry != null) {
      j.c c2 = ((a)entry.getValue()).a;
    } else {
      entry = null;
    } 
    if (!this.h.isEmpty()) {
      arrayList = this.h;
      c1 = arrayList.get(arrayList.size() - 1);
    } 
    return k(k(this.c, (j.c)entry), c1);
  }
  
  @SuppressLint({"RestrictedApi"})
  private void f(String paramString) {
    if (this.i) {
      if (m.a.f().c())
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Method ");
      stringBuilder.append(paramString);
      stringBuilder.append(" must be called on the main thread");
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  private void g(q paramq) {
    b.d<Map.Entry> d = this.b.j();
    while (d.hasNext() && !this.g) {
      Map.Entry entry = d.next();
      a a1 = (a)entry.getValue();
      while (a1.a.compareTo(this.c) < 0 && !this.g && this.b.contains(entry.getKey())) {
        n(a1.a);
        j.b b = j.b.e(a1.a);
        if (b != null) {
          a1.a(paramq, b);
          m();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event up from ");
        stringBuilder.append(a1.a);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  private boolean i() {
    if (this.b.size() == 0)
      return true; 
    j.c c1 = ((a)this.b.h().getValue()).a;
    j.c c2 = ((a)this.b.k().getValue()).a;
    return (c1 == c2 && this.c == c2);
  }
  
  static j.c k(j.c paramc1, j.c paramc2) {
    j.c c1 = paramc1;
    if (paramc2 != null) {
      c1 = paramc1;
      if (paramc2.compareTo(paramc1) < 0)
        c1 = paramc2; 
    } 
    return c1;
  }
  
  private void l(j.c paramc) {
    if (this.c == paramc)
      return; 
    this.c = paramc;
    if (this.f || this.e != 0) {
      this.g = true;
      return;
    } 
    this.f = true;
    p();
    this.f = false;
  }
  
  private void m() {
    ArrayList<j.c> arrayList = this.h;
    arrayList.remove(arrayList.size() - 1);
  }
  
  private void n(j.c paramc) {
    this.h.add(paramc);
  }
  
  private void p() {
    q q = this.d.get();
    if (q != null) {
      while (!i()) {
        this.g = false;
        if (this.c.compareTo(((a)this.b.h().getValue()).a) < 0)
          d(q); 
        Map.Entry entry = this.b.k();
        if (!this.g && entry != null && this.c.compareTo(((a)entry.getValue()).a) > 0)
          g(q); 
      } 
      this.g = false;
      return;
    } 
    throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
  }
  
  public void a(p paramp) {
    boolean bool;
    f("addObserver");
    j.c c2 = this.c;
    j.c c1 = j.c.f;
    if (c2 != c1)
      c1 = j.c.g; 
    a a1 = new a(paramp, c1);
    if ((a)this.b.m(paramp, a1) != null)
      return; 
    q q = this.d.get();
    if (q == null)
      return; 
    if (this.e != 0 || this.f) {
      bool = true;
    } else {
      bool = false;
    } 
    c1 = e(paramp);
    this.e++;
    while (a1.a.compareTo(c1) < 0 && this.b.contains(paramp)) {
      n(a1.a);
      j.b b = j.b.e(a1.a);
      if (b != null) {
        a1.a(q, b);
        m();
        j.c c3 = e(paramp);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("no event up from ");
      stringBuilder.append(a1.a);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    if (!bool)
      p(); 
    this.e--;
  }
  
  public j.c b() {
    return this.c;
  }
  
  public void c(p paramp) {
    f("removeObserver");
    this.b.n(paramp);
  }
  
  public void h(j.b paramb) {
    f("handleLifecycleEvent");
    l(paramb.d());
  }
  
  @Deprecated
  public void j(j.c paramc) {
    f("markState");
    o(paramc);
  }
  
  public void o(j.c paramc) {
    f("setCurrentState");
    l(paramc);
  }
  
  static class a {
    j.c a;
    
    o b;
    
    a(p param1p, j.c param1c) {
      this.b = u.f(param1p);
      this.a = param1c;
    }
    
    void a(q param1q, j.b param1b) {
      j.c c1 = param1b.d();
      this.a = r.k(this.a, c1);
      this.b.d(param1q, param1b);
      this.a = c1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */