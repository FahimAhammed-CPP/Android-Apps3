package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Deprecated
final class b {
  static b c = new b();
  
  private final Map<Class<?>, a> a = new HashMap<Class<?>, a>();
  
  private final Map<Class<?>, Boolean> b = new HashMap<Class<?>, Boolean>();
  
  private a a(Class<?> paramClass, Method[] paramArrayOfMethod) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge Z and I\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private Method[] b(Class<?> paramClass) {
    try {
      return paramClass.getDeclaredMethods();
    } catch (NoClassDefFoundError noClassDefFoundError) {
      throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", noClassDefFoundError);
    } 
  }
  
  private void e(Map<b, j.b> paramMap, b paramb, j.b paramb1, Class<?> paramClass) {
    j.b b1 = paramMap.get(paramb);
    if (b1 == null || paramb1 == b1) {
      if (b1 == null)
        paramMap.put(paramb, paramb1); 
      return;
    } 
    Method method = paramb.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Method ");
    stringBuilder.append(method.getName());
    stringBuilder.append(" in ");
    stringBuilder.append(paramClass.getName());
    stringBuilder.append(" already declared with different @OnLifecycleEvent value: previous value ");
    stringBuilder.append(b1);
    stringBuilder.append(", new value ");
    stringBuilder.append(paramb1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  a c(Class<?> paramClass) {
    a a = this.a.get(paramClass);
    return (a != null) ? a : a(paramClass, null);
  }
  
  boolean d(Class<?> paramClass) {
    Boolean bool = this.b.get(paramClass);
    if (bool != null)
      return bool.booleanValue(); 
    Method[] arrayOfMethod = b(paramClass);
    int j = arrayOfMethod.length;
    for (int i = 0; i < j; i++) {
      if ((y)arrayOfMethod[i].<y>getAnnotation(y.class) != null) {
        a(paramClass, arrayOfMethod);
        return true;
      } 
    } 
    this.b.put(paramClass, Boolean.FALSE);
    return false;
  }
  
  @Deprecated
  static class a {
    final Map<j.b, List<b.b>> a;
    
    final Map<b.b, j.b> b;
    
    a(Map<b.b, j.b> param1Map) {
      this.b = param1Map;
      this.a = new HashMap<j.b, List<b.b>>();
      for (Map.Entry<b.b, j.b> entry : param1Map.entrySet()) {
        j.b b = (j.b)entry.getValue();
        List<b.b> list2 = this.a.get(b);
        List<b.b> list1 = list2;
        if (list2 == null) {
          list1 = new ArrayList();
          this.a.put(b, list1);
        } 
        list1.add((b.b)entry.getKey());
      } 
    }
    
    private static void b(List<b.b> param1List, q param1q, j.b param1b, Object param1Object) {
      if (param1List != null) {
        int i;
        for (i = param1List.size() - 1; i >= 0; i--)
          ((b.b)param1List.get(i)).a(param1q, param1b, param1Object); 
      } 
    }
    
    void a(q param1q, j.b param1b, Object param1Object) {
      b(this.a.get(param1b), param1q, param1b, param1Object);
      b(this.a.get(j.b.ON_ANY), param1q, param1b, param1Object);
    }
  }
  
  @Deprecated
  static final class b {
    final int a;
    
    final Method b;
    
    b(int param1Int, Method param1Method) {
      this.a = param1Int;
      this.b = param1Method;
      param1Method.setAccessible(true);
    }
    
    void a(q param1q, j.b param1b, Object param1Object) {
      try {
        int i = this.a;
        if (i != 0) {
          if (i != 1) {
            if (i != 2)
              return; 
            this.b.invoke(param1Object, new Object[] { param1q, param1b });
            return;
          } 
          this.b.invoke(param1Object, new Object[] { param1q });
          return;
        } 
        this.b.invoke(param1Object, new Object[0]);
        return;
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException("Failed to call observer method", invocationTargetException.getCause());
      } catch (IllegalAccessException illegalAccessException) {
        throw new RuntimeException(illegalAccessException);
      } 
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      param1Object = param1Object;
      return (this.a == ((b)param1Object).a && this.b.getName().equals(((b)param1Object).b.getName()));
    }
    
    public int hashCode() {
      return this.a * 31 + this.b.getName().hashCode();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */