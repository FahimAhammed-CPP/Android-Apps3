package androidx.lifecycle;

import h5.g;
import p5.d;
import w5.d1;

public final class LifecycleCoroutineScopeImpl extends l implements o {
  private final j f;
  
  private final g g;
  
  public void d(q paramq, j.b paramb) {
    d.e(paramq, "source");
    d.e(paramb, "event");
    if (i().b().compareTo(j.c.f) <= 0) {
      i().c(this);
      d1.d(e(), null, 1, null);
    } 
  }
  
  public g e() {
    return this.g;
  }
  
  public j i() {
    return this.f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\LifecycleCoroutineScopeImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */