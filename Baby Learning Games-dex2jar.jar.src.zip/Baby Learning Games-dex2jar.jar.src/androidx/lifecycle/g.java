package androidx.lifecycle;

interface g extends p {
  void a(q paramq);
  
  void b(q paramq);
  
  void c(q paramq);
  
  void f(q paramq);
  
  void g(q paramq);
  
  void h(q paramq);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */