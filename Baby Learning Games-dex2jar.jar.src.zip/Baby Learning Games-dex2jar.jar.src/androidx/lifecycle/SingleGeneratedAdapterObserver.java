package androidx.lifecycle;

class SingleGeneratedAdapterObserver implements o {
  private final h f;
  
  SingleGeneratedAdapterObserver(h paramh) {
    this.f = paramh;
  }
  
  public void d(q paramq, j.b paramb) {
    this.f.a(paramq, paramb, false, null);
    this.f.a(paramq, paramb, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */