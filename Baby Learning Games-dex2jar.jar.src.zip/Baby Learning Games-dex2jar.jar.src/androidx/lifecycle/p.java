package androidx.lifecycle;

public interface p {}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\lifecycle\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */