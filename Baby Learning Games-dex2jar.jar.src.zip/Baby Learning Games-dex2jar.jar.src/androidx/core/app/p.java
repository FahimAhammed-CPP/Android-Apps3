package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class p implements Iterable<Intent> {
  private final ArrayList<Intent> f = new ArrayList<Intent>();
  
  private final Context g;
  
  private p(Context paramContext) {
    this.g = paramContext;
  }
  
  public static p l(Context paramContext) {
    return new p(paramContext);
  }
  
  public p h(Intent paramIntent) {
    this.f.add(paramIntent);
    return this;
  }
  
  public p i(Intent paramIntent) {
    ComponentName componentName2 = paramIntent.getComponent();
    ComponentName componentName1 = componentName2;
    if (componentName2 == null)
      componentName1 = paramIntent.resolveActivity(this.g.getPackageManager()); 
    if (componentName1 != null)
      k(componentName1); 
    h(paramIntent);
    return this;
  }
  
  @Deprecated
  public Iterator<Intent> iterator() {
    return this.f.iterator();
  }
  
  public p j(Activity paramActivity) {
    Intent intent1;
    if (paramActivity instanceof a) {
      intent1 = ((a)paramActivity).j();
    } else {
      intent1 = null;
    } 
    Intent intent2 = intent1;
    if (intent1 == null)
      intent2 = g.a(paramActivity); 
    if (intent2 != null) {
      ComponentName componentName2 = intent2.getComponent();
      ComponentName componentName1 = componentName2;
      if (componentName2 == null)
        componentName1 = intent2.resolveActivity(this.g.getPackageManager()); 
      k(componentName1);
      h(intent2);
    } 
    return this;
  }
  
  public p k(ComponentName paramComponentName) {
    int i = this.f.size();
    try {
      for (Intent intent = g.b(this.g, paramComponentName); intent != null; intent = g.b(this.g, intent.getComponent()))
        this.f.add(i, intent); 
      return this;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
      throw new IllegalArgumentException(nameNotFoundException);
    } 
  }
  
  public void m() {
    n(null);
  }
  
  public void n(Bundle paramBundle) {
    if (!this.f.isEmpty()) {
      ArrayList<Intent> arrayList = this.f;
      Intent[] arrayOfIntent = arrayList.<Intent>toArray(new Intent[arrayList.size()]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      if (!androidx.core.content.a.d(this.g, arrayOfIntent, paramBundle)) {
        Intent intent = new Intent(arrayOfIntent[arrayOfIntent.length - 1]);
        intent.addFlags(268435456);
        this.g.startActivity(intent);
      } 
      return;
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
  }
  
  public static interface a {
    Intent j();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\app\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */