package androidx.core.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.core.view.f;
import androidx.lifecycle.a0;
import androidx.lifecycle.j;
import androidx.lifecycle.q;
import androidx.lifecycle.r;
import s.g;

public class f extends Activity implements q, f.a {
  private g<Class<Object>, Object> f = new g();
  
  private r g = new r(this);
  
  public j a() {
    return (j)this.g;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && f.d(view, paramKeyEvent)) ? true : f.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && f.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public boolean f(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  @SuppressLint({"RestrictedApi"})
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    a0.g(this);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.g.j(j.c.h);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */