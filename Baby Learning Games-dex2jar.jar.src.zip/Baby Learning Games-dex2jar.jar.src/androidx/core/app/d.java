package androidx.core.app;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Binder;
import android.os.Build;

public final class d {
  public static int a(Context paramContext, int paramInt, String paramString1, String paramString2) {
    if (Build.VERSION.SDK_INT >= 29) {
      AppOpsManager appOpsManager = a.c(paramContext);
      int i = a.a(appOpsManager, paramString1, Binder.getCallingUid(), paramString2);
      return (i != 0) ? i : a.a(appOpsManager, paramString1, paramInt, a.b(paramContext));
    } 
    return b(paramContext, paramString1, paramString2);
  }
  
  public static int b(Context paramContext, String paramString1, String paramString2) {
    return ((AppOpsManager)paramContext.getSystemService(AppOpsManager.class)).noteProxyOpNoThrow(paramString1, paramString2);
  }
  
  public static String c(String paramString) {
    return AppOpsManager.permissionToOp(paramString);
  }
  
  static class a {
    static int a(AppOpsManager param1AppOpsManager, String param1String1, int param1Int, String param1String2) {
      return (param1AppOpsManager == null) ? 1 : param1AppOpsManager.checkOpNoThrow(param1String1, param1Int, param1String2);
    }
    
    static String b(Context param1Context) {
      return param1Context.getOpPackageName();
    }
    
    static AppOpsManager c(Context param1Context) {
      return (AppOpsManager)param1Context.getSystemService(AppOpsManager.class);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */