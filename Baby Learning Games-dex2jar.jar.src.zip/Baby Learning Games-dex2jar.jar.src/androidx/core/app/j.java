package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import h0.a;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import s.b;

class j implements h {
  private final Context a;
  
  private final Notification.Builder b;
  
  private final i.d c;
  
  private RemoteViews d;
  
  private RemoteViews e;
  
  private final List<Bundle> f;
  
  private final Bundle g;
  
  private int h;
  
  private RemoteViews i;
  
  j(i.d paramd) {
    boolean bool;
    List<String> list;
    this.f = new ArrayList<Bundle>();
    this.g = new Bundle();
    this.c = paramd;
    this.a = paramd.a;
    if (Build.VERSION.SDK_INT >= 26) {
      this.b = new Notification.Builder(paramd.a, paramd.K);
    } else {
      this.b = new Notification.Builder(paramd.a);
    } 
    Notification notification = paramd.R;
    Notification.Builder builder = this.b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramd.i).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(paramd.e).setContentText(paramd.f).setContentInfo(paramd.k).setContentIntent(paramd.g).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramd.h;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(paramd.j).setNumber(paramd.l).setProgress(paramd.t, paramd.u, paramd.v);
    this.b.setSubText(paramd.q).setUsesChronometer(paramd.o).setPriority(paramd.m);
    Iterator<i.a> iterator = paramd.b.iterator();
    while (iterator.hasNext())
      b(iterator.next()); 
    Bundle bundle = paramd.D;
    if (bundle != null)
      this.g.putAll(bundle); 
    int i = Build.VERSION.SDK_INT;
    this.d = paramd.H;
    this.e = paramd.I;
    this.b.setShowWhen(paramd.n);
    this.b.setLocalOnly(paramd.z).setGroup(paramd.w).setGroupSummary(paramd.x).setSortKey(paramd.y);
    this.h = paramd.O;
    this.b.setCategory(paramd.C).setColor(paramd.E).setVisibility(paramd.F).setPublicVersion(paramd.G).setSound(notification.sound, notification.audioAttributes);
    if (i < 28) {
      list = e(f(paramd.c), paramd.U);
    } else {
      list = paramd.U;
    } 
    if (list != null && !list.isEmpty())
      for (String str : list)
        this.b.addPerson(str);  
    this.i = paramd.J;
    if (paramd.d.size() > 0) {
      Bundle bundle2 = paramd.c().getBundle("android.car.EXTENSIONS");
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle2 = new Bundle(bundle1);
      Bundle bundle3 = new Bundle();
      for (i = 0; i < paramd.d.size(); i++)
        bundle3.putBundle(Integer.toString(i), k.a(paramd.d.get(i))); 
      bundle1.putBundle("invisible_actions", bundle3);
      bundle2.putBundle("invisible_actions", bundle3);
      paramd.c().putBundle("android.car.EXTENSIONS", bundle1);
      this.g.putBundle("android.car.EXTENSIONS", bundle2);
    } 
    i = Build.VERSION.SDK_INT;
    Icon icon = paramd.T;
    if (icon != null)
      this.b.setSmallIcon(icon); 
    if (i >= 24) {
      this.b.setExtras(paramd.D).setRemoteInputHistory(paramd.s);
      RemoteViews remoteViews = paramd.H;
      if (remoteViews != null)
        this.b.setCustomContentView(remoteViews); 
      remoteViews = paramd.I;
      if (remoteViews != null)
        this.b.setCustomBigContentView(remoteViews); 
      remoteViews = paramd.J;
      if (remoteViews != null)
        this.b.setCustomHeadsUpContentView(remoteViews); 
    } 
    if (i >= 26) {
      this.b.setBadgeIconType(paramd.L).setSettingsText(paramd.r).setShortcutId(paramd.M).setTimeoutAfter(paramd.N).setGroupAlertBehavior(paramd.O);
      if (paramd.B)
        this.b.setColorized(paramd.A); 
      if (!TextUtils.isEmpty(paramd.K))
        this.b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (i >= 28)
      for (m m : paramd.c)
        this.b.addPerson(m.h());  
    i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      this.b.setAllowSystemGeneratedContextualActions(paramd.Q);
      this.b.setBubbleMetadata(i.c.a(null));
    } 
    if (a.c()) {
      int k = paramd.P;
      if (k != 0)
        this.b.setForegroundServiceBehavior(k); 
    } 
    if (paramd.S) {
      if (this.c.x) {
        this.h = 2;
      } else {
        this.h = 1;
      } 
      this.b.setVibrate(null);
      this.b.setSound(null);
      int k = notification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
      notification.defaults = k;
      this.b.setDefaults(k);
      if (i >= 26) {
        if (TextUtils.isEmpty(this.c.w))
          this.b.setGroup("silent"); 
        this.b.setGroupAlertBehavior(this.h);
      } 
    } 
  }
  
  private void b(i.a parama) {
    Bundle bundle;
    IconCompat iconCompat = parama.d();
    if (iconCompat != null) {
      Icon icon = iconCompat.n();
    } else {
      iconCompat = null;
    } 
    Notification.Action.Builder builder = new Notification.Action.Builder((Icon)iconCompat, parama.h(), parama.a());
    if (parama.e() != null) {
      RemoteInput[] arrayOfRemoteInput = n.b(parama.e());
      int m = arrayOfRemoteInput.length;
      for (int k = 0; k < m; k++)
        builder.addRemoteInput(arrayOfRemoteInput[k]); 
    } 
    if (parama.c() != null) {
      bundle = new Bundle(parama.c());
    } else {
      bundle = new Bundle();
    } 
    bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
    int i = Build.VERSION.SDK_INT;
    if (i >= 24)
      builder.setAllowGeneratedReplies(parama.b()); 
    bundle.putInt("android.support.action.semanticAction", parama.f());
    if (i >= 28)
      builder.setSemanticAction(parama.f()); 
    if (i >= 29)
      builder.setContextual(parama.i()); 
    bundle.putBoolean("android.support.action.showsUserInterface", parama.g());
    builder.addExtras(bundle);
    this.b.addAction(builder.build());
  }
  
  private static List<String> e(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    b b = new b(paramList1.size() + paramList2.size());
    b.addAll(paramList1);
    b.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)b);
  }
  
  private static List<String> f(List<m> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<m> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((m)iterator.next()).g()); 
    return arrayList;
  }
  
  private void g(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults = paramNotification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
  }
  
  public Notification.Builder a() {
    return this.b;
  }
  
  public Notification c() {
    RemoteViews remoteViews;
    i.e e = this.c.p;
    if (e != null)
      e.b(this); 
    if (e != null) {
      remoteViews = e.e(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = d();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else {
      remoteViews = this.c.H;
      if (remoteViews != null)
        notification.contentView = remoteViews; 
    } 
    if (e != null) {
      remoteViews = e.d(this);
      if (remoteViews != null)
        notification.bigContentView = remoteViews; 
    } 
    if (e != null) {
      remoteViews = this.c.p.f(this);
      if (remoteViews != null)
        notification.headsUpContentView = remoteViews; 
    } 
    if (e != null) {
      Bundle bundle = i.a(notification);
      if (bundle != null)
        e.a(bundle); 
    } 
    return notification;
  }
  
  protected Notification d() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26)
      return this.b.build(); 
    if (i >= 24) {
      Notification notification1 = this.b.build();
      if (this.h != 0) {
        if (notification1.getGroup() != null && (notification1.flags & 0x200) != 0 && this.h == 2)
          g(notification1); 
        if (notification1.getGroup() != null && (notification1.flags & 0x200) == 0 && this.h == 1)
          g(notification1); 
      } 
      return notification1;
    } 
    this.b.setExtras(this.g);
    Notification notification = this.b.build();
    RemoteViews remoteViews = this.d;
    if (remoteViews != null)
      notification.contentView = remoteViews; 
    remoteViews = this.e;
    if (remoteViews != null)
      notification.bigContentView = remoteViews; 
    remoteViews = this.i;
    if (remoteViews != null)
      notification.headsUpContentView = remoteViews; 
    if (this.h != 0) {
      if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.h == 2)
        g(notification); 
      if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.h == 1)
        g(notification); 
    } 
    return notification;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */