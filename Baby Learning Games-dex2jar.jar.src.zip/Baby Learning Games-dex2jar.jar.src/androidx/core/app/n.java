package androidx.core.app;

import android.app.RemoteInput;

public final class n {
  static RemoteInput a(n paramn) {
    throw null;
  }
  
  static RemoteInput[] b(n[] paramArrayOfn) {
    if (paramArrayOfn == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfn.length];
    for (int i = 0; i < paramArrayOfn.length; i++) {
      n n1 = paramArrayOfn[i];
      arrayOfRemoteInput[i] = a(null);
    } 
    return arrayOfRemoteInput;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */