package androidx.core.app;

import android.app.Activity;
import android.os.Build;
import android.os.Handler;
import androidx.core.content.a;

public class a extends a {
  public static void g(Activity paramActivity) {
    paramActivity.finishAffinity();
  }
  
  public static void h(Activity paramActivity) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 28) {
      paramActivity.recreate();
      return;
    } 
    if (i <= 23) {
      (new Handler(paramActivity.getMainLooper())).post(new a(paramActivity));
      return;
    } 
    if (!c.i(paramActivity))
      paramActivity.recreate(); 
  }
  
  class a implements Runnable {
    a(a this$0) {}
    
    public void run() {
      if (!this.f.isFinishing() && !c.i(this.f))
        this.f.recreate(); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */