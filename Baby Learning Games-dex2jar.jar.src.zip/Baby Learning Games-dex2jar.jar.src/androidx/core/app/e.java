package androidx.core.app;

import android.os.Bundle;
import android.os.IBinder;

public final class e {
  public static IBinder a(Bundle paramBundle, String paramString) {
    return paramBundle.getBinder(paramString);
  }
  
  public static void b(Bundle paramBundle, String paramString, IBinder paramIBinder) {
    paramBundle.putBinder(paramString, paramIBinder);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */