package androidx.core.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContentInfo;
import android.view.Display;
import android.view.KeyEvent;
import android.view.OnReceiveContentListener;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class w {
  private static final AtomicInteger a = new AtomicInteger(1);
  
  private static WeakHashMap<View, b0> b = null;
  
  private static Field c;
  
  private static boolean d = false;
  
  private static final int[] e = new int[] { 
      a0.b.b, a0.b.c, a0.b.n, a0.b.y, a0.b.B, a0.b.C, a0.b.D, a0.b.E, a0.b.F, a0.b.G, 
      a0.b.d, a0.b.e, a0.b.f, a0.b.g, a0.b.h, a0.b.i, a0.b.j, a0.b.k, a0.b.l, a0.b.m, 
      a0.b.o, a0.b.p, a0.b.q, a0.b.r, a0.b.s, a0.b.t, a0.b.u, a0.b.v, a0.b.w, a0.b.x, 
      a0.b.z, a0.b.A };
  
  private static final t f = v.f;
  
  private static final e g = new e();
  
  @SuppressLint({"InlinedApi"})
  public static int A(View paramView) {
    return (Build.VERSION.SDK_INT >= 26) ? o.b(paramView) : 0;
  }
  
  public static void A0(View paramView, r paramr) {
    m.u(paramView, paramr);
  }
  
  public static int B(View paramView) {
    return i.d(paramView);
  }
  
  public static void B0(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    i.k(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static int C(View paramView) {
    return h.d(paramView);
  }
  
  public static void C0(View paramView, boolean paramBoolean) {
    n0().g(paramView, Boolean.valueOf(paramBoolean));
  }
  
  public static int D(View paramView) {
    return h.e(paramView);
  }
  
  public static void D0(View paramView, int paramInt1, int paramInt2) {
    n.d(paramView, paramInt1, paramInt2);
  }
  
  public static String[] E(View paramView) {
    return (Build.VERSION.SDK_INT >= 31) ? s.a(paramView) : (String[])paramView.getTag(a0.b.N);
  }
  
  public static void E0(View paramView, CharSequence paramCharSequence) {
    H0().g(paramView, paramCharSequence);
  }
  
  public static int F(View paramView) {
    return i.e(paramView);
  }
  
  public static void F0(View paramView, String paramString) {
    m.v(paramView, paramString);
  }
  
  public static int G(View paramView) {
    return i.f(paramView);
  }
  
  private static void G0(View paramView) {
    if (z(paramView) == 0)
      y0(paramView, 1); 
    for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
      if (z((View)viewParent) == 4) {
        y0(paramView, 2);
        return;
      } 
    } 
  }
  
  public static ViewParent H(View paramView) {
    return h.f(paramView);
  }
  
  private static f<CharSequence> H0() {
    return new c(a0.b.P, CharSequence.class, 64, 30);
  }
  
  public static g0 I(View paramView) {
    return n.a(paramView);
  }
  
  public static void I0(View paramView) {
    m.z(paramView);
  }
  
  public static CharSequence J(View paramView) {
    return H0().f(paramView);
  }
  
  public static String K(View paramView) {
    return m.k(paramView);
  }
  
  @Deprecated
  public static int L(View paramView) {
    return h.g(paramView);
  }
  
  public static float M(View paramView) {
    return m.m(paramView);
  }
  
  public static boolean N(View paramView) {
    return g.a(paramView);
  }
  
  public static boolean O(View paramView) {
    return h.h(paramView);
  }
  
  public static boolean P(View paramView) {
    return h.i(paramView);
  }
  
  public static boolean Q(View paramView) {
    Boolean bool = b().f(paramView);
    return (bool != null && bool.booleanValue());
  }
  
  public static boolean R(View paramView) {
    return k.b(paramView);
  }
  
  public static boolean S(View paramView) {
    return k.c(paramView);
  }
  
  public static boolean T(View paramView) {
    return m.p(paramView);
  }
  
  public static boolean U(View paramView) {
    return i.g(paramView);
  }
  
  public static boolean V(View paramView) {
    Boolean bool = n0().f(paramView);
    return (bool != null && bool.booleanValue());
  }
  
  static void X(View paramView, int paramInt) {
    boolean bool;
    AccessibilityEvent accessibilityEvent;
    AccessibilityManager accessibilityManager = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
    if (!accessibilityManager.isEnabled())
      return; 
    if (p(paramView) != null && paramView.getVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = o(paramView);
    char c = ' ';
    if (i != 0 || bool) {
      accessibilityEvent = AccessibilityEvent.obtain();
      if (!bool)
        c = 'ࠀ'; 
      accessibilityEvent.setEventType(c);
      k.g(accessibilityEvent, paramInt);
      if (bool) {
        accessibilityEvent.getText().add(p(paramView));
        G0(paramView);
      } 
      paramView.sendAccessibilityEventUnchecked(accessibilityEvent);
      return;
    } 
    if (paramInt == 32) {
      AccessibilityEvent accessibilityEvent1 = AccessibilityEvent.obtain();
      paramView.onInitializeAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.setEventType(32);
      k.g(accessibilityEvent1, paramInt);
      accessibilityEvent1.setSource(paramView);
      paramView.onPopulateAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.getText().add(p(paramView));
      accessibilityEvent.sendAccessibilityEvent(accessibilityEvent1);
      return;
    } 
    if (paramView.getParent() != null) {
      ViewParent viewParent = paramView.getParent();
      try {
        k.e(viewParent, paramView, paramView, paramInt);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramView.getParent().getClass().getSimpleName());
        stringBuilder.append(" does not fully implement ViewParent");
        Log.e("ViewCompat", stringBuilder.toString(), abstractMethodError);
        return;
      } 
    } 
  }
  
  public static void Y(View paramView, int paramInt) {
    paramView.offsetLeftAndRight(paramInt);
  }
  
  public static void Z(View paramView, int paramInt) {
    paramView.offsetTopAndBottom(paramInt);
  }
  
  public static g0 a0(View paramView, g0 paramg0) {
    WindowInsets windowInsets = paramg0.v();
    if (windowInsets != null) {
      WindowInsets windowInsets1 = l.b(paramView, windowInsets);
      if (!windowInsets1.equals(windowInsets))
        return g0.x(windowInsets1, paramView); 
    } 
    return paramg0;
  }
  
  private static f<Boolean> b() {
    return new d(a0.b.J, Boolean.class, 28);
  }
  
  public static void b0(View paramView, l0.c paramc) {
    paramView.onInitializeAccessibilityNodeInfo(paramc.B0());
  }
  
  public static int c(View paramView, CharSequence paramCharSequence, l0.f paramf) {
    int i = r(paramView, paramCharSequence);
    if (i != -1)
      d(paramView, new l0.c.a(i, paramCharSequence, paramf)); 
    return i;
  }
  
  private static f<CharSequence> c0() {
    return new b(a0.b.K, CharSequence.class, 8, 28);
  }
  
  private static void d(View paramView, l0.c.a parama) {
    j(paramView);
    j0(parama.b(), paramView);
    q(paramView).add(parama);
    X(paramView, 0);
  }
  
  public static boolean d0(View paramView, int paramInt, Bundle paramBundle) {
    return h.j(paramView, paramInt, paramBundle);
  }
  
  public static b0 e(View paramView) {
    if (b == null)
      b = new WeakHashMap<View, b0>(); 
    b0 b02 = b.get(paramView);
    b0 b01 = b02;
    if (b02 == null) {
      b01 = new b0(paramView);
      b.put(paramView, b01);
    } 
    return b01;
  }
  
  public static c e0(View paramView, c paramc) {
    if (Log.isLoggable("ViewCompat", 3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("performReceiveContent: ");
      stringBuilder.append(paramc);
      stringBuilder.append(", view=");
      stringBuilder.append(paramView.getClass().getSimpleName());
      stringBuilder.append("[");
      stringBuilder.append(paramView.getId());
      stringBuilder.append("]");
      Log.d("ViewCompat", stringBuilder.toString());
    } 
    if (Build.VERSION.SDK_INT >= 31)
      return s.b(paramView, paramc); 
    s s = (s)paramView.getTag(a0.b.M);
    if (s != null) {
      paramc = s.a(paramView, paramc);
      return (paramc == null) ? null : x(paramView).a(paramc);
    } 
    return x(paramView).a(paramc);
  }
  
  public static g0 f(View paramView, g0 paramg0, Rect paramRect) {
    return m.b(paramView, paramg0, paramRect);
  }
  
  public static void f0(View paramView) {
    h.k(paramView);
  }
  
  public static g0 g(View paramView, g0 paramg0) {
    WindowInsets windowInsets = paramg0.v();
    if (windowInsets != null) {
      WindowInsets windowInsets1 = l.a(paramView, windowInsets);
      if (!windowInsets1.equals(windowInsets))
        return g0.x(windowInsets1, paramView); 
    } 
    return paramg0;
  }
  
  public static void g0(View paramView, Runnable paramRunnable) {
    h.m(paramView, paramRunnable);
  }
  
  static boolean h(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : v.a(paramView).b(paramView, paramKeyEvent);
  }
  
  @SuppressLint({"LambdaLast"})
  public static void h0(View paramView, Runnable paramRunnable, long paramLong) {
    h.n(paramView, paramRunnable, paramLong);
  }
  
  static boolean i(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : v.a(paramView).f(paramKeyEvent);
  }
  
  public static void i0(View paramView, int paramInt) {
    j0(paramInt, paramView);
    X(paramView, 0);
  }
  
  static void j(View paramView) {
    a a2 = l(paramView);
    a a1 = a2;
    if (a2 == null)
      a1 = new a(); 
    o0(paramView, a1);
  }
  
  private static void j0(int paramInt, View paramView) {
    List<l0.c.a> list = q(paramView);
    for (int i = 0; i < list.size(); i++) {
      if (((l0.c.a)list.get(i)).b() == paramInt) {
        list.remove(i);
        return;
      } 
    } 
  }
  
  public static int k() {
    return i.a();
  }
  
  public static void k0(View paramView, l0.c.a parama, CharSequence paramCharSequence, l0.f paramf) {
    if (paramf == null && paramCharSequence == null) {
      i0(paramView, parama.b());
      return;
    } 
    d(paramView, parama.a(paramCharSequence, paramf));
  }
  
  public static a l(View paramView) {
    View.AccessibilityDelegate accessibilityDelegate = m(paramView);
    return (accessibilityDelegate == null) ? null : ((accessibilityDelegate instanceof a.a) ? ((a.a)accessibilityDelegate).a : new a(accessibilityDelegate));
  }
  
  public static void l0(View paramView) {
    l.c(paramView);
  }
  
  private static View.AccessibilityDelegate m(View paramView) {
    return (Build.VERSION.SDK_INT >= 29) ? q.a(paramView) : n(paramView);
  }
  
  public static void m0(View paramView, @SuppressLint({"ContextFirst"}) Context paramContext, int[] paramArrayOfint, AttributeSet paramAttributeSet, TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 29)
      q.c(paramView, paramContext, paramArrayOfint, paramAttributeSet, paramTypedArray, paramInt1, paramInt2); 
  }
  
  private static View.AccessibilityDelegate n(View paramView) {
    // Byte code:
    //   0: getstatic androidx/core/view/w.d : Z
    //   3: ifeq -> 8
    //   6: aconst_null
    //   7: areturn
    //   8: getstatic androidx/core/view/w.c : Ljava/lang/reflect/Field;
    //   11: ifnonnull -> 41
    //   14: ldc android/view/View
    //   16: ldc_w 'mAccessibilityDelegate'
    //   19: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   22: astore_1
    //   23: aload_1
    //   24: putstatic androidx/core/view/w.c : Ljava/lang/reflect/Field;
    //   27: aload_1
    //   28: iconst_1
    //   29: invokevirtual setAccessible : (Z)V
    //   32: goto -> 41
    //   35: iconst_1
    //   36: putstatic androidx/core/view/w.d : Z
    //   39: aconst_null
    //   40: areturn
    //   41: getstatic androidx/core/view/w.c : Ljava/lang/reflect/Field;
    //   44: aload_0
    //   45: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   48: astore_0
    //   49: aload_0
    //   50: instanceof android/view/View$AccessibilityDelegate
    //   53: ifeq -> 63
    //   56: aload_0
    //   57: checkcast android/view/View$AccessibilityDelegate
    //   60: astore_0
    //   61: aload_0
    //   62: areturn
    //   63: aconst_null
    //   64: areturn
    //   65: iconst_1
    //   66: putstatic androidx/core/view/w.d : Z
    //   69: aconst_null
    //   70: areturn
    //   71: astore_0
    //   72: goto -> 35
    //   75: astore_0
    //   76: goto -> 65
    // Exception table:
    //   from	to	target	type
    //   14	32	71	finally
    //   41	61	75	finally
  }
  
  private static f<Boolean> n0() {
    return new a(a0.b.O, Boolean.class, 28);
  }
  
  public static int o(View paramView) {
    return k.a(paramView);
  }
  
  public static void o0(View paramView, a parama) {
    View.AccessibilityDelegate accessibilityDelegate;
    a a1 = parama;
    if (parama == null) {
      a1 = parama;
      if (m(paramView) instanceof a.a)
        a1 = new a(); 
    } 
    if (a1 == null) {
      parama = null;
    } else {
      accessibilityDelegate = a1.d();
    } 
    paramView.setAccessibilityDelegate(accessibilityDelegate);
  }
  
  public static CharSequence p(View paramView) {
    return c0().f(paramView);
  }
  
  public static void p0(View paramView, boolean paramBoolean) {
    b().g(paramView, Boolean.valueOf(paramBoolean));
  }
  
  private static List<l0.c.a> q(View paramView) {
    int i = a0.b.H;
    ArrayList<l0.c.a> arrayList2 = (ArrayList)paramView.getTag(i);
    ArrayList<l0.c.a> arrayList1 = arrayList2;
    if (arrayList2 == null) {
      arrayList1 = new ArrayList();
      paramView.setTag(i, arrayList1);
    } 
    return arrayList1;
  }
  
  public static void q0(View paramView, int paramInt) {
    k.f(paramView, paramInt);
  }
  
  private static int r(View paramView, CharSequence paramCharSequence) {
    List<l0.c.a> list = q(paramView);
    int i;
    for (i = 0; i < list.size(); i++) {
      if (TextUtils.equals(paramCharSequence, ((l0.c.a)list.get(i)).c()))
        return ((l0.c.a)list.get(i)).b(); 
    } 
    int j = -1;
    i = 0;
    while (true) {
      int[] arrayOfInt = e;
      if (i < arrayOfInt.length && j == -1) {
        int n = arrayOfInt[i];
        int m = 0;
        int k = 1;
        while (m < list.size()) {
          byte b;
          if (((l0.c.a)list.get(m)).b() != n) {
            b = 1;
          } else {
            b = 0;
          } 
          k &= b;
          m++;
        } 
        if (k != 0)
          j = n; 
        i++;
        continue;
      } 
      break;
    } 
    return j;
  }
  
  public static void r0(View paramView, CharSequence paramCharSequence) {
    c0().g(paramView, paramCharSequence);
    if (paramCharSequence != null) {
      g.a(paramView);
      return;
    } 
    g.d(paramView);
  }
  
  public static ColorStateList s(View paramView) {
    return m.g(paramView);
  }
  
  public static void s0(View paramView, Drawable paramDrawable) {
    h.q(paramView, paramDrawable);
  }
  
  public static PorterDuff.Mode t(View paramView) {
    return m.h(paramView);
  }
  
  public static void t0(View paramView, ColorStateList paramColorStateList) {
    m.q(paramView, paramColorStateList);
  }
  
  public static Rect u(View paramView) {
    return j.a(paramView);
  }
  
  public static void u0(View paramView, PorterDuff.Mode paramMode) {
    m.r(paramView, paramMode);
  }
  
  public static Display v(View paramView) {
    return i.b(paramView);
  }
  
  public static void v0(View paramView, Rect paramRect) {
    j.c(paramView, paramRect);
  }
  
  public static float w(View paramView) {
    return m.i(paramView);
  }
  
  public static void w0(View paramView, float paramFloat) {
    m.s(paramView, paramFloat);
  }
  
  private static t x(View paramView) {
    return (paramView instanceof t) ? (t)paramView : f;
  }
  
  public static void x0(View paramView, boolean paramBoolean) {
    h.r(paramView, paramBoolean);
  }
  
  public static boolean y(View paramView) {
    return h.b(paramView);
  }
  
  public static void y0(View paramView, int paramInt) {
    h.s(paramView, paramInt);
  }
  
  public static int z(View paramView) {
    return h.c(paramView);
  }
  
  public static void z0(View paramView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 26)
      o.l(paramView, paramInt); 
  }
  
  class a extends f<Boolean> {
    a(w this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    Boolean i(View param1View) {
      return Boolean.valueOf(w.p.d(param1View));
    }
    
    void j(View param1View, Boolean param1Boolean) {
      w.p.i(param1View, param1Boolean.booleanValue());
    }
    
    boolean k(Boolean param1Boolean1, Boolean param1Boolean2) {
      return a(param1Boolean1, param1Boolean2) ^ true;
    }
  }
  
  class b extends f<CharSequence> {
    b(w this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence i(View param1View) {
      return w.p.b(param1View);
    }
    
    void j(View param1View, CharSequence param1CharSequence) {
      w.p.h(param1View, param1CharSequence);
    }
    
    boolean k(CharSequence param1CharSequence1, CharSequence param1CharSequence2) {
      return TextUtils.equals(param1CharSequence1, param1CharSequence2) ^ true;
    }
  }
  
  class c extends f<CharSequence> {
    c(w this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    CharSequence i(View param1View) {
      return w.r.a(param1View);
    }
    
    void j(View param1View, CharSequence param1CharSequence) {
      w.r.b(param1View, param1CharSequence);
    }
    
    boolean k(CharSequence param1CharSequence1, CharSequence param1CharSequence2) {
      return TextUtils.equals(param1CharSequence1, param1CharSequence2) ^ true;
    }
  }
  
  class d extends f<Boolean> {
    d(w this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    Boolean i(View param1View) {
      return Boolean.valueOf(w.p.c(param1View));
    }
    
    void j(View param1View, Boolean param1Boolean) {
      w.p.g(param1View, param1Boolean.booleanValue());
    }
    
    boolean k(Boolean param1Boolean1, Boolean param1Boolean2) {
      return a(param1Boolean1, param1Boolean2) ^ true;
    }
  }
  
  static class e implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {
    private final WeakHashMap<View, Boolean> f = new WeakHashMap<View, Boolean>();
    
    private void b(View param1View, boolean param1Boolean) {
      boolean bool;
      if (param1View.getVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1Boolean != bool) {
        byte b;
        if (bool) {
          b = 16;
        } else {
          b = 32;
        } 
        w.X(param1View, b);
        this.f.put(param1View, Boolean.valueOf(bool));
      } 
    }
    
    private void c(View param1View) {
      param1View.getViewTreeObserver().addOnGlobalLayoutListener(this);
    }
    
    private void e(View param1View) {
      w.h.o(param1View.getViewTreeObserver(), this);
    }
    
    void a(View param1View) {
      boolean bool;
      WeakHashMap<View, Boolean> weakHashMap = this.f;
      if (param1View.getVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      weakHashMap.put(param1View, Boolean.valueOf(bool));
      param1View.addOnAttachStateChangeListener(this);
      if (w.k.b(param1View))
        c(param1View); 
    }
    
    void d(View param1View) {
      this.f.remove(param1View);
      param1View.removeOnAttachStateChangeListener(this);
      e(param1View);
    }
    
    public void onGlobalLayout() {
      if (Build.VERSION.SDK_INT < 28)
        for (Map.Entry<View, Boolean> entry : this.f.entrySet())
          b((View)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());  
    }
    
    public void onViewAttachedToWindow(View param1View) {
      c(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
  
  static abstract class f<T> {
    private final int a;
    
    private final Class<T> b;
    
    private final int c;
    
    private final int d;
    
    f(int param1Int1, Class<T> param1Class, int param1Int2) {
      this(param1Int1, param1Class, 0, param1Int2);
    }
    
    f(int param1Int1, Class<T> param1Class, int param1Int2, int param1Int3) {
      this.a = param1Int1;
      this.b = param1Class;
      this.d = param1Int2;
      this.c = param1Int3;
    }
    
    private boolean b() {
      return true;
    }
    
    private boolean c() {
      return (Build.VERSION.SDK_INT >= this.c);
    }
    
    boolean a(Boolean param1Boolean1, Boolean param1Boolean2) {
      boolean bool1;
      boolean bool2;
      if (param1Boolean1 != null && param1Boolean1.booleanValue()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (param1Boolean2 != null && param1Boolean2.booleanValue()) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      return (bool1 == bool2);
    }
    
    abstract T d(View param1View);
    
    abstract void e(View param1View, T param1T);
    
    T f(View param1View) {
      if (c())
        return d(param1View); 
      if (b()) {
        Object object = param1View.getTag(this.a);
        if (this.b.isInstance(object))
          return (T)object; 
      } 
      return null;
    }
    
    void g(View param1View, T param1T) {
      if (c()) {
        e(param1View, param1T);
        return;
      } 
      if (b() && h(f(param1View), param1T)) {
        w.j(param1View);
        param1View.setTag(this.a, param1T);
        w.X(param1View, this.d);
      } 
    }
    
    abstract boolean h(T param1T1, T param1T2);
  }
  
  static class g {
    static boolean a(View param1View) {
      return param1View.hasOnClickListeners();
    }
  }
  
  static class h {
    static AccessibilityNodeProvider a(View param1View) {
      return param1View.getAccessibilityNodeProvider();
    }
    
    static boolean b(View param1View) {
      return param1View.getFitsSystemWindows();
    }
    
    static int c(View param1View) {
      return param1View.getImportantForAccessibility();
    }
    
    static int d(View param1View) {
      return param1View.getMinimumHeight();
    }
    
    static int e(View param1View) {
      return param1View.getMinimumWidth();
    }
    
    static ViewParent f(View param1View) {
      return param1View.getParentForAccessibility();
    }
    
    static int g(View param1View) {
      return param1View.getWindowSystemUiVisibility();
    }
    
    static boolean h(View param1View) {
      return param1View.hasOverlappingRendering();
    }
    
    static boolean i(View param1View) {
      return param1View.hasTransientState();
    }
    
    static boolean j(View param1View, int param1Int, Bundle param1Bundle) {
      return param1View.performAccessibilityAction(param1Int, param1Bundle);
    }
    
    static void k(View param1View) {
      param1View.postInvalidateOnAnimation();
    }
    
    static void l(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.postInvalidateOnAnimation(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void m(View param1View, Runnable param1Runnable) {
      param1View.postOnAnimation(param1Runnable);
    }
    
    static void n(View param1View, Runnable param1Runnable, long param1Long) {
      param1View.postOnAnimationDelayed(param1Runnable, param1Long);
    }
    
    static void o(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
    
    static void p(View param1View) {
      param1View.requestFitSystemWindows();
    }
    
    static void q(View param1View, Drawable param1Drawable) {
      param1View.setBackground(param1Drawable);
    }
    
    static void r(View param1View, boolean param1Boolean) {
      param1View.setHasTransientState(param1Boolean);
    }
    
    static void s(View param1View, int param1Int) {
      param1View.setImportantForAccessibility(param1Int);
    }
  }
  
  static class i {
    static int a() {
      return View.generateViewId();
    }
    
    static Display b(View param1View) {
      return param1View.getDisplay();
    }
    
    static int c(View param1View) {
      return param1View.getLabelFor();
    }
    
    static int d(View param1View) {
      return param1View.getLayoutDirection();
    }
    
    static int e(View param1View) {
      return param1View.getPaddingEnd();
    }
    
    static int f(View param1View) {
      return param1View.getPaddingStart();
    }
    
    static boolean g(View param1View) {
      return param1View.isPaddingRelative();
    }
    
    static void h(View param1View, int param1Int) {
      param1View.setLabelFor(param1Int);
    }
    
    static void i(View param1View, Paint param1Paint) {
      param1View.setLayerPaint(param1Paint);
    }
    
    static void j(View param1View, int param1Int) {
      param1View.setLayoutDirection(param1Int);
    }
    
    static void k(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1View.setPaddingRelative(param1Int1, param1Int2, param1Int3, param1Int4);
    }
  }
  
  static class j {
    static Rect a(View param1View) {
      return param1View.getClipBounds();
    }
    
    static boolean b(View param1View) {
      return param1View.isInLayout();
    }
    
    static void c(View param1View, Rect param1Rect) {
      param1View.setClipBounds(param1Rect);
    }
  }
  
  static class k {
    static int a(View param1View) {
      return param1View.getAccessibilityLiveRegion();
    }
    
    static boolean b(View param1View) {
      return param1View.isAttachedToWindow();
    }
    
    static boolean c(View param1View) {
      return param1View.isLaidOut();
    }
    
    static boolean d(View param1View) {
      return param1View.isLayoutDirectionResolved();
    }
    
    static void e(ViewParent param1ViewParent, View param1View1, View param1View2, int param1Int) {
      param1ViewParent.notifySubtreeAccessibilityStateChanged(param1View1, param1View2, param1Int);
    }
    
    static void f(View param1View, int param1Int) {
      param1View.setAccessibilityLiveRegion(param1Int);
    }
    
    static void g(AccessibilityEvent param1AccessibilityEvent, int param1Int) {
      param1AccessibilityEvent.setContentChangeTypes(param1Int);
    }
  }
  
  static class l {
    static WindowInsets a(View param1View, WindowInsets param1WindowInsets) {
      return param1View.dispatchApplyWindowInsets(param1WindowInsets);
    }
    
    static WindowInsets b(View param1View, WindowInsets param1WindowInsets) {
      return param1View.onApplyWindowInsets(param1WindowInsets);
    }
    
    static void c(View param1View) {
      param1View.requestApplyInsets();
    }
  }
  
  private static class m {
    static void a(WindowInsets param1WindowInsets, View param1View) {
      View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener)param1View.getTag(a0.b.S);
      if (onApplyWindowInsetsListener != null)
        onApplyWindowInsetsListener.onApplyWindowInsets(param1View, param1WindowInsets); 
    }
    
    static g0 b(View param1View, g0 param1g0, Rect param1Rect) {
      WindowInsets windowInsets = param1g0.v();
      if (windowInsets != null)
        return g0.x(param1View.computeSystemWindowInsets(windowInsets, param1Rect), param1View); 
      param1Rect.setEmpty();
      return param1g0;
    }
    
    static boolean c(View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return param1View.dispatchNestedFling(param1Float1, param1Float2, param1Boolean);
    }
    
    static boolean d(View param1View, float param1Float1, float param1Float2) {
      return param1View.dispatchNestedPreFling(param1Float1, param1Float2);
    }
    
    static boolean e(View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint1, int[] param1ArrayOfint2) {
      return param1View.dispatchNestedPreScroll(param1Int1, param1Int2, param1ArrayOfint1, param1ArrayOfint2);
    }
    
    static boolean f(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int[] param1ArrayOfint) {
      return param1View.dispatchNestedScroll(param1Int1, param1Int2, param1Int3, param1Int4, param1ArrayOfint);
    }
    
    static ColorStateList g(View param1View) {
      return param1View.getBackgroundTintList();
    }
    
    static PorterDuff.Mode h(View param1View) {
      return param1View.getBackgroundTintMode();
    }
    
    static float i(View param1View) {
      return param1View.getElevation();
    }
    
    public static g0 j(View param1View) {
      return g0.a.a(param1View);
    }
    
    static String k(View param1View) {
      return param1View.getTransitionName();
    }
    
    static float l(View param1View) {
      return param1View.getTranslationZ();
    }
    
    static float m(View param1View) {
      return param1View.getZ();
    }
    
    static boolean n(View param1View) {
      return param1View.hasNestedScrollingParent();
    }
    
    static boolean o(View param1View) {
      return param1View.isImportantForAccessibility();
    }
    
    static boolean p(View param1View) {
      return param1View.isNestedScrollingEnabled();
    }
    
    static void q(View param1View, ColorStateList param1ColorStateList) {
      param1View.setBackgroundTintList(param1ColorStateList);
    }
    
    static void r(View param1View, PorterDuff.Mode param1Mode) {
      param1View.setBackgroundTintMode(param1Mode);
    }
    
    static void s(View param1View, float param1Float) {
      param1View.setElevation(param1Float);
    }
    
    static void t(View param1View, boolean param1Boolean) {
      param1View.setNestedScrollingEnabled(param1Boolean);
    }
    
    static void u(View param1View, r param1r) {
      if (Build.VERSION.SDK_INT < 30)
        param1View.setTag(a0.b.L, param1r); 
      if (param1r == null) {
        param1View.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener)param1View.getTag(a0.b.S));
        return;
      } 
      param1View.setOnApplyWindowInsetsListener(new a(param1View, param1r));
    }
    
    static void v(View param1View, String param1String) {
      param1View.setTransitionName(param1String);
    }
    
    static void w(View param1View, float param1Float) {
      param1View.setTranslationZ(param1Float);
    }
    
    static void x(View param1View, float param1Float) {
      param1View.setZ(param1Float);
    }
    
    static boolean y(View param1View, int param1Int) {
      return param1View.startNestedScroll(param1Int);
    }
    
    static void z(View param1View) {
      param1View.stopNestedScroll();
    }
    
    class a implements View.OnApplyWindowInsetsListener {
      g0 a = null;
      
      a(w.m this$0, r param2r) {}
      
      public WindowInsets onApplyWindowInsets(View param2View, WindowInsets param2WindowInsets) {
        g0 g02 = g0.x(param2WindowInsets, param2View);
        int i = Build.VERSION.SDK_INT;
        if (i < 30) {
          w.m.a(param2WindowInsets, this.b);
          if (g02.equals(this.a))
            return this.c.a(param2View, g02).v(); 
        } 
        this.a = g02;
        g0 g01 = this.c.a(param2View, g02);
        if (i >= 30)
          return g01.v(); 
        w.l0(param2View);
        return g01.v();
      }
    }
  }
  
  class a implements View.OnApplyWindowInsetsListener {
    g0 a = null;
    
    a(w this$0, r param1r) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      g0 g02 = g0.x(param1WindowInsets, param1View);
      int i = Build.VERSION.SDK_INT;
      if (i < 30) {
        w.m.a(param1WindowInsets, this.b);
        if (g02.equals(this.a))
          return this.c.a(param1View, g02).v(); 
      } 
      this.a = g02;
      g0 g01 = this.c.a(param1View, g02);
      if (i >= 30)
        return g01.v(); 
      w.l0(param1View);
      return g01.v();
    }
  }
  
  private static class n {
    public static g0 a(View param1View) {
      WindowInsets windowInsets = param1View.getRootWindowInsets();
      if (windowInsets == null)
        return null; 
      g0 g0 = g0.w(windowInsets);
      g0.t(g0);
      g0.d(param1View.getRootView());
      return g0;
    }
    
    static int b(View param1View) {
      return param1View.getScrollIndicators();
    }
    
    static void c(View param1View, int param1Int) {
      param1View.setScrollIndicators(param1Int);
    }
    
    static void d(View param1View, int param1Int1, int param1Int2) {
      param1View.setScrollIndicators(param1Int1, param1Int2);
    }
  }
  
  static class o {
    static void a(View param1View, Collection<View> param1Collection, int param1Int) {
      param1View.addKeyboardNavigationClusters(param1Collection, param1Int);
    }
    
    static int b(View param1View) {
      return param1View.getImportantForAutofill();
    }
    
    static int c(View param1View) {
      return param1View.getNextClusterForwardId();
    }
    
    static boolean d(View param1View) {
      return param1View.hasExplicitFocusable();
    }
    
    static boolean e(View param1View) {
      return param1View.isFocusedByDefault();
    }
    
    static boolean f(View param1View) {
      return param1View.isImportantForAutofill();
    }
    
    static boolean g(View param1View) {
      return param1View.isKeyboardNavigationCluster();
    }
    
    static View h(View param1View1, View param1View2, int param1Int) {
      return param1View1.keyboardNavigationClusterSearch(param1View2, param1Int);
    }
    
    static boolean i(View param1View) {
      return param1View.restoreDefaultFocus();
    }
    
    static void j(View param1View, String... param1VarArgs) {
      param1View.setAutofillHints(param1VarArgs);
    }
    
    static void k(View param1View, boolean param1Boolean) {
      param1View.setFocusedByDefault(param1Boolean);
    }
    
    static void l(View param1View, int param1Int) {
      param1View.setImportantForAutofill(param1Int);
    }
    
    static void m(View param1View, boolean param1Boolean) {
      param1View.setKeyboardNavigationCluster(param1Boolean);
    }
    
    static void n(View param1View, int param1Int) {
      param1View.setNextClusterForwardId(param1Int);
    }
    
    static void o(View param1View, CharSequence param1CharSequence) {
      param1View.setTooltipText(param1CharSequence);
    }
  }
  
  static class p {
    static void a(View param1View, w.u param1u) {
      int i = a0.b.R;
      s.g g2 = (s.g)param1View.getTag(i);
      s.g g1 = g2;
      if (g2 == null) {
        g1 = new s.g();
        param1View.setTag(i, g1);
      } 
      Objects.requireNonNull(param1u);
      x x = new x(param1u);
      g1.put(param1u, x);
      param1View.addOnUnhandledKeyEventListener(x);
    }
    
    static CharSequence b(View param1View) {
      return param1View.getAccessibilityPaneTitle();
    }
    
    static boolean c(View param1View) {
      return param1View.isAccessibilityHeading();
    }
    
    static boolean d(View param1View) {
      return param1View.isScreenReaderFocusable();
    }
    
    static void e(View param1View, w.u param1u) {
      s.g g = (s.g)param1View.getTag(a0.b.R);
      if (g == null)
        return; 
      View.OnUnhandledKeyEventListener onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener)g.get(param1u);
      if (onUnhandledKeyEventListener != null)
        param1View.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener); 
    }
    
    static <T> T f(View param1View, int param1Int) {
      return (T)param1View.requireViewById(param1Int);
    }
    
    static void g(View param1View, boolean param1Boolean) {
      param1View.setAccessibilityHeading(param1Boolean);
    }
    
    static void h(View param1View, CharSequence param1CharSequence) {
      param1View.setAccessibilityPaneTitle(param1CharSequence);
    }
    
    static void i(View param1View, boolean param1Boolean) {
      param1View.setScreenReaderFocusable(param1Boolean);
    }
  }
  
  private static class q {
    static View.AccessibilityDelegate a(View param1View) {
      return param1View.getAccessibilityDelegate();
    }
    
    static List<Rect> b(View param1View) {
      return param1View.getSystemGestureExclusionRects();
    }
    
    static void c(View param1View, Context param1Context, int[] param1ArrayOfint, AttributeSet param1AttributeSet, TypedArray param1TypedArray, int param1Int1, int param1Int2) {
      param1View.saveAttributeDataForStyleable(param1Context, param1ArrayOfint, param1AttributeSet, param1TypedArray, param1Int1, param1Int2);
    }
    
    static void d(View param1View, List<Rect> param1List) {
      param1View.setSystemGestureExclusionRects(param1List);
    }
  }
  
  private static class r {
    static CharSequence a(View param1View) {
      return param1View.getStateDescription();
    }
    
    static void b(View param1View, CharSequence param1CharSequence) {
      param1View.setStateDescription(param1CharSequence);
    }
  }
  
  private static final class s {
    public static String[] a(View param1View) {
      return param1View.getReceiveContentMimeTypes();
    }
    
    public static c b(View param1View, c param1c) {
      ContentInfo contentInfo2 = param1c.f();
      ContentInfo contentInfo1 = param1View.performReceiveContent(contentInfo2);
      return (contentInfo1 == null) ? null : ((contentInfo1 == contentInfo2) ? param1c : c.g(contentInfo1));
    }
    
    public static void c(View param1View, String[] param1ArrayOfString, s param1s) {
      if (param1s == null) {
        param1View.setOnReceiveContentListener(param1ArrayOfString, null);
        return;
      } 
      param1View.setOnReceiveContentListener(param1ArrayOfString, new w.t(param1s));
    }
  }
  
  private static final class t implements OnReceiveContentListener {
    private final s a;
    
    t(s param1s) {
      this.a = param1s;
    }
    
    public ContentInfo onReceiveContent(View param1View, ContentInfo param1ContentInfo) {
      c c2 = c.g(param1ContentInfo);
      c c1 = this.a.a(param1View, c2);
      return (c1 == null) ? null : ((c1 == c2) ? param1ContentInfo : c1.f());
    }
  }
  
  public static interface u {
    boolean onUnhandledKeyEvent(View param1View, KeyEvent param1KeyEvent);
  }
  
  static class v {
    private static final ArrayList<WeakReference<View>> d = new ArrayList<WeakReference<View>>();
    
    private WeakHashMap<View, Boolean> a = null;
    
    private SparseArray<WeakReference<View>> b = null;
    
    private WeakReference<KeyEvent> c = null;
    
    static v a(View param1View) {
      int i = a0.b.Q;
      v v2 = (v)param1View.getTag(i);
      v v1 = v2;
      if (v2 == null) {
        v1 = new v();
        param1View.setTag(i, v1);
      } 
      return v1;
    }
    
    private View c(View param1View, KeyEvent param1KeyEvent) {
      WeakHashMap<View, Boolean> weakHashMap = this.a;
      if (weakHashMap != null) {
        if (!weakHashMap.containsKey(param1View))
          return null; 
        if (param1View instanceof ViewGroup) {
          ViewGroup viewGroup = (ViewGroup)param1View;
          for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
            View view = c(viewGroup.getChildAt(i), param1KeyEvent);
            if (view != null)
              return view; 
          } 
        } 
        if (e(param1View, param1KeyEvent))
          return param1View; 
      } 
      return null;
    }
    
    private SparseArray<WeakReference<View>> d() {
      if (this.b == null)
        this.b = new SparseArray(); 
      return this.b;
    }
    
    private boolean e(View param1View, KeyEvent param1KeyEvent) {
      ArrayList<w.u> arrayList = (ArrayList)param1View.getTag(a0.b.R);
      if (arrayList != null)
        for (int i = arrayList.size() - 1; i >= 0; i--) {
          if (((w.u)arrayList.get(i)).onUnhandledKeyEvent(param1View, param1KeyEvent))
            return true; 
        }  
      return false;
    }
    
    private void g() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Ljava/util/WeakHashMap;
      //   4: astore_2
      //   5: aload_2
      //   6: ifnull -> 13
      //   9: aload_2
      //   10: invokevirtual clear : ()V
      //   13: getstatic androidx/core/view/w$v.d : Ljava/util/ArrayList;
      //   16: astore_3
      //   17: aload_3
      //   18: invokevirtual isEmpty : ()Z
      //   21: ifeq -> 25
      //   24: return
      //   25: aload_3
      //   26: monitorenter
      //   27: aload_0
      //   28: getfield a : Ljava/util/WeakHashMap;
      //   31: ifnonnull -> 45
      //   34: aload_0
      //   35: new java/util/WeakHashMap
      //   38: dup
      //   39: invokespecial <init> : ()V
      //   42: putfield a : Ljava/util/WeakHashMap;
      //   45: aload_3
      //   46: invokevirtual size : ()I
      //   49: iconst_1
      //   50: isub
      //   51: istore_1
      //   52: iload_1
      //   53: iflt -> 141
      //   56: getstatic androidx/core/view/w$v.d : Ljava/util/ArrayList;
      //   59: astore_2
      //   60: aload_2
      //   61: iload_1
      //   62: invokevirtual get : (I)Ljava/lang/Object;
      //   65: checkcast java/lang/ref/WeakReference
      //   68: invokevirtual get : ()Ljava/lang/Object;
      //   71: checkcast android/view/View
      //   74: astore #4
      //   76: aload #4
      //   78: ifnonnull -> 90
      //   81: aload_2
      //   82: iload_1
      //   83: invokevirtual remove : (I)Ljava/lang/Object;
      //   86: pop
      //   87: goto -> 149
      //   90: aload_0
      //   91: getfield a : Ljava/util/WeakHashMap;
      //   94: aload #4
      //   96: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   99: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   102: pop
      //   103: aload #4
      //   105: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   108: astore_2
      //   109: aload_2
      //   110: instanceof android/view/View
      //   113: ifeq -> 149
      //   116: aload_0
      //   117: getfield a : Ljava/util/WeakHashMap;
      //   120: aload_2
      //   121: checkcast android/view/View
      //   124: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   127: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   130: pop
      //   131: aload_2
      //   132: invokeinterface getParent : ()Landroid/view/ViewParent;
      //   137: astore_2
      //   138: goto -> 109
      //   141: aload_3
      //   142: monitorexit
      //   143: return
      //   144: astore_2
      //   145: aload_3
      //   146: monitorexit
      //   147: aload_2
      //   148: athrow
      //   149: iload_1
      //   150: iconst_1
      //   151: isub
      //   152: istore_1
      //   153: goto -> 52
      // Exception table:
      //   from	to	target	type
      //   27	45	144	finally
      //   45	52	144	finally
      //   56	76	144	finally
      //   81	87	144	finally
      //   90	109	144	finally
      //   109	138	144	finally
      //   141	143	144	finally
      //   145	147	144	finally
    }
    
    boolean b(View param1View, KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getAction() == 0)
        g(); 
      param1View = c(param1View, param1KeyEvent);
      if (param1KeyEvent.getAction() == 0) {
        int i = param1KeyEvent.getKeyCode();
        if (param1View != null && !KeyEvent.isModifierKey(i))
          d().put(i, new WeakReference<View>(param1View)); 
      } 
      return (param1View != null);
    }
    
    boolean f(KeyEvent param1KeyEvent) {
      WeakReference<KeyEvent> weakReference1 = this.c;
      if (weakReference1 != null && weakReference1.get() == param1KeyEvent)
        return false; 
      this.c = new WeakReference<KeyEvent>(param1KeyEvent);
      WeakReference<KeyEvent> weakReference2 = null;
      SparseArray<WeakReference<View>> sparseArray = d();
      weakReference1 = weakReference2;
      if (param1KeyEvent.getAction() == 1) {
        int i = sparseArray.indexOfKey(param1KeyEvent.getKeyCode());
        weakReference1 = weakReference2;
        if (i >= 0) {
          weakReference1 = (WeakReference<KeyEvent>)sparseArray.valueAt(i);
          sparseArray.removeAt(i);
        } 
      } 
      weakReference2 = weakReference1;
      if (weakReference1 == null)
        weakReference2 = (WeakReference<KeyEvent>)sparseArray.get(param1KeyEvent.getKeyCode()); 
      if (weakReference2 != null) {
        View view = (View)weakReference2.get();
        if (view != null && w.R(view))
          e(view, param1KeyEvent); 
        return true;
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */