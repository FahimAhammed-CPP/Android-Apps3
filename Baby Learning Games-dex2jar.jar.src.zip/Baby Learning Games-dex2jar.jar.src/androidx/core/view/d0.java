package androidx.core.view;

import android.view.View;

public class d0 implements c0 {
  public void a(View paramView) {}
  
  public void c(View paramView) {}
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */