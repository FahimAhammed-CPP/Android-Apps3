package androidx.core.view;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

public class g0 {
  public static final g0 b = l.b;
  
  private final l a;
  
  private g0(WindowInsets paramWindowInsets) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.a = new k(this, paramWindowInsets);
      return;
    } 
    if (i >= 29) {
      this.a = new j(this, paramWindowInsets);
      return;
    } 
    if (i >= 28) {
      this.a = new i(this, paramWindowInsets);
      return;
    } 
    this.a = new h(this, paramWindowInsets);
  }
  
  public g0(g0 paramg0) {
    if (paramg0 != null) {
      l l1 = paramg0.a;
      int i = Build.VERSION.SDK_INT;
      if (i >= 30 && l1 instanceof k) {
        this.a = new k(this, (k)l1);
      } else if (i >= 29 && l1 instanceof j) {
        this.a = new j(this, (j)l1);
      } else if (i >= 28 && l1 instanceof i) {
        this.a = new i(this, (i)l1);
      } else if (l1 instanceof h) {
        this.a = new h(this, (h)l1);
      } else if (l1 instanceof g) {
        this.a = new g(this, (g)l1);
      } else {
        this.a = new l(this);
      } 
      l1.e(this);
      return;
    } 
    this.a = new l(this);
  }
  
  static c0.b o(c0.b paramb, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = Math.max(0, paramb.a - paramInt1);
    int j = Math.max(0, paramb.b - paramInt2);
    int k = Math.max(0, paramb.c - paramInt3);
    int m = Math.max(0, paramb.d - paramInt4);
    return (i == paramInt1 && j == paramInt2 && k == paramInt3 && m == paramInt4) ? paramb : c0.b.b(i, j, k, m);
  }
  
  public static g0 w(WindowInsets paramWindowInsets) {
    return x(paramWindowInsets, null);
  }
  
  public static g0 x(WindowInsets paramWindowInsets, View paramView) {
    g0 g01 = new g0((WindowInsets)k0.h.f(paramWindowInsets));
    if (paramView != null && w.R(paramView)) {
      g01.t(w.I(paramView));
      g01.d(paramView.getRootView());
    } 
    return g01;
  }
  
  @Deprecated
  public g0 a() {
    return this.a.a();
  }
  
  @Deprecated
  public g0 b() {
    return this.a.b();
  }
  
  @Deprecated
  public g0 c() {
    return this.a.c();
  }
  
  void d(View paramView) {
    this.a.d(paramView);
  }
  
  public d e() {
    return this.a.f();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof g0))
      return false; 
    paramObject = paramObject;
    return k0.c.a(this.a, ((g0)paramObject).a);
  }
  
  public c0.b f(int paramInt) {
    return this.a.g(paramInt);
  }
  
  @Deprecated
  public c0.b g() {
    return this.a.i();
  }
  
  @Deprecated
  public c0.b h() {
    return this.a.j();
  }
  
  public int hashCode() {
    l l1 = this.a;
    return (l1 == null) ? 0 : l1.hashCode();
  }
  
  @Deprecated
  public int i() {
    return (this.a.k()).d;
  }
  
  @Deprecated
  public int j() {
    return (this.a.k()).a;
  }
  
  @Deprecated
  public int k() {
    return (this.a.k()).c;
  }
  
  @Deprecated
  public int l() {
    return (this.a.k()).b;
  }
  
  @Deprecated
  public boolean m() {
    return this.a.k().equals(c0.b.e) ^ true;
  }
  
  public g0 n(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return this.a.m(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean p() {
    return this.a.n();
  }
  
  @Deprecated
  public g0 q(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return (new b(this)).c(c0.b.b(paramInt1, paramInt2, paramInt3, paramInt4)).a();
  }
  
  void r(c0.b[] paramArrayOfb) {
    this.a.p(paramArrayOfb);
  }
  
  void s(c0.b paramb) {
    this.a.q(paramb);
  }
  
  void t(g0 paramg0) {
    this.a.r(paramg0);
  }
  
  void u(c0.b paramb) {
    this.a.s(paramb);
  }
  
  public WindowInsets v() {
    l l1 = this.a;
    return (l1 instanceof g) ? ((g)l1).c : null;
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 30) {
      b = k.q;
      return;
    } 
  }
  
  @SuppressLint({"SoonBlockedPrivateApi"})
  static class a {
    private static Field a;
    
    private static Field b;
    
    private static Field c;
    
    private static boolean d;
    
    static {
      try {
        Field field2 = View.class.getDeclaredField("mAttachInfo");
        a = field2;
        field2.setAccessible(true);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        Field field3 = clazz.getDeclaredField("mStableInsets");
        b = field3;
        field3.setAccessible(true);
        Field field1 = clazz.getDeclaredField("mContentInsets");
        c = field1;
        field1.setAccessible(true);
        d = true;
        return;
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets from AttachInfo ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.w("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
        return;
      } 
    }
    
    public static g0 a(View param1View) {
      if (d) {
        if (!param1View.isAttachedToWindow())
          return null; 
        View view = param1View.getRootView();
        try {
          Object object = a.get(view);
          if (object != null) {
            Rect rect = (Rect)b.get(object);
            object = c.get(object);
            if (rect != null && object != null) {
              g0 g0 = (new g0.b()).b(c0.b.c(rect)).c(c0.b.c((Rect)object)).a();
              g0.t(g0);
              g0.d(param1View.getRootView());
              return g0;
            } 
          } 
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to get insets from AttachInfo. ");
          stringBuilder.append(illegalAccessException.getMessage());
          Log.w("WindowInsetsCompat", stringBuilder.toString(), illegalAccessException);
        } 
      } 
      return null;
    }
  }
  
  public static final class b {
    private final g0.f a;
    
    public b() {
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        this.a = new g0.e();
        return;
      } 
      if (i >= 29) {
        this.a = new g0.d();
        return;
      } 
      this.a = new g0.c();
    }
    
    public b(g0 param1g0) {
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        this.a = new g0.e(param1g0);
        return;
      } 
      if (i >= 29) {
        this.a = new g0.d(param1g0);
        return;
      } 
      this.a = new g0.c(param1g0);
    }
    
    public g0 a() {
      return this.a.b();
    }
    
    @Deprecated
    public b b(c0.b param1b) {
      this.a.d(param1b);
      return this;
    }
    
    @Deprecated
    public b c(c0.b param1b) {
      this.a.f(param1b);
      return this;
    }
  }
  
  private static class c extends f {
    private static Field e;
    
    private static boolean f = false;
    
    private static Constructor<WindowInsets> g;
    
    private static boolean h = false;
    
    private WindowInsets c = h();
    
    private c0.b d;
    
    c() {}
    
    c(g0 param1g0) {
      super(param1g0);
    }
    
    private static WindowInsets h() {
      if (!f) {
        try {
          e = WindowInsets.class.getDeclaredField("CONSUMED");
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", reflectiveOperationException);
        } 
        f = true;
      } 
      Field field = e;
      if (field != null)
        try {
          WindowInsets windowInsets = (WindowInsets)field.get(null);
          if (windowInsets != null)
            return new WindowInsets(windowInsets); 
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", reflectiveOperationException);
        }  
      if (!h) {
        try {
          g = WindowInsets.class.getConstructor(new Class[] { Rect.class });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", reflectiveOperationException);
        } 
        h = true;
      } 
      Constructor<WindowInsets> constructor = g;
      if (constructor != null)
        try {
          return constructor.newInstance(new Object[] { new Rect() });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", reflectiveOperationException);
        }  
      return null;
    }
    
    g0 b() {
      a();
      g0 g0 = g0.w(this.c);
      g0.r(this.b);
      g0.u(this.d);
      return g0;
    }
    
    void d(c0.b param1b) {
      this.d = param1b;
    }
    
    void f(c0.b param1b) {
      WindowInsets windowInsets = this.c;
      if (windowInsets != null)
        this.c = windowInsets.replaceSystemWindowInsets(param1b.a, param1b.b, param1b.c, param1b.d); 
    }
  }
  
  private static class d extends f {
    final WindowInsets.Builder c;
    
    d() {
      this.c = new WindowInsets.Builder();
    }
    
    d(g0 param1g0) {
      super(param1g0);
      WindowInsets.Builder builder;
      WindowInsets windowInsets = param1g0.v();
      if (windowInsets != null) {
        builder = new WindowInsets.Builder(windowInsets);
      } else {
        builder = new WindowInsets.Builder();
      } 
      this.c = builder;
    }
    
    g0 b() {
      a();
      g0 g0 = g0.w(this.c.build());
      g0.r(this.b);
      return g0;
    }
    
    void c(c0.b param1b) {
      this.c.setMandatorySystemGestureInsets(param1b.e());
    }
    
    void d(c0.b param1b) {
      this.c.setStableInsets(param1b.e());
    }
    
    void e(c0.b param1b) {
      this.c.setSystemGestureInsets(param1b.e());
    }
    
    void f(c0.b param1b) {
      this.c.setSystemWindowInsets(param1b.e());
    }
    
    void g(c0.b param1b) {
      this.c.setTappableElementInsets(param1b.e());
    }
  }
  
  private static class e extends d {
    e() {}
    
    e(g0 param1g0) {
      super(param1g0);
    }
  }
  
  private static class f {
    private final g0 a;
    
    c0.b[] b;
    
    f() {
      this(new g0(null));
    }
    
    f(g0 param1g0) {
      this.a = param1g0;
    }
    
    protected final void a() {
      c0.b[] arrayOfB = this.b;
      if (arrayOfB != null) {
        c0.b b3 = arrayOfB[g0.m.a(1)];
        c0.b b2 = this.b[g0.m.a(2)];
        c0.b b1 = b2;
        if (b2 == null)
          b1 = this.a.f(2); 
        b2 = b3;
        if (b3 == null)
          b2 = this.a.f(1); 
        f(c0.b.a(b2, b1));
        b1 = this.b[g0.m.a(16)];
        if (b1 != null)
          e(b1); 
        b1 = this.b[g0.m.a(32)];
        if (b1 != null)
          c(b1); 
        b1 = this.b[g0.m.a(64)];
        if (b1 != null)
          g(b1); 
      } 
    }
    
    g0 b() {
      throw null;
    }
    
    void c(c0.b param1b) {}
    
    void d(c0.b param1b) {
      throw null;
    }
    
    void e(c0.b param1b) {}
    
    void f(c0.b param1b) {
      throw null;
    }
    
    void g(c0.b param1b) {}
  }
  
  private static class g extends l {
    private static boolean h = false;
    
    private static Method i;
    
    private static Class<?> j;
    
    private static Field k;
    
    private static Field l;
    
    final WindowInsets c;
    
    private c0.b[] d;
    
    private c0.b e = null;
    
    private g0 f;
    
    c0.b g;
    
    g(g0 param1g0, WindowInsets param1WindowInsets) {
      super(param1g0);
      this.c = param1WindowInsets;
    }
    
    g(g0 param1g0, g param1g) {
      this(param1g0, new WindowInsets(param1g.c));
    }
    
    @SuppressLint({"WrongConstant"})
    private c0.b t(int param1Int, boolean param1Boolean) {
      c0.b b1 = c0.b.e;
      for (int i = 1; i <= 256; i <<= 1) {
        if ((param1Int & i) != 0)
          b1 = c0.b.a(b1, u(i, param1Boolean)); 
      } 
      return b1;
    }
    
    private c0.b v() {
      g0 g01 = this.f;
      return (g01 != null) ? g01.g() : c0.b.e;
    }
    
    private c0.b w(View param1View) {
      if (Build.VERSION.SDK_INT < 30) {
        if (!h)
          x(); 
        Method method = i;
        StringBuilder stringBuilder = null;
        if (method != null && j != null) {
          if (k == null)
            return null; 
          try {
            Object object = method.invoke(param1View, new Object[0]);
            if (object == null) {
              Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
              return null;
            } 
            object = l.get(object);
            Rect rect = (Rect)k.get(object);
            object = stringBuilder;
            if (rect != null)
              object = c0.b.c(rect); 
            return (c0.b)object;
          } catch (ReflectiveOperationException reflectiveOperationException) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to get visible insets. (Reflection error). ");
            stringBuilder.append(reflectiveOperationException.getMessage());
            Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
          } 
        } 
        return null;
      } 
      throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }
    
    @SuppressLint({"PrivateApi"})
    private static void x() {
      try {
        i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        j = clazz;
        k = clazz.getDeclaredField("mVisibleInsets");
        l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
        k.setAccessible(true);
        l.setAccessible(true);
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets. (Reflection error). ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
      } 
      h = true;
    }
    
    void d(View param1View) {
      c0.b b2 = w(param1View);
      c0.b b1 = b2;
      if (b2 == null)
        b1 = c0.b.e; 
      q(b1);
    }
    
    void e(g0 param1g0) {
      param1g0.t(this.f);
      param1g0.s(this.g);
    }
    
    public boolean equals(Object param1Object) {
      if (!super.equals(param1Object))
        return false; 
      param1Object = param1Object;
      return Objects.equals(this.g, ((g)param1Object).g);
    }
    
    public c0.b g(int param1Int) {
      return t(param1Int, false);
    }
    
    final c0.b k() {
      if (this.e == null)
        this.e = c0.b.b(this.c.getSystemWindowInsetLeft(), this.c.getSystemWindowInsetTop(), this.c.getSystemWindowInsetRight(), this.c.getSystemWindowInsetBottom()); 
      return this.e;
    }
    
    g0 m(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      g0.b b1 = new g0.b(g0.w(this.c));
      b1.c(g0.o(k(), param1Int1, param1Int2, param1Int3, param1Int4));
      b1.b(g0.o(i(), param1Int1, param1Int2, param1Int3, param1Int4));
      return b1.a();
    }
    
    boolean o() {
      return this.c.isRound();
    }
    
    public void p(c0.b[] param1ArrayOfb) {
      this.d = param1ArrayOfb;
    }
    
    void q(c0.b param1b) {
      this.g = param1b;
    }
    
    void r(g0 param1g0) {
      this.f = param1g0;
    }
    
    protected c0.b u(int param1Int, boolean param1Boolean) {
      if (param1Int != 1) {
        c0.b b1;
        g0 g01 = null;
        g0 g02 = null;
        if (param1Int != 2) {
          if (param1Int != 8) {
            if (param1Int != 16) {
              if (param1Int != 32) {
                if (param1Int != 64) {
                  d d;
                  if (param1Int != 128)
                    return c0.b.e; 
                  g01 = this.f;
                  if (g01 != null) {
                    d = g01.e();
                  } else {
                    d = f();
                  } 
                  return (d != null) ? c0.b.b(d.b(), d.d(), d.c(), d.a()) : c0.b.e;
                } 
                return l();
              } 
              return h();
            } 
            return j();
          } 
          c0.b[] arrayOfB = this.d;
          g01 = g02;
          if (arrayOfB != null)
            b1 = arrayOfB[g0.m.a(8)]; 
          if (b1 != null)
            return b1; 
          c0.b b3 = k();
          b1 = v();
          param1Int = b3.d;
          if (param1Int > b1.d)
            return c0.b.b(0, 0, 0, param1Int); 
          b3 = this.g;
          if (b3 != null && !b3.equals(c0.b.e)) {
            param1Int = this.g.d;
            if (param1Int > b1.d)
              return c0.b.b(0, 0, 0, param1Int); 
          } 
          return c0.b.e;
        } 
        if (param1Boolean) {
          b1 = v();
          c0.b b3 = i();
          return c0.b.b(Math.max(b1.a, b3.a), 0, Math.max(b1.c, b3.c), Math.max(b1.d, b3.d));
        } 
        c0.b b2 = k();
        g0 g03 = this.f;
        if (g03 != null)
          b1 = g03.g(); 
        int i = b2.d;
        param1Int = i;
        if (b1 != null)
          param1Int = Math.min(i, b1.d); 
        return c0.b.b(b2.a, 0, b2.c, param1Int);
      } 
      return param1Boolean ? c0.b.b(0, Math.max((v()).b, (k()).b), 0, 0) : c0.b.b(0, (k()).b, 0, 0);
    }
  }
  
  private static class h extends g {
    private c0.b m = null;
    
    h(g0 param1g0, WindowInsets param1WindowInsets) {
      super(param1g0, param1WindowInsets);
    }
    
    h(g0 param1g0, h param1h) {
      super(param1g0, param1h);
      this.m = param1h.m;
    }
    
    g0 b() {
      return g0.w(this.c.consumeStableInsets());
    }
    
    g0 c() {
      return g0.w(this.c.consumeSystemWindowInsets());
    }
    
    final c0.b i() {
      if (this.m == null)
        this.m = c0.b.b(this.c.getStableInsetLeft(), this.c.getStableInsetTop(), this.c.getStableInsetRight(), this.c.getStableInsetBottom()); 
      return this.m;
    }
    
    boolean n() {
      return this.c.isConsumed();
    }
    
    public void s(c0.b param1b) {
      this.m = param1b;
    }
  }
  
  private static class i extends h {
    i(g0 param1g0, WindowInsets param1WindowInsets) {
      super(param1g0, param1WindowInsets);
    }
    
    i(g0 param1g0, i param1i) {
      super(param1g0, param1i);
    }
    
    g0 a() {
      return g0.w(this.c.consumeDisplayCutout());
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof i))
        return false; 
      param1Object = param1Object;
      return (Objects.equals(this.c, ((g0.g)param1Object).c) && Objects.equals(this.g, ((g0.g)param1Object).g));
    }
    
    d f() {
      return d.e(this.c.getDisplayCutout());
    }
    
    public int hashCode() {
      return this.c.hashCode();
    }
  }
  
  private static class j extends i {
    private c0.b n = null;
    
    private c0.b o = null;
    
    private c0.b p = null;
    
    j(g0 param1g0, WindowInsets param1WindowInsets) {
      super(param1g0, param1WindowInsets);
    }
    
    j(g0 param1g0, j param1j) {
      super(param1g0, param1j);
    }
    
    c0.b h() {
      if (this.o == null)
        this.o = c0.b.d(this.c.getMandatorySystemGestureInsets()); 
      return this.o;
    }
    
    c0.b j() {
      if (this.n == null)
        this.n = c0.b.d(this.c.getSystemGestureInsets()); 
      return this.n;
    }
    
    c0.b l() {
      if (this.p == null)
        this.p = c0.b.d(this.c.getTappableElementInsets()); 
      return this.p;
    }
    
    g0 m(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return g0.w(this.c.inset(param1Int1, param1Int2, param1Int3, param1Int4));
    }
    
    public void s(c0.b param1b) {}
  }
  
  private static class k extends j {
    static final g0 q = g0.w(WindowInsets.CONSUMED);
    
    k(g0 param1g0, WindowInsets param1WindowInsets) {
      super(param1g0, param1WindowInsets);
    }
    
    k(g0 param1g0, k param1k) {
      super(param1g0, param1k);
    }
    
    final void d(View param1View) {}
    
    public c0.b g(int param1Int) {
      return c0.b.d(this.c.getInsets(g0.n.a(param1Int)));
    }
  }
  
  private static class l {
    static final g0 b = (new g0.b()).a().a().b().c();
    
    final g0 a;
    
    l(g0 param1g0) {
      this.a = param1g0;
    }
    
    g0 a() {
      return this.a;
    }
    
    g0 b() {
      return this.a;
    }
    
    g0 c() {
      return this.a;
    }
    
    void d(View param1View) {}
    
    void e(g0 param1g0) {}
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof l))
        return false; 
      param1Object = param1Object;
      return (o() == param1Object.o() && n() == param1Object.n() && k0.c.a(k(), param1Object.k()) && k0.c.a(i(), param1Object.i()) && k0.c.a(f(), param1Object.f()));
    }
    
    d f() {
      return null;
    }
    
    c0.b g(int param1Int) {
      return c0.b.e;
    }
    
    c0.b h() {
      return k();
    }
    
    public int hashCode() {
      return k0.c.b(new Object[] { Boolean.valueOf(o()), Boolean.valueOf(n()), k(), i(), f() });
    }
    
    c0.b i() {
      return c0.b.e;
    }
    
    c0.b j() {
      return k();
    }
    
    c0.b k() {
      return c0.b.e;
    }
    
    c0.b l() {
      return k();
    }
    
    g0 m(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return b;
    }
    
    boolean n() {
      return false;
    }
    
    boolean o() {
      return false;
    }
    
    public void p(c0.b[] param1ArrayOfb) {}
    
    void q(c0.b param1b) {}
    
    void r(g0 param1g0) {}
    
    public void s(c0.b param1b) {}
  }
  
  public static final class m {
    static int a(int param1Int) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 4) {
            if (param1Int != 8) {
              if (param1Int != 16) {
                if (param1Int != 32) {
                  if (param1Int != 64) {
                    if (param1Int != 128) {
                      if (param1Int == 256)
                        return 8; 
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("type needs to be >= FIRST and <= LAST, type=");
                      stringBuilder.append(param1Int);
                      throw new IllegalArgumentException(stringBuilder.toString());
                    } 
                    return 7;
                  } 
                  return 6;
                } 
                return 5;
              } 
              return 4;
            } 
            return 3;
          } 
          return 2;
        } 
        return 1;
      } 
      return 0;
    }
    
    public static int b() {
      return 32;
    }
    
    public static int c() {
      return 7;
    }
  }
  
  private static final class n {
    static int a(int param1Int) {
      int j = 0;
      int i = 1;
      while (i <= 256) {
        int k = j;
        if ((param1Int & i) != 0)
          if (i != 1) {
            if (i != 2) {
              if (i != 4) {
                if (i != 8) {
                  if (i != 16) {
                    if (i != 32) {
                      if (i != 64) {
                        if (i != 128) {
                          k = j;
                        } else {
                          k = WindowInsets.Type.displayCutout();
                          k = j | k;
                        } 
                      } else {
                        k = WindowInsets.Type.tappableElement();
                        k = j | k;
                      } 
                    } else {
                      k = WindowInsets.Type.mandatorySystemGestures();
                      k = j | k;
                    } 
                  } else {
                    k = WindowInsets.Type.systemGestures();
                    k = j | k;
                  } 
                } else {
                  k = WindowInsets.Type.ime();
                  k = j | k;
                } 
              } else {
                k = WindowInsets.Type.captionBar();
                k = j | k;
              } 
            } else {
              k = WindowInsets.Type.navigationBars();
              k = j | k;
            } 
          } else {
            k = WindowInsets.Type.statusBars();
            k = j | k;
          }  
        i <<= 1;
        j = k;
      } 
      return j;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */