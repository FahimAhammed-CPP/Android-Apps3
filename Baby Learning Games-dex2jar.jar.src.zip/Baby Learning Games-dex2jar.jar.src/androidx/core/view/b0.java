package androidx.core.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

public final class b0 {
  private WeakReference<View> a;
  
  Runnable b = null;
  
  Runnable c = null;
  
  int d = -1;
  
  b0(View paramView) {
    this.a = new WeakReference<View>(paramView);
  }
  
  private void g(View paramView, c0 paramc0) {
    if (paramc0 != null) {
      paramView.animate().setListener((Animator.AnimatorListener)new a(this, paramc0, paramView));
      return;
    } 
    paramView.animate().setListener(null);
  }
  
  public b0 a(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().alpha(paramFloat); 
    return this;
  }
  
  public void b() {
    View view = this.a.get();
    if (view != null)
      view.animate().cancel(); 
  }
  
  public long c() {
    View view = this.a.get();
    return (view != null) ? view.animate().getDuration() : 0L;
  }
  
  public b0 d(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setDuration(paramLong); 
    return this;
  }
  
  public b0 e(Interpolator paramInterpolator) {
    View view = this.a.get();
    if (view != null)
      view.animate().setInterpolator((TimeInterpolator)paramInterpolator); 
    return this;
  }
  
  public b0 f(c0 paramc0) {
    View view = this.a.get();
    if (view != null)
      g(view, paramc0); 
    return this;
  }
  
  public b0 h(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setStartDelay(paramLong); 
    return this;
  }
  
  public b0 i(e0 parame0) {
    View view = this.a.get();
    if (view != null) {
      b b = null;
      if (parame0 != null)
        b = new b(this, parame0, view); 
      view.animate().setUpdateListener(b);
    } 
    return this;
  }
  
  public void j() {
    View view = this.a.get();
    if (view != null)
      view.animate().start(); 
  }
  
  public b0 k(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().translationY(paramFloat); 
    return this;
  }
  
  class a extends AnimatorListenerAdapter {
    a(b0 this$0, c0 param1c0, View param1View) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a.a(this.b);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.b(this.b);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.c(this.b);
    }
  }
  
  class b implements ValueAnimator.AnimatorUpdateListener {
    b(b0 this$0, e0 param1e0, View param1View) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.a.a(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */