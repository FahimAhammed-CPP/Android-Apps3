package androidx.core.view;

import android.view.LayoutInflater;

public final class g {
  public static void a(LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2) {
    paramLayoutInflater.setFactory2(paramFactory2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */