package androidx.core.view;

import android.view.View;

public interface r {
  g0 a(View paramView, g0 paramg0);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */