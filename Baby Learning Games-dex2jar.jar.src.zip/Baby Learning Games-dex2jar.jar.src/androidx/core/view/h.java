package androidx.core.view;

import android.view.ViewGroup;

public final class h {
  public static int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams) {
    return paramMarginLayoutParams.getMarginEnd();
  }
  
  public static int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams) {
    return paramMarginLayoutParams.getMarginStart();
  }
  
  public static void c(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt) {
    paramMarginLayoutParams.setMarginEnd(paramInt);
  }
  
  public static void d(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt) {
    paramMarginLayoutParams.setMarginStart(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */