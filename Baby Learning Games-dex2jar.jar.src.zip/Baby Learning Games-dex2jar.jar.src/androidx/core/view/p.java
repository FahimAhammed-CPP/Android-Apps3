package androidx.core.view;

import android.view.View;

public interface p extends o {
  void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */