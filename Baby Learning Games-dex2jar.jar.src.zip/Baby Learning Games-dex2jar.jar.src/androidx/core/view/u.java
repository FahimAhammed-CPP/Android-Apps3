package androidx.core.view;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.Objects;

public final class u implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
  private final View f;
  
  private ViewTreeObserver g;
  
  private final Runnable h;
  
  private u(View paramView, Runnable paramRunnable) {
    this.f = paramView;
    this.g = paramView.getViewTreeObserver();
    this.h = paramRunnable;
  }
  
  public static u a(View paramView, Runnable paramRunnable) {
    Objects.requireNonNull(paramView, "view == null");
    Objects.requireNonNull(paramRunnable, "runnable == null");
    u u1 = new u(paramView, paramRunnable);
    paramView.getViewTreeObserver().addOnPreDrawListener(u1);
    paramView.addOnAttachStateChangeListener(u1);
    return u1;
  }
  
  public void b() {
    if (this.g.isAlive()) {
      this.g.removeOnPreDrawListener(this);
    } else {
      this.f.getViewTreeObserver().removeOnPreDrawListener(this);
    } 
    this.f.removeOnAttachStateChangeListener(this);
  }
  
  public boolean onPreDraw() {
    b();
    this.h.run();
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {
    this.g = paramView.getViewTreeObserver();
  }
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\vie\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */