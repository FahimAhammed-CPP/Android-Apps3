package androidx.core.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class i {
  private final Runnable a;
  
  private final CopyOnWriteArrayList<k> b = new CopyOnWriteArrayList<k>();
  
  private final Map<k, Object> c = new HashMap<k, Object>();
  
  public i(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  public void a(Menu paramMenu, MenuInflater paramMenuInflater) {
    Iterator<k> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((k)iterator.next()).b(paramMenu, paramMenuInflater); 
  }
  
  public boolean b(MenuItem paramMenuItem) {
    Iterator<k> iterator = this.b.iterator();
    while (iterator.hasNext()) {
      if (((k)iterator.next()).a(paramMenuItem))
        return true; 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */