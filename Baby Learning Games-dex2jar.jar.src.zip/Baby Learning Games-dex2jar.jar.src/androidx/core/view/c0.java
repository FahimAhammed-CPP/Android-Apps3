package androidx.core.view;

import android.view.View;

public interface c0 {
  void a(View paramView);
  
  void b(View paramView);
  
  void c(View paramView);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */