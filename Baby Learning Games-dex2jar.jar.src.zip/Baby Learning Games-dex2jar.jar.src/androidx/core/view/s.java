package androidx.core.view;

import android.view.View;

public interface s {
  c a(View paramView, c paramc);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */