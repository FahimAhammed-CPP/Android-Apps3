package androidx.core.view;

import android.graphics.Rect;
import android.view.Gravity;

public final class e {
  public static void a(int paramInt1, int paramInt2, int paramInt3, Rect paramRect1, Rect paramRect2, int paramInt4) {
    Gravity.apply(paramInt1, paramInt2, paramInt3, paramRect1, paramRect2, paramInt4);
  }
  
  public static int b(int paramInt1, int paramInt2) {
    return Gravity.getAbsoluteGravity(paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */