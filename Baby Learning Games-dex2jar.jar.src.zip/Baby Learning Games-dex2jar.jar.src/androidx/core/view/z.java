package androidx.core.view;

import android.view.ViewGroup;

public final class z {
  public static boolean a(ViewGroup paramViewGroup) {
    return paramViewGroup.isTransitionGroup();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */