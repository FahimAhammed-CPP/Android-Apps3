package androidx.core.view;

import android.util.Log;
import android.view.View;
import android.view.ViewParent;

public final class a0 {
  public static boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    try {
      return paramViewParent.onNestedFling(paramView, paramFloat1, paramFloat2, paramBoolean);
    } catch (AbstractMethodError abstractMethodError) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ViewParent ");
      stringBuilder.append(paramViewParent);
      stringBuilder.append(" does not implement interface method onNestedFling");
      Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      return false;
    } 
  }
  
  public static boolean b(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2) {
    try {
      return paramViewParent.onNestedPreFling(paramView, paramFloat1, paramFloat2);
    } catch (AbstractMethodError abstractMethodError) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ViewParent ");
      stringBuilder.append(paramViewParent);
      stringBuilder.append(" does not implement interface method onNestedPreFling");
      Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      return false;
    } 
  }
  
  public static void c(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramViewParent instanceof o) {
      ((o)paramViewParent).j(paramView, paramInt1, paramInt2, paramArrayOfint, paramInt3);
      return;
    } 
    if (paramInt3 == 0)
      try {
        paramViewParent.onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onNestedPreScroll");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
  }
  
  public static void d(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (paramViewParent instanceof p) {
      ((p)paramViewParent).m(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfint);
      return;
    } 
    paramArrayOfint[0] = paramArrayOfint[0] + paramInt3;
    paramArrayOfint[1] = paramArrayOfint[1] + paramInt4;
    if (paramViewParent instanceof o) {
      ((o)paramViewParent).n(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return;
    } 
    if (paramInt5 == 0)
      try {
        paramViewParent.onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onNestedScroll");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
  }
  
  public static void e(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramViewParent instanceof o) {
      ((o)paramViewParent).h(paramView1, paramView2, paramInt1, paramInt2);
      return;
    } 
    if (paramInt2 == 0)
      try {
        paramViewParent.onNestedScrollAccepted(paramView1, paramView2, paramInt1);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onNestedScrollAccepted");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
  }
  
  public static boolean f(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramViewParent instanceof o)
      return ((o)paramViewParent).o(paramView1, paramView2, paramInt1, paramInt2); 
    if (paramInt2 == 0)
      try {
        return paramViewParent.onStartNestedScroll(paramView1, paramView2, paramInt1);
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onStartNestedScroll");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
    return false;
  }
  
  public static void g(ViewParent paramViewParent, View paramView, int paramInt) {
    if (paramViewParent instanceof o) {
      ((o)paramViewParent).i(paramView, paramInt);
      return;
    } 
    if (paramInt == 0)
      try {
        paramViewParent.onStopNestedScroll(paramView);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ViewParent ");
        stringBuilder.append(paramViewParent);
        stringBuilder.append(" does not implement interface method onStopNestedScroll");
        Log.e("ViewParentCompat", stringBuilder.toString(), abstractMethodError);
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */