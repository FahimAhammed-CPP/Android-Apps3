package androidx.core.view;

import android.view.MotionEvent;

public final class l {
  public static boolean a(MotionEvent paramMotionEvent, int paramInt) {
    return ((paramMotionEvent.getSource() & paramInt) == paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\view\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */