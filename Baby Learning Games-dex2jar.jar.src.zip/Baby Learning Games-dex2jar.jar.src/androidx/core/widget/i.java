package androidx.core.widget;

import android.view.View;
import android.widget.PopupWindow;

public final class i {
  public static void a(PopupWindow paramPopupWindow, boolean paramBoolean) {
    b.c(paramPopupWindow, paramBoolean);
  }
  
  public static void b(PopupWindow paramPopupWindow, int paramInt) {
    b.d(paramPopupWindow, paramInt);
  }
  
  public static void c(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3) {
    a.a(paramPopupWindow, paramView, paramInt1, paramInt2, paramInt3);
  }
  
  static class a {
    static void a(PopupWindow param1PopupWindow, View param1View, int param1Int1, int param1Int2, int param1Int3) {
      param1PopupWindow.showAsDropDown(param1View, param1Int1, param1Int2, param1Int3);
    }
  }
  
  static class b {
    static boolean a(PopupWindow param1PopupWindow) {
      return param1PopupWindow.getOverlapAnchor();
    }
    
    static int b(PopupWindow param1PopupWindow) {
      return param1PopupWindow.getWindowLayoutType();
    }
    
    static void c(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setOverlapAnchor(param1Boolean);
    }
    
    static void d(PopupWindow param1PopupWindow, int param1Int) {
      param1PopupWindow.setWindowLayoutType(param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */