package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.core.view.m;
import androidx.core.view.n;
import androidx.core.view.p;
import androidx.core.view.q;
import androidx.core.view.w;
import l0.e;

public class NestedScrollView extends FrameLayout implements p, m {
  private static final a F = new a();
  
  private static final int[] G = new int[] { 16843130 };
  
  private c A;
  
  private final q B;
  
  private final n C;
  
  private float D;
  
  private b E;
  
  private long f;
  
  private final Rect g = new Rect();
  
  private OverScroller h;
  
  public EdgeEffect i;
  
  public EdgeEffect j;
  
  private int k;
  
  private boolean l = true;
  
  private boolean m = false;
  
  private View n = null;
  
  private boolean o = false;
  
  private VelocityTracker p;
  
  private boolean q;
  
  private boolean r = true;
  
  private int s;
  
  private int t;
  
  private int u;
  
  private int v = -1;
  
  private final int[] w = new int[2];
  
  private final int[] x = new int[2];
  
  private int y;
  
  private int z;
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a0.a.c);
  }
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    this.i = e.a(paramContext, paramAttributeSet);
    this.j = e.a(paramContext, paramAttributeSet);
    x();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, G, paramInt, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.B = new q((ViewGroup)this);
    this.C = new n((View)this);
    setNestedScrollingEnabled(true);
    w.o0((View)this, F);
  }
  
  private static boolean A(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && A((View)viewParent, paramView2));
  }
  
  private boolean B(View paramView, int paramInt1, int paramInt2) {
    paramView.getDrawingRect(this.g);
    offsetDescendantRectToMyCoords(paramView, this.g);
    return (this.g.bottom + paramInt1 >= getScrollY() && this.g.top - paramInt1 <= getScrollY() + paramInt2);
  }
  
  private void C(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int i = getScrollY();
    scrollBy(0, paramInt1);
    i = getScrollY() - i;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + i; 
    this.C.e(0, i, 0, paramInt1 - i, null, paramInt2, paramArrayOfint);
  }
  
  private void D(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.v) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.k = (int)paramMotionEvent.getY(i);
      this.v = paramMotionEvent.getPointerId(i);
      VelocityTracker velocityTracker = this.p;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  private void G() {
    VelocityTracker velocityTracker = this.p;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.p = null;
    } 
  }
  
  private int H(int paramInt, float paramFloat) {
    float f1 = paramFloat / getWidth();
    float f2 = paramInt / getHeight();
    float f3 = e.b(this.i);
    paramFloat = 0.0F;
    if (f3 != 0.0F) {
      f1 = -e.d(this.i, -f2, f1);
      paramFloat = f1;
      if (e.b(this.i) == 0.0F) {
        this.i.onRelease();
        paramFloat = f1;
      } 
    } else if (e.b(this.j) != 0.0F) {
      f1 = e.d(this.j, f2, 1.0F - f1);
      paramFloat = f1;
      if (e.b(this.j) == 0.0F) {
        this.j.onRelease();
        paramFloat = f1;
      } 
    } 
    paramInt = Math.round(paramFloat * getHeight());
    if (paramInt != 0)
      invalidate(); 
    return paramInt;
  }
  
  private void I(boolean paramBoolean) {
    if (paramBoolean) {
      Q(2, 1);
    } else {
      S(1);
    } 
    this.z = getScrollY();
    w.f0((View)this);
  }
  
  private boolean J(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1;
    NestedScrollView nestedScrollView;
    int j = getHeight();
    int i = getScrollY();
    j += i;
    boolean bool2 = false;
    if (paramInt1 == 33) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    View view2 = r(bool1, paramInt2, paramInt3);
    View view1 = view2;
    if (view2 == null)
      nestedScrollView = this; 
    if (paramInt2 >= i && paramInt3 <= j) {
      bool1 = bool2;
    } else {
      if (bool1) {
        paramInt2 -= i;
      } else {
        paramInt2 = paramInt3 - j;
      } 
      k(paramInt2);
      bool1 = true;
    } 
    if (nestedScrollView != findFocus())
      nestedScrollView.requestFocus(paramInt1); 
    return bool1;
  }
  
  private void K(View paramView) {
    paramView.getDrawingRect(this.g);
    offsetDescendantRectToMyCoords(paramView, this.g);
    int i = e(this.g);
    if (i != 0)
      scrollBy(0, i); 
  }
  
  private boolean L(Rect paramRect, boolean paramBoolean) {
    boolean bool;
    int i = e(paramRect);
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, i);
        return bool;
      } 
      M(0, i);
    } 
    return bool;
  }
  
  private void N(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.f > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i = view.getHeight();
      int j = layoutParams.topMargin;
      int k = layoutParams.bottomMargin;
      int i1 = getHeight();
      int i2 = getPaddingTop();
      int i3 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, i + j + k - i1 - i2 - i3)));
      this.h.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, paramInt3);
      I(paramBoolean);
    } else {
      if (!this.h.isFinished())
        a(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.f = AnimationUtils.currentAnimationTimeMillis();
  }
  
  private boolean R(MotionEvent paramMotionEvent) {
    boolean bool;
    if (e.b(this.i) != 0.0F) {
      e.d(this.i, 0.0F, paramMotionEvent.getY() / getHeight());
      bool = true;
    } else {
      bool = false;
    } 
    if (e.b(this.j) != 0.0F) {
      e.d(this.j, 0.0F, 1.0F - paramMotionEvent.getY() / getHeight());
      return true;
    } 
    return bool;
  }
  
  private void a() {
    this.h.abortAnimation();
    S(1);
  }
  
  private boolean c() {
    int i = getChildCount();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      bool1 = bool2;
      if (view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > getHeight() - getPaddingTop() - getPaddingBottom())
        bool1 = true; 
    } 
    return bool1;
  }
  
  private static int d(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.D == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.D = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.D;
  }
  
  private void k(int paramInt) {
    if (paramInt != 0) {
      if (this.r) {
        M(0, paramInt);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  private boolean l(int paramInt) {
    if (e.b(this.i) != 0.0F) {
      this.i.onAbsorb(paramInt);
    } else {
      if (e.b(this.j) != 0.0F) {
        this.j.onAbsorb(-paramInt);
        return true;
      } 
      return false;
    } 
    return true;
  }
  
  private void p() {
    this.o = false;
    G();
    S(0);
    this.i.onRelease();
    this.j.onRelease();
  }
  
  private View r(boolean paramBoolean, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_2
    //   2: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   5: astore #14
    //   7: aload #14
    //   9: invokeinterface size : ()I
    //   14: istore #9
    //   16: aconst_null
    //   17: astore #13
    //   19: iconst_0
    //   20: istore #6
    //   22: iload #6
    //   24: istore #7
    //   26: iload #6
    //   28: iload #9
    //   30: if_icmpge -> 250
    //   33: aload #14
    //   35: iload #6
    //   37: invokeinterface get : (I)Ljava/lang/Object;
    //   42: checkcast android/view/View
    //   45: astore #12
    //   47: aload #12
    //   49: invokevirtual getTop : ()I
    //   52: istore #8
    //   54: aload #12
    //   56: invokevirtual getBottom : ()I
    //   59: istore #10
    //   61: aload #13
    //   63: astore #11
    //   65: iload #7
    //   67: istore #5
    //   69: iload_2
    //   70: iload #10
    //   72: if_icmpge -> 233
    //   75: aload #13
    //   77: astore #11
    //   79: iload #7
    //   81: istore #5
    //   83: iload #8
    //   85: iload_3
    //   86: if_icmpge -> 233
    //   89: iload_2
    //   90: iload #8
    //   92: if_icmpge -> 107
    //   95: iload #10
    //   97: iload_3
    //   98: if_icmpge -> 107
    //   101: iconst_1
    //   102: istore #4
    //   104: goto -> 110
    //   107: iconst_0
    //   108: istore #4
    //   110: aload #13
    //   112: ifnonnull -> 126
    //   115: aload #12
    //   117: astore #11
    //   119: iload #4
    //   121: istore #5
    //   123: goto -> 233
    //   126: iload_1
    //   127: ifeq -> 140
    //   130: iload #8
    //   132: aload #13
    //   134: invokevirtual getTop : ()I
    //   137: if_icmplt -> 154
    //   140: iload_1
    //   141: ifne -> 160
    //   144: iload #10
    //   146: aload #13
    //   148: invokevirtual getBottom : ()I
    //   151: if_icmple -> 160
    //   154: iconst_1
    //   155: istore #8
    //   157: goto -> 163
    //   160: iconst_0
    //   161: istore #8
    //   163: iload #7
    //   165: ifeq -> 197
    //   168: aload #13
    //   170: astore #11
    //   172: iload #7
    //   174: istore #5
    //   176: iload #4
    //   178: ifeq -> 233
    //   181: aload #13
    //   183: astore #11
    //   185: iload #7
    //   187: istore #5
    //   189: iload #8
    //   191: ifeq -> 233
    //   194: goto -> 225
    //   197: iload #4
    //   199: ifeq -> 212
    //   202: aload #12
    //   204: astore #11
    //   206: iconst_1
    //   207: istore #5
    //   209: goto -> 233
    //   212: aload #13
    //   214: astore #11
    //   216: iload #7
    //   218: istore #5
    //   220: iload #8
    //   222: ifeq -> 233
    //   225: aload #12
    //   227: astore #11
    //   229: iload #7
    //   231: istore #5
    //   233: iload #6
    //   235: iconst_1
    //   236: iadd
    //   237: istore #6
    //   239: aload #11
    //   241: astore #13
    //   243: iload #5
    //   245: istore #7
    //   247: goto -> 26
    //   250: aload #13
    //   252: areturn
  }
  
  private boolean v(int paramInt1, int paramInt2) {
    int i = getChildCount();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      i = getScrollY();
      View view = getChildAt(0);
      bool1 = bool2;
      if (paramInt2 >= view.getTop() - i) {
        bool1 = bool2;
        if (paramInt2 < view.getBottom() - i) {
          bool1 = bool2;
          if (paramInt1 >= view.getLeft()) {
            bool1 = bool2;
            if (paramInt1 < view.getRight())
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  private void w() {
    VelocityTracker velocityTracker = this.p;
    if (velocityTracker == null) {
      this.p = VelocityTracker.obtain();
      return;
    } 
    velocityTracker.clear();
  }
  
  private void x() {
    this.h = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.s = viewConfiguration.getScaledTouchSlop();
    this.t = viewConfiguration.getScaledMinimumFlingVelocity();
    this.u = viewConfiguration.getScaledMaximumFlingVelocity();
  }
  
  private void y() {
    if (this.p == null)
      this.p = VelocityTracker.obtain(); 
  }
  
  private boolean z(View paramView) {
    return B(paramView, 0, getHeight()) ^ true;
  }
  
  boolean E(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
    boolean bool1;
    int k = getOverScrollMode();
    int i = computeHorizontalScrollRange();
    int j = computeHorizontalScrollExtent();
    boolean bool2 = false;
    if (i > j) {
      i = 1;
    } else {
      i = 0;
    } 
    if (computeVerticalScrollRange() > computeVerticalScrollExtent()) {
      j = 1;
    } else {
      j = 0;
    } 
    if (k == 0 || (k == 1 && i != 0)) {
      i = 1;
    } else {
      i = 0;
    } 
    if (k == 0 || (k == 1 && j != 0)) {
      j = 1;
    } else {
      j = 0;
    } 
    paramInt3 += paramInt1;
    if (i == 0) {
      paramInt1 = 0;
    } else {
      paramInt1 = paramInt7;
    } 
    paramInt4 += paramInt2;
    if (j == 0) {
      paramInt2 = 0;
    } else {
      paramInt2 = paramInt8;
    } 
    paramInt7 = -paramInt1;
    paramInt1 += paramInt5;
    paramInt5 = -paramInt2;
    paramInt2 += paramInt6;
    if (paramInt3 > paramInt1) {
      paramBoolean = true;
    } else if (paramInt3 < paramInt7) {
      paramBoolean = true;
      paramInt1 = paramInt7;
    } else {
      paramBoolean = false;
      paramInt1 = paramInt3;
    } 
    if (paramInt4 > paramInt2) {
      bool1 = true;
    } else if (paramInt4 < paramInt5) {
      bool1 = true;
      paramInt2 = paramInt5;
    } else {
      bool1 = false;
      paramInt2 = paramInt4;
    } 
    if (bool1 && !u(1))
      this.h.springBack(paramInt1, paramInt2, 0, 0, 0, getScrollRange()); 
    onOverScrolled(paramInt1, paramInt2, paramBoolean, bool1);
    if (!paramBoolean) {
      paramBoolean = bool2;
      return bool1 ? true : paramBoolean;
    } 
    return true;
  }
  
  public boolean F(int paramInt) {
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = getHeight();
    if (i) {
      this.g.top = getScrollY() + j;
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.g;
        if (rect1.top + j > i)
          rect1.top = i - j; 
      } 
    } else {
      this.g.top = getScrollY() - j;
      Rect rect1 = this.g;
      if (rect1.top < 0)
        rect1.top = 0; 
    } 
    Rect rect = this.g;
    int i = rect.top;
    j += i;
    rect.bottom = j;
    return J(paramInt, i, j);
  }
  
  public final void M(int paramInt1, int paramInt2) {
    N(paramInt1, paramInt2, 250, false);
  }
  
  void O(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    N(paramInt1 - getScrollX(), paramInt2 - getScrollY(), paramInt3, paramBoolean);
  }
  
  void P(int paramInt1, int paramInt2, boolean paramBoolean) {
    O(paramInt1, paramInt2, 250, paramBoolean);
  }
  
  public boolean Q(int paramInt1, int paramInt2) {
    return this.C.p(paramInt1, paramInt2);
  }
  
  public void S(int paramInt) {
    this.C.r(paramInt);
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public boolean b(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int i = getMaxScrollAmount();
    if (view2 != null && B(view2, i, getHeight())) {
      view2.getDrawingRect(this.g);
      offsetDescendantRectToMyCoords(view2, this.g);
      k(e(this.g));
      view2.requestFocus(paramInt);
    } else {
      int j;
      if (paramInt == 33 && getScrollY() < i) {
        j = getScrollY();
      } else {
        j = i;
        if (paramInt == 130) {
          j = i;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            j = Math.min(view2.getBottom() + layoutParams.bottomMargin - getScrollY() + getHeight() - getPaddingBottom(), i);
          } 
        } 
      } 
      if (j == 0)
        return false; 
      if (paramInt != 130)
        j = -j; 
      k(j);
    } 
    if (view1 != null && view1.isFocused() && z(view1)) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Landroid/widget/OverScroller;
    //   4: invokevirtual isFinished : ()Z
    //   7: ifeq -> 11
    //   10: return
    //   11: aload_0
    //   12: getfield h : Landroid/widget/OverScroller;
    //   15: invokevirtual computeScrollOffset : ()Z
    //   18: pop
    //   19: aload_0
    //   20: getfield h : Landroid/widget/OverScroller;
    //   23: invokevirtual getCurrY : ()I
    //   26: istore_2
    //   27: iload_2
    //   28: aload_0
    //   29: getfield z : I
    //   32: isub
    //   33: istore_1
    //   34: aload_0
    //   35: iload_2
    //   36: putfield z : I
    //   39: aload_0
    //   40: getfield x : [I
    //   43: astore #6
    //   45: iconst_0
    //   46: istore_3
    //   47: aload #6
    //   49: iconst_1
    //   50: iconst_0
    //   51: iastore
    //   52: aload_0
    //   53: iconst_0
    //   54: iload_1
    //   55: aload #6
    //   57: aconst_null
    //   58: iconst_1
    //   59: invokevirtual f : (II[I[II)Z
    //   62: pop
    //   63: iload_1
    //   64: aload_0
    //   65: getfield x : [I
    //   68: iconst_1
    //   69: iaload
    //   70: isub
    //   71: istore_2
    //   72: aload_0
    //   73: invokevirtual getScrollRange : ()I
    //   76: istore #4
    //   78: iload_2
    //   79: istore_1
    //   80: iload_2
    //   81: ifeq -> 153
    //   84: aload_0
    //   85: invokevirtual getScrollY : ()I
    //   88: istore_1
    //   89: aload_0
    //   90: iconst_0
    //   91: iload_2
    //   92: aload_0
    //   93: invokevirtual getScrollX : ()I
    //   96: iload_1
    //   97: iconst_0
    //   98: iload #4
    //   100: iconst_0
    //   101: iconst_0
    //   102: iconst_0
    //   103: invokevirtual E : (IIIIIIIIZ)Z
    //   106: pop
    //   107: aload_0
    //   108: invokevirtual getScrollY : ()I
    //   111: iload_1
    //   112: isub
    //   113: istore_1
    //   114: iload_2
    //   115: iload_1
    //   116: isub
    //   117: istore_2
    //   118: aload_0
    //   119: getfield x : [I
    //   122: astore #6
    //   124: aload #6
    //   126: iconst_1
    //   127: iconst_0
    //   128: iastore
    //   129: aload_0
    //   130: iconst_0
    //   131: iload_1
    //   132: iconst_0
    //   133: iload_2
    //   134: aload_0
    //   135: getfield w : [I
    //   138: iconst_1
    //   139: aload #6
    //   141: invokevirtual g : (IIII[II[I)V
    //   144: iload_2
    //   145: aload_0
    //   146: getfield x : [I
    //   149: iconst_1
    //   150: iaload
    //   151: isub
    //   152: istore_1
    //   153: iload_1
    //   154: ifeq -> 250
    //   157: aload_0
    //   158: invokevirtual getOverScrollMode : ()I
    //   161: istore #5
    //   163: iload #5
    //   165: ifeq -> 183
    //   168: iload_3
    //   169: istore_2
    //   170: iload #5
    //   172: iconst_1
    //   173: if_icmpne -> 185
    //   176: iload_3
    //   177: istore_2
    //   178: iload #4
    //   180: ifle -> 185
    //   183: iconst_1
    //   184: istore_2
    //   185: iload_2
    //   186: ifeq -> 246
    //   189: iload_1
    //   190: ifge -> 221
    //   193: aload_0
    //   194: getfield i : Landroid/widget/EdgeEffect;
    //   197: invokevirtual isFinished : ()Z
    //   200: ifeq -> 246
    //   203: aload_0
    //   204: getfield i : Landroid/widget/EdgeEffect;
    //   207: aload_0
    //   208: getfield h : Landroid/widget/OverScroller;
    //   211: invokevirtual getCurrVelocity : ()F
    //   214: f2i
    //   215: invokevirtual onAbsorb : (I)V
    //   218: goto -> 246
    //   221: aload_0
    //   222: getfield j : Landroid/widget/EdgeEffect;
    //   225: invokevirtual isFinished : ()Z
    //   228: ifeq -> 246
    //   231: aload_0
    //   232: getfield j : Landroid/widget/EdgeEffect;
    //   235: aload_0
    //   236: getfield h : Landroid/widget/OverScroller;
    //   239: invokevirtual getCurrVelocity : ()F
    //   242: f2i
    //   243: invokevirtual onAbsorb : (I)V
    //   246: aload_0
    //   247: invokespecial a : ()V
    //   250: aload_0
    //   251: getfield h : Landroid/widget/OverScroller;
    //   254: invokevirtual isFinished : ()Z
    //   257: ifne -> 265
    //   260: aload_0
    //   261: invokestatic f0 : (Landroid/view/View;)V
    //   264: return
    //   265: aload_0
    //   266: iconst_1
    //   267: invokevirtual S : (I)V
    //   270: return
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int j = getChildCount();
    int i = getHeight() - getPaddingBottom() - getPaddingTop();
    if (j == 0)
      return i; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    j = view.getBottom() + layoutParams.bottomMargin;
    int k = getScrollY();
    int i1 = Math.max(0, j - i);
    if (k < 0)
      return j - k; 
    i = j;
    if (k > i1)
      i = j + k - i1; 
    return i;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || q(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.C.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.C.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return f(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.C.f(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    int i = getScrollY();
    boolean bool = this.i.isFinished();
    byte b1 = 0;
    if (!bool) {
      boolean bool1;
      int i4 = paramCanvas.save();
      int j = getWidth();
      int i3 = getHeight();
      int i2 = Math.min(0, i);
      if (getClipToPadding()) {
        j -= getPaddingLeft() + getPaddingRight();
        bool1 = getPaddingLeft() + 0;
      } else {
        bool1 = false;
      } 
      int i1 = i3;
      int k = i2;
      if (getClipToPadding()) {
        i1 = i3 - getPaddingTop() + getPaddingBottom();
        k = i2 + getPaddingTop();
      } 
      paramCanvas.translate(bool1, k);
      this.i.setSize(j, i1);
      if (this.i.draw(paramCanvas))
        w.f0((View)this); 
      paramCanvas.restoreToCount(i4);
    } 
    if (!this.j.isFinished()) {
      int i5 = paramCanvas.save();
      int i1 = getWidth();
      int i3 = getHeight();
      int i4 = Math.max(getScrollRange(), i) + i3;
      int k = b1;
      int j = i1;
      if (getClipToPadding()) {
        j = i1 - getPaddingLeft() + getPaddingRight();
        k = 0 + getPaddingLeft();
      } 
      int i2 = i4;
      i1 = i3;
      if (getClipToPadding()) {
        i1 = i3 - getPaddingTop() + getPaddingBottom();
        i2 = i4 - getPaddingBottom();
      } 
      paramCanvas.translate((k - j), i2);
      paramCanvas.rotate(180.0F, j, 0.0F);
      this.j.setSize(j, i1);
      if (this.j.draw(paramCanvas))
        w.f0((View)this); 
      paramCanvas.restoreToCount(i5);
    } 
  }
  
  protected int e(Rect paramRect) {
    int i = getChildCount();
    boolean bool = false;
    if (i == 0)
      return 0; 
    int i1 = getHeight();
    int j = getScrollY();
    int k = j + i1;
    int i2 = getVerticalFadingEdgeLength();
    i = j;
    if (paramRect.top > 0)
      i = j + i2; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      j = k - i2;
    } else {
      j = k;
    } 
    i2 = paramRect.bottom;
    if (i2 > j && paramRect.top > i) {
      if (paramRect.height() > i1) {
        i = paramRect.top - i;
      } else {
        i = paramRect.bottom - j;
      } 
      return Math.min(i + 0, view.getBottom() + layoutParams.bottomMargin - k);
    } 
    k = bool;
    if (paramRect.top < i) {
      k = bool;
      if (i2 < j) {
        if (paramRect.height() > i1) {
          i = 0 - j - paramRect.bottom;
        } else {
          i = 0 - i - paramRect.top;
        } 
        k = Math.max(i, -getScrollY());
      } 
    } 
    return k;
  }
  
  public boolean f(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.C.d(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public void g(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint1, int paramInt5, int[] paramArrayOfint2) {
    this.C.e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint1, paramInt5, paramArrayOfint2);
  }
  
  protected float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int i = getVerticalFadingEdgeLength();
    int j = getHeight();
    int k = getPaddingBottom();
    j = view.getBottom() + layoutParams.bottomMargin - getScrollY() - j - k;
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.B.a();
  }
  
  int getScrollRange() {
    int j = getChildCount();
    int i = 0;
    if (j > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      i = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return i;
  }
  
  protected float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int i = getVerticalFadingEdgeLength();
    int j = getScrollY();
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.B.c(paramView1, paramView2, paramInt1, paramInt2);
    Q(2, paramInt2);
  }
  
  public boolean hasNestedScrollingParent() {
    return u(0);
  }
  
  public void i(View paramView, int paramInt) {
    this.B.d(paramView, paramInt);
    S(paramInt);
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.C.l();
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    f(paramInt1, paramInt2, paramArrayOfint, null, paramInt3);
  }
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    C(paramInt4, paramInt5, paramArrayOfint);
  }
  
  protected void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  protected void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    C(paramInt4, paramInt5, null);
  }
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return ((paramInt1 & 0x2) != 0);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.m = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) != 0) {
      if (paramMotionEvent.getAction() != 8)
        return false; 
      if (!this.o) {
        float f = paramMotionEvent.getAxisValue(9);
        if (f != 0.0F) {
          int j = (int)(f * getVerticalScrollFactorCompat());
          int i = getScrollRange();
          int k = getScrollY();
          j = k - j;
          if (j < 0) {
            i = 0;
          } else if (j <= i) {
            i = j;
          } 
          if (i != k) {
            super.scrollTo(getScrollX(), i);
            return true;
          } 
        } 
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    ViewParent viewParent;
    int i = paramMotionEvent.getAction();
    boolean bool2 = true;
    boolean bool1 = true;
    if (i == 2 && this.o)
      return true; 
    i &= 0xFF;
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            if (i == 6)
              D(paramMotionEvent); 
            return this.o;
          } 
        } else {
          i = this.v;
          if (i != -1) {
            StringBuilder stringBuilder;
            int j = paramMotionEvent.findPointerIndex(i);
            if (j == -1) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Invalid pointerId=");
              stringBuilder.append(i);
              stringBuilder.append(" in onInterceptTouchEvent");
              Log.e("NestedScrollView", stringBuilder.toString());
            } else {
              i = (int)stringBuilder.getY(j);
              if (Math.abs(i - this.k) > this.s && (0x2 & getNestedScrollAxes()) == 0) {
                this.o = true;
                this.k = i;
                y();
                this.p.addMovement((MotionEvent)stringBuilder);
                this.y = 0;
                viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
              } 
            } 
          } 
          return this.o;
        }  
      this.o = false;
      this.v = -1;
      G();
      if (this.h.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
        w.f0((View)this); 
      S(0);
    } else {
      i = (int)viewParent.getY();
      if (!v((int)viewParent.getX(), i)) {
        boolean bool = bool1;
        if (!R((MotionEvent)viewParent))
          if (!this.h.isFinished()) {
            bool = bool1;
          } else {
            bool = false;
          }  
        this.o = bool;
        G();
      } else {
        this.k = i;
        this.v = viewParent.getPointerId(0);
        w();
        this.p.addMovement((MotionEvent)viewParent);
        this.h.computeScrollOffset();
        boolean bool = bool2;
        if (!R((MotionEvent)viewParent))
          if (!this.h.isFinished()) {
            bool = bool2;
          } else {
            bool = false;
          }  
        this.o = bool;
        Q(2, 0);
      } 
    } 
    return this.o;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = 0;
    this.l = false;
    View view = this.n;
    if (view != null && A(view, (View)this))
      K(this.n); 
    this.n = null;
    if (!this.m) {
      if (this.A != null) {
        scrollTo(getScrollX(), this.A.f);
        this.A = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int i = getPaddingTop();
      int j = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = d(paramInt3, paramInt4 - paramInt2 - i - j, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.m = true;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.q)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      paramInt2 = view.getMeasuredHeight();
      int i = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (paramInt2 < i)
        view.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(i, 1073741824)); 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      s((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    j(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    C(paramInt4, 0, null);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    h(paramView1, paramView2, paramInt, 0);
  }
  
  protected void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int i;
    View view;
    if (paramInt == 2) {
      i = 130;
    } else {
      i = paramInt;
      if (paramInt == 1)
        i = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, i);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, i);
    } 
    return (view == null) ? false : (z(view) ? false : view.requestFocus(i, paramRect));
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof c)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    c c1 = (c)paramParcelable;
    super.onRestoreInstanceState(c1.getSuperState());
    this.A = c1;
    requestLayout();
  }
  
  protected Parcelable onSaveInstanceState() {
    c c1 = new c(super.onSaveInstanceState());
    c1.f = getScrollY();
    return (Parcelable)c1;
  }
  
  protected void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    b b1 = this.E;
    if (b1 != null)
      b1.a(this, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (B(view, 0, paramInt4)) {
        view.getDrawingRect(this.g);
        offsetDescendantRectToMyCoords(view, this.g);
        k(e(this.g));
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return o(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    i(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    y();
    int i = paramMotionEvent.getActionMasked();
    boolean bool = false;
    if (i == 0)
      this.y = 0; 
    MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
    motionEvent.offsetLocation(0.0F, this.y);
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i == 6) {
                D(paramMotionEvent);
                this.k = (int)paramMotionEvent.getY(paramMotionEvent.findPointerIndex(this.v));
              } 
            } else {
              i = paramMotionEvent.getActionIndex();
              this.k = (int)paramMotionEvent.getY(i);
              this.v = paramMotionEvent.getPointerId(i);
            } 
          } else {
            if (this.o && getChildCount() > 0 && this.h.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
              w.f0((View)this); 
            this.v = -1;
            p();
          } 
        } else {
          StringBuilder stringBuilder;
          int j = paramMotionEvent.findPointerIndex(this.v);
          if (j == -1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid pointerId=");
            stringBuilder.append(this.v);
            stringBuilder.append(" in onTouchEvent");
            Log.e("NestedScrollView", stringBuilder.toString());
          } else {
            int i1 = (int)stringBuilder.getY(j);
            i = this.k - i1;
            int k = i - H(i, stringBuilder.getX(j));
            i = k;
            if (!this.o) {
              i = k;
              if (Math.abs(k) > this.s) {
                ViewParent viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
                this.o = true;
                if (k > 0) {
                  i = k - this.s;
                } else {
                  i = k + this.s;
                } 
              } 
            } 
            if (this.o) {
              k = i;
              if (f(0, i, this.x, this.w, 0)) {
                k = i - this.x[1];
                this.y += this.w[1];
              } 
              this.k = i1 - this.w[1];
              int i3 = getScrollY();
              int i2 = getScrollRange();
              i = getOverScrollMode();
              if (i == 0 || (i == 1 && i2 > 0)) {
                i1 = 1;
              } else {
                i1 = 0;
              } 
              if (E(0, k, 0, getScrollY(), 0, i2, 0, 0, true) && !u(0)) {
                i = 1;
              } else {
                i = 0;
              } 
              int i4 = getScrollY() - i3;
              int[] arrayOfInt = this.x;
              arrayOfInt[1] = 0;
              g(0, i4, 0, k - i4, this.w, 0, arrayOfInt);
              i4 = this.k;
              arrayOfInt = this.w;
              this.k = i4 - arrayOfInt[1];
              this.y += arrayOfInt[1];
              if (i1 != 0) {
                k -= this.x[1];
                i1 = i3 + k;
                if (i1 < 0) {
                  e.d(this.i, -k / getHeight(), stringBuilder.getX(j) / getWidth());
                  if (!this.j.isFinished())
                    this.j.onRelease(); 
                } else if (i1 > i2) {
                  e.d(this.j, k / getHeight(), 1.0F - stringBuilder.getX(j) / getWidth());
                  if (!this.i.isFinished())
                    this.i.onRelease(); 
                } 
                if (!this.i.isFinished() || !this.j.isFinished()) {
                  w.f0((View)this);
                  i = bool;
                } 
              } 
              if (i != 0)
                this.p.clear(); 
            } 
          } 
        } 
      } else {
        velocityTracker = this.p;
        velocityTracker.computeCurrentVelocity(1000, this.u);
        i = (int)velocityTracker.getYVelocity(this.v);
        if (Math.abs(i) >= this.t) {
          if (!l(i)) {
            i = -i;
            float f = i;
            if (!dispatchNestedPreFling(0.0F, f)) {
              dispatchNestedFling(0.0F, f, true);
              s(i);
            } 
          } 
        } else if (this.h.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
          w.f0((View)this);
        } 
        this.v = -1;
        p();
      } 
    } else {
      if (getChildCount() == 0)
        return false; 
      if (this.o) {
        ViewParent viewParent = getParent();
        if (viewParent != null)
          viewParent.requestDisallowInterceptTouchEvent(true); 
      } 
      if (!this.h.isFinished())
        a(); 
      this.k = (int)velocityTracker.getY();
      this.v = velocityTracker.getPointerId(0);
      Q(2, 0);
    } 
    VelocityTracker velocityTracker = this.p;
    if (velocityTracker != null)
      velocityTracker.addMovement(motionEvent); 
    motionEvent.recycle();
    return true;
  }
  
  public boolean q(KeyEvent paramKeyEvent) {
    View view;
    this.g.setEmpty();
    boolean bool3 = c();
    boolean bool1 = false;
    boolean bool2 = false;
    char c1 = '';
    if (!bool3) {
      bool1 = bool2;
      if (isFocused()) {
        bool1 = bool2;
        if (paramKeyEvent.getKeyCode() != 4) {
          View view1 = findFocus();
          view = view1;
          if (view1 == this)
            view = null; 
          view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view, 130);
          bool1 = bool2;
          if (view != null) {
            bool1 = bool2;
            if (view != this) {
              bool1 = bool2;
              if (view.requestFocus(130))
                bool1 = true; 
            } 
          } 
        } 
      } 
      return bool1;
    } 
    if (view.getAction() == 0) {
      int i = view.getKeyCode();
      if (i != 19) {
        if (i != 20) {
          if (i != 62)
            return false; 
          if (view.isShiftPressed())
            c1 = '!'; 
          F(c1);
          return false;
        } 
        return !view.isAltPressed() ? b(130) : t(130);
      } 
      if (!view.isAltPressed())
        return b(33); 
      bool1 = t(33);
    } 
    return bool1;
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.l) {
      K(paramView2);
    } else {
      this.n = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    return L(paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      G(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.l = true;
    super.requestLayout();
  }
  
  public void s(int paramInt) {
    if (getChildCount() > 0) {
      this.h.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      I(true);
    } 
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i4 = getWidth();
      int i5 = getPaddingLeft();
      int i6 = getPaddingRight();
      int i7 = view.getWidth();
      int i8 = layoutParams.leftMargin;
      int i9 = layoutParams.rightMargin;
      int i = getHeight();
      int j = getPaddingTop();
      int k = getPaddingBottom();
      int i1 = view.getHeight();
      int i2 = layoutParams.topMargin;
      int i3 = layoutParams.bottomMargin;
      paramInt1 = d(paramInt1, i4 - i5 - i6, i7 + i8 + i9);
      paramInt2 = d(paramInt2, i - j - k, i1 + i2 + i3);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.q) {
      this.q = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.C.m(paramBoolean);
  }
  
  public void setOnScrollChangeListener(b paramb) {
    this.E = paramb;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.r = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return Q(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    S(0);
  }
  
  public boolean t(int paramInt) {
    int i;
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = getHeight();
    Rect rect = this.g;
    rect.top = 0;
    rect.bottom = j;
    if (i) {
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        this.g.bottom = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.g;
        rect1.top = rect1.bottom - j;
      } 
    } 
    rect = this.g;
    return J(paramInt, rect.top, rect.bottom);
  }
  
  public boolean u(int paramInt) {
    return this.C.k(paramInt);
  }
  
  static class a extends androidx.core.view.a {
    public void f(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      super.f(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      e.a((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollX());
      e.b((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollRange());
    }
    
    public void g(View param1View, l0.c param1c) {
      super.g(param1View, param1c);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1c.a0(ScrollView.class.getName());
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1c.s0(true);
          if (nestedScrollView.getScrollY() > 0) {
            param1c.b(l0.c.a.r);
            param1c.b(l0.c.a.C);
          } 
          if (nestedScrollView.getScrollY() < i) {
            param1c.b(l0.c.a.q);
            param1c.b(l0.c.a.E);
          } 
        } 
      } 
    }
    
    public boolean j(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.j(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      if (param1Int != 4096)
        if (param1Int != 8192 && param1Int != 16908344) {
          if (param1Int != 16908346)
            return false; 
        } else {
          param1Int = nestedScrollView.getHeight();
          int k = nestedScrollView.getPaddingBottom();
          int m = nestedScrollView.getPaddingTop();
          param1Int = Math.max(nestedScrollView.getScrollY() - param1Int - k - m, 0);
          if (param1Int != nestedScrollView.getScrollY()) {
            nestedScrollView.P(0, param1Int, true);
            return true;
          } 
          return false;
        }  
      param1Int = nestedScrollView.getHeight();
      int i = nestedScrollView.getPaddingBottom();
      int j = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + param1Int - i - j, nestedScrollView.getScrollRange());
      if (param1Int != nestedScrollView.getScrollY()) {
        nestedScrollView.P(0, param1Int, true);
        return true;
      } 
      return false;
    }
  }
  
  public static interface b {
    void a(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
  }
  
  static class c extends View.BaseSavedState {
    public static final Parcelable.Creator<c> CREATOR = new a();
    
    public int f;
    
    c(Parcel param1Parcel) {
      super(param1Parcel);
      this.f = param1Parcel.readInt();
    }
    
    c(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      stringBuilder.append(this.f);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.f);
    }
    
    class a implements Parcelable.Creator<c> {
      public NestedScrollView.c a(Parcel param2Parcel) {
        return new NestedScrollView.c(param2Parcel);
      }
      
      public NestedScrollView.c[] b(int param2Int) {
        return new NestedScrollView.c[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<c> {
    public NestedScrollView.c a(Parcel param1Parcel) {
      return new NestedScrollView.c(param1Parcel);
    }
    
    public NestedScrollView.c[] b(int param1Int) {
      return new NestedScrollView.c[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */