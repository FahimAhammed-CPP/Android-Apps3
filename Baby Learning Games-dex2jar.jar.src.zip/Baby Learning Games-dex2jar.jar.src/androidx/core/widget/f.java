package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.widget.ImageView;

public class f {
  public static ColorStateList a(ImageView paramImageView) {
    return paramImageView.getImageTintList();
  }
  
  public static PorterDuff.Mode b(ImageView paramImageView) {
    return paramImageView.getImageTintMode();
  }
  
  public static void c(ImageView paramImageView, ColorStateList paramColorStateList) {
    paramImageView.setImageTintList(paramColorStateList);
  }
  
  public static void d(ImageView paramImageView, PorterDuff.Mode paramMode) {
    paramImageView.setImageTintMode(paramMode);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */