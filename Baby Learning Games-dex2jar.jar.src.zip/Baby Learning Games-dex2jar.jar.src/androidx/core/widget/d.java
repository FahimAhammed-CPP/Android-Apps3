package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;

public final class d {
  public static Drawable a(CompoundButton paramCompoundButton) {
    return paramCompoundButton.getButtonDrawable();
  }
  
  public static ColorStateList b(CompoundButton paramCompoundButton) {
    return paramCompoundButton.getButtonTintList();
  }
  
  public static void c(CompoundButton paramCompoundButton, ColorStateList paramColorStateList) {
    paramCompoundButton.setButtonTintList(paramColorStateList);
  }
  
  public static void d(CompoundButton paramCompoundButton, PorterDuff.Mode paramMode) {
    paramCompoundButton.setButtonTintMode(paramMode);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */