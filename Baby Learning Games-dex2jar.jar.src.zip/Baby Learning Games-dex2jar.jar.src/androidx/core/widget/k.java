package androidx.core.widget;

import android.content.ClipData;
import android.content.Context;
import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.core.view.c;
import androidx.core.view.s;

public final class k implements s {
  private static CharSequence b(Context paramContext, ClipData.Item paramItem, int paramInt) {
    return a.a(paramContext, paramItem, paramInt);
  }
  
  private static void c(Editable paramEditable, CharSequence paramCharSequence) {
    int j = Selection.getSelectionStart((CharSequence)paramEditable);
    int m = Selection.getSelectionEnd((CharSequence)paramEditable);
    int i = Math.max(0, Math.min(j, m));
    j = Math.max(0, Math.max(j, m));
    Selection.setSelection((Spannable)paramEditable, j);
    paramEditable.replace(i, j, paramCharSequence);
  }
  
  public c a(View paramView, c paramc) {
    if (Log.isLoggable("ReceiveContent", 3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onReceive: ");
      stringBuilder.append(paramc);
      Log.d("ReceiveContent", stringBuilder.toString());
    } 
    if (paramc.d() == 2)
      return paramc; 
    ClipData clipData = paramc.b();
    int j = paramc.c();
    TextView textView = (TextView)paramView;
    Editable editable = (Editable)textView.getText();
    Context context = textView.getContext();
    int i = 0;
    boolean bool;
    for (bool = false; i < clipData.getItemCount(); bool = bool1) {
      CharSequence charSequence = b(context, clipData.getItemAt(i), j);
      boolean bool1 = bool;
      if (charSequence != null)
        if (!bool) {
          c(editable, charSequence);
          bool1 = true;
        } else {
          editable.insert(Selection.getSelectionEnd((CharSequence)editable), "\n");
          editable.insert(Selection.getSelectionEnd((CharSequence)editable), charSequence);
          bool1 = bool;
        }  
      i++;
    } 
    return null;
  }
  
  private static final class a {
    static CharSequence a(Context param1Context, ClipData.Item param1Item, int param1Int) {
      CharSequence charSequence1;
      CharSequence charSequence2;
      if ((param1Int & 0x1) != 0) {
        charSequence2 = param1Item.coerceToText(param1Context);
        charSequence1 = charSequence2;
        if (charSequence2 instanceof android.text.Spanned)
          charSequence1 = charSequence2.toString(); 
        return charSequence1;
      } 
      return charSequence2.coerceToStyledText((Context)charSequence1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */