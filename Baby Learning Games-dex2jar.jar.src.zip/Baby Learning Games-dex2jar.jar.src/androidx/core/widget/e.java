package androidx.core.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.EdgeEffect;

public final class e {
  public static EdgeEffect a(Context paramContext, AttributeSet paramAttributeSet) {
    return h0.a.c() ? a.a(paramContext, paramAttributeSet) : new EdgeEffect(paramContext);
  }
  
  public static float b(EdgeEffect paramEdgeEffect) {
    return h0.a.c() ? a.b(paramEdgeEffect) : 0.0F;
  }
  
  public static void c(EdgeEffect paramEdgeEffect, float paramFloat1, float paramFloat2) {
    paramEdgeEffect.onPull(paramFloat1, paramFloat2);
  }
  
  public static float d(EdgeEffect paramEdgeEffect, float paramFloat1, float paramFloat2) {
    if (h0.a.c())
      return a.c(paramEdgeEffect, paramFloat1, paramFloat2); 
    c(paramEdgeEffect, paramFloat1, paramFloat2);
    return paramFloat1;
  }
  
  private static class a {
    public static EdgeEffect a(Context param1Context, AttributeSet param1AttributeSet) {
      try {
        return new EdgeEffect(param1Context, param1AttributeSet);
      } finally {
        param1AttributeSet = null;
      } 
    }
    
    public static float b(EdgeEffect param1EdgeEffect) {
      try {
        return param1EdgeEffect.getDistance();
      } finally {
        param1EdgeEffect = null;
      } 
    }
    
    public static float c(EdgeEffect param1EdgeEffect, float param1Float1, float param1Float2) {
      try {
        return param1EdgeEffect.onPullDistance(param1Float1, param1Float2);
      } finally {
        Exception exception = null;
        param1EdgeEffect.onPull(param1Float1, param1Float2);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\core\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */