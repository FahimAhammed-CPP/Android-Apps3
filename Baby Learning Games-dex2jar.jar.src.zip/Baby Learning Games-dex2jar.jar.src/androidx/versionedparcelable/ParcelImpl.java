package androidx.versionedparcelable;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import m1.b;

@SuppressLint({"BanParcelableUsage"})
public class ParcelImpl implements Parcelable {
  public static final Parcelable.Creator<ParcelImpl> CREATOR = new a();
  
  private final b f;
  
  protected ParcelImpl(Parcel paramParcel) {
    this.f = (new b(paramParcel)).u();
  }
  
  public <T extends b> T a() {
    return (T)this.f;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    (new b(paramParcel)).L(this.f);
  }
  
  static final class a implements Parcelable.Creator<ParcelImpl> {
    public ParcelImpl a(Parcel param1Parcel) {
      return new ParcelImpl(param1Parcel);
    }
    
    public ParcelImpl[] b(int param1Int) {
      return new ParcelImpl[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\versionedparcelable\ParcelImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */