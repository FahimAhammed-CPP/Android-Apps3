package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;
import w.e;

public class g extends View {
  private int f;
  
  private View g;
  
  private int h;
  
  public void a(ConstraintLayout paramConstraintLayout) {
    if (this.g == null)
      return; 
    ConstraintLayout.b b1 = (ConstraintLayout.b)getLayoutParams();
    ConstraintLayout.b b2 = (ConstraintLayout.b)this.g.getLayoutParams();
    b2.v0.g1(0);
    e.b b3 = b1.v0.y();
    e.b b4 = e.b.f;
    if (b3 != b4)
      b1.v0.h1(b2.v0.U()); 
    if (b1.v0.R() != b4)
      b1.v0.I0(b2.v0.v()); 
    b2.v0.g1(8);
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {
    if (this.f == -1 && !isInEditMode())
      setVisibility(this.h); 
    View view = paramConstraintLayout.findViewById(this.f);
    this.g = view;
    if (view != null) {
      ((ConstraintLayout.b)view.getLayoutParams()).j0 = true;
      this.g.setVisibility(0);
      setVisibility(0);
    } 
  }
  
  public View getContent() {
    return this.g;
  }
  
  public int getEmptyVisibility() {
    return this.h;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (isInEditMode()) {
      paramCanvas.drawRGB(223, 223, 223);
      Paint paint = new Paint();
      paint.setARGB(255, 210, 210, 210);
      paint.setTextAlign(Paint.Align.CENTER);
      paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
      Rect rect = new Rect();
      paramCanvas.getClipBounds(rect);
      paint.setTextSize(rect.height());
      int i = rect.height();
      int j = rect.width();
      paint.setTextAlign(Paint.Align.LEFT);
      paint.getTextBounds("?", 0, 1, rect);
      paramCanvas.drawText("?", j / 2.0F - rect.width() / 2.0F - rect.left, i / 2.0F + rect.height() / 2.0F - rect.bottom, paint);
    } 
  }
  
  public void setContentId(int paramInt) {
    if (this.f == paramInt)
      return; 
    View view = this.g;
    if (view != null) {
      view.setVisibility(0);
      ((ConstraintLayout.b)this.g.getLayoutParams()).j0 = false;
      this.g = null;
    } 
    this.f = paramInt;
    if (paramInt != -1) {
      view = ((View)getParent()).findViewById(paramInt);
      if (view != null)
        view.setVisibility(8); 
    } 
  }
  
  public void setEmptyVisibility(int paramInt) {
    this.h = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\constraintlayout\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */