package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import w.a;
import w.e;
import w.h;

public class Barrier extends b {
  private int o;
  
  private int p;
  
  private a q;
  
  public Barrier(Context paramContext) {
    super(paramContext);
    setVisibility(8);
  }
  
  public Barrier(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setVisibility(8);
  }
  
  private void t(e parame, int paramInt, boolean paramBoolean) {
    this.p = paramInt;
    if (paramBoolean) {
      paramInt = this.o;
      if (paramInt == 5) {
        this.p = 1;
      } else if (paramInt == 6) {
        this.p = 0;
      } 
    } else {
      paramInt = this.o;
      if (paramInt == 5) {
        this.p = 0;
      } else if (paramInt == 6) {
        this.p = 1;
      } 
    } 
    if (parame instanceof a)
      ((a)parame).x1(this.p); 
  }
  
  public boolean getAllowsGoneWidget() {
    return this.q.r1();
  }
  
  public int getMargin() {
    return this.q.t1();
  }
  
  public int getType() {
    return this.o;
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    this.q = new a();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == i.w1) {
          setType(typedArray.getInt(k, 0));
        } else if (k == i.v1) {
          this.q.w1(typedArray.getBoolean(k, true));
        } else if (k == i.x1) {
          k = typedArray.getDimensionPixelSize(k, 0);
          this.q.y1(k);
        } 
      } 
      typedArray.recycle();
    } 
    this.i = (h)this.q;
    s();
  }
  
  public void n(e parame, boolean paramBoolean) {
    t(parame, this.o, paramBoolean);
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.q.w1(paramBoolean);
  }
  
  public void setDpMargin(int paramInt) {
    float f = (getResources().getDisplayMetrics()).density;
    paramInt = (int)(paramInt * f + 0.5F);
    this.q.y1(paramInt);
  }
  
  public void setMargin(int paramInt) {
    this.q.y1(paramInt);
  }
  
  public void setType(int paramInt) {
    this.o = paramInt;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\constraintlayout\widget\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */