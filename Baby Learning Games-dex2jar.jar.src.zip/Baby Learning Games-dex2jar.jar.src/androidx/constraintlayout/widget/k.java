package androidx.constraintlayout.widget;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;

public abstract class k extends b {
  private boolean o;
  
  private boolean p;
  
  protected void i(ConstraintLayout paramConstraintLayout) {
    h(paramConstraintLayout);
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int m = typedArray.getIndex(i);
        if (m == i.p1) {
          this.o = true;
        } else if (m == i.u1) {
          this.p = true;
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.o || this.p) {
      ViewParent viewParent = getParent();
      if (viewParent instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)viewParent;
        int j = getVisibility();
        float f = getElevation();
        for (int i = 0; i < this.g; i++) {
          View view = constraintLayout.l(this.f[i]);
          if (view != null) {
            if (this.o)
              view.setVisibility(j); 
            if (this.p && f > 0.0F)
              view.setTranslationZ(view.getTranslationZ() + f); 
          } 
        } 
      } 
    } 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    g();
  }
  
  public void setVisibility(int paramInt) {
    super.setVisibility(paramInt);
    g();
  }
  
  public void t(w.k paramk, int paramInt1, int paramInt2) {}
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\constraintlayout\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */