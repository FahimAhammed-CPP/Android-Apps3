package androidx.constraintlayout.widget;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;

public class a {
  private boolean a;
  
  String b;
  
  private b c;
  
  private int d;
  
  private float e;
  
  private String f;
  
  boolean g;
  
  private int h;
  
  public a(a parama, Object paramObject) {
    this.a = false;
    this.b = parama.b;
    this.c = parama.c;
    f(paramObject);
  }
  
  public a(String paramString, b paramb, Object paramObject, boolean paramBoolean) {
    this.b = paramString;
    this.c = paramb;
    this.a = paramBoolean;
    f(paramObject);
  }
  
  public static HashMap<String, a> a(HashMap<String, a> paramHashMap, View paramView) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Class<?> clazz = paramView.getClass();
    for (String str : paramHashMap.keySet()) {
      a a1 = paramHashMap.get(str);
      try {
        if (str.equals("BackgroundColor")) {
          hashMap.put(str, new a(a1, Integer.valueOf(((ColorDrawable)paramView.getBackground()).getColor())));
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getMap");
        stringBuilder.append(str);
        hashMap.put(str, new a(a1, clazz.getMethod(stringBuilder.toString(), new Class[0]).invoke(paramView, new Object[0])));
      } catch (NoSuchMethodException noSuchMethodException) {
        noSuchMethodException.printStackTrace();
      } catch (IllegalAccessException illegalAccessException) {
        illegalAccessException.printStackTrace();
      } catch (InvocationTargetException invocationTargetException) {
        invocationTargetException.printStackTrace();
      } 
    } 
    return (HashMap)hashMap;
  }
  
  public static void d(Context paramContext, XmlPullParser paramXmlPullParser, HashMap<String, a> paramHashMap) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge Z and I\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static void e(View paramView, HashMap<String, a> paramHashMap) {
    Class<?> clazz = paramView.getClass();
    for (String str2 : paramHashMap.keySet()) {
      String str1;
      StringBuilder stringBuilder;
      a a1 = paramHashMap.get(str2);
      if (!a1.a) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("set");
        stringBuilder1.append(str2);
        str1 = stringBuilder1.toString();
      } else {
        str1 = str2;
      } 
      try {
        Method method;
        ColorDrawable colorDrawable;
        switch (a.a[a1.c.ordinal()]) {
          case 8:
            clazz.getMethod(str1, new Class[] { float.class }).invoke(paramView, new Object[] { Float.valueOf(a1.e) });
          case 7:
            clazz.getMethod(str1, new Class[] { float.class }).invoke(paramView, new Object[] { Float.valueOf(a1.e) });
          case 6:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(a1.d) });
          case 5:
            method = clazz.getMethod(str1, new Class[] { Drawable.class });
            colorDrawable = new ColorDrawable();
            colorDrawable.setColor(a1.h);
            method.invoke(paramView, new Object[] { colorDrawable });
          case 4:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(a1.h) });
          case 3:
            clazz.getMethod(str1, new Class[] { CharSequence.class }).invoke(paramView, new Object[] { a1.f });
          case 2:
            clazz.getMethod(str1, new Class[] { boolean.class }).invoke(paramView, new Object[] { Boolean.valueOf(a1.g) });
          case 1:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(a1.d) });
        } 
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("TransitionLayout", noSuchMethodException.getMessage());
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append(str2);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Log.e("TransitionLayout", stringBuilder1.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append(clazz.getName());
        stringBuilder.append(" must have a method ");
        stringBuilder.append(str1);
        Log.e("TransitionLayout", stringBuilder.toString());
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append((String)stringBuilder);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Log.e("TransitionLayout", stringBuilder1.toString());
        illegalAccessException.printStackTrace();
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append((String)stringBuilder);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        Log.e("TransitionLayout", stringBuilder1.toString());
        invocationTargetException.printStackTrace();
      } 
    } 
  }
  
  public String b() {
    return this.b;
  }
  
  public b c() {
    return this.c;
  }
  
  public void f(Object paramObject) {
    switch (a.a[this.c.ordinal()]) {
      default:
        return;
      case 8:
        this.e = ((Float)paramObject).floatValue();
        return;
      case 7:
        this.e = ((Float)paramObject).floatValue();
        return;
      case 4:
      case 5:
        this.h = ((Integer)paramObject).intValue();
        return;
      case 3:
        this.f = (String)paramObject;
        return;
      case 2:
        this.g = ((Boolean)paramObject).booleanValue();
        return;
      case 1:
      case 6:
        break;
    } 
    this.d = ((Integer)paramObject).intValue();
  }
  
  public enum b {
    f, g, h, i, j, k, l, m;
    
    static {
      b b1 = new b("INT_TYPE", 0);
      f = b1;
      b b2 = new b("FLOAT_TYPE", 1);
      g = b2;
      b b3 = new b("COLOR_TYPE", 2);
      h = b3;
      b b4 = new b("COLOR_DRAWABLE_TYPE", 3);
      i = b4;
      b b5 = new b("STRING_TYPE", 4);
      j = b5;
      b b6 = new b("BOOLEAN_TYPE", 5);
      k = b6;
      b b7 = new b("DIMENSION_TYPE", 6);
      l = b7;
      b b8 = new b("REFERENCE_TYPE", 7);
      m = b8;
      n = new b[] { b1, b2, b3, b4, b5, b6, b7, b8 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\constraintlayout\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */