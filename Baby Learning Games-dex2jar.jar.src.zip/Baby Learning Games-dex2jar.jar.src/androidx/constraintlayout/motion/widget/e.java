package androidx.constraintlayout.motion.widget;

import android.view.View;

public class e extends d {
  public void a(float paramFloat, View paramView) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\constraintlayout\motion\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */