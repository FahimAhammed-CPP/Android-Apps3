package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Interpolator;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.p;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class j extends ConstraintLayout implements p {
  public static boolean z0;
  
  Interpolator D;
  
  Interpolator E;
  
  float F;
  
  private int G;
  
  int H;
  
  private int I;
  
  private boolean J;
  
  HashMap<View, g> K;
  
  private long L;
  
  private float M;
  
  float N;
  
  float O;
  
  private long P;
  
  float Q;
  
  private boolean R;
  
  boolean S;
  
  private d T;
  
  int U;
  
  private boolean V;
  
  private b W;
  
  boolean a0;
  
  float b0;
  
  float c0;
  
  long d0;
  
  float e0;
  
  private boolean f0;
  
  private ArrayList<h> g0;
  
  private ArrayList<h> h0;
  
  private ArrayList<h> i0;
  
  private CopyOnWriteArrayList<d> j0;
  
  private int k0;
  
  private float l0;
  
  boolean m0;
  
  protected boolean n0;
  
  float o0;
  
  private boolean p0;
  
  private c q0;
  
  private Runnable r0;
  
  private int[] s0;
  
  int t0;
  
  private int u0;
  
  private boolean v0;
  
  e w0;
  
  private boolean x0;
  
  ArrayList<Integer> y0;
  
  private void G() {
    // Byte code:
    //   0: aload_0
    //   1: getfield T : Landroidx/constraintlayout/motion/widget/j$d;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield j0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull -> 219
    //   16: aload_2
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 219
    //   23: aload_0
    //   24: getfield l0 : F
    //   27: aload_0
    //   28: getfield N : F
    //   31: fcmpl
    //   32: ifeq -> 219
    //   35: aload_0
    //   36: getfield k0 : I
    //   39: iconst_m1
    //   40: if_icmpeq -> 121
    //   43: aload_0
    //   44: getfield T : Landroidx/constraintlayout/motion/widget/j$d;
    //   47: astore_2
    //   48: aload_2
    //   49: ifnull -> 67
    //   52: aload_2
    //   53: aload_0
    //   54: aload_0
    //   55: getfield G : I
    //   58: aload_0
    //   59: getfield I : I
    //   62: invokeinterface b : (Landroidx/constraintlayout/motion/widget/j;II)V
    //   67: aload_0
    //   68: getfield j0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   71: astore_2
    //   72: aload_2
    //   73: ifnull -> 116
    //   76: aload_2
    //   77: invokevirtual iterator : ()Ljava/util/Iterator;
    //   80: astore_2
    //   81: aload_2
    //   82: invokeinterface hasNext : ()Z
    //   87: ifeq -> 116
    //   90: aload_2
    //   91: invokeinterface next : ()Ljava/lang/Object;
    //   96: checkcast androidx/constraintlayout/motion/widget/j$d
    //   99: aload_0
    //   100: aload_0
    //   101: getfield G : I
    //   104: aload_0
    //   105: getfield I : I
    //   108: invokeinterface b : (Landroidx/constraintlayout/motion/widget/j;II)V
    //   113: goto -> 81
    //   116: aload_0
    //   117: iconst_1
    //   118: putfield m0 : Z
    //   121: aload_0
    //   122: iconst_m1
    //   123: putfield k0 : I
    //   126: aload_0
    //   127: getfield N : F
    //   130: fstore_1
    //   131: aload_0
    //   132: fload_1
    //   133: putfield l0 : F
    //   136: aload_0
    //   137: getfield T : Landroidx/constraintlayout/motion/widget/j$d;
    //   140: astore_2
    //   141: aload_2
    //   142: ifnull -> 161
    //   145: aload_2
    //   146: aload_0
    //   147: aload_0
    //   148: getfield G : I
    //   151: aload_0
    //   152: getfield I : I
    //   155: fload_1
    //   156: invokeinterface a : (Landroidx/constraintlayout/motion/widget/j;IIF)V
    //   161: aload_0
    //   162: getfield j0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   165: astore_2
    //   166: aload_2
    //   167: ifnull -> 214
    //   170: aload_2
    //   171: invokevirtual iterator : ()Ljava/util/Iterator;
    //   174: astore_2
    //   175: aload_2
    //   176: invokeinterface hasNext : ()Z
    //   181: ifeq -> 214
    //   184: aload_2
    //   185: invokeinterface next : ()Ljava/lang/Object;
    //   190: checkcast androidx/constraintlayout/motion/widget/j$d
    //   193: aload_0
    //   194: aload_0
    //   195: getfield G : I
    //   198: aload_0
    //   199: getfield I : I
    //   202: aload_0
    //   203: getfield N : F
    //   206: invokeinterface a : (Landroidx/constraintlayout/motion/widget/j;IIF)V
    //   211: goto -> 175
    //   214: aload_0
    //   215: iconst_1
    //   216: putfield m0 : Z
    //   219: return
  }
  
  private void J() {
    if (this.T == null) {
      CopyOnWriteArrayList<d> copyOnWriteArrayList = this.j0;
      if (copyOnWriteArrayList == null || copyOnWriteArrayList.isEmpty())
        return; 
    } 
    this.m0 = false;
    for (Integer integer : this.y0) {
      d d1 = this.T;
      if (d1 != null)
        d1.c(this, integer.intValue()); 
      CopyOnWriteArrayList<d> copyOnWriteArrayList = this.j0;
      if (copyOnWriteArrayList != null) {
        Iterator<d> iterator = copyOnWriteArrayList.iterator();
        while (iterator.hasNext())
          ((d)iterator.next()).c(this, integer.intValue()); 
      } 
    } 
    this.y0.clear();
  }
  
  void E(float paramFloat) {}
  
  void F(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield P : J
    //   4: ldc2_w -1
    //   7: lcmp
    //   8: ifne -> 19
    //   11: aload_0
    //   12: aload_0
    //   13: invokevirtual getNanoTime : ()J
    //   16: putfield P : J
    //   19: aload_0
    //   20: getfield O : F
    //   23: fstore_2
    //   24: fload_2
    //   25: fconst_0
    //   26: fcmpl
    //   27: ifle -> 41
    //   30: fload_2
    //   31: fconst_1
    //   32: fcmpg
    //   33: ifge -> 41
    //   36: aload_0
    //   37: iconst_m1
    //   38: putfield H : I
    //   41: aload_0
    //   42: getfield f0 : Z
    //   45: ifne -> 74
    //   48: aload_0
    //   49: getfield S : Z
    //   52: ifeq -> 71
    //   55: iload_1
    //   56: ifne -> 74
    //   59: aload_0
    //   60: getfield Q : F
    //   63: fload_2
    //   64: fcmpl
    //   65: ifeq -> 71
    //   68: goto -> 74
    //   71: goto -> 970
    //   74: aload_0
    //   75: getfield Q : F
    //   78: fload_2
    //   79: fsub
    //   80: invokestatic signum : (F)F
    //   83: fstore #5
    //   85: aload_0
    //   86: invokevirtual getNanoTime : ()J
    //   89: lstore #9
    //   91: aload_0
    //   92: getfield D : Landroid/view/animation/Interpolator;
    //   95: astore #11
    //   97: aload #11
    //   99: instanceof androidx/constraintlayout/motion/widget/i
    //   102: ifne -> 128
    //   105: lload #9
    //   107: aload_0
    //   108: getfield P : J
    //   111: lsub
    //   112: l2f
    //   113: fload #5
    //   115: fmul
    //   116: ldc 1.0E-9
    //   118: fmul
    //   119: aload_0
    //   120: getfield M : F
    //   123: fdiv
    //   124: fstore_3
    //   125: goto -> 130
    //   128: fconst_0
    //   129: fstore_3
    //   130: aload_0
    //   131: getfield O : F
    //   134: fload_3
    //   135: fadd
    //   136: fstore_2
    //   137: aload_0
    //   138: getfield R : Z
    //   141: ifeq -> 149
    //   144: aload_0
    //   145: getfield Q : F
    //   148: fstore_2
    //   149: fload #5
    //   151: fconst_0
    //   152: fcmpl
    //   153: istore #7
    //   155: iload #7
    //   157: ifle -> 169
    //   160: fload_2
    //   161: aload_0
    //   162: getfield Q : F
    //   165: fcmpl
    //   166: ifge -> 185
    //   169: fload #5
    //   171: fconst_0
    //   172: fcmpg
    //   173: ifgt -> 201
    //   176: fload_2
    //   177: aload_0
    //   178: getfield Q : F
    //   181: fcmpg
    //   182: ifgt -> 201
    //   185: aload_0
    //   186: getfield Q : F
    //   189: fstore_2
    //   190: aload_0
    //   191: iconst_0
    //   192: putfield S : Z
    //   195: iconst_1
    //   196: istore #6
    //   198: goto -> 204
    //   201: iconst_0
    //   202: istore #6
    //   204: aload_0
    //   205: fload_2
    //   206: putfield O : F
    //   209: aload_0
    //   210: fload_2
    //   211: putfield N : F
    //   214: aload_0
    //   215: lload #9
    //   217: putfield P : J
    //   220: aload #11
    //   222: ifnull -> 446
    //   225: iload #6
    //   227: ifne -> 446
    //   230: aload_0
    //   231: getfield V : Z
    //   234: ifeq -> 376
    //   237: aload #11
    //   239: lload #9
    //   241: aload_0
    //   242: getfield L : J
    //   245: lsub
    //   246: l2f
    //   247: ldc 1.0E-9
    //   249: fmul
    //   250: invokeinterface getInterpolation : (F)F
    //   255: fstore_3
    //   256: aload_0
    //   257: getfield D : Landroid/view/animation/Interpolator;
    //   260: astore #11
    //   262: aload #11
    //   264: invokestatic requireNonNull : (Ljava/lang/Object;)Ljava/lang/Object;
    //   267: pop
    //   268: aload_0
    //   269: fload_3
    //   270: putfield O : F
    //   273: aload_0
    //   274: lload #9
    //   276: putfield P : J
    //   279: fload_3
    //   280: fstore_2
    //   281: aload #11
    //   283: instanceof androidx/constraintlayout/motion/widget/i
    //   286: ifeq -> 443
    //   289: aload #11
    //   291: checkcast androidx/constraintlayout/motion/widget/i
    //   294: invokevirtual a : ()F
    //   297: fstore #4
    //   299: aload_0
    //   300: fload #4
    //   302: putfield F : F
    //   305: fload #4
    //   307: invokestatic abs : (F)F
    //   310: pop
    //   311: aload_0
    //   312: getfield M : F
    //   315: fstore_2
    //   316: fload #4
    //   318: fconst_0
    //   319: fcmpl
    //   320: ifle -> 344
    //   323: fload_3
    //   324: fconst_1
    //   325: fcmpl
    //   326: iflt -> 344
    //   329: aload_0
    //   330: fconst_1
    //   331: putfield O : F
    //   334: aload_0
    //   335: iconst_0
    //   336: putfield S : Z
    //   339: fconst_1
    //   340: fstore_3
    //   341: goto -> 344
    //   344: fload_3
    //   345: fstore_2
    //   346: fload #4
    //   348: fconst_0
    //   349: fcmpg
    //   350: ifge -> 443
    //   353: fload_3
    //   354: fstore_2
    //   355: fload_3
    //   356: fconst_0
    //   357: fcmpg
    //   358: ifgt -> 443
    //   361: aload_0
    //   362: fconst_0
    //   363: putfield O : F
    //   366: aload_0
    //   367: iconst_0
    //   368: putfield S : Z
    //   371: fconst_0
    //   372: fstore_2
    //   373: goto -> 451
    //   376: aload #11
    //   378: fload_2
    //   379: invokeinterface getInterpolation : (F)F
    //   384: fstore #4
    //   386: aload_0
    //   387: getfield D : Landroid/view/animation/Interpolator;
    //   390: astore #11
    //   392: aload #11
    //   394: instanceof androidx/constraintlayout/motion/widget/i
    //   397: ifeq -> 418
    //   400: aload_0
    //   401: aload #11
    //   403: checkcast androidx/constraintlayout/motion/widget/i
    //   406: invokevirtual a : ()F
    //   409: putfield F : F
    //   412: fload #4
    //   414: fstore_2
    //   415: goto -> 443
    //   418: aload_0
    //   419: aload #11
    //   421: fload_2
    //   422: fload_3
    //   423: fadd
    //   424: invokeinterface getInterpolation : (F)F
    //   429: fload #4
    //   431: fsub
    //   432: fload #5
    //   434: fmul
    //   435: fload_3
    //   436: fdiv
    //   437: putfield F : F
    //   440: fload #4
    //   442: fstore_2
    //   443: goto -> 451
    //   446: aload_0
    //   447: fload_3
    //   448: putfield F : F
    //   451: aload_0
    //   452: getfield F : F
    //   455: invokestatic abs : (F)F
    //   458: ldc 1.0E-5
    //   460: fcmpl
    //   461: ifle -> 471
    //   464: aload_0
    //   465: getstatic androidx/constraintlayout/motion/widget/j$e.h : Landroidx/constraintlayout/motion/widget/j$e;
    //   468: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   471: iload #7
    //   473: ifle -> 485
    //   476: fload_2
    //   477: aload_0
    //   478: getfield Q : F
    //   481: fcmpl
    //   482: ifge -> 505
    //   485: fload_2
    //   486: fstore_3
    //   487: fload #5
    //   489: fconst_0
    //   490: fcmpg
    //   491: ifgt -> 515
    //   494: fload_2
    //   495: fstore_3
    //   496: fload_2
    //   497: aload_0
    //   498: getfield Q : F
    //   501: fcmpg
    //   502: ifgt -> 515
    //   505: aload_0
    //   506: getfield Q : F
    //   509: fstore_3
    //   510: aload_0
    //   511: iconst_0
    //   512: putfield S : Z
    //   515: fload_3
    //   516: fconst_1
    //   517: fcmpl
    //   518: ifge -> 533
    //   521: fload_3
    //   522: fconst_0
    //   523: fcmpg
    //   524: ifgt -> 530
    //   527: goto -> 533
    //   530: goto -> 545
    //   533: aload_0
    //   534: iconst_0
    //   535: putfield S : Z
    //   538: aload_0
    //   539: getstatic androidx/constraintlayout/motion/widget/j$e.i : Landroidx/constraintlayout/motion/widget/j$e;
    //   542: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   545: aload_0
    //   546: invokevirtual getChildCount : ()I
    //   549: istore #8
    //   551: aload_0
    //   552: iconst_0
    //   553: putfield f0 : Z
    //   556: aload_0
    //   557: invokevirtual getNanoTime : ()J
    //   560: lstore #9
    //   562: aload_0
    //   563: fload_3
    //   564: putfield o0 : F
    //   567: aload_0
    //   568: getfield E : Landroid/view/animation/Interpolator;
    //   571: astore #11
    //   573: aload #11
    //   575: ifnonnull -> 583
    //   578: fload_3
    //   579: fstore_2
    //   580: goto -> 592
    //   583: aload #11
    //   585: fload_3
    //   586: invokeinterface getInterpolation : (F)F
    //   591: fstore_2
    //   592: aload_0
    //   593: getfield E : Landroid/view/animation/Interpolator;
    //   596: astore #11
    //   598: aload #11
    //   600: ifnull -> 644
    //   603: aload #11
    //   605: fload #5
    //   607: aload_0
    //   608: getfield M : F
    //   611: fdiv
    //   612: fload_3
    //   613: fadd
    //   614: invokeinterface getInterpolation : (F)F
    //   619: fstore #4
    //   621: aload_0
    //   622: fload #4
    //   624: putfield F : F
    //   627: aload_0
    //   628: fload #4
    //   630: aload_0
    //   631: getfield E : Landroid/view/animation/Interpolator;
    //   634: fload_3
    //   635: invokeinterface getInterpolation : (F)F
    //   640: fsub
    //   641: putfield F : F
    //   644: iconst_0
    //   645: istore #6
    //   647: iload #6
    //   649: iload #8
    //   651: if_icmpge -> 710
    //   654: aload_0
    //   655: iload #6
    //   657: invokevirtual getChildAt : (I)Landroid/view/View;
    //   660: astore #11
    //   662: aload_0
    //   663: getfield K : Ljava/util/HashMap;
    //   666: aload #11
    //   668: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   671: checkcast androidx/constraintlayout/motion/widget/g
    //   674: astore #12
    //   676: aload #12
    //   678: ifnull -> 701
    //   681: aload_0
    //   682: aload_0
    //   683: getfield f0 : Z
    //   686: aload #12
    //   688: aload #11
    //   690: fload_2
    //   691: lload #9
    //   693: aconst_null
    //   694: invokevirtual c : (Landroid/view/View;FJLu/c;)Z
    //   697: ior
    //   698: putfield f0 : Z
    //   701: iload #6
    //   703: iconst_1
    //   704: iadd
    //   705: istore #6
    //   707: goto -> 647
    //   710: iload #7
    //   712: ifle -> 724
    //   715: fload_3
    //   716: aload_0
    //   717: getfield Q : F
    //   720: fcmpl
    //   721: ifge -> 740
    //   724: fload #5
    //   726: fconst_0
    //   727: fcmpg
    //   728: ifgt -> 746
    //   731: fload_3
    //   732: aload_0
    //   733: getfield Q : F
    //   736: fcmpg
    //   737: ifgt -> 746
    //   740: iconst_1
    //   741: istore #6
    //   743: goto -> 749
    //   746: iconst_0
    //   747: istore #6
    //   749: aload_0
    //   750: getfield f0 : Z
    //   753: ifne -> 775
    //   756: aload_0
    //   757: getfield S : Z
    //   760: ifne -> 775
    //   763: iload #6
    //   765: ifeq -> 775
    //   768: aload_0
    //   769: getstatic androidx/constraintlayout/motion/widget/j$e.i : Landroidx/constraintlayout/motion/widget/j$e;
    //   772: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   775: aload_0
    //   776: getfield n0 : Z
    //   779: ifeq -> 786
    //   782: aload_0
    //   783: invokevirtual requestLayout : ()V
    //   786: aload_0
    //   787: getfield f0 : Z
    //   790: iload #6
    //   792: iconst_1
    //   793: ixor
    //   794: ior
    //   795: istore_1
    //   796: aload_0
    //   797: iload_1
    //   798: putfield f0 : Z
    //   801: fload_3
    //   802: fconst_0
    //   803: fcmpg
    //   804: ifgt -> 839
    //   807: aload_0
    //   808: getfield G : I
    //   811: istore #6
    //   813: iload #6
    //   815: iconst_m1
    //   816: if_icmpeq -> 839
    //   819: aload_0
    //   820: getfield H : I
    //   823: iload #6
    //   825: if_icmpne -> 831
    //   828: goto -> 839
    //   831: aload_0
    //   832: iload #6
    //   834: putfield H : I
    //   837: aconst_null
    //   838: athrow
    //   839: fload_3
    //   840: f2d
    //   841: dconst_1
    //   842: dcmpl
    //   843: iflt -> 876
    //   846: aload_0
    //   847: getfield H : I
    //   850: istore #6
    //   852: aload_0
    //   853: getfield I : I
    //   856: istore #8
    //   858: iload #6
    //   860: iload #8
    //   862: if_icmpne -> 868
    //   865: goto -> 876
    //   868: aload_0
    //   869: iload #8
    //   871: putfield H : I
    //   874: aconst_null
    //   875: athrow
    //   876: iload_1
    //   877: ifne -> 924
    //   880: aload_0
    //   881: getfield S : Z
    //   884: ifeq -> 890
    //   887: goto -> 924
    //   890: iload #7
    //   892: ifle -> 901
    //   895: fload_3
    //   896: fconst_1
    //   897: fcmpl
    //   898: ifeq -> 914
    //   901: fload #5
    //   903: fconst_0
    //   904: fcmpg
    //   905: ifge -> 928
    //   908: fload_3
    //   909: fconst_0
    //   910: fcmpl
    //   911: ifne -> 928
    //   914: aload_0
    //   915: getstatic androidx/constraintlayout/motion/widget/j$e.i : Landroidx/constraintlayout/motion/widget/j$e;
    //   918: invokevirtual setState : (Landroidx/constraintlayout/motion/widget/j$e;)V
    //   921: goto -> 928
    //   924: aload_0
    //   925: invokevirtual invalidate : ()V
    //   928: aload_0
    //   929: getfield f0 : Z
    //   932: ifne -> 970
    //   935: aload_0
    //   936: getfield S : Z
    //   939: ifne -> 970
    //   942: iload #7
    //   944: ifle -> 953
    //   947: fload_3
    //   948: fconst_1
    //   949: fcmpl
    //   950: ifeq -> 966
    //   953: fload #5
    //   955: fconst_0
    //   956: fcmpg
    //   957: ifge -> 970
    //   960: fload_3
    //   961: fconst_0
    //   962: fcmpl
    //   963: ifne -> 970
    //   966: aload_0
    //   967: invokevirtual I : ()V
    //   970: iconst_1
    //   971: istore #7
    //   973: iconst_1
    //   974: istore #6
    //   976: aload_0
    //   977: getfield O : F
    //   980: fstore_2
    //   981: fload_2
    //   982: fconst_1
    //   983: fcmpl
    //   984: iflt -> 1021
    //   987: aload_0
    //   988: getfield H : I
    //   991: istore #8
    //   993: aload_0
    //   994: getfield I : I
    //   997: istore #7
    //   999: iload #8
    //   1001: iload #7
    //   1003: if_icmpeq -> 1009
    //   1006: goto -> 1012
    //   1009: iconst_0
    //   1010: istore #6
    //   1012: aload_0
    //   1013: iload #7
    //   1015: putfield H : I
    //   1018: goto -> 1068
    //   1021: fload_2
    //   1022: fconst_0
    //   1023: fcmpg
    //   1024: ifgt -> 1065
    //   1027: aload_0
    //   1028: getfield H : I
    //   1031: istore #6
    //   1033: aload_0
    //   1034: getfield G : I
    //   1037: istore #8
    //   1039: iload #6
    //   1041: iload #8
    //   1043: if_icmpeq -> 1053
    //   1046: iload #7
    //   1048: istore #6
    //   1050: goto -> 1056
    //   1053: iconst_0
    //   1054: istore #6
    //   1056: aload_0
    //   1057: iload #8
    //   1059: putfield H : I
    //   1062: goto -> 1018
    //   1065: iconst_0
    //   1066: istore #6
    //   1068: aload_0
    //   1069: aload_0
    //   1070: getfield x0 : Z
    //   1073: iload #6
    //   1075: ior
    //   1076: putfield x0 : Z
    //   1079: iload #6
    //   1081: ifeq -> 1095
    //   1084: aload_0
    //   1085: getfield p0 : Z
    //   1088: ifne -> 1095
    //   1091: aload_0
    //   1092: invokevirtual requestLayout : ()V
    //   1095: aload_0
    //   1096: aload_0
    //   1097: getfield O : F
    //   1100: putfield N : F
    //   1103: return
  }
  
  protected void H() {
    // Byte code:
    //   0: aload_0
    //   1: getfield T : Landroidx/constraintlayout/motion/widget/j$d;
    //   4: ifnonnull -> 23
    //   7: aload_0
    //   8: getfield j0 : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   11: astore_3
    //   12: aload_3
    //   13: ifnull -> 103
    //   16: aload_3
    //   17: invokevirtual isEmpty : ()Z
    //   20: ifne -> 103
    //   23: aload_0
    //   24: getfield k0 : I
    //   27: iconst_m1
    //   28: if_icmpne -> 103
    //   31: aload_0
    //   32: aload_0
    //   33: getfield H : I
    //   36: putfield k0 : I
    //   39: aload_0
    //   40: getfield y0 : Ljava/util/ArrayList;
    //   43: invokevirtual isEmpty : ()Z
    //   46: ifne -> 74
    //   49: aload_0
    //   50: getfield y0 : Ljava/util/ArrayList;
    //   53: astore_3
    //   54: aload_3
    //   55: aload_3
    //   56: invokevirtual size : ()I
    //   59: iconst_1
    //   60: isub
    //   61: invokevirtual get : (I)Ljava/lang/Object;
    //   64: checkcast java/lang/Integer
    //   67: invokevirtual intValue : ()I
    //   70: istore_1
    //   71: goto -> 76
    //   74: iconst_m1
    //   75: istore_1
    //   76: aload_0
    //   77: getfield H : I
    //   80: istore_2
    //   81: iload_1
    //   82: iload_2
    //   83: if_icmpeq -> 103
    //   86: iload_2
    //   87: iconst_m1
    //   88: if_icmpeq -> 103
    //   91: aload_0
    //   92: getfield y0 : Ljava/util/ArrayList;
    //   95: iload_2
    //   96: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   99: invokevirtual add : (Ljava/lang/Object;)Z
    //   102: pop
    //   103: aload_0
    //   104: invokespecial J : ()V
    //   107: aload_0
    //   108: getfield r0 : Ljava/lang/Runnable;
    //   111: astore_3
    //   112: aload_3
    //   113: ifnull -> 122
    //   116: aload_3
    //   117: invokeinterface run : ()V
    //   122: aload_0
    //   123: getfield s0 : [I
    //   126: astore_3
    //   127: aload_3
    //   128: ifnull -> 171
    //   131: aload_0
    //   132: getfield t0 : I
    //   135: ifle -> 171
    //   138: aload_0
    //   139: aload_3
    //   140: iconst_0
    //   141: iaload
    //   142: invokevirtual O : (I)V
    //   145: aload_0
    //   146: getfield s0 : [I
    //   149: astore_3
    //   150: aload_3
    //   151: iconst_1
    //   152: aload_3
    //   153: iconst_0
    //   154: aload_3
    //   155: arraylength
    //   156: iconst_1
    //   157: isub
    //   158: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   161: aload_0
    //   162: aload_0
    //   163: getfield t0 : I
    //   166: iconst_1
    //   167: isub
    //   168: putfield t0 : I
    //   171: return
  }
  
  void I() {}
  
  public void K(float paramFloat1, float paramFloat2) {
    if (!isAttachedToWindow()) {
      if (this.q0 == null)
        this.q0 = new c(this); 
      this.q0.e(paramFloat1);
      this.q0.h(paramFloat2);
      return;
    } 
    setProgress(paramFloat1);
    setState(e.h);
    this.F = paramFloat2;
    float f2 = 0.0F;
    float f1 = 0.0F;
    int i = paramFloat2 cmp 0.0F;
    if (i != 0) {
      paramFloat1 = f1;
      if (i > 0)
        paramFloat1 = 1.0F; 
      E(paramFloat1);
      return;
    } 
    if (paramFloat1 != 0.0F && paramFloat1 != 1.0F) {
      paramFloat2 = f2;
      if (paramFloat1 > 0.5F)
        paramFloat2 = 1.0F; 
      E(paramFloat2);
    } 
  }
  
  public void L(int paramInt1, int paramInt2, int paramInt3) {
    setState(e.g);
    this.H = paramInt1;
    this.G = -1;
    this.I = -1;
    androidx.constraintlayout.widget.c c1 = this.p;
    if (c1 != null)
      c1.d(paramInt1, paramInt2, paramInt3); 
  }
  
  public void M(int paramInt1, int paramInt2) {
    if (!isAttachedToWindow()) {
      if (this.q0 == null)
        this.q0 = new c(this); 
      this.q0.f(paramInt1);
      this.q0.d(paramInt2);
    } 
  }
  
  public void N() {
    E(1.0F);
    this.r0 = null;
  }
  
  public void O(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.q0 == null)
        this.q0 = new c(this); 
      this.q0.d(paramInt);
      return;
    } 
    P(paramInt, -1, -1);
  }
  
  public void P(int paramInt1, int paramInt2, int paramInt3) {
    Q(paramInt1, paramInt2, paramInt3, -1);
  }
  
  public void Q(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = this.H;
    if (paramInt2 == paramInt1)
      return; 
    if (this.G == paramInt1) {
      E(0.0F);
      if (paramInt4 > 0)
        this.M = paramInt4 / 1000.0F; 
      return;
    } 
    if (this.I == paramInt1) {
      E(1.0F);
      if (paramInt4 > 0)
        this.M = paramInt4 / 1000.0F; 
      return;
    } 
    this.I = paramInt1;
    if (paramInt2 != -1) {
      M(paramInt2, paramInt1);
      E(1.0F);
      this.O = 0.0F;
      N();
      if (paramInt4 > 0)
        this.M = paramInt4 / 1000.0F; 
      return;
    } 
    this.V = false;
    this.Q = 1.0F;
    this.N = 0.0F;
    this.O = 0.0F;
    this.P = getNanoTime();
    this.L = getNanoTime();
    this.R = false;
    this.D = null;
    if (paramInt4 == -1)
      throw null; 
    this.G = -1;
    throw null;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    ArrayList<h> arrayList = this.i0;
    if (arrayList != null) {
      Iterator<h> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((h)iterator.next()).w(paramCanvas); 
    } 
    F(false);
    super.dispatchDraw(paramCanvas);
  }
  
  public int[] getConstraintSetIds() {
    return null;
  }
  
  public int getCurrentState() {
    return this.H;
  }
  
  public ArrayList<l.a> getDefinedTransitions() {
    return null;
  }
  
  public b getDesignTool() {
    if (this.W == null)
      this.W = new b(this); 
    return this.W;
  }
  
  public int getEndState() {
    return this.I;
  }
  
  protected long getNanoTime() {
    return System.nanoTime();
  }
  
  public float getProgress() {
    return this.O;
  }
  
  public l getScene() {
    return null;
  }
  
  public int getStartState() {
    return this.G;
  }
  
  public float getTargetPosition() {
    return this.Q;
  }
  
  public Bundle getTransitionState() {
    if (this.q0 == null)
      this.q0 = new c(this); 
    this.q0.c();
    return this.q0.b();
  }
  
  public long getTransitionTimeMs() {
    return (long)(this.M * 1000.0F);
  }
  
  public float getVelocity() {
    return this.F;
  }
  
  public void h(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.d0 = getNanoTime();
    this.e0 = 0.0F;
    this.b0 = 0.0F;
    this.c0 = 0.0F;
  }
  
  public void i(View paramView, int paramInt) {}
  
  public boolean isAttachedToWindow() {
    return super.isAttachedToWindow();
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {}
  
  public void m(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    if (this.a0 || paramInt1 != 0 || paramInt2 != 0) {
      paramArrayOfint[0] = paramArrayOfint[0] + paramInt3;
      paramArrayOfint[1] = paramArrayOfint[1] + paramInt4;
    } 
    this.a0 = false;
  }
  
  public void n(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
  
  public boolean o(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return false;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    Display display = getDisplay();
    if (display != null)
      this.u0 = display.getRotation(); 
    I();
    c c1 = this.q0;
    if (c1 != null) {
      if (this.v0) {
        post(new a(this));
        return;
      } 
      c1.a();
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return false;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.p0 = true;
    try {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } finally {
      this.p0 = false;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onRtlPropertiesChanged(int paramInt) {}
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    if (paramView instanceof h) {
      h h = (h)paramView;
      if (this.j0 == null)
        this.j0 = new CopyOnWriteArrayList<d>(); 
      this.j0.add(h);
      if (h.v()) {
        if (this.g0 == null)
          this.g0 = new ArrayList<h>(); 
        this.g0.add(h);
      } 
      if (h.u()) {
        if (this.h0 == null)
          this.h0 = new ArrayList<h>(); 
        this.h0.add(h);
      } 
      if (h.t()) {
        if (this.i0 == null)
          this.i0 = new ArrayList<h>(); 
        this.i0.add(h);
      } 
    } 
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    ArrayList<h> arrayList = this.g0;
    if (arrayList != null)
      arrayList.remove(paramView); 
    arrayList = this.h0;
    if (arrayList != null)
      arrayList.remove(paramView); 
  }
  
  public void requestLayout() {
    if (!this.n0)
      int i = this.H; 
    super.requestLayout();
  }
  
  public void setDebugMode(int paramInt) {
    this.U = paramInt;
    invalidate();
  }
  
  public void setDelayedApplicationOfInitialState(boolean paramBoolean) {
    this.v0 = paramBoolean;
  }
  
  public void setInteractionEnabled(boolean paramBoolean) {
    this.J = paramBoolean;
  }
  
  public void setInterpolatedProgress(float paramFloat) {
    setProgress(paramFloat);
  }
  
  public void setOnHide(float paramFloat) {
    ArrayList<h> arrayList = this.h0;
    if (arrayList != null) {
      int k = arrayList.size();
      for (int i = 0; i < k; i++)
        ((h)this.h0.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setOnShow(float paramFloat) {
    ArrayList<h> arrayList = this.g0;
    if (arrayList != null) {
      int k = arrayList.size();
      for (int i = 0; i < k; i++)
        ((h)this.g0.get(i)).setProgress(paramFloat); 
    } 
  }
  
  public void setProgress(float paramFloat) {
    int i = paramFloat cmp 0.0F;
    if (i < 0 || paramFloat > 1.0F)
      Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive"); 
    if (!isAttachedToWindow()) {
      if (this.q0 == null)
        this.q0 = new c(this); 
      this.q0.e(paramFloat);
      return;
    } 
    if (i <= 0) {
      if (this.O == 1.0F && this.H == this.I)
        setState(e.h); 
      this.H = this.G;
      if (this.O == 0.0F) {
        setState(e.i);
        return;
      } 
    } else if (paramFloat >= 1.0F) {
      if (this.O == 0.0F && this.H == this.G)
        setState(e.h); 
      this.H = this.I;
      if (this.O == 1.0F) {
        setState(e.i);
        return;
      } 
    } else {
      this.H = -1;
      setState(e.h);
    } 
  }
  
  public void setScene(l paraml) {
    r();
    throw null;
  }
  
  void setStartState(int paramInt) {
    if (!isAttachedToWindow()) {
      if (this.q0 == null)
        this.q0 = new c(this); 
      this.q0.f(paramInt);
      this.q0.d(paramInt);
      return;
    } 
    this.H = paramInt;
  }
  
  void setState(e parame) {
    e e1 = e.i;
    if (parame == e1 && this.H == -1)
      return; 
    e e2 = this.w0;
    this.w0 = parame;
    e e3 = e.h;
    if (e2 == e3 && parame == e3)
      G(); 
    int i = b.a[e2.ordinal()];
    if (i != 1 && i != 2) {
      if (i != 3)
        return; 
      if (parame == e1) {
        H();
        return;
      } 
    } else {
      if (parame == e3)
        G(); 
      if (parame == e1)
        H(); 
    } 
  }
  
  public void setTransition(int paramInt) {}
  
  protected void setTransition(l.a parama) {
    throw null;
  }
  
  public void setTransitionDuration(int paramInt) {
    Log.e("MotionLayout", "MotionScene not defined");
  }
  
  public void setTransitionListener(d paramd) {
    this.T = paramd;
  }
  
  public void setTransitionState(Bundle paramBundle) {
    if (this.q0 == null)
      this.q0 = new c(this); 
    this.q0.g(paramBundle);
    if (isAttachedToWindow())
      this.q0.a(); 
  }
  
  protected void t(int paramInt) {
    this.p = null;
  }
  
  public String toString() {
    Context context = getContext();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(a.a(context, this.G));
    stringBuilder.append("->");
    stringBuilder.append(a.a(context, this.I));
    stringBuilder.append(" (pos:");
    stringBuilder.append(this.O);
    stringBuilder.append(" Dpos/Dt:");
    stringBuilder.append(this.F);
    return stringBuilder.toString();
  }
  
  class a implements Runnable {
    a(j this$0) {}
    
    public void run() {
      j.B(this.f).a();
    }
  }
  
  class c {
    float a = Float.NaN;
    
    float b = Float.NaN;
    
    int c = -1;
    
    int d = -1;
    
    final String e = "motion.progress";
    
    final String f = "motion.velocity";
    
    final String g = "motion.StartState";
    
    final String h = "motion.EndState";
    
    c(j this$0) {}
    
    void a() {
      int i = this.c;
      if (i != -1 || this.d != -1) {
        if (i == -1) {
          this.i.O(this.d);
        } else {
          int k = this.d;
          if (k == -1) {
            this.i.L(i, -1, -1);
          } else {
            this.i.M(i, k);
          } 
        } 
        this.i.setState(j.e.g);
      } 
      if (Float.isNaN(this.b)) {
        if (Float.isNaN(this.a))
          return; 
        this.i.setProgress(this.a);
        return;
      } 
      this.i.K(this.a, this.b);
      this.a = Float.NaN;
      this.b = Float.NaN;
      this.c = -1;
      this.d = -1;
    }
    
    public Bundle b() {
      Bundle bundle = new Bundle();
      bundle.putFloat("motion.progress", this.a);
      bundle.putFloat("motion.velocity", this.b);
      bundle.putInt("motion.StartState", this.c);
      bundle.putInt("motion.EndState", this.d);
      return bundle;
    }
    
    public void c() {
      this.d = j.C(this.i);
      this.c = j.D(this.i);
      this.b = this.i.getVelocity();
      this.a = this.i.getProgress();
    }
    
    public void d(int param1Int) {
      this.d = param1Int;
    }
    
    public void e(float param1Float) {
      this.a = param1Float;
    }
    
    public void f(int param1Int) {
      this.c = param1Int;
    }
    
    public void g(Bundle param1Bundle) {
      this.a = param1Bundle.getFloat("motion.progress");
      this.b = param1Bundle.getFloat("motion.velocity");
      this.c = param1Bundle.getInt("motion.StartState");
      this.d = param1Bundle.getInt("motion.EndState");
    }
    
    public void h(float param1Float) {
      this.b = param1Float;
    }
  }
  
  public static interface d {
    void a(j param1j, int param1Int1, int param1Int2, float param1Float);
    
    void b(j param1j, int param1Int1, int param1Int2);
    
    void c(j param1j, int param1Int);
  }
  
  enum e {
    f, g, h, i;
    
    static {
      e e1 = new e("UNDEFINED", 0);
      f = e1;
      e e2 = new e("SETUP", 1);
      g = e2;
      e e3 = new e("MOVING", 2);
      h = e3;
      e e4 = new e("FINISHED", 3);
      i = e4;
      j = new e[] { e1, e2, e3, e4 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\constraintlayout\motion\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */