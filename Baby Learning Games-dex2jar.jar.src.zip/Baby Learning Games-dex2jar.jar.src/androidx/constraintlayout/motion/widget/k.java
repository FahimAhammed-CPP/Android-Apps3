package androidx.constraintlayout.motion.widget;

import android.view.View;
import androidx.constraintlayout.widget.a;
import java.util.LinkedHashMap;
import u.b;

class k implements Comparable<k> {
  static String[] x = new String[] { "position", "x", "y", "width", "height", "pathRotate" };
  
  b f;
  
  int g = 0;
  
  float h;
  
  float i;
  
  float j;
  
  float k;
  
  float l;
  
  float m;
  
  float n = Float.NaN;
  
  float o = Float.NaN;
  
  int p;
  
  int q;
  
  float r;
  
  g s;
  
  LinkedHashMap<String, a> t;
  
  int u;
  
  double[] v;
  
  double[] w;
  
  public k() {
    int i = d.a;
    this.p = i;
    this.q = i;
    this.r = Float.NaN;
    this.s = null;
    this.t = new LinkedHashMap<String, a>();
    this.u = 0;
    this.v = new double[18];
    this.w = new double[18];
  }
  
  public int b(k paramk) {
    return Float.compare(this.i, paramk.i);
  }
  
  void d(double paramDouble, int[] paramArrayOfint, double[] paramArrayOfdouble1, float[] paramArrayOffloat1, double[] paramArrayOfdouble2, float[] paramArrayOffloat2) {
    float f3 = this.j;
    float f4 = this.k;
    float f6 = this.l;
    float f5 = this.m;
    int i = 0;
    float f8 = 0.0F;
    float f10 = 0.0F;
    float f7 = 0.0F;
    float f9 = 0.0F;
    while (i < paramArrayOfint.length) {
      float f12 = (float)paramArrayOfdouble1[i];
      float f11 = (float)paramArrayOfdouble2[i];
      int j = paramArrayOfint[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4) {
              f5 = f12;
              f9 = f11;
            } 
          } else {
            f6 = f12;
            f10 = f11;
          } 
        } else {
          f4 = f12;
          f7 = f11;
        } 
      } else {
        f8 = f11;
        f3 = f12;
      } 
      i++;
    } 
    float f1 = f10 / 2.0F + f8;
    float f2 = f9 / 2.0F + f7;
    g g1 = this.s;
    if (g1 != null) {
      float[] arrayOfFloat1 = new float[2];
      float[] arrayOfFloat2 = new float[2];
      g1.b(paramDouble, arrayOfFloat1, arrayOfFloat2);
      f10 = arrayOfFloat1[0];
      f9 = arrayOfFloat1[1];
      f1 = arrayOfFloat2[0];
      f2 = arrayOfFloat2[1];
      double d1 = f10;
      double d2 = f3;
      paramDouble = f4;
      f3 = (float)(d1 + Math.sin(paramDouble) * d2 - (f6 / 2.0F));
      f4 = (float)(f9 - d2 * Math.cos(paramDouble) - (f5 / 2.0F));
      d1 = f1;
      d2 = f8;
      double d3 = Math.sin(paramDouble);
      double d4 = Math.cos(paramDouble);
      double d5 = f7;
      f1 = (float)(d1 + d3 * d2 + d4 * d5);
      f2 = (float)(f2 - d2 * Math.cos(paramDouble) + Math.sin(paramDouble) * d5);
    } 
    paramArrayOffloat1[0] = f3 + f6 / 2.0F + 0.0F;
    paramArrayOffloat1[1] = f4 + f5 / 2.0F + 0.0F;
    paramArrayOffloat2[0] = f1;
    paramArrayOffloat2[1] = f2;
  }
  
  void e(float paramFloat, View paramView, int[] paramArrayOfint, double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : F
    //   4: fstore #28
    //   6: aload_0
    //   7: getfield k : F
    //   10: fstore #27
    //   12: aload_0
    //   13: getfield l : F
    //   16: fstore #29
    //   18: aload_0
    //   19: getfield m : F
    //   22: fstore #26
    //   24: aload_3
    //   25: arraylength
    //   26: ifeq -> 69
    //   29: aload_0
    //   30: getfield v : [D
    //   33: arraylength
    //   34: aload_3
    //   35: aload_3
    //   36: arraylength
    //   37: iconst_1
    //   38: isub
    //   39: iaload
    //   40: if_icmpgt -> 69
    //   43: aload_3
    //   44: aload_3
    //   45: arraylength
    //   46: iconst_1
    //   47: isub
    //   48: iaload
    //   49: iconst_1
    //   50: iadd
    //   51: istore #34
    //   53: aload_0
    //   54: iload #34
    //   56: newarray double
    //   58: putfield v : [D
    //   61: aload_0
    //   62: iload #34
    //   64: newarray double
    //   66: putfield w : [D
    //   69: aload_0
    //   70: getfield v : [D
    //   73: ldc2_w NaN
    //   76: invokestatic fill : ([DD)V
    //   79: iconst_0
    //   80: istore #34
    //   82: iload #34
    //   84: aload_3
    //   85: arraylength
    //   86: if_icmpge -> 126
    //   89: aload_0
    //   90: getfield v : [D
    //   93: aload_3
    //   94: iload #34
    //   96: iaload
    //   97: aload #4
    //   99: iload #34
    //   101: daload
    //   102: dastore
    //   103: aload_0
    //   104: getfield w : [D
    //   107: aload_3
    //   108: iload #34
    //   110: iaload
    //   111: aload #5
    //   113: iload #34
    //   115: daload
    //   116: dastore
    //   117: iload #34
    //   119: iconst_1
    //   120: iadd
    //   121: istore #34
    //   123: goto -> 82
    //   126: ldc NaN
    //   128: fstore #24
    //   130: iconst_0
    //   131: istore #34
    //   133: fconst_0
    //   134: fstore #31
    //   136: fconst_0
    //   137: fstore #30
    //   139: fconst_0
    //   140: fstore #33
    //   142: fconst_0
    //   143: fstore #32
    //   145: aload_0
    //   146: getfield v : [D
    //   149: astore_3
    //   150: iload #34
    //   152: aload_3
    //   153: arraylength
    //   154: if_icmpge -> 361
    //   157: aload_3
    //   158: iload #34
    //   160: daload
    //   161: invokestatic isNaN : (D)Z
    //   164: istore #41
    //   166: dconst_0
    //   167: dstore #8
    //   169: iload #41
    //   171: ifeq -> 192
    //   174: aload #6
    //   176: ifnull -> 189
    //   179: aload #6
    //   181: iload #34
    //   183: daload
    //   184: dconst_0
    //   185: dcmpl
    //   186: ifne -> 192
    //   189: goto -> 281
    //   192: aload #6
    //   194: ifnull -> 204
    //   197: aload #6
    //   199: iload #34
    //   201: daload
    //   202: dstore #8
    //   204: aload_0
    //   205: getfield v : [D
    //   208: iload #34
    //   210: daload
    //   211: invokestatic isNaN : (D)Z
    //   214: ifeq -> 220
    //   217: goto -> 232
    //   220: aload_0
    //   221: getfield v : [D
    //   224: iload #34
    //   226: daload
    //   227: dload #8
    //   229: dadd
    //   230: dstore #8
    //   232: fload #24
    //   234: fstore #23
    //   236: dload #8
    //   238: d2f
    //   239: fstore #22
    //   241: aload_0
    //   242: getfield w : [D
    //   245: iload #34
    //   247: daload
    //   248: d2f
    //   249: fstore #25
    //   251: iload #34
    //   253: iconst_1
    //   254: if_icmpeq -> 336
    //   257: iload #34
    //   259: iconst_2
    //   260: if_icmpeq -> 321
    //   263: iload #34
    //   265: iconst_3
    //   266: if_icmpeq -> 306
    //   269: iload #34
    //   271: iconst_4
    //   272: if_icmpeq -> 291
    //   275: iload #34
    //   277: iconst_5
    //   278: if_icmpeq -> 288
    //   281: fload #24
    //   283: fstore #22
    //   285: goto -> 348
    //   288: goto -> 348
    //   291: fload #22
    //   293: fstore #26
    //   295: fload #23
    //   297: fstore #22
    //   299: fload #25
    //   301: fstore #32
    //   303: goto -> 348
    //   306: fload #22
    //   308: fstore #29
    //   310: fload #23
    //   312: fstore #22
    //   314: fload #25
    //   316: fstore #33
    //   318: goto -> 348
    //   321: fload #22
    //   323: fstore #27
    //   325: fload #23
    //   327: fstore #22
    //   329: fload #25
    //   331: fstore #30
    //   333: goto -> 348
    //   336: fload #22
    //   338: fstore #28
    //   340: fload #25
    //   342: fstore #31
    //   344: fload #23
    //   346: fstore #22
    //   348: iload #34
    //   350: iconst_1
    //   351: iadd
    //   352: istore #34
    //   354: fload #22
    //   356: fstore #24
    //   358: goto -> 145
    //   361: aload_0
    //   362: getfield s : Landroidx/constraintlayout/motion/widget/g;
    //   365: astore_3
    //   366: aload_3
    //   367: ifnull -> 599
    //   370: iconst_2
    //   371: newarray float
    //   373: astore #4
    //   375: iconst_2
    //   376: newarray float
    //   378: astore #6
    //   380: aload_3
    //   381: fload_1
    //   382: f2d
    //   383: aload #4
    //   385: aload #6
    //   387: invokevirtual b : (D[F[F)V
    //   390: aload #4
    //   392: iconst_0
    //   393: faload
    //   394: fstore_1
    //   395: aload #4
    //   397: iconst_1
    //   398: faload
    //   399: fstore #22
    //   401: aload #6
    //   403: iconst_0
    //   404: faload
    //   405: fstore #25
    //   407: aload #6
    //   409: iconst_1
    //   410: faload
    //   411: fstore #23
    //   413: fload_1
    //   414: f2d
    //   415: dstore #12
    //   417: fload #28
    //   419: f2d
    //   420: dstore #8
    //   422: fload #27
    //   424: f2d
    //   425: dstore #10
    //   427: dload #12
    //   429: dload #10
    //   431: invokestatic sin : (D)D
    //   434: dload #8
    //   436: dmul
    //   437: dadd
    //   438: fload #29
    //   440: fconst_2
    //   441: fdiv
    //   442: f2d
    //   443: dsub
    //   444: d2f
    //   445: fstore_1
    //   446: fload #22
    //   448: f2d
    //   449: dload #10
    //   451: invokestatic cos : (D)D
    //   454: dload #8
    //   456: dmul
    //   457: dsub
    //   458: fload #26
    //   460: fconst_2
    //   461: fdiv
    //   462: f2d
    //   463: dsub
    //   464: d2f
    //   465: fstore #22
    //   467: fload #25
    //   469: f2d
    //   470: dstore #12
    //   472: fload #31
    //   474: f2d
    //   475: dstore #14
    //   477: dload #10
    //   479: invokestatic sin : (D)D
    //   482: dstore #16
    //   484: dload #10
    //   486: invokestatic cos : (D)D
    //   489: dstore #18
    //   491: fload #30
    //   493: f2d
    //   494: dstore #20
    //   496: dload #12
    //   498: dload #16
    //   500: dload #14
    //   502: dmul
    //   503: dadd
    //   504: dload #18
    //   506: dload #8
    //   508: dmul
    //   509: dload #20
    //   511: dmul
    //   512: dadd
    //   513: d2f
    //   514: fstore #25
    //   516: fload #23
    //   518: f2d
    //   519: dload #14
    //   521: dload #10
    //   523: invokestatic cos : (D)D
    //   526: dmul
    //   527: dsub
    //   528: dload #8
    //   530: dload #10
    //   532: invokestatic sin : (D)D
    //   535: dmul
    //   536: dload #20
    //   538: dmul
    //   539: dadd
    //   540: d2f
    //   541: fstore #23
    //   543: aload #5
    //   545: arraylength
    //   546: iconst_2
    //   547: if_icmplt -> 567
    //   550: aload #5
    //   552: iconst_0
    //   553: fload #25
    //   555: f2d
    //   556: dastore
    //   557: aload #5
    //   559: iconst_1
    //   560: fload #23
    //   562: f2d
    //   563: dastore
    //   564: goto -> 567
    //   567: fload #24
    //   569: invokestatic isNaN : (F)Z
    //   572: ifne -> 596
    //   575: aload_2
    //   576: fload #24
    //   578: f2d
    //   579: fload #23
    //   581: f2d
    //   582: fload #25
    //   584: f2d
    //   585: invokestatic atan2 : (DD)D
    //   588: invokestatic toDegrees : (D)D
    //   591: dadd
    //   592: d2f
    //   593: invokevirtual setRotation : (F)V
    //   596: goto -> 661
    //   599: fload #28
    //   601: fstore_1
    //   602: fload #27
    //   604: fstore #22
    //   606: fload #24
    //   608: invokestatic isNaN : (F)Z
    //   611: ifne -> 661
    //   614: fload #33
    //   616: fconst_2
    //   617: fdiv
    //   618: fstore_1
    //   619: fload #32
    //   621: fconst_2
    //   622: fdiv
    //   623: fstore #22
    //   625: aload_2
    //   626: fconst_0
    //   627: f2d
    //   628: fload #24
    //   630: f2d
    //   631: fload #30
    //   633: fload #22
    //   635: fadd
    //   636: f2d
    //   637: fload #31
    //   639: fload_1
    //   640: fadd
    //   641: f2d
    //   642: invokestatic atan2 : (DD)D
    //   645: invokestatic toDegrees : (D)D
    //   648: dadd
    //   649: dadd
    //   650: d2f
    //   651: invokevirtual setRotation : (F)V
    //   654: fload #27
    //   656: fstore #22
    //   658: fload #28
    //   660: fstore_1
    //   661: iconst_0
    //   662: istore #34
    //   664: aload_2
    //   665: instanceof androidx/constraintlayout/motion/widget/c
    //   668: ifeq -> 693
    //   671: aload_2
    //   672: checkcast androidx/constraintlayout/motion/widget/c
    //   675: fload_1
    //   676: fload #22
    //   678: fload #29
    //   680: fload_1
    //   681: fadd
    //   682: fload #22
    //   684: fload #26
    //   686: fadd
    //   687: invokeinterface a : (FFFF)V
    //   692: return
    //   693: fload_1
    //   694: ldc 0.5
    //   696: fadd
    //   697: fstore_1
    //   698: fload_1
    //   699: f2i
    //   700: istore #35
    //   702: fload #22
    //   704: ldc 0.5
    //   706: fadd
    //   707: fstore #22
    //   709: fload #22
    //   711: f2i
    //   712: istore #36
    //   714: fload_1
    //   715: fload #29
    //   717: fadd
    //   718: f2i
    //   719: istore #37
    //   721: fload #22
    //   723: fload #26
    //   725: fadd
    //   726: f2i
    //   727: istore #38
    //   729: iload #37
    //   731: iload #35
    //   733: isub
    //   734: istore #39
    //   736: iload #38
    //   738: iload #36
    //   740: isub
    //   741: istore #40
    //   743: iload #39
    //   745: aload_2
    //   746: invokevirtual getMeasuredWidth : ()I
    //   749: if_icmpne -> 761
    //   752: iload #40
    //   754: aload_2
    //   755: invokevirtual getMeasuredHeight : ()I
    //   758: if_icmpeq -> 764
    //   761: iconst_1
    //   762: istore #34
    //   764: iload #34
    //   766: ifne -> 774
    //   769: iload #7
    //   771: ifeq -> 792
    //   774: aload_2
    //   775: iload #39
    //   777: ldc 1073741824
    //   779: invokestatic makeMeasureSpec : (II)I
    //   782: iload #40
    //   784: ldc 1073741824
    //   786: invokestatic makeMeasureSpec : (II)I
    //   789: invokevirtual measure : (II)V
    //   792: aload_2
    //   793: iload #35
    //   795: iload #36
    //   797: iload #37
    //   799: iload #38
    //   801: invokevirtual layout : (IIII)V
    //   804: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\constraintlayout\motion\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */