package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.Switch;
import b0.i;
import c1.c;
import c1.g;

public class SwitchPreference extends TwoStatePreference {
  private final a Q = new a(this);
  
  private CharSequence R;
  
  private CharSequence S;
  
  public SwitchPreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, i.a(paramContext, c.j, 16843629));
  }
  
  public SwitchPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public SwitchPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.J0, paramInt1, paramInt2);
    L(i.o(typedArray, g.R0, g.K0));
    K(i.o(typedArray, g.Q0, g.L0));
    O(i.o(typedArray, g.T0, g.N0));
    N(i.o(typedArray, g.S0, g.O0));
    J(i.b(typedArray, g.P0, g.M0, false));
    typedArray.recycle();
  }
  
  private void P(View paramView) {
    boolean bool = paramView instanceof Switch;
    if (bool)
      ((Switch)paramView).setOnCheckedChangeListener(null); 
    if (paramView instanceof Checkable)
      ((Checkable)paramView).setChecked(this.L); 
    if (bool) {
      Switch switch_ = (Switch)paramView;
      switch_.setTextOn(this.R);
      switch_.setTextOff(this.S);
      switch_.setOnCheckedChangeListener(this.Q);
    } 
  }
  
  private void Q(View paramView) {
    if (!((AccessibilityManager)e().getSystemService("accessibility")).isEnabled())
      return; 
    P(paramView.findViewById(16908352));
    M(paramView.findViewById(16908304));
  }
  
  protected void A(View paramView) {
    super.A(paramView);
    Q(paramView);
  }
  
  public void N(CharSequence paramCharSequence) {
    this.S = paramCharSequence;
    t();
  }
  
  public void O(CharSequence paramCharSequence) {
    this.R = paramCharSequence;
    t();
  }
  
  private class a implements CompoundButton.OnCheckedChangeListener {
    a(SwitchPreference this$0) {}
    
    public void onCheckedChanged(CompoundButton param1CompoundButton, boolean param1Boolean) {
      if (!this.a.b(Boolean.valueOf(param1Boolean))) {
        param1CompoundButton.setChecked(param1Boolean ^ true);
        return;
      } 
      this.a.I(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\SwitchPreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */