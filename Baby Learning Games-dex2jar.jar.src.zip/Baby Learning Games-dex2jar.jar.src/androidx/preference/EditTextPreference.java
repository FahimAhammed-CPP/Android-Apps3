package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import b0.i;
import c1.c;
import c1.f;
import c1.g;

public class EditTextPreference extends DialogPreference {
  private String R;
  
  public EditTextPreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, i.a(paramContext, c.d, 16842898));
  }
  
  public EditTextPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public EditTextPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.v, paramInt1, paramInt2);
    paramInt1 = g.w;
    if (i.b(typedArray, paramInt1, paramInt1, false))
      E(a.b()); 
    typedArray.recycle();
  }
  
  public boolean F() {
    return (TextUtils.isEmpty(this.R) || super.F());
  }
  
  public String H() {
    return this.R;
  }
  
  protected Object x(TypedArray paramTypedArray, int paramInt) {
    return paramTypedArray.getString(paramInt);
  }
  
  public static final class a implements Preference.e<EditTextPreference> {
    private static a a;
    
    public static a b() {
      if (a == null)
        a = new a(); 
      return a;
    }
    
    public CharSequence c(EditTextPreference param1EditTextPreference) {
      return TextUtils.isEmpty(param1EditTextPreference.H()) ? param1EditTextPreference.e().getString(f.a) : param1EditTextPreference.H();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\EditTextPreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */