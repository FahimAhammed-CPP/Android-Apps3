package androidx.preference;

import android.content.Context;
import android.util.AttributeSet;
import b0.i;
import c1.c;

public class PreferenceCategory extends PreferenceGroup {
  public PreferenceCategory(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, i.a(paramContext, c.e, 16842892));
  }
  
  public PreferenceCategory(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public PreferenceCategory(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public boolean F() {
    return super.r() ^ true;
  }
  
  public boolean r() {
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\PreferenceCategory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */