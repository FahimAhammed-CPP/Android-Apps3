package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import b0.i;
import c1.c;
import c1.g;

public abstract class DialogPreference extends Preference {
  private CharSequence L;
  
  private CharSequence M;
  
  private Drawable N;
  
  private CharSequence O;
  
  private CharSequence P;
  
  private int Q;
  
  public DialogPreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, i.a(paramContext, c.b, 16842897));
  }
  
  public DialogPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public DialogPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.i, paramInt1, paramInt2);
    String str = i.o(typedArray, g.s, g.j);
    this.L = str;
    if (str == null)
      this.L = p(); 
    this.M = i.o(typedArray, g.r, g.k);
    this.N = i.c(typedArray, g.p, g.l);
    this.O = i.o(typedArray, g.u, g.m);
    this.P = i.o(typedArray, g.t, g.n);
    this.Q = i.n(typedArray, g.q, g.o, 0);
    typedArray.recycle();
  }
  
  protected void v() {
    m();
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\DialogPreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */