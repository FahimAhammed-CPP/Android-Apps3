package androidx.preference;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import c1.c;

public class DropDownPreference extends ListPreference {
  private final Context W;
  
  private final ArrayAdapter X;
  
  private Spinner Y;
  
  private final AdapterView.OnItemSelectedListener Z = new a(this);
  
  public DropDownPreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, c.c);
  }
  
  public DropDownPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public DropDownPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.W = paramContext;
    this.X = O();
    P();
  }
  
  private void P() {
    this.X.clear();
    if (I() != null)
      for (CharSequence charSequence : I())
        this.X.add(charSequence.toString());  
  }
  
  protected ArrayAdapter O() {
    return new ArrayAdapter(this.W, 17367049);
  }
  
  protected void t() {
    super.t();
    ArrayAdapter arrayAdapter = this.X;
    if (arrayAdapter != null)
      arrayAdapter.notifyDataSetChanged(); 
  }
  
  protected void v() {
    this.Y.performClick();
  }
  
  class a implements AdapterView.OnItemSelectedListener {
    a(DropDownPreference this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int >= 0) {
        String str = this.f.K()[param1Int].toString();
        if (!str.equals(this.f.L()) && this.f.b(str))
          this.f.N(str); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\DropDownPreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */