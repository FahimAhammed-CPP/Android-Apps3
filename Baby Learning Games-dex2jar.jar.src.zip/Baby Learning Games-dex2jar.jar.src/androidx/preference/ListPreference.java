package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import b0.i;
import c1.c;
import c1.f;
import c1.g;

public class ListPreference extends DialogPreference {
  private CharSequence[] R;
  
  private CharSequence[] S;
  
  private String T;
  
  private String U;
  
  private boolean V;
  
  public ListPreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, i.a(paramContext, c.b, 16842897));
  }
  
  public ListPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public ListPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray2 = paramContext.obtainStyledAttributes(paramAttributeSet, g.x, paramInt1, paramInt2);
    this.R = i.q(typedArray2, g.A, g.y);
    this.S = i.q(typedArray2, g.B, g.z);
    int i = g.C;
    if (i.b(typedArray2, i, i, false))
      E(a.b()); 
    typedArray2.recycle();
    TypedArray typedArray1 = paramContext.obtainStyledAttributes(paramAttributeSet, g.I, paramInt1, paramInt2);
    this.U = i.o(typedArray1, g.q0, g.Q);
    typedArray1.recycle();
  }
  
  private int M() {
    return H(this.T);
  }
  
  public int H(String paramString) {
    if (paramString != null) {
      CharSequence[] arrayOfCharSequence = this.S;
      if (arrayOfCharSequence != null)
        for (int i = arrayOfCharSequence.length - 1; i >= 0; i--) {
          if (TextUtils.equals(this.S[i].toString(), paramString))
            return i; 
        }  
    } 
    return -1;
  }
  
  public CharSequence[] I() {
    return this.R;
  }
  
  public CharSequence J() {
    int i = M();
    if (i >= 0) {
      CharSequence[] arrayOfCharSequence = this.R;
      if (arrayOfCharSequence != null)
        return arrayOfCharSequence[i]; 
    } 
    return null;
  }
  
  public CharSequence[] K() {
    return this.S;
  }
  
  public String L() {
    return this.T;
  }
  
  public void N(String paramString) {
    int i = TextUtils.equals(this.T, paramString) ^ true;
    if (i != 0 || !this.V) {
      this.T = paramString;
      this.V = true;
      D(paramString);
      if (i != 0)
        t(); 
    } 
  }
  
  public CharSequence n() {
    if (o() != null)
      return o().a(this); 
    CharSequence charSequence2 = J();
    CharSequence charSequence3 = super.n();
    String str = this.U;
    if (str == null)
      return charSequence3; 
    CharSequence charSequence1 = charSequence2;
    if (charSequence2 == null)
      charSequence1 = ""; 
    charSequence1 = String.format(str, new Object[] { charSequence1 });
    if (TextUtils.equals(charSequence1, charSequence3))
      return charSequence3; 
    Log.w("ListPreference", "Setting a summary with a String formatting marker is no longer supported. You should use a SummaryProvider instead.");
    return charSequence1;
  }
  
  protected Object x(TypedArray paramTypedArray, int paramInt) {
    return paramTypedArray.getString(paramInt);
  }
  
  public static final class a implements Preference.e<ListPreference> {
    private static a a;
    
    public static a b() {
      if (a == null)
        a = new a(); 
      return a;
    }
    
    public CharSequence c(ListPreference param1ListPreference) {
      return TextUtils.isEmpty(param1ListPreference.J()) ? param1ListPreference.e().getString(f.a) : param1ListPreference.J();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\ListPreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */