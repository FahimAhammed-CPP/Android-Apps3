package androidx.preference;

import android.content.Context;
import android.util.AttributeSet;
import b0.i;
import c1.c;

public final class PreferenceScreen extends PreferenceGroup {
  private boolean U = true;
  
  public PreferenceScreen(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet, i.a(paramContext, c.f, 16842891));
  }
  
  protected void v() {
    if (h() == null && g() == null) {
      if (I() == 0)
        return; 
      m();
      throw null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\PreferenceScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */