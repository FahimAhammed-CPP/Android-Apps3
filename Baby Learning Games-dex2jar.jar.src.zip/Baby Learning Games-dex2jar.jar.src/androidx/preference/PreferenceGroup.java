package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;
import b0.i;
import c1.g;
import java.util.ArrayList;
import java.util.List;
import s.g;

public abstract class PreferenceGroup extends Preference {
  final g<String, Long> L = new g();
  
  private final Handler M = new Handler(Looper.getMainLooper());
  
  private final List<Preference> N = new ArrayList<Preference>();
  
  private boolean O = true;
  
  private int P = 0;
  
  private boolean Q = false;
  
  private int R = Integer.MAX_VALUE;
  
  private b S = null;
  
  private final Runnable T = new a(this);
  
  public PreferenceGroup(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public PreferenceGroup(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public PreferenceGroup(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.v0, paramInt1, paramInt2);
    paramInt1 = g.x0;
    this.O = i.b(typedArray, paramInt1, paramInt1, true);
    paramInt1 = g.w0;
    if (typedArray.hasValue(paramInt1))
      J(i.d(typedArray, paramInt1, paramInt1, 2147483647)); 
    typedArray.recycle();
  }
  
  public Preference H(int paramInt) {
    return this.N.get(paramInt);
  }
  
  public int I() {
    return this.N.size();
  }
  
  public void J(int paramInt) {
    if (paramInt != Integer.MAX_VALUE && !q()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(getClass().getSimpleName());
      stringBuilder.append(" should have a key defined if it contains an expandable preference");
      Log.e("PreferenceGroup", stringBuilder.toString());
    } 
    this.R = paramInt;
  }
  
  public void u(boolean paramBoolean) {
    super.u(paramBoolean);
    int j = I();
    for (int i = 0; i < j; i++)
      H(i).y(this, paramBoolean); 
  }
  
  class a implements Runnable {
    a(PreferenceGroup this$0) {}
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield f : Landroidx/preference/PreferenceGroup;
      //   6: getfield L : Ls/g;
      //   9: invokevirtual clear : ()V
      //   12: aload_0
      //   13: monitorexit
      //   14: return
      //   15: astore_1
      //   16: aload_0
      //   17: monitorexit
      //   18: aload_1
      //   19: athrow
      // Exception table:
      //   from	to	target	type
      //   2	14	15	finally
      //   16	18	15	finally
    }
  }
  
  public static interface b {}
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\PreferenceGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */