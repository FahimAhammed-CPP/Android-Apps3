package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import androidx.appcompat.widget.SwitchCompat;
import b0.i;
import c1.c;
import c1.d;
import c1.g;

public class SwitchPreferenceCompat extends TwoStatePreference {
  private final a Q = new a(this);
  
  private CharSequence R;
  
  private CharSequence S;
  
  public SwitchPreferenceCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, c.i);
  }
  
  public SwitchPreferenceCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public SwitchPreferenceCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.U0, paramInt1, paramInt2);
    L(i.o(typedArray, g.c1, g.V0));
    K(i.o(typedArray, g.b1, g.W0));
    O(i.o(typedArray, g.e1, g.Y0));
    N(i.o(typedArray, g.d1, g.Z0));
    J(i.b(typedArray, g.a1, g.X0, false));
    typedArray.recycle();
  }
  
  private void P(View paramView) {
    boolean bool = paramView instanceof SwitchCompat;
    if (bool)
      ((SwitchCompat)paramView).setOnCheckedChangeListener(null); 
    if (paramView instanceof Checkable)
      ((Checkable)paramView).setChecked(this.L); 
    if (bool) {
      SwitchCompat switchCompat = (SwitchCompat)paramView;
      switchCompat.setTextOn(this.R);
      switchCompat.setTextOff(this.S);
      switchCompat.setOnCheckedChangeListener(this.Q);
    } 
  }
  
  private void Q(View paramView) {
    if (!((AccessibilityManager)e().getSystemService("accessibility")).isEnabled())
      return; 
    P(paramView.findViewById(d.a));
    M(paramView.findViewById(16908304));
  }
  
  protected void A(View paramView) {
    super.A(paramView);
    Q(paramView);
  }
  
  public void N(CharSequence paramCharSequence) {
    this.S = paramCharSequence;
    t();
  }
  
  public void O(CharSequence paramCharSequence) {
    this.R = paramCharSequence;
    t();
  }
  
  private class a implements CompoundButton.OnCheckedChangeListener {
    a(SwitchPreferenceCompat this$0) {}
    
    public void onCheckedChanged(CompoundButton param1CompoundButton, boolean param1Boolean) {
      if (!this.a.b(Boolean.valueOf(param1Boolean))) {
        param1CompoundButton.setChecked(param1Boolean ^ true);
        return;
      } 
      this.a.I(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\SwitchPreferenceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */