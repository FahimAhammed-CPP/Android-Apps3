package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;

public abstract class TwoStatePreference extends Preference {
  protected boolean L;
  
  private CharSequence M;
  
  private CharSequence N;
  
  private boolean O;
  
  private boolean P;
  
  public TwoStatePreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public TwoStatePreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public TwoStatePreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public boolean F() {
    boolean bool = this.P;
    boolean bool1 = true;
    if (bool) {
      bool = this.L;
    } else if (!this.L) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool) {
      if (super.F())
        return true; 
      bool1 = false;
    } 
    return bool1;
  }
  
  public boolean H() {
    return this.L;
  }
  
  public void I(boolean paramBoolean) {
    boolean bool;
    if (this.L != paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool || !this.O) {
      this.L = paramBoolean;
      this.O = true;
      B(paramBoolean);
      if (bool) {
        u(F());
        t();
      } 
    } 
  }
  
  public void J(boolean paramBoolean) {
    this.P = paramBoolean;
  }
  
  public void K(CharSequence paramCharSequence) {
    this.N = paramCharSequence;
    if (!H())
      t(); 
  }
  
  public void L(CharSequence paramCharSequence) {
    this.M = paramCharSequence;
    if (H())
      t(); 
  }
  
  protected void M(View paramView) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof android/widget/TextView
    //   4: ifne -> 8
    //   7: return
    //   8: aload_1
    //   9: checkcast android/widget/TextView
    //   12: astore_1
    //   13: iconst_1
    //   14: istore_3
    //   15: aload_0
    //   16: getfield L : Z
    //   19: istore #5
    //   21: iconst_0
    //   22: istore #4
    //   24: iload #5
    //   26: ifeq -> 52
    //   29: aload_0
    //   30: getfield M : Ljava/lang/CharSequence;
    //   33: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   36: ifne -> 52
    //   39: aload_1
    //   40: aload_0
    //   41: getfield M : Ljava/lang/CharSequence;
    //   44: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   47: iconst_0
    //   48: istore_2
    //   49: goto -> 84
    //   52: iload_3
    //   53: istore_2
    //   54: aload_0
    //   55: getfield L : Z
    //   58: ifne -> 84
    //   61: iload_3
    //   62: istore_2
    //   63: aload_0
    //   64: getfield N : Ljava/lang/CharSequence;
    //   67: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   70: ifne -> 84
    //   73: aload_1
    //   74: aload_0
    //   75: getfield N : Ljava/lang/CharSequence;
    //   78: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   81: goto -> 47
    //   84: iload_2
    //   85: istore_3
    //   86: iload_2
    //   87: ifeq -> 114
    //   90: aload_0
    //   91: invokevirtual n : ()Ljava/lang/CharSequence;
    //   94: astore #6
    //   96: iload_2
    //   97: istore_3
    //   98: aload #6
    //   100: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   103: ifne -> 114
    //   106: aload_1
    //   107: aload #6
    //   109: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   112: iconst_0
    //   113: istore_3
    //   114: iload_3
    //   115: ifne -> 124
    //   118: iload #4
    //   120: istore_2
    //   121: goto -> 127
    //   124: bipush #8
    //   126: istore_2
    //   127: iload_2
    //   128: aload_1
    //   129: invokevirtual getVisibility : ()I
    //   132: if_icmpeq -> 140
    //   135: aload_1
    //   136: iload_2
    //   137: invokevirtual setVisibility : (I)V
    //   140: return
  }
  
  protected void v() {
    super.v();
    int i = H() ^ true;
    if (b(Boolean.valueOf(i)))
      I(i); 
  }
  
  protected Object x(TypedArray paramTypedArray, int paramInt) {
    return Boolean.valueOf(paramTypedArray.getBoolean(paramInt, false));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\TwoStatePreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */