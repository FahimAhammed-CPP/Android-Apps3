package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import c1.c;
import c1.g;

public class SeekBarPreference extends Preference {
  int L;
  
  int M;
  
  private int N;
  
  private int O;
  
  boolean P;
  
  SeekBar Q;
  
  private TextView R;
  
  boolean S;
  
  private boolean T;
  
  boolean U;
  
  private final SeekBar.OnSeekBarChangeListener V = new a(this);
  
  private final View.OnKeyListener W = new b(this);
  
  public SeekBarPreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, c.h);
  }
  
  public SeekBarPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public SeekBarPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.C0, paramInt1, paramInt2);
    this.M = typedArray.getInt(g.F0, 0);
    H(typedArray.getInt(g.D0, 100));
    I(typedArray.getInt(g.G0, 0));
    this.S = typedArray.getBoolean(g.E0, true);
    this.T = typedArray.getBoolean(g.H0, false);
    this.U = typedArray.getBoolean(g.I0, false);
    typedArray.recycle();
  }
  
  private void J(int paramInt, boolean paramBoolean) {
    int j = this.M;
    int i = paramInt;
    if (paramInt < j)
      i = j; 
    j = this.N;
    paramInt = i;
    if (i > j)
      paramInt = j; 
    if (paramInt != this.L) {
      this.L = paramInt;
      L(paramInt);
      C(paramInt);
      if (paramBoolean)
        t(); 
    } 
  }
  
  public final void H(int paramInt) {
    int j = this.M;
    int i = paramInt;
    if (paramInt < j)
      i = j; 
    if (i != this.N) {
      this.N = i;
      t();
    } 
  }
  
  public final void I(int paramInt) {
    if (paramInt != this.O) {
      this.O = Math.min(this.N - this.M, Math.abs(paramInt));
      t();
    } 
  }
  
  void K(SeekBar paramSeekBar) {
    int i = this.M + paramSeekBar.getProgress();
    if (i != this.L) {
      if (b(Integer.valueOf(i))) {
        J(i, false);
        return;
      } 
      paramSeekBar.setProgress(this.L - this.M);
      L(this.L);
    } 
  }
  
  void L(int paramInt) {
    TextView textView = this.R;
    if (textView != null)
      textView.setText(String.valueOf(paramInt)); 
  }
  
  protected Object x(TypedArray paramTypedArray, int paramInt) {
    return Integer.valueOf(paramTypedArray.getInt(paramInt, 0));
  }
  
  class a implements SeekBar.OnSeekBarChangeListener {
    a(SeekBarPreference this$0) {}
    
    public void onProgressChanged(SeekBar param1SeekBar, int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        SeekBarPreference seekBarPreference1 = this.a;
        if (seekBarPreference1.U || !seekBarPreference1.P) {
          seekBarPreference1.K(param1SeekBar);
          return;
        } 
      } 
      SeekBarPreference seekBarPreference = this.a;
      seekBarPreference.L(param1Int + seekBarPreference.M);
    }
    
    public void onStartTrackingTouch(SeekBar param1SeekBar) {
      this.a.P = true;
    }
    
    public void onStopTrackingTouch(SeekBar param1SeekBar) {
      this.a.P = false;
      int i = param1SeekBar.getProgress();
      SeekBarPreference seekBarPreference = this.a;
      if (i + seekBarPreference.M != seekBarPreference.L)
        seekBarPreference.K(param1SeekBar); 
    }
  }
  
  class b implements View.OnKeyListener {
    b(SeekBarPreference this$0) {}
    
    public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getAction() != 0)
        return false; 
      SeekBarPreference seekBarPreference = this.f;
      if (!seekBarPreference.S && (param1Int == 21 || param1Int == 22))
        return false; 
      if (param1Int != 23) {
        if (param1Int == 66)
          return false; 
        SeekBar seekBar = seekBarPreference.Q;
        if (seekBar == null) {
          Log.e("SeekBarPreference", "SeekBar view is null and hence cannot be adjusted.");
          return false;
        } 
        return seekBar.onKeyDown(param1Int, param1KeyEvent);
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\SeekBarPreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */