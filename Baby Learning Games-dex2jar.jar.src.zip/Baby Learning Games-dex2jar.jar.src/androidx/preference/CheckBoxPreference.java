package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import b0.i;
import c1.c;
import c1.g;

public class CheckBoxPreference extends TwoStatePreference {
  private final a Q = new a(this);
  
  public CheckBoxPreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, i.a(paramContext, c.a, 16842895));
  }
  
  public CheckBoxPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public CheckBoxPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.b, paramInt1, paramInt2);
    L(i.o(typedArray, g.h, g.c));
    K(i.o(typedArray, g.g, g.d));
    J(i.b(typedArray, g.f, g.e, false));
    typedArray.recycle();
  }
  
  private void N(View paramView) {
    boolean bool = paramView instanceof CompoundButton;
    if (bool)
      ((CompoundButton)paramView).setOnCheckedChangeListener(null); 
    if (paramView instanceof Checkable)
      ((Checkable)paramView).setChecked(this.L); 
    if (bool)
      ((CompoundButton)paramView).setOnCheckedChangeListener(this.Q); 
  }
  
  private void O(View paramView) {
    if (!((AccessibilityManager)e().getSystemService("accessibility")).isEnabled())
      return; 
    N(paramView.findViewById(16908289));
    M(paramView.findViewById(16908304));
  }
  
  protected void A(View paramView) {
    super.A(paramView);
    O(paramView);
  }
  
  private class a implements CompoundButton.OnCheckedChangeListener {
    a(CheckBoxPreference this$0) {}
    
    public void onCheckedChanged(CompoundButton param1CompoundButton, boolean param1Boolean) {
      if (!this.a.b(Boolean.valueOf(param1Boolean))) {
        param1CompoundButton.setChecked(param1Boolean ^ true);
        return;
      } 
      this.a.I(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\CheckBoxPreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */