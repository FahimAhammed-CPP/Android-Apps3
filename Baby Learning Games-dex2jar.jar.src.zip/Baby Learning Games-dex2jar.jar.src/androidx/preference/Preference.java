package androidx.preference;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import b0.i;
import c1.g;
import java.util.List;

public class Preference implements Comparable<Preference> {
  private boolean A;
  
  private boolean B = true;
  
  private boolean C;
  
  private boolean D;
  
  private boolean E = true;
  
  private int F;
  
  private int G;
  
  private b H;
  
  private List<Preference> I;
  
  private e J;
  
  private final View.OnClickListener K;
  
  private final Context f;
  
  private c g;
  
  private d h;
  
  private int i = Integer.MAX_VALUE;
  
  private int j = 0;
  
  private CharSequence k;
  
  private CharSequence l;
  
  private int m;
  
  private String n;
  
  private Intent o;
  
  private String p;
  
  private boolean q = true;
  
  private boolean r = true;
  
  private boolean s = true;
  
  private String t;
  
  private Object u;
  
  private boolean v = true;
  
  private boolean w = true;
  
  private boolean x = true;
  
  private boolean y = true;
  
  private boolean z = true;
  
  public Preference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, i.a(paramContext, c1.c.g, 16842894));
  }
  
  public Preference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public Preference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    int i = c1.e.a;
    this.F = i;
    this.K = new a(this);
    this.f = paramContext;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.I, paramInt1, paramInt2);
    this.m = i.n(typedArray, g.g0, g.J, 0);
    this.n = i.o(typedArray, g.j0, g.P);
    this.k = i.p(typedArray, g.r0, g.N);
    this.l = i.p(typedArray, g.q0, g.Q);
    this.i = i.d(typedArray, g.l0, g.R, 2147483647);
    this.p = i.o(typedArray, g.f0, g.W);
    this.F = i.n(typedArray, g.k0, g.M, i);
    this.G = i.n(typedArray, g.s0, g.S, 0);
    this.q = i.b(typedArray, g.e0, g.L, true);
    this.r = i.b(typedArray, g.n0, g.O, true);
    this.s = i.b(typedArray, g.m0, g.K, true);
    this.t = i.o(typedArray, g.c0, g.T);
    paramInt1 = g.Z;
    this.y = i.b(typedArray, paramInt1, paramInt1, this.r);
    paramInt1 = g.a0;
    this.z = i.b(typedArray, paramInt1, paramInt1, this.r);
    paramInt1 = g.b0;
    if (typedArray.hasValue(paramInt1)) {
      this.u = x(typedArray, paramInt1);
    } else {
      paramInt1 = g.U;
      if (typedArray.hasValue(paramInt1))
        this.u = x(typedArray, paramInt1); 
    } 
    this.E = i.b(typedArray, g.o0, g.V, true);
    paramInt1 = g.p0;
    boolean bool = typedArray.hasValue(paramInt1);
    this.A = bool;
    if (bool)
      this.B = i.b(typedArray, paramInt1, g.X, true); 
    this.C = i.b(typedArray, g.h0, g.Y, false);
    paramInt1 = g.i0;
    this.x = i.b(typedArray, paramInt1, paramInt1, true);
    paramInt1 = g.d0;
    this.D = i.b(typedArray, paramInt1, paramInt1, false);
    typedArray.recycle();
  }
  
  protected void A(View paramView) {
    z();
  }
  
  protected boolean B(boolean paramBoolean) {
    if (!G())
      return false; 
    if (paramBoolean == i(paramBoolean ^ true))
      return true; 
    l();
    throw null;
  }
  
  protected boolean C(int paramInt) {
    if (!G())
      return false; 
    if (paramInt == j(paramInt))
      return true; 
    l();
    throw null;
  }
  
  protected boolean D(String paramString) {
    if (!G())
      return false; 
    if (TextUtils.equals(paramString, k(null)))
      return true; 
    l();
    throw null;
  }
  
  public final void E(e parame) {
    this.J = parame;
    t();
  }
  
  public boolean F() {
    return r() ^ true;
  }
  
  protected boolean G() {
    return false;
  }
  
  public boolean b(Object paramObject) {
    c c1 = this.g;
    return (c1 == null || c1.a(this, paramObject));
  }
  
  public int d(Preference paramPreference) {
    int i = this.i;
    int j = paramPreference.i;
    if (i != j)
      return i - j; 
    CharSequence charSequence1 = this.k;
    CharSequence charSequence2 = paramPreference.k;
    return (charSequence1 == charSequence2) ? 0 : ((charSequence1 == null) ? 1 : ((charSequence2 == null) ? -1 : charSequence1.toString().compareToIgnoreCase(paramPreference.k.toString())));
  }
  
  public Context e() {
    return this.f;
  }
  
  StringBuilder f() {
    StringBuilder stringBuilder = new StringBuilder();
    CharSequence charSequence = p();
    if (!TextUtils.isEmpty(charSequence)) {
      stringBuilder.append(charSequence);
      stringBuilder.append(' ');
    } 
    charSequence = n();
    if (!TextUtils.isEmpty(charSequence)) {
      stringBuilder.append(charSequence);
      stringBuilder.append(' ');
    } 
    if (stringBuilder.length() > 0)
      stringBuilder.setLength(stringBuilder.length() - 1); 
    return stringBuilder;
  }
  
  public String g() {
    return this.p;
  }
  
  public Intent h() {
    return this.o;
  }
  
  protected boolean i(boolean paramBoolean) {
    if (!G())
      return paramBoolean; 
    l();
    throw null;
  }
  
  protected int j(int paramInt) {
    if (!G())
      return paramInt; 
    l();
    throw null;
  }
  
  protected String k(String paramString) {
    if (!G())
      return paramString; 
    l();
    throw null;
  }
  
  public c1.a l() {
    return null;
  }
  
  public c1.b m() {
    return null;
  }
  
  public CharSequence n() {
    return (o() != null) ? o().a(this) : this.l;
  }
  
  public final e o() {
    return this.J;
  }
  
  public CharSequence p() {
    return this.k;
  }
  
  public boolean q() {
    return TextUtils.isEmpty(this.n) ^ true;
  }
  
  public boolean r() {
    return (this.q && this.v && this.w);
  }
  
  public boolean s() {
    return this.r;
  }
  
  protected void t() {
    b b1 = this.H;
    if (b1 != null)
      b1.a(this); 
  }
  
  public String toString() {
    return f().toString();
  }
  
  public void u(boolean paramBoolean) {
    List<Preference> list = this.I;
    if (list == null)
      return; 
    int j = list.size();
    for (int i = 0; i < j; i++)
      ((Preference)list.get(i)).w(this, paramBoolean); 
  }
  
  protected void v() {}
  
  public void w(Preference paramPreference, boolean paramBoolean) {
    if (this.v == paramBoolean) {
      this.v = paramBoolean ^ true;
      u(F());
      t();
    } 
  }
  
  protected Object x(TypedArray paramTypedArray, int paramInt) {
    return null;
  }
  
  public void y(Preference paramPreference, boolean paramBoolean) {
    if (this.w == paramBoolean) {
      this.w = paramBoolean ^ true;
      u(F());
      t();
    } 
  }
  
  public void z() {
    if (r()) {
      if (!s())
        return; 
      v();
      d d1 = this.h;
      if (d1 != null && d1.a(this))
        return; 
      m();
      if (this.o != null)
        e().startActivity(this.o); 
    } 
  }
  
  class a implements View.OnClickListener {
    a(Preference this$0) {}
    
    public void onClick(View param1View) {
      this.f.A(param1View);
    }
  }
  
  static interface b {
    void a(Preference param1Preference);
  }
  
  public static interface c {
    boolean a(Preference param1Preference, Object param1Object);
  }
  
  public static interface d {
    boolean a(Preference param1Preference);
  }
  
  public static interface e<T extends Preference> {
    CharSequence a(T param1T);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\Preference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */