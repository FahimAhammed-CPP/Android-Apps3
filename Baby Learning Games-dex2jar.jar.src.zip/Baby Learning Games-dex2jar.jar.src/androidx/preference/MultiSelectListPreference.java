package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import b0.i;
import c1.c;
import c1.g;
import java.util.HashSet;
import java.util.Set;

public class MultiSelectListPreference extends DialogPreference {
  private CharSequence[] R;
  
  private CharSequence[] S;
  
  private Set<String> T = new HashSet<String>();
  
  public MultiSelectListPreference(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, i.a(paramContext, c.b, 16842897));
  }
  
  public MultiSelectListPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public MultiSelectListPreference(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, g.D, paramInt1, paramInt2);
    this.R = i.q(typedArray, g.G, g.E);
    this.S = i.q(typedArray, g.H, g.F);
    typedArray.recycle();
  }
  
  protected Object x(TypedArray paramTypedArray, int paramInt) {
    CharSequence[] arrayOfCharSequence = paramTypedArray.getTextArray(paramInt);
    HashSet<String> hashSet = new HashSet();
    int i = arrayOfCharSequence.length;
    for (paramInt = 0; paramInt < i; paramInt++)
      hashSet.add(arrayOfCharSequence[paramInt].toString()); 
    return hashSet;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\preference\MultiSelectListPreference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */