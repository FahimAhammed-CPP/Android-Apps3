package androidx.vectordrawable.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class g extends f {
  static final PorterDuff.Mode p = PorterDuff.Mode.SRC_IN;
  
  private h g = new h();
  
  private PorterDuffColorFilter h;
  
  private ColorFilter i;
  
  private boolean j;
  
  private boolean k = true;
  
  private Drawable.ConstantState l;
  
  private final float[] m = new float[9];
  
  private final Matrix n = new Matrix();
  
  private final Rect o = new Rect();
  
  g() {}
  
  g(h paramh) {
    this.h = j(this.h, paramh.c, paramh.d);
  }
  
  static int a(int paramInt, float paramFloat) {
    return paramInt & 0xFFFFFF | (int)(Color.alpha(paramInt) * paramFloat) << 24;
  }
  
  public static g b(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    if (Build.VERSION.SDK_INT >= 24) {
      g g1 = new g();
      g1.f = b0.h.e(paramResources, paramInt, paramTheme);
      g1.l = new i(g1.f.getConstantState());
      return g1;
    } 
    try {
      XmlResourceParser xmlResourceParser = paramResources.getXml(paramInt);
      AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
      while (true) {
        paramInt = xmlResourceParser.next();
        if (paramInt != 2 && paramInt != 1)
          continue; 
        break;
      } 
      if (paramInt == 2)
        return c(paramResources, (XmlPullParser)xmlResourceParser, attributeSet, paramTheme); 
      throw new XmlPullParserException("No start tag found");
    } catch (XmlPullParserException xmlPullParserException) {
      Log.e("VectorDrawableCompat", "parser error", (Throwable)xmlPullParserException);
    } catch (IOException iOException) {
      Log.e("VectorDrawableCompat", "parser error", iOException);
    } 
    return null;
  }
  
  public static g c(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    g g1 = new g();
    g1.inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    return g1;
  }
  
  private void e(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    h h1 = this.g;
    g g1 = h1.b;
    ArrayDeque<d> arrayDeque = new ArrayDeque();
    arrayDeque.push(g1.h);
    int j = paramXmlPullParser.getEventType();
    int k = paramXmlPullParser.getDepth();
    int i;
    for (i = 1; j != 1 && (paramXmlPullParser.getDepth() >= k + 1 || j != 3); i = m) {
      int m;
      if (j == 2) {
        c c;
        String str = paramXmlPullParser.getName();
        d d = arrayDeque.peek();
        if ("path".equals(str)) {
          c = new c();
          c.g(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
          d.b.add(c);
          if (c.getPathName() != null)
            g1.p.put(c.getPathName(), c); 
          m = 0;
          i = h1.a;
          h1.a = c.d | i;
        } else {
          b b;
          if ("clip-path".equals(c)) {
            b = new b();
            b.e(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
            d.b.add(b);
            if (b.getPathName() != null)
              g1.p.put(b.getPathName(), b); 
            m = h1.a;
            h1.a = b.d | m;
            m = i;
          } else {
            m = i;
            if ("group".equals(b)) {
              d d1 = new d();
              d1.c(paramResources, paramAttributeSet, paramTheme, paramXmlPullParser);
              d.b.add(d1);
              arrayDeque.push(d1);
              if (d1.getGroupName() != null)
                g1.p.put(d1.getGroupName(), d1); 
              m = h1.a;
              h1.a = d1.k | m;
              m = i;
            } 
          } 
        } 
      } else {
        m = i;
        if (j == 3) {
          m = i;
          if ("group".equals(paramXmlPullParser.getName())) {
            arrayDeque.pop();
            m = i;
          } 
        } 
      } 
      j = paramXmlPullParser.next();
    } 
    if (i == 0)
      return; 
    throw new XmlPullParserException("no path defined");
  }
  
  private boolean f() {
    return (isAutoMirrored() && d0.a.f(this) == 1);
  }
  
  private static PorterDuff.Mode g(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
  
  private void i(TypedArray paramTypedArray, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme) throws XmlPullParserException {
    String str;
    h h1 = this.g;
    g g1 = h1.b;
    h1.d = g(b0.i.k(paramTypedArray, paramXmlPullParser, "tintMode", 6, -1), PorterDuff.Mode.SRC_IN);
    ColorStateList colorStateList = b0.i.g(paramTypedArray, paramXmlPullParser, paramTheme, "tint", 1);
    if (colorStateList != null)
      h1.c = colorStateList; 
    h1.e = b0.i.e(paramTypedArray, paramXmlPullParser, "autoMirrored", 5, h1.e);
    g1.k = b0.i.j(paramTypedArray, paramXmlPullParser, "viewportWidth", 7, g1.k);
    float f1 = b0.i.j(paramTypedArray, paramXmlPullParser, "viewportHeight", 8, g1.l);
    g1.l = f1;
    if (g1.k > 0.0F) {
      if (f1 > 0.0F) {
        g1.i = paramTypedArray.getDimension(3, g1.i);
        f1 = paramTypedArray.getDimension(2, g1.j);
        g1.j = f1;
        if (g1.i > 0.0F) {
          if (f1 > 0.0F) {
            g1.setAlpha(b0.i.j(paramTypedArray, paramXmlPullParser, "alpha", 4, g1.getAlpha()));
            str = paramTypedArray.getString(0);
            if (str != null) {
              g1.n = str;
              g1.p.put(str, g1);
            } 
            return;
          } 
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append(str.getPositionDescription());
          stringBuilder3.append("<vector> tag requires height > 0");
          throw new XmlPullParserException(stringBuilder3.toString());
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str.getPositionDescription());
        stringBuilder2.append("<vector> tag requires width > 0");
        throw new XmlPullParserException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str.getPositionDescription());
      stringBuilder1.append("<vector> tag requires viewportHeight > 0");
      throw new XmlPullParserException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str.getPositionDescription());
    stringBuilder.append("<vector> tag requires viewportWidth > 0");
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  public boolean canApplyTheme() {
    Drawable drawable = this.f;
    if (drawable != null)
      d0.a.b(drawable); 
    return false;
  }
  
  Object d(String paramString) {
    return this.g.b.p.get(paramString);
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.draw(paramCanvas);
      return;
    } 
    copyBounds(this.o);
    if (this.o.width() > 0) {
      PorterDuffColorFilter porterDuffColorFilter;
      if (this.o.height() <= 0)
        return; 
      ColorFilter colorFilter2 = this.i;
      ColorFilter colorFilter1 = colorFilter2;
      if (colorFilter2 == null)
        porterDuffColorFilter = this.h; 
      paramCanvas.getMatrix(this.n);
      this.n.getValues(this.m);
      float f1 = Math.abs(this.m[0]);
      float f2 = Math.abs(this.m[4]);
      float f4 = Math.abs(this.m[1]);
      float f3 = Math.abs(this.m[3]);
      if (f4 != 0.0F || f3 != 0.0F) {
        f1 = 1.0F;
        f2 = f1;
      } 
      int i = (int)(this.o.width() * f1);
      int j = (int)(this.o.height() * f2);
      i = Math.min(2048, i);
      j = Math.min(2048, j);
      if (i > 0) {
        if (j <= 0)
          return; 
        int k = paramCanvas.save();
        Rect rect = this.o;
        paramCanvas.translate(rect.left, rect.top);
        if (f()) {
          paramCanvas.translate(this.o.width(), 0.0F);
          paramCanvas.scale(-1.0F, 1.0F);
        } 
        this.o.offsetTo(0, 0);
        this.g.c(i, j);
        if (!this.k) {
          this.g.j(i, j);
        } else if (!this.g.b()) {
          this.g.j(i, j);
          this.g.i();
        } 
        this.g.d(paramCanvas, (ColorFilter)porterDuffColorFilter, this.o);
        paramCanvas.restoreToCount(k);
      } 
    } 
  }
  
  public int getAlpha() {
    Drawable drawable = this.f;
    return (drawable != null) ? d0.a.d(drawable) : this.g.b.getRootAlpha();
  }
  
  public int getChangingConfigurations() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.getChangingConfigurations() : (super.getChangingConfigurations() | this.g.getChangingConfigurations());
  }
  
  public ColorFilter getColorFilter() {
    Drawable drawable = this.f;
    return (drawable != null) ? d0.a.e(drawable) : this.i;
  }
  
  public Drawable.ConstantState getConstantState() {
    if (this.f != null && Build.VERSION.SDK_INT >= 24)
      return new i(this.f.getConstantState()); 
    this.g.a = getChangingConfigurations();
    return this.g;
  }
  
  public int getIntrinsicHeight() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.getIntrinsicHeight() : (int)this.g.b.j;
  }
  
  public int getIntrinsicWidth() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.getIntrinsicWidth() : (int)this.g.b.i;
  }
  
  public int getOpacity() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.getOpacity() : -3;
  }
  
  void h(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet) throws XmlPullParserException, IOException {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.inflate(paramResources, paramXmlPullParser, paramAttributeSet);
      return;
    } 
    inflate(paramResources, paramXmlPullParser, paramAttributeSet, null);
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.g(drawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return;
    } 
    h h1 = this.g;
    h1.b = new g();
    TypedArray typedArray = b0.i.s(paramResources, paramTheme, paramAttributeSet, a.a);
    i(typedArray, paramXmlPullParser, paramTheme);
    typedArray.recycle();
    h1.a = getChangingConfigurations();
    h1.k = true;
    e(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    this.h = j(this.h, h1.c, h1.d);
  }
  
  public void invalidateSelf() {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.invalidateSelf();
      return;
    } 
    super.invalidateSelf();
  }
  
  public boolean isAutoMirrored() {
    Drawable drawable = this.f;
    return (drawable != null) ? d0.a.h(drawable) : this.g.e;
  }
  
  public boolean isStateful() {
    Drawable drawable = this.f;
    if (drawable != null)
      return drawable.isStateful(); 
    if (!super.isStateful()) {
      h h1 = this.g;
      if (h1 != null) {
        if (!h1.g()) {
          ColorStateList colorStateList = this.g.c;
          return (colorStateList != null && colorStateList.isStateful());
        } 
      } else {
        return false;
      } 
    } 
    return true;
  }
  
  PorterDuffColorFilter j(PorterDuffColorFilter paramPorterDuffColorFilter, ColorStateList paramColorStateList, PorterDuff.Mode paramMode) {
    return (paramColorStateList == null || paramMode == null) ? null : new PorterDuffColorFilter(paramColorStateList.getColorForState(getState(), 0), paramMode);
  }
  
  public Drawable mutate() {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.mutate();
      return this;
    } 
    if (!this.j && super.mutate() == this) {
      this.g = new h(this.g);
      this.j = true;
    } 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.f;
    if (drawable != null)
      drawable.setBounds(paramRect); 
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    Drawable drawable = this.f;
    if (drawable != null)
      return drawable.setState(paramArrayOfint); 
    boolean bool2 = false;
    h h1 = this.g;
    ColorStateList colorStateList = h1.c;
    boolean bool1 = bool2;
    if (colorStateList != null) {
      PorterDuff.Mode mode = h1.d;
      bool1 = bool2;
      if (mode != null) {
        this.h = j(this.h, colorStateList, mode);
        invalidateSelf();
        bool1 = true;
      } 
    } 
    if (h1.g() && h1.h(paramArrayOfint)) {
      invalidateSelf();
      return true;
    } 
    return bool1;
  }
  
  public void scheduleSelf(Runnable paramRunnable, long paramLong) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.scheduleSelf(paramRunnable, paramLong);
      return;
    } 
    super.scheduleSelf(paramRunnable, paramLong);
  }
  
  public void setAlpha(int paramInt) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.setAlpha(paramInt);
      return;
    } 
    if (this.g.b.getRootAlpha() != paramInt) {
      this.g.b.setRootAlpha(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.j(drawable, paramBoolean);
      return;
    } 
    this.g.e = paramBoolean;
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.setColorFilter(paramColorFilter);
      return;
    } 
    this.i = paramColorFilter;
    invalidateSelf();
  }
  
  public void setTint(int paramInt) {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.n(drawable, paramInt);
      return;
    } 
    setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.o(drawable, paramColorStateList);
      return;
    } 
    h h1 = this.g;
    if (h1.c != paramColorStateList) {
      h1.c = paramColorStateList;
      this.h = j(this.h, paramColorStateList, h1.d);
      invalidateSelf();
    } 
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.p(drawable, paramMode);
      return;
    } 
    h h1 = this.g;
    if (h1.d != paramMode) {
      h1.d = paramMode;
      this.h = j(this.h, h1.c, paramMode);
      invalidateSelf();
    } 
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.setVisible(paramBoolean1, paramBoolean2) : super.setVisible(paramBoolean1, paramBoolean2);
  }
  
  public void unscheduleSelf(Runnable paramRunnable) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.unscheduleSelf(paramRunnable);
      return;
    } 
    super.unscheduleSelf(paramRunnable);
  }
  
  private static class b extends f {
    b() {}
    
    b(b param1b) {
      super(param1b);
    }
    
    private void f(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser) {
      String str = param1TypedArray.getString(0);
      if (str != null)
        this.b = str; 
      str = param1TypedArray.getString(1);
      if (str != null)
        this.a = c0.d.d(str); 
      this.c = b0.i.k(param1TypedArray, param1XmlPullParser, "fillType", 2, 0);
    }
    
    public boolean c() {
      return true;
    }
    
    public void e(Resources param1Resources, AttributeSet param1AttributeSet, Resources.Theme param1Theme, XmlPullParser param1XmlPullParser) {
      if (!b0.i.r(param1XmlPullParser, "pathData"))
        return; 
      TypedArray typedArray = b0.i.s(param1Resources, param1Theme, param1AttributeSet, a.d);
      f(typedArray, param1XmlPullParser);
      typedArray.recycle();
    }
  }
  
  private static class c extends f {
    private int[] e;
    
    b0.d f;
    
    float g = 0.0F;
    
    b0.d h;
    
    float i = 1.0F;
    
    float j = 1.0F;
    
    float k = 0.0F;
    
    float l = 1.0F;
    
    float m = 0.0F;
    
    Paint.Cap n = Paint.Cap.BUTT;
    
    Paint.Join o = Paint.Join.MITER;
    
    float p = 4.0F;
    
    c() {}
    
    c(c param1c) {
      super(param1c);
      this.e = param1c.e;
      this.f = param1c.f;
      this.g = param1c.g;
      this.i = param1c.i;
      this.h = param1c.h;
      this.c = param1c.c;
      this.j = param1c.j;
      this.k = param1c.k;
      this.l = param1c.l;
      this.m = param1c.m;
      this.n = param1c.n;
      this.o = param1c.o;
      this.p = param1c.p;
    }
    
    private Paint.Cap e(int param1Int, Paint.Cap param1Cap) {
      return (param1Int != 0) ? ((param1Int != 1) ? ((param1Int != 2) ? param1Cap : Paint.Cap.SQUARE) : Paint.Cap.ROUND) : Paint.Cap.BUTT;
    }
    
    private Paint.Join f(int param1Int, Paint.Join param1Join) {
      return (param1Int != 0) ? ((param1Int != 1) ? ((param1Int != 2) ? param1Join : Paint.Join.BEVEL) : Paint.Join.ROUND) : Paint.Join.MITER;
    }
    
    private void h(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser, Resources.Theme param1Theme) {
      this.e = null;
      if (!b0.i.r(param1XmlPullParser, "pathData"))
        return; 
      String str = param1TypedArray.getString(0);
      if (str != null)
        this.b = str; 
      str = param1TypedArray.getString(2);
      if (str != null)
        this.a = c0.d.d(str); 
      this.h = b0.i.i(param1TypedArray, param1XmlPullParser, param1Theme, "fillColor", 1, 0);
      this.j = b0.i.j(param1TypedArray, param1XmlPullParser, "fillAlpha", 12, this.j);
      this.n = e(b0.i.k(param1TypedArray, param1XmlPullParser, "strokeLineCap", 8, -1), this.n);
      this.o = f(b0.i.k(param1TypedArray, param1XmlPullParser, "strokeLineJoin", 9, -1), this.o);
      this.p = b0.i.j(param1TypedArray, param1XmlPullParser, "strokeMiterLimit", 10, this.p);
      this.f = b0.i.i(param1TypedArray, param1XmlPullParser, param1Theme, "strokeColor", 3, 0);
      this.i = b0.i.j(param1TypedArray, param1XmlPullParser, "strokeAlpha", 11, this.i);
      this.g = b0.i.j(param1TypedArray, param1XmlPullParser, "strokeWidth", 4, this.g);
      this.l = b0.i.j(param1TypedArray, param1XmlPullParser, "trimPathEnd", 6, this.l);
      this.m = b0.i.j(param1TypedArray, param1XmlPullParser, "trimPathOffset", 7, this.m);
      this.k = b0.i.j(param1TypedArray, param1XmlPullParser, "trimPathStart", 5, this.k);
      this.c = b0.i.k(param1TypedArray, param1XmlPullParser, "fillType", 13, this.c);
    }
    
    public boolean a() {
      return (this.h.i() || this.f.i());
    }
    
    public boolean b(int[] param1ArrayOfint) {
      boolean bool = this.h.j(param1ArrayOfint);
      return this.f.j(param1ArrayOfint) | bool;
    }
    
    public void g(Resources param1Resources, AttributeSet param1AttributeSet, Resources.Theme param1Theme, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = b0.i.s(param1Resources, param1Theme, param1AttributeSet, a.c);
      h(typedArray, param1XmlPullParser, param1Theme);
      typedArray.recycle();
    }
    
    float getFillAlpha() {
      return this.j;
    }
    
    int getFillColor() {
      return this.h.e();
    }
    
    float getStrokeAlpha() {
      return this.i;
    }
    
    int getStrokeColor() {
      return this.f.e();
    }
    
    float getStrokeWidth() {
      return this.g;
    }
    
    float getTrimPathEnd() {
      return this.l;
    }
    
    float getTrimPathOffset() {
      return this.m;
    }
    
    float getTrimPathStart() {
      return this.k;
    }
    
    void setFillAlpha(float param1Float) {
      this.j = param1Float;
    }
    
    void setFillColor(int param1Int) {
      this.h.k(param1Int);
    }
    
    void setStrokeAlpha(float param1Float) {
      this.i = param1Float;
    }
    
    void setStrokeColor(int param1Int) {
      this.f.k(param1Int);
    }
    
    void setStrokeWidth(float param1Float) {
      this.g = param1Float;
    }
    
    void setTrimPathEnd(float param1Float) {
      this.l = param1Float;
    }
    
    void setTrimPathOffset(float param1Float) {
      this.m = param1Float;
    }
    
    void setTrimPathStart(float param1Float) {
      this.k = param1Float;
    }
  }
  
  private static class d extends e {
    final Matrix a = new Matrix();
    
    final ArrayList<g.e> b = new ArrayList<g.e>();
    
    float c = 0.0F;
    
    private float d = 0.0F;
    
    private float e = 0.0F;
    
    private float f = 1.0F;
    
    private float g = 1.0F;
    
    private float h = 0.0F;
    
    private float i = 0.0F;
    
    final Matrix j;
    
    int k;
    
    private int[] l;
    
    private String m;
    
    public d() {
      super(null);
      this.j = new Matrix();
      this.m = null;
    }
    
    public d(d param1d, s.a<String, Object> param1a) {
      super(null);
      Matrix matrix = new Matrix();
      this.j = matrix;
      this.m = null;
      this.c = param1d.c;
      this.d = param1d.d;
      this.e = param1d.e;
      this.f = param1d.f;
      this.g = param1d.g;
      this.h = param1d.h;
      this.i = param1d.i;
      this.l = param1d.l;
      String str = param1d.m;
      this.m = str;
      this.k = param1d.k;
      if (str != null)
        param1a.put(str, this); 
      matrix.set(param1d.j);
      ArrayList<g.e> arrayList = param1d.b;
      for (int i = 0; i < arrayList.size(); i++) {
        param1d = (d)arrayList.get(i);
        if (param1d instanceof d) {
          param1d = param1d;
          this.b.add(new d(param1d, param1a));
        } else {
          g.c c;
          g.b b;
          if (param1d instanceof g.c) {
            c = new g.c((g.c)param1d);
          } else if (c instanceof g.b) {
            b = new g.b((g.b)c);
          } else {
            throw new IllegalStateException("Unknown object in the tree!");
          } 
          this.b.add(b);
          str = b.b;
          if (str != null)
            param1a.put(str, b); 
        } 
      } 
    }
    
    private void d() {
      this.j.reset();
      this.j.postTranslate(-this.d, -this.e);
      this.j.postScale(this.f, this.g);
      this.j.postRotate(this.c, 0.0F, 0.0F);
      this.j.postTranslate(this.h + this.d, this.i + this.e);
    }
    
    private void e(TypedArray param1TypedArray, XmlPullParser param1XmlPullParser) {
      this.l = null;
      this.c = b0.i.j(param1TypedArray, param1XmlPullParser, "rotation", 5, this.c);
      this.d = param1TypedArray.getFloat(1, this.d);
      this.e = param1TypedArray.getFloat(2, this.e);
      this.f = b0.i.j(param1TypedArray, param1XmlPullParser, "scaleX", 3, this.f);
      this.g = b0.i.j(param1TypedArray, param1XmlPullParser, "scaleY", 4, this.g);
      this.h = b0.i.j(param1TypedArray, param1XmlPullParser, "translateX", 6, this.h);
      this.i = b0.i.j(param1TypedArray, param1XmlPullParser, "translateY", 7, this.i);
      String str = param1TypedArray.getString(0);
      if (str != null)
        this.m = str; 
      d();
    }
    
    public boolean a() {
      for (int i = 0; i < this.b.size(); i++) {
        if (((g.e)this.b.get(i)).a())
          return true; 
      } 
      return false;
    }
    
    public boolean b(int[] param1ArrayOfint) {
      int i = 0;
      boolean bool = false;
      while (i < this.b.size()) {
        bool |= ((g.e)this.b.get(i)).b(param1ArrayOfint);
        i++;
      } 
      return bool;
    }
    
    public void c(Resources param1Resources, AttributeSet param1AttributeSet, Resources.Theme param1Theme, XmlPullParser param1XmlPullParser) {
      TypedArray typedArray = b0.i.s(param1Resources, param1Theme, param1AttributeSet, a.b);
      e(typedArray, param1XmlPullParser);
      typedArray.recycle();
    }
    
    public String getGroupName() {
      return this.m;
    }
    
    public Matrix getLocalMatrix() {
      return this.j;
    }
    
    public float getPivotX() {
      return this.d;
    }
    
    public float getPivotY() {
      return this.e;
    }
    
    public float getRotation() {
      return this.c;
    }
    
    public float getScaleX() {
      return this.f;
    }
    
    public float getScaleY() {
      return this.g;
    }
    
    public float getTranslateX() {
      return this.h;
    }
    
    public float getTranslateY() {
      return this.i;
    }
    
    public void setPivotX(float param1Float) {
      if (param1Float != this.d) {
        this.d = param1Float;
        d();
      } 
    }
    
    public void setPivotY(float param1Float) {
      if (param1Float != this.e) {
        this.e = param1Float;
        d();
      } 
    }
    
    public void setRotation(float param1Float) {
      if (param1Float != this.c) {
        this.c = param1Float;
        d();
      } 
    }
    
    public void setScaleX(float param1Float) {
      if (param1Float != this.f) {
        this.f = param1Float;
        d();
      } 
    }
    
    public void setScaleY(float param1Float) {
      if (param1Float != this.g) {
        this.g = param1Float;
        d();
      } 
    }
    
    public void setTranslateX(float param1Float) {
      if (param1Float != this.h) {
        this.h = param1Float;
        d();
      } 
    }
    
    public void setTranslateY(float param1Float) {
      if (param1Float != this.i) {
        this.i = param1Float;
        d();
      } 
    }
  }
  
  private static abstract class e {
    private e() {}
    
    public boolean a() {
      return false;
    }
    
    public boolean b(int[] param1ArrayOfint) {
      return false;
    }
  }
  
  private static abstract class f extends e {
    protected c0.d.b[] a = null;
    
    String b;
    
    int c = 0;
    
    int d;
    
    public f() {
      super(null);
    }
    
    public f(f param1f) {
      super(null);
      this.b = param1f.b;
      this.d = param1f.d;
      this.a = c0.d.f(param1f.a);
    }
    
    public boolean c() {
      return false;
    }
    
    public void d(Path param1Path) {
      param1Path.reset();
      c0.d.b[] arrayOfB = this.a;
      if (arrayOfB != null)
        c0.d.b.e(arrayOfB, param1Path); 
    }
    
    public c0.d.b[] getPathData() {
      return this.a;
    }
    
    public String getPathName() {
      return this.b;
    }
    
    public void setPathData(c0.d.b[] param1ArrayOfb) {
      if (!c0.d.b(this.a, param1ArrayOfb)) {
        this.a = c0.d.f(param1ArrayOfb);
        return;
      } 
      c0.d.j(this.a, param1ArrayOfb);
    }
  }
  
  private static class g {
    private static final Matrix q = new Matrix();
    
    private final Path a;
    
    private final Path b;
    
    private final Matrix c = new Matrix();
    
    Paint d;
    
    Paint e;
    
    private PathMeasure f;
    
    private int g;
    
    final g.d h;
    
    float i = 0.0F;
    
    float j = 0.0F;
    
    float k = 0.0F;
    
    float l = 0.0F;
    
    int m = 255;
    
    String n = null;
    
    Boolean o = null;
    
    final s.a<String, Object> p;
    
    public g() {
      this.p = new s.a();
      this.h = new g.d();
      this.a = new Path();
      this.b = new Path();
    }
    
    public g(g param1g) {
      s.a<String, Object> a1 = new s.a();
      this.p = a1;
      this.h = new g.d(param1g.h, a1);
      this.a = new Path(param1g.a);
      this.b = new Path(param1g.b);
      this.i = param1g.i;
      this.j = param1g.j;
      this.k = param1g.k;
      this.l = param1g.l;
      this.g = param1g.g;
      this.m = param1g.m;
      this.n = param1g.n;
      String str = param1g.n;
      if (str != null)
        a1.put(str, this); 
      this.o = param1g.o;
    }
    
    private static float a(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      return param1Float1 * param1Float4 - param1Float2 * param1Float3;
    }
    
    private void c(g.d param1d, Matrix param1Matrix, Canvas param1Canvas, int param1Int1, int param1Int2, ColorFilter param1ColorFilter) {
      param1d.a.set(param1Matrix);
      param1d.a.preConcat(param1d.j);
      param1Canvas.save();
      int i;
      for (i = 0; i < param1d.b.size(); i++) {
        g.e e = param1d.b.get(i);
        if (e instanceof g.d) {
          c((g.d)e, param1d.a, param1Canvas, param1Int1, param1Int2, param1ColorFilter);
        } else if (e instanceof g.f) {
          d(param1d, (g.f)e, param1Canvas, param1Int1, param1Int2, param1ColorFilter);
        } 
      } 
      param1Canvas.restore();
    }
    
    private void d(g.d param1d, g.f param1f, Canvas param1Canvas, int param1Int1, int param1Int2, ColorFilter param1ColorFilter) {
      Path path1;
      float f2 = param1Int1 / this.k;
      float f3 = param1Int2 / this.l;
      float f1 = Math.min(f2, f3);
      Matrix matrix = param1d.a;
      this.c.set(matrix);
      this.c.postScale(f2, f3);
      f2 = e(matrix);
      if (f2 == 0.0F)
        return; 
      param1f.d(this.a);
      Path path2 = this.a;
      this.b.reset();
      if (param1f.c()) {
        Path.FillType fillType;
        path1 = this.b;
        if (param1f.c == 0) {
          fillType = Path.FillType.WINDING;
        } else {
          fillType = Path.FillType.EVEN_ODD;
        } 
        path1.setFillType(fillType);
        this.b.addPath(path2, this.c);
        param1Canvas.clipPath(this.b);
        return;
      } 
      param1f = param1f;
      float f4 = ((g.c)param1f).k;
      if (f4 != 0.0F || ((g.c)param1f).l != 1.0F) {
        float f5 = ((g.c)param1f).m;
        float f6 = ((g.c)param1f).l;
        if (this.f == null)
          this.f = new PathMeasure(); 
        this.f.setPath(this.a, false);
        f3 = this.f.getLength();
        f4 = (f4 + f5) % 1.0F * f3;
        f5 = (f6 + f5) % 1.0F * f3;
        path2.reset();
        if (f4 > f5) {
          this.f.getSegment(f4, f3, path2, true);
          this.f.getSegment(0.0F, f5, path2, true);
        } else {
          this.f.getSegment(f4, f5, path2, true);
        } 
        path2.rLineTo(0.0F, 0.0F);
      } 
      this.b.addPath(path2, this.c);
      if (((g.c)param1f).h.l()) {
        Shader shader;
        Path.FillType fillType;
        b0.d d1 = ((g.c)param1f).h;
        if (this.e == null) {
          Paint paint1 = new Paint(1);
          this.e = paint1;
          paint1.setStyle(Paint.Style.FILL);
        } 
        Paint paint = this.e;
        if (d1.h()) {
          shader = d1.f();
          shader.setLocalMatrix(this.c);
          paint.setShader(shader);
          paint.setAlpha(Math.round(((g.c)param1f).j * 255.0F));
        } else {
          paint.setShader(null);
          paint.setAlpha(255);
          paint.setColor(g.a(shader.e(), ((g.c)param1f).j));
        } 
        paint.setColorFilter((ColorFilter)path1);
        Path path = this.b;
        if (param1f.c == 0) {
          fillType = Path.FillType.WINDING;
        } else {
          fillType = Path.FillType.EVEN_ODD;
        } 
        path.setFillType(fillType);
        param1Canvas.drawPath(this.b, paint);
      } 
      if (((g.c)param1f).f.l()) {
        Shader shader;
        b0.d d1 = ((g.c)param1f).f;
        if (this.d == null) {
          Paint paint1 = new Paint(1);
          this.d = paint1;
          paint1.setStyle(Paint.Style.STROKE);
        } 
        Paint paint = this.d;
        Paint.Join join = ((g.c)param1f).o;
        if (join != null)
          paint.setStrokeJoin(join); 
        Paint.Cap cap = ((g.c)param1f).n;
        if (cap != null)
          paint.setStrokeCap(cap); 
        paint.setStrokeMiter(((g.c)param1f).p);
        if (d1.h()) {
          shader = d1.f();
          shader.setLocalMatrix(this.c);
          paint.setShader(shader);
          paint.setAlpha(Math.round(((g.c)param1f).i * 255.0F));
        } else {
          paint.setShader(null);
          paint.setAlpha(255);
          paint.setColor(g.a(shader.e(), ((g.c)param1f).i));
        } 
        paint.setColorFilter((ColorFilter)path1);
        paint.setStrokeWidth(((g.c)param1f).g * f1 * f2);
        param1Canvas.drawPath(this.b, paint);
      } 
    }
    
    private float e(Matrix param1Matrix) {
      float[] arrayOfFloat = new float[4];
      arrayOfFloat[0] = 0.0F;
      arrayOfFloat[1] = 1.0F;
      arrayOfFloat[2] = 1.0F;
      arrayOfFloat[3] = 0.0F;
      param1Matrix.mapVectors(arrayOfFloat);
      float f1 = (float)Math.hypot(arrayOfFloat[0], arrayOfFloat[1]);
      float f3 = (float)Math.hypot(arrayOfFloat[2], arrayOfFloat[3]);
      float f2 = a(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3]);
      f3 = Math.max(f1, f3);
      f1 = 0.0F;
      if (f3 > 0.0F)
        f1 = Math.abs(f2) / f3; 
      return f1;
    }
    
    public void b(Canvas param1Canvas, int param1Int1, int param1Int2, ColorFilter param1ColorFilter) {
      c(this.h, q, param1Canvas, param1Int1, param1Int2, param1ColorFilter);
    }
    
    public boolean f() {
      if (this.o == null)
        this.o = Boolean.valueOf(this.h.a()); 
      return this.o.booleanValue();
    }
    
    public boolean g(int[] param1ArrayOfint) {
      return this.h.b(param1ArrayOfint);
    }
    
    public float getAlpha() {
      return getRootAlpha() / 255.0F;
    }
    
    public int getRootAlpha() {
      return this.m;
    }
    
    public void setAlpha(float param1Float) {
      setRootAlpha((int)(param1Float * 255.0F));
    }
    
    public void setRootAlpha(int param1Int) {
      this.m = param1Int;
    }
  }
  
  private static class h extends Drawable.ConstantState {
    int a;
    
    g.g b;
    
    ColorStateList c = null;
    
    PorterDuff.Mode d = g.p;
    
    boolean e;
    
    Bitmap f;
    
    ColorStateList g;
    
    PorterDuff.Mode h;
    
    int i;
    
    boolean j;
    
    boolean k;
    
    Paint l;
    
    public h() {
      this.b = new g.g();
    }
    
    public h(h param1h) {
      if (param1h != null) {
        this.a = param1h.a;
        g.g g1 = new g.g(param1h.b);
        this.b = g1;
        if (param1h.b.e != null)
          g1.e = new Paint(param1h.b.e); 
        if (param1h.b.d != null)
          this.b.d = new Paint(param1h.b.d); 
        this.c = param1h.c;
        this.d = param1h.d;
        this.e = param1h.e;
      } 
    }
    
    public boolean a(int param1Int1, int param1Int2) {
      return (param1Int1 == this.f.getWidth() && param1Int2 == this.f.getHeight());
    }
    
    public boolean b() {
      return (!this.k && this.g == this.c && this.h == this.d && this.j == this.e && this.i == this.b.getRootAlpha());
    }
    
    public void c(int param1Int1, int param1Int2) {
      if (this.f == null || !a(param1Int1, param1Int2)) {
        this.f = Bitmap.createBitmap(param1Int1, param1Int2, Bitmap.Config.ARGB_8888);
        this.k = true;
      } 
    }
    
    public void d(Canvas param1Canvas, ColorFilter param1ColorFilter, Rect param1Rect) {
      Paint paint = e(param1ColorFilter);
      param1Canvas.drawBitmap(this.f, null, param1Rect, paint);
    }
    
    public Paint e(ColorFilter param1ColorFilter) {
      if (!f() && param1ColorFilter == null)
        return null; 
      if (this.l == null) {
        Paint paint = new Paint();
        this.l = paint;
        paint.setFilterBitmap(true);
      } 
      this.l.setAlpha(this.b.getRootAlpha());
      this.l.setColorFilter(param1ColorFilter);
      return this.l;
    }
    
    public boolean f() {
      return (this.b.getRootAlpha() < 255);
    }
    
    public boolean g() {
      return this.b.f();
    }
    
    public int getChangingConfigurations() {
      return this.a;
    }
    
    public boolean h(int[] param1ArrayOfint) {
      boolean bool = this.b.g(param1ArrayOfint);
      this.k |= bool;
      return bool;
    }
    
    public void i() {
      this.g = this.c;
      this.h = this.d;
      this.i = this.b.getRootAlpha();
      this.j = this.e;
      this.k = false;
    }
    
    public void j(int param1Int1, int param1Int2) {
      this.f.eraseColor(0);
      Canvas canvas = new Canvas(this.f);
      this.b.b(canvas, param1Int1, param1Int2, null);
    }
    
    public Drawable newDrawable() {
      return new g(this);
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      return new g(this);
    }
  }
  
  private static class i extends Drawable.ConstantState {
    private final Drawable.ConstantState a;
    
    public i(Drawable.ConstantState param1ConstantState) {
      this.a = param1ConstantState;
    }
    
    public boolean canApplyTheme() {
      return this.a.canApplyTheme();
    }
    
    public int getChangingConfigurations() {
      return this.a.getChangingConfigurations();
    }
    
    public Drawable newDrawable() {
      g g = new g();
      g.f = this.a.newDrawable();
      return g;
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      g g = new g();
      g.f = this.a.newDrawable(param1Resources);
      return g;
    }
    
    public Drawable newDrawable(Resources param1Resources, Resources.Theme param1Theme) {
      g g = new g();
      g.f = this.a.newDrawable(param1Resources, param1Theme);
      return g;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\vectordrawable\graphics\drawable\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */