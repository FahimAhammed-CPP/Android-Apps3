package androidx.vectordrawable.graphics.drawable;

import android.content.Context;
import android.content.res.Resources;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

public class c {
  public static Interpolator a(Context paramContext, int paramInt) throws Resources.NotFoundException {
    return AnimationUtils.loadInterpolator(paramContext, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\vectordrawable\graphics\drawable\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */