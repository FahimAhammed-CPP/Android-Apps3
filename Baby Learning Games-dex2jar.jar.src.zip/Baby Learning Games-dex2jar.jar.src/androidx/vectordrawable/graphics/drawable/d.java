package androidx.vectordrawable.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Xml;
import b0.i;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class d {
  private static Animator a(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, float paramFloat) throws XmlPullParserException, IOException {
    return b(paramContext, paramResources, paramTheme, paramXmlPullParser, Xml.asAttributeSet(paramXmlPullParser), null, 0, paramFloat);
  }
  
  private static Animator b(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, AnimatorSet paramAnimatorSet, int paramInt, float paramFloat) throws XmlPullParserException, IOException {
    byte b;
    int i = paramXmlPullParser.getDepth();
    TypedArray typedArray = null;
    ArrayList<TypedArray> arrayList = null;
    while (true) {
      int j = paramXmlPullParser.next();
      b = 0;
      boolean bool = false;
      if ((j != 3 || paramXmlPullParser.getDepth() > i) && j != 1) {
        ObjectAnimator objectAnimator;
        TypedArray typedArray1;
        if (j != 2)
          continue; 
        String str = paramXmlPullParser.getName();
        if (str.equals("objectAnimator")) {
          objectAnimator = n(paramContext, paramResources, paramTheme, paramAttributeSet, paramFloat, paramXmlPullParser);
        } else {
          ValueAnimator valueAnimator;
          if (objectAnimator.equals("animator")) {
            valueAnimator = l(paramContext, paramResources, paramTheme, paramAttributeSet, null, paramFloat, paramXmlPullParser);
          } else {
            AnimatorSet animatorSet;
            if (valueAnimator.equals("set")) {
              animatorSet = new AnimatorSet();
              typedArray = i.s(paramResources, paramTheme, paramAttributeSet, a.h);
              b(paramContext, paramResources, paramTheme, paramXmlPullParser, paramAttributeSet, animatorSet, i.k(typedArray, paramXmlPullParser, "ordering", 0, 0), paramFloat);
              typedArray.recycle();
            } else if (animatorSet.equals("propertyValuesHolder")) {
              PropertyValuesHolder[] arrayOfPropertyValuesHolder = p(paramContext, paramResources, paramTheme, paramXmlPullParser, Xml.asAttributeSet(paramXmlPullParser));
              if (arrayOfPropertyValuesHolder != null && typedArray instanceof ValueAnimator)
                ((ValueAnimator)typedArray).setValues(arrayOfPropertyValuesHolder); 
              bool = true;
              typedArray1 = typedArray;
            } else {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unknown animator name: ");
              stringBuilder.append(paramXmlPullParser.getName());
              throw new RuntimeException(stringBuilder.toString());
            } 
          } 
        } 
        typedArray = typedArray1;
        if (paramAnimatorSet != null) {
          typedArray = typedArray1;
          if (!bool) {
            ArrayList<TypedArray> arrayList1 = arrayList;
            if (arrayList == null)
              arrayList1 = new ArrayList(); 
            arrayList1.add(typedArray1);
            typedArray = typedArray1;
            arrayList = arrayList1;
          } 
        } 
        continue;
      } 
      break;
    } 
    if (paramAnimatorSet != null && arrayList != null) {
      Animator[] arrayOfAnimator = new Animator[arrayList.size()];
      Iterator<TypedArray> iterator = arrayList.iterator();
      int j;
      for (j = b; iterator.hasNext(); j++)
        arrayOfAnimator[j] = (Animator)iterator.next(); 
      if (paramInt == 0) {
        paramAnimatorSet.playTogether(arrayOfAnimator);
        return (Animator)typedArray;
      } 
      paramAnimatorSet.playSequentially(arrayOfAnimator);
    } 
    return (Animator)typedArray;
  }
  
  private static Keyframe c(Keyframe paramKeyframe, float paramFloat) {
    return (paramKeyframe.getType() == float.class) ? Keyframe.ofFloat(paramFloat) : ((paramKeyframe.getType() == int.class) ? Keyframe.ofInt(paramFloat) : Keyframe.ofObject(paramFloat));
  }
  
  private static void d(Keyframe[] paramArrayOfKeyframe, float paramFloat, int paramInt1, int paramInt2) {
    paramFloat /= (paramInt2 - paramInt1 + 2);
    while (paramInt1 <= paramInt2) {
      paramArrayOfKeyframe[paramInt1].setFraction(paramArrayOfKeyframe[paramInt1 - 1].getFraction() + paramFloat);
      paramInt1++;
    } 
  }
  
  private static PropertyValuesHolder e(TypedArray paramTypedArray, int paramInt1, int paramInt2, int paramInt3, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: iload_2
    //   2: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   5: astore #12
    //   7: aload #12
    //   9: ifnull -> 18
    //   12: iconst_1
    //   13: istore #8
    //   15: goto -> 21
    //   18: iconst_0
    //   19: istore #8
    //   21: iload #8
    //   23: ifeq -> 36
    //   26: aload #12
    //   28: getfield type : I
    //   31: istore #10
    //   33: goto -> 39
    //   36: iconst_0
    //   37: istore #10
    //   39: aload_0
    //   40: iload_3
    //   41: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   44: astore #12
    //   46: aload #12
    //   48: ifnull -> 57
    //   51: iconst_1
    //   52: istore #9
    //   54: goto -> 60
    //   57: iconst_0
    //   58: istore #9
    //   60: iload #9
    //   62: ifeq -> 75
    //   65: aload #12
    //   67: getfield type : I
    //   70: istore #11
    //   72: goto -> 78
    //   75: iconst_0
    //   76: istore #11
    //   78: iload_1
    //   79: istore #7
    //   81: iload_1
    //   82: iconst_4
    //   83: if_icmpne -> 121
    //   86: iload #8
    //   88: ifeq -> 99
    //   91: iload #10
    //   93: invokestatic h : (I)Z
    //   96: ifne -> 112
    //   99: iload #9
    //   101: ifeq -> 118
    //   104: iload #11
    //   106: invokestatic h : (I)Z
    //   109: ifeq -> 118
    //   112: iconst_3
    //   113: istore #7
    //   115: goto -> 121
    //   118: iconst_0
    //   119: istore #7
    //   121: iload #7
    //   123: ifne -> 131
    //   126: iconst_1
    //   127: istore_1
    //   128: goto -> 133
    //   131: iconst_0
    //   132: istore_1
    //   133: aconst_null
    //   134: astore #12
    //   136: aconst_null
    //   137: astore #14
    //   139: iload #7
    //   141: iconst_2
    //   142: if_icmpne -> 334
    //   145: aload_0
    //   146: iload_2
    //   147: invokevirtual getString : (I)Ljava/lang/String;
    //   150: astore #13
    //   152: aload_0
    //   153: iload_3
    //   154: invokevirtual getString : (I)Ljava/lang/String;
    //   157: astore #14
    //   159: aload #13
    //   161: invokestatic d : (Ljava/lang/String;)[Lc0/d$b;
    //   164: astore #15
    //   166: aload #14
    //   168: invokestatic d : (Ljava/lang/String;)[Lc0/d$b;
    //   171: astore #16
    //   173: aload #15
    //   175: ifnonnull -> 186
    //   178: aload #12
    //   180: astore_0
    //   181: aload #16
    //   183: ifnull -> 722
    //   186: aload #15
    //   188: ifnull -> 304
    //   191: new androidx/vectordrawable/graphics/drawable/d$a
    //   194: dup
    //   195: invokespecial <init> : ()V
    //   198: astore_0
    //   199: aload #16
    //   201: ifnull -> 286
    //   204: aload #15
    //   206: aload #16
    //   208: invokestatic b : ([Lc0/d$b;[Lc0/d$b;)Z
    //   211: ifeq -> 238
    //   214: aload #4
    //   216: aload_0
    //   217: iconst_2
    //   218: anewarray java/lang/Object
    //   221: dup
    //   222: iconst_0
    //   223: aload #15
    //   225: aastore
    //   226: dup
    //   227: iconst_1
    //   228: aload #16
    //   230: aastore
    //   231: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   234: astore_0
    //   235: goto -> 302
    //   238: new java/lang/StringBuilder
    //   241: dup
    //   242: invokespecial <init> : ()V
    //   245: astore_0
    //   246: aload_0
    //   247: ldc ' Can't morph from '
    //   249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: pop
    //   253: aload_0
    //   254: aload #13
    //   256: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   259: pop
    //   260: aload_0
    //   261: ldc ' to '
    //   263: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   266: pop
    //   267: aload_0
    //   268: aload #14
    //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: new android/view/InflateException
    //   277: dup
    //   278: aload_0
    //   279: invokevirtual toString : ()Ljava/lang/String;
    //   282: invokespecial <init> : (Ljava/lang/String;)V
    //   285: athrow
    //   286: aload #4
    //   288: aload_0
    //   289: iconst_1
    //   290: anewarray java/lang/Object
    //   293: dup
    //   294: iconst_0
    //   295: aload #15
    //   297: aastore
    //   298: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   301: astore_0
    //   302: aload_0
    //   303: areturn
    //   304: aload #12
    //   306: astore_0
    //   307: aload #16
    //   309: ifnull -> 722
    //   312: aload #4
    //   314: new androidx/vectordrawable/graphics/drawable/d$a
    //   317: dup
    //   318: invokespecial <init> : ()V
    //   321: iconst_1
    //   322: anewarray java/lang/Object
    //   325: dup
    //   326: iconst_0
    //   327: aload #16
    //   329: aastore
    //   330: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   333: areturn
    //   334: iload #7
    //   336: iconst_3
    //   337: if_icmpne -> 348
    //   340: invokestatic a : ()Landroidx/vectordrawable/graphics/drawable/e;
    //   343: astore #13
    //   345: goto -> 351
    //   348: aconst_null
    //   349: astore #13
    //   351: iload_1
    //   352: ifeq -> 499
    //   355: iload #8
    //   357: ifeq -> 454
    //   360: iload #10
    //   362: iconst_5
    //   363: if_icmpne -> 377
    //   366: aload_0
    //   367: iload_2
    //   368: fconst_0
    //   369: invokevirtual getDimension : (IF)F
    //   372: fstore #5
    //   374: goto -> 385
    //   377: aload_0
    //   378: iload_2
    //   379: fconst_0
    //   380: invokevirtual getFloat : (IF)F
    //   383: fstore #5
    //   385: iload #9
    //   387: ifeq -> 437
    //   390: iload #11
    //   392: iconst_5
    //   393: if_icmpne -> 407
    //   396: aload_0
    //   397: iload_3
    //   398: fconst_0
    //   399: invokevirtual getDimension : (IF)F
    //   402: fstore #6
    //   404: goto -> 415
    //   407: aload_0
    //   408: iload_3
    //   409: fconst_0
    //   410: invokevirtual getFloat : (IF)F
    //   413: fstore #6
    //   415: aload #4
    //   417: iconst_2
    //   418: newarray float
    //   420: dup
    //   421: iconst_0
    //   422: fload #5
    //   424: fastore
    //   425: dup
    //   426: iconst_1
    //   427: fload #6
    //   429: fastore
    //   430: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   433: astore_0
    //   434: goto -> 493
    //   437: aload #4
    //   439: iconst_1
    //   440: newarray float
    //   442: dup
    //   443: iconst_0
    //   444: fload #5
    //   446: fastore
    //   447: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   450: astore_0
    //   451: goto -> 493
    //   454: iload #11
    //   456: iconst_5
    //   457: if_icmpne -> 471
    //   460: aload_0
    //   461: iload_3
    //   462: fconst_0
    //   463: invokevirtual getDimension : (IF)F
    //   466: fstore #5
    //   468: goto -> 479
    //   471: aload_0
    //   472: iload_3
    //   473: fconst_0
    //   474: invokevirtual getFloat : (IF)F
    //   477: fstore #5
    //   479: aload #4
    //   481: iconst_1
    //   482: newarray float
    //   484: dup
    //   485: iconst_0
    //   486: fload #5
    //   488: fastore
    //   489: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   492: astore_0
    //   493: aload_0
    //   494: astore #12
    //   496: goto -> 696
    //   499: iload #8
    //   501: ifeq -> 631
    //   504: iload #10
    //   506: iconst_5
    //   507: if_icmpne -> 521
    //   510: aload_0
    //   511: iload_2
    //   512: fconst_0
    //   513: invokevirtual getDimension : (IF)F
    //   516: f2i
    //   517: istore_1
    //   518: goto -> 546
    //   521: iload #10
    //   523: invokestatic h : (I)Z
    //   526: ifeq -> 539
    //   529: aload_0
    //   530: iload_2
    //   531: iconst_0
    //   532: invokevirtual getColor : (II)I
    //   535: istore_1
    //   536: goto -> 546
    //   539: aload_0
    //   540: iload_2
    //   541: iconst_0
    //   542: invokevirtual getInt : (II)I
    //   545: istore_1
    //   546: iload #9
    //   548: ifeq -> 614
    //   551: iload #11
    //   553: iconst_5
    //   554: if_icmpne -> 568
    //   557: aload_0
    //   558: iload_3
    //   559: fconst_0
    //   560: invokevirtual getDimension : (IF)F
    //   563: f2i
    //   564: istore_2
    //   565: goto -> 593
    //   568: iload #11
    //   570: invokestatic h : (I)Z
    //   573: ifeq -> 586
    //   576: aload_0
    //   577: iload_3
    //   578: iconst_0
    //   579: invokevirtual getColor : (II)I
    //   582: istore_2
    //   583: goto -> 593
    //   586: aload_0
    //   587: iload_3
    //   588: iconst_0
    //   589: invokevirtual getInt : (II)I
    //   592: istore_2
    //   593: aload #4
    //   595: iconst_2
    //   596: newarray int
    //   598: dup
    //   599: iconst_0
    //   600: iload_1
    //   601: iastore
    //   602: dup
    //   603: iconst_1
    //   604: iload_2
    //   605: iastore
    //   606: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   609: astore #12
    //   611: goto -> 696
    //   614: aload #4
    //   616: iconst_1
    //   617: newarray int
    //   619: dup
    //   620: iconst_0
    //   621: iload_1
    //   622: iastore
    //   623: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   626: astore #12
    //   628: goto -> 696
    //   631: aload #14
    //   633: astore #12
    //   635: iload #9
    //   637: ifeq -> 696
    //   640: iload #11
    //   642: iconst_5
    //   643: if_icmpne -> 657
    //   646: aload_0
    //   647: iload_3
    //   648: fconst_0
    //   649: invokevirtual getDimension : (IF)F
    //   652: f2i
    //   653: istore_1
    //   654: goto -> 682
    //   657: iload #11
    //   659: invokestatic h : (I)Z
    //   662: ifeq -> 675
    //   665: aload_0
    //   666: iload_3
    //   667: iconst_0
    //   668: invokevirtual getColor : (II)I
    //   671: istore_1
    //   672: goto -> 682
    //   675: aload_0
    //   676: iload_3
    //   677: iconst_0
    //   678: invokevirtual getInt : (II)I
    //   681: istore_1
    //   682: aload #4
    //   684: iconst_1
    //   685: newarray int
    //   687: dup
    //   688: iconst_0
    //   689: iload_1
    //   690: iastore
    //   691: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   694: astore #12
    //   696: aload #12
    //   698: astore_0
    //   699: aload #12
    //   701: ifnull -> 722
    //   704: aload #12
    //   706: astore_0
    //   707: aload #13
    //   709: ifnull -> 722
    //   712: aload #12
    //   714: aload #13
    //   716: invokevirtual setEvaluator : (Landroid/animation/TypeEvaluator;)V
    //   719: aload #12
    //   721: astore_0
    //   722: aload_0
    //   723: areturn
  }
  
  private static int f(TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    boolean bool1;
    TypedValue typedValue2 = paramTypedArray.peekValue(paramInt1);
    int i = 1;
    boolean bool2 = false;
    if (typedValue2 != null) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt1 != 0) {
      bool1 = typedValue2.type;
    } else {
      bool1 = false;
    } 
    TypedValue typedValue1 = paramTypedArray.peekValue(paramInt2);
    if (typedValue1 != null) {
      paramInt2 = i;
    } else {
      paramInt2 = 0;
    } 
    if (paramInt2 != 0) {
      i = typedValue1.type;
    } else {
      i = 0;
    } 
    if (paramInt1 == 0 || !h(bool1)) {
      paramInt1 = bool2;
      if (paramInt2 != 0) {
        paramInt1 = bool2;
        if (h(i))
          return 3; 
      } 
      return paramInt1;
    } 
    return 3;
  }
  
  private static int g(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, XmlPullParser paramXmlPullParser) {
    boolean bool;
    TypedArray typedArray = i.s(paramResources, paramTheme, paramAttributeSet, a.j);
    byte b2 = 0;
    TypedValue typedValue = i.t(typedArray, paramXmlPullParser, "value", 0);
    if (typedValue != null) {
      bool = true;
    } else {
      bool = false;
    } 
    byte b1 = b2;
    if (bool) {
      b1 = b2;
      if (h(typedValue.type))
        b1 = 3; 
    } 
    typedArray.recycle();
    return b1;
  }
  
  private static boolean h(int paramInt) {
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  public static Animator i(Context paramContext, int paramInt) throws Resources.NotFoundException {
    return (Build.VERSION.SDK_INT >= 24) ? AnimatorInflater.loadAnimator(paramContext, paramInt) : j(paramContext, paramContext.getResources(), paramContext.getTheme(), paramInt);
  }
  
  public static Animator j(Context paramContext, Resources paramResources, Resources.Theme paramTheme, int paramInt) throws Resources.NotFoundException {
    return k(paramContext, paramResources, paramTheme, paramInt, 1.0F);
  }
  
  public static Animator k(Context paramContext, Resources paramResources, Resources.Theme paramTheme, int paramInt, float paramFloat) throws Resources.NotFoundException {
    XmlResourceParser xmlResourceParser2 = null;
    XmlResourceParser xmlResourceParser3 = null;
    XmlResourceParser xmlResourceParser1 = null;
    try {
      XmlResourceParser xmlResourceParser = paramResources.getAnimation(paramInt);
      xmlResourceParser1 = xmlResourceParser;
      xmlResourceParser2 = xmlResourceParser;
      xmlResourceParser3 = xmlResourceParser;
      Animator animator = a(paramContext, paramResources, paramTheme, (XmlPullParser)xmlResourceParser, paramFloat);
      if (xmlResourceParser != null)
        xmlResourceParser.close(); 
      return animator;
    } catch (XmlPullParserException xmlPullParserException) {
      xmlResourceParser1 = xmlResourceParser3;
      StringBuilder stringBuilder = new StringBuilder();
      xmlResourceParser1 = xmlResourceParser3;
      stringBuilder.append("Can't load animation resource ID #0x");
      xmlResourceParser1 = xmlResourceParser3;
      stringBuilder.append(Integer.toHexString(paramInt));
      xmlResourceParser1 = xmlResourceParser3;
      Resources.NotFoundException notFoundException = new Resources.NotFoundException(stringBuilder.toString());
      xmlResourceParser1 = xmlResourceParser3;
      notFoundException.initCause((Throwable)xmlPullParserException);
      xmlResourceParser1 = xmlResourceParser3;
      throw notFoundException;
    } catch (IOException iOException) {
      xmlResourceParser1 = xmlResourceParser2;
      StringBuilder stringBuilder = new StringBuilder();
      xmlResourceParser1 = xmlResourceParser2;
      stringBuilder.append("Can't load animation resource ID #0x");
      xmlResourceParser1 = xmlResourceParser2;
      stringBuilder.append(Integer.toHexString(paramInt));
      xmlResourceParser1 = xmlResourceParser2;
      Resources.NotFoundException notFoundException = new Resources.NotFoundException(stringBuilder.toString());
      xmlResourceParser1 = xmlResourceParser2;
      notFoundException.initCause(iOException);
      xmlResourceParser1 = xmlResourceParser2;
      throw notFoundException;
    } finally {}
    if (xmlResourceParser1 != null)
      xmlResourceParser1.close(); 
    throw paramContext;
  }
  
  private static ValueAnimator l(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, ValueAnimator paramValueAnimator, float paramFloat, XmlPullParser paramXmlPullParser) throws Resources.NotFoundException {
    TypedArray typedArray2 = i.s(paramResources, paramTheme, paramAttributeSet, a.g);
    TypedArray typedArray1 = i.s(paramResources, paramTheme, paramAttributeSet, a.k);
    ValueAnimator valueAnimator = paramValueAnimator;
    if (paramValueAnimator == null)
      valueAnimator = new ValueAnimator(); 
    q(valueAnimator, typedArray2, typedArray1, paramFloat, paramXmlPullParser);
    int i = i.l(typedArray2, paramXmlPullParser, "interpolator", 0, 0);
    if (i > 0)
      valueAnimator.setInterpolator((TimeInterpolator)c.a(paramContext, i)); 
    typedArray2.recycle();
    if (typedArray1 != null)
      typedArray1.recycle(); 
    return valueAnimator;
  }
  
  private static Keyframe m(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int paramInt, XmlPullParser paramXmlPullParser) throws XmlPullParserException, IOException {
    Keyframe keyframe;
    boolean bool;
    TypedArray typedArray = i.s(paramResources, paramTheme, paramAttributeSet, a.j);
    float f = i.j(typedArray, paramXmlPullParser, "fraction", 3, -1.0F);
    TypedValue typedValue = i.t(typedArray, paramXmlPullParser, "value", 0);
    if (typedValue != null) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = paramInt;
    if (paramInt == 4)
      if (bool && h(typedValue.type)) {
        i = 3;
      } else {
        i = 0;
      }  
    if (bool) {
      if (i != 0) {
        if (i != 1 && i != 3) {
          typedValue = null;
        } else {
          keyframe = Keyframe.ofInt(f, i.k(typedArray, paramXmlPullParser, "value", 0, 0));
        } 
      } else {
        keyframe = Keyframe.ofFloat(f, i.j(typedArray, paramXmlPullParser, "value", 0, 0.0F));
      } 
    } else if (i == 0) {
      keyframe = Keyframe.ofFloat(f);
    } else {
      keyframe = Keyframe.ofInt(f);
    } 
    paramInt = i.l(typedArray, paramXmlPullParser, "interpolator", 1, 0);
    if (paramInt > 0)
      keyframe.setInterpolator((TimeInterpolator)c.a(paramContext, paramInt)); 
    typedArray.recycle();
    return keyframe;
  }
  
  private static ObjectAnimator n(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, float paramFloat, XmlPullParser paramXmlPullParser) throws Resources.NotFoundException {
    ObjectAnimator objectAnimator = new ObjectAnimator();
    l(paramContext, paramResources, paramTheme, paramAttributeSet, (ValueAnimator)objectAnimator, paramFloat, paramXmlPullParser);
    return objectAnimator;
  }
  
  private static PropertyValuesHolder o(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, String paramString, int paramInt) throws XmlPullParserException, IOException {
    PropertyValuesHolder propertyValuesHolder;
    Context context = null;
    ArrayList<Keyframe> arrayList = null;
    int i = paramInt;
    while (true) {
      paramInt = paramXmlPullParser.next();
      if (paramInt != 3 && paramInt != 1) {
        if (paramXmlPullParser.getName().equals("keyframe")) {
          paramInt = i;
          if (i == 4)
            paramInt = g(paramResources, paramTheme, Xml.asAttributeSet(paramXmlPullParser), paramXmlPullParser); 
          Keyframe keyframe = m(paramContext, paramResources, paramTheme, Xml.asAttributeSet(paramXmlPullParser), paramInt, paramXmlPullParser);
          ArrayList<Keyframe> arrayList1 = arrayList;
          if (keyframe != null) {
            arrayList1 = arrayList;
            if (arrayList == null)
              arrayList1 = new ArrayList(); 
            arrayList1.add(keyframe);
          } 
          paramXmlPullParser.next();
          arrayList = arrayList1;
          i = paramInt;
        } 
        continue;
      } 
      break;
    } 
    paramContext = context;
    if (arrayList != null) {
      int j = arrayList.size();
      paramContext = context;
      if (j > 0) {
        int k = 0;
        Keyframe keyframe1 = arrayList.get(0);
        Keyframe keyframe2 = arrayList.get(j - 1);
        float f = keyframe2.getFraction();
        paramInt = j;
        if (f < 1.0F)
          if (f < 0.0F) {
            keyframe2.setFraction(1.0F);
            paramInt = j;
          } else {
            arrayList.add(arrayList.size(), c(keyframe2, 1.0F));
            paramInt = j + 1;
          }  
        f = keyframe1.getFraction();
        j = paramInt;
        if (f != 0.0F)
          if (f < 0.0F) {
            keyframe1.setFraction(0.0F);
            j = paramInt;
          } else {
            arrayList.add(0, c(keyframe1, 0.0F));
            j = paramInt + 1;
          }  
        Keyframe[] arrayOfKeyframe = new Keyframe[j];
        arrayList.toArray(arrayOfKeyframe);
        for (paramInt = k; paramInt < j; paramInt++) {
          keyframe2 = arrayOfKeyframe[paramInt];
          if (keyframe2.getFraction() < 0.0F)
            if (paramInt == 0) {
              keyframe2.setFraction(0.0F);
            } else {
              int m = j - 1;
              if (paramInt == m) {
                keyframe2.setFraction(1.0F);
              } else {
                k = paramInt + 1;
                int n = paramInt;
                while (k < m && arrayOfKeyframe[k].getFraction() < 0.0F) {
                  n = k;
                  k++;
                } 
                d(arrayOfKeyframe, arrayOfKeyframe[n + 1].getFraction() - arrayOfKeyframe[paramInt - 1].getFraction(), paramInt, n);
              } 
            }  
        } 
        PropertyValuesHolder propertyValuesHolder1 = PropertyValuesHolder.ofKeyframe(paramString, arrayOfKeyframe);
        propertyValuesHolder = propertyValuesHolder1;
        if (i == 3) {
          propertyValuesHolder1.setEvaluator(e.a());
          propertyValuesHolder = propertyValuesHolder1;
        } 
      } 
    } 
    return propertyValuesHolder;
  }
  
  private static PropertyValuesHolder[] p(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet) throws XmlPullParserException, IOException {
    PropertyValuesHolder[] arrayOfPropertyValuesHolder;
    int i;
    ArrayList<PropertyValuesHolder> arrayList;
    Context context = null;
    PropertyValuesHolder propertyValuesHolder = null;
    while (true) {
      int j = paramXmlPullParser.getEventType();
      i = 0;
      if (j != 3 && j != 1) {
        if (j != 2) {
          paramXmlPullParser.next();
          continue;
        } 
        if (paramXmlPullParser.getName().equals("propertyValuesHolder")) {
          ArrayList<PropertyValuesHolder> arrayList1;
          TypedArray typedArray = i.s(paramResources, paramTheme, paramAttributeSet, a.i);
          String str = i.m(typedArray, paramXmlPullParser, "propertyName", 3);
          i = i.k(typedArray, paramXmlPullParser, "valueType", 2, 4);
          PropertyValuesHolder propertyValuesHolder1 = o(paramContext, paramResources, paramTheme, paramXmlPullParser, str, i);
          PropertyValuesHolder propertyValuesHolder2 = propertyValuesHolder1;
          if (propertyValuesHolder1 == null)
            propertyValuesHolder2 = e(typedArray, i, 0, 1, str); 
          propertyValuesHolder1 = propertyValuesHolder;
          if (propertyValuesHolder2 != null) {
            propertyValuesHolder1 = propertyValuesHolder;
            if (propertyValuesHolder == null)
              arrayList1 = new ArrayList(); 
            arrayList1.add(propertyValuesHolder2);
          } 
          typedArray.recycle();
          arrayList = arrayList1;
        } 
        paramXmlPullParser.next();
        continue;
      } 
      break;
    } 
    paramContext = context;
    if (arrayList != null) {
      int j = arrayList.size();
      PropertyValuesHolder[] arrayOfPropertyValuesHolder1 = new PropertyValuesHolder[j];
      while (true) {
        arrayOfPropertyValuesHolder = arrayOfPropertyValuesHolder1;
        if (i < j) {
          arrayOfPropertyValuesHolder1[i] = arrayList.get(i);
          i++;
          continue;
        } 
        break;
      } 
    } 
    return arrayOfPropertyValuesHolder;
  }
  
  private static void q(ValueAnimator paramValueAnimator, TypedArray paramTypedArray1, TypedArray paramTypedArray2, float paramFloat, XmlPullParser paramXmlPullParser) {
    long l1 = i.k(paramTypedArray1, paramXmlPullParser, "duration", 1, 300);
    long l2 = i.k(paramTypedArray1, paramXmlPullParser, "startOffset", 2, 0);
    int i = i.k(paramTypedArray1, paramXmlPullParser, "valueType", 7, 4);
    int j = i;
    if (i.r(paramXmlPullParser, "valueFrom")) {
      j = i;
      if (i.r(paramXmlPullParser, "valueTo")) {
        int k = i;
        if (i == 4)
          k = f(paramTypedArray1, 5, 6); 
        PropertyValuesHolder propertyValuesHolder = e(paramTypedArray1, k, 5, 6, "");
        j = k;
        if (propertyValuesHolder != null) {
          paramValueAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder });
          j = k;
        } 
      } 
    } 
    paramValueAnimator.setDuration(l1);
    paramValueAnimator.setStartDelay(l2);
    paramValueAnimator.setRepeatCount(i.k(paramTypedArray1, paramXmlPullParser, "repeatCount", 3, 0));
    paramValueAnimator.setRepeatMode(i.k(paramTypedArray1, paramXmlPullParser, "repeatMode", 4, 1));
    if (paramTypedArray2 != null)
      r(paramValueAnimator, paramTypedArray2, j, paramFloat, paramXmlPullParser); 
  }
  
  private static void r(ValueAnimator paramValueAnimator, TypedArray paramTypedArray, int paramInt, float paramFloat, XmlPullParser paramXmlPullParser) {
    // Byte code:
    //   0: aload_0
    //   1: checkcast android/animation/ObjectAnimator
    //   4: astore_0
    //   5: aload_1
    //   6: aload #4
    //   8: ldc_w 'pathData'
    //   11: iconst_1
    //   12: invokestatic m : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   15: astore #5
    //   17: aload #5
    //   19: ifnull -> 120
    //   22: aload_1
    //   23: aload #4
    //   25: ldc_w 'propertyXName'
    //   28: iconst_2
    //   29: invokestatic m : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   32: astore #6
    //   34: aload_1
    //   35: aload #4
    //   37: ldc_w 'propertyYName'
    //   40: iconst_3
    //   41: invokestatic m : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   44: astore #4
    //   46: iload_2
    //   47: iconst_2
    //   48: if_icmpeq -> 51
    //   51: aload #6
    //   53: ifnonnull -> 101
    //   56: aload #4
    //   58: ifnull -> 64
    //   61: goto -> 101
    //   64: new java/lang/StringBuilder
    //   67: dup
    //   68: invokespecial <init> : ()V
    //   71: astore_0
    //   72: aload_0
    //   73: aload_1
    //   74: invokevirtual getPositionDescription : ()Ljava/lang/String;
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: aload_0
    //   82: ldc_w ' propertyXName or propertyYName is needed for PathData'
    //   85: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: new android/view/InflateException
    //   92: dup
    //   93: aload_0
    //   94: invokevirtual toString : ()Ljava/lang/String;
    //   97: invokespecial <init> : (Ljava/lang/String;)V
    //   100: athrow
    //   101: aload #5
    //   103: invokestatic e : (Ljava/lang/String;)Landroid/graphics/Path;
    //   106: aload_0
    //   107: fload_3
    //   108: ldc_w 0.5
    //   111: fmul
    //   112: aload #6
    //   114: aload #4
    //   116: invokestatic s : (Landroid/graphics/Path;Landroid/animation/ObjectAnimator;FLjava/lang/String;Ljava/lang/String;)V
    //   119: return
    //   120: aload_0
    //   121: aload_1
    //   122: aload #4
    //   124: ldc_w 'propertyName'
    //   127: iconst_0
    //   128: invokestatic m : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   131: invokevirtual setPropertyName : (Ljava/lang/String;)V
    //   134: return
  }
  
  private static void s(Path paramPath, ObjectAnimator paramObjectAnimator, float paramFloat, String paramString1, String paramString2) {
    PathMeasure pathMeasure = new PathMeasure(paramPath, false);
    ArrayList<Float> arrayList = new ArrayList();
    float f2 = 0.0F;
    arrayList.add(Float.valueOf(0.0F));
    float f1 = 0.0F;
    while (true) {
      float f = f1 + pathMeasure.getLength();
      arrayList.add(Float.valueOf(f));
      f1 = f;
      if (!pathMeasure.nextContour()) {
        PathMeasure pathMeasure1 = new PathMeasure(paramPath, false);
        int k = Math.min(100, (int)(f / paramFloat) + 1);
        float[] arrayOfFloat2 = new float[k];
        float[] arrayOfFloat1 = new float[k];
        float[] arrayOfFloat3 = new float[2];
        f1 = f / (k - 1);
        int i = 0;
        int j = i;
        paramFloat = f2;
        while (true) {
          PropertyValuesHolder propertyValuesHolder;
          pathMeasure = null;
          if (i < k) {
            pathMeasure1.getPosTan(paramFloat - ((Float)arrayList.get(j)).floatValue(), arrayOfFloat3, null);
            arrayOfFloat2[i] = arrayOfFloat3[0];
            arrayOfFloat1[i] = arrayOfFloat3[1];
            paramFloat += f1;
            int n = j + 1;
            int m = j;
            if (n < arrayList.size()) {
              m = j;
              if (paramFloat > ((Float)arrayList.get(n)).floatValue()) {
                pathMeasure1.nextContour();
                m = n;
              } 
            } 
            i++;
            j = m;
            continue;
          } 
          if (paramString1 != null) {
            PropertyValuesHolder propertyValuesHolder1 = PropertyValuesHolder.ofFloat(paramString1, arrayOfFloat2);
          } else {
            pathMeasure1 = null;
          } 
          PathMeasure pathMeasure2 = pathMeasure;
          if (paramString2 != null)
            propertyValuesHolder = PropertyValuesHolder.ofFloat(paramString2, arrayOfFloat1); 
          if (pathMeasure1 == null) {
            paramObjectAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder });
            return;
          } 
          if (propertyValuesHolder == null) {
            paramObjectAnimator.setValues(new PropertyValuesHolder[] { (PropertyValuesHolder)pathMeasure1 });
            return;
          } 
          paramObjectAnimator.setValues(new PropertyValuesHolder[] { (PropertyValuesHolder)pathMeasure1, propertyValuesHolder });
          return;
        } 
        break;
      } 
    } 
  }
  
  private static class a implements TypeEvaluator<c0.d.b[]> {
    private c0.d.b[] a;
    
    public c0.d.b[] a(float param1Float, c0.d.b[] param1ArrayOfb1, c0.d.b[] param1ArrayOfb2) {
      if (c0.d.b(param1ArrayOfb1, param1ArrayOfb2)) {
        if (!c0.d.b(this.a, param1ArrayOfb1))
          this.a = c0.d.f(param1ArrayOfb1); 
        int i;
        for (i = 0; i < param1ArrayOfb1.length; i++)
          this.a[i].d(param1ArrayOfb1[i], param1ArrayOfb2[i], param1Float); 
        return this.a;
      } 
      throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\vectordrawable\graphics\drawable\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */