package androidx.vectordrawable.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import b0.i;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class b extends f implements Animatable {
  private b g;
  
  private Context h;
  
  private ArgbEvaluator i = null;
  
  private Animator.AnimatorListener j = null;
  
  ArrayList<Object> k = null;
  
  final Drawable.Callback l;
  
  b() {
    this(null, null, null);
  }
  
  private b(Context paramContext) {
    this(paramContext, null, null);
  }
  
  private b(Context paramContext, b paramb, Resources paramResources) {
    a a = new a(this);
    this.l = a;
    this.h = paramContext;
    if (paramb != null) {
      this.g = paramb;
      return;
    } 
    this.g = new b(paramContext, paramb, a, paramResources);
  }
  
  public static b a(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    b b1 = new b(paramContext);
    b1.inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    return b1;
  }
  
  private void b(String paramString, Animator paramAnimator) {
    paramAnimator.setTarget(this.g.b.d(paramString));
    b b1 = this.g;
    if (b1.d == null) {
      b1.d = new ArrayList<Animator>();
      this.g.e = new s.a();
    } 
    this.g.d.add(paramAnimator);
    this.g.e.put(paramAnimator, paramString);
  }
  
  public void applyTheme(Resources.Theme paramTheme) {
    Drawable drawable = this.f;
    if (drawable != null)
      d0.a.a(drawable, paramTheme); 
  }
  
  public boolean canApplyTheme() {
    Drawable drawable = this.f;
    return (drawable != null) ? d0.a.b(drawable) : false;
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.draw(paramCanvas);
      return;
    } 
    this.g.b.draw(paramCanvas);
    if (this.g.c.isStarted())
      invalidateSelf(); 
  }
  
  public int getAlpha() {
    Drawable drawable = this.f;
    return (drawable != null) ? d0.a.d(drawable) : this.g.b.getAlpha();
  }
  
  public int getChangingConfigurations() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.getChangingConfigurations() : (super.getChangingConfigurations() | this.g.a);
  }
  
  public ColorFilter getColorFilter() {
    Drawable drawable = this.f;
    return (drawable != null) ? d0.a.e(drawable) : this.g.b.getColorFilter();
  }
  
  public Drawable.ConstantState getConstantState() {
    return (this.f != null && Build.VERSION.SDK_INT >= 24) ? new c(this.f.getConstantState()) : null;
  }
  
  public int getIntrinsicHeight() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.getIntrinsicHeight() : this.g.b.getIntrinsicHeight();
  }
  
  public int getIntrinsicWidth() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.getIntrinsicWidth() : this.g.b.getIntrinsicWidth();
  }
  
  public int getOpacity() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.getOpacity() : this.g.b.getOpacity();
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet) throws XmlPullParserException, IOException {
    inflate(paramResources, paramXmlPullParser, paramAttributeSet, null);
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) throws XmlPullParserException, IOException {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.g(drawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return;
    } 
    int i = paramXmlPullParser.getEventType();
    int j = paramXmlPullParser.getDepth();
    while (i != 1 && (paramXmlPullParser.getDepth() >= j + 1 || i != 3)) {
      if (i == 2) {
        TypedArray typedArray;
        String str = paramXmlPullParser.getName();
        if ("animated-vector".equals(str)) {
          typedArray = i.s(paramResources, paramTheme, paramAttributeSet, a.e);
          i = typedArray.getResourceId(0, 0);
          if (i != 0) {
            g g1 = g.b(paramResources, i, paramTheme);
            g1.h(false);
            g1.setCallback(this.l);
            g g2 = this.g.b;
            if (g2 != null)
              g2.setCallback(null); 
            this.g.b = g1;
          } 
          typedArray.recycle();
        } else if ("target".equals(typedArray)) {
          typedArray = paramResources.obtainAttributes(paramAttributeSet, a.f);
          String str1 = typedArray.getString(0);
          i = typedArray.getResourceId(1, 0);
          if (i != 0) {
            Context context = this.h;
            if (context != null) {
              b(str1, d.i(context, i));
            } else {
              typedArray.recycle();
              throw new IllegalStateException("Context can't be null when inflating animators");
            } 
          } 
          typedArray.recycle();
        } 
      } 
      i = paramXmlPullParser.next();
    } 
    this.g.a();
  }
  
  public boolean isAutoMirrored() {
    Drawable drawable = this.f;
    return (drawable != null) ? d0.a.h(drawable) : this.g.b.isAutoMirrored();
  }
  
  public boolean isRunning() {
    Drawable drawable = this.f;
    return (drawable != null) ? ((AnimatedVectorDrawable)drawable).isRunning() : this.g.c.isRunning();
  }
  
  public boolean isStateful() {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.isStateful() : this.g.b.isStateful();
  }
  
  public Drawable mutate() {
    Drawable drawable = this.f;
    if (drawable != null)
      drawable.mutate(); 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.setBounds(paramRect);
      return;
    } 
    this.g.b.setBounds(paramRect);
  }
  
  protected boolean onLevelChange(int paramInt) {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.setLevel(paramInt) : this.g.b.setLevel(paramInt);
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    Drawable drawable = this.f;
    return (drawable != null) ? drawable.setState(paramArrayOfint) : this.g.b.setState(paramArrayOfint);
  }
  
  public void setAlpha(int paramInt) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.setAlpha(paramInt);
      return;
    } 
    this.g.b.setAlpha(paramInt);
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.j(drawable, paramBoolean);
      return;
    } 
    this.g.b.setAutoMirrored(paramBoolean);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    Drawable drawable = this.f;
    if (drawable != null) {
      drawable.setColorFilter(paramColorFilter);
      return;
    } 
    this.g.b.setColorFilter(paramColorFilter);
  }
  
  public void setTint(int paramInt) {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.n(drawable, paramInt);
      return;
    } 
    this.g.b.setTint(paramInt);
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.o(drawable, paramColorStateList);
      return;
    } 
    this.g.b.setTintList(paramColorStateList);
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    Drawable drawable = this.f;
    if (drawable != null) {
      d0.a.p(drawable, paramMode);
      return;
    } 
    this.g.b.setTintMode(paramMode);
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    Drawable drawable = this.f;
    if (drawable != null)
      return drawable.setVisible(paramBoolean1, paramBoolean2); 
    this.g.b.setVisible(paramBoolean1, paramBoolean2);
    return super.setVisible(paramBoolean1, paramBoolean2);
  }
  
  public void start() {
    Drawable drawable = this.f;
    if (drawable != null) {
      ((AnimatedVectorDrawable)drawable).start();
      return;
    } 
    if (this.g.c.isStarted())
      return; 
    this.g.c.start();
    invalidateSelf();
  }
  
  public void stop() {
    Drawable drawable = this.f;
    if (drawable != null) {
      ((AnimatedVectorDrawable)drawable).stop();
      return;
    } 
    this.g.c.end();
  }
  
  class a implements Drawable.Callback {
    a(b this$0) {}
    
    public void invalidateDrawable(Drawable param1Drawable) {
      this.f.invalidateSelf();
    }
    
    public void scheduleDrawable(Drawable param1Drawable, Runnable param1Runnable, long param1Long) {
      this.f.scheduleSelf(param1Runnable, param1Long);
    }
    
    public void unscheduleDrawable(Drawable param1Drawable, Runnable param1Runnable) {
      this.f.unscheduleSelf(param1Runnable);
    }
  }
  
  private static class b extends Drawable.ConstantState {
    int a;
    
    g b;
    
    AnimatorSet c;
    
    ArrayList<Animator> d;
    
    s.a<Animator, String> e;
    
    public b(Context param1Context, b param1b, Drawable.Callback param1Callback, Resources param1Resources) {
      if (param1b != null) {
        this.a = param1b.a;
        g g1 = param1b.b;
        int i = 0;
        if (g1 != null) {
          Drawable.ConstantState constantState = g1.getConstantState();
          if (param1Resources != null) {
            this.b = (g)constantState.newDrawable(param1Resources);
          } else {
            this.b = (g)constantState.newDrawable();
          } 
          g g2 = (g)this.b.mutate();
          this.b = g2;
          g2.setCallback(param1Callback);
          this.b.setBounds(param1b.b.getBounds());
          this.b.h(false);
        } 
        ArrayList<Animator> arrayList = param1b.d;
        if (arrayList != null) {
          int j = arrayList.size();
          this.d = new ArrayList<Animator>(j);
          this.e = new s.a(j);
          while (i < j) {
            Animator animator2 = param1b.d.get(i);
            Animator animator1 = animator2.clone();
            String str = (String)param1b.e.get(animator2);
            animator1.setTarget(this.b.d(str));
            this.d.add(animator1);
            this.e.put(animator1, str);
            i++;
          } 
          a();
        } 
      } 
    }
    
    public void a() {
      if (this.c == null)
        this.c = new AnimatorSet(); 
      this.c.playTogether(this.d);
    }
    
    public int getChangingConfigurations() {
      return this.a;
    }
    
    public Drawable newDrawable() {
      throw new IllegalStateException("No constant state support for SDK < 24.");
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      throw new IllegalStateException("No constant state support for SDK < 24.");
    }
  }
  
  private static class c extends Drawable.ConstantState {
    private final Drawable.ConstantState a;
    
    public c(Drawable.ConstantState param1ConstantState) {
      this.a = param1ConstantState;
    }
    
    public boolean canApplyTheme() {
      return this.a.canApplyTheme();
    }
    
    public int getChangingConfigurations() {
      return this.a.getChangingConfigurations();
    }
    
    public Drawable newDrawable() {
      b b = new b();
      Drawable drawable = this.a.newDrawable();
      b.f = drawable;
      drawable.setCallback(b.l);
      return b;
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      b b = new b();
      Drawable drawable = this.a.newDrawable(param1Resources);
      b.f = drawable;
      drawable.setCallback(b.l);
      return b;
    }
    
    public Drawable newDrawable(Resources param1Resources, Resources.Theme param1Theme) {
      b b = new b();
      Drawable drawable = this.a.newDrawable(param1Resources, param1Theme);
      b.f = drawable;
      drawable.setCallback(b.l);
      return b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\vectordrawable\graphics\drawable\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */