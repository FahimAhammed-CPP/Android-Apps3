package androidx.work;

import android.os.Build;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import n1.g;
import n1.i;
import n1.q;
import n1.v;

public final class a {
  final Executor a;
  
  final Executor b;
  
  final v c;
  
  final i d;
  
  final q e;
  
  final g f;
  
  final String g;
  
  final int h;
  
  final int i;
  
  final int j;
  
  final int k;
  
  private final boolean l;
  
  a(b paramb) {
    Executor executor = paramb.a;
    if (executor == null) {
      this.a = a(false);
    } else {
      this.a = executor;
    } 
    executor = paramb.d;
    if (executor == null) {
      this.l = true;
      this.b = a(true);
    } else {
      this.l = false;
      this.b = executor;
    } 
    v v1 = paramb.b;
    if (v1 == null) {
      this.c = v.c();
    } else {
      this.c = v1;
    } 
    i i1 = paramb.c;
    if (i1 == null) {
      this.d = i.c();
    } else {
      this.d = i1;
    } 
    q q1 = paramb.e;
    if (q1 == null) {
      this.e = (q)new o1.a();
    } else {
      this.e = q1;
    } 
    this.h = paramb.h;
    this.i = paramb.i;
    this.j = paramb.j;
    this.k = paramb.k;
    this.f = paramb.f;
    this.g = paramb.g;
  }
  
  private Executor a(boolean paramBoolean) {
    return Executors.newFixedThreadPool(Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4)), b(paramBoolean));
  }
  
  private ThreadFactory b(boolean paramBoolean) {
    return new a(this, paramBoolean);
  }
  
  public String c() {
    return this.g;
  }
  
  public g d() {
    return this.f;
  }
  
  public Executor e() {
    return this.a;
  }
  
  public i f() {
    return this.d;
  }
  
  public int g() {
    return this.j;
  }
  
  public int h() {
    return (Build.VERSION.SDK_INT == 23) ? (this.k / 2) : this.k;
  }
  
  public int i() {
    return this.i;
  }
  
  public int j() {
    return this.h;
  }
  
  public q k() {
    return this.e;
  }
  
  public Executor l() {
    return this.b;
  }
  
  public v m() {
    return this.c;
  }
  
  class a implements ThreadFactory {
    private final AtomicInteger a = new AtomicInteger(0);
    
    a(a this$0, boolean param1Boolean) {}
    
    public Thread newThread(Runnable param1Runnable) {
      String str;
      if (this.b) {
        str = "WM.task-";
      } else {
        str = "androidx.work-";
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append(this.a.incrementAndGet());
      return new Thread(param1Runnable, stringBuilder.toString());
    }
  }
  
  public static final class b {
    Executor a;
    
    v b;
    
    i c;
    
    Executor d;
    
    q e;
    
    g f;
    
    String g;
    
    int h = 4;
    
    int i = 0;
    
    int j = Integer.MAX_VALUE;
    
    int k = 20;
    
    public a a() {
      return new a(this);
    }
  }
  
  public static interface c {
    a a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\work\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */