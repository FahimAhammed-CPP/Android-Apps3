package androidx.fragment.app;

import android.animation.Animator;
import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.core.app.o;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.c0;
import androidx.lifecycle.f0;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.j;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import androidx.lifecycle.r;
import androidx.lifecycle.w;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.c;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, q, i0, i, c {
  static final Object f0 = new Object();
  
  Fragment A;
  
  int B;
  
  int C;
  
  String D;
  
  boolean E;
  
  boolean F;
  
  boolean G;
  
  boolean H;
  
  boolean I;
  
  boolean J = true;
  
  private boolean K;
  
  ViewGroup L;
  
  View M;
  
  boolean N;
  
  boolean O = true;
  
  e P;
  
  Runnable Q = new a(this);
  
  boolean R;
  
  boolean S;
  
  float T;
  
  LayoutInflater U;
  
  boolean V;
  
  j.c W = j.c.j;
  
  r X;
  
  z Y;
  
  w<q> Z = new w();
  
  f0.b a0;
  
  androidx.savedstate.b b0;
  
  private int c0;
  
  private final AtomicInteger d0 = new AtomicInteger();
  
  private final ArrayList<g> e0 = new ArrayList<g>();
  
  int f = -1;
  
  Bundle g;
  
  SparseArray<Parcelable> h;
  
  Bundle i;
  
  Boolean j;
  
  String k = UUID.randomUUID().toString();
  
  Bundle l;
  
  Fragment m;
  
  String n = null;
  
  int o;
  
  private Boolean p = null;
  
  boolean q;
  
  boolean r;
  
  boolean s;
  
  boolean t;
  
  boolean u;
  
  boolean v;
  
  int w;
  
  m x;
  
  j<?> y;
  
  m z = new n();
  
  public Fragment() {
    V();
  }
  
  public Fragment(int paramInt) {
    this();
    this.c0 = paramInt;
  }
  
  private int C() {
    j.c c1 = this.W;
    return (c1 == j.c.g || this.A == null) ? c1.ordinal() : Math.min(c1.ordinal(), this.A.C());
  }
  
  private void V() {
    this.X = new r(this);
    this.b0 = androidx.savedstate.b.a(this);
    this.a0 = null;
  }
  
  @Deprecated
  public static Fragment X(Context paramContext, String paramString, Bundle paramBundle) {
    try {
      Fragment fragment = i.d(paramContext.getClassLoader(), paramString).getConstructor(new Class[0]).newInstance(new Object[0]);
      if (paramBundle != null) {
        paramBundle.setClassLoader(fragment.getClass().getClassLoader());
        fragment.v1(paramBundle);
      } 
      return fragment;
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an empty constructor that is public");
      throw new f(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an empty constructor that is public");
      throw new f(stringBuilder.toString(), illegalAccessException);
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": could not find Fragment constructor");
      throw new f(stringBuilder.toString(), noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": calling Fragment constructor caused an exception");
      throw new f(stringBuilder.toString(), invocationTargetException);
    } 
  }
  
  private e g() {
    if (this.P == null)
      this.P = new e(); 
    return this.P;
  }
  
  private void q1() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESTORE_VIEW_STATE: ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    if (this.M != null)
      r1(this.g); 
    this.g = null;
  }
  
  public final int A() {
    return this.B;
  }
  
  public boolean A0(MenuItem paramMenuItem) {
    return false;
  }
  
  void A1(boolean paramBoolean) {
    if (this.P == null)
      return; 
    (g()).c = paramBoolean;
  }
  
  @Deprecated
  public LayoutInflater B(Bundle paramBundle) {
    j<?> j1 = this.y;
    if (j1 != null) {
      LayoutInflater layoutInflater = j1.n();
      androidx.core.view.g.a(layoutInflater, this.z.v0());
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public void B0(Menu paramMenu) {}
  
  void B1(float paramFloat) {
    (g()).s = paramFloat;
  }
  
  public void C0() {
    this.K = true;
  }
  
  void C1(ArrayList<String> paramArrayList1, ArrayList<String> paramArrayList2) {
    g();
    e e1 = this.P;
    e1.i = paramArrayList1;
    e1.j = paramArrayList2;
  }
  
  int D() {
    e e1 = this.P;
    return (e1 == null) ? 0 : e1.h;
  }
  
  public void D0(boolean paramBoolean) {}
  
  public void D1() {
    if (this.P != null) {
      if (!(g()).u)
        return; 
      if (this.y == null) {
        (g()).u = false;
        return;
      } 
      if (Looper.myLooper() != this.y.l().getLooper()) {
        this.y.l().postAtFrontOfQueue(new b(this));
        return;
      } 
      d(true);
    } 
  }
  
  public final Fragment E() {
    return this.A;
  }
  
  public void E0(Menu paramMenu) {}
  
  public final m F() {
    m m1 = this.x;
    if (m1 != null)
      return m1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not associated with a fragment manager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void F0(boolean paramBoolean) {}
  
  boolean G() {
    e e1 = this.P;
    return (e1 == null) ? false : e1.c;
  }
  
  @Deprecated
  public void G0(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {}
  
  int H() {
    e e1 = this.P;
    return (e1 == null) ? 0 : e1.f;
  }
  
  public void H0() {
    this.K = true;
  }
  
  int I() {
    e e1 = this.P;
    return (e1 == null) ? 0 : e1.g;
  }
  
  public void I0(Bundle paramBundle) {}
  
  float J() {
    e e1 = this.P;
    return (e1 == null) ? 1.0F : e1.s;
  }
  
  public void J0() {
    this.K = true;
  }
  
  public Object K() {
    e e1 = this.P;
    if (e1 == null)
      return null; 
    Object object2 = e1.n;
    Object object1 = object2;
    if (object2 == f0)
      object1 = w(); 
    return object1;
  }
  
  public void K0() {
    this.K = true;
  }
  
  public final Resources L() {
    return m1().getResources();
  }
  
  public void L0(View paramView, Bundle paramBundle) {}
  
  public Object M() {
    e e1 = this.P;
    if (e1 == null)
      return null; 
    Object object2 = e1.l;
    Object object1 = object2;
    if (object2 == f0)
      object1 = t(); 
    return object1;
  }
  
  public void M0(Bundle paramBundle) {
    this.K = true;
  }
  
  public Object N() {
    e e1 = this.P;
    return (e1 == null) ? null : e1.o;
  }
  
  void N0(Bundle paramBundle) {
    this.z.R0();
    this.f = 3;
    this.K = false;
    g0(paramBundle);
    if (this.K) {
      q1();
      this.z.z();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onActivityCreated()");
    throw new d0(stringBuilder.toString());
  }
  
  public Object O() {
    e e1 = this.P;
    if (e1 == null)
      return null; 
    Object object2 = e1.p;
    Object object1 = object2;
    if (object2 == f0)
      object1 = N(); 
    return object1;
  }
  
  void O0() {
    Iterator<g> iterator = this.e0.iterator();
    while (iterator.hasNext())
      ((g)iterator.next()).a(); 
    this.e0.clear();
    this.z.k(this.y, e(), this);
    this.f = 0;
    this.K = false;
    j0(this.y.j());
    if (this.K) {
      this.x.J(this);
      this.z.A();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onAttach()");
    throw new d0(stringBuilder.toString());
  }
  
  ArrayList<String> P() {
    e e1 = this.P;
    if (e1 != null) {
      ArrayList<String> arrayList = e1.i;
      if (arrayList != null)
        return arrayList; 
    } 
    return new ArrayList<String>();
  }
  
  void P0(Configuration paramConfiguration) {
    onConfigurationChanged(paramConfiguration);
    this.z.B(paramConfiguration);
  }
  
  ArrayList<String> Q() {
    e e1 = this.P;
    if (e1 != null) {
      ArrayList<String> arrayList = e1.j;
      if (arrayList != null)
        return arrayList; 
    } 
    return new ArrayList<String>();
  }
  
  boolean Q0(MenuItem paramMenuItem) {
    return !this.E ? (l0(paramMenuItem) ? true : this.z.C(paramMenuItem)) : false;
  }
  
  public final String R(int paramInt) {
    return L().getString(paramInt);
  }
  
  void R0(Bundle paramBundle) {
    this.z.R0();
    this.f = 1;
    this.K = false;
    this.X.a((p)new o(this) {
          public void d(q param1q, j.b param1b) {
            if (param1b == j.b.ON_STOP) {
              View view = this.f.M;
              if (view != null)
                view.cancelPendingInputEvents(); 
            } 
          }
        });
    this.b0.c(paramBundle);
    m0(paramBundle);
    this.V = true;
    if (this.K) {
      this.X.h(j.b.ON_CREATE);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onCreate()");
    throw new d0(stringBuilder.toString());
  }
  
  @Deprecated
  public final Fragment S() {
    Fragment fragment = this.m;
    if (fragment != null)
      return fragment; 
    m m1 = this.x;
    if (m1 != null) {
      String str = this.n;
      if (str != null)
        return m1.g0(str); 
    } 
    return null;
  }
  
  boolean S0(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool3 = this.E;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.I) {
        bool = bool1;
        if (this.J) {
          bool = true;
          p0(paramMenu, paramMenuInflater);
        } 
      } 
      bool2 = bool | this.z.E(paramMenu, paramMenuInflater);
    } 
    return bool2;
  }
  
  public View T() {
    return this.M;
  }
  
  void T0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    this.z.R0();
    this.v = true;
    this.Y = new z(this, k());
    View view = q0(paramLayoutInflater, paramViewGroup, paramBundle);
    this.M = view;
    if (view != null) {
      this.Y.e();
      j0.a(this.M, (q)this.Y);
      k0.a(this.M, this.Y);
      androidx.savedstate.d.a(this.M, this.Y);
      this.Z.m(this.Y);
      return;
    } 
    if (!this.Y.f()) {
      this.Y = null;
      return;
    } 
    throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
  }
  
  public LiveData<q> U() {
    return (LiveData<q>)this.Z;
  }
  
  void U0() {
    this.z.F();
    this.X.h(j.b.ON_DESTROY);
    this.f = 0;
    this.K = false;
    this.V = false;
    r0();
    if (this.K)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroy()");
    throw new d0(stringBuilder.toString());
  }
  
  void V0() {
    this.z.G();
    if (this.M != null && this.Y.a().b().b(j.c.h))
      this.Y.d(j.b.ON_DESTROY); 
    this.f = 1;
    this.K = false;
    t0();
    if (this.K) {
      androidx.loader.app.a.b(this).c();
      this.v = false;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroyView()");
    throw new d0(stringBuilder.toString());
  }
  
  void W() {
    V();
    this.k = UUID.randomUUID().toString();
    this.q = false;
    this.r = false;
    this.s = false;
    this.t = false;
    this.u = false;
    this.w = 0;
    this.x = null;
    this.z = new n();
    this.y = null;
    this.B = 0;
    this.C = 0;
    this.D = null;
    this.E = false;
    this.F = false;
  }
  
  void W0() {
    this.f = -1;
    this.K = false;
    u0();
    this.U = null;
    if (this.K) {
      if (!this.z.F0()) {
        this.z.F();
        this.z = new n();
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDetach()");
    throw new d0(stringBuilder.toString());
  }
  
  LayoutInflater X0(Bundle paramBundle) {
    LayoutInflater layoutInflater = v0(paramBundle);
    this.U = layoutInflater;
    return layoutInflater;
  }
  
  boolean Y() {
    e e1 = this.P;
    return (e1 == null) ? false : e1.w;
  }
  
  void Y0() {
    onLowMemory();
    this.z.H();
  }
  
  final boolean Z() {
    return (this.w > 0);
  }
  
  void Z0(boolean paramBoolean) {
    z0(paramBoolean);
    this.z.I(paramBoolean);
  }
  
  public j a() {
    return (j)this.X;
  }
  
  public final boolean a0() {
    if (this.J) {
      m m1 = this.x;
      if (m1 == null || m1.I0(this.A))
        return true; 
    } 
    return false;
  }
  
  boolean a1(MenuItem paramMenuItem) {
    return !this.E ? ((this.I && this.J && A0(paramMenuItem)) ? true : this.z.K(paramMenuItem)) : false;
  }
  
  boolean b0() {
    e e1 = this.P;
    return (e1 == null) ? false : e1.u;
  }
  
  void b1(Menu paramMenu) {
    if (!this.E) {
      if (this.I && this.J)
        B0(paramMenu); 
      this.z.L(paramMenu);
    } 
  }
  
  public final SavedStateRegistry c() {
    return this.b0.b();
  }
  
  public final boolean c0() {
    return this.r;
  }
  
  void c1() {
    this.z.N();
    if (this.M != null)
      this.Y.d(j.b.ON_PAUSE); 
    this.X.h(j.b.ON_PAUSE);
    this.f = 6;
    this.K = false;
    C0();
    if (this.K)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onPause()");
    throw new d0(stringBuilder.toString());
  }
  
  void d(boolean paramBoolean) {
    e e1 = this.P;
    h h = null;
    if (e1 != null) {
      e1.u = false;
      h = e1.v;
      e1.v = null;
    } 
    if (h != null) {
      h.a();
      return;
    } 
    if (m.P && this.M != null) {
      ViewGroup viewGroup = this.L;
      if (viewGroup != null) {
        m m1 = this.x;
        if (m1 != null) {
          b0 b0 = b0.n(viewGroup, m1);
          b0.p();
          if (paramBoolean) {
            this.y.l().post(new c(this, b0));
            return;
          } 
          b0.g();
        } 
      } 
    } 
  }
  
  final boolean d0() {
    Fragment fragment = E();
    return (fragment != null && (fragment.c0() || fragment.d0()));
  }
  
  void d1(boolean paramBoolean) {
    D0(paramBoolean);
    this.z.O(paramBoolean);
  }
  
  g e() {
    return new d(this);
  }
  
  public final boolean e0() {
    m m1 = this.x;
    return (m1 == null) ? false : m1.L0();
  }
  
  boolean e1(Menu paramMenu) {
    boolean bool3 = this.E;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.I) {
        bool = bool1;
        if (this.J) {
          bool = true;
          E0(paramMenu);
        } 
      } 
      bool2 = bool | this.z.P(paramMenu);
    } 
    return bool2;
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  public void f(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.B));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.C));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.D);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.f);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.k);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.w);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.q);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.r);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.s);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.t);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.E);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.F);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.J);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.I);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.G);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.O);
    if (this.x != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.x);
    } 
    if (this.y != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.y);
    } 
    if (this.A != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.A);
    } 
    if (this.l != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.l);
    } 
    if (this.g != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.g);
    } 
    if (this.h != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.h);
    } 
    if (this.i != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewRegistryState=");
      paramPrintWriter.println(this.i);
    } 
    Fragment fragment = S();
    if (fragment != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(fragment);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.o);
    } 
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mPopDirection=");
    paramPrintWriter.println(G());
    if (s() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getEnterAnim=");
      paramPrintWriter.println(s());
    } 
    if (v() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getExitAnim=");
      paramPrintWriter.println(v());
    } 
    if (H() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getPopEnterAnim=");
      paramPrintWriter.println(H());
    } 
    if (I() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("getPopExitAnim=");
      paramPrintWriter.println(I());
    } 
    if (this.L != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.L);
    } 
    if (this.M != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.M);
    } 
    if (n() != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(n());
    } 
    if (r() != null)
      androidx.loader.app.a.b(this).a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Child ");
    stringBuilder1.append(this.z);
    stringBuilder1.append(":");
    paramPrintWriter.println(stringBuilder1.toString());
    m m1 = this.z;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("  ");
    m1.X(stringBuilder2.toString(), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  void f0() {
    this.z.R0();
  }
  
  void f1() {
    boolean bool = this.x.J0(this);
    Boolean bool1 = this.p;
    if (bool1 == null || bool1.booleanValue() != bool) {
      this.p = Boolean.valueOf(bool);
      F0(bool);
      this.z.Q();
    } 
  }
  
  @Deprecated
  public void g0(Bundle paramBundle) {
    this.K = true;
  }
  
  void g1() {
    this.z.R0();
    this.z.b0(true);
    this.f = 7;
    this.K = false;
    H0();
    if (this.K) {
      r r1 = this.X;
      j.b b1 = j.b.ON_RESUME;
      r1.h(b1);
      if (this.M != null)
        this.Y.d(b1); 
      this.z.R();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onResume()");
    throw new d0(stringBuilder.toString());
  }
  
  public f0.b h() {
    if (this.x != null) {
      if (this.a0 == null) {
        Application application1;
        Application application2 = null;
        Context context = m1().getApplicationContext();
        while (true) {
          application1 = application2;
          if (context instanceof ContextWrapper) {
            if (context instanceof Application) {
              application1 = (Application)context;
              break;
            } 
            context = ((ContextWrapper)context).getBaseContext();
            continue;
          } 
          break;
        } 
        if (application1 == null && m.G0(3)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Could not find Application instance from Context ");
          stringBuilder.append(m1().getApplicationContext());
          stringBuilder.append(", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory");
          Log.d("FragmentManager", stringBuilder.toString());
        } 
        this.a0 = (f0.b)new c0(application1, this, p());
      } 
      return this.a0;
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  @Deprecated
  public void h0(int paramInt1, int paramInt2, Intent paramIntent) {
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this);
      stringBuilder.append(" received the following in onActivityResult(): requestCode: ");
      stringBuilder.append(paramInt1);
      stringBuilder.append(" resultCode: ");
      stringBuilder.append(paramInt2);
      stringBuilder.append(" data: ");
      stringBuilder.append(paramIntent);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void h1(Bundle paramBundle) {
    I0(paramBundle);
    this.b0.d(paramBundle);
    Parcelable parcelable = this.z.h1();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  Fragment i(String paramString) {
    return paramString.equals(this.k) ? this : this.z.j0(paramString);
  }
  
  @Deprecated
  public void i0(Activity paramActivity) {
    this.K = true;
  }
  
  void i1() {
    this.z.R0();
    this.z.b0(true);
    this.f = 5;
    this.K = false;
    J0();
    if (this.K) {
      r r1 = this.X;
      j.b b1 = j.b.ON_START;
      r1.h(b1);
      if (this.M != null)
        this.Y.d(b1); 
      this.z.S();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStart()");
    throw new d0(stringBuilder.toString());
  }
  
  public final e j() {
    j<?> j1 = this.y;
    return (j1 == null) ? null : (e)j1.h();
  }
  
  public void j0(Context paramContext) {
    Activity activity;
    this.K = true;
    j<?> j1 = this.y;
    if (j1 == null) {
      j1 = null;
    } else {
      activity = j1.h();
    } 
    if (activity != null) {
      this.K = false;
      i0(activity);
    } 
  }
  
  void j1() {
    this.z.U();
    if (this.M != null)
      this.Y.d(j.b.ON_STOP); 
    this.X.h(j.b.ON_STOP);
    this.f = 4;
    this.K = false;
    K0();
    if (this.K)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStop()");
    throw new d0(stringBuilder.toString());
  }
  
  public h0 k() {
    if (this.x != null) {
      if (C() != j.c.g.ordinal())
        return this.x.B0(this); 
      throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  @Deprecated
  public void k0(Fragment paramFragment) {}
  
  void k1() {
    L0(this.M, this.g);
    this.z.V();
  }
  
  public boolean l() {
    e e1 = this.P;
    if (e1 != null) {
      Boolean bool = e1.r;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public boolean l0(MenuItem paramMenuItem) {
    return false;
  }
  
  public final e l1() {
    e e1 = j();
    if (e1 != null)
      return e1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to an activity.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public boolean m() {
    e e1 = this.P;
    if (e1 != null) {
      Boolean bool = e1.q;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public void m0(Bundle paramBundle) {
    this.K = true;
    p1(paramBundle);
    if (!this.z.K0(1))
      this.z.D(); 
  }
  
  public final Context m1() {
    Context context = r();
    if (context != null)
      return context; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to a context.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  View n() {
    e e1 = this.P;
    return (e1 == null) ? null : e1.a;
  }
  
  public Animation n0(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  @Deprecated
  public final m n1() {
    return F();
  }
  
  Animator o() {
    e e1 = this.P;
    return (e1 == null) ? null : e1.b;
  }
  
  public Animator o0(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public final View o1() {
    View view = T();
    if (view != null)
      return view; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not return a View from onCreateView() or this was called before onCreateView().");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.K = true;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    l1().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onLowMemory() {
    this.K = true;
  }
  
  public final Bundle p() {
    return this.l;
  }
  
  public void p0(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  void p1(Bundle paramBundle) {
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        this.z.f1(parcelable);
        this.z.D();
      } 
    } 
  }
  
  public final m q() {
    if (this.y != null)
      return this.z; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" has not been attached yet.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public View q0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    int k = this.c0;
    return (k != 0) ? paramLayoutInflater.inflate(k, paramViewGroup, false) : null;
  }
  
  public Context r() {
    j<?> j1 = this.y;
    return (j1 == null) ? null : j1.j();
  }
  
  public void r0() {
    this.K = true;
  }
  
  final void r1(Bundle paramBundle) {
    SparseArray<Parcelable> sparseArray = this.h;
    if (sparseArray != null) {
      this.M.restoreHierarchyState(sparseArray);
      this.h = null;
    } 
    if (this.M != null) {
      this.Y.g(this.i);
      this.i = null;
    } 
    this.K = false;
    M0(paramBundle);
    if (this.K) {
      if (this.M != null)
        this.Y.d(j.b.ON_CREATE); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onViewStateRestored()");
    throw new d0(stringBuilder.toString());
  }
  
  int s() {
    e e1 = this.P;
    return (e1 == null) ? 0 : e1.d;
  }
  
  public void s0() {}
  
  void s1(View paramView) {
    (g()).a = paramView;
  }
  
  public Object t() {
    e e1 = this.P;
    return (e1 == null) ? null : e1.k;
  }
  
  public void t0() {
    this.K = true;
  }
  
  void t1(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.P == null && paramInt1 == 0 && paramInt2 == 0 && paramInt3 == 0 && paramInt4 == 0)
      return; 
    (g()).d = paramInt1;
    (g()).e = paramInt2;
    (g()).f = paramInt3;
    (g()).g = paramInt4;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append("{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("}");
    stringBuilder.append(" (");
    stringBuilder.append(this.k);
    if (this.B != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.B));
    } 
    if (this.D != null) {
      stringBuilder.append(" tag=");
      stringBuilder.append(this.D);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  o u() {
    e e1 = this.P;
    if (e1 == null)
      return null; 
    Objects.requireNonNull(e1);
    return null;
  }
  
  public void u0() {
    this.K = true;
  }
  
  void u1(Animator paramAnimator) {
    (g()).b = paramAnimator;
  }
  
  int v() {
    e e1 = this.P;
    return (e1 == null) ? 0 : e1.e;
  }
  
  public LayoutInflater v0(Bundle paramBundle) {
    return B(paramBundle);
  }
  
  public void v1(Bundle paramBundle) {
    if (this.x == null || !e0()) {
      this.l = paramBundle;
      return;
    } 
    throw new IllegalStateException("Fragment already added and state has been saved");
  }
  
  public Object w() {
    e e1 = this.P;
    return (e1 == null) ? null : e1.m;
  }
  
  public void w0(boolean paramBoolean) {}
  
  void w1(View paramView) {
    (g()).t = paramView;
  }
  
  o x() {
    e e1 = this.P;
    if (e1 == null)
      return null; 
    Objects.requireNonNull(e1);
    return null;
  }
  
  @Deprecated
  public void x0(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle) {
    this.K = true;
  }
  
  void x1(boolean paramBoolean) {
    (g()).w = paramBoolean;
  }
  
  View y() {
    e e1 = this.P;
    return (e1 == null) ? null : e1.t;
  }
  
  public void y0(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.K = true;
    j<?> j1 = this.y;
    if (j1 == null) {
      j1 = null;
    } else {
      activity = j1.h();
    } 
    if (activity != null) {
      this.K = false;
      x0(activity, paramAttributeSet, paramBundle);
    } 
  }
  
  void y1(int paramInt) {
    if (this.P == null && paramInt == 0)
      return; 
    g();
    this.P.h = paramInt;
  }
  
  public final Object z() {
    j<?> j1 = this.y;
    return (j1 == null) ? null : j1.m();
  }
  
  public void z0(boolean paramBoolean) {}
  
  void z1(h paramh) {
    g();
    e e1 = this.P;
    h h1 = e1.v;
    if (paramh == h1)
      return; 
    if (paramh == null || h1 == null) {
      if (e1.u)
        e1.v = paramh; 
      if (paramh != null)
        paramh.b(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  class a implements Runnable {
    a(Fragment this$0) {}
    
    public void run() {
      this.f.D1();
    }
  }
  
  class b implements Runnable {
    b(Fragment this$0) {}
    
    public void run() {
      this.f.d(false);
    }
  }
  
  class c implements Runnable {
    c(Fragment this$0, b0 param1b0) {}
    
    public void run() {
      this.f.g();
    }
  }
  
  class d extends g {
    d(Fragment this$0) {}
    
    public View f(int param1Int) {
      View view = this.a.M;
      if (view != null)
        return view.findViewById(param1Int); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this.a);
      stringBuilder.append(" does not have a view");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public boolean g() {
      return (this.a.M != null);
    }
  }
  
  static class e {
    View a;
    
    Animator b;
    
    boolean c;
    
    int d;
    
    int e;
    
    int f;
    
    int g;
    
    int h;
    
    ArrayList<String> i;
    
    ArrayList<String> j;
    
    Object k = null;
    
    Object l;
    
    Object m;
    
    Object n;
    
    Object o;
    
    Object p;
    
    Boolean q;
    
    Boolean r;
    
    float s;
    
    View t;
    
    boolean u;
    
    Fragment.h v;
    
    boolean w;
    
    e() {
      Object object = Fragment.f0;
      this.l = object;
      this.m = null;
      this.n = object;
      this.o = null;
      this.p = object;
      this.s = 1.0F;
      this.t = null;
    }
  }
  
  public static class f extends RuntimeException {
    public f(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  private static abstract class g {
    abstract void a();
  }
  
  static interface h {
    void a();
    
    void b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */