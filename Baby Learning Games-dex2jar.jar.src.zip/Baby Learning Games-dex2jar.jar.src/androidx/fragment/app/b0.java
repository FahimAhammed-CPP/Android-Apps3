package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.w;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

abstract class b0 {
  private final ViewGroup a;
  
  final ArrayList<e> b = new ArrayList<e>();
  
  final ArrayList<e> c = new ArrayList<e>();
  
  boolean d = false;
  
  boolean e = false;
  
  b0(ViewGroup paramViewGroup) {
    this.a = paramViewGroup;
  }
  
  private void a(e.c paramc, e.b paramb, t paramt) {
    synchronized (this.b) {
      h0.b b1 = new h0.b();
      e e = h(paramt.k());
      if (e != null) {
        e.k(paramc, paramb);
        return;
      } 
      d d = new d(paramc, paramb, paramt, b1);
      this.b.add(d);
      d.a(new a(this, d));
      d.a(new b(this, d));
      return;
    } 
  }
  
  private e h(Fragment paramFragment) {
    for (e e : this.b) {
      if (e.f().equals(paramFragment) && !e.h())
        return e; 
    } 
    return null;
  }
  
  private e i(Fragment paramFragment) {
    for (e e : this.c) {
      if (e.f().equals(paramFragment) && !e.h())
        return e; 
    } 
    return null;
  }
  
  static b0 n(ViewGroup paramViewGroup, m paramm) {
    return o(paramViewGroup, paramm.z0());
  }
  
  static b0 o(ViewGroup paramViewGroup, c0 paramc0) {
    int i = u0.b.b;
    Object object = paramViewGroup.getTag(i);
    if (object instanceof b0)
      return (b0)object; 
    b0 b01 = paramc0.a(paramViewGroup);
    paramViewGroup.setTag(i, b01);
    return b01;
  }
  
  private void q() {
    for (e e : this.b) {
      if (e.g() == e.b.g)
        e.k(e.c.d(e.f().o1().getVisibility()), e.b.f); 
    } 
  }
  
  void b(e.c paramc, t paramt) {
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing add operation for fragment ");
      stringBuilder.append(paramt.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    a(paramc, e.b.g, paramt);
  }
  
  void c(t paramt) {
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing hide operation for fragment ");
      stringBuilder.append(paramt.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    a(e.c.h, e.b.f, paramt);
  }
  
  void d(t paramt) {
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing remove operation for fragment ");
      stringBuilder.append(paramt.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    a(e.c.f, e.b.h, paramt);
  }
  
  void e(t paramt) {
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing show operation for fragment ");
      stringBuilder.append(paramt.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    a(e.c.g, e.b.f, paramt);
  }
  
  abstract void f(List<e> paramList, boolean paramBoolean);
  
  void g() {
    if (this.e)
      return; 
    if (!w.R((View)this.a)) {
      j();
      this.d = false;
      return;
    } 
    synchronized (this.b) {
      if (!this.b.isEmpty()) {
        ArrayList<e> arrayList = new ArrayList<e>(this.c);
        this.c.clear();
        for (e e : arrayList) {
          if (m.G0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Cancelling operation ");
            stringBuilder.append(e);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          e.b();
          if (!e.i())
            this.c.add(e); 
        } 
        q();
        arrayList = new ArrayList<e>(this.b);
        this.b.clear();
        this.c.addAll(arrayList);
        Iterator<e> iterator = arrayList.iterator();
        while (iterator.hasNext())
          ((e)iterator.next()).l(); 
        f(arrayList, this.d);
        this.d = false;
      } 
      return;
    } 
  }
  
  void j() {
    boolean bool = w.R((View)this.a);
    synchronized (this.b) {
      q();
      Iterator<e> iterator = this.b.iterator();
      while (iterator.hasNext())
        ((e)iterator.next()).l(); 
      for (e e : new ArrayList(this.c)) {
        if (m.G0(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.a);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling running operation ");
          stringBuilder.append(e);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        e.b();
      } 
      for (e e : new ArrayList(this.b)) {
        if (m.G0(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.a);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling pending operation ");
          stringBuilder.append(e);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        e.b();
      } 
      return;
    } 
  }
  
  void k() {
    if (this.e) {
      this.e = false;
      g();
    } 
  }
  
  e.b l(t paramt) {
    e e2 = h(paramt.k());
    if (e2 != null) {
      e.b b = e2.g();
    } else {
      e2 = null;
    } 
    e e1 = i(paramt.k());
    return (e.b)((e1 != null && (e2 == null || e2 == e.b.f)) ? e1.g() : e2);
  }
  
  public ViewGroup m() {
    return this.a;
  }
  
  void p() {
    synchronized (this.b) {
      q();
      this.e = false;
      int i = this.b.size() - 1;
      while (true) {
        if (i >= 0) {
          e e = this.b.get(i);
          e.c c1 = e.c.e((e.f()).M);
          e.c c2 = e.e();
          e.c c3 = e.c.g;
          if (c2 == c3 && c1 != c3) {
            this.e = e.f().b0();
          } else {
            i--;
            continue;
          } 
        } 
        return;
      } 
    } 
  }
  
  void r(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  class a implements Runnable {
    a(b0 this$0, b0.d param1d) {}
    
    public void run() {
      if (this.g.b.contains(this.f))
        this.f.e().b((this.f.f()).M); 
    }
  }
  
  class b implements Runnable {
    b(b0 this$0, b0.d param1d) {}
    
    public void run() {
      this.g.b.remove(this.f);
      this.g.c.remove(this.f);
    }
  }
  
  private static class d extends e {
    private final t h;
    
    d(b0.e.c param1c, b0.e.b param1b, t param1t, h0.b param1b1) {
      super(param1c, param1b, param1t.k(), param1b1);
      this.h = param1t;
    }
    
    public void c() {
      super.c();
      this.h.m();
    }
    
    void l() {
      if (g() == b0.e.b.g) {
        Fragment fragment = this.h.k();
        View view = fragment.M.findFocus();
        if (view != null) {
          fragment.w1(view);
          if (m.G0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("requestFocus: Saved focused view ");
            stringBuilder.append(view);
            stringBuilder.append(" for Fragment ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
        } 
        view = f().o1();
        if (view.getParent() == null) {
          this.h.b();
          view.setAlpha(0.0F);
        } 
        if (view.getAlpha() == 0.0F && view.getVisibility() == 0)
          view.setVisibility(4); 
        view.setAlpha(fragment.J());
      } 
    }
  }
  
  static class e {
    private c a;
    
    private b b;
    
    private final Fragment c;
    
    private final List<Runnable> d = new ArrayList<Runnable>();
    
    private final HashSet<h0.b> e = new HashSet<h0.b>();
    
    private boolean f = false;
    
    private boolean g = false;
    
    e(c param1c, b param1b, Fragment param1Fragment, h0.b param1b1) {
      this.a = param1c;
      this.b = param1b;
      this.c = param1Fragment;
      param1b1.c(new a(this));
    }
    
    final void a(Runnable param1Runnable) {
      this.d.add(param1Runnable);
    }
    
    final void b() {
      if (h())
        return; 
      this.f = true;
      if (this.e.isEmpty()) {
        c();
        return;
      } 
      Iterator<?> iterator = (new ArrayList(this.e)).iterator();
      while (iterator.hasNext())
        ((h0.b)iterator.next()).a(); 
    }
    
    public void c() {
      if (this.g)
        return; 
      if (m.G0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SpecialEffectsController: ");
        stringBuilder.append(this);
        stringBuilder.append(" has called complete.");
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      this.g = true;
      Iterator<Runnable> iterator = this.d.iterator();
      while (iterator.hasNext())
        ((Runnable)iterator.next()).run(); 
    }
    
    public final void d(h0.b param1b) {
      if (this.e.remove(param1b) && this.e.isEmpty())
        c(); 
    }
    
    public c e() {
      return this.a;
    }
    
    public final Fragment f() {
      return this.c;
    }
    
    b g() {
      return this.b;
    }
    
    final boolean h() {
      return this.f;
    }
    
    final boolean i() {
      return this.g;
    }
    
    public final void j(h0.b param1b) {
      l();
      this.e.add(param1b);
    }
    
    final void k(c param1c, b param1b) {
      int i = b0.c.b[param1b.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          if (this.a != c.f) {
            if (m.G0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: For fragment ");
              stringBuilder.append(this.c);
              stringBuilder.append(" mFinalState = ");
              stringBuilder.append(this.a);
              stringBuilder.append(" -> ");
              stringBuilder.append(param1c);
              stringBuilder.append(". ");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            this.a = param1c;
            return;
          } 
        } else {
          if (m.G0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: For fragment ");
            stringBuilder.append(this.c);
            stringBuilder.append(" mFinalState = ");
            stringBuilder.append(this.a);
            stringBuilder.append(" -> REMOVED. mLifecycleImpact  = ");
            stringBuilder.append(this.b);
            stringBuilder.append(" to REMOVING.");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          this.a = c.f;
          this.b = b.h;
          return;
        } 
      } else if (this.a == c.f) {
        if (m.G0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: For fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = ");
          stringBuilder.append(this.b);
          stringBuilder.append(" to ADDING.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.a = c.g;
        this.b = b.g;
      } 
    }
    
    void l() {}
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Operation ");
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFinalState = ");
      stringBuilder.append(this.a);
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mLifecycleImpact = ");
      stringBuilder.append(this.b);
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFragment = ");
      stringBuilder.append(this.c);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    class a implements h0.b.a {
      a(b0.e this$0) {}
      
      public void a() {
        this.a.b();
      }
    }
    
    enum b {
      f, g, h;
      
      static {
        b b1 = new b("NONE", 0);
        f = b1;
        b b2 = new b("ADDING", 1);
        g = b2;
        b b3 = new b("REMOVING", 2);
        h = b3;
        i = new b[] { b1, b2, b3 };
      }
    }
    
    enum c {
      f, g, h, i;
      
      static {
        c c1 = new c("REMOVED", 0);
        f = c1;
        c c2 = new c("VISIBLE", 1);
        g = c2;
        c c3 = new c("GONE", 2);
        h = c3;
        c c4 = new c("INVISIBLE", 3);
        i = c4;
        j = new c[] { c1, c2, c3, c4 };
      }
      
      static c d(int param2Int) {
        if (param2Int != 0) {
          if (param2Int != 4) {
            if (param2Int == 8)
              return h; 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown visibility ");
            stringBuilder.append(param2Int);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
          return i;
        } 
        return g;
      }
      
      static c e(View param2View) {
        return (param2View.getAlpha() == 0.0F && param2View.getVisibility() == 0) ? i : d(param2View.getVisibility());
      }
      
      void b(View param2View) {
        int i = b0.c.a[ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              if (i != 4)
                return; 
              if (m.G0(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SpecialEffectsController: Setting view ");
                stringBuilder.append(param2View);
                stringBuilder.append(" to INVISIBLE");
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              param2View.setVisibility(4);
              return;
            } 
            if (m.G0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param2View);
              stringBuilder.append(" to GONE");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            param2View.setVisibility(8);
            return;
          } 
          if (m.G0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param2View);
            stringBuilder.append(" to VISIBLE");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          param2View.setVisibility(0);
          return;
        } 
        ViewGroup viewGroup = (ViewGroup)param2View.getParent();
        if (viewGroup != null) {
          if (m.G0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Removing view ");
            stringBuilder.append(param2View);
            stringBuilder.append(" from container ");
            stringBuilder.append(viewGroup);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          viewGroup.removeView(param2View);
        } 
      }
    }
  }
  
  class a implements h0.b.a {
    a(b0 this$0) {}
    
    public void a() {
      this.a.b();
    }
  }
  
  enum b {
    f, g, h;
    
    static {
      b b1 = new b("NONE", 0);
      f = b1;
      b b2 = new b("ADDING", 1);
      g = b2;
      b b3 = new b("REMOVING", 2);
      h = b3;
      i = new b[] { b1, b2, b3 };
    }
  }
  
  enum c {
    f, g, h, i;
    
    static {
      c c1 = new c("REMOVED", 0);
      f = c1;
      c c2 = new c("VISIBLE", 1);
      g = c2;
      c c3 = new c("GONE", 2);
      h = c3;
      c c4 = new c("INVISIBLE", 3);
      i = c4;
      j = new c[] { c1, c2, c3, c4 };
    }
    
    static c d(int param1Int) {
      if (param1Int != 0) {
        if (param1Int != 4) {
          if (param1Int == 8)
            return h; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown visibility ");
          stringBuilder.append(param1Int);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        return i;
      } 
      return g;
    }
    
    static c e(View param1View) {
      return (param1View.getAlpha() == 0.0F && param1View.getVisibility() == 0) ? i : d(param1View.getVisibility());
    }
    
    void b(View param1View) {
      int i = b0.c.a[ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4)
              return; 
            if (m.G0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param1View);
              stringBuilder.append(" to INVISIBLE");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            param1View.setVisibility(4);
            return;
          } 
          if (m.G0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param1View);
            stringBuilder.append(" to GONE");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          param1View.setVisibility(8);
          return;
        } 
        if (m.G0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: Setting view ");
          stringBuilder.append(param1View);
          stringBuilder.append(" to VISIBLE");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        param1View.setVisibility(0);
        return;
      } 
      ViewGroup viewGroup = (ViewGroup)param1View.getParent();
      if (viewGroup != null) {
        if (m.G0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: Removing view ");
          stringBuilder.append(param1View);
          stringBuilder.append(" from container ");
          stringBuilder.append(viewGroup);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        viewGroup.removeView(param1View);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */