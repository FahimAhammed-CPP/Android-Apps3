package androidx.fragment.app;

import android.util.AndroidRuntimeException;

final class d0 extends AndroidRuntimeException {
  public d0(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */