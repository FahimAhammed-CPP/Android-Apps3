package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

class u {
  private final ArrayList<Fragment> a = new ArrayList<Fragment>();
  
  private final HashMap<String, t> b = new HashMap<String, t>();
  
  private p c;
  
  void a(Fragment paramFragment) {
    if (!this.a.contains(paramFragment))
      synchronized (this.a) {
        this.a.add(paramFragment);
        paramFragment.q = true;
        return;
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment already added: ");
    stringBuilder.append(paramFragment);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void b() {
    this.b.values().removeAll(Collections.singleton(null));
  }
  
  boolean c(String paramString) {
    return (this.b.get(paramString) != null);
  }
  
  void d(int paramInt) {
    for (t t : this.b.values()) {
      if (t != null)
        t.t(paramInt); 
    } 
  }
  
  void e(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("    ");
    String str = stringBuilder.toString();
    if (!this.b.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Active Fragments:");
      for (t t : this.b.values()) {
        paramPrintWriter.print(paramString);
        if (t != null) {
          Fragment fragment = t.k();
          paramPrintWriter.println(fragment);
          fragment.f(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          continue;
        } 
        paramPrintWriter.println("null");
      } 
    } 
    int i = this.a.size();
    if (i > 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Added Fragments:");
      int j;
      for (j = 0; j < i; j++) {
        Fragment fragment = this.a.get(j);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(j);
        paramPrintWriter.print(": ");
        paramPrintWriter.println(fragment.toString());
      } 
    } 
  }
  
  Fragment f(String paramString) {
    t t = this.b.get(paramString);
    return (t != null) ? t.k() : null;
  }
  
  Fragment g(int paramInt) {
    for (int i = this.a.size() - 1; i >= 0; i--) {
      Fragment fragment = this.a.get(i);
      if (fragment != null && fragment.B == paramInt)
        return fragment; 
    } 
    for (t t : this.b.values()) {
      if (t != null) {
        Fragment fragment = t.k();
        if (fragment.B == paramInt)
          return fragment; 
      } 
    } 
    return null;
  }
  
  Fragment h(String paramString) {
    if (paramString != null)
      for (int i = this.a.size() - 1; i >= 0; i--) {
        Fragment fragment = this.a.get(i);
        if (fragment != null && paramString.equals(fragment.D))
          return fragment; 
      }  
    if (paramString != null)
      for (t t : this.b.values()) {
        if (t != null) {
          Fragment fragment = t.k();
          if (paramString.equals(fragment.D))
            return fragment; 
        } 
      }  
    return null;
  }
  
  Fragment i(String paramString) {
    for (t t : this.b.values()) {
      if (t != null) {
        Fragment fragment = t.k().i(paramString);
        if (fragment != null)
          return fragment; 
      } 
    } 
    return null;
  }
  
  int j(Fragment paramFragment) {
    int j;
    ViewGroup viewGroup = paramFragment.L;
    if (viewGroup == null)
      return -1; 
    int k = this.a.indexOf(paramFragment);
    int i = k - 1;
    while (true) {
      j = k;
      if (i >= 0) {
        paramFragment = this.a.get(i);
        if (paramFragment.L == viewGroup) {
          View view = paramFragment.M;
          if (view != null)
            return viewGroup.indexOfChild(view) + 1; 
        } 
        i--;
        continue;
      } 
      break;
    } 
    while (true) {
      if (++j < this.a.size()) {
        paramFragment = this.a.get(j);
        if (paramFragment.L == viewGroup) {
          View view = paramFragment.M;
          if (view != null)
            return viewGroup.indexOfChild(view); 
        } 
        continue;
      } 
      return -1;
    } 
  }
  
  List<t> k() {
    ArrayList<t> arrayList = new ArrayList();
    for (t t : this.b.values()) {
      if (t != null)
        arrayList.add(t); 
    } 
    return arrayList;
  }
  
  List<Fragment> l() {
    ArrayList<Fragment> arrayList = new ArrayList();
    for (t t : this.b.values()) {
      if (t != null) {
        arrayList.add(t.k());
        continue;
      } 
      arrayList.add(null);
    } 
    return arrayList;
  }
  
  t m(String paramString) {
    return this.b.get(paramString);
  }
  
  List<Fragment> n() {
    if (this.a.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.a) {
      return new ArrayList<Fragment>(this.a);
    } 
  }
  
  p o() {
    return this.c;
  }
  
  void p(t paramt) {
    Fragment fragment = paramt.k();
    if (c(fragment.k))
      return; 
    this.b.put(fragment.k, paramt);
    if (fragment.H) {
      if (fragment.G) {
        this.c.f(fragment);
      } else {
        this.c.n(fragment);
      } 
      fragment.H = false;
    } 
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Added fragment to active set ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void q(t paramt) {
    Fragment fragment = paramt.k();
    if (fragment.G)
      this.c.n(fragment); 
    if ((t)this.b.put(fragment.k, null) == null)
      return; 
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removed fragment from active set ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void r() {
    for (Fragment fragment : this.a) {
      t t = this.b.get(fragment.k);
      if (t != null)
        t.m(); 
    } 
    for (t t : this.b.values()) {
      if (t != null) {
        boolean bool;
        t.m();
        Fragment fragment = t.k();
        if (fragment.r && !fragment.Z()) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool)
          q(t); 
      } 
    } 
  }
  
  void s(Fragment paramFragment) {
    synchronized (this.a) {
      this.a.remove(paramFragment);
      paramFragment.q = false;
      return;
    } 
  }
  
  void t() {
    this.b.clear();
  }
  
  void u(List<String> paramList) {
    this.a.clear();
    if (paramList != null) {
      Iterator<String> iterator = paramList.iterator();
      while (iterator.hasNext()) {
        String str = iterator.next();
        Fragment fragment = f(str);
        if (fragment != null) {
          if (m.G0(2)) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("restoreSaveState: added (");
            stringBuilder1.append(str);
            stringBuilder1.append("): ");
            stringBuilder1.append(fragment);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          a(fragment);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No instantiated fragment for (");
        stringBuilder.append(str);
        stringBuilder.append(")");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  ArrayList<s> v() {
    ArrayList<s> arrayList = new ArrayList(this.b.size());
    for (t t : this.b.values()) {
      if (t != null) {
        Fragment fragment = t.k();
        s s = t.r();
        arrayList.add(s);
        if (m.G0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Saved state of ");
          stringBuilder.append(fragment);
          stringBuilder.append(": ");
          stringBuilder.append(s.r);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
    return arrayList;
  }
  
  ArrayList<String> w() {
    synchronized (this.a) {
      if (this.a.isEmpty())
        return null; 
      ArrayList<String> arrayList = new ArrayList(this.a.size());
      for (Fragment fragment : this.a) {
        arrayList.add(fragment.k);
        if (m.G0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("saveAllState: adding fragment (");
          stringBuilder.append(fragment.k);
          stringBuilder.append("): ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
      return arrayList;
    } 
  }
  
  void x(p paramp) {
    this.c = paramp;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\ap\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */