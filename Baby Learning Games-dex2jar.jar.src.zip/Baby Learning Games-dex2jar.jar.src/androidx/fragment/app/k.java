package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import u0.c;

class k implements LayoutInflater.Factory2 {
  final m f;
  
  k(m paramm) {
    this.f = paramm;
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (FragmentContainerView.class.getName().equals(paramString))
      return (View)new FragmentContainerView(paramContext, paramAttributeSet, this.f); 
    boolean bool = "fragment".equals(paramString);
    paramString = null;
    if (!bool)
      return null; 
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c.d);
    String str2 = str1;
    if (str1 == null)
      str2 = typedArray.getString(c.e); 
    int i = typedArray.getResourceId(c.f, -1);
    String str3 = typedArray.getString(c.g);
    typedArray.recycle();
    if (str2 != null) {
      t t;
      boolean bool1;
      if (!i.b(paramContext.getClassLoader(), str2))
        return null; 
      if (paramView != null) {
        bool1 = paramView.getId();
      } else {
        bool1 = false;
      } 
      if (bool1 != -1 || i != -1 || str3 != null) {
        StringBuilder stringBuilder2;
        Fragment fragment2;
        if (i != -1)
          fragment1 = this.f.h0(i); 
        Fragment fragment3 = fragment1;
        if (fragment1 == null) {
          fragment3 = fragment1;
          if (str3 != null)
            fragment3 = this.f.i0(str3); 
        } 
        Fragment fragment1 = fragment3;
        if (fragment3 == null) {
          fragment1 = fragment3;
          if (bool1 != -1)
            fragment1 = this.f.h0(bool1); 
        } 
        if (fragment1 == null) {
          boolean bool2;
          fragment1 = this.f.r0().a(paramContext.getClassLoader(), str2);
          fragment1.s = true;
          if (i != 0) {
            bool2 = i;
          } else {
            bool2 = bool1;
          } 
          fragment1.B = bool2;
          fragment1.C = bool1;
          fragment1.D = str3;
          fragment1.t = true;
          m m1 = this.f;
          fragment1.x = m1;
          fragment1.y = m1.u0();
          fragment1.y0(this.f.u0().j(), paramAttributeSet, fragment1.g);
          t t1 = this.f.g(fragment1);
          fragment2 = fragment1;
          t = t1;
          if (m.G0(2)) {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Fragment ");
            stringBuilder3.append(fragment1);
            stringBuilder3.append(" has been inflated via the <fragment> tag: id=0x");
            stringBuilder3.append(Integer.toHexString(i));
            Log.v("FragmentManager", stringBuilder3.toString());
            Fragment fragment = fragment1;
            t = t1;
          } 
        } else if (!fragment1.t) {
          fragment1.t = true;
          m m1 = this.f;
          fragment1.x = m1;
          fragment1.y = m1.u0();
          fragment1.y0(this.f.u0().j(), (AttributeSet)t, fragment1.g);
          t t1 = this.f.w(fragment1);
          fragment2 = fragment1;
          t = t1;
          if (m.G0(2)) {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Retained Fragment ");
            stringBuilder3.append(fragment1);
            stringBuilder3.append(" has been re-attached via the <fragment> tag: id=0x");
            stringBuilder3.append(Integer.toHexString(i));
            Log.v("FragmentManager", stringBuilder3.toString());
            t = t1;
            fragment2 = fragment1;
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append(t.getPositionDescription());
          stringBuilder2.append(": Duplicate id 0x");
          stringBuilder2.append(Integer.toHexString(i));
          stringBuilder2.append(", tag ");
          stringBuilder2.append(str3);
          stringBuilder2.append(", or parent id 0x");
          stringBuilder2.append(Integer.toHexString(bool1));
          stringBuilder2.append(" with another fragment for ");
          stringBuilder2.append(str2);
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
        fragment2.L = (ViewGroup)stringBuilder2;
        t.m();
        t.j();
        View view = fragment2.M;
        if (view != null) {
          if (i != 0)
            view.setId(i); 
          if (fragment2.M.getTag() == null)
            fragment2.M.setTag(str3); 
          fragment2.M.addOnAttachStateChangeListener(new a(this, t));
          return fragment2.M;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Fragment ");
        stringBuilder1.append(str2);
        stringBuilder1.append(" did not create a view.");
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(t.getPositionDescription());
      stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
      stringBuilder.append(str2);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return null;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  class a implements View.OnAttachStateChangeListener {
    a(k this$0, t param1t) {}
    
    public void onViewAttachedToWindow(View param1View) {
      Fragment fragment = this.f.k();
      this.f.m();
      b0.n((ViewGroup)fragment.M.getParent(), this.g.f).j();
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */