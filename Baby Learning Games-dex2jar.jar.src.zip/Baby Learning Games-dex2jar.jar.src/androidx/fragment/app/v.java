package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;
import androidx.core.view.w;
import androidx.lifecycle.j;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public abstract class v {
  private final i a;
  
  private final ClassLoader b;
  
  ArrayList<a> c = new ArrayList<a>();
  
  int d;
  
  int e;
  
  int f;
  
  int g;
  
  int h;
  
  boolean i;
  
  boolean j = true;
  
  String k;
  
  int l;
  
  CharSequence m;
  
  int n;
  
  CharSequence o;
  
  ArrayList<String> p;
  
  ArrayList<String> q;
  
  boolean r = false;
  
  ArrayList<Runnable> s;
  
  v(i parami, ClassLoader paramClassLoader) {
    this.a = parami;
    this.b = paramClassLoader;
  }
  
  public v c(int paramInt, Fragment paramFragment, String paramString) {
    n(paramInt, paramFragment, paramString, 1);
    return this;
  }
  
  v d(ViewGroup paramViewGroup, Fragment paramFragment, String paramString) {
    paramFragment.L = paramViewGroup;
    return c(paramViewGroup.getId(), paramFragment, paramString);
  }
  
  public v e(Fragment paramFragment, String paramString) {
    n(0, paramFragment, paramString, 1);
    return this;
  }
  
  void f(a parama) {
    this.c.add(parama);
    parama.c = this.d;
    parama.d = this.e;
    parama.e = this.f;
    parama.f = this.g;
  }
  
  public v g(View paramView, String paramString) {
    if (w.C()) {
      String str = w.K(paramView);
      if (str != null) {
        StringBuilder stringBuilder1;
        StringBuilder stringBuilder2;
        if (this.p == null) {
          this.p = new ArrayList<String>();
          this.q = new ArrayList<String>();
        } else {
          if (!this.q.contains(paramString)) {
            if (this.p.contains(str)) {
              stringBuilder2 = new StringBuilder();
              stringBuilder2.append("A shared element with the source name '");
              stringBuilder2.append(str);
              stringBuilder2.append("' has already been added to the transaction.");
              throw new IllegalArgumentException(stringBuilder2.toString());
            } 
            this.p.add(str);
            this.q.add(stringBuilder2);
            return this;
          } 
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("A shared element with the target name '");
          stringBuilder1.append((String)stringBuilder2);
          stringBuilder1.append("' has already been added to the transaction.");
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
        this.p.add(stringBuilder1);
        this.q.add(stringBuilder2);
        return this;
      } 
      throw new IllegalArgumentException("Unique transitionNames are required for all sharedElements");
    } 
    return this;
  }
  
  public v h(String paramString) {
    if (this.j) {
      this.i = true;
      this.k = paramString;
      return this;
    } 
    throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
  }
  
  public abstract int i();
  
  public abstract int j();
  
  public abstract void k();
  
  public abstract void l();
  
  public v m() {
    if (!this.i) {
      this.j = false;
      return this;
    } 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  void n(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    Class<?> clazz = paramFragment.getClass();
    int j = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(j) && (!clazz.isMemberClass() || Modifier.isStatic(j))) {
      if (paramString != null) {
        String str = paramFragment.D;
        if (str == null || paramString.equals(str)) {
          paramFragment.D = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(": was ");
          stringBuilder2.append(paramFragment.D);
          stringBuilder2.append(" now ");
          stringBuilder2.append(paramString);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          j = paramFragment.B;
          if (j == 0 || j == paramInt1) {
            paramFragment.B = paramInt1;
            paramFragment.C = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramFragment);
            stringBuilder.append(": was ");
            stringBuilder.append(paramFragment.B);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      f(new a(paramInt2, paramFragment));
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  public v o(Fragment paramFragment) {
    f(new a(3, paramFragment));
    return this;
  }
  
  public v p(int paramInt, Fragment paramFragment) {
    return q(paramInt, paramFragment, null);
  }
  
  public v q(int paramInt, Fragment paramFragment, String paramString) {
    if (paramInt != 0) {
      n(paramInt, paramFragment, paramString, 2);
      return this;
    } 
    throw new IllegalArgumentException("Must use non-zero containerViewId");
  }
  
  public v r(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.d = paramInt1;
    this.e = paramInt2;
    this.f = paramInt3;
    this.g = paramInt4;
    return this;
  }
  
  public v s(Fragment paramFragment) {
    f(new a(8, paramFragment));
    return this;
  }
  
  public v t(boolean paramBoolean) {
    this.r = paramBoolean;
    return this;
  }
  
  static final class a {
    int a;
    
    Fragment b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    j.c g;
    
    j.c h;
    
    a() {}
    
    a(int param1Int, Fragment param1Fragment) {
      this.a = param1Int;
      this.b = param1Fragment;
      j.c c1 = j.c.j;
      this.g = c1;
      this.h = c1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */