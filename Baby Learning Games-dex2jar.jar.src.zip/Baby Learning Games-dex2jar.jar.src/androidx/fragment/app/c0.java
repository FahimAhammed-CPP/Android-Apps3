package androidx.fragment.app;

import android.view.ViewGroup;

interface c0 {
  b0 a(ViewGroup paramViewGroup);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */