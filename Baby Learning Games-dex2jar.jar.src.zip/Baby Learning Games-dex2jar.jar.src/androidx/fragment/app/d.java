package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.q;
import androidx.lifecycle.x;

public class d extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
  private Handler g0;
  
  private Runnable h0 = new a(this);
  
  private DialogInterface.OnCancelListener i0 = new b(this);
  
  private DialogInterface.OnDismissListener j0 = new c(this);
  
  private int k0 = 0;
  
  private int l0 = 0;
  
  private boolean m0 = true;
  
  private boolean n0 = true;
  
  private int o0 = -1;
  
  private boolean p0;
  
  private x<q> q0 = new d(this);
  
  private Dialog r0;
  
  private boolean s0;
  
  private boolean t0;
  
  private boolean u0;
  
  private boolean v0 = false;
  
  private void I1(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.t0)
      return; 
    this.t0 = true;
    this.u0 = false;
    Dialog dialog = this.r0;
    if (dialog != null) {
      dialog.setOnDismissListener(null);
      this.r0.dismiss();
      if (!paramBoolean2)
        if (Looper.myLooper() == this.g0.getLooper()) {
          onDismiss((DialogInterface)this.r0);
        } else {
          this.g0.post(this.h0);
        }  
    } 
    this.s0 = true;
    if (this.o0 >= 0) {
      F().U0(this.o0, 1);
      this.o0 = -1;
      return;
    } 
    v v = F().m();
    v.o(this);
    if (paramBoolean1) {
      v.j();
      return;
    } 
    v.i();
  }
  
  private void O1(Bundle paramBundle) {
    if (!this.n0)
      return; 
    if (!this.v0)
      try {
        this.p0 = true;
        Dialog dialog = L1(paramBundle);
        this.r0 = dialog;
        if (this.n0) {
          R1(dialog, this.k0);
          Context context = r();
          if (context instanceof Activity)
            this.r0.setOwnerActivity((Activity)context); 
          this.r0.setCancelable(this.m0);
          this.r0.setOnCancelListener(this.i0);
          this.r0.setOnDismissListener(this.j0);
          this.v0 = true;
        } else {
          this.r0 = null;
        } 
        return;
      } finally {
        this.p0 = false;
      }  
  }
  
  public void H1() {
    I1(false, false);
  }
  
  public void I0(Bundle paramBundle) {
    super.I0(paramBundle);
    Dialog dialog = this.r0;
    if (dialog != null) {
      Bundle bundle = dialog.onSaveInstanceState();
      bundle.putBoolean("android:dialogShowing", false);
      paramBundle.putBundle("android:savedDialogState", bundle);
    } 
    int i = this.k0;
    if (i != 0)
      paramBundle.putInt("android:style", i); 
    i = this.l0;
    if (i != 0)
      paramBundle.putInt("android:theme", i); 
    boolean bool = this.m0;
    if (!bool)
      paramBundle.putBoolean("android:cancelable", bool); 
    bool = this.n0;
    if (!bool)
      paramBundle.putBoolean("android:showsDialog", bool); 
    i = this.o0;
    if (i != -1)
      paramBundle.putInt("android:backStackId", i); 
  }
  
  public void J0() {
    super.J0();
    Dialog dialog = this.r0;
    if (dialog != null) {
      this.s0 = false;
      dialog.show();
      View view = this.r0.getWindow().getDecorView();
      j0.a(view, this);
      k0.a(view, this);
      androidx.savedstate.d.a(view, this);
    } 
  }
  
  public Dialog J1() {
    return this.r0;
  }
  
  public void K0() {
    super.K0();
    Dialog dialog = this.r0;
    if (dialog != null)
      dialog.hide(); 
  }
  
  public int K1() {
    return this.l0;
  }
  
  public Dialog L1(Bundle paramBundle) {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCreateDialog called for DialogFragment ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    return new Dialog(m1(), K1());
  }
  
  public void M0(Bundle paramBundle) {
    super.M0(paramBundle);
    if (this.r0 != null && paramBundle != null) {
      paramBundle = paramBundle.getBundle("android:savedDialogState");
      if (paramBundle != null)
        this.r0.onRestoreInstanceState(paramBundle); 
    } 
  }
  
  View M1(int paramInt) {
    Dialog dialog = this.r0;
    return (dialog != null) ? dialog.findViewById(paramInt) : null;
  }
  
  boolean N1() {
    return this.v0;
  }
  
  public final Dialog P1() {
    Dialog dialog = J1();
    if (dialog != null)
      return dialog; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DialogFragment ");
    stringBuilder.append(this);
    stringBuilder.append(" does not have a Dialog.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void Q1(boolean paramBoolean) {
    this.n0 = paramBoolean;
  }
  
  public void R1(Dialog paramDialog, int paramInt) {
    if (paramInt != 1 && paramInt != 2) {
      if (paramInt != 3)
        return; 
      Window window = paramDialog.getWindow();
      if (window != null)
        window.addFlags(24); 
    } 
    paramDialog.requestWindowFeature(1);
  }
  
  public void S1(m paramm, String paramString) {
    this.t0 = false;
    this.u0 = true;
    v v = paramm.m();
    v.e(this, paramString);
    v.i();
  }
  
  void T0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    super.T0(paramLayoutInflater, paramViewGroup, paramBundle);
    if (this.M == null && this.r0 != null && paramBundle != null) {
      Bundle bundle = paramBundle.getBundle("android:savedDialogState");
      if (bundle != null)
        this.r0.onRestoreInstanceState(bundle); 
    } 
  }
  
  g e() {
    return new e(this, super.e());
  }
  
  public void j0(Context paramContext) {
    super.j0(paramContext);
    U().h(this.q0);
    if (!this.u0)
      this.t0 = false; 
  }
  
  public void m0(Bundle paramBundle) {
    boolean bool;
    super.m0(paramBundle);
    this.g0 = new Handler();
    if (this.C == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.n0 = bool;
    if (paramBundle != null) {
      this.k0 = paramBundle.getInt("android:style", 0);
      this.l0 = paramBundle.getInt("android:theme", 0);
      this.m0 = paramBundle.getBoolean("android:cancelable", true);
      this.n0 = paramBundle.getBoolean("android:showsDialog", this.n0);
      this.o0 = paramBundle.getInt("android:backStackId", -1);
    } 
  }
  
  public void onCancel(DialogInterface paramDialogInterface) {}
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    if (!this.s0) {
      if (m.G0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onDismiss called for DialogFragment ");
        stringBuilder.append(this);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      I1(true, true);
    } 
  }
  
  public void t0() {
    super.t0();
    Dialog dialog = this.r0;
    if (dialog != null) {
      this.s0 = true;
      dialog.setOnDismissListener(null);
      this.r0.dismiss();
      if (!this.t0)
        onDismiss((DialogInterface)this.r0); 
      this.r0 = null;
      this.v0 = false;
    } 
  }
  
  public void u0() {
    super.u0();
    if (!this.u0 && !this.t0)
      this.t0 = true; 
    U().l(this.q0);
  }
  
  public LayoutInflater v0(Bundle paramBundle) {
    String str;
    LayoutInflater layoutInflater2 = super.v0(paramBundle);
    if (!this.n0 || this.p0) {
      if (m.G0(2)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("getting layout inflater for DialogFragment ");
        stringBuilder1.append(this);
        str = stringBuilder1.toString();
        if (!this.n0) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("mShowsDialog = false: ");
          stringBuilder.append(str);
          Log.d("FragmentManager", stringBuilder.toString());
          return layoutInflater2;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("mCreatingDialog = true: ");
        stringBuilder2.append(str);
        Log.d("FragmentManager", stringBuilder2.toString());
      } 
      return layoutInflater2;
    } 
    O1((Bundle)str);
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("get layout inflater for DialogFragment ");
      stringBuilder.append(this);
      stringBuilder.append(" from dialog context");
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Dialog dialog = this.r0;
    LayoutInflater layoutInflater1 = layoutInflater2;
    if (dialog != null)
      layoutInflater1 = layoutInflater2.cloneInContext(dialog.getContext()); 
    return layoutInflater1;
  }
  
  class a implements Runnable {
    a(d this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void run() {
      d.F1(this.f).onDismiss((DialogInterface)d.E1(this.f));
    }
  }
  
  class b implements DialogInterface.OnCancelListener {
    b(d this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void onCancel(DialogInterface param1DialogInterface) {
      if (d.E1(this.f) != null) {
        d d1 = this.f;
        d1.onCancel((DialogInterface)d.E1(d1));
      } 
    }
  }
  
  class c implements DialogInterface.OnDismissListener {
    c(d this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void onDismiss(DialogInterface param1DialogInterface) {
      if (d.E1(this.f) != null) {
        d d1 = this.f;
        d1.onDismiss((DialogInterface)d.E1(d1));
      } 
    }
  }
  
  class d implements x<q> {
    d(d this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void b(q param1q) {
      if (param1q != null && d.G1(this.a)) {
        View view = this.a.o1();
        if (view.getParent() == null) {
          if (d.E1(this.a) != null) {
            if (m.G0(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("DialogFragment ");
              stringBuilder.append(this);
              stringBuilder.append(" setting the content view on ");
              stringBuilder.append(d.E1(this.a));
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            d.E1(this.a).setContentView(view);
            return;
          } 
        } else {
          throw new IllegalStateException("DialogFragment can not be attached to a container view");
        } 
      } 
    }
  }
  
  class e extends g {
    e(d this$0, g param1g) {}
    
    public View f(int param1Int) {
      return this.a.g() ? this.a.f(param1Int) : this.b.M1(param1Int);
    }
    
    public boolean g() {
      return (this.a.g() || this.b.N1());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */