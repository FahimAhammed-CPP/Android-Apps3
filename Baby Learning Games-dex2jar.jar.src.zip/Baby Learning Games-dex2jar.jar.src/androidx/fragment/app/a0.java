package androidx.fragment.app;

import android.util.Log;
import java.io.Writer;

final class a0 extends Writer {
  private final String f;
  
  private StringBuilder g = new StringBuilder(128);
  
  a0(String paramString) {
    this.f = paramString;
  }
  
  private void d() {
    if (this.g.length() > 0) {
      Log.d(this.f, this.g.toString());
      StringBuilder stringBuilder = this.g;
      stringBuilder.delete(0, stringBuilder.length());
    } 
  }
  
  public void close() {
    d();
  }
  
  public void flush() {
    d();
  }
  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    int i;
    for (i = 0; i < paramInt2; i++) {
      char c = paramArrayOfchar[paramInt1 + i];
      if (c == '\n') {
        d();
      } else {
        this.g.append(c);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */