package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.d;
import androidx.lifecycle.h0;
import androidx.lifecycle.i0;
import androidx.lifecycle.j;
import androidx.lifecycle.q;
import androidx.lifecycle.r;
import androidx.savedstate.SavedStateRegistry;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class e extends ComponentActivity {
  final h q = h.b(new c(this));
  
  final r r = new r((q)this);
  
  boolean s;
  
  boolean t;
  
  boolean u = true;
  
  public e() {
    v();
  }
  
  private void v() {
    c().d("android:support:fragments", new a(this));
    n(new b(this));
  }
  
  private static boolean x(m paramm, j.c paramc) {
    Iterator<Fragment> iterator = paramm.t0().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment == null)
        continue; 
      boolean bool1 = bool;
      if (fragment.z() != null)
        bool1 = bool | x(fragment.q(), paramc); 
      z z = fragment.Y;
      bool = bool1;
      if (z != null) {
        bool = bool1;
        if (z.a().b().b(j.c.i)) {
          fragment.Y.j(paramc);
          bool = true;
        } 
      } 
      if (fragment.X.b().b(j.c.i)) {
        fragment.X.o(paramc);
        bool = true;
      } 
    } 
    return bool;
  }
  
  protected void A() {
    this.r.h(j.b.ON_RESUME);
    this.q.p();
  }
  
  @Deprecated
  public void B() {
    invalidateOptionsMenu();
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.s);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.t);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.u);
    if (getApplication() != null)
      androidx.loader.app.a.b((q)this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.q.t().X(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    this.q.u();
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.q.u();
    super.onConfigurationChanged(paramConfiguration);
    this.q.d(paramConfiguration);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.r.h(j.b.ON_CREATE);
    this.q.f();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt == 0) ? (super.onCreatePanelMenu(paramInt, paramMenu) | this.q.g(paramMenu, getMenuInflater())) : super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = t(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = t(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  protected void onDestroy() {
    super.onDestroy();
    this.q.h();
    this.r.h(j.b.ON_DESTROY);
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.q.i();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.q.e(paramMenuItem)) : this.q.k(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.q.j(paramBoolean);
  }
  
  protected void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    this.q.u();
    super.onNewIntent(paramIntent);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.q.l(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPause() {
    super.onPause();
    this.t = false;
    this.q.m();
    this.r.h(j.b.ON_PAUSE);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.q.n(paramBoolean);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    A();
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0) ? (z(paramView, paramMenu) | this.q.o(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.q.u();
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint);
  }
  
  protected void onResume() {
    this.q.u();
    super.onResume();
    this.t = true;
    this.q.s();
  }
  
  protected void onStart() {
    this.q.u();
    super.onStart();
    this.u = false;
    if (!this.s) {
      this.s = true;
      this.q.c();
    } 
    this.q.s();
    this.r.h(j.b.ON_START);
    this.q.q();
  }
  
  public void onStateNotSaved() {
    this.q.u();
  }
  
  protected void onStop() {
    super.onStop();
    this.u = true;
    w();
    this.q.r();
    this.r.h(j.b.ON_STOP);
  }
  
  final View t(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.q.v(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public m u() {
    return this.q.t();
  }
  
  void w() {
    do {
    
    } while (x(u(), j.c.h));
  }
  
  @Deprecated
  public void y(Fragment paramFragment) {}
  
  @Deprecated
  protected boolean z(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  class a implements SavedStateRegistry.b {
    a(e this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.w();
      this.a.r.h(j.b.ON_STOP);
      Parcelable parcelable = this.a.q.x();
      if (parcelable != null)
        bundle.putParcelable("android:support:fragments", parcelable); 
      return bundle;
    }
  }
  
  class b implements c.b {
    b(e this$0) {}
    
    public void a(Context param1Context) {
      this.a.q.a(null);
      Bundle bundle = this.a.c().a("android:support:fragments");
      if (bundle != null) {
        Parcelable parcelable = bundle.getParcelable("android:support:fragments");
        this.a.q.w(parcelable);
      } 
    }
  }
  
  class c extends j<e> implements i0, androidx.activity.c, androidx.activity.result.e, q {
    public c(e this$0) {
      super(this$0);
    }
    
    public j a() {
      return (j)this.k.r;
    }
    
    public OnBackPressedDispatcher b() {
      return this.k.b();
    }
    
    public void d(m param1m, Fragment param1Fragment) {
      this.k.y(param1Fragment);
    }
    
    public View f(int param1Int) {
      return this.k.findViewById(param1Int);
    }
    
    public boolean g() {
      Window window = this.k.getWindow();
      return (window != null && window.peekDecorView() != null);
    }
    
    public d i() {
      return this.k.i();
    }
    
    public h0 k() {
      return this.k.k();
    }
    
    public LayoutInflater n() {
      return this.k.getLayoutInflater().cloneInContext((Context)this.k);
    }
    
    public boolean o(Fragment param1Fragment) {
      return this.k.isFinishing() ^ true;
    }
    
    public void p() {
      this.k.B();
    }
    
    public e q() {
      return this.k;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */