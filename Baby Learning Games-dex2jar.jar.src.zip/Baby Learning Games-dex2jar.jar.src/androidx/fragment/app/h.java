package androidx.fragment.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class h {
  private final j<?> a;
  
  private h(j<?> paramj) {
    this.a = paramj;
  }
  
  public static h b(j<?> paramj) {
    return new h((j)k0.h.g(paramj, "callbacks == null"));
  }
  
  public void a(Fragment paramFragment) {
    j<?> j1 = this.a;
    j1.j.k(j1, j1, paramFragment);
  }
  
  public void c() {
    this.a.j.z();
  }
  
  public void d(Configuration paramConfiguration) {
    this.a.j.B(paramConfiguration);
  }
  
  public boolean e(MenuItem paramMenuItem) {
    return this.a.j.C(paramMenuItem);
  }
  
  public void f() {
    this.a.j.D();
  }
  
  public boolean g(Menu paramMenu, MenuInflater paramMenuInflater) {
    return this.a.j.E(paramMenu, paramMenuInflater);
  }
  
  public void h() {
    this.a.j.F();
  }
  
  public void i() {
    this.a.j.H();
  }
  
  public void j(boolean paramBoolean) {
    this.a.j.I(paramBoolean);
  }
  
  public boolean k(MenuItem paramMenuItem) {
    return this.a.j.K(paramMenuItem);
  }
  
  public void l(Menu paramMenu) {
    this.a.j.L(paramMenu);
  }
  
  public void m() {
    this.a.j.N();
  }
  
  public void n(boolean paramBoolean) {
    this.a.j.O(paramBoolean);
  }
  
  public boolean o(Menu paramMenu) {
    return this.a.j.P(paramMenu);
  }
  
  public void p() {
    this.a.j.R();
  }
  
  public void q() {
    this.a.j.S();
  }
  
  public void r() {
    this.a.j.U();
  }
  
  public boolean s() {
    return this.a.j.b0(true);
  }
  
  public m t() {
    return this.a.j;
  }
  
  public void u() {
    this.a.j.R0();
  }
  
  public View v(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.a.j.v0().onCreateView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void w(Parcelable paramParcelable) {
    j<?> j1 = this.a;
    if (j1 instanceof androidx.lifecycle.i0) {
      j1.j.f1(paramParcelable);
      return;
    } 
    throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
  }
  
  public Parcelable x() {
    return this.a.j.h1();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */