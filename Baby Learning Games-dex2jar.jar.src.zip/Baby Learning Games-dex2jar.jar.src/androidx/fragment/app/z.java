package androidx.fragment.app;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import androidx.lifecycle.c0;
import androidx.lifecycle.f0;
import androidx.lifecycle.h0;
import androidx.lifecycle.i;
import androidx.lifecycle.i0;
import androidx.lifecycle.j;
import androidx.lifecycle.q;
import androidx.lifecycle.r;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.b;
import androidx.savedstate.c;

class z implements i, c, i0 {
  private final Fragment f;
  
  private final h0 g;
  
  private f0.b h;
  
  private r i = null;
  
  private b j = null;
  
  z(Fragment paramFragment, h0 paramh0) {
    this.f = paramFragment;
    this.g = paramh0;
  }
  
  public j a() {
    e();
    return (j)this.i;
  }
  
  public SavedStateRegistry c() {
    e();
    return this.j.b();
  }
  
  void d(j.b paramb) {
    this.i.h(paramb);
  }
  
  void e() {
    if (this.i == null) {
      this.i = new r((q)this);
      this.j = b.a(this);
    } 
  }
  
  boolean f() {
    return (this.i != null);
  }
  
  void g(Bundle paramBundle) {
    this.j.c(paramBundle);
  }
  
  public f0.b h() {
    f0.b b1 = this.f.h();
    if (!b1.equals(this.f.a0)) {
      this.h = b1;
      return b1;
    } 
    if (this.h == null) {
      Application application1;
      Application application2 = null;
      Context context = this.f.m1().getApplicationContext();
      while (true) {
        application1 = application2;
        if (context instanceof ContextWrapper) {
          if (context instanceof Application) {
            application1 = (Application)context;
            break;
          } 
          context = ((ContextWrapper)context).getBaseContext();
          continue;
        } 
        break;
      } 
      this.h = (f0.b)new c0(application1, this, this.f.p());
    } 
    return this.h;
  }
  
  void i(Bundle paramBundle) {
    this.j.d(paramBundle);
  }
  
  void j(j.c paramc) {
    this.i.o(paramc);
  }
  
  public h0 k() {
    e();
    return this.g;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */