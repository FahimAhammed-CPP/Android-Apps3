package androidx.fragment.app;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.core.view.w;
import androidx.lifecycle.j;

class t {
  private final l a;
  
  private final u b;
  
  private final Fragment c;
  
  private boolean d = false;
  
  private int e = -1;
  
  t(l paraml, u paramu, Fragment paramFragment) {
    this.a = paraml;
    this.b = paramu;
    this.c = paramFragment;
  }
  
  t(l paraml, u paramu, Fragment paramFragment, s params) {
    this.a = paraml;
    this.b = paramu;
    this.c = paramFragment;
    paramFragment.h = null;
    paramFragment.i = null;
    paramFragment.w = 0;
    paramFragment.t = false;
    paramFragment.q = false;
    Fragment fragment = paramFragment.m;
    if (fragment != null) {
      String str = fragment.k;
    } else {
      fragment = null;
    } 
    paramFragment.n = (String)fragment;
    paramFragment.m = null;
    Bundle bundle = params.r;
    if (bundle != null) {
      paramFragment.g = bundle;
      return;
    } 
    paramFragment.g = new Bundle();
  }
  
  t(l paraml, u paramu, ClassLoader paramClassLoader, i parami, s params) {
    this.a = paraml;
    this.b = paramu;
    Fragment fragment = parami.a(paramClassLoader, params.f);
    this.c = fragment;
    Bundle bundle = params.o;
    if (bundle != null)
      bundle.setClassLoader(paramClassLoader); 
    fragment.v1(params.o);
    fragment.k = params.g;
    fragment.s = params.h;
    fragment.u = true;
    fragment.B = params.i;
    fragment.C = params.j;
    fragment.D = params.k;
    fragment.G = params.l;
    fragment.r = params.m;
    fragment.F = params.n;
    fragment.E = params.p;
    fragment.W = j.c.values()[params.q];
    bundle = params.r;
    if (bundle != null) {
      fragment.g = bundle;
    } else {
      fragment.g = new Bundle();
    } 
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Instantiated fragment ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  private boolean l(View paramView) {
    if (paramView == this.c.M)
      return true; 
    for (ViewParent viewParent = paramView.getParent(); viewParent != null; viewParent = viewParent.getParent()) {
      if (viewParent == this.c.M)
        return true; 
    } 
    return false;
  }
  
  private Bundle q() {
    Bundle bundle2 = new Bundle();
    this.c.h1(bundle2);
    this.a.j(this.c, bundle2, false);
    Bundle bundle1 = bundle2;
    if (bundle2.isEmpty())
      bundle1 = null; 
    if (this.c.M != null)
      s(); 
    bundle2 = bundle1;
    if (this.c.h != null) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putSparseParcelableArray("android:view_state", this.c.h);
    } 
    bundle1 = bundle2;
    if (this.c.i != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putBundle("android:view_registry_state", this.c.i);
    } 
    bundle2 = bundle1;
    if (!this.c.O) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", this.c.O);
    } 
    return bundle2;
  }
  
  void a() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto ACTIVITY_CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment1 = this.c;
    fragment1.N0(fragment1.g);
    l l1 = this.a;
    Fragment fragment2 = this.c;
    l1.a(fragment2, fragment2.g, false);
  }
  
  void b() {
    int i = this.b.j(this.c);
    Fragment fragment = this.c;
    fragment.L.addView(fragment.M, i);
  }
  
  void c() {
    StringBuilder stringBuilder;
    if (m.G0(3)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("moveto ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    Fragment fragment3 = fragment2.m;
    t t1 = null;
    if (fragment3 != null) {
      t1 = this.b.m(fragment3.k);
      if (t1 != null) {
        fragment2 = this.c;
        fragment2.n = fragment2.m.k;
        fragment2.m = null;
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" declared target fragment ");
        stringBuilder.append(this.c.m);
        stringBuilder.append(" that does not belong to this FragmentManager!");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      String str = fragment2.n;
      if (str != null) {
        t1 = this.b.m(str);
        if (t1 == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" declared target fragment ");
          stringBuilder.append(this.c.n);
          stringBuilder.append(" that does not belong to this FragmentManager!");
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
    } 
    if (stringBuilder != null && (m.P || (stringBuilder.k()).f < 1))
      stringBuilder.m(); 
    Fragment fragment1 = this.c;
    fragment1.y = fragment1.x.u0();
    fragment1 = this.c;
    fragment1.A = fragment1.x.x0();
    this.a.g(this.c, false);
    this.c.O0();
    this.a.b(this.c, false);
  }
  
  int d() {
    b0.e.b b;
    Fragment fragment2 = this.c;
    if (fragment2.x == null)
      return fragment2.f; 
    int j = this.e;
    int k = b.a[fragment2.W.ordinal()];
    int i = j;
    if (k != 1)
      if (k != 2) {
        if (k != 3) {
          if (k != 4) {
            i = Math.min(j, -1);
          } else {
            i = Math.min(j, 0);
          } 
        } else {
          i = Math.min(j, 1);
        } 
      } else {
        i = Math.min(j, 5);
      }  
    fragment2 = this.c;
    j = i;
    if (fragment2.s) {
      View view;
      if (fragment2.t) {
        i = Math.max(this.e, 2);
        view = this.c.M;
        j = i;
        if (view != null) {
          j = i;
          if (view.getParent() == null)
            j = Math.min(i, 2); 
        } 
      } else if (this.e < 4) {
        j = Math.min(i, ((Fragment)view).f);
      } else {
        j = Math.min(i, 1);
      } 
    } 
    k = j;
    if (!this.c.q)
      k = Math.min(j, 1); 
    Fragment fragment3 = null;
    fragment2 = fragment3;
    if (m.P) {
      Fragment fragment = this.c;
      ViewGroup viewGroup = fragment.L;
      fragment2 = fragment3;
      if (viewGroup != null)
        b = b0.n(viewGroup, fragment.F()).l(this); 
    } 
    if (b == b0.e.b.g) {
      i = Math.min(k, 6);
    } else if (b == b0.e.b.h) {
      i = Math.max(k, 3);
    } else {
      Fragment fragment = this.c;
      i = k;
      if (fragment.r)
        if (fragment.Z()) {
          i = Math.min(k, 1);
        } else {
          i = Math.min(k, -1);
        }  
    } 
    Fragment fragment1 = this.c;
    j = i;
    if (fragment1.N) {
      j = i;
      if (fragment1.f < 5)
        j = Math.min(i, 4); 
    } 
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("computeExpectedState() of ");
      stringBuilder.append(j);
      stringBuilder.append(" for ");
      stringBuilder.append(this.c);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    return j;
  }
  
  void e() {
    l l1;
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    if (!fragment.V) {
      this.a.h(fragment, fragment.g, false);
      fragment = this.c;
      fragment.R0(fragment.g);
      l1 = this.a;
      Fragment fragment1 = this.c;
      l1.c(fragment1, fragment1.g, false);
      return;
    } 
    l1.p1(((Fragment)l1).g);
    this.c.f = 1;
  }
  
  void f() {
    StringBuilder stringBuilder;
    if (this.c.s)
      return; 
    if (m.G0(3)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("moveto CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment1 = this.c;
    LayoutInflater layoutInflater = fragment1.X0(fragment1.g);
    fragment1 = null;
    Fragment fragment3 = this.c;
    ViewGroup viewGroup = fragment3.L;
    if (viewGroup != null) {
      ViewGroup viewGroup1 = viewGroup;
    } else {
      int i = fragment3.C;
      if (i != 0)
        if (i != -1) {
          viewGroup = (ViewGroup)fragment3.x.p0().f(this.c.C);
          ViewGroup viewGroup1 = viewGroup;
          if (viewGroup == null) {
            ViewGroup viewGroup2;
            Fragment fragment = this.c;
            if (fragment.u) {
              viewGroup2 = viewGroup;
            } else {
              String str;
              try {
                str = viewGroup2.L().getResourceName(this.c.C);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                str = "unknown";
              } 
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("No view found for id 0x");
              stringBuilder1.append(Integer.toHexString(this.c.C));
              stringBuilder1.append(" (");
              stringBuilder1.append(str);
              stringBuilder1.append(") for fragment ");
              stringBuilder1.append(this.c);
              throw new IllegalArgumentException(stringBuilder1.toString());
            } 
          } 
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot create fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" for a container view with no id");
          throw new IllegalArgumentException(stringBuilder.toString());
        }  
    } 
    Fragment fragment2 = this.c;
    fragment2.L = (ViewGroup)stringBuilder;
    fragment2.T0(layoutInflater, (ViewGroup)stringBuilder, fragment2.g);
    View view = this.c.M;
    if (view != null) {
      boolean bool = false;
      view.setSaveFromParentEnabled(false);
      Fragment fragment5 = this.c;
      fragment5.M.setTag(u0.b.a, fragment5);
      if (stringBuilder != null)
        b(); 
      Fragment fragment4 = this.c;
      if (fragment4.E)
        fragment4.M.setVisibility(8); 
      if (w.R(this.c.M)) {
        w.l0(this.c.M);
      } else {
        View view1 = this.c.M;
        view1.addOnAttachStateChangeListener(new a(this, view1));
      } 
      this.c.k1();
      l l1 = this.a;
      fragment5 = this.c;
      l1.m(fragment5, fragment5.M, fragment5.g, false);
      int i = this.c.M.getVisibility();
      float f = this.c.M.getAlpha();
      if (m.P) {
        this.c.B1(f);
        Fragment fragment = this.c;
        if (fragment.L != null && i == 0) {
          View view1 = fragment.M.findFocus();
          if (view1 != null) {
            this.c.w1(view1);
            if (m.G0(2)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("requestFocus: Saved focused view ");
              stringBuilder1.append(view1);
              stringBuilder1.append(" for Fragment ");
              stringBuilder1.append(this.c);
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
          } 
          this.c.M.setAlpha(0.0F);
        } 
      } else {
        Fragment fragment = this.c;
        boolean bool1 = bool;
        if (i == 0) {
          bool1 = bool;
          if (fragment.L != null)
            bool1 = true; 
        } 
        fragment.R = bool1;
      } 
    } 
    this.c.f = 2;
  }
  
  void g() {
    boolean bool1;
    boolean bool2;
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    boolean bool4 = fragment.r;
    boolean bool3 = true;
    if (bool4 && !fragment.Z()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1 || this.b.o().p(this.c)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2) {
      int i;
      j<?> j = this.c.y;
      if (j instanceof androidx.lifecycle.i0) {
        bool3 = this.b.o().m();
      } else if (j.j() instanceof Activity) {
        i = true ^ ((Activity)j.j()).isChangingConfigurations();
      } 
      if (bool1 || i != 0)
        this.b.o().g(this.c); 
      this.c.U0();
      this.a.d(this.c, false);
      for (t t1 : this.b.k()) {
        if (t1 != null) {
          Fragment fragment2 = t1.k();
          if (this.c.k.equals(fragment2.n)) {
            fragment2.m = this.c;
            fragment2.n = null;
          } 
        } 
      } 
      Fragment fragment1 = this.c;
      String str1 = fragment1.n;
      if (str1 != null)
        fragment1.m = this.b.f(str1); 
      this.b.q(this);
      return;
    } 
    String str = this.c.n;
    if (str != null) {
      Fragment fragment1 = this.b.f(str);
      if (fragment1 != null && fragment1.G)
        this.c.m = fragment1; 
    } 
    this.c.f = 0;
  }
  
  void h() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    ViewGroup viewGroup = fragment2.L;
    if (viewGroup != null) {
      View view = fragment2.M;
      if (view != null)
        viewGroup.removeView(view); 
    } 
    this.c.V0();
    this.a.n(this.c, false);
    Fragment fragment1 = this.c;
    fragment1.L = null;
    fragment1.M = null;
    fragment1.Y = null;
    fragment1.Z.m(null);
    this.c.t = false;
  }
  
  void i() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.W0();
    l l1 = this.a;
    Fragment fragment2 = this.c;
    boolean bool2 = false;
    l1.e(fragment2, false);
    Fragment fragment1 = this.c;
    fragment1.f = -1;
    fragment1.y = null;
    fragment1.A = null;
    fragment1.x = null;
    boolean bool1 = bool2;
    if (fragment1.r) {
      bool1 = bool2;
      if (!fragment1.Z())
        bool1 = true; 
    } 
    if (bool1 || this.b.o().p(this.c)) {
      if (m.G0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("initState called for fragment: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      this.c.W();
    } 
  }
  
  void j() {
    Fragment fragment = this.c;
    if (fragment.s && fragment.t && !fragment.v) {
      if (m.G0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("moveto CREATE_VIEW: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      fragment = this.c;
      fragment.T0(fragment.X0(fragment.g), null, this.c.g);
      View view = this.c.M;
      if (view != null) {
        view.setSaveFromParentEnabled(false);
        Fragment fragment1 = this.c;
        fragment1.M.setTag(u0.b.a, fragment1);
        fragment1 = this.c;
        if (fragment1.E)
          fragment1.M.setVisibility(8); 
        this.c.k1();
        l l1 = this.a;
        Fragment fragment2 = this.c;
        l1.m(fragment2, fragment2.M, fragment2.g, false);
        this.c.f = 2;
      } 
    } 
  }
  
  Fragment k() {
    return this.c;
  }
  
  void m() {
    if (this.d) {
      if (m.G0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring re-entrant call to moveToExpectedState() for ");
        stringBuilder.append(k());
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    try {
      this.d = true;
      while (true) {
        int i = d();
        Fragment fragment = this.c;
        int j = fragment.f;
        if (i != j) {
          if (i > j) {
            switch (j + 1) {
              case 7:
                p();
                continue;
              case 6:
                fragment.f = 6;
                continue;
              case 5:
                u();
                continue;
              case 4:
                if (fragment.M != null) {
                  ViewGroup viewGroup = fragment.L;
                  if (viewGroup != null)
                    b0.n(viewGroup, fragment.F()).b(b0.e.c.d(this.c.M.getVisibility()), this); 
                } 
                this.c.f = 4;
                continue;
              case 3:
                a();
                continue;
              case 2:
                j();
                f();
                continue;
              case 1:
                e();
                continue;
              case 0:
                c();
                continue;
            } 
            continue;
          } 
        } else {
          if (m.P && fragment.S) {
            if (fragment.M != null) {
              ViewGroup viewGroup = fragment.L;
              if (viewGroup != null) {
                b0 b0 = b0.n(viewGroup, fragment.F());
                if (this.c.E) {
                  b0.c(this);
                } else {
                  b0.e(this);
                } 
              } 
            } 
            fragment = this.c;
            m m = fragment.x;
            if (m != null)
              m.E0(fragment); 
            fragment = this.c;
            fragment.S = false;
            fragment.w0(fragment.E);
          } 
          return;
        } 
        switch (j - 1) {
          case 6:
            n();
          case 5:
            fragment.f = 5;
          case 4:
            v();
          case 3:
            if (m.G0(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom ACTIVITY_CREATED: ");
              stringBuilder.append(this.c);
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            fragment = this.c;
            if (fragment.M != null && fragment.h == null)
              s(); 
            fragment = this.c;
            if (fragment.M != null) {
              ViewGroup viewGroup = fragment.L;
              if (viewGroup != null)
                b0.n(viewGroup, fragment.F()).d(this); 
            } 
            this.c.f = 3;
          case 2:
            fragment.t = false;
            fragment.f = 2;
          case 1:
            h();
            this.c.f = 1;
          case 0:
            g();
          case -1:
            i();
        } 
      } 
    } finally {
      this.d = false;
    } 
  }
  
  void n() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.c1();
    this.a.f(this.c, false);
  }
  
  void o(ClassLoader paramClassLoader) {
    Bundle bundle = this.c.g;
    if (bundle == null)
      return; 
    bundle.setClassLoader(paramClassLoader);
    Fragment fragment = this.c;
    fragment.h = fragment.g.getSparseParcelableArray("android:view_state");
    fragment = this.c;
    fragment.i = fragment.g.getBundle("android:view_registry_state");
    fragment = this.c;
    fragment.n = fragment.g.getString("android:target_state");
    fragment = this.c;
    if (fragment.n != null)
      fragment.o = fragment.g.getInt("android:target_req_state", 0); 
    fragment = this.c;
    Boolean bool = fragment.j;
    if (bool != null) {
      fragment.O = bool.booleanValue();
      this.c.j = null;
    } else {
      fragment.O = fragment.g.getBoolean("android:user_visible_hint", true);
    } 
    fragment = this.c;
    if (!fragment.O)
      fragment.N = true; 
  }
  
  void p() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    View view = this.c.y();
    if (view != null && l(view)) {
      boolean bool = view.requestFocus();
      if (m.G0(2)) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("requestFocus: Restoring focused view ");
        stringBuilder.append(view);
        stringBuilder.append(" ");
        if (bool) {
          str = "succeeded";
        } else {
          str = "failed";
        } 
        stringBuilder.append(str);
        stringBuilder.append(" on Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" resulting in focused view ");
        stringBuilder.append(this.c.M.findFocus());
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    this.c.w1(null);
    this.c.g1();
    this.a.i(this.c, false);
    Fragment fragment = this.c;
    fragment.g = null;
    fragment.h = null;
    fragment.i = null;
  }
  
  s r() {
    Bundle bundle;
    s s = new s(this.c);
    Fragment fragment = this.c;
    if (fragment.f > -1 && s.r == null) {
      bundle = q();
      s.r = bundle;
      if (this.c.n != null) {
        if (bundle == null)
          s.r = new Bundle(); 
        s.r.putString("android:target_state", this.c.n);
        int i = this.c.o;
        if (i != 0) {
          s.r.putInt("android:target_req_state", i);
          return s;
        } 
      } 
    } else {
      s.r = ((Fragment)bundle).g;
    } 
    return s;
  }
  
  void s() {
    if (this.c.M == null)
      return; 
    SparseArray<Parcelable> sparseArray = new SparseArray();
    this.c.M.saveHierarchyState(sparseArray);
    if (sparseArray.size() > 0)
      this.c.h = sparseArray; 
    Bundle bundle = new Bundle();
    this.c.Y.i(bundle);
    if (!bundle.isEmpty())
      this.c.i = bundle; 
  }
  
  void t(int paramInt) {
    this.e = paramInt;
  }
  
  void u() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.i1();
    this.a.k(this.c, false);
  }
  
  void v() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.j1();
    this.a.l(this.c, false);
  }
  
  class a implements View.OnAttachStateChangeListener {
    a(t this$0, View param1View) {}
    
    public void onViewAttachedToWindow(View param1View) {
      this.f.removeOnAttachStateChangeListener(this);
      w.l0(this.f);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */