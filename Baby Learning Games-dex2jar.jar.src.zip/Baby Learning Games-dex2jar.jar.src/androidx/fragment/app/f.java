package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import androidx.core.view.u;

class f {
  static void a(Fragment paramFragment, d paramd, w.g paramg) {
    e e;
    View view = paramFragment.M;
    ViewGroup viewGroup = paramFragment.L;
    viewGroup.startViewTransition(view);
    h0.b b = new h0.b();
    b.c(new a(paramFragment));
    paramg.b(paramFragment, b);
    if (paramd.a != null) {
      e = new e(paramd.a, viewGroup, view);
      paramFragment.s1(paramFragment.M);
      e.setAnimationListener(new b(viewGroup, paramFragment, paramg, b));
      paramFragment.M.startAnimation((Animation)e);
      return;
    } 
    Animator animator = ((d)e).b;
    paramFragment.u1(animator);
    animator.addListener((Animator.AnimatorListener)new c(viewGroup, view, paramFragment, paramg, b));
    animator.setTarget(paramFragment.M);
    animator.start();
  }
  
  private static int b(Fragment paramFragment, boolean paramBoolean1, boolean paramBoolean2) {
    return paramBoolean2 ? (paramBoolean1 ? paramFragment.H() : paramFragment.I()) : (paramBoolean1 ? paramFragment.s() : paramFragment.v());
  }
  
  static d c(Context paramContext, Fragment paramFragment, boolean paramBoolean1, boolean paramBoolean2) {
    int k = paramFragment.D();
    int j = b(paramFragment, paramBoolean1, paramBoolean2);
    boolean bool = false;
    paramFragment.t1(0, 0, 0, 0);
    ViewGroup viewGroup = paramFragment.L;
    if (viewGroup != null) {
      int m = u0.b.c;
      if (viewGroup.getTag(m) != null)
        paramFragment.L.setTag(m, null); 
    } 
    viewGroup = paramFragment.L;
    if (viewGroup != null && viewGroup.getLayoutTransition() != null)
      return null; 
    Animation animation = paramFragment.n0(k, paramBoolean1, j);
    if (animation != null)
      return new d(animation); 
    Animator animator = paramFragment.o0(k, paramBoolean1, j);
    if (animator != null)
      return new d(animator); 
    int i = j;
    if (j == 0) {
      i = j;
      if (k != 0)
        i = d(k, paramBoolean1); 
    } 
    if (i != 0) {
      paramBoolean1 = "anim".equals(paramContext.getResources().getResourceTypeName(i));
      j = bool;
      if (paramBoolean1)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(paramContext, i);
          if (animation1 != null)
            return new d(animation1); 
          j = 1;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          j = bool;
        }  
      if (j == 0)
        try {
          animator = AnimatorInflater.loadAnimator((Context)notFoundException, i);
          if (animator != null)
            return new d(animator); 
        } catch (RuntimeException runtimeException) {
          if (!paramBoolean1) {
            Animation animation1 = AnimationUtils.loadAnimation((Context)notFoundException, i);
            if (animation1 != null)
              return new d(animation1); 
          } else {
            throw runtimeException;
          } 
        }  
    } 
    return null;
  }
  
  private static int d(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? u0.a.a : u0.a.b)) : (paramBoolean ? u0.a.c : u0.a.d)) : (paramBoolean ? u0.a.e : u0.a.f);
  }
  
  class a implements h0.b.a {
    a(f this$0) {}
    
    public void a() {
      if (this.a.n() != null) {
        View view = this.a.n();
        this.a.s1(null);
        view.clearAnimation();
      } 
      this.a.u1(null);
    }
  }
  
  class b implements Animation.AnimationListener {
    b(f this$0, Fragment param1Fragment, w.g param1g, h0.b param1b) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      this.a.post(new a(this));
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
    
    class a implements Runnable {
      a(f.b this$0) {}
      
      public void run() {
        if (this.f.b.n() != null) {
          this.f.b.s1(null);
          f.b b1 = this.f;
          b1.c.a(b1.b, b1.d);
        } 
      }
    }
  }
  
  class a implements Runnable {
    a(f this$0) {}
    
    public void run() {
      if (this.f.b.n() != null) {
        this.f.b.s1(null);
        f.b b1 = this.f;
        b1.c.a(b1.b, b1.d);
      } 
    }
  }
  
  class c extends AnimatorListenerAdapter {
    c(f this$0, View param1View, Fragment param1Fragment, w.g param1g, h0.b param1b) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator = this.c.o();
      this.c.u1(null);
      if (param1Animator != null && this.a.indexOfChild(this.b) < 0)
        this.d.a(this.c, this.e); 
    }
  }
  
  static class d {
    public final Animation a = null;
    
    public final Animator b;
    
    d(Animator param1Animator) {
      this.b = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    d(Animation param1Animation) {
      this.b = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  static class e extends AnimationSet implements Runnable {
    private final ViewGroup f;
    
    private final View g;
    
    private boolean h;
    
    private boolean i;
    
    private boolean j = true;
    
    e(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.f = param1ViewGroup;
      this.g = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.j = true;
      if (this.h)
        return this.i ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.h = true;
        u.a((View)this.f, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.j = true;
      if (this.h)
        return this.i ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.h = true;
        u.a((View)this.f, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.h && this.j) {
        this.j = false;
        this.f.post(this);
        return;
      } 
      this.f.endViewTransition(this.g);
      this.i = true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */