package androidx.fragment.app;

public interface q {
  void d(m paramm, Fragment paramFragment);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */