package androidx.fragment.app;

import android.os.Bundle;
import android.view.View;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

class l {
  private final CopyOnWriteArrayList<a> a = new CopyOnWriteArrayList<a>();
  
  private final m b;
  
  l(m paramm) {
    this.b = paramm;
  }
  
  void a(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().a(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void b(Fragment paramFragment, boolean paramBoolean) {
    this.b.u0().j();
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().b(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void c(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().c(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void d(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().d(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void e(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().e(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void f(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().f(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void g(Fragment paramFragment, boolean paramBoolean) {
    this.b.u0().j();
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().g(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void h(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().h(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void i(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().i(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void j(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().j(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void k(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().k(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void l(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().l(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void m(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().m(paramFragment, paramView, paramBundle, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  void n(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.x0();
    if (fragment != null)
      fragment.F().w0().n(paramFragment, true); 
    for (a a : this.a) {
      if (paramBoolean && !a.a)
        continue; 
      Objects.requireNonNull(a);
      throw null;
    } 
  }
  
  private static final class a {
    final boolean a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */