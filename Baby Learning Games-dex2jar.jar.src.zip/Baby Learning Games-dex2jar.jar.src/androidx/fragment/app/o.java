package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
final class o implements Parcelable {
  public static final Parcelable.Creator<o> CREATOR = new a();
  
  ArrayList<s> f;
  
  ArrayList<String> g;
  
  b[] h;
  
  int i;
  
  String j = null;
  
  ArrayList<String> k = new ArrayList<String>();
  
  ArrayList<Bundle> l = new ArrayList<Bundle>();
  
  ArrayList<m.m> m;
  
  public o() {}
  
  public o(Parcel paramParcel) {
    this.f = paramParcel.createTypedArrayList(s.CREATOR);
    this.g = paramParcel.createStringArrayList();
    this.h = (b[])paramParcel.createTypedArray(b.CREATOR);
    this.i = paramParcel.readInt();
    this.j = paramParcel.readString();
    this.k = paramParcel.createStringArrayList();
    this.l = paramParcel.createTypedArrayList(Bundle.CREATOR);
    this.m = paramParcel.createTypedArrayList(m.m.CREATOR);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeTypedList(this.f);
    paramParcel.writeStringList(this.g);
    paramParcel.writeTypedArray((Parcelable[])this.h, paramInt);
    paramParcel.writeInt(this.i);
    paramParcel.writeString(this.j);
    paramParcel.writeStringList(this.k);
    paramParcel.writeTypedList(this.l);
    paramParcel.writeTypedList(this.m);
  }
  
  class a implements Parcelable.Creator<o> {
    public o a(Parcel param1Parcel) {
      return new o(param1Parcel);
    }
    
    public o[] b(int param1Int) {
      return new o[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */