package androidx.fragment.app;

import android.util.Log;
import java.io.PrintWriter;
import java.util.ArrayList;

final class a extends v implements m.k, m.o {
  final m t;
  
  boolean u;
  
  int v;
  
  a(m paramm) {
    super(i, classLoader);
    ClassLoader classLoader;
    this.v = -1;
    this.t = paramm;
  }
  
  private static boolean D(v.a parama) {
    Fragment fragment = parama.b;
    return (fragment != null && fragment.q && fragment.M != null && !fragment.F && !fragment.E && fragment.b0());
  }
  
  Fragment A(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = 0;
    Fragment fragment;
    for (fragment = paramFragment; i < this.c.size(); fragment = paramFragment) {
      Fragment fragment1;
      v.a a1 = this.c.get(i);
      int j = a1.a;
      if (j != 1)
        if (j != 2) {
          if (j != 3 && j != 6) {
            if (j != 7) {
              if (j != 8) {
                paramFragment = fragment;
                j = i;
              } else {
                this.c.add(i, new v.a(9, fragment));
                j = i + 1;
                paramFragment = a1.b;
              } 
              continue;
            } 
          } else {
            paramArrayList.remove(a1.b);
            fragment1 = a1.b;
            paramFragment = fragment;
            j = i;
            if (fragment1 == fragment) {
              this.c.add(i, new v.a(9, fragment1));
              j = i + 1;
              paramFragment = null;
            } 
            continue;
          } 
        } else {
          Fragment fragment2 = ((v.a)fragment1).b;
          int i1 = fragment2.C;
          int n = paramArrayList.size() - 1;
          boolean bool = false;
          j = i;
          paramFragment = fragment;
          while (n >= 0) {
            Fragment fragment3 = paramArrayList.get(n);
            fragment = paramFragment;
            i = j;
            boolean bool1 = bool;
            if (fragment3.C == i1)
              if (fragment3 == fragment2) {
                bool1 = true;
                fragment = paramFragment;
                i = j;
              } else {
                fragment = paramFragment;
                i = j;
                if (fragment3 == paramFragment) {
                  this.c.add(j, new v.a(9, fragment3));
                  i = j + 1;
                  fragment = null;
                } 
                v.a a2 = new v.a(3, fragment3);
                a2.c = ((v.a)fragment1).c;
                a2.e = ((v.a)fragment1).e;
                a2.d = ((v.a)fragment1).d;
                a2.f = ((v.a)fragment1).f;
                this.c.add(i, a2);
                paramArrayList.remove(fragment3);
                i++;
                bool1 = bool;
              }  
            n--;
            paramFragment = fragment;
            j = i;
            bool = bool1;
          } 
          if (bool) {
            this.c.remove(j);
            j--;
          } else {
            ((v.a)fragment1).a = 1;
            paramArrayList.add(fragment2);
          } 
          continue;
        }  
      paramArrayList.add(((v.a)fragment1).b);
      j = i;
      paramFragment = fragment;
      continue;
      i = SYNTHETIC_LOCAL_VARIABLE_3 + 1;
    } 
    return fragment;
  }
  
  boolean B(int paramInt) {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      int n;
      Fragment fragment = ((v.a)this.c.get(i)).b;
      if (fragment != null) {
        n = fragment.C;
      } else {
        n = 0;
      } 
      if (n && n == paramInt)
        return true; 
    } 
    return false;
  }
  
  boolean C(ArrayList<a> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int n = this.c.size();
    int j = -1;
    int i = 0;
    while (i < n) {
      int i1;
      Fragment fragment = ((v.a)this.c.get(i)).b;
      if (fragment != null) {
        i1 = fragment.C;
      } else {
        i1 = 0;
      } 
      int i2 = j;
      if (i1) {
        i2 = j;
        if (i1 != j) {
          for (j = paramInt1; j < paramInt2; j++) {
            a a1 = paramArrayList.get(j);
            int i3 = a1.c.size();
            for (i2 = 0; i2 < i3; i2++) {
              int i4;
              Fragment fragment1 = ((v.a)a1.c.get(i2)).b;
              if (fragment1 != null) {
                i4 = fragment1.C;
              } else {
                i4 = 0;
              } 
              if (i4 == i1)
                return true; 
            } 
          } 
          i2 = i1;
        } 
      } 
      i++;
      j = i2;
    } 
    return false;
  }
  
  boolean E() {
    for (int i = 0; i < this.c.size(); i++) {
      if (D(this.c.get(i)))
        return true; 
    } 
    return false;
  }
  
  public void F() {
    if (this.s != null) {
      for (int i = 0; i < this.s.size(); i++)
        ((Runnable)this.s.get(i)).run(); 
      this.s = null;
    } 
  }
  
  void G(Fragment.h paramh) {
    for (int i = 0; i < this.c.size(); i++) {
      v.a a1 = this.c.get(i);
      if (D(a1))
        a1.b.z1(paramh); 
    } 
  }
  
  Fragment H(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = this.c.size() - 1;
    while (i >= 0) {
      v.a a1 = this.c.get(i);
      int j = a1.a;
      if (j != 1)
        if (j != 3) {
          switch (j) {
            case 10:
              a1.h = a1.g;
              break;
            case 9:
              paramFragment = a1.b;
              break;
            case 8:
              paramFragment = null;
              break;
            case 6:
              paramArrayList.add(a1.b);
              break;
            case 7:
              paramArrayList.remove(a1.b);
              break;
          } 
          i--;
        }  
    } 
    return paramFragment;
  }
  
  public String a() {
    return this.k;
  }
  
  public boolean b(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.FALSE);
    if (this.i)
      this.t.e(this); 
    return true;
  }
  
  public int i() {
    return v(false);
  }
  
  public int j() {
    return v(true);
  }
  
  public void k() {
    m();
    this.t.c0(this, false);
  }
  
  public void l() {
    m();
    this.t.c0(this, true);
  }
  
  void n(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    super.n(paramInt1, paramFragment, paramString, paramInt2);
    paramFragment.x = this.t;
  }
  
  public v o(Fragment paramFragment) {
    m m1 = paramFragment.x;
    if (m1 == null || m1 == this.t)
      return super.o(paramFragment); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
    stringBuilder.append(paramFragment.toString());
    stringBuilder.append(" is already attached to a FragmentManager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public v s(Fragment paramFragment) {
    if (paramFragment != null) {
      m m1 = paramFragment.x;
      if (m1 != null && m1 != this.t) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot setPrimaryNavigation for Fragment attached to a different FragmentManager. Fragment ");
        stringBuilder.append(paramFragment.toString());
        stringBuilder.append(" is already attached to a FragmentManager.");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
    return super.s(paramFragment);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.v >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.v);
    } 
    if (this.k != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.k);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  void u(int paramInt) {
    if (!this.i)
      return; 
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      v.a a1 = this.c.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.w += paramInt;
        if (m.G0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(a1.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a1.b.w);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  int v(boolean paramBoolean) {
    if (!this.u) {
      if (m.G0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter(new a0("FragmentManager"));
        w("  ", printWriter);
        printWriter.close();
      } 
      this.u = true;
      if (this.i) {
        this.v = this.t.j();
      } else {
        this.v = -1;
      } 
      this.t.Z(this, paramBoolean);
      return this.v;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public void w(String paramString, PrintWriter paramPrintWriter) {
    x(paramString, paramPrintWriter, true);
  }
  
  public void x(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.k);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.v);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.u);
      if (this.h != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.h));
      } 
      if (this.d != 0 || this.e != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.d));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.e));
      } 
      if (this.f != 0 || this.g != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.f));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.g));
      } 
      if (this.l != 0 || this.m != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.l));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.m);
      } 
      if (this.n != 0 || this.o != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.n));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.o);
      } 
    } 
    if (!this.c.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      int j = this.c.size();
      int i;
      for (i = 0; i < j; i++) {
        StringBuilder stringBuilder;
        String str;
        v.a a1 = this.c.get(i);
        switch (a1.a) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("cmd=");
            stringBuilder.append(a1.a);
            str = stringBuilder.toString();
            break;
          case 10:
            str = "OP_SET_MAX_LIFECYCLE";
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(i);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a1.b);
        if (paramBoolean) {
          if (a1.c != 0 || a1.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.d));
          } 
          if (a1.e != 0 || a1.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.f));
          } 
        } 
      } 
    } 
  }
  
  void y() {
    int j = this.c.size();
    for (int i = 0; i < j; i++) {
      StringBuilder stringBuilder;
      v.a a1 = this.c.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.A1(false);
        fragment.y1(this.h);
        fragment.C1(this.p, this.q);
      } 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.t.k1((Fragment)stringBuilder, a1.h);
          break;
        case 9:
          this.t.l1(null);
          break;
        case 8:
          this.t.l1((Fragment)stringBuilder);
          break;
        case 7:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.j1((Fragment)stringBuilder, false);
          this.t.l((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.y((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.j1((Fragment)stringBuilder, false);
          this.t.n1((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.D0((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.b1((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.j1((Fragment)stringBuilder, false);
          this.t.g((Fragment)stringBuilder);
          break;
      } 
      if (!this.r && a1.a != 1 && stringBuilder != null && !m.P)
        this.t.N0((Fragment)stringBuilder); 
    } 
    if (!this.r && !m.P) {
      m m1 = this.t;
      m1.O0(m1.q, true);
    } 
  }
  
  void z(boolean paramBoolean) {
    for (int i = this.c.size() - 1; i >= 0; i--) {
      StringBuilder stringBuilder;
      v.a a1 = this.c.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.A1(true);
        fragment.y1(m.g1(this.h));
        fragment.C1(this.q, this.p);
      } 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.t.k1((Fragment)stringBuilder, a1.g);
          break;
        case 9:
          this.t.l1((Fragment)stringBuilder);
          break;
        case 8:
          this.t.l1(null);
          break;
        case 7:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.j1((Fragment)stringBuilder, true);
          this.t.y((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.l((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.j1((Fragment)stringBuilder, true);
          this.t.D0((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.n1((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.g((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.t1(a1.c, a1.d, a1.e, a1.f);
          this.t.j1((Fragment)stringBuilder, true);
          this.t.b1((Fragment)stringBuilder);
          break;
      } 
      if (!this.r && a1.a != 3 && stringBuilder != null && !m.P)
        this.t.N0((Fragment)stringBuilder); 
    } 
    if (!this.r && paramBoolean && !m.P) {
      m m1 = this.t;
      m1.O0(m1.q, true);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */