package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.core.view.u;
import androidx.core.view.w;
import androidx.core.view.z;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

class c extends b0 {
  c(ViewGroup paramViewGroup) {
    super(paramViewGroup);
  }
  
  private void w(List<k> paramList, List<b0.e> paramList1, boolean paramBoolean, Map<b0.e, Boolean> paramMap) {
    ViewGroup viewGroup = m();
    Context context = viewGroup.getContext();
    ArrayList<k> arrayList = new ArrayList();
    null = paramList.iterator();
    boolean bool;
    for (bool = false; null.hasNext(); bool = true) {
      boolean bool1;
      StringBuilder stringBuilder;
      k k = null.next();
      if (k.d()) {
        k.a();
        continue;
      } 
      f.d d = k.e(context);
      if (d == null) {
        k.a();
        continue;
      } 
      Animator animator = d.b;
      if (animator == null) {
        arrayList.add(k);
        continue;
      } 
      b0.e e = k.b();
      Fragment fragment = e.f();
      if (Boolean.TRUE.equals(paramMap.get(e))) {
        if (m.G0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animator set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as this Fragment was involved in a Transition.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        k.a();
        continue;
      } 
      if (e.e() == b0.e.c.h) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1)
        paramList1.remove(e); 
      View view = fragment.M;
      viewGroup.startViewTransition(view);
      stringBuilder.addListener((Animator.AnimatorListener)new c(this, viewGroup, view, bool1, e, k));
      stringBuilder.setTarget(view);
      stringBuilder.start();
      k.c().c(new d(this, (Animator)stringBuilder));
    } 
    for (k k : arrayList) {
      StringBuilder stringBuilder;
      b0.e e = k.b();
      Fragment fragment = e.f();
      if (paramBoolean) {
        if (m.G0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animation set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as Animations cannot run alongside Transitions.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        k.a();
        continue;
      } 
      if (bool) {
        if (m.G0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animation set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as Animations cannot run alongside Animators.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        k.a();
        continue;
      } 
      View view = fragment.M;
      Animation animation = (Animation)k0.h.f(((f.d)k0.h.f(k.e(context))).a);
      if (stringBuilder.e() != b0.e.c.f) {
        view.startAnimation(animation);
        k.a();
      } else {
        viewGroup.startViewTransition(view);
        f.e e1 = new f.e(animation, viewGroup, view);
        e1.setAnimationListener(new e(this, viewGroup, view, k));
        view.startAnimation((Animation)e1);
      } 
      k.c().c(new f(this, view, viewGroup, k));
    } 
  }
  
  private Map<b0.e, Boolean> x(List<m> paramList, List<b0.e> paramList1, boolean paramBoolean, b0.e parame1, b0.e parame2) {
    StringBuilder stringBuilder;
    b0.e e2 = parame1;
    b0.e e1 = parame2;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<m> iterator1 = paramList.iterator();
    y y1 = null;
    while (iterator1.hasNext()) {
      m m1 = iterator1.next();
      if (m1.d())
        continue; 
      y y = m1.e();
      if (y1 == null) {
        y1 = y;
        continue;
      } 
      if (y == null || y1 == y)
        continue; 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Mixing framework transitions and AndroidX transitions is not allowed. Fragment ");
      stringBuilder.append(m1.b().f());
      stringBuilder.append(" returned Transition ");
      stringBuilder.append(m1.h());
      stringBuilder.append(" which uses a different Transition  type than other Fragments.");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (y1 == null) {
      for (m m : stringBuilder) {
        hashMap.put(m.b(), Boolean.FALSE);
        m.a();
      } 
      return (Map)hashMap;
    } 
    View view = new View(m().getContext());
    Rect rect = new Rect();
    ArrayList<View> arrayList2 = new ArrayList();
    ArrayList<View> arrayList1 = new ArrayList();
    s.a<String, String> a = new s.a();
    Iterator<m> iterator2 = stringBuilder.iterator();
    ArrayList<String> arrayList = null;
    y y3 = null;
    int i = 0;
    y y2 = y1;
    y1 = y3;
    while (true) {
      Object object3;
      View view2;
      b0.e e3;
      b0.e e4;
      Object object4;
      boolean bool = paramBoolean;
      if (iterator2.hasNext()) {
        m m1 = iterator2.next();
        if (m1.i() && e2 != null && e1 != null) {
          Object object = y2.B(y2.g(m1.g()));
          ArrayList<String> arrayList10 = parame2.f().P();
          ArrayList<String> arrayList9 = parame1.f().P();
          arrayList = parame1.f().Q();
          int j;
          for (j = 0; j < arrayList.size(); j++) {
            int n = arrayList10.indexOf(arrayList.get(j));
            if (n != -1)
              arrayList10.set(n, arrayList9.get(j)); 
          } 
          arrayList = parame2.f().Q();
          if (!bool) {
            parame1.f().x();
            parame2.f().u();
          } else {
            parame1.f().u();
            parame2.f().x();
          } 
          j = arrayList10.size();
          int k;
          for (k = 0; k < j; k++)
            a.put(arrayList10.get(k), arrayList.get(k)); 
          s.a<String, View> a2 = new s.a();
          u((Map<String, View>)a2, (parame1.f()).M);
          a2.o(arrayList10);
          a.o(a2.keySet());
          s.a<String, View> a1 = new s.a();
          u((Map<String, View>)a1, (parame2.f()).M);
          a1.o(arrayList);
          a1.o(a.values());
          w.x(a, a1);
          v(a2, a.keySet());
          v(a1, a.values());
          if (a.isEmpty()) {
            arrayList2.clear();
            arrayList1.clear();
            arrayList = null;
            continue;
          } 
          w.f(parame2.f(), parame1.f(), bool, a2, true);
          u.a((View)m(), new g(this, parame2, parame1, paramBoolean, a1));
          arrayList2.addAll(a2.values());
          if (!arrayList10.isEmpty()) {
            view2 = (View)a2.get(arrayList10.get(0));
            y2.v(object, view2);
          } 
          Collection collection = a1.values();
          ArrayList<View> arrayList8 = arrayList1;
          arrayList8.addAll(collection);
          j = i;
          if (!arrayList.isEmpty()) {
            View view4 = (View)a1.get(arrayList.get(0));
            j = i;
            if (view4 != null) {
              u.a((View)m(), new h(this, y2, view4, rect));
              j = 1;
            } 
          } 
          y2.z(object, view, arrayList2);
          y2.t(object, null, null, null, null, object, arrayList8);
          Boolean bool1 = Boolean.TRUE;
          e4 = parame1;
          hashMap.put(e4, bool1);
          e3 = parame2;
          hashMap.put(e3, bool1);
          object4 = object;
          i = j;
        } 
        continue;
      } 
      View view1 = view2;
      ArrayList<View> arrayList4 = arrayList1;
      ArrayList<View> arrayList6 = arrayList2;
      View view3 = view;
      ArrayList<View> arrayList7 = new ArrayList();
      Iterator<m> iterator = stringBuilder.iterator();
      iterator2 = null;
      parame2 = null;
      view = view1;
      b0.e e5 = e3;
      object2 = iterator2;
      ArrayList<View> arrayList5 = arrayList6;
      while (iterator.hasNext()) {
        boolean bool1;
        m m1 = iterator.next();
        if (m1.d()) {
          hashMap.put(m1.b(), Boolean.FALSE);
          m1.a();
          continue;
        } 
        Object object = y2.g(m1.h());
        b0.e e6 = m1.b();
        if (object4 != null && (e6 == e4 || e6 == e5)) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (object == null) {
          if (!bool1) {
            hashMap.put(e6, Boolean.FALSE);
            m1.a();
          } 
          continue;
        } 
        ArrayList<View> arrayList8 = new ArrayList();
        t(arrayList8, (e6.f()).M);
        if (bool1)
          if (e6 == e4) {
            arrayList8.removeAll(arrayList5);
          } else {
            arrayList8.removeAll(arrayList4);
          }  
        if (arrayList8.isEmpty()) {
          y2.a(object, view3);
        } else {
          y2.b(object, arrayList8);
          y2.t(object, object, arrayList8, null, null, null, null);
          if (e6.e() == b0.e.c.h) {
            b0.e e7 = e6;
            m.remove(e7);
            ArrayList<View> arrayList9 = new ArrayList<View>(arrayList8);
            arrayList9.remove((e7.f()).M);
            y2.r(object, (e7.f()).M, arrayList9);
            u.a((View)m(), new i(this, arrayList8));
          } 
        } 
        if (e6.e() == b0.e.c.g) {
          arrayList7.addAll(arrayList8);
          if (i != 0)
            y2.u(object, rect); 
        } else {
          y2.v(object, view);
        } 
        hashMap.put(e6, Boolean.TRUE);
        if (m1.j()) {
          object3 = y2.n(parame2, object, null);
          continue;
        } 
        object2 = y2.n(object2, object, null);
      } 
      Object object1 = y2.m(object3, object2, object4);
      for (Object object2 : stringBuilder) {
        if (object2.d())
          continue; 
        Object object = object2.h();
        object3 = object2.b();
        if (object4 != null && (object3 == e4 || object3 == e5)) {
          i = 1;
        } else {
          i = 0;
        } 
        if (object != null || i != 0) {
          if (!w.S((View)m())) {
            if (m.G0(2)) {
              object = new StringBuilder();
              object.append("SpecialEffectsController: Container ");
              object.append(m());
              object.append(" has not been laid out. Completing operation ");
              object.append(object3);
              Log.v("FragmentManager", object.toString());
            } 
            object2.a();
            continue;
          } 
          y2.w(object2.b().f(), object1, object2.c(), new j(this, (m)object2));
        } 
      } 
      if (!w.S((View)m()))
        return (Map)hashMap; 
      w.A(arrayList7, 4);
      ArrayList<String> arrayList3 = y2.o(arrayList4);
      y2.c(m(), object1);
      y2.y((View)m(), arrayList5, arrayList4, arrayList3, (Map<String, String>)a);
      w.A(arrayList7, 0);
      y2.A(object4, arrayList5, arrayList4);
      return (Map)hashMap;
    } 
  }
  
  void f(List<b0.e> paramList, boolean paramBoolean) {
    Iterator<b0.e> iterator2 = paramList.iterator();
    b0.e e2 = null;
    b0.e e1 = e2;
    while (iterator2.hasNext()) {
      b0.e e = iterator2.next();
      b0.e.c c1 = b0.e.c.e((e.f()).M);
      int i = a.a[e.e().ordinal()];
      if (i != 1 && i != 2 && i != 3) {
        if (i == 4 && c1 != b0.e.c.g)
          e1 = e; 
        continue;
      } 
      if (c1 == b0.e.c.g && e2 == null)
        e2 = e; 
    } 
    ArrayList<k> arrayList1 = new ArrayList();
    ArrayList<m> arrayList2 = new ArrayList();
    ArrayList<b0.e> arrayList = new ArrayList<b0.e>(paramList);
    for (b0.e e : paramList) {
      h0.b b = new h0.b();
      e.j(b);
      arrayList1.add(new k(e, b, paramBoolean));
      b = new h0.b();
      e.j(b);
      boolean bool = false;
      if (paramBoolean ? (e == e2) : (e == e1))
        bool = true; 
      arrayList2.add(new m(e, b, paramBoolean, bool));
      e.a(new b(this, arrayList, e));
    } 
    Map<b0.e, Boolean> map = x(arrayList2, arrayList, paramBoolean, e2, e1);
    w(arrayList1, arrayList, map.containsValue(Boolean.TRUE), map);
    Iterator<b0.e> iterator1 = arrayList.iterator();
    while (iterator1.hasNext())
      s(iterator1.next()); 
    arrayList.clear();
  }
  
  void s(b0.e parame) {
    View view = (parame.f()).M;
    parame.e().b(view);
  }
  
  void t(ArrayList<View> paramArrayList, View paramView) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      if (z.a(viewGroup)) {
        if (!paramArrayList.contains(paramView)) {
          paramArrayList.add(viewGroup);
          return;
        } 
      } else {
        int j = viewGroup.getChildCount();
        for (int i = 0; i < j; i++) {
          paramView = viewGroup.getChildAt(i);
          if (paramView.getVisibility() == 0)
            t(paramArrayList, paramView); 
        } 
      } 
    } else if (!paramArrayList.contains(paramView)) {
      paramArrayList.add(paramView);
    } 
  }
  
  void u(Map<String, View> paramMap, View paramView) {
    String str = w.K(paramView);
    if (str != null)
      paramMap.put(str, paramView); 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int j = viewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = viewGroup.getChildAt(i);
        if (view.getVisibility() == 0)
          u(paramMap, view); 
      } 
    } 
  }
  
  void v(s.a<String, View> parama, Collection<String> paramCollection) {
    Iterator<Map.Entry> iterator = parama.entrySet().iterator();
    while (iterator.hasNext()) {
      if (!paramCollection.contains(w.K((View)((Map.Entry)iterator.next()).getValue())))
        iterator.remove(); 
    } 
  }
  
  class b implements Runnable {
    b(c this$0, List param1List, b0.e param1e) {}
    
    public void run() {
      if (this.f.contains(this.g)) {
        this.f.remove(this.g);
        this.h.s(this.g);
      } 
    }
  }
  
  class c extends AnimatorListenerAdapter {
    c(c this$0, ViewGroup param1ViewGroup, View param1View, boolean param1Boolean, b0.e param1e, c.k param1k) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      if (this.c)
        this.d.e().b(this.b); 
      this.e.a();
    }
  }
  
  class d implements h0.b.a {
    d(c this$0, Animator param1Animator) {}
    
    public void a() {
      this.a.end();
    }
  }
  
  class e implements Animation.AnimationListener {
    e(c this$0, ViewGroup param1ViewGroup, View param1View, c.k param1k) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      this.a.post(new a(this));
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
    
    class a implements Runnable {
      a(c.e this$0) {}
      
      public void run() {
        c.e e1 = this.f;
        e1.a.endViewTransition(e1.b);
        this.f.c.a();
      }
    }
  }
  
  class a implements Runnable {
    a(c this$0) {}
    
    public void run() {
      c.e e1 = this.f;
      e1.a.endViewTransition(e1.b);
      this.f.c.a();
    }
  }
  
  class f implements h0.b.a {
    f(c this$0, View param1View, ViewGroup param1ViewGroup, c.k param1k) {}
    
    public void a() {
      this.a.clearAnimation();
      this.b.endViewTransition(this.a);
      this.c.a();
    }
  }
  
  class g implements Runnable {
    g(c this$0, b0.e param1e1, b0.e param1e2, boolean param1Boolean, s.a param1a) {}
    
    public void run() {
      w.f(this.f.f(), this.g.f(), this.h, this.i, false);
    }
  }
  
  class h implements Runnable {
    h(c this$0, y param1y, View param1View, Rect param1Rect) {}
    
    public void run() {
      this.f.k(this.g, this.h);
    }
  }
  
  class i implements Runnable {
    i(c this$0, ArrayList param1ArrayList) {}
    
    public void run() {
      w.A(this.f, 4);
    }
  }
  
  class j implements Runnable {
    j(c this$0, c.m param1m) {}
    
    public void run() {
      this.f.a();
    }
  }
  
  private static class k extends l {
    private boolean c;
    
    private boolean d = false;
    
    private f.d e;
    
    k(b0.e param1e, h0.b param1b, boolean param1Boolean) {
      super(param1e, param1b);
      this.c = param1Boolean;
    }
    
    f.d e(Context param1Context) {
      boolean bool;
      if (this.d)
        return this.e; 
      Fragment fragment = b().f();
      if (b().e() == b0.e.c.g) {
        bool = true;
      } else {
        bool = false;
      } 
      f.d d1 = f.c(param1Context, fragment, bool, this.c);
      this.e = d1;
      this.d = true;
      return d1;
    }
  }
  
  private static class l {
    private final b0.e a;
    
    private final h0.b b;
    
    l(b0.e param1e, h0.b param1b) {
      this.a = param1e;
      this.b = param1b;
    }
    
    void a() {
      this.a.d(this.b);
    }
    
    b0.e b() {
      return this.a;
    }
    
    h0.b c() {
      return this.b;
    }
    
    boolean d() {
      b0.e.c c1 = b0.e.c.e((this.a.f()).M);
      b0.e.c c2 = this.a.e();
      if (c1 != c2) {
        b0.e.c c = b0.e.c.g;
        if (c1 == c || c2 == c)
          return false; 
      } 
      return true;
    }
  }
  
  private static class m extends l {
    private final Object c;
    
    private final boolean d;
    
    private final Object e;
    
    m(b0.e param1e, h0.b param1b, boolean param1Boolean1, boolean param1Boolean2) {
      super(param1e, param1b);
      if (param1e.e() == b0.e.c.g) {
        Object object;
        boolean bool;
        if (param1Boolean1) {
          object = param1e.f().K();
        } else {
          object = param1e.f().t();
        } 
        this.c = object;
        if (param1Boolean1) {
          bool = param1e.f().m();
        } else {
          bool = param1e.f().l();
        } 
        this.d = bool;
      } else {
        Object object;
        if (param1Boolean1) {
          object = param1e.f().M();
        } else {
          object = param1e.f().w();
        } 
        this.c = object;
        this.d = true;
      } 
      if (param1Boolean2) {
        if (param1Boolean1) {
          this.e = param1e.f().O();
          return;
        } 
        this.e = param1e.f().N();
        return;
      } 
      this.e = null;
    }
    
    private y f(Object param1Object) {
      if (param1Object == null)
        return null; 
      y y = w.b;
      if (y != null && y.e(param1Object))
        return y; 
      y = w.c;
      if (y != null && y.e(param1Object))
        return y; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Transition ");
      stringBuilder.append(param1Object);
      stringBuilder.append(" for fragment ");
      stringBuilder.append(b().f());
      stringBuilder.append(" is not a valid framework Transition or AndroidX Transition");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    y e() {
      y y1 = f(this.c);
      y y2 = f(this.e);
      if (y1 == null || y2 == null || y1 == y2)
        return (y1 != null) ? y1 : y2; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Mixing framework transitions and AndroidX transitions is not allowed. Fragment ");
      stringBuilder.append(b().f());
      stringBuilder.append(" returned Transition ");
      stringBuilder.append(this.c);
      stringBuilder.append(" which uses a different Transition  type than its shared element transition ");
      stringBuilder.append(this.e);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Object g() {
      return this.e;
    }
    
    Object h() {
      return this.c;
    }
    
    public boolean i() {
      return (this.e != null);
    }
    
    boolean j() {
      return this.d;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */