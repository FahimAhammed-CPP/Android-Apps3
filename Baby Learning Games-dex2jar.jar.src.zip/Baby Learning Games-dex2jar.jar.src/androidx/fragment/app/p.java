package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.e0;
import androidx.lifecycle.f0;
import androidx.lifecycle.h0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

final class p extends e0 {
  private static final f0.b j = new a();
  
  private final HashMap<String, Fragment> c = new HashMap<String, Fragment>();
  
  private final HashMap<String, p> d = new HashMap<String, p>();
  
  private final HashMap<String, h0> e = new HashMap<String, h0>();
  
  private final boolean f;
  
  private boolean g = false;
  
  private boolean h = false;
  
  private boolean i = false;
  
  p(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  static p j(h0 paramh0) {
    return (p)(new f0(paramh0, j)).a(p.class);
  }
  
  protected void d() {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCleared called for ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.g = true;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (p.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.c.equals(((p)paramObject).c) && this.d.equals(((p)paramObject).d) && this.e.equals(((p)paramObject).e));
    } 
    return false;
  }
  
  void f(Fragment paramFragment) {
    if (this.i) {
      if (m.G0(2))
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.c.containsKey(paramFragment.k))
      return; 
    this.c.put(paramFragment.k, paramFragment);
    if (m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void g(Fragment paramFragment) {
    if (m.G0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing non-config state for ");
      stringBuilder.append(paramFragment);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    p p1 = this.d.get(paramFragment.k);
    if (p1 != null) {
      p1.d();
      this.d.remove(paramFragment.k);
    } 
    h0 h0 = this.e.get(paramFragment.k);
    if (h0 != null) {
      h0.a();
      this.e.remove(paramFragment.k);
    } 
  }
  
  Fragment h(String paramString) {
    return this.c.get(paramString);
  }
  
  public int hashCode() {
    return (this.c.hashCode() * 31 + this.d.hashCode()) * 31 + this.e.hashCode();
  }
  
  p i(Fragment paramFragment) {
    p p2 = this.d.get(paramFragment.k);
    p p1 = p2;
    if (p2 == null) {
      p1 = new p(this.f);
      this.d.put(paramFragment.k, p1);
    } 
    return p1;
  }
  
  Collection<Fragment> k() {
    return new ArrayList<Fragment>(this.c.values());
  }
  
  h0 l(Fragment paramFragment) {
    h0 h02 = this.e.get(paramFragment.k);
    h0 h01 = h02;
    if (h02 == null) {
      h01 = new h0();
      this.e.put(paramFragment.k, h01);
    } 
    return h01;
  }
  
  boolean m() {
    return this.g;
  }
  
  void n(Fragment paramFragment) {
    boolean bool;
    if (this.i) {
      if (m.G0(2))
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.c.remove(paramFragment.k) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool && m.G0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void o(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  boolean p(Fragment paramFragment) {
    return !this.c.containsKey(paramFragment.k) ? true : (this.f ? this.g : (this.h ^ true));
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("FragmentManagerViewModel{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("} Fragments (");
    Iterator<String> iterator = this.c.values().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") Child Non Config (");
    iterator = this.d.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") ViewModelStores (");
    iterator = this.e.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  class a implements f0.b {
    public <T extends e0> T a(Class<T> param1Class) {
      return (T)new p(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */