package androidx.fragment.app;

import android.os.Bundle;
import androidx.lifecycle.j;
import androidx.lifecycle.o;
import androidx.lifecycle.p;
import androidx.lifecycle.q;

class FragmentManager$6 implements o {
  public void d(q paramq, j.b paramb) {
    if (paramb == j.b.ON_START) {
      Bundle bundle = (Bundle)m.a(this.i).get(this.f);
      if (bundle != null) {
        this.g.a(this.f, bundle);
        this.i.r(this.f);
      } 
    } 
    if (paramb == j.b.ON_DESTROY) {
      this.h.c((p)this);
      m.b(this.i).remove(this.f);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\FragmentManager$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */