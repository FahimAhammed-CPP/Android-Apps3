package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import k0.h;

public abstract class j<E> extends g {
  private final Activity f;
  
  private final Context g;
  
  private final Handler h;
  
  private final int i;
  
  final m j = new n();
  
  j(Activity paramActivity, Context paramContext, Handler paramHandler, int paramInt) {
    this.f = paramActivity;
    this.g = (Context)h.g(paramContext, "context == null");
    this.h = (Handler)h.g(paramHandler, "handler == null");
    this.i = paramInt;
  }
  
  j(e parame) {
    this((Activity)parame, (Context)parame, new Handler(), 0);
  }
  
  public View f(int paramInt) {
    return null;
  }
  
  public boolean g() {
    return true;
  }
  
  Activity h() {
    return this.f;
  }
  
  Context j() {
    return this.g;
  }
  
  Handler l() {
    return this.h;
  }
  
  public abstract E m();
  
  public LayoutInflater n() {
    return LayoutInflater.from(this.g);
  }
  
  public boolean o(Fragment paramFragment) {
    return true;
  }
  
  public void p() {}
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\fragment\app\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */