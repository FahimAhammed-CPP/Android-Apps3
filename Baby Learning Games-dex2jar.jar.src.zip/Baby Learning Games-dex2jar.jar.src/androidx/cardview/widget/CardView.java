package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import r.b;
import r.c;
import r.d;

public class CardView extends FrameLayout {
  private static final int[] m = new int[] { 16842801 };
  
  private static final c n;
  
  private boolean f;
  
  private boolean g;
  
  int h;
  
  int i;
  
  final Rect j;
  
  final Rect k;
  
  private final b l;
  
  static {
    a a = new a();
    n = a;
    a.f();
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, r.a.a);
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    ColorStateList colorStateList;
    Rect rect = new Rect();
    this.j = rect;
    this.k = new Rect();
    a a = new a(this);
    this.l = a;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, d.a, paramInt, c.a);
    paramInt = d.d;
    if (typedArray.hasValue(paramInt)) {
      colorStateList = typedArray.getColorStateList(paramInt);
    } else {
      TypedArray typedArray1 = getContext().obtainStyledAttributes(m);
      paramInt = typedArray1.getColor(0, 0);
      typedArray1.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(paramInt, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F) {
        paramInt = getResources().getColor(b.b);
      } else {
        paramInt = getResources().getColor(b.a);
      } 
      colorStateList = ColorStateList.valueOf(paramInt);
    } 
    float f3 = typedArray.getDimension(d.e, 0.0F);
    float f2 = typedArray.getDimension(d.f, 0.0F);
    float f1 = typedArray.getDimension(d.g, 0.0F);
    this.f = typedArray.getBoolean(d.i, false);
    this.g = typedArray.getBoolean(d.h, true);
    paramInt = typedArray.getDimensionPixelSize(d.j, 0);
    rect.left = typedArray.getDimensionPixelSize(d.l, paramInt);
    rect.top = typedArray.getDimensionPixelSize(d.n, paramInt);
    rect.right = typedArray.getDimensionPixelSize(d.m, paramInt);
    rect.bottom = typedArray.getDimensionPixelSize(d.k, paramInt);
    if (f2 > f1)
      f1 = f2; 
    this.h = typedArray.getDimensionPixelSize(d.b, 0);
    this.i = typedArray.getDimensionPixelSize(d.c, 0);
    typedArray.recycle();
    n.c(a, paramContext, colorStateList, f3, f2, f1);
  }
  
  public ColorStateList getCardBackgroundColor() {
    return n.b(this.l);
  }
  
  public float getCardElevation() {
    return n.e(this.l);
  }
  
  public int getContentPaddingBottom() {
    return this.j.bottom;
  }
  
  public int getContentPaddingLeft() {
    return this.j.left;
  }
  
  public int getContentPaddingRight() {
    return this.j.right;
  }
  
  public int getContentPaddingTop() {
    return this.j.top;
  }
  
  public float getMaxCardElevation() {
    return n.a(this.l);
  }
  
  public boolean getPreventCornerOverlap() {
    return this.g;
  }
  
  public float getRadius() {
    return n.g(this.l);
  }
  
  public boolean getUseCompatPadding() {
    return this.f;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    c c1 = n;
    if (!(c1 instanceof a)) {
      int i = View.MeasureSpec.getMode(paramInt1);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(c1.i(this.l)), View.MeasureSpec.getSize(paramInt1)), i); 
      i = View.MeasureSpec.getMode(paramInt2);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(c1.h(this.l)), View.MeasureSpec.getSize(paramInt2)), i); 
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCardBackgroundColor(int paramInt) {
    n.m(this.l, ColorStateList.valueOf(paramInt));
  }
  
  public void setCardBackgroundColor(ColorStateList paramColorStateList) {
    n.m(this.l, paramColorStateList);
  }
  
  public void setCardElevation(float paramFloat) {
    n.k(this.l, paramFloat);
  }
  
  public void setMaxCardElevation(float paramFloat) {
    n.n(this.l, paramFloat);
  }
  
  public void setMinimumHeight(int paramInt) {
    this.i = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setMinimumWidth(int paramInt) {
    this.h = paramInt;
    super.setMinimumWidth(paramInt);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPreventCornerOverlap(boolean paramBoolean) {
    if (paramBoolean != this.g) {
      this.g = paramBoolean;
      n.l(this.l);
    } 
  }
  
  public void setRadius(float paramFloat) {
    n.d(this.l, paramFloat);
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.f != paramBoolean) {
      this.f = paramBoolean;
      n.j(this.l);
    } 
  }
  
  class a implements b {
    private Drawable a;
    
    a(CardView this$0) {}
    
    public void a(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.b.k.set(param1Int1, param1Int2, param1Int3, param1Int4);
      CardView cardView = this.b;
      Rect rect = cardView.j;
      CardView.c(cardView, param1Int1 + rect.left, param1Int2 + rect.top, param1Int3 + rect.right, param1Int4 + rect.bottom);
    }
    
    public View b() {
      return (View)this.b;
    }
    
    public void c(Drawable param1Drawable) {
      this.a = param1Drawable;
      this.b.setBackgroundDrawable(param1Drawable);
    }
    
    public boolean d() {
      return this.b.getPreventCornerOverlap();
    }
    
    public boolean e() {
      return this.b.getUseCompatPadding();
    }
    
    public Drawable f() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\cardview\widget\CardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */