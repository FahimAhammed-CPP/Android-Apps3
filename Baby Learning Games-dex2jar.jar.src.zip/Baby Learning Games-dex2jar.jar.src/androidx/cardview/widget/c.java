package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;

interface c {
  float a(b paramb);
  
  ColorStateList b(b paramb);
  
  void c(b paramb, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3);
  
  void d(b paramb, float paramFloat);
  
  float e(b paramb);
  
  void f();
  
  float g(b paramb);
  
  float h(b paramb);
  
  float i(b paramb);
  
  void j(b paramb);
  
  void k(b paramb, float paramFloat);
  
  void l(b paramb);
  
  void m(b paramb, ColorStateList paramColorStateList);
  
  void n(b paramb, float paramFloat);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\cardview\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */