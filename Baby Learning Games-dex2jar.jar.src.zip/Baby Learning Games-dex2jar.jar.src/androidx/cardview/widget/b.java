package androidx.cardview.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

interface b {
  void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  View b();
  
  void c(Drawable paramDrawable);
  
  boolean d();
  
  boolean e();
  
  Drawable f();
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\cardview\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */