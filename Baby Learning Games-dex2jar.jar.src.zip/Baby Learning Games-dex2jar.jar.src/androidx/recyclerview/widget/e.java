package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import h0.i;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

final class e implements Runnable {
  static final ThreadLocal<e> j = new ThreadLocal<e>();
  
  static Comparator<c> k = new a();
  
  ArrayList<RecyclerView> f = new ArrayList<RecyclerView>();
  
  long g;
  
  long h;
  
  private ArrayList<c> i = new ArrayList<c>();
  
  private void b() {
    int k = this.f.size();
    int i = 0;
    int j;
    for (j = i; i < k; j = m) {
      RecyclerView recyclerView = this.f.get(i);
      int m = j;
      if (recyclerView.getWindowVisibility() == 0) {
        recyclerView.l0.c(recyclerView, false);
        m = j + recyclerView.l0.d;
      } 
      i++;
    } 
    this.i.ensureCapacity(j);
    j = 0;
    for (i = j; j < k; i = m) {
      int m;
      RecyclerView recyclerView = this.f.get(j);
      if (recyclerView.getWindowVisibility() != 0) {
        m = i;
      } else {
        b b = recyclerView.l0;
        int i1 = Math.abs(b.a) + Math.abs(b.b);
        int n = 0;
        while (true) {
          m = i;
          if (n < b.d * 2) {
            boolean bool;
            c c;
            if (i >= this.i.size()) {
              c = new c();
              this.i.add(c);
            } else {
              c = this.i.get(i);
            } 
            int[] arrayOfInt = b.c;
            m = arrayOfInt[n + 1];
            if (m <= i1) {
              bool = true;
            } else {
              bool = false;
            } 
            c.a = bool;
            c.b = i1;
            c.c = m;
            c.d = recyclerView;
            c.e = arrayOfInt[n];
            i++;
            n += 2;
            continue;
          } 
          break;
        } 
      } 
      j++;
    } 
    Collections.sort(this.i, k);
  }
  
  private void c(c paramc, long paramLong) {
    long l;
    if (paramc.a) {
      l = Long.MAX_VALUE;
    } else {
      l = paramLong;
    } 
    RecyclerView.d0 d0 = i(paramc.d, paramc.e, l);
    if (d0 != null && d0.b != null && d0.s() && !d0.t())
      h(d0.b.get(), paramLong); 
  }
  
  private void d(long paramLong) {
    for (int i = 0; i < this.i.size(); i++) {
      c c = this.i.get(i);
      if (c.d == null)
        return; 
      c(c, paramLong);
      c.a();
    } 
  }
  
  static boolean e(RecyclerView paramRecyclerView, int paramInt) {
    int j = paramRecyclerView.j.j();
    for (int i = 0; i < j; i++) {
      RecyclerView.d0 d0 = RecyclerView.f0(paramRecyclerView.j.i(i));
      if (d0.c == paramInt && !d0.t())
        return true; 
    } 
    return false;
  }
  
  private void h(RecyclerView paramRecyclerView, long paramLong) {
    if (paramRecyclerView == null)
      return; 
    if (paramRecyclerView.I && paramRecyclerView.j.j() != 0)
      paramRecyclerView.T0(); 
    b b = paramRecyclerView.l0;
    b.c(paramRecyclerView, true);
    if (b.d != 0)
      try {
        i.a("RV Nested Prefetch");
        paramRecyclerView.m0.f(paramRecyclerView.q);
        int i;
        for (i = 0; i < b.d * 2; i += 2)
          i(paramRecyclerView, b.c[i], paramLong); 
        return;
      } finally {
        i.b();
      }  
  }
  
  private RecyclerView.d0 i(RecyclerView paramRecyclerView, int paramInt, long paramLong) {
    if (e(paramRecyclerView, paramInt))
      return null; 
    null = paramRecyclerView.g;
    try {
      paramRecyclerView.F0();
      RecyclerView.d0 d0 = null.I(paramInt, false, paramLong);
      if (d0 != null)
        if (d0.s() && !d0.t()) {
          null.B(d0.a);
        } else {
          null.a(d0, false);
        }  
      return d0;
    } finally {
      paramRecyclerView.H0(false);
    } 
  }
  
  public void a(RecyclerView paramRecyclerView) {
    this.f.add(paramRecyclerView);
  }
  
  void f(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    if (paramRecyclerView.isAttachedToWindow() && this.g == 0L) {
      this.g = paramRecyclerView.getNanoTime();
      paramRecyclerView.post(this);
    } 
    paramRecyclerView.l0.e(paramInt1, paramInt2);
  }
  
  void g(long paramLong) {
    b();
    d(paramLong);
  }
  
  public void j(RecyclerView paramRecyclerView) {
    this.f.remove(paramRecyclerView);
  }
  
  public void run() {
    try {
      i.a("RV Prefetch");
      boolean bool = this.f.isEmpty();
      if (!bool) {
        int j = this.f.size();
        int i = 0;
        long l;
        for (l = 0L; i < j; l = l1) {
          RecyclerView recyclerView = this.f.get(i);
          long l1 = l;
          if (recyclerView.getWindowVisibility() == 0)
            l1 = Math.max(recyclerView.getDrawingTime(), l); 
          i++;
        } 
        if (l != 0L) {
          g(TimeUnit.MILLISECONDS.toNanos(l) + this.h);
          return;
        } 
      } 
      return;
    } finally {
      this.g = 0L;
      i.b();
    } 
  }
  
  static final class a implements Comparator<c> {
    public int a(e.c param1c1, e.c param1c2) {
      byte b1;
      RecyclerView recyclerView = param1c1.d;
      byte b2 = 1;
      if (recyclerView == null) {
        i = 1;
      } else {
        i = 0;
      } 
      if (param1c2.d == null) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      if (i != b1)
        return (recyclerView == null) ? 1 : -1; 
      boolean bool = param1c1.a;
      if (bool != param1c2.a) {
        i = b2;
        if (bool)
          i = -1; 
        return i;
      } 
      int i = param1c2.b - param1c1.b;
      if (i != 0)
        return i; 
      i = param1c1.c - param1c2.c;
      return (i != 0) ? i : 0;
    }
  }
  
  @SuppressLint({"VisibleForTests"})
  static class b implements RecyclerView.o.c {
    int a;
    
    int b;
    
    int[] c;
    
    int d;
    
    public void a(int param1Int1, int param1Int2) {
      if (param1Int1 >= 0) {
        if (param1Int2 >= 0) {
          int i = this.d * 2;
          int[] arrayOfInt = this.c;
          if (arrayOfInt == null) {
            arrayOfInt = new int[4];
            this.c = arrayOfInt;
            Arrays.fill(arrayOfInt, -1);
          } else if (i >= arrayOfInt.length) {
            int[] arrayOfInt1 = new int[i * 2];
            this.c = arrayOfInt1;
            System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
          } 
          arrayOfInt = this.c;
          arrayOfInt[i] = param1Int1;
          arrayOfInt[i + 1] = param1Int2;
          this.d++;
          return;
        } 
        throw new IllegalArgumentException("Pixel distance must be non-negative");
      } 
      throw new IllegalArgumentException("Layout positions must be non-negative");
    }
    
    void b() {
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      this.d = 0;
    }
    
    void c(RecyclerView param1RecyclerView, boolean param1Boolean) {
      this.d = 0;
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1); 
      RecyclerView.o o = param1RecyclerView.r;
      if (param1RecyclerView.q != null && o != null && o.u0()) {
        if (param1Boolean) {
          if (!param1RecyclerView.i.p())
            o.p(param1RecyclerView.q.c(), this); 
        } else if (!param1RecyclerView.l0()) {
          o.o(this.a, this.b, param1RecyclerView.m0, this);
        } 
        int i = this.d;
        if (i > o.m) {
          o.m = i;
          o.n = param1Boolean;
          param1RecyclerView.g.K();
        } 
      } 
    }
    
    boolean d(int param1Int) {
      if (this.c != null) {
        int j = this.d;
        for (int i = 0; i < j * 2; i += 2) {
          if (this.c[i] == param1Int)
            return true; 
        } 
      } 
      return false;
    }
    
    void e(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
  }
  
  static class c {
    public boolean a;
    
    public int b;
    
    public int c;
    
    public RecyclerView d;
    
    public int e;
    
    public void a() {
      this.a = false;
      this.b = 0;
      this.c = 0;
      this.d = null;
      this.e = 0;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\recyclerview\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */