package androidx.recyclerview.widget;

import k0.e;
import k0.f;
import s.d;
import s.g;

class p {
  final g<RecyclerView.d0, a> a = new g();
  
  final d<RecyclerView.d0> b = new d();
  
  private RecyclerView.l.c l(RecyclerView.d0 paramd0, int paramInt) {
    int i = this.a.f(paramd0);
    if (i < 0)
      return null; 
    a a = (a)this.a.m(i);
    if (a != null) {
      int j = a.a;
      if ((j & paramInt) != 0) {
        RecyclerView.l.c c;
        j = paramInt & j;
        a.a = j;
        if (paramInt == 4) {
          c = a.b;
        } else if (paramInt == 8) {
          c = a.c;
        } else {
          throw new IllegalArgumentException("Must provide flag PRE or POST");
        } 
        if ((j & 0xC) == 0) {
          this.a.k(i);
          a.c(a);
        } 
        return c;
      } 
    } 
    return null;
  }
  
  void a(RecyclerView.d0 paramd0, RecyclerView.l.c paramc) {
    a a2 = (a)this.a.get(paramd0);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.b();
      this.a.put(paramd0, a1);
    } 
    a1.a |= 0x2;
    a1.b = paramc;
  }
  
  void b(RecyclerView.d0 paramd0) {
    a a2 = (a)this.a.get(paramd0);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.b();
      this.a.put(paramd0, a1);
    } 
    a1.a |= 0x1;
  }
  
  void c(long paramLong, RecyclerView.d0 paramd0) {
    this.b.j(paramLong, paramd0);
  }
  
  void d(RecyclerView.d0 paramd0, RecyclerView.l.c paramc) {
    a a2 = (a)this.a.get(paramd0);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.b();
      this.a.put(paramd0, a1);
    } 
    a1.c = paramc;
    a1.a |= 0x8;
  }
  
  void e(RecyclerView.d0 paramd0, RecyclerView.l.c paramc) {
    a a2 = (a)this.a.get(paramd0);
    a a1 = a2;
    if (a2 == null) {
      a1 = a.b();
      this.a.put(paramd0, a1);
    } 
    a1.b = paramc;
    a1.a |= 0x4;
  }
  
  void f() {
    this.a.clear();
    this.b.b();
  }
  
  RecyclerView.d0 g(long paramLong) {
    return (RecyclerView.d0)this.b.f(paramLong);
  }
  
  boolean h(RecyclerView.d0 paramd0) {
    a a = (a)this.a.get(paramd0);
    return (a != null && (a.a & 0x1) != 0);
  }
  
  boolean i(RecyclerView.d0 paramd0) {
    a a = (a)this.a.get(paramd0);
    return (a != null && (a.a & 0x4) != 0);
  }
  
  void j() {
    a.a();
  }
  
  public void k(RecyclerView.d0 paramd0) {
    p(paramd0);
  }
  
  RecyclerView.l.c m(RecyclerView.d0 paramd0) {
    return l(paramd0, 8);
  }
  
  RecyclerView.l.c n(RecyclerView.d0 paramd0) {
    return l(paramd0, 4);
  }
  
  void o(b paramb) {
    for (int i = this.a.size() - 1; i >= 0; i--) {
      RecyclerView.d0 d0 = (RecyclerView.d0)this.a.i(i);
      a a = (a)this.a.k(i);
      int j = a.a;
      if ((j & 0x3) == 3) {
        paramb.a(d0);
      } else if ((j & 0x1) != 0) {
        RecyclerView.l.c c = a.b;
        if (c == null) {
          paramb.a(d0);
        } else {
          paramb.c(d0, c, a.c);
        } 
      } else if ((j & 0xE) == 14) {
        paramb.b(d0, a.b, a.c);
      } else if ((j & 0xC) == 12) {
        paramb.d(d0, a.b, a.c);
      } else if ((j & 0x4) != 0) {
        paramb.c(d0, a.b, null);
      } else if ((j & 0x8) != 0) {
        paramb.b(d0, a.b, a.c);
      } 
      a.c(a);
    } 
  }
  
  void p(RecyclerView.d0 paramd0) {
    a a = (a)this.a.get(paramd0);
    if (a == null)
      return; 
    a.a &= 0xFFFFFFFE;
  }
  
  void q(RecyclerView.d0 paramd0) {
    for (int i = this.b.n() - 1; i >= 0; i--) {
      if (paramd0 == this.b.o(i)) {
        this.b.m(i);
        break;
      } 
    } 
    a a = (a)this.a.remove(paramd0);
    if (a != null)
      a.c(a); 
  }
  
  static class a {
    static e<a> d = (e<a>)new f(20);
    
    int a;
    
    RecyclerView.l.c b;
    
    RecyclerView.l.c c;
    
    static void a() {
      while (d.b() != null);
    }
    
    static a b() {
      a a2 = (a)d.b();
      a a1 = a2;
      if (a2 == null)
        a1 = new a(); 
      return a1;
    }
    
    static void c(a param1a) {
      param1a.a = 0;
      param1a.b = null;
      param1a.c = null;
      d.a(param1a);
    }
  }
  
  static interface b {
    void a(RecyclerView.d0 param1d0);
    
    void b(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2);
    
    void c(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2);
    
    void d(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\recyclerview\widget\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */