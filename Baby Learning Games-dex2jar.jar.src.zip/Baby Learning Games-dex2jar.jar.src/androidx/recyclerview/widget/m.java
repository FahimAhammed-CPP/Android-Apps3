package androidx.recyclerview.widget;

import android.view.View;

public abstract class m extends RecyclerView.l {
  boolean g = true;
  
  public final void A(RecyclerView.d0 paramd0) {
    I(paramd0);
    h(paramd0);
  }
  
  public final void B(RecyclerView.d0 paramd0) {
    J(paramd0);
  }
  
  public final void C(RecyclerView.d0 paramd0, boolean paramBoolean) {
    K(paramd0, paramBoolean);
    h(paramd0);
  }
  
  public final void D(RecyclerView.d0 paramd0, boolean paramBoolean) {
    L(paramd0, paramBoolean);
  }
  
  public final void E(RecyclerView.d0 paramd0) {
    M(paramd0);
    h(paramd0);
  }
  
  public final void F(RecyclerView.d0 paramd0) {
    N(paramd0);
  }
  
  public final void G(RecyclerView.d0 paramd0) {
    O(paramd0);
    h(paramd0);
  }
  
  public final void H(RecyclerView.d0 paramd0) {
    P(paramd0);
  }
  
  public void I(RecyclerView.d0 paramd0) {}
  
  public void J(RecyclerView.d0 paramd0) {}
  
  public void K(RecyclerView.d0 paramd0, boolean paramBoolean) {}
  
  public void L(RecyclerView.d0 paramd0, boolean paramBoolean) {}
  
  public void M(RecyclerView.d0 paramd0) {}
  
  public void N(RecyclerView.d0 paramd0) {}
  
  public void O(RecyclerView.d0 paramd0) {}
  
  public void P(RecyclerView.d0 paramd0) {}
  
  public boolean a(RecyclerView.d0 paramd0, RecyclerView.l.c paramc1, RecyclerView.l.c paramc2) {
    if (paramc1 != null) {
      int i = paramc1.a;
      int j = paramc2.a;
      if (i != j || paramc1.b != paramc2.b)
        return y(paramd0, i, paramc1.b, j, paramc2.b); 
    } 
    return w(paramd0);
  }
  
  public boolean b(RecyclerView.d0 paramd01, RecyclerView.d0 paramd02, RecyclerView.l.c paramc1, RecyclerView.l.c paramc2) {
    int i;
    int j;
    int k = paramc1.a;
    int n = paramc1.b;
    if (paramd02.J()) {
      i = paramc1.a;
      j = paramc1.b;
    } else {
      i = paramc2.a;
      j = paramc2.b;
    } 
    return x(paramd01, paramd02, k, n, i, j);
  }
  
  public boolean c(RecyclerView.d0 paramd0, RecyclerView.l.c paramc1, RecyclerView.l.c paramc2) {
    int i;
    int j;
    int k = paramc1.a;
    int n = paramc1.b;
    View view = paramd0.a;
    if (paramc2 == null) {
      i = view.getLeft();
    } else {
      i = paramc2.a;
    } 
    if (paramc2 == null) {
      j = view.getTop();
    } else {
      j = paramc2.b;
    } 
    if (!paramd0.v() && (k != i || n != j)) {
      view.layout(i, j, view.getWidth() + i, view.getHeight() + j);
      return y(paramd0, k, n, i, j);
    } 
    return z(paramd0);
  }
  
  public boolean d(RecyclerView.d0 paramd0, RecyclerView.l.c paramc1, RecyclerView.l.c paramc2) {
    int i = paramc1.a;
    int j = paramc2.a;
    if (i != j || paramc1.b != paramc2.b)
      return y(paramd0, i, paramc1.b, j, paramc2.b); 
    E(paramd0);
    return false;
  }
  
  public boolean f(RecyclerView.d0 paramd0) {
    return (!this.g || paramd0.t());
  }
  
  public abstract boolean w(RecyclerView.d0 paramd0);
  
  public abstract boolean x(RecyclerView.d0 paramd01, RecyclerView.d0 paramd02, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract boolean y(RecyclerView.d0 paramd0, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract boolean z(RecyclerView.d0 paramd0);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\recyclerview\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */