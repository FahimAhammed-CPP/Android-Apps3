package androidx.recyclerview.widget;

import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.Scroller;

public abstract class n extends RecyclerView.r {
  RecyclerView a;
  
  private Scroller b;
  
  private final RecyclerView.t c = new a(this);
  
  private void f() {
    this.a.X0(this.c);
    this.a.setOnFlingListener(null);
  }
  
  private void i() throws IllegalStateException {
    if (this.a.getOnFlingListener() == null) {
      this.a.k(this.c);
      this.a.setOnFlingListener(this);
      return;
    } 
    throw new IllegalStateException("An instance of OnFlingListener already set.");
  }
  
  private boolean j(RecyclerView.o paramo, int paramInt1, int paramInt2) {
    if (!(paramo instanceof RecyclerView.z.b))
      return false; 
    RecyclerView.z z = d(paramo);
    if (z == null)
      return false; 
    paramInt1 = h(paramo, paramInt1, paramInt2);
    if (paramInt1 == -1)
      return false; 
    z.p(paramInt1);
    paramo.J1(z);
    return true;
  }
  
  public boolean a(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/recyclerview/widget/RecyclerView;
    //   4: invokevirtual getLayoutManager : ()Landroidx/recyclerview/widget/RecyclerView$o;
    //   7: astore #6
    //   9: iconst_0
    //   10: istore #5
    //   12: aload #6
    //   14: ifnonnull -> 19
    //   17: iconst_0
    //   18: ireturn
    //   19: aload_0
    //   20: getfield a : Landroidx/recyclerview/widget/RecyclerView;
    //   23: invokevirtual getAdapter : ()Landroidx/recyclerview/widget/RecyclerView$g;
    //   26: ifnonnull -> 31
    //   29: iconst_0
    //   30: ireturn
    //   31: aload_0
    //   32: getfield a : Landroidx/recyclerview/widget/RecyclerView;
    //   35: invokevirtual getMinFlingVelocity : ()I
    //   38: istore_3
    //   39: iload_2
    //   40: invokestatic abs : (I)I
    //   43: iload_3
    //   44: if_icmpgt -> 59
    //   47: iload #5
    //   49: istore #4
    //   51: iload_1
    //   52: invokestatic abs : (I)I
    //   55: iload_3
    //   56: if_icmple -> 77
    //   59: iload #5
    //   61: istore #4
    //   63: aload_0
    //   64: aload #6
    //   66: iload_1
    //   67: iload_2
    //   68: invokespecial j : (Landroidx/recyclerview/widget/RecyclerView$o;II)Z
    //   71: ifeq -> 77
    //   74: iconst_1
    //   75: istore #4
    //   77: iload #4
    //   79: ireturn
  }
  
  public void b(RecyclerView paramRecyclerView) throws IllegalStateException {
    RecyclerView recyclerView = this.a;
    if (recyclerView == paramRecyclerView)
      return; 
    if (recyclerView != null)
      f(); 
    this.a = paramRecyclerView;
    if (paramRecyclerView != null) {
      i();
      this.b = new Scroller(this.a.getContext(), (Interpolator)new DecelerateInterpolator());
      k();
    } 
  }
  
  public abstract int[] c(RecyclerView.o paramo, View paramView);
  
  protected RecyclerView.z d(RecyclerView.o paramo) {
    return e(paramo);
  }
  
  @Deprecated
  protected abstract g e(RecyclerView.o paramo);
  
  public abstract View g(RecyclerView.o paramo);
  
  public abstract int h(RecyclerView.o paramo, int paramInt1, int paramInt2);
  
  void k() {
    RecyclerView recyclerView = this.a;
    if (recyclerView == null)
      return; 
    RecyclerView.o o = recyclerView.getLayoutManager();
    if (o == null)
      return; 
    View view = g(o);
    if (view == null)
      return; 
    int[] arrayOfInt = c(o, view);
    if (arrayOfInt[0] != 0 || arrayOfInt[1] != 0)
      this.a.k1(arrayOfInt[0], arrayOfInt[1]); 
  }
  
  class a extends RecyclerView.t {
    boolean a = false;
    
    a(n this$0) {}
    
    public void a(RecyclerView param1RecyclerView, int param1Int) {
      super.a(param1RecyclerView, param1Int);
      if (param1Int == 0 && this.a) {
        this.a = false;
        this.b.k();
      } 
    }
    
    public void b(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {
      if (param1Int1 != 0 || param1Int2 != 0)
        this.a = true; 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\recyclerview\widget\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */