package androidx.recyclerview.widget;

import java.util.List;

class h {
  final a a;
  
  h(a parama) {
    this.a = parama;
  }
  
  private int a(List<a.b> paramList) {
    int i = paramList.size() - 1;
    for (boolean bool = false; i >= 0; bool = bool1) {
      boolean bool1;
      if (((a.b)paramList.get(i)).a == 8) {
        bool1 = bool;
        if (bool)
          return i; 
      } else {
        bool1 = true;
      } 
      i--;
    } 
    return -1;
  }
  
  private void c(List<a.b> paramList, int paramInt1, a.b paramb1, int paramInt2, a.b paramb2) {
    int k = paramb1.d;
    int m = paramb2.b;
    if (k < m) {
      i = -1;
    } else {
      i = 0;
    } 
    int n = paramb1.b;
    int j = i;
    if (n < m)
      j = i + 1; 
    if (m <= n)
      paramb1.b = n + paramb2.d; 
    int i = paramb2.b;
    if (i <= k)
      paramb1.d = k + paramb2.d; 
    paramb2.b = i + j;
    paramList.set(paramInt1, paramb2);
    paramList.set(paramInt2, paramb1);
  }
  
  private void d(List<a.b> paramList, int paramInt1, int paramInt2) {
    a.b b1 = paramList.get(paramInt1);
    a.b b2 = paramList.get(paramInt2);
    int i = b2.a;
    if (i != 1) {
      if (i != 2) {
        if (i != 4)
          return; 
        f(paramList, paramInt1, b1, paramInt2, b2);
        return;
      } 
      e(paramList, paramInt1, b1, paramInt2, b2);
      return;
    } 
    c(paramList, paramInt1, b1, paramInt2, b2);
  }
  
  void b(List<a.b> paramList) {
    while (true) {
      int i = a(paramList);
      if (i != -1) {
        d(paramList, i, i + 1);
        continue;
      } 
      break;
    } 
  }
  
  void e(List<a.b> paramList, int paramInt1, a.b paramb1, int paramInt2, a.b paramb2) {
    int i = paramb1.b;
    int k = paramb1.d;
    int j = 0;
    if (i < k) {
      if (paramb2.b == i && paramb2.d == k - i) {
        i = 0;
        j = 1;
      } else {
        i = 0;
      } 
    } else if (paramb2.b == k + 1 && paramb2.d == i - k) {
      i = 1;
      j = i;
    } else {
      i = 1;
    } 
    int m = paramb2.b;
    if (k < m) {
      paramb2.b = m - 1;
    } else {
      int n = paramb2.d;
      if (k < m + n) {
        paramb2.d = n - 1;
        paramb1.a = 2;
        paramb1.d = 1;
        if (paramb2.d == 0) {
          paramList.remove(paramInt2);
          this.a.a(paramb2);
        } 
        return;
      } 
    } 
    k = paramb1.b;
    m = paramb2.b;
    a.b b1 = null;
    if (k <= m) {
      paramb2.b = m + 1;
    } else {
      int n = paramb2.d;
      if (k < m + n) {
        b1 = this.a.b(2, k + 1, m + n - k, null);
        paramb2.d = paramb1.b - paramb2.b;
      } 
    } 
    if (j != 0) {
      paramList.set(paramInt1, paramb2);
      paramList.remove(paramInt2);
      this.a.a(paramb1);
      return;
    } 
    if (i != 0) {
      if (b1 != null) {
        i = paramb1.b;
        if (i > b1.b)
          paramb1.b = i - b1.d; 
        i = paramb1.d;
        if (i > b1.b)
          paramb1.d = i - b1.d; 
      } 
      i = paramb1.b;
      if (i > paramb2.b)
        paramb1.b = i - paramb2.d; 
      i = paramb1.d;
      if (i > paramb2.b)
        paramb1.d = i - paramb2.d; 
    } else {
      if (b1 != null) {
        i = paramb1.b;
        if (i >= b1.b)
          paramb1.b = i - b1.d; 
        i = paramb1.d;
        if (i >= b1.b)
          paramb1.d = i - b1.d; 
      } 
      i = paramb1.b;
      if (i >= paramb2.b)
        paramb1.b = i - paramb2.d; 
      i = paramb1.d;
      if (i >= paramb2.b)
        paramb1.d = i - paramb2.d; 
    } 
    paramList.set(paramInt1, paramb2);
    if (paramb1.b != paramb1.d) {
      paramList.set(paramInt2, paramb1);
    } else {
      paramList.remove(paramInt2);
    } 
    if (b1 != null)
      paramList.add(paramInt1, b1); 
  }
  
  void f(List<a.b> paramList, int paramInt1, a.b paramb1, int paramInt2, a.b paramb2) {
    // Byte code:
    //   0: aload_3
    //   1: getfield d : I
    //   4: istore #6
    //   6: aload #5
    //   8: getfield b : I
    //   11: istore #7
    //   13: aconst_null
    //   14: astore #10
    //   16: iload #6
    //   18: iload #7
    //   20: if_icmpge -> 35
    //   23: aload #5
    //   25: iload #7
    //   27: iconst_1
    //   28: isub
    //   29: putfield b : I
    //   32: goto -> 86
    //   35: aload #5
    //   37: getfield d : I
    //   40: istore #8
    //   42: iload #6
    //   44: iload #7
    //   46: iload #8
    //   48: iadd
    //   49: if_icmpge -> 86
    //   52: aload #5
    //   54: iload #8
    //   56: iconst_1
    //   57: isub
    //   58: putfield d : I
    //   61: aload_0
    //   62: getfield a : Landroidx/recyclerview/widget/h$a;
    //   65: iconst_4
    //   66: aload_3
    //   67: getfield b : I
    //   70: iconst_1
    //   71: aload #5
    //   73: getfield c : Ljava/lang/Object;
    //   76: invokeinterface b : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   81: astore #9
    //   83: goto -> 89
    //   86: aconst_null
    //   87: astore #9
    //   89: aload_3
    //   90: getfield b : I
    //   93: istore #6
    //   95: aload #5
    //   97: getfield b : I
    //   100: istore #7
    //   102: iload #6
    //   104: iload #7
    //   106: if_icmpgt -> 121
    //   109: aload #5
    //   111: iload #7
    //   113: iconst_1
    //   114: iadd
    //   115: putfield b : I
    //   118: goto -> 184
    //   121: aload #5
    //   123: getfield d : I
    //   126: istore #8
    //   128: iload #6
    //   130: iload #7
    //   132: iload #8
    //   134: iadd
    //   135: if_icmpge -> 184
    //   138: iload #7
    //   140: iload #8
    //   142: iadd
    //   143: iload #6
    //   145: isub
    //   146: istore #7
    //   148: aload_0
    //   149: getfield a : Landroidx/recyclerview/widget/h$a;
    //   152: iconst_4
    //   153: iload #6
    //   155: iconst_1
    //   156: iadd
    //   157: iload #7
    //   159: aload #5
    //   161: getfield c : Ljava/lang/Object;
    //   164: invokeinterface b : (IIILjava/lang/Object;)Landroidx/recyclerview/widget/a$b;
    //   169: astore #10
    //   171: aload #5
    //   173: aload #5
    //   175: getfield d : I
    //   178: iload #7
    //   180: isub
    //   181: putfield d : I
    //   184: aload_1
    //   185: iload #4
    //   187: aload_3
    //   188: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   193: pop
    //   194: aload #5
    //   196: getfield d : I
    //   199: ifle -> 215
    //   202: aload_1
    //   203: iload_2
    //   204: aload #5
    //   206: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   211: pop
    //   212: goto -> 234
    //   215: aload_1
    //   216: iload_2
    //   217: invokeinterface remove : (I)Ljava/lang/Object;
    //   222: pop
    //   223: aload_0
    //   224: getfield a : Landroidx/recyclerview/widget/h$a;
    //   227: aload #5
    //   229: invokeinterface a : (Landroidx/recyclerview/widget/a$b;)V
    //   234: aload #9
    //   236: ifnull -> 248
    //   239: aload_1
    //   240: iload_2
    //   241: aload #9
    //   243: invokeinterface add : (ILjava/lang/Object;)V
    //   248: aload #10
    //   250: ifnull -> 262
    //   253: aload_1
    //   254: iload_2
    //   255: aload #10
    //   257: invokeinterface add : (ILjava/lang/Object;)V
    //   262: return
  }
  
  static interface a {
    void a(a.b param1b);
    
    a.b b(int param1Int1, int param1Int2, int param1Int3, Object param1Object);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\recyclerview\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */