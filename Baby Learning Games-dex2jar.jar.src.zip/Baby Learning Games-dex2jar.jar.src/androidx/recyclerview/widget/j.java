package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Interpolator;

public class j extends n {
  private i d;
  
  private i e;
  
  private int l(RecyclerView.o paramo, View paramView, i parami) {
    return parami.g(paramView) + parami.e(paramView) / 2 - parami.m() + parami.n() / 2;
  }
  
  private View m(RecyclerView.o paramo, i parami) {
    int i1 = paramo.J();
    View view = null;
    if (i1 == 0)
      return null; 
    int i2 = parami.m();
    int i3 = parami.n() / 2;
    int m = Integer.MAX_VALUE;
    int k = 0;
    while (k < i1) {
      View view1 = paramo.I(k);
      int i5 = Math.abs(parami.g(view1) + parami.e(view1) / 2 - i2 + i3);
      int i4 = m;
      if (i5 < m) {
        view = view1;
        i4 = i5;
      } 
      k++;
      m = i4;
    } 
    return view;
  }
  
  private i n(RecyclerView.o paramo) {
    i i1 = this.e;
    if (i1 == null || i1.a != paramo)
      this.e = i.a(paramo); 
    return this.e;
  }
  
  private i o(RecyclerView.o paramo) {
    return paramo.l() ? p(paramo) : (paramo.k() ? n(paramo) : null);
  }
  
  private i p(RecyclerView.o paramo) {
    i i1 = this.d;
    if (i1 == null || i1.a != paramo)
      this.d = i.c(paramo); 
    return this.d;
  }
  
  private boolean q(RecyclerView.o paramo, int paramInt1, int paramInt2) {
    return paramo.k() ? ((paramInt1 > 0)) : ((paramInt2 > 0));
  }
  
  private boolean r(RecyclerView.o paramo) {
    int k = paramo.Y();
    boolean bool1 = paramo instanceof RecyclerView.z.b;
    boolean bool = false;
    null = bool;
    if (bool1) {
      PointF pointF = ((RecyclerView.z.b)paramo).a(k - 1);
      null = bool;
      if (pointF != null) {
        if (pointF.x >= 0.0F) {
          null = bool;
          return (pointF.y < 0.0F) ? true : null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public int[] c(RecyclerView.o paramo, View paramView) {
    int[] arrayOfInt = new int[2];
    if (paramo.k()) {
      arrayOfInt[0] = l(paramo, paramView, n(paramo));
    } else {
      arrayOfInt[0] = 0;
    } 
    if (paramo.l()) {
      arrayOfInt[1] = l(paramo, paramView, p(paramo));
      return arrayOfInt;
    } 
    arrayOfInt[1] = 0;
    return arrayOfInt;
  }
  
  protected g e(RecyclerView.o paramo) {
    return !(paramo instanceof RecyclerView.z.b) ? null : new a(this, this.a.getContext());
  }
  
  public View g(RecyclerView.o paramo) {
    return paramo.l() ? m(paramo, p(paramo)) : (paramo.k() ? m(paramo, n(paramo)) : null);
  }
  
  public int h(RecyclerView.o paramo, int paramInt1, int paramInt2) {
    int i2 = paramo.Y();
    if (i2 == 0)
      return -1; 
    i i4 = o(paramo);
    if (i4 == null)
      return -1; 
    int k = Integer.MIN_VALUE;
    int i1 = Integer.MAX_VALUE;
    int i3 = paramo.J();
    int m = 0;
    View view2 = null;
    View view1 = null;
    while (m < i3) {
      int i5;
      View view4;
      View view3 = paramo.I(m);
      if (view3 == null) {
        i5 = i1;
        view4 = view2;
      } else {
        int i7 = l(paramo, view3, i4);
        int i6 = k;
        View view = view1;
        if (i7 <= 0) {
          i6 = k;
          view = view1;
          if (i7 > k) {
            view = view3;
            i6 = i7;
          } 
        } 
        k = i6;
        i5 = i1;
        view4 = view2;
        view1 = view;
        if (i7 >= 0) {
          k = i6;
          i5 = i1;
          view4 = view2;
          view1 = view;
          if (i7 < i1) {
            view1 = view;
            view4 = view3;
            i5 = i7;
            k = i6;
          } 
        } 
      } 
      m++;
      i1 = i5;
      view2 = view4;
    } 
    boolean bool = q(paramo, paramInt1, paramInt2);
    if (bool && view2 != null)
      return paramo.h0(view2); 
    if (!bool && view1 != null)
      return paramo.h0(view1); 
    if (bool)
      view2 = view1; 
    if (view2 == null)
      return -1; 
    paramInt2 = paramo.h0(view2);
    if (r(paramo) == bool) {
      paramInt1 = -1;
    } else {
      paramInt1 = 1;
    } 
    paramInt1 = paramInt2 + paramInt1;
    return (paramInt1 >= 0) ? ((paramInt1 >= i2) ? -1 : paramInt1) : -1;
  }
  
  class a extends g {
    a(j this$0, Context param1Context) {
      super(param1Context);
    }
    
    protected void o(View param1View, RecyclerView.a0 param1a0, RecyclerView.z.a param1a) {
      j j1 = this.q;
      int[] arrayOfInt = j1.c(j1.a.getLayoutManager(), param1View);
      int i = arrayOfInt[0];
      int k = arrayOfInt[1];
      int m = w(Math.max(Math.abs(i), Math.abs(k)));
      if (m > 0)
        param1a.d(i, k, m, (Interpolator)this.j); 
    }
    
    protected float v(DisplayMetrics param1DisplayMetrics) {
      return 100.0F / param1DisplayMetrics.densityDpi;
    }
    
    protected int x(int param1Int) {
      return Math.min(100, super.x(param1Int));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\recyclerview\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */