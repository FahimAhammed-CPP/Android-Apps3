package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;

public class GridLayoutManager extends LinearLayoutManager {
  boolean I = false;
  
  int J = -1;
  
  int[] K;
  
  View[] L;
  
  final SparseIntArray M = new SparseIntArray();
  
  final SparseIntArray N = new SparseIntArray();
  
  c O = new a();
  
  final Rect P = new Rect();
  
  private boolean Q;
  
  public GridLayoutManager(Context paramContext, int paramInt1, int paramInt2, boolean paramBoolean) {
    super(paramContext, paramInt2, paramBoolean);
    e3(paramInt1);
  }
  
  public GridLayoutManager(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    e3((RecyclerView.o.i0(paramContext, paramAttributeSet, paramInt1, paramInt2)).b);
  }
  
  private void N2(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt, boolean paramBoolean) {
    byte b;
    int j = 0;
    int i = -1;
    if (paramBoolean) {
      b = 1;
      boolean bool = false;
      i = paramInt;
      paramInt = bool;
    } else {
      paramInt--;
      b = -1;
    } 
    while (paramInt != i) {
      View view = this.L[paramInt];
      b b1 = (b)view.getLayoutParams();
      int k = a3(paramv, parama0, h0(view));
      b1.f = k;
      b1.e = j;
      j += k;
      paramInt += b;
    } 
  }
  
  private void O2() {
    int j = J();
    for (int i = 0; i < j; i++) {
      b b = (b)I(i).getLayoutParams();
      int k = b.a();
      this.M.put(k, b.f());
      this.N.put(k, b.e());
    } 
  }
  
  private void P2(int paramInt) {
    this.K = Q2(this.K, this.J, paramInt);
  }
  
  static int[] Q2(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #4
    //   3: aload_0
    //   4: ifnull -> 28
    //   7: aload_0
    //   8: arraylength
    //   9: iload_1
    //   10: iconst_1
    //   11: iadd
    //   12: if_icmpne -> 28
    //   15: aload_0
    //   16: astore #8
    //   18: aload_0
    //   19: aload_0
    //   20: arraylength
    //   21: iconst_1
    //   22: isub
    //   23: iaload
    //   24: iload_2
    //   25: if_icmpeq -> 35
    //   28: iload_1
    //   29: iconst_1
    //   30: iadd
    //   31: newarray int
    //   33: astore #8
    //   35: iconst_0
    //   36: istore #5
    //   38: aload #8
    //   40: iconst_0
    //   41: iconst_0
    //   42: iastore
    //   43: iload_2
    //   44: iload_1
    //   45: idiv
    //   46: istore #6
    //   48: iload_2
    //   49: iload_1
    //   50: irem
    //   51: istore #7
    //   53: iconst_0
    //   54: istore_3
    //   55: iload #5
    //   57: istore_2
    //   58: iload #4
    //   60: iload_1
    //   61: if_icmpgt -> 118
    //   64: iload_2
    //   65: iload #7
    //   67: iadd
    //   68: istore_2
    //   69: iload_2
    //   70: ifle -> 94
    //   73: iload_1
    //   74: iload_2
    //   75: isub
    //   76: iload #7
    //   78: if_icmpge -> 94
    //   81: iload #6
    //   83: iconst_1
    //   84: iadd
    //   85: istore #5
    //   87: iload_2
    //   88: iload_1
    //   89: isub
    //   90: istore_2
    //   91: goto -> 98
    //   94: iload #6
    //   96: istore #5
    //   98: iload_3
    //   99: iload #5
    //   101: iadd
    //   102: istore_3
    //   103: aload #8
    //   105: iload #4
    //   107: iload_3
    //   108: iastore
    //   109: iload #4
    //   111: iconst_1
    //   112: iadd
    //   113: istore #4
    //   115: goto -> 58
    //   118: aload #8
    //   120: areturn
  }
  
  private void R2() {
    this.M.clear();
    this.N.clear();
  }
  
  private int S2(RecyclerView.a0 parama0) {
    if (J() != 0) {
      if (parama0.b() == 0)
        return 0; 
      T1();
      boolean bool = r2();
      View view1 = Y1(bool ^ true, true);
      View view2 = X1(bool ^ true, true);
      if (view1 != null) {
        if (view2 == null)
          return 0; 
        int j = this.O.b(h0(view1), this.J);
        int k = this.O.b(h0(view2), this.J);
        int i = Math.min(j, k);
        j = Math.max(j, k);
        k = this.O.b(parama0.b() - 1, this.J);
        if (this.x) {
          i = Math.max(0, k + 1 - j - 1);
        } else {
          i = Math.max(0, i);
        } 
        if (!bool)
          return i; 
        j = Math.abs(this.u.d(view2) - this.u.g(view1));
        k = this.O.b(h0(view1), this.J);
        int m = this.O.b(h0(view2), this.J);
        float f = j / (m - k + 1);
        return Math.round(i * f + (this.u.m() - this.u.g(view1)));
      } 
    } 
    return 0;
  }
  
  private int T2(RecyclerView.a0 parama0) {
    if (J() != 0) {
      if (parama0.b() == 0)
        return 0; 
      T1();
      View view1 = Y1(r2() ^ true, true);
      View view2 = X1(r2() ^ true, true);
      if (view1 != null) {
        if (view2 == null)
          return 0; 
        if (!r2())
          return this.O.b(parama0.b() - 1, this.J) + 1; 
        int i = this.u.d(view2);
        int j = this.u.g(view1);
        int k = this.O.b(h0(view1), this.J);
        int m = this.O.b(h0(view2), this.J);
        int n = this.O.b(parama0.b() - 1, this.J);
        return (int)((i - j) / (m - k + 1) * (n + 1));
      } 
    } 
    return 0;
  }
  
  private void U2(RecyclerView.v paramv, RecyclerView.a0 parama0, LinearLayoutManager.a parama, int paramInt) {
    if (paramInt == 1) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    int i = Z2(paramv, parama0, parama.b);
    if (paramInt != 0) {
      while (i > 0) {
        paramInt = parama.b;
        if (paramInt > 0) {
          parama.b = --paramInt;
          i = Z2(paramv, parama0, paramInt);
        } 
      } 
    } else {
      int j = parama0.b();
      paramInt = parama.b;
      while (paramInt < j - 1) {
        int m = paramInt + 1;
        int k = Z2(paramv, parama0, m);
        if (k > i) {
          paramInt = m;
          i = k;
        } 
      } 
      parama.b = paramInt;
    } 
  }
  
  private void V2() {
    View[] arrayOfView = this.L;
    if (arrayOfView == null || arrayOfView.length != this.J)
      this.L = new View[this.J]; 
  }
  
  private int Y2(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.e())
      return this.O.b(paramInt, this.J); 
    int i = paramv.f(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. ");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    return this.O.b(i, this.J);
  }
  
  private int Z2(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.e())
      return this.O.c(paramInt, this.J); 
    int i = this.N.get(paramInt, -1);
    if (i != -1)
      return i; 
    i = paramv.f(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 0;
    } 
    return this.O.c(i, this.J);
  }
  
  private int a3(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt) {
    if (!parama0.e())
      return this.O.f(paramInt); 
    int i = this.M.get(paramInt, -1);
    if (i != -1)
      return i; 
    i = paramv.f(paramInt);
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:");
      stringBuilder.append(paramInt);
      Log.w("GridLayoutManager", stringBuilder.toString());
      return 1;
    } 
    return this.O.f(i);
  }
  
  private void b3(float paramFloat, int paramInt) {
    P2(Math.max(Math.round(paramFloat * this.J), paramInt));
  }
  
  private void c3(View paramView, int paramInt, boolean paramBoolean) {
    b b = (b)paramView.getLayoutParams();
    Rect rect = b.b;
    int j = rect.top + rect.bottom + b.topMargin + b.bottomMargin;
    int i = rect.left + rect.right + b.leftMargin + b.rightMargin;
    int k = W2(b.e, b.f);
    if (this.s == 1) {
      i = RecyclerView.o.K(k, paramInt, i, b.width, false);
      paramInt = RecyclerView.o.K(this.u.n(), X(), j, b.height, true);
    } else {
      paramInt = RecyclerView.o.K(k, paramInt, j, b.height, false);
      i = RecyclerView.o.K(this.u.n(), p0(), i, b.width, true);
    } 
    d3(paramView, i, paramInt, paramBoolean);
  }
  
  private void d3(View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    RecyclerView.p p = (RecyclerView.p)paramView.getLayoutParams();
    if (paramBoolean) {
      paramBoolean = H1(paramView, paramInt1, paramInt2, p);
    } else {
      paramBoolean = F1(paramView, paramInt1, paramInt2, p);
    } 
    if (paramBoolean)
      paramView.measure(paramInt1, paramInt2); 
  }
  
  private void f3() {
    int i;
    int j;
    if (p2() == 1) {
      i = o0() - f0();
      j = e0();
    } else {
      i = W() - d0();
      j = g0();
    } 
    P2(i - j);
  }
  
  public void C1(Rect paramRect, int paramInt1, int paramInt2) {
    int[] arrayOfInt;
    if (this.K == null)
      super.C1(paramRect, paramInt1, paramInt2); 
    int i = e0() + f0();
    int j = g0() + d0();
    if (this.s == 1) {
      paramInt2 = RecyclerView.o.n(paramInt2, paramRect.height() + j, b0());
      arrayOfInt = this.K;
      i = RecyclerView.o.n(paramInt1, arrayOfInt[arrayOfInt.length - 1] + i, c0());
      paramInt1 = paramInt2;
      paramInt2 = i;
    } else {
      paramInt1 = RecyclerView.o.n(paramInt1, arrayOfInt.width() + i, c0());
      arrayOfInt = this.K;
      i = RecyclerView.o.n(paramInt2, arrayOfInt[arrayOfInt.length - 1] + j, b0());
      paramInt2 = paramInt1;
      paramInt1 = i;
    } 
    B1(paramInt2, paramInt1);
  }
  
  public RecyclerView.p D() {
    return (this.s == 0) ? new b(-2, -1) : new b(-1, -2);
  }
  
  public RecyclerView.p E(Context paramContext, AttributeSet paramAttributeSet) {
    return new b(paramContext, paramAttributeSet);
  }
  
  public void E2(boolean paramBoolean) {
    if (!paramBoolean) {
      super.E2(false);
      return;
    } 
    throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
  }
  
  public RecyclerView.p F(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new b((ViewGroup.MarginLayoutParams)paramLayoutParams) : new b(paramLayoutParams);
  }
  
  public View J0(View paramView, int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual B : (Landroid/view/View;)Landroid/view/View;
    //   5: astore #22
    //   7: aconst_null
    //   8: astore #23
    //   10: aload #22
    //   12: ifnonnull -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: aload #22
    //   19: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   22: checkcast androidx/recyclerview/widget/GridLayoutManager$b
    //   25: astore #24
    //   27: aload #24
    //   29: getfield e : I
    //   32: istore #15
    //   34: aload #24
    //   36: getfield f : I
    //   39: iload #15
    //   41: iadd
    //   42: istore #16
    //   44: aload_0
    //   45: aload_1
    //   46: iload_2
    //   47: aload_3
    //   48: aload #4
    //   50: invokespecial J0 : (Landroid/view/View;ILandroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;)Landroid/view/View;
    //   53: ifnonnull -> 58
    //   56: aconst_null
    //   57: areturn
    //   58: aload_0
    //   59: iload_2
    //   60: invokevirtual R1 : (I)I
    //   63: iconst_1
    //   64: if_icmpne -> 73
    //   67: iconst_1
    //   68: istore #21
    //   70: goto -> 76
    //   73: iconst_0
    //   74: istore #21
    //   76: iload #21
    //   78: aload_0
    //   79: getfield x : Z
    //   82: if_icmpeq -> 90
    //   85: iconst_1
    //   86: istore_2
    //   87: goto -> 92
    //   90: iconst_0
    //   91: istore_2
    //   92: iload_2
    //   93: ifeq -> 113
    //   96: aload_0
    //   97: invokevirtual J : ()I
    //   100: iconst_1
    //   101: isub
    //   102: istore_2
    //   103: iconst_m1
    //   104: istore #5
    //   106: iload #5
    //   108: istore #8
    //   110: goto -> 124
    //   113: aload_0
    //   114: invokevirtual J : ()I
    //   117: istore #5
    //   119: iconst_1
    //   120: istore #8
    //   122: iconst_0
    //   123: istore_2
    //   124: aload_0
    //   125: getfield s : I
    //   128: iconst_1
    //   129: if_icmpne -> 145
    //   132: aload_0
    //   133: invokevirtual q2 : ()Z
    //   136: ifeq -> 145
    //   139: iconst_1
    //   140: istore #9
    //   142: goto -> 148
    //   145: iconst_0
    //   146: istore #9
    //   148: aload_0
    //   149: aload_3
    //   150: aload #4
    //   152: iload_2
    //   153: invokespecial Y2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;I)I
    //   156: istore #17
    //   158: iconst_m1
    //   159: istore #12
    //   161: iload #12
    //   163: istore #6
    //   165: iconst_0
    //   166: istore #7
    //   168: iconst_0
    //   169: istore #10
    //   171: iload_2
    //   172: istore #11
    //   174: aconst_null
    //   175: astore_1
    //   176: iload #10
    //   178: istore_2
    //   179: iload #5
    //   181: istore #10
    //   183: iload #7
    //   185: istore #5
    //   187: iload #11
    //   189: iload #10
    //   191: if_icmpeq -> 570
    //   194: aload_0
    //   195: aload_3
    //   196: aload #4
    //   198: iload #11
    //   200: invokespecial Y2 : (Landroidx/recyclerview/widget/RecyclerView$v;Landroidx/recyclerview/widget/RecyclerView$a0;I)I
    //   203: istore #7
    //   205: aload_0
    //   206: iload #11
    //   208: invokevirtual I : (I)Landroid/view/View;
    //   211: astore #24
    //   213: aload #24
    //   215: aload #22
    //   217: if_acmpne -> 223
    //   220: goto -> 570
    //   223: aload #24
    //   225: invokevirtual hasFocusable : ()Z
    //   228: ifeq -> 249
    //   231: iload #7
    //   233: iload #17
    //   235: if_icmpeq -> 249
    //   238: aload #23
    //   240: ifnull -> 246
    //   243: goto -> 570
    //   246: goto -> 560
    //   249: aload #24
    //   251: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   254: checkcast androidx/recyclerview/widget/GridLayoutManager$b
    //   257: astore #25
    //   259: aload #25
    //   261: getfield e : I
    //   264: istore #18
    //   266: aload #25
    //   268: getfield f : I
    //   271: iload #18
    //   273: iadd
    //   274: istore #19
    //   276: aload #24
    //   278: invokevirtual hasFocusable : ()Z
    //   281: ifeq -> 301
    //   284: iload #18
    //   286: iload #15
    //   288: if_icmpne -> 301
    //   291: iload #19
    //   293: iload #16
    //   295: if_icmpne -> 301
    //   298: aload #24
    //   300: areturn
    //   301: aload #24
    //   303: invokevirtual hasFocusable : ()Z
    //   306: ifeq -> 314
    //   309: aload #23
    //   311: ifnull -> 326
    //   314: aload #24
    //   316: invokevirtual hasFocusable : ()Z
    //   319: ifne -> 332
    //   322: aload_1
    //   323: ifnonnull -> 332
    //   326: iconst_1
    //   327: istore #7
    //   329: goto -> 479
    //   332: iload #18
    //   334: iload #15
    //   336: invokestatic max : (II)I
    //   339: istore #7
    //   341: iload #19
    //   343: iload #16
    //   345: invokestatic min : (II)I
    //   348: iload #7
    //   350: isub
    //   351: istore #20
    //   353: aload #24
    //   355: invokevirtual hasFocusable : ()Z
    //   358: ifeq -> 404
    //   361: iload #20
    //   363: iload #5
    //   365: if_icmple -> 371
    //   368: goto -> 326
    //   371: iload #20
    //   373: iload #5
    //   375: if_icmpne -> 476
    //   378: iload #18
    //   380: iload #12
    //   382: if_icmple -> 391
    //   385: iconst_1
    //   386: istore #7
    //   388: goto -> 394
    //   391: iconst_0
    //   392: istore #7
    //   394: iload #9
    //   396: iload #7
    //   398: if_icmpne -> 476
    //   401: goto -> 368
    //   404: aload #23
    //   406: ifnonnull -> 476
    //   409: iconst_1
    //   410: istore #14
    //   412: iconst_1
    //   413: istore #7
    //   415: aload_0
    //   416: aload #24
    //   418: iconst_0
    //   419: iconst_1
    //   420: invokevirtual y0 : (Landroid/view/View;ZZ)Z
    //   423: ifeq -> 476
    //   426: iload_2
    //   427: istore #13
    //   429: iload #20
    //   431: iload #13
    //   433: if_icmple -> 443
    //   436: iload #14
    //   438: istore #7
    //   440: goto -> 479
    //   443: iload #20
    //   445: iload #13
    //   447: if_icmpne -> 473
    //   450: iload #18
    //   452: iload #6
    //   454: if_icmple -> 460
    //   457: goto -> 463
    //   460: iconst_0
    //   461: istore #7
    //   463: iload #9
    //   465: iload #7
    //   467: if_icmpne -> 476
    //   470: goto -> 326
    //   473: goto -> 476
    //   476: iconst_0
    //   477: istore #7
    //   479: iload #7
    //   481: ifeq -> 560
    //   484: aload #24
    //   486: invokevirtual hasFocusable : ()Z
    //   489: ifeq -> 531
    //   492: aload #25
    //   494: getfield e : I
    //   497: istore #12
    //   499: iload #19
    //   501: iload #16
    //   503: invokestatic min : (II)I
    //   506: istore #5
    //   508: iload #18
    //   510: iload #15
    //   512: invokestatic max : (II)I
    //   515: istore #7
    //   517: aload #24
    //   519: astore #23
    //   521: iload #5
    //   523: iload #7
    //   525: isub
    //   526: istore #5
    //   528: goto -> 560
    //   531: aload #25
    //   533: getfield e : I
    //   536: istore #6
    //   538: iload #19
    //   540: iload #16
    //   542: invokestatic min : (II)I
    //   545: iload #18
    //   547: iload #15
    //   549: invokestatic max : (II)I
    //   552: isub
    //   553: istore_2
    //   554: aload #24
    //   556: astore_1
    //   557: goto -> 560
    //   560: iload #11
    //   562: iload #8
    //   564: iadd
    //   565: istore #11
    //   567: goto -> 187
    //   570: aload #23
    //   572: ifnull -> 578
    //   575: aload #23
    //   577: areturn
    //   578: aload_1
    //   579: areturn
  }
  
  public boolean L1() {
    return (this.D == null && !this.I);
  }
  
  public int N(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.s == 1) ? this.J : ((parama0.b() < 1) ? 0 : (Y2(paramv, parama0, parama0.b() - 1) + 1));
  }
  
  void N1(RecyclerView.a0 parama0, LinearLayoutManager.c paramc, RecyclerView.o.c paramc1) {
    int j = this.J;
    int i;
    for (i = 0; i < this.J && paramc.c(parama0) && j > 0; i++) {
      int k = paramc.d;
      paramc1.a(k, Math.max(0, paramc.g));
      j -= this.O.f(k);
      paramc.d += paramc.e;
    } 
  }
  
  public void P0(RecyclerView.v paramv, RecyclerView.a0 parama0, View paramView, l0.c paramc) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (!(layoutParams instanceof b)) {
      O0(paramView, paramc);
      return;
    } 
    b b = (b)layoutParams;
    int i = Y2(paramv, parama0, b.a());
    if (this.s == 0) {
      paramc.d0(l0.c.c.a(b.e(), b.f(), i, 1, false, false));
      return;
    } 
    paramc.d0(l0.c.c.a(i, 1, b.e(), b.f(), false, false));
  }
  
  public void R0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.O.h();
    this.O.g();
  }
  
  public void S0(RecyclerView paramRecyclerView) {
    this.O.h();
    this.O.g();
  }
  
  public void T0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, int paramInt3) {
    this.O.h();
    this.O.g();
  }
  
  public void U0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2) {
    this.O.h();
    this.O.g();
  }
  
  public void W0(RecyclerView paramRecyclerView, int paramInt1, int paramInt2, Object paramObject) {
    this.O.h();
    this.O.g();
  }
  
  int W2(int paramInt1, int paramInt2) {
    if (this.s == 1 && q2()) {
      int[] arrayOfInt1 = this.K;
      int i = this.J;
      return arrayOfInt1[i - paramInt1] - arrayOfInt1[i - paramInt1 - paramInt2];
    } 
    int[] arrayOfInt = this.K;
    return arrayOfInt[paramInt2 + paramInt1] - arrayOfInt[paramInt1];
  }
  
  public void X0(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    if (parama0.e())
      O2(); 
    super.X0(paramv, parama0);
    R2();
  }
  
  public int X2() {
    return this.J;
  }
  
  public void Y0(RecyclerView.a0 parama0) {
    super.Y0(parama0);
    this.I = false;
  }
  
  public void e3(int paramInt) {
    if (paramInt == this.J)
      return; 
    this.I = true;
    if (paramInt >= 1) {
      this.J = paramInt;
      this.O.h();
      t1();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Span count should be at least 1. Provided ");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  View h2(RecyclerView.v paramv, RecyclerView.a0 parama0, int paramInt1, int paramInt2, int paramInt3) {
    byte b;
    T1();
    int i = this.u.m();
    int j = this.u.i();
    if (paramInt2 > paramInt1) {
      b = 1;
    } else {
      b = -1;
    } 
    View view2 = null;
    View view1;
    for (view1 = null; paramInt1 != paramInt2; view1 = view4) {
      View view5 = I(paramInt1);
      int k = h0(view5);
      View view3 = view2;
      View view4 = view1;
      if (k >= 0) {
        view3 = view2;
        view4 = view1;
        if (k < paramInt3)
          if (Z2(paramv, parama0, k) != 0) {
            view3 = view2;
            view4 = view1;
          } else if (((RecyclerView.p)view5.getLayoutParams()).c()) {
            view3 = view2;
            view4 = view1;
            if (view1 == null) {
              view4 = view5;
              view3 = view2;
            } 
          } else if (this.u.g(view5) >= j || this.u.d(view5) < i) {
            view3 = view2;
            view4 = view1;
            if (view2 == null) {
              view3 = view5;
              view4 = view1;
            } 
          } else {
            return view5;
          }  
      } 
      paramInt1 += b;
      view2 = view3;
    } 
    return (view2 != null) ? view2 : view1;
  }
  
  public int k0(RecyclerView.v paramv, RecyclerView.a0 parama0) {
    return (this.s == 0) ? this.J : ((parama0.b() < 1) ? 0 : (Y2(paramv, parama0, parama0.b() - 1) + 1));
  }
  
  public boolean m(RecyclerView.p paramp) {
    return paramp instanceof b;
  }
  
  public int r(RecyclerView.a0 parama0) {
    return this.Q ? S2(parama0) : super.r(parama0);
  }
  
  public int s(RecyclerView.a0 parama0) {
    return this.Q ? T2(parama0) : super.s(parama0);
  }
  
  void s2(RecyclerView.v paramv, RecyclerView.a0 parama0, LinearLayoutManager.c paramc, LinearLayoutManager.b paramb) {
    StringBuilder stringBuilder;
    int k;
    int m;
    boolean bool;
    int i1 = this.u.l();
    if (i1 != 1073741824) {
      k = 1;
    } else {
      k = 0;
    } 
    if (J() > 0) {
      m = this.K[this.J];
    } else {
      m = 0;
    } 
    if (k)
      f3(); 
    if (paramc.e == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = this.J;
    if (!bool)
      i = Z2(paramv, parama0, paramc.d) + a3(paramv, parama0, paramc.d); 
    int n = 0;
    while (n < this.J && paramc.c(parama0) && i > 0) {
      int i2 = paramc.d;
      int i3 = a3(paramv, parama0, i2);
      if (i3 <= this.J) {
        i -= i3;
        if (i < 0)
          break; 
        View view = paramc.d(paramv);
        if (view == null)
          break; 
        this.L[n] = view;
        n++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Item at position ");
      stringBuilder.append(i2);
      stringBuilder.append(" requires ");
      stringBuilder.append(i3);
      stringBuilder.append(" spans but GridLayoutManager has only ");
      stringBuilder.append(this.J);
      stringBuilder.append(" spans.");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (n == 0) {
      paramb.b = true;
      return;
    } 
    float f = 0.0F;
    N2((RecyclerView.v)stringBuilder, parama0, n, bool);
    int j = 0;
    i = j;
    while (j < n) {
      View view = this.L[j];
      if (paramc.l == null) {
        if (bool) {
          d(view);
        } else {
          e(view, 0);
        } 
      } else if (bool) {
        b(view);
      } else {
        c(view, 0);
      } 
      j(view, this.P);
      c3(view, i1, false);
      int i3 = this.u.e(view);
      int i2 = i;
      if (i3 > i)
        i2 = i3; 
      b b2 = (b)view.getLayoutParams();
      float f2 = this.u.f(view) * 1.0F / b2.f;
      float f1 = f;
      if (f2 > f)
        f1 = f2; 
      j++;
      i = i2;
      f = f1;
    } 
    j = i;
    if (k) {
      b3(f, m);
      k = 0;
      i = 0;
      while (true) {
        j = i;
        if (k < n) {
          View view = this.L[k];
          c3(view, 1073741824, true);
          m = this.u.e(view);
          j = i;
          if (m > i)
            j = m; 
          k++;
          i = j;
          continue;
        } 
        break;
      } 
    } 
    for (i = 0; i < n; i++) {
      View view = this.L[i];
      if (this.u.e(view) != j) {
        b b2 = (b)view.getLayoutParams();
        Rect rect = b2.b;
        m = rect.top + rect.bottom + b2.topMargin + b2.bottomMargin;
        k = rect.left + rect.right + b2.leftMargin + b2.rightMargin;
        int i2 = W2(b2.e, b2.f);
        if (this.s == 1) {
          k = RecyclerView.o.K(i2, 1073741824, k, b2.width, false);
          m = View.MeasureSpec.makeMeasureSpec(j - m, 1073741824);
        } else {
          k = View.MeasureSpec.makeMeasureSpec(j - k, 1073741824);
          m = RecyclerView.o.K(i2, 1073741824, m, b2.height, false);
        } 
        d3(view, k, m, true);
      } 
    } 
    byte b1 = 0;
    paramb.a = j;
    if (this.s == 1) {
      if (paramc.f == -1) {
        i = paramc.b;
        j = i - j;
      } else {
        k = paramc.b;
        i = k;
        k = j + k;
        j = i;
        i = k;
      } 
      m = 0;
      k = m;
    } else if (paramc.f == -1) {
      m = paramc.b;
      k = m - j;
      j = 0;
      i = j;
    } else {
      k = paramc.b;
      m = j + k;
      i = 0;
      j = i;
    } 
    while (true) {
      View view;
      if (b1 < n) {
        int i2;
        view = this.L[b1];
        b b2 = (b)view.getLayoutParams();
        if (this.s == 1) {
          if (q2()) {
            m = e0() + this.K[this.J - b2.e];
            k = m - this.u.f(view);
            i2 = j;
          } else {
            k = e0() + this.K[b2.e];
            m = this.u.f(view);
            i2 = k;
            m += k;
            k = j;
            j = i2;
            z0(view, j, k, m, i);
          } 
        } else {
          i = g0() + this.K[b2.e];
          j = this.u.f(view);
          i2 = i;
          i = j + i;
        } 
        j = k;
        k = i2;
      } else {
        break;
      } 
      z0(view, j, k, m, i);
    } 
    Arrays.fill((Object[])this.L, (Object)null);
  }
  
  public int u(RecyclerView.a0 parama0) {
    return this.Q ? S2(parama0) : super.u(parama0);
  }
  
  void u2(RecyclerView.v paramv, RecyclerView.a0 parama0, LinearLayoutManager.a parama, int paramInt) {
    super.u2(paramv, parama0, parama, paramInt);
    f3();
    if (parama0.b() > 0 && !parama0.e())
      U2(paramv, parama0, parama, paramInt); 
    V2();
  }
  
  public int v(RecyclerView.a0 parama0) {
    return this.Q ? T2(parama0) : super.v(parama0);
  }
  
  public int w1(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    f3();
    V2();
    return super.w1(paramInt, paramv, parama0);
  }
  
  public int y1(int paramInt, RecyclerView.v paramv, RecyclerView.a0 parama0) {
    f3();
    V2();
    return super.y1(paramInt, paramv, parama0);
  }
  
  public static final class a extends c {
    public int e(int param1Int1, int param1Int2) {
      return param1Int1 % param1Int2;
    }
    
    public int f(int param1Int) {
      return 1;
    }
  }
  
  public static class b extends RecyclerView.p {
    int e = -1;
    
    int f = 0;
    
    public b(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public b(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public b(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public b(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public int e() {
      return this.e;
    }
    
    public int f() {
      return this.f;
    }
  }
  
  public static abstract class c {
    final SparseIntArray a = new SparseIntArray();
    
    final SparseIntArray b = new SparseIntArray();
    
    private boolean c = false;
    
    private boolean d = false;
    
    static int a(SparseIntArray param1SparseIntArray, int param1Int) {
      int j = param1SparseIntArray.size() - 1;
      int i = 0;
      while (i <= j) {
        int k = i + j >>> 1;
        if (param1SparseIntArray.keyAt(k) < param1Int) {
          i = k + 1;
          continue;
        } 
        j = k - 1;
      } 
      param1Int = i - 1;
      return (param1Int >= 0 && param1Int < param1SparseIntArray.size()) ? param1SparseIntArray.keyAt(param1Int) : -1;
    }
    
    int b(int param1Int1, int param1Int2) {
      if (!this.d)
        return d(param1Int1, param1Int2); 
      int i = this.b.get(param1Int1, -1);
      if (i != -1)
        return i; 
      param1Int2 = d(param1Int1, param1Int2);
      this.b.put(param1Int1, param1Int2);
      return param1Int2;
    }
    
    int c(int param1Int1, int param1Int2) {
      if (!this.c)
        return e(param1Int1, param1Int2); 
      int i = this.a.get(param1Int1, -1);
      if (i != -1)
        return i; 
      param1Int2 = e(param1Int1, param1Int2);
      this.a.put(param1Int1, param1Int2);
      return param1Int2;
    }
    
    public int d(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield d : Z
      //   4: ifeq -> 82
      //   7: aload_0
      //   8: getfield b : Landroid/util/SparseIntArray;
      //   11: iload_1
      //   12: invokestatic a : (Landroid/util/SparseIntArray;I)I
      //   15: istore_3
      //   16: iload_3
      //   17: iconst_m1
      //   18: if_icmpeq -> 82
      //   21: aload_0
      //   22: getfield b : Landroid/util/SparseIntArray;
      //   25: iload_3
      //   26: invokevirtual get : (I)I
      //   29: istore #7
      //   31: iload_3
      //   32: iconst_1
      //   33: iadd
      //   34: istore #6
      //   36: aload_0
      //   37: iload_3
      //   38: iload_2
      //   39: invokevirtual c : (II)I
      //   42: aload_0
      //   43: iload_3
      //   44: invokevirtual f : (I)I
      //   47: iadd
      //   48: istore #8
      //   50: iload #7
      //   52: istore_3
      //   53: iload #6
      //   55: istore #5
      //   57: iload #8
      //   59: istore #4
      //   61: iload #8
      //   63: iload_2
      //   64: if_icmpne -> 91
      //   67: iload #7
      //   69: iconst_1
      //   70: iadd
      //   71: istore_3
      //   72: iconst_0
      //   73: istore #4
      //   75: iload #6
      //   77: istore #5
      //   79: goto -> 91
      //   82: iconst_0
      //   83: istore_3
      //   84: iload_3
      //   85: istore #5
      //   87: iload #5
      //   89: istore #4
      //   91: aload_0
      //   92: iload_1
      //   93: invokevirtual f : (I)I
      //   96: istore #9
      //   98: iload #4
      //   100: istore #7
      //   102: iload #5
      //   104: istore #6
      //   106: iload_3
      //   107: istore #4
      //   109: iload #6
      //   111: iload_1
      //   112: if_icmpge -> 185
      //   115: aload_0
      //   116: iload #6
      //   118: invokevirtual f : (I)I
      //   121: istore #8
      //   123: iload #7
      //   125: iload #8
      //   127: iadd
      //   128: istore #7
      //   130: iload #7
      //   132: iload_2
      //   133: if_icmpne -> 147
      //   136: iload #4
      //   138: iconst_1
      //   139: iadd
      //   140: istore #5
      //   142: iconst_0
      //   143: istore_3
      //   144: goto -> 169
      //   147: iload #4
      //   149: istore #5
      //   151: iload #7
      //   153: istore_3
      //   154: iload #7
      //   156: iload_2
      //   157: if_icmple -> 169
      //   160: iload #4
      //   162: iconst_1
      //   163: iadd
      //   164: istore #5
      //   166: iload #8
      //   168: istore_3
      //   169: iload #6
      //   171: iconst_1
      //   172: iadd
      //   173: istore #6
      //   175: iload #5
      //   177: istore #4
      //   179: iload_3
      //   180: istore #7
      //   182: goto -> 109
      //   185: iload #4
      //   187: istore_1
      //   188: iload #7
      //   190: iload #9
      //   192: iadd
      //   193: iload_2
      //   194: if_icmple -> 202
      //   197: iload #4
      //   199: iconst_1
      //   200: iadd
      //   201: istore_1
      //   202: iload_1
      //   203: ireturn
    }
    
    public abstract int e(int param1Int1, int param1Int2);
    
    public abstract int f(int param1Int);
    
    public void g() {
      this.b.clear();
    }
    
    public void h() {
      this.a.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\recyclerview\widget\GridLayoutManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */