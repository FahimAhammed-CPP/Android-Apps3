package androidx.recyclerview.widget;

import android.animation.LayoutTransition;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import androidx.core.view.m;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RecyclerView extends ViewGroup implements m {
  private static final int[] D0 = new int[] { 16843830 };
  
  static final boolean E0 = false;
  
  static final boolean F0 = true;
  
  static final boolean G0 = true;
  
  static final boolean H0 = true;
  
  private static final boolean I0 = false;
  
  private static final boolean J0 = false;
  
  private static final Class<?>[] K0;
  
  static final Interpolator L0 = new c();
  
  private int A;
  
  final List<d0> A0;
  
  boolean B;
  
  private Runnable B0;
  
  boolean C;
  
  private final p.b C0;
  
  private boolean D;
  
  private int E;
  
  boolean F;
  
  private final AccessibilityManager G;
  
  private List<q> H;
  
  boolean I;
  
  boolean J;
  
  private int K;
  
  private int L;
  
  private k M;
  
  private EdgeEffect N;
  
  private EdgeEffect O;
  
  private EdgeEffect P;
  
  private EdgeEffect Q;
  
  l R;
  
  private int S;
  
  private int T;
  
  private VelocityTracker U;
  
  private int V;
  
  private int W;
  
  private int a0;
  
  private int b0;
  
  private int c0;
  
  private r d0;
  
  private final int e0;
  
  private final x f;
  
  private final int f0;
  
  final v g;
  
  private float g0;
  
  private y h;
  
  private float h0;
  
  a i;
  
  private boolean i0;
  
  b j;
  
  final c0 j0;
  
  final p k;
  
  e k0;
  
  boolean l;
  
  e.b l0;
  
  final Runnable m;
  
  final a0 m0;
  
  final Rect n;
  
  private t n0;
  
  private final Rect o;
  
  private List<t> o0;
  
  final RectF p;
  
  boolean p0;
  
  g q;
  
  boolean q0;
  
  o r;
  
  private l.b r0;
  
  w s;
  
  boolean s0;
  
  final ArrayList<n> t;
  
  k t0;
  
  private final ArrayList<s> u;
  
  private j u0;
  
  private s v;
  
  private final int[] v0;
  
  boolean w;
  
  private androidx.core.view.n w0;
  
  boolean x;
  
  private final int[] x0;
  
  boolean y;
  
  private final int[] y0;
  
  boolean z;
  
  final int[] z0;
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, d1.a.a);
  }
  
  public RecyclerView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    e.b b1;
    this.f = new x(this);
    this.g = new v(this);
    this.k = new p();
    this.m = new a(this);
    this.n = new Rect();
    this.o = new Rect();
    this.p = new RectF();
    this.t = new ArrayList<n>();
    this.u = new ArrayList<s>();
    this.A = 0;
    this.I = false;
    this.J = false;
    this.K = 0;
    this.L = 0;
    this.M = new k();
    this.R = new c();
    this.S = 0;
    this.T = -1;
    this.g0 = Float.MIN_VALUE;
    this.h0 = Float.MIN_VALUE;
    this.i0 = true;
    this.j0 = new c0(this);
    if (H0) {
      b1 = new e.b();
    } else {
      b1 = null;
    } 
    this.l0 = b1;
    this.m0 = new a0();
    this.p0 = false;
    this.q0 = false;
    this.r0 = new m(this);
    this.s0 = false;
    this.v0 = new int[2];
    this.x0 = new int[2];
    this.y0 = new int[2];
    this.z0 = new int[2];
    this.A0 = new ArrayList<d0>();
    this.B0 = new b(this);
    this.C0 = new d(this);
    setScrollContainer(true);
    setFocusableInTouchMode(true);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    this.c0 = viewConfiguration.getScaledTouchSlop();
    this.g0 = androidx.core.view.y.b(viewConfiguration, paramContext);
    this.h0 = androidx.core.view.y.d(viewConfiguration, paramContext);
    this.e0 = viewConfiguration.getScaledMinimumFlingVelocity();
    this.f0 = viewConfiguration.getScaledMaximumFlingVelocity();
    if (getOverScrollMode() == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    this.R.v(this.r0);
    n0();
    p0();
    o0();
    if (androidx.core.view.w.z((View)this) == 0)
      androidx.core.view.w.y0((View)this, 1); 
    this.G = (AccessibilityManager)getContext().getSystemService("accessibility");
    setAccessibilityDelegateCompat(new k(this));
    int[] arrayOfInt2 = d1.c.f;
    TypedArray typedArray1 = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt2, paramInt, 0);
    int i = Build.VERSION.SDK_INT;
    if (i >= 29)
      saveAttributeDataForStyleable(paramContext, arrayOfInt2, paramAttributeSet, typedArray1, paramInt, 0); 
    String str = typedArray1.getString(d1.c.o);
    if (typedArray1.getInt(d1.c.i, -1) == -1)
      setDescendantFocusability(262144); 
    this.l = typedArray1.getBoolean(d1.c.h, true);
    boolean bool = typedArray1.getBoolean(d1.c.j, false);
    this.y = bool;
    if (bool)
      q0((StateListDrawable)typedArray1.getDrawable(d1.c.m), typedArray1.getDrawable(d1.c.n), (StateListDrawable)typedArray1.getDrawable(d1.c.k), typedArray1.getDrawable(d1.c.l)); 
    typedArray1.recycle();
    v(paramContext, str, paramAttributeSet, paramInt, 0);
    int[] arrayOfInt1 = D0;
    TypedArray typedArray2 = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt1, paramInt, 0);
    if (i >= 29)
      saveAttributeDataForStyleable(paramContext, arrayOfInt1, paramAttributeSet, typedArray2, paramInt, 0); 
    bool = typedArray2.getBoolean(0, true);
    typedArray2.recycle();
    setNestedScrollingEnabled(bool);
  }
  
  private void A() {
    int i = this.E;
    this.E = 0;
    if (i != 0 && s0()) {
      AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain();
      accessibilityEvent.setEventType(2048);
      l0.b.b(accessibilityEvent, i);
      sendAccessibilityEventUnchecked(accessibilityEvent);
    } 
  }
  
  private void C() {
    a0 a01 = this.m0;
    boolean bool = true;
    a01.a(1);
    Q(this.m0);
    this.m0.j = false;
    p1();
    this.k.f();
    F0();
    N0();
    c1();
    a01 = this.m0;
    if (!a01.k || !this.q0)
      bool = false; 
    a01.i = bool;
    this.q0 = false;
    this.p0 = false;
    a01.h = a01.l;
    a01.f = this.q.c();
    U(this.v0);
    if (this.m0.k) {
      int i1 = this.j.g();
      for (int i = 0; i < i1; i++) {
        d0 d0 = f0(this.j.f(i));
        if (!d0.J() && (!d0.t() || this.q.g())) {
          l.c c = this.R.t(this.m0, d0, l.e(d0), d0.o());
          this.k.e(d0, c);
          if (this.m0.i && d0.y() && !d0.v() && !d0.J() && !d0.t()) {
            long l1 = c0(d0);
            this.k.c(l1, d0);
          } 
        } 
      } 
    } 
    if (this.m0.l) {
      d1();
      a01 = this.m0;
      bool = a01.g;
      a01.g = false;
      this.r.X0(this.g, a01);
      this.m0.g = bool;
      for (int i = 0; i < this.j.g(); i++) {
        d0 d0 = f0(this.j.f(i));
        if (!d0.J() && !this.k.i(d0)) {
          int i2 = l.e(d0);
          bool = d0.p(8192);
          int i1 = i2;
          if (!bool)
            i1 = i2 | 0x1000; 
          l.c c = this.R.t(this.m0, d0, i1, d0.o());
          if (bool) {
            Q0(d0, c);
          } else {
            this.k.a(d0, c);
          } 
        } 
      } 
      s();
    } else {
      s();
    } 
    G0();
    r1(false);
    this.m0.e = 2;
  }
  
  private void D() {
    boolean bool;
    p1();
    F0();
    this.m0.a(6);
    this.i.j();
    this.m0.f = this.q.c();
    a0 a01 = this.m0;
    a01.d = 0;
    a01.h = false;
    this.r.X0(this.g, a01);
    a01 = this.m0;
    a01.g = false;
    this.h = null;
    if (a01.k && this.R != null) {
      bool = true;
    } else {
      bool = false;
    } 
    a01.k = bool;
    a01.e = 4;
    G0();
    r1(false);
  }
  
  private void E() {
    this.m0.a(4);
    p1();
    F0();
    a0 a01 = this.m0;
    a01.e = 1;
    if (a01.k) {
      for (int i = this.j.g() - 1; i >= 0; i--) {
        d0 d0 = f0(this.j.f(i));
        if (!d0.J()) {
          long l1 = c0(d0);
          l.c c = this.R.s(this.m0, d0);
          d0 d01 = this.k.g(l1);
          if (d01 != null && !d01.J()) {
            boolean bool1 = this.k.h(d01);
            boolean bool2 = this.k.h(d0);
            if (bool1 && d01 == d0) {
              this.k.d(d0, c);
            } else {
              l.c c1 = this.k.n(d01);
              this.k.d(d0, c);
              c = this.k.m(d0);
              if (c1 == null) {
                k0(l1, d0, d01);
              } else {
                m(d01, d0, c1, c, bool1, bool2);
              } 
            } 
          } else {
            this.k.d(d0, c);
          } 
        } 
      } 
      this.k.o(this.C0);
    } 
    this.r.l1(this.g);
    a01 = this.m0;
    a01.c = a01.f;
    this.I = false;
    this.J = false;
    a01.k = false;
    a01.l = false;
    this.r.h = false;
    ArrayList<d0> arrayList = this.g.b;
    if (arrayList != null)
      arrayList.clear(); 
    o o1 = this.r;
    if (o1.n) {
      o1.m = 0;
      o1.n = false;
      this.g.K();
    } 
    this.r.Y0(this.m0);
    G0();
    r1(false);
    this.k.f();
    int[] arrayOfInt = this.v0;
    if (x(arrayOfInt[0], arrayOfInt[1]))
      I(0, 0); 
    R0();
    a1();
  }
  
  private void I0(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.T) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.T = paramMotionEvent.getPointerId(i);
      int i1 = (int)(paramMotionEvent.getX(i) + 0.5F);
      this.a0 = i1;
      this.V = i1;
      i = (int)(paramMotionEvent.getY(i) + 0.5F);
      this.b0 = i;
      this.W = i;
    } 
  }
  
  private boolean K(MotionEvent paramMotionEvent) {
    s s1 = this.v;
    if (s1 == null)
      return (paramMotionEvent.getAction() == 0) ? false : T(paramMotionEvent); 
    s1.b(this, paramMotionEvent);
    int i = paramMotionEvent.getAction();
    if (i == 3 || i == 1)
      this.v = null; 
    return true;
  }
  
  private boolean M0() {
    return (this.R != null && this.r.L1());
  }
  
  private void N0() {
    // Byte code:
    //   0: aload_0
    //   1: getfield I : Z
    //   4: ifeq -> 29
    //   7: aload_0
    //   8: getfield i : Landroidx/recyclerview/widget/a;
    //   11: invokevirtual u : ()V
    //   14: aload_0
    //   15: getfield J : Z
    //   18: ifeq -> 29
    //   21: aload_0
    //   22: getfield r : Landroidx/recyclerview/widget/RecyclerView$o;
    //   25: aload_0
    //   26: invokevirtual S0 : (Landroidx/recyclerview/widget/RecyclerView;)V
    //   29: aload_0
    //   30: invokespecial M0 : ()Z
    //   33: ifeq -> 46
    //   36: aload_0
    //   37: getfield i : Landroidx/recyclerview/widget/a;
    //   40: invokevirtual s : ()V
    //   43: goto -> 53
    //   46: aload_0
    //   47: getfield i : Landroidx/recyclerview/widget/a;
    //   50: invokevirtual j : ()V
    //   53: aload_0
    //   54: getfield p0 : Z
    //   57: istore_2
    //   58: iconst_0
    //   59: istore_3
    //   60: iload_2
    //   61: ifne -> 79
    //   64: aload_0
    //   65: getfield q0 : Z
    //   68: ifeq -> 74
    //   71: goto -> 79
    //   74: iconst_0
    //   75: istore_1
    //   76: goto -> 81
    //   79: iconst_1
    //   80: istore_1
    //   81: aload_0
    //   82: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
    //   85: astore #4
    //   87: aload_0
    //   88: getfield z : Z
    //   91: ifeq -> 143
    //   94: aload_0
    //   95: getfield R : Landroidx/recyclerview/widget/RecyclerView$l;
    //   98: ifnull -> 143
    //   101: aload_0
    //   102: getfield I : Z
    //   105: istore_2
    //   106: iload_2
    //   107: ifne -> 124
    //   110: iload_1
    //   111: ifne -> 124
    //   114: aload_0
    //   115: getfield r : Landroidx/recyclerview/widget/RecyclerView$o;
    //   118: getfield h : Z
    //   121: ifeq -> 143
    //   124: iload_2
    //   125: ifeq -> 138
    //   128: aload_0
    //   129: getfield q : Landroidx/recyclerview/widget/RecyclerView$g;
    //   132: invokevirtual g : ()Z
    //   135: ifeq -> 143
    //   138: iconst_1
    //   139: istore_2
    //   140: goto -> 145
    //   143: iconst_0
    //   144: istore_2
    //   145: aload #4
    //   147: iload_2
    //   148: putfield k : Z
    //   151: aload_0
    //   152: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
    //   155: astore #4
    //   157: iload_3
    //   158: istore_2
    //   159: aload #4
    //   161: getfield k : Z
    //   164: ifeq -> 193
    //   167: iload_3
    //   168: istore_2
    //   169: iload_1
    //   170: ifeq -> 193
    //   173: iload_3
    //   174: istore_2
    //   175: aload_0
    //   176: getfield I : Z
    //   179: ifne -> 193
    //   182: iload_3
    //   183: istore_2
    //   184: aload_0
    //   185: invokespecial M0 : ()Z
    //   188: ifeq -> 193
    //   191: iconst_1
    //   192: istore_2
    //   193: aload #4
    //   195: iload_2
    //   196: putfield l : Z
    //   199: return
  }
  
  private void P0(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #6
    //   3: fload_2
    //   4: fconst_0
    //   5: fcmpg
    //   6: ifge -> 43
    //   9: aload_0
    //   10: invokevirtual M : ()V
    //   13: aload_0
    //   14: getfield N : Landroid/widget/EdgeEffect;
    //   17: fload_2
    //   18: fneg
    //   19: aload_0
    //   20: invokevirtual getWidth : ()I
    //   23: i2f
    //   24: fdiv
    //   25: fconst_1
    //   26: fload_3
    //   27: aload_0
    //   28: invokevirtual getHeight : ()I
    //   31: i2f
    //   32: fdiv
    //   33: fsub
    //   34: invokestatic c : (Landroid/widget/EdgeEffect;FF)V
    //   37: iconst_1
    //   38: istore #5
    //   40: goto -> 80
    //   43: fload_2
    //   44: fconst_0
    //   45: fcmpl
    //   46: ifle -> 77
    //   49: aload_0
    //   50: invokevirtual N : ()V
    //   53: aload_0
    //   54: getfield P : Landroid/widget/EdgeEffect;
    //   57: fload_2
    //   58: aload_0
    //   59: invokevirtual getWidth : ()I
    //   62: i2f
    //   63: fdiv
    //   64: fload_3
    //   65: aload_0
    //   66: invokevirtual getHeight : ()I
    //   69: i2f
    //   70: fdiv
    //   71: invokestatic c : (Landroid/widget/EdgeEffect;FF)V
    //   74: goto -> 37
    //   77: iconst_0
    //   78: istore #5
    //   80: fload #4
    //   82: fconst_0
    //   83: fcmpg
    //   84: ifge -> 121
    //   87: aload_0
    //   88: invokevirtual O : ()V
    //   91: aload_0
    //   92: getfield O : Landroid/widget/EdgeEffect;
    //   95: fload #4
    //   97: fneg
    //   98: aload_0
    //   99: invokevirtual getHeight : ()I
    //   102: i2f
    //   103: fdiv
    //   104: fload_1
    //   105: aload_0
    //   106: invokevirtual getWidth : ()I
    //   109: i2f
    //   110: fdiv
    //   111: invokestatic c : (Landroid/widget/EdgeEffect;FF)V
    //   114: iload #6
    //   116: istore #5
    //   118: goto -> 163
    //   121: fload #4
    //   123: fconst_0
    //   124: fcmpl
    //   125: ifle -> 163
    //   128: aload_0
    //   129: invokevirtual L : ()V
    //   132: aload_0
    //   133: getfield Q : Landroid/widget/EdgeEffect;
    //   136: fload #4
    //   138: aload_0
    //   139: invokevirtual getHeight : ()I
    //   142: i2f
    //   143: fdiv
    //   144: fconst_1
    //   145: fload_1
    //   146: aload_0
    //   147: invokevirtual getWidth : ()I
    //   150: i2f
    //   151: fdiv
    //   152: fsub
    //   153: invokestatic c : (Landroid/widget/EdgeEffect;FF)V
    //   156: iload #6
    //   158: istore #5
    //   160: goto -> 163
    //   163: iload #5
    //   165: ifne -> 181
    //   168: fload_2
    //   169: fconst_0
    //   170: fcmpl
    //   171: ifne -> 181
    //   174: fload #4
    //   176: fconst_0
    //   177: fcmpl
    //   178: ifeq -> 185
    //   181: aload_0
    //   182: invokestatic f0 : (Landroid/view/View;)V
    //   185: return
  }
  
  private void R0() {
    if (this.i0 && this.q != null && hasFocus() && getDescendantFocusability() != 393216) {
      View view1;
      if (getDescendantFocusability() == 131072 && isFocused())
        return; 
      if (!isFocused()) {
        view1 = getFocusedChild();
        if (J0 && (view1.getParent() == null || !view1.hasFocus())) {
          if (this.j.g() == 0) {
            requestFocus();
            return;
          } 
        } else if (!this.j.n(view1)) {
          return;
        } 
      } 
      long l1 = this.m0.n;
      View view2 = null;
      if (l1 != -1L && this.q.g()) {
        view1 = (View)Y(this.m0.n);
      } else {
        view1 = null;
      } 
      if (view1 == null || this.j.n(((d0)view1).a) || !((d0)view1).a.hasFocusable()) {
        view1 = view2;
        if (this.j.g() > 0)
          view1 = W(); 
      } else {
        view1 = ((d0)view1).a;
      } 
      if (view1 != null) {
        int i = this.m0.o;
        view2 = view1;
        if (i != -1L) {
          View view = view1.findViewById(i);
          view2 = view1;
          if (view != null) {
            view2 = view1;
            if (view.isFocusable())
              view2 = view; 
          } 
        } 
        view2.requestFocus();
      } 
    } 
  }
  
  private void S0() {
    EdgeEffect edgeEffect = this.N;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool2 = this.N.isFinished();
    } else {
      bool2 = false;
    } 
    edgeEffect = this.O;
    boolean bool1 = bool2;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool1 = bool2 | this.O.isFinished();
    } 
    edgeEffect = this.P;
    boolean bool2 = bool1;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool2 = bool1 | this.P.isFinished();
    } 
    edgeEffect = this.Q;
    bool1 = bool2;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      bool1 = bool2 | this.Q.isFinished();
    } 
    if (bool1)
      androidx.core.view.w.f0((View)this); 
  }
  
  private boolean T(MotionEvent paramMotionEvent) {
    int i1 = paramMotionEvent.getAction();
    int i2 = this.u.size();
    for (int i = 0; i < i2; i++) {
      s s1 = this.u.get(i);
      if (s1.a(this, paramMotionEvent) && i1 != 3) {
        this.v = s1;
        return true;
      } 
    } 
    return false;
  }
  
  private void U(int[] paramArrayOfint) {
    int i3 = this.j.g();
    if (i3 == 0) {
      paramArrayOfint[0] = -1;
      paramArrayOfint[1] = -1;
      return;
    } 
    int i = Integer.MAX_VALUE;
    int i2 = Integer.MIN_VALUE;
    int i1 = 0;
    while (i1 < i3) {
      int i4;
      d0 d0 = f0(this.j.f(i1));
      if (d0.J()) {
        i4 = i2;
      } else {
        int i6 = d0.m();
        int i5 = i;
        if (i6 < i)
          i5 = i6; 
        i = i5;
        i4 = i2;
        if (i6 > i2) {
          i4 = i6;
          i = i5;
        } 
      } 
      i1++;
      i2 = i4;
    } 
    paramArrayOfint[0] = i;
    paramArrayOfint[1] = i2;
  }
  
  static RecyclerView V(View paramView) {
    if (!(paramView instanceof ViewGroup))
      return null; 
    if (paramView instanceof RecyclerView)
      return (RecyclerView)paramView; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int i1 = viewGroup.getChildCount();
    for (int i = 0; i < i1; i++) {
      RecyclerView recyclerView = V(viewGroup.getChildAt(i));
      if (recyclerView != null)
        return recyclerView; 
    } 
    return null;
  }
  
  private View W() {
    a0 a01 = this.m0;
    int i = a01.m;
    if (i == -1)
      i = 0; 
    int i2 = a01.b();
    for (int i1 = i; i1 < i2; i1++) {
      d0 d0 = X(i1);
      if (d0 == null)
        break; 
      if (d0.a.hasFocusable())
        return d0.a; 
    } 
    for (i = Math.min(i2, i) - 1; i >= 0; i--) {
      d0 d0 = X(i);
      if (d0 == null)
        return null; 
      if (d0.a.hasFocusable())
        return d0.a; 
    } 
    return null;
  }
  
  private void Z0(View paramView1, View paramView2) {
    boolean bool;
    View view;
    if (paramView2 != null) {
      view = paramView2;
    } else {
      view = paramView1;
    } 
    this.n.set(0, 0, view.getWidth(), view.getHeight());
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (layoutParams instanceof p) {
      p p1 = (p)layoutParams;
      if (!p1.c) {
        Rect rect1 = p1.b;
        Rect rect2 = this.n;
        rect2.left -= rect1.left;
        rect2.right += rect1.right;
        rect2.top -= rect1.top;
        rect2.bottom += rect1.bottom;
      } 
    } 
    if (paramView2 != null) {
      offsetDescendantRectToMyCoords(paramView2, this.n);
      offsetRectIntoDescendantCoords(paramView1, this.n);
    } 
    o o1 = this.r;
    Rect rect = this.n;
    boolean bool1 = this.z;
    if (paramView2 == null) {
      bool = true;
    } else {
      bool = false;
    } 
    o1.s1(this, paramView1, rect, bool1 ^ true, bool);
  }
  
  private void a1() {
    a0 a01 = this.m0;
    a01.n = -1L;
    a01.m = -1;
    a01.o = -1;
  }
  
  private void b1() {
    VelocityTracker velocityTracker = this.U;
    if (velocityTracker != null)
      velocityTracker.clear(); 
    s1(0);
    S0();
  }
  
  private void c1() {
    int i;
    long l1;
    d0 d01;
    boolean bool = this.i0;
    d0 d02 = null;
    if (bool && hasFocus() && this.q != null) {
      d01 = (d0)getFocusedChild();
    } else {
      d01 = null;
    } 
    if (d01 == null) {
      d01 = d02;
    } else {
      d01 = S((View)d01);
    } 
    if (d01 == null) {
      a1();
      return;
    } 
    a0 a01 = this.m0;
    if (this.q.g()) {
      l1 = d01.k();
    } else {
      l1 = -1L;
    } 
    a01.n = l1;
    a01 = this.m0;
    if (this.I) {
      i = -1;
    } else if (d01.v()) {
      i = d01.d;
    } else {
      i = d01.j();
    } 
    a01.m = i;
    this.m0.o = h0(d01.a);
  }
  
  static d0 f0(View paramView) {
    return (paramView == null) ? null : ((p)paramView.getLayoutParams()).a;
  }
  
  private void g(d0 paramd0) {
    boolean bool;
    View view = paramd0.a;
    if (view.getParent() == this) {
      bool = true;
    } else {
      bool = false;
    } 
    this.g.J(e0(view));
    if (paramd0.x()) {
      this.j.c(view, -1, view.getLayoutParams(), true);
      return;
    } 
    if (!bool) {
      this.j.b(view, true);
      return;
    } 
    this.j.k(view);
  }
  
  static void g0(View paramView, Rect paramRect) {
    p p1 = (p)paramView.getLayoutParams();
    Rect rect = p1.b;
    paramRect.set(paramView.getLeft() - rect.left - p1.leftMargin, paramView.getTop() - rect.top - p1.topMargin, paramView.getRight() + rect.right + p1.rightMargin, paramView.getBottom() + rect.bottom + p1.bottomMargin);
  }
  
  private androidx.core.view.n getScrollingChildHelper() {
    if (this.w0 == null)
      this.w0 = new androidx.core.view.n((View)this); 
    return this.w0;
  }
  
  private int h0(View paramView) {
    int i = paramView.getId();
    while (!paramView.isFocused() && paramView instanceof ViewGroup && paramView.hasFocus()) {
      View view = ((ViewGroup)paramView).getFocusedChild();
      paramView = view;
      if (view.getId() != -1) {
        i = view.getId();
        paramView = view;
      } 
    } 
    return i;
  }
  
  private void h1(g paramg, boolean paramBoolean1, boolean paramBoolean2) {
    g g1 = this.q;
    if (g1 != null) {
      g1.t(this.f);
      this.q.m(this);
    } 
    if (!paramBoolean1 || paramBoolean2)
      T0(); 
    this.i.u();
    g1 = this.q;
    this.q = paramg;
    if (paramg != null) {
      paramg.r(this.f);
      paramg.i(this);
    } 
    o o1 = this.r;
    if (o1 != null)
      o1.E0(g1, this.q); 
    this.g.x(g1, this.q, paramBoolean1);
    this.m0.g = true;
  }
  
  private String i0(Context paramContext, String paramString) {
    if (paramString.charAt(0) == '.') {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramContext.getPackageName());
      stringBuilder1.append(paramString);
      return stringBuilder1.toString();
    } 
    if (paramString.contains("."))
      return paramString; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(RecyclerView.class.getPackage().getName());
    stringBuilder.append('.');
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  private void k0(long paramLong, d0 paramd01, d0 paramd02) {
    StringBuilder stringBuilder1;
    int i1 = this.j.g();
    int i;
    for (i = 0; i < i1; i++) {
      d0 d01 = f0(this.j.f(i));
      if (d01 != paramd01 && c0(d01) == paramLong) {
        g g1 = this.q;
        if (g1 != null && g1.g()) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
          stringBuilder.append(d01);
          stringBuilder.append(" \n View Holder 2:");
          stringBuilder.append(paramd01);
          stringBuilder.append(P());
          throw new IllegalStateException(stringBuilder.toString());
        } 
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
        stringBuilder1.append(d01);
        stringBuilder1.append(" \n View Holder 2:");
        stringBuilder1.append(paramd01);
        stringBuilder1.append(P());
        throw new IllegalStateException(stringBuilder1.toString());
      } 
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Problem while matching changed view holders with the newones. The pre-layout information for the change holder ");
    stringBuilder2.append(stringBuilder1);
    stringBuilder2.append(" cannot be found but it is necessary for ");
    stringBuilder2.append(paramd01);
    stringBuilder2.append(P());
    Log.e("RecyclerView", stringBuilder2.toString());
  }
  
  private void m(d0 paramd01, d0 paramd02, l.c paramc1, l.c paramc2, boolean paramBoolean1, boolean paramBoolean2) {
    paramd01.G(false);
    if (paramBoolean1)
      g(paramd01); 
    if (paramd01 != paramd02) {
      if (paramBoolean2)
        g(paramd02); 
      paramd01.h = paramd02;
      g(paramd01);
      this.g.J(paramd01);
      paramd02.G(false);
      paramd02.i = paramd01;
    } 
    if (this.R.b(paramd01, paramd02, paramc1, paramc2))
      L0(); 
  }
  
  private boolean m0() {
    int i1 = this.j.g();
    for (int i = 0; i < i1; i++) {
      d0 d0 = f0(this.j.f(i));
      if (d0 != null && !d0.J() && d0.y())
        return true; 
    } 
    return false;
  }
  
  @SuppressLint({"InlinedApi"})
  private void o0() {
    if (androidx.core.view.w.A((View)this) == 0)
      androidx.core.view.w.z0((View)this, 8); 
  }
  
  private void p0() {
    this.j = new b(new e(this));
  }
  
  private void q() {
    b1();
    setScrollState(0);
  }
  
  static void r(d0 paramd0) {
    WeakReference<RecyclerView> weakReference = paramd0.b;
    if (weakReference != null) {
      View view = (View)weakReference.get();
      while (view != null) {
        if (view == paramd0.a)
          return; 
        ViewParent viewParent = view.getParent();
        if (viewParent instanceof View) {
          View view1 = (View)viewParent;
          continue;
        } 
        viewParent = null;
      } 
      paramd0.b = null;
    } 
  }
  
  private boolean u0(View paramView1, View paramView2, int paramInt) {
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool1 = false;
    boolean bool6 = false;
    boolean bool2 = false;
    null = bool6;
    if (paramView2 != null) {
      byte b2;
      if (paramView2 == this)
        return false; 
      if (R(paramView2) == null)
        return false; 
      if (paramView1 == null)
        return true; 
      if (R(paramView1) == null)
        return true; 
      this.n.set(0, 0, paramView1.getWidth(), paramView1.getHeight());
      this.o.set(0, 0, paramView2.getWidth(), paramView2.getHeight());
      offsetDescendantRectToMyCoords(paramView1, this.n);
      offsetDescendantRectToMyCoords(paramView2, this.o);
      int i = this.r.Z();
      byte b1 = -1;
      if (i == 1) {
        b2 = -1;
      } else {
        b2 = 1;
      } 
      Rect rect1 = this.n;
      i = rect1.left;
      Rect rect2 = this.o;
      int i1 = rect2.left;
      if ((i < i1 || rect1.right <= i1) && rect1.right < rect2.right) {
        i = 1;
      } else {
        int i3 = rect1.right;
        int i4 = rect2.right;
        if ((i3 > i4 || i >= i4) && i > i1) {
          i = -1;
        } else {
          i = 0;
        } 
      } 
      i1 = rect1.top;
      int i2 = rect2.top;
      if ((i1 < i2 || rect1.bottom <= i2) && rect1.bottom < rect2.bottom) {
        b1 = 1;
      } else {
        int i3 = rect1.bottom;
        int i4 = rect2.bottom;
        if ((i3 <= i4 && i1 < i4) || i1 <= i2)
          b1 = 0; 
      } 
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 17) {
            if (paramInt != 33) {
              if (paramInt != 66) {
                if (paramInt == 130) {
                  null = bool2;
                  if (b1 > 0)
                    null = true; 
                  return null;
                } 
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid direction: ");
                stringBuilder.append(paramInt);
                stringBuilder.append(P());
                throw new IllegalArgumentException(stringBuilder.toString());
              } 
              null = bool3;
              if (i > 0)
                null = true; 
              return null;
            } 
            null = bool4;
            if (b1 < 0)
              null = true; 
            return null;
          } 
          null = bool5;
          if (i < 0)
            null = true; 
          return null;
        } 
        if (b1 <= 0) {
          null = bool1;
          if (b1 == 0) {
            null = bool1;
            if (i * b2 >= 0)
              return true; 
          } 
          return null;
        } 
      } else {
        if (b1 >= 0) {
          null = bool6;
          if (b1 == 0) {
            null = bool6;
            if (i * b2 <= 0)
              null = true; 
          } 
          return null;
        } 
        null = true;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  private void u1() {
    this.j0.g();
    o o1 = this.r;
    if (o1 != null)
      o1.K1(); 
  }
  
  private void v(Context paramContext, String paramString, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    if (paramString != null) {
      paramString = paramString.trim();
      if (!paramString.isEmpty()) {
        String str = i0(paramContext, paramString);
        try {
          StringBuilder stringBuilder;
          ClassLoader classLoader;
          if (isInEditMode()) {
            classLoader = getClass().getClassLoader();
          } else {
            classLoader = paramContext.getClassLoader();
          } 
          Class<? extends o> clazz = Class.forName(str, false, classLoader).asSubclass(o.class);
          NoSuchMethodException noSuchMethodException2 = null;
          try {
            Constructor<? extends o> constructor = clazz.getConstructor(K0);
            Object[] arrayOfObject = { paramContext, paramAttributeSet, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) };
          } catch (NoSuchMethodException noSuchMethodException) {
            try {
              Constructor<? extends o> constructor = clazz.getConstructor(new Class[0]);
              noSuchMethodException = noSuchMethodException2;
              constructor.setAccessible(true);
              setLayoutManager(constructor.newInstance((Object[])noSuchMethodException));
              return;
            } catch (NoSuchMethodException noSuchMethodException1) {
              noSuchMethodException1.initCause(noSuchMethodException);
              stringBuilder = new StringBuilder();
              stringBuilder.append(paramAttributeSet.getPositionDescription());
              stringBuilder.append(": Error creating LayoutManager ");
              stringBuilder.append(str);
              throw new IllegalStateException(stringBuilder.toString(), noSuchMethodException1);
            } 
          } 
          noSuchMethodException1.setAccessible(true);
          setLayoutManager(noSuchMethodException1.newInstance((Object[])stringBuilder));
          return;
        } catch (ClassNotFoundException classNotFoundException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Unable to find LayoutManager ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), classNotFoundException);
        } catch (InvocationTargetException invocationTargetException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Could not instantiate the LayoutManager: ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), invocationTargetException);
        } catch (InstantiationException instantiationException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Could not instantiate the LayoutManager: ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), instantiationException);
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Cannot access non-public constructor ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), illegalAccessException);
        } catch (ClassCastException classCastException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramAttributeSet.getPositionDescription());
          stringBuilder.append(": Class is not a LayoutManager ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString(), classCastException);
        } 
      } 
    } 
  }
  
  private boolean x(int paramInt1, int paramInt2) {
    U(this.v0);
    int[] arrayOfInt = this.v0;
    boolean bool = false;
    if (arrayOfInt[0] != paramInt1 || arrayOfInt[1] != paramInt2)
      bool = true; 
    return bool;
  }
  
  void A0(int paramInt1, int paramInt2) {
    int i1 = this.j.j();
    for (int i = 0; i < i1; i++) {
      d0 d0 = f0(this.j.i(i));
      if (d0 != null && !d0.J() && d0.c >= paramInt1) {
        d0.A(paramInt2, false);
        this.m0.g = true;
      } 
    } 
    this.g.u(paramInt1, paramInt2);
    requestLayout();
  }
  
  void B() {
    if (this.q == null) {
      Log.e("RecyclerView", "No adapter attached; skipping layout");
      return;
    } 
    if (this.r == null) {
      Log.e("RecyclerView", "No layout manager attached; skipping layout");
      return;
    } 
    a0 a01 = this.m0;
    a01.j = false;
    if (a01.e == 1) {
      C();
      this.r.z1(this);
      D();
    } else if (this.i.q() || this.r.o0() != getWidth() || this.r.W() != getHeight()) {
      this.r.z1(this);
      D();
    } else {
      this.r.z1(this);
    } 
    E();
  }
  
  void B0(int paramInt1, int paramInt2) {
    boolean bool;
    int i;
    int i1;
    int i3 = this.j.j();
    if (paramInt1 < paramInt2) {
      bool = true;
      i = paramInt1;
      i1 = paramInt2;
    } else {
      i1 = paramInt1;
      i = paramInt2;
      bool = true;
    } 
    int i2;
    for (i2 = 0; i2 < i3; i2++) {
      d0 d0 = f0(this.j.i(i2));
      if (d0 != null) {
        int i4 = d0.c;
        if (i4 >= i && i4 <= i1) {
          if (i4 == paramInt1) {
            d0.A(paramInt2 - paramInt1, false);
          } else {
            d0.A(bool, false);
          } 
          this.m0.g = true;
        } 
      } 
    } 
    this.g.v(paramInt1, paramInt2);
    requestLayout();
  }
  
  void C0(int paramInt1, int paramInt2, boolean paramBoolean) {
    int i1 = this.j.j();
    int i;
    for (i = 0; i < i1; i++) {
      d0 d0 = f0(this.j.i(i));
      if (d0 != null && !d0.J()) {
        int i2 = d0.c;
        if (i2 >= paramInt1 + paramInt2) {
          d0.A(-paramInt2, paramBoolean);
          this.m0.g = true;
        } else if (i2 >= paramInt1) {
          d0.i(paramInt1 - 1, -paramInt2, paramBoolean);
          this.m0.g = true;
        } 
      } 
    } 
    this.g.w(paramInt1, paramInt2, paramBoolean);
    requestLayout();
  }
  
  public void D0(View paramView) {}
  
  public void E0(View paramView) {}
  
  public boolean F(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return getScrollingChildHelper().d(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  void F0() {
    this.K++;
  }
  
  public final void G(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint1, int paramInt5, int[] paramArrayOfint2) {
    getScrollingChildHelper().e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint1, paramInt5, paramArrayOfint2);
  }
  
  void G0() {
    H0(true);
  }
  
  void H(int paramInt) {
    o o1 = this.r;
    if (o1 != null)
      o1.e1(paramInt); 
    J0(paramInt);
    t t1 = this.n0;
    if (t1 != null)
      t1.a(this, paramInt); 
    List<t> list = this.o0;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((t)this.o0.get(i)).a(this, paramInt);  
  }
  
  void H0(boolean paramBoolean) {
    int i = this.K - 1;
    this.K = i;
    if (i < 1) {
      this.K = 0;
      if (paramBoolean) {
        A();
        J();
      } 
    } 
  }
  
  void I(int paramInt1, int paramInt2) {
    this.L++;
    int i = getScrollX();
    int i1 = getScrollY();
    onScrollChanged(i, i1, i - paramInt1, i1 - paramInt2);
    K0(paramInt1, paramInt2);
    t t1 = this.n0;
    if (t1 != null)
      t1.b(this, paramInt1, paramInt2); 
    List<t> list = this.o0;
    if (list != null)
      for (i = list.size() - 1; i >= 0; i--)
        ((t)this.o0.get(i)).b(this, paramInt1, paramInt2);  
    this.L--;
  }
  
  void J() {
    for (int i = this.A0.size() - 1; i >= 0; i--) {
      d0 d0 = this.A0.get(i);
      if (d0.a.getParent() == this && !d0.J()) {
        int i1 = d0.q;
        if (i1 != -1) {
          androidx.core.view.w.y0(d0.a, i1);
          d0.q = -1;
        } 
      } 
    } 
    this.A0.clear();
  }
  
  public void J0(int paramInt) {}
  
  public void K0(int paramInt1, int paramInt2) {}
  
  void L() {
    if (this.Q != null)
      return; 
    EdgeEffect edgeEffect = this.M.a(this, 3);
    this.Q = edgeEffect;
    if (this.l) {
      edgeEffect.setSize(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), getMeasuredHeight() - getPaddingTop() - getPaddingBottom());
      return;
    } 
    edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
  }
  
  void L0() {
    if (!this.s0 && this.w) {
      androidx.core.view.w.g0((View)this, this.B0);
      this.s0 = true;
    } 
  }
  
  void M() {
    if (this.N != null)
      return; 
    EdgeEffect edgeEffect = this.M.a(this, 0);
    this.N = edgeEffect;
    if (this.l) {
      edgeEffect.setSize(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), getMeasuredWidth() - getPaddingLeft() - getPaddingRight());
      return;
    } 
    edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
  }
  
  void N() {
    if (this.P != null)
      return; 
    EdgeEffect edgeEffect = this.M.a(this, 2);
    this.P = edgeEffect;
    if (this.l) {
      edgeEffect.setSize(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), getMeasuredWidth() - getPaddingLeft() - getPaddingRight());
      return;
    } 
    edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
  }
  
  void O() {
    if (this.O != null)
      return; 
    EdgeEffect edgeEffect = this.M.a(this, 1);
    this.O = edgeEffect;
    if (this.l) {
      edgeEffect.setSize(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), getMeasuredHeight() - getPaddingTop() - getPaddingBottom());
      return;
    } 
    edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
  }
  
  void O0(boolean paramBoolean) {
    this.J = paramBoolean | this.J;
    this.I = true;
    x0();
  }
  
  String P() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(" ");
    stringBuilder.append(toString());
    stringBuilder.append(", adapter:");
    stringBuilder.append(this.q);
    stringBuilder.append(", layout:");
    stringBuilder.append(this.r);
    stringBuilder.append(", context:");
    stringBuilder.append(getContext());
    return stringBuilder.toString();
  }
  
  final void Q(a0 parama0) {
    if (getScrollState() == 2) {
      OverScroller overScroller = this.j0.h;
      parama0.p = overScroller.getFinalX() - overScroller.getCurrX();
      parama0.q = overScroller.getFinalY() - overScroller.getCurrY();
      return;
    } 
    parama0.p = 0;
    parama0.q = 0;
  }
  
  void Q0(d0 paramd0, l.c paramc) {
    paramd0.F(0, 8192);
    if (this.m0.i && paramd0.y() && !paramd0.v() && !paramd0.J()) {
      long l1 = c0(paramd0);
      this.k.c(l1, paramd0);
    } 
    this.k.e(paramd0, paramc);
  }
  
  public View R(View paramView) {
    ViewParent viewParent2 = paramView.getParent();
    View view = paramView;
    ViewParent viewParent1;
    for (viewParent1 = viewParent2; viewParent1 != null && viewParent1 != this && viewParent1 instanceof View; viewParent1 = view.getParent())
      view = (View)viewParent1; 
    return (viewParent1 == this) ? view : null;
  }
  
  public d0 S(View paramView) {
    paramView = R(paramView);
    return (paramView == null) ? null : e0(paramView);
  }
  
  void T0() {
    l l1 = this.R;
    if (l1 != null)
      l1.k(); 
    o o1 = this.r;
    if (o1 != null) {
      o1.k1(this.g);
      this.r.l1(this.g);
    } 
    this.g.c();
  }
  
  boolean U0(View paramView) {
    p1();
    boolean bool = this.j.r(paramView);
    if (bool) {
      d0 d0 = f0(paramView);
      this.g.J(d0);
      this.g.C(d0);
    } 
    r1(bool ^ true);
    return bool;
  }
  
  public void V0(n paramn) {
    o o1 = this.r;
    if (o1 != null)
      o1.g("Cannot remove item decoration during a scroll  or layout"); 
    this.t.remove(paramn);
    if (this.t.isEmpty()) {
      boolean bool;
      if (getOverScrollMode() == 2) {
        bool = true;
      } else {
        bool = false;
      } 
      setWillNotDraw(bool);
    } 
    w0();
    requestLayout();
  }
  
  public void W0(s params) {
    this.u.remove(params);
    if (this.v == params)
      this.v = null; 
  }
  
  public d0 X(int paramInt) {
    boolean bool = this.I;
    d0 d0 = null;
    if (bool)
      return null; 
    int i1 = this.j.j();
    int i = 0;
    while (i < i1) {
      d0 d02 = f0(this.j.i(i));
      d0 d01 = d0;
      if (d02 != null) {
        d01 = d0;
        if (!d02.v()) {
          d01 = d0;
          if (b0(d02) == paramInt)
            if (this.j.n(d02.a)) {
              d01 = d02;
            } else {
              return d02;
            }  
        } 
      } 
      i++;
      d0 = d01;
    } 
    return d0;
  }
  
  public void X0(t paramt) {
    List<t> list = this.o0;
    if (list != null)
      list.remove(paramt); 
  }
  
  public d0 Y(long paramLong) {
    g g1 = this.q;
    d0 d02 = null;
    d0 d01 = null;
    if (g1 != null) {
      if (!g1.g())
        return null; 
      int i1 = this.j.j();
      int i = 0;
      while (true) {
        d02 = d01;
        if (i < i1) {
          d0 d0 = f0(this.j.i(i));
          d02 = d01;
          if (d0 != null) {
            d02 = d01;
            if (!d0.v()) {
              d02 = d01;
              if (d0.k() == paramLong)
                if (this.j.n(d0.a)) {
                  d02 = d0;
                } else {
                  return d0;
                }  
            } 
          } 
          i++;
          d01 = d02;
          continue;
        } 
        break;
      } 
    } 
    return d02;
  }
  
  void Y0() {
    int i1 = this.j.g();
    for (int i = 0; i < i1; i++) {
      View view = this.j.f(i);
      d0 d0 = e0(view);
      if (d0 != null) {
        d0 = d0.i;
        if (d0 != null) {
          View view1 = d0.a;
          int i2 = view.getLeft();
          int i3 = view.getTop();
          if (i2 != view1.getLeft() || i3 != view1.getTop())
            view1.layout(i2, i3, view1.getWidth() + i2, view1.getHeight() + i3); 
        } 
      } 
    } 
  }
  
  d0 Z(int paramInt, boolean paramBoolean) {
    int i1 = this.j.j();
    Object object = null;
    int i = 0;
    while (i < i1) {
      d0 d0 = f0(this.j.i(i));
      Object object1 = object;
      if (d0 != null) {
        object1 = object;
        if (!d0.v()) {
          if (paramBoolean) {
            if (d0.c != paramInt) {
              object1 = object;
              continue;
            } 
          } else if (d0.m() != paramInt) {
            object1 = object;
            continue;
          } 
          if (this.j.n(d0.a)) {
            object1 = d0;
          } else {
            return d0;
          } 
        } 
      } 
      continue;
      i++;
      object = SYNTHETIC_LOCAL_VARIABLE_6;
    } 
    return (d0)object;
  }
  
  void a(int paramInt1, int paramInt2) {
    if (paramInt1 < 0) {
      M();
      if (this.N.isFinished())
        this.N.onAbsorb(-paramInt1); 
    } else if (paramInt1 > 0) {
      N();
      if (this.P.isFinished())
        this.P.onAbsorb(paramInt1); 
    } 
    if (paramInt2 < 0) {
      O();
      if (this.O.isFinished())
        this.O.onAbsorb(-paramInt2); 
    } else if (paramInt2 > 0) {
      L();
      if (this.Q.isFinished())
        this.Q.onAbsorb(paramInt2); 
    } 
    if (paramInt1 != 0 || paramInt2 != 0)
      androidx.core.view.w.f0((View)this); 
  }
  
  public boolean a0(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    o o1 = this.r;
    if (o1 == null || !o1.F0(this, paramArrayList, paramInt1, paramInt2))
      super.addFocusables(paramArrayList, paramInt1, paramInt2); 
  }
  
  int b0(d0 paramd0) {
    return (paramd0.p(524) || !paramd0.s()) ? -1 : this.i.e(paramd0.c);
  }
  
  long c0(d0 paramd0) {
    return this.q.g() ? paramd0.k() : paramd0.c;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof p && this.r.m((p)paramLayoutParams));
  }
  
  public int computeHorizontalScrollExtent() {
    o o1 = this.r;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.k())
      i = this.r.q(this.m0); 
    return i;
  }
  
  public int computeHorizontalScrollOffset() {
    o o1 = this.r;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.k())
      i = this.r.r(this.m0); 
    return i;
  }
  
  public int computeHorizontalScrollRange() {
    o o1 = this.r;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.k())
      i = this.r.s(this.m0); 
    return i;
  }
  
  public int computeVerticalScrollExtent() {
    o o1 = this.r;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.l())
      i = this.r.t(this.m0); 
    return i;
  }
  
  public int computeVerticalScrollOffset() {
    o o1 = this.r;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.l())
      i = this.r.u(this.m0); 
    return i;
  }
  
  public int computeVerticalScrollRange() {
    o o1 = this.r;
    int i = 0;
    if (o1 == null)
      return 0; 
    if (o1.l())
      i = this.r.v(this.m0); 
    return i;
  }
  
  public int d0(View paramView) {
    d0 d0 = f0(paramView);
    return (d0 != null) ? d0.m() : -1;
  }
  
  void d1() {
    int i1 = this.j.j();
    for (int i = 0; i < i1; i++) {
      d0 d0 = f0(this.j.i(i));
      if (!d0.J())
        d0.E(); 
    } 
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return getScrollingChildHelper().a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return getScrollingChildHelper().b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return getScrollingChildHelper().c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return getScrollingChildHelper().f(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    onPopulateAccessibilityEvent(paramAccessibilityEvent);
    return true;
  }
  
  protected void dispatchRestoreInstanceState(SparseArray<Parcelable> paramSparseArray) {
    dispatchThawSelfOnly(paramSparseArray);
  }
  
  protected void dispatchSaveInstanceState(SparseArray<Parcelable> paramSparseArray) {
    dispatchFreezeSelfOnly(paramSparseArray);
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    int i1 = this.t.size();
    boolean bool1 = false;
    int i;
    for (i = 0; i < i1; i++)
      ((n)this.t.get(i)).i(paramCanvas, this, this.m0); 
    EdgeEffect edgeEffect = this.N;
    boolean bool2 = true;
    if (edgeEffect != null && !edgeEffect.isFinished()) {
      int i2 = paramCanvas.save();
      if (this.l) {
        i = getPaddingBottom();
      } else {
        i = 0;
      } 
      paramCanvas.rotate(270.0F);
      paramCanvas.translate((-getHeight() + i), 0.0F);
      edgeEffect = this.N;
      if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
        i1 = 1;
      } else {
        i1 = 0;
      } 
      paramCanvas.restoreToCount(i2);
    } else {
      i1 = 0;
    } 
    edgeEffect = this.O;
    i = i1;
    if (edgeEffect != null) {
      i = i1;
      if (!edgeEffect.isFinished()) {
        int i2 = paramCanvas.save();
        if (this.l)
          paramCanvas.translate(getPaddingLeft(), getPaddingTop()); 
        edgeEffect = this.O;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          i = 1;
        } else {
          i = 0;
        } 
        i = i1 | i;
        paramCanvas.restoreToCount(i2);
      } 
    } 
    edgeEffect = this.P;
    i1 = i;
    if (edgeEffect != null) {
      i1 = i;
      if (!edgeEffect.isFinished()) {
        int i2 = paramCanvas.save();
        int i3 = getWidth();
        if (this.l) {
          i1 = getPaddingTop();
        } else {
          i1 = 0;
        } 
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-i1, -i3);
        edgeEffect = this.P;
        if (edgeEffect != null && edgeEffect.draw(paramCanvas)) {
          i1 = 1;
        } else {
          i1 = 0;
        } 
        i1 = i | i1;
        paramCanvas.restoreToCount(i2);
      } 
    } 
    edgeEffect = this.Q;
    i = i1;
    if (edgeEffect != null) {
      i = i1;
      if (!edgeEffect.isFinished()) {
        int i2 = paramCanvas.save();
        paramCanvas.rotate(180.0F);
        if (this.l) {
          paramCanvas.translate((-getWidth() + getPaddingRight()), (-getHeight() + getPaddingBottom()));
        } else {
          paramCanvas.translate(-getWidth(), -getHeight());
        } 
        edgeEffect = this.Q;
        i = bool1;
        if (edgeEffect != null) {
          i = bool1;
          if (edgeEffect.draw(paramCanvas))
            i = 1; 
        } 
        i = i1 | i;
        paramCanvas.restoreToCount(i2);
      } 
    } 
    if (i == 0 && this.R != null && this.t.size() > 0 && this.R.p())
      i = bool2; 
    if (i != 0)
      androidx.core.view.w.f0((View)this); 
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public d0 e0(View paramView) {
    ViewParent viewParent = paramView.getParent();
    if (viewParent == null || viewParent == this)
      return f0(paramView); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a direct child of ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  boolean e1(int paramInt1, int paramInt2, MotionEvent paramMotionEvent) {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    boolean bool1;
    u();
    g g1 = this.q;
    boolean bool3 = true;
    if (g1 != null) {
      int[] arrayOfInt = this.z0;
      arrayOfInt[0] = 0;
      arrayOfInt[1] = 0;
      f1(paramInt1, paramInt2, arrayOfInt);
      arrayOfInt = this.z0;
      b3 = arrayOfInt[0];
      b4 = arrayOfInt[1];
      b1 = b4;
      b2 = b3;
      b3 = paramInt1 - b3;
      b4 = paramInt2 - b4;
    } else {
      bool1 = false;
      b1 = bool1;
      b2 = b1;
      b4 = b2;
      b3 = b2;
      b2 = b1;
      b1 = bool1;
    } 
    if (!this.t.isEmpty())
      invalidate(); 
    int[] arrayOfInt1 = this.z0;
    arrayOfInt1[0] = 0;
    arrayOfInt1[1] = 0;
    G(b2, b1, b3, b4, this.x0, 0, arrayOfInt1);
    arrayOfInt1 = this.z0;
    int i = arrayOfInt1[0];
    int i1 = arrayOfInt1[1];
    if (arrayOfInt1[0] != 0 || arrayOfInt1[1] != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int i2 = this.a0;
    arrayOfInt1 = this.x0;
    this.a0 = i2 - arrayOfInt1[0];
    this.b0 -= arrayOfInt1[1];
    int[] arrayOfInt2 = this.y0;
    arrayOfInt2[0] = arrayOfInt2[0] + arrayOfInt1[0];
    arrayOfInt2[1] = arrayOfInt2[1] + arrayOfInt1[1];
    if (getOverScrollMode() != 2) {
      if (paramMotionEvent != null && !androidx.core.view.l.a(paramMotionEvent, 8194))
        P0(paramMotionEvent.getX(), (b3 - i), paramMotionEvent.getY(), (b4 - i1)); 
      t(paramInt1, paramInt2);
    } 
    if (b2 != 0 || b1 != 0)
      I(b2, b1); 
    if (!awakenScrollBars())
      invalidate(); 
    boolean bool2 = bool3;
    if (!bool1) {
      bool2 = bool3;
      if (b2 == 0) {
        if (b1 != 0)
          return true; 
        bool2 = false;
      } 
    } 
    return bool2;
  }
  
  void f1(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    p1();
    F0();
    h0.i.a("RV Scroll");
    Q(this.m0);
    if (paramInt1 != 0) {
      paramInt1 = this.r.w1(paramInt1, this.g, this.m0);
    } else {
      paramInt1 = 0;
    } 
    if (paramInt2 != 0) {
      paramInt2 = this.r.y1(paramInt2, this.g, this.m0);
    } else {
      paramInt2 = 0;
    } 
    h0.i.b();
    Y0();
    G0();
    r1(false);
    if (paramArrayOfint != null) {
      paramArrayOfint[0] = paramInt1;
      paramArrayOfint[1] = paramInt2;
    } 
  }
  
  public View focusSearch(View paramView, int paramInt) {
    int i;
    View view1;
    View view2 = this.r.Q0(paramView, paramInt);
    if (view2 != null)
      return view2; 
    g g1 = this.q;
    boolean bool = true;
    if (g1 != null && this.r != null && !t0() && !this.C) {
      i = 1;
    } else {
      i = 0;
    } 
    FocusFinder focusFinder = FocusFinder.getInstance();
    if (i && (paramInt == 2 || paramInt == 1)) {
      if (this.r.l()) {
        byte b1;
        byte b2;
        if (paramInt == 2) {
          b1 = 130;
        } else {
          b1 = 33;
        } 
        if (focusFinder.findNextFocus(this, paramView, b1) == null) {
          b2 = 1;
        } else {
          b2 = 0;
        } 
        i = b2;
        if (I0) {
          paramInt = b1;
          i = b2;
        } 
      } else {
        i = 0;
      } 
      int i2 = i;
      int i1 = paramInt;
      if (!i) {
        i2 = i;
        i1 = paramInt;
        if (this.r.k()) {
          if (this.r.Z() == 1) {
            i = 1;
          } else {
            i = 0;
          } 
          if (paramInt == 2) {
            i1 = 1;
          } else {
            i1 = 0;
          } 
          if ((i ^ i1) != 0) {
            i = 66;
          } else {
            i = 17;
          } 
          if (focusFinder.findNextFocus(this, paramView, i) == null) {
            i1 = bool;
          } else {
            i1 = 0;
          } 
          if (I0)
            paramInt = i; 
          i2 = i1;
          i1 = paramInt;
        } 
      } 
      if (i2 != 0) {
        u();
        if (R(paramView) == null)
          return null; 
        p1();
        this.r.J0(paramView, i1, this.g, this.m0);
        r1(false);
      } 
      view1 = focusFinder.findNextFocus(this, paramView, i1);
      paramInt = i1;
    } else {
      view1 = view1.findNextFocus(this, paramView, paramInt);
      if (view1 == null && i != 0) {
        u();
        if (R(paramView) == null)
          return null; 
        p1();
        view1 = this.r.J0(paramView, paramInt, this.g, this.m0);
        r1(false);
      } 
    } 
    if (view1 != null && !view1.hasFocusable()) {
      if (getFocusedChild() == null)
        return super.focusSearch(paramView, paramInt); 
      Z0(view1, null);
      return paramView;
    } 
    return u0(paramView, view1, paramInt) ? view1 : super.focusSearch(paramView, paramInt);
  }
  
  public void g1(int paramInt) {
    if (this.C)
      return; 
    t1();
    o o1 = this.r;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    o1.x1(paramInt);
    awakenScrollBars();
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    o o1 = this.r;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.D(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(P());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    o o1 = this.r;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.E(getContext(), paramAttributeSet); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(P());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    o o1 = this.r;
    if (o1 != null)
      return (ViewGroup.LayoutParams)o1.F(paramLayoutParams); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RecyclerView has no LayoutManager");
    stringBuilder.append(P());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public CharSequence getAccessibilityClassName() {
    return "androidx.recyclerview.widget.RecyclerView";
  }
  
  public g getAdapter() {
    return this.q;
  }
  
  public int getBaseline() {
    o o1 = this.r;
    return (o1 != null) ? o1.G() : super.getBaseline();
  }
  
  protected int getChildDrawingOrder(int paramInt1, int paramInt2) {
    j j1 = this.u0;
    return (j1 == null) ? super.getChildDrawingOrder(paramInt1, paramInt2) : j1.a(paramInt1, paramInt2);
  }
  
  public boolean getClipToPadding() {
    return this.l;
  }
  
  public k getCompatAccessibilityDelegate() {
    return this.t0;
  }
  
  public k getEdgeEffectFactory() {
    return this.M;
  }
  
  public l getItemAnimator() {
    return this.R;
  }
  
  public int getItemDecorationCount() {
    return this.t.size();
  }
  
  public o getLayoutManager() {
    return this.r;
  }
  
  public int getMaxFlingVelocity() {
    return this.f0;
  }
  
  public int getMinFlingVelocity() {
    return this.e0;
  }
  
  long getNanoTime() {
    return H0 ? System.nanoTime() : 0L;
  }
  
  public r getOnFlingListener() {
    return this.d0;
  }
  
  public boolean getPreserveFocusAfterLayout() {
    return this.i0;
  }
  
  public u getRecycledViewPool() {
    return this.g.i();
  }
  
  public int getScrollState() {
    return this.S;
  }
  
  public void h(n paramn) {
    i(paramn, -1);
  }
  
  public boolean hasNestedScrollingParent() {
    return getScrollingChildHelper().j();
  }
  
  public void i(n paramn, int paramInt) {
    o o1 = this.r;
    if (o1 != null)
      o1.g("Cannot add item decoration during a scroll  or layout"); 
    if (this.t.isEmpty())
      setWillNotDraw(false); 
    if (paramInt < 0) {
      this.t.add(paramn);
    } else {
      this.t.add(paramInt, paramn);
    } 
    w0();
    requestLayout();
  }
  
  boolean i1(d0 paramd0, int paramInt) {
    if (t0()) {
      paramd0.q = paramInt;
      this.A0.add(paramd0);
      return false;
    } 
    androidx.core.view.w.y0(paramd0.a, paramInt);
    return true;
  }
  
  public boolean isAttachedToWindow() {
    return this.w;
  }
  
  public final boolean isLayoutSuppressed() {
    return this.C;
  }
  
  public boolean isNestedScrollingEnabled() {
    return getScrollingChildHelper().l();
  }
  
  public void j(s params) {
    this.u.add(params);
  }
  
  Rect j0(View paramView) {
    p p1 = (p)paramView.getLayoutParams();
    if (!p1.c)
      return p1.b; 
    if (this.m0.e() && (p1.b() || p1.d()))
      return p1.b; 
    Rect rect = p1.b;
    rect.set(0, 0, 0, 0);
    int i1 = this.t.size();
    for (int i = 0; i < i1; i++) {
      this.n.set(0, 0, 0, 0);
      ((n)this.t.get(i)).e(this.n, paramView, this, this.m0);
      int i2 = rect.left;
      Rect rect1 = this.n;
      rect.left = i2 + rect1.left;
      rect.top += rect1.top;
      rect.right += rect1.right;
      rect.bottom += rect1.bottom;
    } 
    p1.c = false;
    return rect;
  }
  
  boolean j1(AccessibilityEvent paramAccessibilityEvent) {
    boolean bool1 = t0();
    boolean bool = false;
    if (bool1) {
      boolean bool2;
      if (paramAccessibilityEvent != null) {
        bool2 = l0.b.a(paramAccessibilityEvent);
      } else {
        bool2 = false;
      } 
      if (!bool2)
        bool2 = bool; 
      this.E |= bool2;
      return true;
    } 
    return false;
  }
  
  public void k(t paramt) {
    if (this.o0 == null)
      this.o0 = new ArrayList<t>(); 
    this.o0.add(paramt);
  }
  
  public void k1(int paramInt1, int paramInt2) {
    l1(paramInt1, paramInt2, null);
  }
  
  void l(d0 paramd0, l.c paramc1, l.c paramc2) {
    paramd0.G(false);
    if (this.R.a(paramd0, paramc1, paramc2))
      L0(); 
  }
  
  public boolean l0() {
    return (!this.z || this.I || this.i.p());
  }
  
  public void l1(int paramInt1, int paramInt2, Interpolator paramInterpolator) {
    m1(paramInt1, paramInt2, paramInterpolator, -2147483648);
  }
  
  public void m1(int paramInt1, int paramInt2, Interpolator paramInterpolator, int paramInt3) {
    n1(paramInt1, paramInt2, paramInterpolator, paramInt3, false);
  }
  
  void n(d0 paramd0, l.c paramc1, l.c paramc2) {
    g(paramd0);
    paramd0.G(false);
    if (this.R.c(paramd0, paramc1, paramc2))
      L0(); 
  }
  
  void n0() {
    this.i = new a(new f(this));
  }
  
  void n1(int paramInt1, int paramInt2, Interpolator paramInterpolator, int paramInt3, boolean paramBoolean) {
    o o1 = this.r;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    if (this.C)
      return; 
    boolean bool = o1.k();
    int i1 = 0;
    int i = paramInt1;
    if (!bool)
      i = 0; 
    if (!this.r.l())
      paramInt2 = 0; 
    if (i != 0 || paramInt2 != 0) {
      if (paramInt3 == Integer.MIN_VALUE || paramInt3 > 0) {
        paramInt1 = 1;
      } else {
        paramInt1 = 0;
      } 
      if (paramInt1 != 0) {
        if (paramBoolean) {
          paramInt1 = i1;
          if (i != 0)
            paramInt1 = 1; 
          i1 = paramInt1;
          if (paramInt2 != 0)
            i1 = paramInt1 | 0x2; 
          q1(i1, 1);
        } 
        this.j0.f(i, paramInt2, paramInt3, paramInterpolator);
        return;
      } 
      scrollBy(i, paramInt2);
    } 
  }
  
  void o(String paramString) {
    if (t0()) {
      StringBuilder stringBuilder;
      if (paramString == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot call this method while RecyclerView is computing a layout or scrolling");
        stringBuilder.append(P());
        throw new IllegalStateException(stringBuilder.toString());
      } 
      throw new IllegalStateException(stringBuilder);
    } 
    if (this.L > 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(P());
      Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(stringBuilder.toString()));
    } 
  }
  
  public void o1(int paramInt) {
    if (this.C)
      return; 
    o o1 = this.r;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    o1.I1(this, this.m0, paramInt);
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.K = 0;
    boolean bool = true;
    this.w = true;
    if (!this.z || isLayoutRequested())
      bool = false; 
    this.z = bool;
    o o1 = this.r;
    if (o1 != null)
      o1.z(this); 
    this.s0 = false;
    if (H0) {
      ThreadLocal<e> threadLocal = e.j;
      e e1 = threadLocal.get();
      this.k0 = e1;
      if (e1 == null) {
        this.k0 = new e();
        Display display = androidx.core.view.w.v((View)this);
        float f2 = 60.0F;
        float f1 = f2;
        if (!isInEditMode()) {
          f1 = f2;
          if (display != null) {
            float f = display.getRefreshRate();
            f1 = f2;
            if (f >= 30.0F)
              f1 = f; 
          } 
        } 
        e e2 = this.k0;
        e2.h = (long)(1.0E9F / f1);
        threadLocal.set(e2);
      } 
      this.k0.a(this);
    } 
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    l l1 = this.R;
    if (l1 != null)
      l1.k(); 
    t1();
    this.w = false;
    o o1 = this.r;
    if (o1 != null)
      o1.A(this, this.g); 
    this.A0.clear();
    removeCallbacks(this.B0);
    this.k.j();
    if (H0) {
      e e1 = this.k0;
      if (e1 != null) {
        e1.j(this);
        this.k0 = null;
      } 
    } 
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    int i1 = this.t.size();
    for (int i = 0; i < i1; i++)
      ((n)this.t.get(i)).g(paramCanvas, this, this.m0); 
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield r : Landroidx/recyclerview/widget/RecyclerView$o;
    //   4: ifnonnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_0
    //   10: getfield C : Z
    //   13: ifeq -> 18
    //   16: iconst_0
    //   17: ireturn
    //   18: aload_1
    //   19: invokevirtual getAction : ()I
    //   22: bipush #8
    //   24: if_icmpne -> 177
    //   27: aload_1
    //   28: invokevirtual getSource : ()I
    //   31: iconst_2
    //   32: iand
    //   33: ifeq -> 92
    //   36: aload_0
    //   37: getfield r : Landroidx/recyclerview/widget/RecyclerView$o;
    //   40: invokevirtual l : ()Z
    //   43: ifeq -> 57
    //   46: aload_1
    //   47: bipush #9
    //   49: invokevirtual getAxisValue : (I)F
    //   52: fneg
    //   53: fstore_2
    //   54: goto -> 59
    //   57: fconst_0
    //   58: fstore_2
    //   59: fload_2
    //   60: fstore_3
    //   61: aload_0
    //   62: getfield r : Landroidx/recyclerview/widget/RecyclerView$o;
    //   65: invokevirtual k : ()Z
    //   68: ifeq -> 81
    //   71: aload_1
    //   72: bipush #10
    //   74: invokevirtual getAxisValue : (I)F
    //   77: fstore_3
    //   78: goto -> 145
    //   81: fconst_0
    //   82: fstore #4
    //   84: fload_3
    //   85: fstore_2
    //   86: fload #4
    //   88: fstore_3
    //   89: goto -> 145
    //   92: aload_1
    //   93: invokevirtual getSource : ()I
    //   96: ldc_w 4194304
    //   99: iand
    //   100: ifeq -> 141
    //   103: aload_1
    //   104: bipush #26
    //   106: invokevirtual getAxisValue : (I)F
    //   109: fstore_3
    //   110: aload_0
    //   111: getfield r : Landroidx/recyclerview/widget/RecyclerView$o;
    //   114: invokevirtual l : ()Z
    //   117: ifeq -> 126
    //   120: fload_3
    //   121: fneg
    //   122: fstore_3
    //   123: goto -> 81
    //   126: aload_0
    //   127: getfield r : Landroidx/recyclerview/widget/RecyclerView$o;
    //   130: invokevirtual k : ()Z
    //   133: ifeq -> 141
    //   136: fconst_0
    //   137: fstore_2
    //   138: goto -> 145
    //   141: fconst_0
    //   142: fstore_2
    //   143: fload_2
    //   144: fstore_3
    //   145: fload_2
    //   146: fconst_0
    //   147: fcmpl
    //   148: ifne -> 157
    //   151: fload_3
    //   152: fconst_0
    //   153: fcmpl
    //   154: ifeq -> 177
    //   157: aload_0
    //   158: fload_3
    //   159: aload_0
    //   160: getfield g0 : F
    //   163: fmul
    //   164: f2i
    //   165: fload_2
    //   166: aload_0
    //   167: getfield h0 : F
    //   170: fmul
    //   171: f2i
    //   172: aload_1
    //   173: invokevirtual e1 : (IILandroid/view/MotionEvent;)Z
    //   176: pop
    //   177: iconst_0
    //   178: ireturn
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    h0.i.a("RV OnLayout");
    B();
    h0.i.b();
    this.z = true;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    o o1 = this.r;
    if (o1 == null) {
      w(paramInt1, paramInt2);
      return;
    } 
    boolean bool1 = o1.s0();
    boolean bool = false;
    if (bool1) {
      int i = View.MeasureSpec.getMode(paramInt1);
      int i1 = View.MeasureSpec.getMode(paramInt2);
      this.r.Z0(this.g, this.m0, paramInt1, paramInt2);
      boolean bool2 = bool;
      if (i == 1073741824) {
        bool2 = bool;
        if (i1 == 1073741824)
          bool2 = true; 
      } 
      if (!bool2) {
        if (this.q == null)
          return; 
        if (this.m0.e == 1)
          C(); 
        this.r.A1(paramInt1, paramInt2);
        this.m0.j = true;
        D();
        this.r.D1(paramInt1, paramInt2);
        if (this.r.G1()) {
          this.r.A1(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
          this.m0.j = true;
          D();
          this.r.D1(paramInt1, paramInt2);
          return;
        } 
      } else {
        return;
      } 
    } else {
      if (this.x) {
        this.r.Z0(this.g, this.m0, paramInt1, paramInt2);
        return;
      } 
      if (this.F) {
        p1();
        F0();
        N0();
        G0();
        a0 a01 = this.m0;
        if (a01.l) {
          a01.h = true;
        } else {
          this.i.j();
          this.m0.h = false;
        } 
        this.F = false;
        r1(false);
      } else if (this.m0.l) {
        setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
        return;
      } 
      g g1 = this.q;
      if (g1 != null) {
        this.m0.f = g1.c();
      } else {
        this.m0.f = 0;
      } 
      p1();
      this.r.Z0(this.g, this.m0, paramInt1, paramInt2);
      r1(false);
      this.m0.h = false;
    } 
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    return t0() ? false : super.onRequestFocusInDescendants(paramInt, paramRect);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof y)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    y y1 = (y)paramParcelable;
    this.h = y1;
    super.onRestoreInstanceState(y1.a());
    o o1 = this.r;
    if (o1 != null) {
      Parcelable parcelable = this.h.h;
      if (parcelable != null)
        o1.c1(parcelable); 
    } 
  }
  
  protected Parcelable onSaveInstanceState() {
    y y1 = new y(super.onSaveInstanceState());
    y y2 = this.h;
    if (y2 != null) {
      y1.c(y2);
      return (Parcelable)y1;
    } 
    o o1 = this.r;
    if (o1 != null) {
      y1.h = o1.d1();
      return (Parcelable)y1;
    } 
    y1.h = null;
    return (Parcelable)y1;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3 || paramInt2 != paramInt4)
      r0(); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  boolean p(d0 paramd0) {
    l l1 = this.R;
    return (l1 == null || l1.g(paramd0, paramd0.o()));
  }
  
  void p1() {
    int i = this.A + 1;
    this.A = i;
    if (i == 1 && !this.C)
      this.B = false; 
  }
  
  void q0(StateListDrawable paramStateListDrawable1, Drawable paramDrawable1, StateListDrawable paramStateListDrawable2, Drawable paramDrawable2) {
    if (paramStateListDrawable1 != null && paramDrawable1 != null && paramStateListDrawable2 != null && paramDrawable2 != null) {
      Resources resources = getContext().getResources();
      new d(this, paramStateListDrawable1, paramDrawable1, paramStateListDrawable2, paramDrawable2, resources.getDimensionPixelSize(d1.b.a), resources.getDimensionPixelSize(d1.b.c), resources.getDimensionPixelOffset(d1.b.b));
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set fast scroller without both required drawables.");
    stringBuilder.append(P());
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean q1(int paramInt1, int paramInt2) {
    return getScrollingChildHelper().p(paramInt1, paramInt2);
  }
  
  void r0() {
    this.Q = null;
    this.O = null;
    this.P = null;
    this.N = null;
  }
  
  void r1(boolean paramBoolean) {
    if (this.A < 1)
      this.A = 1; 
    if (!paramBoolean && !this.C)
      this.B = false; 
    if (this.A == 1) {
      if (paramBoolean && this.B && !this.C && this.r != null && this.q != null)
        B(); 
      if (!this.C)
        this.B = false; 
    } 
    this.A--;
  }
  
  protected void removeDetachedView(View paramView, boolean paramBoolean) {
    StringBuilder stringBuilder;
    d0 d0 = f0(paramView);
    if (d0 != null)
      if (d0.x()) {
        d0.f();
      } else if (!d0.J()) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
        stringBuilder.append(d0);
        stringBuilder.append(P());
        throw new IllegalArgumentException(stringBuilder.toString());
      }  
    stringBuilder.clearAnimation();
    z((View)stringBuilder);
    super.removeDetachedView((View)stringBuilder, paramBoolean);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.r.b1(this, this.m0, paramView1, paramView2) && paramView2 != null)
      Z0(paramView1, paramView2); 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    return this.r.r1(this, paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    int i1 = this.u.size();
    for (int i = 0; i < i1; i++)
      ((s)this.u.get(i)).c(paramBoolean); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    if (this.A == 0 && !this.C) {
      super.requestLayout();
      return;
    } 
    this.B = true;
  }
  
  void s() {
    int i1 = this.j.j();
    for (int i = 0; i < i1; i++) {
      d0 d0 = f0(this.j.i(i));
      if (!d0.J())
        d0.c(); 
    } 
    this.g.d();
  }
  
  boolean s0() {
    AccessibilityManager accessibilityManager = this.G;
    return (accessibilityManager != null && accessibilityManager.isEnabled());
  }
  
  public void s1(int paramInt) {
    getScrollingChildHelper().r(paramInt);
  }
  
  public void scrollBy(int paramInt1, int paramInt2) {
    o o1 = this.r;
    if (o1 == null) {
      Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
      return;
    } 
    if (this.C)
      return; 
    boolean bool1 = o1.k();
    boolean bool2 = this.r.l();
    if (bool1 || bool2) {
      if (!bool1)
        paramInt1 = 0; 
      if (!bool2)
        paramInt2 = 0; 
      e1(paramInt1, paramInt2, null);
    } 
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
  }
  
  public void sendAccessibilityEventUnchecked(AccessibilityEvent paramAccessibilityEvent) {
    if (j1(paramAccessibilityEvent))
      return; 
    super.sendAccessibilityEventUnchecked(paramAccessibilityEvent);
  }
  
  public void setAccessibilityDelegateCompat(k paramk) {
    this.t0 = paramk;
    androidx.core.view.w.o0((View)this, paramk);
  }
  
  public void setAdapter(g paramg) {
    setLayoutFrozen(false);
    h1(paramg, false, true);
    O0(false);
    requestLayout();
  }
  
  public void setChildDrawingOrderCallback(j paramj) {
    boolean bool;
    if (paramj == this.u0)
      return; 
    this.u0 = paramj;
    if (paramj != null) {
      bool = true;
    } else {
      bool = false;
    } 
    setChildrenDrawingOrderEnabled(bool);
  }
  
  public void setClipToPadding(boolean paramBoolean) {
    if (paramBoolean != this.l)
      r0(); 
    this.l = paramBoolean;
    super.setClipToPadding(paramBoolean);
    if (this.z)
      requestLayout(); 
  }
  
  public void setEdgeEffectFactory(k paramk) {
    k0.h.f(paramk);
    this.M = paramk;
    r0();
  }
  
  public void setHasFixedSize(boolean paramBoolean) {
    this.x = paramBoolean;
  }
  
  public void setItemAnimator(l paraml) {
    l l1 = this.R;
    if (l1 != null) {
      l1.k();
      this.R.v(null);
    } 
    this.R = paraml;
    if (paraml != null)
      paraml.v(this.r0); 
  }
  
  public void setItemViewCacheSize(int paramInt) {
    this.g.G(paramInt);
  }
  
  @Deprecated
  public void setLayoutFrozen(boolean paramBoolean) {
    suppressLayout(paramBoolean);
  }
  
  public void setLayoutManager(o paramo) {
    if (paramo == this.r)
      return; 
    t1();
    if (this.r != null) {
      l l1 = this.R;
      if (l1 != null)
        l1.k(); 
      this.r.k1(this.g);
      this.r.l1(this.g);
      this.g.c();
      if (this.w)
        this.r.A(this, this.g); 
      this.r.E1(null);
      this.r = null;
    } else {
      this.g.c();
    } 
    this.j.o();
    this.r = paramo;
    if (paramo != null)
      if (paramo.b == null) {
        paramo.E1(this);
        if (this.w)
          this.r.z(this); 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("LayoutManager ");
        stringBuilder.append(paramo);
        stringBuilder.append(" is already attached to a RecyclerView:");
        stringBuilder.append(paramo.b.P());
        throw new IllegalArgumentException(stringBuilder.toString());
      }  
    this.g.K();
    requestLayout();
  }
  
  @Deprecated
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    if (paramLayoutTransition == null) {
      super.setLayoutTransition(null);
      return;
    } 
    throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    getScrollingChildHelper().m(paramBoolean);
  }
  
  public void setOnFlingListener(r paramr) {
    this.d0 = paramr;
  }
  
  @Deprecated
  public void setOnScrollListener(t paramt) {
    this.n0 = paramt;
  }
  
  public void setPreserveFocusAfterLayout(boolean paramBoolean) {
    this.i0 = paramBoolean;
  }
  
  public void setRecycledViewPool(u paramu) {
    this.g.E(paramu);
  }
  
  public void setRecyclerListener(w paramw) {
    this.s = paramw;
  }
  
  void setScrollState(int paramInt) {
    if (paramInt == this.S)
      return; 
    this.S = paramInt;
    if (paramInt != 2)
      u1(); 
    H(paramInt);
  }
  
  public void setScrollingTouchSlop(int paramInt) {
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    if (paramInt != 0)
      if (paramInt != 1) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("setScrollingTouchSlop(): bad argument constant ");
        stringBuilder.append(paramInt);
        stringBuilder.append("; using default value");
        Log.w("RecyclerView", stringBuilder.toString());
      } else {
        this.c0 = viewConfiguration.getScaledPagingTouchSlop();
        return;
      }  
    this.c0 = viewConfiguration.getScaledTouchSlop();
  }
  
  public void setViewCacheExtension(b0 paramb0) {
    this.g.F(paramb0);
  }
  
  public boolean startNestedScroll(int paramInt) {
    return getScrollingChildHelper().o(paramInt);
  }
  
  public void stopNestedScroll() {
    getScrollingChildHelper().q();
  }
  
  public final void suppressLayout(boolean paramBoolean) {
    if (paramBoolean != this.C) {
      o("Do not suppressLayout in layout or scroll");
      if (!paramBoolean) {
        this.C = false;
        if (this.B && this.r != null && this.q != null)
          requestLayout(); 
        this.B = false;
        return;
      } 
      long l1 = SystemClock.uptimeMillis();
      onTouchEvent(MotionEvent.obtain(l1, l1, 3, 0.0F, 0.0F, 0));
      this.C = true;
      this.D = true;
      t1();
    } 
  }
  
  void t(int paramInt1, int paramInt2) {
    EdgeEffect edgeEffect = this.N;
    if (edgeEffect != null && !edgeEffect.isFinished() && paramInt1 > 0) {
      this.N.onRelease();
      bool2 = this.N.isFinished();
    } else {
      bool2 = false;
    } 
    edgeEffect = this.P;
    boolean bool1 = bool2;
    if (edgeEffect != null) {
      bool1 = bool2;
      if (!edgeEffect.isFinished()) {
        bool1 = bool2;
        if (paramInt1 < 0) {
          this.P.onRelease();
          bool1 = bool2 | this.P.isFinished();
        } 
      } 
    } 
    edgeEffect = this.O;
    boolean bool2 = bool1;
    if (edgeEffect != null) {
      bool2 = bool1;
      if (!edgeEffect.isFinished()) {
        bool2 = bool1;
        if (paramInt2 > 0) {
          this.O.onRelease();
          bool2 = bool1 | this.O.isFinished();
        } 
      } 
    } 
    edgeEffect = this.Q;
    bool1 = bool2;
    if (edgeEffect != null) {
      bool1 = bool2;
      if (!edgeEffect.isFinished()) {
        bool1 = bool2;
        if (paramInt2 < 0) {
          this.Q.onRelease();
          bool1 = bool2 | this.Q.isFinished();
        } 
      } 
    } 
    if (bool1)
      androidx.core.view.w.f0((View)this); 
  }
  
  public boolean t0() {
    return (this.K > 0);
  }
  
  public void t1() {
    setScrollState(0);
    u1();
  }
  
  void u() {
    if (!this.z || this.I) {
      h0.i.a("RV FullInvalidate");
      B();
      h0.i.b();
      return;
    } 
    if (!this.i.p())
      return; 
    if (this.i.o(4) && !this.i.o(11)) {
      h0.i.a("RV PartialInvalidate");
      p1();
      F0();
      this.i.s();
      if (!this.B)
        if (m0()) {
          B();
        } else {
          this.i.i();
        }  
      r1(true);
      G0();
      h0.i.b();
      return;
    } 
    if (this.i.p()) {
      h0.i.a("RV FullInvalidate");
      B();
      h0.i.b();
    } 
  }
  
  void v0(int paramInt) {
    if (this.r == null)
      return; 
    setScrollState(2);
    this.r.x1(paramInt);
    awakenScrollBars();
  }
  
  void v1(int paramInt1, int paramInt2, Object paramObject) {
    int i1 = this.j.j();
    int i;
    for (i = 0; i < i1; i++) {
      View view = this.j.i(i);
      d0 d0 = f0(view);
      if (d0 != null && !d0.J()) {
        int i2 = d0.c;
        if (i2 >= paramInt1 && i2 < paramInt1 + paramInt2) {
          d0.b(2);
          d0.a(paramObject);
          ((p)view.getLayoutParams()).c = true;
        } 
      } 
    } 
    this.g.M(paramInt1, paramInt2);
  }
  
  void w(int paramInt1, int paramInt2) {
    setMeasuredDimension(o.n(paramInt1, getPaddingLeft() + getPaddingRight(), androidx.core.view.w.D((View)this)), o.n(paramInt2, getPaddingTop() + getPaddingBottom(), androidx.core.view.w.C((View)this)));
  }
  
  void w0() {
    int i1 = this.j.j();
    for (int i = 0; i < i1; i++)
      ((p)this.j.i(i).getLayoutParams()).c = true; 
    this.g.s();
  }
  
  void x0() {
    int i1 = this.j.j();
    for (int i = 0; i < i1; i++) {
      d0 d0 = f0(this.j.i(i));
      if (d0 != null && !d0.J())
        d0.b(6); 
    } 
    w0();
    this.g.t();
  }
  
  void y(View paramView) {
    d0 d0 = f0(paramView);
    D0(paramView);
    g<d0> g1 = this.q;
    if (g1 != null && d0 != null)
      g1.o(d0); 
    List<q> list = this.H;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((q)this.H.get(i)).a(paramView);  
  }
  
  public void y0(int paramInt) {
    int i1 = this.j.g();
    for (int i = 0; i < i1; i++)
      this.j.f(i).offsetLeftAndRight(paramInt); 
  }
  
  void z(View paramView) {
    d0 d0 = f0(paramView);
    E0(paramView);
    g<d0> g1 = this.q;
    if (g1 != null && d0 != null)
      g1.p(d0); 
    List<q> list = this.H;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((q)this.H.get(i)).b(paramView);  
  }
  
  public void z0(int paramInt) {
    int i1 = this.j.g();
    for (int i = 0; i < i1; i++)
      this.j.f(i).offsetTopAndBottom(paramInt); 
  }
  
  static {
    Class<int> clazz = int.class;
    K0 = new Class[] { Context.class, AttributeSet.class, clazz, clazz };
  }
  
  class a implements Runnable {
    a(RecyclerView this$0) {}
    
    public void run() {
      RecyclerView recyclerView = this.f;
      if (recyclerView.z) {
        if (recyclerView.isLayoutRequested())
          return; 
        recyclerView = this.f;
        if (!recyclerView.w) {
          recyclerView.requestLayout();
          return;
        } 
        if (recyclerView.C) {
          recyclerView.B = true;
          return;
        } 
        recyclerView.u();
      } 
    }
  }
  
  public static class a0 {
    int a = -1;
    
    private SparseArray<Object> b;
    
    int c = 0;
    
    int d = 0;
    
    int e = 1;
    
    int f = 0;
    
    boolean g = false;
    
    boolean h = false;
    
    boolean i = false;
    
    boolean j = false;
    
    boolean k = false;
    
    boolean l = false;
    
    int m;
    
    long n;
    
    int o;
    
    int p;
    
    int q;
    
    void a(int param1Int) {
      if ((this.e & param1Int) != 0)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Layout state should be one of ");
      stringBuilder.append(Integer.toBinaryString(param1Int));
      stringBuilder.append(" but it is ");
      stringBuilder.append(Integer.toBinaryString(this.e));
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public int b() {
      return this.h ? (this.c - this.d) : this.f;
    }
    
    public int c() {
      return this.a;
    }
    
    public boolean d() {
      return (this.a != -1);
    }
    
    public boolean e() {
      return this.h;
    }
    
    void f(RecyclerView.g param1g) {
      this.e = 1;
      this.f = param1g.c();
      this.h = false;
      this.i = false;
      this.j = false;
    }
    
    public boolean g() {
      return this.l;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("State{mTargetPosition=");
      stringBuilder.append(this.a);
      stringBuilder.append(", mData=");
      stringBuilder.append(this.b);
      stringBuilder.append(", mItemCount=");
      stringBuilder.append(this.f);
      stringBuilder.append(", mIsMeasuring=");
      stringBuilder.append(this.j);
      stringBuilder.append(", mPreviousLayoutItemCount=");
      stringBuilder.append(this.c);
      stringBuilder.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
      stringBuilder.append(this.d);
      stringBuilder.append(", mStructureChanged=");
      stringBuilder.append(this.g);
      stringBuilder.append(", mInPreLayout=");
      stringBuilder.append(this.h);
      stringBuilder.append(", mRunSimpleAnimations=");
      stringBuilder.append(this.k);
      stringBuilder.append(", mRunPredictiveAnimations=");
      stringBuilder.append(this.l);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  class b implements Runnable {
    b(RecyclerView this$0) {}
    
    public void run() {
      RecyclerView.l l = this.f.R;
      if (l != null)
        l.u(); 
      this.f.s0 = false;
    }
  }
  
  public static abstract class b0 {}
  
  static final class c implements Interpolator {
    public float getInterpolation(float param1Float) {
      param1Float--;
      return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
    }
  }
  
  class c0 implements Runnable {
    private int f;
    
    private int g;
    
    OverScroller h;
    
    Interpolator i;
    
    private boolean j;
    
    private boolean k;
    
    c0(RecyclerView this$0) {
      Interpolator interpolator = RecyclerView.L0;
      this.i = interpolator;
      this.j = false;
      this.k = false;
      this.h = new OverScroller(this$0.getContext(), interpolator);
    }
    
    private int a(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool;
      int i = Math.abs(param1Int1);
      int j = Math.abs(param1Int2);
      if (i > j) {
        bool = true;
      } else {
        bool = false;
      } 
      param1Int3 = (int)Math.sqrt((param1Int3 * param1Int3 + param1Int4 * param1Int4));
      param1Int2 = (int)Math.sqrt((param1Int1 * param1Int1 + param1Int2 * param1Int2));
      RecyclerView recyclerView = this.l;
      if (bool) {
        param1Int1 = recyclerView.getWidth();
      } else {
        param1Int1 = recyclerView.getHeight();
      } 
      param1Int4 = param1Int1 / 2;
      float f2 = param1Int2;
      float f1 = param1Int1;
      float f3 = Math.min(1.0F, f2 * 1.0F / f1);
      f2 = param1Int4;
      f3 = b(f3);
      if (param1Int3 > 0) {
        param1Int1 = Math.round(Math.abs((f2 + f3 * f2) / param1Int3) * 1000.0F) * 4;
      } else {
        if (bool) {
          param1Int1 = i;
        } else {
          param1Int1 = j;
        } 
        param1Int1 = (int)((param1Int1 / f1 + 1.0F) * 300.0F);
      } 
      return Math.min(param1Int1, 2000);
    }
    
    private float b(float param1Float) {
      return (float)Math.sin(((param1Float - 0.5F) * 0.47123894F));
    }
    
    private void d() {
      this.l.removeCallbacks(this);
      androidx.core.view.w.g0((View)this.l, this);
    }
    
    public void c(int param1Int1, int param1Int2) {
      this.l.setScrollState(2);
      this.g = 0;
      this.f = 0;
      Interpolator interpolator1 = this.i;
      Interpolator interpolator2 = RecyclerView.L0;
      if (interpolator1 != interpolator2) {
        this.i = interpolator2;
        this.h = new OverScroller(this.l.getContext(), interpolator2);
      } 
      this.h.fling(0, 0, param1Int1, param1Int2, -2147483648, 2147483647, -2147483648, 2147483647);
      e();
    }
    
    void e() {
      if (this.j) {
        this.k = true;
        return;
      } 
      d();
    }
    
    public void f(int param1Int1, int param1Int2, int param1Int3, Interpolator param1Interpolator) {
      int i = param1Int3;
      if (param1Int3 == Integer.MIN_VALUE)
        i = a(param1Int1, param1Int2, 0, 0); 
      Interpolator interpolator = param1Interpolator;
      if (param1Interpolator == null)
        interpolator = RecyclerView.L0; 
      if (this.i != interpolator) {
        this.i = interpolator;
        this.h = new OverScroller(this.l.getContext(), interpolator);
      } 
      this.g = 0;
      this.f = 0;
      this.l.setScrollState(2);
      this.h.startScroll(0, 0, param1Int1, param1Int2, i);
      e();
    }
    
    public void g() {
      this.l.removeCallbacks(this);
      this.h.abortAnimation();
    }
    
    public void run() {
      RecyclerView recyclerView = this.l;
      if (recyclerView.r == null) {
        g();
        return;
      } 
      this.k = false;
      this.j = true;
      recyclerView.u();
      OverScroller overScroller = this.h;
      if (overScroller.computeScrollOffset()) {
        int i = overScroller.getCurrX();
        int j = overScroller.getCurrY();
        int m = i - this.f;
        int k = j - this.g;
        this.f = i;
        this.g = j;
        RecyclerView recyclerView1 = this.l;
        int[] arrayOfInt = recyclerView1.z0;
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        i = m;
        j = k;
        if (recyclerView1.F(m, k, arrayOfInt, null, 1)) {
          int[] arrayOfInt1 = this.l.z0;
          i = m - arrayOfInt1[0];
          j = k - arrayOfInt1[1];
        } 
        if (this.l.getOverScrollMode() != 2)
          this.l.t(i, j); 
        recyclerView1 = this.l;
        if (recyclerView1.q != null) {
          arrayOfInt = recyclerView1.z0;
          arrayOfInt[0] = 0;
          arrayOfInt[1] = 0;
          recyclerView1.f1(i, j, arrayOfInt);
          recyclerView1 = this.l;
          arrayOfInt = recyclerView1.z0;
          int i2 = arrayOfInt[0];
          int i3 = arrayOfInt[1];
          int i4 = i - i2;
          int i5 = j - i3;
          RecyclerView.z z2 = recyclerView1.r.g;
          i = i4;
          k = i3;
          j = i2;
          m = i5;
          if (z2 != null) {
            i = i4;
            k = i3;
            j = i2;
            m = i5;
            if (!z2.g()) {
              i = i4;
              k = i3;
              j = i2;
              m = i5;
              if (z2.h()) {
                i = this.l.m0.b();
                if (i == 0) {
                  z2.r();
                  i = i4;
                  k = i3;
                  j = i2;
                  m = i5;
                } else if (z2.f() >= i) {
                  z2.p(i - 1);
                  z2.j(i2, i3);
                  i = i4;
                  k = i3;
                  j = i2;
                  m = i5;
                } else {
                  z2.j(i2, i3);
                  i = i4;
                  k = i3;
                  j = i2;
                  m = i5;
                } 
              } 
            } 
          } 
        } else {
          k = 0;
          int i2 = k;
          m = j;
          j = i2;
        } 
        if (!this.l.t.isEmpty())
          this.l.invalidate(); 
        recyclerView1 = this.l;
        arrayOfInt = recyclerView1.z0;
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        recyclerView1.G(j, k, i, m, null, 1, arrayOfInt);
        recyclerView1 = this.l;
        arrayOfInt = recyclerView1.z0;
        int i1 = i - arrayOfInt[0];
        int n = m - arrayOfInt[1];
        if (j != 0 || k != 0)
          recyclerView1.I(j, k); 
        if (!RecyclerView.e(this.l))
          this.l.invalidate(); 
        if (overScroller.getCurrX() == overScroller.getFinalX()) {
          i = 1;
        } else {
          i = 0;
        } 
        if (overScroller.getCurrY() == overScroller.getFinalY()) {
          m = 1;
        } else {
          m = 0;
        } 
        if (overScroller.isFinished() || ((i != 0 || i1 != 0) && (m != 0 || n != 0))) {
          i = 1;
        } else {
          i = 0;
        } 
        RecyclerView.z z1 = this.l.r.g;
        if (z1 != null && z1.g()) {
          m = 1;
        } else {
          m = 0;
        } 
        if (m == 0 && i != 0) {
          if (this.l.getOverScrollMode() != 2) {
            j = (int)overScroller.getCurrVelocity();
            if (i1 < 0) {
              i = -j;
            } else if (i1 > 0) {
              i = j;
            } else {
              i = 0;
            } 
            if (n < 0) {
              j = -j;
            } else if (n <= 0) {
              j = 0;
            } 
            this.l.a(i, j);
          } 
          if (RecyclerView.H0)
            this.l.l0.b(); 
        } else {
          e();
          RecyclerView recyclerView2 = this.l;
          e e = recyclerView2.k0;
          if (e != null)
            e.f(recyclerView2, j, k); 
        } 
      } 
      RecyclerView.z z = this.l.r.g;
      if (z != null && z.g())
        z.j(0, 0); 
      this.j = false;
      if (this.k) {
        d();
        return;
      } 
      this.l.setScrollState(0);
      this.l.s1(1);
    }
  }
  
  class d implements p.b {
    d(RecyclerView this$0) {}
    
    public void a(RecyclerView.d0 param1d0) {
      RecyclerView recyclerView = this.a;
      recyclerView.r.m1(param1d0.a, recyclerView.g);
    }
    
    public void b(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2) {
      this.a.l(param1d0, param1c1, param1c2);
    }
    
    public void c(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2) {
      this.a.g.J(param1d0);
      this.a.n(param1d0, param1c1, param1c2);
    }
    
    public void d(RecyclerView.d0 param1d0, RecyclerView.l.c param1c1, RecyclerView.l.c param1c2) {
      param1d0.G(false);
      RecyclerView recyclerView = this.a;
      if (recyclerView.I) {
        if (recyclerView.R.b(param1d0, param1d0, param1c1, param1c2)) {
          this.a.L0();
          return;
        } 
      } else if (recyclerView.R.d(param1d0, param1c1, param1c2)) {
        this.a.L0();
      } 
    }
  }
  
  public static abstract class d0 {
    private static final List<Object> s = Collections.emptyList();
    
    public final View a;
    
    WeakReference<RecyclerView> b;
    
    int c = -1;
    
    int d = -1;
    
    long e = -1L;
    
    int f = -1;
    
    int g = -1;
    
    d0 h = null;
    
    d0 i = null;
    
    int j;
    
    List<Object> k = null;
    
    List<Object> l = null;
    
    private int m = 0;
    
    RecyclerView.v n = null;
    
    boolean o = false;
    
    private int p = 0;
    
    int q = -1;
    
    RecyclerView r;
    
    public d0(View param1View) {
      if (param1View != null) {
        this.a = param1View;
        return;
      } 
      throw new IllegalArgumentException("itemView may not be null");
    }
    
    private void g() {
      if (this.k == null) {
        ArrayList<Object> arrayList = new ArrayList();
        this.k = arrayList;
        this.l = Collections.unmodifiableList(arrayList);
      } 
    }
    
    void A(int param1Int, boolean param1Boolean) {
      if (this.d == -1)
        this.d = this.c; 
      if (this.g == -1)
        this.g = this.c; 
      if (param1Boolean)
        this.g += param1Int; 
      this.c += param1Int;
      if (this.a.getLayoutParams() != null)
        ((RecyclerView.p)this.a.getLayoutParams()).c = true; 
    }
    
    void B(RecyclerView param1RecyclerView) {
      int i = this.q;
      if (i != -1) {
        this.p = i;
      } else {
        this.p = androidx.core.view.w.z(this.a);
      } 
      param1RecyclerView.i1(this, 4);
    }
    
    void C(RecyclerView param1RecyclerView) {
      param1RecyclerView.i1(this, this.p);
      this.p = 0;
    }
    
    void D() {
      this.j = 0;
      this.c = -1;
      this.d = -1;
      this.e = -1L;
      this.g = -1;
      this.m = 0;
      this.h = null;
      this.i = null;
      d();
      this.p = 0;
      this.q = -1;
      RecyclerView.r(this);
    }
    
    void E() {
      if (this.d == -1)
        this.d = this.c; 
    }
    
    void F(int param1Int1, int param1Int2) {
      this.j = param1Int1 & param1Int2 | this.j & param1Int2;
    }
    
    public final void G(boolean param1Boolean) {
      int i = this.m;
      if (param1Boolean) {
        i--;
      } else {
        i++;
      } 
      this.m = i;
      if (i < 0) {
        this.m = 0;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for ");
        stringBuilder.append(this);
        Log.e("View", stringBuilder.toString());
        return;
      } 
      if (!param1Boolean && i == 1) {
        this.j |= 0x10;
        return;
      } 
      if (param1Boolean && i == 0)
        this.j &= 0xFFFFFFEF; 
    }
    
    void H(RecyclerView.v param1v, boolean param1Boolean) {
      this.n = param1v;
      this.o = param1Boolean;
    }
    
    boolean I() {
      return ((this.j & 0x10) != 0);
    }
    
    boolean J() {
      return ((this.j & 0x80) != 0);
    }
    
    void K() {
      this.n.J(this);
    }
    
    boolean L() {
      return ((this.j & 0x20) != 0);
    }
    
    void a(Object param1Object) {
      if (param1Object == null) {
        b(1024);
        return;
      } 
      if ((0x400 & this.j) == 0) {
        g();
        this.k.add(param1Object);
      } 
    }
    
    void b(int param1Int) {
      this.j = param1Int | this.j;
    }
    
    void c() {
      this.d = -1;
      this.g = -1;
    }
    
    void d() {
      List<Object> list = this.k;
      if (list != null)
        list.clear(); 
      this.j &= 0xFFFFFBFF;
    }
    
    void e() {
      this.j &= 0xFFFFFFDF;
    }
    
    void f() {
      this.j &= 0xFFFFFEFF;
    }
    
    boolean h() {
      return ((this.j & 0x10) == 0 && androidx.core.view.w.P(this.a));
    }
    
    void i(int param1Int1, int param1Int2, boolean param1Boolean) {
      b(8);
      A(param1Int2, param1Boolean);
      this.c = param1Int1;
    }
    
    public final int j() {
      RecyclerView recyclerView = this.r;
      return (recyclerView == null) ? -1 : recyclerView.b0(this);
    }
    
    public final long k() {
      return this.e;
    }
    
    public final int l() {
      return this.f;
    }
    
    public final int m() {
      int j = this.g;
      int i = j;
      if (j == -1)
        i = this.c; 
      return i;
    }
    
    public final int n() {
      return this.d;
    }
    
    List<Object> o() {
      if ((this.j & 0x400) == 0) {
        List<Object> list = this.k;
        return (list == null || list.size() == 0) ? s : this.l;
      } 
      return s;
    }
    
    boolean p(int param1Int) {
      return ((param1Int & this.j) != 0);
    }
    
    boolean q() {
      return ((this.j & 0x200) != 0 || t());
    }
    
    boolean r() {
      return (this.a.getParent() != null && this.a.getParent() != this.r);
    }
    
    boolean s() {
      return ((this.j & 0x1) != 0);
    }
    
    boolean t() {
      return ((this.j & 0x4) != 0);
    }
    
    public String toString() {
      String str;
      if (getClass().isAnonymousClass()) {
        str = "ViewHolder";
      } else {
        str = getClass().getSimpleName();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(hashCode()));
      stringBuilder.append(" position=");
      stringBuilder.append(this.c);
      stringBuilder.append(" id=");
      stringBuilder.append(this.e);
      stringBuilder.append(", oldPos=");
      stringBuilder.append(this.d);
      stringBuilder.append(", pLpos:");
      stringBuilder.append(this.g);
      stringBuilder = new StringBuilder(stringBuilder.toString());
      if (w()) {
        stringBuilder.append(" scrap ");
        if (this.o) {
          str = "[changeScrap]";
        } else {
          str = "[attachedScrap]";
        } 
        stringBuilder.append(str);
      } 
      if (t())
        stringBuilder.append(" invalid"); 
      if (!s())
        stringBuilder.append(" unbound"); 
      if (z())
        stringBuilder.append(" update"); 
      if (v())
        stringBuilder.append(" removed"); 
      if (J())
        stringBuilder.append(" ignored"); 
      if (x())
        stringBuilder.append(" tmpDetached"); 
      if (!u()) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" not recyclable(");
        stringBuilder1.append(this.m);
        stringBuilder1.append(")");
        stringBuilder.append(stringBuilder1.toString());
      } 
      if (q())
        stringBuilder.append(" undefined adapter position"); 
      if (this.a.getParent() == null)
        stringBuilder.append(" no parent"); 
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public final boolean u() {
      return ((this.j & 0x10) == 0 && !androidx.core.view.w.P(this.a));
    }
    
    boolean v() {
      return ((this.j & 0x8) != 0);
    }
    
    boolean w() {
      return (this.n != null);
    }
    
    boolean x() {
      return ((this.j & 0x100) != 0);
    }
    
    boolean y() {
      return ((this.j & 0x2) != 0);
    }
    
    boolean z() {
      return ((this.j & 0x2) != 0);
    }
  }
  
  class e implements b.b {
    e(RecyclerView this$0) {}
    
    public View a(int param1Int) {
      return this.a.getChildAt(param1Int);
    }
    
    public void b(View param1View) {
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (d0 != null)
        d0.B(this.a); 
    }
    
    public RecyclerView.d0 c(View param1View) {
      return RecyclerView.f0(param1View);
    }
    
    public void d(int param1Int) {
      View view = a(param1Int);
      if (view != null) {
        RecyclerView.d0 d0 = RecyclerView.f0(view);
        if (d0 != null)
          if (!d0.x() || d0.J()) {
            d0.b(256);
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("called detach on an already detached child ");
            stringBuilder.append(d0);
            stringBuilder.append(this.a.P());
            throw new IllegalArgumentException(stringBuilder.toString());
          }  
      } 
      RecyclerView.d(this.a, param1Int);
    }
    
    public void e(View param1View) {
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (d0 != null)
        d0.C(this.a); 
    }
    
    public void f(View param1View, int param1Int) {
      this.a.addView(param1View, param1Int);
      this.a.y(param1View);
    }
    
    public int g() {
      return this.a.getChildCount();
    }
    
    public void h(int param1Int) {
      View view = this.a.getChildAt(param1Int);
      if (view != null) {
        this.a.z(view);
        view.clearAnimation();
      } 
      this.a.removeViewAt(param1Int);
    }
    
    public void i() {
      int j = g();
      for (int i = 0; i < j; i++) {
        View view = a(i);
        this.a.z(view);
        view.clearAnimation();
      } 
      this.a.removeAllViews();
    }
    
    public void j(View param1View, int param1Int, ViewGroup.LayoutParams param1LayoutParams) {
      StringBuilder stringBuilder;
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (d0 != null)
        if (d0.x() || d0.J()) {
          d0.f();
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Called attach on a child which is not detached: ");
          stringBuilder.append(d0);
          stringBuilder.append(this.a.P());
          throw new IllegalArgumentException(stringBuilder.toString());
        }  
      RecyclerView.c(this.a, (View)stringBuilder, param1Int, param1LayoutParams);
    }
    
    public int k(View param1View) {
      return this.a.indexOfChild(param1View);
    }
  }
  
  class f implements a.a {
    f(RecyclerView this$0) {}
    
    public void a(int param1Int1, int param1Int2) {
      this.a.B0(param1Int1, param1Int2);
      this.a.p0 = true;
    }
    
    public void b(a.b param1b) {
      i(param1b);
    }
    
    public RecyclerView.d0 c(int param1Int) {
      RecyclerView.d0 d0 = this.a.Z(param1Int, true);
      return (d0 == null) ? null : (this.a.j.n(d0.a) ? null : d0);
    }
    
    public void d(int param1Int1, int param1Int2) {
      this.a.C0(param1Int1, param1Int2, false);
      this.a.p0 = true;
    }
    
    public void e(int param1Int1, int param1Int2) {
      this.a.A0(param1Int1, param1Int2);
      this.a.p0 = true;
    }
    
    public void f(int param1Int1, int param1Int2) {
      this.a.C0(param1Int1, param1Int2, true);
      RecyclerView recyclerView = this.a;
      recyclerView.p0 = true;
      RecyclerView.a0 a0 = recyclerView.m0;
      a0.d += param1Int2;
    }
    
    public void g(a.b param1b) {
      i(param1b);
    }
    
    public void h(int param1Int1, int param1Int2, Object param1Object) {
      this.a.v1(param1Int1, param1Int2, param1Object);
      this.a.q0 = true;
    }
    
    void i(a.b param1b) {
      int i = param1b.a;
      if (i != 1) {
        if (i != 2) {
          if (i != 4) {
            if (i != 8)
              return; 
            RecyclerView recyclerView3 = this.a;
            recyclerView3.r.T0(recyclerView3, param1b.b, param1b.d, 1);
            return;
          } 
          RecyclerView recyclerView2 = this.a;
          recyclerView2.r.W0(recyclerView2, param1b.b, param1b.d, param1b.c);
          return;
        } 
        RecyclerView recyclerView1 = this.a;
        recyclerView1.r.U0(recyclerView1, param1b.b, param1b.d);
        return;
      } 
      RecyclerView recyclerView = this.a;
      recyclerView.r.R0(recyclerView, param1b.b, param1b.d);
    }
  }
  
  public static abstract class g<VH extends d0> {
    private final RecyclerView.h a = new RecyclerView.h();
    
    private boolean b = false;
    
    public final void a(VH param1VH, int param1Int) {
      ((RecyclerView.d0)param1VH).c = param1Int;
      if (g())
        ((RecyclerView.d0)param1VH).e = d(param1Int); 
      param1VH.F(1, 519);
      h0.i.a("RV OnBindView");
      k(param1VH, param1Int, param1VH.o());
      param1VH.d();
      ViewGroup.LayoutParams layoutParams = ((RecyclerView.d0)param1VH).a.getLayoutParams();
      if (layoutParams instanceof RecyclerView.p)
        ((RecyclerView.p)layoutParams).c = true; 
      h0.i.b();
    }
    
    public final VH b(ViewGroup param1ViewGroup, int param1Int) {
      try {
        h0.i.a("RV CreateView");
        param1ViewGroup = (ViewGroup)l(param1ViewGroup, param1Int);
        if (((RecyclerView.d0)param1ViewGroup).a.getParent() == null) {
          ((RecyclerView.d0)param1ViewGroup).f = param1Int;
          return (VH)param1ViewGroup;
        } 
        throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
      } finally {
        h0.i.b();
      } 
    }
    
    public abstract int c();
    
    public long d(int param1Int) {
      return -1L;
    }
    
    public int e(int param1Int) {
      return 0;
    }
    
    public final boolean f() {
      return this.a.a();
    }
    
    public final boolean g() {
      return this.b;
    }
    
    public final void h() {
      this.a.b();
    }
    
    public void i(RecyclerView param1RecyclerView) {}
    
    public abstract void j(VH param1VH, int param1Int);
    
    public void k(VH param1VH, int param1Int, List<Object> param1List) {
      j(param1VH, param1Int);
    }
    
    public abstract VH l(ViewGroup param1ViewGroup, int param1Int);
    
    public void m(RecyclerView param1RecyclerView) {}
    
    public boolean n(VH param1VH) {
      return false;
    }
    
    public void o(VH param1VH) {}
    
    public void p(VH param1VH) {}
    
    public void q(VH param1VH) {}
    
    public void r(RecyclerView.i param1i) {
      this.a.registerObserver(param1i);
    }
    
    public void s(boolean param1Boolean) {
      if (!f()) {
        this.b = param1Boolean;
        return;
      } 
      throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
    }
    
    public void t(RecyclerView.i param1i) {
      this.a.unregisterObserver(param1i);
    }
  }
  
  static class h extends Observable<i> {
    public boolean a() {
      return this.mObservers.isEmpty() ^ true;
    }
    
    public void b() {
      for (int i = this.mObservers.size() - 1; i >= 0; i--)
        ((RecyclerView.i)this.mObservers.get(i)).a(); 
    }
  }
  
  public static abstract class i {
    public void a() {}
  }
  
  public static interface j {
    int a(int param1Int1, int param1Int2);
  }
  
  public static class k {
    protected EdgeEffect a(RecyclerView param1RecyclerView, int param1Int) {
      return new EdgeEffect(param1RecyclerView.getContext());
    }
  }
  
  public static abstract class l {
    private b a = null;
    
    private ArrayList<a> b = new ArrayList<a>();
    
    private long c = 120L;
    
    private long d = 120L;
    
    private long e = 250L;
    
    private long f = 250L;
    
    static int e(RecyclerView.d0 param1d0) {
      int j = param1d0.j & 0xE;
      if (param1d0.t())
        return 4; 
      int i = j;
      if ((j & 0x4) == 0) {
        int k = param1d0.n();
        int m = param1d0.j();
        i = j;
        if (k != -1) {
          i = j;
          if (m != -1) {
            i = j;
            if (k != m)
              i = j | 0x800; 
          } 
        } 
      } 
      return i;
    }
    
    public abstract boolean a(RecyclerView.d0 param1d0, c param1c1, c param1c2);
    
    public abstract boolean b(RecyclerView.d0 param1d01, RecyclerView.d0 param1d02, c param1c1, c param1c2);
    
    public abstract boolean c(RecyclerView.d0 param1d0, c param1c1, c param1c2);
    
    public abstract boolean d(RecyclerView.d0 param1d0, c param1c1, c param1c2);
    
    public abstract boolean f(RecyclerView.d0 param1d0);
    
    public boolean g(RecyclerView.d0 param1d0, List<Object> param1List) {
      return f(param1d0);
    }
    
    public final void h(RecyclerView.d0 param1d0) {
      r(param1d0);
      b b1 = this.a;
      if (b1 != null)
        b1.a(param1d0); 
    }
    
    public final void i() {
      int j = this.b.size();
      for (int i = 0; i < j; i++)
        ((a)this.b.get(i)).a(); 
      this.b.clear();
    }
    
    public abstract void j(RecyclerView.d0 param1d0);
    
    public abstract void k();
    
    public long l() {
      return this.c;
    }
    
    public long m() {
      return this.f;
    }
    
    public long n() {
      return this.e;
    }
    
    public long o() {
      return this.d;
    }
    
    public abstract boolean p();
    
    public c q() {
      return new c();
    }
    
    public void r(RecyclerView.d0 param1d0) {}
    
    public c s(RecyclerView.a0 param1a0, RecyclerView.d0 param1d0) {
      return q().a(param1d0);
    }
    
    public c t(RecyclerView.a0 param1a0, RecyclerView.d0 param1d0, int param1Int, List<Object> param1List) {
      return q().a(param1d0);
    }
    
    public abstract void u();
    
    void v(b param1b) {
      this.a = param1b;
    }
    
    public static interface a {
      void a();
    }
    
    static interface b {
      void a(RecyclerView.d0 param2d0);
    }
    
    public static class c {
      public int a;
      
      public int b;
      
      public int c;
      
      public int d;
      
      public c a(RecyclerView.d0 param2d0) {
        return b(param2d0, 0);
      }
      
      public c b(RecyclerView.d0 param2d0, int param2Int) {
        View view = param2d0.a;
        this.a = view.getLeft();
        this.b = view.getTop();
        this.c = view.getRight();
        this.d = view.getBottom();
        return this;
      }
    }
  }
  
  public static interface a {
    void a();
  }
  
  static interface b {
    void a(RecyclerView.d0 param1d0);
  }
  
  public static class c {
    public int a;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public c a(RecyclerView.d0 param1d0) {
      return b(param1d0, 0);
    }
    
    public c b(RecyclerView.d0 param1d0, int param1Int) {
      View view = param1d0.a;
      this.a = view.getLeft();
      this.b = view.getTop();
      this.c = view.getRight();
      this.d = view.getBottom();
      return this;
    }
  }
  
  private class m implements l.b {
    m(RecyclerView this$0) {}
    
    public void a(RecyclerView.d0 param1d0) {
      param1d0.G(true);
      if (param1d0.h != null && param1d0.i == null)
        param1d0.h = null; 
      param1d0.i = null;
      if (!param1d0.I() && !this.a.U0(param1d0.a) && param1d0.x())
        this.a.removeDetachedView(param1d0.a, false); 
    }
  }
  
  public static abstract class n {
    @Deprecated
    public void d(Rect param1Rect, int param1Int, RecyclerView param1RecyclerView) {
      param1Rect.set(0, 0, 0, 0);
    }
    
    public void e(Rect param1Rect, View param1View, RecyclerView param1RecyclerView, RecyclerView.a0 param1a0) {
      d(param1Rect, ((RecyclerView.p)param1View.getLayoutParams()).a(), param1RecyclerView);
    }
    
    @Deprecated
    public void f(Canvas param1Canvas, RecyclerView param1RecyclerView) {}
    
    public void g(Canvas param1Canvas, RecyclerView param1RecyclerView, RecyclerView.a0 param1a0) {
      f(param1Canvas, param1RecyclerView);
    }
    
    @Deprecated
    public void h(Canvas param1Canvas, RecyclerView param1RecyclerView) {}
    
    public void i(Canvas param1Canvas, RecyclerView param1RecyclerView, RecyclerView.a0 param1a0) {
      h(param1Canvas, param1RecyclerView);
    }
  }
  
  public static abstract class o {
    b a;
    
    RecyclerView b;
    
    private final o.b c;
    
    private final o.b d;
    
    o e;
    
    o f;
    
    RecyclerView.z g;
    
    boolean h;
    
    boolean i;
    
    boolean j;
    
    private boolean k;
    
    private boolean l;
    
    int m;
    
    boolean n;
    
    private int o;
    
    private int p;
    
    private int q;
    
    private int r;
    
    public o() {
      a a = new a(this);
      this.c = a;
      b b1 = new b(this);
      this.d = b1;
      this.e = new o(a);
      this.f = new o(b1);
      this.h = false;
      this.i = false;
      this.j = false;
      this.k = true;
      this.l = true;
    }
    
    public static int K(int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean) {
      param1Int1 = Math.max(0, param1Int1 - param1Int3);
      if (param1Boolean) {
        if (param1Int4 >= 0) {
          param1Int2 = 1073741824;
          return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
        } 
        if (param1Int4 != -1 || (param1Int2 != Integer.MIN_VALUE && (param1Int2 == 0 || param1Int2 != 1073741824))) {
          param1Int2 = 0;
          param1Int4 = param1Int2;
        } 
      } else {
        if (param1Int4 >= 0) {
          param1Int2 = 1073741824;
          return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
        } 
        if (param1Int4 == -1) {
          param1Int4 = param1Int1;
          return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
        } 
        if (param1Int4 == -2) {
          if (param1Int2 == Integer.MIN_VALUE || param1Int2 == 1073741824) {
            param1Int2 = Integer.MIN_VALUE;
            param1Int4 = param1Int1;
            return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
          } 
          param1Int2 = 0;
          param1Int4 = param1Int1;
          return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
        } 
        param1Int2 = 0;
        param1Int4 = param1Int2;
      } 
      param1Int4 = param1Int1;
      return View.MeasureSpec.makeMeasureSpec(param1Int4, param1Int2);
    }
    
    private int[] L(View param1View, Rect param1Rect) {
      int i = e0();
      int j = g0();
      int k = o0();
      int i5 = f0();
      int n = W();
      int i1 = d0();
      int i6 = param1View.getLeft() + param1Rect.left - param1View.getScrollX();
      int i2 = param1View.getTop() + param1Rect.top - param1View.getScrollY();
      int i7 = param1Rect.width();
      int i3 = param1Rect.height();
      int i4 = i6 - i;
      i = Math.min(0, i4);
      int m = i2 - j;
      j = Math.min(0, m);
      i5 = i7 + i6 - k - i5;
      k = Math.max(0, i5);
      n = Math.max(0, i3 + i2 - n - i1);
      if (Z() == 1) {
        if (k != 0) {
          i = k;
        } else {
          i = Math.max(i, i5);
        } 
      } else if (i == 0) {
        i = Math.min(i4, k);
      } 
      if (j == 0)
        j = Math.min(m, n); 
      return new int[] { i, j };
    }
    
    private void f(View param1View, int param1Int, boolean param1Boolean) {
      StringBuilder stringBuilder;
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (param1Boolean || d0.v()) {
        this.b.k.b(d0);
      } else {
        this.b.k.p(d0);
      } 
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      if (d0.L() || d0.w()) {
        if (d0.w()) {
          d0.K();
        } else {
          d0.e();
        } 
        this.a.c(param1View, param1Int, param1View.getLayoutParams(), false);
      } else if (param1View.getParent() == this.b) {
        int j = this.a.m(param1View);
        int i = param1Int;
        if (param1Int == -1)
          i = this.a.g(); 
        if (j != -1) {
          if (j != i)
            this.b.r.B0(j, i); 
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
          stringBuilder.append(this.b.indexOfChild(param1View));
          stringBuilder.append(this.b.P());
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } else {
        this.a.a(param1View, param1Int, false);
        p.c = true;
        RecyclerView.z z1 = this.g;
        if (z1 != null && z1.h())
          this.g.k(param1View); 
      } 
      if (p.d) {
        ((RecyclerView.d0)stringBuilder).a.invalidate();
        p.d = false;
      } 
    }
    
    public static d i0(Context param1Context, AttributeSet param1AttributeSet, int param1Int1, int param1Int2) {
      d d = new d();
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, d1.c.f, param1Int1, param1Int2);
      d.a = typedArray.getInt(d1.c.g, 1);
      d.b = typedArray.getInt(d1.c.q, 1);
      d.c = typedArray.getBoolean(d1.c.p, false);
      d.d = typedArray.getBoolean(d1.c.r, false);
      typedArray.recycle();
      return d;
    }
    
    public static int n(int param1Int1, int param1Int2, int param1Int3) {
      int i = View.MeasureSpec.getMode(param1Int1);
      param1Int1 = View.MeasureSpec.getSize(param1Int1);
      if (i != Integer.MIN_VALUE) {
        if (i != 1073741824)
          param1Int1 = Math.max(param1Int2, param1Int3); 
        return param1Int1;
      } 
      return Math.min(param1Int1, Math.max(param1Int2, param1Int3));
    }
    
    private boolean t0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {
      View view = param1RecyclerView.getFocusedChild();
      if (view == null)
        return false; 
      int i = e0();
      int j = g0();
      int k = o0();
      int m = f0();
      int n = W();
      int i1 = d0();
      Rect rect = this.b.n;
      P(view, rect);
      return (rect.left - param1Int1 < k - m && rect.right - param1Int1 > i && rect.top - param1Int2 < n - i1) ? (!(rect.bottom - param1Int2 <= j)) : false;
    }
    
    private void v1(RecyclerView.v param1v, int param1Int, View param1View) {
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (d0.J())
        return; 
      if (d0.t() && !d0.v() && !this.b.q.g()) {
        q1(param1Int);
        param1v.C(d0);
        return;
      } 
      x(param1Int);
      param1v.D(param1View);
      this.b.k.k(d0);
    }
    
    private static boolean w0(int param1Int1, int param1Int2, int param1Int3) {
      int i = View.MeasureSpec.getMode(param1Int2);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      boolean bool2 = false;
      boolean bool1 = false;
      if (param1Int3 > 0 && param1Int1 != param1Int3)
        return false; 
      if (i != Integer.MIN_VALUE) {
        if (i != 0) {
          if (i != 1073741824)
            return false; 
          if (param1Int2 == param1Int1)
            bool1 = true; 
          return bool1;
        } 
        return true;
      } 
      bool1 = bool2;
      if (param1Int2 >= param1Int1)
        bool1 = true; 
      return bool1;
    }
    
    private void y(int param1Int, View param1View) {
      this.a.d(param1Int);
    }
    
    void A(RecyclerView param1RecyclerView, RecyclerView.v param1v) {
      this.i = false;
      I0(param1RecyclerView, param1v);
    }
    
    public void A0(View param1View, int param1Int1, int param1Int2) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      Rect rect = this.b.j0(param1View);
      int k = rect.left;
      int m = rect.right;
      int i = rect.top;
      int j = rect.bottom;
      param1Int1 = K(o0(), p0(), e0() + f0() + p.leftMargin + p.rightMargin + param1Int1 + k + m, p.width, k());
      param1Int2 = K(W(), X(), g0() + d0() + p.topMargin + p.bottomMargin + param1Int2 + i + j, p.height, l());
      if (F1(param1View, param1Int1, param1Int2, p))
        param1View.measure(param1Int1, param1Int2); 
    }
    
    void A1(int param1Int1, int param1Int2) {
      this.q = View.MeasureSpec.getSize(param1Int1);
      param1Int1 = View.MeasureSpec.getMode(param1Int1);
      this.o = param1Int1;
      if (param1Int1 == 0 && !RecyclerView.F0)
        this.q = 0; 
      this.r = View.MeasureSpec.getSize(param1Int2);
      param1Int1 = View.MeasureSpec.getMode(param1Int2);
      this.p = param1Int1;
      if (param1Int1 == 0 && !RecyclerView.F0)
        this.r = 0; 
    }
    
    public View B(View param1View) {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null)
        return null; 
      param1View = recyclerView.R(param1View);
      return (param1View == null) ? null : (this.a.n(param1View) ? null : param1View);
    }
    
    public void B0(int param1Int1, int param1Int2) {
      View view = I(param1Int1);
      if (view != null) {
        x(param1Int1);
        h(view, param1Int2);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot move a child from non-existing index:");
      stringBuilder.append(param1Int1);
      stringBuilder.append(this.b.toString());
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public void B1(int param1Int1, int param1Int2) {
      RecyclerView.f(this.b, param1Int1, param1Int2);
    }
    
    public View C(int param1Int) {
      int j = J();
      for (int i = 0; i < j; i++) {
        View view = I(i);
        RecyclerView.d0 d0 = RecyclerView.f0(view);
        if (d0 != null && d0.m() == param1Int && !d0.J() && (this.b.m0.e() || !d0.v()))
          return view; 
      } 
      return null;
    }
    
    public void C0(int param1Int) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.y0(param1Int); 
    }
    
    public void C1(Rect param1Rect, int param1Int1, int param1Int2) {
      int i = param1Rect.width();
      int j = e0();
      int k = f0();
      int m = param1Rect.height();
      int n = g0();
      int i1 = d0();
      B1(n(param1Int1, i + j + k, c0()), n(param1Int2, m + n + i1, b0()));
    }
    
    public abstract RecyclerView.p D();
    
    public void D0(int param1Int) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.z0(param1Int); 
    }
    
    void D1(int param1Int1, int param1Int2) {
      int i1 = J();
      if (i1 == 0) {
        this.b.w(param1Int1, param1Int2);
        return;
      } 
      int j = 0;
      int n = Integer.MIN_VALUE;
      int m = Integer.MAX_VALUE;
      int k = m;
      int i = Integer.MIN_VALUE;
      while (j < i1) {
        View view = I(j);
        Rect rect = this.b.n;
        P(view, rect);
        int i3 = rect.left;
        int i2 = m;
        if (i3 < m)
          i2 = i3; 
        i3 = rect.right;
        m = n;
        if (i3 > n)
          m = i3; 
        n = rect.top;
        i3 = k;
        if (n < k)
          i3 = n; 
        n = rect.bottom;
        k = i;
        if (n > i)
          k = n; 
        j++;
        n = m;
        i = k;
        m = i2;
        k = i3;
      } 
      this.b.n.set(m, k, n, i);
      C1(this.b.n, param1Int1, param1Int2);
    }
    
    public RecyclerView.p E(Context param1Context, AttributeSet param1AttributeSet) {
      return new RecyclerView.p(param1Context, param1AttributeSet);
    }
    
    public void E0(RecyclerView.g param1g1, RecyclerView.g param1g2) {}
    
    void E1(RecyclerView param1RecyclerView) {
      if (param1RecyclerView == null) {
        this.b = null;
        this.a = null;
        this.q = 0;
        this.r = 0;
      } else {
        this.b = param1RecyclerView;
        this.a = param1RecyclerView.j;
        this.q = param1RecyclerView.getWidth();
        this.r = param1RecyclerView.getHeight();
      } 
      this.o = 1073741824;
      this.p = 1073741824;
    }
    
    public RecyclerView.p F(ViewGroup.LayoutParams param1LayoutParams) {
      return (param1LayoutParams instanceof RecyclerView.p) ? new RecyclerView.p((RecyclerView.p)param1LayoutParams) : ((param1LayoutParams instanceof ViewGroup.MarginLayoutParams) ? new RecyclerView.p((ViewGroup.MarginLayoutParams)param1LayoutParams) : new RecyclerView.p(param1LayoutParams));
    }
    
    public boolean F0(RecyclerView param1RecyclerView, ArrayList<View> param1ArrayList, int param1Int1, int param1Int2) {
      return false;
    }
    
    boolean F1(View param1View, int param1Int1, int param1Int2, RecyclerView.p param1p) {
      return (param1View.isLayoutRequested() || !this.k || !w0(param1View.getWidth(), param1Int1, param1p.width) || !w0(param1View.getHeight(), param1Int2, param1p.height));
    }
    
    public int G() {
      return -1;
    }
    
    public void G0(RecyclerView param1RecyclerView) {}
    
    boolean G1() {
      return false;
    }
    
    public int H(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).b.bottom;
    }
    
    @Deprecated
    public void H0(RecyclerView param1RecyclerView) {}
    
    boolean H1(View param1View, int param1Int1, int param1Int2, RecyclerView.p param1p) {
      return (!this.k || !w0(param1View.getMeasuredWidth(), param1Int1, param1p.width) || !w0(param1View.getMeasuredHeight(), param1Int2, param1p.height));
    }
    
    public View I(int param1Int) {
      b b1 = this.a;
      return (b1 != null) ? b1.f(param1Int) : null;
    }
    
    public void I0(RecyclerView param1RecyclerView, RecyclerView.v param1v) {
      H0(param1RecyclerView);
    }
    
    public void I1(RecyclerView param1RecyclerView, RecyclerView.a0 param1a0, int param1Int) {
      Log.e("RecyclerView", "You must override smoothScrollToPosition to support smooth scrolling");
    }
    
    public int J() {
      b b1 = this.a;
      return (b1 != null) ? b1.g() : 0;
    }
    
    public View J0(View param1View, int param1Int, RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return null;
    }
    
    public void J1(RecyclerView.z param1z) {
      RecyclerView.z z1 = this.g;
      if (z1 != null && param1z != z1 && z1.h())
        this.g.r(); 
      this.g = param1z;
      param1z.q(this.b, this);
    }
    
    public void K0(AccessibilityEvent param1AccessibilityEvent) {
      RecyclerView recyclerView = this.b;
      L0(recyclerView.g, recyclerView.m0, param1AccessibilityEvent);
    }
    
    void K1() {
      RecyclerView.z z1 = this.g;
      if (z1 != null)
        z1.r(); 
    }
    
    public void L0(RecyclerView.v param1v, RecyclerView.a0 param1a0, AccessibilityEvent param1AccessibilityEvent) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        if (param1AccessibilityEvent == null)
          return; 
        boolean bool2 = true;
        boolean bool1 = bool2;
        if (!recyclerView.canScrollVertically(1)) {
          bool1 = bool2;
          if (!this.b.canScrollVertically(-1)) {
            bool1 = bool2;
            if (!this.b.canScrollHorizontally(-1))
              if (this.b.canScrollHorizontally(1)) {
                bool1 = bool2;
              } else {
                bool1 = false;
              }  
          } 
        } 
        param1AccessibilityEvent.setScrollable(bool1);
        RecyclerView.g g = this.b.q;
        if (g != null)
          param1AccessibilityEvent.setItemCount(g.c()); 
      } 
    }
    
    public boolean L1() {
      return false;
    }
    
    public boolean M() {
      RecyclerView recyclerView = this.b;
      return (recyclerView != null && recyclerView.l);
    }
    
    public void M0(RecyclerView.v param1v, RecyclerView.a0 param1a0, l0.c param1c) {
      if (this.b.canScrollVertically(-1) || this.b.canScrollHorizontally(-1)) {
        param1c.a(8192);
        param1c.s0(true);
      } 
      if (this.b.canScrollVertically(1) || this.b.canScrollHorizontally(1)) {
        param1c.a(4096);
        param1c.s0(true);
      } 
      param1c.c0(l0.c.b.b(k0(param1v, param1a0), N(param1v, param1a0), v0(param1v, param1a0), l0(param1v, param1a0)));
    }
    
    public int N(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      RecyclerView recyclerView = this.b;
      byte b1 = 1;
      int i = b1;
      if (recyclerView != null) {
        if (recyclerView.q == null)
          return 1; 
        i = b1;
        if (k())
          i = this.b.q.c(); 
      } 
      return i;
    }
    
    void N0(l0.c param1c) {
      RecyclerView recyclerView = this.b;
      M0(recyclerView.g, recyclerView.m0, param1c);
    }
    
    public int O(View param1View) {
      return param1View.getBottom() + H(param1View);
    }
    
    void O0(View param1View, l0.c param1c) {
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (d0 != null && !d0.v() && !this.a.n(d0.a)) {
        RecyclerView recyclerView = this.b;
        P0(recyclerView.g, recyclerView.m0, param1View, param1c);
      } 
    }
    
    public void P(View param1View, Rect param1Rect) {
      RecyclerView.g0(param1View, param1Rect);
    }
    
    public void P0(RecyclerView.v param1v, RecyclerView.a0 param1a0, View param1View, l0.c param1c) {
      boolean bool;
      boolean bool1 = l();
      int i = 0;
      if (bool1) {
        bool = h0(param1View);
      } else {
        bool = false;
      } 
      if (k())
        i = h0(param1View); 
      param1c.d0(l0.c.c.a(bool, 1, i, 1, false, false));
    }
    
    public int Q(View param1View) {
      return param1View.getLeft() - a0(param1View);
    }
    
    public View Q0(View param1View, int param1Int) {
      return null;
    }
    
    public int R(View param1View) {
      Rect rect = ((RecyclerView.p)param1View.getLayoutParams()).b;
      return param1View.getMeasuredHeight() + rect.top + rect.bottom;
    }
    
    public void R0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public int S(View param1View) {
      Rect rect = ((RecyclerView.p)param1View.getLayoutParams()).b;
      return param1View.getMeasuredWidth() + rect.left + rect.right;
    }
    
    public void S0(RecyclerView param1RecyclerView) {}
    
    public int T(View param1View) {
      return param1View.getRight() + j0(param1View);
    }
    
    public void T0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public int U(View param1View) {
      return param1View.getTop() - m0(param1View);
    }
    
    public void U0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public View V() {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null)
        return null; 
      View view = recyclerView.getFocusedChild();
      return (view != null) ? (this.a.n(view) ? null : view) : null;
    }
    
    public void V0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
    
    public int W() {
      return this.r;
    }
    
    public void W0(RecyclerView param1RecyclerView, int param1Int1, int param1Int2, Object param1Object) {
      V0(param1RecyclerView, param1Int1, param1Int2);
    }
    
    public int X() {
      return this.p;
    }
    
    public void X0(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
    }
    
    public int Y() {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null) {
        RecyclerView.g g = recyclerView.getAdapter();
      } else {
        recyclerView = null;
      } 
      return (recyclerView != null) ? recyclerView.c() : 0;
    }
    
    public void Y0(RecyclerView.a0 param1a0) {}
    
    public int Z() {
      return androidx.core.view.w.B((View)this.b);
    }
    
    public void Z0(RecyclerView.v param1v, RecyclerView.a0 param1a0, int param1Int1, int param1Int2) {
      this.b.w(param1Int1, param1Int2);
    }
    
    public int a0(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).b.left;
    }
    
    @Deprecated
    public boolean a1(RecyclerView param1RecyclerView, View param1View1, View param1View2) {
      return (x0() || param1RecyclerView.t0());
    }
    
    public void b(View param1View) {
      c(param1View, -1);
    }
    
    public int b0() {
      return androidx.core.view.w.C((View)this.b);
    }
    
    public boolean b1(RecyclerView param1RecyclerView, RecyclerView.a0 param1a0, View param1View1, View param1View2) {
      return a1(param1RecyclerView, param1View1, param1View2);
    }
    
    public void c(View param1View, int param1Int) {
      f(param1View, param1Int, true);
    }
    
    public int c0() {
      return androidx.core.view.w.D((View)this.b);
    }
    
    public void c1(Parcelable param1Parcelable) {}
    
    public void d(View param1View) {
      e(param1View, -1);
    }
    
    public int d0() {
      RecyclerView recyclerView = this.b;
      return (recyclerView != null) ? recyclerView.getPaddingBottom() : 0;
    }
    
    public Parcelable d1() {
      return null;
    }
    
    public void e(View param1View, int param1Int) {
      f(param1View, param1Int, false);
    }
    
    public int e0() {
      RecyclerView recyclerView = this.b;
      return (recyclerView != null) ? recyclerView.getPaddingLeft() : 0;
    }
    
    public void e1(int param1Int) {}
    
    public int f0() {
      RecyclerView recyclerView = this.b;
      return (recyclerView != null) ? recyclerView.getPaddingRight() : 0;
    }
    
    void f1(RecyclerView.z param1z) {
      if (this.g == param1z)
        this.g = null; 
    }
    
    public void g(String param1String) {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.o(param1String); 
    }
    
    public int g0() {
      RecyclerView recyclerView = this.b;
      return (recyclerView != null) ? recyclerView.getPaddingTop() : 0;
    }
    
    boolean g1(int param1Int, Bundle param1Bundle) {
      RecyclerView recyclerView = this.b;
      return h1(recyclerView.g, recyclerView.m0, param1Int, param1Bundle);
    }
    
    public void h(View param1View, int param1Int) {
      i(param1View, param1Int, (RecyclerView.p)param1View.getLayoutParams());
    }
    
    public int h0(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).a();
    }
    
    public boolean h1(RecyclerView.v param1v, RecyclerView.a0 param1a0, int param1Int, Bundle param1Bundle) {
      // Byte code:
      //   0: aload_0
      //   1: getfield b : Landroidx/recyclerview/widget/RecyclerView;
      //   4: astore_1
      //   5: aload_1
      //   6: ifnonnull -> 11
      //   9: iconst_0
      //   10: ireturn
      //   11: iload_3
      //   12: sipush #4096
      //   15: if_icmpeq -> 96
      //   18: iload_3
      //   19: sipush #8192
      //   22: if_icmpeq -> 33
      //   25: iconst_0
      //   26: istore_3
      //   27: iload_3
      //   28: istore #5
      //   30: goto -> 169
      //   33: aload_1
      //   34: iconst_m1
      //   35: invokevirtual canScrollVertically : (I)Z
      //   38: ifeq -> 60
      //   41: aload_0
      //   42: invokevirtual W : ()I
      //   45: aload_0
      //   46: invokevirtual g0 : ()I
      //   49: isub
      //   50: aload_0
      //   51: invokevirtual d0 : ()I
      //   54: isub
      //   55: ineg
      //   56: istore_3
      //   57: goto -> 62
      //   60: iconst_0
      //   61: istore_3
      //   62: iload_3
      //   63: istore #5
      //   65: aload_0
      //   66: getfield b : Landroidx/recyclerview/widget/RecyclerView;
      //   69: iconst_m1
      //   70: invokevirtual canScrollHorizontally : (I)Z
      //   73: ifeq -> 167
      //   76: aload_0
      //   77: invokevirtual o0 : ()I
      //   80: aload_0
      //   81: invokevirtual e0 : ()I
      //   84: isub
      //   85: aload_0
      //   86: invokevirtual f0 : ()I
      //   89: isub
      //   90: ineg
      //   91: istore #5
      //   93: goto -> 154
      //   96: aload_1
      //   97: iconst_1
      //   98: invokevirtual canScrollVertically : (I)Z
      //   101: ifeq -> 122
      //   104: aload_0
      //   105: invokevirtual W : ()I
      //   108: aload_0
      //   109: invokevirtual g0 : ()I
      //   112: isub
      //   113: aload_0
      //   114: invokevirtual d0 : ()I
      //   117: isub
      //   118: istore_3
      //   119: goto -> 124
      //   122: iconst_0
      //   123: istore_3
      //   124: iload_3
      //   125: istore #5
      //   127: aload_0
      //   128: getfield b : Landroidx/recyclerview/widget/RecyclerView;
      //   131: iconst_1
      //   132: invokevirtual canScrollHorizontally : (I)Z
      //   135: ifeq -> 167
      //   138: aload_0
      //   139: invokevirtual o0 : ()I
      //   142: aload_0
      //   143: invokevirtual e0 : ()I
      //   146: isub
      //   147: aload_0
      //   148: invokevirtual f0 : ()I
      //   151: isub
      //   152: istore #5
      //   154: iload_3
      //   155: istore #6
      //   157: iload #5
      //   159: istore_3
      //   160: iload #6
      //   162: istore #5
      //   164: goto -> 169
      //   167: iconst_0
      //   168: istore_3
      //   169: iload #5
      //   171: ifne -> 180
      //   174: iload_3
      //   175: ifne -> 180
      //   178: iconst_0
      //   179: ireturn
      //   180: aload_0
      //   181: getfield b : Landroidx/recyclerview/widget/RecyclerView;
      //   184: iload_3
      //   185: iload #5
      //   187: aconst_null
      //   188: ldc -2147483648
      //   190: iconst_1
      //   191: invokevirtual n1 : (IILandroid/view/animation/Interpolator;IZ)V
      //   194: iconst_1
      //   195: ireturn
    }
    
    public void i(View param1View, int param1Int, RecyclerView.p param1p) {
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (d0.v()) {
        this.b.k.b(d0);
      } else {
        this.b.k.p(d0);
      } 
      this.a.c(param1View, param1Int, (ViewGroup.LayoutParams)param1p, d0.v());
    }
    
    boolean i1(View param1View, int param1Int, Bundle param1Bundle) {
      RecyclerView recyclerView = this.b;
      return j1(recyclerView.g, recyclerView.m0, param1View, param1Int, param1Bundle);
    }
    
    public void j(View param1View, Rect param1Rect) {
      RecyclerView recyclerView = this.b;
      if (recyclerView == null) {
        param1Rect.set(0, 0, 0, 0);
        return;
      } 
      param1Rect.set(recyclerView.j0(param1View));
    }
    
    public int j0(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).b.right;
    }
    
    public boolean j1(RecyclerView.v param1v, RecyclerView.a0 param1a0, View param1View, int param1Int, Bundle param1Bundle) {
      return false;
    }
    
    public boolean k() {
      return false;
    }
    
    public int k0(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      RecyclerView recyclerView = this.b;
      byte b1 = 1;
      int i = b1;
      if (recyclerView != null) {
        if (recyclerView.q == null)
          return 1; 
        i = b1;
        if (l())
          i = this.b.q.c(); 
      } 
      return i;
    }
    
    public void k1(RecyclerView.v param1v) {
      for (int i = J() - 1; i >= 0; i--) {
        if (!RecyclerView.f0(I(i)).J())
          n1(i, param1v); 
      } 
    }
    
    public boolean l() {
      return false;
    }
    
    public int l0(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return 0;
    }
    
    void l1(RecyclerView.v param1v) {
      int j = param1v.j();
      for (int i = j - 1; i >= 0; i--) {
        View view = param1v.n(i);
        RecyclerView.d0 d0 = RecyclerView.f0(view);
        if (!d0.J()) {
          d0.G(false);
          if (d0.x())
            this.b.removeDetachedView(view, false); 
          RecyclerView.l l = this.b.R;
          if (l != null)
            l.j(d0); 
          d0.G(true);
          param1v.y(view);
        } 
      } 
      param1v.e();
      if (j > 0)
        this.b.invalidate(); 
    }
    
    public boolean m(RecyclerView.p param1p) {
      return (param1p != null);
    }
    
    public int m0(View param1View) {
      return ((RecyclerView.p)param1View.getLayoutParams()).b.top;
    }
    
    public void m1(View param1View, RecyclerView.v param1v) {
      p1(param1View);
      param1v.B(param1View);
    }
    
    public void n0(View param1View, boolean param1Boolean, Rect param1Rect) {
      if (param1Boolean) {
        Rect rect = ((RecyclerView.p)param1View.getLayoutParams()).b;
        param1Rect.set(-rect.left, -rect.top, param1View.getWidth() + rect.right, param1View.getHeight() + rect.bottom);
      } else {
        param1Rect.set(0, 0, param1View.getWidth(), param1View.getHeight());
      } 
      if (this.b != null) {
        Matrix matrix = param1View.getMatrix();
        if (matrix != null && !matrix.isIdentity()) {
          RectF rectF = this.b.p;
          rectF.set(param1Rect);
          matrix.mapRect(rectF);
          param1Rect.set((int)Math.floor(rectF.left), (int)Math.floor(rectF.top), (int)Math.ceil(rectF.right), (int)Math.ceil(rectF.bottom));
        } 
      } 
      param1Rect.offset(param1View.getLeft(), param1View.getTop());
    }
    
    public void n1(int param1Int, RecyclerView.v param1v) {
      View view = I(param1Int);
      q1(param1Int);
      param1v.B(view);
    }
    
    public void o(int param1Int1, int param1Int2, RecyclerView.a0 param1a0, c param1c) {}
    
    public int o0() {
      return this.q;
    }
    
    public boolean o1(Runnable param1Runnable) {
      RecyclerView recyclerView = this.b;
      return (recyclerView != null) ? recyclerView.removeCallbacks(param1Runnable) : false;
    }
    
    public void p(int param1Int, c param1c) {}
    
    public int p0() {
      return this.o;
    }
    
    public void p1(View param1View) {
      this.a.p(param1View);
    }
    
    public int q(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    boolean q0() {
      int j = J();
      for (int i = 0; i < j; i++) {
        ViewGroup.LayoutParams layoutParams = I(i).getLayoutParams();
        if (layoutParams.width < 0 && layoutParams.height < 0)
          return true; 
      } 
      return false;
    }
    
    public void q1(int param1Int) {
      if (I(param1Int) != null)
        this.a.q(param1Int); 
    }
    
    public int r(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public boolean r0() {
      return this.i;
    }
    
    public boolean r1(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean) {
      return s1(param1RecyclerView, param1View, param1Rect, param1Boolean, false);
    }
    
    public int s(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public boolean s0() {
      return this.j;
    }
    
    public boolean s1(RecyclerView param1RecyclerView, View param1View, Rect param1Rect, boolean param1Boolean1, boolean param1Boolean2) {
      int[] arrayOfInt = L(param1View, param1Rect);
      int i = arrayOfInt[0];
      int j = arrayOfInt[1];
      if ((!param1Boolean2 || t0(param1RecyclerView, i, j)) && (i != 0 || j != 0)) {
        if (param1Boolean1) {
          param1RecyclerView.scrollBy(i, j);
          return true;
        } 
        param1RecyclerView.k1(i, j);
        return true;
      } 
      return false;
    }
    
    public int t(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public void t1() {
      RecyclerView recyclerView = this.b;
      if (recyclerView != null)
        recyclerView.requestLayout(); 
    }
    
    public int u(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public final boolean u0() {
      return this.l;
    }
    
    public void u1() {
      this.h = true;
    }
    
    public int v(RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public boolean v0(RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return false;
    }
    
    public void w(RecyclerView.v param1v) {
      for (int i = J() - 1; i >= 0; i--)
        v1(param1v, i, I(i)); 
    }
    
    public int w1(int param1Int, RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return 0;
    }
    
    public void x(int param1Int) {
      y(param1Int, I(param1Int));
    }
    
    public boolean x0() {
      RecyclerView.z z1 = this.g;
      return (z1 != null && z1.h());
    }
    
    public void x1(int param1Int) {}
    
    public boolean y0(View param1View, boolean param1Boolean1, boolean param1Boolean2) {
      if (this.e.b(param1View, 24579) && this.f.b(param1View, 24579)) {
        param1Boolean2 = true;
      } else {
        param1Boolean2 = false;
      } 
      return param1Boolean1 ? param1Boolean2 : (param1Boolean2 ^ true);
    }
    
    public int y1(int param1Int, RecyclerView.v param1v, RecyclerView.a0 param1a0) {
      return 0;
    }
    
    void z(RecyclerView param1RecyclerView) {
      this.i = true;
      G0(param1RecyclerView);
    }
    
    public void z0(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      Rect rect = p.b;
      param1View.layout(param1Int1 + rect.left + p.leftMargin, param1Int2 + rect.top + p.topMargin, param1Int3 - rect.right - p.rightMargin, param1Int4 - rect.bottom - p.bottomMargin);
    }
    
    void z1(RecyclerView param1RecyclerView) {
      A1(View.MeasureSpec.makeMeasureSpec(param1RecyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(param1RecyclerView.getHeight(), 1073741824));
    }
    
    class a implements o.b {
      a(RecyclerView.o this$0) {}
      
      public View a(int param2Int) {
        return this.a.I(param2Int);
      }
      
      public int b() {
        return this.a.o0() - this.a.f0();
      }
      
      public int c(View param2View) {
        RecyclerView.p p = (RecyclerView.p)param2View.getLayoutParams();
        return this.a.Q(param2View) - p.leftMargin;
      }
      
      public int d() {
        return this.a.e0();
      }
      
      public int e(View param2View) {
        RecyclerView.p p = (RecyclerView.p)param2View.getLayoutParams();
        return this.a.T(param2View) + p.rightMargin;
      }
    }
    
    class b implements o.b {
      b(RecyclerView.o this$0) {}
      
      public View a(int param2Int) {
        return this.a.I(param2Int);
      }
      
      public int b() {
        return this.a.W() - this.a.d0();
      }
      
      public int c(View param2View) {
        RecyclerView.p p = (RecyclerView.p)param2View.getLayoutParams();
        return this.a.U(param2View) - p.topMargin;
      }
      
      public int d() {
        return this.a.g0();
      }
      
      public int e(View param2View) {
        RecyclerView.p p = (RecyclerView.p)param2View.getLayoutParams();
        return this.a.O(param2View) + p.bottomMargin;
      }
    }
    
    public static interface c {
      void a(int param2Int1, int param2Int2);
    }
    
    public static class d {
      public int a;
      
      public int b;
      
      public boolean c;
      
      public boolean d;
    }
  }
  
  class a implements o.b {
    a(RecyclerView this$0) {}
    
    public View a(int param1Int) {
      return this.a.I(param1Int);
    }
    
    public int b() {
      return this.a.o0() - this.a.f0();
    }
    
    public int c(View param1View) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return this.a.Q(param1View) - p.leftMargin;
    }
    
    public int d() {
      return this.a.e0();
    }
    
    public int e(View param1View) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return this.a.T(param1View) + p.rightMargin;
    }
  }
  
  class b implements o.b {
    b(RecyclerView this$0) {}
    
    public View a(int param1Int) {
      return this.a.I(param1Int);
    }
    
    public int b() {
      return this.a.W() - this.a.d0();
    }
    
    public int c(View param1View) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return this.a.U(param1View) - p.topMargin;
    }
    
    public int d() {
      return this.a.g0();
    }
    
    public int e(View param1View) {
      RecyclerView.p p = (RecyclerView.p)param1View.getLayoutParams();
      return this.a.O(param1View) + p.bottomMargin;
    }
  }
  
  public static interface c {
    void a(int param1Int1, int param1Int2);
  }
  
  public static class d {
    public int a;
    
    public int b;
    
    public boolean c;
    
    public boolean d;
  }
  
  public static class p extends ViewGroup.MarginLayoutParams {
    RecyclerView.d0 a;
    
    final Rect b = new Rect();
    
    boolean c = true;
    
    boolean d = false;
    
    public p(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public p(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public p(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public p(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public p(p param1p) {
      super((ViewGroup.LayoutParams)param1p);
    }
    
    public int a() {
      return this.a.m();
    }
    
    public boolean b() {
      return this.a.y();
    }
    
    public boolean c() {
      return this.a.v();
    }
    
    public boolean d() {
      return this.a.t();
    }
  }
  
  public static interface q {
    void a(View param1View);
    
    void b(View param1View);
  }
  
  public static abstract class r {
    public abstract boolean a(int param1Int1, int param1Int2);
  }
  
  public static interface s {
    boolean a(RecyclerView param1RecyclerView, MotionEvent param1MotionEvent);
    
    void b(RecyclerView param1RecyclerView, MotionEvent param1MotionEvent);
    
    void c(boolean param1Boolean);
  }
  
  public static abstract class t {
    public void a(RecyclerView param1RecyclerView, int param1Int) {}
    
    public void b(RecyclerView param1RecyclerView, int param1Int1, int param1Int2) {}
  }
  
  public static class u {
    SparseArray<a> a = new SparseArray();
    
    private int b = 0;
    
    private a g(int param1Int) {
      a a2 = (a)this.a.get(param1Int);
      a a1 = a2;
      if (a2 == null) {
        a1 = new a();
        this.a.put(param1Int, a1);
      } 
      return a1;
    }
    
    void a() {
      this.b++;
    }
    
    public void b() {
      for (int i = 0; i < this.a.size(); i++)
        ((a)this.a.valueAt(i)).a.clear(); 
    }
    
    void c() {
      this.b--;
    }
    
    void d(int param1Int, long param1Long) {
      a a = g(param1Int);
      a.d = j(a.d, param1Long);
    }
    
    void e(int param1Int, long param1Long) {
      a a = g(param1Int);
      a.c = j(a.c, param1Long);
    }
    
    public RecyclerView.d0 f(int param1Int) {
      a a = (a)this.a.get(param1Int);
      if (a != null && !a.a.isEmpty()) {
        ArrayList<RecyclerView.d0> arrayList = a.a;
        for (param1Int = arrayList.size() - 1; param1Int >= 0; param1Int--) {
          if (!((RecyclerView.d0)arrayList.get(param1Int)).r())
            return arrayList.remove(param1Int); 
        } 
      } 
      return null;
    }
    
    void h(RecyclerView.g param1g1, RecyclerView.g param1g2, boolean param1Boolean) {
      if (param1g1 != null)
        c(); 
      if (!param1Boolean && this.b == 0)
        b(); 
      if (param1g2 != null)
        a(); 
    }
    
    public void i(RecyclerView.d0 param1d0) {
      int i = param1d0.l();
      ArrayList<RecyclerView.d0> arrayList = (g(i)).a;
      if (((a)this.a.get(i)).b <= arrayList.size())
        return; 
      param1d0.D();
      arrayList.add(param1d0);
    }
    
    long j(long param1Long1, long param1Long2) {
      return (param1Long1 == 0L) ? param1Long2 : (param1Long1 / 4L * 3L + param1Long2 / 4L);
    }
    
    boolean k(int param1Int, long param1Long1, long param1Long2) {
      long l = (g(param1Int)).d;
      return (l == 0L || param1Long1 + l < param1Long2);
    }
    
    boolean l(int param1Int, long param1Long1, long param1Long2) {
      long l = (g(param1Int)).c;
      return (l == 0L || param1Long1 + l < param1Long2);
    }
    
    static class a {
      final ArrayList<RecyclerView.d0> a = new ArrayList<RecyclerView.d0>();
      
      int b = 5;
      
      long c = 0L;
      
      long d = 0L;
    }
  }
  
  static class a {
    final ArrayList<RecyclerView.d0> a = new ArrayList<RecyclerView.d0>();
    
    int b = 5;
    
    long c = 0L;
    
    long d = 0L;
  }
  
  public final class v {
    final ArrayList<RecyclerView.d0> a;
    
    ArrayList<RecyclerView.d0> b;
    
    final ArrayList<RecyclerView.d0> c;
    
    private final List<RecyclerView.d0> d;
    
    private int e;
    
    int f;
    
    RecyclerView.u g;
    
    public v(RecyclerView this$0) {
      ArrayList<RecyclerView.d0> arrayList = new ArrayList();
      this.a = arrayList;
      this.b = null;
      this.c = new ArrayList<RecyclerView.d0>();
      this.d = Collections.unmodifiableList(arrayList);
      this.e = 2;
      this.f = 2;
    }
    
    private boolean H(RecyclerView.d0 param1d0, int param1Int1, int param1Int2, long param1Long) {
      param1d0.r = this.h;
      int i = param1d0.l();
      long l = this.h.getNanoTime();
      if (param1Long != Long.MAX_VALUE && !this.g.k(i, l, param1Long))
        return false; 
      this.h.q.a(param1d0, param1Int1);
      param1Long = this.h.getNanoTime();
      this.g.d(param1d0.l(), param1Long - l);
      b(param1d0);
      if (this.h.m0.e())
        param1d0.g = param1Int2; 
      return true;
    }
    
    private void b(RecyclerView.d0 param1d0) {
      if (this.h.s0()) {
        View view = param1d0.a;
        if (androidx.core.view.w.z(view) == 0)
          androidx.core.view.w.y0(view, 1); 
        k k = this.h.t0;
        if (k == null)
          return; 
        androidx.core.view.a a = k.n();
        if (a instanceof k.a)
          ((k.a)a).o(view); 
        androidx.core.view.w.o0(view, a);
      } 
    }
    
    private void q(ViewGroup param1ViewGroup, boolean param1Boolean) {
      int i;
      for (i = param1ViewGroup.getChildCount() - 1; i >= 0; i--) {
        View view = param1ViewGroup.getChildAt(i);
        if (view instanceof ViewGroup)
          q((ViewGroup)view, true); 
      } 
      if (!param1Boolean)
        return; 
      if (param1ViewGroup.getVisibility() == 4) {
        param1ViewGroup.setVisibility(0);
        param1ViewGroup.setVisibility(4);
        return;
      } 
      i = param1ViewGroup.getVisibility();
      param1ViewGroup.setVisibility(4);
      param1ViewGroup.setVisibility(i);
    }
    
    private void r(RecyclerView.d0 param1d0) {
      View view = param1d0.a;
      if (view instanceof ViewGroup)
        q((ViewGroup)view, false); 
    }
    
    void A(int param1Int) {
      a(this.c.get(param1Int), true);
      this.c.remove(param1Int);
    }
    
    public void B(View param1View) {
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (d0.x())
        this.h.removeDetachedView(param1View, false); 
      if (d0.w()) {
        d0.K();
      } else if (d0.L()) {
        d0.e();
      } 
      C(d0);
      if (this.h.R != null && !d0.u())
        this.h.R.j(d0); 
    }
    
    void C(RecyclerView.d0 param1d0) {
      StringBuilder stringBuilder1;
      boolean bool2 = param1d0.w();
      boolean bool1 = false;
      int i = 0;
      boolean bool = true;
      if (bool2 || param1d0.a.getParent() != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scrapped or attached views may not be recycled. isScrap:");
        stringBuilder.append(param1d0.w());
        stringBuilder.append(" isAttached:");
        if (param1d0.a.getParent() != null)
          bool1 = true; 
        stringBuilder.append(bool1);
        stringBuilder.append(this.h.P());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      if (!param1d0.x()) {
        if (!param1d0.J()) {
          int j;
          bool1 = param1d0.h();
          RecyclerView.g<RecyclerView.d0> g = this.h.q;
          if (g != null && bool1 && g.n(param1d0)) {
            j = 1;
          } else {
            j = 0;
          } 
          if (j || param1d0.u()) {
            if (this.f > 0 && !param1d0.p(526)) {
              i = this.c.size();
              j = i;
              if (i >= this.f) {
                j = i;
                if (i > 0) {
                  A(0);
                  j = i - 1;
                } 
              } 
              i = j;
              if (RecyclerView.H0) {
                i = j;
                if (j > 0) {
                  i = j;
                  if (!this.h.l0.d(param1d0.c)) {
                    while (--j >= 0) {
                      i = ((RecyclerView.d0)this.c.get(j)).c;
                      if (!this.h.l0.d(i))
                        break; 
                      j--;
                    } 
                    i = j + 1;
                  } 
                } 
              } 
              this.c.add(i, param1d0);
              j = 1;
            } else {
              j = 0;
            } 
            if (j == 0) {
              a(param1d0, true);
              i = bool;
            } else {
              i = 0;
            } 
          } else {
            bool = false;
            j = i;
            i = bool;
          } 
          this.h.k.q(param1d0);
          if (j == 0 && i == 0 && bool1)
            param1d0.r = null; 
          return;
        } 
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.");
        stringBuilder1.append(this.h.P());
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
      stringBuilder2.append(stringBuilder1);
      stringBuilder2.append(this.h.P());
      throw new IllegalArgumentException(stringBuilder2.toString());
    }
    
    void D(View param1View) {
      StringBuilder stringBuilder;
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      if (d0.p(12) || !d0.y() || this.h.p(d0)) {
        if (!d0.t() || d0.v() || this.h.q.g()) {
          d0.H(this, false);
          this.a.add(d0);
          return;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.");
        stringBuilder.append(this.h.P());
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      if (this.b == null)
        this.b = new ArrayList<RecyclerView.d0>(); 
      stringBuilder.H(this, true);
      this.b.add(stringBuilder);
    }
    
    void E(RecyclerView.u param1u) {
      RecyclerView.u u1 = this.g;
      if (u1 != null)
        u1.c(); 
      this.g = param1u;
      if (param1u != null && this.h.getAdapter() != null)
        this.g.a(); 
    }
    
    void F(RecyclerView.b0 param1b0) {}
    
    public void G(int param1Int) {
      this.e = param1Int;
      K();
    }
    
    RecyclerView.d0 I(int param1Int, boolean param1Boolean, long param1Long) {
      // Byte code:
      //   0: iload_1
      //   1: iflt -> 888
      //   4: iload_1
      //   5: aload_0
      //   6: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   9: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
      //   12: invokevirtual b : ()I
      //   15: if_icmpge -> 888
      //   18: aload_0
      //   19: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   22: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
      //   25: invokevirtual e : ()Z
      //   28: istore #10
      //   30: iconst_1
      //   31: istore #9
      //   33: iload #10
      //   35: ifeq -> 60
      //   38: aload_0
      //   39: iload_1
      //   40: invokevirtual h : (I)Landroidx/recyclerview/widget/RecyclerView$d0;
      //   43: astore #16
      //   45: aload #16
      //   47: astore #15
      //   49: aload #16
      //   51: ifnull -> 63
      //   54: iconst_1
      //   55: istore #6
      //   57: goto -> 70
      //   60: aconst_null
      //   61: astore #15
      //   63: iconst_0
      //   64: istore #6
      //   66: aload #15
      //   68: astore #16
      //   70: aload #16
      //   72: astore #15
      //   74: iload #6
      //   76: istore #5
      //   78: aload #16
      //   80: ifnonnull -> 188
      //   83: aload_0
      //   84: iload_1
      //   85: iload_2
      //   86: invokevirtual m : (IZ)Landroidx/recyclerview/widget/RecyclerView$d0;
      //   89: astore #16
      //   91: aload #16
      //   93: astore #15
      //   95: iload #6
      //   97: istore #5
      //   99: aload #16
      //   101: ifnull -> 188
      //   104: aload_0
      //   105: aload #16
      //   107: invokevirtual L : (Landroidx/recyclerview/widget/RecyclerView$d0;)Z
      //   110: ifne -> 181
      //   113: iload_2
      //   114: ifne -> 171
      //   117: aload #16
      //   119: iconst_4
      //   120: invokevirtual b : (I)V
      //   123: aload #16
      //   125: invokevirtual w : ()Z
      //   128: ifeq -> 152
      //   131: aload_0
      //   132: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   135: aload #16
      //   137: getfield a : Landroid/view/View;
      //   140: iconst_0
      //   141: invokevirtual removeDetachedView : (Landroid/view/View;Z)V
      //   144: aload #16
      //   146: invokevirtual K : ()V
      //   149: goto -> 165
      //   152: aload #16
      //   154: invokevirtual L : ()Z
      //   157: ifeq -> 165
      //   160: aload #16
      //   162: invokevirtual e : ()V
      //   165: aload_0
      //   166: aload #16
      //   168: invokevirtual C : (Landroidx/recyclerview/widget/RecyclerView$d0;)V
      //   171: aconst_null
      //   172: astore #15
      //   174: iload #6
      //   176: istore #5
      //   178: goto -> 188
      //   181: iconst_1
      //   182: istore #5
      //   184: aload #16
      //   186: astore #15
      //   188: aload #15
      //   190: astore #17
      //   192: iload #5
      //   194: istore #7
      //   196: aload #15
      //   198: ifnonnull -> 576
      //   201: aload_0
      //   202: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   205: getfield i : Landroidx/recyclerview/widget/a;
      //   208: iload_1
      //   209: invokevirtual m : (I)I
      //   212: istore #7
      //   214: iload #7
      //   216: iflt -> 483
      //   219: iload #7
      //   221: aload_0
      //   222: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   225: getfield q : Landroidx/recyclerview/widget/RecyclerView$g;
      //   228: invokevirtual c : ()I
      //   231: if_icmpge -> 483
      //   234: aload_0
      //   235: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   238: getfield q : Landroidx/recyclerview/widget/RecyclerView$g;
      //   241: iload #7
      //   243: invokevirtual e : (I)I
      //   246: istore #8
      //   248: iload #5
      //   250: istore #6
      //   252: aload_0
      //   253: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   256: getfield q : Landroidx/recyclerview/widget/RecyclerView$g;
      //   259: invokevirtual g : ()Z
      //   262: ifeq -> 313
      //   265: aload_0
      //   266: aload_0
      //   267: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   270: getfield q : Landroidx/recyclerview/widget/RecyclerView$g;
      //   273: iload #7
      //   275: invokevirtual d : (I)J
      //   278: iload #8
      //   280: iload_2
      //   281: invokevirtual l : (JIZ)Landroidx/recyclerview/widget/RecyclerView$d0;
      //   284: astore #16
      //   286: aload #16
      //   288: astore #15
      //   290: iload #5
      //   292: istore #6
      //   294: aload #16
      //   296: ifnull -> 313
      //   299: aload #16
      //   301: iload #7
      //   303: putfield c : I
      //   306: iconst_1
      //   307: istore #6
      //   309: aload #16
      //   311: astore #15
      //   313: aload #15
      //   315: astore #16
      //   317: aload #15
      //   319: ifnonnull -> 355
      //   322: aload_0
      //   323: invokevirtual i : ()Landroidx/recyclerview/widget/RecyclerView$u;
      //   326: iload #8
      //   328: invokevirtual f : (I)Landroidx/recyclerview/widget/RecyclerView$d0;
      //   331: astore #16
      //   333: aload #16
      //   335: ifnull -> 355
      //   338: aload #16
      //   340: invokevirtual D : ()V
      //   343: getstatic androidx/recyclerview/widget/RecyclerView.E0 : Z
      //   346: ifeq -> 355
      //   349: aload_0
      //   350: aload #16
      //   352: invokespecial r : (Landroidx/recyclerview/widget/RecyclerView$d0;)V
      //   355: aload #16
      //   357: astore #17
      //   359: iload #6
      //   361: istore #7
      //   363: aload #16
      //   365: ifnonnull -> 576
      //   368: aload_0
      //   369: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   372: invokevirtual getNanoTime : ()J
      //   375: lstore #11
      //   377: lload_3
      //   378: ldc2_w 9223372036854775807
      //   381: lcmp
      //   382: ifeq -> 402
      //   385: aload_0
      //   386: getfield g : Landroidx/recyclerview/widget/RecyclerView$u;
      //   389: iload #8
      //   391: lload #11
      //   393: lload_3
      //   394: invokevirtual l : (IJJ)Z
      //   397: ifne -> 402
      //   400: aconst_null
      //   401: areturn
      //   402: aload_0
      //   403: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   406: astore #15
      //   408: aload #15
      //   410: getfield q : Landroidx/recyclerview/widget/RecyclerView$g;
      //   413: aload #15
      //   415: iload #8
      //   417: invokevirtual b : (Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$d0;
      //   420: astore #16
      //   422: getstatic androidx/recyclerview/widget/RecyclerView.H0 : Z
      //   425: ifeq -> 457
      //   428: aload #16
      //   430: getfield a : Landroid/view/View;
      //   433: invokestatic V : (Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView;
      //   436: astore #15
      //   438: aload #15
      //   440: ifnull -> 457
      //   443: aload #16
      //   445: new java/lang/ref/WeakReference
      //   448: dup
      //   449: aload #15
      //   451: invokespecial <init> : (Ljava/lang/Object;)V
      //   454: putfield b : Ljava/lang/ref/WeakReference;
      //   457: aload_0
      //   458: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   461: invokevirtual getNanoTime : ()J
      //   464: lstore #13
      //   466: aload_0
      //   467: getfield g : Landroidx/recyclerview/widget/RecyclerView$u;
      //   470: iload #8
      //   472: lload #13
      //   474: lload #11
      //   476: lsub
      //   477: invokevirtual e : (IJ)V
      //   480: goto -> 584
      //   483: new java/lang/StringBuilder
      //   486: dup
      //   487: invokespecial <init> : ()V
      //   490: astore #15
      //   492: aload #15
      //   494: ldc_w 'Inconsistency detected. Invalid item position '
      //   497: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   500: pop
      //   501: aload #15
      //   503: iload_1
      //   504: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   507: pop
      //   508: aload #15
      //   510: ldc_w '(offset:'
      //   513: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   516: pop
      //   517: aload #15
      //   519: iload #7
      //   521: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   524: pop
      //   525: aload #15
      //   527: ldc_w ').state:'
      //   530: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   533: pop
      //   534: aload #15
      //   536: aload_0
      //   537: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   540: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
      //   543: invokevirtual b : ()I
      //   546: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   549: pop
      //   550: aload #15
      //   552: aload_0
      //   553: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   556: invokevirtual P : ()Ljava/lang/String;
      //   559: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   562: pop
      //   563: new java/lang/IndexOutOfBoundsException
      //   566: dup
      //   567: aload #15
      //   569: invokevirtual toString : ()Ljava/lang/String;
      //   572: invokespecial <init> : (Ljava/lang/String;)V
      //   575: athrow
      //   576: aload #17
      //   578: astore #16
      //   580: iload #7
      //   582: istore #6
      //   584: iload #6
      //   586: ifeq -> 687
      //   589: aload_0
      //   590: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   593: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
      //   596: invokevirtual e : ()Z
      //   599: ifne -> 687
      //   602: aload #16
      //   604: sipush #8192
      //   607: invokevirtual p : (I)Z
      //   610: ifeq -> 687
      //   613: aload #16
      //   615: iconst_0
      //   616: sipush #8192
      //   619: invokevirtual F : (II)V
      //   622: aload_0
      //   623: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   626: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
      //   629: getfield k : Z
      //   632: ifeq -> 687
      //   635: aload #16
      //   637: invokestatic e : (Landroidx/recyclerview/widget/RecyclerView$d0;)I
      //   640: istore #5
      //   642: aload_0
      //   643: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   646: astore #15
      //   648: aload #15
      //   650: getfield R : Landroidx/recyclerview/widget/RecyclerView$l;
      //   653: aload #15
      //   655: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
      //   658: aload #16
      //   660: iload #5
      //   662: sipush #4096
      //   665: ior
      //   666: aload #16
      //   668: invokevirtual o : ()Ljava/util/List;
      //   671: invokevirtual t : (Landroidx/recyclerview/widget/RecyclerView$a0;Landroidx/recyclerview/widget/RecyclerView$d0;ILjava/util/List;)Landroidx/recyclerview/widget/RecyclerView$l$c;
      //   674: astore #15
      //   676: aload_0
      //   677: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   680: aload #16
      //   682: aload #15
      //   684: invokevirtual Q0 : (Landroidx/recyclerview/widget/RecyclerView$d0;Landroidx/recyclerview/widget/RecyclerView$l$c;)V
      //   687: aload_0
      //   688: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   691: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
      //   694: invokevirtual e : ()Z
      //   697: ifeq -> 717
      //   700: aload #16
      //   702: invokevirtual s : ()Z
      //   705: ifeq -> 717
      //   708: aload #16
      //   710: iload_1
      //   711: putfield g : I
      //   714: goto -> 744
      //   717: aload #16
      //   719: invokevirtual s : ()Z
      //   722: ifeq -> 749
      //   725: aload #16
      //   727: invokevirtual z : ()Z
      //   730: ifne -> 749
      //   733: aload #16
      //   735: invokevirtual t : ()Z
      //   738: ifeq -> 744
      //   741: goto -> 749
      //   744: iconst_0
      //   745: istore_2
      //   746: goto -> 769
      //   749: aload_0
      //   750: aload #16
      //   752: aload_0
      //   753: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   756: getfield i : Landroidx/recyclerview/widget/a;
      //   759: iload_1
      //   760: invokevirtual m : (I)I
      //   763: iload_1
      //   764: lload_3
      //   765: invokespecial H : (Landroidx/recyclerview/widget/RecyclerView$d0;IIJ)Z
      //   768: istore_2
      //   769: aload #16
      //   771: getfield a : Landroid/view/View;
      //   774: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   777: astore #15
      //   779: aload #15
      //   781: ifnonnull -> 809
      //   784: aload_0
      //   785: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   788: invokevirtual generateDefaultLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   791: checkcast androidx/recyclerview/widget/RecyclerView$p
      //   794: astore #15
      //   796: aload #16
      //   798: getfield a : Landroid/view/View;
      //   801: aload #15
      //   803: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
      //   806: goto -> 855
      //   809: aload_0
      //   810: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   813: aload #15
      //   815: invokevirtual checkLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)Z
      //   818: ifne -> 848
      //   821: aload_0
      //   822: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   825: aload #15
      //   827: invokevirtual generateLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
      //   830: checkcast androidx/recyclerview/widget/RecyclerView$p
      //   833: astore #15
      //   835: aload #16
      //   837: getfield a : Landroid/view/View;
      //   840: aload #15
      //   842: invokevirtual setLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)V
      //   845: goto -> 855
      //   848: aload #15
      //   850: checkcast androidx/recyclerview/widget/RecyclerView$p
      //   853: astore #15
      //   855: aload #15
      //   857: aload #16
      //   859: putfield a : Landroidx/recyclerview/widget/RecyclerView$d0;
      //   862: iload #6
      //   864: ifeq -> 877
      //   867: iload_2
      //   868: ifeq -> 877
      //   871: iload #9
      //   873: istore_2
      //   874: goto -> 879
      //   877: iconst_0
      //   878: istore_2
      //   879: aload #15
      //   881: iload_2
      //   882: putfield d : Z
      //   885: aload #16
      //   887: areturn
      //   888: new java/lang/StringBuilder
      //   891: dup
      //   892: invokespecial <init> : ()V
      //   895: astore #15
      //   897: aload #15
      //   899: ldc_w 'Invalid item position '
      //   902: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   905: pop
      //   906: aload #15
      //   908: iload_1
      //   909: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   912: pop
      //   913: aload #15
      //   915: ldc_w '('
      //   918: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   921: pop
      //   922: aload #15
      //   924: iload_1
      //   925: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   928: pop
      //   929: aload #15
      //   931: ldc_w '). Item count:'
      //   934: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   937: pop
      //   938: aload #15
      //   940: aload_0
      //   941: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   944: getfield m0 : Landroidx/recyclerview/widget/RecyclerView$a0;
      //   947: invokevirtual b : ()I
      //   950: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   953: pop
      //   954: aload #15
      //   956: aload_0
      //   957: getfield h : Landroidx/recyclerview/widget/RecyclerView;
      //   960: invokevirtual P : ()Ljava/lang/String;
      //   963: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   966: pop
      //   967: new java/lang/IndexOutOfBoundsException
      //   970: dup
      //   971: aload #15
      //   973: invokevirtual toString : ()Ljava/lang/String;
      //   976: invokespecial <init> : (Ljava/lang/String;)V
      //   979: athrow
    }
    
    void J(RecyclerView.d0 param1d0) {
      if (param1d0.o) {
        this.b.remove(param1d0);
      } else {
        this.a.remove(param1d0);
      } 
      param1d0.n = null;
      param1d0.o = false;
      param1d0.e();
    }
    
    void K() {
      RecyclerView.o o = this.h.r;
      if (o != null) {
        i = o.m;
      } else {
        i = 0;
      } 
      this.f = this.e + i;
      for (int i = this.c.size() - 1; i >= 0 && this.c.size() > this.f; i--)
        A(i); 
    }
    
    boolean L(RecyclerView.d0 param1d0) {
      if (param1d0.v())
        return this.h.m0.e(); 
      int i = param1d0.c;
      if (i >= 0 && i < this.h.q.c()) {
        boolean bool1 = this.h.m0.e();
        boolean bool = false;
        if (!bool1 && this.h.q.e(param1d0.c) != param1d0.l())
          return false; 
        if (this.h.q.g()) {
          if (param1d0.k() == this.h.q.d(param1d0.c))
            bool = true; 
          return bool;
        } 
        return true;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Inconsistency detected. Invalid view holder adapter position");
      stringBuilder.append(param1d0);
      stringBuilder.append(this.h.P());
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    void M(int param1Int1, int param1Int2) {
      for (int i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (d0 != null) {
          int j = d0.c;
          if (j >= param1Int1 && j < param1Int2 + param1Int1) {
            d0.b(2);
            A(i);
          } 
        } 
      } 
    }
    
    void a(RecyclerView.d0 param1d0, boolean param1Boolean) {
      RecyclerView.r(param1d0);
      View view = param1d0.a;
      k k = this.h.t0;
      if (k != null) {
        androidx.core.view.a a = k.n();
        if (a instanceof k.a) {
          a = ((k.a)a).n(view);
        } else {
          a = null;
        } 
        androidx.core.view.w.o0(view, a);
      } 
      if (param1Boolean)
        g(param1d0); 
      param1d0.r = null;
      i().i(param1d0);
    }
    
    public void c() {
      this.a.clear();
      z();
    }
    
    void d() {
      int j = this.c.size();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++)
        ((RecyclerView.d0)this.c.get(i)).c(); 
      j = this.a.size();
      for (i = 0; i < j; i++)
        ((RecyclerView.d0)this.a.get(i)).c(); 
      ArrayList<RecyclerView.d0> arrayList = this.b;
      if (arrayList != null) {
        j = arrayList.size();
        for (i = bool; i < j; i++)
          ((RecyclerView.d0)this.b.get(i)).c(); 
      } 
    }
    
    void e() {
      this.a.clear();
      ArrayList<RecyclerView.d0> arrayList = this.b;
      if (arrayList != null)
        arrayList.clear(); 
    }
    
    public int f(int param1Int) {
      if (param1Int >= 0 && param1Int < this.h.m0.b())
        return !this.h.m0.e() ? param1Int : this.h.i.m(param1Int); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("invalid position ");
      stringBuilder.append(param1Int);
      stringBuilder.append(". State item count is ");
      stringBuilder.append(this.h.m0.b());
      stringBuilder.append(this.h.P());
      throw new IndexOutOfBoundsException(stringBuilder.toString());
    }
    
    void g(RecyclerView.d0 param1d0) {
      RecyclerView.w w = this.h.s;
      if (w != null)
        w.a(param1d0); 
      RecyclerView.g<RecyclerView.d0> g = this.h.q;
      if (g != null)
        g.q(param1d0); 
      RecyclerView recyclerView = this.h;
      if (recyclerView.m0 != null)
        recyclerView.k.q(param1d0); 
    }
    
    RecyclerView.d0 h(int param1Int) {
      ArrayList<RecyclerView.d0> arrayList = this.b;
      if (arrayList != null) {
        int j = arrayList.size();
        if (j == 0)
          return null; 
        boolean bool = false;
        for (int i = 0; i < j; i++) {
          RecyclerView.d0 d0 = this.b.get(i);
          if (!d0.L() && d0.m() == param1Int) {
            d0.b(32);
            return d0;
          } 
        } 
        if (this.h.q.g()) {
          param1Int = this.h.i.m(param1Int);
          if (param1Int > 0 && param1Int < this.h.q.c()) {
            long l = this.h.q.d(param1Int);
            for (param1Int = bool; param1Int < j; param1Int++) {
              RecyclerView.d0 d0 = this.b.get(param1Int);
              if (!d0.L() && d0.k() == l) {
                d0.b(32);
                return d0;
              } 
            } 
          } 
        } 
      } 
      return null;
    }
    
    RecyclerView.u i() {
      if (this.g == null)
        this.g = new RecyclerView.u(); 
      return this.g;
    }
    
    int j() {
      return this.a.size();
    }
    
    public List<RecyclerView.d0> k() {
      return this.d;
    }
    
    RecyclerView.d0 l(long param1Long, int param1Int, boolean param1Boolean) {
      int i;
      for (i = this.a.size() - 1; i >= 0; i--) {
        RecyclerView.d0 d0 = this.a.get(i);
        if (d0.k() == param1Long && !d0.L()) {
          if (param1Int == d0.l()) {
            d0.b(32);
            if (d0.v() && !this.h.m0.e())
              d0.F(2, 14); 
            return d0;
          } 
          if (!param1Boolean) {
            this.a.remove(i);
            this.h.removeDetachedView(d0.a, false);
            y(d0.a);
          } 
        } 
      } 
      for (i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (d0.k() == param1Long && !d0.r()) {
          if (param1Int == d0.l()) {
            if (!param1Boolean)
              this.c.remove(i); 
            return d0;
          } 
          if (!param1Boolean) {
            A(i);
            return null;
          } 
        } 
      } 
      return null;
    }
    
    RecyclerView.d0 m(int param1Int, boolean param1Boolean) {
      int j = this.a.size();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        RecyclerView.d0 d0 = this.a.get(i);
        if (!d0.L() && d0.m() == param1Int && !d0.t() && (this.h.m0.h || !d0.v())) {
          d0.b(32);
          return d0;
        } 
      } 
      if (!param1Boolean) {
        View view = this.h.j.e(param1Int);
        if (view != null) {
          RecyclerView.d0 d0 = RecyclerView.f0(view);
          this.h.j.s(view);
          param1Int = this.h.j.m(view);
          if (param1Int != -1) {
            this.h.j.d(param1Int);
            D(view);
            d0.b(8224);
            return d0;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("layout index should not be -1 after unhiding a view:");
          stringBuilder.append(d0);
          stringBuilder.append(this.h.P());
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
      j = this.c.size();
      for (i = bool; i < j; i++) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (!d0.t() && d0.m() == param1Int && !d0.r()) {
          if (!param1Boolean)
            this.c.remove(i); 
          return d0;
        } 
      } 
      return null;
    }
    
    View n(int param1Int) {
      return ((RecyclerView.d0)this.a.get(param1Int)).a;
    }
    
    public View o(int param1Int) {
      return p(param1Int, false);
    }
    
    View p(int param1Int, boolean param1Boolean) {
      return (I(param1Int, param1Boolean, Long.MAX_VALUE)).a;
    }
    
    void s() {
      int j = this.c.size();
      for (int i = 0; i < j; i++) {
        RecyclerView.p p = (RecyclerView.p)((RecyclerView.d0)this.c.get(i)).a.getLayoutParams();
        if (p != null)
          p.c = true; 
      } 
    }
    
    void t() {
      int j = this.c.size();
      for (int i = 0; i < j; i++) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (d0 != null) {
          d0.b(6);
          d0.a(null);
        } 
      } 
      RecyclerView.g g = this.h.q;
      if (g == null || !g.g())
        z(); 
    }
    
    void u(int param1Int1, int param1Int2) {
      int j = this.c.size();
      for (int i = 0; i < j; i++) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (d0 != null && d0.c >= param1Int1)
          d0.A(param1Int2, true); 
      } 
    }
    
    void v(int param1Int1, int param1Int2) {
      boolean bool;
      int i;
      int j;
      if (param1Int1 < param1Int2) {
        bool = true;
        i = param1Int1;
        j = param1Int2;
      } else {
        bool = true;
        j = param1Int1;
        i = param1Int2;
      } 
      int m = this.c.size();
      int k;
      for (k = 0; k < m; k++) {
        RecyclerView.d0 d0 = this.c.get(k);
        if (d0 != null) {
          int n = d0.c;
          if (n >= i && n <= j)
            if (n == param1Int1) {
              d0.A(param1Int2 - param1Int1, false);
            } else {
              d0.A(bool, false);
            }  
        } 
      } 
    }
    
    void w(int param1Int1, int param1Int2, boolean param1Boolean) {
      int i;
      for (i = this.c.size() - 1; i >= 0; i--) {
        RecyclerView.d0 d0 = this.c.get(i);
        if (d0 != null) {
          int j = d0.c;
          if (j >= param1Int1 + param1Int2) {
            d0.A(-param1Int2, param1Boolean);
          } else if (j >= param1Int1) {
            d0.b(8);
            A(i);
          } 
        } 
      } 
    }
    
    void x(RecyclerView.g param1g1, RecyclerView.g param1g2, boolean param1Boolean) {
      c();
      i().h(param1g1, param1g2, param1Boolean);
    }
    
    void y(View param1View) {
      RecyclerView.d0 d0 = RecyclerView.f0(param1View);
      d0.n = null;
      d0.o = false;
      d0.e();
      C(d0);
    }
    
    void z() {
      for (int i = this.c.size() - 1; i >= 0; i--)
        A(i); 
      this.c.clear();
      if (RecyclerView.H0)
        this.h.l0.b(); 
    }
  }
  
  public static interface w {
    void a(RecyclerView.d0 param1d0);
  }
  
  private class x extends i {
    x(RecyclerView this$0) {}
    
    public void a() {
      this.a.o(null);
      RecyclerView recyclerView = this.a;
      recyclerView.m0.g = true;
      recyclerView.O0(true);
      if (!this.a.i.p())
        this.a.requestLayout(); 
    }
  }
  
  public static class y extends p0.a {
    public static final Parcelable.Creator<y> CREATOR = (Parcelable.Creator<y>)new a();
    
    Parcelable h;
    
    y(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      if (param1ClassLoader == null)
        param1ClassLoader = RecyclerView.o.class.getClassLoader(); 
      this.h = param1Parcel.readParcelable(param1ClassLoader);
    }
    
    y(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    void c(y param1y) {
      this.h = param1y.h;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeParcelable(this.h, 0);
    }
    
    static final class a implements Parcelable.ClassLoaderCreator<y> {
      public RecyclerView.y a(Parcel param2Parcel) {
        return new RecyclerView.y(param2Parcel, null);
      }
      
      public RecyclerView.y b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new RecyclerView.y(param2Parcel, param2ClassLoader);
      }
      
      public RecyclerView.y[] c(int param2Int) {
        return new RecyclerView.y[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.ClassLoaderCreator<y> {
    public RecyclerView.y a(Parcel param1Parcel) {
      return new RecyclerView.y(param1Parcel, null);
    }
    
    public RecyclerView.y b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new RecyclerView.y(param1Parcel, param1ClassLoader);
    }
    
    public RecyclerView.y[] c(int param1Int) {
      return new RecyclerView.y[param1Int];
    }
  }
  
  public static abstract class z {
    private int a = -1;
    
    private RecyclerView b;
    
    private RecyclerView.o c;
    
    private boolean d;
    
    private boolean e;
    
    private View f;
    
    private final a g = new a(0, 0);
    
    private boolean h;
    
    public PointF a(int param1Int) {
      RecyclerView.o o1 = e();
      if (o1 instanceof b)
        return ((b)o1).a(param1Int); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("You should override computeScrollVectorForPosition when the LayoutManager does not implement ");
      stringBuilder.append(b.class.getCanonicalName());
      Log.w("RecyclerView", stringBuilder.toString());
      return null;
    }
    
    public View b(int param1Int) {
      return this.b.r.C(param1Int);
    }
    
    public int c() {
      return this.b.r.J();
    }
    
    public int d(View param1View) {
      return this.b.d0(param1View);
    }
    
    public RecyclerView.o e() {
      return this.c;
    }
    
    public int f() {
      return this.a;
    }
    
    public boolean g() {
      return this.d;
    }
    
    public boolean h() {
      return this.e;
    }
    
    protected void i(PointF param1PointF) {
      float f1 = param1PointF.x;
      float f2 = param1PointF.y;
      f1 = (float)Math.sqrt((f1 * f1 + f2 * f2));
      param1PointF.x /= f1;
      param1PointF.y /= f1;
    }
    
    void j(int param1Int1, int param1Int2) {
      RecyclerView recyclerView = this.b;
      if (this.a == -1 || recyclerView == null)
        r(); 
      if (this.d && this.f == null && this.c != null) {
        PointF pointF = a(this.a);
        if (pointF != null) {
          float f = pointF.x;
          if (f != 0.0F || pointF.y != 0.0F)
            recyclerView.f1((int)Math.signum(f), (int)Math.signum(pointF.y), null); 
        } 
      } 
      this.d = false;
      View view = this.f;
      if (view != null)
        if (d(view) == this.a) {
          o(this.f, recyclerView.m0, this.g);
          this.g.c(recyclerView);
          r();
        } else {
          Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
          this.f = null;
        }  
      if (this.e) {
        l(param1Int1, param1Int2, recyclerView.m0, this.g);
        boolean bool = this.g.a();
        this.g.c(recyclerView);
        if (bool && this.e) {
          this.d = true;
          recyclerView.j0.e();
        } 
      } 
    }
    
    protected void k(View param1View) {
      if (d(param1View) == f())
        this.f = param1View; 
    }
    
    protected abstract void l(int param1Int1, int param1Int2, RecyclerView.a0 param1a0, a param1a);
    
    protected abstract void m();
    
    protected abstract void n();
    
    protected abstract void o(View param1View, RecyclerView.a0 param1a0, a param1a);
    
    public void p(int param1Int) {
      this.a = param1Int;
    }
    
    void q(RecyclerView param1RecyclerView, RecyclerView.o param1o) {
      param1RecyclerView.j0.g();
      if (this.h) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("An instance of ");
        stringBuilder.append(getClass().getSimpleName());
        stringBuilder.append(" was started more than once. Each instance of");
        stringBuilder.append(getClass().getSimpleName());
        stringBuilder.append(" is intended to only be used once. You should create a new instance for each use.");
        Log.w("RecyclerView", stringBuilder.toString());
      } 
      this.b = param1RecyclerView;
      this.c = param1o;
      int i = this.a;
      if (i != -1) {
        param1RecyclerView.m0.a = i;
        this.e = true;
        this.d = true;
        this.f = b(f());
        m();
        this.b.j0.e();
        this.h = true;
        return;
      } 
      throw new IllegalArgumentException("Invalid target position");
    }
    
    protected final void r() {
      if (!this.e)
        return; 
      this.e = false;
      n();
      this.b.m0.a = -1;
      this.f = null;
      this.a = -1;
      this.d = false;
      this.c.f1(this);
      this.c = null;
      this.b = null;
    }
    
    public static class a {
      private int a;
      
      private int b;
      
      private int c;
      
      private int d = -1;
      
      private Interpolator e;
      
      private boolean f = false;
      
      private int g = 0;
      
      public a(int param2Int1, int param2Int2) {
        this(param2Int1, param2Int2, -2147483648, null);
      }
      
      public a(int param2Int1, int param2Int2, int param2Int3, Interpolator param2Interpolator) {
        this.a = param2Int1;
        this.b = param2Int2;
        this.c = param2Int3;
        this.e = param2Interpolator;
      }
      
      private void e() {
        if (this.e == null || this.c >= 1) {
          if (this.c >= 1)
            return; 
          throw new IllegalStateException("Scroll duration must be a positive number");
        } 
        throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
      }
      
      boolean a() {
        return (this.d >= 0);
      }
      
      public void b(int param2Int) {
        this.d = param2Int;
      }
      
      void c(RecyclerView param2RecyclerView) {
        int i = this.d;
        if (i >= 0) {
          this.d = -1;
          param2RecyclerView.v0(i);
          this.f = false;
          return;
        } 
        if (this.f) {
          e();
          param2RecyclerView.j0.f(this.a, this.b, this.c, this.e);
          i = this.g + 1;
          this.g = i;
          if (i > 10)
            Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary"); 
          this.f = false;
          return;
        } 
        this.g = 0;
      }
      
      public void d(int param2Int1, int param2Int2, int param2Int3, Interpolator param2Interpolator) {
        this.a = param2Int1;
        this.b = param2Int2;
        this.c = param2Int3;
        this.e = param2Interpolator;
        this.f = true;
      }
    }
    
    public static interface b {
      PointF a(int param2Int);
    }
  }
  
  public static class a {
    private int a;
    
    private int b;
    
    private int c;
    
    private int d = -1;
    
    private Interpolator e;
    
    private boolean f = false;
    
    private int g = 0;
    
    public a(int param1Int1, int param1Int2) {
      this(param1Int1, param1Int2, -2147483648, null);
    }
    
    public a(int param1Int1, int param1Int2, int param1Int3, Interpolator param1Interpolator) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1Int3;
      this.e = param1Interpolator;
    }
    
    private void e() {
      if (this.e == null || this.c >= 1) {
        if (this.c >= 1)
          return; 
        throw new IllegalStateException("Scroll duration must be a positive number");
      } 
      throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
    }
    
    boolean a() {
      return (this.d >= 0);
    }
    
    public void b(int param1Int) {
      this.d = param1Int;
    }
    
    void c(RecyclerView param1RecyclerView) {
      int i = this.d;
      if (i >= 0) {
        this.d = -1;
        param1RecyclerView.v0(i);
        this.f = false;
        return;
      } 
      if (this.f) {
        e();
        param1RecyclerView.j0.f(this.a, this.b, this.c, this.e);
        i = this.g + 1;
        this.g = i;
        if (i > 10)
          Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary"); 
        this.f = false;
        return;
      } 
      this.g = 0;
    }
    
    public void d(int param1Int1, int param1Int2, int param1Int3, Interpolator param1Interpolator) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1Int3;
      this.e = param1Interpolator;
      this.f = true;
    }
  }
  
  public static interface b {
    PointF a(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\androidx\recyclerview\widget\RecyclerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */