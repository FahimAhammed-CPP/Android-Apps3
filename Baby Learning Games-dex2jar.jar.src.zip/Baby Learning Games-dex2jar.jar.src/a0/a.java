package a0;

public final class a {
  public static final int a = 2130968630;
  
  public static final int b = 2130969164;
  
  public static final int c = 2130969374;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */