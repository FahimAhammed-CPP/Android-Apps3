package a0;

public final class b {
  public static final int A = 2131296297;
  
  public static final int B = 2131296298;
  
  public static final int C = 2131296299;
  
  public static final int D = 2131296300;
  
  public static final int E = 2131296301;
  
  public static final int F = 2131296302;
  
  public static final int G = 2131296303;
  
  public static final int H = 2131296778;
  
  public static final int I = 2131296779;
  
  public static final int J = 2131296780;
  
  public static final int K = 2131296781;
  
  public static final int L = 2131296782;
  
  public static final int M = 2131296783;
  
  public static final int N = 2131296784;
  
  public static final int O = 2131296785;
  
  public static final int P = 2131296786;
  
  public static final int Q = 2131296788;
  
  public static final int R = 2131296789;
  
  public static final int S = 2131296790;
  
  public static final int a = 2131296271;
  
  public static final int b = 2131296272;
  
  public static final int c = 2131296273;
  
  public static final int d = 2131296274;
  
  public static final int e = 2131296275;
  
  public static final int f = 2131296276;
  
  public static final int g = 2131296277;
  
  public static final int h = 2131296278;
  
  public static final int i = 2131296279;
  
  public static final int j = 2131296280;
  
  public static final int k = 2131296281;
  
  public static final int l = 2131296282;
  
  public static final int m = 2131296283;
  
  public static final int n = 2131296284;
  
  public static final int o = 2131296285;
  
  public static final int p = 2131296286;
  
  public static final int q = 2131296287;
  
  public static final int r = 2131296288;
  
  public static final int s = 2131296289;
  
  public static final int t = 2131296290;
  
  public static final int u = 2131296291;
  
  public static final int v = 2131296292;
  
  public static final int w = 2131296293;
  
  public static final int x = 2131296294;
  
  public static final int y = 2131296295;
  
  public static final int z = 2131296296;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */