package a0;

public final class c {
  public static final int[] A;
  
  public static final int B = 0;
  
  public static final int C = 1;
  
  public static final int D = 2;
  
  public static final int E = 3;
  
  public static final int F = 4;
  
  public static final int G = 5;
  
  public static final int H = 6;
  
  public static final int I = 7;
  
  public static final int J = 8;
  
  public static final int K = 9;
  
  public static final int L = 10;
  
  public static final int M = 11;
  
  public static final int[] N;
  
  public static final int O = 0;
  
  public static final int P = 1;
  
  public static final int[] a = new int[] { 2130969453, 2130969498 };
  
  public static final int[] b = new int[] { 16843173, 16843551, 16844359, 2130968630, 2130969164 };
  
  public static final int c = 0;
  
  public static final int d = 1;
  
  public static final int e = 2;
  
  public static final int f = 3;
  
  public static final int g = 4;
  
  public static final int[] h = new int[] { 2130969058, 2130969059, 2130969060, 2130969061, 2130969062, 2130969063, 2130969064 };
  
  public static final int i = 0;
  
  public static final int j = 1;
  
  public static final int k = 2;
  
  public static final int l = 3;
  
  public static final int m = 4;
  
  public static final int n = 5;
  
  public static final int o = 6;
  
  public static final int[] p = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130969056, 2130969065, 2130969066, 2130969067, 2130969742 };
  
  public static final int q = 0;
  
  public static final int r = 1;
  
  public static final int s = 2;
  
  public static final int t = 3;
  
  public static final int u = 4;
  
  public static final int v = 5;
  
  public static final int w = 6;
  
  public static final int x = 7;
  
  public static final int y = 8;
  
  public static final int z = 9;
  
  static {
    A = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    N = new int[] { 16843173, 16844052 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */