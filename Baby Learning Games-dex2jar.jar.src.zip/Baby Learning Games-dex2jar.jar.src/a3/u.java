package a3;

final class u implements Runnable {
  u(y paramy) {}
  
  public final void run() {
    y.M(this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */