package a3;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.api.Status;

public interface l {
  @RecentlyNonNull
  Exception a(@RecentlyNonNull Status paramStatus);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */