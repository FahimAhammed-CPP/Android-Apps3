package a3;

import androidx.annotation.RecentlyNonNull;
import com.google.android.gms.common.api.Status;
import t3.i;
import z2.b;

public class n {
  public static <TResult> void a(@RecentlyNonNull Status paramStatus, TResult paramTResult, @RecentlyNonNull i<TResult> parami) {
    if (paramStatus.p()) {
      parami.c(paramTResult);
      return;
    } 
    parami.b((Exception)new b(paramStatus));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */