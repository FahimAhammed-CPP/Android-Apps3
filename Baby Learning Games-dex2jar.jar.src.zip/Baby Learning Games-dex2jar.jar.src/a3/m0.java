package a3;

import b3.i;
import com.google.android.gms.common.api.Scope;
import java.util.Set;
import y2.b;

public interface m0 {
  void a(i parami, Set<Scope> paramSet);
  
  void b(b paramb);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */