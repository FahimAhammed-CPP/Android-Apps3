package a3;

import android.util.Log;
import b3.c;
import b3.i;
import com.google.android.gms.common.api.Scope;
import java.util.Set;
import y2.b;
import z2.a;

final class b0 implements c.c, m0 {
  private final a.f a;
  
  private final b<?> b;
  
  private i c = null;
  
  private Set<Scope> d = null;
  
  private boolean e = false;
  
  public b0(e parame, a.f paramf, b<?> paramb) {
    this.a = paramf;
    this.b = paramb;
  }
  
  private final void h() {
    if (this.e) {
      i i1 = this.c;
      if (i1 != null)
        this.a.e(i1, this.d); 
    } 
  }
  
  public final void a(i parami, Set<Scope> paramSet) {
    if (parami == null || paramSet == null) {
      Log.wtf("GoogleApiManager", "Received null response from onSignInSuccess", new Exception());
      b(new b(4));
      return;
    } 
    this.c = parami;
    this.d = paramSet;
    h();
  }
  
  public final void b(b paramb) {
    y y = (y)e.g(this.f).get(this.b);
    if (y != null)
      y.o(paramb); 
  }
  
  public final void c(b paramb) {
    e.w(this.f).post(new a0(this, paramb));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */