package a3;

import b3.c;
import b3.e;
import b3.m;
import b3.p;
import b3.q;
import com.google.android.gms.common.api.Status;
import f3.a;
import t3.d;
import t3.h;
import y2.b;
import z2.b;

final class d0<T> implements d<T> {
  private final e a;
  
  private final int b;
  
  private final b<?> c;
  
  private final long d;
  
  d0(e parame, int paramInt, b<?> paramb, long paramLong, String paramString1, String paramString2) {
    this.a = parame;
    this.b = paramInt;
    this.c = paramb;
    this.d = paramLong;
  }
  
  static <T> d0<T> b(e parame, int paramInt, b<?> paramb) {
    boolean bool;
    long l;
    if (!parame.s())
      return null; 
    q q = p.b().a();
    if (q != null) {
      if (!q.n())
        return null; 
      boolean bool1 = q.o();
      y<?> y = parame.p(paramb);
      bool = bool1;
      if (y != null) {
        if (!(y.s() instanceof c))
          return null; 
        c<?> c = (c)y.s();
        bool = bool1;
        if (c.I()) {
          bool = bool1;
          if (!c.j()) {
            e e1 = c(y, c, paramInt);
            if (e1 == null)
              return null; 
            y.G();
            bool = e1.p();
          } 
        } 
      } 
    } else {
      bool = true;
    } 
    if (bool) {
      l = System.currentTimeMillis();
    } else {
      l = 0L;
    } 
    return new d0<T>(parame, paramInt, paramb, l, null, null);
  }
  
  private static e c(y<?> paramy, c<?> paramc, int paramInt) {
    e e1 = paramc.G();
    if (e1 != null && e1.o()) {
      int[] arrayOfInt = e1.k();
      if (arrayOfInt == null) {
        arrayOfInt = e1.n();
        if (arrayOfInt != null && a.a(arrayOfInt, paramInt))
          return null; 
      } else if (!a.a(arrayOfInt, paramInt)) {
        return null;
      } 
      if (paramy.F() < e1.c())
        return e1; 
    } 
    return null;
  }
  
  public final void a(h<T> paramh) {
    if (!this.a.s())
      return; 
    q q = p.b().a();
    if (q == null || q.n()) {
      y<?> y = this.a.p(this.c);
      if (y != null) {
        int i;
        byte b1;
        byte b2;
        boolean bool;
        char c;
        byte b3;
        int k;
        long l2;
        if (!(y.s() instanceof c))
          return; 
        c<?> c1 = (c)y.s();
        long l1 = this.d;
        int j = 1;
        if (l1 > 0L) {
          i = 1;
        } else {
          i = 0;
        } 
        int m = c1.y();
        byte b4 = 100;
        if (q != null) {
          int i2 = i & q.o();
          c = q.c();
          int i3 = q.k();
          bool = q.p();
          i = i2;
          int n = i3;
          if (c1.I()) {
            i = i2;
            n = i3;
            if (!c1.j()) {
              e e2 = c(y, c1, this.b);
              if (e2 == null)
                return; 
              if (e2.p() && this.d > 0L) {
                i = j;
              } else {
                i = 0;
              } 
              n = e2.c();
            } 
          } 
          j = n;
          int i1 = i;
        } else {
          bool = false;
          b3 = 100;
          c = 'ᎈ';
          k = i;
        } 
        e e1 = this.a;
        if (paramh.m()) {
          b2 = 0;
          b1 = b2;
        } else if (paramh.k()) {
          b1 = -1;
          b2 = b4;
        } else {
          Exception exception = paramh.i();
          if (exception instanceof b) {
            Status status = ((b)exception).a();
            b2 = status.k();
            b b5 = status.c();
            if (b5 == null) {
              b1 = -1;
            } else {
              b1 = b5.c();
            } 
          } else {
            b1 = -1;
            b2 = 101;
          } 
        } 
        if (k != 0) {
          l1 = this.d;
          l2 = System.currentTimeMillis();
        } else {
          l1 = 0L;
          l2 = l1;
        } 
        e1.v(new m(this.b, b2, b1, l1, l2, null, null, m), bool, c, b3);
      } 
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */