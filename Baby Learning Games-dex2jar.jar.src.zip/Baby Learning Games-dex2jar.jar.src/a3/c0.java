package a3;

import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import z2.a;
import z2.e;

public final class c0<O extends a.d> extends r {
  @NotOnlyInitialized
  private final e<O> c;
  
  public c0(e<O> parame) {
    super("Method is not supported by connectionless client. APIs supporting connectionless client must not call this method.");
    this.c = parame;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */