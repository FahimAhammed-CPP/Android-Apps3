package a3;

import androidx.annotation.RecentlyNonNull;
import b3.n;
import z2.a;

public final class b<O extends a.d> {
  private final int a;
  
  private final a<O> b;
  
  private final O c;
  
  private final String d;
  
  private b(a<O> parama, O paramO, String paramString) {
    this.b = parama;
    this.c = paramO;
    this.d = paramString;
    this.a = n.b(new Object[] { parama, paramO, paramString });
  }
  
  @RecentlyNonNull
  public static <O extends a.d> b<O> a(@RecentlyNonNull a<O> parama, O paramO, String paramString) {
    return new b<O>(parama, paramO, paramString);
  }
  
  @RecentlyNonNull
  public final String b() {
    return this.b.b();
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject == null)
      return false; 
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof b))
      return false; 
    paramObject = paramObject;
    return (n.a(this.b, ((b)paramObject).b) && n.a(this.c, ((b)paramObject).c) && n.a(this.d, ((b)paramObject).d));
  }
  
  public final int hashCode() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */