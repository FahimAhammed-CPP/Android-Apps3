package a3;

import android.util.Log;
import y2.b;

final class a0 implements Runnable {
  a0(b0 paramb0, b paramb) {}
  
  public final void run() {
    y y = (y)e.g(this.g.f).get(b0.d(this.g));
    if (y == null)
      return; 
    if (this.f.p()) {
      b0.e(this.g, true);
      if (b0.f(this.g).o()) {
        b0.g(this.g);
        return;
      } 
      try {
        b0.f(this.g).e(null, b0.f(this.g).c());
        return;
      } catch (SecurityException securityException) {
        Log.e("GoogleApiManager", "Failed to get service from broker. ", securityException);
        b0.f(this.g).d("Failed to get service from broker.");
        y.p(new b(10), null);
        return;
      } 
    } 
    y.p(this.f, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */