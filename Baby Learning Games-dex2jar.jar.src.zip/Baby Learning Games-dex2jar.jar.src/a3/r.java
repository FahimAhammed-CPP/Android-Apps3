package a3;

import z2.f;

public class r extends f {
  private final String b = "Method is not supported by connectionless client. APIs supporting connectionless client must not call this method.";
  
  public r(String paramString) {}
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */