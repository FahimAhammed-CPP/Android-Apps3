package a3;

import android.os.RemoteException;
import t3.i;
import y2.d;
import z2.a;

final class p0 extends m {
  p0(m.a parama, d[] paramArrayOfd, boolean paramBoolean, int paramInt) {
    super(paramArrayOfd, paramBoolean, paramInt);
  }
  
  protected final void b(a.b paramb, i parami) throws RemoteException {
    m.a.f(this.d).a(paramb, parami);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */