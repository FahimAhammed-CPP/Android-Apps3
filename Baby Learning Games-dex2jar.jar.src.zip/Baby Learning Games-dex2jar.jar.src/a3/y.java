package a3;

import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import b3.n;
import b3.o;
import com.google.android.gms.common.api.Status;
import f3.a;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import s.a;
import t3.i;
import y2.b;
import y2.d;
import z2.a;
import z2.e;
import z2.f;
import z2.l;

public final class y<O extends a.d> implements f.a, f.b {
  private final Queue<t0> f = new LinkedList<t0>();
  
  @NotOnlyInitialized
  private final a.f g;
  
  private final b<O> h;
  
  private final o i;
  
  private final Set<u0> j = new HashSet<u0>();
  
  private final Map<h<?>, j0> k = new HashMap<h<?>, j0>();
  
  private final int l;
  
  private final n0 m;
  
  private boolean n;
  
  private final List<z> o = new ArrayList<z>();
  
  private b p = null;
  
  private int q = 0;
  
  public y(e parame, e<O> parame1) {
    a.f f1 = parame1.h(e.w(parame).getLooper(), this);
    this.g = f1;
    this.h = parame1.f();
    this.i = new o();
    this.l = parame1.i();
    if (f1.o()) {
      this.m = parame1.j(e.x(parame), e.w(parame));
      return;
    } 
    this.m = null;
  }
  
  private final void b() {
    u();
    m(b.j);
    j();
    Iterator<j0> iterator = this.k.values().iterator();
    if (!iterator.hasNext()) {
      e();
      k();
      return;
    } 
    Objects.requireNonNull(iterator.next());
    throw null;
  }
  
  private final void c(int paramInt) {
    u();
    this.n = true;
    this.i.d(paramInt, this.g.m());
    e.w(this.r).sendMessageDelayed(Message.obtain(e.w(this.r), 9, this.h), e.y(this.r));
    e.w(this.r).sendMessageDelayed(Message.obtain(e.w(this.r), 11, this.h), e.z(this.r));
    e.A(this.r).c();
    Iterator iterator = this.k.values().iterator();
    while (iterator.hasNext())
      ((j0)iterator.next()).a.run(); 
  }
  
  private final boolean d(b paramb) {
    synchronized (e.B()) {
      e.C(this.r);
      return false;
    } 
  }
  
  private final void e() {
    ArrayList<t0> arrayList = new ArrayList<t0>(this.f);
    int j = arrayList.size();
    for (int i = 0; i < j; i++) {
      t0 t0 = arrayList.get(i);
      if (!this.g.a())
        return; 
      if (f(t0))
        this.f.remove(t0); 
    } 
  }
  
  private final boolean f(t0 paramt0) {
    if (!(paramt0 instanceof g0)) {
      g(paramt0);
      return true;
    } 
    g0 g0 = (g0)paramt0;
    d d = n(g0.f(this));
    if (d == null) {
      g(paramt0);
      return true;
    } 
    String str1 = this.g.getClass().getName();
    String str2 = d.c();
    long l = d.k();
    StringBuilder stringBuilder = new StringBuilder(str1.length() + 77 + String.valueOf(str2).length());
    stringBuilder.append(str1);
    stringBuilder.append(" could not execute call because it requires feature (");
    stringBuilder.append(str2);
    stringBuilder.append(", ");
    stringBuilder.append(l);
    stringBuilder.append(").");
    Log.w("GoogleApiManager", stringBuilder.toString());
    if (e.c(this.r) && g0.g(this)) {
      z z = new z(this.h, d, null);
      int i = this.o.indexOf(z);
      if (i >= 0) {
        z = this.o.get(i);
        e.w(this.r).removeMessages(15, z);
        e.w(this.r).sendMessageDelayed(Message.obtain(e.w(this.r), 15, z), e.y(this.r));
      } else {
        this.o.add(z);
        e.w(this.r).sendMessageDelayed(Message.obtain(e.w(this.r), 15, z), e.y(this.r));
        e.w(this.r).sendMessageDelayed(Message.obtain(e.w(this.r), 16, z), e.z(this.r));
        b b1 = new b(2, null);
        if (!d(b1))
          this.r.t(b1, this.l); 
      } 
      return false;
    } 
    g0.b((Exception)new l(d));
    return true;
  }
  
  private final void g(t0 paramt0) {
    paramt0.c(this.i, C());
    try {
      return;
    } catch (DeadObjectException deadObjectException) {
      D(1);
      return;
    } finally {
      paramt0 = null;
    } 
  }
  
  private final void h(Status paramStatus, Exception paramException, boolean paramBoolean) {
    boolean bool1;
    o.c(e.w(this.r));
    boolean bool2 = false;
    if (paramStatus != null) {
      bool1 = false;
    } else {
      bool1 = true;
    } 
    if (paramException == null)
      bool2 = true; 
    if (bool1 != bool2) {
      Iterator<t0> iterator = this.f.iterator();
      while (iterator.hasNext()) {
        t0 t0 = iterator.next();
        if (!paramBoolean || t0.a == 2) {
          if (paramStatus != null) {
            t0.a(paramStatus);
          } else {
            t0.b(paramException);
          } 
          iterator.remove();
        } 
      } 
      return;
    } 
    throw new IllegalArgumentException("Status XOR exception should be null");
  }
  
  private final void i(Status paramStatus) {
    o.c(e.w(this.r));
    h(paramStatus, null, false);
  }
  
  private final void j() {
    if (this.n) {
      e.w(this.r).removeMessages(11, this.h);
      e.w(this.r).removeMessages(9, this.h);
      this.n = false;
    } 
  }
  
  private final void k() {
    e.w(this.r).removeMessages(12, this.h);
    e.w(this.r).sendMessageDelayed(e.w(this.r).obtainMessage(12, this.h), e.e(this.r));
  }
  
  private final boolean l(boolean paramBoolean) {
    o.c(e.w(this.r));
    if (this.g.a() && this.k.size() == 0) {
      if (this.i.b()) {
        if (paramBoolean)
          k(); 
        return false;
      } 
      this.g.d("Timing out service connection.");
      return true;
    } 
    return false;
  }
  
  private final void m(b paramb) {
    for (u0 u0 : this.j) {
      String str;
      if (n.a(paramb, b.j)) {
        str = this.g.l();
      } else {
        str = null;
      } 
      u0.b(this.h, paramb, str);
    } 
    this.j.clear();
  }
  
  private final d n(d[] paramArrayOfd) {
    if (paramArrayOfd != null) {
      if (paramArrayOfd.length == 0)
        return null; 
      d[] arrayOfD2 = this.g.k();
      boolean bool = false;
      d[] arrayOfD1 = arrayOfD2;
      if (arrayOfD2 == null)
        arrayOfD1 = new d[0]; 
      int j = arrayOfD1.length;
      a<String, Long> a1 = new a(j);
      int i;
      for (i = 0; i < j; i++) {
        d d1 = arrayOfD1[i];
        a1.put(d1.c(), Long.valueOf(d1.k()));
      } 
      j = paramArrayOfd.length;
      i = bool;
      while (i < j) {
        d d1 = paramArrayOfd[i];
        Long long_ = a1.get(d1.c());
        if (long_ != null) {
          if (long_.longValue() < d1.k())
            return d1; 
          i++;
          continue;
        } 
        return d1;
      } 
    } 
    return null;
  }
  
  public final void A(u0 paramu0) {
    o.c(e.w(this.r));
    this.j.add(paramu0);
  }
  
  final boolean B() {
    return this.g.a();
  }
  
  public final boolean C() {
    return this.g.o();
  }
  
  public final void D(int paramInt) {
    if (Looper.myLooper() == e.w(this.r).getLooper()) {
      c(paramInt);
      return;
    } 
    e.w(this.r).post(new v(this, paramInt));
  }
  
  public final int E() {
    return this.l;
  }
  
  public final void E0(Bundle paramBundle) {
    if (Looper.myLooper() == e.w(this.r).getLooper()) {
      b();
      return;
    } 
    e.w(this.r).post(new u(this));
  }
  
  final int F() {
    return this.q;
  }
  
  final void G() {
    this.q++;
  }
  
  public final void l0(b paramb) {
    p(paramb, null);
  }
  
  public final void o(b paramb) {
    o.c(e.w(this.r));
    a.f f1 = this.g;
    String str1 = f1.getClass().getName();
    String str2 = String.valueOf(paramb);
    StringBuilder stringBuilder = new StringBuilder(str1.length() + 25 + str2.length());
    stringBuilder.append("onSignInFailed for ");
    stringBuilder.append(str1);
    stringBuilder.append(" with ");
    stringBuilder.append(str2);
    f1.d(stringBuilder.toString());
    p(paramb, null);
  }
  
  public final void p(b paramb, Exception paramException) {
    o.c(e.w(this.r));
    n0 n01 = this.m;
    if (n01 != null)
      n01.W3(); 
    u();
    e.A(this.r).c();
    m(paramb);
    if (this.g instanceof d3.e && paramb.c() != 24) {
      e.a(this.r, true);
      e.w(this.r).sendMessageDelayed(e.w(this.r).obtainMessage(19), 300000L);
    } 
    if (paramb.c() == 4) {
      i(e.b());
      return;
    } 
    if (this.f.isEmpty()) {
      this.p = paramb;
      return;
    } 
    if (paramException != null) {
      o.c(e.w(this.r));
      h(null, paramException, false);
      return;
    } 
    if (e.c(this.r)) {
      h(e.f(this.h, paramb), null, true);
      if (this.f.isEmpty())
        return; 
      if (d(paramb))
        return; 
      if (!this.r.t(paramb, this.l)) {
        if (paramb.c() == 18)
          this.n = true; 
        if (this.n) {
          e.w(this.r).sendMessageDelayed(Message.obtain(e.w(this.r), 9, this.h), e.y(this.r));
          return;
        } 
        i(e.f(this.h, paramb));
      } 
      return;
    } 
    i(e.f(this.h, paramb));
  }
  
  public final void q(t0 paramt0) {
    o.c(e.w(this.r));
    if (this.g.a()) {
      if (f(paramt0)) {
        k();
        return;
      } 
      this.f.add(paramt0);
      return;
    } 
    this.f.add(paramt0);
    b b1 = this.p;
    if (b1 != null && b1.o()) {
      p(this.p, null);
      return;
    } 
    z();
  }
  
  public final void r() {
    o.c(e.w(this.r));
    i(e.v);
    this.i.c();
    Set<h<?>> set = this.k.keySet();
    int i = 0;
    h[] arrayOfH = set.<h>toArray(new h[0]);
    int j = arrayOfH.length;
    while (i < j) {
      q(new s0(arrayOfH[i], new i()));
      i++;
    } 
    m(new b(4));
    if (this.g.a())
      this.g.b(new x(this)); 
  }
  
  public final a.f s() {
    return this.g;
  }
  
  public final Map<h<?>, j0> t() {
    return this.k;
  }
  
  public final void u() {
    o.c(e.w(this.r));
    this.p = null;
  }
  
  public final b v() {
    o.c(e.w(this.r));
    return this.p;
  }
  
  public final void w() {
    o.c(e.w(this.r));
    if (this.n)
      z(); 
  }
  
  public final void x() {
    o.c(e.w(this.r));
    if (this.n) {
      Status status;
      j();
      if (e.d(this.r).g(e.x(this.r)) == 18) {
        status = new Status(21, "Connection timed out waiting for Google Play services update to complete.");
      } else {
        status = new Status(22, "API failed to connect while resuming due to an unknown error.");
      } 
      i(status);
      this.g.d("Timing out connection while resuming.");
    } 
  }
  
  public final boolean y() {
    return l(true);
  }
  
  public final void z() {
    o.c(e.w(this.r));
    if (!this.g.a()) {
      if (this.g.j())
        return; 
      try {
        int i = e.A(this.r).a(e.x(this.r), this.g);
        if (i != 0) {
          b b1 = new b(i, null);
          String str1 = this.g.getClass().getName();
          String str2 = String.valueOf(b1);
          StringBuilder stringBuilder = new StringBuilder(str1.length() + 35 + str2.length());
          stringBuilder.append("The service for ");
          stringBuilder.append(str1);
          stringBuilder.append(" is not available: ");
          stringBuilder.append(str2);
          Log.w("GoogleApiManager", stringBuilder.toString());
          p(b1, null);
          return;
        } 
        b0 b0 = new b0(this.r, this.g, this.h);
        if (this.g.o())
          ((n0)o.h(this.m)).r3(b0); 
        try {
          this.g.i(b0);
          return;
        } catch (SecurityException securityException) {
          p(new b(10), securityException);
          return;
        } 
      } catch (IllegalStateException illegalStateException) {
        p(new b(10), illegalStateException);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */