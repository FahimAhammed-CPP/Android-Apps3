package a3;

import b3.n;
import y2.d;

final class z {
  private final b<?> a;
  
  private final d b;
  
  public final boolean equals(Object paramObject) {
    if (paramObject != null && paramObject instanceof z) {
      paramObject = paramObject;
      if (n.a(this.a, ((z)paramObject).a) && n.a(this.b, ((z)paramObject).b))
        return true; 
    } 
    return false;
  }
  
  public final int hashCode() {
    return n.b(new Object[] { this.a, this.b });
  }
  
  public final String toString() {
    return n.c(this).a("key", this.a).a("feature", this.b).toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */