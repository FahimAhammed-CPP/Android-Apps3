package a3;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import t3.i;
import z2.b;

public final class o {
  private final Map<BasePendingResult<?>, Boolean> a = Collections.synchronizedMap(new WeakHashMap<BasePendingResult<?>, Boolean>());
  
  private final Map<i<?>, Boolean> b = Collections.synchronizedMap(new WeakHashMap<i<?>, Boolean>());
  
  private final void f(boolean paramBoolean, Status paramStatus) {
    synchronized (this.a) {
      Map<i<?>, Boolean> map;
      HashMap<BasePendingResult<?>, Boolean> hashMap = new HashMap<BasePendingResult<?>, Boolean>(this.a);
      synchronized (this.b) {
        null = (Map)new HashMap<Object, Boolean>(this.b);
        for (Map.Entry<BasePendingResult<?>, Boolean> entry : hashMap.entrySet()) {
          if (paramBoolean || ((Boolean)entry.getValue()).booleanValue())
            ((BasePendingResult)entry.getKey()).b(paramStatus); 
        } 
        for (Map.Entry<BasePendingResult<?>, Boolean> entry1 : null.entrySet()) {
          if (paramBoolean || ((Boolean)entry1.getValue()).booleanValue())
            ((i)entry1.getKey()).d((Exception)new b(paramStatus)); 
        } 
        return;
      } 
    } 
  }
  
  final <TResult> void a(i<TResult> parami, boolean paramBoolean) {
    this.b.put(parami, Boolean.valueOf(paramBoolean));
    parami.a().c(new w0(this, parami));
  }
  
  final boolean b() {
    return (!this.a.isEmpty() || !this.b.isEmpty());
  }
  
  public final void c() {
    f(false, e.v);
  }
  
  final void d(int paramInt, String paramString) {
    StringBuilder stringBuilder = new StringBuilder("The connection to Google Play services was lost");
    if (paramInt == 1) {
      stringBuilder.append(" due to service disconnection.");
    } else if (paramInt == 3) {
      stringBuilder.append(" due to dead object exception.");
    } 
    if (paramString != null) {
      stringBuilder.append(" Last reason for disconnect: ");
      stringBuilder.append(paramString);
    } 
    f(true, new Status(20, stringBuilder.toString()));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */