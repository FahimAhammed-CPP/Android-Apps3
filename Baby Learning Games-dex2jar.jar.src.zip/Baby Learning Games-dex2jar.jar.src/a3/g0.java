package a3;

import y2.d;

public abstract class g0 extends t0 {
  public g0(int paramInt) {
    super(paramInt);
  }
  
  public abstract d[] f(y<?> paramy);
  
  public abstract boolean g(y<?> paramy);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */