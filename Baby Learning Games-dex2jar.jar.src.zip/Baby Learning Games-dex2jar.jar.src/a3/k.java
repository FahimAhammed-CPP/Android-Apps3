package a3;

import android.os.RemoteException;
import androidx.annotation.RecentlyNonNull;

public interface k<T, U> {
  void a(@RecentlyNonNull T paramT, @RecentlyNonNull U paramU) throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */