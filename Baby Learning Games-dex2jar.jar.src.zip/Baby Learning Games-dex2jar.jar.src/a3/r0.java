package a3;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import t3.i;
import y2.d;
import z2.a;

public final class r0<ResultT> extends g0 {
  private final m<a.b, ResultT> b;
  
  private final i<ResultT> c;
  
  private final l d;
  
  public r0(int paramInt, m<a.b, ResultT> paramm, i<ResultT> parami, l paraml) {
    super(paramInt);
    this.c = parami;
    this.b = paramm;
    this.d = paraml;
    if (paramInt == 2) {
      if (!paramm.c())
        return; 
      throw new IllegalArgumentException("Best-effort write calls cannot pass methods that should auto-resolve missing features.");
    } 
  }
  
  public final void a(Status paramStatus) {
    this.c.d(this.d.a(paramStatus));
  }
  
  public final void b(Exception paramException) {
    this.c.d(paramException);
  }
  
  public final void c(o paramo, boolean paramBoolean) {
    paramo.a(this.c, paramBoolean);
  }
  
  public final void d(y<?> paramy) throws DeadObjectException {
    try {
      this.b.b(paramy.s(), this.c);
      return;
    } catch (DeadObjectException deadObjectException) {
      throw deadObjectException;
    } catch (RemoteException remoteException) {
      a(t0.e(remoteException));
      return;
    } catch (RuntimeException runtimeException) {
      this.c.d(runtimeException);
      return;
    } 
  }
  
  public final d[] f(y<?> paramy) {
    return this.b.d();
  }
  
  public final boolean g(y<?> paramy) {
    return this.b.c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */