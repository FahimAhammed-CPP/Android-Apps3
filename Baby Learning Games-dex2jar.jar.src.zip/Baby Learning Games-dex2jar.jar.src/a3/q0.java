package a3;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import t3.i;
import z2.b;

abstract class q0<T> extends g0 {
  protected final i<T> b;
  
  public q0(int paramInt, i<T> parami) {
    super(paramInt);
    this.b = parami;
  }
  
  public final void a(Status paramStatus) {
    this.b.d((Exception)new b(paramStatus));
  }
  
  public final void b(Exception paramException) {
    this.b.d(paramException);
  }
  
  public final void d(y<?> paramy) throws DeadObjectException {
    try {
      h(paramy);
      return;
    } catch (DeadObjectException deadObjectException) {
      a(t0.e((RemoteException)deadObjectException));
      throw deadObjectException;
    } catch (RemoteException remoteException) {
      a(t0.e(remoteException));
      return;
    } catch (RuntimeException runtimeException) {
      this.b.d(runtimeException);
      return;
    } 
  }
  
  protected abstract void h(y<?> paramy) throws RemoteException;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\q0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */