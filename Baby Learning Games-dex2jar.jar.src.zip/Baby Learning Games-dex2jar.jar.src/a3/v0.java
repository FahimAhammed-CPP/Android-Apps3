package a3;

import android.content.DialogInterface;
import com.google.android.gms.common.api.internal.LifecycleCallback;

public abstract class v0 extends LifecycleCallback implements DialogInterface.OnCancelListener {}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */