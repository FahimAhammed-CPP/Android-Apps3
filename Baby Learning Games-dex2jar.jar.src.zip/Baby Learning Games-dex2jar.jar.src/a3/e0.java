package a3;

import b3.m;

final class e0 {
  final m a;
  
  final int b;
  
  final long c;
  
  final int d;
  
  e0(m paramm, int paramInt1, long paramLong, int paramInt2) {
    this.a = paramm;
    this.b = paramInt1;
    this.c = paramLong;
    this.d = paramInt2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */