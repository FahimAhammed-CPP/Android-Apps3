package a3;

import android.os.RemoteException;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import b3.o;
import t3.i;
import y2.d;
import z2.a;

public abstract class m<A extends a.b, ResultT> {
  private final d[] a;
  
  private final boolean b;
  
  private final int c;
  
  protected m(d[] paramArrayOfd, boolean paramBoolean, int paramInt) {
    this.a = paramArrayOfd;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramArrayOfd != null) {
      bool1 = bool2;
      if (paramBoolean)
        bool1 = true; 
    } 
    this.b = bool1;
    this.c = paramInt;
  }
  
  @RecentlyNonNull
  public static <A extends a.b, ResultT> a<A, ResultT> a() {
    return new a<A, ResultT>(null);
  }
  
  protected abstract void b(@RecentlyNonNull A paramA, @RecentlyNonNull i<ResultT> parami) throws RemoteException;
  
  public boolean c() {
    return this.b;
  }
  
  @RecentlyNullable
  public final d[] d() {
    return this.a;
  }
  
  public final int e() {
    return this.c;
  }
  
  public static class a<A extends a.b, ResultT> {
    private k<A, i<ResultT>> a;
    
    private boolean b = true;
    
    private d[] c;
    
    private int d = 0;
    
    @RecentlyNonNull
    public m<A, ResultT> a() {
      boolean bool;
      if (this.a != null) {
        bool = true;
      } else {
        bool = false;
      } 
      o.b(bool, "execute parameter required");
      return new p0(this, this.c, this.b, this.d);
    }
    
    @RecentlyNonNull
    public a<A, ResultT> b(@RecentlyNonNull k<A, i<ResultT>> param1k) {
      this.a = param1k;
      return this;
    }
    
    @RecentlyNonNull
    public a<A, ResultT> c(boolean param1Boolean) {
      this.b = param1Boolean;
      return this;
    }
    
    @RecentlyNonNull
    public a<A, ResultT> d(@RecentlyNonNull d... param1VarArgs) {
      this.c = param1VarArgs;
      return this;
    }
    
    @RecentlyNonNull
    public a<A, ResultT> e(int param1Int) {
      this.d = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */