package a3;

final class t implements c.a {
  t(e parame) {}
  
  public final void a(boolean paramBoolean) {
    e.w(this.a).sendMessage(e.w(this.a).obtainMessage(1, Boolean.valueOf(paramBoolean)));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */