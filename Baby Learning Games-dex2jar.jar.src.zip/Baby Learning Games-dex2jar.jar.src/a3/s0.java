package a3;

import android.os.RemoteException;
import t3.i;
import y2.d;

public final class s0 extends q0<Boolean> {
  public final h<?> c;
  
  public s0(h<?> paramh, i<Boolean> parami) {
    super(4, parami);
    this.c = paramh;
  }
  
  public final d[] f(y<?> paramy) {
    if ((j0)paramy.t().get(this.c) == null)
      return null; 
    throw null;
  }
  
  public final boolean g(y<?> paramy) {
    if ((j0)paramy.t().get(this.c) == null)
      return false; 
    throw null;
  }
  
  public final void h(y<?> paramy) throws RemoteException {
    if ((j0)paramy.t().remove(this.c) == null) {
      this.b.e(Boolean.FALSE);
      return;
    } 
    paramy.s();
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */