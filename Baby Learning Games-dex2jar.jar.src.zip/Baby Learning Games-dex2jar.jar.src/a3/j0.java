package a3;

public final class j0 {
  public final Runnable a;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */