package a3;

import y2.b;

final class k0 implements Runnable {
  k0(n0 paramn0) {}
  
  public final void run() {
    n0.l5(this.f).b(new b(4));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */