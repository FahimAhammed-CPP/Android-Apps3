package a3;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import b3.d;
import b3.h0;
import b3.o;
import com.google.android.gms.common.api.Scope;
import java.util.Set;
import r3.a;
import r3.e;
import r3.f;
import s3.d;
import s3.f;
import s3.l;
import y2.b;
import z2.a;
import z2.f;

public final class n0 extends d implements f.a, f.b {
  private static final a.a<? extends f, a> m = e.c;
  
  private final Context f;
  
  private final Handler g;
  
  private final a.a<? extends f, a> h;
  
  private final Set<Scope> i;
  
  private final d j;
  
  private f k;
  
  private m0 l;
  
  public n0(Context paramContext, Handler paramHandler, d paramd) {
    this.f = paramContext;
    this.g = paramHandler;
    this.j = (d)o.i(paramd, "ClientSettings must not be null");
    this.i = paramd.e();
    this.h = a1;
  }
  
  public final void D(int paramInt) {
    this.k.n();
  }
  
  public final void E0(Bundle paramBundle) {
    this.k.p((f)this);
  }
  
  public final void W3() {
    f f1 = this.k;
    if (f1 != null)
      f1.n(); 
  }
  
  public final void g3(l paraml) {
    this.g.post(new l0(this, paraml));
  }
  
  public final void l0(b paramb) {
    this.l.b(paramb);
  }
  
  public final void r3(m0 paramm0) {
    f f1 = this.k;
    if (f1 != null)
      f1.n(); 
    this.j.i(Integer.valueOf(System.identityHashCode(this)));
    a.a<? extends f, a> a1 = this.h;
    Context context = this.f;
    Looper looper = this.g.getLooper();
    d d1 = this.j;
    this.k = (f)a1.b(context, looper, d1, d1.g(), this, this);
    this.l = paramm0;
    Set<Scope> set = this.i;
    if (set == null || set.isEmpty()) {
      this.g.post(new k0(this));
      return;
    } 
    this.k.g();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */