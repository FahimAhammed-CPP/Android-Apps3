package a3;

public final class h<L> {
  private final L a;
  
  private final String b;
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof h))
      return false; 
    paramObject = paramObject;
    return (this.a == ((h)paramObject).a && this.b.equals(((h)paramObject).b));
  }
  
  public int hashCode() {
    return System.identityHashCode(this.a) * 31 + this.b.hashCode();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */