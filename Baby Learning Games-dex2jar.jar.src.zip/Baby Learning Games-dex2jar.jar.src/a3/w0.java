package a3;

import t3.d;
import t3.h;
import t3.i;

final class w0 implements d {
  w0(o paramo, i parami) {}
  
  public final void a(h paramh) {
    o.e(this.b).remove(this.a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */