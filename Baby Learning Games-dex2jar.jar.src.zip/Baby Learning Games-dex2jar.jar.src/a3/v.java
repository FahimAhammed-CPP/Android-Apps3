package a3;

final class v implements Runnable {
  v(y paramy, int paramInt) {}
  
  public final void run() {
    y.N(this.g, this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */