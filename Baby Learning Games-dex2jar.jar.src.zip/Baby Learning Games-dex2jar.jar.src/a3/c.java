package a3;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import android.os.Bundle;
import androidx.annotation.RecentlyNonNull;
import f3.l;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.concurrent.GuardedBy;

public final class c implements Application.ActivityLifecycleCallbacks, ComponentCallbacks2 {
  private static final c j = new c();
  
  private final AtomicBoolean f = new AtomicBoolean();
  
  private final AtomicBoolean g = new AtomicBoolean();
  
  @GuardedBy("sInstance")
  private final ArrayList<a> h = new ArrayList<a>();
  
  @GuardedBy("sInstance")
  private boolean i = false;
  
  @RecentlyNonNull
  public static c b() {
    return j;
  }
  
  public static void c(@RecentlyNonNull Application paramApplication) {
    synchronized (j) {
      if (!null.i) {
        paramApplication.registerActivityLifecycleCallbacks(null);
        paramApplication.registerComponentCallbacks((ComponentCallbacks)null);
        null.i = true;
      } 
      return;
    } 
  }
  
  private final void f(boolean paramBoolean) {
    synchronized (j) {
      Iterator<a> iterator = this.h.iterator();
      while (iterator.hasNext())
        ((a)iterator.next()).a(paramBoolean); 
      return;
    } 
  }
  
  public void a(@RecentlyNonNull a parama) {
    synchronized (j) {
      this.h.add(parama);
      return;
    } 
  }
  
  public boolean d() {
    return this.f.get();
  }
  
  @TargetApi(16)
  public boolean e(boolean paramBoolean) {
    if (!this.g.get())
      if (l.b()) {
        ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        if (!this.g.getAndSet(true) && runningAppProcessInfo.importance > 100)
          this.f.set(true); 
      } else {
        return paramBoolean;
      }  
    return d();
  }
  
  public final void onActivityCreated(@RecentlyNonNull Activity paramActivity, Bundle paramBundle) {
    boolean bool = this.f.compareAndSet(true, false);
    this.g.set(true);
    if (bool)
      f(false); 
  }
  
  public final void onActivityDestroyed(@RecentlyNonNull Activity paramActivity) {}
  
  public final void onActivityPaused(@RecentlyNonNull Activity paramActivity) {}
  
  public final void onActivityResumed(@RecentlyNonNull Activity paramActivity) {
    boolean bool = this.f.compareAndSet(true, false);
    this.g.set(true);
    if (bool)
      f(false); 
  }
  
  public final void onActivitySaveInstanceState(@RecentlyNonNull Activity paramActivity, @RecentlyNonNull Bundle paramBundle) {}
  
  public final void onActivityStarted(@RecentlyNonNull Activity paramActivity) {}
  
  public final void onActivityStopped(@RecentlyNonNull Activity paramActivity) {}
  
  public final void onConfigurationChanged(@RecentlyNonNull Configuration paramConfiguration) {}
  
  public final void onLowMemory() {}
  
  public final void onTrimMemory(int paramInt) {
    if (paramInt == 20 && this.f.compareAndSet(false, true)) {
      this.g.set(true);
      f(true);
    } 
  }
  
  public static interface a {
    void a(boolean param1Boolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */