package a3;

import b3.c;

final class x implements c.e {
  x(y paramy) {}
  
  public final void a() {
    e.w(this.a.r).post(new w(this));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */