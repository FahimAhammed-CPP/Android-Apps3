package a3;

import androidx.annotation.RecentlyNonNull;
import y2.b;

public interface j {
  void l0(@RecentlyNonNull b paramb);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */