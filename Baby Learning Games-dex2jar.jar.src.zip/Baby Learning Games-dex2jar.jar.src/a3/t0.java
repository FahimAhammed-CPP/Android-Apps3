package a3;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;

public abstract class t0 {
  public final int a;
  
  public t0(int paramInt) {
    this.a = paramInt;
  }
  
  public abstract void a(Status paramStatus);
  
  public abstract void b(Exception paramException);
  
  public abstract void c(o paramo, boolean paramBoolean);
  
  public abstract void d(y<?> paramy) throws DeadObjectException;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\t0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */