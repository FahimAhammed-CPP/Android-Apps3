package a3;

import s3.l;

final class l0 implements Runnable {
  l0(n0 paramn0, l paraml) {}
  
  public final void run() {
    n0.W5(this.g, this.f);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */