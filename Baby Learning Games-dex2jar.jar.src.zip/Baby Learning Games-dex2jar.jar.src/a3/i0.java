package a3;

import z2.e;

public final class i0 {
  public final t0 a;
  
  public final int b;
  
  public final e<?> c;
  
  public i0(t0 paramt0, int paramInt, e<?> parame) {
    this.a = paramt0;
    this.b = paramInt;
    this.c = parame;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */