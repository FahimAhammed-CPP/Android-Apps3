package a3;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import androidx.annotation.RecentlyNonNull;
import b3.d0;
import b3.m;
import b3.p;
import b3.q;
import b3.r;
import b3.s;
import b3.t;
import com.google.android.gms.common.api.Status;
import f3.h;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import javax.annotation.concurrent.GuardedBy;
import org.checkerframework.checker.initialization.qual.NotOnlyInitialized;
import s.b;
import t3.h;
import t3.i;
import y2.b;
import y2.f;
import z2.a;

public class e implements Handler.Callback {
  @RecentlyNonNull
  public static final Status v = new Status(4, "Sign-out occurred while this API call was in progress.");
  
  private static final Status w = new Status(4, "The user must be signed in to make this API call.");
  
  private static final Object x = new Object();
  
  @GuardedBy("lock")
  private static e y;
  
  private long f = 5000L;
  
  private long g = 120000L;
  
  private long h = 10000L;
  
  private boolean i = false;
  
  private r j;
  
  private t k;
  
  private final Context l;
  
  private final y2.e m;
  
  private final d0 n;
  
  private final AtomicInteger o = new AtomicInteger(1);
  
  private final AtomicInteger p = new AtomicInteger(0);
  
  private final Map<b<?>, y<?>> q = new ConcurrentHashMap<b<?>, y<?>>(5, 0.75F, 1);
  
  @GuardedBy("lock")
  private final Set<b<?>> r = (Set<b<?>>)new b();
  
  private final Set<b<?>> s = (Set<b<?>>)new b();
  
  @NotOnlyInitialized
  private final Handler t;
  
  private volatile boolean u = true;
  
  private e(Context paramContext, Looper paramLooper, y2.e parame) {
    this.l = paramContext;
    k3.e e1 = new k3.e(paramLooper, this);
    this.t = (Handler)e1;
    this.m = parame;
    this.n = new d0((f)parame);
    if (h.a(paramContext))
      this.u = false; 
    e1.sendMessage(e1.obtainMessage(6));
  }
  
  private final y<?> h(z2.e<?> parame) {
    b<?> b = parame.f();
    y<?> y2 = this.q.get(b);
    y<?> y1 = y2;
    if (y2 == null) {
      y1 = new y(this, parame);
      this.q.put(b, y1);
    } 
    if (y1.C())
      this.s.add(b); 
    y1.z();
    return y1;
  }
  
  private final <T> void i(i<T> parami, int paramInt, z2.e parame) {
    if (paramInt != 0) {
      d0<?> d01 = d0.b(this, paramInt, parame.f());
      if (d01 != null) {
        h h = parami.a();
        Handler handler = this.t;
        handler.getClass();
        h.b(s.a(handler), d01);
      } 
    } 
  }
  
  private static Status j(b<?> paramb, b paramb1) {
    String str1 = paramb.b();
    String str2 = String.valueOf(paramb1);
    StringBuilder stringBuilder = new StringBuilder(String.valueOf(str1).length() + 63 + str2.length());
    stringBuilder.append("API: ");
    stringBuilder.append(str1);
    stringBuilder.append(" is not available on this device. Connection failed with: ");
    stringBuilder.append(str2);
    return new Status(paramb1, stringBuilder.toString());
  }
  
  private final void k() {
    r r1 = this.j;
    if (r1 != null) {
      if (r1.c() > 0 || s())
        l().a(r1); 
      this.j = null;
    } 
  }
  
  private final t l() {
    if (this.k == null)
      this.k = s.a(this.l); 
    return this.k;
  }
  
  @RecentlyNonNull
  public static e m(@RecentlyNonNull Context paramContext) {
    synchronized (x) {
      if (y == null) {
        HandlerThread handlerThread = new HandlerThread("GoogleApiHandler", 9);
        handlerThread.start();
        Looper looper = handlerThread.getLooper();
        y = new e(paramContext.getApplicationContext(), looper, y2.e.l());
      } 
      return y;
    } 
  }
  
  public final boolean handleMessage(@RecentlyNonNull Message paramMessage) {
    StringBuilder stringBuilder2;
    e0 e0;
    r r1;
    z z;
    q q;
    y<?> y2;
    StringBuilder stringBuilder1;
    y<?> y1;
    u0 u0;
    boolean bool;
    b b1;
    i0 i0;
    Iterator<y> iterator;
    int i = paramMessage.what;
    long l = 300000L;
    r r2 = null;
    switch (i) {
      default:
        stringBuilder2 = new StringBuilder(31);
        stringBuilder2.append("Unknown message id: ");
        stringBuilder2.append(i);
        Log.w("GoogleApiManager", stringBuilder2.toString());
        return false;
      case 19:
        this.i = false;
        return true;
      case 18:
        e0 = (e0)((Message)stringBuilder2).obj;
        if (e0.c == 0L) {
          r1 = new r(e0.b, Arrays.asList(new m[] { e0.a }));
          l().a(r1);
          return true;
        } 
        r2 = this.j;
        if (r2 != null) {
          List list = r2.k();
          if (this.j.c() != ((e0)r1).b || (list != null && list.size() >= ((e0)r1).d)) {
            this.t.removeMessages(17);
            k();
          } else {
            this.j.n(((e0)r1).a);
          } 
        } 
        if (this.j == null) {
          ArrayList<m> arrayList = new ArrayList();
          arrayList.add(((e0)r1).a);
          this.j = new r(((e0)r1).b, arrayList);
          Handler handler = this.t;
          handler.sendMessageDelayed(handler.obtainMessage(17), ((e0)r1).c);
          return true;
        } 
        return true;
      case 17:
        k();
        return true;
      case 16:
        z = (z)((Message)r1).obj;
        if (this.q.containsKey(z.a(z))) {
          y.J(this.q.get(z.a(z)), z);
          return true;
        } 
        return true;
      case 15:
        z = (z)((Message)z).obj;
        if (this.q.containsKey(z.a(z))) {
          y.I(this.q.get(z.a(z)), z);
          return true;
        } 
        return true;
      case 14:
        q = (q)((Message)z).obj;
        b = q.a();
        if (!this.q.containsKey(b)) {
          q.b().c(Boolean.FALSE);
          return true;
        } 
        bool = y.H(this.q.get(b), false);
        q.b().c(Boolean.valueOf(bool));
        return true;
      case 12:
        if (this.q.containsKey(((Message)q).obj)) {
          ((y)this.q.get(((Message)q).obj)).y();
          return true;
        } 
        return true;
      case 11:
        if (this.q.containsKey(((Message)q).obj)) {
          ((y)this.q.get(((Message)q).obj)).x();
          return true;
        } 
        return true;
      case 10:
        for (b<?> b : this.s) {
          y3 = this.q.remove(b);
          if (y3 != null)
            y3.r(); 
        } 
        this.s.clear();
        return true;
      case 9:
        if (this.q.containsKey(((Message)q).obj)) {
          ((y)this.q.get(((Message)q).obj)).w();
          return true;
        } 
        return true;
      case 7:
        h((z2.e)((Message)q).obj);
        return true;
      case 6:
        if (this.l.getApplicationContext() instanceof Application) {
          c.c((Application)this.l.getApplicationContext());
          c.b().a(new t(this));
          if (!c.b().e(true)) {
            this.h = 300000L;
            return true;
          } 
        } 
        return true;
      case 5:
        i = ((Message)q).arg1;
        b1 = (b)((Message)q).obj;
        iterator = this.q.values().iterator();
        while (true) {
          y2 = y3;
          if (iterator.hasNext()) {
            y2 = iterator.next();
            if (y2.E() == i)
              break; 
            continue;
          } 
          break;
        } 
        if (y2 != null) {
          String str;
          if (b1.c() == 13) {
            String str1 = this.m.e(b1.c());
            str = b1.k();
            StringBuilder stringBuilder = new StringBuilder(String.valueOf(str1).length() + 69 + String.valueOf(str).length());
            stringBuilder.append("Error resolution was canceled by the user, original error message: ");
            stringBuilder.append(str1);
            stringBuilder.append(": ");
            stringBuilder.append(str);
            y.K(y2, new Status(17, stringBuilder.toString()));
            return true;
          } 
          y.K(y2, j(y.L(y2), (b)str));
          return true;
        } 
        stringBuilder1 = new StringBuilder(76);
        stringBuilder1.append("Could not find API instance ");
        stringBuilder1.append(i);
        stringBuilder1.append(" while trying to fail enqueued calls.");
        Log.wtf("GoogleApiManager", stringBuilder1.toString(), new Exception());
        return true;
      case 4:
      case 8:
      case 13:
        i0 = (i0)((Message)stringBuilder1).obj;
        y3 = this.q.get(i0.c.f());
        y1 = y3;
        if (y3 == null)
          y1 = h(i0.c); 
        if (y1.C() && this.p.get() != i0.b) {
          i0.a.a(v);
          y1.r();
          return true;
        } 
        y1.q(i0.a);
        return true;
      case 3:
        for (y<?> y3 : this.q.values()) {
          y3.u();
          y3.z();
        } 
        return true;
      case 2:
        u0 = (u0)((Message)y1).obj;
        for (b<?> b2 : u0.a()) {
          y y = this.q.get(b2);
          if (y == null) {
            u0.b(b2, new b(13), null);
            return true;
          } 
          if (y.B()) {
            u0.b(b2, b.j, y.s().l());
            continue;
          } 
          b b3 = y.v();
          if (b3 != null) {
            u0.b(b2, b3, null);
            continue;
          } 
          y.A(u0);
          y.z();
        } 
        return true;
      case 1:
        break;
    } 
    if (true == ((Boolean)((Message)u0).obj).booleanValue())
      l = 10000L; 
    this.h = l;
    this.t.removeMessages(12);
    for (b<?> b2 : this.q.keySet()) {
      Handler handler = this.t;
      handler.sendMessageDelayed(handler.obtainMessage(12, b2), this.h);
    } 
    return true;
  }
  
  public final int n() {
    return this.o.getAndIncrement();
  }
  
  public final void o(@RecentlyNonNull z2.e<?> parame) {
    Handler handler = this.t;
    handler.sendMessage(handler.obtainMessage(7, parame));
  }
  
  final y p(b<?> paramb) {
    return this.q.get(paramb);
  }
  
  public final void q() {
    Handler handler = this.t;
    handler.sendMessage(handler.obtainMessage(3));
  }
  
  public final <O extends a.d, ResultT> void r(@RecentlyNonNull z2.e<O> parame, int paramInt, @RecentlyNonNull m<a.b, ResultT> paramm, @RecentlyNonNull i<ResultT> parami, @RecentlyNonNull l paraml) {
    i(parami, paramm.e(), parame);
    r0<ResultT> r0 = new r0<ResultT>(paramInt, paramm, parami, paraml);
    Handler handler = this.t;
    handler.sendMessage(handler.obtainMessage(4, new i0(r0, this.p.get(), parame)));
  }
  
  final boolean s() {
    if (this.i)
      return false; 
    q q = p.b().a();
    if (q == null || q.n()) {
      int i = this.n.b(this.l, 203390000);
      return (i == -1 || i == 0);
    } 
    return false;
  }
  
  final boolean t(b paramb, int paramInt) {
    return this.m.p(this.l, paramb, paramInt);
  }
  
  public final void u(@RecentlyNonNull b paramb, int paramInt) {
    if (!t(paramb, paramInt)) {
      Handler handler = this.t;
      handler.sendMessage(handler.obtainMessage(5, paramInt, 0, paramb));
    } 
  }
  
  final void v(m paramm, int paramInt1, long paramLong, int paramInt2) {
    Handler handler = this.t;
    handler.sendMessage(handler.obtainMessage(18, new e0(paramm, paramInt1, paramLong, paramInt2)));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */