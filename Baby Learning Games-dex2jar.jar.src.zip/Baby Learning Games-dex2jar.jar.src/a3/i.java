package a3;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import androidx.annotation.RecentlyNonNull;
import androidx.annotation.RecentlyNullable;
import b3.c;
import b3.h;
import b3.o;
import com.google.android.gms.common.api.Scope;
import java.util.Collections;
import java.util.Set;
import y2.b;
import y2.d;
import z2.a;

public final class i implements a.f, ServiceConnection {
  private static final String l = i.class.getSimpleName();
  
  private final String a;
  
  private final String b;
  
  private final ComponentName c;
  
  private final Context d;
  
  private final d e;
  
  private final Handler f;
  
  private final j g;
  
  private IBinder h;
  
  private boolean i;
  
  private String j;
  
  private String k;
  
  private final void g() {
    if (Thread.currentThread() == this.f.getLooper().getThread())
      return; 
    throw new IllegalStateException("This method should only run on the NonGmsServiceBrokerClient's handler thread.");
  }
  
  private final void t(String paramString) {
    String.valueOf(this.h);
    paramString.length();
  }
  
  public final boolean a() {
    g();
    return (this.h != null);
  }
  
  public final void b(@RecentlyNonNull c.e parame) {}
  
  public final Set<Scope> c() {
    return Collections.emptySet();
  }
  
  public final void d(@RecentlyNonNull String paramString) {
    g();
    this.j = paramString;
    n();
  }
  
  public final void e(b3.i parami, Set<Scope> paramSet) {}
  
  public final boolean f() {
    return false;
  }
  
  public final int h() {
    return 0;
  }
  
  public final void i(@RecentlyNonNull c.c paramc) {
    g();
    t("Connect started.");
    if (a())
      try {
        d("connect() called when already connected");
      } catch (Exception exception) {} 
    try {
      Intent intent = new Intent();
      ComponentName componentName = this.c;
      if (componentName != null) {
        intent.setComponent(componentName);
      } else {
        intent.setPackage(this.a).setAction(this.b);
      } 
      boolean bool = this.d.bindService(intent, this, h.a());
      this.i = bool;
      if (!bool) {
        this.h = null;
        this.g.l0(new b(16));
      } 
      t("Finished connect.");
      return;
    } catch (SecurityException securityException) {
      this.i = false;
      this.h = null;
      throw securityException;
    } 
  }
  
  public final boolean j() {
    g();
    return this.i;
  }
  
  @RecentlyNonNull
  public final d[] k() {
    return new d[0];
  }
  
  @RecentlyNonNull
  public final String l() {
    String str = this.a;
    if (str != null)
      return str; 
    o.h(this.c);
    return this.c.getPackageName();
  }
  
  @RecentlyNullable
  public final String m() {
    return this.j;
  }
  
  public final void n() {
    g();
    t("Disconnect called.");
    try {
      this.d.unbindService(this);
    } catch (IllegalArgumentException illegalArgumentException) {}
    this.i = false;
    this.h = null;
  }
  
  public final boolean o() {
    return false;
  }
  
  public final void onServiceConnected(@RecentlyNonNull ComponentName paramComponentName, @RecentlyNonNull IBinder paramIBinder) {
    this.f.post(new f0(this, paramIBinder));
  }
  
  public final void onServiceDisconnected(@RecentlyNonNull ComponentName paramComponentName) {
    this.f.post(new h0(this));
  }
  
  public final void q(String paramString) {
    this.k = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a3\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */