package a3;

import java.util.Map;
import java.util.Set;
import s.a;
import t3.i;
import y2.b;
import z2.c;

public final class u0 {
  private final a<b<?>, b> a;
  
  private final a<b<?>, String> b;
  
  private final i<Map<b<?>, String>> c;
  
  private int d;
  
  private boolean e;
  
  public final Set<b<?>> a() {
    return this.a.keySet();
  }
  
  public final void b(b<?> paramb, b paramb1, String paramString) {
    this.a.put(paramb, paramb1);
    this.b.put(paramb, paramString);
    this.d--;
    if (!paramb1.p())
      this.e = true; 
    if (this.d == 0) {
      if (this.e) {
        c c = new c(this.a);
        this.c.b((Exception)c);
        return;
      } 
      this.c.c(this.b);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Learning Games-dex2jar.jar!\a\\u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */