package androidx.sqlite.db;

import java.io.Closeable;

public interface SupportSQLiteProgram extends Closeable {
  void bindBlob(int paramInt, byte[] paramArrayOfbyte);
  
  void bindDouble(int paramInt, double paramDouble);
  
  void bindLong(int paramInt, long paramLong);
  
  void bindNull(int paramInt);
  
  void bindString(int paramInt, String paramString);
  
  void clearBindings();
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\sqlite\db\SupportSQLiteProgram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */