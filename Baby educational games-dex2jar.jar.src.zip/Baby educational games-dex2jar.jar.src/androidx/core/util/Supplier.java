package androidx.core.util;

public interface Supplier<T> {
  T get();
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\cor\\util\Supplier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */