package androidx.core.app;

import android.app.Notification;

public interface NotificationBuilderWithBuilderAccessor {
  Notification.Builder getBuilder();
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\core\app\NotificationBuilderWithBuilderAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */