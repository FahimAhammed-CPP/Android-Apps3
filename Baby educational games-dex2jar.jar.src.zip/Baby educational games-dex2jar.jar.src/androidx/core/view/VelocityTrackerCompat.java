package androidx.core.view;

import android.view.VelocityTracker;

@Deprecated
public final class VelocityTrackerCompat {
  @Deprecated
  public static float getXVelocity(VelocityTracker paramVelocityTracker, int paramInt) {
    return paramVelocityTracker.getXVelocity(paramInt);
  }
  
  @Deprecated
  public static float getYVelocity(VelocityTracker paramVelocityTracker, int paramInt) {
    return paramVelocityTracker.getYVelocity(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\core\view\VelocityTrackerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */