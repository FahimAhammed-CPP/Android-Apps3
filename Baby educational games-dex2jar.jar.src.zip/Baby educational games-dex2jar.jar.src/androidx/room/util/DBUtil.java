package androidx.room.util;

import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.os.Build;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteQuery;
import java.util.ArrayList;

public class DBUtil {
  public static void dropFtsSyncTriggers(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    ArrayList<String> arrayList = new ArrayList();
    Cursor cursor = paramSupportSQLiteDatabase.query("SELECT name FROM sqlite_master WHERE type = 'trigger'");
    try {
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      cursor.close();
      return;
    } finally {
      cursor.close();
    } 
  }
  
  public static Cursor query(RoomDatabase paramRoomDatabase, SupportSQLiteQuery paramSupportSQLiteQuery, boolean paramBoolean) {
    AbstractWindowedCursor abstractWindowedCursor;
    Cursor cursor = paramRoomDatabase.query(paramSupportSQLiteQuery);
    null = cursor;
    if (paramBoolean) {
      null = cursor;
      if (cursor instanceof AbstractWindowedCursor) {
        int i;
        abstractWindowedCursor = (AbstractWindowedCursor)cursor;
        int j = abstractWindowedCursor.getCount();
        if (abstractWindowedCursor.hasWindow()) {
          i = abstractWindowedCursor.getWindow().getNumRows();
        } else {
          i = j;
        } 
        if (Build.VERSION.SDK_INT >= 23) {
          null = cursor;
          return (i < j) ? CursorUtil.copyAndClose((Cursor)abstractWindowedCursor) : null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return CursorUtil.copyAndClose((Cursor)abstractWindowedCursor);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\roo\\util\DBUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */