package androidx.room;

public class FtsOptions {
  public static final String TOKENIZER_ICU = "icu";
  
  public static final String TOKENIZER_PORTER = "porter";
  
  public static final String TOKENIZER_SIMPLE = "simple";
  
  public static final String TOKENIZER_UNICODE61 = "unicode61";
  
  public enum MatchInfo {
    FTS3, FTS4;
    
    static {
    
    }
  }
  
  public enum Order {
    ASC, DESC;
    
    static {
    
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\room\FtsOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */