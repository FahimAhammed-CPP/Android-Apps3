package androidx.room;

import androidx.sqlite.db.SupportSQLiteStatement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public abstract class EntityInsertionAdapter<T> extends SharedSQLiteStatement {
  public EntityInsertionAdapter(RoomDatabase paramRoomDatabase) {
    super(paramRoomDatabase);
  }
  
  protected abstract void bind(SupportSQLiteStatement paramSupportSQLiteStatement, T paramT);
  
  public final void insert(Iterable<T> paramIterable) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      Iterator<T> iterator = paramIterable.iterator();
      while (iterator.hasNext()) {
        bind(supportSQLiteStatement, iterator.next());
        supportSQLiteStatement.executeInsert();
      } 
      return;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final void insert(T paramT) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      bind(supportSQLiteStatement, paramT);
      supportSQLiteStatement.executeInsert();
      return;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final void insert(T[] paramArrayOfT) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      int j = paramArrayOfT.length;
      for (int i = 0; i < j; i++) {
        bind(supportSQLiteStatement, paramArrayOfT[i]);
        supportSQLiteStatement.executeInsert();
      } 
      return;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final long insertAndReturnId(T paramT) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      bind(supportSQLiteStatement, paramT);
      return supportSQLiteStatement.executeInsert();
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final long[] insertAndReturnIdsArray(Collection<T> paramCollection) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      long[] arrayOfLong = new long[paramCollection.size()];
      int i = 0;
      Iterator<T> iterator = paramCollection.iterator();
      while (iterator.hasNext()) {
        bind(supportSQLiteStatement, iterator.next());
        arrayOfLong[i] = supportSQLiteStatement.executeInsert();
        i++;
      } 
      return arrayOfLong;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final long[] insertAndReturnIdsArray(T[] paramArrayOfT) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      long[] arrayOfLong = new long[paramArrayOfT.length];
      int k = paramArrayOfT.length;
      int i = 0;
      int j = 0;
      while (i < k) {
        bind(supportSQLiteStatement, paramArrayOfT[i]);
        arrayOfLong[j] = supportSQLiteStatement.executeInsert();
        j++;
        i++;
      } 
      return arrayOfLong;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final Long[] insertAndReturnIdsArrayBox(Collection<T> paramCollection) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      Long[] arrayOfLong = new Long[paramCollection.size()];
      int i = 0;
      Iterator<T> iterator = paramCollection.iterator();
      while (iterator.hasNext()) {
        bind(supportSQLiteStatement, iterator.next());
        arrayOfLong[i] = Long.valueOf(supportSQLiteStatement.executeInsert());
        i++;
      } 
      return arrayOfLong;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final Long[] insertAndReturnIdsArrayBox(T[] paramArrayOfT) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      Long[] arrayOfLong = new Long[paramArrayOfT.length];
      int k = paramArrayOfT.length;
      int i = 0;
      int j = 0;
      while (i < k) {
        bind(supportSQLiteStatement, paramArrayOfT[i]);
        arrayOfLong[j] = Long.valueOf(supportSQLiteStatement.executeInsert());
        j++;
        i++;
      } 
      return arrayOfLong;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final List<Long> insertAndReturnIdsList(Collection<T> paramCollection) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      ArrayList<Long> arrayList = new ArrayList(paramCollection.size());
      int i = 0;
      Iterator<T> iterator = paramCollection.iterator();
      while (iterator.hasNext()) {
        bind(supportSQLiteStatement, iterator.next());
        arrayList.add(i, Long.valueOf(supportSQLiteStatement.executeInsert()));
        i++;
      } 
      return arrayList;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
  
  public final List<Long> insertAndReturnIdsList(T[] paramArrayOfT) {
    SupportSQLiteStatement supportSQLiteStatement = acquire();
    try {
      ArrayList<Long> arrayList = new ArrayList(paramArrayOfT.length);
      int k = paramArrayOfT.length;
      int i = 0;
      int j = 0;
      while (i < k) {
        bind(supportSQLiteStatement, paramArrayOfT[i]);
        arrayList.add(j, Long.valueOf(supportSQLiteStatement.executeInsert()));
        j++;
        i++;
      } 
      return arrayList;
    } finally {
      release(supportSQLiteStatement);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\room\EntityInsertionAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */