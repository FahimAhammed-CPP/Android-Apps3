package androidx.room;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import androidx.arch.core.internal.SafeIterableMap;
import androidx.collection.ArrayMap;
import androidx.collection.ArraySet;
import androidx.lifecycle.LiveData;
import androidx.sqlite.db.SimpleSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;

public class InvalidationTracker {
  private static final String CREATE_TRACKING_TABLE_SQL = "CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)";
  
  private static final String INVALIDATED_COLUMN_NAME = "invalidated";
  
  static final String RESET_UPDATED_TABLES_SQL = "UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 ";
  
  static final String SELECT_UPDATED_TABLES_SQL = "SELECT * FROM room_table_modification_log WHERE invalidated = 1;";
  
  private static final String TABLE_ID_COLUMN_NAME = "table_id";
  
  private static final String[] TRIGGERS = new String[] { "UPDATE", "DELETE", "INSERT" };
  
  private static final String UPDATE_TABLE_NAME = "room_table_modification_log";
  
  volatile SupportSQLiteStatement mCleanupStatement;
  
  final RoomDatabase mDatabase;
  
  private volatile boolean mInitialized;
  
  private final InvalidationLiveDataContainer mInvalidationLiveDataContainer;
  
  private MultiInstanceInvalidationClient mMultiInstanceInvalidationClient;
  
  private ObservedTableTracker mObservedTableTracker;
  
  final SafeIterableMap<Observer, ObserverWrapper> mObserverMap;
  
  AtomicBoolean mPendingRefresh;
  
  Runnable mRefreshRunnable;
  
  final ArrayMap<String, Integer> mTableIdLookup;
  
  final String[] mTableNames;
  
  private Map<String, Set<String>> mViewTables;
  
  public InvalidationTracker(RoomDatabase paramRoomDatabase, Map<String, String> paramMap, Map<String, Set<String>> paramMap1, String... paramVarArgs) {
    int i = 0;
    this.mPendingRefresh = new AtomicBoolean(false);
    this.mInitialized = false;
    this.mObserverMap = new SafeIterableMap();
    this.mRefreshRunnable = new Runnable() {
        private Set<Integer> checkUpdatedTable() {
          null = new ArraySet();
          Cursor cursor = InvalidationTracker.this.mDatabase.query((SupportSQLiteQuery)new SimpleSQLiteQuery("SELECT * FROM room_table_modification_log WHERE invalidated = 1;"));
          try {
            while (cursor.moveToNext())
              null.add(Integer.valueOf(cursor.getInt(0))); 
            cursor.close();
            return (Set<Integer>)null;
          } finally {
            cursor.close();
          } 
        }
        
        public void run() {
          Lock lock = InvalidationTracker.this.mDatabase.getCloseLock();
          Set<Integer> set4 = null;
          Set<Integer> set5 = null;
          Set<Integer> set3 = null;
          Set<Integer> set2 = set4;
          Set<Integer> set1 = set5;
          try {
            lock.lock();
            set2 = set4;
            set1 = set5;
            boolean bool = InvalidationTracker.this.ensureInitialization();
            if (!bool) {
              lock.unlock();
              return;
            } 
            set2 = set4;
            set1 = set5;
            bool = InvalidationTracker.this.mPendingRefresh.compareAndSet(true, false);
            if (!bool) {
              lock.unlock();
              return;
            } 
            set2 = set4;
            set1 = set5;
            bool = InvalidationTracker.this.mDatabase.inTransaction();
            if (bool) {
              lock.unlock();
              return;
            } 
            set2 = set4;
            set1 = set5;
            if (InvalidationTracker.this.mDatabase.mWriteAheadLoggingEnabled) {
              set2 = set4;
              set1 = set5;
              SupportSQLiteDatabase supportSQLiteDatabase = InvalidationTracker.this.mDatabase.getOpenHelper().getWritableDatabase();
              set2 = set4;
              set1 = set5;
              supportSQLiteDatabase.beginTransaction();
              try {
                set4 = checkUpdatedTable();
                set3 = set4;
              } finally {
                set2 = set3;
                set1 = set3;
                supportSQLiteDatabase.endTransaction();
                set2 = set3;
                set1 = set3;
              } 
            } else {
              set2 = set4;
              set1 = set5;
              set3 = checkUpdatedTable();
              set1 = set3;
            } 
          } catch (IllegalStateException illegalStateException) {
            Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", illegalStateException);
          } catch (SQLiteException sQLiteException2) {
            IllegalStateException illegalStateException1 = illegalStateException;
            SQLiteException sQLiteException1 = sQLiteException2;
          } finally {}
          lock.unlock();
          if (set1 != null && !set1.isEmpty())
            synchronized (InvalidationTracker.this.mObserverMap) {
              Iterator<Map.Entry> iterator = InvalidationTracker.this.mObserverMap.iterator();
              while (iterator.hasNext())
                ((InvalidationTracker.ObserverWrapper)((Map.Entry)iterator.next()).getValue()).notifyByTableInvalidStatus(set1); 
              return;
            }  
        }
      };
    this.mDatabase = paramRoomDatabase;
    this.mObservedTableTracker = new ObservedTableTracker(paramVarArgs.length);
    this.mTableIdLookup = new ArrayMap();
    this.mViewTables = paramMap1;
    this.mInvalidationLiveDataContainer = new InvalidationLiveDataContainer(this.mDatabase);
    int j = paramVarArgs.length;
    this.mTableNames = new String[j];
    while (i < j) {
      String str1 = paramVarArgs[i].toLowerCase(Locale.US);
      this.mTableIdLookup.put(str1, Integer.valueOf(i));
      String str2 = paramMap.get(paramVarArgs[i]);
      if (str2 != null) {
        this.mTableNames[i] = str2.toLowerCase(Locale.US);
      } else {
        this.mTableNames[i] = str1;
      } 
      i++;
    } 
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      String str = ((String)entry.getValue()).toLowerCase(Locale.US);
      if (this.mTableIdLookup.containsKey(str)) {
        String str1 = ((String)entry.getKey()).toLowerCase(Locale.US);
        ArrayMap<String, Integer> arrayMap = this.mTableIdLookup;
        arrayMap.put(str1, arrayMap.get(str));
      } 
    } 
  }
  
  public InvalidationTracker(RoomDatabase paramRoomDatabase, String... paramVarArgs) {
    this(paramRoomDatabase, new HashMap<String, String>(), Collections.emptyMap(), paramVarArgs);
  }
  
  private static void appendTriggerName(StringBuilder paramStringBuilder, String paramString1, String paramString2) {
    paramStringBuilder.append("`");
    paramStringBuilder.append("room_table_modification_trigger_");
    paramStringBuilder.append(paramString1);
    paramStringBuilder.append("_");
    paramStringBuilder.append(paramString2);
    paramStringBuilder.append("`");
  }
  
  private String[] resolveViews(String[] paramArrayOfString) {
    ArraySet<String> arraySet = new ArraySet();
    int j = paramArrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str1 = paramArrayOfString[i];
      String str2 = str1.toLowerCase(Locale.US);
      if (this.mViewTables.containsKey(str2)) {
        arraySet.addAll(this.mViewTables.get(str2));
      } else {
        arraySet.add(str1);
      } 
    } 
    return arraySet.<String>toArray(new String[arraySet.size()]);
  }
  
  private void startTrackingTable(SupportSQLiteDatabase paramSupportSQLiteDatabase, int paramInt) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("INSERT OR IGNORE INTO room_table_modification_log VALUES(");
    stringBuilder1.append(paramInt);
    stringBuilder1.append(", 0)");
    paramSupportSQLiteDatabase.execSQL(stringBuilder1.toString());
    String str = this.mTableNames[paramInt];
    StringBuilder stringBuilder2 = new StringBuilder();
    for (String str1 : TRIGGERS) {
      stringBuilder2.setLength(0);
      stringBuilder2.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
      appendTriggerName(stringBuilder2, str, str1);
      stringBuilder2.append(" AFTER ");
      stringBuilder2.append(str1);
      stringBuilder2.append(" ON `");
      stringBuilder2.append(str);
      stringBuilder2.append("` BEGIN UPDATE ");
      stringBuilder2.append("room_table_modification_log");
      stringBuilder2.append(" SET ");
      stringBuilder2.append("invalidated");
      stringBuilder2.append(" = 1");
      stringBuilder2.append(" WHERE ");
      stringBuilder2.append("table_id");
      stringBuilder2.append(" = ");
      stringBuilder2.append(paramInt);
      stringBuilder2.append(" AND ");
      stringBuilder2.append("invalidated");
      stringBuilder2.append(" = 0");
      stringBuilder2.append("; END");
      paramSupportSQLiteDatabase.execSQL(stringBuilder2.toString());
    } 
  }
  
  private void stopTrackingTable(SupportSQLiteDatabase paramSupportSQLiteDatabase, int paramInt) {
    String str = this.mTableNames[paramInt];
    StringBuilder stringBuilder = new StringBuilder();
    String[] arrayOfString = TRIGGERS;
    int i = arrayOfString.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      String str1 = arrayOfString[paramInt];
      stringBuilder.setLength(0);
      stringBuilder.append("DROP TRIGGER IF EXISTS ");
      appendTriggerName(stringBuilder, str, str1);
      paramSupportSQLiteDatabase.execSQL(stringBuilder.toString());
    } 
  }
  
  private String[] validateAndResolveTableNames(String[] paramArrayOfString) {
    StringBuilder stringBuilder;
    String[] arrayOfString = resolveViews(paramArrayOfString);
    int j = arrayOfString.length;
    int i = 0;
    while (i < j) {
      String str = arrayOfString[i];
      if (this.mTableIdLookup.containsKey(str.toLowerCase(Locale.US))) {
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("There is no table with name ");
      stringBuilder.append(str);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return (String[])stringBuilder;
  }
  
  public void addObserver(Observer paramObserver) {
    String[] arrayOfString = resolveViews(paramObserver.mTables);
    int[] arrayOfInt = new int[arrayOfString.length];
    int j = arrayOfString.length;
    int i = 0;
    while (i < j) {
      Integer integer = (Integer)this.mTableIdLookup.get(arrayOfString[i].toLowerCase(Locale.US));
      if (integer != null) {
        arrayOfInt[i] = integer.intValue();
        i++;
        continue;
      } 
      null = new StringBuilder();
      null.append("There is no table with name ");
      null.append(arrayOfString[i]);
      throw new IllegalArgumentException(null.toString());
    } 
    ObserverWrapper observerWrapper = new ObserverWrapper((Observer)null, arrayOfInt, arrayOfString);
    synchronized (this.mObserverMap) {
      ObserverWrapper observerWrapper1 = (ObserverWrapper)this.mObserverMap.putIfAbsent(null, observerWrapper);
      if (observerWrapper1 == null && this.mObservedTableTracker.onAdded(arrayOfInt))
        syncTriggers(); 
      return;
    } 
  }
  
  public void addWeakObserver(Observer paramObserver) {
    addObserver(new WeakObserver(this, paramObserver));
  }
  
  @Deprecated
  public <T> LiveData<T> createLiveData(String[] paramArrayOfString, Callable<T> paramCallable) {
    return createLiveData(paramArrayOfString, false, paramCallable);
  }
  
  public <T> LiveData<T> createLiveData(String[] paramArrayOfString, boolean paramBoolean, Callable<T> paramCallable) {
    return this.mInvalidationLiveDataContainer.create(validateAndResolveTableNames(paramArrayOfString), paramBoolean, paramCallable);
  }
  
  boolean ensureInitialization() {
    if (!this.mDatabase.isOpen())
      return false; 
    if (!this.mInitialized)
      this.mDatabase.getOpenHelper().getWritableDatabase(); 
    if (!this.mInitialized) {
      Log.e("ROOM", "database is not initialized even though it is open");
      return false;
    } 
    return true;
  }
  
  void internalInit(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mInitialized : Z
    //   6: ifeq -> 22
    //   9: ldc_w 'ROOM'
    //   12: ldc_w 'Invalidation tracker is initialized twice :/.'
    //   15: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_1
    //   23: ldc_w 'PRAGMA temp_store = MEMORY;'
    //   26: invokeinterface execSQL : (Ljava/lang/String;)V
    //   31: aload_1
    //   32: ldc_w 'PRAGMA recursive_triggers='ON';'
    //   35: invokeinterface execSQL : (Ljava/lang/String;)V
    //   40: aload_1
    //   41: ldc 'CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)'
    //   43: invokeinterface execSQL : (Ljava/lang/String;)V
    //   48: aload_0
    //   49: aload_1
    //   50: invokevirtual syncTriggers : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   53: aload_0
    //   54: aload_1
    //   55: ldc 'UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 '
    //   57: invokeinterface compileStatement : (Ljava/lang/String;)Landroidx/sqlite/db/SupportSQLiteStatement;
    //   62: putfield mCleanupStatement : Landroidx/sqlite/db/SupportSQLiteStatement;
    //   65: aload_0
    //   66: iconst_1
    //   67: putfield mInitialized : Z
    //   70: aload_0
    //   71: monitorexit
    //   72: return
    //   73: astore_1
    //   74: aload_0
    //   75: monitorexit
    //   76: aload_1
    //   77: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	73	finally
    //   22	72	73	finally
    //   74	76	73	finally
  }
  
  public void notifyObserversByTableNames(String... paramVarArgs) {
    synchronized (this.mObserverMap) {
      for (Map.Entry entry : this.mObserverMap) {
        if (!((Observer)entry.getKey()).isRemote())
          ((ObserverWrapper)entry.getValue()).notifyByTableNames(paramVarArgs); 
      } 
      return;
    } 
  }
  
  public void refreshVersionsAsync() {
    if (this.mPendingRefresh.compareAndSet(false, true))
      this.mDatabase.getQueryExecutor().execute(this.mRefreshRunnable); 
  }
  
  public void refreshVersionsSync() {
    syncTriggers();
    this.mRefreshRunnable.run();
  }
  
  public void removeObserver(Observer paramObserver) {
    synchronized (this.mObserverMap) {
      ObserverWrapper observerWrapper = (ObserverWrapper)this.mObserverMap.remove(paramObserver);
      if (observerWrapper != null && this.mObservedTableTracker.onRemoved(observerWrapper.mTableIds))
        syncTriggers(); 
      return;
    } 
  }
  
  void startMultiInstanceInvalidation(Context paramContext, String paramString) {
    this.mMultiInstanceInvalidationClient = new MultiInstanceInvalidationClient(paramContext, paramString, this, this.mDatabase.getQueryExecutor());
  }
  
  void stopMultiInstanceInvalidation() {
    MultiInstanceInvalidationClient multiInstanceInvalidationClient = this.mMultiInstanceInvalidationClient;
    if (multiInstanceInvalidationClient != null) {
      multiInstanceInvalidationClient.stop();
      this.mMultiInstanceInvalidationClient = null;
    } 
  }
  
  void syncTriggers() {
    if (!this.mDatabase.isOpen())
      return; 
    syncTriggers(this.mDatabase.getOpenHelper().getWritableDatabase());
  }
  
  void syncTriggers(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    if (paramSupportSQLiteDatabase.inTransaction())
      return; 
    label38: while (true) {
      try {
        Lock lock = this.mDatabase.getCloseLock();
        lock.lock();
        try {
          int i;
          int[] arrayOfInt = this.mObservedTableTracker.getTablesToSync();
          if (arrayOfInt == null)
            return; 
          int j = arrayOfInt.length;
          paramSupportSQLiteDatabase.beginTransaction();
        } finally {
          lock.unlock();
        } 
        break;
      } catch (IllegalStateException illegalStateException) {
      
      } catch (SQLiteException sQLiteException) {}
      Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", (Throwable)sQLiteException);
      return;
    } 
  }
  
  static class ObservedTableTracker {
    static final int ADD = 1;
    
    static final int NO_OP = 0;
    
    static final int REMOVE = 2;
    
    boolean mNeedsSync;
    
    boolean mPendingSync;
    
    final long[] mTableObservers;
    
    final int[] mTriggerStateChanges;
    
    final boolean[] mTriggerStates;
    
    ObservedTableTracker(int param1Int) {
      this.mTableObservers = new long[param1Int];
      this.mTriggerStates = new boolean[param1Int];
      this.mTriggerStateChanges = new int[param1Int];
      Arrays.fill(this.mTableObservers, 0L);
      Arrays.fill(this.mTriggerStates, false);
    }
    
    int[] getTablesToSync() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield mNeedsSync : Z
      //   6: ifeq -> 119
      //   9: aload_0
      //   10: getfield mPendingSync : Z
      //   13: ifeq -> 19
      //   16: goto -> 119
      //   19: aload_0
      //   20: getfield mTableObservers : [J
      //   23: arraylength
      //   24: istore_3
      //   25: iconst_0
      //   26: istore_1
      //   27: iconst_1
      //   28: istore_2
      //   29: iload_1
      //   30: iload_3
      //   31: if_icmpge -> 98
      //   34: aload_0
      //   35: getfield mTableObservers : [J
      //   38: iload_1
      //   39: laload
      //   40: lconst_0
      //   41: lcmp
      //   42: ifle -> 136
      //   45: iconst_1
      //   46: istore #4
      //   48: goto -> 51
      //   51: iload #4
      //   53: aload_0
      //   54: getfield mTriggerStates : [Z
      //   57: iload_1
      //   58: baload
      //   59: if_icmpeq -> 76
      //   62: aload_0
      //   63: getfield mTriggerStateChanges : [I
      //   66: astore #5
      //   68: iload #4
      //   70: ifeq -> 142
      //   73: goto -> 144
      //   76: aload_0
      //   77: getfield mTriggerStateChanges : [I
      //   80: iload_1
      //   81: iconst_0
      //   82: iastore
      //   83: aload_0
      //   84: getfield mTriggerStates : [Z
      //   87: iload_1
      //   88: iload #4
      //   90: bastore
      //   91: iload_1
      //   92: iconst_1
      //   93: iadd
      //   94: istore_1
      //   95: goto -> 27
      //   98: aload_0
      //   99: iconst_1
      //   100: putfield mPendingSync : Z
      //   103: aload_0
      //   104: iconst_0
      //   105: putfield mNeedsSync : Z
      //   108: aload_0
      //   109: getfield mTriggerStateChanges : [I
      //   112: astore #5
      //   114: aload_0
      //   115: monitorexit
      //   116: aload #5
      //   118: areturn
      //   119: aload_0
      //   120: monitorexit
      //   121: aconst_null
      //   122: areturn
      //   123: astore #5
      //   125: aload_0
      //   126: monitorexit
      //   127: goto -> 133
      //   130: aload #5
      //   132: athrow
      //   133: goto -> 130
      //   136: iconst_0
      //   137: istore #4
      //   139: goto -> 51
      //   142: iconst_2
      //   143: istore_2
      //   144: aload #5
      //   146: iload_1
      //   147: iload_2
      //   148: iastore
      //   149: goto -> 83
      // Exception table:
      //   from	to	target	type
      //   2	16	123	finally
      //   19	25	123	finally
      //   34	45	123	finally
      //   51	68	123	finally
      //   76	83	123	finally
      //   83	91	123	finally
      //   98	116	123	finally
      //   119	121	123	finally
      //   125	127	123	finally
    }
    
    boolean onAdded(int... param1VarArgs) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: arraylength
      //   4: istore_3
      //   5: iconst_0
      //   6: istore_2
      //   7: iconst_0
      //   8: istore #5
      //   10: iload_2
      //   11: iload_3
      //   12: if_icmpge -> 58
      //   15: aload_1
      //   16: iload_2
      //   17: iaload
      //   18: istore #4
      //   20: aload_0
      //   21: getfield mTableObservers : [J
      //   24: iload #4
      //   26: laload
      //   27: lstore #6
      //   29: aload_0
      //   30: getfield mTableObservers : [J
      //   33: iload #4
      //   35: lconst_1
      //   36: lload #6
      //   38: ladd
      //   39: lastore
      //   40: lload #6
      //   42: lconst_0
      //   43: lcmp
      //   44: ifne -> 74
      //   47: aload_0
      //   48: iconst_1
      //   49: putfield mNeedsSync : Z
      //   52: iconst_1
      //   53: istore #5
      //   55: goto -> 74
      //   58: aload_0
      //   59: monitorexit
      //   60: iload #5
      //   62: ireturn
      //   63: astore_1
      //   64: aload_0
      //   65: monitorexit
      //   66: goto -> 71
      //   69: aload_1
      //   70: athrow
      //   71: goto -> 69
      //   74: iload_2
      //   75: iconst_1
      //   76: iadd
      //   77: istore_2
      //   78: goto -> 10
      // Exception table:
      //   from	to	target	type
      //   2	5	63	finally
      //   20	40	63	finally
      //   47	52	63	finally
      //   58	60	63	finally
      //   64	66	63	finally
    }
    
    boolean onRemoved(int... param1VarArgs) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: arraylength
      //   4: istore_3
      //   5: iconst_0
      //   6: istore_2
      //   7: iconst_0
      //   8: istore #5
      //   10: iload_2
      //   11: iload_3
      //   12: if_icmpge -> 58
      //   15: aload_1
      //   16: iload_2
      //   17: iaload
      //   18: istore #4
      //   20: aload_0
      //   21: getfield mTableObservers : [J
      //   24: iload #4
      //   26: laload
      //   27: lstore #6
      //   29: aload_0
      //   30: getfield mTableObservers : [J
      //   33: iload #4
      //   35: lload #6
      //   37: lconst_1
      //   38: lsub
      //   39: lastore
      //   40: lload #6
      //   42: lconst_1
      //   43: lcmp
      //   44: ifne -> 74
      //   47: aload_0
      //   48: iconst_1
      //   49: putfield mNeedsSync : Z
      //   52: iconst_1
      //   53: istore #5
      //   55: goto -> 74
      //   58: aload_0
      //   59: monitorexit
      //   60: iload #5
      //   62: ireturn
      //   63: astore_1
      //   64: aload_0
      //   65: monitorexit
      //   66: goto -> 71
      //   69: aload_1
      //   70: athrow
      //   71: goto -> 69
      //   74: iload_2
      //   75: iconst_1
      //   76: iadd
      //   77: istore_2
      //   78: goto -> 10
      // Exception table:
      //   from	to	target	type
      //   2	5	63	finally
      //   20	40	63	finally
      //   47	52	63	finally
      //   58	60	63	finally
      //   64	66	63	finally
    }
    
    void onSyncCompleted() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: iconst_0
      //   4: putfield mPendingSync : Z
      //   7: aload_0
      //   8: monitorexit
      //   9: return
      //   10: astore_1
      //   11: aload_0
      //   12: monitorexit
      //   13: aload_1
      //   14: athrow
      // Exception table:
      //   from	to	target	type
      //   2	9	10	finally
      //   11	13	10	finally
    }
  }
  
  public static abstract class Observer {
    final String[] mTables;
    
    protected Observer(String param1String, String... param1VarArgs) {
      this.mTables = Arrays.<String>copyOf(param1VarArgs, param1VarArgs.length + 1);
      this.mTables[param1VarArgs.length] = param1String;
    }
    
    public Observer(String[] param1ArrayOfString) {
      this.mTables = Arrays.<String>copyOf(param1ArrayOfString, param1ArrayOfString.length);
    }
    
    boolean isRemote() {
      return false;
    }
    
    public abstract void onInvalidated(Set<String> param1Set);
  }
  
  static class ObserverWrapper {
    final InvalidationTracker.Observer mObserver;
    
    private final Set<String> mSingleTableSet;
    
    final int[] mTableIds;
    
    private final String[] mTableNames;
    
    ObserverWrapper(InvalidationTracker.Observer param1Observer, int[] param1ArrayOfint, String[] param1ArrayOfString) {
      this.mObserver = param1Observer;
      this.mTableIds = param1ArrayOfint;
      this.mTableNames = param1ArrayOfString;
      if (param1ArrayOfint.length == 1) {
        ArraySet arraySet = new ArraySet();
        arraySet.add(this.mTableNames[0]);
        this.mSingleTableSet = Collections.unmodifiableSet((Set<? extends String>)arraySet);
        return;
      } 
      this.mSingleTableSet = null;
    }
    
    void notifyByTableInvalidStatus(Set<Integer> param1Set) {
      ArraySet<String> arraySet;
      int j = this.mTableIds.length;
      Set<String> set = null;
      int i = 0;
      while (i < j) {
        ArraySet<String> arraySet1;
        Set<String> set1 = set;
        if (param1Set.contains(Integer.valueOf(this.mTableIds[i])))
          if (j == 1) {
            set1 = this.mSingleTableSet;
          } else {
            set1 = set;
            if (set == null)
              arraySet1 = new ArraySet(j); 
            arraySet1.add(this.mTableNames[i]);
          }  
        i++;
        arraySet = arraySet1;
      } 
      if (arraySet != null)
        this.mObserver.onInvalidated((Set<String>)arraySet); 
    }
    
    void notifyByTableNames(String[] param1ArrayOfString) {
      ArraySet arraySet;
      int i = this.mTableNames.length;
      Set<String> set = null;
      if (i == 1) {
        int j = param1ArrayOfString.length;
        i = 0;
        while (true) {
          Set<String> set1 = set;
          if (i < j) {
            if (param1ArrayOfString[i].equalsIgnoreCase(this.mTableNames[0])) {
              set1 = this.mSingleTableSet;
              break;
            } 
            i++;
            continue;
          } 
          break;
        } 
      } else {
        ArraySet arraySet1 = new ArraySet();
        int j = param1ArrayOfString.length;
        for (i = 0; i < j; i++) {
          String str = param1ArrayOfString[i];
          for (String str1 : this.mTableNames) {
            if (str1.equalsIgnoreCase(str)) {
              arraySet1.add(str1);
              break;
            } 
          } 
        } 
        Set<String> set1 = set;
        if (arraySet1.size() > 0)
          arraySet = arraySet1; 
      } 
      if (arraySet != null)
        this.mObserver.onInvalidated((Set<String>)arraySet); 
    }
  }
  
  static class WeakObserver extends Observer {
    final WeakReference<InvalidationTracker.Observer> mDelegateRef;
    
    final InvalidationTracker mTracker;
    
    WeakObserver(InvalidationTracker param1InvalidationTracker, InvalidationTracker.Observer param1Observer) {
      super(param1Observer.mTables);
      this.mTracker = param1InvalidationTracker;
      this.mDelegateRef = new WeakReference<InvalidationTracker.Observer>(param1Observer);
    }
    
    public void onInvalidated(Set<String> param1Set) {
      InvalidationTracker.Observer observer = this.mDelegateRef.get();
      if (observer == null) {
        this.mTracker.removeObserver(this);
        return;
      } 
      observer.onInvalidated(param1Set);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\room\InvalidationTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */