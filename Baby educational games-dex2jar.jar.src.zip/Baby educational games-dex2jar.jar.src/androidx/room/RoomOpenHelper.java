package androidx.room;

import android.database.Cursor;
import androidx.sqlite.db.SimpleSQLiteQuery;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import androidx.sqlite.db.SupportSQLiteQuery;

public class RoomOpenHelper extends SupportSQLiteOpenHelper.Callback {
  private DatabaseConfiguration mConfiguration;
  
  private final Delegate mDelegate;
  
  private final String mIdentityHash;
  
  private final String mLegacyHash;
  
  public RoomOpenHelper(DatabaseConfiguration paramDatabaseConfiguration, Delegate paramDelegate, String paramString) {
    this(paramDatabaseConfiguration, paramDelegate, "", paramString);
  }
  
  public RoomOpenHelper(DatabaseConfiguration paramDatabaseConfiguration, Delegate paramDelegate, String paramString1, String paramString2) {
    super(paramDelegate.version);
    this.mConfiguration = paramDatabaseConfiguration;
    this.mDelegate = paramDelegate;
    this.mIdentityHash = paramString1;
    this.mLegacyHash = paramString2;
  }
  
  private void checkIdentity(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    String str;
    boolean bool = hasRoomMasterTable(paramSupportSQLiteDatabase);
    Cursor cursor = null;
    SupportSQLiteDatabase supportSQLiteDatabase = null;
    if (bool) {
      cursor = paramSupportSQLiteDatabase.query((SupportSQLiteQuery)new SimpleSQLiteQuery("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"));
      paramSupportSQLiteDatabase = supportSQLiteDatabase;
      try {
        String str1;
        if (cursor.moveToFirst())
          str1 = cursor.getString(0); 
        cursor.close();
      } finally {
        str.close();
      } 
    } 
    if (!this.mIdentityHash.equals(str)) {
      if (this.mLegacyHash.equals(str))
        return; 
      throw new IllegalStateException("Room cannot verify the data integrity. Looks like you've changed schema but forgot to update the version number. You can simply fix this by increasing the version number.");
    } 
  }
  
  private void createMasterTableIfNotExists(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    paramSupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
  }
  
  private static boolean hasRoomMasterTable(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    Cursor cursor = paramSupportSQLiteDatabase.query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
    try {
      boolean bool = cursor.moveToFirst();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        int i = cursor.getInt(0);
        bool1 = bool2;
        if (i != 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
    } 
  }
  
  private void updateIdentity(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    createMasterTableIfNotExists(paramSupportSQLiteDatabase);
    paramSupportSQLiteDatabase.execSQL(RoomMasterTable.createInsertQuery(this.mIdentityHash));
  }
  
  public void onConfigure(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    super.onConfigure(paramSupportSQLiteDatabase);
  }
  
  public void onCreate(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    updateIdentity(paramSupportSQLiteDatabase);
    this.mDelegate.createAllTables(paramSupportSQLiteDatabase);
    this.mDelegate.onCreate(paramSupportSQLiteDatabase);
  }
  
  public void onDowngrade(SupportSQLiteDatabase paramSupportSQLiteDatabase, int paramInt1, int paramInt2) {
    onUpgrade(paramSupportSQLiteDatabase, paramInt1, paramInt2);
  }
  
  public void onOpen(SupportSQLiteDatabase paramSupportSQLiteDatabase) {
    super.onOpen(paramSupportSQLiteDatabase);
    checkIdentity(paramSupportSQLiteDatabase);
    this.mDelegate.onOpen(paramSupportSQLiteDatabase);
    this.mConfiguration = null;
  }
  
  public void onUpgrade(SupportSQLiteDatabase paramSupportSQLiteDatabase, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mConfiguration : Landroidx/room/DatabaseConfiguration;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnull -> 99
    //   11: aload #5
    //   13: getfield migrationContainer : Landroidx/room/RoomDatabase$MigrationContainer;
    //   16: iload_2
    //   17: iload_3
    //   18: invokevirtual findMigrationPath : (II)Ljava/util/List;
    //   21: astore #5
    //   23: aload #5
    //   25: ifnull -> 99
    //   28: aload_0
    //   29: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   32: aload_1
    //   33: invokevirtual onPreMigrate : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   36: aload #5
    //   38: invokeinterface iterator : ()Ljava/util/Iterator;
    //   43: astore #5
    //   45: aload #5
    //   47: invokeinterface hasNext : ()Z
    //   52: ifeq -> 72
    //   55: aload #5
    //   57: invokeinterface next : ()Ljava/lang/Object;
    //   62: checkcast androidx/room/migration/Migration
    //   65: aload_1
    //   66: invokevirtual migrate : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   69: goto -> 45
    //   72: aload_0
    //   73: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   76: aload_1
    //   77: invokevirtual validateMigration : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   80: aload_0
    //   81: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   84: aload_1
    //   85: invokevirtual onPostMigrate : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   88: aload_0
    //   89: aload_1
    //   90: invokespecial updateIdentity : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   93: iconst_1
    //   94: istore #4
    //   96: goto -> 102
    //   99: iconst_0
    //   100: istore #4
    //   102: iload #4
    //   104: ifne -> 198
    //   107: aload_0
    //   108: getfield mConfiguration : Landroidx/room/DatabaseConfiguration;
    //   111: astore #5
    //   113: aload #5
    //   115: ifnull -> 145
    //   118: aload #5
    //   120: iload_2
    //   121: iload_3
    //   122: invokevirtual isMigrationRequired : (II)Z
    //   125: ifne -> 145
    //   128: aload_0
    //   129: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   132: aload_1
    //   133: invokevirtual dropAllTables : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   136: aload_0
    //   137: getfield mDelegate : Landroidx/room/RoomOpenHelper$Delegate;
    //   140: aload_1
    //   141: invokevirtual createAllTables : (Landroidx/sqlite/db/SupportSQLiteDatabase;)V
    //   144: return
    //   145: new java/lang/StringBuilder
    //   148: dup
    //   149: invokespecial <init> : ()V
    //   152: astore_1
    //   153: aload_1
    //   154: ldc 'A migration from '
    //   156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: pop
    //   160: aload_1
    //   161: iload_2
    //   162: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   165: pop
    //   166: aload_1
    //   167: ldc ' to '
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: aload_1
    //   174: iload_3
    //   175: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   178: pop
    //   179: aload_1
    //   180: ldc ' was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.'
    //   182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: pop
    //   186: new java/lang/IllegalStateException
    //   189: dup
    //   190: aload_1
    //   191: invokevirtual toString : ()Ljava/lang/String;
    //   194: invokespecial <init> : (Ljava/lang/String;)V
    //   197: athrow
    //   198: return
  }
  
  public static abstract class Delegate {
    public final int version;
    
    public Delegate(int param1Int) {
      this.version = param1Int;
    }
    
    protected abstract void createAllTables(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    protected abstract void dropAllTables(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    protected abstract void onCreate(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    protected abstract void onOpen(SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    protected void onPostMigrate(SupportSQLiteDatabase param1SupportSQLiteDatabase) {}
    
    protected void onPreMigrate(SupportSQLiteDatabase param1SupportSQLiteDatabase) {}
    
    protected abstract void validateMigration(SupportSQLiteDatabase param1SupportSQLiteDatabase);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby educational games-dex2jar.jar!\androidx\room\RoomOpenHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */