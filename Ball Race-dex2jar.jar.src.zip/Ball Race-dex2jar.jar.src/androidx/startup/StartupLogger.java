package androidx.startup;

import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY})
public final class StartupLogger {
  static final boolean DEBUG = false;
  
  private static final String TAG = "StartupLogger";
  
  public static void e(@NonNull String paramString, @Nullable Throwable paramThrowable) {
    Log.e("StartupLogger", paramString, paramThrowable);
  }
  
  public static void i(@NonNull String paramString) {
    Log.i("StartupLogger", paramString);
  }
  
  public static void w(@NonNull String paramString) {
    Log.w("StartupLogger", paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\startup\StartupLogger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */