package androidx.core.view;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public interface WindowInsetsAnimationControlListenerCompat {
  void onCancelled(@Nullable WindowInsetsAnimationControllerCompat paramWindowInsetsAnimationControllerCompat);
  
  void onFinished(@NonNull WindowInsetsAnimationControllerCompat paramWindowInsetsAnimationControllerCompat);
  
  void onReady(@NonNull WindowInsetsAnimationControllerCompat paramWindowInsetsAnimationControllerCompat, int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\core\view\WindowInsetsAnimationControlListenerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */