package androidx.core.location;

import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

public final class LocationCompat {
  private static final String EXTRA_IS_MOCK = "mockLocation";
  
  @Nullable
  private static Method sSetIsFromMockProviderMethod;
  
  public static long getElapsedRealtimeMillis(@NonNull Location paramLocation) {
    if (Build.VERSION.SDK_INT >= 17)
      return TimeUnit.NANOSECONDS.toMillis(Api17Impl.getElapsedRealtimeNanos(paramLocation)); 
    long l1 = System.currentTimeMillis() - paramLocation.getTime();
    long l2 = SystemClock.elapsedRealtime();
    return (l1 < 0L) ? l2 : ((l1 > l2) ? 0L : (l2 - l1));
  }
  
  public static long getElapsedRealtimeNanos(@NonNull Location paramLocation) {
    return (Build.VERSION.SDK_INT >= 17) ? Api17Impl.getElapsedRealtimeNanos(paramLocation) : TimeUnit.MILLISECONDS.toNanos(getElapsedRealtimeMillis(paramLocation));
  }
  
  private static Method getSetIsFromMockProviderMethod() throws NoSuchMethodException {
    if (sSetIsFromMockProviderMethod == null) {
      sSetIsFromMockProviderMethod = Location.class.getDeclaredMethod("setIsFromMockProvider", new Class[] { boolean.class });
      sSetIsFromMockProviderMethod.setAccessible(true);
    } 
    return sSetIsFromMockProviderMethod;
  }
  
  public static boolean isMock(@NonNull Location paramLocation) {
    if (Build.VERSION.SDK_INT >= 18)
      return Api18Impl.isMock(paramLocation); 
    Bundle bundle = paramLocation.getExtras();
    return (bundle == null) ? false : bundle.getBoolean("mockLocation", false);
  }
  
  public static void setMock(@NonNull Location paramLocation, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 18)
      try {
        getSetIsFromMockProviderMethod().invoke(paramLocation, new Object[] { Boolean.valueOf(paramBoolean) });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        NoSuchMethodError noSuchMethodError = new NoSuchMethodError();
        noSuchMethodError.initCause(noSuchMethodException);
        throw noSuchMethodError;
      } catch (IllegalAccessException illegalAccessException) {
        IllegalAccessError illegalAccessError = new IllegalAccessError();
        illegalAccessError.initCause(illegalAccessException);
        throw illegalAccessError;
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException(invocationTargetException);
      }  
    Bundle bundle = invocationTargetException.getExtras();
    if (bundle == null) {
      bundle = new Bundle();
      bundle.putBoolean("mockLocation", true);
      invocationTargetException.setExtras(bundle);
      return;
    } 
    bundle.putBoolean("mockLocation", true);
  }
  
  @RequiresApi(17)
  private static class Api17Impl {
    @DoNotInline
    static long getElapsedRealtimeNanos(Location param1Location) {
      return param1Location.getElapsedRealtimeNanos();
    }
  }
  
  @RequiresApi(18)
  private static class Api18Impl {
    @DoNotInline
    static boolean isMock(Location param1Location) {
      return param1Location.isFromMockProvider();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\core\location\LocationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */