package androidx.core.provider;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.collection.LruCache;
import androidx.collection.SimpleArrayMap;
import androidx.core.graphics.TypefaceCompat;
import androidx.core.util.Consumer;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

class FontRequestWorker {
  private static final ExecutorService DEFAULT_EXECUTOR_SERVICE;
  
  static final Object LOCK;
  
  @GuardedBy("LOCK")
  static final SimpleArrayMap<String, ArrayList<Consumer<TypefaceResult>>> PENDING_REPLIES;
  
  static final LruCache<String, Typeface> sTypefaceCache = new LruCache(16);
  
  static {
    DEFAULT_EXECUTOR_SERVICE = RequestExecutor.createDefaultExecutor("fonts-androidx", 10, 10000);
    LOCK = new Object();
    PENDING_REPLIES = new SimpleArrayMap();
  }
  
  private static String createCacheId(@NonNull FontRequest paramFontRequest, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramFontRequest.getId());
    stringBuilder.append("-");
    stringBuilder.append(paramInt);
    return stringBuilder.toString();
  }
  
  @SuppressLint({"WrongConstant"})
  private static int getFontFamilyResultStatus(@NonNull FontsContractCompat.FontFamilyResult paramFontFamilyResult) {
    int i = paramFontFamilyResult.getStatusCode();
    int j = 1;
    if (i != 0)
      return (paramFontFamilyResult.getStatusCode() != 1) ? -3 : -2; 
    FontsContractCompat.FontInfo[] arrayOfFontInfo = paramFontFamilyResult.getFonts();
    if (arrayOfFontInfo != null) {
      if (arrayOfFontInfo.length == 0)
        return 1; 
      int k = arrayOfFontInfo.length;
      byte b = 0;
      i = 0;
      while (true) {
        j = b;
        if (i < k) {
          j = arrayOfFontInfo[i].getResultCode();
          if (j != 0)
            return (j < 0) ? -3 : j; 
          i++;
          continue;
        } 
        break;
      } 
    } 
    return j;
  }
  
  @NonNull
  static TypefaceResult getFontSync(@NonNull String paramString, @NonNull Context paramContext, @NonNull FontRequest paramFontRequest, int paramInt) {
    Typeface typeface = (Typeface)sTypefaceCache.get(paramString);
    if (typeface != null)
      return new TypefaceResult(typeface); 
    try {
      FontsContractCompat.FontFamilyResult fontFamilyResult = FontProvider.getFontFamilyResult(paramContext, paramFontRequest, null);
      int i = getFontFamilyResultStatus(fontFamilyResult);
      if (i != 0)
        return new TypefaceResult(i); 
      Typeface typeface1 = TypefaceCompat.createFromFontInfo(paramContext, null, fontFamilyResult.getFonts(), paramInt);
      if (typeface1 != null) {
        sTypefaceCache.put(paramString, typeface1);
        return new TypefaceResult(typeface1);
      } 
      return new TypefaceResult(-3);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return new TypefaceResult(-1);
    } 
  }
  
  static Typeface requestFontAsync(@NonNull final Context context, @NonNull final FontRequest request, final int style, @Nullable Executor paramExecutor, @NonNull final CallbackWithHandler callback) {
    final String id = createCacheId(request, style);
    Typeface typeface = (Typeface)sTypefaceCache.get(str);
    if (typeface != null) {
      callback.onTypefaceResult(new TypefaceResult(typeface));
      return typeface;
    } 
    Consumer<TypefaceResult> consumer = new Consumer<TypefaceResult>() {
        public void accept(FontRequestWorker.TypefaceResult param1TypefaceResult) {
          callback.onTypefaceResult(param1TypefaceResult);
        }
      };
    synchronized (LOCK) {
      ArrayList<Consumer<TypefaceResult>> arrayList = (ArrayList)PENDING_REPLIES.get(str);
      if (arrayList != null) {
        arrayList.add(consumer);
        return null;
      } 
      arrayList = new ArrayList<Consumer<TypefaceResult>>();
      arrayList.add(consumer);
      PENDING_REPLIES.put(str, arrayList);
      Callable<TypefaceResult> callable = new Callable<TypefaceResult>() {
          public FontRequestWorker.TypefaceResult call() {
            return FontRequestWorker.getFontSync(id, context, request, style);
          }
        };
      Executor executor = paramExecutor;
      if (paramExecutor == null)
        executor = DEFAULT_EXECUTOR_SERVICE; 
      RequestExecutor.execute(executor, callable, new Consumer<TypefaceResult>() {
            public void accept(FontRequestWorker.TypefaceResult param1TypefaceResult) {
              synchronized (FontRequestWorker.LOCK) {
                ArrayList<Consumer> arrayList = (ArrayList)FontRequestWorker.PENDING_REPLIES.get(id);
                if (arrayList == null)
                  return; 
                FontRequestWorker.PENDING_REPLIES.remove(id);
                for (int i = 0; i < arrayList.size(); i++)
                  ((Consumer)arrayList.get(i)).accept(param1TypefaceResult); 
                return;
              } 
            }
          });
      return null;
    } 
  }
  
  static Typeface requestFontSync(@NonNull Context paramContext, @NonNull final FontRequest request, @NonNull CallbackWithHandler paramCallbackWithHandler, final int style, int paramInt2) {
    final TypefaceResult context;
    final String id = createCacheId(request, style);
    Typeface typeface = (Typeface)sTypefaceCache.get(str);
    if (typeface != null) {
      paramCallbackWithHandler.onTypefaceResult(new TypefaceResult(typeface));
      return typeface;
    } 
    if (paramInt2 == -1) {
      typefaceResult = getFontSync(str, paramContext, request, style);
      paramCallbackWithHandler.onTypefaceResult(typefaceResult);
      return typefaceResult.mTypeface;
    } 
    Callable<TypefaceResult> callable = new Callable<TypefaceResult>() {
        public FontRequestWorker.TypefaceResult call() {
          return FontRequestWorker.getFontSync(id, context, request, style);
        }
      };
    try {
      TypefaceResult typefaceResult1 = RequestExecutor.<TypefaceResult>submit(DEFAULT_EXECUTOR_SERVICE, callable, paramInt2);
      paramCallbackWithHandler.onTypefaceResult(typefaceResult1);
      return typefaceResult1.mTypeface;
    } catch (InterruptedException interruptedException) {
      paramCallbackWithHandler.onTypefaceResult(new TypefaceResult(-3));
      return null;
    } 
  }
  
  static void resetTypefaceCache() {
    sTypefaceCache.evictAll();
  }
  
  static final class TypefaceResult {
    final int mResult;
    
    final Typeface mTypeface = null;
    
    TypefaceResult(int param1Int) {
      this.mResult = param1Int;
    }
    
    @SuppressLint({"WrongConstant"})
    TypefaceResult(@NonNull Typeface param1Typeface) {
      this.mResult = 0;
    }
    
    @SuppressLint({"WrongConstant"})
    boolean isSuccess() {
      return (this.mResult == 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\core\provider\FontRequestWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */