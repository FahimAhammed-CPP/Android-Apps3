package androidx.sqlite.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

public interface SupportSQLiteOpenHelper extends Closeable {
  void close();
  
  @Nullable
  String getDatabaseName();
  
  SupportSQLiteDatabase getReadableDatabase();
  
  SupportSQLiteDatabase getWritableDatabase();
  
  @RequiresApi(api = 16)
  void setWriteAheadLoggingEnabled(boolean paramBoolean);
  
  public static abstract class Callback {
    private static final String TAG = "SupportSQLite";
    
    public final int version;
    
    public Callback(int param1Int) {
      this.version = param1Int;
    }
    
    private void deleteDatabaseFile(String param1String) {
      if (!param1String.equalsIgnoreCase(":memory:")) {
        if (param1String.trim().length() == 0)
          return; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("deleting the database file: ");
        stringBuilder.append(param1String);
        Log.w("SupportSQLite", stringBuilder.toString());
        try {
          if (Build.VERSION.SDK_INT >= 16) {
            SQLiteDatabase.deleteDatabase(new File(param1String));
            return;
          } 
          try {
            if (!(new File(param1String)).delete()) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Could not delete the database file ");
              stringBuilder.append(param1String);
              Log.e("SupportSQLite", stringBuilder.toString());
              return;
            } 
          } catch (Exception exception) {
            Log.e("SupportSQLite", "error while deleting corrupted database file", exception);
            return;
          } 
        } catch (Exception exception) {
          Log.w("SupportSQLite", "delete failed: ", exception);
        } 
      } 
    }
    
    public void onConfigure(@NonNull SupportSQLiteDatabase param1SupportSQLiteDatabase) {}
    
    public void onCorruption(@NonNull SupportSQLiteDatabase param1SupportSQLiteDatabase) {
      Iterator iterator;
      null = new StringBuilder();
      null.append("Corruption reported by sqlite on database: ");
      null.append(param1SupportSQLiteDatabase.getPath());
      Log.e("SupportSQLite", null.toString());
      if (!param1SupportSQLiteDatabase.isOpen()) {
        deleteDatabaseFile(param1SupportSQLiteDatabase.getPath());
        return;
      } 
      null = null;
      sQLiteException = null;
      try {
        List list2 = param1SupportSQLiteDatabase.getAttachedDbs();
      } catch (SQLiteException sQLiteException) {
      
      } finally {
        if (sQLiteException != null) {
          iterator = sQLiteException.iterator();
          while (iterator.hasNext())
            deleteDatabaseFile((String)((Pair)iterator.next()).second); 
        } else {
          deleteDatabaseFile(iterator.getPath());
        } 
      } 
      Object object = SYNTHETIC_LOCAL_VARIABLE_2;
      try {
        iterator.close();
      } catch (IOException iOException) {}
      if (SYNTHETIC_LOCAL_VARIABLE_2 != null) {
        iterator = SYNTHETIC_LOCAL_VARIABLE_2.iterator();
        while (iterator.hasNext())
          deleteDatabaseFile((String)((Pair)iterator.next()).second); 
      } else {
        deleteDatabaseFile(iterator.getPath());
      } 
    }
    
    public abstract void onCreate(@NonNull SupportSQLiteDatabase param1SupportSQLiteDatabase);
    
    public void onDowngrade(@NonNull SupportSQLiteDatabase param1SupportSQLiteDatabase, int param1Int1, int param1Int2) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Can't downgrade database from version ");
      stringBuilder.append(param1Int1);
      stringBuilder.append(" to ");
      stringBuilder.append(param1Int2);
      throw new SQLiteException(stringBuilder.toString());
    }
    
    public void onOpen(@NonNull SupportSQLiteDatabase param1SupportSQLiteDatabase) {}
    
    public abstract void onUpgrade(@NonNull SupportSQLiteDatabase param1SupportSQLiteDatabase, int param1Int1, int param1Int2);
  }
  
  public static class Configuration {
    @NonNull
    public final SupportSQLiteOpenHelper.Callback callback;
    
    @NonNull
    public final Context context;
    
    @Nullable
    public final String name;
    
    public final boolean useNoBackupDirectory;
    
    Configuration(@NonNull Context param1Context, @Nullable String param1String, @NonNull SupportSQLiteOpenHelper.Callback param1Callback) {
      this(param1Context, param1String, param1Callback, false);
    }
    
    Configuration(@NonNull Context param1Context, @Nullable String param1String, @NonNull SupportSQLiteOpenHelper.Callback param1Callback, boolean param1Boolean) {
      this.context = param1Context;
      this.name = param1String;
      this.callback = param1Callback;
      this.useNoBackupDirectory = param1Boolean;
    }
    
    @NonNull
    public static Builder builder(@NonNull Context param1Context) {
      return new Builder(param1Context);
    }
    
    public static class Builder {
      SupportSQLiteOpenHelper.Callback mCallback;
      
      Context mContext;
      
      String mName;
      
      boolean mUseNoBackUpDirectory;
      
      Builder(@NonNull Context param2Context) {
        this.mContext = param2Context;
      }
      
      @NonNull
      public SupportSQLiteOpenHelper.Configuration build() {
        if (this.mCallback != null) {
          if (this.mContext != null) {
            if (!this.mUseNoBackUpDirectory || !TextUtils.isEmpty(this.mName))
              return new SupportSQLiteOpenHelper.Configuration(this.mContext, this.mName, this.mCallback, this.mUseNoBackUpDirectory); 
            throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.");
          } 
          throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
        } 
        throw new IllegalArgumentException("Must set a callback to create the configuration.");
      }
      
      @NonNull
      public Builder callback(@NonNull SupportSQLiteOpenHelper.Callback param2Callback) {
        this.mCallback = param2Callback;
        return this;
      }
      
      @NonNull
      public Builder name(@Nullable String param2String) {
        this.mName = param2String;
        return this;
      }
      
      @NonNull
      public Builder noBackupDirectory(boolean param2Boolean) {
        this.mUseNoBackUpDirectory = param2Boolean;
        return this;
      }
    }
  }
  
  public static class Builder {
    SupportSQLiteOpenHelper.Callback mCallback;
    
    Context mContext;
    
    String mName;
    
    boolean mUseNoBackUpDirectory;
    
    Builder(@NonNull Context param1Context) {
      this.mContext = param1Context;
    }
    
    @NonNull
    public SupportSQLiteOpenHelper.Configuration build() {
      if (this.mCallback != null) {
        if (this.mContext != null) {
          if (!this.mUseNoBackUpDirectory || !TextUtils.isEmpty(this.mName))
            return new SupportSQLiteOpenHelper.Configuration(this.mContext, this.mName, this.mCallback, this.mUseNoBackUpDirectory); 
          throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.");
        } 
        throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
      } 
      throw new IllegalArgumentException("Must set a callback to create the configuration.");
    }
    
    @NonNull
    public Builder callback(@NonNull SupportSQLiteOpenHelper.Callback param1Callback) {
      this.mCallback = param1Callback;
      return this;
    }
    
    @NonNull
    public Builder name(@Nullable String param1String) {
      this.mName = param1String;
      return this;
    }
    
    @NonNull
    public Builder noBackupDirectory(boolean param1Boolean) {
      this.mUseNoBackUpDirectory = param1Boolean;
      return this;
    }
  }
  
  public static interface Factory {
    @NonNull
    SupportSQLiteOpenHelper create(@NonNull SupportSQLiteOpenHelper.Configuration param1Configuration);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\sqlite\db\SupportSQLiteOpenHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */