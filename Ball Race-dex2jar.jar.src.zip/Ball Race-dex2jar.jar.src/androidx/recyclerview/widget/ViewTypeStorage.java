package androidx.recyclerview.widget;

import android.util.SparseArray;
import android.util.SparseIntArray;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.List;

interface ViewTypeStorage {
  @NonNull
  ViewTypeLookup createViewTypeWrapper(@NonNull NestedAdapterWrapper paramNestedAdapterWrapper);
  
  @NonNull
  NestedAdapterWrapper getWrapperForGlobalType(int paramInt);
  
  public static class IsolatedViewTypeStorage implements ViewTypeStorage {
    SparseArray<NestedAdapterWrapper> mGlobalTypeToWrapper = new SparseArray();
    
    int mNextViewType = 0;
    
    @NonNull
    public ViewTypeStorage.ViewTypeLookup createViewTypeWrapper(@NonNull NestedAdapterWrapper param1NestedAdapterWrapper) {
      return new WrapperViewTypeLookup(param1NestedAdapterWrapper);
    }
    
    @NonNull
    public NestedAdapterWrapper getWrapperForGlobalType(int param1Int) {
      NestedAdapterWrapper nestedAdapterWrapper = (NestedAdapterWrapper)this.mGlobalTypeToWrapper.get(param1Int);
      if (nestedAdapterWrapper != null)
        return nestedAdapterWrapper; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find the wrapper for global view type ");
      stringBuilder.append(param1Int);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    int obtainViewType(NestedAdapterWrapper param1NestedAdapterWrapper) {
      int i = this.mNextViewType;
      this.mNextViewType = i + 1;
      this.mGlobalTypeToWrapper.put(i, param1NestedAdapterWrapper);
      return i;
    }
    
    void removeWrapper(@NonNull NestedAdapterWrapper param1NestedAdapterWrapper) {
      for (int i = this.mGlobalTypeToWrapper.size() - 1; i >= 0; i--) {
        if ((NestedAdapterWrapper)this.mGlobalTypeToWrapper.valueAt(i) == param1NestedAdapterWrapper)
          this.mGlobalTypeToWrapper.removeAt(i); 
      } 
    }
    
    class WrapperViewTypeLookup implements ViewTypeStorage.ViewTypeLookup {
      private SparseIntArray mGlobalToLocalMapping = new SparseIntArray(1);
      
      private SparseIntArray mLocalToGlobalMapping = new SparseIntArray(1);
      
      final NestedAdapterWrapper mWrapper;
      
      WrapperViewTypeLookup(NestedAdapterWrapper param2NestedAdapterWrapper) {
        this.mWrapper = param2NestedAdapterWrapper;
      }
      
      public void dispose() {
        ViewTypeStorage.IsolatedViewTypeStorage.this.removeWrapper(this.mWrapper);
      }
      
      public int globalToLocal(int param2Int) {
        int i = this.mGlobalToLocalMapping.indexOfKey(param2Int);
        if (i >= 0)
          return this.mGlobalToLocalMapping.valueAt(i); 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("requested global type ");
        stringBuilder.append(param2Int);
        stringBuilder.append(" does not belong to the adapter:");
        stringBuilder.append(this.mWrapper.adapter);
        throw new IllegalStateException(stringBuilder.toString());
      }
      
      public int localToGlobal(int param2Int) {
        int i = this.mLocalToGlobalMapping.indexOfKey(param2Int);
        if (i > -1)
          return this.mLocalToGlobalMapping.valueAt(i); 
        i = ViewTypeStorage.IsolatedViewTypeStorage.this.obtainViewType(this.mWrapper);
        this.mLocalToGlobalMapping.put(param2Int, i);
        this.mGlobalToLocalMapping.put(i, param2Int);
        return i;
      }
    }
  }
  
  class WrapperViewTypeLookup implements ViewTypeLookup {
    private SparseIntArray mGlobalToLocalMapping = new SparseIntArray(1);
    
    private SparseIntArray mLocalToGlobalMapping = new SparseIntArray(1);
    
    final NestedAdapterWrapper mWrapper;
    
    WrapperViewTypeLookup(NestedAdapterWrapper param1NestedAdapterWrapper) {
      this.mWrapper = param1NestedAdapterWrapper;
    }
    
    public void dispose() {
      this.this$0.removeWrapper(this.mWrapper);
    }
    
    public int globalToLocal(int param1Int) {
      int i = this.mGlobalToLocalMapping.indexOfKey(param1Int);
      if (i >= 0)
        return this.mGlobalToLocalMapping.valueAt(i); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("requested global type ");
      stringBuilder.append(param1Int);
      stringBuilder.append(" does not belong to the adapter:");
      stringBuilder.append(this.mWrapper.adapter);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public int localToGlobal(int param1Int) {
      int i = this.mLocalToGlobalMapping.indexOfKey(param1Int);
      if (i > -1)
        return this.mLocalToGlobalMapping.valueAt(i); 
      i = this.this$0.obtainViewType(this.mWrapper);
      this.mLocalToGlobalMapping.put(param1Int, i);
      this.mGlobalToLocalMapping.put(i, param1Int);
      return i;
    }
  }
  
  public static class SharedIdRangeViewTypeStorage implements ViewTypeStorage {
    SparseArray<List<NestedAdapterWrapper>> mGlobalTypeToWrapper = new SparseArray();
    
    @NonNull
    public ViewTypeStorage.ViewTypeLookup createViewTypeWrapper(@NonNull NestedAdapterWrapper param1NestedAdapterWrapper) {
      return new WrapperViewTypeLookup(param1NestedAdapterWrapper);
    }
    
    @NonNull
    public NestedAdapterWrapper getWrapperForGlobalType(int param1Int) {
      List<NestedAdapterWrapper> list = (List)this.mGlobalTypeToWrapper.get(param1Int);
      if (list != null && !list.isEmpty())
        return list.get(0); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot find the wrapper for global view type ");
      stringBuilder.append(param1Int);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    void removeWrapper(@NonNull NestedAdapterWrapper param1NestedAdapterWrapper) {
      for (int i = this.mGlobalTypeToWrapper.size() - 1; i >= 0; i--) {
        List list = (List)this.mGlobalTypeToWrapper.valueAt(i);
        if (list.remove(param1NestedAdapterWrapper) && list.isEmpty())
          this.mGlobalTypeToWrapper.removeAt(i); 
      } 
    }
    
    class WrapperViewTypeLookup implements ViewTypeStorage.ViewTypeLookup {
      final NestedAdapterWrapper mWrapper;
      
      WrapperViewTypeLookup(NestedAdapterWrapper param2NestedAdapterWrapper) {
        this.mWrapper = param2NestedAdapterWrapper;
      }
      
      public void dispose() {
        ViewTypeStorage.SharedIdRangeViewTypeStorage.this.removeWrapper(this.mWrapper);
      }
      
      public int globalToLocal(int param2Int) {
        return param2Int;
      }
      
      public int localToGlobal(int param2Int) {
        List<NestedAdapterWrapper> list2 = (List)ViewTypeStorage.SharedIdRangeViewTypeStorage.this.mGlobalTypeToWrapper.get(param2Int);
        List<NestedAdapterWrapper> list1 = list2;
        if (list2 == null) {
          list1 = new ArrayList();
          ViewTypeStorage.SharedIdRangeViewTypeStorage.this.mGlobalTypeToWrapper.put(param2Int, list1);
        } 
        if (!list1.contains(this.mWrapper))
          list1.add(this.mWrapper); 
        return param2Int;
      }
    }
  }
  
  class WrapperViewTypeLookup implements ViewTypeLookup {
    final NestedAdapterWrapper mWrapper;
    
    WrapperViewTypeLookup(NestedAdapterWrapper param1NestedAdapterWrapper) {
      this.mWrapper = param1NestedAdapterWrapper;
    }
    
    public void dispose() {
      this.this$0.removeWrapper(this.mWrapper);
    }
    
    public int globalToLocal(int param1Int) {
      return param1Int;
    }
    
    public int localToGlobal(int param1Int) {
      List<NestedAdapterWrapper> list2 = (List)this.this$0.mGlobalTypeToWrapper.get(param1Int);
      List<NestedAdapterWrapper> list1 = list2;
      if (list2 == null) {
        list1 = new ArrayList();
        this.this$0.mGlobalTypeToWrapper.put(param1Int, list1);
      } 
      if (!list1.contains(this.mWrapper))
        list1.add(this.mWrapper); 
      return param1Int;
    }
  }
  
  public static interface ViewTypeLookup {
    void dispose();
    
    int globalToLocal(int param1Int);
    
    int localToGlobal(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\recyclerview\widget\ViewTypeStorage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */