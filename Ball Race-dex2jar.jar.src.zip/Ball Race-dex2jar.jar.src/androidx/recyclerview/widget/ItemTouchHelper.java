package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.view.animation.Interpolator;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.core.view.GestureDetectorCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.R;
import java.util.ArrayList;
import java.util.List;

public class ItemTouchHelper extends RecyclerView.ItemDecoration implements RecyclerView.OnChildAttachStateChangeListener {
  static final int ACTION_MODE_DRAG_MASK = 16711680;
  
  private static final int ACTION_MODE_IDLE_MASK = 255;
  
  static final int ACTION_MODE_SWIPE_MASK = 65280;
  
  public static final int ACTION_STATE_DRAG = 2;
  
  public static final int ACTION_STATE_IDLE = 0;
  
  public static final int ACTION_STATE_SWIPE = 1;
  
  private static final int ACTIVE_POINTER_ID_NONE = -1;
  
  public static final int ANIMATION_TYPE_DRAG = 8;
  
  public static final int ANIMATION_TYPE_SWIPE_CANCEL = 4;
  
  public static final int ANIMATION_TYPE_SWIPE_SUCCESS = 2;
  
  private static final boolean DEBUG = false;
  
  static final int DIRECTION_FLAG_COUNT = 8;
  
  public static final int DOWN = 2;
  
  public static final int END = 32;
  
  public static final int LEFT = 4;
  
  private static final int PIXELS_PER_SECOND = 1000;
  
  public static final int RIGHT = 8;
  
  public static final int START = 16;
  
  private static final String TAG = "ItemTouchHelper";
  
  public static final int UP = 1;
  
  private int mActionState = 0;
  
  int mActivePointerId = -1;
  
  @NonNull
  Callback mCallback;
  
  private RecyclerView.ChildDrawingOrderCallback mChildDrawingOrderCallback = null;
  
  private List<Integer> mDistances;
  
  private long mDragScrollStartTimeInMs;
  
  float mDx;
  
  float mDy;
  
  GestureDetectorCompat mGestureDetector;
  
  float mInitialTouchX;
  
  float mInitialTouchY;
  
  private ItemTouchHelperGestureListener mItemTouchHelperGestureListener;
  
  private float mMaxSwipeVelocity;
  
  private final RecyclerView.OnItemTouchListener mOnItemTouchListener = new RecyclerView.OnItemTouchListener() {
      public boolean onInterceptTouchEvent(@NonNull RecyclerView param1RecyclerView, @NonNull MotionEvent param1MotionEvent) {
        ItemTouchHelper.this.mGestureDetector.onTouchEvent(param1MotionEvent);
        int i = param1MotionEvent.getActionMasked();
        if (i == 0) {
          ItemTouchHelper.this.mActivePointerId = param1MotionEvent.getPointerId(0);
          ItemTouchHelper.this.mInitialTouchX = param1MotionEvent.getX();
          ItemTouchHelper.this.mInitialTouchY = param1MotionEvent.getY();
          ItemTouchHelper.this.obtainVelocityTracker();
          if (ItemTouchHelper.this.mSelected == null) {
            ItemTouchHelper.RecoverAnimation recoverAnimation = ItemTouchHelper.this.findAnimation(param1MotionEvent);
            if (recoverAnimation != null) {
              ItemTouchHelper itemTouchHelper2 = ItemTouchHelper.this;
              itemTouchHelper2.mInitialTouchX -= recoverAnimation.mX;
              itemTouchHelper2 = ItemTouchHelper.this;
              itemTouchHelper2.mInitialTouchY -= recoverAnimation.mY;
              ItemTouchHelper.this.endRecoverAnimation(recoverAnimation.mViewHolder, true);
              if (ItemTouchHelper.this.mPendingCleanup.remove(recoverAnimation.mViewHolder.itemView))
                ItemTouchHelper.this.mCallback.clearView(ItemTouchHelper.this.mRecyclerView, recoverAnimation.mViewHolder); 
              ItemTouchHelper.this.select(recoverAnimation.mViewHolder, recoverAnimation.mActionState);
              ItemTouchHelper itemTouchHelper1 = ItemTouchHelper.this;
              itemTouchHelper1.updateDxDy(param1MotionEvent, itemTouchHelper1.mSelectedFlags, 0);
            } 
          } 
        } else if (i == 3 || i == 1) {
          ItemTouchHelper itemTouchHelper = ItemTouchHelper.this;
          itemTouchHelper.mActivePointerId = -1;
          itemTouchHelper.select(null, 0);
        } else if (ItemTouchHelper.this.mActivePointerId != -1) {
          int j = param1MotionEvent.findPointerIndex(ItemTouchHelper.this.mActivePointerId);
          if (j >= 0)
            ItemTouchHelper.this.checkSelectForSwipe(i, param1MotionEvent, j); 
        } 
        if (ItemTouchHelper.this.mVelocityTracker != null)
          ItemTouchHelper.this.mVelocityTracker.addMovement(param1MotionEvent); 
        return (ItemTouchHelper.this.mSelected != null);
      }
      
      public void onRequestDisallowInterceptTouchEvent(boolean param1Boolean) {
        if (!param1Boolean)
          return; 
        ItemTouchHelper.this.select(null, 0);
      }
      
      public void onTouchEvent(@NonNull RecyclerView param1RecyclerView, @NonNull MotionEvent param1MotionEvent) {
        ItemTouchHelper.this.mGestureDetector.onTouchEvent(param1MotionEvent);
        if (ItemTouchHelper.this.mVelocityTracker != null)
          ItemTouchHelper.this.mVelocityTracker.addMovement(param1MotionEvent); 
        if (ItemTouchHelper.this.mActivePointerId == -1)
          return; 
        int i = param1MotionEvent.getActionMasked();
        int j = param1MotionEvent.findPointerIndex(ItemTouchHelper.this.mActivePointerId);
        if (j >= 0)
          ItemTouchHelper.this.checkSelectForSwipe(i, param1MotionEvent, j); 
        RecyclerView.ViewHolder viewHolder = ItemTouchHelper.this.mSelected;
        if (viewHolder == null)
          return; 
        boolean bool = false;
        if (i != 1) {
          ItemTouchHelper itemTouchHelper;
          if (i != 2) {
            if (i != 3) {
              if (i != 6)
                return; 
              i = param1MotionEvent.getActionIndex();
              if (param1MotionEvent.getPointerId(i) == ItemTouchHelper.this.mActivePointerId) {
                if (i == 0)
                  bool = true; 
                ItemTouchHelper.this.mActivePointerId = param1MotionEvent.getPointerId(bool);
                itemTouchHelper = ItemTouchHelper.this;
                itemTouchHelper.updateDxDy(param1MotionEvent, itemTouchHelper.mSelectedFlags, i);
                return;
              } 
            } else {
              if (ItemTouchHelper.this.mVelocityTracker != null)
                ItemTouchHelper.this.mVelocityTracker.clear(); 
              ItemTouchHelper.this.select(null, 0);
              ItemTouchHelper.this.mActivePointerId = -1;
            } 
          } else if (j >= 0) {
            ItemTouchHelper itemTouchHelper1 = ItemTouchHelper.this;
            itemTouchHelper1.updateDxDy(param1MotionEvent, itemTouchHelper1.mSelectedFlags, j);
            ItemTouchHelper.this.moveIfNecessary((RecyclerView.ViewHolder)itemTouchHelper);
            ItemTouchHelper.this.mRecyclerView.removeCallbacks(ItemTouchHelper.this.mScrollRunnable);
            ItemTouchHelper.this.mScrollRunnable.run();
            ItemTouchHelper.this.mRecyclerView.invalidate();
            return;
          } 
          return;
        } 
        ItemTouchHelper.this.select(null, 0);
        ItemTouchHelper.this.mActivePointerId = -1;
      }
    };
  
  View mOverdrawChild = null;
  
  int mOverdrawChildPosition = -1;
  
  final List<View> mPendingCleanup = new ArrayList<View>();
  
  @VisibleForTesting
  List<RecoverAnimation> mRecoverAnimations = new ArrayList<RecoverAnimation>();
  
  RecyclerView mRecyclerView;
  
  final Runnable mScrollRunnable = new Runnable() {
      public void run() {
        if (ItemTouchHelper.this.mSelected != null && ItemTouchHelper.this.scrollIfNecessary()) {
          if (ItemTouchHelper.this.mSelected != null) {
            ItemTouchHelper itemTouchHelper = ItemTouchHelper.this;
            itemTouchHelper.moveIfNecessary(itemTouchHelper.mSelected);
          } 
          ItemTouchHelper.this.mRecyclerView.removeCallbacks(ItemTouchHelper.this.mScrollRunnable);
          ViewCompat.postOnAnimation((View)ItemTouchHelper.this.mRecyclerView, this);
        } 
      }
    };
  
  RecyclerView.ViewHolder mSelected = null;
  
  int mSelectedFlags;
  
  private float mSelectedStartX;
  
  private float mSelectedStartY;
  
  private int mSlop;
  
  private List<RecyclerView.ViewHolder> mSwapTargets;
  
  private float mSwipeEscapeVelocity;
  
  private final float[] mTmpPosition = new float[2];
  
  private Rect mTmpRect;
  
  VelocityTracker mVelocityTracker;
  
  public ItemTouchHelper(@NonNull Callback paramCallback) {
    this.mCallback = paramCallback;
  }
  
  private void addChildDrawingOrderCallback() {
    if (Build.VERSION.SDK_INT >= 21)
      return; 
    if (this.mChildDrawingOrderCallback == null)
      this.mChildDrawingOrderCallback = new RecyclerView.ChildDrawingOrderCallback() {
          public int onGetChildDrawingOrder(int param1Int1, int param1Int2) {
            if (ItemTouchHelper.this.mOverdrawChild == null)
              return param1Int2; 
            int j = ItemTouchHelper.this.mOverdrawChildPosition;
            int i = j;
            if (j == -1) {
              i = ItemTouchHelper.this.mRecyclerView.indexOfChild(ItemTouchHelper.this.mOverdrawChild);
              ItemTouchHelper.this.mOverdrawChildPosition = i;
            } 
            return (param1Int2 == param1Int1 - 1) ? i : ((param1Int2 < i) ? param1Int2 : (param1Int2 + 1));
          }
        }; 
    this.mRecyclerView.setChildDrawingOrderCallback(this.mChildDrawingOrderCallback);
  }
  
  private int checkHorizontalSwipe(RecyclerView.ViewHolder paramViewHolder, int paramInt) {
    if ((paramInt & 0xC) != 0) {
      byte b1;
      float f1 = this.mDx;
      byte b2 = 8;
      if (f1 > 0.0F) {
        b1 = 8;
      } else {
        b1 = 4;
      } 
      VelocityTracker velocityTracker = this.mVelocityTracker;
      if (velocityTracker != null && this.mActivePointerId > -1) {
        velocityTracker.computeCurrentVelocity(1000, this.mCallback.getSwipeVelocityThreshold(this.mMaxSwipeVelocity));
        float f = this.mVelocityTracker.getXVelocity(this.mActivePointerId);
        f1 = this.mVelocityTracker.getYVelocity(this.mActivePointerId);
        if (f <= 0.0F)
          b2 = 4; 
        f = Math.abs(f);
        if ((b2 & paramInt) != 0 && b1 == b2 && f >= this.mCallback.getSwipeEscapeVelocity(this.mSwipeEscapeVelocity) && f > Math.abs(f1))
          return b2; 
      } 
      f1 = this.mRecyclerView.getWidth();
      float f2 = this.mCallback.getSwipeThreshold(paramViewHolder);
      if ((paramInt & b1) != 0 && Math.abs(this.mDx) > f1 * f2)
        return b1; 
    } 
    return 0;
  }
  
  private int checkVerticalSwipe(RecyclerView.ViewHolder paramViewHolder, int paramInt) {
    if ((paramInt & 0x3) != 0) {
      byte b1;
      float f1 = this.mDy;
      byte b2 = 2;
      if (f1 > 0.0F) {
        b1 = 2;
      } else {
        b1 = 1;
      } 
      VelocityTracker velocityTracker = this.mVelocityTracker;
      if (velocityTracker != null && this.mActivePointerId > -1) {
        velocityTracker.computeCurrentVelocity(1000, this.mCallback.getSwipeVelocityThreshold(this.mMaxSwipeVelocity));
        f1 = this.mVelocityTracker.getXVelocity(this.mActivePointerId);
        float f = this.mVelocityTracker.getYVelocity(this.mActivePointerId);
        if (f <= 0.0F)
          b2 = 1; 
        f = Math.abs(f);
        if ((b2 & paramInt) != 0 && b2 == b1 && f >= this.mCallback.getSwipeEscapeVelocity(this.mSwipeEscapeVelocity) && f > Math.abs(f1))
          return b2; 
      } 
      f1 = this.mRecyclerView.getHeight();
      float f2 = this.mCallback.getSwipeThreshold(paramViewHolder);
      if ((paramInt & b1) != 0 && Math.abs(this.mDy) > f1 * f2)
        return b1; 
    } 
    return 0;
  }
  
  private void destroyCallbacks() {
    this.mRecyclerView.removeItemDecoration(this);
    this.mRecyclerView.removeOnItemTouchListener(this.mOnItemTouchListener);
    this.mRecyclerView.removeOnChildAttachStateChangeListener(this);
    for (int i = this.mRecoverAnimations.size() - 1; i >= 0; i--) {
      RecoverAnimation recoverAnimation = this.mRecoverAnimations.get(0);
      recoverAnimation.cancel();
      this.mCallback.clearView(this.mRecyclerView, recoverAnimation.mViewHolder);
    } 
    this.mRecoverAnimations.clear();
    this.mOverdrawChild = null;
    this.mOverdrawChildPosition = -1;
    releaseVelocityTracker();
    stopGestureDetection();
  }
  
  private List<RecyclerView.ViewHolder> findSwapTargets(RecyclerView.ViewHolder paramViewHolder) {
    RecyclerView.ViewHolder viewHolder = paramViewHolder;
    List<RecyclerView.ViewHolder> list = this.mSwapTargets;
    if (list == null) {
      this.mSwapTargets = new ArrayList<RecyclerView.ViewHolder>();
      this.mDistances = new ArrayList<Integer>();
    } else {
      list.clear();
      this.mDistances.clear();
    } 
    int j = this.mCallback.getBoundingBoxMargin();
    int k = Math.round(this.mSelectedStartX + this.mDx) - j;
    int m = Math.round(this.mSelectedStartY + this.mDy) - j;
    int i = viewHolder.itemView.getWidth();
    j *= 2;
    int n = i + k + j;
    int i1 = viewHolder.itemView.getHeight() + m + j;
    int i2 = (k + n) / 2;
    int i3 = (m + i1) / 2;
    RecyclerView.LayoutManager layoutManager = this.mRecyclerView.getLayoutManager();
    int i4 = layoutManager.getChildCount();
    for (i = 0; i < i4; i++) {
      View view = layoutManager.getChildAt(i);
      if (view != paramViewHolder.itemView && view.getBottom() >= m && view.getTop() <= i1 && view.getRight() >= k && view.getLeft() <= n) {
        RecyclerView.ViewHolder viewHolder1 = this.mRecyclerView.getChildViewHolder(view);
        if (this.mCallback.canDropOver(this.mRecyclerView, this.mSelected, viewHolder1)) {
          j = Math.abs(i2 - (view.getLeft() + view.getRight()) / 2);
          int i5 = Math.abs(i3 - (view.getTop() + view.getBottom()) / 2);
          int i6 = j * j + i5 * i5;
          int i7 = this.mSwapTargets.size();
          j = 0;
          i5 = 0;
          while (j < i7 && i6 > ((Integer)this.mDistances.get(j)).intValue()) {
            i5++;
            j++;
          } 
          this.mSwapTargets.add(i5, viewHolder1);
          this.mDistances.add(i5, Integer.valueOf(i6));
        } 
      } 
    } 
    return this.mSwapTargets;
  }
  
  private RecyclerView.ViewHolder findSwipedView(MotionEvent paramMotionEvent) {
    RecyclerView.LayoutManager layoutManager = this.mRecyclerView.getLayoutManager();
    int i = this.mActivePointerId;
    if (i == -1)
      return null; 
    i = paramMotionEvent.findPointerIndex(i);
    float f3 = paramMotionEvent.getX(i);
    float f4 = this.mInitialTouchX;
    float f1 = paramMotionEvent.getY(i);
    float f2 = this.mInitialTouchY;
    f3 = Math.abs(f3 - f4);
    f1 = Math.abs(f1 - f2);
    i = this.mSlop;
    if (f3 < i && f1 < i)
      return null; 
    if (f3 > f1 && layoutManager.canScrollHorizontally())
      return null; 
    if (f1 > f3 && layoutManager.canScrollVertically())
      return null; 
    View view = findChildView(paramMotionEvent);
    return (view == null) ? null : this.mRecyclerView.getChildViewHolder(view);
  }
  
  private void getSelectedDxDy(float[] paramArrayOffloat) {
    if ((this.mSelectedFlags & 0xC) != 0) {
      paramArrayOffloat[0] = this.mSelectedStartX + this.mDx - this.mSelected.itemView.getLeft();
    } else {
      paramArrayOffloat[0] = this.mSelected.itemView.getTranslationX();
    } 
    if ((this.mSelectedFlags & 0x3) != 0) {
      paramArrayOffloat[1] = this.mSelectedStartY + this.mDy - this.mSelected.itemView.getTop();
      return;
    } 
    paramArrayOffloat[1] = this.mSelected.itemView.getTranslationY();
  }
  
  private static boolean hitTest(View paramView, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return (paramFloat1 >= paramFloat3 && paramFloat1 <= paramFloat3 + paramView.getWidth() && paramFloat2 >= paramFloat4 && paramFloat2 <= paramFloat4 + paramView.getHeight());
  }
  
  private void releaseVelocityTracker() {
    VelocityTracker velocityTracker = this.mVelocityTracker;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.mVelocityTracker = null;
    } 
  }
  
  private void setupCallbacks() {
    this.mSlop = ViewConfiguration.get(this.mRecyclerView.getContext()).getScaledTouchSlop();
    this.mRecyclerView.addItemDecoration(this);
    this.mRecyclerView.addOnItemTouchListener(this.mOnItemTouchListener);
    this.mRecyclerView.addOnChildAttachStateChangeListener(this);
    startGestureDetection();
  }
  
  private void startGestureDetection() {
    this.mItemTouchHelperGestureListener = new ItemTouchHelperGestureListener();
    this.mGestureDetector = new GestureDetectorCompat(this.mRecyclerView.getContext(), (GestureDetector.OnGestureListener)this.mItemTouchHelperGestureListener);
  }
  
  private void stopGestureDetection() {
    ItemTouchHelperGestureListener itemTouchHelperGestureListener = this.mItemTouchHelperGestureListener;
    if (itemTouchHelperGestureListener != null) {
      itemTouchHelperGestureListener.doNotReactToLongPress();
      this.mItemTouchHelperGestureListener = null;
    } 
    if (this.mGestureDetector != null)
      this.mGestureDetector = null; 
  }
  
  private int swipeIfNecessary(RecyclerView.ViewHolder paramViewHolder) {
    if (this.mActionState == 2)
      return 0; 
    int j = this.mCallback.getMovementFlags(this.mRecyclerView, paramViewHolder);
    int i = (this.mCallback.convertToAbsoluteDirection(j, ViewCompat.getLayoutDirection((View)this.mRecyclerView)) & 0xFF00) >> 8;
    if (i == 0)
      return 0; 
    int k = (j & 0xFF00) >> 8;
    if (Math.abs(this.mDx) > Math.abs(this.mDy)) {
      j = checkHorizontalSwipe(paramViewHolder, i);
      if (j > 0)
        return ((k & j) == 0) ? Callback.convertToRelativeDirection(j, ViewCompat.getLayoutDirection((View)this.mRecyclerView)) : j; 
      i = checkVerticalSwipe(paramViewHolder, i);
      if (i > 0)
        return i; 
    } else {
      j = checkVerticalSwipe(paramViewHolder, i);
      if (j > 0)
        return j; 
      j = checkHorizontalSwipe(paramViewHolder, i);
      if (j > 0) {
        i = j;
        if ((k & j) == 0)
          i = Callback.convertToRelativeDirection(j, ViewCompat.getLayoutDirection((View)this.mRecyclerView)); 
        return i;
      } 
    } 
    return 0;
  }
  
  public void attachToRecyclerView(@Nullable RecyclerView paramRecyclerView) {
    RecyclerView recyclerView = this.mRecyclerView;
    if (recyclerView == paramRecyclerView)
      return; 
    if (recyclerView != null)
      destroyCallbacks(); 
    this.mRecyclerView = paramRecyclerView;
    if (paramRecyclerView != null) {
      Resources resources = paramRecyclerView.getResources();
      this.mSwipeEscapeVelocity = resources.getDimension(R.dimen.item_touch_helper_swipe_escape_velocity);
      this.mMaxSwipeVelocity = resources.getDimension(R.dimen.item_touch_helper_swipe_escape_max_velocity);
      setupCallbacks();
    } 
  }
  
  void checkSelectForSwipe(int paramInt1, MotionEvent paramMotionEvent, int paramInt2) {
    if (this.mSelected == null && paramInt1 == 2 && this.mActionState != 2) {
      if (!this.mCallback.isItemViewSwipeEnabled())
        return; 
      if (this.mRecyclerView.getScrollState() == 1)
        return; 
      RecyclerView.ViewHolder viewHolder = findSwipedView(paramMotionEvent);
      if (viewHolder == null)
        return; 
      paramInt1 = (this.mCallback.getAbsoluteMovementFlags(this.mRecyclerView, viewHolder) & 0xFF00) >> 8;
      if (paramInt1 == 0)
        return; 
      float f1 = paramMotionEvent.getX(paramInt2);
      float f2 = paramMotionEvent.getY(paramInt2);
      f1 -= this.mInitialTouchX;
      f2 -= this.mInitialTouchY;
      float f3 = Math.abs(f1);
      float f4 = Math.abs(f2);
      paramInt2 = this.mSlop;
      if (f3 < paramInt2 && f4 < paramInt2)
        return; 
      if (f3 > f4) {
        if (f1 < 0.0F && (paramInt1 & 0x4) == 0)
          return; 
        if (f1 > 0.0F && (paramInt1 & 0x8) == 0)
          return; 
      } else {
        if (f2 < 0.0F && (paramInt1 & 0x1) == 0)
          return; 
        if (f2 > 0.0F && (paramInt1 & 0x2) == 0)
          return; 
      } 
      this.mDy = 0.0F;
      this.mDx = 0.0F;
      this.mActivePointerId = paramMotionEvent.getPointerId(0);
      select(viewHolder, 1);
    } 
  }
  
  void endRecoverAnimation(RecyclerView.ViewHolder paramViewHolder, boolean paramBoolean) {
    for (int i = this.mRecoverAnimations.size() - 1; i >= 0; i--) {
      RecoverAnimation recoverAnimation = this.mRecoverAnimations.get(i);
      if (recoverAnimation.mViewHolder == paramViewHolder) {
        recoverAnimation.mOverridden |= paramBoolean;
        if (!recoverAnimation.mEnded)
          recoverAnimation.cancel(); 
        this.mRecoverAnimations.remove(i);
        return;
      } 
    } 
  }
  
  RecoverAnimation findAnimation(MotionEvent paramMotionEvent) {
    if (this.mRecoverAnimations.isEmpty())
      return null; 
    View view = findChildView(paramMotionEvent);
    for (int i = this.mRecoverAnimations.size() - 1; i >= 0; i--) {
      RecoverAnimation recoverAnimation = this.mRecoverAnimations.get(i);
      if (recoverAnimation.mViewHolder.itemView == view)
        return recoverAnimation; 
    } 
    return null;
  }
  
  View findChildView(MotionEvent paramMotionEvent) {
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    RecyclerView.ViewHolder viewHolder = this.mSelected;
    if (viewHolder != null) {
      View view = viewHolder.itemView;
      if (hitTest(view, f1, f2, this.mSelectedStartX + this.mDx, this.mSelectedStartY + this.mDy))
        return view; 
    } 
    int i;
    for (i = this.mRecoverAnimations.size() - 1; i >= 0; i--) {
      RecoverAnimation recoverAnimation = this.mRecoverAnimations.get(i);
      View view = recoverAnimation.mViewHolder.itemView;
      if (hitTest(view, f1, f2, recoverAnimation.mX, recoverAnimation.mY))
        return view; 
    } 
    return this.mRecyclerView.findChildViewUnder(f1, f2);
  }
  
  public void getItemOffsets(Rect paramRect, View paramView, RecyclerView paramRecyclerView, RecyclerView.State paramState) {
    paramRect.setEmpty();
  }
  
  boolean hasRunningRecoverAnim() {
    int j = this.mRecoverAnimations.size();
    for (int i = 0; i < j; i++) {
      if (!((RecoverAnimation)this.mRecoverAnimations.get(i)).mEnded)
        return true; 
    } 
    return false;
  }
  
  void moveIfNecessary(RecyclerView.ViewHolder paramViewHolder) {
    if (this.mRecyclerView.isLayoutRequested())
      return; 
    if (this.mActionState != 2)
      return; 
    float f = this.mCallback.getMoveThreshold(paramViewHolder);
    int i = (int)(this.mSelectedStartX + this.mDx);
    int j = (int)(this.mSelectedStartY + this.mDy);
    if (Math.abs(j - paramViewHolder.itemView.getTop()) < paramViewHolder.itemView.getHeight() * f && Math.abs(i - paramViewHolder.itemView.getLeft()) < paramViewHolder.itemView.getWidth() * f)
      return; 
    List<RecyclerView.ViewHolder> list = findSwapTargets(paramViewHolder);
    if (list.size() == 0)
      return; 
    RecyclerView.ViewHolder viewHolder = this.mCallback.chooseDropTarget(paramViewHolder, list, i, j);
    if (viewHolder == null) {
      this.mSwapTargets.clear();
      this.mDistances.clear();
      return;
    } 
    int k = viewHolder.getAbsoluteAdapterPosition();
    int m = paramViewHolder.getAbsoluteAdapterPosition();
    if (this.mCallback.onMove(this.mRecyclerView, paramViewHolder, viewHolder))
      this.mCallback.onMoved(this.mRecyclerView, paramViewHolder, m, viewHolder, k, i, j); 
  }
  
  void obtainVelocityTracker() {
    VelocityTracker velocityTracker = this.mVelocityTracker;
    if (velocityTracker != null)
      velocityTracker.recycle(); 
    this.mVelocityTracker = VelocityTracker.obtain();
  }
  
  public void onChildViewAttachedToWindow(@NonNull View paramView) {}
  
  public void onChildViewDetachedFromWindow(@NonNull View paramView) {
    removeChildDrawingOrderCallbackIfNecessary(paramView);
    RecyclerView.ViewHolder viewHolder1 = this.mRecyclerView.getChildViewHolder(paramView);
    if (viewHolder1 == null)
      return; 
    RecyclerView.ViewHolder viewHolder2 = this.mSelected;
    if (viewHolder2 != null && viewHolder1 == viewHolder2) {
      select(null, 0);
      return;
    } 
    endRecoverAnimation(viewHolder1, false);
    if (this.mPendingCleanup.remove(viewHolder1.itemView))
      this.mCallback.clearView(this.mRecyclerView, viewHolder1); 
  }
  
  public void onDraw(Canvas paramCanvas, RecyclerView paramRecyclerView, RecyclerView.State paramState) {
    float f1;
    float f2;
    this.mOverdrawChildPosition = -1;
    if (this.mSelected != null) {
      getSelectedDxDy(this.mTmpPosition);
      float[] arrayOfFloat = this.mTmpPosition;
      f1 = arrayOfFloat[0];
      f2 = arrayOfFloat[1];
    } else {
      f1 = 0.0F;
      f2 = 0.0F;
    } 
    this.mCallback.onDraw(paramCanvas, paramRecyclerView, this.mSelected, this.mRecoverAnimations, this.mActionState, f1, f2);
  }
  
  public void onDrawOver(Canvas paramCanvas, RecyclerView paramRecyclerView, RecyclerView.State paramState) {
    float f1;
    float f2;
    if (this.mSelected != null) {
      getSelectedDxDy(this.mTmpPosition);
      float[] arrayOfFloat = this.mTmpPosition;
      f1 = arrayOfFloat[0];
      f2 = arrayOfFloat[1];
    } else {
      f1 = 0.0F;
      f2 = 0.0F;
    } 
    this.mCallback.onDrawOver(paramCanvas, paramRecyclerView, this.mSelected, this.mRecoverAnimations, this.mActionState, f1, f2);
  }
  
  void postDispatchSwipe(final RecoverAnimation anim, final int swipeDir) {
    this.mRecyclerView.post(new Runnable() {
          public void run() {
            if (ItemTouchHelper.this.mRecyclerView != null && ItemTouchHelper.this.mRecyclerView.isAttachedToWindow() && !anim.mOverridden && anim.mViewHolder.getAbsoluteAdapterPosition() != -1) {
              RecyclerView.ItemAnimator itemAnimator = ItemTouchHelper.this.mRecyclerView.getItemAnimator();
              if ((itemAnimator == null || !itemAnimator.isRunning(null)) && !ItemTouchHelper.this.hasRunningRecoverAnim()) {
                ItemTouchHelper.this.mCallback.onSwiped(anim.mViewHolder, swipeDir);
                return;
              } 
              ItemTouchHelper.this.mRecyclerView.post(this);
            } 
          }
        });
  }
  
  void removeChildDrawingOrderCallbackIfNecessary(View paramView) {
    if (paramView == this.mOverdrawChild) {
      this.mOverdrawChild = null;
      if (this.mChildDrawingOrderCallback != null)
        this.mRecyclerView.setChildDrawingOrderCallback((RecyclerView.ChildDrawingOrderCallback)null); 
    } 
  }
  
  boolean scrollIfNecessary() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mSelected : Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    //   4: ifnonnull -> 16
    //   7: aload_0
    //   8: ldc2_w -9223372036854775808
    //   11: putfield mDragScrollStartTimeInMs : J
    //   14: iconst_0
    //   15: ireturn
    //   16: invokestatic currentTimeMillis : ()J
    //   19: lstore #6
    //   21: aload_0
    //   22: getfield mDragScrollStartTimeInMs : J
    //   25: lstore #4
    //   27: lload #4
    //   29: ldc2_w -9223372036854775808
    //   32: lcmp
    //   33: ifne -> 42
    //   36: lconst_0
    //   37: lstore #4
    //   39: goto -> 49
    //   42: lload #6
    //   44: lload #4
    //   46: lsub
    //   47: lstore #4
    //   49: aload_0
    //   50: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   53: invokevirtual getLayoutManager : ()Landroidx/recyclerview/widget/RecyclerView$LayoutManager;
    //   56: astore #8
    //   58: aload_0
    //   59: getfield mTmpRect : Landroid/graphics/Rect;
    //   62: ifnonnull -> 76
    //   65: aload_0
    //   66: new android/graphics/Rect
    //   69: dup
    //   70: invokespecial <init> : ()V
    //   73: putfield mTmpRect : Landroid/graphics/Rect;
    //   76: aload #8
    //   78: aload_0
    //   79: getfield mSelected : Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    //   82: getfield itemView : Landroid/view/View;
    //   85: aload_0
    //   86: getfield mTmpRect : Landroid/graphics/Rect;
    //   89: invokevirtual calculateItemDecorationsForChild : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   92: aload #8
    //   94: invokevirtual canScrollHorizontally : ()Z
    //   97: ifeq -> 198
    //   100: aload_0
    //   101: getfield mSelectedStartX : F
    //   104: aload_0
    //   105: getfield mDx : F
    //   108: fadd
    //   109: f2i
    //   110: istore_2
    //   111: iload_2
    //   112: aload_0
    //   113: getfield mTmpRect : Landroid/graphics/Rect;
    //   116: getfield left : I
    //   119: isub
    //   120: aload_0
    //   121: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   124: invokevirtual getPaddingLeft : ()I
    //   127: isub
    //   128: istore_1
    //   129: aload_0
    //   130: getfield mDx : F
    //   133: fconst_0
    //   134: fcmpg
    //   135: ifge -> 145
    //   138: iload_1
    //   139: ifge -> 145
    //   142: goto -> 200
    //   145: aload_0
    //   146: getfield mDx : F
    //   149: fconst_0
    //   150: fcmpl
    //   151: ifle -> 198
    //   154: iload_2
    //   155: aload_0
    //   156: getfield mSelected : Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    //   159: getfield itemView : Landroid/view/View;
    //   162: invokevirtual getWidth : ()I
    //   165: iadd
    //   166: aload_0
    //   167: getfield mTmpRect : Landroid/graphics/Rect;
    //   170: getfield right : I
    //   173: iadd
    //   174: aload_0
    //   175: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   178: invokevirtual getWidth : ()I
    //   181: aload_0
    //   182: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   185: invokevirtual getPaddingRight : ()I
    //   188: isub
    //   189: isub
    //   190: istore_1
    //   191: iload_1
    //   192: ifle -> 198
    //   195: goto -> 200
    //   198: iconst_0
    //   199: istore_1
    //   200: aload #8
    //   202: invokevirtual canScrollVertically : ()Z
    //   205: ifeq -> 306
    //   208: aload_0
    //   209: getfield mSelectedStartY : F
    //   212: aload_0
    //   213: getfield mDy : F
    //   216: fadd
    //   217: f2i
    //   218: istore_3
    //   219: iload_3
    //   220: aload_0
    //   221: getfield mTmpRect : Landroid/graphics/Rect;
    //   224: getfield top : I
    //   227: isub
    //   228: aload_0
    //   229: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   232: invokevirtual getPaddingTop : ()I
    //   235: isub
    //   236: istore_2
    //   237: aload_0
    //   238: getfield mDy : F
    //   241: fconst_0
    //   242: fcmpg
    //   243: ifge -> 253
    //   246: iload_2
    //   247: ifge -> 253
    //   250: goto -> 308
    //   253: aload_0
    //   254: getfield mDy : F
    //   257: fconst_0
    //   258: fcmpl
    //   259: ifle -> 306
    //   262: iload_3
    //   263: aload_0
    //   264: getfield mSelected : Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    //   267: getfield itemView : Landroid/view/View;
    //   270: invokevirtual getHeight : ()I
    //   273: iadd
    //   274: aload_0
    //   275: getfield mTmpRect : Landroid/graphics/Rect;
    //   278: getfield bottom : I
    //   281: iadd
    //   282: aload_0
    //   283: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   286: invokevirtual getHeight : ()I
    //   289: aload_0
    //   290: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   293: invokevirtual getPaddingBottom : ()I
    //   296: isub
    //   297: isub
    //   298: istore_2
    //   299: iload_2
    //   300: ifle -> 306
    //   303: goto -> 308
    //   306: iconst_0
    //   307: istore_2
    //   308: iload_1
    //   309: istore_3
    //   310: iload_1
    //   311: ifeq -> 346
    //   314: aload_0
    //   315: getfield mCallback : Landroidx/recyclerview/widget/ItemTouchHelper$Callback;
    //   318: aload_0
    //   319: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   322: aload_0
    //   323: getfield mSelected : Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    //   326: getfield itemView : Landroid/view/View;
    //   329: invokevirtual getWidth : ()I
    //   332: iload_1
    //   333: aload_0
    //   334: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   337: invokevirtual getWidth : ()I
    //   340: lload #4
    //   342: invokevirtual interpolateOutOfBoundsScroll : (Landroidx/recyclerview/widget/RecyclerView;IIIJ)I
    //   345: istore_3
    //   346: iload_2
    //   347: ifeq -> 385
    //   350: aload_0
    //   351: getfield mCallback : Landroidx/recyclerview/widget/ItemTouchHelper$Callback;
    //   354: aload_0
    //   355: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   358: aload_0
    //   359: getfield mSelected : Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    //   362: getfield itemView : Landroid/view/View;
    //   365: invokevirtual getHeight : ()I
    //   368: iload_2
    //   369: aload_0
    //   370: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   373: invokevirtual getHeight : ()I
    //   376: lload #4
    //   378: invokevirtual interpolateOutOfBoundsScroll : (Landroidx/recyclerview/widget/RecyclerView;IIIJ)I
    //   381: istore_2
    //   382: goto -> 385
    //   385: iload_3
    //   386: ifne -> 405
    //   389: iload_2
    //   390: ifeq -> 396
    //   393: goto -> 405
    //   396: aload_0
    //   397: ldc2_w -9223372036854775808
    //   400: putfield mDragScrollStartTimeInMs : J
    //   403: iconst_0
    //   404: ireturn
    //   405: aload_0
    //   406: getfield mDragScrollStartTimeInMs : J
    //   409: ldc2_w -9223372036854775808
    //   412: lcmp
    //   413: ifne -> 422
    //   416: aload_0
    //   417: lload #6
    //   419: putfield mDragScrollStartTimeInMs : J
    //   422: aload_0
    //   423: getfield mRecyclerView : Landroidx/recyclerview/widget/RecyclerView;
    //   426: iload_3
    //   427: iload_2
    //   428: invokevirtual scrollBy : (II)V
    //   431: iconst_1
    //   432: ireturn
  }
  
  void select(@Nullable RecyclerView.ViewHolder paramViewHolder, int paramInt) {
    boolean bool1;
    if (paramViewHolder == this.mSelected && paramInt == this.mActionState)
      return; 
    this.mDragScrollStartTimeInMs = Long.MIN_VALUE;
    int i = this.mActionState;
    endRecoverAnimation(paramViewHolder, true);
    this.mActionState = paramInt;
    if (paramInt == 2)
      if (paramViewHolder != null) {
        this.mOverdrawChild = paramViewHolder.itemView;
        addChildDrawingOrderCallback();
      } else {
        throw new IllegalArgumentException("Must pass a ViewHolder when dragging");
      }  
    final RecyclerView.ViewHolder prevSelected = this.mSelected;
    if (viewHolder != null) {
      RecoverAnimation recoverAnimation;
      if (viewHolder.itemView.getParent() != null) {
        float f1;
        float f2;
        final int swipeDir;
        if (i == 2) {
          j = 0;
        } else {
          j = swipeIfNecessary(viewHolder);
        } 
        releaseVelocityTracker();
        if (j != 1 && j != 2) {
          if (j != 4 && j != 8 && j != 16 && j != 32) {
            f1 = 0.0F;
          } else {
            f1 = Math.signum(this.mDx) * this.mRecyclerView.getWidth();
          } 
          f2 = 0.0F;
        } else {
          f2 = Math.signum(this.mDy) * this.mRecyclerView.getHeight();
          f1 = 0.0F;
        } 
        if (i == 2) {
          bool1 = true;
        } else if (j > 0) {
          bool1 = true;
        } else {
          bool1 = true;
        } 
        getSelectedDxDy(this.mTmpPosition);
        float[] arrayOfFloat = this.mTmpPosition;
        float f3 = arrayOfFloat[0];
        float f4 = arrayOfFloat[1];
        recoverAnimation = new RecoverAnimation(viewHolder, bool1, i, f3, f4, f1, f2) {
            public void onAnimationEnd(Animator param1Animator) {
              super.onAnimationEnd(param1Animator);
              if (this.mOverridden)
                return; 
              if (swipeDir <= 0) {
                ItemTouchHelper.this.mCallback.clearView(ItemTouchHelper.this.mRecyclerView, prevSelected);
              } else {
                ItemTouchHelper.this.mPendingCleanup.add(prevSelected.itemView);
                this.mIsPendingCleanup = true;
                int i = swipeDir;
                if (i > 0)
                  ItemTouchHelper.this.postDispatchSwipe(this, i); 
              } 
              if (ItemTouchHelper.this.mOverdrawChild == prevSelected.itemView)
                ItemTouchHelper.this.removeChildDrawingOrderCallbackIfNecessary(prevSelected.itemView); 
            }
          };
        recoverAnimation.setDuration(this.mCallback.getAnimationDuration(this.mRecyclerView, bool1, f1 - f3, f2 - f4));
        this.mRecoverAnimations.add(recoverAnimation);
        recoverAnimation.start();
        bool1 = true;
      } else {
        removeChildDrawingOrderCallbackIfNecessary(((RecyclerView.ViewHolder)recoverAnimation).itemView);
        this.mCallback.clearView(this.mRecyclerView, (RecyclerView.ViewHolder)recoverAnimation);
        bool1 = false;
      } 
      this.mSelected = null;
    } else {
      bool1 = false;
    } 
    if (paramViewHolder != null) {
      this.mSelectedFlags = (this.mCallback.getAbsoluteMovementFlags(this.mRecyclerView, paramViewHolder) & (1 << paramInt * 8 + 8) - 1) >> this.mActionState * 8;
      this.mSelectedStartX = paramViewHolder.itemView.getLeft();
      this.mSelectedStartY = paramViewHolder.itemView.getTop();
      this.mSelected = paramViewHolder;
      if (paramInt == 2)
        this.mSelected.itemView.performHapticFeedback(0); 
    } 
    boolean bool2 = false;
    ViewParent viewParent = this.mRecyclerView.getParent();
    if (viewParent != null) {
      if (this.mSelected != null)
        bool2 = true; 
      viewParent.requestDisallowInterceptTouchEvent(bool2);
    } 
    if (!bool1)
      this.mRecyclerView.getLayoutManager().requestSimpleAnimationsInNextLayout(); 
    this.mCallback.onSelectedChanged(this.mSelected, this.mActionState);
    this.mRecyclerView.invalidate();
  }
  
  public void startDrag(@NonNull RecyclerView.ViewHolder paramViewHolder) {
    if (!this.mCallback.hasDragFlag(this.mRecyclerView, paramViewHolder)) {
      Log.e("ItemTouchHelper", "Start drag has been called but dragging is not enabled");
      return;
    } 
    if (paramViewHolder.itemView.getParent() != this.mRecyclerView) {
      Log.e("ItemTouchHelper", "Start drag has been called with a view holder which is not a child of the RecyclerView which is controlled by this ItemTouchHelper.");
      return;
    } 
    obtainVelocityTracker();
    this.mDy = 0.0F;
    this.mDx = 0.0F;
    select(paramViewHolder, 2);
  }
  
  public void startSwipe(@NonNull RecyclerView.ViewHolder paramViewHolder) {
    if (!this.mCallback.hasSwipeFlag(this.mRecyclerView, paramViewHolder)) {
      Log.e("ItemTouchHelper", "Start swipe has been called but swiping is not enabled");
      return;
    } 
    if (paramViewHolder.itemView.getParent() != this.mRecyclerView) {
      Log.e("ItemTouchHelper", "Start swipe has been called with a view holder which is not a child of the RecyclerView controlled by this ItemTouchHelper.");
      return;
    } 
    obtainVelocityTracker();
    this.mDy = 0.0F;
    this.mDx = 0.0F;
    select(paramViewHolder, 1);
  }
  
  void updateDxDy(MotionEvent paramMotionEvent, int paramInt1, int paramInt2) {
    float f1 = paramMotionEvent.getX(paramInt2);
    float f2 = paramMotionEvent.getY(paramInt2);
    this.mDx = f1 - this.mInitialTouchX;
    this.mDy = f2 - this.mInitialTouchY;
    if ((paramInt1 & 0x4) == 0)
      this.mDx = Math.max(0.0F, this.mDx); 
    if ((paramInt1 & 0x8) == 0)
      this.mDx = Math.min(0.0F, this.mDx); 
    if ((paramInt1 & 0x1) == 0)
      this.mDy = Math.max(0.0F, this.mDy); 
    if ((paramInt1 & 0x2) == 0)
      this.mDy = Math.min(0.0F, this.mDy); 
  }
  
  public static abstract class Callback {
    private static final int ABS_HORIZONTAL_DIR_FLAGS = 789516;
    
    public static final int DEFAULT_DRAG_ANIMATION_DURATION = 200;
    
    public static final int DEFAULT_SWIPE_ANIMATION_DURATION = 250;
    
    private static final long DRAG_SCROLL_ACCELERATION_LIMIT_TIME_MS = 2000L;
    
    static final int RELATIVE_DIR_FLAGS = 3158064;
    
    private static final Interpolator sDragScrollInterpolator = new Interpolator() {
        public float getInterpolation(float param2Float) {
          return param2Float * param2Float * param2Float * param2Float * param2Float;
        }
      };
    
    private static final Interpolator sDragViewScrollCapInterpolator = new Interpolator() {
        public float getInterpolation(float param2Float) {
          param2Float--;
          return param2Float * param2Float * param2Float * param2Float * param2Float + 1.0F;
        }
      };
    
    private int mCachedMaxScrollSpeed = -1;
    
    public static int convertToRelativeDirection(int param1Int1, int param1Int2) {
      int i = param1Int1 & 0xC0C0C;
      if (i == 0)
        return param1Int1; 
      param1Int1 &= i;
      if (param1Int2 == 0) {
        param1Int2 = i << 2;
        return param1Int1 | param1Int2;
      } 
      param1Int2 = i << 1;
      param1Int1 |= 0xFFF3F3F3 & param1Int2;
      param1Int2 = (param1Int2 & 0xC0C0C) << 2;
      return param1Int1 | param1Int2;
    }
    
    @NonNull
    public static ItemTouchUIUtil getDefaultUIUtil() {
      return ItemTouchUIUtilImpl.INSTANCE;
    }
    
    private int getMaxDragScroll(RecyclerView param1RecyclerView) {
      if (this.mCachedMaxScrollSpeed == -1)
        this.mCachedMaxScrollSpeed = param1RecyclerView.getResources().getDimensionPixelSize(R.dimen.item_touch_helper_max_drag_scroll_per_frame); 
      return this.mCachedMaxScrollSpeed;
    }
    
    public static int makeFlag(int param1Int1, int param1Int2) {
      return param1Int2 << param1Int1 * 8;
    }
    
    public static int makeMovementFlags(int param1Int1, int param1Int2) {
      int i = makeFlag(0, param1Int2 | param1Int1);
      param1Int2 = makeFlag(1, param1Int2);
      return makeFlag(2, param1Int1) | param1Int2 | i;
    }
    
    public boolean canDropOver(@NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder1, @NonNull RecyclerView.ViewHolder param1ViewHolder2) {
      return true;
    }
    
    public RecyclerView.ViewHolder chooseDropTarget(@NonNull RecyclerView.ViewHolder param1ViewHolder, @NonNull List<RecyclerView.ViewHolder> param1List, int param1Int1, int param1Int2) {
      // Byte code:
      //   0: aload_1
      //   1: getfield itemView : Landroid/view/View;
      //   4: invokevirtual getWidth : ()I
      //   7: istore #9
      //   9: aload_1
      //   10: getfield itemView : Landroid/view/View;
      //   13: invokevirtual getHeight : ()I
      //   16: istore #10
      //   18: iload_3
      //   19: aload_1
      //   20: getfield itemView : Landroid/view/View;
      //   23: invokevirtual getLeft : ()I
      //   26: isub
      //   27: istore #11
      //   29: iload #4
      //   31: aload_1
      //   32: getfield itemView : Landroid/view/View;
      //   35: invokevirtual getTop : ()I
      //   38: isub
      //   39: istore #12
      //   41: aload_2
      //   42: invokeinterface size : ()I
      //   47: istore #13
      //   49: aconst_null
      //   50: astore #16
      //   52: iconst_m1
      //   53: istore #5
      //   55: iconst_0
      //   56: istore #7
      //   58: iload #7
      //   60: iload #13
      //   62: if_icmpge -> 413
      //   65: aload_2
      //   66: iload #7
      //   68: invokeinterface get : (I)Ljava/lang/Object;
      //   73: checkcast androidx/recyclerview/widget/RecyclerView$ViewHolder
      //   76: astore #14
      //   78: iload #11
      //   80: ifle -> 142
      //   83: aload #14
      //   85: getfield itemView : Landroid/view/View;
      //   88: invokevirtual getRight : ()I
      //   91: iload_3
      //   92: iload #9
      //   94: iadd
      //   95: isub
      //   96: istore #6
      //   98: iload #6
      //   100: ifge -> 142
      //   103: aload #14
      //   105: getfield itemView : Landroid/view/View;
      //   108: invokevirtual getRight : ()I
      //   111: aload_1
      //   112: getfield itemView : Landroid/view/View;
      //   115: invokevirtual getRight : ()I
      //   118: if_icmple -> 142
      //   121: iload #6
      //   123: invokestatic abs : (I)I
      //   126: istore #6
      //   128: iload #6
      //   130: iload #5
      //   132: if_icmple -> 142
      //   135: aload #14
      //   137: astore #16
      //   139: goto -> 146
      //   142: iload #5
      //   144: istore #6
      //   146: aload #16
      //   148: astore #15
      //   150: iload #6
      //   152: istore #5
      //   154: iload #11
      //   156: ifge -> 240
      //   159: aload #14
      //   161: getfield itemView : Landroid/view/View;
      //   164: invokevirtual getLeft : ()I
      //   167: iload_3
      //   168: isub
      //   169: istore #8
      //   171: aload #16
      //   173: astore #15
      //   175: iload #6
      //   177: istore #5
      //   179: iload #8
      //   181: ifle -> 240
      //   184: aload #16
      //   186: astore #15
      //   188: iload #6
      //   190: istore #5
      //   192: aload #14
      //   194: getfield itemView : Landroid/view/View;
      //   197: invokevirtual getLeft : ()I
      //   200: aload_1
      //   201: getfield itemView : Landroid/view/View;
      //   204: invokevirtual getLeft : ()I
      //   207: if_icmpge -> 240
      //   210: iload #8
      //   212: invokestatic abs : (I)I
      //   215: istore #8
      //   217: aload #16
      //   219: astore #15
      //   221: iload #6
      //   223: istore #5
      //   225: iload #8
      //   227: iload #6
      //   229: if_icmple -> 240
      //   232: iload #8
      //   234: istore #5
      //   236: aload #14
      //   238: astore #15
      //   240: aload #15
      //   242: astore #16
      //   244: iload #5
      //   246: istore #6
      //   248: iload #12
      //   250: ifge -> 335
      //   253: aload #14
      //   255: getfield itemView : Landroid/view/View;
      //   258: invokevirtual getTop : ()I
      //   261: iload #4
      //   263: isub
      //   264: istore #8
      //   266: aload #15
      //   268: astore #16
      //   270: iload #5
      //   272: istore #6
      //   274: iload #8
      //   276: ifle -> 335
      //   279: aload #15
      //   281: astore #16
      //   283: iload #5
      //   285: istore #6
      //   287: aload #14
      //   289: getfield itemView : Landroid/view/View;
      //   292: invokevirtual getTop : ()I
      //   295: aload_1
      //   296: getfield itemView : Landroid/view/View;
      //   299: invokevirtual getTop : ()I
      //   302: if_icmpge -> 335
      //   305: iload #8
      //   307: invokestatic abs : (I)I
      //   310: istore #8
      //   312: aload #15
      //   314: astore #16
      //   316: iload #5
      //   318: istore #6
      //   320: iload #8
      //   322: iload #5
      //   324: if_icmple -> 335
      //   327: iload #8
      //   329: istore #6
      //   331: aload #14
      //   333: astore #16
      //   335: iload #12
      //   337: ifle -> 400
      //   340: aload #14
      //   342: getfield itemView : Landroid/view/View;
      //   345: invokevirtual getBottom : ()I
      //   348: iload #4
      //   350: iload #10
      //   352: iadd
      //   353: isub
      //   354: istore #5
      //   356: iload #5
      //   358: ifge -> 400
      //   361: aload #14
      //   363: getfield itemView : Landroid/view/View;
      //   366: invokevirtual getBottom : ()I
      //   369: aload_1
      //   370: getfield itemView : Landroid/view/View;
      //   373: invokevirtual getBottom : ()I
      //   376: if_icmple -> 400
      //   379: iload #5
      //   381: invokestatic abs : (I)I
      //   384: istore #5
      //   386: iload #5
      //   388: iload #6
      //   390: if_icmple -> 400
      //   393: aload #14
      //   395: astore #16
      //   397: goto -> 404
      //   400: iload #6
      //   402: istore #5
      //   404: iload #7
      //   406: iconst_1
      //   407: iadd
      //   408: istore #7
      //   410: goto -> 58
      //   413: aload #16
      //   415: areturn
    }
    
    public void clearView(@NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder) {
      ItemTouchUIUtilImpl.INSTANCE.clearView(param1ViewHolder.itemView);
    }
    
    public int convertToAbsoluteDirection(int param1Int1, int param1Int2) {
      int i = param1Int1 & 0x303030;
      if (i == 0)
        return param1Int1; 
      param1Int1 &= i;
      if (param1Int2 == 0) {
        param1Int2 = i >> 2;
        return param1Int1 | param1Int2;
      } 
      param1Int2 = i >> 1;
      param1Int1 |= 0xFFCFCFCF & param1Int2;
      param1Int2 = (param1Int2 & 0x303030) >> 2;
      return param1Int1 | param1Int2;
    }
    
    final int getAbsoluteMovementFlags(RecyclerView param1RecyclerView, RecyclerView.ViewHolder param1ViewHolder) {
      return convertToAbsoluteDirection(getMovementFlags(param1RecyclerView, param1ViewHolder), ViewCompat.getLayoutDirection((View)param1RecyclerView));
    }
    
    public long getAnimationDuration(@NonNull RecyclerView param1RecyclerView, int param1Int, float param1Float1, float param1Float2) {
      RecyclerView.ItemAnimator itemAnimator = param1RecyclerView.getItemAnimator();
      return (itemAnimator == null) ? ((param1Int == 8) ? 200L : 250L) : ((param1Int == 8) ? itemAnimator.getMoveDuration() : itemAnimator.getRemoveDuration());
    }
    
    public int getBoundingBoxMargin() {
      return 0;
    }
    
    public float getMoveThreshold(@NonNull RecyclerView.ViewHolder param1ViewHolder) {
      return 0.5F;
    }
    
    public abstract int getMovementFlags(@NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder);
    
    public float getSwipeEscapeVelocity(float param1Float) {
      return param1Float;
    }
    
    public float getSwipeThreshold(@NonNull RecyclerView.ViewHolder param1ViewHolder) {
      return 0.5F;
    }
    
    public float getSwipeVelocityThreshold(float param1Float) {
      return param1Float;
    }
    
    boolean hasDragFlag(RecyclerView param1RecyclerView, RecyclerView.ViewHolder param1ViewHolder) {
      return ((getAbsoluteMovementFlags(param1RecyclerView, param1ViewHolder) & 0xFF0000) != 0);
    }
    
    boolean hasSwipeFlag(RecyclerView param1RecyclerView, RecyclerView.ViewHolder param1ViewHolder) {
      return ((getAbsoluteMovementFlags(param1RecyclerView, param1ViewHolder) & 0xFF00) != 0);
    }
    
    public int interpolateOutOfBoundsScroll(@NonNull RecyclerView param1RecyclerView, int param1Int1, int param1Int2, int param1Int3, long param1Long) {
      param1Int3 = getMaxDragScroll(param1RecyclerView);
      int i = Math.abs(param1Int2);
      int j = (int)Math.signum(param1Int2);
      float f2 = i;
      float f1 = 1.0F;
      f2 = Math.min(1.0F, f2 * 1.0F / param1Int1);
      param1Int1 = (int)((j * param1Int3) * sDragViewScrollCapInterpolator.getInterpolation(f2));
      if (param1Long <= 2000L)
        f1 = (float)param1Long / 2000.0F; 
      param1Int3 = (int)(param1Int1 * sDragScrollInterpolator.getInterpolation(f1));
      param1Int1 = param1Int3;
      if (param1Int3 == 0) {
        if (param1Int2 > 0)
          return 1; 
        param1Int1 = -1;
      } 
      return param1Int1;
    }
    
    public boolean isItemViewSwipeEnabled() {
      return true;
    }
    
    public boolean isLongPressDragEnabled() {
      return true;
    }
    
    public void onChildDraw(@NonNull Canvas param1Canvas, @NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder, float param1Float1, float param1Float2, int param1Int, boolean param1Boolean) {
      ItemTouchUIUtilImpl.INSTANCE.onDraw(param1Canvas, param1RecyclerView, param1ViewHolder.itemView, param1Float1, param1Float2, param1Int, param1Boolean);
    }
    
    public void onChildDrawOver(@NonNull Canvas param1Canvas, @NonNull RecyclerView param1RecyclerView, RecyclerView.ViewHolder param1ViewHolder, float param1Float1, float param1Float2, int param1Int, boolean param1Boolean) {
      ItemTouchUIUtilImpl.INSTANCE.onDrawOver(param1Canvas, param1RecyclerView, param1ViewHolder.itemView, param1Float1, param1Float2, param1Int, param1Boolean);
    }
    
    void onDraw(Canvas param1Canvas, RecyclerView param1RecyclerView, RecyclerView.ViewHolder param1ViewHolder, List<ItemTouchHelper.RecoverAnimation> param1List, int param1Int, float param1Float1, float param1Float2) {
      int j = param1List.size();
      int i;
      for (i = 0; i < j; i++) {
        ItemTouchHelper.RecoverAnimation recoverAnimation = param1List.get(i);
        recoverAnimation.update();
        int k = param1Canvas.save();
        onChildDraw(param1Canvas, param1RecyclerView, recoverAnimation.mViewHolder, recoverAnimation.mX, recoverAnimation.mY, recoverAnimation.mActionState, false);
        param1Canvas.restoreToCount(k);
      } 
      if (param1ViewHolder != null) {
        i = param1Canvas.save();
        onChildDraw(param1Canvas, param1RecyclerView, param1ViewHolder, param1Float1, param1Float2, param1Int, true);
        param1Canvas.restoreToCount(i);
      } 
    }
    
    void onDrawOver(Canvas param1Canvas, RecyclerView param1RecyclerView, RecyclerView.ViewHolder param1ViewHolder, List<ItemTouchHelper.RecoverAnimation> param1List, int param1Int, float param1Float1, float param1Float2) {
      int j = param1List.size();
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++) {
        ItemTouchHelper.RecoverAnimation recoverAnimation = param1List.get(i);
        int k = param1Canvas.save();
        onChildDrawOver(param1Canvas, param1RecyclerView, recoverAnimation.mViewHolder, recoverAnimation.mX, recoverAnimation.mY, recoverAnimation.mActionState, false);
        param1Canvas.restoreToCount(k);
      } 
      if (param1ViewHolder != null) {
        i = param1Canvas.save();
        onChildDrawOver(param1Canvas, param1RecyclerView, param1ViewHolder, param1Float1, param1Float2, param1Int, true);
        param1Canvas.restoreToCount(i);
      } 
      param1Int = j - 1;
      i = bool;
      while (param1Int >= 0) {
        ItemTouchHelper.RecoverAnimation recoverAnimation = param1List.get(param1Int);
        if (recoverAnimation.mEnded && !recoverAnimation.mIsPendingCleanup) {
          param1List.remove(param1Int);
        } else if (!recoverAnimation.mEnded) {
          i = 1;
        } 
        param1Int--;
      } 
      if (i != 0)
        param1RecyclerView.invalidate(); 
    }
    
    public abstract boolean onMove(@NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder1, @NonNull RecyclerView.ViewHolder param1ViewHolder2);
    
    public void onMoved(@NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder1, int param1Int1, @NonNull RecyclerView.ViewHolder param1ViewHolder2, int param1Int2, int param1Int3, int param1Int4) {
      RecyclerView.LayoutManager layoutManager = param1RecyclerView.getLayoutManager();
      if (layoutManager instanceof ItemTouchHelper.ViewDropHandler) {
        ((ItemTouchHelper.ViewDropHandler)layoutManager).prepareForDrop(param1ViewHolder1.itemView, param1ViewHolder2.itemView, param1Int3, param1Int4);
        return;
      } 
      if (layoutManager.canScrollHorizontally()) {
        if (layoutManager.getDecoratedLeft(param1ViewHolder2.itemView) <= param1RecyclerView.getPaddingLeft())
          param1RecyclerView.scrollToPosition(param1Int2); 
        if (layoutManager.getDecoratedRight(param1ViewHolder2.itemView) >= param1RecyclerView.getWidth() - param1RecyclerView.getPaddingRight())
          param1RecyclerView.scrollToPosition(param1Int2); 
      } 
      if (layoutManager.canScrollVertically()) {
        if (layoutManager.getDecoratedTop(param1ViewHolder2.itemView) <= param1RecyclerView.getPaddingTop())
          param1RecyclerView.scrollToPosition(param1Int2); 
        if (layoutManager.getDecoratedBottom(param1ViewHolder2.itemView) >= param1RecyclerView.getHeight() - param1RecyclerView.getPaddingBottom())
          param1RecyclerView.scrollToPosition(param1Int2); 
      } 
    }
    
    public void onSelectedChanged(@Nullable RecyclerView.ViewHolder param1ViewHolder, int param1Int) {
      if (param1ViewHolder != null)
        ItemTouchUIUtilImpl.INSTANCE.onSelected(param1ViewHolder.itemView); 
    }
    
    public abstract void onSwiped(@NonNull RecyclerView.ViewHolder param1ViewHolder, int param1Int);
  }
  
  class null implements Interpolator {
    public float getInterpolation(float param1Float) {
      return param1Float * param1Float * param1Float * param1Float * param1Float;
    }
  }
  
  class null implements Interpolator {
    public float getInterpolation(float param1Float) {
      param1Float--;
      return param1Float * param1Float * param1Float * param1Float * param1Float + 1.0F;
    }
  }
  
  private class ItemTouchHelperGestureListener extends GestureDetector.SimpleOnGestureListener {
    private boolean mShouldReactToLongPress = true;
    
    void doNotReactToLongPress() {
      this.mShouldReactToLongPress = false;
    }
    
    public boolean onDown(MotionEvent param1MotionEvent) {
      return true;
    }
    
    public void onLongPress(MotionEvent param1MotionEvent) {
      if (!this.mShouldReactToLongPress)
        return; 
      View view = ItemTouchHelper.this.findChildView(param1MotionEvent);
      if (view != null) {
        RecyclerView.ViewHolder viewHolder = ItemTouchHelper.this.mRecyclerView.getChildViewHolder(view);
        if (viewHolder != null) {
          if (!ItemTouchHelper.this.mCallback.hasDragFlag(ItemTouchHelper.this.mRecyclerView, viewHolder))
            return; 
          if (param1MotionEvent.getPointerId(0) == ItemTouchHelper.this.mActivePointerId) {
            int i = param1MotionEvent.findPointerIndex(ItemTouchHelper.this.mActivePointerId);
            float f1 = param1MotionEvent.getX(i);
            float f2 = param1MotionEvent.getY(i);
            ItemTouchHelper itemTouchHelper = ItemTouchHelper.this;
            itemTouchHelper.mInitialTouchX = f1;
            itemTouchHelper.mInitialTouchY = f2;
            itemTouchHelper.mDy = 0.0F;
            itemTouchHelper.mDx = 0.0F;
            if (itemTouchHelper.mCallback.isLongPressDragEnabled())
              ItemTouchHelper.this.select(viewHolder, 2); 
          } 
        } 
      } 
    }
  }
  
  @VisibleForTesting
  static class RecoverAnimation implements Animator.AnimatorListener {
    final int mActionState;
    
    final int mAnimationType;
    
    boolean mEnded = false;
    
    private float mFraction;
    
    boolean mIsPendingCleanup;
    
    boolean mOverridden = false;
    
    final float mStartDx;
    
    final float mStartDy;
    
    final float mTargetX;
    
    final float mTargetY;
    
    @VisibleForTesting
    final ValueAnimator mValueAnimator;
    
    final RecyclerView.ViewHolder mViewHolder;
    
    float mX;
    
    float mY;
    
    RecoverAnimation(RecyclerView.ViewHolder param1ViewHolder, int param1Int1, int param1Int2, float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      this.mActionState = param1Int2;
      this.mAnimationType = param1Int1;
      this.mViewHolder = param1ViewHolder;
      this.mStartDx = param1Float1;
      this.mStartDy = param1Float2;
      this.mTargetX = param1Float3;
      this.mTargetY = param1Float4;
      this.mValueAnimator = ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F });
      this.mValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator param2ValueAnimator) {
              ItemTouchHelper.RecoverAnimation.this.setFraction(param2ValueAnimator.getAnimatedFraction());
            }
          });
      this.mValueAnimator.setTarget(param1ViewHolder.itemView);
      this.mValueAnimator.addListener(this);
      setFraction(0.0F);
    }
    
    public void cancel() {
      this.mValueAnimator.cancel();
    }
    
    public void onAnimationCancel(Animator param1Animator) {
      setFraction(1.0F);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      if (!this.mEnded)
        this.mViewHolder.setIsRecyclable(true); 
      this.mEnded = true;
    }
    
    public void onAnimationRepeat(Animator param1Animator) {}
    
    public void onAnimationStart(Animator param1Animator) {}
    
    public void setDuration(long param1Long) {
      this.mValueAnimator.setDuration(param1Long);
    }
    
    public void setFraction(float param1Float) {
      this.mFraction = param1Float;
    }
    
    public void start() {
      this.mViewHolder.setIsRecyclable(false);
      this.mValueAnimator.start();
    }
    
    public void update() {
      float f1 = this.mStartDx;
      float f2 = this.mTargetX;
      if (f1 == f2) {
        this.mX = this.mViewHolder.itemView.getTranslationX();
      } else {
        this.mX = f1 + this.mFraction * (f2 - f1);
      } 
      f1 = this.mStartDy;
      f2 = this.mTargetY;
      if (f1 == f2) {
        this.mY = this.mViewHolder.itemView.getTranslationY();
        return;
      } 
      this.mY = f1 + this.mFraction * (f2 - f1);
    }
  }
  
  class null implements ValueAnimator.AnimatorUpdateListener {
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.this$0.setFraction(param1ValueAnimator.getAnimatedFraction());
    }
  }
  
  public static abstract class SimpleCallback extends Callback {
    private int mDefaultDragDirs;
    
    private int mDefaultSwipeDirs;
    
    public SimpleCallback(int param1Int1, int param1Int2) {
      this.mDefaultSwipeDirs = param1Int2;
      this.mDefaultDragDirs = param1Int1;
    }
    
    public int getDragDirs(@NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder) {
      return this.mDefaultDragDirs;
    }
    
    public int getMovementFlags(@NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder) {
      return makeMovementFlags(getDragDirs(param1RecyclerView, param1ViewHolder), getSwipeDirs(param1RecyclerView, param1ViewHolder));
    }
    
    public int getSwipeDirs(@NonNull RecyclerView param1RecyclerView, @NonNull RecyclerView.ViewHolder param1ViewHolder) {
      return this.mDefaultSwipeDirs;
    }
    
    public void setDefaultDragDirs(int param1Int) {
      this.mDefaultDragDirs = param1Int;
    }
    
    public void setDefaultSwipeDirs(int param1Int) {
      this.mDefaultSwipeDirs = param1Int;
    }
  }
  
  public static interface ViewDropHandler {
    void prepareForDrop(@NonNull View param1View1, @NonNull View param1View2, int param1Int1, int param1Int2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\recyclerview\widget\ItemTouchHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */