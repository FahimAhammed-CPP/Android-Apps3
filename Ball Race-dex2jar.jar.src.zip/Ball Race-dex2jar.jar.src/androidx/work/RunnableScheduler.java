package androidx.work;

import androidx.annotation.IntRange;
import androidx.annotation.NonNull;

public interface RunnableScheduler {
  void cancel(@NonNull Runnable paramRunnable);
  
  void scheduleWithDelay(@IntRange(from = 0L) long paramLong, @NonNull Runnable paramRunnable);
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\RunnableScheduler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */