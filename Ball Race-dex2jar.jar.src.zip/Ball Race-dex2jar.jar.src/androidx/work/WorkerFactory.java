package androidx.work;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

public abstract class WorkerFactory {
  private static final String TAG = Logger.tagWithPrefix("WorkerFactory");
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static WorkerFactory getDefaultWorkerFactory() {
    return new WorkerFactory() {
        @Nullable
        public ListenableWorker createWorker(@NonNull Context param1Context, @NonNull String param1String, @NonNull WorkerParameters param1WorkerParameters) {
          return null;
        }
      };
  }
  
  @Nullable
  public abstract ListenableWorker createWorker(@NonNull Context paramContext, @NonNull String paramString, @NonNull WorkerParameters paramWorkerParameters);
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final ListenableWorker createWorkerWithDefaultFallback(@NonNull Context paramContext, @NonNull String paramString, @NonNull WorkerParameters paramWorkerParameters) {
    ListenableWorker listenableWorker2 = createWorker(paramContext, paramString, paramWorkerParameters);
    if (listenableWorker2 == null) {
      Class<? extends ListenableWorker> clazz = null;
      try {
        Class<? extends ListenableWorker> clazz1 = Class.forName(paramString).asSubclass(ListenableWorker.class);
        clazz = clazz1;
      } catch (Throwable throwable) {
        Logger logger = Logger.get();
        String str = TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid class: ");
        stringBuilder.append(paramString);
        logger.error(str, stringBuilder.toString(), new Throwable[] { throwable });
      } 
      if (clazz != null) {
        ListenableWorker listenableWorker;
        try {
          listenableWorker = clazz.getDeclaredConstructor(new Class[] { Context.class, WorkerParameters.class }).newInstance(new Object[] { paramContext, paramWorkerParameters });
        } catch (Throwable throwable) {
          Logger logger = Logger.get();
          String str = TAG;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Could not instantiate ");
          stringBuilder.append(paramString);
          logger.error(str, stringBuilder.toString(), new Throwable[] { throwable });
          listenableWorker = listenableWorker2;
        } 
        if (listenableWorker != null) {
          if (!listenableWorker.isUsed())
            return listenableWorker; 
          throw new IllegalStateException(String.format("WorkerFactory (%s) returned an instance of a ListenableWorker (%s) which has already been invoked. createWorker() must always return a new instance of a ListenableWorker.", new Object[] { getClass().getName(), paramString }));
        } 
        return listenableWorker;
      } 
    } 
    ListenableWorker listenableWorker1 = listenableWorker2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\WorkerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */