package androidx.work;

import androidx.annotation.RequiresApi;

public enum NetworkType {
  CONNECTED, METERED, NOT_REQUIRED, NOT_ROAMING, TEMPORARILY_UNMETERED, UNMETERED;
  
  static {
    CONNECTED = new NetworkType("CONNECTED", 1);
    UNMETERED = new NetworkType("UNMETERED", 2);
    NOT_ROAMING = new NetworkType("NOT_ROAMING", 3);
    METERED = new NetworkType("METERED", 4);
    TEMPORARILY_UNMETERED = new NetworkType("TEMPORARILY_UNMETERED", 5);
    $VALUES = new NetworkType[] { NOT_REQUIRED, CONNECTED, UNMETERED, NOT_ROAMING, METERED, TEMPORARILY_UNMETERED };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\NetworkType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */