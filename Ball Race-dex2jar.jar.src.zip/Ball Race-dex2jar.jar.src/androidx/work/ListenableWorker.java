package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.annotation.IntRange;
import androidx.annotation.Keep;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.work.impl.utils.futures.SettableFuture;
import androidx.work.impl.utils.taskexecutor.TaskExecutor;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public abstract class ListenableWorker {
  @NonNull
  private Context mAppContext;
  
  private boolean mRunInForeground;
  
  private volatile boolean mStopped;
  
  private boolean mUsed;
  
  @NonNull
  private WorkerParameters mWorkerParams;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public ListenableWorker(@NonNull Context paramContext, @NonNull WorkerParameters paramWorkerParameters) {
    if (paramContext != null) {
      if (paramWorkerParameters != null) {
        this.mAppContext = paramContext;
        this.mWorkerParams = paramWorkerParameters;
        return;
      } 
      throw new IllegalArgumentException("WorkerParameters is null");
    } 
    throw new IllegalArgumentException("Application Context is null");
  }
  
  @NonNull
  public final Context getApplicationContext() {
    return this.mAppContext;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public Executor getBackgroundExecutor() {
    return this.mWorkerParams.getBackgroundExecutor();
  }
  
  @NonNull
  public ListenableFuture<ForegroundInfo> getForegroundInfoAsync() {
    SettableFuture settableFuture = SettableFuture.create();
    settableFuture.setException(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return (ListenableFuture<ForegroundInfo>)settableFuture;
  }
  
  @NonNull
  public final UUID getId() {
    return this.mWorkerParams.getId();
  }
  
  @NonNull
  public final Data getInputData() {
    return this.mWorkerParams.getInputData();
  }
  
  @Nullable
  @RequiresApi(28)
  public final Network getNetwork() {
    return this.mWorkerParams.getNetwork();
  }
  
  @IntRange(from = 0L)
  public final int getRunAttemptCount() {
    return this.mWorkerParams.getRunAttemptCount();
  }
  
  @NonNull
  public final Set<String> getTags() {
    return this.mWorkerParams.getTags();
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public TaskExecutor getTaskExecutor() {
    return this.mWorkerParams.getTaskExecutor();
  }
  
  @NonNull
  @RequiresApi(24)
  public final List<String> getTriggeredContentAuthorities() {
    return this.mWorkerParams.getTriggeredContentAuthorities();
  }
  
  @NonNull
  @RequiresApi(24)
  public final List<Uri> getTriggeredContentUris() {
    return this.mWorkerParams.getTriggeredContentUris();
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public WorkerFactory getWorkerFactory() {
    return this.mWorkerParams.getWorkerFactory();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public boolean isRunInForeground() {
    return this.mRunInForeground;
  }
  
  public final boolean isStopped() {
    return this.mStopped;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final boolean isUsed() {
    return this.mUsed;
  }
  
  public void onStopped() {}
  
  @NonNull
  public final ListenableFuture<Void> setForegroundAsync(@NonNull ForegroundInfo paramForegroundInfo) {
    this.mRunInForeground = true;
    return this.mWorkerParams.getForegroundUpdater().setForegroundAsync(getApplicationContext(), getId(), paramForegroundInfo);
  }
  
  @NonNull
  public ListenableFuture<Void> setProgressAsync(@NonNull Data paramData) {
    return this.mWorkerParams.getProgressUpdater().updateProgress(getApplicationContext(), getId(), paramData);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setRunInForeground(boolean paramBoolean) {
    this.mRunInForeground = paramBoolean;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final void setUsed() {
    this.mUsed = true;
  }
  
  @MainThread
  @NonNull
  public abstract ListenableFuture<Result> startWork();
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final void stop() {
    this.mStopped = true;
    onStopped();
  }
  
  public static abstract class Result {
    @NonNull
    public static Result failure() {
      return new Failure();
    }
    
    @NonNull
    public static Result failure(@NonNull Data param1Data) {
      return new Failure(param1Data);
    }
    
    @NonNull
    public static Result retry() {
      return new Retry();
    }
    
    @NonNull
    public static Result success() {
      return new Success();
    }
    
    @NonNull
    public static Result success(@NonNull Data param1Data) {
      return new Success(param1Data);
    }
    
    @NonNull
    public abstract Data getOutputData();
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final class Failure extends Result {
      private final Data mOutputData;
      
      public Failure() {
        this(Data.EMPTY);
      }
      
      public Failure(@NonNull Data param2Data) {
        this.mOutputData = param2Data;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || getClass() != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.mOutputData.equals(((Failure)param2Object).mOutputData);
      }
      
      @NonNull
      public Data getOutputData() {
        return this.mOutputData;
      }
      
      public int hashCode() {
        return Failure.class.getName().hashCode() * 31 + this.mOutputData.hashCode();
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failure {mOutputData=");
        stringBuilder.append(this.mOutputData);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final class Retry extends Result {
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : ((param2Object != null && getClass() == param2Object.getClass()));
      }
      
      @NonNull
      public Data getOutputData() {
        return Data.EMPTY;
      }
      
      public int hashCode() {
        return Retry.class.getName().hashCode();
      }
      
      public String toString() {
        return "Retry";
      }
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static final class Success extends Result {
      private final Data mOutputData;
      
      public Success() {
        this(Data.EMPTY);
      }
      
      public Success(@NonNull Data param2Data) {
        this.mOutputData = param2Data;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || getClass() != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.mOutputData.equals(((Success)param2Object).mOutputData);
      }
      
      @NonNull
      public Data getOutputData() {
        return this.mOutputData;
      }
      
      public int hashCode() {
        return Success.class.getName().hashCode() * 31 + this.mOutputData.hashCode();
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Success {mOutputData=");
        stringBuilder.append(this.mOutputData);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Failure extends Result {
    private final Data mOutputData;
    
    public Failure() {
      this(Data.EMPTY);
    }
    
    public Failure(@NonNull Data param1Data) {
      this.mOutputData = param1Data;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || getClass() != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.mOutputData.equals(((Failure)param1Object).mOutputData);
    }
    
    @NonNull
    public Data getOutputData() {
      return this.mOutputData;
    }
    
    public int hashCode() {
      return Failure.class.getName().hashCode() * 31 + this.mOutputData.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failure {mOutputData=");
      stringBuilder.append(this.mOutputData);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Retry extends Result {
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : ((param1Object != null && getClass() == param1Object.getClass()));
    }
    
    @NonNull
    public Data getOutputData() {
      return Data.EMPTY;
    }
    
    public int hashCode() {
      return Retry.class.getName().hashCode();
    }
    
    public String toString() {
      return "Retry";
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final class Success extends Result {
    private final Data mOutputData;
    
    public Success() {
      this(Data.EMPTY);
    }
    
    public Success(@NonNull Data param1Data) {
      this.mOutputData = param1Data;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || getClass() != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.mOutputData.equals(((Success)param1Object).mOutputData);
    }
    
    @NonNull
    public Data getOutputData() {
      return this.mOutputData;
    }
    
    public int hashCode() {
      return Success.class.getName().hashCode() * 31 + this.mOutputData.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Success {mOutputData=");
      stringBuilder.append(this.mOutputData);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */