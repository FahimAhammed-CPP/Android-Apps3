package androidx.work;

import android.annotation.SuppressLint;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.work.impl.model.WorkSpec;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public abstract class WorkRequest {
  public static final long DEFAULT_BACKOFF_DELAY_MILLIS = 30000L;
  
  @SuppressLint({"MinMaxConstant"})
  public static final long MAX_BACKOFF_MILLIS = 18000000L;
  
  @SuppressLint({"MinMaxConstant"})
  public static final long MIN_BACKOFF_MILLIS = 10000L;
  
  @NonNull
  private UUID mId;
  
  @NonNull
  private Set<String> mTags;
  
  @NonNull
  private WorkSpec mWorkSpec;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected WorkRequest(@NonNull UUID paramUUID, @NonNull WorkSpec paramWorkSpec, @NonNull Set<String> paramSet) {
    this.mId = paramUUID;
    this.mWorkSpec = paramWorkSpec;
    this.mTags = paramSet;
  }
  
  @NonNull
  public UUID getId() {
    return this.mId;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public String getStringId() {
    return this.mId.toString();
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public Set<String> getTags() {
    return this.mTags;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public WorkSpec getWorkSpec() {
    return this.mWorkSpec;
  }
  
  public static abstract class Builder<B extends Builder<?, ?>, W extends WorkRequest> {
    boolean mBackoffCriteriaSet = false;
    
    UUID mId = UUID.randomUUID();
    
    Set<String> mTags = new HashSet<String>();
    
    WorkSpec mWorkSpec;
    
    Class<? extends ListenableWorker> mWorkerClass;
    
    Builder(@NonNull Class<? extends ListenableWorker> param1Class) {
      this.mWorkerClass = param1Class;
      this.mWorkSpec = new WorkSpec(this.mId.toString(), param1Class.getName());
      addTag(param1Class.getName());
    }
    
    @NonNull
    public final B addTag(@NonNull String param1String) {
      this.mTags.add(param1String);
      return getThis();
    }
    
    @NonNull
    public final W build() {
      boolean bool;
      W w = buildInternal();
      Constraints constraints = this.mWorkSpec.constraints;
      if ((Build.VERSION.SDK_INT >= 24 && constraints.hasContentUriTriggers()) || constraints.requiresBatteryNotLow() || constraints.requiresCharging() || (Build.VERSION.SDK_INT >= 23 && constraints.requiresDeviceIdle())) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!this.mWorkSpec.expedited || !bool) {
        this.mId = UUID.randomUUID();
        this.mWorkSpec = new WorkSpec(this.mWorkSpec);
        this.mWorkSpec.id = this.mId.toString();
        return w;
      } 
      throw new IllegalArgumentException("Expedited jobs only support network and storage constraints");
    }
    
    @NonNull
    abstract W buildInternal();
    
    @NonNull
    abstract B getThis();
    
    @NonNull
    public final B keepResultsForAtLeast(long param1Long, @NonNull TimeUnit param1TimeUnit) {
      this.mWorkSpec.minimumRetentionDuration = param1TimeUnit.toMillis(param1Long);
      return getThis();
    }
    
    @NonNull
    @RequiresApi(26)
    public final B keepResultsForAtLeast(@NonNull Duration param1Duration) {
      this.mWorkSpec.minimumRetentionDuration = param1Duration.toMillis();
      return getThis();
    }
    
    @NonNull
    public final B setBackoffCriteria(@NonNull BackoffPolicy param1BackoffPolicy, long param1Long, @NonNull TimeUnit param1TimeUnit) {
      this.mBackoffCriteriaSet = true;
      WorkSpec workSpec = this.mWorkSpec;
      workSpec.backoffPolicy = param1BackoffPolicy;
      workSpec.setBackoffDelayDuration(param1TimeUnit.toMillis(param1Long));
      return getThis();
    }
    
    @NonNull
    @RequiresApi(26)
    public final B setBackoffCriteria(@NonNull BackoffPolicy param1BackoffPolicy, @NonNull Duration param1Duration) {
      this.mBackoffCriteriaSet = true;
      WorkSpec workSpec = this.mWorkSpec;
      workSpec.backoffPolicy = param1BackoffPolicy;
      workSpec.setBackoffDelayDuration(param1Duration.toMillis());
      return getThis();
    }
    
    @NonNull
    public final B setConstraints(@NonNull Constraints param1Constraints) {
      this.mWorkSpec.constraints = param1Constraints;
      return getThis();
    }
    
    @SuppressLint({"MissingGetterMatchingBuilder"})
    @NonNull
    public B setExpedited(@NonNull OutOfQuotaPolicy param1OutOfQuotaPolicy) {
      WorkSpec workSpec = this.mWorkSpec;
      workSpec.expedited = true;
      workSpec.outOfQuotaPolicy = param1OutOfQuotaPolicy;
      return getThis();
    }
    
    @NonNull
    public B setInitialDelay(long param1Long, @NonNull TimeUnit param1TimeUnit) {
      this.mWorkSpec.initialDelay = param1TimeUnit.toMillis(param1Long);
      if (Long.MAX_VALUE - System.currentTimeMillis() > this.mWorkSpec.initialDelay)
        return getThis(); 
      throw new IllegalArgumentException("The given initial delay is too large and will cause an overflow!");
    }
    
    @NonNull
    @RequiresApi(26)
    public B setInitialDelay(@NonNull Duration param1Duration) {
      this.mWorkSpec.initialDelay = param1Duration.toMillis();
      if (Long.MAX_VALUE - System.currentTimeMillis() > this.mWorkSpec.initialDelay)
        return getThis(); 
      throw new IllegalArgumentException("The given initial delay is too large and will cause an overflow!");
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    @VisibleForTesting
    public final B setInitialRunAttemptCount(int param1Int) {
      this.mWorkSpec.runAttemptCount = param1Int;
      return getThis();
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    @VisibleForTesting
    public final B setInitialState(@NonNull WorkInfo.State param1State) {
      this.mWorkSpec.state = param1State;
      return getThis();
    }
    
    @NonNull
    public final B setInputData(@NonNull Data param1Data) {
      this.mWorkSpec.input = param1Data;
      return getThis();
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    @VisibleForTesting
    public final B setPeriodStartTime(long param1Long, @NonNull TimeUnit param1TimeUnit) {
      this.mWorkSpec.periodStartTime = param1TimeUnit.toMillis(param1Long);
      return getThis();
    }
    
    @NonNull
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    @VisibleForTesting
    public final B setScheduleRequestedAt(long param1Long, @NonNull TimeUnit param1TimeUnit) {
      this.mWorkSpec.scheduleRequestedAt = param1TimeUnit.toMillis(param1Long);
      return getThis();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\WorkRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */