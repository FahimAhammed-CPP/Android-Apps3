package androidx.work.impl;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.content.ContextCompat;
import androidx.work.Configuration;
import androidx.work.ForegroundInfo;
import androidx.work.Logger;
import androidx.work.WorkerParameters;
import androidx.work.impl.foreground.ForegroundProcessor;
import androidx.work.impl.foreground.SystemForegroundDispatcher;
import androidx.work.impl.utils.WakeLocks;
import androidx.work.impl.utils.taskexecutor.TaskExecutor;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class Processor implements ExecutionListener, ForegroundProcessor {
  private static final String FOREGROUND_WAKELOCK_TAG = "ProcessorForegroundLck";
  
  private static final String TAG = Logger.tagWithPrefix("Processor");
  
  private Context mAppContext;
  
  private Set<String> mCancelledIds;
  
  private Configuration mConfiguration;
  
  private Map<String, WorkerWrapper> mEnqueuedWorkMap;
  
  @Nullable
  private PowerManager.WakeLock mForegroundLock;
  
  private Map<String, WorkerWrapper> mForegroundWorkMap;
  
  private final Object mLock;
  
  private final List<ExecutionListener> mOuterListeners;
  
  private List<Scheduler> mSchedulers;
  
  private WorkDatabase mWorkDatabase;
  
  private TaskExecutor mWorkTaskExecutor;
  
  public Processor(@NonNull Context paramContext, @NonNull Configuration paramConfiguration, @NonNull TaskExecutor paramTaskExecutor, @NonNull WorkDatabase paramWorkDatabase, @NonNull List<Scheduler> paramList) {
    this.mAppContext = paramContext;
    this.mConfiguration = paramConfiguration;
    this.mWorkTaskExecutor = paramTaskExecutor;
    this.mWorkDatabase = paramWorkDatabase;
    this.mEnqueuedWorkMap = new HashMap<String, WorkerWrapper>();
    this.mForegroundWorkMap = new HashMap<String, WorkerWrapper>();
    this.mSchedulers = paramList;
    this.mCancelledIds = new HashSet<String>();
    this.mOuterListeners = new ArrayList<ExecutionListener>();
    this.mForegroundLock = null;
    this.mLock = new Object();
  }
  
  private static boolean interrupt(@NonNull String paramString, @Nullable WorkerWrapper paramWorkerWrapper) {
    if (paramWorkerWrapper != null) {
      paramWorkerWrapper.interrupt();
      Logger.get().debug(TAG, String.format("WorkerWrapper interrupted for %s", new Object[] { paramString }), new Throwable[0]);
      return true;
    } 
    Logger.get().debug(TAG, String.format("WorkerWrapper could not be found for %s", new Object[] { paramString }), new Throwable[0]);
    return false;
  }
  
  private void stopForegroundService() {
    synchronized (this.mLock) {
      if ((this.mForegroundWorkMap.isEmpty() ^ true) == 0) {
        Intent intent = SystemForegroundDispatcher.createStopForegroundIntent(this.mAppContext);
        try {
          this.mAppContext.startService(intent);
        } catch (Throwable throwable) {
          Logger.get().error(TAG, "Unable to stop foreground service", new Throwable[] { throwable });
        } 
        if (this.mForegroundLock != null) {
          this.mForegroundLock.release();
          this.mForegroundLock = null;
        } 
      } 
      return;
    } 
  }
  
  public void addExecutionListener(@NonNull ExecutionListener paramExecutionListener) {
    synchronized (this.mLock) {
      this.mOuterListeners.add(paramExecutionListener);
      return;
    } 
  }
  
  public boolean hasWork() {
    synchronized (this.mLock) {
      if (!this.mEnqueuedWorkMap.isEmpty() || !this.mForegroundWorkMap.isEmpty())
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public boolean isCancelled(@NonNull String paramString) {
    synchronized (this.mLock) {
      return this.mCancelledIds.contains(paramString);
    } 
  }
  
  public boolean isEnqueued(@NonNull String paramString) {
    synchronized (this.mLock) {
      if (this.mEnqueuedWorkMap.containsKey(paramString) || this.mForegroundWorkMap.containsKey(paramString))
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
    return bool;
  }
  
  public boolean isEnqueuedInForeground(@NonNull String paramString) {
    synchronized (this.mLock) {
      return this.mForegroundWorkMap.containsKey(paramString);
    } 
  }
  
  public void onExecuted(@NonNull String paramString, boolean paramBoolean) {
    synchronized (this.mLock) {
      this.mEnqueuedWorkMap.remove(paramString);
      Logger.get().debug(TAG, String.format("%s %s executed; reschedule = %s", new Object[] { getClass().getSimpleName(), paramString, Boolean.valueOf(paramBoolean) }), new Throwable[0]);
      Iterator<ExecutionListener> iterator = this.mOuterListeners.iterator();
      while (iterator.hasNext())
        ((ExecutionListener)iterator.next()).onExecuted(paramString, paramBoolean); 
      return;
    } 
  }
  
  public void removeExecutionListener(@NonNull ExecutionListener paramExecutionListener) {
    synchronized (this.mLock) {
      this.mOuterListeners.remove(paramExecutionListener);
      return;
    } 
  }
  
  public void startForeground(@NonNull String paramString, @NonNull ForegroundInfo paramForegroundInfo) {
    synchronized (this.mLock) {
      Logger.get().info(TAG, String.format("Moving WorkSpec (%s) to the foreground", new Object[] { paramString }), new Throwable[0]);
      WorkerWrapper workerWrapper = this.mEnqueuedWorkMap.remove(paramString);
      if (workerWrapper != null) {
        if (this.mForegroundLock == null) {
          this.mForegroundLock = WakeLocks.newWakeLock(this.mAppContext, "ProcessorForegroundLck");
          this.mForegroundLock.acquire();
        } 
        this.mForegroundWorkMap.put(paramString, workerWrapper);
        Intent intent = SystemForegroundDispatcher.createStartForegroundIntent(this.mAppContext, paramString, paramForegroundInfo);
        ContextCompat.startForegroundService(this.mAppContext, intent);
      } 
      return;
    } 
  }
  
  public boolean startWork(@NonNull String paramString) {
    return startWork(paramString, null);
  }
  
  public boolean startWork(@NonNull String paramString, @Nullable WorkerParameters.RuntimeExtras paramRuntimeExtras) {
    synchronized (this.mLock) {
      if (isEnqueued(paramString)) {
        Logger.get().debug(TAG, String.format("Work %s is already enqueued for processing", new Object[] { paramString }), new Throwable[0]);
        return false;
      } 
      WorkerWrapper workerWrapper = (new WorkerWrapper.Builder(this.mAppContext, this.mConfiguration, this.mWorkTaskExecutor, this, this.mWorkDatabase, paramString)).withSchedulers(this.mSchedulers).withRuntimeExtras(paramRuntimeExtras).build();
      ListenableFuture<Boolean> listenableFuture = workerWrapper.getFuture();
      listenableFuture.addListener(new FutureListener(this, paramString, listenableFuture), this.mWorkTaskExecutor.getMainThreadExecutor());
      this.mEnqueuedWorkMap.put(paramString, workerWrapper);
      this.mWorkTaskExecutor.getBackgroundExecutor().execute((Runnable)workerWrapper);
      Logger.get().debug(TAG, String.format("%s: processing %s", new Object[] { getClass().getSimpleName(), paramString }), new Throwable[0]);
      return true;
    } 
  }
  
  public boolean stopAndCancelWork(@NonNull String paramString) {
    synchronized (this.mLock) {
      Logger logger = Logger.get();
      String str = TAG;
      boolean bool = true;
      logger.debug(str, String.format("Processor cancelling %s", new Object[] { paramString }), new Throwable[0]);
      this.mCancelledIds.add(paramString);
      WorkerWrapper workerWrapper2 = this.mForegroundWorkMap.remove(paramString);
      if (workerWrapper2 == null)
        bool = false; 
      WorkerWrapper workerWrapper1 = workerWrapper2;
      if (workerWrapper2 == null)
        workerWrapper1 = this.mEnqueuedWorkMap.remove(paramString); 
      boolean bool1 = interrupt(paramString, workerWrapper1);
      if (bool)
        stopForegroundService(); 
      return bool1;
    } 
  }
  
  public void stopForeground(@NonNull String paramString) {
    synchronized (this.mLock) {
      this.mForegroundWorkMap.remove(paramString);
      stopForegroundService();
      return;
    } 
  }
  
  public boolean stopForegroundWork(@NonNull String paramString) {
    synchronized (this.mLock) {
      Logger.get().debug(TAG, String.format("Processor stopping foreground work %s", new Object[] { paramString }), new Throwable[0]);
      return interrupt(paramString, this.mForegroundWorkMap.remove(paramString));
    } 
  }
  
  public boolean stopWork(@NonNull String paramString) {
    synchronized (this.mLock) {
      Logger.get().debug(TAG, String.format("Processor stopping background work %s", new Object[] { paramString }), new Throwable[0]);
      return interrupt(paramString, this.mEnqueuedWorkMap.remove(paramString));
    } 
  }
  
  private static class FutureListener implements Runnable {
    @NonNull
    private ExecutionListener mExecutionListener;
    
    @NonNull
    private ListenableFuture<Boolean> mFuture;
    
    @NonNull
    private String mWorkSpecId;
    
    FutureListener(@NonNull ExecutionListener param1ExecutionListener, @NonNull String param1String, @NonNull ListenableFuture<Boolean> param1ListenableFuture) {
      this.mExecutionListener = param1ExecutionListener;
      this.mWorkSpecId = param1String;
      this.mFuture = param1ListenableFuture;
    }
    
    public void run() {
      boolean bool;
      try {
        bool = ((Boolean)this.mFuture.get()).booleanValue();
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        bool = true;
      } 
      this.mExecutionListener.onExecuted(this.mWorkSpecId, bool);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\impl\Processor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */