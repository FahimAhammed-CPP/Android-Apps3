package androidx.work.impl.constraints.trackers;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.work.impl.utils.taskexecutor.TaskExecutor;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class Trackers {
  private static Trackers sInstance;
  
  private BatteryChargingTracker mBatteryChargingTracker;
  
  private BatteryNotLowTracker mBatteryNotLowTracker;
  
  private NetworkStateTracker mNetworkStateTracker;
  
  private StorageNotLowTracker mStorageNotLowTracker;
  
  private Trackers(@NonNull Context paramContext, @NonNull TaskExecutor paramTaskExecutor) {
    paramContext = paramContext.getApplicationContext();
    this.mBatteryChargingTracker = new BatteryChargingTracker(paramContext, paramTaskExecutor);
    this.mBatteryNotLowTracker = new BatteryNotLowTracker(paramContext, paramTaskExecutor);
    this.mNetworkStateTracker = new NetworkStateTracker(paramContext, paramTaskExecutor);
    this.mStorageNotLowTracker = new StorageNotLowTracker(paramContext, paramTaskExecutor);
  }
  
  @NonNull
  public static Trackers getInstance(Context paramContext, TaskExecutor paramTaskExecutor) {
    // Byte code:
    //   0: ldc androidx/work/impl/constraints/trackers/Trackers
    //   2: monitorenter
    //   3: getstatic androidx/work/impl/constraints/trackers/Trackers.sInstance : Landroidx/work/impl/constraints/trackers/Trackers;
    //   6: ifnonnull -> 21
    //   9: new androidx/work/impl/constraints/trackers/Trackers
    //   12: dup
    //   13: aload_0
    //   14: aload_1
    //   15: invokespecial <init> : (Landroid/content/Context;Landroidx/work/impl/utils/taskexecutor/TaskExecutor;)V
    //   18: putstatic androidx/work/impl/constraints/trackers/Trackers.sInstance : Landroidx/work/impl/constraints/trackers/Trackers;
    //   21: getstatic androidx/work/impl/constraints/trackers/Trackers.sInstance : Landroidx/work/impl/constraints/trackers/Trackers;
    //   24: astore_0
    //   25: ldc androidx/work/impl/constraints/trackers/Trackers
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc androidx/work/impl/constraints/trackers/Trackers
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
  
  @VisibleForTesting
  public static void setInstance(@NonNull Trackers paramTrackers) {
    // Byte code:
    //   0: ldc androidx/work/impl/constraints/trackers/Trackers
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic androidx/work/impl/constraints/trackers/Trackers.sInstance : Landroidx/work/impl/constraints/trackers/Trackers;
    //   7: ldc androidx/work/impl/constraints/trackers/Trackers
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc androidx/work/impl/constraints/trackers/Trackers
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
  
  @NonNull
  public BatteryChargingTracker getBatteryChargingTracker() {
    return this.mBatteryChargingTracker;
  }
  
  @NonNull
  public BatteryNotLowTracker getBatteryNotLowTracker() {
    return this.mBatteryNotLowTracker;
  }
  
  @NonNull
  public NetworkStateTracker getNetworkStateTracker() {
    return this.mNetworkStateTracker;
  }
  
  @NonNull
  public StorageNotLowTracker getStorageNotLowTracker() {
    return this.mStorageNotLowTracker;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\impl\constraints\trackers\Trackers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */