package androidx.work.impl.constraints.trackers;

import androidx.annotation.RestrictTo;



/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\impl\constraints\trackers\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */