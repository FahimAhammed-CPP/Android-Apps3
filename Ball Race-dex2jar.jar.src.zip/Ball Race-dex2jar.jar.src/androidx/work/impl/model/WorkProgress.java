package androidx.work.impl.model;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
import androidx.work.Data;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
@Entity(foreignKeys = {@ForeignKey(childColumns = {"work_spec_id"}, entity = WorkSpec.class, onDelete = 5, onUpdate = 5, parentColumns = {"id"})})
public class WorkProgress {
  @NonNull
  @ColumnInfo(name = "progress")
  public final Data mProgress;
  
  @NonNull
  @ColumnInfo(name = "work_spec_id")
  @PrimaryKey
  public final String mWorkSpecId;
  
  public WorkProgress(@NonNull String paramString, @NonNull Data paramData) {
    this.mWorkSpecId = paramString;
    this.mProgress = paramData;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\impl\model\WorkProgress.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */