package androidx.work.impl.model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface SystemIdInfoDao {
  @Nullable
  @Query("SELECT * FROM SystemIdInfo WHERE work_spec_id=:workSpecId")
  SystemIdInfo getSystemIdInfo(@NonNull String paramString);
  
  @NonNull
  @Query("SELECT DISTINCT work_spec_id FROM SystemIdInfo")
  List<String> getWorkSpecIds();
  
  @Insert(onConflict = 1)
  void insertSystemIdInfo(@NonNull SystemIdInfo paramSystemIdInfo);
  
  @Query("DELETE FROM SystemIdInfo where work_spec_id=:workSpecId")
  void removeSystemIdInfo(@NonNull String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\impl\model\SystemIdInfoDao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */