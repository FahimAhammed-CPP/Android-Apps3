package androidx.work.impl.model;

import android.os.Build;
import androidx.annotation.NonNull;
import androidx.room.TypeConverter;
import androidx.work.BackoffPolicy;
import androidx.work.ContentUriTriggers;
import androidx.work.NetworkType;
import androidx.work.OutOfQuotaPolicy;
import androidx.work.WorkInfo;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class WorkTypeConverters {
  @TypeConverter
  public static int backoffPolicyToInt(BackoffPolicy paramBackoffPolicy) {
    int i = null.$SwitchMap$androidx$work$BackoffPolicy[paramBackoffPolicy.ordinal()];
    if (i != 1) {
      if (i == 2)
        return 1; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not convert ");
      stringBuilder.append(paramBackoffPolicy);
      stringBuilder.append(" to int");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return 0;
  }
  
  @TypeConverter
  public static ContentUriTriggers byteArrayToContentUriTriggers(byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: new androidx/work/ContentUriTriggers
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #5
    //   9: aload_0
    //   10: ifnonnull -> 16
    //   13: aload #5
    //   15: areturn
    //   16: new java/io/ByteArrayInputStream
    //   19: dup
    //   20: aload_0
    //   21: invokespecial <init> : ([B)V
    //   24: astore #4
    //   26: new java/io/ObjectInputStream
    //   29: dup
    //   30: aload #4
    //   32: invokespecial <init> : (Ljava/io/InputStream;)V
    //   35: astore_2
    //   36: aload_2
    //   37: astore_0
    //   38: aload_2
    //   39: invokevirtual readInt : ()I
    //   42: istore_1
    //   43: iload_1
    //   44: ifle -> 72
    //   47: aload_2
    //   48: astore_0
    //   49: aload #5
    //   51: aload_2
    //   52: invokevirtual readUTF : ()Ljava/lang/String;
    //   55: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   58: aload_2
    //   59: invokevirtual readBoolean : ()Z
    //   62: invokevirtual add : (Landroid/net/Uri;Z)V
    //   65: iload_1
    //   66: iconst_1
    //   67: isub
    //   68: istore_1
    //   69: goto -> 43
    //   72: aload_2
    //   73: invokevirtual close : ()V
    //   76: goto -> 84
    //   79: astore_0
    //   80: aload_0
    //   81: invokevirtual printStackTrace : ()V
    //   84: aload #4
    //   86: invokevirtual close : ()V
    //   89: aload #5
    //   91: areturn
    //   92: astore_3
    //   93: goto -> 105
    //   96: astore_2
    //   97: aconst_null
    //   98: astore_0
    //   99: goto -> 144
    //   102: astore_3
    //   103: aconst_null
    //   104: astore_2
    //   105: aload_2
    //   106: astore_0
    //   107: aload_3
    //   108: invokevirtual printStackTrace : ()V
    //   111: aload_2
    //   112: ifnull -> 127
    //   115: aload_2
    //   116: invokevirtual close : ()V
    //   119: goto -> 127
    //   122: astore_0
    //   123: aload_0
    //   124: invokevirtual printStackTrace : ()V
    //   127: aload #4
    //   129: invokevirtual close : ()V
    //   132: aload #5
    //   134: areturn
    //   135: astore_0
    //   136: aload_0
    //   137: invokevirtual printStackTrace : ()V
    //   140: aload #5
    //   142: areturn
    //   143: astore_2
    //   144: aload_0
    //   145: ifnull -> 160
    //   148: aload_0
    //   149: invokevirtual close : ()V
    //   152: goto -> 160
    //   155: astore_0
    //   156: aload_0
    //   157: invokevirtual printStackTrace : ()V
    //   160: aload #4
    //   162: invokevirtual close : ()V
    //   165: goto -> 173
    //   168: astore_0
    //   169: aload_0
    //   170: invokevirtual printStackTrace : ()V
    //   173: aload_2
    //   174: athrow
    // Exception table:
    //   from	to	target	type
    //   26	36	102	java/io/IOException
    //   26	36	96	finally
    //   38	43	92	java/io/IOException
    //   38	43	143	finally
    //   49	65	92	java/io/IOException
    //   49	65	143	finally
    //   72	76	79	java/io/IOException
    //   84	89	135	java/io/IOException
    //   107	111	143	finally
    //   115	119	122	java/io/IOException
    //   127	132	135	java/io/IOException
    //   148	152	155	java/io/IOException
    //   160	165	168	java/io/IOException
  }
  
  @TypeConverter
  public static byte[] contentUriTriggersToByteArray(ContentUriTriggers paramContentUriTriggers) {
    IOException iOException2;
    int i = paramContentUriTriggers.size();
    ContentUriTriggers contentUriTriggers2 = null;
    trigger = null;
    if (i == 0)
      return null; 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
    } catch (IOException null) {
    
    } finally {
      paramContentUriTriggers = null;
    } 
    ContentUriTriggers contentUriTriggers1 = paramContentUriTriggers;
    iOException2.printStackTrace();
    if (paramContentUriTriggers != null)
      try {
        paramContentUriTriggers.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      }  
    byteArrayOutputStream.close();
    return byteArrayOutputStream.toByteArray();
  }
  
  @TypeConverter
  public static BackoffPolicy intToBackoffPolicy(int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1)
        return BackoffPolicy.LINEAR; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not convert ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" to BackoffPolicy");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return BackoffPolicy.EXPONENTIAL;
  }
  
  @TypeConverter
  public static NetworkType intToNetworkType(int paramInt) {
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 3) {
            if (paramInt != 4) {
              if (Build.VERSION.SDK_INT >= 30 && paramInt == 5)
                return NetworkType.TEMPORARILY_UNMETERED; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Could not convert ");
              stringBuilder.append(paramInt);
              stringBuilder.append(" to NetworkType");
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            return NetworkType.METERED;
          } 
          return NetworkType.NOT_ROAMING;
        } 
        return NetworkType.UNMETERED;
      } 
      return NetworkType.CONNECTED;
    } 
    return NetworkType.NOT_REQUIRED;
  }
  
  @NonNull
  @TypeConverter
  public static OutOfQuotaPolicy intToOutOfQuotaPolicy(int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1)
        return OutOfQuotaPolicy.DROP_WORK_REQUEST; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not convert ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" to OutOfQuotaPolicy");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST;
  }
  
  @TypeConverter
  public static WorkInfo.State intToState(int paramInt) {
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 3) {
            if (paramInt != 4) {
              if (paramInt == 5)
                return WorkInfo.State.CANCELLED; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Could not convert ");
              stringBuilder.append(paramInt);
              stringBuilder.append(" to State");
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            return WorkInfo.State.BLOCKED;
          } 
          return WorkInfo.State.FAILED;
        } 
        return WorkInfo.State.SUCCEEDED;
      } 
      return WorkInfo.State.RUNNING;
    } 
    return WorkInfo.State.ENQUEUED;
  }
  
  @TypeConverter
  public static int networkTypeToInt(NetworkType paramNetworkType) {
    int i = null.$SwitchMap$androidx$work$NetworkType[paramNetworkType.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            if (i != 5) {
              if (Build.VERSION.SDK_INT >= 30 && paramNetworkType == NetworkType.TEMPORARILY_UNMETERED)
                return 5; 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Could not convert ");
              stringBuilder.append(paramNetworkType);
              stringBuilder.append(" to int");
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
            return 4;
          } 
          return 3;
        } 
        return 2;
      } 
      return 1;
    } 
    return 0;
  }
  
  @TypeConverter
  public static int outOfQuotaPolicyToInt(@NonNull OutOfQuotaPolicy paramOutOfQuotaPolicy) {
    int i = null.$SwitchMap$androidx$work$OutOfQuotaPolicy[paramOutOfQuotaPolicy.ordinal()];
    if (i != 1) {
      if (i == 2)
        return 1; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not convert ");
      stringBuilder.append(paramOutOfQuotaPolicy);
      stringBuilder.append(" to int");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return 0;
  }
  
  @TypeConverter
  public static int stateToInt(WorkInfo.State paramState) {
    StringBuilder stringBuilder;
    switch (paramState) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append("Could not convert ");
        stringBuilder.append(paramState);
        stringBuilder.append(" to int");
        throw new IllegalArgumentException(stringBuilder.toString());
      case null:
        return 5;
      case null:
        return 4;
      case null:
        return 3;
      case null:
        return 2;
      case DROP_WORK_REQUEST:
        return 1;
      case RUN_AS_NON_EXPEDITED_WORK_REQUEST:
        break;
    } 
    return 0;
  }
  
  public static interface BackoffPolicyIds {
    public static final int EXPONENTIAL = 0;
    
    public static final int LINEAR = 1;
  }
  
  public static interface NetworkTypeIds {
    public static final int CONNECTED = 1;
    
    public static final int METERED = 4;
    
    public static final int NOT_REQUIRED = 0;
    
    public static final int NOT_ROAMING = 3;
    
    public static final int TEMPORARILY_UNMETERED = 5;
    
    public static final int UNMETERED = 2;
  }
  
  public static interface OutOfPolicyIds {
    public static final int DROP_WORK_REQUEST = 1;
    
    public static final int RUN_AS_NON_EXPEDITED_WORK_REQUEST = 0;
  }
  
  public static interface StateIds {
    public static final int BLOCKED = 4;
    
    public static final int CANCELLED = 5;
    
    public static final String COMPLETED_STATES = "(2, 3, 5)";
    
    public static final int ENQUEUED = 0;
    
    public static final int FAILED = 3;
    
    public static final int RUNNING = 1;
    
    public static final int SUCCEEDED = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\impl\model\WorkTypeConverters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */