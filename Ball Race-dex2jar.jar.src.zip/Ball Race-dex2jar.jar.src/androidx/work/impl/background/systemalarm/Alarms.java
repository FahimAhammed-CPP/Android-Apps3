package androidx.work.impl.background.systemalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.work.Logger;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.WorkManagerImpl;
import androidx.work.impl.model.SystemIdInfo;
import androidx.work.impl.model.SystemIdInfoDao;
import androidx.work.impl.utils.IdGenerator;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class Alarms {
  private static final String TAG = Logger.tagWithPrefix("Alarms");
  
  public static void cancelAlarm(@NonNull Context paramContext, @NonNull WorkManagerImpl paramWorkManagerImpl, @NonNull String paramString) {
    SystemIdInfoDao systemIdInfoDao = paramWorkManagerImpl.getWorkDatabase().systemIdInfoDao();
    SystemIdInfo systemIdInfo = systemIdInfoDao.getSystemIdInfo(paramString);
    if (systemIdInfo != null) {
      cancelExactAlarm(paramContext, paramString, systemIdInfo.systemId);
      Logger.get().debug(TAG, String.format("Removing SystemIdInfo for workSpecId (%s)", new Object[] { paramString }), new Throwable[0]);
      systemIdInfoDao.removeSystemIdInfo(paramString);
    } 
  }
  
  private static void cancelExactAlarm(@NonNull Context paramContext, @NonNull String paramString, int paramInt) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    Intent intent = CommandHandler.createDelayMetIntent(paramContext, paramString);
    if (Build.VERSION.SDK_INT >= 23) {
      i = 603979776;
    } else {
      i = 536870912;
    } 
    PendingIntent pendingIntent = PendingIntent.getService(paramContext, paramInt, intent, i);
    if (pendingIntent != null && alarmManager != null) {
      Logger.get().debug(TAG, String.format("Cancelling existing alarm with (workSpecId, systemId) (%s, %s)", new Object[] { paramString, Integer.valueOf(paramInt) }), new Throwable[0]);
      alarmManager.cancel(pendingIntent);
    } 
  }
  
  public static void setAlarm(@NonNull Context paramContext, @NonNull WorkManagerImpl paramWorkManagerImpl, @NonNull String paramString, long paramLong) {
    WorkDatabase workDatabase = paramWorkManagerImpl.getWorkDatabase();
    SystemIdInfoDao systemIdInfoDao = workDatabase.systemIdInfoDao();
    SystemIdInfo systemIdInfo = systemIdInfoDao.getSystemIdInfo(paramString);
    if (systemIdInfo != null) {
      cancelExactAlarm(paramContext, paramString, systemIdInfo.systemId);
      setExactAlarm(paramContext, paramString, systemIdInfo.systemId, paramLong);
      return;
    } 
    int i = (new IdGenerator(workDatabase)).nextAlarmManagerId();
    systemIdInfoDao.insertSystemIdInfo(new SystemIdInfo(paramString, i));
    setExactAlarm(paramContext, paramString, i, paramLong);
  }
  
  private static void setExactAlarm(@NonNull Context paramContext, @NonNull String paramString, int paramInt, long paramLong) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (Build.VERSION.SDK_INT >= 23) {
      i = 201326592;
    } else {
      i = 134217728;
    } 
    PendingIntent pendingIntent = PendingIntent.getService(paramContext, paramInt, CommandHandler.createDelayMetIntent(paramContext, paramString), i);
    if (alarmManager != null) {
      if (Build.VERSION.SDK_INT >= 19) {
        alarmManager.setExact(0, paramLong, pendingIntent);
        return;
      } 
      alarmManager.set(0, paramLong, pendingIntent);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\impl\background\systemalarm\Alarms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */