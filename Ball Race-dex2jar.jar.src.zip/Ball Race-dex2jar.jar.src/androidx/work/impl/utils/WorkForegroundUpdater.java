package androidx.work.impl.utils;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.work.ForegroundInfo;
import androidx.work.ForegroundUpdater;
import androidx.work.Logger;
import androidx.work.WorkInfo;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.foreground.ForegroundProcessor;
import androidx.work.impl.foreground.SystemForegroundDispatcher;
import androidx.work.impl.model.WorkSpecDao;
import androidx.work.impl.utils.futures.SettableFuture;
import androidx.work.impl.utils.taskexecutor.TaskExecutor;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.UUID;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class WorkForegroundUpdater implements ForegroundUpdater {
  private static final String TAG = Logger.tagWithPrefix("WMFgUpdater");
  
  final ForegroundProcessor mForegroundProcessor;
  
  private final TaskExecutor mTaskExecutor;
  
  final WorkSpecDao mWorkSpecDao;
  
  public WorkForegroundUpdater(@NonNull WorkDatabase paramWorkDatabase, @NonNull ForegroundProcessor paramForegroundProcessor, @NonNull TaskExecutor paramTaskExecutor) {
    this.mForegroundProcessor = paramForegroundProcessor;
    this.mTaskExecutor = paramTaskExecutor;
    this.mWorkSpecDao = paramWorkDatabase.workSpecDao();
  }
  
  @NonNull
  public ListenableFuture<Void> setForegroundAsync(@NonNull final Context context, @NonNull final UUID id, @NonNull final ForegroundInfo foregroundInfo) {
    final SettableFuture future = SettableFuture.create();
    this.mTaskExecutor.executeOnBackgroundThread(new Runnable() {
          public void run() {
            try {
              if (!future.isCancelled()) {
                String str = id.toString();
                WorkInfo.State state = WorkForegroundUpdater.this.mWorkSpecDao.getState(str);
                if (state != null && !state.isFinished()) {
                  WorkForegroundUpdater.this.mForegroundProcessor.startForeground(str, foregroundInfo);
                  Intent intent = SystemForegroundDispatcher.createNotifyIntent(context, str, foregroundInfo);
                  context.startService(intent);
                } else {
                  throw new IllegalStateException("Calls to setForegroundAsync() must complete before a ListenableWorker signals completion of work by returning an instance of Result.");
                } 
              } 
              future.set(null);
              return;
            } catch (Throwable throwable) {
              future.setException(throwable);
              return;
            } 
          }
        });
    return (ListenableFuture<Void>)settableFuture;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\imp\\utils\WorkForegroundUpdater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */