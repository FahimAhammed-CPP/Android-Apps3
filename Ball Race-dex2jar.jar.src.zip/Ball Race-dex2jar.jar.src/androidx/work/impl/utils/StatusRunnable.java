package androidx.work.impl.utils;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.annotation.WorkerThread;
import androidx.work.WorkInfo;
import androidx.work.WorkQuery;
import androidx.work.impl.WorkManagerImpl;
import androidx.work.impl.model.WorkSpec;
import androidx.work.impl.utils.futures.SettableFuture;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.List;
import java.util.UUID;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public abstract class StatusRunnable<T> implements Runnable {
  private final SettableFuture<T> mFuture = SettableFuture.create();
  
  @NonNull
  public static StatusRunnable<List<WorkInfo>> forStringIds(@NonNull final WorkManagerImpl workManager, @NonNull final List<String> ids) {
    return new StatusRunnable<List<WorkInfo>>() {
        public List<WorkInfo> runInternal() {
          List list = workManager.getWorkDatabase().workSpecDao().getWorkStatusPojoForIds(ids);
          return (List<WorkInfo>)WorkSpec.WORK_INFO_MAPPER.apply(list);
        }
      };
  }
  
  @NonNull
  public static StatusRunnable<List<WorkInfo>> forTag(@NonNull final WorkManagerImpl workManager, @NonNull final String tag) {
    return new StatusRunnable<List<WorkInfo>>() {
        List<WorkInfo> runInternal() {
          List list = workManager.getWorkDatabase().workSpecDao().getWorkStatusPojoForTag(tag);
          return (List<WorkInfo>)WorkSpec.WORK_INFO_MAPPER.apply(list);
        }
      };
  }
  
  @NonNull
  public static StatusRunnable<WorkInfo> forUUID(@NonNull final WorkManagerImpl workManager, @NonNull final UUID id) {
    return new StatusRunnable<WorkInfo>() {
        WorkInfo runInternal() {
          WorkSpec.WorkInfoPojo workInfoPojo = workManager.getWorkDatabase().workSpecDao().getWorkStatusPojoForId(id.toString());
          return (workInfoPojo != null) ? workInfoPojo.toWorkInfo() : null;
        }
      };
  }
  
  @NonNull
  public static StatusRunnable<List<WorkInfo>> forUniqueWork(@NonNull final WorkManagerImpl workManager, @NonNull final String name) {
    return new StatusRunnable<List<WorkInfo>>() {
        List<WorkInfo> runInternal() {
          List list = workManager.getWorkDatabase().workSpecDao().getWorkStatusPojoForName(name);
          return (List<WorkInfo>)WorkSpec.WORK_INFO_MAPPER.apply(list);
        }
      };
  }
  
  @NonNull
  public static StatusRunnable<List<WorkInfo>> forWorkQuerySpec(@NonNull final WorkManagerImpl workManager, @NonNull final WorkQuery querySpec) {
    return new StatusRunnable<List<WorkInfo>>() {
        List<WorkInfo> runInternal() {
          List list = workManager.getWorkDatabase().rawWorkInfoDao().getWorkInfoPojos(RawQueries.workQueryToRawQuery(querySpec));
          return (List<WorkInfo>)WorkSpec.WORK_INFO_MAPPER.apply(list);
        }
      };
  }
  
  @NonNull
  public ListenableFuture<T> getFuture() {
    return (ListenableFuture<T>)this.mFuture;
  }
  
  public void run() {
    try {
      T t = runInternal();
      this.mFuture.set(t);
      return;
    } catch (Throwable throwable) {
      this.mFuture.setException(throwable);
      return;
    } 
  }
  
  @WorkerThread
  abstract T runInternal();
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\imp\\utils\StatusRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */