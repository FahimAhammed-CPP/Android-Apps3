package androidx.work.impl.utils;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.work.Logger;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class WorkTimer {
  private static final String TAG = Logger.tagWithPrefix("WorkTimer");
  
  private final ThreadFactory mBackgroundThreadFactory = new ThreadFactory() {
      private int mThreadsCreated = 0;
      
      public Thread newThread(@NonNull Runnable param1Runnable) {
        param1Runnable = Executors.defaultThreadFactory().newThread(param1Runnable);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WorkManager-WorkTimer-thread-");
        stringBuilder.append(this.mThreadsCreated);
        param1Runnable.setName(stringBuilder.toString());
        this.mThreadsCreated++;
        return (Thread)param1Runnable;
      }
    };
  
  private final ScheduledExecutorService mExecutorService = Executors.newSingleThreadScheduledExecutor(this.mBackgroundThreadFactory);
  
  final Map<String, TimeLimitExceededListener> mListeners = new HashMap<String, TimeLimitExceededListener>();
  
  final Object mLock = new Object();
  
  final Map<String, WorkTimerRunnable> mTimerMap = new HashMap<String, WorkTimerRunnable>();
  
  @NonNull
  @VisibleForTesting
  public ScheduledExecutorService getExecutorService() {
    return this.mExecutorService;
  }
  
  @NonNull
  @VisibleForTesting
  public Map<String, TimeLimitExceededListener> getListeners() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mListeners : Ljava/util/Map;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  @NonNull
  @VisibleForTesting
  public Map<String, WorkTimerRunnable> getTimerMap() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mTimerMap : Ljava/util/Map;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public void onDestroy() {
    if (!this.mExecutorService.isShutdown())
      this.mExecutorService.shutdownNow(); 
  }
  
  public void startTimer(@NonNull String paramString, long paramLong, @NonNull TimeLimitExceededListener paramTimeLimitExceededListener) {
    synchronized (this.mLock) {
      Logger.get().debug(TAG, String.format("Starting timer for %s", new Object[] { paramString }), new Throwable[0]);
      stopTimer(paramString);
      WorkTimerRunnable workTimerRunnable = new WorkTimerRunnable(this, paramString);
      this.mTimerMap.put(paramString, workTimerRunnable);
      this.mListeners.put(paramString, paramTimeLimitExceededListener);
      this.mExecutorService.schedule(workTimerRunnable, paramLong, TimeUnit.MILLISECONDS);
      return;
    } 
  }
  
  public void stopTimer(@NonNull String paramString) {
    synchronized (this.mLock) {
      if ((WorkTimerRunnable)this.mTimerMap.remove(paramString) != null) {
        Logger.get().debug(TAG, String.format("Stopping timer for %s", new Object[] { paramString }), new Throwable[0]);
        this.mListeners.remove(paramString);
      } 
      return;
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static interface TimeLimitExceededListener {
    void onTimeLimitExceeded(@NonNull String param1String);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static class WorkTimerRunnable implements Runnable {
    static final String TAG = "WrkTimerRunnable";
    
    private final String mWorkSpecId;
    
    private final WorkTimer mWorkTimer;
    
    WorkTimerRunnable(@NonNull WorkTimer param1WorkTimer, @NonNull String param1String) {
      this.mWorkTimer = param1WorkTimer;
      this.mWorkSpecId = param1String;
    }
    
    public void run() {
      synchronized (this.mWorkTimer.mLock) {
        if ((WorkTimerRunnable)this.mWorkTimer.mTimerMap.remove(this.mWorkSpecId) != null) {
          WorkTimer.TimeLimitExceededListener timeLimitExceededListener = this.mWorkTimer.mListeners.remove(this.mWorkSpecId);
          if (timeLimitExceededListener != null)
            timeLimitExceededListener.onTimeLimitExceeded(this.mWorkSpecId); 
        } else {
          Logger.get().debug("WrkTimerRunnable", String.format("Timer with %s is already marked as complete.", new Object[] { this.mWorkSpecId }), new Throwable[0]);
        } 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\imp\\utils\WorkTimer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */