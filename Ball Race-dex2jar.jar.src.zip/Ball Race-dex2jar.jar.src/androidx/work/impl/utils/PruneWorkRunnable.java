package androidx.work.impl.utils;

import androidx.annotation.RestrictTo;
import androidx.work.Operation;
import androidx.work.impl.OperationImpl;
import androidx.work.impl.WorkManagerImpl;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class PruneWorkRunnable implements Runnable {
  private final OperationImpl mOperation;
  
  private final WorkManagerImpl mWorkManagerImpl;
  
  public PruneWorkRunnable(WorkManagerImpl paramWorkManagerImpl) {
    this.mWorkManagerImpl = paramWorkManagerImpl;
    this.mOperation = new OperationImpl();
  }
  
  public Operation getOperation() {
    return (Operation)this.mOperation;
  }
  
  public void run() {
    try {
      this.mWorkManagerImpl.getWorkDatabase().workSpecDao().pruneFinishedWorkWithZeroDependentsIgnoringKeepForAtLeast();
      this.mOperation.setState((Operation.State)Operation.SUCCESS);
      return;
    } catch (Throwable throwable) {
      this.mOperation.setState((Operation.State)new Operation.State.FAILURE(throwable));
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\imp\\utils\PruneWorkRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */