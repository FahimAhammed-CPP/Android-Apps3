package androidx.work.impl.utils.taskexecutor;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.work.impl.utils.SerialExecutor;
import java.util.concurrent.Executor;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class WorkManagerTaskExecutor implements TaskExecutor {
  private final SerialExecutor mBackgroundExecutor;
  
  private final Executor mMainThreadExecutor = new Executor() {
      public void execute(@NonNull Runnable param1Runnable) {
        WorkManagerTaskExecutor.this.postToMainThread(param1Runnable);
      }
    };
  
  private final Handler mMainThreadHandler = new Handler(Looper.getMainLooper());
  
  public WorkManagerTaskExecutor(@NonNull Executor paramExecutor) {
    this.mBackgroundExecutor = new SerialExecutor(paramExecutor);
  }
  
  public void executeOnBackgroundThread(Runnable paramRunnable) {
    this.mBackgroundExecutor.execute(paramRunnable);
  }
  
  @NonNull
  public SerialExecutor getBackgroundExecutor() {
    return this.mBackgroundExecutor;
  }
  
  public Executor getMainThreadExecutor() {
    return this.mMainThreadExecutor;
  }
  
  public void postToMainThread(Runnable paramRunnable) {
    this.mMainThreadHandler.post(paramRunnable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\imp\\utils\taskexecutor\WorkManagerTaskExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */