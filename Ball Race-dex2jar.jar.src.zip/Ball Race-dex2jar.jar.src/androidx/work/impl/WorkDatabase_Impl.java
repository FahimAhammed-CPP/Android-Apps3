package androidx.work.impl;

import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import androidx.work.impl.model.DependencyDao;
import androidx.work.impl.model.PreferenceDao;
import androidx.work.impl.model.RawWorkInfoDao;
import androidx.work.impl.model.SystemIdInfoDao;
import androidx.work.impl.model.WorkNameDao;
import androidx.work.impl.model.WorkProgressDao;
import androidx.work.impl.model.WorkSpecDao;
import androidx.work.impl.model.WorkTagDao;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public final class WorkDatabase_Impl extends WorkDatabase {
  private volatile DependencyDao _dependencyDao;
  
  private volatile PreferenceDao _preferenceDao;
  
  private volatile RawWorkInfoDao _rawWorkInfoDao;
  
  private volatile SystemIdInfoDao _systemIdInfoDao;
  
  private volatile WorkNameDao _workNameDao;
  
  private volatile WorkProgressDao _workProgressDao;
  
  private volatile WorkSpecDao _workSpecDao;
  
  private volatile WorkTagDao _workTagDao;
  
  public void clearAllTables() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial assertNotMainThread : ()V
    //   4: aload_0
    //   5: invokespecial getOpenHelper : ()Landroidx/sqlite/db/SupportSQLiteOpenHelper;
    //   8: invokeinterface getWritableDatabase : ()Landroidx/sqlite/db/SupportSQLiteDatabase;
    //   13: astore_2
    //   14: getstatic android/os/Build$VERSION.SDK_INT : I
    //   17: bipush #21
    //   19: if_icmplt -> 27
    //   22: iconst_1
    //   23: istore_1
    //   24: goto -> 29
    //   27: iconst_0
    //   28: istore_1
    //   29: iload_1
    //   30: ifne -> 41
    //   33: aload_2
    //   34: ldc 'PRAGMA foreign_keys = FALSE'
    //   36: invokeinterface execSQL : (Ljava/lang/String;)V
    //   41: aload_0
    //   42: invokespecial beginTransaction : ()V
    //   45: iload_1
    //   46: ifeq -> 57
    //   49: aload_2
    //   50: ldc 'PRAGMA defer_foreign_keys = TRUE'
    //   52: invokeinterface execSQL : (Ljava/lang/String;)V
    //   57: aload_2
    //   58: ldc 'DELETE FROM `Dependency`'
    //   60: invokeinterface execSQL : (Ljava/lang/String;)V
    //   65: aload_2
    //   66: ldc 'DELETE FROM `WorkSpec`'
    //   68: invokeinterface execSQL : (Ljava/lang/String;)V
    //   73: aload_2
    //   74: ldc 'DELETE FROM `WorkTag`'
    //   76: invokeinterface execSQL : (Ljava/lang/String;)V
    //   81: aload_2
    //   82: ldc 'DELETE FROM `SystemIdInfo`'
    //   84: invokeinterface execSQL : (Ljava/lang/String;)V
    //   89: aload_2
    //   90: ldc 'DELETE FROM `WorkName`'
    //   92: invokeinterface execSQL : (Ljava/lang/String;)V
    //   97: aload_2
    //   98: ldc 'DELETE FROM `WorkProgress`'
    //   100: invokeinterface execSQL : (Ljava/lang/String;)V
    //   105: aload_2
    //   106: ldc 'DELETE FROM `Preference`'
    //   108: invokeinterface execSQL : (Ljava/lang/String;)V
    //   113: aload_0
    //   114: invokespecial setTransactionSuccessful : ()V
    //   117: aload_0
    //   118: invokespecial endTransaction : ()V
    //   121: iload_1
    //   122: ifne -> 133
    //   125: aload_2
    //   126: ldc 'PRAGMA foreign_keys = TRUE'
    //   128: invokeinterface execSQL : (Ljava/lang/String;)V
    //   133: aload_2
    //   134: ldc 'PRAGMA wal_checkpoint(FULL)'
    //   136: invokeinterface query : (Ljava/lang/String;)Landroid/database/Cursor;
    //   141: invokeinterface close : ()V
    //   146: aload_2
    //   147: invokeinterface inTransaction : ()Z
    //   152: ifne -> 163
    //   155: aload_2
    //   156: ldc 'VACUUM'
    //   158: invokeinterface execSQL : (Ljava/lang/String;)V
    //   163: return
    //   164: astore_3
    //   165: aload_0
    //   166: invokespecial endTransaction : ()V
    //   169: iload_1
    //   170: ifne -> 181
    //   173: aload_2
    //   174: ldc 'PRAGMA foreign_keys = TRUE'
    //   176: invokeinterface execSQL : (Ljava/lang/String;)V
    //   181: aload_2
    //   182: ldc 'PRAGMA wal_checkpoint(FULL)'
    //   184: invokeinterface query : (Ljava/lang/String;)Landroid/database/Cursor;
    //   189: invokeinterface close : ()V
    //   194: aload_2
    //   195: invokeinterface inTransaction : ()Z
    //   200: ifne -> 211
    //   203: aload_2
    //   204: ldc 'VACUUM'
    //   206: invokeinterface execSQL : (Ljava/lang/String;)V
    //   211: aload_3
    //   212: athrow
    // Exception table:
    //   from	to	target	type
    //   33	41	164	finally
    //   41	45	164	finally
    //   49	57	164	finally
    //   57	117	164	finally
  }
  
  protected InvalidationTracker createInvalidationTracker() {
    return new InvalidationTracker((RoomDatabase)this, new HashMap<Object, Object>(0), new HashMap<Object, Object>(0), new String[] { "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference" });
  }
  
  protected SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration paramDatabaseConfiguration) {
    RoomOpenHelper roomOpenHelper = new RoomOpenHelper(paramDatabaseConfiguration, new RoomOpenHelper.Delegate(12) {
          public void createAllTables(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
            param1SupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            param1SupportSQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
            param1SupportSQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
            param1SupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))");
            param1SupportSQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
            param1SupportSQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)");
            param1SupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            param1SupportSQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
            param1SupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            param1SupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            param1SupportSQLiteDatabase.execSQL("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
            param1SupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
            param1SupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
            param1SupportSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
            param1SupportSQLiteDatabase.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'c103703e120ae8cc73c9248622f3cd1e')");
          }
          
          public void dropAllTables(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
            param1SupportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `Dependency`");
            param1SupportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `WorkSpec`");
            param1SupportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `WorkTag`");
            param1SupportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `SystemIdInfo`");
            param1SupportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `WorkName`");
            param1SupportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `WorkProgress`");
            param1SupportSQLiteDatabase.execSQL("DROP TABLE IF EXISTS `Preference`");
            if (WorkDatabase_Impl.this.mCallbacks != null) {
              int i = 0;
              int j = WorkDatabase_Impl.this.mCallbacks.size();
              while (i < j) {
                ((RoomDatabase.Callback)WorkDatabase_Impl.this.mCallbacks.get(i)).onDestructiveMigration(param1SupportSQLiteDatabase);
                i++;
              } 
            } 
          }
          
          protected void onCreate(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
            if (WorkDatabase_Impl.this.mCallbacks != null) {
              int i = 0;
              int j = WorkDatabase_Impl.this.mCallbacks.size();
              while (i < j) {
                ((RoomDatabase.Callback)WorkDatabase_Impl.this.mCallbacks.get(i)).onCreate(param1SupportSQLiteDatabase);
                i++;
              } 
            } 
          }
          
          public void onOpen(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
            WorkDatabase_Impl.access$602(WorkDatabase_Impl.this, param1SupportSQLiteDatabase);
            param1SupportSQLiteDatabase.execSQL("PRAGMA foreign_keys = ON");
            WorkDatabase_Impl.this.internalInitInvalidationTracker(param1SupportSQLiteDatabase);
            if (WorkDatabase_Impl.this.mCallbacks != null) {
              int i = 0;
              int j = WorkDatabase_Impl.this.mCallbacks.size();
              while (i < j) {
                ((RoomDatabase.Callback)WorkDatabase_Impl.this.mCallbacks.get(i)).onOpen(param1SupportSQLiteDatabase);
                i++;
              } 
            } 
          }
          
          public void onPostMigrate(SupportSQLiteDatabase param1SupportSQLiteDatabase) {}
          
          public void onPreMigrate(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
            DBUtil.dropFtsSyncTriggers(param1SupportSQLiteDatabase);
          }
          
          protected RoomOpenHelper.ValidationResult onValidateSchema(SupportSQLiteDatabase param1SupportSQLiteDatabase) {
            StringBuilder stringBuilder;
            HashMap<Object, Object> hashMap7 = new HashMap<Object, Object>(2);
            hashMap7.put("work_spec_id", new TableInfo.Column("work_spec_id", "TEXT", true, 1, null, 1));
            hashMap7.put("prerequisite_id", new TableInfo.Column("prerequisite_id", "TEXT", true, 2, null, 1));
            HashSet<TableInfo.ForeignKey> hashSet5 = new HashSet(2);
            hashSet5.add(new TableInfo.ForeignKey("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
            hashSet5.add(new TableInfo.ForeignKey("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "prerequisite_id" }, ), Arrays.asList(new String[] { "id" })));
            HashSet<TableInfo.Index> hashSet6 = new HashSet(2);
            hashSet6.add(new TableInfo.Index("index_Dependency_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
            hashSet6.add(new TableInfo.Index("index_Dependency_prerequisite_id", false, Arrays.asList(new String[] { "prerequisite_id" })));
            TableInfo tableInfo8 = new TableInfo("Dependency", hashMap7, hashSet5, hashSet6);
            TableInfo tableInfo14 = TableInfo.read(param1SupportSQLiteDatabase, "Dependency");
            if (!tableInfo8.equals(tableInfo14)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Dependency(androidx.work.impl.model.Dependency).\n Expected:\n");
              stringBuilder.append(tableInfo8);
              stringBuilder.append("\n Found:\n");
              stringBuilder.append(tableInfo14);
              return new RoomOpenHelper.ValidationResult(false, stringBuilder.toString());
            } 
            HashMap<Object, Object> hashMap6 = new HashMap<Object, Object>(25);
            hashMap6.put("id", new TableInfo.Column("id", "TEXT", true, 1, null, 1));
            hashMap6.put("state", new TableInfo.Column("state", "INTEGER", true, 0, null, 1));
            hashMap6.put("worker_class_name", new TableInfo.Column("worker_class_name", "TEXT", true, 0, null, 1));
            hashMap6.put("input_merger_class_name", new TableInfo.Column("input_merger_class_name", "TEXT", false, 0, null, 1));
            hashMap6.put("input", new TableInfo.Column("input", "BLOB", true, 0, null, 1));
            hashMap6.put("output", new TableInfo.Column("output", "BLOB", true, 0, null, 1));
            hashMap6.put("initial_delay", new TableInfo.Column("initial_delay", "INTEGER", true, 0, null, 1));
            hashMap6.put("interval_duration", new TableInfo.Column("interval_duration", "INTEGER", true, 0, null, 1));
            hashMap6.put("flex_duration", new TableInfo.Column("flex_duration", "INTEGER", true, 0, null, 1));
            hashMap6.put("run_attempt_count", new TableInfo.Column("run_attempt_count", "INTEGER", true, 0, null, 1));
            hashMap6.put("backoff_policy", new TableInfo.Column("backoff_policy", "INTEGER", true, 0, null, 1));
            hashMap6.put("backoff_delay_duration", new TableInfo.Column("backoff_delay_duration", "INTEGER", true, 0, null, 1));
            hashMap6.put("period_start_time", new TableInfo.Column("period_start_time", "INTEGER", true, 0, null, 1));
            hashMap6.put("minimum_retention_duration", new TableInfo.Column("minimum_retention_duration", "INTEGER", true, 0, null, 1));
            hashMap6.put("schedule_requested_at", new TableInfo.Column("schedule_requested_at", "INTEGER", true, 0, null, 1));
            hashMap6.put("run_in_foreground", new TableInfo.Column("run_in_foreground", "INTEGER", true, 0, null, 1));
            hashMap6.put("out_of_quota_policy", new TableInfo.Column("out_of_quota_policy", "INTEGER", true, 0, null, 1));
            hashMap6.put("required_network_type", new TableInfo.Column("required_network_type", "INTEGER", false, 0, null, 1));
            hashMap6.put("requires_charging", new TableInfo.Column("requires_charging", "INTEGER", true, 0, null, 1));
            hashMap6.put("requires_device_idle", new TableInfo.Column("requires_device_idle", "INTEGER", true, 0, null, 1));
            hashMap6.put("requires_battery_not_low", new TableInfo.Column("requires_battery_not_low", "INTEGER", true, 0, null, 1));
            hashMap6.put("requires_storage_not_low", new TableInfo.Column("requires_storage_not_low", "INTEGER", true, 0, null, 1));
            hashMap6.put("trigger_content_update_delay", new TableInfo.Column("trigger_content_update_delay", "INTEGER", true, 0, null, 1));
            hashMap6.put("trigger_max_content_delay", new TableInfo.Column("trigger_max_content_delay", "INTEGER", true, 0, null, 1));
            hashMap6.put("content_uri_triggers", new TableInfo.Column("content_uri_triggers", "BLOB", false, 0, null, 1));
            HashSet hashSet = new HashSet(0);
            hashSet6 = new HashSet<TableInfo.Index>(2);
            hashSet6.add(new TableInfo.Index("index_WorkSpec_schedule_requested_at", false, Arrays.asList(new String[] { "schedule_requested_at" })));
            hashSet6.add(new TableInfo.Index("index_WorkSpec_period_start_time", false, Arrays.asList(new String[] { "period_start_time" })));
            TableInfo tableInfo7 = new TableInfo("WorkSpec", hashMap6, hashSet, hashSet6);
            TableInfo tableInfo13 = TableInfo.read((SupportSQLiteDatabase)stringBuilder, "WorkSpec");
            if (!tableInfo7.equals(tableInfo13)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n");
              stringBuilder.append(tableInfo7);
              stringBuilder.append("\n Found:\n");
              stringBuilder.append(tableInfo13);
              return new RoomOpenHelper.ValidationResult(false, stringBuilder.toString());
            } 
            HashMap<Object, Object> hashMap5 = new HashMap<Object, Object>(2);
            hashMap5.put("tag", new TableInfo.Column("tag", "TEXT", true, 1, null, 1));
            hashMap5.put("work_spec_id", new TableInfo.Column("work_spec_id", "TEXT", true, 2, null, 1));
            HashSet<TableInfo.ForeignKey> hashSet4 = new HashSet(1);
            hashSet4.add(new TableInfo.ForeignKey("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
            hashSet6 = new HashSet<TableInfo.Index>(1);
            hashSet6.add(new TableInfo.Index("index_WorkTag_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
            TableInfo tableInfo6 = new TableInfo("WorkTag", hashMap5, hashSet4, hashSet6);
            TableInfo tableInfo12 = TableInfo.read((SupportSQLiteDatabase)stringBuilder, "WorkTag");
            if (!tableInfo6.equals(tableInfo12)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n");
              stringBuilder.append(tableInfo6);
              stringBuilder.append("\n Found:\n");
              stringBuilder.append(tableInfo12);
              return new RoomOpenHelper.ValidationResult(false, stringBuilder.toString());
            } 
            HashMap<Object, Object> hashMap4 = new HashMap<Object, Object>(2);
            hashMap4.put("work_spec_id", new TableInfo.Column("work_spec_id", "TEXT", true, 1, null, 1));
            hashMap4.put("system_id", new TableInfo.Column("system_id", "INTEGER", true, 0, null, 1));
            HashSet<TableInfo.ForeignKey> hashSet3 = new HashSet(1);
            hashSet3.add(new TableInfo.ForeignKey("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
            TableInfo tableInfo5 = new TableInfo("SystemIdInfo", hashMap4, hashSet3, new HashSet(0));
            TableInfo tableInfo11 = TableInfo.read((SupportSQLiteDatabase)stringBuilder, "SystemIdInfo");
            if (!tableInfo5.equals(tableInfo11)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n");
              stringBuilder.append(tableInfo5);
              stringBuilder.append("\n Found:\n");
              stringBuilder.append(tableInfo11);
              return new RoomOpenHelper.ValidationResult(false, stringBuilder.toString());
            } 
            HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>(2);
            hashMap3.put("name", new TableInfo.Column("name", "TEXT", true, 1, null, 1));
            hashMap3.put("work_spec_id", new TableInfo.Column("work_spec_id", "TEXT", true, 2, null, 1));
            HashSet<TableInfo.ForeignKey> hashSet2 = new HashSet(1);
            hashSet2.add(new TableInfo.ForeignKey("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
            hashSet6 = new HashSet<TableInfo.Index>(1);
            hashSet6.add(new TableInfo.Index("index_WorkName_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
            TableInfo tableInfo4 = new TableInfo("WorkName", hashMap3, hashSet2, hashSet6);
            TableInfo tableInfo10 = TableInfo.read((SupportSQLiteDatabase)stringBuilder, "WorkName");
            if (!tableInfo4.equals(tableInfo10)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("WorkName(androidx.work.impl.model.WorkName).\n Expected:\n");
              stringBuilder.append(tableInfo4);
              stringBuilder.append("\n Found:\n");
              stringBuilder.append(tableInfo10);
              return new RoomOpenHelper.ValidationResult(false, stringBuilder.toString());
            } 
            HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>(2);
            hashMap2.put("work_spec_id", new TableInfo.Column("work_spec_id", "TEXT", true, 1, null, 1));
            hashMap2.put("progress", new TableInfo.Column("progress", "BLOB", true, 0, null, 1));
            HashSet<TableInfo.ForeignKey> hashSet1 = new HashSet(1);
            hashSet1.add(new TableInfo.ForeignKey("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
            TableInfo tableInfo3 = new TableInfo("WorkProgress", hashMap2, hashSet1, new HashSet(0));
            TableInfo tableInfo9 = TableInfo.read((SupportSQLiteDatabase)stringBuilder, "WorkProgress");
            if (!tableInfo3.equals(tableInfo9)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n");
              stringBuilder.append(tableInfo3);
              stringBuilder.append("\n Found:\n");
              stringBuilder.append(tableInfo9);
              return new RoomOpenHelper.ValidationResult(false, stringBuilder.toString());
            } 
            HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>(2);
            hashMap1.put("key", new TableInfo.Column("key", "TEXT", true, 1, null, 1));
            hashMap1.put("long_value", new TableInfo.Column("long_value", "INTEGER", false, 0, null, 1));
            TableInfo tableInfo2 = new TableInfo("Preference", hashMap1, new HashSet(0), new HashSet(0));
            TableInfo tableInfo1 = TableInfo.read((SupportSQLiteDatabase)stringBuilder, "Preference");
            if (!tableInfo2.equals(tableInfo1)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Preference(androidx.work.impl.model.Preference).\n Expected:\n");
              stringBuilder1.append(tableInfo2);
              stringBuilder1.append("\n Found:\n");
              stringBuilder1.append(tableInfo1);
              return new RoomOpenHelper.ValidationResult(false, stringBuilder1.toString());
            } 
            return new RoomOpenHelper.ValidationResult(true, null);
          }
        }"c103703e120ae8cc73c9248622f3cd1e", "49f946663a8deb7054212b8adda248c6");
    SupportSQLiteOpenHelper.Configuration configuration = SupportSQLiteOpenHelper.Configuration.builder(paramDatabaseConfiguration.context).name(paramDatabaseConfiguration.name).callback((SupportSQLiteOpenHelper.Callback)roomOpenHelper).build();
    return paramDatabaseConfiguration.sqliteOpenHelperFactory.create(configuration);
  }
  
  public DependencyDao dependencyDao() {
    // Byte code:
    //   0: aload_0
    //   1: getfield _dependencyDao : Landroidx/work/impl/model/DependencyDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _dependencyDao : Landroidx/work/impl/model/DependencyDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _dependencyDao : Landroidx/work/impl/model/DependencyDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new androidx/work/impl/model/DependencyDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _dependencyDao : Landroidx/work/impl/model/DependencyDao;
    //   33: aload_0
    //   34: getfield _dependencyDao : Landroidx/work/impl/model/DependencyDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public PreferenceDao preferenceDao() {
    // Byte code:
    //   0: aload_0
    //   1: getfield _preferenceDao : Landroidx/work/impl/model/PreferenceDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _preferenceDao : Landroidx/work/impl/model/PreferenceDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _preferenceDao : Landroidx/work/impl/model/PreferenceDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new androidx/work/impl/model/PreferenceDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _preferenceDao : Landroidx/work/impl/model/PreferenceDao;
    //   33: aload_0
    //   34: getfield _preferenceDao : Landroidx/work/impl/model/PreferenceDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public RawWorkInfoDao rawWorkInfoDao() {
    // Byte code:
    //   0: aload_0
    //   1: getfield _rawWorkInfoDao : Landroidx/work/impl/model/RawWorkInfoDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _rawWorkInfoDao : Landroidx/work/impl/model/RawWorkInfoDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _rawWorkInfoDao : Landroidx/work/impl/model/RawWorkInfoDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new androidx/work/impl/model/RawWorkInfoDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _rawWorkInfoDao : Landroidx/work/impl/model/RawWorkInfoDao;
    //   33: aload_0
    //   34: getfield _rawWorkInfoDao : Landroidx/work/impl/model/RawWorkInfoDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public SystemIdInfoDao systemIdInfoDao() {
    // Byte code:
    //   0: aload_0
    //   1: getfield _systemIdInfoDao : Landroidx/work/impl/model/SystemIdInfoDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _systemIdInfoDao : Landroidx/work/impl/model/SystemIdInfoDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _systemIdInfoDao : Landroidx/work/impl/model/SystemIdInfoDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new androidx/work/impl/model/SystemIdInfoDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _systemIdInfoDao : Landroidx/work/impl/model/SystemIdInfoDao;
    //   33: aload_0
    //   34: getfield _systemIdInfoDao : Landroidx/work/impl/model/SystemIdInfoDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public WorkNameDao workNameDao() {
    // Byte code:
    //   0: aload_0
    //   1: getfield _workNameDao : Landroidx/work/impl/model/WorkNameDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _workNameDao : Landroidx/work/impl/model/WorkNameDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _workNameDao : Landroidx/work/impl/model/WorkNameDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new androidx/work/impl/model/WorkNameDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _workNameDao : Landroidx/work/impl/model/WorkNameDao;
    //   33: aload_0
    //   34: getfield _workNameDao : Landroidx/work/impl/model/WorkNameDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public WorkProgressDao workProgressDao() {
    // Byte code:
    //   0: aload_0
    //   1: getfield _workProgressDao : Landroidx/work/impl/model/WorkProgressDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _workProgressDao : Landroidx/work/impl/model/WorkProgressDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _workProgressDao : Landroidx/work/impl/model/WorkProgressDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new androidx/work/impl/model/WorkProgressDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _workProgressDao : Landroidx/work/impl/model/WorkProgressDao;
    //   33: aload_0
    //   34: getfield _workProgressDao : Landroidx/work/impl/model/WorkProgressDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public WorkSpecDao workSpecDao() {
    // Byte code:
    //   0: aload_0
    //   1: getfield _workSpecDao : Landroidx/work/impl/model/WorkSpecDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _workSpecDao : Landroidx/work/impl/model/WorkSpecDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _workSpecDao : Landroidx/work/impl/model/WorkSpecDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new androidx/work/impl/model/WorkSpecDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _workSpecDao : Landroidx/work/impl/model/WorkSpecDao;
    //   33: aload_0
    //   34: getfield _workSpecDao : Landroidx/work/impl/model/WorkSpecDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public WorkTagDao workTagDao() {
    // Byte code:
    //   0: aload_0
    //   1: getfield _workTagDao : Landroidx/work/impl/model/WorkTagDao;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield _workTagDao : Landroidx/work/impl/model/WorkTagDao;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield _workTagDao : Landroidx/work/impl/model/WorkTagDao;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new androidx/work/impl/model/WorkTagDao_Impl
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Landroidx/room/RoomDatabase;)V
    //   30: putfield _workTagDao : Landroidx/work/impl/model/WorkTagDao;
    //   33: aload_0
    //   34: getfield _workTagDao : Landroidx/work/impl/model/WorkTagDao;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\impl\WorkDatabase_Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */