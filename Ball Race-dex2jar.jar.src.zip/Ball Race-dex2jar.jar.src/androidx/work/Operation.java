package androidx.work;

import android.annotation.SuppressLint;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.lifecycle.LiveData;
import com.google.common.util.concurrent.ListenableFuture;

public interface Operation {
  @SuppressLint({"SyntheticAccessor"})
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final State.IN_PROGRESS IN_PROGRESS;
  
  @SuppressLint({"SyntheticAccessor"})
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final State.SUCCESS SUCCESS = new State.SUCCESS();
  
  static {
    IN_PROGRESS = new State.IN_PROGRESS();
  }
  
  @NonNull
  ListenableFuture<State.SUCCESS> getResult();
  
  @NonNull
  LiveData<State> getState();
  
  public static abstract class State {
    public static final class FAILURE extends State {
      private final Throwable mThrowable;
      
      public FAILURE(@NonNull Throwable param2Throwable) {
        this.mThrowable = param2Throwable;
      }
      
      @NonNull
      public Throwable getThrowable() {
        return this.mThrowable;
      }
      
      @NonNull
      public String toString() {
        return String.format("FAILURE (%s)", new Object[] { this.mThrowable.getMessage() });
      }
    }
    
    public static final class IN_PROGRESS extends State {
      private IN_PROGRESS() {}
      
      @NonNull
      public String toString() {
        return "IN_PROGRESS";
      }
    }
    
    public static final class SUCCESS extends State {
      private SUCCESS() {}
      
      @NonNull
      public String toString() {
        return "SUCCESS";
      }
    }
  }
  
  public static final class FAILURE extends State {
    private final Throwable mThrowable;
    
    public FAILURE(@NonNull Throwable param1Throwable) {
      this.mThrowable = param1Throwable;
    }
    
    @NonNull
    public Throwable getThrowable() {
      return this.mThrowable;
    }
    
    @NonNull
    public String toString() {
      return String.format("FAILURE (%s)", new Object[] { this.mThrowable.getMessage() });
    }
  }
  
  public static final class IN_PROGRESS extends State {
    private IN_PROGRESS() {}
    
    @NonNull
    public String toString() {
      return "IN_PROGRESS";
    }
  }
  
  public static final class SUCCESS extends State {
    private SUCCESS() {}
    
    @NonNull
    public String toString() {
      return "SUCCESS";
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\work\Operation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */