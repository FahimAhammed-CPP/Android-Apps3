package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import java.util.HashMap;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
public class MultiInstanceInvalidationService extends Service {
  private final IMultiInstanceInvalidationService.Stub mBinder = new IMultiInstanceInvalidationService.Stub() {
      public void broadcastInvalidation(int param1Int, String[] param1ArrayOfString) {
        synchronized (MultiInstanceInvalidationService.this.mCallbackList) {
          String str = MultiInstanceInvalidationService.this.mClientNames.get(Integer.valueOf(param1Int));
          if (str == null) {
            Log.w("ROOM", "Remote invalidation client ID not registered");
            return;
          } 
          int j = MultiInstanceInvalidationService.this.mCallbackList.beginBroadcast();
          int i = 0;
          while (i < j) {
            try {
              int k = ((Integer)MultiInstanceInvalidationService.this.mCallbackList.getBroadcastCookie(i)).intValue();
              String str1 = MultiInstanceInvalidationService.this.mClientNames.get(Integer.valueOf(k));
              if (param1Int != k) {
                boolean bool = str.equals(str1);
                if (bool)
                  try {
                    ((IMultiInstanceInvalidationCallback)MultiInstanceInvalidationService.this.mCallbackList.getBroadcastItem(i)).onInvalidation(param1ArrayOfString);
                  } catch (RemoteException remoteException) {
                    Log.w("ROOM", "Error invoking a remote callback", (Throwable)remoteException);
                  }  
              } 
            } finally {
              MultiInstanceInvalidationService.this.mCallbackList.finishBroadcast();
            } 
          } 
          MultiInstanceInvalidationService.this.mCallbackList.finishBroadcast();
          return;
        } 
      }
      
      public int registerCallback(IMultiInstanceInvalidationCallback param1IMultiInstanceInvalidationCallback, String param1String) {
        if (param1String == null)
          return 0; 
        synchronized (MultiInstanceInvalidationService.this.mCallbackList) {
          MultiInstanceInvalidationService multiInstanceInvalidationService2 = MultiInstanceInvalidationService.this;
          int i = multiInstanceInvalidationService2.mMaxClientId + 1;
          multiInstanceInvalidationService2.mMaxClientId = i;
          if (MultiInstanceInvalidationService.this.mCallbackList.register(param1IMultiInstanceInvalidationCallback, Integer.valueOf(i))) {
            MultiInstanceInvalidationService.this.mClientNames.put(Integer.valueOf(i), param1String);
            return i;
          } 
          MultiInstanceInvalidationService multiInstanceInvalidationService1 = MultiInstanceInvalidationService.this;
          multiInstanceInvalidationService1.mMaxClientId--;
          return 0;
        } 
      }
      
      public void unregisterCallback(IMultiInstanceInvalidationCallback param1IMultiInstanceInvalidationCallback, int param1Int) {
        synchronized (MultiInstanceInvalidationService.this.mCallbackList) {
          MultiInstanceInvalidationService.this.mCallbackList.unregister(param1IMultiInstanceInvalidationCallback);
          MultiInstanceInvalidationService.this.mClientNames.remove(Integer.valueOf(param1Int));
          return;
        } 
      }
    };
  
  final RemoteCallbackList<IMultiInstanceInvalidationCallback> mCallbackList = new RemoteCallbackList<IMultiInstanceInvalidationCallback>() {
      public void onCallbackDied(IMultiInstanceInvalidationCallback param1IMultiInstanceInvalidationCallback, Object param1Object) {
        MultiInstanceInvalidationService.this.mClientNames.remove(Integer.valueOf(((Integer)param1Object).intValue()));
      }
    };
  
  final HashMap<Integer, String> mClientNames = new HashMap<Integer, String>();
  
  int mMaxClientId = 0;
  
  @Nullable
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.mBinder;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */