package androidx.browser.browseractions;

import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.browser.R;
import androidx.core.widget.TextViewCompat;
import java.util.ArrayList;
import java.util.List;

@Deprecated
class BrowserActionsFallbackMenuUi implements AdapterView.OnItemClickListener {
  private static final String TAG = "BrowserActionskMenuUi";
  
  @Nullable
  private BrowserActionsFallbackMenuDialog mBrowserActionsDialog;
  
  final Context mContext;
  
  private final List<BrowserActionItem> mMenuItems;
  
  @Nullable
  BrowserActionsFallMenuUiListener mMenuUiListener;
  
  final Uri mUri;
  
  BrowserActionsFallbackMenuUi(@NonNull Context paramContext, @NonNull Uri paramUri, @NonNull List<BrowserActionItem> paramList) {
    this.mContext = paramContext;
    this.mUri = paramUri;
    this.mMenuItems = buildFallbackMenuItemList(paramList);
  }
  
  private Runnable buildCopyAction() {
    return new Runnable() {
        public void run() {
          ((ClipboardManager)BrowserActionsFallbackMenuUi.this.mContext.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("url", BrowserActionsFallbackMenuUi.this.mUri.toString()));
          String str = BrowserActionsFallbackMenuUi.this.mContext.getString(R.string.copy_toast_msg);
          Toast.makeText(BrowserActionsFallbackMenuUi.this.mContext, str, 0).show();
        }
      };
  }
  
  @NonNull
  private List<BrowserActionItem> buildFallbackMenuItemList(List<BrowserActionItem> paramList) {
    ArrayList<BrowserActionItem> arrayList = new ArrayList();
    arrayList.add(new BrowserActionItem(this.mContext.getString(R.string.fallback_menu_item_open_in_browser), buildOpenInBrowserAction()));
    arrayList.add(new BrowserActionItem(this.mContext.getString(R.string.fallback_menu_item_copy_link), buildCopyAction()));
    arrayList.add(new BrowserActionItem(this.mContext.getString(R.string.fallback_menu_item_share_link), buildShareAction()));
    arrayList.addAll(paramList);
    return arrayList;
  }
  
  private PendingIntent buildOpenInBrowserAction() {
    Intent intent = new Intent("android.intent.action.VIEW", this.mUri);
    return PendingIntent.getActivity(this.mContext, 0, intent, 67108864);
  }
  
  private PendingIntent buildShareAction() {
    Intent intent = new Intent("android.intent.action.SEND");
    intent.putExtra("android.intent.extra.TEXT", this.mUri.toString());
    intent.setType("text/plain");
    return PendingIntent.getActivity(this.mContext, 0, intent, 67108864);
  }
  
  private BrowserActionsFallbackMenuView initMenuView(View paramView) {
    BrowserActionsFallbackMenuView browserActionsFallbackMenuView = (BrowserActionsFallbackMenuView)paramView.findViewById(R.id.browser_actions_menu_view);
    final TextView urlTextView = (TextView)paramView.findViewById(R.id.browser_actions_header_text);
    textView.setText(this.mUri.toString());
    textView.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (TextViewCompat.getMaxLines(urlTextView) == Integer.MAX_VALUE) {
              urlTextView.setMaxLines(1);
              urlTextView.setEllipsize(TextUtils.TruncateAt.END);
              return;
            } 
            urlTextView.setMaxLines(2147483647);
            urlTextView.setEllipsize(null);
          }
        });
    ListView listView = (ListView)paramView.findViewById(R.id.browser_actions_menu_items);
    listView.setAdapter((ListAdapter)new BrowserActionsFallbackMenuAdapter(this.mMenuItems, this.mContext));
    listView.setOnItemClickListener(this);
    return browserActionsFallbackMenuView;
  }
  
  public void displayMenu() {
    final View view = LayoutInflater.from(this.mContext).inflate(R.layout.browser_actions_context_menu_page, null);
    this.mBrowserActionsDialog = new BrowserActionsFallbackMenuDialog(this.mContext, (View)initMenuView(view));
    this.mBrowserActionsDialog.setContentView(view);
    if (this.mMenuUiListener != null)
      this.mBrowserActionsDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            public void onShow(DialogInterface param1DialogInterface) {
              if (BrowserActionsFallbackMenuUi.this.mMenuUiListener == null) {
                Log.e("BrowserActionskMenuUi", "Cannot trigger menu item listener, it is null");
                return;
              } 
              BrowserActionsFallbackMenuUi.this.mMenuUiListener.onMenuShown(view);
            }
          }); 
    this.mBrowserActionsDialog.show();
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    BrowserActionItem browserActionItem = this.mMenuItems.get(paramInt);
    if (browserActionItem.getAction() != null) {
      try {
        browserActionItem.getAction().send();
      } catch (android.app.PendingIntent.CanceledException canceledException) {
        Log.e("BrowserActionskMenuUi", "Failed to send custom item action", (Throwable)canceledException);
      } 
    } else if (canceledException.getRunnableAction() != null) {
      canceledException.getRunnableAction().run();
    } 
    BrowserActionsFallbackMenuDialog browserActionsFallbackMenuDialog = this.mBrowserActionsDialog;
    if (browserActionsFallbackMenuDialog == null) {
      Log.e("BrowserActionskMenuUi", "Cannot dismiss dialog, it has already been dismissed.");
      return;
    } 
    browserActionsFallbackMenuDialog.dismiss();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  @VisibleForTesting
  void setMenuUiListener(@Nullable BrowserActionsFallMenuUiListener paramBrowserActionsFallMenuUiListener) {
    this.mMenuUiListener = paramBrowserActionsFallMenuUiListener;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP_PREFIX})
  @VisibleForTesting
  static interface BrowserActionsFallMenuUiListener {
    void onMenuShown(View param1View);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\androidx\browser\browseractions\BrowserActionsFallbackMenuUi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */