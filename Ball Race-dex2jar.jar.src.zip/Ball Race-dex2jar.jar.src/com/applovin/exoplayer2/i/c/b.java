package com.applovin.exoplayer2.i.c;

import com.applovin.exoplayer2.i.a;
import com.applovin.exoplayer2.i.f;
import java.util.List;

final class b implements f {
  private final List<a> a;
  
  public b(List<a> paramList) {
    this.a = paramList;
  }
  
  public int a(long paramLong) {
    return -1;
  }
  
  public long a(int paramInt) {
    return 0L;
  }
  
  public List<a> b(long paramLong) {
    return this.a;
  }
  
  public int f_() {
    return 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\i\c\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */