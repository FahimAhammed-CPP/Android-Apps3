package com.applovin.exoplayer2.i.c;

import android.graphics.Bitmap;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.i.d;
import com.applovin.exoplayer2.i.f;
import com.applovin.exoplayer2.i.h;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.y;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.zip.Inflater;

public final class a extends d {
  private final y a = new y();
  
  private final y b = new y();
  
  private final a c = new a();
  
  @Nullable
  private Inflater d;
  
  public a() {
    super("PgsDecoder");
  }
  
  @Nullable
  private static com.applovin.exoplayer2.i.a a(y paramy, a parama) {
    com.applovin.exoplayer2.i.a a1;
    int i = paramy.b();
    int j = paramy.h();
    int k = paramy.i();
    int m = paramy.c() + k;
    a a2 = null;
    if (m > i) {
      paramy.d(i);
      return null;
    } 
    if (j != 128) {
      switch (j) {
        default:
          parama = a2;
          paramy.d(m);
          return (com.applovin.exoplayer2.i.a)parama;
        case 22:
          a.c(parama, paramy, k);
          parama = a2;
          paramy.d(m);
          return (com.applovin.exoplayer2.i.a)parama;
        case 21:
          a.b(parama, paramy, k);
          parama = a2;
          paramy.d(m);
          return (com.applovin.exoplayer2.i.a)parama;
        case 20:
          break;
      } 
      a.a(parama, paramy, k);
      parama = a2;
    } else {
      com.applovin.exoplayer2.i.a a3 = parama.a();
      parama.b();
      a1 = a3;
    } 
    paramy.d(m);
    return a1;
  }
  
  private void a(y paramy) {
    if (paramy.a() > 0 && paramy.f() == 120) {
      if (this.d == null)
        this.d = new Inflater(); 
      if (ai.a(paramy, this.b, this.d))
        paramy.a(this.b.d(), this.b.b()); 
    } 
  }
  
  protected f a(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) throws h {
    this.a.a(paramArrayOfbyte, paramInt);
    a(this.a);
    this.c.b();
    ArrayList<com.applovin.exoplayer2.i.a> arrayList = new ArrayList();
    while (this.a.a() >= 3) {
      com.applovin.exoplayer2.i.a a1 = a(this.a, this.c);
      if (a1 != null)
        arrayList.add(a1); 
    } 
    return new b(Collections.unmodifiableList(arrayList));
  }
  
  private static final class a {
    private final y a = new y();
    
    private final int[] b = new int[256];
    
    private boolean c;
    
    private int d;
    
    private int e;
    
    private int f;
    
    private int g;
    
    private int h;
    
    private int i;
    
    private void a(y param1y, int param1Int) {
      if (param1Int % 5 != 2)
        return; 
      param1y.e(2);
      Arrays.fill(this.b, 0);
      int i = param1Int / 5;
      for (param1Int = 0; param1Int < i; param1Int++) {
        int j = param1y.h();
        int n = param1y.h();
        int i1 = param1y.h();
        int m = param1y.h();
        int k = param1y.h();
        double d1 = n;
        double d2 = (i1 - 128);
        n = (int)(1.402D * d2 + d1);
        double d3 = (m - 128);
        i1 = (int)(d1 - 0.34414D * d3 - d2 * 0.71414D);
        m = (int)(d1 + d3 * 1.772D);
        int[] arrayOfInt = this.b;
        n = ai.a(n, 0, 255);
        i1 = ai.a(i1, 0, 255);
        arrayOfInt[j] = ai.a(m, 0, 255) | i1 << 8 | k << 24 | n << 16;
      } 
      this.c = true;
    }
    
    private void b(y param1y, int param1Int) {
      if (param1Int < 4)
        return; 
      param1y.e(3);
      if ((param1y.h() & 0x80) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      int j = param1Int - 4;
      param1Int = j;
      if (i) {
        if (j < 7)
          return; 
        param1Int = param1y.m();
        if (param1Int < 4)
          return; 
        this.h = param1y.i();
        this.i = param1y.i();
        this.a.a(param1Int - 4);
        param1Int = j - 7;
      } 
      int i = this.a.c();
      j = this.a.b();
      if (i < j && param1Int > 0) {
        param1Int = Math.min(param1Int, j - i);
        param1y.a(this.a.d(), i, param1Int);
        this.a.d(i + param1Int);
      } 
    }
    
    private void c(y param1y, int param1Int) {
      if (param1Int < 19)
        return; 
      this.d = param1y.i();
      this.e = param1y.i();
      param1y.e(11);
      this.f = param1y.i();
      this.g = param1y.i();
    }
    
    @Nullable
    public com.applovin.exoplayer2.i.a a() {
      if (this.d == 0 || this.e == 0 || this.h == 0 || this.i == 0 || this.a.b() == 0 || this.a.c() != this.a.b() || !this.c)
        return null; 
      this.a.d(0);
      int[] arrayOfInt = new int[this.h * this.i];
      int i = 0;
      while (i < arrayOfInt.length) {
        int j = this.a.h();
        if (j != 0) {
          int k = i + 1;
          arrayOfInt[i] = this.b[j];
          i = k;
          continue;
        } 
        j = this.a.h();
        if (j != 0) {
          int k;
          if ((j & 0x40) == 0) {
            k = j & 0x3F;
          } else {
            k = (j & 0x3F) << 8 | this.a.h();
          } 
          if ((j & 0x80) == 0) {
            j = 0;
          } else {
            j = this.b[this.a.h()];
          } 
          k += i;
          Arrays.fill(arrayOfInt, i, k, j);
          i = k;
        } 
      } 
      Bitmap bitmap = Bitmap.createBitmap(arrayOfInt, this.h, this.i, Bitmap.Config.ARGB_8888);
      return (new com.applovin.exoplayer2.i.a.a()).a(bitmap).a(this.f / this.d).b(0).a(this.g / this.e, 0).a(0).b(this.h / this.d).c(this.i / this.e).e();
    }
    
    public void b() {
      this.d = 0;
      this.e = 0;
      this.f = 0;
      this.g = 0;
      this.h = 0;
      this.i = 0;
      this.a.a(0);
      this.c = false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\i\c\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */