package com.applovin.exoplayer2.i.a;

import android.text.Layout;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.c.f;
import com.applovin.exoplayer2.i.f;
import com.applovin.exoplayer2.i.h;
import com.applovin.exoplayer2.i.j;
import com.applovin.exoplayer2.i.k;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.y;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class a extends c {
  private static final int[] a = new int[] { 11, 1, 3, 12, 14, 5, 7, 9 };
  
  private static final int[] b = new int[] { 0, 4, 8, 12, 16, 20, 24, 28 };
  
  private static final int[] c = new int[] { -1, -16711936, -16776961, -16711681, -65536, -256, -65281 };
  
  private static final int[] d = new int[] { 
      32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 
      225, 43, 44, 45, 46, 47, 48, 49, 50, 51, 
      52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 
      62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 
      72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 
      82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 
      233, 93, 237, 243, 250, 97, 98, 99, 100, 101, 
      102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 
      112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 
      122, 231, 247, 209, 241, 9632 };
  
  private static final int[] e = new int[] { 
      174, 176, 189, 191, 8482, 162, 163, 9834, 224, 32, 
      232, 226, 234, 238, 244, 251 };
  
  private static final int[] f = new int[] { 
      193, 201, 211, 218, 220, 252, 8216, 161, 42, 39, 
      8212, 169, 8480, 8226, 8220, 8221, 192, 194, 199, 200, 
      202, 203, 235, 206, 207, 239, 212, 217, 249, 219, 
      171, 187 };
  
  private static final int[] g = new int[] { 
      195, 227, 205, 204, 236, 210, 242, 213, 245, 123, 
      125, 92, 94, 95, 124, 126, 196, 228, 214, 246, 
      223, 165, 164, 9474, 197, 229, 216, 248, 9484, 9488, 
      9492, 9496 };
  
  private static final boolean[] h = new boolean[] { 
      false, true, true, false, true, false, false, true, true, false, 
      false, true, false, true, true, false, true, false, false, true, 
      false, true, true, false, false, true, true, false, true, false, 
      false, true, true, false, false, true, false, true, true, false, 
      false, true, true, false, true, false, false, true, false, true, 
      true, false, true, false, false, true, true, false, false, true, 
      false, true, true, false, true, false, false, true, false, true, 
      true, false, false, true, true, false, true, false, false, true, 
      false, true, true, false, true, false, false, true, true, false, 
      false, true, false, true, true, false, false, true, true, false, 
      true, false, false, true, true, false, false, true, false, true, 
      true, false, true, false, false, true, false, true, true, false, 
      false, true, true, false, true, false, false, true, true, false, 
      false, true, false, true, true, false, false, true, true, false, 
      true, false, false, true, false, true, true, false, true, false, 
      false, true, true, false, false, true, false, true, true, false, 
      false, true, true, false, true, false, false, true, true, false, 
      false, true, false, true, true, false, true, false, false, true, 
      false, true, true, false, false, true, true, false, true, false, 
      false, true, false, true, true, false, true, false, false, true, 
      true, false, false, true, false, true, true, false, true, false, 
      false, true, false, true, true, false, false, true, true, false, 
      true, false, false, true, true, false, false, true, false, true, 
      true, false, false, true, true, false, true, false, false, true, 
      false, true, true, false, true, false, false, true, true, false, 
      false, true, false, true, true, false };
  
  private final y i;
  
  private final int j;
  
  private final int k;
  
  private final int l;
  
  private final long m;
  
  private final ArrayList<a> n;
  
  private a o;
  
  @Nullable
  private List<com.applovin.exoplayer2.i.a> p;
  
  @Nullable
  private List<com.applovin.exoplayer2.i.a> q;
  
  private int r;
  
  private int s;
  
  private boolean t;
  
  private boolean u;
  
  private byte v;
  
  private byte w;
  
  private int x;
  
  private boolean y;
  
  private long z;
  
  public a(String paramString, int paramInt, long paramLong) {
    byte b;
    this.i = new y();
    this.n = new ArrayList<a>();
    this.o = new a(0, 4);
    this.x = 0;
    if (paramLong > 0L) {
      paramLong *= 1000L;
    } else {
      paramLong = -9223372036854775807L;
    } 
    this.m = paramLong;
    if ("application/x-mp4-cea-608".equals(paramString)) {
      b = 2;
    } else {
      b = 3;
    } 
    this.j = b;
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 3) {
          if (paramInt != 4) {
            q.c("Cea608Decoder", "Invalid channel. Defaulting to CC1.");
            this.l = 0;
            this.k = 0;
          } else {
            this.l = 1;
            this.k = 1;
          } 
        } else {
          this.l = 0;
          this.k = 1;
        } 
      } else {
        this.l = 1;
        this.k = 0;
      } 
    } else {
      this.l = 0;
      this.k = 0;
    } 
    a(0);
    m();
    this.y = true;
    this.z = -9223372036854775807L;
  }
  
  private void a(byte paramByte1, byte paramByte2) {
    int i;
    int k = a[paramByte1 & 0x7];
    boolean bool = false;
    if ((paramByte2 & 0x20) != 0) {
      paramByte1 = 1;
    } else {
      paramByte1 = 0;
    } 
    int j = k;
    if (paramByte1 != 0)
      j = k + 1; 
    if (j != a.a(this.o)) {
      if (this.r != 1 && !this.o.a()) {
        this.o = new a(this.r, this.s);
        this.n.add(this.o);
      } 
      a.b(this.o, j);
    } 
    if ((paramByte2 & 0x10) == 16) {
      paramByte1 = 1;
    } else {
      paramByte1 = 0;
    } 
    if ((paramByte2 & 0x1) == 1)
      bool = true; 
    j = paramByte2 >> 1 & 0x7;
    a a1 = this.o;
    if (paramByte1 != 0) {
      paramByte2 = 8;
    } else {
      i = j;
    } 
    a1.a(i, bool);
    if (paramByte1 != 0)
      a.c(this.o, b[j]); 
  }
  
  private void a(int paramInt) {
    int i = this.r;
    if (i == paramInt)
      return; 
    this.r = paramInt;
    if (paramInt == 3) {
      for (i = 0; i < this.n.size(); i++)
        ((a)this.n.get(i)).b(paramInt); 
      return;
    } 
    m();
    if (i == 3 || paramInt == 1 || paramInt == 0)
      this.p = Collections.emptyList(); 
  }
  
  private boolean a(byte paramByte) {
    if (h(paramByte))
      this.x = i(paramByte); 
    return (this.x == this.l);
  }
  
  private boolean a(boolean paramBoolean, byte paramByte1, byte paramByte2) {
    if (paramBoolean && j(paramByte1)) {
      if (this.u && this.v == paramByte1 && this.w == paramByte2) {
        this.u = false;
        return true;
      } 
      this.u = true;
      this.v = paramByte1;
      this.w = paramByte2;
      return false;
    } 
    this.u = false;
    return false;
  }
  
  private void b(byte paramByte) {
    boolean bool;
    this.o.a(' ');
    if ((paramByte & 0x1) == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    this.o.a(paramByte >> 1 & 0x7, bool);
  }
  
  private void b(byte paramByte1, byte paramByte2) {
    if (k(paramByte1)) {
      this.y = false;
      return;
    } 
    if (l(paramByte1)) {
      if (paramByte2 != 32 && paramByte2 != 47)
        switch (paramByte2) {
          default:
            switch (paramByte2) {
              default:
                return;
              case 42:
              case 43:
                this.y = false;
                return;
              case 41:
                break;
            } 
            break;
          case 37:
          case 38:
          case 39:
            break;
        }  
      this.y = true;
    } 
  }
  
  private void b(int paramInt) {
    this.s = paramInt;
    this.o.c(paramInt);
  }
  
  private void c(byte paramByte) {
    if (paramByte != 32) {
      if (paramByte != 41) {
        int i;
        switch (paramByte) {
          default:
            i = this.r;
            if (i == 0)
              return; 
            if (paramByte != 33) {
              if (paramByte != 36) {
                switch (paramByte) {
                  default:
                    return;
                  case 47:
                    this.p = l();
                    m();
                    return;
                  case 46:
                    m();
                    return;
                  case 45:
                    if (i == 1 && !this.o.a()) {
                      this.o.c();
                      return;
                    } 
                    return;
                  case 44:
                    break;
                } 
                this.p = Collections.emptyList();
                int j = this.r;
                if (j == 1 || j == 3) {
                  m();
                  return;
                } 
              } 
            } else {
              this.o.b();
            } 
            return;
          case 39:
            a(1);
            b(4);
            return;
          case 38:
            a(1);
            b(3);
            return;
          case 37:
            break;
        } 
        a(1);
        b(2);
        return;
      } 
      a(3);
      return;
    } 
    a(2);
  }
  
  private static boolean c(byte paramByte1, byte paramByte2) {
    return ((paramByte1 & 0xF7) == 17 && (paramByte2 & 0xF0) == 48);
  }
  
  private static char d(byte paramByte) {
    return (char)d[(paramByte & Byte.MAX_VALUE) - 32];
  }
  
  private static boolean d(byte paramByte1, byte paramByte2) {
    return ((paramByte1 & 0xF6) == 18 && (paramByte2 & 0xE0) == 32);
  }
  
  private static char e(byte paramByte) {
    return (char)e[paramByte & 0xF];
  }
  
  private static char e(byte paramByte1, byte paramByte2) {
    return ((paramByte1 & 0x1) == 0) ? f(paramByte2) : g(paramByte2);
  }
  
  private static char f(byte paramByte) {
    return (char)f[paramByte & 0x1F];
  }
  
  private static boolean f(byte paramByte1, byte paramByte2) {
    return ((paramByte1 & 0xF7) == 17 && (paramByte2 & 0xF0) == 32);
  }
  
  private static char g(byte paramByte) {
    return (char)g[paramByte & 0x1F];
  }
  
  private static boolean g(byte paramByte1, byte paramByte2) {
    return ((paramByte1 & 0xF0) == 16 && (paramByte2 & 0xC0) == 64);
  }
  
  private static boolean h(byte paramByte) {
    return ((paramByte & 0xE0) == 0);
  }
  
  private static boolean h(byte paramByte1, byte paramByte2) {
    return ((paramByte1 & 0xF7) == 23 && paramByte2 >= 33 && paramByte2 <= 35);
  }
  
  private static int i(byte paramByte) {
    return paramByte >> 3 & 0x1;
  }
  
  private static boolean i(byte paramByte1, byte paramByte2) {
    return ((paramByte1 & 0xF6) == 20 && (paramByte2 & 0xF0) == 32);
  }
  
  private static boolean j(byte paramByte) {
    return ((paramByte & 0xF0) == 16);
  }
  
  private static boolean k(byte paramByte) {
    return (1 <= paramByte && paramByte <= 15);
  }
  
  private List<com.applovin.exoplayer2.i.a> l() {
    int k = this.n.size();
    ArrayList<com.applovin.exoplayer2.i.a> arrayList1 = new ArrayList(k);
    boolean bool = false;
    int j = 0;
    int i;
    for (i = 2; j < k; i = m) {
      com.applovin.exoplayer2.i.a a1 = ((a)this.n.get(j)).d(-2147483648);
      arrayList1.add(a1);
      int m = i;
      if (a1 != null)
        m = Math.min(i, a1.j); 
      j++;
    } 
    ArrayList<com.applovin.exoplayer2.i.a> arrayList2 = new ArrayList(k);
    for (j = bool; j < k; j++) {
      com.applovin.exoplayer2.i.a a1 = arrayList1.get(j);
      if (a1 != null) {
        com.applovin.exoplayer2.i.a a2 = a1;
        if (a1.j != i)
          a2 = (com.applovin.exoplayer2.i.a)com.applovin.exoplayer2.l.a.b(((a)this.n.get(j)).d(i)); 
        arrayList2.add(a2);
      } 
    } 
    return arrayList2;
  }
  
  private static boolean l(byte paramByte) {
    return ((paramByte & 0xF7) == 20);
  }
  
  private void m() {
    this.o.a(this.r);
    this.n.clear();
    this.n.add(this.o);
  }
  
  private boolean n() {
    long l = this.m;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (l != -9223372036854775807L) {
      if (this.z == -9223372036854775807L)
        return false; 
      bool1 = bool2;
      if (k() - this.z >= this.m)
        bool1 = true; 
    } 
    return bool1;
  }
  
  protected void a(j paramj) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Ljava/nio/ByteBuffer;
    //   4: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   7: checkcast java/nio/ByteBuffer
    //   10: astore_1
    //   11: aload_0
    //   12: getfield i : Lcom/applovin/exoplayer2/l/y;
    //   15: aload_1
    //   16: invokevirtual array : ()[B
    //   19: aload_1
    //   20: invokevirtual limit : ()I
    //   23: invokevirtual a : ([BI)V
    //   26: iconst_0
    //   27: istore #4
    //   29: aload_0
    //   30: getfield i : Lcom/applovin/exoplayer2/l/y;
    //   33: invokevirtual a : ()I
    //   36: istore #5
    //   38: aload_0
    //   39: getfield j : I
    //   42: istore #6
    //   44: iload #5
    //   46: iload #6
    //   48: if_icmplt -> 417
    //   51: iload #6
    //   53: iconst_2
    //   54: if_icmpne -> 64
    //   57: bipush #-4
    //   59: istore #5
    //   61: goto -> 74
    //   64: aload_0
    //   65: getfield i : Lcom/applovin/exoplayer2/l/y;
    //   68: invokevirtual h : ()I
    //   71: i2b
    //   72: istore #5
    //   74: aload_0
    //   75: getfield i : Lcom/applovin/exoplayer2/l/y;
    //   78: invokevirtual h : ()I
    //   81: istore #6
    //   83: aload_0
    //   84: getfield i : Lcom/applovin/exoplayer2/l/y;
    //   87: invokevirtual h : ()I
    //   90: istore #7
    //   92: iload #5
    //   94: iconst_2
    //   95: iand
    //   96: ifeq -> 102
    //   99: goto -> 29
    //   102: iload #5
    //   104: iconst_1
    //   105: iand
    //   106: aload_0
    //   107: getfield k : I
    //   110: if_icmpeq -> 116
    //   113: goto -> 29
    //   116: iload #6
    //   118: bipush #127
    //   120: iand
    //   121: i2b
    //   122: istore_2
    //   123: iload #7
    //   125: bipush #127
    //   127: iand
    //   128: i2b
    //   129: istore_3
    //   130: iload_2
    //   131: ifne -> 141
    //   134: iload_3
    //   135: ifne -> 141
    //   138: goto -> 29
    //   141: aload_0
    //   142: getfield t : Z
    //   145: istore #9
    //   147: iload #5
    //   149: iconst_4
    //   150: iand
    //   151: iconst_4
    //   152: if_icmpne -> 179
    //   155: getstatic com/applovin/exoplayer2/i/a/a.h : [Z
    //   158: astore_1
    //   159: aload_1
    //   160: iload #6
    //   162: baload
    //   163: ifeq -> 179
    //   166: aload_1
    //   167: iload #7
    //   169: baload
    //   170: ifeq -> 179
    //   173: iconst_1
    //   174: istore #8
    //   176: goto -> 182
    //   179: iconst_0
    //   180: istore #8
    //   182: aload_0
    //   183: iload #8
    //   185: putfield t : Z
    //   188: aload_0
    //   189: aload_0
    //   190: getfield t : Z
    //   193: iload_2
    //   194: iload_3
    //   195: invokespecial a : (ZBB)Z
    //   198: ifeq -> 204
    //   201: goto -> 29
    //   204: aload_0
    //   205: getfield t : Z
    //   208: ifne -> 226
    //   211: iload #9
    //   213: ifeq -> 29
    //   216: aload_0
    //   217: invokespecial m : ()V
    //   220: iconst_1
    //   221: istore #4
    //   223: goto -> 29
    //   226: aload_0
    //   227: iload_2
    //   228: iload_3
    //   229: invokespecial b : (BB)V
    //   232: aload_0
    //   233: getfield y : Z
    //   236: ifne -> 242
    //   239: goto -> 29
    //   242: aload_0
    //   243: iload_2
    //   244: invokespecial a : (B)Z
    //   247: ifne -> 253
    //   250: goto -> 29
    //   253: iload_2
    //   254: invokestatic h : (B)Z
    //   257: ifeq -> 384
    //   260: iload_2
    //   261: iload_3
    //   262: invokestatic c : (BB)Z
    //   265: ifeq -> 282
    //   268: aload_0
    //   269: getfield o : Lcom/applovin/exoplayer2/i/a/a$a;
    //   272: iload_3
    //   273: invokestatic e : (B)C
    //   276: invokevirtual a : (C)V
    //   279: goto -> 220
    //   282: iload_2
    //   283: iload_3
    //   284: invokestatic d : (BB)Z
    //   287: ifeq -> 312
    //   290: aload_0
    //   291: getfield o : Lcom/applovin/exoplayer2/i/a/a$a;
    //   294: invokevirtual b : ()V
    //   297: aload_0
    //   298: getfield o : Lcom/applovin/exoplayer2/i/a/a$a;
    //   301: iload_2
    //   302: iload_3
    //   303: invokestatic e : (BB)C
    //   306: invokevirtual a : (C)V
    //   309: goto -> 220
    //   312: iload_2
    //   313: iload_3
    //   314: invokestatic f : (BB)Z
    //   317: ifeq -> 328
    //   320: aload_0
    //   321: iload_3
    //   322: invokespecial b : (B)V
    //   325: goto -> 220
    //   328: iload_2
    //   329: iload_3
    //   330: invokestatic g : (BB)Z
    //   333: ifeq -> 345
    //   336: aload_0
    //   337: iload_2
    //   338: iload_3
    //   339: invokespecial a : (BB)V
    //   342: goto -> 220
    //   345: iload_2
    //   346: iload_3
    //   347: invokestatic h : (BB)Z
    //   350: ifeq -> 368
    //   353: aload_0
    //   354: getfield o : Lcom/applovin/exoplayer2/i/a/a$a;
    //   357: iload_3
    //   358: bipush #32
    //   360: isub
    //   361: invokestatic a : (Lcom/applovin/exoplayer2/i/a/a$a;I)I
    //   364: pop
    //   365: goto -> 220
    //   368: iload_2
    //   369: iload_3
    //   370: invokestatic i : (BB)Z
    //   373: ifeq -> 220
    //   376: aload_0
    //   377: iload_3
    //   378: invokespecial c : (B)V
    //   381: goto -> 220
    //   384: aload_0
    //   385: getfield o : Lcom/applovin/exoplayer2/i/a/a$a;
    //   388: iload_2
    //   389: invokestatic d : (B)C
    //   392: invokevirtual a : (C)V
    //   395: iload_3
    //   396: sipush #224
    //   399: iand
    //   400: ifeq -> 220
    //   403: aload_0
    //   404: getfield o : Lcom/applovin/exoplayer2/i/a/a$a;
    //   407: iload_3
    //   408: invokestatic d : (B)C
    //   411: invokevirtual a : (C)V
    //   414: goto -> 220
    //   417: iload #4
    //   419: ifeq -> 456
    //   422: aload_0
    //   423: getfield r : I
    //   426: istore #4
    //   428: iload #4
    //   430: iconst_1
    //   431: if_icmpeq -> 440
    //   434: iload #4
    //   436: iconst_3
    //   437: if_icmpne -> 456
    //   440: aload_0
    //   441: aload_0
    //   442: invokespecial l : ()Ljava/util/List;
    //   445: putfield p : Ljava/util/List;
    //   448: aload_0
    //   449: aload_0
    //   450: invokevirtual k : ()J
    //   453: putfield z : J
    //   456: return
  }
  
  public void c() {
    super.c();
    this.p = null;
    this.q = null;
    a(0);
    b(4);
    m();
    this.t = false;
    this.u = false;
    this.v = 0;
    this.w = 0;
    this.x = 0;
    this.y = true;
    this.z = -9223372036854775807L;
  }
  
  public void d() {}
  
  @Nullable
  public k e() throws h {
    k k = super.e();
    if (k != null)
      return k; 
    if (n()) {
      k = j();
      if (k != null) {
        this.p = Collections.emptyList();
        this.z = -9223372036854775807L;
        f f = g();
        k.a(k(), f, Long.MAX_VALUE);
        return k;
      } 
    } 
    return null;
  }
  
  protected boolean f() {
    return (this.p != this.q);
  }
  
  protected f g() {
    List<com.applovin.exoplayer2.i.a> list = this.p;
    this.q = list;
    return new d((List<com.applovin.exoplayer2.i.a>)com.applovin.exoplayer2.l.a.b(list));
  }
  
  private static final class a {
    private final List<a> a = new ArrayList<a>();
    
    private final List<SpannableString> b = new ArrayList<SpannableString>();
    
    private final StringBuilder c = new StringBuilder();
    
    private int d;
    
    private int e;
    
    private int f;
    
    private int g;
    
    private int h;
    
    public a(int param1Int1, int param1Int2) {
      a(param1Int1);
      this.h = param1Int2;
    }
    
    private static void a(SpannableStringBuilder param1SpannableStringBuilder, int param1Int1, int param1Int2) {
      param1SpannableStringBuilder.setSpan(new UnderlineSpan(), param1Int1, param1Int2, 33);
    }
    
    private static void a(SpannableStringBuilder param1SpannableStringBuilder, int param1Int1, int param1Int2, int param1Int3) {
      if (param1Int3 == -1)
        return; 
      param1SpannableStringBuilder.setSpan(new ForegroundColorSpan(param1Int3), param1Int1, param1Int2, 33);
    }
    
    private static void b(SpannableStringBuilder param1SpannableStringBuilder, int param1Int1, int param1Int2) {
      param1SpannableStringBuilder.setSpan(new StyleSpan(2), param1Int1, param1Int2, 33);
    }
    
    private SpannableString d() {
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(this.c);
      int i3 = spannableStringBuilder.length();
      int i1 = 0;
      int n = -1;
      int m = -1;
      int j = 0;
      int k = -1;
      int i = -1;
      int i2 = 0;
      while (i1 < this.a.size()) {
        int i6;
        int i7;
        a a1 = this.a.get(i1);
        boolean bool = a1.b;
        int i5 = a1.a;
        int i4 = i;
        int i8 = i2;
        if (i5 != 8) {
          if (i5 == 7) {
            i4 = 1;
          } else {
            i4 = 0;
          } 
          if (i5 != 7)
            i = a.i()[i5]; 
          i8 = i4;
          i4 = i;
        } 
        i5 = a1.c;
        int i9 = i1 + 1;
        if (i9 < this.a.size()) {
          i = ((a)this.a.get(i9)).c;
        } else {
          i = i3;
        } 
        if (i5 == i) {
          i1 = i9;
          i = i4;
          i2 = i8;
          continue;
        } 
        if (n != -1 && !bool) {
          a(spannableStringBuilder, n, i5);
          i6 = -1;
        } else {
          i6 = n;
          if (n == -1) {
            i6 = n;
            if (bool)
              i6 = i5; 
          } 
        } 
        if (m != -1 && i8 == 0) {
          b(spannableStringBuilder, m, i5);
          i7 = -1;
        } else {
          i7 = m;
          if (m == -1) {
            i7 = m;
            if (i8 != 0)
              i7 = i5; 
          } 
        } 
        i1 = i9;
        n = i6;
        m = i7;
        i = i4;
        i2 = i8;
        if (i4 != k) {
          a(spannableStringBuilder, j, i5, k);
          k = i4;
          i1 = i9;
          n = i6;
          m = i7;
          j = i5;
          i = i4;
          i2 = i8;
        } 
      } 
      if (n != -1 && n != i3)
        a(spannableStringBuilder, n, i3); 
      if (m != -1 && m != i3)
        b(spannableStringBuilder, m, i3); 
      if (j != i3)
        a(spannableStringBuilder, j, i3, k); 
      return new SpannableString((CharSequence)spannableStringBuilder);
    }
    
    public void a(char param1Char) {
      if (this.c.length() < 32)
        this.c.append(param1Char); 
    }
    
    public void a(int param1Int) {
      this.g = param1Int;
      this.a.clear();
      this.b.clear();
      this.c.setLength(0);
      this.d = 15;
      this.e = 0;
      this.f = 0;
    }
    
    public void a(int param1Int, boolean param1Boolean) {
      this.a.add(new a(param1Int, param1Boolean, this.c.length()));
    }
    
    public boolean a() {
      return (this.a.isEmpty() && this.b.isEmpty() && this.c.length() == 0);
    }
    
    public void b() {
      int i = this.c.length();
      if (i > 0) {
        this.c.delete(i - 1, i);
        int j = this.a.size() - 1;
        while (j >= 0) {
          a a1 = this.a.get(j);
          if (a1.c == i) {
            a1.c--;
            j--;
          } 
        } 
      } 
    }
    
    public void b(int param1Int) {
      this.g = param1Int;
    }
    
    public void c() {
      this.b.add(d());
      this.c.setLength(0);
      this.a.clear();
      int i = Math.min(this.h, this.d);
      while (this.b.size() >= i)
        this.b.remove(0); 
    }
    
    public void c(int param1Int) {
      this.h = param1Int;
    }
    
    @Nullable
    public com.applovin.exoplayer2.i.a d(int param1Int) {
      float f;
      int j = this.e + this.f;
      int k = 32 - j;
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
      int i;
      for (i = 0; i < this.b.size(); i++) {
        spannableStringBuilder.append(ai.a((CharSequence)this.b.get(i), k));
        spannableStringBuilder.append('\n');
      } 
      spannableStringBuilder.append(ai.a((CharSequence)d(), k));
      if (spannableStringBuilder.length() == 0)
        return null; 
      i = k - spannableStringBuilder.length();
      k = j - i;
      if (param1Int == Integer.MIN_VALUE)
        if (this.g == 2 && (Math.abs(k) < 3 || i < 0)) {
          param1Int = 1;
        } else if (this.g == 2 && k > 0) {
          param1Int = 2;
        } else {
          param1Int = 0;
        }  
      if (param1Int != 1) {
        if (param1Int != 2) {
          i = j;
        } else {
          i = 32 - i;
        } 
        f = i / 32.0F * 0.8F + 0.1F;
      } else {
        f = 0.5F;
      } 
      j = this.d;
      if (j > 7) {
        i = j - 15 - 2;
      } else {
        i = j;
        if (this.g == 1)
          i = j - this.h - 1; 
      } 
      return (new com.applovin.exoplayer2.i.a.a()).a((CharSequence)spannableStringBuilder).a(Layout.Alignment.ALIGN_NORMAL).a(i, 1).a(f).b(param1Int).e();
    }
    
    private static class a {
      public final int a;
      
      public final boolean b;
      
      public int c;
      
      public a(int param2Int1, boolean param2Boolean, int param2Int2) {
        this.a = param2Int1;
        this.b = param2Boolean;
        this.c = param2Int2;
      }
    }
  }
  
  private static class a {
    public final int a;
    
    public final boolean b;
    
    public int c;
    
    public a(int param1Int1, boolean param1Boolean, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Boolean;
      this.c = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\i\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */