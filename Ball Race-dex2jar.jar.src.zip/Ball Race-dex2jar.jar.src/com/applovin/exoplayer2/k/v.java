package com.applovin.exoplayer2.k;

import com.applovin.exoplayer2.h.j;
import com.applovin.exoplayer2.h.m;
import java.io.IOException;

public interface v {
  int a(int paramInt);
  
  long a(a parama);
  
  void a(long paramLong);
  
  public static final class a {
    public final j a;
    
    public final m b;
    
    public final IOException c;
    
    public final int d;
    
    public a(j param1j, m param1m, IOException param1IOException, int param1Int) {
      this.a = param1j;
      this.b = param1m;
      this.c = param1IOException;
      this.d = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\k\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */