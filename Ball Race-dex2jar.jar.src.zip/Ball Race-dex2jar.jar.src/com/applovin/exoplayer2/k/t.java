package com.applovin.exoplayer2.k;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.common.base.Ascii;
import com.applovin.exoplayer2.common.base.Predicate;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface t extends i {
  public static final Predicate<String> a = -$$Lambda$t$H1UlgP-nTKRt6qV1j43DU5tw7_I.INSTANCE;
  
  public static final class a extends c {
    public a(IOException param1IOException, l param1l) {
      super("Cleartext HTTP traffic not permitted. See https://exoplayer.dev/issues/cleartext-not-permitted", param1IOException, param1l, 2007, 1);
    }
  }
  
  public static interface b extends i.a {
    t c();
  }
  
  public static class c extends j {
    public final l b;
    
    public final int c;
    
    public c(l param1l, int param1Int1, int param1Int2) {
      super(a(param1Int1, param1Int2));
      this.b = param1l;
      this.c = param1Int2;
    }
    
    public c(IOException param1IOException, l param1l, int param1Int1, int param1Int2) {
      super(param1IOException, a(param1Int1, param1Int2));
      this.b = param1l;
      this.c = param1Int2;
    }
    
    public c(String param1String, l param1l, int param1Int1, int param1Int2) {
      super(param1String, a(param1Int1, param1Int2));
      this.b = param1l;
      this.c = param1Int2;
    }
    
    public c(String param1String, @Nullable IOException param1IOException, l param1l, int param1Int1, int param1Int2) {
      super(param1String, param1IOException, a(param1Int1, param1Int2));
      this.b = param1l;
      this.c = param1Int2;
    }
    
    private static int a(int param1Int1, int param1Int2) {
      int i = param1Int1;
      if (param1Int1 == 2000) {
        i = param1Int1;
        if (param1Int2 == 1)
          i = 2001; 
      } 
      return i;
    }
    
    public static c a(IOException param1IOException, l param1l, int param1Int) {
      char c1;
      String str = param1IOException.getMessage();
      if (param1IOException instanceof java.net.SocketTimeoutException) {
        c1 = 'ߒ';
      } else if (param1IOException instanceof java.io.InterruptedIOException) {
        c1 = 'Ϭ';
      } else if (str != null && Ascii.toLowerCase(str).matches("cleartext.*not permitted.*")) {
        c1 = 'ߗ';
      } else {
        c1 = 'ߑ';
      } 
      return (c1 == 'ߗ') ? new t.a(param1IOException, param1l) : new c(param1IOException, param1l, c1, param1Int);
    }
  }
  
  public static final class d extends c {
    public final String d;
    
    public d(String param1String, l param1l) {
      super(stringBuilder.toString(), param1l, 2003, 1);
      this.d = param1String;
    }
  }
  
  public static final class e extends c {
    public final int d;
    
    @Nullable
    public final String e;
    
    public final Map<String, List<String>> f;
    
    public final byte[] g;
    
    public e(int param1Int, @Nullable String param1String, @Nullable IOException param1IOException, Map<String, List<String>> param1Map, l param1l, byte[] param1ArrayOfbyte) {
      super(stringBuilder.toString(), param1IOException, param1l, 2004, 1);
      this.d = param1Int;
      this.e = param1String;
      this.f = param1Map;
      this.g = param1ArrayOfbyte;
    }
  }
  
  public static final class f {
    private final Map<String, String> a = new HashMap<String, String>();
    
    @Nullable
    private Map<String, String> b;
    
    public Map<String, String> a() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield b : Ljava/util/Map;
      //   6: ifnonnull -> 27
      //   9: aload_0
      //   10: new java/util/HashMap
      //   13: dup
      //   14: aload_0
      //   15: getfield a : Ljava/util/Map;
      //   18: invokespecial <init> : (Ljava/util/Map;)V
      //   21: invokestatic unmodifiableMap : (Ljava/util/Map;)Ljava/util/Map;
      //   24: putfield b : Ljava/util/Map;
      //   27: aload_0
      //   28: getfield b : Ljava/util/Map;
      //   31: astore_1
      //   32: aload_0
      //   33: monitorexit
      //   34: aload_1
      //   35: areturn
      //   36: astore_1
      //   37: aload_0
      //   38: monitorexit
      //   39: aload_1
      //   40: athrow
      // Exception table:
      //   from	to	target	type
      //   2	27	36	finally
      //   27	32	36	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\k\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */