package com.applovin.exoplayer2.k;

import android.net.Uri;
import androidx.annotation.Nullable;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface i extends g {
  long a(l paraml) throws IOException;
  
  @Nullable
  Uri a();
  
  void a(aa paramaa);
  
  Map<String, List<String>> b();
  
  void c() throws IOException;
  
  public static interface a {
    i a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\k\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */