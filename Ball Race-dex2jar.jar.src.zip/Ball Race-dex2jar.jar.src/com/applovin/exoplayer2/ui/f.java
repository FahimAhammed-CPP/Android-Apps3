package com.applovin.exoplayer2.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import com.applovin.exoplayer2.ab;
import com.applovin.exoplayer2.ac;
import com.applovin.exoplayer2.ak;
import com.applovin.exoplayer2.am;
import com.applovin.exoplayer2.an;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.h;
import com.applovin.exoplayer2.h.ad;
import com.applovin.exoplayer2.i;
import com.applovin.exoplayer2.j;
import com.applovin.exoplayer2.j.h;
import com.applovin.exoplayer2.l.ab;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.m.o;
import com.applovin.exoplayer2.o;
import com.applovin.exoplayer2.t;
import com.applovin.sdk.R;
import java.util.Arrays;
import java.util.Formatter;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

public class f extends FrameLayout {
  private final Drawable A;
  
  private final Drawable B;
  
  private final float C;
  
  private final float D;
  
  private final String E;
  
  private final String F;
  
  @Nullable
  private an G;
  
  private i H;
  
  @Nullable
  private c I;
  
  private boolean J;
  
  private boolean K;
  
  private boolean L;
  
  private boolean M;
  
  private int N;
  
  private int O;
  
  private int P;
  
  private boolean Q;
  
  private boolean R;
  
  private boolean S;
  
  private boolean T;
  
  private boolean U;
  
  private long V;
  
  private long[] W;
  
  private final b a;
  
  private boolean[] aa;
  
  private long[] ab;
  
  private boolean[] ac;
  
  private long ad;
  
  private long ae;
  
  private long af;
  
  private final CopyOnWriteArrayList<d> b;
  
  @Nullable
  private final View c;
  
  @Nullable
  private final View d;
  
  @Nullable
  private final View e;
  
  @Nullable
  private final View f;
  
  @Nullable
  private final View g;
  
  @Nullable
  private final View h;
  
  @Nullable
  private final ImageView i;
  
  @Nullable
  private final ImageView j;
  
  @Nullable
  private final View k;
  
  @Nullable
  private final TextView l;
  
  @Nullable
  private final TextView m;
  
  @Nullable
  private final k n;
  
  private final StringBuilder o;
  
  private final Formatter p;
  
  private final ba.a q;
  
  private final ba.c r;
  
  private final Runnable s;
  
  private final Runnable t;
  
  private final Drawable u;
  
  private final Drawable v;
  
  private final Drawable w;
  
  private final String x;
  
  private final String y;
  
  private final String z;
  
  static {
    t.a("goog.exo.ui");
  }
  
  public f(Context paramContext, @Nullable AttributeSet paramAttributeSet1, int paramInt, @Nullable AttributeSet paramAttributeSet2) {
    super(paramContext, paramAttributeSet1, paramInt);
    int m = R.layout.applovin_exo_player_control_view;
    this.N = 5000;
    this.P = 0;
    this.O = 200;
    this.V = -9223372036854775807L;
    this.Q = true;
    this.R = true;
    this.S = true;
    this.T = true;
    this.U = false;
    int j = m;
    if (paramAttributeSet2 != null) {
      TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(paramAttributeSet2, R.styleable.AppLovinPlayerControlView, paramInt, 0);
      try {
        this.N = typedArray.getInt(R.styleable.AppLovinPlayerControlView_al_show_timeout, this.N);
        j = typedArray.getResourceId(R.styleable.AppLovinPlayerControlView_al_controller_layout_id, m);
        this.P = a(typedArray, this.P);
        this.Q = typedArray.getBoolean(R.styleable.AppLovinPlayerControlView_al_show_rewind_button, this.Q);
        this.R = typedArray.getBoolean(R.styleable.AppLovinPlayerControlView_al_show_fastforward_button, this.R);
        this.S = typedArray.getBoolean(R.styleable.AppLovinPlayerControlView_al_show_previous_button, this.S);
        this.T = typedArray.getBoolean(R.styleable.AppLovinPlayerControlView_al_show_next_button, this.T);
        this.U = typedArray.getBoolean(R.styleable.AppLovinPlayerControlView_al_show_shuffle_button, this.U);
        setTimeBarMinUpdateInterval(typedArray.getInt(R.styleable.AppLovinPlayerControlView_al_time_bar_min_update_interval, this.O));
      } finally {
        typedArray.recycle();
      } 
    } 
    this.b = new CopyOnWriteArrayList<d>();
    this.q = new ba.a();
    this.r = new ba.c();
    this.o = new StringBuilder();
    this.p = new Formatter(this.o, Locale.getDefault());
    this.W = new long[0];
    this.aa = new boolean[0];
    this.ab = new long[0];
    this.ac = new boolean[0];
    this.a = new b();
    this.H = (i)new j();
    this.s = (Runnable)new -$.Lambda.f.HOUhDgOu5XHOS9rBEb_jr5wCE8g(this);
    this.t = new -$$Lambda$UYas5eXFtG7n_uq6CrQ8KdCtlyI(this);
    LayoutInflater.from(paramContext).inflate(j, (ViewGroup)this);
    setDescendantFocusability(262144);
    k k2 = (k)findViewById(R.id.al_exo_progress);
    View view2 = findViewById(R.id.al_exo_progress_placeholder);
    if (k2 != null) {
      this.n = k2;
    } else if (view2 != null) {
      d d = new d(paramContext, null, 0, paramAttributeSet2);
      d.setId(R.id.al_exo_progress);
      d.setLayoutParams(view2.getLayoutParams());
      ViewGroup viewGroup = (ViewGroup)view2.getParent();
      paramInt = viewGroup.indexOfChild(view2);
      viewGroup.removeView(view2);
      viewGroup.addView((View)d, paramInt);
      this.n = (k)d;
    } else {
      this.n = null;
    } 
    this.l = (TextView)findViewById(R.id.al_exo_duration);
    this.m = (TextView)findViewById(R.id.al_exo_position);
    k k1 = this.n;
    if (k1 != null)
      k1.a(this.a); 
    this.e = findViewById(R.id.al_exo_play);
    View view1 = this.e;
    if (view1 != null)
      view1.setOnClickListener(this.a); 
    this.f = findViewById(R.id.al_exo_pause);
    view1 = this.f;
    if (view1 != null)
      view1.setOnClickListener(this.a); 
    this.c = findViewById(R.id.al_exo_prev);
    view1 = this.c;
    if (view1 != null)
      view1.setOnClickListener(this.a); 
    this.d = findViewById(R.id.al_exo_next);
    view1 = this.d;
    if (view1 != null)
      view1.setOnClickListener(this.a); 
    this.h = findViewById(R.id.al_exo_rew);
    view1 = this.h;
    if (view1 != null)
      view1.setOnClickListener(this.a); 
    this.g = findViewById(R.id.al_exo_ffwd);
    view1 = this.g;
    if (view1 != null)
      view1.setOnClickListener(this.a); 
    this.i = (ImageView)findViewById(R.id.al_exo_repeat_toggle);
    ImageView imageView = this.i;
    if (imageView != null)
      imageView.setOnClickListener(this.a); 
    this.j = (ImageView)findViewById(R.id.al_exo_shuffle);
    imageView = this.j;
    if (imageView != null)
      imageView.setOnClickListener(this.a); 
    this.k = findViewById(R.id.al_exo_vr);
    setShowVrButton(false);
    a(false, false, this.k);
    Resources resources = paramContext.getResources();
    this.C = resources.getInteger(R.integer.al_exo_media_button_opacity_percentage_enabled) / 100.0F;
    this.D = resources.getInteger(R.integer.al_exo_media_button_opacity_percentage_disabled) / 100.0F;
    this.u = resources.getDrawable(R.drawable.al_exo_controls_repeat_off);
    this.v = resources.getDrawable(R.drawable.al_exo_controls_repeat_one);
    this.w = resources.getDrawable(R.drawable.al_exo_controls_repeat_all);
    this.A = resources.getDrawable(R.drawable.al_exo_controls_shuffle_on);
    this.B = resources.getDrawable(R.drawable.al_exo_controls_shuffle_off);
    this.x = resources.getString(R.string.al_exo_controls_repeat_off_description);
    this.y = resources.getString(R.string.al_exo_controls_repeat_one_description);
    this.z = resources.getString(R.string.al_exo_controls_repeat_all_description);
    this.E = resources.getString(R.string.al_exo_controls_shuffle_on_description);
    this.F = resources.getString(R.string.al_exo_controls_shuffle_off_description);
  }
  
  private static int a(TypedArray paramTypedArray, int paramInt) {
    return paramTypedArray.getInt(R.styleable.AppLovinPlayerControlView_al_repeat_toggle_modes, paramInt);
  }
  
  private void a(an paraman) {
    int j = paraman.t();
    if (j == 1 || j == 4 || !paraman.x()) {
      b(paraman);
      return;
    } 
    c(paraman);
  }
  
  private void a(an paraman, long paramLong) {
    int j;
    ba ba = paraman.S();
    if (this.L && !ba.d()) {
      int m = ba.b();
      for (j = 0;; j++) {
        long l = ba.a(j, this.r).c();
        if (paramLong < l)
          break; 
        if (j == m - 1) {
          paramLong = l;
          break;
        } 
        paramLong -= l;
      } 
    } else {
      j = paraman.G();
    } 
    a(paraman, j, paramLong);
    k();
  }
  
  private void a(boolean paramBoolean1, boolean paramBoolean2, @Nullable View paramView) {
    float f1;
    byte b1;
    if (paramView == null)
      return; 
    paramView.setEnabled(paramBoolean2);
    if (paramBoolean2) {
      f1 = this.C;
    } else {
      f1 = this.D;
    } 
    paramView.setAlpha(f1);
    if (paramBoolean1) {
      b1 = 0;
    } else {
      b1 = 8;
    } 
    paramView.setVisibility(b1);
  }
  
  @SuppressLint({"InlinedApi"})
  private static boolean a(int paramInt) {
    return (paramInt == 90 || paramInt == 89 || paramInt == 85 || paramInt == 79 || paramInt == 126 || paramInt == 127 || paramInt == 87 || paramInt == 88);
  }
  
  private boolean a(an paraman, int paramInt, long paramLong) {
    return this.H.a(paraman, paramInt, paramLong);
  }
  
  private static boolean a(ba paramba, ba.c paramc) {
    if (paramba.b() > 100)
      return false; 
    int m = paramba.b();
    for (int j = 0; j < m; j++) {
      if ((paramba.a(j, paramc)).o == -9223372036854775807L)
        return false; 
    } 
    return true;
  }
  
  private void b(an paraman) {
    int j = paraman.t();
    if (j == 1) {
      this.H.a(paraman);
    } else if (j == 4) {
      a(paraman, paraman.G(), -9223372036854775807L);
    } 
    this.H.a(paraman, true);
  }
  
  private void c(an paraman) {
    this.H.a(paraman, false);
  }
  
  private void d() {
    removeCallbacks(this.t);
    if (this.N > 0) {
      long l = SystemClock.uptimeMillis();
      int j = this.N;
      this.V = l + j;
      if (this.J) {
        postDelayed(this.t, j);
        return;
      } 
    } else {
      this.V = -9223372036854775807L;
    } 
  }
  
  private void e() {
    f();
    g();
    h();
    i();
    j();
  }
  
  private void f() {
    if (c()) {
      int j;
      int m;
      if (!this.J)
        return; 
      boolean bool1 = n();
      View view = this.e;
      byte b1 = 8;
      boolean bool = true;
      if (view != null) {
        if (bool1 && view.isFocused()) {
          j = 1;
        } else {
          j = 0;
        } 
        m = j | 0x0;
        if (ai.a < 21) {
          j = m;
        } else if (bool1 && a.a(this.e)) {
          j = 1;
        } else {
          j = 0;
        } 
        int i2 = j | 0x0;
        view = this.e;
        if (bool1) {
          j = 8;
        } else {
          j = 0;
        } 
        view.setVisibility(j);
        j = i2;
      } else {
        m = 0;
        j = 0;
      } 
      view = this.f;
      int n = m;
      int i1 = j;
      if (view != null) {
        if (!bool1 && view.isFocused()) {
          n = 1;
        } else {
          n = 0;
        } 
        n = m | n;
        if (ai.a < 21) {
          m = n;
        } else if (!bool1 && a.a(this.f)) {
          m = bool;
        } else {
          m = 0;
        } 
        i1 = j | m;
        view = this.f;
        j = b1;
        if (bool1)
          j = 0; 
        view.setVisibility(j);
      } 
      if (n != 0)
        l(); 
      if (i1 != 0)
        m(); 
    } 
  }
  
  private void g() {
    if (c()) {
      boolean bool1;
      boolean bool2;
      boolean bool5;
      if (!this.J)
        return; 
      an an1 = this.G;
      boolean bool3 = false;
      boolean bool4 = false;
      if (an1 != null) {
        bool5 = an1.a(4);
        bool3 = an1.a(6);
        if (an1.a(10) && this.H.a()) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        bool2 = bool4;
        if (an1.a(11)) {
          bool2 = bool4;
          if (this.H.b())
            bool2 = true; 
        } 
        bool4 = an1.a(8);
      } else {
        bool2 = false;
        bool4 = false;
        bool5 = false;
        bool1 = false;
      } 
      a(this.S, bool3, this.c);
      a(this.Q, bool1, this.h);
      a(this.R, bool2, this.g);
      a(this.T, bool4, this.d);
      k k1 = this.n;
      if (k1 != null)
        k1.setEnabled(bool5); 
    } 
  }
  
  private void h() {
    if (c() && this.J) {
      ImageView imageView = this.i;
      if (imageView == null)
        return; 
      if (this.P == 0) {
        a(false, false, (View)imageView);
        return;
      } 
      an an1 = this.G;
      if (an1 == null) {
        a(true, false, (View)imageView);
        this.i.setImageDrawable(this.u);
        this.i.setContentDescription(this.x);
        return;
      } 
      a(true, true, (View)imageView);
      int j = an1.y();
      if (j != 0) {
        if (j != 1) {
          if (j == 2) {
            this.i.setImageDrawable(this.w);
            this.i.setContentDescription(this.z);
          } 
        } else {
          this.i.setImageDrawable(this.v);
          this.i.setContentDescription(this.y);
        } 
      } else {
        this.i.setImageDrawable(this.u);
        this.i.setContentDescription(this.x);
      } 
      this.i.setVisibility(0);
    } 
  }
  
  private void i() {
    if (c() && this.J) {
      Drawable drawable;
      String str;
      ImageView imageView1 = this.j;
      if (imageView1 == null)
        return; 
      an an1 = this.G;
      if (!this.U) {
        a(false, false, (View)imageView1);
        return;
      } 
      if (an1 == null) {
        a(true, false, (View)imageView1);
        this.j.setImageDrawable(this.B);
        this.j.setContentDescription(this.F);
        return;
      } 
      a(true, true, (View)imageView1);
      ImageView imageView2 = this.j;
      if (an1.z()) {
        drawable = this.A;
      } else {
        drawable = this.B;
      } 
      imageView2.setImageDrawable(drawable);
      imageView2 = this.j;
      if (an1.z()) {
        str = this.E;
      } else {
        str = this.F;
      } 
      imageView2.setContentDescription(str);
    } 
  }
  
  private void j() {
    byte b1;
    boolean bool;
    an an1 = this.G;
    if (an1 == null)
      return; 
    if (this.K && a(an1.S(), this.r)) {
      bool = true;
    } else {
      bool = false;
    } 
    this.L = bool;
    this.ad = 0L;
    ba ba = an1.S();
    if (!ba.d()) {
      int j;
      int n;
      int m = an1.G();
      if (this.L) {
        j = 0;
      } else {
        j = m;
      } 
      if (this.L) {
        n = ba.b() - 1;
      } else {
        n = m;
      } 
      l = 0L;
      b1 = 0;
      while (j <= n) {
        if (j == m)
          this.ad = h.a(l); 
        ba.a(j, this.r);
        if (this.r.o == -9223372036854775807L) {
          com.applovin.exoplayer2.l.a.b(this.L ^ true);
          break;
        } 
        int i1;
        for (i1 = this.r.p; i1 <= this.r.q; i1++) {
          Object object;
          ba.a(i1, this.q);
          int i2 = this.q.e();
          int i3 = this.q.d();
          while (true) {
            long l1;
            if (i2 < i3) {
              long l2 = this.q.a(i2);
              l1 = l2;
              if (l2 == Long.MIN_VALUE) {
                if (this.q.d == -9223372036854775807L) {
                  Object object2 = object;
                } else {
                  l1 = this.q.d;
                  l1 += this.q.c();
                  Object object2 = object;
                } 
                continue;
              } 
            } else {
              break;
            } 
            l1 += this.q.c();
            Object object1 = object;
            i2++;
            object = SYNTHETIC_LOCAL_VARIABLE_7;
          } 
        } 
        l += this.r.o;
        j++;
      } 
    } else {
      b1 = 0;
      l = 0L;
    } 
    long l = h.a(l);
    TextView textView = this.l;
    if (textView != null)
      textView.setText(ai.a(this.o, this.p, l)); 
    k k1 = this.n;
    if (k1 != null) {
      k1.setDuration(l);
      int j = this.ab.length;
      int m = b1 + j;
      long[] arrayOfLong = this.W;
      if (m > arrayOfLong.length) {
        this.W = Arrays.copyOf(arrayOfLong, m);
        this.aa = Arrays.copyOf(this.aa, m);
      } 
      System.arraycopy(this.ab, 0, this.W, b1, j);
      System.arraycopy(this.ac, 0, this.aa, b1, j);
      this.n.a(this.W, this.aa, m);
    } 
    k();
  }
  
  private void k() {
    if (c()) {
      int j;
      long l2;
      if (!this.J)
        return; 
      an an1 = this.G;
      long l1 = 0L;
      if (an1 != null) {
        l1 = this.ad + an1.N();
        l2 = this.ad + an1.O();
      } else {
        l2 = 0L;
      } 
      long l3 = this.ae;
      boolean bool = false;
      if (l1 != l3) {
        j = 1;
      } else {
        j = 0;
      } 
      if (l2 != this.af)
        bool = true; 
      this.ae = l1;
      this.af = l2;
      TextView textView = this.m;
      if (textView != null && !this.M && j)
        textView.setText(ai.a(this.o, this.p, l1)); 
      k k1 = this.n;
      if (k1 != null) {
        k1.setPosition(l1);
        this.n.setBufferedPosition(l2);
      } 
      if (this.I != null && (j || bool))
        this.I.a(l1, l2); 
      removeCallbacks(this.s);
      if (an1 == null) {
        j = 1;
      } else {
        j = an1.t();
      } 
      l3 = 1000L;
      if (an1 != null && an1.a()) {
        k1 = this.n;
        if (k1 != null) {
          l2 = k1.getPreferredUpdateDelay();
        } else {
          l2 = 1000L;
        } 
        l2 = Math.min(l2, 1000L - l1 % 1000L);
        float f1 = (an1.D()).b;
        l1 = l3;
        if (f1 > 0.0F)
          l1 = (long)((float)l2 / f1); 
        l1 = ai.a(l1, this.O, 1000L);
        postDelayed(this.s, l1);
        return;
      } 
      if (j != 4 && j != 1)
        postDelayed(this.s, 1000L); 
    } 
  }
  
  private void l() {
    boolean bool = n();
    if (!bool) {
      View view = this.e;
      if (view != null) {
        view.requestFocus();
        return;
      } 
    } 
    if (bool) {
      View view = this.f;
      if (view != null)
        view.requestFocus(); 
    } 
  }
  
  private void m() {
    boolean bool = n();
    if (!bool) {
      View view = this.e;
      if (view != null) {
        view.sendAccessibilityEvent(8);
        return;
      } 
    } 
    if (bool) {
      View view = this.f;
      if (view != null)
        view.sendAccessibilityEvent(8); 
    } 
  }
  
  private boolean n() {
    an an1 = this.G;
    return (an1 != null && an1.t() != 4 && this.G.t() != 1 && this.G.x());
  }
  
  public void a() {
    if (!c()) {
      setVisibility(0);
      Iterator<d> iterator = this.b.iterator();
      while (iterator.hasNext())
        ((d)iterator.next()).a(getVisibility()); 
      e();
      l();
      m();
    } 
    d();
  }
  
  public void a(d paramd) {
    com.applovin.exoplayer2.l.a.b(paramd);
    this.b.add(paramd);
  }
  
  public boolean a(KeyEvent paramKeyEvent) {
    int j = paramKeyEvent.getKeyCode();
    an an1 = this.G;
    if (an1 == null || !a(j))
      return false; 
    if (paramKeyEvent.getAction() == 0)
      if (j == 90) {
        if (an1.t() != 4)
          this.H.e(an1); 
      } else if (j == 89) {
        this.H.d(an1);
      } else if (paramKeyEvent.getRepeatCount() == 0) {
        if (j != 79 && j != 85) {
          if (j != 87) {
            if (j != 88) {
              if (j != 126) {
                if (j == 127)
                  c(an1); 
              } else {
                b(an1);
              } 
            } else {
              this.H.b(an1);
            } 
          } else {
            this.H.c(an1);
          } 
        } else {
          a(an1);
        } 
      }  
    return true;
  }
  
  public void b() {
    if (c()) {
      setVisibility(8);
      Iterator<d> iterator = this.b.iterator();
      while (iterator.hasNext())
        ((d)iterator.next()).a(getVisibility()); 
      removeCallbacks(this.s);
      removeCallbacks(this.t);
      this.V = -9223372036854775807L;
    } 
  }
  
  public void b(d paramd) {
    this.b.remove(paramd);
  }
  
  public boolean c() {
    return (getVisibility() == 0);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (a(paramKeyEvent) || super.dispatchKeyEvent(paramKeyEvent));
  }
  
  public final boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 0) {
      removeCallbacks(this.t);
    } else if (paramMotionEvent.getAction() == 1) {
      d();
    } 
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  @Nullable
  public an getPlayer() {
    return this.G;
  }
  
  public int getRepeatToggleModes() {
    return this.P;
  }
  
  public boolean getShowShuffleButton() {
    return this.U;
  }
  
  public int getShowTimeoutMs() {
    return this.N;
  }
  
  public boolean getShowVrButton() {
    View view = this.k;
    return (view != null && view.getVisibility() == 0);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.J = true;
    long l = this.V;
    if (l != -9223372036854775807L) {
      l -= SystemClock.uptimeMillis();
      if (l <= 0L) {
        b();
      } else {
        postDelayed(this.t, l);
      } 
    } else if (c()) {
      d();
    } 
    e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.J = false;
    removeCallbacks(this.s);
    removeCallbacks(this.t);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  @Deprecated
  public void setControlDispatcher(i parami) {
    if (this.H != parami) {
      this.H = parami;
      g();
    } 
  }
  
  public void setPlayer(@Nullable an paraman) {
    Looper looper1 = Looper.myLooper();
    Looper looper2 = Looper.getMainLooper();
    boolean bool2 = true;
    if (looper1 == looper2) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    com.applovin.exoplayer2.l.a.b(bool1);
    boolean bool1 = bool2;
    if (paraman != null)
      if (paraman.r() == Looper.getMainLooper()) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    com.applovin.exoplayer2.l.a.a(bool1);
    an an1 = this.G;
    if (an1 == paraman)
      return; 
    if (an1 != null)
      an1.b(this.a); 
    this.G = paraman;
    if (paraman != null)
      paraman.a(this.a); 
    e();
  }
  
  public void setProgressUpdateListener(@Nullable c paramc) {
    this.I = paramc;
  }
  
  public void setRepeatToggleModes(int paramInt) {
    this.P = paramInt;
    an an1 = this.G;
    if (an1 != null) {
      int j = an1.y();
      if (paramInt == 0 && j != 0) {
        this.H.a(this.G, 0);
      } else if (paramInt == 1 && j == 2) {
        this.H.a(this.G, 1);
      } else if (paramInt == 2 && j == 1) {
        this.H.a(this.G, 2);
      } 
    } 
    h();
  }
  
  public void setShowFastForwardButton(boolean paramBoolean) {
    this.R = paramBoolean;
    g();
  }
  
  public void setShowMultiWindowTimeBar(boolean paramBoolean) {
    this.K = paramBoolean;
    j();
  }
  
  public void setShowNextButton(boolean paramBoolean) {
    this.T = paramBoolean;
    g();
  }
  
  public void setShowPreviousButton(boolean paramBoolean) {
    this.S = paramBoolean;
    g();
  }
  
  public void setShowRewindButton(boolean paramBoolean) {
    this.Q = paramBoolean;
    g();
  }
  
  public void setShowShuffleButton(boolean paramBoolean) {
    this.U = paramBoolean;
    i();
  }
  
  public void setShowTimeoutMs(int paramInt) {
    this.N = paramInt;
    if (c())
      d(); 
  }
  
  public void setShowVrButton(boolean paramBoolean) {
    View view = this.k;
    if (view != null) {
      byte b1;
      if (paramBoolean) {
        b1 = 0;
      } else {
        b1 = 8;
      } 
      view.setVisibility(b1);
    } 
  }
  
  public void setTimeBarMinUpdateInterval(int paramInt) {
    this.O = ai.a(paramInt, 16, 1000);
  }
  
  public void setVrButtonListener(@Nullable View.OnClickListener paramOnClickListener) {
    View view = this.k;
    if (view != null) {
      boolean bool;
      view.setOnClickListener(paramOnClickListener);
      boolean bool1 = getShowVrButton();
      if (paramOnClickListener != null) {
        bool = true;
      } else {
        bool = false;
      } 
      a(bool1, bool, this.k);
    } 
  }
  
  @RequiresApi(21)
  private static final class a {
    public static boolean a(View param1View) {
      return param1View.isAccessibilityFocused();
    }
  }
  
  private final class b implements View.OnClickListener, an.d, k.a {
    private b(f this$0) {}
    
    public void a(an param1an, an.c param1c) {
      if (param1c.a(new int[] { 4, 5 }))
        f.a(this.a); 
      if (param1c.a(new int[] { 4, 5, 7 }))
        f.b(this.a); 
      if (param1c.a(8))
        f.c(this.a); 
      if (param1c.a(9))
        f.d(this.a); 
      if (param1c.a(new int[] { 8, 9, 11, 0, 13 }))
        f.e(this.a); 
      if (param1c.a(new int[] { 11, 0 }))
        f.f(this.a); 
    }
    
    public void a(k param1k, long param1Long) {
      f.a(this.a, true);
      if (f.g(this.a) != null)
        f.g(this.a).setText(ai.a(f.h(this.a), f.i(this.a), param1Long)); 
    }
    
    public void a(k param1k, long param1Long, boolean param1Boolean) {
      f.a(this.a, false);
      if (!param1Boolean && f.j(this.a) != null) {
        f f1 = this.a;
        f.a(f1, f.j(f1), param1Long);
      } 
    }
    
    public void b(k param1k, long param1Long) {
      if (f.g(this.a) != null)
        f.g(this.a).setText(ai.a(f.h(this.a), f.i(this.a), param1Long)); 
    }
    
    public void onClick(View param1View) {
      an an = f.j(this.a);
      if (an == null)
        return; 
      if (f.k(this.a) == param1View) {
        f.l(this.a).c(an);
        return;
      } 
      if (f.m(this.a) == param1View) {
        f.l(this.a).b(an);
        return;
      } 
      if (f.n(this.a) == param1View) {
        if (an.t() != 4) {
          f.l(this.a).e(an);
          return;
        } 
      } else {
        if (f.o(this.a) == param1View) {
          f.l(this.a).d(an);
          return;
        } 
        if (f.p(this.a) == param1View) {
          f.a(this.a, an);
          return;
        } 
        if (f.q(this.a) == param1View) {
          f.b(this.a, an);
          return;
        } 
        if (f.r(this.a) == param1View) {
          f.l(this.a).a(an, ab.a(an.y(), f.s(this.a)));
          return;
        } 
        if (f.t(this.a) == param1View)
          f.l(this.a).b(an, an.z() ^ true); 
      } 
    }
  }
  
  public static interface c {
    void a(long param1Long1, long param1Long2);
  }
  
  public static interface d {
    void a(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer\\ui\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */