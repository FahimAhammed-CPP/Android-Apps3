package com.applovin.exoplayer2.j;

import android.util.Pair;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.as;
import com.applovin.exoplayer2.at;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.h.ac;
import com.applovin.exoplayer2.h.ad;
import com.applovin.exoplayer2.h.p;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.u;
import com.applovin.exoplayer2.p;

public abstract class f extends j {
  @Nullable
  private a a;
  
  private static int a(as[] paramArrayOfas, ac paramac, int[] paramArrayOfint, boolean paramBoolean) throws p {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: istore #9
    //   4: iconst_0
    //   5: istore #4
    //   7: iconst_0
    //   8: istore #8
    //   10: iconst_1
    //   11: istore #7
    //   13: iload #4
    //   15: aload_0
    //   16: arraylength
    //   17: if_icmpge -> 198
    //   20: aload_0
    //   21: iload #4
    //   23: aaload
    //   24: astore #13
    //   26: iconst_0
    //   27: istore #6
    //   29: iconst_0
    //   30: istore #5
    //   32: iload #6
    //   34: aload_1
    //   35: getfield a : I
    //   38: if_icmpge -> 73
    //   41: iload #5
    //   43: aload #13
    //   45: aload_1
    //   46: iload #6
    //   48: invokevirtual a : (I)Lcom/applovin/exoplayer2/v;
    //   51: invokeinterface a : (Lcom/applovin/exoplayer2/v;)I
    //   56: invokestatic c : (I)I
    //   59: invokestatic max : (II)I
    //   62: istore #5
    //   64: iload #6
    //   66: iconst_1
    //   67: iadd
    //   68: istore #6
    //   70: goto -> 32
    //   73: aload_2
    //   74: iload #4
    //   76: iaload
    //   77: ifne -> 86
    //   80: iconst_1
    //   81: istore #6
    //   83: goto -> 89
    //   86: iconst_0
    //   87: istore #6
    //   89: iload #5
    //   91: iload #8
    //   93: if_icmpgt -> 165
    //   96: iload #9
    //   98: istore #12
    //   100: iload #8
    //   102: istore #11
    //   104: iload #7
    //   106: istore #10
    //   108: iload #5
    //   110: iload #8
    //   112: if_icmpne -> 177
    //   115: iload #9
    //   117: istore #12
    //   119: iload #8
    //   121: istore #11
    //   123: iload #7
    //   125: istore #10
    //   127: iload_3
    //   128: ifeq -> 177
    //   131: iload #9
    //   133: istore #12
    //   135: iload #8
    //   137: istore #11
    //   139: iload #7
    //   141: istore #10
    //   143: iload #7
    //   145: ifne -> 177
    //   148: iload #9
    //   150: istore #12
    //   152: iload #8
    //   154: istore #11
    //   156: iload #7
    //   158: istore #10
    //   160: iload #6
    //   162: ifeq -> 177
    //   165: iload #4
    //   167: istore #12
    //   169: iload #6
    //   171: istore #10
    //   173: iload #5
    //   175: istore #11
    //   177: iload #4
    //   179: iconst_1
    //   180: iadd
    //   181: istore #4
    //   183: iload #12
    //   185: istore #9
    //   187: iload #11
    //   189: istore #8
    //   191: iload #10
    //   193: istore #7
    //   195: goto -> 13
    //   198: iload #9
    //   200: ireturn
  }
  
  private static int[] a(as paramas, ac paramac) throws p {
    int[] arrayOfInt = new int[paramac.a];
    for (int i = 0; i < paramac.a; i++)
      arrayOfInt[i] = paramas.a(paramac.a(i)); 
    return arrayOfInt;
  }
  
  private static int[] a(as[] paramArrayOfas) throws p {
    int[] arrayOfInt = new int[paramArrayOfas.length];
    for (int i = 0; i < arrayOfInt.length; i++)
      arrayOfInt[i] = paramArrayOfas[i].o(); 
    return arrayOfInt;
  }
  
  protected abstract Pair<at[], d[]> a(a parama, int[][][] paramArrayOfint, int[] paramArrayOfint1, p.a parama1, ba paramba) throws p;
  
  public final k a(as[] paramArrayOfas, ad paramad, p.a parama, ba paramba) throws p {
    int[] arrayOfInt2 = new int[paramArrayOfas.length + 1];
    ac[][] arrayOfAc = new ac[paramArrayOfas.length + 1][];
    int[][][] arrayOfInt = new int[paramArrayOfas.length + 1][][];
    int k = 0;
    int i;
    for (i = 0; i < arrayOfAc.length; i++) {
      arrayOfAc[i] = new ac[paramad.b];
      arrayOfInt[i] = new int[paramad.b][];
    } 
    int[] arrayOfInt1 = a(paramArrayOfas);
    for (i = 0; i < paramad.b; i++) {
      boolean bool;
      int[] arrayOfInt4;
      ac ac = paramad.a(i);
      if (u.e((ac.a(0)).l) == 5) {
        bool = true;
      } else {
        bool = false;
      } 
      int m = a(paramArrayOfas, ac, arrayOfInt2, bool);
      if (m == paramArrayOfas.length) {
        arrayOfInt4 = new int[ac.a];
      } else {
        arrayOfInt4 = a(paramArrayOfas[m], ac);
      } 
      int n = arrayOfInt2[m];
      arrayOfAc[m][n] = ac;
      arrayOfInt[m][n] = arrayOfInt4;
      arrayOfInt2[m] = arrayOfInt2[m] + 1;
    } 
    ad[] arrayOfAd = new ad[paramArrayOfas.length];
    String[] arrayOfString = new String[paramArrayOfas.length];
    int[] arrayOfInt3 = new int[paramArrayOfas.length];
    for (i = k; i < paramArrayOfas.length; i++) {
      k = arrayOfInt2[i];
      arrayOfAd[i] = new ad((ac[])ai.a((Object[])arrayOfAc[i], k));
      arrayOfInt[i] = (int[][])ai.a((Object[])arrayOfInt[i], k);
      arrayOfString[i] = paramArrayOfas[i].y();
      arrayOfInt3[i] = paramArrayOfas[i].a();
    } 
    i = arrayOfInt2[paramArrayOfas.length];
    a a1 = new a(arrayOfString, arrayOfInt3, arrayOfAd, arrayOfInt1, arrayOfInt, new ad((ac[])ai.a((Object[])arrayOfAc[paramArrayOfas.length], i)));
    Pair<at[], d[]> pair = a(a1, arrayOfInt, arrayOfInt1, parama, paramba);
    return new k((at[])pair.first, (d[])pair.second, a1);
  }
  
  public final void a(@Nullable Object paramObject) {
    this.a = (a)paramObject;
  }
  
  public static final class a {
    private final int a;
    
    private final String[] b;
    
    private final int[] c;
    
    private final ad[] d;
    
    private final int[] e;
    
    private final int[][][] f;
    
    private final ad g;
    
    a(String[] param1ArrayOfString, int[] param1ArrayOfint1, ad[] param1ArrayOfad, int[] param1ArrayOfint2, int[][][] param1ArrayOfint, ad param1ad) {
      this.b = param1ArrayOfString;
      this.c = param1ArrayOfint1;
      this.d = param1ArrayOfad;
      this.f = param1ArrayOfint;
      this.e = param1ArrayOfint2;
      this.g = param1ad;
      this.a = param1ArrayOfint1.length;
    }
    
    public int a() {
      return this.a;
    }
    
    public int a(int param1Int) {
      return this.c[param1Int];
    }
    
    public ad b(int param1Int) {
      return this.d[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\j\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */