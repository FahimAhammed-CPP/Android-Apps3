package com.applovin.exoplayer2.j;

import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.h.ac;
import com.applovin.exoplayer2.h.p;
import com.applovin.exoplayer2.v;

public interface d extends g {
  void a();
  
  void a(float paramFloat);
  
  void a(boolean paramBoolean);
  
  void b();
  
  int c();
  
  v f();
  
  void g();
  
  void h();
  
  public static final class a {
    public final ac a;
    
    public final int[] b;
    
    public final int c;
    
    public a(ac param1ac, int... param1VarArgs) {
      this(param1ac, param1VarArgs, 0);
    }
    
    public a(ac param1ac, int[] param1ArrayOfint, int param1Int) {
      this.a = param1ac;
      this.b = param1ArrayOfint;
      this.c = param1Int;
    }
  }
  
  public static interface b {
    d[] a(d.a[] param1ArrayOfa, com.applovin.exoplayer2.k.d param1d, p.a param1a, ba param1ba);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\j\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */