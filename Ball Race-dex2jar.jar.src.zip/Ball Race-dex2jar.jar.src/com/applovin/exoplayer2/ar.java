package com.applovin.exoplayer2;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.h.x;
import com.applovin.exoplayer2.l.s;
import java.io.IOException;

public interface ar extends ao.b {
  boolean A();
  
  int a();
  
  void a(float paramFloat1, float paramFloat2) throws p;
  
  void a(int paramInt);
  
  void a(long paramLong) throws p;
  
  void a(long paramLong1, long paramLong2) throws p;
  
  void a(at paramat, v[] paramArrayOfv, x paramx, long paramLong1, boolean paramBoolean1, boolean paramBoolean2, long paramLong2, long paramLong3) throws p;
  
  void a(v[] paramArrayOfv, x paramx, long paramLong1, long paramLong2) throws p;
  
  as b();
  
  @Nullable
  s c();
  
  int d_();
  
  void e() throws p;
  
  @Nullable
  x f();
  
  boolean g();
  
  long h();
  
  void i();
  
  boolean j();
  
  void k() throws IOException;
  
  void l();
  
  void m();
  
  void n();
  
  String y();
  
  boolean z();
  
  public static interface a {
    void a();
    
    void a(long param1Long);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */