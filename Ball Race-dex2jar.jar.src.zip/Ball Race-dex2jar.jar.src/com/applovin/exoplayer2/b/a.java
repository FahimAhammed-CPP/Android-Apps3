package com.applovin.exoplayer2.b;

import com.applovin.exoplayer2.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.x;

public final class a {
  private static final int[] a = new int[] { 
      96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 
      11025, 8000, 7350 };
  
  private static final int[] b = new int[] { 
      0, 1, 2, 3, 4, 5, 6, 8, -1, -1, 
      -1, 7, 8, -1, 8, -1 };
  
  private static int a(x paramx) {
    int j = paramx.c(5);
    int i = j;
    if (j == 31)
      i = paramx.c(6) + 32; 
    return i;
  }
  
  public static a a(x paramx, boolean paramBoolean) throws ai {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic a : (Lcom/applovin/exoplayer2/l/x;)I
    //   4: istore #6
    //   6: aload_0
    //   7: invokestatic b : (Lcom/applovin/exoplayer2/l/x;)I
    //   10: istore_2
    //   11: aload_0
    //   12: iconst_4
    //   13: invokevirtual c : (I)I
    //   16: istore #5
    //   18: new java/lang/StringBuilder
    //   21: dup
    //   22: invokespecial <init> : ()V
    //   25: astore #8
    //   27: aload #8
    //   29: ldc 'mp4a.40.'
    //   31: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: pop
    //   35: aload #8
    //   37: iload #6
    //   39: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   42: pop
    //   43: aload #8
    //   45: invokevirtual toString : ()Ljava/lang/String;
    //   48: astore #8
    //   50: iload #6
    //   52: iconst_5
    //   53: if_icmpeq -> 70
    //   56: iload #6
    //   58: istore_3
    //   59: iload #5
    //   61: istore #4
    //   63: iload #6
    //   65: bipush #29
    //   67: if_icmpne -> 112
    //   70: aload_0
    //   71: invokestatic b : (Lcom/applovin/exoplayer2/l/x;)I
    //   74: istore #6
    //   76: aload_0
    //   77: invokestatic a : (Lcom/applovin/exoplayer2/l/x;)I
    //   80: istore #7
    //   82: iload #7
    //   84: istore_3
    //   85: iload #6
    //   87: istore_2
    //   88: iload #5
    //   90: istore #4
    //   92: iload #7
    //   94: bipush #22
    //   96: if_icmpne -> 112
    //   99: aload_0
    //   100: iconst_4
    //   101: invokevirtual c : (I)I
    //   104: istore #4
    //   106: iload #6
    //   108: istore_2
    //   109: iload #7
    //   111: istore_3
    //   112: iload_1
    //   113: ifeq -> 319
    //   116: iload_3
    //   117: iconst_1
    //   118: if_icmpeq -> 217
    //   121: iload_3
    //   122: iconst_2
    //   123: if_icmpeq -> 217
    //   126: iload_3
    //   127: iconst_3
    //   128: if_icmpeq -> 217
    //   131: iload_3
    //   132: iconst_4
    //   133: if_icmpeq -> 217
    //   136: iload_3
    //   137: bipush #6
    //   139: if_icmpeq -> 217
    //   142: iload_3
    //   143: bipush #7
    //   145: if_icmpeq -> 217
    //   148: iload_3
    //   149: bipush #17
    //   151: if_icmpeq -> 217
    //   154: iload_3
    //   155: tableswitch default -> 188, 19 -> 217, 20 -> 217, 21 -> 217, 22 -> 217, 23 -> 217
    //   188: new java/lang/StringBuilder
    //   191: dup
    //   192: invokespecial <init> : ()V
    //   195: astore_0
    //   196: aload_0
    //   197: ldc 'Unsupported audio object type: '
    //   199: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   202: pop
    //   203: aload_0
    //   204: iload_3
    //   205: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   208: pop
    //   209: aload_0
    //   210: invokevirtual toString : ()Ljava/lang/String;
    //   213: invokestatic a : (Ljava/lang/String;)Lcom/applovin/exoplayer2/ai;
    //   216: athrow
    //   217: aload_0
    //   218: iload_3
    //   219: iload #4
    //   221: invokestatic a : (Lcom/applovin/exoplayer2/l/x;II)V
    //   224: iload_3
    //   225: tableswitch default -> 268, 17 -> 271, 18 -> 268, 19 -> 271, 20 -> 271, 21 -> 271, 22 -> 271, 23 -> 271
    //   268: goto -> 319
    //   271: aload_0
    //   272: iconst_2
    //   273: invokevirtual c : (I)I
    //   276: istore_3
    //   277: iload_3
    //   278: iconst_2
    //   279: if_icmpeq -> 290
    //   282: iload_3
    //   283: iconst_3
    //   284: if_icmpeq -> 290
    //   287: goto -> 319
    //   290: new java/lang/StringBuilder
    //   293: dup
    //   294: invokespecial <init> : ()V
    //   297: astore_0
    //   298: aload_0
    //   299: ldc 'Unsupported epConfig: '
    //   301: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   304: pop
    //   305: aload_0
    //   306: iload_3
    //   307: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   310: pop
    //   311: aload_0
    //   312: invokevirtual toString : ()Ljava/lang/String;
    //   315: invokestatic a : (Ljava/lang/String;)Lcom/applovin/exoplayer2/ai;
    //   318: athrow
    //   319: getstatic com/applovin/exoplayer2/b/a.b : [I
    //   322: iload #4
    //   324: iaload
    //   325: istore_3
    //   326: iload_3
    //   327: iconst_m1
    //   328: if_icmpeq -> 344
    //   331: new com/applovin/exoplayer2/b/a$a
    //   334: dup
    //   335: iload_2
    //   336: iload_3
    //   337: aload #8
    //   339: aconst_null
    //   340: invokespecial <init> : (IILjava/lang/String;Lcom/applovin/exoplayer2/b/a$1;)V
    //   343: areturn
    //   344: aconst_null
    //   345: aconst_null
    //   346: invokestatic b : (Ljava/lang/String;Ljava/lang/Throwable;)Lcom/applovin/exoplayer2/ai;
    //   349: athrow
  }
  
  public static a a(byte[] paramArrayOfbyte) throws ai {
    return a(new x(paramArrayOfbyte), false);
  }
  
  private static void a(x paramx, int paramInt1, int paramInt2) {
    if (paramx.e())
      q.c("AacUtil", "Unexpected frameLengthFlag = 1"); 
    if (paramx.e())
      paramx.b(14); 
    boolean bool = paramx.e();
    if (paramInt2 != 0) {
      if (paramInt1 == 6 || paramInt1 == 20)
        paramx.b(3); 
      if (bool) {
        if (paramInt1 == 22)
          paramx.b(16); 
        if (paramInt1 == 17 || paramInt1 == 19 || paramInt1 == 20 || paramInt1 == 23)
          paramx.b(3); 
        paramx.b(1);
      } 
      return;
    } 
    throw new UnsupportedOperationException();
  }
  
  public static byte[] a(int paramInt1, int paramInt2, int paramInt3) {
    return new byte[] { (byte)(paramInt1 << 3 & 0xF8 | paramInt2 >> 1 & 0x7), (byte)(paramInt2 << 7 & 0x80 | paramInt3 << 3 & 0x78) };
  }
  
  private static int b(x paramx) throws ai {
    int i = paramx.c(4);
    if (i == 15)
      return paramx.c(24); 
    if (i < 13)
      return a[i]; 
    throw ai.b(null, null);
  }
  
  public static final class a {
    public final int a;
    
    public final int b;
    
    public final String c;
    
    private a(int param1Int1, int param1Int2, String param1String) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */