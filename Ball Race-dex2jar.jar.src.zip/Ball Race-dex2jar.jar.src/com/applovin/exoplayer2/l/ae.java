package com.applovin.exoplayer2.l;

import android.os.Handler;
import android.os.Message;
import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

final class ae implements o {
  @GuardedBy("messagePool")
  private static final List<a> a = new ArrayList<a>(50);
  
  private final Handler b;
  
  public ae(Handler paramHandler) {
    this.b = paramHandler;
  }
  
  private static a a() {
    synchronized (a) {
      a a;
      if (a.isEmpty()) {
        a = new a();
      } else {
        a = a.remove(a.size() - 1);
      } 
      return a;
    } 
  }
  
  private static void b(a parama) {
    synchronized (a) {
      if (a.size() < 50)
        a.add(parama); 
      return;
    } 
  }
  
  public o.a a(int paramInt1, int paramInt2, int paramInt3) {
    return a().a(this.b.obtainMessage(paramInt1, paramInt2, paramInt3), this);
  }
  
  public o.a a(int paramInt1, int paramInt2, int paramInt3, @Nullable Object paramObject) {
    return a().a(this.b.obtainMessage(paramInt1, paramInt2, paramInt3, paramObject), this);
  }
  
  public o.a a(int paramInt, @Nullable Object paramObject) {
    return a().a(this.b.obtainMessage(paramInt, paramObject), this);
  }
  
  public void a(@Nullable Object paramObject) {
    this.b.removeCallbacksAndMessages(paramObject);
  }
  
  public boolean a(int paramInt) {
    return this.b.hasMessages(paramInt);
  }
  
  public boolean a(int paramInt, long paramLong) {
    return this.b.sendEmptyMessageAtTime(paramInt, paramLong);
  }
  
  public boolean a(o.a parama) {
    return ((a)parama).a(this.b);
  }
  
  public boolean a(Runnable paramRunnable) {
    return this.b.post(paramRunnable);
  }
  
  public o.a b(int paramInt) {
    return a().a(this.b.obtainMessage(paramInt), this);
  }
  
  public boolean c(int paramInt) {
    return this.b.sendEmptyMessage(paramInt);
  }
  
  public void d(int paramInt) {
    this.b.removeMessages(paramInt);
  }
  
  private static final class a implements o.a {
    @Nullable
    private Message a;
    
    @Nullable
    private ae b;
    
    private a() {}
    
    private void b() {
      this.a = null;
      this.b = null;
      ae.a(this);
    }
    
    public a a(Message param1Message, ae param1ae) {
      this.a = param1Message;
      this.b = param1ae;
      return this;
    }
    
    public void a() {
      ((Message)a.b(this.a)).sendToTarget();
      b();
    }
    
    public boolean a(Handler param1Handler) {
      boolean bool = param1Handler.sendMessageAtFrontOfQueue((Message)a.b(this.a));
      b();
      return bool;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\l\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */