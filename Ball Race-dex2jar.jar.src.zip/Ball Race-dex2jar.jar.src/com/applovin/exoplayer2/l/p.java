package com.applovin.exoplayer2.l;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import androidx.annotation.CheckResult;
import androidx.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArraySet;

public final class p<T> {
  private final d a;
  
  private final o b;
  
  private final b<T> c;
  
  private final CopyOnWriteArraySet<c<T>> d;
  
  private final ArrayDeque<Runnable> e;
  
  private final ArrayDeque<Runnable> f;
  
  private boolean g;
  
  public p(Looper paramLooper, d paramd, b<T> paramb) {
    this(new CopyOnWriteArraySet<c<T>>(), paramLooper, paramd, paramb);
  }
  
  private p(CopyOnWriteArraySet<c<T>> paramCopyOnWriteArraySet, Looper paramLooper, d paramd, b<T> paramb) {
    this.a = paramd;
    this.d = paramCopyOnWriteArraySet;
    this.c = paramb;
    this.e = new ArrayDeque<Runnable>();
    this.f = new ArrayDeque<Runnable>();
    this.b = paramd.a(paramLooper, (Handler.Callback)new -$.Lambda.p.NwXVVMSVBahFkEbLrYv5oG7mecU(this));
  }
  
  private boolean a(Message paramMessage) {
    Iterator<c<T>> iterator = this.d.iterator();
    while (iterator.hasNext()) {
      ((c<T>)iterator.next()).b(this.c);
      if (this.b.a(0))
        break; 
    } 
    return true;
  }
  
  @CheckResult
  public p<T> a(Looper paramLooper, b<T> paramb) {
    return new p(this.d, paramLooper, this.a, paramb);
  }
  
  public void a() {
    if (this.f.isEmpty())
      return; 
    if (!this.b.a(0)) {
      o o1 = this.b;
      o1.a(o1.b(0));
    } 
    boolean bool = this.e.isEmpty();
    this.e.addAll(this.f);
    this.f.clear();
    if ((bool ^ true) != 0)
      return; 
    while (!this.e.isEmpty()) {
      ((Runnable)this.e.peekFirst()).run();
      this.e.removeFirst();
    } 
  }
  
  public void a(int paramInt, a<T> parama) {
    CopyOnWriteArraySet<c<T>> copyOnWriteArraySet = new CopyOnWriteArraySet<c<T>>(this.d);
    this.f.add(new -$.Lambda.p.ugTf41YHD0AA2uBY075AR5fBU2I(copyOnWriteArraySet, paramInt, parama));
  }
  
  public void a(T paramT) {
    if (this.g)
      return; 
    a.b(paramT);
    this.d.add(new c<T>(paramT));
  }
  
  public void b() {
    Iterator<c<T>> iterator = this.d.iterator();
    while (iterator.hasNext())
      ((c<T>)iterator.next()).a(this.c); 
    this.d.clear();
    this.g = true;
  }
  
  public void b(int paramInt, a<T> parama) {
    a(paramInt, parama);
    a();
  }
  
  public void b(T paramT) {
    for (c<T> c : this.d) {
      if (c.a.equals(paramT)) {
        c.a(this.c);
        this.d.remove(c);
      } 
    } 
  }
  
  public static interface a<T> {
    void invoke(T param1T);
  }
  
  public static interface b<T> {
    void invoke(T param1T, m param1m);
  }
  
  private static final class c<T> {
    public final T a;
    
    private m.a b;
    
    private boolean c;
    
    private boolean d;
    
    public c(T param1T) {
      this.a = param1T;
      this.b = new m.a();
    }
    
    public void a(int param1Int, p.a<T> param1a) {
      if (!this.d) {
        if (param1Int != -1)
          this.b.a(param1Int); 
        this.c = true;
        param1a.invoke(this.a);
      } 
    }
    
    public void a(p.b<T> param1b) {
      this.d = true;
      if (this.c)
        param1b.invoke(this.a, this.b.a()); 
    }
    
    public void b(p.b<T> param1b) {
      if (!this.d && this.c) {
        m m = this.b.a();
        this.b = new m.a();
        this.c = false;
        param1b.invoke(this.a, m);
      } 
    }
    
    public boolean equals(@Nullable Object param1Object) {
      return (this == param1Object) ? true : ((param1Object == null || getClass() != param1Object.getClass()) ? false : this.a.equals(((c)param1Object).a));
    }
    
    public int hashCode() {
      return this.a.hashCode();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\l\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */