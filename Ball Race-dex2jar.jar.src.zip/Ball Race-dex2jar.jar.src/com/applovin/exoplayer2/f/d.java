package com.applovin.exoplayer2.f;

import androidx.annotation.IntRange;
import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.l.a;
import java.nio.ByteBuffer;

final class d extends g {
  private long f;
  
  private int g;
  
  private int h = 32;
  
  public d() {
    super(2);
  }
  
  private boolean b(g paramg) {
    if (!l())
      return true; 
    if (this.g >= this.h)
      return false; 
    if (paramg.b() != b())
      return false; 
    ByteBuffer byteBuffer = paramg.b;
    return !(byteBuffer != null && this.b != null && this.b.position() + byteBuffer.remaining() > 3072000);
  }
  
  public void a() {
    super.a();
    this.g = 0;
  }
  
  public boolean a(g paramg) {
    a.a(paramg.g() ^ true);
    a.a(paramg.e() ^ true);
    a.a(paramg.c() ^ true);
    if (!b(paramg))
      return false; 
    int i = this.g;
    this.g = i + 1;
    if (i == 0) {
      this.d = paramg.d;
      if (paramg.d())
        a_(1); 
    } 
    if (paramg.b())
      a_(-2147483648); 
    ByteBuffer byteBuffer = paramg.b;
    if (byteBuffer != null) {
      f(byteBuffer.remaining());
      this.b.put(byteBuffer);
    } 
    this.f = paramg.d;
    return true;
  }
  
  public void g(@IntRange(from = 1L) int paramInt) {
    boolean bool;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    a.a(bool);
    this.h = paramInt;
  }
  
  public long i() {
    return this.d;
  }
  
  public long j() {
    return this.f;
  }
  
  public int k() {
    return this.g;
  }
  
  public boolean l() {
    return (this.g > 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */