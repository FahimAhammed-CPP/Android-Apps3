package com.applovin.exoplayer2.f;

import android.annotation.SuppressLint;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.text.TextUtils;
import android.util.Pair;
import androidx.annotation.CheckResult;
import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import com.applovin.exoplayer2.common.base.Ascii;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.u;
import com.applovin.exoplayer2.v;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressLint({"InlinedApi"})
public final class l {
  private static final Pattern a = Pattern.compile("^\\D?(\\d+)$");
  
  @GuardedBy("MediaCodecUtil.class")
  private static final HashMap<a, List<i>> b = new HashMap<a, List<i>>();
  
  private static int c = -1;
  
  private static int a(int paramInt) {
    if (paramInt != 1 && paramInt != 2) {
      switch (paramInt) {
        default:
          return -1;
        case 131072:
        case 262144:
        case 524288:
          return 35651584;
        case 32768:
        case 65536:
          return 9437184;
        case 16384:
          return 5652480;
        case 8192:
          return 2228224;
        case 2048:
        case 4096:
          return 2097152;
        case 1024:
          return 1310720;
        case 512:
          return 921600;
        case 128:
        case 256:
          return 414720;
        case 64:
          return 202752;
        case 8:
        case 16:
        case 32:
          break;
      } 
      return 101376;
    } 
    return 25344;
  }
  
  @Nullable
  public static Pair<Integer, Integer> a(v paramv) {
    if (paramv.i == null)
      return null; 
    String[] arrayOfString = paramv.i.split("\\.");
    if ("video/dolby-vision".equals(paramv.l))
      return a(paramv.i, arrayOfString); 
    byte b = 0;
    String str = arrayOfString[0];
    switch (str.hashCode()) {
      default:
        b = -1;
        break;
      case 3624515:
        if (str.equals("vp09")) {
          b = 2;
          break;
        } 
      case 3356560:
        if (str.equals("mp4a")) {
          b = 6;
          break;
        } 
      case 3214780:
        if (str.equals("hvc1")) {
          b = 4;
          break;
        } 
      case 3199032:
        if (str.equals("hev1")) {
          b = 3;
          break;
        } 
      case 3006244:
        if (str.equals("avc2")) {
          b = 1;
          break;
        } 
      case 3006243:
        if (str.equals("avc1"))
          break; 
      case 3004662:
        if (str.equals("av01")) {
          b = 5;
          break;
        } 
    } 
    switch (b) {
      default:
        return null;
      case 6:
        return e(paramv.i, arrayOfString);
      case 5:
        return a(paramv.i, arrayOfString, paramv.x);
      case 3:
      case 4:
        return b(paramv.i, arrayOfString);
      case 2:
        return d(paramv.i, arrayOfString);
      case 0:
      case 1:
        break;
    } 
    return c(paramv.i, arrayOfString);
  }
  
  @Nullable
  private static Pair<Integer, Integer> a(String paramString, String[] paramArrayOfString) {
    StringBuilder stringBuilder1;
    if (paramArrayOfString.length < 3) {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Ignoring malformed Dolby Vision codec string: ");
      stringBuilder2.append(paramString);
      q.c("MediaCodecUtil", stringBuilder2.toString());
      return null;
    } 
    Matcher matcher = a.matcher(stringBuilder2[1]);
    if (!matcher.matches()) {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Ignoring malformed Dolby Vision codec string: ");
      stringBuilder2.append(paramString);
      q.c("MediaCodecUtil", stringBuilder2.toString());
      return null;
    } 
    String str = matcher.group(1);
    Integer integer1 = b(str);
    if (integer1 == null) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Unknown Dolby Vision profile string: ");
      stringBuilder1.append(str);
      q.c("MediaCodecUtil", stringBuilder1.toString());
      return null;
    } 
    StringBuilder stringBuilder2 = stringBuilder2[2];
    Integer integer2 = c((String)stringBuilder2);
    if (integer2 == null) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Unknown Dolby Vision level string: ");
      stringBuilder1.append((String)stringBuilder2);
      q.c("MediaCodecUtil", stringBuilder1.toString());
      return null;
    } 
    return new Pair(stringBuilder1, integer2);
  }
  
  @Nullable
  private static Pair<Integer, Integer> a(String paramString, String[] paramArrayOfString, @Nullable com.applovin.exoplayer2.m.b paramb) {
    StringBuilder stringBuilder1;
    StringBuilder stringBuilder2;
    if (paramArrayOfString.length < 4) {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Ignoring malformed AV1 codec string: ");
      stringBuilder2.append(paramString);
      q.c("MediaCodecUtil", stringBuilder2.toString());
      return null;
    } 
    char c = '\001';
    try {
      int j = Integer.parseInt((String)stringBuilder2[1]);
      int i = Integer.parseInt(stringBuilder2[2].substring(0, 2));
      int k = Integer.parseInt((String)stringBuilder2[3]);
      if (j != 0) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unknown AV1 profile: ");
        stringBuilder1.append(j);
        q.c("MediaCodecUtil", stringBuilder1.toString());
        return null;
      } 
      if (k != 8 && k != 10) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unknown AV1 bit depth: ");
        stringBuilder1.append(k);
        q.c("MediaCodecUtil", stringBuilder1.toString());
        return null;
      } 
      if (k != 8)
        if (paramb != null && (paramb.d != null || paramb.c == 7 || paramb.c == 6)) {
          c = 'က';
        } else {
          c = '\002';
        }  
      j = f(i);
      if (j == -1) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unknown AV1 level: ");
        stringBuilder1.append(i);
        q.c("MediaCodecUtil", stringBuilder1.toString());
        return null;
      } 
      return new Pair(Integer.valueOf(c), Integer.valueOf(j));
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ignoring malformed AV1 codec string: ");
      stringBuilder.append((String)stringBuilder1);
      q.c("MediaCodecUtil", stringBuilder.toString());
      return null;
    } 
  }
  
  @Nullable
  public static i a() throws b {
    return a("audio/raw", false, false);
  }
  
  @Nullable
  public static i a(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws b {
    List<i> list = b(paramString, paramBoolean1, paramBoolean2);
    return list.isEmpty() ? null : list.get(0);
  }
  
  @Nullable
  private static Integer a(@Nullable String paramString) {
    if (paramString == null)
      return null; 
    byte b = -1;
    switch (paramString.hashCode()) {
      case 2312995:
        if (paramString.equals("L186"))
          b = 12; 
        break;
      case 2312992:
        if (paramString.equals("L183"))
          b = 11; 
        break;
      case 2312989:
        if (paramString.equals("L180"))
          b = 10; 
        break;
      case 2312902:
        if (paramString.equals("L156"))
          b = 9; 
        break;
      case 2312899:
        if (paramString.equals("L153"))
          b = 8; 
        break;
      case 2312896:
        if (paramString.equals("L150"))
          b = 7; 
        break;
      case 2312806:
        if (paramString.equals("L123"))
          b = 6; 
        break;
      case 2312803:
        if (paramString.equals("L120"))
          b = 5; 
        break;
      case 2193831:
        if (paramString.equals("H186"))
          b = 25; 
        break;
      case 2193828:
        if (paramString.equals("H183"))
          b = 24; 
        break;
      case 2193825:
        if (paramString.equals("H180"))
          b = 23; 
        break;
      case 2193738:
        if (paramString.equals("H156"))
          b = 22; 
        break;
      case 2193735:
        if (paramString.equals("H153"))
          b = 21; 
        break;
      case 2193732:
        if (paramString.equals("H150"))
          b = 20; 
        break;
      case 2193642:
        if (paramString.equals("H123"))
          b = 19; 
        break;
      case 2193639:
        if (paramString.equals("H120"))
          b = 18; 
        break;
      case 74854:
        if (paramString.equals("L93"))
          b = 4; 
        break;
      case 74851:
        if (paramString.equals("L90"))
          b = 3; 
        break;
      case 74761:
        if (paramString.equals("L63"))
          b = 2; 
        break;
      case 74758:
        if (paramString.equals("L60"))
          b = 1; 
        break;
      case 74665:
        if (paramString.equals("L30"))
          b = 0; 
        break;
      case 71010:
        if (paramString.equals("H93"))
          b = 17; 
        break;
      case 71007:
        if (paramString.equals("H90"))
          b = 16; 
        break;
      case 70917:
        if (paramString.equals("H63"))
          b = 15; 
        break;
      case 70914:
        if (paramString.equals("H60"))
          b = 14; 
        break;
      case 70821:
        if (paramString.equals("H30"))
          b = 13; 
        break;
    } 
    switch (b) {
      default:
        return null;
      case 25:
        return Integer.valueOf(33554432);
      case 24:
        return Integer.valueOf(8388608);
      case 23:
        return Integer.valueOf(2097152);
      case 22:
        return Integer.valueOf(524288);
      case 21:
        return Integer.valueOf(131072);
      case 20:
        return Integer.valueOf(32768);
      case 19:
        return Integer.valueOf(8192);
      case 18:
        return Integer.valueOf(2048);
      case 17:
        return Integer.valueOf(512);
      case 16:
        return Integer.valueOf(128);
      case 15:
        return Integer.valueOf(32);
      case 14:
        return Integer.valueOf(8);
      case 13:
        return Integer.valueOf(2);
      case 12:
        return Integer.valueOf(16777216);
      case 11:
        return Integer.valueOf(4194304);
      case 10:
        return Integer.valueOf(1048576);
      case 9:
        return Integer.valueOf(262144);
      case 8:
        return Integer.valueOf(65536);
      case 7:
        return Integer.valueOf(16384);
      case 6:
        return Integer.valueOf(4096);
      case 5:
        return Integer.valueOf(1024);
      case 4:
        return Integer.valueOf(256);
      case 3:
        return Integer.valueOf(64);
      case 2:
        return Integer.valueOf(16);
      case 1:
        return Integer.valueOf(4);
      case 0:
        break;
    } 
    return Integer.valueOf(1);
  }
  
  @Nullable
  private static String a(MediaCodecInfo paramMediaCodecInfo, String paramString1, String paramString2) {
    for (String str : paramMediaCodecInfo.getSupportedTypes()) {
      if (str.equalsIgnoreCase(paramString2))
        return str; 
    } 
    if (paramString2.equals("video/dolby-vision")) {
      if ("OMX.MS.HEVCDV.Decoder".equals(paramString1))
        return "video/hevcdv"; 
      if ("OMX.RTK.video.decoder".equals(paramString1) || "OMX.realtek.video.decoder.tunneled".equals(paramString1))
        return "video/dv_hevc"; 
    } else {
      if (paramString2.equals("audio/alac") && "OMX.lge.alac.decoder".equals(paramString1))
        return "audio/x-lg-alac"; 
      if (paramString2.equals("audio/flac") && "OMX.lge.flac.decoder".equals(paramString1))
        return "audio/x-lg-flac"; 
    } 
    return null;
  }
  
  private static ArrayList<i> a(a parama, c paramc) throws b {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #14
    //   9: aload_0
    //   10: getfield a : Ljava/lang/String;
    //   13: astore #15
    //   15: aload_1
    //   16: invokeinterface a : ()I
    //   21: istore_2
    //   22: aload_1
    //   23: invokeinterface b : ()Z
    //   28: istore #5
    //   30: iconst_0
    //   31: istore_3
    //   32: aload_0
    //   33: astore #12
    //   35: iload_3
    //   36: iload_2
    //   37: if_icmpge -> 536
    //   40: aload_1
    //   41: iload_3
    //   42: invokeinterface a : (I)Landroid/media/MediaCodecInfo;
    //   47: astore #17
    //   49: aload #17
    //   51: invokestatic a : (Landroid/media/MediaCodecInfo;)Z
    //   54: ifeq -> 60
    //   57: goto -> 550
    //   60: aload #17
    //   62: invokevirtual getName : ()Ljava/lang/String;
    //   65: astore #11
    //   67: aload #17
    //   69: aload #11
    //   71: iload #5
    //   73: aload #15
    //   75: invokestatic a : (Landroid/media/MediaCodecInfo;Ljava/lang/String;ZLjava/lang/String;)Z
    //   78: ifne -> 84
    //   81: goto -> 550
    //   84: aload #17
    //   86: aload #11
    //   88: aload #15
    //   90: invokestatic a : (Landroid/media/MediaCodecInfo;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   93: astore #16
    //   95: aload #16
    //   97: ifnonnull -> 103
    //   100: goto -> 550
    //   103: aload #17
    //   105: aload #16
    //   107: invokevirtual getCapabilitiesForType : (Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;
    //   110: astore #13
    //   112: aload_1
    //   113: ldc_w 'tunneled-playback'
    //   116: aload #16
    //   118: aload #13
    //   120: invokeinterface a : (Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    //   125: istore #6
    //   127: aload_1
    //   128: ldc_w 'tunneled-playback'
    //   131: aload #16
    //   133: aload #13
    //   135: invokeinterface b : (Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    //   140: istore #7
    //   142: aload #12
    //   144: getfield c : Z
    //   147: ifne -> 155
    //   150: iload #7
    //   152: ifne -> 550
    //   155: aload #12
    //   157: getfield c : Z
    //   160: ifeq -> 171
    //   163: iload #6
    //   165: ifne -> 171
    //   168: goto -> 550
    //   171: aload_1
    //   172: ldc_w 'secure-playback'
    //   175: aload #16
    //   177: aload #13
    //   179: invokeinterface a : (Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    //   184: istore #6
    //   186: aload_1
    //   187: ldc_w 'secure-playback'
    //   190: aload #16
    //   192: aload #13
    //   194: invokeinterface b : (Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;)Z
    //   199: istore #7
    //   201: aload #12
    //   203: getfield b : Z
    //   206: ifne -> 214
    //   209: iload #7
    //   211: ifne -> 550
    //   214: aload #12
    //   216: getfield b : Z
    //   219: ifeq -> 230
    //   222: iload #6
    //   224: ifne -> 230
    //   227: goto -> 550
    //   230: aload #17
    //   232: invokestatic c : (Landroid/media/MediaCodecInfo;)Z
    //   235: istore #7
    //   237: aload #17
    //   239: invokestatic e : (Landroid/media/MediaCodecInfo;)Z
    //   242: istore #8
    //   244: aload #17
    //   246: invokestatic g : (Landroid/media/MediaCodecInfo;)Z
    //   249: istore #9
    //   251: iload #5
    //   253: ifeq -> 270
    //   256: aload #12
    //   258: getfield b : Z
    //   261: istore #10
    //   263: iload #10
    //   265: iload #6
    //   267: if_icmpeq -> 287
    //   270: iload #5
    //   272: ifne -> 315
    //   275: aload #12
    //   277: getfield b : Z
    //   280: istore #10
    //   282: iload #10
    //   284: ifne -> 315
    //   287: aload #14
    //   289: aload #11
    //   291: aload #15
    //   293: aload #16
    //   295: aload #13
    //   297: iload #7
    //   299: iload #8
    //   301: iload #9
    //   303: iconst_0
    //   304: iconst_0
    //   305: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;ZZZZZ)Lcom/applovin/exoplayer2/f/i;
    //   308: invokevirtual add : (Ljava/lang/Object;)Z
    //   311: pop
    //   312: goto -> 579
    //   315: aload #11
    //   317: astore #12
    //   319: iload #5
    //   321: ifne -> 579
    //   324: iload #6
    //   326: ifeq -> 579
    //   329: new java/lang/StringBuilder
    //   332: dup
    //   333: invokespecial <init> : ()V
    //   336: astore #17
    //   338: aload #17
    //   340: aload #12
    //   342: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   345: pop
    //   346: aload #17
    //   348: ldc_w '.secure'
    //   351: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: pop
    //   355: aload #17
    //   357: invokevirtual toString : ()Ljava/lang/String;
    //   360: astore #11
    //   362: aload #14
    //   364: aload #11
    //   366: aload #15
    //   368: aload #16
    //   370: aload #13
    //   372: iload #7
    //   374: iload #8
    //   376: iload #9
    //   378: iconst_0
    //   379: iconst_1
    //   380: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/media/MediaCodecInfo$CodecCapabilities;ZZZZZ)Lcom/applovin/exoplayer2/f/i;
    //   383: invokevirtual add : (Ljava/lang/Object;)Z
    //   386: pop
    //   387: aload #14
    //   389: areturn
    //   390: astore #11
    //   392: goto -> 410
    //   395: astore #11
    //   397: goto -> 410
    //   400: astore #13
    //   402: aload #11
    //   404: astore #12
    //   406: aload #13
    //   408: astore #11
    //   410: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   413: istore #4
    //   415: iload #4
    //   417: bipush #23
    //   419: if_icmpgt -> 478
    //   422: aload #14
    //   424: invokevirtual isEmpty : ()Z
    //   427: ifne -> 478
    //   430: new java/lang/StringBuilder
    //   433: dup
    //   434: invokespecial <init> : ()V
    //   437: astore #11
    //   439: aload #11
    //   441: ldc_w 'Skipping codec '
    //   444: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   447: pop
    //   448: aload #11
    //   450: aload #12
    //   452: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   455: pop
    //   456: aload #11
    //   458: ldc_w ' (failed to query capabilities)'
    //   461: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   464: pop
    //   465: ldc 'MediaCodecUtil'
    //   467: aload #11
    //   469: invokevirtual toString : ()Ljava/lang/String;
    //   472: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)V
    //   475: goto -> 579
    //   478: new java/lang/StringBuilder
    //   481: dup
    //   482: invokespecial <init> : ()V
    //   485: astore_0
    //   486: aload_0
    //   487: ldc_w 'Failed to query codec '
    //   490: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   493: pop
    //   494: aload_0
    //   495: aload #12
    //   497: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   500: pop
    //   501: aload_0
    //   502: ldc_w ' ('
    //   505: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   508: pop
    //   509: aload_0
    //   510: aload #16
    //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   515: pop
    //   516: aload_0
    //   517: ldc_w ')'
    //   520: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   523: pop
    //   524: ldc 'MediaCodecUtil'
    //   526: aload_0
    //   527: invokevirtual toString : ()Ljava/lang/String;
    //   530: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)V
    //   533: aload #11
    //   535: athrow
    //   536: aload #14
    //   538: areturn
    //   539: astore_0
    //   540: new com/applovin/exoplayer2/f/l$b
    //   543: dup
    //   544: aload_0
    //   545: aconst_null
    //   546: invokespecial <init> : (Ljava/lang/Throwable;Lcom/applovin/exoplayer2/f/l$1;)V
    //   549: athrow
    //   550: goto -> 579
    //   553: astore #13
    //   555: aload #11
    //   557: astore #12
    //   559: aload #13
    //   561: astore #11
    //   563: goto -> 410
    //   566: astore #13
    //   568: aload #11
    //   570: astore #12
    //   572: aload #13
    //   574: astore #11
    //   576: goto -> 410
    //   579: iload_3
    //   580: iconst_1
    //   581: iadd
    //   582: istore_3
    //   583: goto -> 32
    // Exception table:
    //   from	to	target	type
    //   0	30	539	java/lang/Exception
    //   40	57	539	java/lang/Exception
    //   60	81	539	java/lang/Exception
    //   84	95	539	java/lang/Exception
    //   103	150	400	java/lang/Exception
    //   155	163	400	java/lang/Exception
    //   171	209	400	java/lang/Exception
    //   214	222	400	java/lang/Exception
    //   230	251	400	java/lang/Exception
    //   256	263	400	java/lang/Exception
    //   275	282	566	java/lang/Exception
    //   287	312	553	java/lang/Exception
    //   329	338	553	java/lang/Exception
    //   338	362	395	java/lang/Exception
    //   362	387	390	java/lang/Exception
    //   410	415	539	java/lang/Exception
    //   422	475	539	java/lang/Exception
    //   478	536	539	java/lang/Exception
  }
  
  @CheckResult
  public static List<i> a(List<i> paramList, v paramv) {
    paramList = new ArrayList<i>(paramList);
    a(paramList, new -$$Lambda$l$1nOwn6qO8giKH2D2J2BjLrgcfYI(paramv));
    return paramList;
  }
  
  private static void a(String paramString, List<i> paramList) {
    if ("audio/raw".equals(paramString)) {
      if (ai.a < 26 && ai.b.equals("R9") && paramList.size() == 1 && ((i)paramList.get(0)).a.equals("OMX.MTK.AUDIO.DECODER.RAW"))
        paramList.add(i.a("OMX.google.raw.decoder", "audio/raw", "audio/raw", null, false, true, false, false, false)); 
      a(paramList, (f<i>)-$.Lambda.l.Tl7kcoI8lF70y_eEfdPwqt8BwQc.INSTANCE);
    } 
    if (ai.a < 21 && paramList.size() > 1) {
      paramString = ((i)paramList.get(0)).a;
      if ("OMX.SEC.mp3.dec".equals(paramString) || "OMX.SEC.MP3.Decoder".equals(paramString) || "OMX.brcm.audio.mp3.decoder".equals(paramString))
        a(paramList, (f<i>)-$.Lambda.l.V0co7jnKyzCB6kZJrZXrymu7l_4.INSTANCE); 
    } 
    if (ai.a < 32 && paramList.size() > 1 && "OMX.qti.audio.decoder.flac".equals(((i)paramList.get(0)).a))
      paramList.add(paramList.remove(0)); 
  }
  
  private static <T> void a(List<T> paramList, f<T> paramf) {
    Collections.sort(paramList, (Comparator<? super T>)new -$.Lambda.l.-gAQmsbIEAq_GvOCsY6ttOCAQio(paramf));
  }
  
  private static boolean a(MediaCodecInfo paramMediaCodecInfo) {
    return (ai.a >= 29 && b(paramMediaCodecInfo));
  }
  
  private static boolean a(MediaCodecInfo paramMediaCodecInfo, String paramString1, boolean paramBoolean, String paramString2) {
    return !paramMediaCodecInfo.isEncoder() ? ((!paramBoolean && paramString1.endsWith(".secure")) ? false : ((ai.a < 21 && ("CIPAACDecoder".equals(paramString1) || "CIPMP3Decoder".equals(paramString1) || "CIPVorbisDecoder".equals(paramString1) || "CIPAMRNBDecoder".equals(paramString1) || "AACDecoder".equals(paramString1) || "MP3Decoder".equals(paramString1))) ? false : ((ai.a < 18 && "OMX.MTK.AUDIO.DECODER.AAC".equals(paramString1) && ("a70".equals(ai.b) || ("Xiaomi".equals(ai.c) && ai.b.startsWith("HM")))) ? false : ((ai.a == 16 && "OMX.qcom.audio.decoder.mp3".equals(paramString1) && ("dlxu".equals(ai.b) || "protou".equals(ai.b) || "ville".equals(ai.b) || "villeplus".equals(ai.b) || "villec2".equals(ai.b) || ai.b.startsWith("gee") || "C6602".equals(ai.b) || "C6603".equals(ai.b) || "C6606".equals(ai.b) || "C6616".equals(ai.b) || "L36h".equals(ai.b) || "SO-02E".equals(ai.b))) ? false : ((ai.a == 16 && "OMX.qcom.audio.decoder.aac".equals(paramString1) && ("C1504".equals(ai.b) || "C1505".equals(ai.b) || "C1604".equals(ai.b) || "C1605".equals(ai.b))) ? false : ((ai.a < 24 && ("OMX.SEC.aac.dec".equals(paramString1) || "OMX.Exynos.AAC.Decoder".equals(paramString1)) && "samsung".equals(ai.c) && (ai.b.startsWith("zeroflte") || ai.b.startsWith("zerolte") || ai.b.startsWith("zenlte") || "SC-05G".equals(ai.b) || "marinelteatt".equals(ai.b) || "404SC".equals(ai.b) || "SC-04G".equals(ai.b) || "SCV31".equals(ai.b))) ? false : ((ai.a <= 19 && "OMX.SEC.vp8.dec".equals(paramString1) && "samsung".equals(ai.c) && (ai.b.startsWith("d2") || ai.b.startsWith("serrano") || ai.b.startsWith("jflte") || ai.b.startsWith("santos") || ai.b.startsWith("t0"))) ? false : ((ai.a <= 19 && ai.b.startsWith("jflte") && "OMX.qcom.video.decoder.vp8".equals(paramString1)) ? false : (!("audio/eac3-joc".equals(paramString2) && "OMX.MTK.AUDIO.DECODER.DSPAC3".equals(paramString1))))))))))) : false;
  }
  
  public static int b() throws b {
    if (c == -1) {
      int i = 0;
      int j = 0;
      i i1 = a("video/avc", false, false);
      if (i1 != null) {
        MediaCodecInfo.CodecProfileLevel[] arrayOfCodecProfileLevel = i1.a();
        int k = arrayOfCodecProfileLevel.length;
        i = 0;
        while (j < k) {
          i = Math.max(a((arrayOfCodecProfileLevel[j]).level), i);
          j++;
        } 
        if (ai.a >= 21) {
          j = 345600;
        } else {
          j = 172800;
        } 
        i = Math.max(i, j);
      } 
      c = i;
    } 
    return c;
  }
  
  private static int b(int paramInt) {
    return (paramInt != 66) ? ((paramInt != 77) ? ((paramInt != 88) ? ((paramInt != 100) ? ((paramInt != 110) ? ((paramInt != 122) ? ((paramInt != 244) ? -1 : 64) : 32) : 16) : 8) : 4) : 2) : 1;
  }
  
  @Nullable
  private static Pair<Integer, Integer> b(String paramString, String[] paramArrayOfString) {
    StringBuilder stringBuilder3;
    StringBuilder stringBuilder2;
    if (paramArrayOfString.length < 4) {
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append("Ignoring malformed HEVC codec string: ");
      stringBuilder3.append(paramString);
      q.c("MediaCodecUtil", stringBuilder3.toString());
      return null;
    } 
    Pattern pattern = a;
    byte b = 1;
    Matcher matcher = pattern.matcher(stringBuilder3[1]);
    if (!matcher.matches()) {
      stringBuilder3 = new StringBuilder();
      stringBuilder3.append("Ignoring malformed HEVC codec string: ");
      stringBuilder3.append(paramString);
      q.c("MediaCodecUtil", stringBuilder3.toString());
      return null;
    } 
    paramString = matcher.group(1);
    if (!"1".equals(paramString))
      if ("2".equals(paramString)) {
        b = 2;
      } else {
        stringBuilder3 = new StringBuilder();
        stringBuilder3.append("Unknown HEVC profile string: ");
        stringBuilder3.append(paramString);
        q.c("MediaCodecUtil", stringBuilder3.toString());
        return null;
      }  
    StringBuilder stringBuilder1 = stringBuilder3[3];
    Integer integer = a((String)stringBuilder1);
    if (integer == null) {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Unknown HEVC level string: ");
      stringBuilder2.append((String)stringBuilder1);
      q.c("MediaCodecUtil", stringBuilder2.toString());
      return null;
    } 
    return new Pair(Integer.valueOf(b), stringBuilder2);
  }
  
  @Nullable
  private static Integer b(@Nullable String paramString) {
    if (paramString == null)
      return null; 
    byte b = -1;
    switch (paramString.hashCode()) {
      case 1545:
        if (paramString.equals("09"))
          b = 9; 
        break;
      case 1544:
        if (paramString.equals("08"))
          b = 8; 
        break;
      case 1543:
        if (paramString.equals("07"))
          b = 7; 
        break;
      case 1542:
        if (paramString.equals("06"))
          b = 6; 
        break;
      case 1541:
        if (paramString.equals("05"))
          b = 5; 
        break;
      case 1540:
        if (paramString.equals("04"))
          b = 4; 
        break;
      case 1539:
        if (paramString.equals("03"))
          b = 3; 
        break;
      case 1538:
        if (paramString.equals("02"))
          b = 2; 
        break;
      case 1537:
        if (paramString.equals("01"))
          b = 1; 
        break;
      case 1536:
        if (paramString.equals("00"))
          b = 0; 
        break;
    } 
    switch (b) {
      default:
        return null;
      case 9:
        return Integer.valueOf(512);
      case 8:
        return Integer.valueOf(256);
      case 7:
        return Integer.valueOf(128);
      case 6:
        return Integer.valueOf(64);
      case 5:
        return Integer.valueOf(32);
      case 4:
        return Integer.valueOf(16);
      case 3:
        return Integer.valueOf(8);
      case 2:
        return Integer.valueOf(4);
      case 1:
        return Integer.valueOf(2);
      case 0:
        break;
    } 
    return Integer.valueOf(1);
  }
  
  public static List<i> b(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws b {
    // Byte code:
    //   0: ldc com/applovin/exoplayer2/f/l
    //   2: monitorenter
    //   3: new com/applovin/exoplayer2/f/l$a
    //   6: dup
    //   7: aload_0
    //   8: iload_1
    //   9: iload_2
    //   10: invokespecial <init> : (Ljava/lang/String;ZZ)V
    //   13: astore #5
    //   15: getstatic com/applovin/exoplayer2/f/l.b : Ljava/util/HashMap;
    //   18: aload #5
    //   20: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   23: checkcast java/util/List
    //   26: astore_3
    //   27: aload_3
    //   28: ifnull -> 36
    //   31: ldc com/applovin/exoplayer2/f/l
    //   33: monitorexit
    //   34: aload_3
    //   35: areturn
    //   36: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   39: bipush #21
    //   41: if_icmplt -> 57
    //   44: new com/applovin/exoplayer2/f/l$e
    //   47: dup
    //   48: iload_1
    //   49: iload_2
    //   50: invokespecial <init> : (ZZ)V
    //   53: astore_3
    //   54: goto -> 66
    //   57: new com/applovin/exoplayer2/f/l$d
    //   60: dup
    //   61: aconst_null
    //   62: invokespecial <init> : (Lcom/applovin/exoplayer2/f/l$1;)V
    //   65: astore_3
    //   66: aload #5
    //   68: aload_3
    //   69: invokestatic a : (Lcom/applovin/exoplayer2/f/l$a;Lcom/applovin/exoplayer2/f/l$c;)Ljava/util/ArrayList;
    //   72: astore #4
    //   74: aload #4
    //   76: astore_3
    //   77: iload_1
    //   78: ifeq -> 199
    //   81: aload #4
    //   83: astore_3
    //   84: aload #4
    //   86: invokevirtual isEmpty : ()Z
    //   89: ifeq -> 199
    //   92: aload #4
    //   94: astore_3
    //   95: bipush #21
    //   97: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   100: if_icmpgt -> 199
    //   103: aload #4
    //   105: astore_3
    //   106: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   109: bipush #23
    //   111: if_icmpgt -> 199
    //   114: aload #5
    //   116: new com/applovin/exoplayer2/f/l$d
    //   119: dup
    //   120: aconst_null
    //   121: invokespecial <init> : (Lcom/applovin/exoplayer2/f/l$1;)V
    //   124: invokestatic a : (Lcom/applovin/exoplayer2/f/l$a;Lcom/applovin/exoplayer2/f/l$c;)Ljava/util/ArrayList;
    //   127: astore #4
    //   129: aload #4
    //   131: astore_3
    //   132: aload #4
    //   134: invokevirtual isEmpty : ()Z
    //   137: ifne -> 199
    //   140: new java/lang/StringBuilder
    //   143: dup
    //   144: invokespecial <init> : ()V
    //   147: astore_3
    //   148: aload_3
    //   149: ldc_w 'MediaCodecList API didn't list secure decoder for: '
    //   152: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   155: pop
    //   156: aload_3
    //   157: aload_0
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: pop
    //   162: aload_3
    //   163: ldc_w '. Assuming: '
    //   166: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   169: pop
    //   170: aload_3
    //   171: aload #4
    //   173: iconst_0
    //   174: invokevirtual get : (I)Ljava/lang/Object;
    //   177: checkcast com/applovin/exoplayer2/f/i
    //   180: getfield a : Ljava/lang/String;
    //   183: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   186: pop
    //   187: ldc 'MediaCodecUtil'
    //   189: aload_3
    //   190: invokevirtual toString : ()Ljava/lang/String;
    //   193: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
    //   196: aload #4
    //   198: astore_3
    //   199: aload_0
    //   200: aload_3
    //   201: invokestatic a : (Ljava/lang/String;Ljava/util/List;)V
    //   204: aload_3
    //   205: invokestatic unmodifiableList : (Ljava/util/List;)Ljava/util/List;
    //   208: astore_0
    //   209: getstatic com/applovin/exoplayer2/f/l.b : Ljava/util/HashMap;
    //   212: aload #5
    //   214: aload_0
    //   215: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   218: pop
    //   219: ldc com/applovin/exoplayer2/f/l
    //   221: monitorexit
    //   222: aload_0
    //   223: areturn
    //   224: astore_0
    //   225: ldc com/applovin/exoplayer2/f/l
    //   227: monitorexit
    //   228: aload_0
    //   229: athrow
    // Exception table:
    //   from	to	target	type
    //   3	27	224	finally
    //   36	54	224	finally
    //   57	66	224	finally
    //   66	74	224	finally
    //   84	92	224	finally
    //   95	103	224	finally
    //   106	129	224	finally
    //   132	196	224	finally
    //   199	219	224	finally
  }
  
  @RequiresApi(29)
  private static boolean b(MediaCodecInfo paramMediaCodecInfo) {
    return paramMediaCodecInfo.isAlias();
  }
  
  private static int c(int paramInt) {
    switch (paramInt) {
      default:
        switch (paramInt) {
          default:
            switch (paramInt) {
              default:
                switch (paramInt) {
                  default:
                    switch (paramInt) {
                      default:
                        return -1;
                      case 52:
                        return 65536;
                      case 51:
                        return 32768;
                      case 50:
                        break;
                    } 
                    return 16384;
                  case 42:
                    return 8192;
                  case 41:
                    return 4096;
                  case 40:
                    break;
                } 
                return 2048;
              case 32:
                return 1024;
              case 31:
                return 512;
              case 30:
                break;
            } 
            return 256;
          case 22:
            return 128;
          case 21:
            return 64;
          case 20:
            break;
        } 
        return 32;
      case 13:
        return 16;
      case 12:
        return 8;
      case 11:
        return 4;
      case 10:
        break;
    } 
    return 1;
  }
  
  @Nullable
  private static Pair<Integer, Integer> c(String paramString, String[] paramArrayOfString) {
    StringBuilder stringBuilder1;
    StringBuilder stringBuilder2;
    if (paramArrayOfString.length < 2) {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Ignoring malformed AVC codec string: ");
      stringBuilder2.append(paramString);
      q.c("MediaCodecUtil", stringBuilder2.toString());
      return null;
    } 
    try {
      int i;
      if (stringBuilder2[1].length() == 6) {
        j = Integer.parseInt(stringBuilder2[1].substring(0, 2), 16);
        i = Integer.parseInt(stringBuilder2[1].substring(4), 16);
      } else if (stringBuilder2.length >= 3) {
        j = Integer.parseInt((String)stringBuilder2[1]);
        i = Integer.parseInt((String)stringBuilder2[2]);
      } else {
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Ignoring malformed AVC codec string: ");
        stringBuilder2.append(paramString);
        q.c("MediaCodecUtil", stringBuilder2.toString());
        return null;
      } 
      int k = b(j);
      if (k == -1) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unknown AVC profile: ");
        stringBuilder1.append(j);
        q.c("MediaCodecUtil", stringBuilder1.toString());
        return null;
      } 
      int j = c(i);
      if (j == -1) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unknown AVC level: ");
        stringBuilder1.append(i);
        q.c("MediaCodecUtil", stringBuilder1.toString());
        return null;
      } 
      return new Pair(Integer.valueOf(k), Integer.valueOf(j));
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ignoring malformed AVC codec string: ");
      stringBuilder.append((String)stringBuilder1);
      q.c("MediaCodecUtil", stringBuilder.toString());
      return null;
    } 
  }
  
  @Nullable
  private static Integer c(@Nullable String paramString) {
    if (paramString == null)
      return null; 
    byte b = -1;
    int i = paramString.hashCode();
    switch (i) {
      default:
        switch (i) {
          default:
            break;
          case 1570:
            if (paramString.equals("13"))
              b = 12; 
            break;
          case 1569:
            if (paramString.equals("12"))
              b = 11; 
            break;
          case 1568:
            if (paramString.equals("11"))
              b = 10; 
            break;
          case 1567:
            break;
        } 
        if (paramString.equals("10"))
          b = 9; 
        break;
      case 1545:
        if (paramString.equals("09"))
          b = 8; 
        break;
      case 1544:
        if (paramString.equals("08"))
          b = 7; 
        break;
      case 1543:
        if (paramString.equals("07"))
          b = 6; 
        break;
      case 1542:
        if (paramString.equals("06"))
          b = 5; 
        break;
      case 1541:
        if (paramString.equals("05"))
          b = 4; 
        break;
      case 1540:
        if (paramString.equals("04"))
          b = 3; 
        break;
      case 1539:
        if (paramString.equals("03"))
          b = 2; 
        break;
      case 1538:
        if (paramString.equals("02"))
          b = 1; 
        break;
      case 1537:
        if (paramString.equals("01"))
          b = 0; 
        break;
    } 
    switch (b) {
      default:
        return null;
      case 12:
        return Integer.valueOf(4096);
      case 11:
        return Integer.valueOf(2048);
      case 10:
        return Integer.valueOf(1024);
      case 9:
        return Integer.valueOf(512);
      case 8:
        return Integer.valueOf(256);
      case 7:
        return Integer.valueOf(128);
      case 6:
        return Integer.valueOf(64);
      case 5:
        return Integer.valueOf(32);
      case 4:
        return Integer.valueOf(16);
      case 3:
        return Integer.valueOf(8);
      case 2:
        return Integer.valueOf(4);
      case 1:
        return Integer.valueOf(2);
      case 0:
        break;
    } 
    return Integer.valueOf(1);
  }
  
  private static boolean c(MediaCodecInfo paramMediaCodecInfo) {
    return (ai.a >= 29) ? d(paramMediaCodecInfo) : (e(paramMediaCodecInfo) ^ true);
  }
  
  private static int d(int paramInt) {
    return (paramInt != 0) ? ((paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? -1 : 8) : 4) : 2) : 1;
  }
  
  @Nullable
  private static Pair<Integer, Integer> d(String paramString, String[] paramArrayOfString) {
    StringBuilder stringBuilder1;
    StringBuilder stringBuilder2;
    if (paramArrayOfString.length < 3) {
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Ignoring malformed VP9 codec string: ");
      stringBuilder2.append(paramString);
      q.c("MediaCodecUtil", stringBuilder2.toString());
      return null;
    } 
    try {
      int k = Integer.parseInt((String)stringBuilder2[1]);
      int i = Integer.parseInt((String)stringBuilder2[2]);
      int j = d(k);
      if (j == -1) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unknown VP9 profile: ");
        stringBuilder1.append(k);
        q.c("MediaCodecUtil", stringBuilder1.toString());
        return null;
      } 
      k = e(i);
      if (k == -1) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Unknown VP9 level: ");
        stringBuilder1.append(i);
        q.c("MediaCodecUtil", stringBuilder1.toString());
        return null;
      } 
      return new Pair(Integer.valueOf(j), Integer.valueOf(k));
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ignoring malformed VP9 codec string: ");
      stringBuilder.append((String)stringBuilder1);
      q.c("MediaCodecUtil", stringBuilder.toString());
      return null;
    } 
  }
  
  @RequiresApi(29)
  private static boolean d(MediaCodecInfo paramMediaCodecInfo) {
    return paramMediaCodecInfo.isHardwareAccelerated();
  }
  
  private static int e(int paramInt) {
    if (paramInt != 10) {
      if (paramInt != 11) {
        if (paramInt != 20) {
          if (paramInt != 21) {
            if (paramInt != 30) {
              if (paramInt != 31) {
                if (paramInt != 40) {
                  if (paramInt != 41) {
                    if (paramInt != 50) {
                      if (paramInt != 51) {
                        switch (paramInt) {
                          default:
                            return -1;
                          case 62:
                            return 8192;
                          case 61:
                            return 4096;
                          case 60:
                            break;
                        } 
                        return 2048;
                      } 
                      return 512;
                    } 
                    return 256;
                  } 
                  return 128;
                } 
                return 64;
              } 
              return 32;
            } 
            return 16;
          } 
          return 8;
        } 
        return 4;
      } 
      return 2;
    } 
    return 1;
  }
  
  @Nullable
  private static Pair<Integer, Integer> e(String paramString, String[] paramArrayOfString) {
    StringBuilder stringBuilder;
    if (paramArrayOfString.length != 3) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Ignoring malformed MP4A codec string: ");
      stringBuilder.append(paramString);
      q.c("MediaCodecUtil", stringBuilder.toString());
      return null;
    } 
    try {
      if ("audio/mp4a-latm".equals(u.a(Integer.parseInt((String)stringBuilder[1], 16)))) {
        int i = g(Integer.parseInt((String)stringBuilder[2]));
        if (i != -1)
          return new Pair(Integer.valueOf(i), Integer.valueOf(0)); 
      } 
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Ignoring malformed MP4A codec string: ");
      stringBuilder1.append(paramString);
      q.c("MediaCodecUtil", stringBuilder1.toString());
    } 
    return null;
  }
  
  private static boolean e(MediaCodecInfo paramMediaCodecInfo) {
    if (ai.a >= 29)
      return f(paramMediaCodecInfo); 
    String str = Ascii.toLowerCase(paramMediaCodecInfo.getName());
    null = str.startsWith("arc.");
    boolean bool = false;
    if (null)
      return false; 
    if (!str.startsWith("omx.google.") && !str.startsWith("omx.ffmpeg.") && (!str.startsWith("omx.sec.") || !str.contains(".sw.")) && !str.equals("omx.qcom.video.decoder.hevcswvdec") && !str.startsWith("c2.android.") && !str.startsWith("c2.google.")) {
      null = bool;
      if (!str.startsWith("omx.")) {
        null = bool;
        if (!str.startsWith("c2."))
          return true; 
      } 
      return null;
    } 
    return true;
  }
  
  private static int f(int paramInt) {
    switch (paramInt) {
      default:
        return -1;
      case 23:
        return 8388608;
      case 22:
        return 4194304;
      case 21:
        return 2097152;
      case 20:
        return 1048576;
      case 19:
        return 524288;
      case 18:
        return 262144;
      case 17:
        return 131072;
      case 16:
        return 65536;
      case 15:
        return 32768;
      case 14:
        return 16384;
      case 13:
        return 8192;
      case 12:
        return 4096;
      case 11:
        return 2048;
      case 10:
        return 1024;
      case 9:
        return 512;
      case 8:
        return 256;
      case 7:
        return 128;
      case 6:
        return 64;
      case 5:
        return 32;
      case 4:
        return 16;
      case 3:
        return 8;
      case 2:
        return 4;
      case 1:
        return 2;
      case 0:
        break;
    } 
    return 1;
  }
  
  @RequiresApi(29)
  private static boolean f(MediaCodecInfo paramMediaCodecInfo) {
    return paramMediaCodecInfo.isSoftwareOnly();
  }
  
  private static int g(int paramInt) {
    byte b = 17;
    if (paramInt != 17) {
      b = 20;
      if (paramInt != 20) {
        b = 23;
        if (paramInt != 23) {
          b = 29;
          if (paramInt != 29) {
            b = 39;
            if (paramInt != 39) {
              b = 42;
              if (paramInt != 42) {
                switch (paramInt) {
                  default:
                    return -1;
                  case 6:
                    return 6;
                  case 5:
                    return 5;
                  case 4:
                    return 4;
                  case 3:
                    return 3;
                  case 2:
                    return 2;
                  case 1:
                    break;
                } 
                return 1;
              } 
            } 
          } 
        } 
      } 
    } 
    return b;
  }
  
  private static boolean g(MediaCodecInfo paramMediaCodecInfo) {
    if (ai.a >= 29)
      return h(paramMediaCodecInfo); 
    String str = Ascii.toLowerCase(paramMediaCodecInfo.getName());
    return (!str.startsWith("omx.google.") && !str.startsWith("c2.android.") && !str.startsWith("c2.google."));
  }
  
  @RequiresApi(29)
  private static boolean h(MediaCodecInfo paramMediaCodecInfo) {
    return paramMediaCodecInfo.isVendor();
  }
  
  private static final class a {
    public final String a;
    
    public final boolean b;
    
    public final boolean c;
    
    public a(String param1String, boolean param1Boolean1, boolean param1Boolean2) {
      this.a = param1String;
      this.b = param1Boolean1;
      this.c = param1Boolean2;
    }
    
    public boolean equals(@Nullable Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (param1Object.getClass() != a.class)
          return false; 
        param1Object = param1Object;
        return (TextUtils.equals(this.a, ((a)param1Object).a) && this.b == ((a)param1Object).b && this.c == ((a)param1Object).c);
      } 
      return false;
    }
    
    public int hashCode() {
      char c1;
      int i = this.a.hashCode();
      boolean bool = this.b;
      char c2 = 'ӏ';
      if (bool) {
        c1 = 'ӏ';
      } else {
        c1 = 'ӕ';
      } 
      if (!this.c)
        c2 = 'ӕ'; 
      return ((i + 31) * 31 + c1) * 31 + c2;
    }
  }
  
  public static class b extends Exception {
    private b(Throwable param1Throwable) {
      super("Failed to query underlying media codecs", param1Throwable);
    }
  }
  
  private static interface c {
    int a();
    
    MediaCodecInfo a(int param1Int);
    
    boolean a(String param1String1, String param1String2, MediaCodecInfo.CodecCapabilities param1CodecCapabilities);
    
    boolean b();
    
    boolean b(String param1String1, String param1String2, MediaCodecInfo.CodecCapabilities param1CodecCapabilities);
  }
  
  private static final class d implements c {
    private d() {}
    
    public int a() {
      return MediaCodecList.getCodecCount();
    }
    
    public MediaCodecInfo a(int param1Int) {
      return MediaCodecList.getCodecInfoAt(param1Int);
    }
    
    public boolean a(String param1String1, String param1String2, MediaCodecInfo.CodecCapabilities param1CodecCapabilities) {
      return ("secure-playback".equals(param1String1) && "video/avc".equals(param1String2));
    }
    
    public boolean b() {
      return false;
    }
    
    public boolean b(String param1String1, String param1String2, MediaCodecInfo.CodecCapabilities param1CodecCapabilities) {
      return false;
    }
  }
  
  @RequiresApi(21)
  private static final class e implements c {
    private final int a;
    
    @Nullable
    private MediaCodecInfo[] b;
    
    public e(boolean param1Boolean1, boolean param1Boolean2) {
      boolean bool;
      if (param1Boolean1 || param1Boolean2) {
        bool = true;
      } else {
        bool = false;
      } 
      this.a = bool;
    }
    
    private void c() {
      if (this.b == null)
        this.b = (new MediaCodecList(this.a)).getCodecInfos(); 
    }
    
    public int a() {
      c();
      return this.b.length;
    }
    
    public MediaCodecInfo a(int param1Int) {
      c();
      return this.b[param1Int];
    }
    
    public boolean a(String param1String1, String param1String2, MediaCodecInfo.CodecCapabilities param1CodecCapabilities) {
      return param1CodecCapabilities.isFeatureSupported(param1String1);
    }
    
    public boolean b() {
      return true;
    }
    
    public boolean b(String param1String1, String param1String2, MediaCodecInfo.CodecCapabilities param1CodecCapabilities) {
      return param1CodecCapabilities.isFeatureRequired(param1String1);
    }
  }
  
  private static interface f<T> {
    int getScore(T param1T);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */