package com.applovin.exoplayer2.f;

import android.graphics.Point;
import android.media.MediaCodecInfo;
import android.util.Pair;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import com.applovin.exoplayer2.c.h;
import com.applovin.exoplayer2.l.a;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.u;
import com.applovin.exoplayer2.v;

public final class i {
  public final String a;
  
  public final String b;
  
  public final String c;
  
  @Nullable
  public final MediaCodecInfo.CodecCapabilities d;
  
  public final boolean e;
  
  public final boolean f;
  
  public final boolean g;
  
  public final boolean h;
  
  public final boolean i;
  
  public final boolean j;
  
  private final boolean k;
  
  @VisibleForTesting
  i(String paramString1, String paramString2, String paramString3, @Nullable MediaCodecInfo.CodecCapabilities paramCodecCapabilities, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6) {
    this.a = (String)a.b(paramString1);
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramCodecCapabilities;
    this.h = paramBoolean1;
    this.i = paramBoolean2;
    this.j = paramBoolean3;
    this.e = paramBoolean4;
    this.f = paramBoolean5;
    this.g = paramBoolean6;
    this.k = u.b(paramString2);
  }
  
  private static int a(String paramString1, String paramString2, int paramInt) {
    if (paramInt <= 1) {
      if (ai.a >= 26 && paramInt > 0)
        return paramInt; 
      if (!"audio/mpeg".equals(paramString2) && !"audio/3gpp".equals(paramString2) && !"audio/amr-wb".equals(paramString2) && !"audio/mp4a-latm".equals(paramString2) && !"audio/vorbis".equals(paramString2) && !"audio/opus".equals(paramString2) && !"audio/raw".equals(paramString2) && !"audio/flac".equals(paramString2) && !"audio/g711-alaw".equals(paramString2) && !"audio/g711-mlaw".equals(paramString2)) {
        byte b;
        if ("audio/gsm".equals(paramString2))
          return paramInt; 
        if ("audio/ac3".equals(paramString2)) {
          b = 6;
        } else if ("audio/eac3".equals(paramString2)) {
          b = 16;
        } else {
          b = 30;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("AssumedMaxChannelAdjustment: ");
        stringBuilder.append(paramString1);
        stringBuilder.append(", [");
        stringBuilder.append(paramInt);
        stringBuilder.append(" to ");
        stringBuilder.append(b);
        stringBuilder.append("]");
        q.c("MediaCodecInfo", stringBuilder.toString());
        return b;
      } 
    } 
    return paramInt;
  }
  
  @RequiresApi(21)
  private static Point a(MediaCodecInfo.VideoCapabilities paramVideoCapabilities, int paramInt1, int paramInt2) {
    int j = paramVideoCapabilities.getWidthAlignment();
    int k = paramVideoCapabilities.getHeightAlignment();
    return new Point(ai.a(paramInt1, j) * j, ai.a(paramInt2, k) * k);
  }
  
  public static i a(String paramString1, String paramString2, String paramString3, @Nullable MediaCodecInfo.CodecCapabilities paramCodecCapabilities, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) {
    boolean bool;
    if (!paramBoolean4 && paramCodecCapabilities != null && a(paramCodecCapabilities) && !c(paramString1)) {
      paramBoolean4 = true;
    } else {
      paramBoolean4 = false;
    } 
    if (paramCodecCapabilities != null && c(paramCodecCapabilities)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramBoolean5 || (paramCodecCapabilities != null && e(paramCodecCapabilities))) {
      paramBoolean5 = true;
      return new i(paramString1, paramString2, paramString3, paramCodecCapabilities, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, bool, paramBoolean5);
    } 
    paramBoolean5 = false;
    return new i(paramString1, paramString2, paramString3, paramCodecCapabilities, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, bool, paramBoolean5);
  }
  
  private void a(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("NoSupport [");
    stringBuilder.append(paramString);
    stringBuilder.append("] [");
    stringBuilder.append(this.a);
    stringBuilder.append(", ");
    stringBuilder.append(this.b);
    stringBuilder.append("] [");
    stringBuilder.append(ai.e);
    stringBuilder.append("]");
    q.a("MediaCodecInfo", stringBuilder.toString());
  }
  
  private static boolean a(MediaCodecInfo.CodecCapabilities paramCodecCapabilities) {
    return (ai.a >= 19 && b(paramCodecCapabilities));
  }
  
  @RequiresApi(21)
  private static boolean a(MediaCodecInfo.VideoCapabilities paramVideoCapabilities, int paramInt1, int paramInt2, double paramDouble) {
    Point point = a(paramVideoCapabilities, paramInt1, paramInt2);
    paramInt1 = point.x;
    paramInt2 = point.y;
    return (paramDouble == -1.0D || paramDouble < 1.0D) ? paramVideoCapabilities.isSizeSupported(paramInt1, paramInt2) : paramVideoCapabilities.areSizeAndRateSupported(paramInt1, paramInt2, Math.floor(paramDouble));
  }
  
  private void b(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AssumedSupport [");
    stringBuilder.append(paramString);
    stringBuilder.append("] [");
    stringBuilder.append(this.a);
    stringBuilder.append(", ");
    stringBuilder.append(this.b);
    stringBuilder.append("] [");
    stringBuilder.append(ai.e);
    stringBuilder.append("]");
    q.a("MediaCodecInfo", stringBuilder.toString());
  }
  
  @RequiresApi(19)
  private static boolean b(MediaCodecInfo.CodecCapabilities paramCodecCapabilities) {
    return paramCodecCapabilities.isFeatureSupported("adaptive-playback");
  }
  
  private static boolean c(MediaCodecInfo.CodecCapabilities paramCodecCapabilities) {
    return (ai.a >= 21 && d(paramCodecCapabilities));
  }
  
  private static boolean c(String paramString) {
    return (ai.a <= 22 && ("ODROID-XU3".equals(ai.d) || "Nexus 10".equals(ai.d)) && ("OMX.Exynos.AVC.Decoder".equals(paramString) || "OMX.Exynos.AVC.Decoder.secure".equals(paramString)));
  }
  
  @RequiresApi(21)
  private static boolean d(MediaCodecInfo.CodecCapabilities paramCodecCapabilities) {
    return paramCodecCapabilities.isFeatureSupported("tunneled-playback");
  }
  
  private static boolean d(String paramString) {
    return (ai.d.startsWith("SM-T230") && "OMX.MARVELL.VIDEO.HW.CODA7542DECODER".equals(paramString));
  }
  
  private static boolean e(MediaCodecInfo.CodecCapabilities paramCodecCapabilities) {
    return (ai.a >= 21 && f(paramCodecCapabilities));
  }
  
  private static boolean e(String paramString) {
    return "audio/opus".equals(paramString);
  }
  
  @RequiresApi(21)
  private static boolean f(MediaCodecInfo.CodecCapabilities paramCodecCapabilities) {
    return paramCodecCapabilities.isFeatureSupported("secure-playback");
  }
  
  private static final boolean f(String paramString) {
    return !("OMX.MTK.VIDEO.DECODER.HEVC".equals(paramString) && "mcv5a".equals(ai.b));
  }
  
  private static MediaCodecInfo.CodecProfileLevel[] g(@Nullable MediaCodecInfo.CodecCapabilities paramCodecCapabilities) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 30
    //   4: aload_0
    //   5: invokevirtual getVideoCapabilities : ()Landroid/media/MediaCodecInfo$VideoCapabilities;
    //   8: astore_0
    //   9: aload_0
    //   10: ifnull -> 30
    //   13: aload_0
    //   14: invokevirtual getBitrateRange : ()Landroid/util/Range;
    //   17: invokevirtual getUpper : ()Ljava/lang/Comparable;
    //   20: checkcast java/lang/Integer
    //   23: invokevirtual intValue : ()I
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ldc_w 180000000
    //   36: if_icmplt -> 46
    //   39: sipush #1024
    //   42: istore_1
    //   43: goto -> 166
    //   46: iload_1
    //   47: ldc_w 120000000
    //   50: if_icmplt -> 60
    //   53: sipush #512
    //   56: istore_1
    //   57: goto -> 166
    //   60: iload_1
    //   61: ldc_w 60000000
    //   64: if_icmplt -> 74
    //   67: sipush #256
    //   70: istore_1
    //   71: goto -> 166
    //   74: iload_1
    //   75: ldc_w 30000000
    //   78: if_icmplt -> 88
    //   81: sipush #128
    //   84: istore_1
    //   85: goto -> 166
    //   88: iload_1
    //   89: ldc_w 18000000
    //   92: if_icmplt -> 101
    //   95: bipush #64
    //   97: istore_1
    //   98: goto -> 166
    //   101: iload_1
    //   102: ldc_w 12000000
    //   105: if_icmplt -> 114
    //   108: bipush #32
    //   110: istore_1
    //   111: goto -> 166
    //   114: iload_1
    //   115: ldc_w 7200000
    //   118: if_icmplt -> 127
    //   121: bipush #16
    //   123: istore_1
    //   124: goto -> 166
    //   127: iload_1
    //   128: ldc_w 3600000
    //   131: if_icmplt -> 140
    //   134: bipush #8
    //   136: istore_1
    //   137: goto -> 166
    //   140: iload_1
    //   141: ldc_w 1800000
    //   144: if_icmplt -> 152
    //   147: iconst_4
    //   148: istore_1
    //   149: goto -> 166
    //   152: iload_1
    //   153: ldc_w 800000
    //   156: if_icmplt -> 164
    //   159: iconst_2
    //   160: istore_1
    //   161: goto -> 166
    //   164: iconst_1
    //   165: istore_1
    //   166: new android/media/MediaCodecInfo$CodecProfileLevel
    //   169: dup
    //   170: invokespecial <init> : ()V
    //   173: astore_0
    //   174: aload_0
    //   175: iconst_1
    //   176: putfield profile : I
    //   179: aload_0
    //   180: iload_1
    //   181: putfield level : I
    //   184: iconst_1
    //   185: anewarray android/media/MediaCodecInfo$CodecProfileLevel
    //   188: dup
    //   189: iconst_0
    //   190: aload_0
    //   191: aastore
    //   192: areturn
  }
  
  @Nullable
  @RequiresApi(21)
  public Point a(int paramInt1, int paramInt2) {
    MediaCodecInfo.CodecCapabilities codecCapabilities = this.d;
    if (codecCapabilities == null)
      return null; 
    MediaCodecInfo.VideoCapabilities videoCapabilities = codecCapabilities.getVideoCapabilities();
    return (videoCapabilities == null) ? null : a(videoCapabilities, paramInt1, paramInt2);
  }
  
  public h a(v paramv1, v paramv2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield l : Ljava/lang/String;
    //   4: aload_2
    //   5: getfield l : Ljava/lang/String;
    //   8: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   11: ifne -> 20
    //   14: bipush #8
    //   16: istore_3
    //   17: goto -> 22
    //   20: iconst_0
    //   21: istore_3
    //   22: aload_0
    //   23: getfield k : Z
    //   26: ifeq -> 190
    //   29: iload_3
    //   30: istore #4
    //   32: aload_1
    //   33: getfield t : I
    //   36: aload_2
    //   37: getfield t : I
    //   40: if_icmpeq -> 50
    //   43: iload_3
    //   44: sipush #1024
    //   47: ior
    //   48: istore #4
    //   50: iload #4
    //   52: istore_3
    //   53: aload_0
    //   54: getfield e : Z
    //   57: ifne -> 92
    //   60: aload_1
    //   61: getfield q : I
    //   64: aload_2
    //   65: getfield q : I
    //   68: if_icmpne -> 85
    //   71: iload #4
    //   73: istore_3
    //   74: aload_1
    //   75: getfield r : I
    //   78: aload_2
    //   79: getfield r : I
    //   82: if_icmpeq -> 92
    //   85: iload #4
    //   87: sipush #512
    //   90: ior
    //   91: istore_3
    //   92: iload_3
    //   93: istore #4
    //   95: aload_1
    //   96: getfield x : Lcom/applovin/exoplayer2/m/b;
    //   99: aload_2
    //   100: getfield x : Lcom/applovin/exoplayer2/m/b;
    //   103: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   106: ifne -> 116
    //   109: iload_3
    //   110: sipush #2048
    //   113: ior
    //   114: istore #4
    //   116: iload #4
    //   118: istore_3
    //   119: aload_0
    //   120: getfield a : Ljava/lang/String;
    //   123: invokestatic d : (Ljava/lang/String;)Z
    //   126: ifeq -> 145
    //   129: iload #4
    //   131: istore_3
    //   132: aload_1
    //   133: aload_2
    //   134: invokevirtual a : (Lcom/applovin/exoplayer2/v;)Z
    //   137: ifne -> 145
    //   140: iload #4
    //   142: iconst_2
    //   143: ior
    //   144: istore_3
    //   145: iload_3
    //   146: istore #4
    //   148: iload_3
    //   149: ifne -> 187
    //   152: aload_0
    //   153: getfield a : Ljava/lang/String;
    //   156: astore #6
    //   158: aload_1
    //   159: aload_2
    //   160: invokevirtual a : (Lcom/applovin/exoplayer2/v;)Z
    //   163: ifeq -> 171
    //   166: iconst_3
    //   167: istore_3
    //   168: goto -> 173
    //   171: iconst_2
    //   172: istore_3
    //   173: new com/applovin/exoplayer2/c/h
    //   176: dup
    //   177: aload #6
    //   179: aload_1
    //   180: aload_2
    //   181: iload_3
    //   182: iconst_0
    //   183: invokespecial <init> : (Ljava/lang/String;Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/v;II)V
    //   186: areturn
    //   187: goto -> 407
    //   190: iload_3
    //   191: istore #4
    //   193: aload_1
    //   194: getfield y : I
    //   197: aload_2
    //   198: getfield y : I
    //   201: if_icmpeq -> 211
    //   204: iload_3
    //   205: sipush #4096
    //   208: ior
    //   209: istore #4
    //   211: iload #4
    //   213: istore #5
    //   215: aload_1
    //   216: getfield z : I
    //   219: aload_2
    //   220: getfield z : I
    //   223: if_icmpeq -> 234
    //   226: iload #4
    //   228: sipush #8192
    //   231: ior
    //   232: istore #5
    //   234: iload #5
    //   236: istore_3
    //   237: aload_1
    //   238: getfield A : I
    //   241: aload_2
    //   242: getfield A : I
    //   245: if_icmpeq -> 255
    //   248: iload #5
    //   250: sipush #16384
    //   253: ior
    //   254: istore_3
    //   255: iload_3
    //   256: ifne -> 349
    //   259: ldc 'audio/mp4a-latm'
    //   261: aload_0
    //   262: getfield b : Ljava/lang/String;
    //   265: invokevirtual equals : (Ljava/lang/Object;)Z
    //   268: ifeq -> 349
    //   271: aload_1
    //   272: invokestatic a : (Lcom/applovin/exoplayer2/v;)Landroid/util/Pair;
    //   275: astore #6
    //   277: aload_2
    //   278: invokestatic a : (Lcom/applovin/exoplayer2/v;)Landroid/util/Pair;
    //   281: astore #7
    //   283: aload #6
    //   285: ifnull -> 349
    //   288: aload #7
    //   290: ifnull -> 349
    //   293: aload #6
    //   295: getfield first : Ljava/lang/Object;
    //   298: checkcast java/lang/Integer
    //   301: invokevirtual intValue : ()I
    //   304: istore #4
    //   306: aload #7
    //   308: getfield first : Ljava/lang/Object;
    //   311: checkcast java/lang/Integer
    //   314: invokevirtual intValue : ()I
    //   317: istore #5
    //   319: iload #4
    //   321: bipush #42
    //   323: if_icmpne -> 349
    //   326: iload #5
    //   328: bipush #42
    //   330: if_icmpne -> 349
    //   333: new com/applovin/exoplayer2/c/h
    //   336: dup
    //   337: aload_0
    //   338: getfield a : Ljava/lang/String;
    //   341: aload_1
    //   342: aload_2
    //   343: iconst_3
    //   344: iconst_0
    //   345: invokespecial <init> : (Ljava/lang/String;Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/v;II)V
    //   348: areturn
    //   349: iload_3
    //   350: istore #4
    //   352: aload_1
    //   353: aload_2
    //   354: invokevirtual a : (Lcom/applovin/exoplayer2/v;)Z
    //   357: ifne -> 366
    //   360: iload_3
    //   361: bipush #32
    //   363: ior
    //   364: istore #4
    //   366: iload #4
    //   368: istore_3
    //   369: aload_0
    //   370: getfield b : Ljava/lang/String;
    //   373: invokestatic e : (Ljava/lang/String;)Z
    //   376: ifeq -> 384
    //   379: iload #4
    //   381: iconst_2
    //   382: ior
    //   383: istore_3
    //   384: iload_3
    //   385: istore #4
    //   387: iload_3
    //   388: ifne -> 187
    //   391: new com/applovin/exoplayer2/c/h
    //   394: dup
    //   395: aload_0
    //   396: getfield a : Ljava/lang/String;
    //   399: aload_1
    //   400: aload_2
    //   401: iconst_1
    //   402: iconst_0
    //   403: invokespecial <init> : (Ljava/lang/String;Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/v;II)V
    //   406: areturn
    //   407: new com/applovin/exoplayer2/c/h
    //   410: dup
    //   411: aload_0
    //   412: getfield a : Ljava/lang/String;
    //   415: aload_1
    //   416: aload_2
    //   417: iconst_0
    //   418: iload #4
    //   420: invokespecial <init> : (Ljava/lang/String;Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/v;II)V
    //   423: areturn
  }
  
  @RequiresApi(21)
  public boolean a(int paramInt) {
    MediaCodecInfo.CodecCapabilities codecCapabilities = this.d;
    if (codecCapabilities == null) {
      a("sampleRate.caps");
      return false;
    } 
    MediaCodecInfo.AudioCapabilities audioCapabilities = codecCapabilities.getAudioCapabilities();
    if (audioCapabilities == null) {
      a("sampleRate.aCaps");
      return false;
    } 
    if (!audioCapabilities.isSampleRateSupported(paramInt)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sampleRate.support, ");
      stringBuilder.append(paramInt);
      a(stringBuilder.toString());
      return false;
    } 
    return true;
  }
  
  @RequiresApi(21)
  public boolean a(int paramInt1, int paramInt2, double paramDouble) {
    MediaCodecInfo.CodecCapabilities codecCapabilities = this.d;
    if (codecCapabilities == null) {
      a("sizeAndRate.caps");
      return false;
    } 
    MediaCodecInfo.VideoCapabilities videoCapabilities = codecCapabilities.getVideoCapabilities();
    if (videoCapabilities == null) {
      a("sizeAndRate.vCaps");
      return false;
    } 
    if (!a(videoCapabilities, paramInt1, paramInt2, paramDouble)) {
      if (paramInt1 >= paramInt2 || !f(this.a) || !a(videoCapabilities, paramInt2, paramInt1, paramDouble)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("sizeAndRate.support, ");
        stringBuilder1.append(paramInt1);
        stringBuilder1.append("x");
        stringBuilder1.append(paramInt2);
        stringBuilder1.append("x");
        stringBuilder1.append(paramDouble);
        a(stringBuilder1.toString());
        return false;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sizeAndRate.rotated, ");
      stringBuilder.append(paramInt1);
      stringBuilder.append("x");
      stringBuilder.append(paramInt2);
      stringBuilder.append("x");
      stringBuilder.append(paramDouble);
      b(stringBuilder.toString());
    } 
    return true;
  }
  
  public boolean a(v paramv) throws l.b {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual b : (Lcom/applovin/exoplayer2/v;)Z
    //   5: istore #4
    //   7: iconst_0
    //   8: istore_3
    //   9: iconst_0
    //   10: istore_2
    //   11: iload #4
    //   13: ifne -> 18
    //   16: iconst_0
    //   17: ireturn
    //   18: aload_0
    //   19: getfield k : Z
    //   22: ifeq -> 148
    //   25: aload_1
    //   26: getfield q : I
    //   29: ifle -> 146
    //   32: aload_1
    //   33: getfield r : I
    //   36: ifgt -> 41
    //   39: iconst_1
    //   40: ireturn
    //   41: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   44: bipush #21
    //   46: if_icmplt -> 67
    //   49: aload_0
    //   50: aload_1
    //   51: getfield q : I
    //   54: aload_1
    //   55: getfield r : I
    //   58: aload_1
    //   59: getfield s : F
    //   62: f2d
    //   63: invokevirtual a : (IID)Z
    //   66: ireturn
    //   67: aload_1
    //   68: getfield q : I
    //   71: aload_1
    //   72: getfield r : I
    //   75: imul
    //   76: invokestatic b : ()I
    //   79: if_icmpgt -> 84
    //   82: iconst_1
    //   83: istore_2
    //   84: iload_2
    //   85: ifne -> 144
    //   88: new java/lang/StringBuilder
    //   91: dup
    //   92: invokespecial <init> : ()V
    //   95: astore #5
    //   97: aload #5
    //   99: ldc_w 'legacyFrameSize, '
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: aload #5
    //   108: aload_1
    //   109: getfield q : I
    //   112: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   115: pop
    //   116: aload #5
    //   118: ldc_w 'x'
    //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: pop
    //   125: aload #5
    //   127: aload_1
    //   128: getfield r : I
    //   131: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   134: pop
    //   135: aload_0
    //   136: aload #5
    //   138: invokevirtual toString : ()Ljava/lang/String;
    //   141: invokespecial a : (Ljava/lang/String;)V
    //   144: iload_2
    //   145: ireturn
    //   146: iconst_1
    //   147: ireturn
    //   148: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   151: bipush #21
    //   153: if_icmplt -> 198
    //   156: aload_1
    //   157: getfield z : I
    //   160: iconst_m1
    //   161: if_icmpeq -> 177
    //   164: iload_3
    //   165: istore_2
    //   166: aload_0
    //   167: aload_1
    //   168: getfield z : I
    //   171: invokevirtual a : (I)Z
    //   174: ifeq -> 200
    //   177: aload_1
    //   178: getfield y : I
    //   181: iconst_m1
    //   182: if_icmpeq -> 198
    //   185: iload_3
    //   186: istore_2
    //   187: aload_0
    //   188: aload_1
    //   189: getfield y : I
    //   192: invokevirtual b : (I)Z
    //   195: ifeq -> 200
    //   198: iconst_1
    //   199: istore_2
    //   200: iload_2
    //   201: ireturn
  }
  
  public MediaCodecInfo.CodecProfileLevel[] a() {
    MediaCodecInfo.CodecCapabilities codecCapabilities = this.d;
    return (codecCapabilities == null || codecCapabilities.profileLevels == null) ? new MediaCodecInfo.CodecProfileLevel[0] : this.d.profileLevels;
  }
  
  public boolean b() {
    if (ai.a >= 29 && "video/x-vnd.on2.vp9".equals(this.b)) {
      MediaCodecInfo.CodecProfileLevel[] arrayOfCodecProfileLevel = a();
      int k = arrayOfCodecProfileLevel.length;
      for (int j = 0; j < k; j++) {
        if ((arrayOfCodecProfileLevel[j]).profile == 16384)
          return true; 
      } 
    } 
    return false;
  }
  
  @RequiresApi(21)
  public boolean b(int paramInt) {
    MediaCodecInfo.CodecCapabilities codecCapabilities = this.d;
    if (codecCapabilities == null) {
      a("channelCount.caps");
      return false;
    } 
    MediaCodecInfo.AudioCapabilities audioCapabilities = codecCapabilities.getAudioCapabilities();
    if (audioCapabilities == null) {
      a("channelCount.aCaps");
      return false;
    } 
    if (a(this.a, this.b, audioCapabilities.getMaxInputChannelCount()) < paramInt) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("channelCount.support, ");
      stringBuilder.append(paramInt);
      a(stringBuilder.toString());
      return false;
    } 
    return true;
  }
  
  public boolean b(v paramv) {
    if (paramv.i != null) {
      if (this.b == null)
        return true; 
      String str = u.d(paramv.i);
      if (str == null)
        return true; 
      if (!this.b.equals(str)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("codec.mime ");
        stringBuilder1.append(paramv.i);
        stringBuilder1.append(", ");
        stringBuilder1.append(str);
        a(stringBuilder1.toString());
        return false;
      } 
      Pair<Integer, Integer> pair = l.a(paramv);
      if (pair == null)
        return true; 
      int k = ((Integer)pair.first).intValue();
      int m = ((Integer)pair.second).intValue();
      if (!this.k && k != 42)
        return true; 
      MediaCodecInfo.CodecProfileLevel[] arrayOfCodecProfileLevel2 = a();
      MediaCodecInfo.CodecProfileLevel[] arrayOfCodecProfileLevel1 = arrayOfCodecProfileLevel2;
      if (ai.a <= 23) {
        arrayOfCodecProfileLevel1 = arrayOfCodecProfileLevel2;
        if ("video/x-vnd.on2.vp9".equals(this.b)) {
          arrayOfCodecProfileLevel1 = arrayOfCodecProfileLevel2;
          if (arrayOfCodecProfileLevel2.length == 0)
            arrayOfCodecProfileLevel1 = g(this.d); 
        } 
      } 
      int n = arrayOfCodecProfileLevel1.length;
      for (int j = 0; j < n; j++) {
        MediaCodecInfo.CodecProfileLevel codecProfileLevel = arrayOfCodecProfileLevel1[j];
        if (codecProfileLevel.profile == k && codecProfileLevel.level >= m)
          return true; 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("codec.profileLevel, ");
      stringBuilder.append(paramv.i);
      stringBuilder.append(", ");
      stringBuilder.append(str);
      a(stringBuilder.toString());
      return false;
    } 
    return true;
  }
  
  public boolean c(v paramv) {
    if (this.k)
      return this.e; 
    Pair<Integer, Integer> pair = l.a(paramv);
    return (pair != null && ((Integer)pair.first).intValue() == 42);
  }
  
  public String toString() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */