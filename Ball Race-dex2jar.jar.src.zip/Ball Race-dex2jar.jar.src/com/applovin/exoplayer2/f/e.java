package com.applovin.exoplayer2.f;

import com.applovin.exoplayer2.b.r;
import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.l.a;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.v;
import java.nio.ByteBuffer;

final class e {
  private long a;
  
  private long b;
  
  private boolean c;
  
  private long a(long paramLong) {
    return this.a + Math.max(0L, (this.b - 529L) * 1000000L / paramLong);
  }
  
  public long a(v paramv) {
    return a(paramv.z);
  }
  
  public long a(v paramv, g paramg) {
    if (this.b == 0L)
      this.a = paramg.d; 
    if (this.c)
      return paramg.d; 
    ByteBuffer byteBuffer = (ByteBuffer)a.b(paramg.b);
    int i = 0;
    int j = 0;
    while (i < 4) {
      j = j << 8 | byteBuffer.get(i) & 0xFF;
      i++;
    } 
    i = r.b(j);
    if (i == -1) {
      this.c = true;
      this.b = 0L;
      this.a = paramg.d;
      q.c("C2Mp3TimestampTracker", "MPEG audio header is invalid.");
      return paramg.d;
    } 
    long l = a(paramv.z);
    this.b += i;
    return l;
  }
  
  public void a() {
    this.a = 0L;
    this.b = 0L;
    this.c = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */