package com.applovin.exoplayer2.f;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaCryptoException;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.SystemClock;
import androidx.annotation.CallSuper;
import androidx.annotation.CheckResult;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import com.applovin.exoplayer2.c.b;
import com.applovin.exoplayer2.c.e;
import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.c.h;
import com.applovin.exoplayer2.d.f;
import com.applovin.exoplayer2.d.n;
import com.applovin.exoplayer2.e;
import com.applovin.exoplayer2.h;
import com.applovin.exoplayer2.l.af;
import com.applovin.exoplayer2.l.ah;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.v;
import com.applovin.exoplayer2.p;
import com.applovin.exoplayer2.v;
import com.applovin.exoplayer2.w;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public abstract class j extends e {
  private static final byte[] b = new byte[] { 
      0, 0, 1, 103, 66, -64, 11, -38, 37, -112, 
      0, 0, 1, 104, -50, 15, 19, 32, 0, 0, 
      1, 101, -120, -124, 13, -50, 113, 24, -96, 0, 
      47, -65, 28, 49, -61, 39, 93, 120 };
  
  @Nullable
  private v A;
  
  @Nullable
  private MediaFormat B;
  
  private boolean C;
  
  private float D;
  
  @Nullable
  private ArrayDeque<i> E;
  
  @Nullable
  private a F;
  
  @Nullable
  private i G;
  
  private int H;
  
  private boolean I;
  
  private boolean J;
  
  private boolean K;
  
  private boolean L;
  
  private boolean M;
  
  private boolean N;
  
  private boolean O;
  
  private boolean P;
  
  private boolean Q;
  
  private boolean R;
  
  @Nullable
  private e S;
  
  private long T;
  
  private int U;
  
  private int V;
  
  @Nullable
  private ByteBuffer W;
  
  private boolean X;
  
  private boolean Y;
  
  private boolean Z;
  
  protected e a;
  
  private boolean aa;
  
  private boolean ab;
  
  private boolean ac;
  
  private int ad;
  
  private int ae;
  
  private int af;
  
  private boolean ag;
  
  private boolean ah;
  
  private boolean ai;
  
  private long aj;
  
  private long ak;
  
  private boolean al;
  
  private boolean am;
  
  private boolean an;
  
  private boolean ao;
  
  private boolean ap;
  
  private boolean aq;
  
  private boolean ar;
  
  @Nullable
  private p as;
  
  private long at;
  
  private long au;
  
  private int av;
  
  private final g.b c;
  
  private final k d;
  
  private final boolean e;
  
  private final float f;
  
  private final g g;
  
  private final g h;
  
  private final g i;
  
  private final d j;
  
  private final af<v> k;
  
  private final ArrayList<Long> l;
  
  private final MediaCodec.BufferInfo m;
  
  private final long[] n;
  
  private final long[] o;
  
  private final long[] p;
  
  @Nullable
  private v q;
  
  @Nullable
  private v r;
  
  @Nullable
  private f s;
  
  @Nullable
  private f t;
  
  @Nullable
  private MediaCrypto u;
  
  private boolean v;
  
  private long w;
  
  private float x;
  
  private float y;
  
  @Nullable
  private g z;
  
  public j(int paramInt, g.b paramb, k paramk, boolean paramBoolean, float paramFloat) {
    super(paramInt);
    this.c = paramb;
    this.d = (k)com.applovin.exoplayer2.l.a.b(paramk);
    this.e = paramBoolean;
    this.f = paramFloat;
    this.g = g.f();
    this.h = new g(0);
    this.i = new g(2);
    this.j = new d();
    this.k = new af();
    this.l = new ArrayList<Long>();
    this.m = new MediaCodec.BufferInfo();
    this.x = 1.0F;
    this.y = 1.0F;
    this.w = -9223372036854775807L;
    this.n = new long[10];
    this.o = new long[10];
    this.p = new long[10];
    this.at = -9223372036854775807L;
    this.au = -9223372036854775807L;
    this.j.f(0);
    this.j.b.order(ByteOrder.nativeOrder());
    this.D = -1.0F;
    this.H = 0;
    this.ad = 0;
    this.U = -1;
    this.V = -1;
    this.T = -9223372036854775807L;
    this.aj = -9223372036854775807L;
    this.ak = -9223372036854775807L;
    this.ae = 0;
    this.af = 0;
  }
  
  private void B() {
    this.ab = false;
    this.j.a();
    this.i.a();
    this.aa = false;
    this.Z = false;
  }
  
  private void R() {
    try {
      this.z.d();
      return;
    } finally {
      M();
    } 
  }
  
  private boolean S() {
    return (this.V >= 0);
  }
  
  private void T() {
    this.U = -1;
    this.h.b = null;
  }
  
  private void U() {
    this.V = -1;
    this.W = null;
  }
  
  private boolean V() throws p {
    g g1 = this.z;
    if (g1 != null && this.ae != 2) {
      if (this.al)
        return false; 
      if (this.U < 0) {
        this.U = g1.b();
        int n = this.U;
        if (n < 0)
          return false; 
        this.h.b = this.z.a(n);
        this.h.a();
      } 
      if (this.ae == 1) {
        if (!this.R) {
          this.ah = true;
          this.z.a(this.U, 0, 0, 0L, 4);
          T();
        } 
        this.ae = 2;
        return false;
      } 
      if (this.P) {
        this.P = false;
        this.h.b.put(b);
        this.z.a(this.U, 0, b.length, 0L, 0);
        T();
        this.ag = true;
        return true;
      } 
      if (this.ad == 1) {
        for (int n = 0; n < this.A.n.size(); n++) {
          byte[] arrayOfByte = this.A.n.get(n);
          this.h.b.put(arrayOfByte);
        } 
        this.ad = 2;
      } 
      int m = this.h.b.position();
      w w = t();
      try {
        int n = a(w, this.h, 0);
        if (g())
          this.ak = this.aj; 
        if (n == -3)
          return false; 
        if (n == -5) {
          if (this.ad == 2) {
            this.h.a();
            this.ad = 1;
          } 
          a(w);
          return true;
        } 
        if (this.h.c()) {
          if (this.ad == 2) {
            this.h.a();
            this.ad = 1;
          } 
          this.al = true;
          if (!this.ag) {
            aa();
            return false;
          } 
          try {
            if (this.R)
              return false; 
            this.ah = true;
            this.z.a(this.U, 0, 0, 0L, 4);
            T();
            return false;
          } catch (android.media.MediaCodec.CryptoException cryptoException) {
            throw a(cryptoException, this.q, h.b(cryptoException.getErrorCode()));
          } 
        } 
        if (!this.ag && !this.h.d()) {
          this.h.a();
          if (this.ad == 2)
            this.ad = 1; 
          return true;
        } 
        boolean bool = this.h.g();
        if (bool)
          this.h.a.a(m); 
        if (this.I && !bool) {
          v.a(this.h.b);
          if (this.h.b.position() == 0)
            return true; 
          this.I = false;
        } 
        long l = this.h.d;
        e e2 = this.S;
        if (e2 != null) {
          l = e2.a(this.q, this.h);
          this.aj = Math.max(this.aj, this.S.a(this.q));
        } 
        if (this.h.b())
          this.l.add(Long.valueOf(l)); 
        if (this.an) {
          this.k.a(l, this.q);
          this.an = false;
        } 
        this.aj = Math.max(this.aj, l);
        this.h.h();
        if (this.h.e())
          b(this.h); 
        a(this.h);
        if (bool)
          try {
            this.z.a(this.U, 0, this.h.a, l, 0);
            T();
            this.ag = true;
            this.ad = 0;
            e e3 = this.a;
            e3.c++;
            return true;
          } catch (android.media.MediaCodec.CryptoException cryptoException) {
            throw a(cryptoException, this.q, h.b(cryptoException.getErrorCode()));
          }  
        this.z.a(this.U, 0, this.h.b.limit(), l, 0);
        T();
        this.ag = true;
        this.ad = 0;
        e e1 = this.a;
        e1.c++;
        return true;
      } catch (com.applovin.exoplayer2.c.g.a a1) {
        a((Exception)a1);
        e(0);
        R();
        return true;
      } 
    } 
    return false;
  }
  
  private boolean W() {
    if (this.ag) {
      this.ae = 1;
      if (this.J || this.L) {
        this.af = 3;
        return false;
      } 
      this.af = 1;
      return true;
    } 
    return true;
  }
  
  @TargetApi(23)
  private boolean X() throws p {
    if (this.ag) {
      this.ae = 1;
      if (this.J || this.L) {
        this.af = 3;
        return false;
      } 
      this.af = 2;
      return true;
    } 
    ac();
    return true;
  }
  
  private void Y() throws p {
    if (this.ag) {
      this.ae = 1;
      this.af = 3;
      return;
    } 
    ab();
  }
  
  private void Z() {
    this.ai = true;
    MediaFormat mediaFormat = this.z.c();
    if (this.H != 0 && mediaFormat.getInteger("width") == 32 && mediaFormat.getInteger("height") == 32) {
      this.Q = true;
      return;
    } 
    if (this.O)
      mediaFormat.setInteger("channel-count", 1); 
    this.B = mediaFormat;
    this.C = true;
  }
  
  private void a(MediaCrypto paramMediaCrypto, boolean paramBoolean) throws a {
    if (this.E == null)
      try {
        List<i> list = d(paramBoolean);
        this.E = new ArrayDeque<i>();
        if (this.e) {
          this.E.addAll(list);
        } else if (!list.isEmpty()) {
          this.E.add(list.get(0));
        } 
        this.F = null;
      } catch (b b1) {
        throw new a(this.q, b1, paramBoolean, -49998);
      }  
    if (!this.E.isEmpty()) {
      while (this.z == null) {
        i i1 = this.E.peekFirst();
        if (!a(i1))
          return; 
        try {
          a(i1, (MediaCrypto)b1);
        } catch (Exception exception) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to initialize decoder: ");
          stringBuilder.append(i1);
          q.b("MediaCodecRenderer", stringBuilder.toString(), exception);
          this.E.removeFirst();
          a a1 = new a(this.q, exception, paramBoolean, i1);
          a(a1);
          exception = this.F;
          if (exception == null) {
            this.F = a1;
          } else {
            this.F = a.a((a)exception, a1);
          } 
          if (!this.E.isEmpty())
            continue; 
          throw this.F;
        } 
      } 
      this.E = null;
      return;
    } 
    throw new a(this.q, null, paramBoolean, -49999);
  }
  
  private void a(@Nullable f paramf) {
    f.-CC.a(this.t, paramf);
    this.t = paramf;
  }
  
  private void a(i parami, MediaCrypto paramMediaCrypto) throws Exception {
    g g1;
    float f1;
    String str = parami.a;
    if (ai.a < 23) {
      f1 = -1.0F;
    } else {
      f1 = a(this.y, this.q, u());
    } 
    float f2 = f1;
    if (f1 <= this.f)
      f2 = -1.0F; 
    long l1 = SystemClock.elapsedRealtime();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("createCodec:");
    stringBuilder.append(str);
    ah.a(stringBuilder.toString());
    g.a a1 = a(parami, this.q, paramMediaCrypto, f2);
    if (this.ap && ai.a >= 23) {
      g1 = (new a.a(a(), this.aq, this.ar)).a(a1);
    } else {
      g1 = this.c.b((g.a)g1);
    } 
    long l2 = SystemClock.elapsedRealtime();
    this.z = g1;
    this.G = parami;
    this.D = f2;
    this.A = this.q;
    this.H = c(str);
    this.I = a(str, this.A);
    this.J = b(str);
    this.K = d(str);
    this.L = e(str);
    this.M = g(str);
    this.N = f(str);
    this.O = b(str, this.A);
    boolean bool = b(parami);
    boolean bool1 = false;
    if (bool || F()) {
      bool = true;
    } else {
      bool = false;
    } 
    this.R = bool;
    if (g1.a()) {
      this.ac = true;
      this.ad = 1;
      bool = bool1;
      if (this.H != 0)
        bool = true; 
      this.P = bool;
    } 
    if ("c2.android.mp3.decoder".equals(parami.a))
      this.S = new e(); 
    if (d_() == 2)
      this.T = SystemClock.elapsedRealtime() + 1000L; 
    e e1 = this.a;
    e1.a++;
    a(str, l2, l2 - l1);
  }
  
  private boolean a(i parami, v paramv, @Nullable f paramf1, @Nullable f paramf2) throws p {
    if (paramf1 == paramf2)
      return false; 
    if (paramf2 != null) {
      if (paramf1 == null)
        return true; 
      if (ai.a < 23)
        return true; 
      if (!h.e.equals(paramf1.f())) {
        boolean bool;
        if (h.e.equals(paramf2.f()))
          return true; 
        n n = c(paramf2);
        if (n == null)
          return true; 
        if (n.d) {
          bool = false;
        } else {
          bool = paramf2.a(paramv.l);
        } 
        return (!parami.g && bool);
      } 
    } 
    return true;
  }
  
  private static boolean a(IllegalStateException paramIllegalStateException) {
    if (ai.a >= 21 && b(paramIllegalStateException))
      return true; 
    StackTraceElement[] arrayOfStackTraceElement = paramIllegalStateException.getStackTrace();
    return (arrayOfStackTraceElement.length > 0 && arrayOfStackTraceElement[0].getClassName().equals("android.media.MediaCodec"));
  }
  
  private static boolean a(String paramString, v paramv) {
    return (ai.a < 21 && paramv.n.isEmpty() && "OMX.MTK.VIDEO.DECODER.AVC".equals(paramString));
  }
  
  @TargetApi(23)
  private void aa() throws p {
    int m = this.af;
    if (m != 1) {
      if (m != 2) {
        if (m != 3) {
          this.am = true;
          D();
          return;
        } 
        ab();
        return;
      } 
      R();
      ac();
      return;
    } 
    R();
  }
  
  private void ab() throws p {
    J();
    E();
  }
  
  @RequiresApi(23)
  private void ac() throws p {
    try {
      this.u.setMediaDrmSession((c(this.t)).c);
      b(this.t);
      this.ae = 0;
      this.af = 0;
      return;
    } catch (MediaCryptoException mediaCryptoException) {
      throw a(mediaCryptoException, this.q, 6006);
    } 
  }
  
  private void ad() throws p {
    com.applovin.exoplayer2.l.a.b(this.al ^ true);
    w w = t();
    this.i.a();
    while (true) {
      this.i.a();
      int m = a(w, this.i, 0);
      if (m != -5) {
        if (m != -4) {
          if (m == -3)
            return; 
          throw new IllegalStateException();
        } 
        if (this.i.c()) {
          this.al = true;
          return;
        } 
        if (this.an) {
          this.r = (v)com.applovin.exoplayer2.l.a.b(this.q);
          a(this.r, (MediaFormat)null);
          this.an = false;
        } 
        this.i.h();
        if (!this.j.a(this.i)) {
          this.aa = true;
          return;
        } 
        continue;
      } 
      a(w);
      return;
    } 
  }
  
  private void b(@Nullable f paramf) {
    f.-CC.a(this.s, paramf);
    this.s = paramf;
  }
  
  private boolean b(long paramLong1, long paramLong2) throws p {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial S : ()Z
    //   4: ifne -> 350
    //   7: aload_0
    //   8: getfield M : Z
    //   11: ifeq -> 56
    //   14: aload_0
    //   15: getfield ah : Z
    //   18: ifeq -> 56
    //   21: aload_0
    //   22: getfield z : Lcom/applovin/exoplayer2/f/g;
    //   25: aload_0
    //   26: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   29: invokeinterface a : (Landroid/media/MediaCodec$BufferInfo;)I
    //   34: istore #5
    //   36: goto -> 71
    //   39: aload_0
    //   40: invokespecial aa : ()V
    //   43: aload_0
    //   44: getfield am : Z
    //   47: ifeq -> 54
    //   50: aload_0
    //   51: invokevirtual J : ()V
    //   54: iconst_0
    //   55: ireturn
    //   56: aload_0
    //   57: getfield z : Lcom/applovin/exoplayer2/f/g;
    //   60: aload_0
    //   61: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   64: invokeinterface a : (Landroid/media/MediaCodec$BufferInfo;)I
    //   69: istore #5
    //   71: iload #5
    //   73: ifge -> 117
    //   76: iload #5
    //   78: bipush #-2
    //   80: if_icmpne -> 89
    //   83: aload_0
    //   84: invokespecial Z : ()V
    //   87: iconst_1
    //   88: ireturn
    //   89: aload_0
    //   90: getfield R : Z
    //   93: ifeq -> 115
    //   96: aload_0
    //   97: getfield al : Z
    //   100: ifne -> 111
    //   103: aload_0
    //   104: getfield ae : I
    //   107: iconst_2
    //   108: if_icmpne -> 115
    //   111: aload_0
    //   112: invokespecial aa : ()V
    //   115: iconst_0
    //   116: ireturn
    //   117: aload_0
    //   118: getfield Q : Z
    //   121: ifeq -> 143
    //   124: aload_0
    //   125: iconst_0
    //   126: putfield Q : Z
    //   129: aload_0
    //   130: getfield z : Lcom/applovin/exoplayer2/f/g;
    //   133: iload #5
    //   135: iconst_0
    //   136: invokeinterface a : (IZ)V
    //   141: iconst_1
    //   142: ireturn
    //   143: aload_0
    //   144: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   147: getfield size : I
    //   150: ifne -> 171
    //   153: aload_0
    //   154: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   157: getfield flags : I
    //   160: iconst_4
    //   161: iand
    //   162: ifeq -> 171
    //   165: aload_0
    //   166: invokespecial aa : ()V
    //   169: iconst_0
    //   170: ireturn
    //   171: aload_0
    //   172: iload #5
    //   174: putfield V : I
    //   177: aload_0
    //   178: aload_0
    //   179: getfield z : Lcom/applovin/exoplayer2/f/g;
    //   182: iload #5
    //   184: invokeinterface b : (I)Ljava/nio/ByteBuffer;
    //   189: putfield W : Ljava/nio/ByteBuffer;
    //   192: aload_0
    //   193: getfield W : Ljava/nio/ByteBuffer;
    //   196: astore #11
    //   198: aload #11
    //   200: ifnull -> 239
    //   203: aload #11
    //   205: aload_0
    //   206: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   209: getfield offset : I
    //   212: invokevirtual position : (I)Ljava/nio/Buffer;
    //   215: pop
    //   216: aload_0
    //   217: getfield W : Ljava/nio/ByteBuffer;
    //   220: aload_0
    //   221: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   224: getfield offset : I
    //   227: aload_0
    //   228: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   231: getfield size : I
    //   234: iadd
    //   235: invokevirtual limit : (I)Ljava/nio/Buffer;
    //   238: pop
    //   239: aload_0
    //   240: getfield N : Z
    //   243: ifeq -> 294
    //   246: aload_0
    //   247: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   250: getfield presentationTimeUs : J
    //   253: lconst_0
    //   254: lcmp
    //   255: ifne -> 294
    //   258: aload_0
    //   259: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   262: getfield flags : I
    //   265: iconst_4
    //   266: iand
    //   267: ifeq -> 294
    //   270: aload_0
    //   271: getfield aj : J
    //   274: lstore #7
    //   276: lload #7
    //   278: ldc2_w -9223372036854775807
    //   281: lcmp
    //   282: ifeq -> 294
    //   285: aload_0
    //   286: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   289: lload #7
    //   291: putfield presentationTimeUs : J
    //   294: aload_0
    //   295: aload_0
    //   296: aload_0
    //   297: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   300: getfield presentationTimeUs : J
    //   303: invokespecial f : (J)Z
    //   306: putfield X : Z
    //   309: aload_0
    //   310: getfield ak : J
    //   313: aload_0
    //   314: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   317: getfield presentationTimeUs : J
    //   320: lcmp
    //   321: ifne -> 330
    //   324: iconst_1
    //   325: istore #9
    //   327: goto -> 333
    //   330: iconst_0
    //   331: istore #9
    //   333: aload_0
    //   334: iload #9
    //   336: putfield Y : Z
    //   339: aload_0
    //   340: aload_0
    //   341: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   344: getfield presentationTimeUs : J
    //   347: invokevirtual c : (J)V
    //   350: aload_0
    //   351: getfield M : Z
    //   354: ifeq -> 466
    //   357: aload_0
    //   358: getfield ah : Z
    //   361: ifeq -> 466
    //   364: aload_0
    //   365: getfield z : Lcom/applovin/exoplayer2/f/g;
    //   368: astore #11
    //   370: aload_0
    //   371: getfield W : Ljava/nio/ByteBuffer;
    //   374: astore #12
    //   376: aload_0
    //   377: getfield V : I
    //   380: istore #5
    //   382: aload_0
    //   383: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   386: getfield flags : I
    //   389: istore #6
    //   391: aload_0
    //   392: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   395: getfield presentationTimeUs : J
    //   398: lstore #7
    //   400: aload_0
    //   401: getfield X : Z
    //   404: istore #9
    //   406: aload_0
    //   407: getfield Y : Z
    //   410: istore #10
    //   412: aload_0
    //   413: getfield r : Lcom/applovin/exoplayer2/v;
    //   416: astore #13
    //   418: aload_0
    //   419: lload_1
    //   420: lload_3
    //   421: aload #11
    //   423: aload #12
    //   425: iload #5
    //   427: iload #6
    //   429: iconst_1
    //   430: lload #7
    //   432: iload #9
    //   434: iload #10
    //   436: aload #13
    //   438: invokevirtual a : (JJLcom/applovin/exoplayer2/f/g;Ljava/nio/ByteBuffer;IIIJZZLcom/applovin/exoplayer2/v;)Z
    //   441: istore #9
    //   443: goto -> 513
    //   446: goto -> 449
    //   449: aload_0
    //   450: invokespecial aa : ()V
    //   453: aload_0
    //   454: getfield am : Z
    //   457: ifeq -> 464
    //   460: aload_0
    //   461: invokevirtual J : ()V
    //   464: iconst_0
    //   465: ireturn
    //   466: aload_0
    //   467: lload_1
    //   468: lload_3
    //   469: aload_0
    //   470: getfield z : Lcom/applovin/exoplayer2/f/g;
    //   473: aload_0
    //   474: getfield W : Ljava/nio/ByteBuffer;
    //   477: aload_0
    //   478: getfield V : I
    //   481: aload_0
    //   482: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   485: getfield flags : I
    //   488: iconst_1
    //   489: aload_0
    //   490: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   493: getfield presentationTimeUs : J
    //   496: aload_0
    //   497: getfield X : Z
    //   500: aload_0
    //   501: getfield Y : Z
    //   504: aload_0
    //   505: getfield r : Lcom/applovin/exoplayer2/v;
    //   508: invokevirtual a : (JJLcom/applovin/exoplayer2/f/g;Ljava/nio/ByteBuffer;IIIJZZLcom/applovin/exoplayer2/v;)Z
    //   511: istore #9
    //   513: iload #9
    //   515: ifeq -> 565
    //   518: aload_0
    //   519: aload_0
    //   520: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   523: getfield presentationTimeUs : J
    //   526: invokevirtual d : (J)V
    //   529: aload_0
    //   530: getfield m : Landroid/media/MediaCodec$BufferInfo;
    //   533: getfield flags : I
    //   536: iconst_4
    //   537: iand
    //   538: ifeq -> 547
    //   541: iconst_1
    //   542: istore #5
    //   544: goto -> 550
    //   547: iconst_0
    //   548: istore #5
    //   550: aload_0
    //   551: invokespecial U : ()V
    //   554: iload #5
    //   556: ifne -> 561
    //   559: iconst_1
    //   560: ireturn
    //   561: aload_0
    //   562: invokespecial aa : ()V
    //   565: iconst_0
    //   566: ireturn
    //   567: astore #11
    //   569: goto -> 39
    //   572: astore #11
    //   574: goto -> 449
    //   577: astore #11
    //   579: goto -> 446
    // Exception table:
    //   from	to	target	type
    //   21	36	567	java/lang/IllegalStateException
    //   364	418	572	java/lang/IllegalStateException
    //   418	443	577	java/lang/IllegalStateException
  }
  
  private static boolean b(i parami) {
    String str = parami.a;
    return ((ai.a <= 25 && "OMX.rk.video_decoder.avc".equals(str)) || (ai.a <= 17 && "OMX.allwinner.video.decoder.avc".equals(str)) || (ai.a <= 29 && ("OMX.broadcom.video_decoder.tunnel".equals(str) || "OMX.broadcom.video_decoder.tunnel.secure".equals(str))) || ("Amazon".equals(ai.c) && "AFTS".equals(ai.d) && parami.g));
  }
  
  @RequiresApi(21)
  private static boolean b(IllegalStateException paramIllegalStateException) {
    return paramIllegalStateException instanceof MediaCodec.CodecException;
  }
  
  private static boolean b(String paramString) {
    return (ai.a < 18 || (ai.a == 18 && ("OMX.SEC.avc.dec".equals(paramString) || "OMX.SEC.avc.dec.secure".equals(paramString))) || (ai.a == 19 && ai.d.startsWith("SM-G800") && ("OMX.Exynos.avc.dec".equals(paramString) || "OMX.Exynos.avc.dec.secure".equals(paramString))));
  }
  
  private static boolean b(String paramString, v paramv) {
    return (ai.a <= 18 && paramv.y == 1 && "OMX.MTK.AUDIO.DECODER.MP3".equals(paramString));
  }
  
  private int c(String paramString) {
    return (ai.a <= 25 && "OMX.Exynos.avc.dec.secure".equals(paramString) && (ai.d.startsWith("SM-T585") || ai.d.startsWith("SM-A510") || ai.d.startsWith("SM-A520") || ai.d.startsWith("SM-J700"))) ? 2 : ((ai.a < 24 && ("OMX.Nvidia.h264.decode".equals(paramString) || "OMX.Nvidia.h264.decode.secure".equals(paramString)) && ("flounder".equals(ai.b) || "flounder_lte".equals(ai.b) || "grouper".equals(ai.b) || "tilapia".equals(ai.b))) ? 1 : 0);
  }
  
  @Nullable
  private n c(f paramf) throws p {
    b b1 = paramf.g();
    if (b1 == null || b1 instanceof n)
      return (n)b1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Expecting FrameworkCryptoConfig but found: ");
    stringBuilder.append(b1);
    throw a(new IllegalArgumentException(stringBuilder.toString()), this.q, 6001);
  }
  
  private boolean c(long paramLong1, long paramLong2) throws p {
    com.applovin.exoplayer2.l.a.b(this.am ^ true);
    if (this.j.l())
      if (a(paramLong1, paramLong2, (g)null, this.j.b, this.V, 0, this.j.k(), this.j.i(), this.j.b(), this.j.c(), this.r)) {
        d(this.j.j());
        this.j.a();
      } else {
        return false;
      }  
    boolean bool = false;
    if (this.al) {
      this.am = true;
      return false;
    } 
    if (this.aa) {
      com.applovin.exoplayer2.l.a.b(this.j.a(this.i));
      this.aa = false;
    } 
    if (this.ab) {
      if (this.j.l())
        return true; 
      B();
      this.ab = false;
      E();
      if (!this.Z)
        return false; 
    } 
    ad();
    if (this.j.l())
      this.j.h(); 
    if (this.j.l() || this.al || this.ab)
      bool = true; 
    return bool;
  }
  
  protected static boolean c(v paramv) {
    return (paramv.E == 0 || paramv.E == 2);
  }
  
  @RequiresApi(21)
  private static boolean c(IllegalStateException paramIllegalStateException) {
    return (paramIllegalStateException instanceof MediaCodec.CodecException) ? ((MediaCodec.CodecException)paramIllegalStateException).isRecoverable() : false;
  }
  
  private List<i> d(boolean paramBoolean) throws l.b {
    List<i> list2 = a(this.d, this.q, paramBoolean);
    List<i> list1 = list2;
    if (list2.isEmpty()) {
      list1 = list2;
      if (paramBoolean) {
        list2 = a(this.d, this.q, false);
        list1 = list2;
        if (!list2.isEmpty()) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Drm session requires secure decoder for ");
          stringBuilder.append(this.q.l);
          stringBuilder.append(", but no secure decoder available. Trying to proceed with ");
          stringBuilder.append(list2);
          stringBuilder.append(".");
          q.c("MediaCodecRenderer", stringBuilder.toString());
          list1 = list2;
        } 
      } 
    } 
    return list1;
  }
  
  private void d(v paramv) {
    B();
    String str = paramv.l;
    if (!"audio/mp4a-latm".equals(str) && !"audio/mpeg".equals(str) && !"audio/opus".equals(str)) {
      this.j.g(1);
    } else {
      this.j.g(32);
    } 
    this.Z = true;
  }
  
  private static boolean d(String paramString) {
    return (ai.a == 29 && "c2.android.aac.decoder".equals(paramString));
  }
  
  private boolean e(int paramInt) throws p {
    w w = t();
    this.g.a();
    paramInt = a(w, this.g, paramInt | 0x4);
    if (paramInt == -5) {
      a(w);
      return true;
    } 
    if (paramInt == -4 && this.g.c()) {
      this.al = true;
      aa();
    } 
    return false;
  }
  
  private boolean e(long paramLong) {
    return (this.w == -9223372036854775807L || SystemClock.elapsedRealtime() - paramLong < this.w);
  }
  
  private boolean e(v paramv) throws p {
    if (ai.a < 23)
      return true; 
    if (this.z != null && this.af != 3) {
      if (d_() == 0)
        return true; 
      float f1 = a(this.y, paramv, u());
      float f2 = this.D;
      if (f2 == f1)
        return true; 
      if (f1 == -1.0F) {
        Y();
        return false;
      } 
      if (f2 != -1.0F || f1 > this.f) {
        Bundle bundle = new Bundle();
        bundle.putFloat("operating-rate", f1);
        this.z.a(bundle);
        this.D = f1;
        return true;
      } 
      return true;
    } 
    return true;
  }
  
  private static boolean e(String paramString) {
    return ((ai.a <= 23 && "OMX.google.vorbis.decoder".equals(paramString)) || (ai.a <= 19 && ("hb2000".equals(ai.b) || "stvm8".equals(ai.b)) && ("OMX.amlogic.avc.decoder.awesome".equals(paramString) || "OMX.amlogic.avc.decoder.awesome.secure".equals(paramString))));
  }
  
  private boolean f(long paramLong) {
    int n = this.l.size();
    for (int m = 0; m < n; m++) {
      if (((Long)this.l.get(m)).longValue() == paramLong) {
        this.l.remove(m);
        return true;
      } 
    } 
    return false;
  }
  
  private static boolean f(String paramString) {
    return (ai.a < 21 && "OMX.SEC.mp3.dec".equals(paramString) && "samsung".equals(ai.c) && (ai.b.startsWith("baffin") || ai.b.startsWith("grand") || ai.b.startsWith("fortuna") || ai.b.startsWith("gprimelte") || ai.b.startsWith("j2y18lte") || ai.b.startsWith("ms01")));
  }
  
  private static boolean g(String paramString) {
    return (ai.a == 21 && "OMX.google.aac.decoder".equals(paramString));
  }
  
  public boolean A() {
    return this.am;
  }
  
  protected void C() {}
  
  protected void D() throws p {}
  
  protected final void E() throws p {
    if (this.z == null && !this.Z) {
      v v1 = this.q;
      if (v1 == null)
        return; 
      if (this.t == null && b(v1)) {
        d(this.q);
        return;
      } 
      b(this.t);
      String str = this.q.l;
      f f1 = this.s;
      if (f1 != null) {
        if (this.u == null) {
          n n = c(f1);
          if (n == null) {
            if (this.s.e() == null)
              return; 
          } else {
            try {
              boolean bool;
              this.u = new MediaCrypto(n.b, n.c);
              if (!n.d && this.u.requiresSecureDecoderComponent(str)) {
                bool = true;
              } else {
                bool = false;
              } 
              this.v = bool;
            } catch (MediaCryptoException mediaCryptoException) {
              throw a(mediaCryptoException, this.q, 6006);
            } 
          } 
        } 
        if (n.a) {
          int m = this.s.c();
          if (m != 1) {
            if (m != 4)
              return; 
          } else {
            f.a a1 = (f.a)com.applovin.exoplayer2.l.a.b(this.s.e());
            throw a(a1, this.q, a1.a);
          } 
        } 
      } 
      try {
        a(this.u, this.v);
        return;
      } catch (a a1) {
        throw a(a1, this.q, 4001);
      } 
    } 
  }
  
  protected boolean F() {
    return false;
  }
  
  @Nullable
  protected final g G() {
    return this.z;
  }
  
  @Nullable
  protected final MediaFormat H() {
    return this.B;
  }
  
  @Nullable
  protected final i I() {
    return this.G;
  }
  
  protected void J() {
    try {
      if (this.z != null) {
        this.z.e();
        e e1 = this.a;
        e1.b++;
        a(this.G.a);
      } 
    } finally {
      null = null;
      this.z = null;
    } 
  }
  
  protected final boolean K() throws p {
    boolean bool = L();
    if (bool)
      E(); 
    return bool;
  }
  
  protected boolean L() {
    if (this.z == null)
      return false; 
    if (this.af == 3 || this.J || (this.K && !this.ai) || (this.L && this.ah)) {
      J();
      return true;
    } 
    R();
    return false;
  }
  
  @CallSuper
  protected void M() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  @CallSuper
  protected void N() {
    M();
    this.as = null;
    this.S = null;
    this.E = null;
    this.G = null;
    this.A = null;
    this.B = null;
    this.C = false;
    this.ai = false;
    this.D = -1.0F;
    this.H = 0;
    this.I = false;
    this.J = false;
    this.K = false;
    this.L = false;
    this.M = false;
    this.N = false;
    this.O = false;
    this.R = false;
    this.ac = false;
    this.ad = 0;
    this.v = false;
  }
  
  protected float O() {
    return this.x;
  }
  
  protected final void P() {
    this.ao = true;
  }
  
  protected final long Q() {
    return this.au;
  }
  
  protected float a(float paramFloat, v paramv, v[] paramArrayOfv) {
    return -1.0F;
  }
  
  protected abstract int a(k paramk, v paramv) throws l.b;
  
  public final int a(v paramv) throws p {
    try {
      return a(this.d, paramv);
    } catch (b b1) {
      throw a(b1, paramv, 4002);
    } 
  }
  
  protected h a(i parami, v paramv1, v paramv2) {
    return new h(parami.a, paramv1, paramv2, 0, 1);
  }
  
  @CallSuper
  @Nullable
  protected h a(w paramw) throws p {
    // Byte code:
    //   0: iconst_1
    //   1: istore #5
    //   3: aload_0
    //   4: iconst_1
    //   5: putfield an : Z
    //   8: aload_1
    //   9: getfield b : Lcom/applovin/exoplayer2/v;
    //   12: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   15: checkcast com/applovin/exoplayer2/v
    //   18: astore #6
    //   20: aload #6
    //   22: getfield l : Ljava/lang/String;
    //   25: ifnull -> 458
    //   28: aload_0
    //   29: aload_1
    //   30: getfield a : Lcom/applovin/exoplayer2/d/f;
    //   33: invokespecial a : (Lcom/applovin/exoplayer2/d/f;)V
    //   36: aload_0
    //   37: aload #6
    //   39: putfield q : Lcom/applovin/exoplayer2/v;
    //   42: aload_0
    //   43: getfield Z : Z
    //   46: ifeq -> 56
    //   49: aload_0
    //   50: iconst_1
    //   51: putfield ab : Z
    //   54: aconst_null
    //   55: areturn
    //   56: aload_0
    //   57: getfield z : Lcom/applovin/exoplayer2/f/g;
    //   60: astore_1
    //   61: aload_1
    //   62: ifnonnull -> 76
    //   65: aload_0
    //   66: aconst_null
    //   67: putfield E : Ljava/util/ArrayDeque;
    //   70: aload_0
    //   71: invokevirtual E : ()V
    //   74: aconst_null
    //   75: areturn
    //   76: aload_0
    //   77: getfield G : Lcom/applovin/exoplayer2/f/i;
    //   80: astore #7
    //   82: aload_0
    //   83: getfield A : Lcom/applovin/exoplayer2/v;
    //   86: astore #8
    //   88: aload_0
    //   89: aload #7
    //   91: aload #6
    //   93: aload_0
    //   94: getfield s : Lcom/applovin/exoplayer2/d/f;
    //   97: aload_0
    //   98: getfield t : Lcom/applovin/exoplayer2/d/f;
    //   101: invokespecial a : (Lcom/applovin/exoplayer2/f/i;Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/d/f;Lcom/applovin/exoplayer2/d/f;)Z
    //   104: ifeq -> 132
    //   107: aload_0
    //   108: invokespecial Y : ()V
    //   111: new com/applovin/exoplayer2/c/h
    //   114: dup
    //   115: aload #7
    //   117: getfield a : Ljava/lang/String;
    //   120: aload #8
    //   122: aload #6
    //   124: iconst_0
    //   125: sipush #128
    //   128: invokespecial <init> : (Ljava/lang/String;Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/v;II)V
    //   131: areturn
    //   132: aload_0
    //   133: getfield t : Lcom/applovin/exoplayer2/d/f;
    //   136: aload_0
    //   137: getfield s : Lcom/applovin/exoplayer2/d/f;
    //   140: if_acmpeq -> 148
    //   143: iconst_1
    //   144: istore_2
    //   145: goto -> 150
    //   148: iconst_0
    //   149: istore_2
    //   150: iload_2
    //   151: ifeq -> 171
    //   154: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   157: bipush #23
    //   159: if_icmplt -> 165
    //   162: goto -> 171
    //   165: iconst_0
    //   166: istore #4
    //   168: goto -> 174
    //   171: iconst_1
    //   172: istore #4
    //   174: iload #4
    //   176: invokestatic b : (Z)V
    //   179: aload_0
    //   180: aload #7
    //   182: aload #8
    //   184: aload #6
    //   186: invokevirtual a : (Lcom/applovin/exoplayer2/f/i;Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/v;)Lcom/applovin/exoplayer2/c/h;
    //   189: astore #9
    //   191: aload #9
    //   193: getfield d : I
    //   196: istore_3
    //   197: iload_3
    //   198: ifeq -> 406
    //   201: iload_3
    //   202: iconst_1
    //   203: if_icmpeq -> 359
    //   206: iload_3
    //   207: iconst_2
    //   208: if_icmpeq -> 256
    //   211: iload_3
    //   212: iconst_3
    //   213: if_icmpne -> 248
    //   216: aload_0
    //   217: aload #6
    //   219: invokespecial e : (Lcom/applovin/exoplayer2/v;)Z
    //   222: ifne -> 228
    //   225: goto -> 368
    //   228: aload_0
    //   229: aload #6
    //   231: putfield A : Lcom/applovin/exoplayer2/v;
    //   234: iload_2
    //   235: ifeq -> 410
    //   238: aload_0
    //   239: invokespecial X : ()Z
    //   242: ifne -> 410
    //   245: goto -> 401
    //   248: new java/lang/IllegalStateException
    //   251: dup
    //   252: invokespecial <init> : ()V
    //   255: athrow
    //   256: aload_0
    //   257: aload #6
    //   259: invokespecial e : (Lcom/applovin/exoplayer2/v;)Z
    //   262: ifne -> 268
    //   265: goto -> 368
    //   268: aload_0
    //   269: iconst_1
    //   270: putfield ac : Z
    //   273: aload_0
    //   274: iconst_1
    //   275: putfield ad : I
    //   278: aload_0
    //   279: getfield H : I
    //   282: istore_3
    //   283: iload #5
    //   285: istore #4
    //   287: iload_3
    //   288: iconst_2
    //   289: if_icmpeq -> 333
    //   292: iload_3
    //   293: iconst_1
    //   294: if_icmpne -> 330
    //   297: aload #6
    //   299: getfield q : I
    //   302: aload #8
    //   304: getfield q : I
    //   307: if_icmpne -> 330
    //   310: aload #6
    //   312: getfield r : I
    //   315: aload #8
    //   317: getfield r : I
    //   320: if_icmpne -> 330
    //   323: iload #5
    //   325: istore #4
    //   327: goto -> 333
    //   330: iconst_0
    //   331: istore #4
    //   333: aload_0
    //   334: iload #4
    //   336: putfield P : Z
    //   339: aload_0
    //   340: aload #6
    //   342: putfield A : Lcom/applovin/exoplayer2/v;
    //   345: iload_2
    //   346: ifeq -> 410
    //   349: aload_0
    //   350: invokespecial X : ()Z
    //   353: ifne -> 410
    //   356: goto -> 401
    //   359: aload_0
    //   360: aload #6
    //   362: invokespecial e : (Lcom/applovin/exoplayer2/v;)Z
    //   365: ifne -> 374
    //   368: bipush #16
    //   370: istore_2
    //   371: goto -> 412
    //   374: aload_0
    //   375: aload #6
    //   377: putfield A : Lcom/applovin/exoplayer2/v;
    //   380: iload_2
    //   381: ifeq -> 394
    //   384: aload_0
    //   385: invokespecial X : ()Z
    //   388: ifne -> 410
    //   391: goto -> 401
    //   394: aload_0
    //   395: invokespecial W : ()Z
    //   398: ifne -> 410
    //   401: iconst_2
    //   402: istore_2
    //   403: goto -> 412
    //   406: aload_0
    //   407: invokespecial Y : ()V
    //   410: iconst_0
    //   411: istore_2
    //   412: aload #9
    //   414: getfield d : I
    //   417: ifeq -> 455
    //   420: aload_0
    //   421: getfield z : Lcom/applovin/exoplayer2/f/g;
    //   424: aload_1
    //   425: if_acmpne -> 436
    //   428: aload_0
    //   429: getfield af : I
    //   432: iconst_3
    //   433: if_icmpne -> 455
    //   436: new com/applovin/exoplayer2/c/h
    //   439: dup
    //   440: aload #7
    //   442: getfield a : Ljava/lang/String;
    //   445: aload #8
    //   447: aload #6
    //   449: iconst_0
    //   450: iload_2
    //   451: invokespecial <init> : (Ljava/lang/String;Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/v;II)V
    //   454: areturn
    //   455: aload #9
    //   457: areturn
    //   458: aload_0
    //   459: new java/lang/IllegalArgumentException
    //   462: dup
    //   463: invokespecial <init> : ()V
    //   466: aload #6
    //   468: sipush #4005
    //   471: invokevirtual a : (Ljava/lang/Throwable;Lcom/applovin/exoplayer2/v;I)Lcom/applovin/exoplayer2/p;
    //   474: athrow
  }
  
  @Nullable
  protected abstract g.a a(i parami, v paramv, @Nullable MediaCrypto paramMediaCrypto, float paramFloat);
  
  protected h a(Throwable paramThrowable, @Nullable i parami) {
    return new h(paramThrowable, parami);
  }
  
  protected abstract List<i> a(k paramk, v paramv, boolean paramBoolean) throws l.b;
  
  public void a(float paramFloat1, float paramFloat2) throws p {
    this.x = paramFloat1;
    this.y = paramFloat2;
    e(this.A);
  }
  
  public void a(long paramLong1, long paramLong2) throws p {
    if (this.ao) {
      this.ao = false;
      aa();
    } 
    p p1 = this.as;
    if (p1 == null) {
      boolean bool = true;
      try {
        if (this.am) {
          D();
          return;
        } 
        if (this.q == null && !e(2))
          return; 
        E();
        if (this.Z) {
          ah.a("bypassRender");
          while (c(paramLong1, paramLong2));
          ah.a();
        } else if (this.z != null) {
          long l = SystemClock.elapsedRealtime();
          ah.a("drainAndFeed");
          while (b(paramLong1, paramLong2) && e(l));
          while (V() && e(l));
          ah.a();
        } else {
          e e1 = this.a;
          e1.d += b(paramLong1);
          e(1);
        } 
        this.a.a();
        return;
      } catch (IllegalStateException illegalStateException) {
        if (a(illegalStateException)) {
          a(illegalStateException);
          if (ai.a < 21 || !c(illegalStateException))
            bool = false; 
          if (bool)
            J(); 
          throw a(a(illegalStateException, I()), this.q, bool, 4003);
        } 
        throw illegalStateException;
      } 
    } 
    this.as = null;
    throw illegalStateException;
  }
  
  protected void a(long paramLong, boolean paramBoolean) throws p {
    this.al = false;
    this.am = false;
    this.ao = false;
    if (this.Z) {
      this.j.a();
      this.i.a();
      this.aa = false;
    } else {
      K();
    } 
    if (this.k.b() > 0)
      this.an = true; 
    this.k.a();
    int m = this.av;
    if (m != 0) {
      this.au = this.o[m - 1];
      this.at = this.n[m - 1];
      this.av = 0;
    } 
  }
  
  protected void a(g paramg) throws p {}
  
  protected final void a(p paramp) {
    this.as = paramp;
  }
  
  protected void a(v paramv, @Nullable MediaFormat paramMediaFormat) throws p {}
  
  protected void a(Exception paramException) {}
  
  protected void a(String paramString) {}
  
  protected void a(String paramString, long paramLong1, long paramLong2) {}
  
  public void a(boolean paramBoolean) {
    this.ap = paramBoolean;
  }
  
  protected void a(boolean paramBoolean1, boolean paramBoolean2) throws p {
    this.a = new e();
  }
  
  protected void a(v[] paramArrayOfv, long paramLong1, long paramLong2) throws p {
    long l = this.au;
    boolean bool = true;
    if (l == -9223372036854775807L) {
      if (this.at != -9223372036854775807L)
        bool = false; 
      com.applovin.exoplayer2.l.a.b(bool);
      this.at = paramLong1;
      this.au = paramLong2;
      return;
    } 
    int m = this.av;
    if (m == this.o.length) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Too many stream changes, so dropping offset: ");
      stringBuilder.append(this.o[this.av - 1]);
      q.c("MediaCodecRenderer", stringBuilder.toString());
    } else {
      this.av = m + 1;
    } 
    long[] arrayOfLong = this.n;
    m = this.av;
    arrayOfLong[m - 1] = paramLong1;
    this.o[m - 1] = paramLong2;
    this.p[m - 1] = this.aj;
  }
  
  protected abstract boolean a(long paramLong1, long paramLong2, @Nullable g paramg, @Nullable ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, long paramLong3, boolean paramBoolean1, boolean paramBoolean2, v paramv) throws p;
  
  protected boolean a(i parami) {
    return true;
  }
  
  protected void b(g paramg) throws p {}
  
  public void b(boolean paramBoolean) {
    this.aq = paramBoolean;
  }
  
  protected boolean b(v paramv) {
    return false;
  }
  
  protected final void c(long paramLong) throws p {
    boolean bool;
    v v2 = (v)this.k.a(paramLong);
    v v1 = v2;
    if (v2 == null) {
      v1 = v2;
      if (this.C)
        v1 = (v)this.k.c(); 
    } 
    if (v1 != null) {
      this.r = v1;
      bool = true;
    } else {
      bool = false;
    } 
    if (bool || (this.C && this.r != null)) {
      a(this.r, this.B);
      this.C = false;
    } 
  }
  
  public void c(boolean paramBoolean) {
    this.ar = paramBoolean;
  }
  
  @CallSuper
  protected void d(long paramLong) {
    while (true) {
      int m = this.av;
      if (m != 0 && paramLong >= this.p[0]) {
        long[] arrayOfLong = this.n;
        this.at = arrayOfLong[0];
        this.au = this.o[0];
        this.av = m - 1;
        System.arraycopy(arrayOfLong, 1, arrayOfLong, 0, this.av);
        arrayOfLong = this.o;
        System.arraycopy(arrayOfLong, 1, arrayOfLong, 0, this.av);
        arrayOfLong = this.p;
        System.arraycopy(arrayOfLong, 1, arrayOfLong, 0, this.av);
        C();
        continue;
      } 
      break;
    } 
  }
  
  public final int o() {
    return 8;
  }
  
  protected void p() {}
  
  protected void q() {}
  
  protected void r() {
    this.q = null;
    this.at = -9223372036854775807L;
    this.au = -9223372036854775807L;
    this.av = 0;
    L();
  }
  
  protected void s() {
    try {
      B();
      J();
      return;
    } finally {
      a((f)null);
    } 
  }
  
  public boolean z() {
    return (this.q != null && (x() || S() || (this.T != -9223372036854775807L && SystemClock.elapsedRealtime() < this.T)));
  }
  
  public static class a extends Exception {
    public final String a;
    
    public final boolean b;
    
    @Nullable
    public final i c;
    
    @Nullable
    public final String d;
    
    @Nullable
    public final a e;
    
    public a(v param1v, @Nullable Throwable param1Throwable, boolean param1Boolean, int param1Int) {
      this(stringBuilder.toString(), param1Throwable, param1v.l, param1Boolean, (i)null, a(param1Int), (a)null);
    }
    
    public a(v param1v, @Nullable Throwable param1Throwable, boolean param1Boolean, i param1i) {
      this(str1, param1Throwable, str2, param1Boolean, param1i, (String)param1v, (a)null);
    }
    
    private a(String param1String1, @Nullable Throwable param1Throwable, String param1String2, boolean param1Boolean, @Nullable i param1i, @Nullable String param1String3, @Nullable a param1a) {
      super(param1String1, param1Throwable);
      this.a = param1String2;
      this.b = param1Boolean;
      this.c = param1i;
      this.d = param1String3;
      this.e = param1a;
    }
    
    @CheckResult
    private a a(a param1a) {
      return new a(getMessage(), getCause(), this.a, this.b, this.c, this.d, param1a);
    }
    
    private static String a(int param1Int) {
      String str;
      if (param1Int < 0) {
        str = "neg_";
      } else {
        str = "";
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("com.applovin.exoplayer2.mediacodec.MediaCodecRenderer_");
      stringBuilder.append(str);
      stringBuilder.append(Math.abs(param1Int));
      return stringBuilder.toString();
    }
    
    @Nullable
    @RequiresApi(21)
    private static String a(@Nullable Throwable param1Throwable) {
      return (param1Throwable instanceof MediaCodec.CodecException) ? ((MediaCodec.CodecException)param1Throwable).getDiagnosticInfo() : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */