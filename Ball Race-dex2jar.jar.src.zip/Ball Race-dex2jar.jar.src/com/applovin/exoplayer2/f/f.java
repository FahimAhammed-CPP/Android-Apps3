package com.applovin.exoplayer2.f;

import java.util.NoSuchElementException;

final class f {
  private int a = 0;
  
  private int b = -1;
  
  private int c = 0;
  
  private int[] d = new int[16];
  
  private int e = this.d.length - 1;
  
  private void d() {
    int[] arrayOfInt = this.d;
    int i = arrayOfInt.length << 1;
    if (i >= 0) {
      int[] arrayOfInt1 = new int[i];
      int j = arrayOfInt.length;
      i = this.a;
      j -= i;
      System.arraycopy(arrayOfInt, i, arrayOfInt1, 0, j);
      System.arraycopy(this.d, 0, arrayOfInt1, j, i);
      this.a = 0;
      this.b = this.c - 1;
      this.d = arrayOfInt1;
      this.e = this.d.length - 1;
      return;
    } 
    throw new IllegalStateException();
  }
  
  public int a() {
    int i = this.c;
    if (i != 0) {
      int[] arrayOfInt = this.d;
      int j = this.a;
      int k = arrayOfInt[j];
      this.a = j + 1 & this.e;
      this.c = i - 1;
      return k;
    } 
    throw new NoSuchElementException();
  }
  
  public void a(int paramInt) {
    if (this.c == this.d.length)
      d(); 
    this.b = this.b + 1 & this.e;
    this.d[this.b] = paramInt;
    this.c++;
  }
  
  public boolean b() {
    return (this.c == 0);
  }
  
  public void c() {
    this.a = 0;
    this.b = -1;
    this.c = 0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */