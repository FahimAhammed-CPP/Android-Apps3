package com.applovin.exoplayer2.f;

import android.media.MediaCodec;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import com.applovin.exoplayer2.c.c;
import com.applovin.exoplayer2.common.base.Ascii;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.g;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReference;

@RequiresApi(23)
class b {
  @GuardedBy("MESSAGE_PARAMS_INSTANCE_POOL")
  private static final ArrayDeque<a> a = new ArrayDeque<a>();
  
  private static final Object b = new Object();
  
  private final MediaCodec c;
  
  private final HandlerThread d;
  
  private Handler e;
  
  private final AtomicReference<RuntimeException> f;
  
  private final g g;
  
  private final boolean h;
  
  private boolean i;
  
  public b(MediaCodec paramMediaCodec, HandlerThread paramHandlerThread, boolean paramBoolean) {
    this(paramMediaCodec, paramHandlerThread, paramBoolean, new g());
  }
  
  @VisibleForTesting
  b(MediaCodec paramMediaCodec, HandlerThread paramHandlerThread, boolean paramBoolean, g paramg) {
    this.c = paramMediaCodec;
    this.d = paramHandlerThread;
    this.g = paramg;
    this.f = new AtomicReference<RuntimeException>();
    if (paramBoolean || i()) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.h = paramBoolean;
  }
  
  private void a(int paramInt1, int paramInt2, MediaCodec.CryptoInfo paramCryptoInfo, long paramLong, int paramInt3) {
    try {
      if (this.h)
        synchronized (b) {
          this.c.queueSecureInputBuffer(paramInt1, paramInt2, paramCryptoInfo, paramLong, paramInt3);
          return;
        }  
      this.c.queueSecureInputBuffer(paramInt1, paramInt2, paramCryptoInfo, paramLong, paramInt3);
      return;
    } catch (RuntimeException runtimeException) {
      a(runtimeException);
      return;
    } 
  }
  
  private void a(Message paramMessage) {
    a a;
    int i = paramMessage.what;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          a(new IllegalStateException(String.valueOf(paramMessage.what)));
        } else {
          this.g.a();
        } 
        paramMessage = null;
      } else {
        a = (a)paramMessage.obj;
        a(a.a, a.b, a.d, a.e, a.f);
      } 
    } else {
      a = (a)((Message)a).obj;
      b(a.a, a.b, a.c, a.e, a.f);
    } 
    if (a != null)
      a(a); 
  }
  
  private static void a(c paramc, MediaCodec.CryptoInfo paramCryptoInfo) {
    paramCryptoInfo.numSubSamples = paramc.f;
    paramCryptoInfo.numBytesOfClearData = a(paramc.d, paramCryptoInfo.numBytesOfClearData);
    paramCryptoInfo.numBytesOfEncryptedData = a(paramc.e, paramCryptoInfo.numBytesOfEncryptedData);
    paramCryptoInfo.key = (byte[])com.applovin.exoplayer2.l.a.b(a(paramc.b, paramCryptoInfo.key));
    paramCryptoInfo.iv = (byte[])com.applovin.exoplayer2.l.a.b(a(paramc.a, paramCryptoInfo.iv));
    paramCryptoInfo.mode = paramc.c;
    if (ai.a >= 24)
      paramCryptoInfo.setPattern(new MediaCodec.CryptoInfo.Pattern(paramc.g, paramc.h)); 
  }
  
  private static void a(a parama) {
    synchronized (a) {
      a.add(parama);
      return;
    } 
  }
  
  @Nullable
  private static byte[] a(@Nullable byte[] paramArrayOfbyte1, @Nullable byte[] paramArrayOfbyte2) {
    if (paramArrayOfbyte1 == null)
      return paramArrayOfbyte2; 
    if (paramArrayOfbyte2 == null || paramArrayOfbyte2.length < paramArrayOfbyte1.length)
      return Arrays.copyOf(paramArrayOfbyte1, paramArrayOfbyte1.length); 
    System.arraycopy(paramArrayOfbyte1, 0, paramArrayOfbyte2, 0, paramArrayOfbyte1.length);
    return paramArrayOfbyte2;
  }
  
  @Nullable
  private static int[] a(@Nullable int[] paramArrayOfint1, @Nullable int[] paramArrayOfint2) {
    if (paramArrayOfint1 == null)
      return paramArrayOfint2; 
    if (paramArrayOfint2 == null || paramArrayOfint2.length < paramArrayOfint1.length)
      return Arrays.copyOf(paramArrayOfint1, paramArrayOfint1.length); 
    System.arraycopy(paramArrayOfint1, 0, paramArrayOfint2, 0, paramArrayOfint1.length);
    return paramArrayOfint2;
  }
  
  private void b(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4) {
    try {
      this.c.queueInputBuffer(paramInt1, paramInt2, paramInt3, paramLong, paramInt4);
      return;
    } catch (RuntimeException runtimeException) {
      a(runtimeException);
      return;
    } 
  }
  
  private void e() {
    RuntimeException runtimeException = this.f.getAndSet(null);
    if (runtimeException == null)
      return; 
    throw runtimeException;
  }
  
  private void f() throws InterruptedException {
    ((Handler)ai.a(this.e)).removeCallbacksAndMessages(null);
    g();
    e();
  }
  
  private void g() throws InterruptedException {
    this.g.b();
    ((Handler)ai.a(this.e)).obtainMessage(2).sendToTarget();
    this.g.c();
  }
  
  private static a h() {
    synchronized (a) {
      if (a.isEmpty())
        return new a(); 
      return a.removeFirst();
    } 
  }
  
  private static boolean i() {
    String str = Ascii.toLowerCase(ai.c);
    return (str.contains("samsung") || str.contains("motorola"));
  }
  
  public void a() {
    if (!this.i) {
      this.d.start();
      this.e = new Handler(this, this.d.getLooper()) {
          public void handleMessage(Message param1Message) {
            b.a(this.a, param1Message);
          }
        };
      this.i = true;
    } 
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4) {
    e();
    a a = h();
    a.a(paramInt1, paramInt2, paramInt3, paramLong, paramInt4);
    ((Handler)ai.a(this.e)).obtainMessage(0, a).sendToTarget();
  }
  
  public void a(int paramInt1, int paramInt2, c paramc, long paramLong, int paramInt3) {
    e();
    a a = h();
    a.a(paramInt1, paramInt2, 0, paramLong, paramInt3);
    a(paramc, a.d);
    ((Handler)ai.a(this.e)).obtainMessage(1, a).sendToTarget();
  }
  
  @VisibleForTesting
  void a(RuntimeException paramRuntimeException) {
    this.f.set(paramRuntimeException);
  }
  
  public void b() {
    if (this.i)
      try {
        f();
        return;
      } catch (InterruptedException interruptedException) {
        Thread.currentThread().interrupt();
        throw new IllegalStateException(interruptedException);
      }  
  }
  
  public void c() {
    if (this.i) {
      b();
      this.d.quit();
    } 
    this.i = false;
  }
  
  public void d() throws InterruptedException {
    g();
  }
  
  private static class a {
    public int a;
    
    public int b;
    
    public int c;
    
    public final MediaCodec.CryptoInfo d = new MediaCodec.CryptoInfo();
    
    public long e;
    
    public int f;
    
    public void a(int param1Int1, int param1Int2, int param1Int3, long param1Long, int param1Int4) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1Int3;
      this.e = param1Long;
      this.f = param1Int4;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */