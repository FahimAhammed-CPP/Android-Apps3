package com.applovin.exoplayer2.f;

import android.media.MediaCodec;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import com.applovin.exoplayer2.c.f;
import com.applovin.exoplayer2.l.ai;

public class h extends f {
  @Nullable
  public final i a;
  
  @Nullable
  public final String b;
  
  public h(Throwable paramThrowable, @Nullable i parami) {
    super(stringBuilder.toString(), paramThrowable);
    String str1;
    String str2;
    this.a = parami;
    parami = i1;
    if (ai.a >= 21)
      str1 = a(paramThrowable); 
    this.b = str1;
  }
  
  @Nullable
  @RequiresApi(21)
  private static String a(Throwable paramThrowable) {
    return (paramThrowable instanceof MediaCodec.CodecException) ? ((MediaCodec.CodecException)paramThrowable).getDiagnosticInfo() : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */