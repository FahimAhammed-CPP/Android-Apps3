package com.applovin.exoplayer2.f;

import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.Handler;
import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import com.applovin.exoplayer2.v;
import java.io.IOException;
import java.nio.ByteBuffer;

public interface g {
  int a(MediaCodec.BufferInfo paramBufferInfo);
  
  @Nullable
  ByteBuffer a(int paramInt);
  
  void a(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4);
  
  void a(int paramInt1, int paramInt2, com.applovin.exoplayer2.c.c paramc, long paramLong, int paramInt3);
  
  @RequiresApi(21)
  void a(int paramInt, long paramLong);
  
  void a(int paramInt, boolean paramBoolean);
  
  @RequiresApi(19)
  void a(Bundle paramBundle);
  
  @RequiresApi(23)
  void a(Surface paramSurface);
  
  @RequiresApi(23)
  void a(c paramc, Handler paramHandler);
  
  boolean a();
  
  int b();
  
  @Nullable
  ByteBuffer b(int paramInt);
  
  MediaFormat c();
  
  void c(int paramInt);
  
  void d();
  
  void e();
  
  public static final class a {
    public final i a;
    
    public final MediaFormat b;
    
    public final v c;
    
    @Nullable
    public final Surface d;
    
    @Nullable
    public final MediaCrypto e;
    
    public final int f;
    
    public final boolean g;
    
    private a(i param1i, MediaFormat param1MediaFormat, v param1v, @Nullable Surface param1Surface, @Nullable MediaCrypto param1MediaCrypto, int param1Int, boolean param1Boolean) {
      this.a = param1i;
      this.b = param1MediaFormat;
      this.c = param1v;
      this.d = param1Surface;
      this.e = param1MediaCrypto;
      this.f = param1Int;
      this.g = param1Boolean;
    }
    
    public static a a(i param1i, MediaFormat param1MediaFormat, v param1v, @Nullable MediaCrypto param1MediaCrypto) {
      return new a(param1i, param1MediaFormat, param1v, null, param1MediaCrypto, 0, false);
    }
    
    public static a a(i param1i, MediaFormat param1MediaFormat, v param1v, @Nullable Surface param1Surface, @Nullable MediaCrypto param1MediaCrypto) {
      return new a(param1i, param1MediaFormat, param1v, param1Surface, param1MediaCrypto, 0, false);
    }
  }
  
  public static interface b {
    public static final b a = new m.b();
    
    g b(g.a param1a) throws IOException;
  }
  
  public static interface c {
    void a(g param1g, long param1Long1, long param1Long2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */