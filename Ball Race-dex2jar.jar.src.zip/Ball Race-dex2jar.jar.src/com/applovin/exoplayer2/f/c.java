package com.applovin.exoplayer2.f;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import com.applovin.exoplayer2.l.a;
import com.applovin.exoplayer2.l.ai;
import java.util.ArrayDeque;

@RequiresApi(23)
final class c extends MediaCodec.Callback {
  private final Object a = new Object();
  
  private final HandlerThread b;
  
  private Handler c;
  
  @GuardedBy("lock")
  private final f d;
  
  @GuardedBy("lock")
  private final f e;
  
  @GuardedBy("lock")
  private final ArrayDeque<MediaCodec.BufferInfo> f;
  
  @GuardedBy("lock")
  private final ArrayDeque<MediaFormat> g;
  
  @GuardedBy("lock")
  @Nullable
  private MediaFormat h;
  
  @GuardedBy("lock")
  @Nullable
  private MediaFormat i;
  
  @GuardedBy("lock")
  @Nullable
  private MediaCodec.CodecException j;
  
  @GuardedBy("lock")
  private long k;
  
  @GuardedBy("lock")
  private boolean l;
  
  @GuardedBy("lock")
  @Nullable
  private IllegalStateException m;
  
  c(HandlerThread paramHandlerThread) {
    this.b = paramHandlerThread;
    this.d = new f();
    this.e = new f();
    this.f = new ArrayDeque<MediaCodec.BufferInfo>();
    this.g = new ArrayDeque<MediaFormat>();
  }
  
  @GuardedBy("lock")
  private void a(MediaFormat paramMediaFormat) {
    this.e.a(-2);
    this.g.add(paramMediaFormat);
  }
  
  private void a(IllegalStateException paramIllegalStateException) {
    synchronized (this.a) {
      this.m = paramIllegalStateException;
      return;
    } 
  }
  
  private void b(Runnable paramRunnable) {
    synchronized (this.a) {
      c(paramRunnable);
      return;
    } 
  }
  
  @GuardedBy("lock")
  private void c(Runnable paramRunnable) {
    if (this.l)
      return; 
    long l = --this.k;
    if (l > 0L)
      return; 
    if (l < 0L) {
      a(new IllegalStateException());
      return;
    } 
    d();
    try {
      paramRunnable.run();
      return;
    } catch (IllegalStateException illegalStateException) {
      a(illegalStateException);
      return;
    } catch (Exception exception) {
      a(new IllegalStateException(exception));
      return;
    } 
  }
  
  @GuardedBy("lock")
  private void d() {
    if (!this.g.isEmpty())
      this.i = this.g.getLast(); 
    this.d.c();
    this.e.c();
    this.f.clear();
    this.g.clear();
    this.j = null;
  }
  
  @GuardedBy("lock")
  private boolean e() {
    return (this.k > 0L || this.l);
  }
  
  @GuardedBy("lock")
  private void f() {
    g();
    h();
  }
  
  @GuardedBy("lock")
  private void g() {
    IllegalStateException illegalStateException = this.m;
    if (illegalStateException == null)
      return; 
    this.m = null;
    throw illegalStateException;
  }
  
  @GuardedBy("lock")
  private void h() {
    MediaCodec.CodecException codecException = this.j;
    if (codecException == null)
      return; 
    this.j = null;
    throw codecException;
  }
  
  public int a(MediaCodec.BufferInfo paramBufferInfo) {
    synchronized (this.a) {
      if (e())
        return -1; 
      f();
      if (this.e.b())
        return -1; 
      int i = this.e.a();
      if (i >= 0) {
        a.a(this.h);
        MediaCodec.BufferInfo bufferInfo = this.f.remove();
        paramBufferInfo.set(bufferInfo.offset, bufferInfo.size, bufferInfo.presentationTimeUs, bufferInfo.flags);
      } else if (i == -2) {
        this.h = this.g.remove();
      } 
      return i;
    } 
  }
  
  public void a() {
    synchronized (this.a) {
      this.l = true;
      this.b.quit();
      d();
      return;
    } 
  }
  
  public void a(MediaCodec paramMediaCodec) {
    boolean bool;
    if (this.c == null) {
      bool = true;
    } else {
      bool = false;
    } 
    a.b(bool);
    this.b.start();
    Handler handler = new Handler(this.b.getLooper());
    paramMediaCodec.setCallback(this, handler);
    this.c = handler;
  }
  
  public void a(Runnable paramRunnable) {
    synchronized (this.a) {
      this.k++;
      ((Handler)ai.a(this.c)).post(new -$$Lambda$c$4S3CruBFZ4XbnSlnqttTRJyMIaA(this, paramRunnable));
      return;
    } 
  }
  
  public int b() {
    synchronized (this.a) {
      boolean bool = e();
      int i = -1;
      if (bool)
        return -1; 
      f();
      if (!this.d.b())
        i = this.d.a(); 
      return i;
    } 
  }
  
  public MediaFormat c() {
    synchronized (this.a) {
      if (this.h != null)
        return this.h; 
      throw new IllegalStateException();
    } 
  }
  
  public void onError(@NonNull MediaCodec paramMediaCodec, @NonNull MediaCodec.CodecException paramCodecException) {
    synchronized (this.a) {
      this.j = paramCodecException;
      return;
    } 
  }
  
  public void onInputBufferAvailable(@NonNull MediaCodec paramMediaCodec, int paramInt) {
    synchronized (this.a) {
      this.d.a(paramInt);
      return;
    } 
  }
  
  public void onOutputBufferAvailable(@NonNull MediaCodec paramMediaCodec, int paramInt, @NonNull MediaCodec.BufferInfo paramBufferInfo) {
    synchronized (this.a) {
      if (this.i != null) {
        a(this.i);
        this.i = null;
      } 
      this.e.a(paramInt);
      this.f.add(paramBufferInfo);
      return;
    } 
  }
  
  public void onOutputFormatChanged(@NonNull MediaCodec paramMediaCodec, @NonNull MediaFormat paramMediaFormat) {
    synchronized (this.a) {
      a(paramMediaFormat);
      this.i = null;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */