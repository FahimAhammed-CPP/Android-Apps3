package com.applovin.exoplayer2.f;

import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;
import com.applovin.exoplayer2.c.c;
import com.applovin.exoplayer2.common.base.Supplier;
import com.applovin.exoplayer2.l.ah;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Objects;

@RequiresApi(23)
final class a implements g {
  private final MediaCodec a;
  
  private final c b;
  
  private final b c;
  
  private final boolean d;
  
  private boolean e;
  
  private int f;
  
  @Nullable
  private Surface g;
  
  private a(MediaCodec paramMediaCodec, HandlerThread paramHandlerThread1, HandlerThread paramHandlerThread2, boolean paramBoolean1, boolean paramBoolean2) {
    this.a = paramMediaCodec;
    this.b = new c(paramHandlerThread1);
    this.c = new b(paramMediaCodec, paramHandlerThread2, paramBoolean1);
    this.d = paramBoolean2;
    this.f = 0;
  }
  
  private static String a(int paramInt, String paramString) {
    StringBuilder stringBuilder = new StringBuilder(paramString);
    if (paramInt == 1) {
      stringBuilder.append("Audio");
    } else if (paramInt == 2) {
      stringBuilder.append("Video");
    } else {
      stringBuilder.append("Unknown(");
      stringBuilder.append(paramInt);
      stringBuilder.append(")");
    } 
    return stringBuilder.toString();
  }
  
  private void a(@Nullable MediaFormat paramMediaFormat, @Nullable Surface paramSurface, @Nullable MediaCrypto paramMediaCrypto, int paramInt, boolean paramBoolean) {
    this.b.a(this.a);
    ah.a("configureCodec");
    this.a.configure(paramMediaFormat, paramSurface, paramMediaCrypto, paramInt);
    ah.a();
    if (paramBoolean)
      this.g = this.a.createInputSurface(); 
    this.c.a();
    ah.a("startCodec");
    this.a.start();
    ah.a();
    this.f = 1;
  }
  
  private static String f(int paramInt) {
    return a(paramInt, "ExoPlayer:MediaCodecAsyncAdapter:");
  }
  
  private void f() {
    if (this.d)
      try {
        this.c.d();
        return;
      } catch (InterruptedException interruptedException) {
        Thread.currentThread().interrupt();
        throw new IllegalStateException(interruptedException);
      }  
  }
  
  private static String g(int paramInt) {
    return a(paramInt, "ExoPlayer:MediaCodecQueueingThread:");
  }
  
  public int a(MediaCodec.BufferInfo paramBufferInfo) {
    return this.b.a(paramBufferInfo);
  }
  
  @Nullable
  public ByteBuffer a(int paramInt) {
    return this.a.getInputBuffer(paramInt);
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4) {
    this.c.a(paramInt1, paramInt2, paramInt3, paramLong, paramInt4);
  }
  
  public void a(int paramInt1, int paramInt2, c paramc, long paramLong, int paramInt3) {
    this.c.a(paramInt1, paramInt2, paramc, paramLong, paramInt3);
  }
  
  public void a(int paramInt, long paramLong) {
    this.a.releaseOutputBuffer(paramInt, paramLong);
  }
  
  public void a(int paramInt, boolean paramBoolean) {
    this.a.releaseOutputBuffer(paramInt, paramBoolean);
  }
  
  public void a(Bundle paramBundle) {
    f();
    this.a.setParameters(paramBundle);
  }
  
  public void a(Surface paramSurface) {
    f();
    this.a.setOutputSurface(paramSurface);
  }
  
  public void a(g.c paramc, Handler paramHandler) {
    f();
    this.a.setOnFrameRenderedListener((MediaCodec.OnFrameRenderedListener)new -$.Lambda.a.TuArWumklfgga5wf-obvpshEY1I(this, paramc), paramHandler);
  }
  
  public boolean a() {
    return false;
  }
  
  public int b() {
    return this.b.b();
  }
  
  @Nullable
  public ByteBuffer b(int paramInt) {
    return this.a.getOutputBuffer(paramInt);
  }
  
  public MediaFormat c() {
    return this.b.c();
  }
  
  public void c(int paramInt) {
    f();
    this.a.setVideoScalingMode(paramInt);
  }
  
  public void d() {
    this.c.b();
    this.a.flush();
    c c1 = this.b;
    MediaCodec mediaCodec = this.a;
    Objects.requireNonNull(mediaCodec);
    c1.a(new -$$Lambda$izPR8Lzfsy3-jbfJFz3Zg9j84Yw(mediaCodec));
  }
  
  public void e() {
    try {
      if (this.f == 1) {
        this.c.c();
        this.b.a();
      } 
      this.f = 2;
      return;
    } finally {
      Surface surface = this.g;
      if (surface != null)
        surface.release(); 
      if (!this.e) {
        this.a.release();
        this.e = true;
      } 
    } 
  }
  
  public static final class a implements g.b {
    private final Supplier<HandlerThread> b;
    
    private final Supplier<HandlerThread> c;
    
    private final boolean d;
    
    private final boolean e;
    
    public a(int param1Int, boolean param1Boolean1, boolean param1Boolean2) {
      this((Supplier<HandlerThread>)new -$.Lambda.a.a.OxSE-G6CLhYSiH4CwJ7O5hnesrA(param1Int), (Supplier<HandlerThread>)new -$.Lambda.a.a.gPmUCzPxf3uc78Yvq12vsrlgLMw(param1Int), param1Boolean1, param1Boolean2);
    }
    
    @VisibleForTesting
    a(Supplier<HandlerThread> param1Supplier1, Supplier<HandlerThread> param1Supplier2, boolean param1Boolean1, boolean param1Boolean2) {
      this.b = param1Supplier1;
      this.c = param1Supplier2;
      this.d = param1Boolean1;
      this.e = param1Boolean2;
    }
    
    public a a(g.a param1a) throws IOException {
      String str = param1a.a.a;
      a a1 = null;
      try {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("createCodec:");
        stringBuilder.append(str);
        ah.a(stringBuilder.toString());
        MediaCodec mediaCodec = MediaCodec.createByCodecName(str);
        try {
          a a2 = new a(mediaCodec, (HandlerThread)this.b.get(), (HandlerThread)this.c.get(), this.d, this.e);
          try {
            ah.a();
            a.a(a2, param1a.b, param1a.d, param1a.e, param1a.f, param1a.g);
            return a2;
          } catch (Exception null) {
            a1 = a2;
          } 
        } catch (Exception null) {}
      } catch (Exception exception) {
        str = null;
      } 
      if (a1 == null) {
        if (str != null)
          str.release(); 
      } else {
        a1.e();
      } 
      throw exception;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */