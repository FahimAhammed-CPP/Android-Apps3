package com.applovin.exoplayer2.f;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Bundle;
import android.os.Handler;
import android.view.Surface;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import com.applovin.exoplayer2.c.c;
import com.applovin.exoplayer2.l.ah;
import com.applovin.exoplayer2.l.ai;
import java.io.IOException;
import java.nio.ByteBuffer;

public class m implements g {
  private final MediaCodec a;
  
  @Nullable
  private final Surface b;
  
  @Nullable
  private ByteBuffer[] c;
  
  @Nullable
  private ByteBuffer[] d;
  
  private m(MediaCodec paramMediaCodec, @Nullable Surface paramSurface) {
    this.a = paramMediaCodec;
    this.b = paramSurface;
    if (ai.a < 21) {
      this.c = this.a.getInputBuffers();
      this.d = this.a.getOutputBuffers();
    } 
  }
  
  public int a(MediaCodec.BufferInfo paramBufferInfo) {
    while (true) {
      int i = this.a.dequeueOutputBuffer(paramBufferInfo, 0L);
      if (i == -3 && ai.a < 21)
        this.d = this.a.getOutputBuffers(); 
      if (i != -3)
        return i; 
    } 
  }
  
  @Nullable
  public ByteBuffer a(int paramInt) {
    return (ai.a >= 21) ? this.a.getInputBuffer(paramInt) : ((ByteBuffer[])ai.a(this.c))[paramInt];
  }
  
  public void a(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4) {
    this.a.queueInputBuffer(paramInt1, paramInt2, paramInt3, paramLong, paramInt4);
  }
  
  public void a(int paramInt1, int paramInt2, c paramc, long paramLong, int paramInt3) {
    this.a.queueSecureInputBuffer(paramInt1, paramInt2, paramc.a(), paramLong, paramInt3);
  }
  
  @RequiresApi(21)
  public void a(int paramInt, long paramLong) {
    this.a.releaseOutputBuffer(paramInt, paramLong);
  }
  
  public void a(int paramInt, boolean paramBoolean) {
    this.a.releaseOutputBuffer(paramInt, paramBoolean);
  }
  
  @RequiresApi(19)
  public void a(Bundle paramBundle) {
    this.a.setParameters(paramBundle);
  }
  
  @RequiresApi(23)
  public void a(Surface paramSurface) {
    this.a.setOutputSurface(paramSurface);
  }
  
  @RequiresApi(23)
  public void a(g.c paramc, Handler paramHandler) {
    this.a.setOnFrameRenderedListener((MediaCodec.OnFrameRenderedListener)new -$.Lambda.m.m_a0WHIOVy7SwO2idGJ7c3jfnI(this, paramc), paramHandler);
  }
  
  public boolean a() {
    return false;
  }
  
  public int b() {
    return this.a.dequeueInputBuffer(0L);
  }
  
  @Nullable
  public ByteBuffer b(int paramInt) {
    return (ai.a >= 21) ? this.a.getOutputBuffer(paramInt) : ((ByteBuffer[])ai.a(this.d))[paramInt];
  }
  
  public MediaFormat c() {
    return this.a.getOutputFormat();
  }
  
  public void c(int paramInt) {
    this.a.setVideoScalingMode(paramInt);
  }
  
  public void d() {
    this.a.flush();
  }
  
  public void e() {
    this.c = null;
    this.d = null;
    Surface surface = this.b;
    if (surface != null)
      surface.release(); 
    this.a.release();
  }
  
  @RequiresApi(18)
  private static final class a {
    public static Surface a(MediaCodec param1MediaCodec) {
      return param1MediaCodec.createInputSurface();
    }
  }
  
  public static class b implements g.b {
    protected MediaCodec a(g.a param1a) throws IOException {
      com.applovin.exoplayer2.l.a.b(param1a.a);
      String str = param1a.a.a;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("createCodec:");
      stringBuilder.append(str);
      ah.a(stringBuilder.toString());
      MediaCodec mediaCodec = MediaCodec.createByCodecName(str);
      ah.a();
      return mediaCodec;
    }
    
    @RequiresApi(16)
    public g b(g.a param1a) throws IOException {
      g.a a1;
      MediaCodec mediaCodec;
      m m = null;
      try {
        MediaCodec mediaCodec1 = a(param1a);
        try {
          ah.a("configureCodec");
          mediaCodec1.configure(param1a.b, param1a.d, param1a.e, param1a.f);
          ah.a();
          if (param1a.g) {
            if (ai.a >= 18) {
              Surface surface = m.a.a(mediaCodec1);
            } else {
              throw new IllegalStateException("Encoding from a surface is only supported on API 18 and up.");
            } 
          } else {
            param1a = null;
          } 
          try {
            ah.a("startCodec");
            mediaCodec1.start();
            ah.a();
            return new m(mediaCodec1, (Surface)param1a);
          } catch (IOException iOException) {
          
          } catch (RuntimeException runtimeException1) {}
          g.a a2 = param1a;
          runtimeException = runtimeException1;
          a1 = a2;
          mediaCodec = mediaCodec1;
        } catch (IOException iOException) {
          mediaCodec = mediaCodec1;
        } catch (RuntimeException null) {
          mediaCodec = mediaCodec1;
        } 
      } catch (IOException iOException) {
        mediaCodec = null;
      } catch (RuntimeException runtimeException) {}
      if (a1 != null)
        a1.release(); 
      if (mediaCodec != null)
        mediaCodec.release(); 
      throw runtimeException;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\f\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */