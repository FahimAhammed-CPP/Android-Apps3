package com.applovin.exoplayer2.m;

import android.os.Handler;
import android.os.SystemClock;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.c.e;
import com.applovin.exoplayer2.c.h;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.v;

public interface n {
  void a(int paramInt, long paramLong);
  
  void a(long paramLong, int paramInt);
  
  void a(e parame);
  
  void a(o paramo);
  
  void a(v paramv, @Nullable h paramh);
  
  void a(Exception paramException);
  
  void a(Object paramObject, long paramLong);
  
  void a(String paramString);
  
  void a(String paramString, long paramLong1, long paramLong2);
  
  @Deprecated
  void a_(v paramv);
  
  void b(e parame);
  
  public static final class a {
    @Nullable
    private final Handler a;
    
    @Nullable
    private final n b;
    
    public a(@Nullable Handler param1Handler, @Nullable n param1n) {
      if (param1n != null) {
        param1Handler = (Handler)com.applovin.exoplayer2.l.a.b(param1Handler);
      } else {
        param1Handler = null;
      } 
      this.a = param1Handler;
      this.b = param1n;
    }
    
    public void a(int param1Int, long param1Long) {
      Handler handler = this.a;
      if (handler != null)
        handler.post(new -$$Lambda$n$a$uicWCs3LnFPtQooiFPdCNp6FWJc(this, param1Int, param1Long)); 
    }
    
    public void a(long param1Long, int param1Int) {
      Handler handler = this.a;
      if (handler != null)
        handler.post(new -$$Lambda$n$a$1dGKUbwUDuUoYGchSduBnbOCTvw(this, param1Long, param1Int)); 
    }
    
    public void a(e param1e) {
      Handler handler = this.a;
      if (handler != null)
        handler.post(new -$$Lambda$n$a$qdNDmhZyhr5nZgSkD7BB0j1Og3c(this, param1e)); 
    }
    
    public void a(o param1o) {
      Handler handler = this.a;
      if (handler != null)
        handler.post(new -$$Lambda$n$a$wb2tA-1ZkvAI7GcEc6FDVzVPOSg(this, param1o)); 
    }
    
    public void a(v param1v, @Nullable h param1h) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new -$.Lambda.n.a.j9WMFs3y0X55AnI8Fq96NV2ypXU(this, param1v, param1h)); 
    }
    
    public void a(Exception param1Exception) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new -$.Lambda.n.a.NjZlClqG7ybA-UgTaZ4IaFc3Ctk(this, param1Exception)); 
    }
    
    public void a(Object param1Object) {
      if (this.a != null) {
        long l = SystemClock.elapsedRealtime();
        this.a.post((Runnable)new -$.Lambda.n.a.pna9fVaTVDmCriC3REXO8XmgJo(this, param1Object, l));
      } 
    }
    
    public void a(String param1String) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new -$.Lambda.n.a.WXsHwt1n-VGot16ubVBOamdodKo(this, param1String)); 
    }
    
    public void a(String param1String, long param1Long1, long param1Long2) {
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new -$.Lambda.n.a.hQRJrGyG2rBN8s9Pt1sAsLRZ5Y(this, param1String, param1Long1, param1Long2)); 
    }
    
    public void b(e param1e) {
      param1e.a();
      Handler handler = this.a;
      if (handler != null)
        handler.post((Runnable)new -$.Lambda.n.a.xeP6kdbKtTCpvJjRXYX-96EZhyU(this, param1e)); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\m\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */