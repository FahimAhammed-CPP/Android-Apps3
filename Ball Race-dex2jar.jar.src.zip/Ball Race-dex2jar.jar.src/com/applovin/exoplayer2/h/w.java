package com.applovin.exoplayer2.h;

import android.os.Looper;
import androidx.annotation.CallSuper;
import androidx.annotation.GuardedBy;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.d.e;
import com.applovin.exoplayer2.d.f;
import com.applovin.exoplayer2.d.g;
import com.applovin.exoplayer2.d.h;
import com.applovin.exoplayer2.e.x;
import com.applovin.exoplayer2.k.g;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.h;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.y;
import com.applovin.exoplayer2.v;
import java.io.IOException;

public class w implements x {
  private boolean A;
  
  @Nullable
  private v B;
  
  @Nullable
  private v C;
  
  private int D;
  
  private boolean E;
  
  private boolean F;
  
  private long G;
  
  private boolean H;
  
  private final v a;
  
  private final a b;
  
  private final ab<b> c;
  
  @Nullable
  private final h d;
  
  @Nullable
  private final g.a e;
  
  @Nullable
  private final Looper f;
  
  @Nullable
  private c g;
  
  @Nullable
  private v h;
  
  @Nullable
  private f i;
  
  private int j;
  
  private int[] k;
  
  private long[] l;
  
  private int[] m;
  
  private int[] n;
  
  private long[] o;
  
  private x.a[] p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private int t;
  
  private long u;
  
  private long v;
  
  private long w;
  
  private boolean x;
  
  private boolean y;
  
  private boolean z;
  
  protected w(com.applovin.exoplayer2.k.b paramb, @Nullable Looper paramLooper, @Nullable h paramh, @Nullable g.a parama) {
    this.f = paramLooper;
    this.d = paramh;
    this.e = parama;
    this.a = new v(paramb);
    this.b = new a();
    this.j = 1000;
    int i = this.j;
    this.k = new int[i];
    this.l = new long[i];
    this.o = new long[i];
    this.n = new int[i];
    this.m = new int[i];
    this.p = new x.a[i];
    this.c = new ab<b>((h<b>)-$.Lambda.w.ZgqdAvo8Ssoldu4N7_nka4oiy6s.INSTANCE);
    this.u = Long.MIN_VALUE;
    this.v = Long.MIN_VALUE;
    this.w = Long.MIN_VALUE;
    this.z = true;
    this.y = true;
  }
  
  private int a(int paramInt1, int paramInt2, long paramLong, boolean paramBoolean) {
    int i = paramInt1;
    paramInt1 = 0;
    int j = -1;
    while (paramInt1 < paramInt2 && this.o[i] <= paramLong) {
      if (!paramBoolean || (this.n[i] & 0x1) != 0) {
        if (this.o[i] == paramLong)
          return paramInt1; 
        j = paramInt1;
      } 
      int k = i + 1;
      i = k;
      if (k == this.j)
        i = 0; 
      paramInt1++;
    } 
    return j;
  }
  
  private int a(com.applovin.exoplayer2.w paramw, g paramg, boolean paramBoolean1, boolean paramBoolean2, a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_2
    //   3: iconst_0
    //   4: putfield c : Z
    //   7: aload_0
    //   8: invokespecial o : ()Z
    //   11: ifne -> 86
    //   14: iload #4
    //   16: ifne -> 76
    //   19: aload_0
    //   20: getfield x : Z
    //   23: ifeq -> 29
    //   26: goto -> 76
    //   29: aload_0
    //   30: getfield C : Lcom/applovin/exoplayer2/v;
    //   33: ifnull -> 71
    //   36: iload_3
    //   37: ifne -> 51
    //   40: aload_0
    //   41: getfield C : Lcom/applovin/exoplayer2/v;
    //   44: aload_0
    //   45: getfield h : Lcom/applovin/exoplayer2/v;
    //   48: if_acmpeq -> 71
    //   51: aload_0
    //   52: aload_0
    //   53: getfield C : Lcom/applovin/exoplayer2/v;
    //   56: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   59: checkcast com/applovin/exoplayer2/v
    //   62: aload_1
    //   63: invokespecial a : (Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/w;)V
    //   66: aload_0
    //   67: monitorexit
    //   68: bipush #-5
    //   70: ireturn
    //   71: aload_0
    //   72: monitorexit
    //   73: bipush #-3
    //   75: ireturn
    //   76: aload_2
    //   77: iconst_4
    //   78: invokevirtual a_ : (I)V
    //   81: aload_0
    //   82: monitorexit
    //   83: bipush #-4
    //   85: ireturn
    //   86: aload_0
    //   87: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   90: aload_0
    //   91: invokevirtual f : ()I
    //   94: invokevirtual a : (I)Ljava/lang/Object;
    //   97: checkcast com/applovin/exoplayer2/h/w$b
    //   100: getfield a : Lcom/applovin/exoplayer2/v;
    //   103: astore #7
    //   105: iload_3
    //   106: ifne -> 231
    //   109: aload #7
    //   111: aload_0
    //   112: getfield h : Lcom/applovin/exoplayer2/v;
    //   115: if_acmpeq -> 121
    //   118: goto -> 231
    //   121: aload_0
    //   122: aload_0
    //   123: getfield t : I
    //   126: invokespecial f : (I)I
    //   129: istore #6
    //   131: aload_0
    //   132: iload #6
    //   134: invokespecial c : (I)Z
    //   137: ifne -> 150
    //   140: aload_2
    //   141: iconst_1
    //   142: putfield c : Z
    //   145: aload_0
    //   146: monitorexit
    //   147: bipush #-3
    //   149: ireturn
    //   150: aload_2
    //   151: aload_0
    //   152: getfield n : [I
    //   155: iload #6
    //   157: iaload
    //   158: invokevirtual a_ : (I)V
    //   161: aload_2
    //   162: aload_0
    //   163: getfield o : [J
    //   166: iload #6
    //   168: laload
    //   169: putfield d : J
    //   172: aload_2
    //   173: getfield d : J
    //   176: aload_0
    //   177: getfield u : J
    //   180: lcmp
    //   181: ifge -> 190
    //   184: aload_2
    //   185: ldc -2147483648
    //   187: invokevirtual b : (I)V
    //   190: aload #5
    //   192: aload_0
    //   193: getfield m : [I
    //   196: iload #6
    //   198: iaload
    //   199: putfield a : I
    //   202: aload #5
    //   204: aload_0
    //   205: getfield l : [J
    //   208: iload #6
    //   210: laload
    //   211: putfield b : J
    //   214: aload #5
    //   216: aload_0
    //   217: getfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   220: iload #6
    //   222: aaload
    //   223: putfield c : Lcom/applovin/exoplayer2/e/x$a;
    //   226: aload_0
    //   227: monitorexit
    //   228: bipush #-4
    //   230: ireturn
    //   231: aload_0
    //   232: aload #7
    //   234: aload_1
    //   235: invokespecial a : (Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/w;)V
    //   238: aload_0
    //   239: monitorexit
    //   240: bipush #-5
    //   242: ireturn
    //   243: astore_1
    //   244: aload_0
    //   245: monitorexit
    //   246: aload_1
    //   247: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	243	finally
    //   19	26	243	finally
    //   29	36	243	finally
    //   40	51	243	finally
    //   51	66	243	finally
    //   76	81	243	finally
    //   86	105	243	finally
    //   109	118	243	finally
    //   121	145	243	finally
    //   150	190	243	finally
    //   190	226	243	finally
    //   231	238	243	finally
  }
  
  public static w a(com.applovin.exoplayer2.k.b paramb, Looper paramLooper, h paramh, g.a parama) {
    return new w(paramb, (Looper)com.applovin.exoplayer2.l.a.b(paramLooper), (h)com.applovin.exoplayer2.l.a.b(paramh), (g.a)com.applovin.exoplayer2.l.a.b(parama));
  }
  
  private void a(long paramLong1, int paramInt1, long paramLong2, int paramInt2, @Nullable x.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : I
    //   6: ifle -> 567
    //   9: aload_0
    //   10: aload_0
    //   11: getfield q : I
    //   14: iconst_1
    //   15: isub
    //   16: invokespecial f : (I)I
    //   19: istore #8
    //   21: aload_0
    //   22: getfield l : [J
    //   25: iload #8
    //   27: laload
    //   28: aload_0
    //   29: getfield m : [I
    //   32: iload #8
    //   34: iaload
    //   35: i2l
    //   36: ladd
    //   37: lload #4
    //   39: lcmp
    //   40: ifgt -> 561
    //   43: iconst_1
    //   44: istore #9
    //   46: goto -> 49
    //   49: iload #9
    //   51: invokestatic a : (Z)V
    //   54: goto -> 567
    //   57: aload_0
    //   58: iload #9
    //   60: putfield x : Z
    //   63: aload_0
    //   64: aload_0
    //   65: getfield w : J
    //   68: lload_1
    //   69: invokestatic max : (JJ)J
    //   72: putfield w : J
    //   75: aload_0
    //   76: aload_0
    //   77: getfield q : I
    //   80: invokespecial f : (I)I
    //   83: istore #8
    //   85: aload_0
    //   86: getfield o : [J
    //   89: iload #8
    //   91: lload_1
    //   92: lastore
    //   93: aload_0
    //   94: getfield l : [J
    //   97: iload #8
    //   99: lload #4
    //   101: lastore
    //   102: aload_0
    //   103: getfield m : [I
    //   106: iload #8
    //   108: iload #6
    //   110: iastore
    //   111: aload_0
    //   112: getfield n : [I
    //   115: iload #8
    //   117: iload_3
    //   118: iastore
    //   119: aload_0
    //   120: getfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   123: iload #8
    //   125: aload #7
    //   127: aastore
    //   128: aload_0
    //   129: getfield k : [I
    //   132: iload #8
    //   134: aload_0
    //   135: getfield D : I
    //   138: iastore
    //   139: aload_0
    //   140: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   143: invokevirtual c : ()Z
    //   146: ifne -> 172
    //   149: aload_0
    //   150: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   153: invokevirtual a : ()Ljava/lang/Object;
    //   156: checkcast com/applovin/exoplayer2/h/w$b
    //   159: getfield a : Lcom/applovin/exoplayer2/v;
    //   162: aload_0
    //   163: getfield C : Lcom/applovin/exoplayer2/v;
    //   166: invokevirtual equals : (Ljava/lang/Object;)Z
    //   169: ifne -> 247
    //   172: aload_0
    //   173: getfield d : Lcom/applovin/exoplayer2/d/h;
    //   176: ifnull -> 211
    //   179: aload_0
    //   180: getfield d : Lcom/applovin/exoplayer2/d/h;
    //   183: aload_0
    //   184: getfield f : Landroid/os/Looper;
    //   187: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   190: checkcast android/os/Looper
    //   193: aload_0
    //   194: getfield e : Lcom/applovin/exoplayer2/d/g$a;
    //   197: aload_0
    //   198: getfield C : Lcom/applovin/exoplayer2/v;
    //   201: invokeinterface a : (Landroid/os/Looper;Lcom/applovin/exoplayer2/d/g$a;Lcom/applovin/exoplayer2/v;)Lcom/applovin/exoplayer2/d/h$a;
    //   206: astore #7
    //   208: goto -> 216
    //   211: getstatic com/applovin/exoplayer2/d/h$a.b : Lcom/applovin/exoplayer2/d/h$a;
    //   214: astore #7
    //   216: aload_0
    //   217: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   220: aload_0
    //   221: invokevirtual c : ()I
    //   224: new com/applovin/exoplayer2/h/w$b
    //   227: dup
    //   228: aload_0
    //   229: getfield C : Lcom/applovin/exoplayer2/v;
    //   232: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   235: checkcast com/applovin/exoplayer2/v
    //   238: aload #7
    //   240: aconst_null
    //   241: invokespecial <init> : (Lcom/applovin/exoplayer2/v;Lcom/applovin/exoplayer2/d/h$a;Lcom/applovin/exoplayer2/h/w$1;)V
    //   244: invokevirtual a : (ILjava/lang/Object;)V
    //   247: aload_0
    //   248: aload_0
    //   249: getfield q : I
    //   252: iconst_1
    //   253: iadd
    //   254: putfield q : I
    //   257: aload_0
    //   258: getfield q : I
    //   261: aload_0
    //   262: getfield j : I
    //   265: if_icmpne -> 551
    //   268: aload_0
    //   269: getfield j : I
    //   272: sipush #1000
    //   275: iadd
    //   276: istore_3
    //   277: iload_3
    //   278: newarray int
    //   280: astore #7
    //   282: iload_3
    //   283: newarray long
    //   285: astore #10
    //   287: iload_3
    //   288: newarray long
    //   290: astore #11
    //   292: iload_3
    //   293: newarray int
    //   295: astore #12
    //   297: iload_3
    //   298: newarray int
    //   300: astore #13
    //   302: iload_3
    //   303: anewarray com/applovin/exoplayer2/e/x$a
    //   306: astore #14
    //   308: aload_0
    //   309: getfield j : I
    //   312: aload_0
    //   313: getfield s : I
    //   316: isub
    //   317: istore #6
    //   319: aload_0
    //   320: getfield l : [J
    //   323: aload_0
    //   324: getfield s : I
    //   327: aload #10
    //   329: iconst_0
    //   330: iload #6
    //   332: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   335: aload_0
    //   336: getfield o : [J
    //   339: aload_0
    //   340: getfield s : I
    //   343: aload #11
    //   345: iconst_0
    //   346: iload #6
    //   348: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   351: aload_0
    //   352: getfield n : [I
    //   355: aload_0
    //   356: getfield s : I
    //   359: aload #12
    //   361: iconst_0
    //   362: iload #6
    //   364: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   367: aload_0
    //   368: getfield m : [I
    //   371: aload_0
    //   372: getfield s : I
    //   375: aload #13
    //   377: iconst_0
    //   378: iload #6
    //   380: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   383: aload_0
    //   384: getfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   387: aload_0
    //   388: getfield s : I
    //   391: aload #14
    //   393: iconst_0
    //   394: iload #6
    //   396: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   399: aload_0
    //   400: getfield k : [I
    //   403: aload_0
    //   404: getfield s : I
    //   407: aload #7
    //   409: iconst_0
    //   410: iload #6
    //   412: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   415: aload_0
    //   416: getfield s : I
    //   419: istore #8
    //   421: aload_0
    //   422: getfield l : [J
    //   425: iconst_0
    //   426: aload #10
    //   428: iload #6
    //   430: iload #8
    //   432: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   435: aload_0
    //   436: getfield o : [J
    //   439: iconst_0
    //   440: aload #11
    //   442: iload #6
    //   444: iload #8
    //   446: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   449: aload_0
    //   450: getfield n : [I
    //   453: iconst_0
    //   454: aload #12
    //   456: iload #6
    //   458: iload #8
    //   460: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   463: aload_0
    //   464: getfield m : [I
    //   467: iconst_0
    //   468: aload #13
    //   470: iload #6
    //   472: iload #8
    //   474: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   477: aload_0
    //   478: getfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   481: iconst_0
    //   482: aload #14
    //   484: iload #6
    //   486: iload #8
    //   488: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   491: aload_0
    //   492: getfield k : [I
    //   495: iconst_0
    //   496: aload #7
    //   498: iload #6
    //   500: iload #8
    //   502: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   505: aload_0
    //   506: aload #10
    //   508: putfield l : [J
    //   511: aload_0
    //   512: aload #11
    //   514: putfield o : [J
    //   517: aload_0
    //   518: aload #12
    //   520: putfield n : [I
    //   523: aload_0
    //   524: aload #13
    //   526: putfield m : [I
    //   529: aload_0
    //   530: aload #14
    //   532: putfield p : [Lcom/applovin/exoplayer2/e/x$a;
    //   535: aload_0
    //   536: aload #7
    //   538: putfield k : [I
    //   541: aload_0
    //   542: iconst_0
    //   543: putfield s : I
    //   546: aload_0
    //   547: iload_3
    //   548: putfield j : I
    //   551: aload_0
    //   552: monitorexit
    //   553: return
    //   554: astore #7
    //   556: aload_0
    //   557: monitorexit
    //   558: aload #7
    //   560: athrow
    //   561: iconst_0
    //   562: istore #9
    //   564: goto -> 49
    //   567: ldc 536870912
    //   569: iload_3
    //   570: iand
    //   571: ifeq -> 580
    //   574: iconst_1
    //   575: istore #9
    //   577: goto -> 57
    //   580: iconst_0
    //   581: istore #9
    //   583: goto -> 57
    // Exception table:
    //   from	to	target	type
    //   2	43	554	finally
    //   49	54	554	finally
    //   57	172	554	finally
    //   172	208	554	finally
    //   211	216	554	finally
    //   216	247	554	finally
    //   247	551	554	finally
  }
  
  private void a(v paramv, com.applovin.exoplayer2.w paramw) {
    boolean bool;
    e e1;
    v v1;
    if (this.h == null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      e1 = null;
    } else {
      e1 = this.h.o;
    } 
    this.h = paramv;
    e e2 = paramv.o;
    h h1 = this.d;
    if (h1 != null) {
      v1 = paramv.a(h1.a(paramv));
    } else {
      v1 = paramv;
    } 
    paramw.b = v1;
    paramw.a = this.i;
    if (this.d == null)
      return; 
    if (!bool && ai.a(e1, e2))
      return; 
    f f1 = this.i;
    this.i = this.d.b((Looper)com.applovin.exoplayer2.l.a.b(this.f), this.e, paramv);
    paramw.a = this.i;
    if (f1 != null)
      f1.b(this.e); 
  }
  
  private long b(int paramInt) {
    int i = c() - paramInt;
    boolean bool2 = false;
    if (i >= 0 && i <= this.q - this.t) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    com.applovin.exoplayer2.l.a.a(bool1);
    this.q -= i;
    this.w = Math.max(this.v, e(this.q));
    boolean bool1 = bool2;
    if (i == 0) {
      bool1 = bool2;
      if (this.x)
        bool1 = true; 
    } 
    this.x = bool1;
    this.c.c(paramInt);
    paramInt = this.q;
    if (paramInt != 0) {
      paramInt = f(paramInt - 1);
      return this.l[paramInt] + this.m[paramInt];
    } 
    return 0L;
  }
  
  private long b(long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : I
    //   6: ifeq -> 96
    //   9: lload_1
    //   10: aload_0
    //   11: getfield o : [J
    //   14: aload_0
    //   15: getfield s : I
    //   18: laload
    //   19: lcmp
    //   20: ifge -> 26
    //   23: goto -> 96
    //   26: iload #4
    //   28: ifeq -> 53
    //   31: aload_0
    //   32: getfield t : I
    //   35: aload_0
    //   36: getfield q : I
    //   39: if_icmpeq -> 53
    //   42: aload_0
    //   43: getfield t : I
    //   46: iconst_1
    //   47: iadd
    //   48: istore #5
    //   50: goto -> 59
    //   53: aload_0
    //   54: getfield q : I
    //   57: istore #5
    //   59: aload_0
    //   60: aload_0
    //   61: getfield s : I
    //   64: iload #5
    //   66: lload_1
    //   67: iload_3
    //   68: invokespecial a : (IIJZ)I
    //   71: istore #5
    //   73: iload #5
    //   75: iconst_m1
    //   76: if_icmpne -> 85
    //   79: aload_0
    //   80: monitorexit
    //   81: ldc2_w -1
    //   84: lreturn
    //   85: aload_0
    //   86: iload #5
    //   88: invokespecial d : (I)J
    //   91: lstore_1
    //   92: aload_0
    //   93: monitorexit
    //   94: lload_1
    //   95: lreturn
    //   96: aload_0
    //   97: monitorexit
    //   98: ldc2_w -1
    //   101: lreturn
    //   102: astore #6
    //   104: aload_0
    //   105: monitorexit
    //   106: aload #6
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	102	finally
    //   31	50	102	finally
    //   53	59	102	finally
    //   59	73	102	finally
    //   85	92	102	finally
  }
  
  private boolean b(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : I
    //   6: istore_3
    //   7: iconst_1
    //   8: istore #6
    //   10: iload_3
    //   11: ifne -> 38
    //   14: aload_0
    //   15: getfield v : J
    //   18: lstore #4
    //   20: lload_1
    //   21: lload #4
    //   23: lcmp
    //   24: ifle -> 30
    //   27: goto -> 33
    //   30: iconst_0
    //   31: istore #6
    //   33: aload_0
    //   34: monitorexit
    //   35: iload #6
    //   37: ireturn
    //   38: aload_0
    //   39: invokevirtual i : ()J
    //   42: lstore #4
    //   44: lload #4
    //   46: lload_1
    //   47: lcmp
    //   48: iflt -> 55
    //   51: aload_0
    //   52: monitorexit
    //   53: iconst_0
    //   54: ireturn
    //   55: aload_0
    //   56: lload_1
    //   57: invokespecial c : (J)I
    //   60: istore_3
    //   61: aload_0
    //   62: aload_0
    //   63: getfield r : I
    //   66: iload_3
    //   67: iadd
    //   68: invokespecial b : (I)J
    //   71: pop2
    //   72: aload_0
    //   73: monitorexit
    //   74: iconst_1
    //   75: ireturn
    //   76: astore #7
    //   78: aload_0
    //   79: monitorexit
    //   80: aload #7
    //   82: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	76	finally
    //   14	20	76	finally
    //   38	44	76	finally
    //   55	72	76	finally
  }
  
  private int c(long paramLong) {
    int j = this.q;
    int i = f(j - 1);
    while (j > this.t && this.o[i] >= paramLong) {
      int k = j - 1;
      int m = i - 1;
      j = k;
      i = m;
      if (m == -1) {
        i = this.j - 1;
        j = k;
      } 
    } 
    return j;
  }
  
  private boolean c(int paramInt) {
    f f1 = this.i;
    return (f1 == null || f1.c() == 4 || ((this.n[paramInt] & 0x40000000) == 0 && this.i.d()));
  }
  
  private boolean c(v paramv) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield z : Z
    //   7: aload_1
    //   8: aload_0
    //   9: getfield C : Lcom/applovin/exoplayer2/v;
    //   12: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   15: istore_2
    //   16: iload_2
    //   17: ifeq -> 24
    //   20: aload_0
    //   21: monitorexit
    //   22: iconst_0
    //   23: ireturn
    //   24: aload_0
    //   25: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   28: invokevirtual c : ()Z
    //   31: ifne -> 74
    //   34: aload_0
    //   35: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   38: invokevirtual a : ()Ljava/lang/Object;
    //   41: checkcast com/applovin/exoplayer2/h/w$b
    //   44: getfield a : Lcom/applovin/exoplayer2/v;
    //   47: aload_1
    //   48: invokevirtual equals : (Ljava/lang/Object;)Z
    //   51: ifeq -> 74
    //   54: aload_0
    //   55: aload_0
    //   56: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   59: invokevirtual a : ()Ljava/lang/Object;
    //   62: checkcast com/applovin/exoplayer2/h/w$b
    //   65: getfield a : Lcom/applovin/exoplayer2/v;
    //   68: putfield C : Lcom/applovin/exoplayer2/v;
    //   71: goto -> 79
    //   74: aload_0
    //   75: aload_1
    //   76: putfield C : Lcom/applovin/exoplayer2/v;
    //   79: aload_0
    //   80: aload_0
    //   81: getfield C : Lcom/applovin/exoplayer2/v;
    //   84: getfield l : Ljava/lang/String;
    //   87: aload_0
    //   88: getfield C : Lcom/applovin/exoplayer2/v;
    //   91: getfield i : Ljava/lang/String;
    //   94: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)Z
    //   97: putfield E : Z
    //   100: aload_0
    //   101: iconst_0
    //   102: putfield F : Z
    //   105: aload_0
    //   106: monitorexit
    //   107: iconst_1
    //   108: ireturn
    //   109: astore_1
    //   110: aload_0
    //   111: monitorexit
    //   112: aload_1
    //   113: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	109	finally
    //   24	71	109	finally
    //   74	79	109	finally
    //   79	105	109	finally
  }
  
  @GuardedBy("this")
  private long d(int paramInt) {
    this.v = Math.max(this.v, e(paramInt));
    this.q -= paramInt;
    this.r += paramInt;
    this.s += paramInt;
    int i = this.s;
    int j = this.j;
    if (i >= j)
      this.s = i - j; 
    this.t -= paramInt;
    if (this.t < 0)
      this.t = 0; 
    this.c.b(this.r);
    if (this.q == 0) {
      i = this.s;
      paramInt = i;
      if (i == 0)
        paramInt = this.j; 
      return this.l[--paramInt] + this.m[paramInt];
    } 
    return this.l[this.s];
  }
  
  private long e(int paramInt) {
    long l = Long.MIN_VALUE;
    if (paramInt == 0)
      return Long.MIN_VALUE; 
    int i = f(paramInt - 1);
    for (int j = 0; j < paramInt; j++) {
      l = Math.max(l, this.o[i]);
      if ((this.n[i] & 0x1) != 0)
        return l; 
      int k = i - 1;
      i = k;
      if (k == -1)
        i = this.j - 1; 
    } 
    return l;
  }
  
  private int f(int paramInt) {
    paramInt = this.s + paramInt;
    int i = this.j;
    return (paramInt < i) ? paramInt : (paramInt - i);
  }
  
  private void l() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield t : I
    //   7: aload_0
    //   8: getfield a : Lcom/applovin/exoplayer2/h/v;
    //   11: invokevirtual b : ()V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
  }
  
  private long m() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield q : I
    //   6: istore_1
    //   7: iload_1
    //   8: ifne -> 17
    //   11: aload_0
    //   12: monitorexit
    //   13: ldc2_w -1
    //   16: lreturn
    //   17: aload_0
    //   18: aload_0
    //   19: getfield q : I
    //   22: invokespecial d : (I)J
    //   25: lstore_2
    //   26: aload_0
    //   27: monitorexit
    //   28: lload_2
    //   29: lreturn
    //   30: astore #4
    //   32: aload_0
    //   33: monitorexit
    //   34: aload #4
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	30	finally
    //   17	26	30	finally
  }
  
  private void n() {
    f f1 = this.i;
    if (f1 != null) {
      f1.b(this.e);
      this.i = null;
      this.h = null;
    } 
  }
  
  private boolean o() {
    return (this.t != this.q);
  }
  
  public final int a(g paramg, int paramInt1, boolean paramBoolean, int paramInt2) throws IOException {
    return this.a.a(paramg, paramInt1, paramBoolean);
  }
  
  @CallSuper
  public int a(com.applovin.exoplayer2.w paramw, g paramg, int paramInt, boolean paramBoolean) {
    boolean bool2;
    boolean bool1 = false;
    if ((paramInt & 0x2) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    int i = a(paramw, paramg, bool2, paramBoolean, this.b);
    if (i == -4 && !paramg.c()) {
      if ((paramInt & 0x1) != 0)
        bool1 = true; 
      if ((paramInt & 0x4) == 0)
        if (bool1) {
          this.a.b(paramg, this.b);
        } else {
          this.a.a(paramg, this.b);
        }  
      if (!bool1)
        this.t++; 
    } 
    return i;
  }
  
  @CallSuper
  public void a() {
    a(true);
    n();
  }
  
  public final void a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: iflt -> 49
    //   6: aload_0
    //   7: getfield t : I
    //   10: iload_1
    //   11: iadd
    //   12: aload_0
    //   13: getfield q : I
    //   16: if_icmpgt -> 49
    //   19: iconst_1
    //   20: istore_2
    //   21: goto -> 24
    //   24: iload_2
    //   25: invokestatic a : (Z)V
    //   28: aload_0
    //   29: aload_0
    //   30: getfield t : I
    //   33: iload_1
    //   34: iadd
    //   35: putfield t : I
    //   38: aload_0
    //   39: monitorexit
    //   40: return
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_3
    //   44: athrow
    //   45: astore_3
    //   46: goto -> 41
    //   49: iconst_0
    //   50: istore_2
    //   51: goto -> 24
    // Exception table:
    //   from	to	target	type
    //   6	19	45	finally
    //   24	38	45	finally
  }
  
  public final void a(long paramLong) {
    this.u = paramLong;
  }
  
  public void a(long paramLong, int paramInt1, int paramInt2, int paramInt3, @Nullable x.a parama) {
    boolean bool;
    if (this.A)
      a((v)com.applovin.exoplayer2.l.a.a(this.B)); 
    int i = paramInt1 & 0x1;
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (this.y) {
      if (!bool)
        return; 
      this.y = false;
    } 
    paramLong = this.G + paramLong;
    if (this.E) {
      if (paramLong < this.u)
        return; 
      if (i == 0) {
        if (!this.F) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Overriding unexpected non-sync sample for format: ");
          stringBuilder.append(this.C);
          q.c("SampleQueue", stringBuilder.toString());
          this.F = true;
        } 
        paramInt1 |= 0x1;
      } 
    } 
    if (this.H)
      if (bool) {
        if (!b(paramLong))
          return; 
        this.H = false;
      } else {
        return;
      }  
    a(paramLong, paramInt1, this.a.c() - paramInt2 - paramInt3, paramInt2, parama);
  }
  
  public final void a(long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    this.a.a(b(paramLong, paramBoolean1, paramBoolean2));
  }
  
  public final void a(@Nullable c paramc) {
    this.g = paramc;
  }
  
  public final void a(y paramy, int paramInt1, int paramInt2) {
    this.a.a(paramy, paramInt1);
  }
  
  public final void a(v paramv) {
    v v1 = b(paramv);
    this.A = false;
    this.B = paramv;
    boolean bool = c(v1);
    c c1 = this.g;
    if (c1 != null && bool)
      c1.a(v1); 
  }
  
  @CallSuper
  public void a(boolean paramBoolean) {
    this.a.a();
    this.q = 0;
    this.r = 0;
    this.s = 0;
    this.t = 0;
    this.y = true;
    this.u = Long.MIN_VALUE;
    this.v = Long.MIN_VALUE;
    this.w = Long.MIN_VALUE;
    this.x = false;
    this.c.b();
    if (paramBoolean) {
      this.B = null;
      this.C = null;
      this.z = true;
    } 
  }
  
  public final boolean a(long paramLong, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial l : ()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield t : I
    //   11: invokespecial f : (I)I
    //   14: istore #4
    //   16: aload_0
    //   17: invokespecial o : ()Z
    //   20: ifeq -> 100
    //   23: lload_1
    //   24: aload_0
    //   25: getfield o : [J
    //   28: iload #4
    //   30: laload
    //   31: lcmp
    //   32: iflt -> 100
    //   35: lload_1
    //   36: aload_0
    //   37: getfield w : J
    //   40: lcmp
    //   41: ifle -> 51
    //   44: iload_3
    //   45: ifne -> 51
    //   48: goto -> 100
    //   51: aload_0
    //   52: iload #4
    //   54: aload_0
    //   55: getfield q : I
    //   58: aload_0
    //   59: getfield t : I
    //   62: isub
    //   63: lload_1
    //   64: iconst_1
    //   65: invokespecial a : (IIJZ)I
    //   68: istore #4
    //   70: iload #4
    //   72: iconst_m1
    //   73: if_icmpne -> 80
    //   76: aload_0
    //   77: monitorexit
    //   78: iconst_0
    //   79: ireturn
    //   80: aload_0
    //   81: lload_1
    //   82: putfield u : J
    //   85: aload_0
    //   86: aload_0
    //   87: getfield t : I
    //   90: iload #4
    //   92: iadd
    //   93: putfield t : I
    //   96: aload_0
    //   97: monitorexit
    //   98: iconst_1
    //   99: ireturn
    //   100: aload_0
    //   101: monitorexit
    //   102: iconst_0
    //   103: ireturn
    //   104: astore #5
    //   106: aload_0
    //   107: monitorexit
    //   108: aload #5
    //   110: athrow
    // Exception table:
    //   from	to	target	type
    //   2	44	104	finally
    //   51	70	104	finally
    //   80	96	104	finally
  }
  
  public final int b(long paramLong, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield t : I
    //   7: invokespecial f : (I)I
    //   10: istore #4
    //   12: aload_0
    //   13: invokespecial o : ()Z
    //   16: ifeq -> 101
    //   19: lload_1
    //   20: aload_0
    //   21: getfield o : [J
    //   24: iload #4
    //   26: laload
    //   27: lcmp
    //   28: ifge -> 34
    //   31: goto -> 101
    //   34: lload_1
    //   35: aload_0
    //   36: getfield w : J
    //   39: lcmp
    //   40: ifle -> 67
    //   43: iload_3
    //   44: ifeq -> 67
    //   47: aload_0
    //   48: getfield q : I
    //   51: istore #4
    //   53: aload_0
    //   54: getfield t : I
    //   57: istore #5
    //   59: aload_0
    //   60: monitorexit
    //   61: iload #4
    //   63: iload #5
    //   65: isub
    //   66: ireturn
    //   67: aload_0
    //   68: iload #4
    //   70: aload_0
    //   71: getfield q : I
    //   74: aload_0
    //   75: getfield t : I
    //   78: isub
    //   79: lload_1
    //   80: iconst_1
    //   81: invokespecial a : (IIJZ)I
    //   84: istore #4
    //   86: iload #4
    //   88: iconst_m1
    //   89: if_icmpne -> 96
    //   92: aload_0
    //   93: monitorexit
    //   94: iconst_0
    //   95: ireturn
    //   96: aload_0
    //   97: monitorexit
    //   98: iload #4
    //   100: ireturn
    //   101: aload_0
    //   102: monitorexit
    //   103: iconst_0
    //   104: ireturn
    //   105: astore #6
    //   107: aload_0
    //   108: monitorexit
    //   109: aload #6
    //   111: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	105	finally
    //   34	43	105	finally
    //   47	59	105	finally
    //   67	86	105	finally
  }
  
  @CallSuper
  protected v b(v paramv) {
    v v1 = paramv;
    if (this.G != 0L) {
      v1 = paramv;
      if (paramv.p != Long.MAX_VALUE)
        v1 = paramv.a().a(paramv.p + this.G).a(); 
    } 
    return v1;
  }
  
  public final void b() {
    a(false);
  }
  
  @CallSuper
  public boolean b(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial o : ()Z
    //   6: istore_2
    //   7: iconst_1
    //   8: istore_3
    //   9: iload_2
    //   10: ifne -> 65
    //   13: iload_3
    //   14: istore_2
    //   15: iload_1
    //   16: ifne -> 61
    //   19: iload_3
    //   20: istore_2
    //   21: aload_0
    //   22: getfield x : Z
    //   25: ifne -> 61
    //   28: aload_0
    //   29: getfield C : Lcom/applovin/exoplayer2/v;
    //   32: ifnull -> 59
    //   35: aload_0
    //   36: getfield C : Lcom/applovin/exoplayer2/v;
    //   39: astore #4
    //   41: aload_0
    //   42: getfield h : Lcom/applovin/exoplayer2/v;
    //   45: astore #5
    //   47: aload #4
    //   49: aload #5
    //   51: if_acmpeq -> 59
    //   54: iload_3
    //   55: istore_2
    //   56: goto -> 61
    //   59: iconst_0
    //   60: istore_2
    //   61: aload_0
    //   62: monitorexit
    //   63: iload_2
    //   64: ireturn
    //   65: aload_0
    //   66: getfield c : Lcom/applovin/exoplayer2/h/ab;
    //   69: aload_0
    //   70: invokevirtual f : ()I
    //   73: invokevirtual a : (I)Ljava/lang/Object;
    //   76: checkcast com/applovin/exoplayer2/h/w$b
    //   79: getfield a : Lcom/applovin/exoplayer2/v;
    //   82: astore #4
    //   84: aload_0
    //   85: getfield h : Lcom/applovin/exoplayer2/v;
    //   88: astore #5
    //   90: aload #4
    //   92: aload #5
    //   94: if_acmpeq -> 101
    //   97: aload_0
    //   98: monitorexit
    //   99: iconst_1
    //   100: ireturn
    //   101: aload_0
    //   102: aload_0
    //   103: aload_0
    //   104: getfield t : I
    //   107: invokespecial f : (I)I
    //   110: invokespecial c : (I)Z
    //   113: istore_1
    //   114: aload_0
    //   115: monitorexit
    //   116: iload_1
    //   117: ireturn
    //   118: astore #4
    //   120: aload_0
    //   121: monitorexit
    //   122: aload #4
    //   124: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	118	finally
    //   21	47	118	finally
    //   65	90	118	finally
    //   101	114	118	finally
  }
  
  public final int c() {
    return this.r + this.q;
  }
  
  @CallSuper
  public void d() {
    k();
    n();
  }
  
  @CallSuper
  public void e() throws IOException {
    f f1 = this.i;
    if (f1 != null) {
      if (f1.c() != 1)
        return; 
      throw (f.a)com.applovin.exoplayer2.l.a.b(this.i.e());
    } 
  }
  
  public final int f() {
    return this.r + this.t;
  }
  
  @Nullable
  public final v g() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield z : Z
    //   6: ifeq -> 14
    //   9: aconst_null
    //   10: astore_1
    //   11: goto -> 19
    //   14: aload_0
    //   15: getfield C : Lcom/applovin/exoplayer2/v;
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: areturn
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	23	finally
    //   14	19	23	finally
  }
  
  public final long h() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield w : J
    //   6: lstore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: lload_1
    //   10: lreturn
    //   11: astore_3
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_3
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final long i() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield v : J
    //   6: aload_0
    //   7: aload_0
    //   8: getfield t : I
    //   11: invokespecial e : (I)J
    //   14: invokestatic max : (JJ)J
    //   17: lstore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: lload_1
    //   21: lreturn
    //   22: astore_3
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_3
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	22	finally
  }
  
  public final boolean j() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield x : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final void k() {
    this.a.a(m());
  }
  
  static final class a {
    public int a;
    
    public long b;
    
    @Nullable
    public x.a c;
  }
  
  private static final class b {
    public final v a;
    
    public final h.a b;
    
    private b(v param1v, h.a param1a) {
      this.a = param1v;
      this.b = param1a;
    }
  }
  
  public static interface c {
    void a(v param1v);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */