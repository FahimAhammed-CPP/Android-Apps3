package com.applovin.exoplayer2.h;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.applovin.exoplayer2.ab;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.h.a.a;
import com.applovin.exoplayer2.k.aa;
import com.applovin.exoplayer2.l.ai;

public final class l extends e<Void> {
  private final p a;
  
  private final boolean b;
  
  private final ba.c c;
  
  private final ba.a d;
  
  private a e;
  
  @Nullable
  private k f;
  
  private boolean g;
  
  private boolean h;
  
  private boolean i;
  
  public l(p paramp, boolean paramBoolean) {
    this.a = paramp;
    if (paramBoolean && paramp.i()) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.b = paramBoolean;
    this.c = new ba.c();
    this.d = new ba.a();
    ba ba = paramp.h();
    if (ba != null) {
      this.e = a.a(ba, (Object)null, (Object)null);
      this.i = true;
      return;
    } 
    this.e = a.a(paramp.g());
  }
  
  private Object a(Object paramObject) {
    Object object = paramObject;
    if (a.a(this.e) != null) {
      object = paramObject;
      if (paramObject.equals(a.d))
        object = a.a(this.e); 
    } 
    return object;
  }
  
  private void a(long paramLong) {
    k k1 = this.f;
    int i = this.e.c(k1.a.a);
    if (i == -1)
      return; 
    long l2 = (this.e.a(i, this.d)).d;
    long l1 = paramLong;
    if (l2 != -9223372036854775807L) {
      l1 = paramLong;
      if (paramLong >= l2)
        l1 = Math.max(0L, l2 - 1L); 
    } 
    k1.d(l1);
  }
  
  private Object b(Object paramObject) {
    Object object = paramObject;
    if (a.a(this.e) != null) {
      object = paramObject;
      if (a.a(this.e).equals(paramObject))
        object = a.d; 
    } 
    return object;
  }
  
  public k a(p.a parama, com.applovin.exoplayer2.k.b paramb, long paramLong) {
    k k1 = new k(parama, paramb, paramLong);
    k1.a(this.a);
    if (this.h) {
      k1.a(parama.b(a(parama.a)));
      return k1;
    } 
    this.f = k1;
    if (!this.g) {
      this.g = true;
      a((Void)null, this.a);
    } 
    return k1;
  }
  
  @Nullable
  protected p.a a(Void paramVoid, p.a parama) {
    return parama.b(b(parama.a));
  }
  
  public void a(n paramn) {
    ((k)paramn).i();
    if (paramn == this.f)
      this.f = null; 
  }
  
  public void a(@Nullable aa paramaa) {
    super.a(paramaa);
    if (!this.b) {
      this.g = true;
      a((Void)null, this.a);
    } 
  }
  
  protected void a(Void paramVoid, p paramp, ba paramba) {
    // Byte code:
    //   0: aload_0
    //   1: getfield h : Z
    //   4: ifeq -> 39
    //   7: aload_0
    //   8: aload_0
    //   9: getfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   12: aload_3
    //   13: invokevirtual a : (Lcom/applovin/exoplayer2/ba;)Lcom/applovin/exoplayer2/h/l$a;
    //   16: putfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   19: aload_0
    //   20: getfield f : Lcom/applovin/exoplayer2/h/k;
    //   23: astore_1
    //   24: aload_1
    //   25: ifnull -> 291
    //   28: aload_0
    //   29: aload_1
    //   30: invokevirtual h : ()J
    //   33: invokespecial a : (J)V
    //   36: goto -> 291
    //   39: aload_3
    //   40: invokevirtual d : ()Z
    //   43: ifeq -> 84
    //   46: aload_0
    //   47: getfield i : Z
    //   50: ifeq -> 65
    //   53: aload_0
    //   54: getfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   57: aload_3
    //   58: invokevirtual a : (Lcom/applovin/exoplayer2/ba;)Lcom/applovin/exoplayer2/h/l$a;
    //   61: astore_1
    //   62: goto -> 76
    //   65: aload_3
    //   66: getstatic com/applovin/exoplayer2/ba$c.a : Ljava/lang/Object;
    //   69: getstatic com/applovin/exoplayer2/h/l$a.d : Ljava/lang/Object;
    //   72: invokestatic a : (Lcom/applovin/exoplayer2/ba;Ljava/lang/Object;Ljava/lang/Object;)Lcom/applovin/exoplayer2/h/l$a;
    //   75: astore_1
    //   76: aload_0
    //   77: aload_1
    //   78: putfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   81: goto -> 291
    //   84: aload_3
    //   85: iconst_0
    //   86: aload_0
    //   87: getfield c : Lcom/applovin/exoplayer2/ba$c;
    //   90: invokevirtual a : (ILcom/applovin/exoplayer2/ba$c;)Lcom/applovin/exoplayer2/ba$c;
    //   93: pop
    //   94: aload_0
    //   95: getfield c : Lcom/applovin/exoplayer2/ba$c;
    //   98: invokevirtual b : ()J
    //   101: lstore #4
    //   103: aload_0
    //   104: getfield c : Lcom/applovin/exoplayer2/ba$c;
    //   107: getfield b : Ljava/lang/Object;
    //   110: astore_1
    //   111: aload_0
    //   112: getfield f : Lcom/applovin/exoplayer2/h/k;
    //   115: astore_2
    //   116: aload_2
    //   117: ifnull -> 188
    //   120: aload_2
    //   121: invokevirtual g : ()J
    //   124: lstore #6
    //   126: aload_0
    //   127: getfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   130: aload_0
    //   131: getfield f : Lcom/applovin/exoplayer2/h/k;
    //   134: getfield a : Lcom/applovin/exoplayer2/h/p$a;
    //   137: getfield a : Ljava/lang/Object;
    //   140: aload_0
    //   141: getfield d : Lcom/applovin/exoplayer2/ba$a;
    //   144: invokevirtual a : (Ljava/lang/Object;Lcom/applovin/exoplayer2/ba$a;)Lcom/applovin/exoplayer2/ba$a;
    //   147: pop
    //   148: lload #6
    //   150: aload_0
    //   151: getfield d : Lcom/applovin/exoplayer2/ba$a;
    //   154: invokevirtual c : ()J
    //   157: ladd
    //   158: lstore #6
    //   160: lload #6
    //   162: aload_0
    //   163: getfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   166: iconst_0
    //   167: aload_0
    //   168: getfield c : Lcom/applovin/exoplayer2/ba$c;
    //   171: invokevirtual a : (ILcom/applovin/exoplayer2/ba$c;)Lcom/applovin/exoplayer2/ba$c;
    //   174: invokevirtual b : ()J
    //   177: lcmp
    //   178: ifeq -> 188
    //   181: lload #6
    //   183: lstore #4
    //   185: goto -> 188
    //   188: aload_3
    //   189: aload_0
    //   190: getfield c : Lcom/applovin/exoplayer2/ba$c;
    //   193: aload_0
    //   194: getfield d : Lcom/applovin/exoplayer2/ba$a;
    //   197: iconst_0
    //   198: lload #4
    //   200: invokevirtual a : (Lcom/applovin/exoplayer2/ba$c;Lcom/applovin/exoplayer2/ba$a;IJ)Landroid/util/Pair;
    //   203: astore_2
    //   204: aload_2
    //   205: getfield first : Ljava/lang/Object;
    //   208: astore #8
    //   210: aload_2
    //   211: getfield second : Ljava/lang/Object;
    //   214: checkcast java/lang/Long
    //   217: invokevirtual longValue : ()J
    //   220: lstore #4
    //   222: aload_0
    //   223: getfield i : Z
    //   226: ifeq -> 241
    //   229: aload_0
    //   230: getfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   233: aload_3
    //   234: invokevirtual a : (Lcom/applovin/exoplayer2/ba;)Lcom/applovin/exoplayer2/h/l$a;
    //   237: astore_1
    //   238: goto -> 249
    //   241: aload_3
    //   242: aload_1
    //   243: aload #8
    //   245: invokestatic a : (Lcom/applovin/exoplayer2/ba;Ljava/lang/Object;Ljava/lang/Object;)Lcom/applovin/exoplayer2/h/l$a;
    //   248: astore_1
    //   249: aload_0
    //   250: aload_1
    //   251: putfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   254: aload_0
    //   255: getfield f : Lcom/applovin/exoplayer2/h/k;
    //   258: astore_1
    //   259: aload_1
    //   260: ifnull -> 291
    //   263: aload_0
    //   264: lload #4
    //   266: invokespecial a : (J)V
    //   269: aload_1
    //   270: getfield a : Lcom/applovin/exoplayer2/h/p$a;
    //   273: aload_0
    //   274: aload_1
    //   275: getfield a : Lcom/applovin/exoplayer2/h/p$a;
    //   278: getfield a : Ljava/lang/Object;
    //   281: invokespecial a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   284: invokevirtual b : (Ljava/lang/Object;)Lcom/applovin/exoplayer2/h/p$a;
    //   287: astore_1
    //   288: goto -> 293
    //   291: aconst_null
    //   292: astore_1
    //   293: aload_0
    //   294: iconst_1
    //   295: putfield i : Z
    //   298: aload_0
    //   299: iconst_1
    //   300: putfield h : Z
    //   303: aload_0
    //   304: aload_0
    //   305: getfield e : Lcom/applovin/exoplayer2/h/l$a;
    //   308: invokevirtual a : (Lcom/applovin/exoplayer2/ba;)V
    //   311: aload_1
    //   312: ifnull -> 329
    //   315: aload_0
    //   316: getfield f : Lcom/applovin/exoplayer2/h/k;
    //   319: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   322: checkcast com/applovin/exoplayer2/h/k
    //   325: aload_1
    //   326: invokevirtual a : (Lcom/applovin/exoplayer2/h/p$a;)V
    //   329: return
  }
  
  public void c() {
    this.h = false;
    this.g = false;
    super.c();
  }
  
  public void e() {}
  
  public ba f() {
    return this.e;
  }
  
  public ab g() {
    return this.a.g();
  }
  
  private static final class a extends h {
    public static final Object d = new Object();
    
    @Nullable
    private final Object e;
    
    @Nullable
    private final Object f;
    
    private a(ba param1ba, @Nullable Object param1Object1, @Nullable Object param1Object2) {
      super(param1ba);
      this.e = param1Object1;
      this.f = param1Object2;
    }
    
    public static a a(ab param1ab) {
      return new a(new l.b(param1ab), ba.c.a, d);
    }
    
    public static a a(ba param1ba, @Nullable Object param1Object1, @Nullable Object param1Object2) {
      return new a(param1ba, param1Object1, param1Object2);
    }
    
    public ba.a a(int param1Int, ba.a param1a, boolean param1Boolean) {
      this.c.a(param1Int, param1a, param1Boolean);
      if (ai.a(param1a.b, this.f) && param1Boolean)
        param1a.b = d; 
      return param1a;
    }
    
    public ba.c a(int param1Int, ba.c param1c, long param1Long) {
      this.c.a(param1Int, param1c, param1Long);
      if (ai.a(param1c.b, this.e))
        param1c.b = ba.c.a; 
      return param1c;
    }
    
    public a a(ba param1ba) {
      return new a(param1ba, this.e, this.f);
    }
    
    public Object a(int param1Int) {
      Object object2 = this.c.a(param1Int);
      Object object1 = object2;
      if (ai.a(object2, this.f))
        object1 = d; 
      return object1;
    }
    
    public int c(Object param1Object) {
      ba ba = this.c;
      Object object = param1Object;
      if (d.equals(param1Object)) {
        Object object1 = this.f;
        object = param1Object;
        if (object1 != null)
          object = object1; 
      } 
      return ba.c(object);
    }
  }
  
  @VisibleForTesting
  public static final class b extends ba {
    private final ab c;
    
    public b(ab param1ab) {
      this.c = param1ab;
    }
    
    public ba.a a(int param1Int, ba.a param1a, boolean param1Boolean) {
      Object object;
      Object object1 = null;
      if (param1Boolean) {
        object = Integer.valueOf(0);
      } else {
        object = null;
      } 
      if (param1Boolean)
        object1 = l.a.d; 
      param1a.a(object, object1, 0, -9223372036854775807L, 0L, a.a, true);
      return param1a;
    }
    
    public ba.c a(int param1Int, ba.c param1c, long param1Long) {
      param1c.a(ba.c.a, this.c, null, -9223372036854775807L, -9223372036854775807L, -9223372036854775807L, false, true, null, 0L, -9223372036854775807L, 0, 0, 0L);
      param1c.m = true;
      return param1c;
    }
    
    public Object a(int param1Int) {
      return l.a.d;
    }
    
    public int b() {
      return 1;
    }
    
    public int c() {
      return 1;
    }
    
    public int c(Object param1Object) {
      return (param1Object == l.a.d) ? 0 : -1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */