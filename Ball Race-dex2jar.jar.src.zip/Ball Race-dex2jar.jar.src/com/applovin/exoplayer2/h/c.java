package com.applovin.exoplayer2.h;

import android.net.Uri;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.e.f.d;
import com.applovin.exoplayer2.e.h;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.l;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.k.g;
import com.applovin.exoplayer2.l.a;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public final class c implements s {
  private final l a;
  
  @Nullable
  private h b;
  
  @Nullable
  private i c;
  
  public c(l paraml) {
    this.a = paraml;
  }
  
  public int a(u paramu) throws IOException {
    return ((h)a.b(this.b)).a((i)a.b(this.c), paramu);
  }
  
  public void a() {
    h h1 = this.b;
    if (h1 != null) {
      h1.c();
      this.b = null;
    } 
    this.c = null;
  }
  
  public void a(long paramLong1, long paramLong2) {
    ((h)a.b(this.b)).a(paramLong1, paramLong2);
  }
  
  public void a(g paramg, Uri paramUri, Map<String, List<String>> paramMap, long paramLong1, long paramLong2, j paramj) throws IOException {
    // Byte code:
    //   0: new com/applovin/exoplayer2/e/e
    //   3: dup
    //   4: aload_1
    //   5: lload #4
    //   7: lload #6
    //   9: invokespecial <init> : (Lcom/applovin/exoplayer2/k/g;JJ)V
    //   12: astore_1
    //   13: aload_0
    //   14: aload_1
    //   15: putfield c : Lcom/applovin/exoplayer2/e/i;
    //   18: aload_0
    //   19: getfield b : Lcom/applovin/exoplayer2/e/h;
    //   22: ifnull -> 26
    //   25: return
    //   26: aload_0
    //   27: getfield a : Lcom/applovin/exoplayer2/e/l;
    //   30: aload_2
    //   31: aload_3
    //   32: invokeinterface a : (Landroid/net/Uri;Ljava/util/Map;)[Lcom/applovin/exoplayer2/e/h;
    //   37: astore_3
    //   38: aload_3
    //   39: arraylength
    //   40: istore #9
    //   42: iconst_0
    //   43: istore #13
    //   45: iconst_0
    //   46: istore #12
    //   48: iload #9
    //   50: iconst_1
    //   51: if_icmpne -> 64
    //   54: aload_0
    //   55: aload_3
    //   56: iconst_0
    //   57: aaload
    //   58: putfield b : Lcom/applovin/exoplayer2/e/h;
    //   61: goto -> 261
    //   64: aload_3
    //   65: arraylength
    //   66: istore #10
    //   68: iconst_0
    //   69: istore #9
    //   71: iload #9
    //   73: iload #10
    //   75: if_icmpge -> 254
    //   78: aload_3
    //   79: iload #9
    //   81: aaload
    //   82: astore #14
    //   84: aload #14
    //   86: aload_1
    //   87: invokeinterface a : (Lcom/applovin/exoplayer2/e/i;)Z
    //   92: ifeq -> 141
    //   95: aload_0
    //   96: aload #14
    //   98: putfield b : Lcom/applovin/exoplayer2/e/h;
    //   101: aload_0
    //   102: getfield b : Lcom/applovin/exoplayer2/e/h;
    //   105: ifnonnull -> 124
    //   108: iload #12
    //   110: istore #11
    //   112: aload_1
    //   113: invokeinterface c : ()J
    //   118: lload #4
    //   120: lcmp
    //   121: ifne -> 127
    //   124: iconst_1
    //   125: istore #11
    //   127: iload #11
    //   129: invokestatic b : (Z)V
    //   132: aload_1
    //   133: invokeinterface a : ()V
    //   138: goto -> 254
    //   141: aload_0
    //   142: getfield b : Lcom/applovin/exoplayer2/e/h;
    //   145: ifnonnull -> 231
    //   148: aload_1
    //   149: invokeinterface c : ()J
    //   154: lload #4
    //   156: lcmp
    //   157: ifne -> 225
    //   160: goto -> 231
    //   163: astore_2
    //   164: aload_0
    //   165: getfield b : Lcom/applovin/exoplayer2/e/h;
    //   168: ifnonnull -> 187
    //   171: iload #13
    //   173: istore #11
    //   175: aload_1
    //   176: invokeinterface c : ()J
    //   181: lload #4
    //   183: lcmp
    //   184: ifne -> 190
    //   187: iconst_1
    //   188: istore #11
    //   190: iload #11
    //   192: invokestatic b : (Z)V
    //   195: aload_1
    //   196: invokeinterface a : ()V
    //   201: aload_2
    //   202: athrow
    //   203: aload_0
    //   204: getfield b : Lcom/applovin/exoplayer2/e/h;
    //   207: ifnonnull -> 231
    //   210: aload_1
    //   211: invokeinterface c : ()J
    //   216: lload #4
    //   218: lcmp
    //   219: ifne -> 225
    //   222: goto -> 231
    //   225: iconst_0
    //   226: istore #11
    //   228: goto -> 234
    //   231: iconst_1
    //   232: istore #11
    //   234: iload #11
    //   236: invokestatic b : (Z)V
    //   239: aload_1
    //   240: invokeinterface a : ()V
    //   245: iload #9
    //   247: iconst_1
    //   248: iadd
    //   249: istore #9
    //   251: goto -> 71
    //   254: aload_0
    //   255: getfield b : Lcom/applovin/exoplayer2/e/h;
    //   258: ifnull -> 273
    //   261: aload_0
    //   262: getfield b : Lcom/applovin/exoplayer2/e/h;
    //   265: aload #8
    //   267: invokeinterface a : (Lcom/applovin/exoplayer2/e/j;)V
    //   272: return
    //   273: new java/lang/StringBuilder
    //   276: dup
    //   277: invokespecial <init> : ()V
    //   280: astore_1
    //   281: aload_1
    //   282: ldc 'None of the available extractors ('
    //   284: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   287: pop
    //   288: aload_1
    //   289: aload_3
    //   290: invokestatic b : ([Ljava/lang/Object;)Ljava/lang/String;
    //   293: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   296: pop
    //   297: aload_1
    //   298: ldc ') could read the stream.'
    //   300: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: pop
    //   304: new com/applovin/exoplayer2/h/ae
    //   307: dup
    //   308: aload_1
    //   309: invokevirtual toString : ()Ljava/lang/String;
    //   312: aload_2
    //   313: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   316: checkcast android/net/Uri
    //   319: invokespecial <init> : (Ljava/lang/String;Landroid/net/Uri;)V
    //   322: athrow
    //   323: astore #14
    //   325: goto -> 203
    // Exception table:
    //   from	to	target	type
    //   84	101	323	java/io/EOFException
    //   84	101	163	finally
  }
  
  public void b() {
    h h1 = this.b;
    if (h1 instanceof d)
      ((d)h1).a(); 
  }
  
  public long c() {
    i i1 = this.c;
    return (i1 != null) ? i1.c() : -1L;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */