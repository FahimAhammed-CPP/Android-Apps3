package com.applovin.exoplayer2.h;

import androidx.annotation.Nullable;

public class o {
  public final Object a;
  
  public final int b;
  
  public final int c;
  
  public final long d;
  
  public final int e;
  
  protected o(o paramo) {
    this.a = paramo.a;
    this.b = paramo.b;
    this.c = paramo.c;
    this.d = paramo.d;
    this.e = paramo.e;
  }
  
  public o(Object paramObject) {
    this(paramObject, -1L);
  }
  
  public o(Object paramObject, int paramInt1, int paramInt2, long paramLong) {
    this(paramObject, paramInt1, paramInt2, paramLong, -1);
  }
  
  private o(Object paramObject, int paramInt1, int paramInt2, long paramLong, int paramInt3) {
    this.a = paramObject;
    this.b = paramInt1;
    this.c = paramInt2;
    this.d = paramLong;
    this.e = paramInt3;
  }
  
  public o(Object paramObject, long paramLong) {
    this(paramObject, -1, -1, paramLong, -1);
  }
  
  public o(Object paramObject, long paramLong, int paramInt) {
    this(paramObject, -1, -1, paramLong, paramInt);
  }
  
  public o a(Object paramObject) {
    return this.a.equals(paramObject) ? this : new o(paramObject, this.b, this.c, this.d, this.e);
  }
  
  public boolean a() {
    return (this.b != -1);
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof o))
      return false; 
    paramObject = paramObject;
    return (this.a.equals(((o)paramObject).a) && this.b == ((o)paramObject).b && this.c == ((o)paramObject).c && this.d == ((o)paramObject).d && this.e == ((o)paramObject).e);
  }
  
  public int hashCode() {
    return ((((527 + this.a.hashCode()) * 31 + this.b) * 31 + this.c) * 31 + (int)this.d) * 31 + this.e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */