package com.applovin.exoplayer2.h;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ab;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.d.d;
import com.applovin.exoplayer2.d.h;
import com.applovin.exoplayer2.d.i;
import com.applovin.exoplayer2.e.f;
import com.applovin.exoplayer2.e.l;
import com.applovin.exoplayer2.k.aa;
import com.applovin.exoplayer2.k.b;
import com.applovin.exoplayer2.k.i;
import com.applovin.exoplayer2.k.r;
import com.applovin.exoplayer2.k.v;

public final class u extends a implements t.b {
  private final ab a;
  
  private final ab.f b;
  
  private final i.a c;
  
  private final s.a d;
  
  private final h e;
  
  private final v f;
  
  private final int g;
  
  private boolean h;
  
  private long i;
  
  private boolean j;
  
  private boolean k;
  
  @Nullable
  private aa l;
  
  private u(ab paramab, i.a parama, s.a parama1, h paramh, v paramv, int paramInt) {
    this.b = (ab.f)com.applovin.exoplayer2.l.a.b(paramab.c);
    this.a = paramab;
    this.c = parama;
    this.d = parama1;
    this.e = paramh;
    this.f = paramv;
    this.g = paramInt;
    this.h = true;
    this.i = -9223372036854775807L;
  }
  
  private void f() {
    h h1;
    aa aa1 = new aa(this.i, this.j, false, this.k, null, this.a);
    if (this.h)
      h1 = new h(this, aa1) {
          public ba.a a(int param1Int, ba.a param1a, boolean param1Boolean) {
            super.a(param1Int, param1a, param1Boolean);
            param1a.f = true;
            return param1a;
          }
          
          public ba.c a(int param1Int, ba.c param1c, long param1Long) {
            super.a(param1Int, param1c, param1Long);
            param1c.m = true;
            return param1c;
          }
        }; 
    a(h1);
  }
  
  public void a(long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    long l = paramLong;
    if (paramLong == -9223372036854775807L)
      l = this.i; 
    if (!this.h && this.i == l && this.j == paramBoolean1 && this.k == paramBoolean2)
      return; 
    this.i = l;
    this.j = paramBoolean1;
    this.k = paramBoolean2;
    this.h = false;
    f();
  }
  
  public void a(n paramn) {
    ((t)paramn).g();
  }
  
  protected void a(@Nullable aa paramaa) {
    this.l = paramaa;
    this.e.a();
    f();
  }
  
  public n b(p.a parama, b paramb, long paramLong) {
    i i = this.c.a();
    aa aa1 = this.l;
    if (aa1 != null)
      i.a(aa1); 
    return new t(this.b.a, i, this.d.createProgressiveMediaExtractor(), this.e, b(parama), this.f, a(parama), this, paramb, this.b.f, this.g);
  }
  
  protected void c() {
    this.e.b();
  }
  
  public void e() {}
  
  public ab g() {
    return this.a;
  }
  
  public static final class a implements r {
    private final i.a a;
    
    private s.a b;
    
    private i c;
    
    private v d;
    
    private int e;
    
    @Nullable
    private String f;
    
    @Nullable
    private Object g;
    
    public a(i.a param1a) {
      this(param1a, (l)new f());
    }
    
    public a(i.a param1a, l param1l) {
      this(param1a, (s.a)new -$.Lambda.u.a.N2g26a5Ufd3eHbcZ9wWJKkBFOu4(param1l));
    }
    
    public a(i.a param1a, s.a param1a1) {
      this.a = param1a;
      this.b = param1a1;
      this.c = (i)new d();
      this.d = (v)new r();
      this.e = 1048576;
    }
    
    public u a(ab param1ab) {
      boolean bool1;
      com.applovin.exoplayer2.l.a.b(param1ab.c);
      Object object = param1ab.c.h;
      boolean bool2 = true;
      if (object == null && this.g != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (param1ab.c.f != null || this.f == null)
        bool2 = false; 
      if (bool1 && bool2) {
        object = param1ab.a().a(this.g).b(this.f).a();
      } else if (bool1) {
        object = param1ab.a().a(this.g).a();
      } else {
        object = param1ab;
        if (bool2)
          object = param1ab.a().b(this.f).a(); 
      } 
      return new u((ab)object, this.a, this.b, this.c.a((ab)object), this.d, this.e);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */