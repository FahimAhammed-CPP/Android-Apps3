package com.applovin.exoplayer2.h;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.av;
import com.applovin.exoplayer2.j.d;
import com.applovin.exoplayer2.k.b;
import com.applovin.exoplayer2.l.ai;
import java.io.IOException;

public final class k implements n, n.a {
  public final p.a a;
  
  private final long b;
  
  private final b c;
  
  private p d;
  
  private n e;
  
  @Nullable
  private n.a f;
  
  @Nullable
  private a g;
  
  private boolean h;
  
  private long i;
  
  public k(p.a parama, b paramb, long paramLong) {
    this.a = parama;
    this.c = paramb;
    this.b = paramLong;
    this.i = -9223372036854775807L;
  }
  
  private long e(long paramLong) {
    long l = this.i;
    if (l != -9223372036854775807L)
      paramLong = l; 
    return paramLong;
  }
  
  public long a(long paramLong, av paramav) {
    return ((n)ai.a(this.e)).a(paramLong, paramav);
  }
  
  public long a(d[] paramArrayOfd, boolean[] paramArrayOfboolean1, x[] paramArrayOfx, boolean[] paramArrayOfboolean2, long paramLong) {
    long l = this.i;
    if (l != -9223372036854775807L && paramLong == this.b) {
      this.i = -9223372036854775807L;
      paramLong = l;
    } 
    return ((n)ai.a(this.e)).a(paramArrayOfd, paramArrayOfboolean1, paramArrayOfx, paramArrayOfboolean2, paramLong);
  }
  
  public void a(long paramLong) {
    ((n)ai.a(this.e)).a(paramLong);
  }
  
  public void a(long paramLong, boolean paramBoolean) {
    ((n)ai.a(this.e)).a(paramLong, paramBoolean);
  }
  
  public void a(n.a parama, long paramLong) {
    this.f = parama;
    n n1 = this.e;
    if (n1 != null)
      n1.a(this, e(this.b)); 
  }
  
  public void a(n paramn) {
    ((n.a)ai.a(this.f)).a(this);
    a a1 = this.g;
    if (a1 != null)
      a1.a(this.a); 
  }
  
  public void a(p.a parama) {
    long l = e(this.b);
    this.e = ((p)com.applovin.exoplayer2.l.a.b(this.d)).b(parama, this.c, l);
    if (this.f != null)
      this.e.a(this, l); 
  }
  
  public void a(p paramp) {
    boolean bool;
    if (this.d == null) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.b(bool);
    this.d = paramp;
  }
  
  public long b(long paramLong) {
    return ((n)ai.a(this.e)).b(paramLong);
  }
  
  public ad b() {
    return ((n)ai.a(this.e)).b();
  }
  
  public void b(n paramn) {
    ((n.a)ai.a(this.f)).a(this);
  }
  
  public long c() {
    return ((n)ai.a(this.e)).c();
  }
  
  public boolean c(long paramLong) {
    n n1 = this.e;
    return (n1 != null && n1.c(paramLong));
  }
  
  public long d() {
    return ((n)ai.a(this.e)).d();
  }
  
  public void d(long paramLong) {
    this.i = paramLong;
  }
  
  public long e() {
    return ((n)ai.a(this.e)).e();
  }
  
  public void e_() throws IOException {
    try {
      if (this.e != null) {
        this.e.e_();
        return;
      } 
      if (this.d != null) {
        this.d.e();
        return;
      } 
    } catch (IOException iOException) {
      a a1 = this.g;
      if (a1 != null) {
        if (!this.h) {
          this.h = true;
          a1.a(this.a, iOException);
        } 
        return;
      } 
    } 
  }
  
  public boolean f() {
    n n1 = this.e;
    return (n1 != null && n1.f());
  }
  
  public long g() {
    return this.b;
  }
  
  public long h() {
    return this.i;
  }
  
  public void i() {
    if (this.e != null)
      ((p)com.applovin.exoplayer2.l.a.b(this.d)).a(this.e); 
  }
  
  public static interface a {
    void a(p.a param1a);
    
    void a(p.a param1a, IOException param1IOException);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */