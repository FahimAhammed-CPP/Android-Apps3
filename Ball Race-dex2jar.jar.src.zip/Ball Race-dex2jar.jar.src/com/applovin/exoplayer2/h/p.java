package com.applovin.exoplayer2.h;

import android.os.Handler;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ab;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.d.g;
import com.applovin.exoplayer2.k.aa;
import java.io.IOException;

public interface p {
  void a(Handler paramHandler, g paramg);
  
  void a(Handler paramHandler, q paramq);
  
  void a(g paramg);
  
  void a(n paramn);
  
  void a(b paramb);
  
  void a(b paramb, @Nullable aa paramaa);
  
  void a(q paramq);
  
  n b(a parama, com.applovin.exoplayer2.k.b paramb, long paramLong);
  
  void b(b paramb);
  
  void c(b paramb);
  
  void e() throws IOException;
  
  ab g();
  
  @Nullable
  ba h();
  
  boolean i();
  
  public static final class a extends o {
    public a(o param1o) {
      super(param1o);
    }
    
    public a(Object param1Object) {
      super(param1Object);
    }
    
    public a(Object param1Object, int param1Int1, int param1Int2, long param1Long) {
      super(param1Object, param1Int1, param1Int2, param1Long);
    }
    
    public a(Object param1Object, long param1Long, int param1Int) {
      super(param1Object, param1Long, param1Int);
    }
    
    public a b(Object param1Object) {
      return new a(super.a(param1Object));
    }
  }
  
  public static interface b {
    void onSourceInfoRefreshed(p param1p, ba param1ba);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */