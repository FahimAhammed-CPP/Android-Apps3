package com.applovin.exoplayer2.h;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.av;
import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.u;
import com.applovin.exoplayer2.v;
import com.applovin.exoplayer2.w;
import java.io.IOException;

public final class d implements n, n.a {
  public final n a;
  
  long b;
  
  long c;
  
  @Nullable
  private n.a d;
  
  private a[] e;
  
  private long f;
  
  public d(n paramn, boolean paramBoolean, long paramLong1, long paramLong2) {
    long l;
    this.a = paramn;
    this.e = new a[0];
    if (paramBoolean) {
      l = paramLong1;
    } else {
      l = -9223372036854775807L;
    } 
    this.f = l;
    this.b = paramLong1;
    this.c = paramLong2;
  }
  
  private static boolean a(long paramLong, com.applovin.exoplayer2.j.d[] paramArrayOfd) {
    if (paramLong != 0L) {
      int j = paramArrayOfd.length;
      for (int i = 0; i < j; i++) {
        com.applovin.exoplayer2.j.d d1 = paramArrayOfd[i];
        if (d1 != null) {
          v v = d1.f();
          if (!u.a(v.l, v.i))
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  private av b(long paramLong, av paramav) {
    long l1 = ai.a(paramav.f, 0L, paramLong - this.b);
    long l2 = paramav.g;
    long l3 = this.c;
    if (l3 == Long.MIN_VALUE) {
      paramLong = Long.MAX_VALUE;
    } else {
      paramLong = l3 - paramLong;
    } 
    paramLong = ai.a(l2, 0L, paramLong);
    return (l1 == paramav.f && paramLong == paramav.g) ? paramav : new av(l1, paramLong);
  }
  
  public long a(long paramLong, av paramav) {
    long l = this.b;
    if (paramLong == l)
      return l; 
    paramav = b(paramLong, paramav);
    return this.a.a(paramLong, paramav);
  }
  
  public long a(com.applovin.exoplayer2.j.d[] paramArrayOfd, boolean[] paramArrayOfboolean1, x[] paramArrayOfx, boolean[] paramArrayOfboolean2, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: aload_3
    //   2: arraylength
    //   3: anewarray com/applovin/exoplayer2/h/d$a
    //   6: putfield e : [Lcom/applovin/exoplayer2/h/d$a;
    //   9: aload_3
    //   10: arraylength
    //   11: anewarray com/applovin/exoplayer2/h/x
    //   14: astore #16
    //   16: iconst_0
    //   17: istore #8
    //   19: iconst_0
    //   20: istore #7
    //   22: aload_3
    //   23: arraylength
    //   24: istore #9
    //   26: aconst_null
    //   27: astore #15
    //   29: iload #7
    //   31: iload #9
    //   33: if_icmpge -> 88
    //   36: aload_0
    //   37: getfield e : [Lcom/applovin/exoplayer2/h/d$a;
    //   40: astore #17
    //   42: aload #17
    //   44: iload #7
    //   46: aload_3
    //   47: iload #7
    //   49: aaload
    //   50: checkcast com/applovin/exoplayer2/h/d$a
    //   53: aastore
    //   54: aload #17
    //   56: iload #7
    //   58: aaload
    //   59: ifnull -> 72
    //   62: aload #17
    //   64: iload #7
    //   66: aaload
    //   67: getfield a : Lcom/applovin/exoplayer2/h/x;
    //   70: astore #15
    //   72: aload #16
    //   74: iload #7
    //   76: aload #15
    //   78: aastore
    //   79: iload #7
    //   81: iconst_1
    //   82: iadd
    //   83: istore #7
    //   85: goto -> 22
    //   88: aload_0
    //   89: getfield a : Lcom/applovin/exoplayer2/h/n;
    //   92: aload_1
    //   93: aload_2
    //   94: aload #16
    //   96: aload #4
    //   98: lload #5
    //   100: invokeinterface a : ([Lcom/applovin/exoplayer2/j/d;[Z[Lcom/applovin/exoplayer2/h/x;[ZJ)J
    //   105: lstore #12
    //   107: aload_0
    //   108: invokevirtual g : ()Z
    //   111: ifeq -> 144
    //   114: aload_0
    //   115: getfield b : J
    //   118: lstore #10
    //   120: lload #5
    //   122: lload #10
    //   124: lcmp
    //   125: ifne -> 144
    //   128: lload #10
    //   130: aload_1
    //   131: invokestatic a : (J[Lcom/applovin/exoplayer2/j/d;)Z
    //   134: ifeq -> 144
    //   137: lload #12
    //   139: lstore #10
    //   141: goto -> 149
    //   144: ldc2_w -9223372036854775807
    //   147: lstore #10
    //   149: aload_0
    //   150: lload #10
    //   152: putfield f : J
    //   155: lload #12
    //   157: lload #5
    //   159: lcmp
    //   160: ifeq -> 205
    //   163: lload #12
    //   165: aload_0
    //   166: getfield b : J
    //   169: lcmp
    //   170: iflt -> 199
    //   173: aload_0
    //   174: getfield c : J
    //   177: lstore #5
    //   179: lload #5
    //   181: ldc2_w -9223372036854775808
    //   184: lcmp
    //   185: ifeq -> 205
    //   188: lload #12
    //   190: lload #5
    //   192: lcmp
    //   193: ifgt -> 199
    //   196: goto -> 205
    //   199: iconst_0
    //   200: istore #14
    //   202: goto -> 208
    //   205: iconst_1
    //   206: istore #14
    //   208: iload #14
    //   210: invokestatic b : (Z)V
    //   213: iload #8
    //   215: istore #7
    //   217: iload #7
    //   219: aload_3
    //   220: arraylength
    //   221: if_icmpge -> 310
    //   224: aload #16
    //   226: iload #7
    //   228: aaload
    //   229: ifnonnull -> 243
    //   232: aload_0
    //   233: getfield e : [Lcom/applovin/exoplayer2/h/d$a;
    //   236: iload #7
    //   238: aconst_null
    //   239: aastore
    //   240: goto -> 290
    //   243: aload_0
    //   244: getfield e : [Lcom/applovin/exoplayer2/h/d$a;
    //   247: astore_1
    //   248: aload_1
    //   249: iload #7
    //   251: aaload
    //   252: ifnull -> 270
    //   255: aload_1
    //   256: iload #7
    //   258: aaload
    //   259: getfield a : Lcom/applovin/exoplayer2/h/x;
    //   262: aload #16
    //   264: iload #7
    //   266: aaload
    //   267: if_acmpeq -> 290
    //   270: aload_0
    //   271: getfield e : [Lcom/applovin/exoplayer2/h/d$a;
    //   274: iload #7
    //   276: new com/applovin/exoplayer2/h/d$a
    //   279: dup
    //   280: aload_0
    //   281: aload #16
    //   283: iload #7
    //   285: aaload
    //   286: invokespecial <init> : (Lcom/applovin/exoplayer2/h/d;Lcom/applovin/exoplayer2/h/x;)V
    //   289: aastore
    //   290: aload_3
    //   291: iload #7
    //   293: aload_0
    //   294: getfield e : [Lcom/applovin/exoplayer2/h/d$a;
    //   297: iload #7
    //   299: aaload
    //   300: aastore
    //   301: iload #7
    //   303: iconst_1
    //   304: iadd
    //   305: istore #7
    //   307: goto -> 217
    //   310: lload #12
    //   312: lreturn
  }
  
  public void a(long paramLong) {
    this.a.a(paramLong);
  }
  
  public void a(long paramLong1, long paramLong2) {
    this.b = paramLong1;
    this.c = paramLong2;
  }
  
  public void a(long paramLong, boolean paramBoolean) {
    this.a.a(paramLong, paramBoolean);
  }
  
  public void a(n.a parama, long paramLong) {
    this.d = parama;
    this.a.a(this, paramLong);
  }
  
  public void a(n paramn) {
    ((n.a)com.applovin.exoplayer2.l.a.b(this.d)).a(this);
  }
  
  public long b(long paramLong) {
    this.f = -9223372036854775807L;
    a[] arrayOfA = this.e;
    int j = arrayOfA.length;
    boolean bool2 = false;
    for (int i = 0; i < j; i++) {
      a a1 = arrayOfA[i];
      if (a1 != null)
        a1.a(); 
    } 
    long l = this.a.b(paramLong);
    if (l != paramLong) {
      boolean bool = bool2;
      if (l >= this.b) {
        paramLong = this.c;
        if (paramLong != Long.MIN_VALUE) {
          bool = bool2;
          if (l <= paramLong) {
            bool = true;
            com.applovin.exoplayer2.l.a.b(bool);
            return l;
          } 
          com.applovin.exoplayer2.l.a.b(bool);
          return l;
        } 
      } else {
        com.applovin.exoplayer2.l.a.b(bool);
        return l;
      } 
    } 
    boolean bool1 = true;
    com.applovin.exoplayer2.l.a.b(bool1);
    return l;
  }
  
  public ad b() {
    return this.a.b();
  }
  
  public void b(n paramn) {
    ((n.a)com.applovin.exoplayer2.l.a.b(this.d)).a(this);
  }
  
  public long c() {
    if (g()) {
      long l3 = this.f;
      this.f = -9223372036854775807L;
      long l4 = c();
      if (l4 != -9223372036854775807L)
        l3 = l4; 
      return l3;
    } 
    long l1 = this.a.c();
    if (l1 == -9223372036854775807L)
      return -9223372036854775807L; 
    long l2 = this.b;
    boolean bool2 = true;
    if (l1 >= l2) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    com.applovin.exoplayer2.l.a.b(bool1);
    l2 = this.c;
    boolean bool1 = bool2;
    if (l2 != Long.MIN_VALUE)
      if (l1 <= l2) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    com.applovin.exoplayer2.l.a.b(bool1);
    return l1;
  }
  
  public boolean c(long paramLong) {
    return this.a.c(paramLong);
  }
  
  public long d() {
    long l = this.a.d();
    if (l != Long.MIN_VALUE) {
      long l1 = this.c;
      return (l1 != Long.MIN_VALUE && l >= l1) ? Long.MIN_VALUE : l;
    } 
    return Long.MIN_VALUE;
  }
  
  public long e() {
    long l = this.a.e();
    if (l != Long.MIN_VALUE) {
      long l1 = this.c;
      return (l1 != Long.MIN_VALUE && l >= l1) ? Long.MIN_VALUE : l;
    } 
    return Long.MIN_VALUE;
  }
  
  public void e_() throws IOException {
    this.a.e_();
  }
  
  public boolean f() {
    return this.a.f();
  }
  
  boolean g() {
    return (this.f != -9223372036854775807L);
  }
  
  private final class a implements x {
    public final x a;
    
    private boolean c;
    
    public a(d this$0, x param1x) {
      this.a = param1x;
    }
    
    public int a(long param1Long) {
      return this.b.g() ? -3 : this.a.a(param1Long);
    }
    
    public int a(w param1w, g param1g, int param1Int) {
      v v;
      if (this.b.g())
        return -3; 
      if (this.c) {
        param1g.a_(4);
        return -4;
      } 
      param1Int = this.a.a(param1w, param1g, param1Int);
      if (param1Int == -5) {
        v = (v)com.applovin.exoplayer2.l.a.b(param1w.b);
        if (v.B != 0 || v.C != 0) {
          long l = this.b.b;
          int i = 0;
          if (l != 0L) {
            param1Int = 0;
          } else {
            param1Int = v.B;
          } 
          if (this.b.c == Long.MIN_VALUE)
            i = v.C; 
          param1w.b = v.a().n(param1Int).o(i).a();
        } 
        return -5;
      } 
      if (this.b.c != Long.MIN_VALUE && ((param1Int == -4 && ((g)v).d >= this.b.c) || (param1Int == -3 && this.b.d() == Long.MIN_VALUE && !((g)v).c))) {
        v.a();
        v.a_(4);
        this.c = true;
        return -4;
      } 
      return param1Int;
    }
    
    public void a() {
      this.c = false;
    }
    
    public boolean b() {
      return (!this.b.g() && this.a.b());
    }
    
    public void c() throws IOException {
      this.a.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */