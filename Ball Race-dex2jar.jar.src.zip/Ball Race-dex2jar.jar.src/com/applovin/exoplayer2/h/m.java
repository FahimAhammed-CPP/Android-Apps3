package com.applovin.exoplayer2.h;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.v;

public final class m {
  public final int a;
  
  public final int b;
  
  @Nullable
  public final v c;
  
  public final int d;
  
  @Nullable
  public final Object e;
  
  public final long f;
  
  public final long g;
  
  public m(int paramInt) {
    this(paramInt, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
  }
  
  public m(int paramInt1, int paramInt2, @Nullable v paramv, int paramInt3, @Nullable Object paramObject, long paramLong1, long paramLong2) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramv;
    this.d = paramInt3;
    this.e = paramObject;
    this.f = paramLong1;
    this.g = paramLong2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */