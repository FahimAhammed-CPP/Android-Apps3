package com.applovin.exoplayer2.h;

import android.net.Uri;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.k.g;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface s {
  int a(u paramu) throws IOException;
  
  void a();
  
  void a(long paramLong1, long paramLong2);
  
  void a(g paramg, Uri paramUri, Map<String, List<String>> paramMap, long paramLong1, long paramLong2, j paramj) throws IOException;
  
  void b();
  
  long c();
  
  public static interface a {
    s createProgressiveMediaExtractor();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */