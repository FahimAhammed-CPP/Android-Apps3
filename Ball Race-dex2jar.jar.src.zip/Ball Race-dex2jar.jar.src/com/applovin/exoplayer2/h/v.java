package com.applovin.exoplayer2.h;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.k.b;
import com.applovin.exoplayer2.k.g;
import com.applovin.exoplayer2.l.y;
import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;

class v {
  private final b a;
  
  private final int b;
  
  private final y c;
  
  private a d;
  
  private a e;
  
  private a f;
  
  private long g;
  
  public v(b paramb) {
    this.a = paramb;
    this.b = paramb.c();
    this.c = new y(32);
    this.d = new a(0L, this.b);
    a a1 = this.d;
    this.e = a1;
    this.f = a1;
  }
  
  private int a(int paramInt) {
    if (!this.f.c)
      this.f.a(this.a.a(), new a(this.f.b, this.b)); 
    return Math.min(paramInt, (int)(this.f.b - this.g));
  }
  
  private static a a(a parama, long paramLong) {
    while (paramLong >= parama.b)
      parama = parama.e; 
    return parama;
  }
  
  private static a a(a parama, long paramLong, ByteBuffer paramByteBuffer, int paramInt) {
    parama = a(parama, paramLong);
    while (paramInt > 0) {
      int j = Math.min(paramInt, (int)(parama.b - paramLong));
      paramByteBuffer.put(parama.d.a, parama.a(paramLong), j);
      int i = paramInt - j;
      long l = paramLong + j;
      paramLong = l;
      paramInt = i;
      if (l == parama.b) {
        parama = parama.e;
        paramLong = l;
        paramInt = i;
      } 
    } 
    return parama;
  }
  
  private static a a(a parama, long paramLong, byte[] paramArrayOfbyte, int paramInt) {
    parama = a(parama, paramLong);
    int i = paramInt;
    while (i > 0) {
      int k = Math.min(i, (int)(parama.b - paramLong));
      System.arraycopy(parama.d.a, parama.a(paramLong), paramArrayOfbyte, paramInt - i, k);
      int j = i - k;
      long l = paramLong + k;
      paramLong = l;
      i = j;
      if (l == parama.b) {
        parama = parama.e;
        paramLong = l;
        i = j;
      } 
    } 
    return parama;
  }
  
  private static a a(a parama, g paramg, w.a parama1, y paramy) {
    a a1 = parama;
    if (paramg.g())
      a1 = b(parama, paramg, parama1, paramy); 
    if (paramg.e()) {
      paramy.a(4);
      parama = a(a1, parama1.b, paramy.d(), 4);
      int i = paramy.w();
      parama1.b += 4L;
      parama1.a -= 4;
      paramg.f(i);
      parama = a(parama, parama1.b, paramg.b, i);
      parama1.b += i;
      parama1.a -= i;
      paramg.e(parama1.a);
      return a(parama, parama1.b, paramg.e, parama1.a);
    } 
    paramg.f(parama1.a);
    return a(a1, parama1.b, paramg.b, parama1.a);
  }
  
  private void a(a parama) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e2expr(TypeTransformer.java:629)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:716)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:539)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s2stmt(TypeTransformer.java:820)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:843)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private static a b(a parama, g paramg, w.a parama1, y paramy) {
    // Byte code:
    //   0: aload_2
    //   1: getfield b : J
    //   4: lstore #7
    //   6: aload_3
    //   7: iconst_1
    //   8: invokevirtual a : (I)V
    //   11: aload_0
    //   12: lload #7
    //   14: aload_3
    //   15: invokevirtual d : ()[B
    //   18: iconst_1
    //   19: invokestatic a : (Lcom/applovin/exoplayer2/h/v$a;J[BI)Lcom/applovin/exoplayer2/h/v$a;
    //   22: astore_0
    //   23: lload #7
    //   25: lconst_1
    //   26: ladd
    //   27: lstore #7
    //   29: aload_3
    //   30: invokevirtual d : ()[B
    //   33: astore #11
    //   35: iconst_0
    //   36: istore #6
    //   38: aload #11
    //   40: iconst_0
    //   41: baload
    //   42: istore #5
    //   44: iload #5
    //   46: sipush #128
    //   49: iand
    //   50: ifeq -> 59
    //   53: iconst_1
    //   54: istore #4
    //   56: goto -> 62
    //   59: iconst_0
    //   60: istore #4
    //   62: iload #5
    //   64: bipush #127
    //   66: iand
    //   67: istore #5
    //   69: aload_1
    //   70: getfield a : Lcom/applovin/exoplayer2/c/c;
    //   73: astore #13
    //   75: aload #13
    //   77: getfield a : [B
    //   80: ifnonnull -> 95
    //   83: aload #13
    //   85: bipush #16
    //   87: newarray byte
    //   89: putfield a : [B
    //   92: goto -> 104
    //   95: aload #13
    //   97: getfield a : [B
    //   100: iconst_0
    //   101: invokestatic fill : ([BB)V
    //   104: aload_0
    //   105: lload #7
    //   107: aload #13
    //   109: getfield a : [B
    //   112: iload #5
    //   114: invokestatic a : (Lcom/applovin/exoplayer2/h/v$a;J[BI)Lcom/applovin/exoplayer2/h/v$a;
    //   117: astore_0
    //   118: lload #7
    //   120: iload #5
    //   122: i2l
    //   123: ladd
    //   124: lstore #7
    //   126: iload #4
    //   128: ifeq -> 165
    //   131: aload_3
    //   132: iconst_2
    //   133: invokevirtual a : (I)V
    //   136: aload_0
    //   137: lload #7
    //   139: aload_3
    //   140: invokevirtual d : ()[B
    //   143: iconst_2
    //   144: invokestatic a : (Lcom/applovin/exoplayer2/h/v$a;J[BI)Lcom/applovin/exoplayer2/h/v$a;
    //   147: astore_0
    //   148: lload #7
    //   150: ldc2_w 2
    //   153: ladd
    //   154: lstore #7
    //   156: aload_3
    //   157: invokevirtual i : ()I
    //   160: istore #5
    //   162: goto -> 168
    //   165: iconst_1
    //   166: istore #5
    //   168: aload #13
    //   170: getfield d : [I
    //   173: astore #11
    //   175: aload #11
    //   177: ifnull -> 191
    //   180: aload #11
    //   182: astore_1
    //   183: aload #11
    //   185: arraylength
    //   186: iload #5
    //   188: if_icmpge -> 196
    //   191: iload #5
    //   193: newarray int
    //   195: astore_1
    //   196: aload #13
    //   198: getfield e : [I
    //   201: astore #12
    //   203: aload #12
    //   205: ifnull -> 220
    //   208: aload #12
    //   210: astore #11
    //   212: aload #12
    //   214: arraylength
    //   215: iload #5
    //   217: if_icmpge -> 226
    //   220: iload #5
    //   222: newarray int
    //   224: astore #11
    //   226: iload #4
    //   228: ifeq -> 315
    //   231: iload #5
    //   233: bipush #6
    //   235: imul
    //   236: istore #4
    //   238: aload_3
    //   239: iload #4
    //   241: invokevirtual a : (I)V
    //   244: aload_0
    //   245: lload #7
    //   247: aload_3
    //   248: invokevirtual d : ()[B
    //   251: iload #4
    //   253: invokestatic a : (Lcom/applovin/exoplayer2/h/v$a;J[BI)Lcom/applovin/exoplayer2/h/v$a;
    //   256: astore #12
    //   258: lload #7
    //   260: iload #4
    //   262: i2l
    //   263: ladd
    //   264: lstore #9
    //   266: aload_3
    //   267: iconst_0
    //   268: invokevirtual d : (I)V
    //   271: iload #6
    //   273: istore #4
    //   275: lload #9
    //   277: lstore #7
    //   279: aload #12
    //   281: astore_0
    //   282: iload #4
    //   284: iload #5
    //   286: if_icmpge -> 336
    //   289: aload_1
    //   290: iload #4
    //   292: aload_3
    //   293: invokevirtual i : ()I
    //   296: iastore
    //   297: aload #11
    //   299: iload #4
    //   301: aload_3
    //   302: invokevirtual w : ()I
    //   305: iastore
    //   306: iload #4
    //   308: iconst_1
    //   309: iadd
    //   310: istore #4
    //   312: goto -> 275
    //   315: aload_1
    //   316: iconst_0
    //   317: iconst_0
    //   318: iastore
    //   319: aload #11
    //   321: iconst_0
    //   322: aload_2
    //   323: getfield a : I
    //   326: lload #7
    //   328: aload_2
    //   329: getfield b : J
    //   332: lsub
    //   333: l2i
    //   334: isub
    //   335: iastore
    //   336: aload_2
    //   337: getfield c : Lcom/applovin/exoplayer2/e/x$a;
    //   340: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   343: checkcast com/applovin/exoplayer2/e/x$a
    //   346: astore_3
    //   347: aload #13
    //   349: iload #5
    //   351: aload_1
    //   352: aload #11
    //   354: aload_3
    //   355: getfield b : [B
    //   358: aload #13
    //   360: getfield a : [B
    //   363: aload_3
    //   364: getfield a : I
    //   367: aload_3
    //   368: getfield c : I
    //   371: aload_3
    //   372: getfield d : I
    //   375: invokevirtual a : (I[I[I[B[BIII)V
    //   378: lload #7
    //   380: aload_2
    //   381: getfield b : J
    //   384: lsub
    //   385: l2i
    //   386: istore #4
    //   388: aload_2
    //   389: aload_2
    //   390: getfield b : J
    //   393: iload #4
    //   395: i2l
    //   396: ladd
    //   397: putfield b : J
    //   400: aload_2
    //   401: aload_2
    //   402: getfield a : I
    //   405: iload #4
    //   407: isub
    //   408: putfield a : I
    //   411: aload_0
    //   412: areturn
  }
  
  private void b(int paramInt) {
    this.g += paramInt;
    if (this.g == this.f.b)
      this.f = this.f.e; 
  }
  
  public int a(g paramg, int paramInt, boolean paramBoolean) throws IOException {
    paramInt = a(paramInt);
    paramInt = paramg.a(this.f.d.a, this.f.a(this.g), paramInt);
    if (paramInt == -1) {
      if (paramBoolean)
        return -1; 
      throw new EOFException();
    } 
    b(paramInt);
    return paramInt;
  }
  
  public void a() {
    a(this.d);
    this.d = new a(0L, this.b);
    a a1 = this.d;
    this.e = a1;
    this.f = a1;
    this.g = 0L;
    this.a.b();
  }
  
  public void a(long paramLong) {
    if (paramLong == -1L)
      return; 
    while (paramLong >= this.d.b) {
      this.a.a(this.d.d);
      this.d = this.d.a();
    } 
    if (this.e.a < this.d.a)
      this.e = this.d; 
  }
  
  public void a(g paramg, w.a parama) {
    this.e = a(this.e, paramg, parama, this.c);
  }
  
  public void a(y paramy, int paramInt) {
    while (paramInt > 0) {
      int i = a(paramInt);
      paramy.a(this.f.d.a, this.f.a(this.g), i);
      paramInt -= i;
      b(i);
    } 
  }
  
  public void b() {
    this.e = this.d;
  }
  
  public void b(g paramg, w.a parama) {
    a(this.e, paramg, parama, this.c);
  }
  
  public long c() {
    return this.g;
  }
  
  private static final class a {
    public final long a;
    
    public final long b;
    
    public boolean c;
    
    @Nullable
    public com.applovin.exoplayer2.k.a d;
    
    @Nullable
    public a e;
    
    public a(long param1Long, int param1Int) {
      this.a = param1Long;
      this.b = param1Long + param1Int;
    }
    
    public int a(long param1Long) {
      return (int)(param1Long - this.a) + this.d.b;
    }
    
    public a a() {
      this.d = null;
      a a1 = this.e;
      this.e = null;
      return a1;
    }
    
    public void a(com.applovin.exoplayer2.k.a param1a, a param1a1) {
      this.d = param1a;
      this.e = param1a1;
      this.c = true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */