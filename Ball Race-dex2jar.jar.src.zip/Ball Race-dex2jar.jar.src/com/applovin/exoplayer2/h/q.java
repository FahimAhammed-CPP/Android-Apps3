package com.applovin.exoplayer2.h;

import android.os.Handler;
import androidx.annotation.CheckResult;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.h;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.v;
import java.io.IOException;
import java.util.concurrent.CopyOnWriteArrayList;

public interface q {
  void a(int paramInt, @Nullable p.a parama, j paramj, m paramm);
  
  void a(int paramInt, @Nullable p.a parama, j paramj, m paramm, IOException paramIOException, boolean paramBoolean);
  
  void a(int paramInt, @Nullable p.a parama, m paramm);
  
  void b(int paramInt, @Nullable p.a parama, j paramj, m paramm);
  
  void c(int paramInt, @Nullable p.a parama, j paramj, m paramm);
  
  public static class a {
    public final int a;
    
    @Nullable
    public final p.a b;
    
    private final CopyOnWriteArrayList<a> c;
    
    private final long d;
    
    public a() {
      this(new CopyOnWriteArrayList<a>(), 0, null, 0L);
    }
    
    private a(CopyOnWriteArrayList<a> param1CopyOnWriteArrayList, int param1Int, @Nullable p.a param1a, long param1Long) {
      this.c = param1CopyOnWriteArrayList;
      this.a = param1Int;
      this.b = param1a;
      this.d = param1Long;
    }
    
    private long a(long param1Long) {
      param1Long = h.a(param1Long);
      return (param1Long == -9223372036854775807L) ? -9223372036854775807L : (this.d + param1Long);
    }
    
    @CheckResult
    public a a(int param1Int, @Nullable p.a param1a, long param1Long) {
      return new a(this.c, param1Int, param1a, param1Long);
    }
    
    public void a(int param1Int1, @Nullable v param1v, int param1Int2, @Nullable Object param1Object, long param1Long) {
      a(new m(1, param1Int1, param1v, param1Int2, param1Object, a(param1Long), -9223372036854775807L));
    }
    
    public void a(Handler param1Handler, q param1q) {
      com.applovin.exoplayer2.l.a.b(param1Handler);
      com.applovin.exoplayer2.l.a.b(param1q);
      this.c.add(new a(param1Handler, param1q));
    }
    
    public void a(j param1j, int param1Int1, int param1Int2, @Nullable v param1v, int param1Int3, @Nullable Object param1Object, long param1Long1, long param1Long2) {
      a(param1j, new m(param1Int1, param1Int2, param1v, param1Int3, param1Object, a(param1Long1), a(param1Long2)));
    }
    
    public void a(j param1j, int param1Int1, int param1Int2, @Nullable v param1v, int param1Int3, @Nullable Object param1Object, long param1Long1, long param1Long2, IOException param1IOException, boolean param1Boolean) {
      a(param1j, new m(param1Int1, param1Int2, param1v, param1Int3, param1Object, a(param1Long1), a(param1Long2)), param1IOException, param1Boolean);
    }
    
    public void a(j param1j, m param1m) {
      for (a a1 : this.c) {
        q q = a1.b;
        ai.a(a1.a, (Runnable)new -$.Lambda.q.a.jp93sbuuwjqfsL9Vz_spoYvbkgU(this, q, param1j, param1m));
      } 
    }
    
    public void a(j param1j, m param1m, IOException param1IOException, boolean param1Boolean) {
      for (a a1 : this.c) {
        q q = a1.b;
        ai.a(a1.a, (Runnable)new -$.Lambda.q.a.fwAY2kWrd3fQP8F3i-Fko20MCXU(this, q, param1j, param1m, param1IOException, param1Boolean));
      } 
    }
    
    public void a(m param1m) {
      for (a a1 : this.c) {
        q q = a1.b;
        ai.a(a1.a, (Runnable)new -$.Lambda.q.a.TZ-79c-fAXlk-f_-SOhD1M_a5BM(this, q, param1m));
      } 
    }
    
    public void a(q param1q) {
      for (a a1 : this.c) {
        if (a1.b == param1q)
          this.c.remove(a1); 
      } 
    }
    
    public void b(j param1j, int param1Int1, int param1Int2, @Nullable v param1v, int param1Int3, @Nullable Object param1Object, long param1Long1, long param1Long2) {
      b(param1j, new m(param1Int1, param1Int2, param1v, param1Int3, param1Object, a(param1Long1), a(param1Long2)));
    }
    
    public void b(j param1j, m param1m) {
      for (a a1 : this.c) {
        q q = a1.b;
        ai.a(a1.a, new -$$Lambda$q$a$O8ApIHaJFohvKsBeF_RWIachvqo(this, q, param1j, param1m));
      } 
    }
    
    public void c(j param1j, int param1Int1, int param1Int2, @Nullable v param1v, int param1Int3, @Nullable Object param1Object, long param1Long1, long param1Long2) {
      c(param1j, new m(param1Int1, param1Int2, param1v, param1Int3, param1Object, a(param1Long1), a(param1Long2)));
    }
    
    public void c(j param1j, m param1m) {
      for (a a1 : this.c) {
        q q = a1.b;
        ai.a(a1.a, new -$$Lambda$q$a$lhiicm4cZQcgfFULysWrz4s4IlU(this, q, param1j, param1m));
      } 
    }
    
    private static final class a {
      public Handler a;
      
      public q b;
      
      public a(Handler param2Handler, q param2q) {
        this.a = param2Handler;
        this.b = param2q;
      }
    }
  }
  
  private static final class a {
    public Handler a;
    
    public q b;
    
    public a(Handler param1Handler, q param1q) {
      this.a = param1Handler;
      this.b = param1q;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */