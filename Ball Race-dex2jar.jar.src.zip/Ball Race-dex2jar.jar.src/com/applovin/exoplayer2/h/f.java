package com.applovin.exoplayer2.h;

import android.content.Context;
import android.util.SparseArray;
import com.applovin.exoplayer2.e.l;
import com.applovin.exoplayer2.k.i;
import com.applovin.exoplayer2.k.o;

public final class f implements r {
  private final i.a a;
  
  private final SparseArray<r> b;
  
  private final int[] c;
  
  private long d;
  
  private long e;
  
  private long f;
  
  private float g;
  
  private float h;
  
  public f(Context paramContext, l paraml) {
    this((i.a)new o.a(paramContext), paraml);
  }
  
  public f(i.a parama, l paraml) {
    this.a = parama;
    this.b = a(parama, paraml);
    this.c = new int[this.b.size()];
    for (int i = 0; i < this.b.size(); i++)
      this.c[i] = this.b.keyAt(i); 
    this.d = -9223372036854775807L;
    this.e = -9223372036854775807L;
    this.f = -9223372036854775807L;
    this.g = -3.4028235E38F;
    this.h = -3.4028235E38F;
  }
  
  private static SparseArray<r> a(i.a parama, l paraml) {
    SparseArray sparseArray = new SparseArray();
    try {
      sparseArray.put(0, Class.forName("com.applovin.exoplayer2.source.dash.DashMediaSource$Factory").<r>asSubclass(r.class).getConstructor(new Class[] { i.a.class }).newInstance(new Object[] { parama }));
    } catch (Exception exception) {}
    try {
      sparseArray.put(1, Class.forName("com.applovin.exoplayer2.source.smoothstreaming.SsMediaSource$Factory").<r>asSubclass(r.class).getConstructor(new Class[] { i.a.class }).newInstance(new Object[] { parama }));
    } catch (Exception exception) {}
    try {
      sparseArray.put(2, Class.forName("com.applovin.exoplayer2.source.hls.HlsMediaSource$Factory").<r>asSubclass(r.class).getConstructor(new Class[] { i.a.class }).newInstance(new Object[] { parama }));
    } catch (Exception exception) {}
    try {
      sparseArray.put(3, Class.forName("com.applovin.exoplayer2.source.rtsp.RtspMediaSource$Factory").<r>asSubclass(r.class).getConstructor(new Class[0]).newInstance(new Object[0]));
    } catch (Exception exception) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */