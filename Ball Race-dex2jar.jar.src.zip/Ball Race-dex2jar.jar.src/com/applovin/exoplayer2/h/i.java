package com.applovin.exoplayer2.h;

import android.net.Uri;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.k.aa;
import com.applovin.exoplayer2.k.i;
import com.applovin.exoplayer2.k.l;
import com.applovin.exoplayer2.l.y;
import java.io.IOException;
import java.util.List;
import java.util.Map;

final class i implements i {
  private final i a;
  
  private final int b;
  
  private final a c;
  
  private final byte[] d;
  
  private int e;
  
  public i(i parami, int paramInt, a parama) {
    boolean bool;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.a(bool);
    this.a = parami;
    this.b = paramInt;
    this.c = parama;
    this.d = new byte[1];
    this.e = paramInt;
  }
  
  private boolean d() throws IOException {
    int n;
    if (this.a.a(this.d, 0, 1) == -1)
      return false; 
    int j = (this.d[0] & 0xFF) << 4;
    if (j == 0)
      return true; 
    byte[] arrayOfByte = new byte[j];
    int k = j;
    int m = 0;
    while (true) {
      n = j;
      if (k > 0) {
        n = this.a.a(arrayOfByte, m, k);
        if (n == -1)
          return false; 
        m += n;
        k -= n;
        continue;
      } 
      break;
    } 
    while (n > 0 && arrayOfByte[n - 1] == 0)
      n--; 
    if (n > 0)
      this.c.a(new y(arrayOfByte, n)); 
    return true;
  }
  
  public int a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    if (this.e == 0)
      if (d()) {
        this.e = this.b;
      } else {
        return -1;
      }  
    paramInt1 = this.a.a(paramArrayOfbyte, paramInt1, Math.min(this.e, paramInt2));
    if (paramInt1 != -1)
      this.e -= paramInt1; 
    return paramInt1;
  }
  
  public long a(l paraml) {
    throw new UnsupportedOperationException();
  }
  
  @Nullable
  public Uri a() {
    return this.a.a();
  }
  
  public void a(aa paramaa) {
    com.applovin.exoplayer2.l.a.b(paramaa);
    this.a.a(paramaa);
  }
  
  public Map<String, List<String>> b() {
    return this.a.b();
  }
  
  public void c() {
    throw new UnsupportedOperationException();
  }
  
  public static interface a {
    void a(y param1y);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */