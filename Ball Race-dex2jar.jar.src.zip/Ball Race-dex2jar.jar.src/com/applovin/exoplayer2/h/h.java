package com.applovin.exoplayer2.h;

import com.applovin.exoplayer2.ba;

public abstract class h extends ba {
  protected final ba c;
  
  public h(ba paramba) {
    this.c = paramba;
  }
  
  public int a(int paramInt1, int paramInt2, boolean paramBoolean) {
    return this.c.a(paramInt1, paramInt2, paramBoolean);
  }
  
  public int a(boolean paramBoolean) {
    return this.c.a(paramBoolean);
  }
  
  public ba.a a(int paramInt, ba.a parama, boolean paramBoolean) {
    return this.c.a(paramInt, parama, paramBoolean);
  }
  
  public ba.c a(int paramInt, ba.c paramc, long paramLong) {
    return this.c.a(paramInt, paramc, paramLong);
  }
  
  public Object a(int paramInt) {
    return this.c.a(paramInt);
  }
  
  public int b() {
    return this.c.b();
  }
  
  public int b(int paramInt1, int paramInt2, boolean paramBoolean) {
    return this.c.b(paramInt1, paramInt2, paramBoolean);
  }
  
  public int b(boolean paramBoolean) {
    return this.c.b(paramBoolean);
  }
  
  public int c() {
    return this.c.c();
  }
  
  public int c(Object paramObject) {
    return this.c.c(paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */