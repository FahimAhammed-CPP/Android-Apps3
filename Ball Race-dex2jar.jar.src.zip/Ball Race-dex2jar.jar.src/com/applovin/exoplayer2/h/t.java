package com.applovin.exoplayer2.h;

import android.net.Uri;
import android.os.Handler;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ai;
import com.applovin.exoplayer2.av;
import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.d.g;
import com.applovin.exoplayer2.d.h;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.x;
import com.applovin.exoplayer2.h;
import com.applovin.exoplayer2.k.g;
import com.applovin.exoplayer2.k.i;
import com.applovin.exoplayer2.k.l;
import com.applovin.exoplayer2.k.v;
import com.applovin.exoplayer2.k.w;
import com.applovin.exoplayer2.k.z;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.g;
import com.applovin.exoplayer2.l.u;
import com.applovin.exoplayer2.l.y;
import com.applovin.exoplayer2.v;
import com.applovin.exoplayer2.w;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class t implements j, n, w.c, w.a<t.a>, w.e {
  private static final Map<String, String> b = t();
  
  private static final v c = (new v.a()).a("icy").f("application/x-icy").a();
  
  private e A;
  
  private v B;
  
  private long C;
  
  private boolean D;
  
  private int E;
  
  private boolean F;
  
  private boolean G;
  
  private int H;
  
  private long I;
  
  private long J;
  
  private long K;
  
  private boolean L;
  
  private int M;
  
  private boolean N;
  
  private boolean O;
  
  private final Uri d;
  
  private final i e;
  
  private final h f;
  
  private final v g;
  
  private final q.a h;
  
  private final g.a i;
  
  private final b j;
  
  private final com.applovin.exoplayer2.k.b k;
  
  @Nullable
  private final String l;
  
  private final long m;
  
  private final w n;
  
  private final s o;
  
  private final g p;
  
  private final Runnable q;
  
  private final Runnable r;
  
  private final Handler s;
  
  @Nullable
  private n.a t;
  
  @Nullable
  private com.applovin.exoplayer2.g.d.b u;
  
  private w[] v;
  
  private d[] w;
  
  private boolean x;
  
  private boolean y;
  
  private boolean z;
  
  public t(Uri paramUri, i parami, s params, h paramh, g.a parama, v paramv, q.a parama1, b paramb, com.applovin.exoplayer2.k.b paramb1, @Nullable String paramString, int paramInt) {
    this.d = paramUri;
    this.e = parami;
    this.f = paramh;
    this.i = parama;
    this.g = paramv;
    this.h = parama1;
    this.j = paramb;
    this.k = paramb1;
    this.l = paramString;
    this.m = paramInt;
    this.n = new w("ProgressiveMediaPeriod");
    this.o = params;
    this.p = new g();
    this.q = (Runnable)new -$.Lambda.t.PnWF5zff0virUlnkzxpucOrk9M(this);
    this.r = (Runnable)new -$.Lambda.t.rt3lRshSS8wD_wOkkWfDuloePcA(this);
    this.s = ai.a();
    this.w = new d[0];
    this.v = new w[0];
    this.K = -9223372036854775807L;
    this.I = -1L;
    this.C = -9223372036854775807L;
    this.E = 1;
  }
  
  private x a(d paramd) {
    int m = this.v.length;
    int k;
    for (k = 0; k < m; k++) {
      if (paramd.equals(this.w[k]))
        return this.v[k]; 
    } 
    w w1 = w.a(this.k, this.s.getLooper(), this.f, this.i);
    w1.a(this);
    d[] arrayOfD = this.w;
    k = m + 1;
    arrayOfD = Arrays.<d>copyOf(arrayOfD, k);
    arrayOfD[m] = paramd;
    this.w = (d[])ai.a((Object[])arrayOfD);
    w[] arrayOfW = Arrays.<w>copyOf(this.v, k);
    arrayOfW[m] = w1;
    this.v = (w[])ai.a((Object[])arrayOfW);
    return w1;
  }
  
  private void a(a parama) {
    if (this.I == -1L)
      this.I = a.e(parama); 
  }
  
  private boolean a(a parama, int paramInt) {
    if (this.I == -1L) {
      v v1 = this.B;
      if (v1 == null || v1.b() == -9223372036854775807L) {
        boolean bool = this.y;
        paramInt = 0;
        if (bool && !m()) {
          this.L = true;
          return false;
        } 
        this.G = this.y;
        this.J = 0L;
        this.M = 0;
        w[] arrayOfW = this.v;
        int k = arrayOfW.length;
        while (paramInt < k) {
          arrayOfW[paramInt].b();
          paramInt++;
        } 
        a.a(parama, 0L, 0L);
        return true;
      } 
    } 
    this.M = paramInt;
    return true;
  }
  
  private boolean a(boolean[] paramArrayOfboolean, long paramLong) {
    int m = this.v.length;
    int k;
    for (k = 0; k < m; k++) {
      if (!this.v[k].a(paramLong, false) && (paramArrayOfboolean[k] || !this.z))
        return false; 
    } 
    return true;
  }
  
  private void b(v paramv) {
    boolean bool;
    v.b b2;
    if (this.u == null) {
      v v1 = paramv;
    } else {
      b2 = new v.b(-9223372036854775807L);
    } 
    this.B = (v)b2;
    this.C = paramv.b();
    long l = this.I;
    byte b1 = 1;
    if (l == -1L && paramv.b() == -9223372036854775807L) {
      bool = true;
    } else {
      bool = false;
    } 
    this.D = bool;
    if (this.D)
      b1 = 7; 
    this.E = b1;
    this.j.a(this.C, paramv.a(), this.D);
    if (!this.y)
      n(); 
  }
  
  private void c(int paramInt) {
    s();
    boolean[] arrayOfBoolean = this.A.d;
    if (!arrayOfBoolean[paramInt]) {
      v v1 = this.A.a.a(paramInt).a(0);
      this.h.a(u.e(v1.l), v1, 0, (Object)null, this.J);
      arrayOfBoolean[paramInt] = true;
    } 
  }
  
  private void d(int paramInt) {
    s();
    boolean[] arrayOfBoolean = this.A.b;
    if (this.L && arrayOfBoolean[paramInt]) {
      w w1 = this.v[paramInt];
      paramInt = 0;
      if (w1.b(false))
        return; 
      this.K = 0L;
      this.L = false;
      this.G = true;
      this.J = 0L;
      this.M = 0;
      w[] arrayOfW = this.v;
      int k = arrayOfW.length;
      while (paramInt < k) {
        arrayOfW[paramInt].b();
        paramInt++;
      } 
      ((n.a)com.applovin.exoplayer2.l.a.b(this.t)).a(this);
    } 
  }
  
  private boolean m() {
    return (this.G || r());
  }
  
  private void n() {
    // Byte code:
    //   0: aload_0
    //   1: getfield O : Z
    //   4: ifne -> 415
    //   7: aload_0
    //   8: getfield y : Z
    //   11: ifne -> 415
    //   14: aload_0
    //   15: getfield x : Z
    //   18: ifeq -> 415
    //   21: aload_0
    //   22: getfield B : Lcom/applovin/exoplayer2/e/v;
    //   25: ifnonnull -> 29
    //   28: return
    //   29: aload_0
    //   30: getfield v : [Lcom/applovin/exoplayer2/h/w;
    //   33: astore #5
    //   35: aload #5
    //   37: arraylength
    //   38: istore_2
    //   39: iconst_0
    //   40: istore_1
    //   41: iload_1
    //   42: iload_2
    //   43: if_icmpge -> 64
    //   46: aload #5
    //   48: iload_1
    //   49: aaload
    //   50: invokevirtual g : ()Lcom/applovin/exoplayer2/v;
    //   53: ifnonnull -> 57
    //   56: return
    //   57: iload_1
    //   58: iconst_1
    //   59: iadd
    //   60: istore_1
    //   61: goto -> 41
    //   64: aload_0
    //   65: getfield p : Lcom/applovin/exoplayer2/l/g;
    //   68: invokevirtual b : ()Z
    //   71: pop
    //   72: aload_0
    //   73: getfield v : [Lcom/applovin/exoplayer2/h/w;
    //   76: arraylength
    //   77: istore_2
    //   78: iload_2
    //   79: anewarray com/applovin/exoplayer2/h/ac
    //   82: astore #8
    //   84: iload_2
    //   85: newarray boolean
    //   87: astore #9
    //   89: iconst_0
    //   90: istore_1
    //   91: iload_1
    //   92: iload_2
    //   93: if_icmpge -> 372
    //   96: aload_0
    //   97: getfield v : [Lcom/applovin/exoplayer2/h/w;
    //   100: iload_1
    //   101: aaload
    //   102: invokevirtual g : ()Lcom/applovin/exoplayer2/v;
    //   105: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   108: checkcast com/applovin/exoplayer2/v
    //   111: astore #7
    //   113: aload #7
    //   115: getfield l : Ljava/lang/String;
    //   118: astore #5
    //   120: aload #5
    //   122: invokestatic a : (Ljava/lang/String;)Z
    //   125: istore #4
    //   127: iload #4
    //   129: ifne -> 148
    //   132: aload #5
    //   134: invokestatic b : (Ljava/lang/String;)Z
    //   137: ifeq -> 143
    //   140: goto -> 148
    //   143: iconst_0
    //   144: istore_3
    //   145: goto -> 150
    //   148: iconst_1
    //   149: istore_3
    //   150: aload #9
    //   152: iload_1
    //   153: iload_3
    //   154: bastore
    //   155: aload_0
    //   156: iload_3
    //   157: aload_0
    //   158: getfield z : Z
    //   161: ior
    //   162: putfield z : Z
    //   165: aload_0
    //   166: getfield u : Lcom/applovin/exoplayer2/g/d/b;
    //   169: astore #10
    //   171: aload #7
    //   173: astore #6
    //   175: aload #10
    //   177: ifnull -> 331
    //   180: iload #4
    //   182: ifne -> 201
    //   185: aload #7
    //   187: astore #5
    //   189: aload_0
    //   190: getfield w : [Lcom/applovin/exoplayer2/h/t$d;
    //   193: iload_1
    //   194: aaload
    //   195: getfield b : Z
    //   198: ifeq -> 265
    //   201: aload #7
    //   203: getfield j : Lcom/applovin/exoplayer2/g/a;
    //   206: astore #5
    //   208: aload #5
    //   210: ifnonnull -> 234
    //   213: new com/applovin/exoplayer2/g/a
    //   216: dup
    //   217: iconst_1
    //   218: anewarray com/applovin/exoplayer2/g/a$a
    //   221: dup
    //   222: iconst_0
    //   223: aload #10
    //   225: aastore
    //   226: invokespecial <init> : ([Lcom/applovin/exoplayer2/g/a$a;)V
    //   229: astore #5
    //   231: goto -> 250
    //   234: aload #5
    //   236: iconst_1
    //   237: anewarray com/applovin/exoplayer2/g/a$a
    //   240: dup
    //   241: iconst_0
    //   242: aload #10
    //   244: aastore
    //   245: invokevirtual a : ([Lcom/applovin/exoplayer2/g/a$a;)Lcom/applovin/exoplayer2/g/a;
    //   248: astore #5
    //   250: aload #7
    //   252: invokevirtual a : ()Lcom/applovin/exoplayer2/v$a;
    //   255: aload #5
    //   257: invokevirtual a : (Lcom/applovin/exoplayer2/g/a;)Lcom/applovin/exoplayer2/v$a;
    //   260: invokevirtual a : ()Lcom/applovin/exoplayer2/v;
    //   263: astore #5
    //   265: aload #5
    //   267: astore #6
    //   269: iload #4
    //   271: ifeq -> 331
    //   274: aload #5
    //   276: astore #6
    //   278: aload #5
    //   280: getfield f : I
    //   283: iconst_m1
    //   284: if_icmpne -> 331
    //   287: aload #5
    //   289: astore #6
    //   291: aload #5
    //   293: getfield g : I
    //   296: iconst_m1
    //   297: if_icmpne -> 331
    //   300: aload #5
    //   302: astore #6
    //   304: aload #10
    //   306: getfield a : I
    //   309: iconst_m1
    //   310: if_icmpeq -> 331
    //   313: aload #5
    //   315: invokevirtual a : ()Lcom/applovin/exoplayer2/v$a;
    //   318: aload #10
    //   320: getfield a : I
    //   323: invokevirtual d : (I)Lcom/applovin/exoplayer2/v$a;
    //   326: invokevirtual a : ()Lcom/applovin/exoplayer2/v;
    //   329: astore #6
    //   331: aload #8
    //   333: iload_1
    //   334: new com/applovin/exoplayer2/h/ac
    //   337: dup
    //   338: iconst_1
    //   339: anewarray com/applovin/exoplayer2/v
    //   342: dup
    //   343: iconst_0
    //   344: aload #6
    //   346: aload_0
    //   347: getfield f : Lcom/applovin/exoplayer2/d/h;
    //   350: aload #6
    //   352: invokeinterface a : (Lcom/applovin/exoplayer2/v;)I
    //   357: invokevirtual a : (I)Lcom/applovin/exoplayer2/v;
    //   360: aastore
    //   361: invokespecial <init> : ([Lcom/applovin/exoplayer2/v;)V
    //   364: aastore
    //   365: iload_1
    //   366: iconst_1
    //   367: iadd
    //   368: istore_1
    //   369: goto -> 91
    //   372: aload_0
    //   373: new com/applovin/exoplayer2/h/t$e
    //   376: dup
    //   377: new com/applovin/exoplayer2/h/ad
    //   380: dup
    //   381: aload #8
    //   383: invokespecial <init> : ([Lcom/applovin/exoplayer2/h/ac;)V
    //   386: aload #9
    //   388: invokespecial <init> : (Lcom/applovin/exoplayer2/h/ad;[Z)V
    //   391: putfield A : Lcom/applovin/exoplayer2/h/t$e;
    //   394: aload_0
    //   395: iconst_1
    //   396: putfield y : Z
    //   399: aload_0
    //   400: getfield t : Lcom/applovin/exoplayer2/h/n$a;
    //   403: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   406: checkcast com/applovin/exoplayer2/h/n$a
    //   409: aload_0
    //   410: invokeinterface a : (Lcom/applovin/exoplayer2/h/n;)V
    //   415: return
  }
  
  private void o() {
    a a1 = new a(this, this.d, this.e, this.o, this, this.p);
    if (this.y) {
      com.applovin.exoplayer2.l.a.b(r());
      long l2 = this.C;
      if (l2 != -9223372036854775807L && this.K > l2) {
        this.N = true;
        this.K = -9223372036854775807L;
        return;
      } 
      a.a(a1, (((v)com.applovin.exoplayer2.l.a.b(this.B)).a(this.K)).a.c, this.K);
      w[] arrayOfW = this.v;
      int m = arrayOfW.length;
      for (int k = 0; k < m; k++)
        arrayOfW[k].a(this.K); 
      this.K = -9223372036854775807L;
    } 
    this.M = p();
    long l = this.n.a(a1, this, this.g.a(this.E));
    l l1 = a.c(a1);
    this.h.a(new j(a.b(a1), l1, l), 1, -1, null, 0, null, a.d(a1), this.C);
  }
  
  private int p() {
    w[] arrayOfW = this.v;
    int i1 = arrayOfW.length;
    int k = 0;
    int m = 0;
    while (k < i1) {
      m += arrayOfW[k].c();
      k++;
    } 
    return m;
  }
  
  private long q() {
    w[] arrayOfW = this.v;
    int m = arrayOfW.length;
    long l = Long.MIN_VALUE;
    for (int k = 0; k < m; k++)
      l = Math.max(l, arrayOfW[k].h()); 
    return l;
  }
  
  private boolean r() {
    return (this.K != -9223372036854775807L);
  }
  
  private void s() {
    com.applovin.exoplayer2.l.a.b(this.y);
    com.applovin.exoplayer2.l.a.b(this.A);
    com.applovin.exoplayer2.l.a.b(this.B);
  }
  
  private static Map<String, String> t() {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("Icy-MetaData", "1");
    return (Map)Collections.unmodifiableMap(hashMap);
  }
  
  int a(int paramInt, long paramLong) {
    if (m())
      return 0; 
    c(paramInt);
    w w1 = this.v[paramInt];
    int k = w1.b(paramLong, this.N);
    w1.a(k);
    if (k == 0)
      d(paramInt); 
    return k;
  }
  
  int a(int paramInt1, w paramw, g paramg, int paramInt2) {
    if (m())
      return -3; 
    c(paramInt1);
    paramInt2 = this.v[paramInt1].a(paramw, paramg, paramInt2, this.N);
    if (paramInt2 == -3)
      d(paramInt1); 
    return paramInt2;
  }
  
  public long a(long paramLong, av paramav) {
    s();
    if (!this.B.a())
      return 0L; 
    v.a a1 = this.B.a(paramLong);
    return paramav.a(paramLong, a1.a.b, a1.b.b);
  }
  
  public long a(com.applovin.exoplayer2.j.d[] paramArrayOfd, boolean[] paramArrayOfboolean1, x[] paramArrayOfx, boolean[] paramArrayOfboolean2, long paramLong) {
    long l;
    s();
    ad ad = this.A.a;
    boolean[] arrayOfBoolean = this.A.c;
    int m = this.H;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool1 = false;
    int k;
    for (k = 0; k < paramArrayOfd.length; k++) {
      if (paramArrayOfx[k] != null && (paramArrayOfd[k] == null || !paramArrayOfboolean1[k])) {
        int i2 = c.a((c)paramArrayOfx[k]);
        com.applovin.exoplayer2.l.a.b(arrayOfBoolean[i2]);
        this.H--;
        arrayOfBoolean[i2] = false;
        paramArrayOfx[k] = null;
      } 
    } 
    if (this.F ? (m == 0) : (paramLong != 0L)) {
      k = 1;
    } else {
      k = 0;
    } 
    m = 0;
    int i1;
    for (i1 = k; m < paramArrayOfd.length; i1 = k) {
      k = i1;
      if (paramArrayOfx[m] == null) {
        k = i1;
        if (paramArrayOfd[m] != null) {
          boolean bool;
          com.applovin.exoplayer2.j.d d1 = paramArrayOfd[m];
          if (d1.e() == 1) {
            bool = true;
          } else {
            bool = false;
          } 
          com.applovin.exoplayer2.l.a.b(bool);
          if (d1.b(0) == 0) {
            bool = true;
          } else {
            bool = false;
          } 
          com.applovin.exoplayer2.l.a.b(bool);
          int i2 = ad.a(d1.d());
          com.applovin.exoplayer2.l.a.b(arrayOfBoolean[i2] ^ true);
          this.H++;
          arrayOfBoolean[i2] = true;
          paramArrayOfx[m] = new c(this, i2);
          paramArrayOfboolean2[m] = true;
          k = i1;
          if (i1 == 0) {
            w w1 = this.v[i2];
            if (!w1.a(paramLong, true) && w1.f() != 0) {
              k = 1;
            } else {
              k = 0;
            } 
          } 
        } 
      } 
      m++;
    } 
    if (this.H == 0) {
      this.L = false;
      this.G = false;
      if (this.n.c()) {
        w[] arrayOfW = this.v;
        m = arrayOfW.length;
        for (k = bool1; k < m; k++)
          arrayOfW[k].k(); 
        this.n.d();
        l = paramLong;
      } else {
        w[] arrayOfW = this.v;
        m = arrayOfW.length;
        k = bool2;
        while (true) {
          l = paramLong;
          if (k < m) {
            arrayOfW[k].b();
            k++;
            continue;
          } 
          break;
        } 
      } 
    } else {
      l = paramLong;
      if (i1 != 0) {
        paramLong = b(paramLong);
        k = bool3;
        while (true) {
          l = paramLong;
          if (k < paramArrayOfx.length) {
            if (paramArrayOfx[k] != null)
              paramArrayOfboolean2[k] = true; 
            k++;
            continue;
          } 
          break;
        } 
      } 
    } 
    this.F = true;
    return l;
  }
  
  public x a(int paramInt1, int paramInt2) {
    return a(new d(paramInt1, false));
  }
  
  public w.b a(a parama, long paramLong1, long paramLong2, IOException paramIOException, int paramInt) {
    w.b b1;
    a(parama);
    z z = a.a(parama);
    j j1 = new j(a.b(parama), a.c(parama), z.e(), z.f(), paramLong1, paramLong2, z.d());
    m m = new m(1, -1, null, 0, null, h.a(a.d(parama)), h.a(this.C));
    paramLong1 = this.g.a(new v.a(j1, m, paramIOException, paramInt));
    if (paramLong1 == -9223372036854775807L) {
      b1 = w.d;
    } else {
      boolean bool;
      paramInt = p();
      if (paramInt > this.M) {
        bool = true;
      } else {
        bool = false;
      } 
      if (a(parama, paramInt)) {
        b1 = w.a(bool, paramLong1);
      } else {
        b1 = w.c;
      } 
    } 
    int k = b1.a() ^ true;
    this.h.a(j1, 1, -1, null, 0, null, a.d(parama), this.C, paramIOException, k);
    if (k != 0)
      this.g.a(a.b(parama)); 
    return b1;
  }
  
  public void a() {
    this.x = true;
    this.s.post(this.q);
  }
  
  public void a(long paramLong) {}
  
  public void a(long paramLong, boolean paramBoolean) {
    s();
    if (r())
      return; 
    boolean[] arrayOfBoolean = this.A.c;
    int m = this.v.length;
    int k;
    for (k = 0; k < m; k++)
      this.v[k].a(paramLong, paramBoolean, arrayOfBoolean[k]); 
  }
  
  public void a(v paramv) {
    this.s.post((Runnable)new -$.Lambda.t.tC6SHSRtqY9KgmfW1MiSFs_J3p8(this, paramv));
  }
  
  public void a(n.a parama, long paramLong) {
    this.t = parama;
    this.p.a();
    o();
  }
  
  public void a(a parama, long paramLong1, long paramLong2) {
    if (this.C == -9223372036854775807L) {
      v v1 = this.B;
      if (v1 != null) {
        boolean bool = v1.a();
        long l = q();
        if (l == Long.MIN_VALUE) {
          l = 0L;
        } else {
          l += 10000L;
        } 
        this.C = l;
        this.j.a(this.C, bool, this.D);
      } 
    } 
    z z = a.a(parama);
    j j1 = new j(a.b(parama), a.c(parama), z.e(), z.f(), paramLong1, paramLong2, z.d());
    this.g.a(a.b(parama));
    this.h.b(j1, 1, -1, null, 0, null, a.d(parama), this.C);
    a(parama);
    this.N = true;
    ((n.a)com.applovin.exoplayer2.l.a.b(this.t)).a(this);
  }
  
  public void a(a parama, long paramLong1, long paramLong2, boolean paramBoolean) {
    z z = a.a(parama);
    j j1 = new j(a.b(parama), a.c(parama), z.e(), z.f(), paramLong1, paramLong2, z.d());
    this.g.a(a.b(parama));
    this.h.c(j1, 1, -1, null, 0, null, a.d(parama), this.C);
    if (!paramBoolean) {
      a(parama);
      w[] arrayOfW = this.v;
      int m = arrayOfW.length;
      int k;
      for (k = 0; k < m; k++)
        arrayOfW[k].b(); 
      if (this.H > 0)
        ((n.a)com.applovin.exoplayer2.l.a.b(this.t)).a(this); 
    } 
  }
  
  public void a(v paramv) {
    this.s.post(this.q);
  }
  
  boolean a(int paramInt) {
    return (!m() && this.v[paramInt].b(this.N));
  }
  
  public long b(long paramLong) {
    s();
    boolean[] arrayOfBoolean = this.A.b;
    if (!this.B.a())
      paramLong = 0L; 
    int m = 0;
    int k = 0;
    this.G = false;
    this.J = paramLong;
    if (r()) {
      this.K = paramLong;
      return paramLong;
    } 
    if (this.E != 7 && a(arrayOfBoolean, paramLong))
      return paramLong; 
    this.L = false;
    this.K = paramLong;
    this.N = false;
    if (this.n.c()) {
      w[] arrayOfW1 = this.v;
      m = arrayOfW1.length;
      while (k < m) {
        arrayOfW1[k].k();
        k++;
      } 
      this.n.d();
      return paramLong;
    } 
    this.n.b();
    w[] arrayOfW = this.v;
    int i1 = arrayOfW.length;
    for (k = m; k < i1; k++)
      arrayOfW[k].b(); 
    return paramLong;
  }
  
  public ad b() {
    s();
    return this.A.a;
  }
  
  void b(int paramInt) throws IOException {
    this.v[paramInt].e();
    i();
  }
  
  public long c() {
    if (this.G && (this.N || p() > this.M)) {
      this.G = false;
      return this.J;
    } 
    return -9223372036854775807L;
  }
  
  public boolean c(long paramLong) {
    if (this.N || this.n.a() || this.L || (this.y && this.H == 0))
      return false; 
    boolean bool = this.p.a();
    if (!this.n.c()) {
      o();
      bool = true;
    } 
    return bool;
  }
  
  public long d() {
    s();
    boolean[] arrayOfBoolean = this.A.b;
    if (this.N)
      return Long.MIN_VALUE; 
    if (r())
      return this.K; 
    if (this.z) {
      int m = this.v.length;
      int k = 0;
      long l = Long.MAX_VALUE;
      while (true) {
        l2 = l;
        if (k < m) {
          l2 = l;
          if (arrayOfBoolean[k]) {
            l2 = l;
            if (!this.v[k].j())
              l2 = Math.min(l, this.v[k].h()); 
          } 
          k++;
          l = l2;
          continue;
        } 
        break;
      } 
    } else {
      l2 = Long.MAX_VALUE;
    } 
    long l1 = l2;
    if (l2 == Long.MAX_VALUE)
      l1 = q(); 
    long l2 = l1;
    if (l1 == Long.MIN_VALUE)
      l2 = this.J; 
    return l2;
  }
  
  public long e() {
    return (this.H == 0) ? Long.MIN_VALUE : d();
  }
  
  public void e_() throws IOException {
    i();
    if (this.N) {
      if (this.y)
        return; 
      throw ai.b("Loading finished before preparation is complete.", null);
    } 
  }
  
  public boolean f() {
    return (this.n.c() && this.p.e());
  }
  
  public void g() {
    if (this.y) {
      w[] arrayOfW = this.v;
      int m = arrayOfW.length;
      for (int k = 0; k < m; k++)
        arrayOfW[k].d(); 
    } 
    this.n.a(this);
    this.s.removeCallbacksAndMessages(null);
    this.t = null;
    this.O = true;
  }
  
  public void h() {
    w[] arrayOfW = this.v;
    int m = arrayOfW.length;
    for (int k = 0; k < m; k++)
      arrayOfW[k].a(); 
    this.o.a();
  }
  
  void i() throws IOException {
    this.n.a(this.g.a(this.E));
  }
  
  x j() {
    return a(new d(0, true));
  }
  
  final class a implements i.a, w.d {
    private final long b;
    
    private final Uri c;
    
    private final z d;
    
    private final s e;
    
    private final j f;
    
    private final g g;
    
    private final u h;
    
    private volatile boolean i;
    
    private boolean j;
    
    private long k;
    
    private l l;
    
    private long m;
    
    @Nullable
    private x n;
    
    private boolean o;
    
    public a(t this$0, Uri param1Uri, i param1i, s param1s, j param1j, g param1g) {
      this.c = param1Uri;
      this.d = new z(param1i);
      this.e = param1s;
      this.f = param1j;
      this.g = param1g;
      this.h = new u();
      this.j = true;
      this.m = -1L;
      this.b = j.a();
      this.l = a(0L);
    }
    
    private l a(long param1Long) {
      return (new l.a()).a(this.c).a(param1Long).b(t.f(this.a)).b(6).a(t.l()).a();
    }
    
    private void a(long param1Long1, long param1Long2) {
      this.h.a = param1Long1;
      this.k = param1Long2;
      this.j = true;
      this.o = false;
    }
    
    public void a() {
      this.i = true;
    }
    
    public void a(y param1y) {
      long l1;
      if (!this.o) {
        l1 = this.k;
      } else {
        l1 = Math.max(t.e(this.a), this.k);
      } 
      int i = param1y.a();
      x x1 = (x)com.applovin.exoplayer2.l.a.b(this.n);
      x1.a(param1y, i);
      x1.a(l1, 1, i, 0, null);
      this.o = true;
    }
    
    public void b() throws IOException {
      int i = 0;
      label71: while (true) {
        if (!i && !this.i) {
          int k = i;
          try {
            i i1;
            long l2 = this.h.a;
            k = i;
            this.l = a(l2);
            k = i;
            this.m = this.d.a(this.l);
            k = i;
            if (this.m != -1L) {
              k = i;
              this.m += l2;
            } 
            k = i;
            t.a(this.a, com.applovin.exoplayer2.g.d.b.a(this.d.b()));
            k = i;
            z z2 = this.d;
            z z1 = z2;
            k = i;
            if (t.a(this.a) != null) {
              z1 = z2;
              k = i;
              if ((t.a(this.a)).f != -1) {
                k = i;
                i1 = new i((i)this.d, (t.a(this.a)).f, this);
                k = i;
                this.n = this.a.j();
                k = i;
                this.n.a(t.k());
              } 
            } 
            k = i;
            s s1 = this.e;
            k = i;
            Uri uri = this.c;
            k = i;
            Map<String, List<String>> map = this.d.b();
            k = i;
            long l3 = this.m;
            k = i;
            j j1 = this.f;
            long l1 = l2;
            k = i;
            s1.a((g)i1, uri, map, l2, l3, j1);
            k = i;
            if (t.a(this.a) != null) {
              k = i;
              this.e.b();
            } 
            int m = i;
            l2 = l1;
            k = i;
            if (this.j) {
              k = i;
              this.e.a(l1, this.k);
              k = i;
              this.j = false;
              l2 = l1;
              m = i;
            } 
            while (true) {
              if (!m) {
                k = m;
                boolean bool = this.i;
                if (!bool) {
                  k = m;
                  try {
                    this.g.c();
                    k = m;
                    i = this.e.a(this.h);
                    k = i;
                    l1 = this.e.c();
                    m = i;
                    k = i;
                    if (l1 > t.b(this.a) + l2) {
                      k = i;
                      this.g.b();
                      k = i;
                      t.d(this.a).post(t.c(this.a));
                      l2 = l1;
                      m = i;
                    } 
                  } catch (InterruptedException interruptedException) {
                    k = m;
                    throw new InterruptedIOException();
                  } 
                  continue;
                } 
              } 
              if (m == 1) {
                i = 0;
              } else {
                i = m;
                if (this.e.c() != -1L) {
                  this.h.a = this.e.c();
                  i = m;
                } 
              } 
              ai.a((i)this.d);
              continue label71;
            } 
          } finally {
            if (k != 1 && this.e.c() != -1L)
              this.h.a = this.e.c(); 
            ai.a((i)this.d);
          } 
          break;
        } 
        return;
      } 
    }
  }
  
  static interface b {
    void a(long param1Long, boolean param1Boolean1, boolean param1Boolean2);
  }
  
  private final class c implements x {
    private final int b;
    
    public c(t this$0, int param1Int) {
      this.b = param1Int;
    }
    
    public int a(long param1Long) {
      return this.a.a(this.b, param1Long);
    }
    
    public int a(w param1w, g param1g, int param1Int) {
      return this.a.a(this.b, param1w, param1g, param1Int);
    }
    
    public boolean b() {
      return this.a.a(this.b);
    }
    
    public void c() throws IOException {
      this.a.b(this.b);
    }
  }
  
  private static final class d {
    public final int a;
    
    public final boolean b;
    
    public d(int param1Int, boolean param1Boolean) {
      this.a = param1Int;
      this.b = param1Boolean;
    }
    
    public boolean equals(@Nullable Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        return (this.a == ((d)param1Object).a && this.b == ((d)param1Object).b);
      } 
      return false;
    }
    
    public int hashCode() {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e2expr(TypeTransformer.java:632)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:716)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
  
  private static final class e {
    public final ad a;
    
    public final boolean[] b;
    
    public final boolean[] c;
    
    public final boolean[] d;
    
    public e(ad param1ad, boolean[] param1ArrayOfboolean) {
      this.a = param1ad;
      this.b = param1ArrayOfboolean;
      this.c = new boolean[param1ad.b];
      this.d = new boolean[param1ad.b];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */