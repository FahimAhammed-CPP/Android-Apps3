package com.applovin.exoplayer2.h;

import android.net.Uri;
import com.applovin.exoplayer2.k.l;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class j {
  private static final AtomicLong h = new AtomicLong();
  
  public final long a;
  
  public final l b;
  
  public final Uri c;
  
  public final Map<String, List<String>> d;
  
  public final long e;
  
  public final long f;
  
  public final long g;
  
  public j(long paramLong1, l paraml, long paramLong2) {
    this(paramLong1, paraml, paraml.a, Collections.emptyMap(), paramLong2, 0L, 0L);
  }
  
  public j(long paramLong1, l paraml, Uri paramUri, Map<String, List<String>> paramMap, long paramLong2, long paramLong3, long paramLong4) {
    this.a = paramLong1;
    this.b = paraml;
    this.c = paramUri;
    this.d = paramMap;
    this.e = paramLong2;
    this.f = paramLong3;
    this.g = paramLong4;
  }
  
  public static long a() {
    return h.getAndIncrement();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */