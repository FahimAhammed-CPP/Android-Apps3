package com.applovin.exoplayer2.h;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.d.g;
import com.applovin.exoplayer2.k.aa;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public abstract class a implements p {
  private final ArrayList<p.b> a = new ArrayList<p.b>(1);
  
  private final HashSet<p.b> b = new HashSet<p.b>(1);
  
  private final q.a c = new q.a();
  
  private final g.a d = new g.a();
  
  @Nullable
  private Looper e;
  
  @Nullable
  private ba f;
  
  protected final g.a a(int paramInt, @Nullable p.a parama) {
    return this.d.a(paramInt, parama);
  }
  
  protected final q.a a(int paramInt, @Nullable p.a parama, long paramLong) {
    return this.c.a(paramInt, parama, paramLong);
  }
  
  protected final q.a a(@Nullable p.a parama) {
    return this.c.a(0, parama, 0L);
  }
  
  protected void a() {}
  
  public final void a(Handler paramHandler, g paramg) {
    com.applovin.exoplayer2.l.a.b(paramHandler);
    com.applovin.exoplayer2.l.a.b(paramg);
    this.d.a(paramHandler, paramg);
  }
  
  public final void a(Handler paramHandler, q paramq) {
    com.applovin.exoplayer2.l.a.b(paramHandler);
    com.applovin.exoplayer2.l.a.b(paramq);
    this.c.a(paramHandler, paramq);
  }
  
  protected final void a(ba paramba) {
    this.f = paramba;
    Iterator<p.b> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((p.b)iterator.next()).onSourceInfoRefreshed(this, paramba); 
  }
  
  public final void a(g paramg) {
    this.d.a(paramg);
  }
  
  public final void a(p.b paramb) {
    com.applovin.exoplayer2.l.a.b(this.e);
    boolean bool = this.b.isEmpty();
    this.b.add(paramb);
    if (bool)
      a(); 
  }
  
  public final void a(p.b paramb, @Nullable aa paramaa) {
    boolean bool;
    Looper looper1 = Looper.myLooper();
    Looper looper2 = this.e;
    if (looper2 == null || looper2 == looper1) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.a(bool);
    ba ba1 = this.f;
    this.a.add(paramb);
    if (this.e == null) {
      this.e = looper1;
      this.b.add(paramb);
      a(paramaa);
      return;
    } 
    if (ba1 != null) {
      a(paramb);
      paramb.onSourceInfoRefreshed(this, ba1);
    } 
  }
  
  public final void a(q paramq) {
    this.c.a(paramq);
  }
  
  protected abstract void a(@Nullable aa paramaa);
  
  protected final g.a b(@Nullable p.a parama) {
    return this.d.a(0, parama);
  }
  
  protected void b() {}
  
  public final void b(p.b paramb) {
    boolean bool = this.b.isEmpty();
    this.b.remove(paramb);
    if ((bool ^ true) != 0 && this.b.isEmpty())
      b(); 
  }
  
  protected abstract void c();
  
  public final void c(p.b paramb) {
    this.a.remove(paramb);
    if (this.a.isEmpty()) {
      this.e = null;
      this.f = null;
      this.b.clear();
      c();
      return;
    } 
    b(paramb);
  }
  
  protected final boolean d() {
    return this.b.isEmpty() ^ true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */