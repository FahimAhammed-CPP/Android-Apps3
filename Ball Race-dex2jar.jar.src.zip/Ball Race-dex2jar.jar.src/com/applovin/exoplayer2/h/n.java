package com.applovin.exoplayer2.h;

import com.applovin.exoplayer2.av;
import com.applovin.exoplayer2.j.d;
import java.io.IOException;

public interface n extends y {
  long a(long paramLong, av paramav);
  
  long a(d[] paramArrayOfd, boolean[] paramArrayOfboolean1, x[] paramArrayOfx, boolean[] paramArrayOfboolean2, long paramLong);
  
  void a(long paramLong);
  
  void a(long paramLong, boolean paramBoolean);
  
  void a(a parama, long paramLong);
  
  long b(long paramLong);
  
  ad b();
  
  long c();
  
  boolean c(long paramLong);
  
  long d();
  
  long e();
  
  void e_() throws IOException;
  
  boolean f();
  
  public static interface a extends y.a<n> {
    void a(n param1n);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */