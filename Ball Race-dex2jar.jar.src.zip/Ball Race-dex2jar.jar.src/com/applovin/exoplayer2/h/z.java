package com.applovin.exoplayer2.h;

import java.util.Arrays;
import java.util.Random;

public interface z {
  int a();
  
  int a(int paramInt);
  
  z a(int paramInt1, int paramInt2);
  
  int b();
  
  int b(int paramInt);
  
  z b(int paramInt1, int paramInt2);
  
  int c();
  
  z d();
  
  public static class a implements z {
    private final Random a;
    
    private final int[] b;
    
    private final int[] c;
    
    public a(int param1Int) {
      this(param1Int, new Random());
    }
    
    private a(int param1Int, Random param1Random) {
      this(a(param1Int, param1Random), param1Random);
    }
    
    private a(int[] param1ArrayOfint, Random param1Random) {
      this.b = param1ArrayOfint;
      this.a = param1Random;
      this.c = new int[param1ArrayOfint.length];
      for (int i = 0; i < param1ArrayOfint.length; i++)
        this.c[param1ArrayOfint[i]] = i; 
    }
    
    private static int[] a(int param1Int, Random param1Random) {
      int[] arrayOfInt = new int[param1Int];
      for (int i = 0; i < param1Int; i = j) {
        int j = i + 1;
        int k = param1Random.nextInt(j);
        arrayOfInt[i] = arrayOfInt[k];
        arrayOfInt[k] = i;
      } 
      return arrayOfInt;
    }
    
    public int a() {
      return this.b.length;
    }
    
    public int a(int param1Int) {
      param1Int = this.c[param1Int] + 1;
      int[] arrayOfInt = this.b;
      return (param1Int < arrayOfInt.length) ? arrayOfInt[param1Int] : -1;
    }
    
    public z a(int param1Int1, int param1Int2) {
      int[] arrayOfInt1 = new int[param1Int2];
      int[] arrayOfInt2 = new int[param1Int2];
      boolean bool = false;
      int i;
      for (i = 0; i < param1Int2; i = m) {
        arrayOfInt1[i] = this.a.nextInt(this.b.length + 1);
        Random random = this.a;
        int m = i + 1;
        int n = random.nextInt(m);
        arrayOfInt2[i] = arrayOfInt2[n];
        arrayOfInt2[n] = i + param1Int1;
      } 
      Arrays.sort(arrayOfInt1);
      int[] arrayOfInt3 = new int[this.b.length + param1Int2];
      int k = 0;
      int j = 0;
      for (i = bool; i < this.b.length + param1Int2; i++) {
        if (k < param1Int2 && j == arrayOfInt1[k]) {
          arrayOfInt3[i] = arrayOfInt2[k];
          k++;
        } else {
          arrayOfInt3[i] = this.b[j];
          if (arrayOfInt3[i] >= param1Int1)
            arrayOfInt3[i] = arrayOfInt3[i] + param1Int2; 
          j++;
        } 
      } 
      return new a(arrayOfInt3, new Random(this.a.nextLong()));
    }
    
    public int b() {
      int[] arrayOfInt = this.b;
      return (arrayOfInt.length > 0) ? arrayOfInt[arrayOfInt.length - 1] : -1;
    }
    
    public int b(int param1Int) {
      int i = this.c[param1Int];
      param1Int = -1;
      if (--i >= 0)
        param1Int = this.b[i]; 
      return param1Int;
    }
    
    public z b(int param1Int1, int param1Int2) {
      int k = param1Int2 - param1Int1;
      int[] arrayOfInt = new int[this.b.length - k];
      int i = 0;
      int j = 0;
      while (true) {
        int[] arrayOfInt1 = this.b;
        if (i < arrayOfInt1.length) {
          if (arrayOfInt1[i] >= param1Int1 && arrayOfInt1[i] < param1Int2) {
            j++;
          } else {
            int m;
            arrayOfInt1 = this.b;
            if (arrayOfInt1[i] >= param1Int1) {
              m = arrayOfInt1[i] - k;
            } else {
              m = arrayOfInt1[i];
            } 
            arrayOfInt[i - j] = m;
          } 
          i++;
          continue;
        } 
        return new a(arrayOfInt, new Random(this.a.nextLong()));
      } 
    }
    
    public int c() {
      int[] arrayOfInt = this.b;
      return (arrayOfInt.length > 0) ? arrayOfInt[0] : -1;
    }
    
    public z d() {
      return new a(0, new Random(this.a.nextLong()));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */