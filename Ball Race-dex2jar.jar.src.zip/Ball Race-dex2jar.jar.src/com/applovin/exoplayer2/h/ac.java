package com.applovin.exoplayer2.h;

import android.os.Bundle;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.common.a.s;
import com.applovin.exoplayer2.g;
import com.applovin.exoplayer2.l.a;
import com.applovin.exoplayer2.l.c;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.v;
import java.util.Arrays;
import java.util.List;

public final class ac implements g {
  public static final g.a<ac> b = (g.a<ac>)-$.Lambda.ac.L_aEfpqtzq0pMYyjg9Q7hkABVWg.INSTANCE;
  
  public final int a;
  
  private final v[] c;
  
  private int d;
  
  public ac(v... paramVarArgs) {
    boolean bool;
    if (paramVarArgs.length > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    a.a(bool);
    this.c = paramVarArgs;
    this.a = paramVarArgs.length;
    a();
  }
  
  private static String a(@Nullable String paramString) {
    if (paramString != null) {
      String str = paramString;
      return paramString.equals("und") ? "" : str;
    } 
    return "";
  }
  
  private void a() {
    String str = a((this.c[0]).c);
    int j = c((this.c[0]).e);
    int i = 1;
    while (true) {
      v[] arrayOfV = this.c;
      if (i < arrayOfV.length) {
        if (!str.equals(a((arrayOfV[i]).c))) {
          a("languages", (this.c[0]).c, (this.c[i]).c, i);
          return;
        } 
        if (j != c((this.c[i]).e)) {
          a("role flags", Integer.toBinaryString((this.c[0]).e), Integer.toBinaryString((this.c[i]).e), i);
          return;
        } 
        i++;
        continue;
      } 
      break;
    } 
  }
  
  private static void a(String paramString1, @Nullable String paramString2, @Nullable String paramString3, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Different ");
    stringBuilder.append(paramString1);
    stringBuilder.append(" combined in one TrackGroup: '");
    stringBuilder.append(paramString2);
    stringBuilder.append("' (track 0) and '");
    stringBuilder.append(paramString3);
    stringBuilder.append("' (track ");
    stringBuilder.append(paramInt);
    stringBuilder.append(")");
    q.c("TrackGroup", "", new IllegalStateException(stringBuilder.toString()));
  }
  
  private static String b(int paramInt) {
    return Integer.toString(paramInt, 36);
  }
  
  private static int c(int paramInt) {
    return paramInt | 0x4000;
  }
  
  public int a(v paramv) {
    int i = 0;
    while (true) {
      v[] arrayOfV = this.c;
      if (i < arrayOfV.length) {
        if (paramv == arrayOfV[i])
          return i; 
        i++;
        continue;
      } 
      return -1;
    } 
  }
  
  public v a(int paramInt) {
    return this.c[paramInt];
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.a == ((ac)paramObject).a && Arrays.equals((Object[])this.c, (Object[])((ac)paramObject).c));
    } 
    return false;
  }
  
  public int hashCode() {
    if (this.d == 0)
      this.d = 527 + Arrays.hashCode((Object[])this.c); 
    return this.d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */