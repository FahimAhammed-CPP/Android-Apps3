package com.applovin.exoplayer2.h;

import com.applovin.exoplayer2.w;

public final class g implements x {
  public int a(long paramLong) {
    return 0;
  }
  
  public int a(w paramw, com.applovin.exoplayer2.c.g paramg, int paramInt) {
    paramg.a_(4);
    return -4;
  }
  
  public boolean b() {
    return true;
  }
  
  public void c() {}
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */