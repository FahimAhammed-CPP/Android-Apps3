package com.applovin.exoplayer2.h;

import com.applovin.exoplayer2.c.g;
import com.applovin.exoplayer2.w;
import java.io.IOException;

public interface x {
  int a(long paramLong);
  
  int a(w paramw, g paramg, int paramInt);
  
  boolean b();
  
  void c() throws IOException;
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */