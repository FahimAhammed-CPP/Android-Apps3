package com.applovin.exoplayer2.h;

import android.os.Handler;
import androidx.annotation.CallSuper;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ba;
import com.applovin.exoplayer2.d.g;
import com.applovin.exoplayer2.k.aa;
import com.applovin.exoplayer2.l.ai;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

public abstract class e<T> extends a {
  private final HashMap<T, b<T>> a = new HashMap<T, b<T>>();
  
  @Nullable
  private Handler b;
  
  @Nullable
  private aa c;
  
  protected int a(T paramT, int paramInt) {
    return paramInt;
  }
  
  protected long a(T paramT, long paramLong) {
    return paramLong;
  }
  
  @Nullable
  protected p.a a(T paramT, p.a parama) {
    return parama;
  }
  
  @CallSuper
  protected void a() {
    for (b<T> b : this.a.values())
      b.a.a(b.b); 
  }
  
  @CallSuper
  protected void a(@Nullable aa paramaa) {
    this.c = paramaa;
    this.b = ai.a();
  }
  
  protected final void a(T paramT, p paramp) {
    com.applovin.exoplayer2.l.a.a(this.a.containsKey(paramT) ^ true);
    -$.Lambda.e.OZCo_CmHiftu8Xvuu-Lxkv425S0 oZCo_CmHiftu8Xvuu-Lxkv425S0 = new -$.Lambda.e.OZCo_CmHiftu8Xvuu-Lxkv425S0(this, paramT);
    a a1 = new a(this, paramT);
    this.a.put(paramT, new b<T>(paramp, (p.b)oZCo_CmHiftu8Xvuu-Lxkv425S0, a1));
    paramp.a((Handler)com.applovin.exoplayer2.l.a.b(this.b), a1);
    paramp.a((Handler)com.applovin.exoplayer2.l.a.b(this.b), a1);
    paramp.a((p.b)oZCo_CmHiftu8Xvuu-Lxkv425S0, this.c);
    if (!d())
      paramp.b((p.b)oZCo_CmHiftu8Xvuu-Lxkv425S0); 
  }
  
  protected abstract void a(T paramT, p paramp, ba paramba);
  
  @CallSuper
  protected void b() {
    for (b<T> b : this.a.values())
      b.a.b(b.b); 
  }
  
  @CallSuper
  protected void c() {
    for (b<T> b : this.a.values()) {
      b.a.c(b.b);
      b.a.a(b.c);
      b.a.a(b.c);
    } 
    this.a.clear();
  }
  
  @CallSuper
  public void e() throws IOException {
    Iterator iterator = this.a.values().iterator();
    while (iterator.hasNext())
      ((b)iterator.next()).a.e(); 
  }
  
  private final class a implements g, q {
    private final T b;
    
    private q.a c;
    
    private g.a d;
    
    public a(e this$0, T param1T) {
      this.c = this$0.a((p.a)null);
      this.d = this$0.b((p.a)null);
      this.b = param1T;
    }
    
    private m a(m param1m) {
      long l1 = this.a.a(this.b, param1m.f);
      long l2 = this.a.a(this.b, param1m.g);
      return (l1 == param1m.f && l2 == param1m.g) ? param1m : new m(param1m.a, param1m.b, param1m.c, param1m.d, param1m.e, l1, l2);
    }
    
    private boolean f(int param1Int, @Nullable p.a param1a) {
      if (param1a != null) {
        p.a a1 = this.a.a(this.b, param1a);
        param1a = a1;
        if (a1 == null)
          return false; 
      } else {
        param1a = null;
      } 
      param1Int = this.a.a(this.b, param1Int);
      if (this.c.a != param1Int || !ai.a(this.c.b, param1a))
        this.c = this.a.a(param1Int, param1a, 0L); 
      if (this.d.a != param1Int || !ai.a(this.d.b, param1a))
        this.d = this.a.a(param1Int, param1a); 
      return true;
    }
    
    public void a(int param1Int, @Nullable p.a param1a) {
      if (f(param1Int, param1a))
        this.d.a(); 
    }
    
    public void a(int param1Int1, @Nullable p.a param1a, int param1Int2) {
      if (f(param1Int1, param1a))
        this.d.a(param1Int2); 
    }
    
    public void a(int param1Int, @Nullable p.a param1a, j param1j, m param1m) {
      if (f(param1Int, param1a))
        this.c.a(param1j, a(param1m)); 
    }
    
    public void a(int param1Int, @Nullable p.a param1a, j param1j, m param1m, IOException param1IOException, boolean param1Boolean) {
      if (f(param1Int, param1a))
        this.c.a(param1j, a(param1m), param1IOException, param1Boolean); 
    }
    
    public void a(int param1Int, @Nullable p.a param1a, m param1m) {
      if (f(param1Int, param1a))
        this.c.a(a(param1m)); 
    }
    
    public void a(int param1Int, @Nullable p.a param1a, Exception param1Exception) {
      if (f(param1Int, param1a))
        this.d.a(param1Exception); 
    }
    
    public void b(int param1Int, @Nullable p.a param1a) {
      if (f(param1Int, param1a))
        this.d.b(); 
    }
    
    public void b(int param1Int, @Nullable p.a param1a, j param1j, m param1m) {
      if (f(param1Int, param1a))
        this.c.b(param1j, a(param1m)); 
    }
    
    public void c(int param1Int, @Nullable p.a param1a) {
      if (f(param1Int, param1a))
        this.d.c(); 
    }
    
    public void c(int param1Int, @Nullable p.a param1a, j param1j, m param1m) {
      if (f(param1Int, param1a))
        this.c.c(param1j, a(param1m)); 
    }
    
    public void d(int param1Int, @Nullable p.a param1a) {
      if (f(param1Int, param1a))
        this.d.d(); 
    }
  }
  
  private static final class b<T> {
    public final p a;
    
    public final p.b b;
    
    public final e<T>.a c;
    
    public b(p param1p, p.b param1b, e<T>.a param1a) {
      this.a = param1p;
      this.b = param1b;
      this.c = param1a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\h\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */