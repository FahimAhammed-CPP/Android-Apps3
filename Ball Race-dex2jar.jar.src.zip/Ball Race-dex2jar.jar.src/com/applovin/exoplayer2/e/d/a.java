package com.applovin.exoplayer2.e.d;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.e.g.g;
import com.applovin.exoplayer2.e.h;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.g.f.b;
import com.applovin.exoplayer2.l.y;
import com.applovin.exoplayer2.v;
import java.io.IOException;

public final class a implements h {
  private final y a = new y(6);
  
  private j b;
  
  private int c;
  
  private int d;
  
  private int e;
  
  private long f = -1L;
  
  @Nullable
  private b g;
  
  private i h;
  
  private c i;
  
  @Nullable
  private g j;
  
  @Nullable
  private static b a(String paramString, long paramLong) throws IOException {
    if (paramLong == -1L)
      return null; 
    b b1 = e.a(paramString);
    return (b1 == null) ? null : b1.a(paramLong);
  }
  
  private void a() {
    a(new com.applovin.exoplayer2.g.a.a[] { (com.applovin.exoplayer2.g.a.a)com.applovin.exoplayer2.l.a.b(this.g) });
    this.c = 5;
  }
  
  private void a(com.applovin.exoplayer2.g.a.a... paramVarArgs) {
    ((j)com.applovin.exoplayer2.l.a.b(this.b)).a(1024, 4).a((new v.a()).e("image/jpeg").a(new com.applovin.exoplayer2.g.a(paramVarArgs)).a());
  }
  
  private int b(i parami) throws IOException {
    this.a.a(2);
    parami.d(this.a.d(), 0, 2);
    return this.a.i();
  }
  
  private void b() {
    a(new com.applovin.exoplayer2.g.a.a[0]);
    ((j)com.applovin.exoplayer2.l.a.b(this.b)).a();
    this.b.a((v)new v.b(-9223372036854775807L));
    this.c = 6;
  }
  
  private void c(i parami) throws IOException {
    this.a.a(2);
    parami.d(this.a.d(), 0, 2);
    parami.c(this.a.i() - 2);
  }
  
  private void d(i parami) throws IOException {
    this.a.a(2);
    parami.b(this.a.d(), 0, 2);
    this.d = this.a.i();
    int k = this.d;
    if (k == 65498) {
      if (this.f != -1L) {
        this.c = 4;
        return;
      } 
      b();
      return;
    } 
    if ((k < 65488 || k > 65497) && this.d != 65281)
      this.c = 1; 
  }
  
  private void e(i parami) throws IOException {
    this.a.a(2);
    parami.b(this.a.d(), 0, 2);
    this.e = this.a.i() - 2;
    this.c = 2;
  }
  
  private void f(i parami) throws IOException {
    b b1;
    if (this.d == 65505) {
      y y1 = new y(this.e);
      parami.b(y1.d(), 0, this.e);
      if (this.g == null && "http://ns.adobe.com/xap/1.0/".equals(y1.B())) {
        String str = y1.B();
        if (str != null) {
          this.g = a(str, parami.d());
          b1 = this.g;
          if (b1 != null)
            this.f = b1.d; 
        } 
      } 
    } else {
      b1.b(this.e);
    } 
    this.c = 0;
  }
  
  private void g(i parami) throws IOException {
    if (!parami.b(this.a.d(), 0, 1, true)) {
      b();
      return;
    } 
    parami.a();
    if (this.j == null)
      this.j = new g(); 
    this.i = new c(parami, this.f);
    if (this.j.a((i)this.i)) {
      this.j.a(new d(this.f, (j)com.applovin.exoplayer2.l.a.b(this.b)));
      a();
      return;
    } 
    b();
  }
  
  public int a(i parami, u paramu) throws IOException {
    int k = this.c;
    if (k != 0) {
      if (k != 1) {
        if (k != 2) {
          if (k != 4) {
            if (k != 5) {
              if (k == 6)
                return -1; 
              throw new IllegalStateException();
            } 
            if (this.i == null || parami != this.h) {
              this.h = parami;
              this.i = new c(parami, this.f);
            } 
            k = ((g)com.applovin.exoplayer2.l.a.b(this.j)).a((i)this.i, paramu);
            if (k == 1)
              paramu.a += this.f; 
            return k;
          } 
          long l1 = parami.c();
          long l2 = this.f;
          if (l1 != l2) {
            paramu.a = l2;
            return 1;
          } 
          g(parami);
          return 0;
        } 
        f(parami);
        return 0;
      } 
      e(parami);
      return 0;
    } 
    d(parami);
    return 0;
  }
  
  public void a(long paramLong1, long paramLong2) {
    if (paramLong1 == 0L) {
      this.c = 0;
      this.j = null;
      return;
    } 
    if (this.c == 5)
      ((g)com.applovin.exoplayer2.l.a.b(this.j)).a(paramLong1, paramLong2); 
  }
  
  public void a(j paramj) {
    this.b = paramj;
  }
  
  public boolean a(i parami) throws IOException {
    int k = b(parami);
    boolean bool2 = false;
    if (k != 65496)
      return false; 
    this.d = b(parami);
    if (this.d == 65504) {
      c(parami);
      this.d = b(parami);
    } 
    if (this.d != 65505)
      return false; 
    parami.c(2);
    this.a.a(6);
    parami.d(this.a.d(), 0, 6);
    boolean bool1 = bool2;
    if (this.a.o() == 1165519206L) {
      bool1 = bool2;
      if (this.a.i() == 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public void c() {
    g g1 = this.j;
    if (g1 != null)
      g1.c(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\d\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */