package com.applovin.exoplayer2.e.d;

import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.q;
import com.applovin.exoplayer2.l.a;

final class c extends q {
  private final long a;
  
  public c(i parami, long paramLong) {
    super(parami);
    boolean bool;
    if (parami.c() >= paramLong) {
      bool = true;
    } else {
      bool = false;
    } 
    a.a(bool);
    this.a = paramLong;
  }
  
  public long b() {
    return super.b() - this.a;
  }
  
  public long c() {
    return super.c() - this.a;
  }
  
  public long d() {
    return super.d() - this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\d\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */