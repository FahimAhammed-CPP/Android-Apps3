package com.applovin.exoplayer2.e.d;

import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.w;
import com.applovin.exoplayer2.e.x;

public final class d implements j {
  private final long b;
  
  private final j c;
  
  public d(long paramLong, j paramj) {
    this.b = paramLong;
    this.c = paramj;
  }
  
  public x a(int paramInt1, int paramInt2) {
    return this.c.a(paramInt1, paramInt2);
  }
  
  public void a() {
    this.c.a();
  }
  
  public void a(v paramv) {
    this.c.a(new v(this, paramv) {
          public v.a a(long param1Long) {
            v.a a = this.a.a(param1Long);
            return new v.a(new w(a.a.b, a.a.c + d.a(this.b)), new w(a.b.b, a.b.c + d.a(this.b)));
          }
          
          public boolean a() {
            return this.a.a();
          }
          
          public long b() {
            return this.a.b();
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\d\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */