package com.applovin.exoplayer2.e.d;

import androidx.annotation.Nullable;
import java.util.List;

final class b {
  public final long a;
  
  public final List<a> b;
  
  public b(long paramLong, List<a> paramList) {
    this.a = paramLong;
    this.b = paramList;
  }
  
  @Nullable
  public com.applovin.exoplayer2.g.f.b a(long paramLong) {
    if (this.b.size() < 2)
      return null; 
    int i = this.b.size() - 1;
    boolean bool = false;
    long l2 = -1L;
    long l1 = -1L;
    long l3 = -1L;
    long l4 = -1L;
    while (i >= 0) {
      long l;
      a a = this.b.get(i);
      bool = "video/mp4".equals(a.a) | bool;
      if (i == 0) {
        l = paramLong - a.d;
        paramLong = 0L;
      } else {
        long l5 = a.c;
        l = paramLong;
        paramLong -= l5;
      } 
      if (bool && paramLong != l) {
        l4 = l - paramLong;
        l3 = paramLong;
        bool = false;
      } 
      if (i == 0) {
        l2 = paramLong;
        l1 = l;
      } 
      i--;
    } 
    return (l3 == -1L || l4 == -1L || l2 == -1L || l1 == -1L) ? null : new com.applovin.exoplayer2.g.f.b(l2, l1, this.a, l3, l4);
  }
  
  public static final class a {
    public final String a;
    
    public final String b;
    
    public final long c;
    
    public final long d;
    
    public a(String param1String1, String param1String2, long param1Long1, long param1Long2) {
      this.a = param1String1;
      this.b = param1String2;
      this.c = param1Long1;
      this.d = param1Long2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\d\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */