package com.applovin.exoplayer2.e.d;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ai;
import com.applovin.exoplayer2.common.a.s;
import com.applovin.exoplayer2.l.aj;
import com.applovin.exoplayer2.l.q;
import java.io.IOException;
import java.io.StringReader;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

final class e {
  private static final String[] a = new String[] { "Camera:MotionPhoto", "GCamera:MotionPhoto", "Camera:MicroVideo", "GCamera:MicroVideo" };
  
  private static final String[] b = new String[] { "Camera:MotionPhotoPresentationTimestampUs", "GCamera:MotionPhotoPresentationTimestampUs", "Camera:MicroVideoPresentationTimestampUs", "GCamera:MicroVideoPresentationTimestampUs" };
  
  private static final String[] c = new String[] { "Camera:MicroVideoOffset", "GCamera:MicroVideoOffset" };
  
  private static s<b.a> a(XmlPullParser paramXmlPullParser, String paramString1, String paramString2) throws XmlPullParserException, IOException {
    s.a a = s.i();
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString1);
    stringBuilder1.append(":Item");
    String str = stringBuilder1.toString();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString1);
    stringBuilder2.append(":Directory");
    paramString1 = stringBuilder2.toString();
    while (true) {
      paramXmlPullParser.next();
      if (aj.b(paramXmlPullParser, str)) {
        long l1;
        long l2;
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(paramString2);
        stringBuilder2.append(":Mime");
        String str1 = stringBuilder2.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(paramString2);
        stringBuilder3.append(":Semantic");
        String str2 = stringBuilder3.toString();
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(paramString2);
        stringBuilder4.append(":Length");
        String str3 = stringBuilder4.toString();
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append(paramString2);
        stringBuilder5.append(":Padding");
        String str4 = stringBuilder5.toString();
        str1 = aj.c(paramXmlPullParser, str1);
        str2 = aj.c(paramXmlPullParser, str2);
        str3 = aj.c(paramXmlPullParser, str3);
        str4 = aj.c(paramXmlPullParser, str4);
        if (str1 == null || str2 == null)
          return s.g(); 
        if (str3 != null) {
          l1 = Long.parseLong(str3);
        } else {
          l1 = 0L;
        } 
        if (str4 != null) {
          l2 = Long.parseLong(str4);
        } else {
          l2 = 0L;
        } 
        a.b(new b.a(str1, str2, l1, l2));
      } 
      if (aj.a(paramXmlPullParser, paramString1))
        return a.a(); 
    } 
  }
  
  @Nullable
  public static b a(String paramString) throws IOException {
    try {
      return b(paramString);
    } catch (XmlPullParserException|ai|NumberFormatException xmlPullParserException) {
      q.c("MotionPhotoXmpParser", "Ignoring unexpected XMP metadata");
      return null;
    } 
  }
  
  private static boolean a(XmlPullParser paramXmlPullParser) {
    String[] arrayOfString = a;
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str = aj.c(paramXmlPullParser, arrayOfString[i]);
      if (str != null)
        return (Integer.parseInt(str) == 1); 
    } 
    return false;
  }
  
  private static long b(XmlPullParser paramXmlPullParser) {
    String[] arrayOfString = b;
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str = aj.c(paramXmlPullParser, arrayOfString[i]);
      if (str != null) {
        long l2 = Long.parseLong(str);
        long l1 = l2;
        if (l2 == -1L)
          l1 = -9223372036854775807L; 
        return l1;
      } 
    } 
    return -9223372036854775807L;
  }
  
  @Nullable
  private static b b(String paramString) throws XmlPullParserException, IOException {
    XmlPullParser xmlPullParser = XmlPullParserFactory.newInstance().newPullParser();
    xmlPullParser.setInput(new StringReader(paramString));
    xmlPullParser.next();
    if (aj.b(xmlPullParser, "x:xmpmeta")) {
      long l = -9223372036854775807L;
      s<b.a> s = s.g();
      while (true) {
        s<b.a> s1;
        long l1;
        xmlPullParser.next();
        if (aj.b(xmlPullParser, "rdf:Description")) {
          if (!a(xmlPullParser))
            return null; 
          l1 = b(xmlPullParser);
          s1 = c(xmlPullParser);
        } else if (aj.b(xmlPullParser, "Container:Directory")) {
          s1 = a(xmlPullParser, "Container", "Item");
          l1 = l;
        } else {
          s1 = s;
          l1 = l;
          if (aj.b(xmlPullParser, "GContainer:Directory")) {
            s1 = a(xmlPullParser, "GContainer", "GContainerItem");
            l1 = l;
          } 
        } 
        s = s1;
        l = l1;
        if (aj.a(xmlPullParser, "x:xmpmeta"))
          return s1.isEmpty() ? null : new b(l1, (List<b.a>)s1); 
      } 
    } 
    throw ai.b("Couldn't find xmp metadata", null);
  }
  
  private static s<b.a> c(XmlPullParser paramXmlPullParser) {
    String[] arrayOfString = c;
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str = aj.c(paramXmlPullParser, arrayOfString[i]);
      if (str != null) {
        long l = Long.parseLong(str);
        return s.a(new b.a("image/jpeg", "Primary", 0L, 0L), new b.a("video/mp4", "MotionPhoto", l, 0L));
      } 
    } 
    return s.g();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\d\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */