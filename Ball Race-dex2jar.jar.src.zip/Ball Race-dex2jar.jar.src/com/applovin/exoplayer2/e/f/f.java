package com.applovin.exoplayer2.e.f;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.b.r;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.w;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.y;

final class f implements e {
  private final long[] a;
  
  private final long[] b;
  
  private final long c;
  
  private final long d;
  
  private f(long[] paramArrayOflong1, long[] paramArrayOflong2, long paramLong1, long paramLong2) {
    this.a = paramArrayOflong1;
    this.b = paramArrayOflong2;
    this.c = paramLong1;
    this.d = paramLong2;
  }
  
  @Nullable
  public static f a(long paramLong1, long paramLong2, r.a parama, y paramy) {
    paramy.e(10);
    int i = paramy.q();
    if (i <= 0)
      return null; 
    int j = parama.d;
    long l1 = i;
    if (j >= 32000) {
      i = 1152;
    } else {
      i = 576;
    } 
    long l3 = ai.d(l1, 1000000L * i, j);
    int m = paramy.i();
    j = paramy.i();
    int n = paramy.i();
    paramy.e(2);
    long l2 = paramLong2 + parama.c;
    long[] arrayOfLong1 = new long[m];
    long[] arrayOfLong2 = new long[m];
    int k = 0;
    l1 = paramLong2;
    paramLong2 = l2;
    while (k < m) {
      arrayOfLong1[k] = k * l3 / m;
      arrayOfLong2[k] = Math.max(l1, paramLong2);
      if (n != 1) {
        if (n != 2) {
          if (n != 3) {
            if (n != 4)
              return null; 
            i = paramy.w();
          } else {
            i = paramy.m();
          } 
        } else {
          i = paramy.i();
        } 
      } else {
        i = paramy.h();
      } 
      l1 += (i * j);
      k++;
    } 
    if (paramLong1 != -1L && paramLong1 != l1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("VBRI data size mismatch: ");
      stringBuilder.append(paramLong1);
      stringBuilder.append(", ");
      stringBuilder.append(l1);
      q.c("VbriSeeker", stringBuilder.toString());
    } 
    return new f(arrayOfLong1, arrayOfLong2, l3, l1);
  }
  
  public v.a a(long paramLong) {
    int i = ai.a(this.a, paramLong, true, true);
    w w = new w(this.a[i], this.b[i]);
    if (w.b < paramLong) {
      long[] arrayOfLong = this.a;
      if (i != arrayOfLong.length - 1)
        return new v.a(w, new w(arrayOfLong[++i], this.b[i])); 
    } 
    return new v.a(w);
  }
  
  public boolean a() {
    return true;
  }
  
  public long b() {
    return this.c;
  }
  
  public long c() {
    return this.d;
  }
  
  public long c(long paramLong) {
    return this.a[ai.a(this.b, paramLong, true, true)];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\f\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */