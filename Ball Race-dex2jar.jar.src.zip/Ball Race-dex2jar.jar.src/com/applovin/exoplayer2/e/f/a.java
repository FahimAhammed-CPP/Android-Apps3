package com.applovin.exoplayer2.e.f;

import com.applovin.exoplayer2.b.r;
import com.applovin.exoplayer2.e.d;

final class a extends d implements e {
  public a(long paramLong1, long paramLong2, r.a parama, boolean paramBoolean) {
    super(paramLong1, paramLong2, parama.f, parama.c, paramBoolean);
  }
  
  public long c() {
    return -1L;
  }
  
  public long c(long paramLong) {
    return b(paramLong);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */