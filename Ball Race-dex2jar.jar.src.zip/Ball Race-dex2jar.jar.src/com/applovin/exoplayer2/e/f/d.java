package com.applovin.exoplayer2.e.f;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.b.r;
import com.applovin.exoplayer2.e.g;
import com.applovin.exoplayer2.e.h;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.l;
import com.applovin.exoplayer2.e.r;
import com.applovin.exoplayer2.e.s;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.e.x;
import com.applovin.exoplayer2.g.a;
import com.applovin.exoplayer2.g.e.g;
import com.applovin.exoplayer2.g.e.j;
import com.applovin.exoplayer2.g.e.l;
import com.applovin.exoplayer2.h;
import com.applovin.exoplayer2.k.g;
import com.applovin.exoplayer2.l.a;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.y;
import java.io.EOFException;
import java.io.IOException;

public final class d implements h {
  public static final l a = (l)-$.Lambda.d.M00HXtLQ4mGUqsI0jBaBwLQNDFI.INSTANCE;
  
  private static final g.a b = (g.a)-$.Lambda.d.PsVn2vj1IEaDQ66FqrWGI__HiT8.INSTANCE;
  
  private final int c;
  
  private final long d;
  
  private final y e;
  
  private final r.a f;
  
  private final r g;
  
  private final s h;
  
  private final x i;
  
  private j j;
  
  private x k;
  
  private x l;
  
  private int m;
  
  @Nullable
  private a n;
  
  private long o;
  
  private long p;
  
  private long q;
  
  private int r;
  
  private e s;
  
  private boolean t;
  
  private boolean u;
  
  private long v;
  
  public d() {
    this(0);
  }
  
  public d(int paramInt) {
    this(paramInt, -9223372036854775807L);
  }
  
  public d(int paramInt, long paramLong) {
    int i = paramInt;
    if ((paramInt & 0x2) != 0)
      i = paramInt | 0x1; 
    this.c = i;
    this.d = paramLong;
    this.e = new y(10);
    this.f = new r.a();
    this.g = new r();
    this.o = -9223372036854775807L;
    this.h = new s();
    this.i = (x)new g();
    this.l = this.i;
  }
  
  private static int a(y paramy, int paramInt) {
    if (paramy.b() >= paramInt + 4) {
      paramy.d(paramInt);
      paramInt = paramy.q();
      if (paramInt == 1483304551 || paramInt == 1231971951)
        return paramInt; 
    } 
    if (paramy.b() >= 40) {
      paramy.d(36);
      if (paramy.q() == 1447187017)
        return 1447187017; 
    } 
    return 0;
  }
  
  private long a(long paramLong) {
    return this.o + paramLong * 1000000L / this.f.d;
  }
  
  private static long a(@Nullable a parama) {
    if (parama != null) {
      int k = parama.a();
      for (int i = 0; i < k; i++) {
        a.a a1 = parama.a(i);
        if (a1 instanceof l) {
          l l1 = (l)a1;
          if (l1.f.equals("TLEN"))
            return h.b(Long.parseLong(l1.b)); 
        } 
      } 
    } 
    return -9223372036854775807L;
  }
  
  @Nullable
  private static c a(@Nullable a parama, long paramLong) {
    if (parama != null) {
      int k = parama.a();
      for (int i = 0; i < k; i++) {
        a.a a1 = parama.a(i);
        if (a1 instanceof j)
          return c.a(paramLong, (j)a1, a(parama)); 
      } 
    } 
    return null;
  }
  
  private static boolean a(int paramInt, long paramLong) {
    return ((paramInt & 0xFFFE0C00) == (paramLong & 0xFFFFFFFFFFFE0C00L));
  }
  
  private boolean a(i parami, boolean paramBoolean) throws IOException {
    // Byte code:
    //   0: iload_2
    //   1: ifeq -> 11
    //   4: ldc 32768
    //   6: istore #6
    //   8: goto -> 15
    //   11: ldc 131072
    //   13: istore #6
    //   15: aload_1
    //   16: invokeinterface a : ()V
    //   21: aload_1
    //   22: invokeinterface c : ()J
    //   27: lconst_0
    //   28: lcmp
    //   29: ifne -> 131
    //   32: aload_0
    //   33: getfield c : I
    //   36: bipush #8
    //   38: iand
    //   39: ifne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 59
    //   53: aconst_null
    //   54: astore #11
    //   56: goto -> 64
    //   59: getstatic com/applovin/exoplayer2/e/f/d.b : Lcom/applovin/exoplayer2/g/e/g$a;
    //   62: astore #11
    //   64: aload_0
    //   65: aload_0
    //   66: getfield h : Lcom/applovin/exoplayer2/e/s;
    //   69: aload_1
    //   70: aload #11
    //   72: invokevirtual a : (Lcom/applovin/exoplayer2/e/i;Lcom/applovin/exoplayer2/g/e/g$a;)Lcom/applovin/exoplayer2/g/a;
    //   75: putfield n : Lcom/applovin/exoplayer2/g/a;
    //   78: aload_0
    //   79: getfield n : Lcom/applovin/exoplayer2/g/a;
    //   82: astore #11
    //   84: aload #11
    //   86: ifnull -> 99
    //   89: aload_0
    //   90: getfield g : Lcom/applovin/exoplayer2/e/r;
    //   93: aload #11
    //   95: invokevirtual a : (Lcom/applovin/exoplayer2/g/a;)Z
    //   98: pop
    //   99: aload_1
    //   100: invokeinterface b : ()J
    //   105: l2i
    //   106: istore #7
    //   108: iload_2
    //   109: ifne -> 120
    //   112: aload_1
    //   113: iload #7
    //   115: invokeinterface b : (I)V
    //   120: iconst_0
    //   121: istore_3
    //   122: iconst_0
    //   123: istore #4
    //   125: iconst_0
    //   126: istore #5
    //   128: goto -> 142
    //   131: iconst_0
    //   132: istore_3
    //   133: iconst_0
    //   134: istore #4
    //   136: iconst_0
    //   137: istore #5
    //   139: iconst_0
    //   140: istore #7
    //   142: aload_0
    //   143: aload_1
    //   144: invokespecial d : (Lcom/applovin/exoplayer2/e/i;)Z
    //   147: ifeq -> 166
    //   150: iload #4
    //   152: ifle -> 158
    //   155: goto -> 314
    //   158: new java/io/EOFException
    //   161: dup
    //   162: invokespecial <init> : ()V
    //   165: athrow
    //   166: aload_0
    //   167: getfield e : Lcom/applovin/exoplayer2/l/y;
    //   170: iconst_0
    //   171: invokevirtual d : (I)V
    //   174: aload_0
    //   175: getfield e : Lcom/applovin/exoplayer2/l/y;
    //   178: invokevirtual q : ()I
    //   181: istore #9
    //   183: iload_3
    //   184: ifeq -> 197
    //   187: iload #9
    //   189: iload_3
    //   190: i2l
    //   191: invokestatic a : (IJ)Z
    //   194: ifeq -> 210
    //   197: iload #9
    //   199: invokestatic a : (I)I
    //   202: istore #10
    //   204: iload #10
    //   206: iconst_m1
    //   207: if_icmpne -> 276
    //   210: iload #5
    //   212: iconst_1
    //   213: iadd
    //   214: istore_3
    //   215: iload #5
    //   217: iload #6
    //   219: if_icmpne -> 235
    //   222: iload_2
    //   223: ifeq -> 228
    //   226: iconst_0
    //   227: ireturn
    //   228: ldc 'Searched too many bytes.'
    //   230: aconst_null
    //   231: invokestatic b : (Ljava/lang/String;Ljava/lang/Throwable;)Lcom/applovin/exoplayer2/ai;
    //   234: athrow
    //   235: iload_2
    //   236: ifeq -> 258
    //   239: aload_1
    //   240: invokeinterface a : ()V
    //   245: aload_1
    //   246: iload #7
    //   248: iload_3
    //   249: iadd
    //   250: invokeinterface c : (I)V
    //   255: goto -> 265
    //   258: aload_1
    //   259: iconst_1
    //   260: invokeinterface b : (I)V
    //   265: iload_3
    //   266: istore #5
    //   268: iconst_0
    //   269: istore_3
    //   270: iconst_0
    //   271: istore #4
    //   273: goto -> 142
    //   276: iload #4
    //   278: iconst_1
    //   279: iadd
    //   280: istore #8
    //   282: iload #8
    //   284: iconst_1
    //   285: if_icmpne -> 305
    //   288: aload_0
    //   289: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   292: iload #9
    //   294: invokevirtual a : (I)Z
    //   297: pop
    //   298: iload #9
    //   300: istore #4
    //   302: goto -> 345
    //   305: iload_3
    //   306: istore #4
    //   308: iload #8
    //   310: iconst_4
    //   311: if_icmpne -> 345
    //   314: iload_2
    //   315: ifeq -> 332
    //   318: aload_1
    //   319: iload #7
    //   321: iload #5
    //   323: iadd
    //   324: invokeinterface b : (I)V
    //   329: goto -> 338
    //   332: aload_1
    //   333: invokeinterface a : ()V
    //   338: aload_0
    //   339: iload_3
    //   340: putfield m : I
    //   343: iconst_1
    //   344: ireturn
    //   345: aload_1
    //   346: iload #10
    //   348: iconst_4
    //   349: isub
    //   350: invokeinterface c : (I)V
    //   355: iload #4
    //   357: istore_3
    //   358: iload #8
    //   360: istore #4
    //   362: goto -> 142
  }
  
  private int b(i parami) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : I
    //   4: ifne -> 19
    //   7: aload_0
    //   8: aload_1
    //   9: iconst_0
    //   10: invokespecial a : (Lcom/applovin/exoplayer2/e/i;Z)Z
    //   13: pop
    //   14: goto -> 19
    //   17: iconst_m1
    //   18: ireturn
    //   19: aload_0
    //   20: getfield s : Lcom/applovin/exoplayer2/e/f/e;
    //   23: ifnonnull -> 171
    //   26: aload_0
    //   27: aload_0
    //   28: aload_1
    //   29: invokespecial e : (Lcom/applovin/exoplayer2/e/i;)Lcom/applovin/exoplayer2/e/f/e;
    //   32: putfield s : Lcom/applovin/exoplayer2/e/f/e;
    //   35: aload_0
    //   36: getfield j : Lcom/applovin/exoplayer2/e/j;
    //   39: aload_0
    //   40: getfield s : Lcom/applovin/exoplayer2/e/f/e;
    //   43: invokeinterface a : (Lcom/applovin/exoplayer2/e/v;)V
    //   48: aload_0
    //   49: getfield l : Lcom/applovin/exoplayer2/e/x;
    //   52: astore #7
    //   54: new com/applovin/exoplayer2/v$a
    //   57: dup
    //   58: invokespecial <init> : ()V
    //   61: aload_0
    //   62: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   65: getfield b : Ljava/lang/String;
    //   68: invokevirtual f : (Ljava/lang/String;)Lcom/applovin/exoplayer2/v$a;
    //   71: sipush #4096
    //   74: invokevirtual f : (I)Lcom/applovin/exoplayer2/v$a;
    //   77: aload_0
    //   78: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   81: getfield e : I
    //   84: invokevirtual k : (I)Lcom/applovin/exoplayer2/v$a;
    //   87: aload_0
    //   88: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   91: getfield d : I
    //   94: invokevirtual l : (I)Lcom/applovin/exoplayer2/v$a;
    //   97: aload_0
    //   98: getfield g : Lcom/applovin/exoplayer2/e/r;
    //   101: getfield a : I
    //   104: invokevirtual n : (I)Lcom/applovin/exoplayer2/v$a;
    //   107: aload_0
    //   108: getfield g : Lcom/applovin/exoplayer2/e/r;
    //   111: getfield b : I
    //   114: invokevirtual o : (I)Lcom/applovin/exoplayer2/v$a;
    //   117: astore #8
    //   119: aload_0
    //   120: getfield c : I
    //   123: bipush #8
    //   125: iand
    //   126: ifeq -> 135
    //   129: aconst_null
    //   130: astore #6
    //   132: goto -> 141
    //   135: aload_0
    //   136: getfield n : Lcom/applovin/exoplayer2/g/a;
    //   139: astore #6
    //   141: aload #7
    //   143: aload #8
    //   145: aload #6
    //   147: invokevirtual a : (Lcom/applovin/exoplayer2/g/a;)Lcom/applovin/exoplayer2/v$a;
    //   150: invokevirtual a : ()Lcom/applovin/exoplayer2/v;
    //   153: invokeinterface a : (Lcom/applovin/exoplayer2/v;)V
    //   158: aload_0
    //   159: aload_1
    //   160: invokeinterface c : ()J
    //   165: putfield q : J
    //   168: goto -> 211
    //   171: aload_0
    //   172: getfield q : J
    //   175: lconst_0
    //   176: lcmp
    //   177: ifeq -> 211
    //   180: aload_1
    //   181: invokeinterface c : ()J
    //   186: lstore_2
    //   187: aload_0
    //   188: getfield q : J
    //   191: lstore #4
    //   193: lload_2
    //   194: lload #4
    //   196: lcmp
    //   197: ifge -> 211
    //   200: aload_1
    //   201: lload #4
    //   203: lload_2
    //   204: lsub
    //   205: l2i
    //   206: invokeinterface b : (I)V
    //   211: aload_0
    //   212: aload_1
    //   213: invokespecial c : (Lcom/applovin/exoplayer2/e/i;)I
    //   216: ireturn
    //   217: astore_1
    //   218: goto -> 17
    // Exception table:
    //   from	to	target	type
    //   7	14	217	java/io/EOFException
  }
  
  private e b(i parami, boolean paramBoolean) throws IOException {
    parami.d(this.e.d(), 0, 4);
    this.e.d(0);
    this.f.a(this.e.q());
    return new a(parami.d(), parami.c(), this.f, paramBoolean);
  }
  
  private void b() {
    a.a(this.k);
    ai.a(this.j);
  }
  
  private int c(i parami) throws IOException {
    if (this.r == 0) {
      parami.a();
      if (d(parami))
        return -1; 
      this.e.d(0);
      int m = this.e.q();
      if (!a(m, this.m) || r.a(m) == -1) {
        parami.b(1);
        this.m = 0;
        return 0;
      } 
      this.f.a(m);
      if (this.o == -9223372036854775807L) {
        this.o = this.s.c(parami.c());
        if (this.d != -9223372036854775807L) {
          long l1 = this.s.c(0L);
          this.o += this.d - l1;
        } 
      } 
      this.r = this.f.c;
      e e1 = this.s;
      if (e1 instanceof b) {
        e1 = e1;
        e1.a(a(this.p + this.f.g), parami.c() + this.f.c);
        if (this.u && e1.b(this.v)) {
          this.u = false;
          this.l = this.k;
        } 
      } 
    } 
    int k = this.l.a((g)parami, this.r, true);
    if (k == -1)
      return -1; 
    this.r -= k;
    if (this.r > 0)
      return 0; 
    this.l.a(a(this.p), 1, this.f.c, 0, null);
    this.p += this.f.g;
    this.r = 0;
    return 0;
  }
  
  private boolean d(i parami) throws IOException {
    e e1 = this.s;
    if (e1 != null) {
      long l1 = e1.c();
      if (l1 != -1L && parami.b() > l1 - 4L)
        return true; 
    } 
    try {
      boolean bool = parami.b(this.e.d(), 0, 4, true);
      return bool ^ true;
    } catch (EOFException eOFException) {
      return true;
    } 
  }
  
  private e e(i parami) throws IOException {
    e e1 = f(parami);
    c c = a(this.n, parami.c());
    if (this.t)
      return new e.a(); 
    if ((this.c & 0x4) != 0) {
      long l1;
      long l2;
      if (c != null) {
        l1 = c.b();
        l2 = c.c();
      } else if (e1 != null) {
        l1 = e1.b();
        l2 = e1.c();
      } else {
        l1 = a(this.n);
        l2 = -1L;
      } 
      e1 = new b(l1, parami.c(), l2);
    } else if (c != null) {
      e1 = c;
    } else if (e1 == null) {
      e1 = null;
    } 
    boolean bool = true;
    if (e1 != null) {
      e e2 = e1;
      if (!e1.a()) {
        e2 = e1;
        if ((this.c & 0x1) != 0) {
          if ((this.c & 0x2) == 0)
            bool = false; 
          return b(parami, bool);
        } 
      } 
      return e2;
    } 
    if ((this.c & 0x2) == 0)
      bool = false; 
    return b(parami, bool);
  }
  
  @Nullable
  private e f(i parami) throws IOException {
    // Byte code:
    //   0: new com/applovin/exoplayer2/l/y
    //   3: dup
    //   4: aload_0
    //   5: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   8: getfield c : I
    //   11: invokespecial <init> : (I)V
    //   14: astore #4
    //   16: aload_1
    //   17: aload #4
    //   19: invokevirtual d : ()[B
    //   22: iconst_0
    //   23: aload_0
    //   24: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   27: getfield c : I
    //   30: invokeinterface d : ([BII)V
    //   35: aload_0
    //   36: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   39: getfield a : I
    //   42: iconst_1
    //   43: iand
    //   44: ifeq -> 64
    //   47: aload_0
    //   48: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   51: getfield e : I
    //   54: iconst_1
    //   55: if_icmpeq -> 75
    //   58: bipush #36
    //   60: istore_2
    //   61: goto -> 84
    //   64: aload_0
    //   65: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   68: getfield e : I
    //   71: iconst_1
    //   72: if_icmpeq -> 81
    //   75: bipush #21
    //   77: istore_2
    //   78: goto -> 84
    //   81: bipush #13
    //   83: istore_2
    //   84: aload #4
    //   86: iload_2
    //   87: invokestatic a : (Lcom/applovin/exoplayer2/l/y;I)I
    //   90: istore_3
    //   91: iload_3
    //   92: ldc 1483304551
    //   94: if_icmpeq -> 159
    //   97: iload_3
    //   98: ldc 1231971951
    //   100: if_icmpne -> 106
    //   103: goto -> 159
    //   106: iload_3
    //   107: ldc 1447187017
    //   109: if_icmpne -> 151
    //   112: aload_1
    //   113: invokeinterface d : ()J
    //   118: aload_1
    //   119: invokeinterface c : ()J
    //   124: aload_0
    //   125: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   128: aload #4
    //   130: invokestatic a : (JJLcom/applovin/exoplayer2/b/r$a;Lcom/applovin/exoplayer2/l/y;)Lcom/applovin/exoplayer2/e/f/f;
    //   133: astore #4
    //   135: aload_1
    //   136: aload_0
    //   137: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   140: getfield c : I
    //   143: invokeinterface b : (I)V
    //   148: aload #4
    //   150: areturn
    //   151: aload_1
    //   152: invokeinterface a : ()V
    //   157: aconst_null
    //   158: areturn
    //   159: aload_1
    //   160: invokeinterface d : ()J
    //   165: aload_1
    //   166: invokeinterface c : ()J
    //   171: aload_0
    //   172: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   175: aload #4
    //   177: invokestatic a : (JJLcom/applovin/exoplayer2/b/r$a;Lcom/applovin/exoplayer2/l/y;)Lcom/applovin/exoplayer2/e/f/g;
    //   180: astore #4
    //   182: aload #4
    //   184: ifnull -> 252
    //   187: aload_0
    //   188: getfield g : Lcom/applovin/exoplayer2/e/r;
    //   191: invokevirtual a : ()Z
    //   194: ifne -> 252
    //   197: aload_1
    //   198: invokeinterface a : ()V
    //   203: aload_1
    //   204: iload_2
    //   205: sipush #141
    //   208: iadd
    //   209: invokeinterface c : (I)V
    //   214: aload_1
    //   215: aload_0
    //   216: getfield e : Lcom/applovin/exoplayer2/l/y;
    //   219: invokevirtual d : ()[B
    //   222: iconst_0
    //   223: iconst_3
    //   224: invokeinterface d : ([BII)V
    //   229: aload_0
    //   230: getfield e : Lcom/applovin/exoplayer2/l/y;
    //   233: iconst_0
    //   234: invokevirtual d : (I)V
    //   237: aload_0
    //   238: getfield g : Lcom/applovin/exoplayer2/e/r;
    //   241: aload_0
    //   242: getfield e : Lcom/applovin/exoplayer2/l/y;
    //   245: invokevirtual m : ()I
    //   248: invokevirtual a : (I)Z
    //   251: pop
    //   252: aload_1
    //   253: aload_0
    //   254: getfield f : Lcom/applovin/exoplayer2/b/r$a;
    //   257: getfield c : I
    //   260: invokeinterface b : (I)V
    //   265: aload #4
    //   267: ifnull -> 293
    //   270: aload #4
    //   272: invokeinterface a : ()Z
    //   277: ifne -> 293
    //   280: iload_3
    //   281: ldc 1231971951
    //   283: if_icmpne -> 293
    //   286: aload_0
    //   287: aload_1
    //   288: iconst_0
    //   289: invokespecial b : (Lcom/applovin/exoplayer2/e/i;Z)Lcom/applovin/exoplayer2/e/f/e;
    //   292: areturn
    //   293: aload #4
    //   295: areturn
  }
  
  public int a(i parami, u paramu) throws IOException {
    b();
    int k = b(parami);
    if (k == -1 && this.s instanceof b) {
      long l1 = a(this.p);
      if (this.s.b() != l1) {
        ((b)this.s).d(l1);
        this.j.a(this.s);
      } 
    } 
    return k;
  }
  
  public void a() {
    this.t = true;
  }
  
  public void a(long paramLong1, long paramLong2) {
    this.m = 0;
    this.o = -9223372036854775807L;
    this.p = 0L;
    this.r = 0;
    this.v = paramLong2;
    e e1 = this.s;
    if (e1 instanceof b && !((b)e1).b(paramLong2)) {
      this.u = true;
      this.l = this.i;
    } 
  }
  
  public void a(j paramj) {
    this.j = paramj;
    this.k = this.j.a(0, 1);
    this.l = this.k;
    this.j.a();
  }
  
  public boolean a(i parami) throws IOException {
    return a(parami, true);
  }
  
  public void c() {}
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\f\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */