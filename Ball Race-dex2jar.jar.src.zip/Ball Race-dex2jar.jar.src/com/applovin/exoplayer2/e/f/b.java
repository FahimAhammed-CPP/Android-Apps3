package com.applovin.exoplayer2.e.f;

import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.w;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.r;

final class b implements e {
  private final long a;
  
  private final r b;
  
  private final r c;
  
  private long d;
  
  public b(long paramLong1, long paramLong2, long paramLong3) {
    this.d = paramLong1;
    this.a = paramLong3;
    this.b = new r();
    this.c = new r();
    this.b.a(0L);
    this.c.a(paramLong2);
  }
  
  public v.a a(long paramLong) {
    int i = ai.a(this.b, paramLong, true, true);
    w w = new w(this.b.a(i), this.c.a(i));
    if (w.b == paramLong || i == this.b.a() - 1)
      return new v.a(w); 
    r r1 = this.b;
    return new v.a(w, new w(r1.a(++i), this.c.a(i)));
  }
  
  public void a(long paramLong1, long paramLong2) {
    if (b(paramLong1))
      return; 
    this.b.a(paramLong1);
    this.c.a(paramLong2);
  }
  
  public boolean a() {
    return true;
  }
  
  public long b() {
    return this.d;
  }
  
  public boolean b(long paramLong) {
    r r1 = this.b;
    return (paramLong - r1.a(r1.a() - 1) < 100000L);
  }
  
  public long c() {
    return this.a;
  }
  
  public long c(long paramLong) {
    int i = ai.a(this.c, paramLong, true, true);
    return this.b.a(i);
  }
  
  void d(long paramLong) {
    this.d = paramLong;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */