package com.applovin.exoplayer2.e.f;

import android.util.Pair;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.w;
import com.applovin.exoplayer2.g.e.j;
import com.applovin.exoplayer2.h;
import com.applovin.exoplayer2.l.ai;

final class c implements e {
  private final long[] a;
  
  private final long[] b;
  
  private final long c;
  
  private c(long[] paramArrayOflong1, long[] paramArrayOflong2, long paramLong) {
    this.a = paramArrayOflong1;
    this.b = paramArrayOflong2;
    if (paramLong == -9223372036854775807L)
      paramLong = h.b(paramArrayOflong2[paramArrayOflong2.length - 1]); 
    this.c = paramLong;
  }
  
  private static Pair<Long, Long> a(long paramLong, long[] paramArrayOflong1, long[] paramArrayOflong2) {
    double d;
    int i = ai.a(paramArrayOflong1, paramLong, true, true);
    long l1 = paramArrayOflong1[i];
    long l2 = paramArrayOflong2[i];
    if (++i == paramArrayOflong1.length)
      return Pair.create(Long.valueOf(l1), Long.valueOf(l2)); 
    long l3 = paramArrayOflong1[i];
    long l4 = paramArrayOflong2[i];
    if (l3 == l1) {
      d = 0.0D;
    } else {
      d = (paramLong - l1) / (l3 - l1);
    } 
    return Pair.create(Long.valueOf(paramLong), Long.valueOf((long)(d * (l4 - l2)) + l2));
  }
  
  public static c a(long paramLong1, j paramj, long paramLong2) {
    int k = paramj.d.length;
    int i = k + 1;
    long[] arrayOfLong1 = new long[i];
    long[] arrayOfLong2 = new long[i];
    arrayOfLong1[0] = paramLong1;
    long l2 = 0L;
    arrayOfLong2[0] = 0L;
    i = 1;
    long l1 = paramLong1;
    paramLong1 = l2;
    while (i <= k) {
      int m = paramj.b;
      int[] arrayOfInt = paramj.d;
      int n = i - 1;
      l1 += (m + arrayOfInt[n]);
      paramLong1 += (paramj.c + paramj.e[n]);
      arrayOfLong1[i] = l1;
      arrayOfLong2[i] = paramLong1;
      i++;
    } 
    return new c(arrayOfLong1, arrayOfLong2, paramLong2);
  }
  
  public v.a a(long paramLong) {
    Pair<Long, Long> pair = a(h.a(ai.a(paramLong, 0L, this.c)), this.b, this.a);
    return new v.a(new w(h.b(((Long)pair.first).longValue()), ((Long)pair.second).longValue()));
  }
  
  public boolean a() {
    return true;
  }
  
  public long b() {
    return this.c;
  }
  
  public long c() {
    return -1L;
  }
  
  public long c(long paramLong) {
    return h.b(((Long)(a(paramLong, this.a, this.b)).second).longValue());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\f\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */