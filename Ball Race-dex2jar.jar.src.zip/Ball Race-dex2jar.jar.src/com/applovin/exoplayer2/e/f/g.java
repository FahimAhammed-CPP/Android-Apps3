package com.applovin.exoplayer2.e.f;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.b.r;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.w;
import com.applovin.exoplayer2.l.a;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.y;

final class g implements e {
  private final long a;
  
  private final int b;
  
  private final long c;
  
  private final long d;
  
  private final long e;
  
  @Nullable
  private final long[] f;
  
  private g(long paramLong1, int paramInt, long paramLong2) {
    this(paramLong1, paramInt, paramLong2, -1L, null);
  }
  
  private g(long paramLong1, int paramInt, long paramLong2, long paramLong3, @Nullable long[] paramArrayOflong) {
    this.a = paramLong1;
    this.b = paramInt;
    this.c = paramLong2;
    this.f = paramArrayOflong;
    this.d = paramLong3;
    paramLong2 = -1L;
    if (paramLong3 == -1L) {
      paramLong1 = paramLong2;
    } else {
      paramLong1 += paramLong3;
    } 
    this.e = paramLong1;
  }
  
  private long a(int paramInt) {
    return this.c * paramInt / 100L;
  }
  
  @Nullable
  public static g a(long paramLong1, long paramLong2, r.a parama, y paramy) {
    int i = parama.g;
    int j = parama.d;
    int k = paramy.q();
    if ((k & 0x1) == 1) {
      int m = paramy.w();
      if (m != 0) {
        long l1 = ai.d(m, i * 1000000L, j);
        if ((k & 0x6) != 6)
          return new g(paramLong2, parama.c, l1); 
        long l2 = paramy.o();
        long[] arrayOfLong = new long[100];
        for (i = 0; i < 100; i++)
          arrayOfLong[i] = paramy.h(); 
        if (paramLong1 != -1L) {
          long l = paramLong2 + l2;
          if (paramLong1 != l) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("XING data size mismatch: ");
            stringBuilder.append(paramLong1);
            stringBuilder.append(", ");
            stringBuilder.append(l);
            q.c("XingSeeker", stringBuilder.toString());
          } 
        } 
        return new g(paramLong2, parama.c, l1, l2, arrayOfLong);
      } 
    } 
    return null;
  }
  
  public v.a a(long paramLong) {
    if (!a())
      return new v.a(new w(0L, this.a + this.b)); 
    paramLong = ai.a(paramLong, 0L, this.c);
    double d2 = paramLong * 100.0D / this.c;
    double d1 = 0.0D;
    if (d2 > 0.0D)
      if (d2 >= 100.0D) {
        d1 = 256.0D;
      } else {
        int i = (int)d2;
        long[] arrayOfLong = (long[])a.a(this.f);
        double d = arrayOfLong[i];
        if (i == 99) {
          d1 = 256.0D;
        } else {
          d1 = arrayOfLong[i + 1];
        } 
        d1 = d + (d2 - i) * (d1 - d);
      }  
    long l = ai.a(Math.round(d1 / 256.0D * this.d), this.b, this.d - 1L);
    return new v.a(new w(paramLong, this.a + l));
  }
  
  public boolean a() {
    return (this.f != null);
  }
  
  public long b() {
    return this.c;
  }
  
  public long c() {
    return this.e;
  }
  
  public long c(long paramLong) {
    paramLong -= this.a;
    if (!a() || paramLong <= this.b)
      return 0L; 
    long[] arrayOfLong = (long[])a.a(this.f);
    double d = paramLong * 256.0D / this.d;
    int i = ai.a(arrayOfLong, (long)d, true, true);
    long l1 = a(i);
    long l2 = arrayOfLong[i];
    int j = i + 1;
    long l3 = a(j);
    if (i == 99) {
      paramLong = 256L;
    } else {
      paramLong = arrayOfLong[j];
    } 
    if (l2 == paramLong) {
      d = 0.0D;
    } else {
      d = (d - l2) / (paramLong - l2);
    } 
    return l1 + Math.round(d * (l3 - l1));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\f\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */