package com.applovin.exoplayer2.e.f;

import com.applovin.exoplayer2.e.v;

interface e extends v {
  long c();
  
  long c(long paramLong);
  
  public static class a extends v.b implements e {
    public a() {
      super(-9223372036854775807L);
    }
    
    public long c() {
      return -1L;
    }
    
    public long c(long param1Long) {
      return 0L;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\f\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */