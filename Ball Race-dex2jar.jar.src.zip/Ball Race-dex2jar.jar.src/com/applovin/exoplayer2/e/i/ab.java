package com.applovin.exoplayer2.e.i;

import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.y;
import java.io.IOException;

final class ab {
  private final int a;
  
  private final ag b;
  
  private final y c;
  
  private boolean d;
  
  private boolean e;
  
  private boolean f;
  
  private long g;
  
  private long h;
  
  private long i;
  
  ab(int paramInt) {
    this.a = paramInt;
    this.b = new ag(0L);
    this.g = -9223372036854775807L;
    this.h = -9223372036854775807L;
    this.i = -9223372036854775807L;
    this.c = new y();
  }
  
  private int a(i parami) {
    this.c.a(ai.f);
    this.d = true;
    parami.a();
    return 0;
  }
  
  private long a(y paramy, int paramInt) {
    int i = paramy.c();
    int j = paramy.b();
    while (i < j) {
      if (paramy.d()[i] == 71) {
        long l = ae.a(paramy, i, paramInt);
        if (l != -9223372036854775807L)
          return l; 
      } 
      i++;
    } 
    return -9223372036854775807L;
  }
  
  private int b(i parami, u paramu, int paramInt) throws IOException {
    int j = (int)Math.min(this.a, parami.d());
    long l1 = parami.c();
    long l2 = 0L;
    if (l1 != l2) {
      paramu.a = l2;
      return 1;
    } 
    this.c.a(j);
    parami.a();
    parami.d(this.c.d(), 0, j);
    this.g = a(this.c, paramInt);
    this.e = true;
    return 0;
  }
  
  private long b(y paramy, int paramInt) {
    int j = paramy.c();
    int k = paramy.b();
    for (int i = k - 188; i >= j; i--) {
      if (ae.a(paramy.d(), j, k, i)) {
        long l = ae.a(paramy, i, paramInt);
        if (l != -9223372036854775807L)
          return l; 
      } 
    } 
    return -9223372036854775807L;
  }
  
  private int c(i parami, u paramu, int paramInt) throws IOException {
    long l = parami.d();
    int j = (int)Math.min(this.a, l);
    l -= j;
    if (parami.c() != l) {
      paramu.a = l;
      return 1;
    } 
    this.c.a(j);
    parami.a();
    parami.d(this.c.d(), 0, j);
    this.h = b(this.c, paramInt);
    this.f = true;
    return 0;
  }
  
  public int a(i parami, u paramu, int paramInt) throws IOException {
    if (paramInt <= 0)
      return a(parami); 
    if (!this.f)
      return c(parami, paramu, paramInt); 
    if (this.h == -9223372036854775807L)
      return a(parami); 
    if (!this.e)
      return b(parami, paramu, paramInt); 
    long l = this.g;
    if (l == -9223372036854775807L)
      return a(parami); 
    l = this.b.b(l);
    this.i = this.b.b(this.h) - l;
    if (this.i < 0L) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid duration: ");
      stringBuilder.append(this.i);
      stringBuilder.append(". Using TIME_UNSET instead.");
      q.c("TsDurationReader", stringBuilder.toString());
      this.i = -9223372036854775807L;
    } 
    return a(parami);
  }
  
  public boolean a() {
    return this.d;
  }
  
  public long b() {
    return this.i;
  }
  
  public ag c() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\i\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */