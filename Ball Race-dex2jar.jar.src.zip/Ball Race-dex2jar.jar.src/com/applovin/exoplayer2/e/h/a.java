package com.applovin.exoplayer2.e.h;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.k;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.w;
import com.applovin.exoplayer2.l.ai;
import java.io.EOFException;
import java.io.IOException;

final class a implements f {
  private final e a;
  
  private final long b;
  
  private final long c;
  
  private final h d;
  
  private int e;
  
  private long f;
  
  private long g;
  
  private long h;
  
  private long i;
  
  private long j;
  
  private long k;
  
  private long l;
  
  public a(h paramh, long paramLong1, long paramLong2, long paramLong3, long paramLong4, boolean paramBoolean) {
    boolean bool;
    if (paramLong1 >= 0L && paramLong2 > paramLong1) {
      bool = true;
    } else {
      bool = false;
    } 
    com.applovin.exoplayer2.l.a.a(bool);
    this.d = paramh;
    this.b = paramLong1;
    this.c = paramLong2;
    if (paramLong3 == paramLong2 - paramLong1 || paramBoolean) {
      this.f = paramLong4;
      this.e = 4;
    } else {
      this.e = 0;
    } 
    this.a = new e();
  }
  
  private long c(i parami) throws IOException {
    if (this.i == this.j)
      return -1L; 
    long l1 = parami.c();
    if (!this.a.a(parami, this.j)) {
      long l = this.i;
      if (l != l1)
        return l; 
      throw new IOException("No ogg page can be found.");
    } 
    this.a.a(parami, false);
    parami.a();
    long l2 = this.h - this.a.c;
    int j = this.a.h + this.a.i;
    if (0L <= l2 && l2 < 72000L)
      return -1L; 
    int k = l2 cmp 0L;
    if (k < 0) {
      this.j = l1;
      this.l = this.a.c;
    } else {
      this.i = parami.c() + j;
      this.k = this.a.c;
    } 
    l1 = this.j;
    long l3 = this.i;
    if (l1 - l3 < 100000L) {
      this.j = l3;
      return l3;
    } 
    l3 = j;
    if (k <= 0) {
      l1 = 2L;
    } else {
      l1 = 1L;
    } 
    long l4 = parami.c();
    long l5 = this.j;
    long l6 = this.i;
    return ai.a(l4 - l3 * l1 + l2 * (l5 - l6) / (this.l - this.k), l6, l5 - 1L);
  }
  
  private void d(i parami) throws IOException {
    while (true) {
      this.a.a(parami);
      this.a.a(parami, false);
      if (this.a.c > this.h) {
        parami.a();
        return;
      } 
      parami.b(this.a.h + this.a.i);
      this.i = parami.c();
      this.k = this.a.c;
    } 
  }
  
  public long a(i parami) throws IOException {
    int j = this.e;
    if (j != 0) {
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j == 4)
              return -1L; 
            throw new IllegalStateException();
          } 
        } else {
          long l = c(parami);
          if (l != -1L)
            return l; 
          this.e = 3;
        } 
        d(parami);
        this.e = 4;
        return -(this.k + 2L);
      } 
    } else {
      this.g = parami.c();
      this.e = 1;
      long l = this.c - 65307L;
      if (l > this.g)
        return l; 
    } 
    this.f = b(parami);
    this.e = 4;
    return this.g;
  }
  
  @Nullable
  public a a() {
    return (this.f != 0L) ? new a() : null;
  }
  
  public void a(long paramLong) {
    this.h = ai.a(paramLong, 0L, this.f - 1L);
    this.e = 2;
    this.i = this.b;
    this.j = this.c;
    this.k = 0L;
    this.l = this.f;
  }
  
  @VisibleForTesting
  long b(i parami) throws IOException {
    this.a.a();
    if (this.a.a(parami)) {
      this.a.a(parami, false);
      parami.b(this.a.h + this.a.i);
      long l;
      for (l = this.a.c; (this.a.b & 0x4) != 4 && this.a.a(parami) && parami.c() < this.c && this.a.a(parami, true); l = this.a.c) {
        if (!k.a(parami, this.a.h + this.a.i))
          return l; 
      } 
      return l;
    } 
    throw new EOFException();
  }
  
  private final class a implements v {
    private a(a this$0) {}
    
    public v.a a(long param1Long) {
      long l = a.a(this.a).b(param1Long);
      return new v.a(new w(param1Long, ai.a(a.b(this.a) + l * (a.c(this.a) - a.b(this.a)) / a.d(this.a) - 30000L, a.b(this.a), a.c(this.a) - 1L)));
    }
    
    public boolean a() {
      return true;
    }
    
    public long b() {
      return a.a(this.a).a(a.d(this.a));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\h\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */