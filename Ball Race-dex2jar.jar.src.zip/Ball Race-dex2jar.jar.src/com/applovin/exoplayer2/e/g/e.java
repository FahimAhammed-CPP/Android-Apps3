package com.applovin.exoplayer2.e.g;

import android.util.Pair;
import android.util.SparseArray;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ai;
import com.applovin.exoplayer2.e.c;
import com.applovin.exoplayer2.e.h;
import com.applovin.exoplayer2.e.i;
import com.applovin.exoplayer2.e.j;
import com.applovin.exoplayer2.e.l;
import com.applovin.exoplayer2.e.r;
import com.applovin.exoplayer2.e.u;
import com.applovin.exoplayer2.e.v;
import com.applovin.exoplayer2.e.x;
import com.applovin.exoplayer2.g.b.c;
import com.applovin.exoplayer2.l.ag;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.v;
import com.applovin.exoplayer2.l.y;
import com.applovin.exoplayer2.v;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class e implements h {
  public static final l a = -$$Lambda$e$XdcPKOBxOMtaTqkUwwYk0cfnngM.INSTANCE;
  
  private static final byte[] b = new byte[] { 
      -94, 57, 79, 82, 90, -101, 79, 20, -94, 68, 
      108, 66, 124, 100, -115, -12 };
  
  private static final v c = (new v.a()).f("application/x-emsg").a();
  
  private long A;
  
  private long B;
  
  @Nullable
  private b C;
  
  private int D;
  
  private int E;
  
  private int F;
  
  private boolean G;
  
  private j H;
  
  private x[] I;
  
  private x[] J;
  
  private boolean K;
  
  private final int d;
  
  @Nullable
  private final k e;
  
  private final List<v> f;
  
  private final SparseArray<b> g;
  
  private final y h;
  
  private final y i;
  
  private final y j;
  
  private final byte[] k;
  
  private final y l;
  
  @Nullable
  private final ag m;
  
  private final c n;
  
  private final y o;
  
  private final ArrayDeque<a.a> p;
  
  private final ArrayDeque<a> q;
  
  @Nullable
  private final x r;
  
  private int s;
  
  private int t;
  
  private long u;
  
  private int v;
  
  @Nullable
  private y w;
  
  private long x;
  
  private int y;
  
  private long z;
  
  public e() {
    this(0);
  }
  
  public e(int paramInt) {
    this(paramInt, null);
  }
  
  public e(int paramInt, @Nullable ag paramag) {
    this(paramInt, paramag, null, Collections.emptyList());
  }
  
  public e(int paramInt, @Nullable ag paramag, @Nullable k paramk, List<v> paramList) {
    this(paramInt, paramag, paramk, paramList, null);
  }
  
  public e(int paramInt, @Nullable ag paramag, @Nullable k paramk, List<v> paramList, @Nullable x paramx) {
    this.d = paramInt;
    this.m = paramag;
    this.e = paramk;
    this.f = Collections.unmodifiableList(paramList);
    this.r = paramx;
    this.n = new c();
    this.o = new y(16);
    this.h = new y(v.a);
    this.i = new y(5);
    this.j = new y();
    this.k = new byte[16];
    this.l = new y(this.k);
    this.p = new ArrayDeque<a.a>();
    this.q = new ArrayDeque<a>();
    this.g = new SparseArray();
    this.A = -9223372036854775807L;
    this.z = -9223372036854775807L;
    this.B = -9223372036854775807L;
    this.H = j.a;
    this.I = new x[0];
    this.J = new x[0];
  }
  
  private static int a(int paramInt) throws ai {
    if (paramInt >= 0)
      return paramInt; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unexpected negative value: ");
    stringBuilder.append(paramInt);
    throw ai.b(stringBuilder.toString(), null);
  }
  
  private static int a(b paramb, int paramInt1, int paramInt2, y paramy, int paramInt3) throws ai {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    boolean bool4;
    b b1 = paramb;
    paramy.d(8);
    int m = a.b(paramy.q());
    k k1 = b1.d.a;
    m m1 = b1.b;
    c c1 = (c)ai.a(m1.a);
    m1.h[paramInt1] = paramy.w();
    m1.g[paramInt1] = m1.c;
    if ((m & 0x1) != 0) {
      long[] arrayOfLong = m1.g;
      arrayOfLong[paramInt1] = arrayOfLong[paramInt1] + paramy.q();
    } 
    if ((m & 0x4) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int i = c1.d;
    if (bool1)
      i = paramy.q(); 
    if ((m & 0x100) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if ((m & 0x200) != 0) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    if ((m & 0x400) != 0) {
      bool4 = true;
    } else {
      bool4 = false;
    } 
    if ((m & 0x800) != 0) {
      m = 1;
    } else {
      m = 0;
    } 
    long[] arrayOfLong1 = k1.h;
    long l2 = 0L;
    long l1 = l2;
    if (arrayOfLong1 != null) {
      l1 = l2;
      if (k1.h.length == 1) {
        l1 = l2;
        if (k1.h[0] == 0L)
          l1 = ai.d(((long[])ai.a(k1.i))[0], 1000000L, k1.c); 
      } 
    } 
    int[] arrayOfInt1 = m1.i;
    int[] arrayOfInt2 = m1.j;
    long[] arrayOfLong2 = m1.k;
    boolean[] arrayOfBoolean = m1.l;
    if (k1.b == 2 && (paramInt2 & 0x1) != 0) {
      paramInt2 = 1;
    } else {
      paramInt2 = 0;
    } 
    int n = paramInt3 + m1.h[paramInt1];
    l2 = k1.c;
    long l3 = m1.r;
    while (paramInt3 < n) {
      boolean bool;
      if (bool2) {
        paramInt1 = paramy.q();
      } else {
        paramInt1 = c1.b;
      } 
      int i1 = a(paramInt1);
      if (bool3) {
        paramInt1 = paramy.q();
      } else {
        paramInt1 = c1.c;
      } 
      int i2 = a(paramInt1);
      if (bool4) {
        paramInt1 = paramy.q();
      } else if (paramInt3 == 0 && bool1) {
        paramInt1 = i;
      } else {
        paramInt1 = c1.d;
      } 
      if (m != 0) {
        arrayOfInt2[paramInt3] = (int)(paramy.q() * 1000000L / l2);
      } else {
        arrayOfInt2[paramInt3] = 0;
      } 
      arrayOfLong2[paramInt3] = ai.d(l3, 1000000L, l2) - l1;
      if (!m1.s)
        arrayOfLong2[paramInt3] = arrayOfLong2[paramInt3] + paramb.d.h; 
      arrayOfInt1[paramInt3] = i2;
      if ((paramInt1 >> 16 & 0x1) == 0 && (paramInt2 == 0 || paramInt3 == 0)) {
        bool = true;
      } else {
        bool = false;
      } 
      arrayOfBoolean[paramInt3] = bool;
      l3 += i1;
      paramInt3++;
    } 
    m1.r = l3;
    return n;
  }
  
  private static Pair<Long, c> a(y paramy, long paramLong) throws ai {
    paramy.d(8);
    int i = a.a(paramy.q());
    paramy.e(4);
    long l4 = paramy.o();
    if (i == 0) {
      l1 = paramy.o();
      l2 = paramy.o();
    } else {
      l1 = paramy.y();
      l2 = paramy.y();
    } 
    paramLong += l2;
    long l3 = ai.d(l1, 1000000L, l4);
    paramy.e(2);
    i = paramy.i();
    int[] arrayOfInt = new int[i];
    long[] arrayOfLong1 = new long[i];
    long[] arrayOfLong2 = new long[i];
    long[] arrayOfLong3 = new long[i];
    long l2 = l1;
    long l1 = l3;
    int m = 0;
    while (m < i) {
      int n = paramy.q();
      if ((n & Integer.MIN_VALUE) == 0) {
        long l5 = paramy.o();
        arrayOfInt[m] = n & Integer.MAX_VALUE;
        arrayOfLong1[m] = paramLong;
        arrayOfLong3[m] = l1;
        l2 += l5;
        l1 = ai.d(l2, 1000000L, l4);
        arrayOfLong2[m] = l1 - arrayOfLong3[m];
        paramy.e(4);
        paramLong += arrayOfInt[m];
        m++;
        continue;
      } 
      throw ai.b("Unhandled indirect reference", null);
    } 
    return Pair.create(Long.valueOf(l3), new c(arrayOfInt, arrayOfLong1, arrayOfLong2, arrayOfLong3));
  }
  
  @Nullable
  private static com.applovin.exoplayer2.d.e a(List<a.b> paramList) {
    int m = paramList.size();
    int i = 0;
    ArrayList<com.applovin.exoplayer2.d.e.a> arrayList;
    for (arrayList = null; i < m; arrayList = arrayList1) {
      a.b b1 = paramList.get(i);
      ArrayList<com.applovin.exoplayer2.d.e.a> arrayList1 = arrayList;
      if (b1.a == 1886614376) {
        arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        byte[] arrayOfByte = b1.b.d();
        UUID uUID = h.b(arrayOfByte);
        if (uUID == null) {
          q.c("FragmentedMp4Extractor", "Skipped pssh atom (failed to extract uuid)");
        } else {
          arrayList1.add(new com.applovin.exoplayer2.d.e.a(uUID, "video/mp4", arrayOfByte));
        } 
      } 
      i++;
    } 
    return (arrayList == null) ? null : new com.applovin.exoplayer2.d.e(arrayList);
  }
  
  private c a(SparseArray<c> paramSparseArray, int paramInt) {
    return (paramSparseArray.size() == 1) ? (c)paramSparseArray.valueAt(0) : (c)com.applovin.exoplayer2.l.a.b(paramSparseArray.get(paramInt));
  }
  
  @Nullable
  private static b a(SparseArray<b> paramSparseArray) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual size : ()I
    //   4: istore_2
    //   5: aconst_null
    //   6: astore #9
    //   8: ldc2_w 9223372036854775807
    //   11: lstore_3
    //   12: iconst_0
    //   13: istore_1
    //   14: iload_1
    //   15: iload_2
    //   16: if_icmpge -> 137
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   24: checkcast com/applovin/exoplayer2/e/g/e$b
    //   27: astore #11
    //   29: aload #11
    //   31: invokestatic a : (Lcom/applovin/exoplayer2/e/g/e$b;)Z
    //   34: ifne -> 60
    //   37: aload #9
    //   39: astore #10
    //   41: lload_3
    //   42: lstore #5
    //   44: aload #11
    //   46: getfield f : I
    //   49: aload #11
    //   51: getfield d : Lcom/applovin/exoplayer2/e/g/n;
    //   54: getfield b : I
    //   57: if_icmpeq -> 123
    //   60: aload #11
    //   62: invokestatic a : (Lcom/applovin/exoplayer2/e/g/e$b;)Z
    //   65: ifeq -> 94
    //   68: aload #11
    //   70: getfield h : I
    //   73: aload #11
    //   75: getfield b : Lcom/applovin/exoplayer2/e/g/m;
    //   78: getfield e : I
    //   81: if_icmpne -> 94
    //   84: aload #9
    //   86: astore #10
    //   88: lload_3
    //   89: lstore #5
    //   91: goto -> 123
    //   94: aload #11
    //   96: invokevirtual c : ()J
    //   99: lstore #7
    //   101: aload #9
    //   103: astore #10
    //   105: lload_3
    //   106: lstore #5
    //   108: lload #7
    //   110: lload_3
    //   111: lcmp
    //   112: ifge -> 123
    //   115: aload #11
    //   117: astore #10
    //   119: lload #7
    //   121: lstore #5
    //   123: iload_1
    //   124: iconst_1
    //   125: iadd
    //   126: istore_1
    //   127: aload #10
    //   129: astore #9
    //   131: lload #5
    //   133: lstore_3
    //   134: goto -> 14
    //   137: aload #9
    //   139: areturn
  }
  
  @Nullable
  private static b a(y paramy, SparseArray<b> paramSparseArray, boolean paramBoolean) {
    int m;
    int n;
    paramy.d(8);
    int i1 = a.b(paramy.q());
    int i = paramy.q();
    if (paramBoolean) {
      object = paramSparseArray.valueAt(0);
    } else {
      object = object.get(i);
    } 
    Object object = object;
    if (object == null)
      return null; 
    if ((i1 & 0x1) != 0) {
      long l1 = paramy.y();
      ((b)object).b.c = l1;
      ((b)object).b.d = l1;
    } 
    c c1 = ((b)object).e;
    if ((i1 & 0x2) != 0) {
      i = paramy.q() - 1;
    } else {
      i = c1.a;
    } 
    if ((i1 & 0x8) != 0) {
      m = paramy.q();
    } else {
      m = c1.b;
    } 
    if ((i1 & 0x10) != 0) {
      n = paramy.q();
    } else {
      n = c1.c;
    } 
    if ((i1 & 0x20) != 0) {
      i1 = paramy.q();
    } else {
      i1 = c1.d;
    } 
    ((b)object).b.a = new c(i, m, n, i1);
    return (b)object;
  }
  
  private void a() {
    this.s = 0;
    this.v = 0;
  }
  
  private void a(long paramLong) throws ai {
    while (!this.p.isEmpty() && ((a.a)this.p.peek()).b == paramLong)
      a(this.p.pop()); 
    a();
  }
  
  private void a(a.a parama) throws ai {
    if (parama.a == 1836019574) {
      b(parama);
      return;
    } 
    if (parama.a == 1836019558) {
      c(parama);
      return;
    } 
    if (!this.p.isEmpty())
      ((a.a)this.p.peek()).a(parama); 
  }
  
  private static void a(a.a parama, SparseArray<b> paramSparseArray, boolean paramBoolean, int paramInt, byte[] paramArrayOfbyte) throws ai {
    int m = parama.d.size();
    int i;
    for (i = 0; i < m; i++) {
      a.a a1 = parama.d.get(i);
      if (a1.a == 1953653094)
        b(a1, paramSparseArray, paramBoolean, paramInt, paramArrayOfbyte); 
    } 
  }
  
  private static void a(a.a parama, b paramb, int paramInt) throws ai {
    List<a.b> list = parama.c;
    int i1 = list.size();
    boolean bool = false;
    int i = 0;
    int m = 0;
    int n;
    for (n = 0; i < i1; n = i2) {
      a.b b1 = list.get(i);
      int i3 = m;
      int i2 = n;
      if (b1.a == 1953658222) {
        y y1 = b1.b;
        y1.d(12);
        int i4 = y1.w();
        i3 = m;
        i2 = n;
        if (i4 > 0) {
          i2 = n + i4;
          i3 = m + 1;
        } 
      } 
      i++;
      m = i3;
    } 
    paramb.h = 0;
    paramb.g = 0;
    paramb.f = 0;
    paramb.b.a(m, n);
    m = 0;
    n = 0;
    i = bool;
    while (i < i1) {
      a.b b1 = list.get(i);
      int i3 = m;
      int i2 = n;
      if (b1.a == 1953658222) {
        i2 = a(paramb, m, paramInt, b1.b, n);
        i3 = m + 1;
      } 
      i++;
      m = i3;
      n = i2;
    } 
  }
  
  private static void a(a.a parama, @Nullable String paramString, m paramm) throws ai {
    a.a a1 = null;
    y y2 = null;
    y y1 = y2;
    int i = 0;
    while (i < parama.c.size()) {
      y y4;
      y y5;
      a.b b1 = parama.c.get(i);
      y y3 = b1.b;
      if (b1.a == 1935828848) {
        y3.d(12);
        y4 = y2;
        y5 = y1;
        if (y3.q() == 1936025959) {
          y4 = y3;
          y5 = y1;
        } 
      } else {
        y4 = y2;
        y5 = y1;
        if (b1.a == 1936158820) {
          y3.d(12);
          y4 = y2;
          y5 = y1;
          if (y3.q() == 1936025959) {
            y5 = y3;
            y4 = y2;
          } 
        } 
      } 
      i++;
      y2 = y4;
      y1 = y5;
    } 
    if (y2 != null) {
      if (y1 == null)
        return; 
      y2.d(8);
      i = a.a(y2.q());
      y2.e(4);
      if (i == 1)
        y2.e(4); 
      if (y2.q() == 1) {
        y1.d(8);
        i = a.a(y1.q());
        y1.e(4);
        if (i == 1) {
          if (y1.o() == 0L)
            throw ai.a("Variable length description in sgpd found (unsupported)"); 
        } else if (i >= 2) {
          y1.e(4);
        } 
        if (y1.o() == 1L) {
          byte[] arrayOfByte1;
          boolean bool;
          y1.e(1);
          i = y1.h();
          if (y1.h() == 1) {
            bool = true;
          } else {
            bool = false;
          } 
          if (!bool)
            return; 
          int n = y1.h();
          byte[] arrayOfByte2 = new byte[16];
          y1.a(arrayOfByte2, 0, arrayOfByte2.length);
          parama = a1;
          if (n == 0) {
            int i1 = y1.h();
            arrayOfByte1 = new byte[i1];
            y1.a(arrayOfByte1, 0, i1);
          } 
          paramm.m = true;
          paramm.o = new l(bool, paramString, n, arrayOfByte2, (i & 0xF0) >> 4, i & 0xF, arrayOfByte1);
          return;
        } 
        throw ai.a("Entry count in sgpd != 1 (unsupported).");
      } 
      throw ai.a("Entry count in sbgp != 1 (unsupported).");
    } 
  }
  
  private void a(a.b paramb, long paramLong) throws ai {
    Pair<Long, c> pair;
    if (!this.p.isEmpty()) {
      ((a.a)this.p.peek()).a(paramb);
      return;
    } 
    if (paramb.a == 1936286840) {
      pair = a(paramb.b, paramLong);
      this.B = ((Long)pair.first).longValue();
      this.H.a((v)pair.second);
      this.K = true;
      return;
    } 
    if (((a.b)pair).a == 1701671783)
      a(((a.b)pair).b); 
  }
  
  private static void a(l paraml, y paramy, m paramm) throws ai {
    int n = paraml.d;
    paramy.d(8);
    int i = a.b(paramy.q());
    boolean bool = true;
    if ((i & 0x1) == 1)
      paramy.e(8); 
    i = paramy.h();
    int i1 = paramy.w();
    if (i1 <= paramm.f) {
      int i2;
      if (i == 0) {
        boolean[] arrayOfBoolean = paramm.n;
        int i3 = 0;
        i = 0;
        while (true) {
          i2 = i;
          if (i3 < i1) {
            i2 = paramy.h();
            i += i2;
            if (i2 > n) {
              bool = true;
            } else {
              bool = false;
            } 
            arrayOfBoolean[i3] = bool;
            i3++;
            continue;
          } 
          break;
        } 
      } else {
        if (i <= n)
          bool = false; 
        i2 = i * i1 + 0;
        Arrays.fill(paramm.n, 0, i1, bool);
      } 
      Arrays.fill(paramm.n, i1, paramm.f, false);
      if (i2 > 0)
        paramm.a(i2); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Saiz sample count ");
    stringBuilder.append(i1);
    stringBuilder.append(" is greater than fragment sample count");
    stringBuilder.append(paramm.f);
    throw ai.b(stringBuilder.toString(), null);
  }
  
  private void a(y paramy) {
    StringBuilder stringBuilder;
    long l1;
    long l3;
    long l4;
    String str1;
    String str2;
    if (this.I.length == 0)
      return; 
    paramy.d(8);
    null = a.a(paramy.q());
    if (null != 0) {
      if (null != 1) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Skipping unsupported emsg version: ");
        stringBuilder.append(null);
        q.c("FragmentedMp4Extractor", stringBuilder.toString());
        return;
      } 
      l2 = stringBuilder.o();
      l1 = ai.d(stringBuilder.y(), 1000000L, l2);
      l2 = ai.d(stringBuilder.o(), 1000L, l2);
      l3 = stringBuilder.o();
      str1 = (String)com.applovin.exoplayer2.l.a.b(stringBuilder.B());
      str2 = (String)com.applovin.exoplayer2.l.a.b(stringBuilder.B());
      l4 = -9223372036854775807L;
    } else {
      str1 = (String)com.applovin.exoplayer2.l.a.b(stringBuilder.B());
      str2 = (String)com.applovin.exoplayer2.l.a.b(stringBuilder.B());
      l2 = stringBuilder.o();
      l4 = ai.d(stringBuilder.o(), 1000000L, l2);
      l1 = this.B;
      if (l1 != -9223372036854775807L) {
        l1 += l4;
      } else {
        l1 = -9223372036854775807L;
      } 
      l2 = ai.d(stringBuilder.o(), 1000L, l2);
      l3 = stringBuilder.o();
    } 
    byte[] arrayOfByte = new byte[stringBuilder.a()];
    null = stringBuilder.a();
    byte b1 = 0;
    stringBuilder.a(arrayOfByte, 0, null);
    com.applovin.exoplayer2.g.b.a a = new com.applovin.exoplayer2.g.b.a(str1, str2, l2, l3, arrayOfByte);
    y y1 = new y(this.n.a(a));
    int m = y1.a();
    for (x x1 : this.I) {
      y1.d(0);
      x1.a(y1, m);
    } 
    if (l1 == -9223372036854775807L) {
      this.q.addLast(new a(l4, m));
      this.y += m;
      return;
    } 
    ag ag1 = this.m;
    long l2 = l1;
    if (ag1 != null)
      l2 = ag1.c(l1); 
    x[] arrayOfX = this.I;
    int n = arrayOfX.length;
    for (int i = b1; i < n; i++)
      arrayOfX[i].a(l2, 1, m, 0, null); 
  }
  
  private static void a(y paramy, int paramInt, m paramm) throws ai {
    paramy.d(paramInt + 8);
    paramInt = a.b(paramy.q());
    if ((paramInt & 0x1) == 0) {
      boolean bool;
      if ((paramInt & 0x2) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      paramInt = paramy.w();
      if (paramInt == 0) {
        Arrays.fill(paramm.n, 0, paramm.f, false);
        return;
      } 
      if (paramInt == paramm.f) {
        Arrays.fill(paramm.n, 0, paramInt, bool);
        paramm.a(paramy.a());
        paramm.a(paramy);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Senc sample count ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" is different from fragment sample count");
      stringBuilder.append(paramm.f);
      throw ai.b(stringBuilder.toString(), null);
    } 
    throw ai.a("Overriding TrackEncryptionBox parameters is unsupported.");
  }
  
  private static void a(y paramy, m paramm) throws ai {
    paramy.d(8);
    int i = paramy.q();
    if ((a.b(i) & 0x1) == 1)
      paramy.e(8); 
    int n = paramy.w();
    if (n == 1) {
      long l1;
      i = a.a(i);
      long l2 = paramm.d;
      if (i == 0) {
        l1 = paramy.o();
      } else {
        l1 = paramy.y();
      } 
      paramm.d = l2 + l1;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unexpected saio entry count: ");
    stringBuilder.append(n);
    throw ai.b(stringBuilder.toString(), null);
  }
  
  private static void a(y paramy, m paramm, byte[] paramArrayOfbyte) throws ai {
    paramy.d(8);
    paramy.a(paramArrayOfbyte, 0, 16);
    if (!Arrays.equals(paramArrayOfbyte, b))
      return; 
    a(paramy, 16, paramm);
  }
  
  private static Pair<Integer, c> b(y paramy) {
    paramy.d(12);
    return Pair.create(Integer.valueOf(paramy.q()), new c(paramy.q() - 1, paramy.q(), paramy.q(), paramy.q()));
  }
  
  private void b() {
    this.I = new x[2];
    x x1 = this.r;
    boolean bool = false;
    if (x1 != null) {
      this.I[0] = x1;
      m = 1;
    } else {
      m = 0;
    } 
    int i1 = this.d;
    int i = 100;
    int n = m;
    if ((i1 & 0x4) != 0) {
      this.I[m] = this.H.a(100, 5);
      n = m + 1;
      i = 101;
    } 
    this.I = (x[])ai.a((Object[])this.I, n);
    x[] arrayOfX = this.I;
    n = arrayOfX.length;
    int m;
    for (m = 0; m < n; m++)
      arrayOfX[m].a(c); 
    this.J = new x[this.f.size()];
    m = bool;
    while (m < this.J.length) {
      x x2 = this.H.a(i, 3);
      x2.a(this.f.get(m));
      this.J[m] = x2;
      m++;
      i++;
    } 
  }
  
  private void b(long paramLong) {
    while (!this.q.isEmpty()) {
      a a = this.q.removeFirst();
      this.y -= a.b;
      long l2 = a.a + paramLong;
      ag ag1 = this.m;
      long l1 = l2;
      if (ag1 != null)
        l1 = ag1.c(l2); 
      x[] arrayOfX = this.I;
      int m = arrayOfX.length;
      for (int i = 0; i < m; i++)
        arrayOfX[i].a(l1, 1, a.b, this.y, null); 
    } 
  }
  
  private void b(a.a parama) throws ai {
    boolean bool3;
    k k1 = this.e;
    boolean bool4 = true;
    boolean bool2 = false;
    boolean bool1 = false;
    if (k1 == null) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    com.applovin.exoplayer2.l.a.b(bool3, "Unexpected moov box.");
    com.applovin.exoplayer2.d.e e1 = a(parama.c);
    a.a a1 = (a.a)com.applovin.exoplayer2.l.a.b(parama.e(1836475768));
    SparseArray<c> sparseArray = new SparseArray();
    int m = a1.c.size();
    long l1 = -9223372036854775807L;
    int i;
    for (i = 0; i < m; i++) {
      Pair<Integer, c> pair;
      a.b b1 = a1.c.get(i);
      if (b1.a == 1953654136) {
        pair = b(b1.b);
        sparseArray.put(((Integer)pair.first).intValue(), pair.second);
      } else if (((a.b)pair).a == 1835362404) {
        l1 = c(((a.b)pair).b);
      } 
    } 
    r r = new r();
    if ((this.d & 0x10) != 0) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    List<n> list = b.a(parama, r, l1, e1, bool3, false, new -$$Lambda$XLNslbbdGUVszHL4TyR-aAvaheQ(this));
    m = list.size();
    if (this.g.size() == 0) {
      for (i = bool1; i < m; i++) {
        n n = list.get(i);
        k k2 = n.a;
        b b1 = new b(this.H.a(i, k2.b), n, a(sparseArray, k2.a));
        this.g.put(k2.a, b1);
        this.A = Math.max(this.A, k2.e);
      } 
      this.H.a();
      return;
    } 
    if (this.g.size() == m) {
      bool3 = bool4;
    } else {
      bool3 = false;
    } 
    com.applovin.exoplayer2.l.a.b(bool3);
    for (i = bool2; i < m; i++) {
      n n = list.get(i);
      k k2 = n.a;
      ((b)this.g.get(k2.a)).a(n, a(sparseArray, k2.a));
    } 
  }
  
  private static void b(a.a parama, SparseArray<b> paramSparseArray, boolean paramBoolean, int paramInt, byte[] paramArrayOfbyte) throws ai {
    b b1 = a(((a.b)com.applovin.exoplayer2.l.a.b(parama.d(1952868452))).b, paramSparseArray, paramBoolean);
    if (b1 == null)
      return; 
    m m = b1.b;
    long l2 = m.r;
    paramBoolean = m.s;
    b1.a();
    b.a(b1, true);
    a.b b2 = parama.d(1952867444);
    if (b2 != null && (paramInt & 0x2) == 0) {
      m.r = d(b2.b);
      m.s = true;
    } else {
      m.r = l2;
      m.s = paramBoolean;
    } 
    a(parama, b1, paramInt);
    l l1 = b1.d.a.a(((c)com.applovin.exoplayer2.l.a.b(m.a)).a);
    b2 = parama.d(1935763834);
    if (b2 != null)
      a((l)com.applovin.exoplayer2.l.a.b(l1), b2.b, m); 
    b2 = parama.d(1935763823);
    if (b2 != null)
      a(b2.b, m); 
    b2 = parama.d(1936027235);
    if (b2 != null)
      b(b2.b, m); 
    if (l1 != null) {
      String str = l1.b;
    } else {
      l1 = null;
    } 
    a(parama, (String)l1, m);
    int i = parama.c.size();
    for (paramInt = 0; paramInt < i; paramInt++) {
      a.b b3 = parama.c.get(paramInt);
      if (b3.a == 1970628964)
        a(b3.b, m, paramArrayOfbyte); 
    } 
  }
  
  private static void b(y paramy, m paramm) throws ai {
    a(paramy, 0, paramm);
  }
  
  private static boolean b(int paramInt) {
    return (paramInt == 1751411826 || paramInt == 1835296868 || paramInt == 1836476516 || paramInt == 1936286840 || paramInt == 1937011556 || paramInt == 1937011827 || paramInt == 1668576371 || paramInt == 1937011555 || paramInt == 1937011578 || paramInt == 1937013298 || paramInt == 1937007471 || paramInt == 1668232756 || paramInt == 1937011571 || paramInt == 1952867444 || paramInt == 1952868452 || paramInt == 1953196132 || paramInt == 1953654136 || paramInt == 1953658222 || paramInt == 1886614376 || paramInt == 1935763834 || paramInt == 1935763823 || paramInt == 1936027235 || paramInt == 1970628964 || paramInt == 1935828848 || paramInt == 1936158820 || paramInt == 1701606260 || paramInt == 1835362404 || paramInt == 1701671783);
  }
  
  private boolean b(i parami) throws IOException {
    if (this.v == 0) {
      if (!parami.a(this.o.d(), 0, 8, true))
        return false; 
      this.v = 8;
      this.o.d(0);
      this.u = this.o.o();
      this.t = this.o.q();
    } 
    long l1 = this.u;
    if (l1 == 1L) {
      parami.b(this.o.d(), 8, 8);
      this.v += 8;
      this.u = this.o.y();
    } else if (l1 == 0L) {
      long l2 = parami.d();
      l1 = l2;
      if (l2 == -1L) {
        l1 = l2;
        if (!this.p.isEmpty())
          l1 = ((a.a)this.p.peek()).b; 
      } 
      if (l1 != -1L)
        this.u = l1 - parami.c() + this.v; 
    } 
    if (this.u >= this.v) {
      l1 = parami.c() - this.v;
      int m = this.t;
      if ((m == 1836019558 || m == 1835295092) && !this.K) {
        this.H.a((v)new v.b(this.A, l1));
        this.K = true;
      } 
      if (this.t == 1836019558) {
        int n = this.g.size();
        for (m = 0; m < n; m++) {
          m m1 = ((b)this.g.valueAt(m)).b;
          m1.b = l1;
          m1.d = l1;
          m1.c = l1;
        } 
      } 
      m = this.t;
      if (m == 1835295092) {
        this.C = null;
        this.x = l1 + this.u;
        this.s = 2;
        return true;
      } 
      if (c(m)) {
        l1 = parami.c() + this.u - 8L;
        this.p.push(new a.a(this.t, l1));
        if (this.u == this.v) {
          a(l1);
          return true;
        } 
        a();
        return true;
      } 
      if (b(this.t)) {
        if (this.v == 8) {
          l1 = this.u;
          if (l1 <= 2147483647L) {
            y y1 = new y((int)l1);
            System.arraycopy(this.o.d(), 0, y1.d(), 0, 8);
            this.w = y1;
            this.s = 1;
            return true;
          } 
          throw ai.a("Leaf atom with length > 2147483647 (unsupported).");
        } 
        throw ai.a("Leaf atom defines extended atom size (unsupported).");
      } 
      if (this.u <= 2147483647L) {
        this.w = null;
        this.s = 1;
        return true;
      } 
      throw ai.a("Skipping atom with length > 2147483647 (unsupported).");
    } 
    throw ai.a("Atom size less than header length (unsupported).");
  }
  
  private static long c(y paramy) {
    paramy.d(8);
    return (a.a(paramy.q()) == 0) ? paramy.o() : paramy.y();
  }
  
  private void c(a.a parama) throws ai {
    boolean bool;
    SparseArray<b> sparseArray = this.g;
    k k1 = this.e;
    byte b1 = 0;
    if (k1 != null) {
      bool = true;
    } else {
      bool = false;
    } 
    a(parama, sparseArray, bool, this.d, this.k);
    com.applovin.exoplayer2.d.e e1 = a(parama.c);
    if (e1 != null) {
      int m = this.g.size();
      for (int i = 0; i < m; i++)
        ((b)this.g.valueAt(i)).a(e1); 
    } 
    if (this.z != -9223372036854775807L) {
      int m = this.g.size();
      for (int i = b1; i < m; i++)
        ((b)this.g.valueAt(i)).a(this.z); 
      this.z = -9223372036854775807L;
    } 
  }
  
  private void c(i parami) throws IOException {
    int m = (int)this.u - this.v;
    y y1 = this.w;
    if (y1 != null) {
      parami.b(y1.d(), 8, m);
      a(new a.b(this.t, y1), parami.c());
    } else {
      parami.b(m);
    } 
    a(parami.c());
  }
  
  private static boolean c(int paramInt) {
    return (paramInt == 1836019574 || paramInt == 1953653099 || paramInt == 1835297121 || paramInt == 1835626086 || paramInt == 1937007212 || paramInt == 1836019558 || paramInt == 1953653094 || paramInt == 1836475768 || paramInt == 1701082227);
  }
  
  private static long d(y paramy) {
    paramy.d(8);
    return (a.a(paramy.q()) == 1) ? paramy.y() : paramy.o();
  }
  
  private void d(i parami) throws IOException {
    int n = this.g.size();
    int m = 0;
    long l1 = Long.MAX_VALUE;
    b b1 = null;
    while (m < n) {
      m m1 = ((b)this.g.valueAt(m)).b;
      b b2 = b1;
      long l2 = l1;
      if (m1.q) {
        b2 = b1;
        l2 = l1;
        if (m1.d < l1) {
          l2 = m1.d;
          b2 = (b)this.g.valueAt(m);
        } 
      } 
      m++;
      b1 = b2;
      l1 = l2;
    } 
    if (b1 == null) {
      this.s = 3;
      return;
    } 
    m = (int)(l1 - parami.c());
    if (m >= 0) {
      parami.b(m);
      b1.b.a(parami);
      return;
    } 
    throw ai.b("Offset to encryption data was negative.", null);
  }
  
  private boolean e(i parami) throws IOException {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public int a(i parami, u paramu) throws IOException {
    while (true) {
      int m = this.s;
      if (m != 0) {
        if (m != 1) {
          if (m != 2) {
            if (e(parami))
              return 0; 
            continue;
          } 
          d(parami);
          continue;
        } 
        c(parami);
        continue;
      } 
      if (!b(parami))
        return -1; 
    } 
  }
  
  @Nullable
  protected k a(@Nullable k paramk) {
    return paramk;
  }
  
  public void a(long paramLong1, long paramLong2) {
    int m = this.g.size();
    int i;
    for (i = 0; i < m; i++)
      ((b)this.g.valueAt(i)).a(); 
    this.q.clear();
    this.y = 0;
    this.z = paramLong2;
    this.p.clear();
    a();
  }
  
  public void a(j paramj) {
    this.H = paramj;
    a();
    b();
    k k1 = this.e;
    if (k1 != null) {
      b b1 = new b(paramj.a(0, k1.b), new n(this.e, new long[0], new int[0], 0, new long[0], new int[0], 0L), new c(0, 0, 0, 0));
      this.g.put(0, b1);
      this.H.a();
    } 
  }
  
  public boolean a(i parami) throws IOException {
    return j.a(parami);
  }
  
  public void c() {}
  
  private static final class a {
    public final long a;
    
    public final int b;
    
    public a(long param1Long, int param1Int) {
      this.a = param1Long;
      this.b = param1Int;
    }
  }
  
  private static final class b {
    public final x a;
    
    public final m b;
    
    public final y c;
    
    public n d;
    
    public c e;
    
    public int f;
    
    public int g;
    
    public int h;
    
    public int i;
    
    private final y j;
    
    private final y k;
    
    private boolean l;
    
    public b(x param1x, n param1n, c param1c) {
      this.a = param1x;
      this.d = param1n;
      this.e = param1c;
      this.b = new m();
      this.c = new y();
      this.j = new y(1);
      this.k = new y();
      a(param1n, param1c);
    }
    
    public int a(int param1Int1, int param1Int2) {
      int i;
      boolean bool;
      int j;
      l l = h();
      if (l == null)
        return 0; 
      if (l.d != 0) {
        y1 = this.b.p;
        i = l.d;
      } else {
        byte[] arrayOfByte1 = (byte[])ai.a(l.e);
        this.k.a(arrayOfByte1, arrayOfByte1.length);
        y1 = this.k;
        i = arrayOfByte1.length;
      } 
      boolean bool1 = this.b.c(this.f);
      if (bool1 || param1Int2 != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      byte[] arrayOfByte = this.j.d();
      if (bool) {
        j = 128;
      } else {
        j = 0;
      } 
      arrayOfByte[0] = (byte)(j | i);
      this.j.d(0);
      this.a.a(this.j, 1, 1);
      this.a.a(y1, i, 1);
      if (!bool)
        return i + 1; 
      if (!bool1) {
        this.c.a(8);
        byte[] arrayOfByte1 = this.c.d();
        arrayOfByte1[0] = 0;
        arrayOfByte1[1] = 1;
        arrayOfByte1[2] = (byte)(param1Int2 >> 8 & 0xFF);
        arrayOfByte1[3] = (byte)(param1Int2 & 0xFF);
        arrayOfByte1[4] = (byte)(param1Int1 >> 24 & 0xFF);
        arrayOfByte1[5] = (byte)(param1Int1 >> 16 & 0xFF);
        arrayOfByte1[6] = (byte)(param1Int1 >> 8 & 0xFF);
        arrayOfByte1[7] = (byte)(param1Int1 & 0xFF);
        this.a.a(this.c, 8, 1);
        return i + 1 + 8;
      } 
      y y2 = this.b.p;
      param1Int1 = y2.i();
      y2.e(-2);
      param1Int1 = param1Int1 * 6 + 2;
      y y1 = y2;
      if (param1Int2 != 0) {
        this.c.a(param1Int1);
        byte[] arrayOfByte1 = this.c.d();
        y2.a(arrayOfByte1, 0, param1Int1);
        param1Int2 = ((arrayOfByte1[2] & 0xFF) << 8 | arrayOfByte1[3] & 0xFF) + param1Int2;
        arrayOfByte1[2] = (byte)(param1Int2 >> 8 & 0xFF);
        arrayOfByte1[3] = (byte)(param1Int2 & 0xFF);
        y1 = this.c;
      } 
      this.a.a(y1, param1Int1, 1);
      return i + 1 + param1Int1;
    }
    
    public void a() {
      this.b.a();
      this.f = 0;
      this.h = 0;
      this.g = 0;
      this.i = 0;
      this.l = false;
    }
    
    public void a(long param1Long) {
      for (int i = this.f; i < this.b.f && this.b.b(i) < param1Long; i++) {
        if (this.b.l[i])
          this.i = i; 
      } 
    }
    
    public void a(com.applovin.exoplayer2.d.e param1e) {
      l l = this.d.a.a(((c)ai.a(this.b.a)).a);
      if (l != null) {
        String str = l.b;
      } else {
        l = null;
      } 
      param1e = param1e.a((String)l);
      v v = this.d.a.f.a().a(param1e).a();
      this.a.a(v);
    }
    
    public void a(n param1n, c param1c) {
      this.d = param1n;
      this.e = param1c;
      this.a.a(param1n.a.f);
      a();
    }
    
    public long b() {
      return !this.l ? this.d.f[this.f] : this.b.b(this.f);
    }
    
    public long c() {
      return !this.l ? this.d.c[this.f] : this.b.g[this.h];
    }
    
    public int d() {
      return !this.l ? this.d.d[this.f] : this.b.i[this.f];
    }
    
    public int e() {
      byte b1;
      if (!this.l) {
        b1 = this.d.g[this.f];
      } else if (this.b.l[this.f]) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      int i = b1;
      if (h() != null)
        i = b1 | 0x40000000; 
      return i;
    }
    
    public boolean f() {
      this.f++;
      if (!this.l)
        return false; 
      int i = ++this.g;
      int[] arrayOfInt = this.b.h;
      int j = this.h;
      if (i == arrayOfInt[j]) {
        this.h = j + 1;
        this.g = 0;
        return false;
      } 
      return true;
    }
    
    public void g() {
      l l = h();
      if (l == null)
        return; 
      y y1 = this.b.p;
      if (l.d != 0)
        y1.e(l.d); 
      if (this.b.c(this.f))
        y1.e(y1.i() * 6); 
    }
    
    @Nullable
    public l h() {
      l l;
      if (!this.l)
        return null; 
      int i = ((c)ai.a(this.b.a)).a;
      if (this.b.o != null) {
        l = this.b.o;
      } else {
        l = this.d.a.a(i);
      } 
      return (l != null && l.a) ? l : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\e\g\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */