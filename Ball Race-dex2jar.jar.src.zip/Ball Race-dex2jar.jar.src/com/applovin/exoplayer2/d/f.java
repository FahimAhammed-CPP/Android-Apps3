package com.applovin.exoplayer2.d;

import androidx.annotation.Nullable;
import com.applovin.exoplayer2.c.b;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

public interface f {
  void a(@Nullable g.a parama);
  
  boolean a(String paramString);
  
  void b(@Nullable g.a parama);
  
  int c();
  
  boolean d();
  
  @Nullable
  a e();
  
  UUID f();
  
  @Nullable
  b g();
  
  @Nullable
  Map<String, String> h();
  
  public static class a extends IOException {
    public final int a;
    
    public a(Throwable param1Throwable, int param1Int) {
      super(param1Throwable);
      this.a = param1Int;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\d\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */