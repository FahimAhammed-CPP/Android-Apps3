package com.applovin.exoplayer2.d;

import android.annotation.SuppressLint;
import android.media.DeniedByServerException;
import android.media.MediaCrypto;
import android.media.MediaCryptoException;
import android.media.MediaDrm;
import android.media.MediaDrmException;
import android.media.NotProvisionedException;
import android.media.UnsupportedSchemeException;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import com.applovin.exoplayer2.c.b;
import com.applovin.exoplayer2.common.base.Charsets;
import com.applovin.exoplayer2.e.g.h;
import com.applovin.exoplayer2.h;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.l.q;
import com.applovin.exoplayer2.l.y;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RequiresApi(18)
public final class o implements m {
  public static final m.c a = (m.c)-$.Lambda.o.XVYXmOdxA2_o_KZ-Z58SbICq1sI.INSTANCE;
  
  private final UUID b;
  
  private final MediaDrm c;
  
  private int d;
  
  private o(UUID paramUUID) throws UnsupportedSchemeException {
    com.applovin.exoplayer2.l.a.b(paramUUID);
    com.applovin.exoplayer2.l.a.a(h.b.equals(paramUUID) ^ true, "Use C.CLEARKEY_UUID instead");
    this.b = paramUUID;
    this.c = new MediaDrm(b(paramUUID));
    this.d = 1;
    if (h.d.equals(paramUUID) && e())
      a(this.c); 
  }
  
  private static e.a a(UUID paramUUID, List<e.a> paramList) {
    // Byte code:
    //   0: getstatic com/applovin/exoplayer2/h.d : Ljava/util/UUID;
    //   3: aload_0
    //   4: invokevirtual equals : (Ljava/lang/Object;)Z
    //   7: ifne -> 21
    //   10: aload_1
    //   11: iconst_0
    //   12: invokeinterface get : (I)Ljava/lang/Object;
    //   17: checkcast com/applovin/exoplayer2/d/e$a
    //   20: areturn
    //   21: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   24: bipush #28
    //   26: if_icmplt -> 226
    //   29: aload_1
    //   30: invokeinterface size : ()I
    //   35: iconst_1
    //   36: if_icmple -> 226
    //   39: aload_1
    //   40: iconst_0
    //   41: invokeinterface get : (I)Ljava/lang/Object;
    //   46: checkcast com/applovin/exoplayer2/d/e$a
    //   49: astore_0
    //   50: iconst_0
    //   51: istore_3
    //   52: iconst_0
    //   53: istore_2
    //   54: iload_3
    //   55: aload_1
    //   56: invokeinterface size : ()I
    //   61: if_icmpge -> 145
    //   64: aload_1
    //   65: iload_3
    //   66: invokeinterface get : (I)Ljava/lang/Object;
    //   71: checkcast com/applovin/exoplayer2/d/e$a
    //   74: astore #5
    //   76: aload #5
    //   78: getfield d : [B
    //   81: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   84: checkcast [B
    //   87: astore #6
    //   89: aload #5
    //   91: getfield c : Ljava/lang/String;
    //   94: aload_0
    //   95: getfield c : Ljava/lang/String;
    //   98: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   101: ifeq -> 140
    //   104: aload #5
    //   106: getfield b : Ljava/lang/String;
    //   109: aload_0
    //   110: getfield b : Ljava/lang/String;
    //   113: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   116: ifeq -> 140
    //   119: aload #6
    //   121: invokestatic a : ([B)Z
    //   124: ifeq -> 140
    //   127: iload_2
    //   128: aload #6
    //   130: arraylength
    //   131: iadd
    //   132: istore_2
    //   133: iload_3
    //   134: iconst_1
    //   135: iadd
    //   136: istore_3
    //   137: goto -> 54
    //   140: iconst_0
    //   141: istore_3
    //   142: goto -> 147
    //   145: iconst_1
    //   146: istore_3
    //   147: iload_3
    //   148: ifeq -> 226
    //   151: iload_2
    //   152: newarray byte
    //   154: astore #5
    //   156: iconst_0
    //   157: istore_2
    //   158: iconst_0
    //   159: istore_3
    //   160: iload_2
    //   161: aload_1
    //   162: invokeinterface size : ()I
    //   167: if_icmpge -> 219
    //   170: aload_1
    //   171: iload_2
    //   172: invokeinterface get : (I)Ljava/lang/Object;
    //   177: checkcast com/applovin/exoplayer2/d/e$a
    //   180: getfield d : [B
    //   183: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   186: checkcast [B
    //   189: astore #6
    //   191: aload #6
    //   193: arraylength
    //   194: istore #4
    //   196: aload #6
    //   198: iconst_0
    //   199: aload #5
    //   201: iload_3
    //   202: iload #4
    //   204: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   207: iload_3
    //   208: iload #4
    //   210: iadd
    //   211: istore_3
    //   212: iload_2
    //   213: iconst_1
    //   214: iadd
    //   215: istore_2
    //   216: goto -> 160
    //   219: aload_0
    //   220: aload #5
    //   222: invokevirtual a : ([B)Lcom/applovin/exoplayer2/d/e$a;
    //   225: areturn
    //   226: iconst_0
    //   227: istore_2
    //   228: iload_2
    //   229: aload_1
    //   230: invokeinterface size : ()I
    //   235: if_icmpge -> 299
    //   238: aload_1
    //   239: iload_2
    //   240: invokeinterface get : (I)Ljava/lang/Object;
    //   245: checkcast com/applovin/exoplayer2/d/e$a
    //   248: astore_0
    //   249: aload_0
    //   250: getfield d : [B
    //   253: invokestatic b : (Ljava/lang/Object;)Ljava/lang/Object;
    //   256: checkcast [B
    //   259: invokestatic c : ([B)I
    //   262: istore_3
    //   263: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   266: bipush #23
    //   268: if_icmpge -> 277
    //   271: iload_3
    //   272: ifne -> 277
    //   275: aload_0
    //   276: areturn
    //   277: getstatic com/applovin/exoplayer2/l/ai.a : I
    //   280: bipush #23
    //   282: if_icmplt -> 292
    //   285: iload_3
    //   286: iconst_1
    //   287: if_icmpne -> 292
    //   290: aload_0
    //   291: areturn
    //   292: iload_2
    //   293: iconst_1
    //   294: iadd
    //   295: istore_2
    //   296: goto -> 228
    //   299: aload_1
    //   300: iconst_0
    //   301: invokeinterface get : (I)Ljava/lang/Object;
    //   306: checkcast com/applovin/exoplayer2/d/e$a
    //   309: areturn
  }
  
  public static o a(UUID paramUUID) throws t {
    try {
      return new o(paramUUID);
    } catch (UnsupportedSchemeException unsupportedSchemeException) {
      throw new t(1, unsupportedSchemeException);
    } catch (Exception exception) {
      throw new t(2, exception);
    } 
  }
  
  private static String a(UUID paramUUID, String paramString) {
    return (ai.a < 26 && h.c.equals(paramUUID) && ("video/mp4".equals(paramString) || "audio/mp4".equals(paramString))) ? "cenc" : paramString;
  }
  
  @SuppressLint({"WrongConstant"})
  private static void a(MediaDrm paramMediaDrm) {
    paramMediaDrm.setPropertyString("securityLevel", "L3");
  }
  
  private static byte[] a(UUID paramUUID, byte[] paramArrayOfbyte) {
    byte[] arrayOfByte = paramArrayOfbyte;
    if (h.e.equals(paramUUID)) {
      arrayOfByte = h.a(paramArrayOfbyte, paramUUID);
      if (arrayOfByte != null)
        paramArrayOfbyte = arrayOfByte; 
      arrayOfByte = h.a(h.e, f(paramArrayOfbyte));
    } 
    if ((ai.a < 23 && h.d.equals(paramUUID)) || (h.e.equals(paramUUID) && "Amazon".equals(ai.c) && ("AFTB".equals(ai.d) || "AFTS".equals(ai.d) || "AFTM".equals(ai.d) || "AFTT".equals(ai.d)))) {
      byte[] arrayOfByte1 = h.a(arrayOfByte, paramUUID);
      if (arrayOfByte1 != null)
        return arrayOfByte1; 
    } 
    return arrayOfByte;
  }
  
  private static UUID b(UUID paramUUID) {
    UUID uUID = paramUUID;
    if (ai.a < 27) {
      uUID = paramUUID;
      if (h.c.equals(paramUUID))
        uUID = h.b; 
    } 
    return uUID;
  }
  
  private static byte[] b(UUID paramUUID, byte[] paramArrayOfbyte) {
    return h.c.equals(paramUUID) ? a.a(paramArrayOfbyte) : paramArrayOfbyte;
  }
  
  private static boolean e() {
    return "ASUS_Z00AD".equals(ai.d);
  }
  
  private static byte[] f(byte[] paramArrayOfbyte) {
    y y = new y(paramArrayOfbyte);
    int i = y.r();
    short s1 = y.l();
    short s2 = y.l();
    if (s1 != 1 || s2 != 1) {
      q.b("FrameworkMediaDrm", "Unexpected record count or type. Skipping LA_URL workaround.");
      return paramArrayOfbyte;
    } 
    String str2 = y.a(y.l(), Charsets.UTF_16LE);
    if (str2.contains("<LA_URL>"))
      return paramArrayOfbyte; 
    int j = str2.indexOf("</DATA>");
    if (j == -1)
      q.c("FrameworkMediaDrm", "Could not find the </DATA> tag. Skipping LA_URL workaround."); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str2.substring(0, j));
    stringBuilder.append("<LA_URL>https://x</LA_URL>");
    stringBuilder.append(str2.substring(j));
    String str1 = stringBuilder.toString();
    i += 52;
    ByteBuffer byteBuffer = ByteBuffer.allocate(i);
    byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
    byteBuffer.putInt(i);
    byteBuffer.putShort((short)s1);
    byteBuffer.putShort((short)s2);
    byteBuffer.putShort((short)(str1.length() * 2));
    byteBuffer.put(str1.getBytes(Charsets.UTF_16LE));
    return byteBuffer.array();
  }
  
  public m.a a(byte[] paramArrayOfbyte, @Nullable List<e.a> paramList, int paramInt, @Nullable HashMap<String, String> paramHashMap) throws NotProvisionedException {
    MediaDrm.KeyRequest keyRequest2;
    List list = null;
    if (paramList != null) {
      e.a a = a(this.b, paramList);
      keyRequest1 = (MediaDrm.KeyRequest)a(this.b, (byte[])com.applovin.exoplayer2.l.a.b(a.d));
      keyRequest2 = (MediaDrm.KeyRequest)a(this.b, a.c);
    } else {
      keyRequest1 = null;
      keyRequest2 = keyRequest1;
      paramList = list;
    } 
    MediaDrm.KeyRequest keyRequest1 = this.c.getKeyRequest(paramArrayOfbyte, (byte[])keyRequest1, (String)keyRequest2, paramInt, paramHashMap);
    byte[] arrayOfByte = b(this.b, keyRequest1.getData());
    String str2 = keyRequest1.getDefaultUrl();
    String str1 = str2;
    if ("https://x".equals(str2))
      str1 = ""; 
    str2 = str1;
    if (TextUtils.isEmpty(str1)) {
      str2 = str1;
      if (paramList != null) {
        str2 = str1;
        if (!TextUtils.isEmpty(((e.a)paramList).b))
          str2 = ((e.a)paramList).b; 
      } 
    } 
    if (ai.a >= 23) {
      paramInt = keyRequest1.getRequestType();
    } else {
      paramInt = Integer.MIN_VALUE;
    } 
    return new m.a(arrayOfByte, str2, paramInt);
  }
  
  public String a(String paramString) {
    return this.c.getPropertyString(paramString);
  }
  
  public void a(@Nullable m.b paramb) {
    -$$Lambda$o$jzFe5UhrubfdJv3koK23alb5bU4 -$$Lambda$o$jzFe5UhrubfdJv3koK23alb5bU4;
    MediaDrm mediaDrm = this.c;
    if (paramb == null) {
      paramb = null;
    } else {
      -$$Lambda$o$jzFe5UhrubfdJv3koK23alb5bU4 = new -$$Lambda$o$jzFe5UhrubfdJv3koK23alb5bU4(this, paramb);
    } 
    mediaDrm.setOnEventListener(-$$Lambda$o$jzFe5UhrubfdJv3koK23alb5bU4);
  }
  
  public void a(byte[] paramArrayOfbyte) {
    this.c.closeSession(paramArrayOfbyte);
  }
  
  public boolean a(byte[] paramArrayOfbyte, String paramString) {
    if (ai.a >= 31)
      return a.a(this.c, paramString); 
    try {
      MediaCrypto mediaCrypto = new MediaCrypto(this.b, paramArrayOfbyte);
      try {
        return mediaCrypto.requiresSecureDecoderComponent(paramString);
      } finally {
        mediaCrypto.release();
      } 
    } catch (MediaCryptoException mediaCryptoException) {
      return true;
    } 
  }
  
  public byte[] a() throws MediaDrmException {
    return this.c.openSession();
  }
  
  @Nullable
  public byte[] a(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws NotProvisionedException, DeniedByServerException {
    byte[] arrayOfByte = paramArrayOfbyte2;
    if (h.c.equals(this.b))
      arrayOfByte = a.b(paramArrayOfbyte2); 
    return this.c.provideKeyResponse(paramArrayOfbyte1, arrayOfByte);
  }
  
  public m.d b() {
    MediaDrm.ProvisionRequest provisionRequest = this.c.getProvisionRequest();
    return new m.d(provisionRequest.getData(), provisionRequest.getDefaultUrl());
  }
  
  public void b(byte[] paramArrayOfbyte) throws DeniedByServerException {
    this.c.provideProvisionResponse(paramArrayOfbyte);
  }
  
  public void b(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    this.c.restoreKeys(paramArrayOfbyte1, paramArrayOfbyte2);
  }
  
  public Map<String, String> c(byte[] paramArrayOfbyte) {
    return this.c.queryKeyStatus(paramArrayOfbyte);
  }
  
  public void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : I
    //   6: iconst_1
    //   7: isub
    //   8: istore_1
    //   9: aload_0
    //   10: iload_1
    //   11: putfield d : I
    //   14: iload_1
    //   15: ifne -> 25
    //   18: aload_0
    //   19: getfield c : Landroid/media/MediaDrm;
    //   22: invokevirtual release : ()V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: astore_2
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_2
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	28	finally
    //   18	25	28	finally
  }
  
  public int d() {
    return 2;
  }
  
  public n e(byte[] paramArrayOfbyte) throws MediaCryptoException {
    boolean bool;
    if (ai.a < 21 && h.d.equals(this.b) && "L3".equals(a("securityLevel"))) {
      bool = true;
    } else {
      bool = false;
    } 
    return new n(b(this.b), paramArrayOfbyte, bool);
  }
  
  @RequiresApi(31)
  private static class a {
    public static boolean a(MediaDrm param1MediaDrm, String param1String) {
      return param1MediaDrm.requiresSecureDecoder(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\d\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */