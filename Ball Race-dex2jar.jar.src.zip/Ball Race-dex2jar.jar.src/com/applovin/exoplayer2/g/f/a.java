package com.applovin.exoplayer2.g.f;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.ac;
import com.applovin.exoplayer2.g.a;
import com.applovin.exoplayer2.l.ai;
import com.applovin.exoplayer2.v;
import java.util.Arrays;

public final class a implements a.a {
  public static final Parcelable.Creator<a> CREATOR = new Parcelable.Creator<a>() {
      public a a(Parcel param1Parcel) {
        return new a(param1Parcel);
      }
      
      public a[] a(int param1Int) {
        return new a[param1Int];
      }
    };
  
  public final String a;
  
  public final byte[] b;
  
  public final int c;
  
  public final int d;
  
  private a(Parcel paramParcel) {
    this.a = (String)ai.a(paramParcel.readString());
    this.b = (byte[])ai.a(paramParcel.createByteArray());
    this.c = paramParcel.readInt();
    this.d = paramParcel.readInt();
  }
  
  public a(String paramString, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    this.a = paramString;
    this.b = paramArrayOfbyte;
    this.c = paramInt1;
    this.d = paramInt2;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.a.equals(((a)paramObject).a) && Arrays.equals(this.b, ((a)paramObject).b) && this.c == ((a)paramObject).c && this.d == ((a)paramObject).d);
    } 
    return false;
  }
  
  public int hashCode() {
    return (((527 + this.a.hashCode()) * 31 + Arrays.hashCode(this.b)) * 31 + this.c) * 31 + this.d;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("mdta: key=");
    stringBuilder.append(this.a);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.a);
    paramParcel.writeByteArray(this.b);
    paramParcel.writeInt(this.c);
    paramParcel.writeInt(this.d);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\g\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */