package com.applovin.exoplayer2.g.g;

import android.os.Parcel;
import android.os.Parcelable;
import com.applovin.exoplayer2.l.y;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class f extends b {
  public static final Parcelable.Creator<f> CREATOR = new Parcelable.Creator<f>() {
      public f a(Parcel param1Parcel) {
        return new f(param1Parcel);
      }
      
      public f[] a(int param1Int) {
        return new f[param1Int];
      }
    };
  
  public final List<b> a;
  
  private f(Parcel paramParcel) {
    int j = paramParcel.readInt();
    ArrayList<b> arrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
      arrayList.add(b.a(paramParcel)); 
    this.a = Collections.unmodifiableList(arrayList);
  }
  
  private f(List<b> paramList) {
    this.a = Collections.unmodifiableList(paramList);
  }
  
  static f a(y paramy) {
    int j = paramy.h();
    ArrayList<b> arrayList = new ArrayList(j);
    for (int i = 0; i < j; i++)
      arrayList.add(b.a(paramy)); 
    return new f(arrayList);
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = this.a.size();
    paramParcel.writeInt(i);
    for (paramInt = 0; paramInt < i; paramInt++)
      b.a(this.a.get(paramInt), paramParcel); 
  }
  
  public static final class a {
    public final int a;
    
    public final long b;
    
    private a(int param1Int, long param1Long) {
      this.a = param1Int;
      this.b = param1Long;
    }
    
    private static a b(Parcel param1Parcel) {
      return new a(param1Parcel.readInt(), param1Parcel.readLong());
    }
    
    private void c(Parcel param1Parcel) {
      param1Parcel.writeInt(this.a);
      param1Parcel.writeLong(this.b);
    }
  }
  
  public static final class b {
    public final long a;
    
    public final boolean b;
    
    public final boolean c;
    
    public final boolean d;
    
    public final long e;
    
    public final List<f.a> f;
    
    public final boolean g;
    
    public final long h;
    
    public final int i;
    
    public final int j;
    
    public final int k;
    
    private b(long param1Long1, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, List<f.a> param1List, long param1Long2, boolean param1Boolean4, long param1Long3, int param1Int1, int param1Int2, int param1Int3) {
      this.a = param1Long1;
      this.b = param1Boolean1;
      this.c = param1Boolean2;
      this.d = param1Boolean3;
      this.f = Collections.unmodifiableList(param1List);
      this.e = param1Long2;
      this.g = param1Boolean4;
      this.h = param1Long3;
      this.i = param1Int1;
      this.j = param1Int2;
      this.k = param1Int3;
    }
    
    private b(Parcel param1Parcel) {
      this.a = param1Parcel.readLong();
      byte b1 = param1Parcel.readByte();
      boolean bool2 = false;
      if (b1 == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.b = bool1;
      if (param1Parcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.c = bool1;
      if (param1Parcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.d = bool1;
      int i = param1Parcel.readInt();
      ArrayList<f.a> arrayList = new ArrayList(i);
      b1 = 0;
      while (b1 < i) {
        arrayList.add(f.a.a(param1Parcel));
        int j = b1 + 1;
      } 
      this.f = Collections.unmodifiableList(arrayList);
      this.e = param1Parcel.readLong();
      boolean bool1 = bool2;
      if (param1Parcel.readByte() == 1)
        bool1 = true; 
      this.g = bool1;
      this.h = param1Parcel.readLong();
      this.i = param1Parcel.readInt();
      this.j = param1Parcel.readInt();
      this.k = param1Parcel.readInt();
    }
    
    private static b b(y param1y) {
      boolean bool1;
      boolean bool2;
      boolean bool3;
      long l1;
      long l2;
      boolean bool4;
      boolean bool5;
      boolean bool6;
      boolean bool7;
      long l3 = param1y.o();
      if ((param1y.h() & 0x80) != 0) {
        bool7 = true;
      } else {
        bool7 = false;
      } 
      ArrayList<f.a> arrayList = new ArrayList();
      if (!bool7) {
        bool1 = param1y.h();
        if ((bool1 & 0x80) != 0) {
          bool4 = true;
        } else {
          bool4 = false;
        } 
        if ((bool1 & 0x40) != 0) {
          bool5 = true;
        } else {
          bool5 = false;
        } 
        if ((bool1 & 0x20) != 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (bool5) {
          l1 = param1y.o();
        } else {
          l1 = -9223372036854775807L;
        } 
        if (!bool5) {
          int j = param1y.h();
          arrayList = new ArrayList(j);
          for (int i = 0; i < j; i++)
            arrayList.add(new f.a(param1y.h(), param1y.o())); 
        } 
        if (bool1 != 0) {
          l2 = param1y.h();
          if ((0x80L & l2) != 0L) {
            bool6 = true;
          } else {
            bool6 = false;
          } 
          l2 = ((l2 & 0x1L) << 32L | param1y.o()) * 1000L / 90L;
        } else {
          bool6 = false;
          l2 = -9223372036854775807L;
        } 
        bool1 = param1y.i();
        bool2 = param1y.h();
        bool3 = param1y.h();
      } else {
        bool4 = false;
        l1 = -9223372036854775807L;
        bool6 = false;
        l2 = -9223372036854775807L;
        bool1 = false;
        bool2 = false;
        bool3 = false;
        bool5 = false;
      } 
      return new b(l3, bool7, bool4, bool5, arrayList, l1, bool6, l2, bool1, bool2, bool3);
    }
    
    private void b(Parcel param1Parcel) {
      param1Parcel.writeLong(this.a);
      param1Parcel.writeByte((byte)this.b);
      param1Parcel.writeByte((byte)this.c);
      param1Parcel.writeByte((byte)this.d);
      int j = this.f.size();
      param1Parcel.writeInt(j);
      for (int i = 0; i < j; i++)
        f.a.a(this.f.get(i), param1Parcel); 
      param1Parcel.writeLong(this.e);
      param1Parcel.writeByte((byte)this.g);
      param1Parcel.writeLong(this.h);
      param1Parcel.writeInt(this.i);
      param1Parcel.writeInt(this.j);
      param1Parcel.writeInt(this.k);
    }
    
    private static b c(Parcel param1Parcel) {
      return new b(param1Parcel);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\g\g\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */