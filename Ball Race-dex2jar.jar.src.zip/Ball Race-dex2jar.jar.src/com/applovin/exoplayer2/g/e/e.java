package com.applovin.exoplayer2.g.e;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.Nullable;
import com.applovin.exoplayer2.l.ai;

public final class e extends h {
  public static final Parcelable.Creator<e> CREATOR = new Parcelable.Creator<e>() {
      public e a(Parcel param1Parcel) {
        return new e(param1Parcel);
      }
      
      public e[] a(int param1Int) {
        return new e[param1Int];
      }
    };
  
  public final String a;
  
  public final String b;
  
  public final String c;
  
  e(Parcel paramParcel) {
    super("COMM");
    this.a = (String)ai.a(paramParcel.readString());
    this.b = (String)ai.a(paramParcel.readString());
    this.c = (String)ai.a(paramParcel.readString());
  }
  
  public e(String paramString1, String paramString2, String paramString3) {
    super("COMM");
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
  }
  
  public boolean equals(@Nullable Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (ai.a(this.b, ((e)paramObject).b) && ai.a(this.a, ((e)paramObject).a) && ai.a(this.c, ((e)paramObject).c));
    } 
    return false;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    String str = this.a;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    str = this.b;
    if (str != null) {
      b2 = str.hashCode();
    } else {
      b2 = 0;
    } 
    str = this.c;
    if (str != null)
      i = str.hashCode(); 
    return ((527 + b1) * 31 + b2) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.f);
    stringBuilder.append(": language=");
    stringBuilder.append(this.a);
    stringBuilder.append(", description=");
    stringBuilder.append(this.b);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.f);
    paramParcel.writeString(this.a);
    paramParcel.writeString(this.c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\g\e\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */