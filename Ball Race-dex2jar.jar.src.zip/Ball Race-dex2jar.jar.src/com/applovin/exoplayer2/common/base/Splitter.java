package com.applovin.exoplayer2.common.base;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class Splitter {
  private final int limit;
  
  private final boolean omitEmptyStrings;
  
  private final b strategy;
  
  private final CharMatcher trimmer;
  
  private Splitter(b paramb) {
    this(paramb, false, CharMatcher.none(), 2147483647);
  }
  
  private Splitter(b paramb, boolean paramBoolean, CharMatcher paramCharMatcher, int paramInt) {
    this.strategy = paramb;
    this.omitEmptyStrings = paramBoolean;
    this.trimmer = paramCharMatcher;
    this.limit = paramInt;
  }
  
  public static Splitter fixedLength(int paramInt) {
    boolean bool;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkArgument(bool, "The length may not be less than 1");
    return new Splitter(new b(paramInt) {
          public Splitter.a a(Splitter param1Splitter, CharSequence param1CharSequence) {
            return new Splitter.a(this, param1Splitter, param1CharSequence) {
                public int a(int param2Int) {
                  param2Int += this.a.a;
                  return (param2Int < this.b.length()) ? param2Int : -1;
                }
                
                public int b(int param2Int) {
                  return param2Int;
                }
              };
          }
        });
  }
  
  public static Splitter on(char paramChar) {
    return on(CharMatcher.is(paramChar));
  }
  
  public static Splitter on(CharMatcher paramCharMatcher) {
    Preconditions.checkNotNull(paramCharMatcher);
    return new Splitter(new b(paramCharMatcher) {
          public Splitter.a a(Splitter param1Splitter, CharSequence param1CharSequence) {
            return new Splitter.a(this, param1Splitter, param1CharSequence) {
                int a(int param2Int) {
                  return this.a.a.indexIn(this.b, param2Int);
                }
                
                int b(int param2Int) {
                  return param2Int + 1;
                }
              };
          }
        });
  }
  
  public static Splitter on(String paramString) {
    boolean bool;
    if (paramString.length() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkArgument(bool, "The separator may not be the empty string.");
    return (paramString.length() == 1) ? on(paramString.charAt(0)) : new Splitter(new b(paramString) {
          public Splitter.a a(Splitter param1Splitter, CharSequence param1CharSequence) {
            return new Splitter.a(this, param1Splitter, param1CharSequence) {
                public int a(int param2Int) {
                  int i = this.a.a.length();
                  int j = this.b.length();
                  label14: while (param2Int <= j - i) {
                    for (int k = 0; k < i; k++) {
                      if (this.b.charAt(k + param2Int) != this.a.a.charAt(k)) {
                        param2Int++;
                        continue label14;
                      } 
                    } 
                    return param2Int;
                  } 
                  return -1;
                }
                
                public int b(int param2Int) {
                  return param2Int + this.a.a.length();
                }
              };
          }
        });
  }
  
  private Iterator<String> splittingIterator(CharSequence paramCharSequence) {
    return this.strategy.b(this, paramCharSequence);
  }
  
  public Splitter limit(int paramInt) {
    boolean bool;
    if (paramInt > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkArgument(bool, "must be greater than zero: %s", paramInt);
    return new Splitter(this.strategy, this.omitEmptyStrings, this.trimmer, paramInt);
  }
  
  public Splitter omitEmptyStrings() {
    return new Splitter(this.strategy, true, this.trimmer, this.limit);
  }
  
  public List<String> splitToList(CharSequence paramCharSequence) {
    Preconditions.checkNotNull(paramCharSequence);
    Iterator<String> iterator = splittingIterator(paramCharSequence);
    ArrayList<String> arrayList = new ArrayList();
    while (iterator.hasNext())
      arrayList.add(iterator.next()); 
    return Collections.unmodifiableList(arrayList);
  }
  
  public Splitter trimResults() {
    return trimResults(CharMatcher.whitespace());
  }
  
  public Splitter trimResults(CharMatcher paramCharMatcher) {
    Preconditions.checkNotNull(paramCharMatcher);
    return new Splitter(this.strategy, this.omitEmptyStrings, paramCharMatcher, this.limit);
  }
  
  private static abstract class a extends b<String> {
    final CharSequence b;
    
    final CharMatcher c;
    
    final boolean d;
    
    int e = 0;
    
    int f;
    
    protected a(Splitter param1Splitter, CharSequence param1CharSequence) {
      this.c = param1Splitter.trimmer;
      this.d = param1Splitter.omitEmptyStrings;
      this.f = param1Splitter.limit;
      this.b = param1CharSequence;
    }
    
    abstract int a(int param1Int);
    
    abstract int b(int param1Int);
    
    protected String c() {
      int i = this.e;
      while (true) {
        int j = this.e;
        if (j != -1) {
          j = a(j);
          if (j == -1) {
            j = this.b.length();
            this.e = -1;
          } else {
            this.e = b(j);
          } 
          int m = this.e;
          int k = i;
          if (m == i) {
            this.e = m + 1;
            if (this.e > this.b.length())
              this.e = -1; 
            continue;
          } 
          while (true) {
            i = j;
            if (k < j) {
              i = j;
              if (this.c.matches(this.b.charAt(k))) {
                k++;
                continue;
              } 
            } 
            break;
          } 
          while (i > k && this.c.matches(this.b.charAt(i - 1)))
            i--; 
          if (this.d) {
            if (k == i) {
              i = this.e;
              continue;
            } 
            j = this.f;
            if (j == 1) {
              i = this.b.length();
              this.e = -1;
              while (true) {
                j = i;
                if (i > k) {
                  j = i;
                  if (this.c.matches(this.b.charAt(i - 1))) {
                    i--;
                    continue;
                  } 
                } 
                break;
              } 
            } else {
              this.f = j - 1;
              j = i;
            } 
            return this.b.subSequence(k, j).toString();
          } 
          continue;
        } 
        return b();
      } 
    }
  }
  
  private static interface b {
    Iterator<String> b(Splitter param1Splitter, CharSequence param1CharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\base\Splitter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */