package com.applovin.exoplayer2.common.base;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

abstract class b<T> implements Iterator<T> {
  private a a = a.b;
  
  @NullableDecl
  private T b;
  
  private boolean c() {
    this.a = a.d;
    this.b = a();
    if (this.a != a.c) {
      this.a = a.a;
      return true;
    } 
    return false;
  }
  
  protected abstract T a();
  
  @NullableDecl
  @CanIgnoreReturnValue
  protected final T b() {
    this.a = a.c;
    return null;
  }
  
  public final boolean hasNext() {
    boolean bool;
    if (this.a != a.d) {
      bool = true;
    } else {
      bool = false;
    } 
    Preconditions.checkState(bool);
    int i = null.a[this.a.ordinal()];
    return (i != 1) ? ((i != 2) ? c() : false) : true;
  }
  
  public final T next() {
    if (hasNext()) {
      this.a = a.b;
      T t = this.b;
      this.b = null;
      return t;
    } 
    throw new NoSuchElementException();
  }
  
  public final void remove() {
    throw new UnsupportedOperationException();
  }
  
  private enum a {
    a, b, c, d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\base\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */