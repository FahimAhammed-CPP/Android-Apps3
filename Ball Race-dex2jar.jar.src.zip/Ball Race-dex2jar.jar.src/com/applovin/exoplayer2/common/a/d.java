package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.io.Serializable;
import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.RandomAccess;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

abstract class d<K, V> extends f<K, V> implements Serializable {
  private transient Map<K, Collection<V>> a;
  
  private transient int b;
  
  protected d(Map<K, Collection<V>> paramMap) {
    Preconditions.checkArgument(paramMap.isEmpty());
    this.a = paramMap;
  }
  
  private static <E> Iterator<E> c(Collection<E> paramCollection) {
    return (paramCollection instanceof List) ? ((List<E>)paramCollection).listIterator() : paramCollection.iterator();
  }
  
  private void e(Object paramObject) {
    paramObject = ab.<Collection>c((Map)this.a, paramObject);
    if (paramObject != null) {
      int i = paramObject.size();
      paramObject.clear();
      this.b -= i;
    } 
  }
  
  Collection<V> a(@NullableDecl K paramK, Collection<V> paramCollection) {
    return new i(this, paramK, paramCollection, null);
  }
  
  <E> Collection<E> a(Collection<E> paramCollection) {
    return Collections.unmodifiableCollection(paramCollection);
  }
  
  final List<V> a(@NullableDecl K paramK, List<V> paramList, @NullableDecl i parami) {
    return (paramList instanceof RandomAccess) ? new f(this, paramK, paramList, parami) : new j(this, paramK, paramList, parami);
  }
  
  public boolean a(@NullableDecl K paramK, @NullableDecl V paramV) {
    Collection<V> collection = this.a.get(paramK);
    if (collection == null) {
      collection = c(paramK);
      if (collection.add(paramV)) {
        this.b++;
        this.a.put(paramK, collection);
        return true;
      } 
      throw new AssertionError("New Collection violated the Collection spec");
    } 
    if (collection.add(paramV)) {
      this.b++;
      return true;
    } 
    return false;
  }
  
  public Collection<V> b(@NullableDecl K paramK) {
    Collection<V> collection2 = this.a.get(paramK);
    Collection<V> collection1 = collection2;
    if (collection2 == null)
      collection1 = c(paramK); 
    return a(paramK, collection1);
  }
  
  abstract Collection<V> c();
  
  Collection<V> c(@NullableDecl K paramK) {
    return c();
  }
  
  public int d() {
    return this.b;
  }
  
  public void e() {
    Iterator<Collection> iterator = this.a.values().iterator();
    while (iterator.hasNext())
      ((Collection)iterator.next()).clear(); 
    this.a.clear();
    this.b = 0;
  }
  
  Set<K> f() {
    return new c(this, this.a);
  }
  
  final Set<K> g() {
    Map<K, Collection<V>> map = this.a;
    return (map instanceof NavigableMap) ? new e(this, (NavigableMap<K, Collection<V>>)map) : ((map instanceof SortedMap) ? new h(this, (SortedMap<K, Collection<V>>)map) : new c(this, map));
  }
  
  public Collection<V> h() {
    return super.h();
  }
  
  Collection<V> i() {
    return new f.c(this);
  }
  
  Iterator<V> j() {
    return new b<V>(this) {
        V a(K param1K, V param1V) {
          return param1V;
        }
      };
  }
  
  public Collection<Map.Entry<K, V>> k() {
    return super.k();
  }
  
  Collection<Map.Entry<K, V>> l() {
    return (Collection<Map.Entry<K, V>>)((this instanceof ap) ? new f.b(this) : new f.a(this));
  }
  
  Iterator<Map.Entry<K, V>> m() {
    return new b<Map.Entry<K, V>>(this) {
        Map.Entry<K, V> b(K param1K, V param1V) {
          return ab.a(param1K, param1V);
        }
      };
  }
  
  Map<K, Collection<V>> n() {
    return new a(this, this.a);
  }
  
  final Map<K, Collection<V>> o() {
    Map<K, Collection<V>> map = this.a;
    return (map instanceof NavigableMap) ? new d(this, (NavigableMap<K, Collection<V>>)map) : ((map instanceof SortedMap) ? new g(this, (SortedMap<K, Collection<V>>)map) : new a(this, map));
  }
  
  private class a extends ab.e<K, Collection<V>> {
    final transient Map<K, Collection<V>> a;
    
    a(d this$0, Map<K, Collection<V>> param1Map) {
      this.a = param1Map;
    }
    
    public Collection<V> a(Object param1Object) {
      Collection<V> collection = ab.<Collection>a((Map)this.a, param1Object);
      return (collection == null) ? null : this.b.a(param1Object, collection);
    }
    
    Map.Entry<K, Collection<V>> a(Map.Entry<K, Collection<V>> param1Entry) {
      K k = param1Entry.getKey();
      return ab.a(k, this.b.a(k, param1Entry.getValue()));
    }
    
    protected Set<Map.Entry<K, Collection<V>>> a() {
      return new a(this);
    }
    
    public Collection<V> b(Object param1Object) {
      param1Object = this.a.remove(param1Object);
      if (param1Object == null)
        return null; 
      Collection<V> collection = this.b.c();
      collection.addAll((Collection)param1Object);
      d.b(this.b, param1Object.size());
      param1Object.clear();
      return collection;
    }
    
    public void clear() {
      if (this.a == d.a(this.b)) {
        this.b.e();
        return;
      } 
      y.d(new b(this));
    }
    
    public boolean containsKey(Object param1Object) {
      return ab.b(this.a, param1Object);
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      return (this == param1Object || this.a.equals(param1Object));
    }
    
    public int hashCode() {
      return this.a.hashCode();
    }
    
    public Set<K> keySet() {
      return this.b.p();
    }
    
    public int size() {
      return this.a.size();
    }
    
    public String toString() {
      return this.a.toString();
    }
    
    class a extends ab.b<K, Collection<V>> {
      a(d.a this$0) {}
      
      Map<K, Collection<V>> a() {
        return this.a;
      }
      
      public boolean contains(Object param2Object) {
        return k.a(this.a.a.entrySet(), param2Object);
      }
      
      public Iterator<Map.Entry<K, Collection<V>>> iterator() {
        return new d.a.b(this.a);
      }
      
      public boolean remove(Object param2Object) {
        if (!contains(param2Object))
          return false; 
        param2Object = param2Object;
        d.a(this.a.b, param2Object.getKey());
        return true;
      }
    }
    
    class b implements Iterator<Map.Entry<K, Collection<V>>> {
      final Iterator<Map.Entry<K, Collection<V>>> a = this.c.a.entrySet().iterator();
      
      @NullableDecl
      Collection<V> b;
      
      b(d.a this$0) {}
      
      public Map.Entry<K, Collection<V>> a() {
        Map.Entry<K, Collection<V>> entry = this.a.next();
        this.b = (Collection<V>)entry.getValue();
        return this.c.a(entry);
      }
      
      public boolean hasNext() {
        return this.a.hasNext();
      }
      
      public void remove() {
        boolean bool;
        if (this.b != null) {
          bool = true;
        } else {
          bool = false;
        } 
        j.a(bool);
        this.a.remove();
        d.b(this.c.b, this.b.size());
        this.b.clear();
        this.b = null;
      }
    }
  }
  
  class a extends ab.b<K, Collection<V>> {
    a(d this$0) {}
    
    Map<K, Collection<V>> a() {
      return this.a;
    }
    
    public boolean contains(Object param1Object) {
      return k.a(this.a.a.entrySet(), param1Object);
    }
    
    public Iterator<Map.Entry<K, Collection<V>>> iterator() {
      return new d.a.b(this.a);
    }
    
    public boolean remove(Object param1Object) {
      if (!contains(param1Object))
        return false; 
      param1Object = param1Object;
      d.a(this.a.b, param1Object.getKey());
      return true;
    }
  }
  
  class b implements Iterator<Map.Entry<K, Collection<V>>> {
    final Iterator<Map.Entry<K, Collection<V>>> a = this.c.a.entrySet().iterator();
    
    @NullableDecl
    Collection<V> b;
    
    b(d this$0) {}
    
    public Map.Entry<K, Collection<V>> a() {
      Map.Entry<K, Collection<V>> entry = this.a.next();
      this.b = (Collection<V>)entry.getValue();
      return this.c.a(entry);
    }
    
    public boolean hasNext() {
      return this.a.hasNext();
    }
    
    public void remove() {
      boolean bool;
      if (this.b != null) {
        bool = true;
      } else {
        bool = false;
      } 
      j.a(bool);
      this.a.remove();
      d.b(this.c.b, this.b.size());
      this.b.clear();
      this.b = null;
    }
  }
  
  private abstract class b<T> implements Iterator<T> {
    final Iterator<Map.Entry<K, Collection<V>>> b;
    
    @NullableDecl
    K c;
    
    @MonotonicNonNullDecl
    Collection<V> d;
    
    Iterator<V> e;
    
    b(d this$0) {
      this.b = d.a(this$0).entrySet().iterator();
      this.c = null;
      this.d = null;
      this.e = y.c();
    }
    
    abstract T a(K param1K, V param1V);
    
    public boolean hasNext() {
      return (this.b.hasNext() || this.e.hasNext());
    }
    
    public T next() {
      if (!this.e.hasNext()) {
        Map.Entry entry = this.b.next();
        this.c = (K)entry.getKey();
        this.d = (Collection<V>)entry.getValue();
        this.e = this.d.iterator();
      } 
      return a(this.c, this.e.next());
    }
    
    public void remove() {
      this.e.remove();
      if (this.d.isEmpty())
        this.b.remove(); 
      d.b(this.f);
    }
  }
  
  private class c extends ab.c<K, Collection<V>> {
    c(d this$0, Map<K, Collection<V>> param1Map) {
      super(param1Map);
    }
    
    public void clear() {
      y.d(iterator());
    }
    
    public boolean containsAll(Collection<?> param1Collection) {
      return c().keySet().containsAll(param1Collection);
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      return (this == param1Object || c().keySet().equals(param1Object));
    }
    
    public int hashCode() {
      return c().keySet().hashCode();
    }
    
    public Iterator<K> iterator() {
      return new Iterator<K>(this, c().entrySet().iterator()) {
          @NullableDecl
          Map.Entry<K, Collection<V>> a;
          
          public boolean hasNext() {
            return this.b.hasNext();
          }
          
          public K next() {
            this.a = this.b.next();
            return this.a.getKey();
          }
          
          public void remove() {
            boolean bool;
            if (this.a != null) {
              bool = true;
            } else {
              bool = false;
            } 
            j.a(bool);
            Collection collection = this.a.getValue();
            this.b.remove();
            d.b(this.c.a, collection.size());
            collection.clear();
            this.a = null;
          }
        };
    }
    
    public boolean remove(Object param1Object) {
      boolean bool1;
      param1Object = c().remove(param1Object);
      boolean bool2 = false;
      if (param1Object != null) {
        bool1 = param1Object.size();
        param1Object.clear();
        d.b(this.a, bool1);
      } else {
        bool1 = false;
      } 
      if (bool1)
        bool2 = true; 
      return bool2;
    }
  }
  
  class null implements Iterator<K> {
    @NullableDecl
    Map.Entry<K, Collection<V>> a;
    
    null(d this$0, Iterator param1Iterator) {}
    
    public boolean hasNext() {
      return this.b.hasNext();
    }
    
    public K next() {
      this.a = this.b.next();
      return this.a.getKey();
    }
    
    public void remove() {
      boolean bool;
      if (this.a != null) {
        bool = true;
      } else {
        bool = false;
      } 
      j.a(bool);
      Collection collection = this.a.getValue();
      this.b.remove();
      d.b(this.c.a, collection.size());
      collection.clear();
      this.a = null;
    }
  }
  
  class d extends g implements NavigableMap<K, Collection<V>> {
    d(d this$0, NavigableMap<K, Collection<V>> param1NavigableMap) {
      super(this$0, param1NavigableMap);
    }
    
    Map.Entry<K, Collection<V>> a(Iterator<Map.Entry<K, Collection<V>>> param1Iterator) {
      if (!param1Iterator.hasNext())
        return null; 
      Map.Entry entry = param1Iterator.next();
      Collection collection = this.c.c();
      collection.addAll((Collection)entry.getValue());
      param1Iterator.remove();
      return ab.a((K)entry.getKey(), this.c.a(collection));
    }
    
    public NavigableMap<K, Collection<V>> a(K param1K1, K param1K2) {
      return subMap(param1K1, true, param1K2, false);
    }
    
    NavigableMap<K, Collection<V>> b() {
      return (NavigableMap<K, Collection<V>>)super.g();
    }
    
    public NavigableMap<K, Collection<V>> c(K param1K) {
      return headMap(param1K, false);
    }
    
    public NavigableSet<K> c() {
      return (NavigableSet<K>)super.f();
    }
    
    public Map.Entry<K, Collection<V>> ceilingEntry(K param1K) {
      Map.Entry<K, Collection<V>> entry = b().ceilingEntry(param1K);
      return (entry == null) ? null : a(entry);
    }
    
    public K ceilingKey(K param1K) {
      return b().ceilingKey(param1K);
    }
    
    public NavigableMap<K, Collection<V>> d(K param1K) {
      return tailMap(param1K, true);
    }
    
    NavigableSet<K> d() {
      return new d.e(this.c, b());
    }
    
    public NavigableSet<K> descendingKeySet() {
      return descendingMap().navigableKeySet();
    }
    
    public NavigableMap<K, Collection<V>> descendingMap() {
      return new d(this.c, b().descendingMap());
    }
    
    public Map.Entry<K, Collection<V>> firstEntry() {
      Map.Entry<K, Collection<V>> entry = b().firstEntry();
      return (entry == null) ? null : a(entry);
    }
    
    public Map.Entry<K, Collection<V>> floorEntry(K param1K) {
      Map.Entry<K, Collection<V>> entry = b().floorEntry(param1K);
      return (entry == null) ? null : a(entry);
    }
    
    public K floorKey(K param1K) {
      return b().floorKey(param1K);
    }
    
    public NavigableMap<K, Collection<V>> headMap(K param1K, boolean param1Boolean) {
      return new d(this.c, b().headMap(param1K, param1Boolean));
    }
    
    public Map.Entry<K, Collection<V>> higherEntry(K param1K) {
      Map.Entry<K, Collection<V>> entry = b().higherEntry(param1K);
      return (entry == null) ? null : a(entry);
    }
    
    public K higherKey(K param1K) {
      return b().higherKey(param1K);
    }
    
    public Map.Entry<K, Collection<V>> lastEntry() {
      Map.Entry<K, Collection<V>> entry = b().lastEntry();
      return (entry == null) ? null : a(entry);
    }
    
    public Map.Entry<K, Collection<V>> lowerEntry(K param1K) {
      Map.Entry<K, Collection<V>> entry = b().lowerEntry(param1K);
      return (entry == null) ? null : a(entry);
    }
    
    public K lowerKey(K param1K) {
      return b().lowerKey(param1K);
    }
    
    public NavigableSet<K> navigableKeySet() {
      return c();
    }
    
    public Map.Entry<K, Collection<V>> pollFirstEntry() {
      return a(entrySet().iterator());
    }
    
    public Map.Entry<K, Collection<V>> pollLastEntry() {
      return a(descendingMap().entrySet().iterator());
    }
    
    public NavigableMap<K, Collection<V>> subMap(K param1K1, boolean param1Boolean1, K param1K2, boolean param1Boolean2) {
      return new d(this.c, b().subMap(param1K1, param1Boolean1, param1K2, param1Boolean2));
    }
    
    public NavigableMap<K, Collection<V>> tailMap(K param1K, boolean param1Boolean) {
      return new d(this.c, b().tailMap(param1K, param1Boolean));
    }
  }
  
  class e extends h implements NavigableSet<K> {
    e(d this$0, NavigableMap<K, Collection<V>> param1NavigableMap) {
      super(this$0, param1NavigableMap);
    }
    
    NavigableMap<K, Collection<V>> a() {
      return (NavigableMap<K, Collection<V>>)super.b();
    }
    
    public NavigableSet<K> a(K param1K) {
      return headSet(param1K, false);
    }
    
    public NavigableSet<K> a(K param1K1, K param1K2) {
      return subSet(param1K1, true, param1K2, false);
    }
    
    public NavigableSet<K> b(K param1K) {
      return tailSet(param1K, true);
    }
    
    public K ceiling(K param1K) {
      return a().ceilingKey(param1K);
    }
    
    public Iterator<K> descendingIterator() {
      return descendingSet().iterator();
    }
    
    public NavigableSet<K> descendingSet() {
      return new e(this.b, a().descendingMap());
    }
    
    public K floor(K param1K) {
      return a().floorKey(param1K);
    }
    
    public NavigableSet<K> headSet(K param1K, boolean param1Boolean) {
      return new e(this.b, a().headMap(param1K, param1Boolean));
    }
    
    public K higher(K param1K) {
      return a().higherKey(param1K);
    }
    
    public K lower(K param1K) {
      return a().lowerKey(param1K);
    }
    
    public K pollFirst() {
      return y.c(iterator());
    }
    
    public K pollLast() {
      return y.c(descendingIterator());
    }
    
    public NavigableSet<K> subSet(K param1K1, boolean param1Boolean1, K param1K2, boolean param1Boolean2) {
      return new e(this.b, a().subMap(param1K1, param1Boolean1, param1K2, param1Boolean2));
    }
    
    public NavigableSet<K> tailSet(K param1K, boolean param1Boolean) {
      return new e(this.b, a().tailMap(param1K, param1Boolean));
    }
  }
  
  private class f extends j implements RandomAccess {
    f(@NullableDecl d this$0, K param1K, @NullableDecl List<V> param1List, d<K, V>.i param1i) {
      super(this$0, param1K, param1List, param1i);
    }
  }
  
  private class g extends a implements SortedMap<K, Collection<V>> {
    @MonotonicNonNullDecl
    SortedSet<K> d;
    
    g(d this$0, SortedMap<K, Collection<V>> param1SortedMap) {
      super(this$0, param1SortedMap);
    }
    
    public Comparator<? super K> comparator() {
      return g().comparator();
    }
    
    SortedSet<K> e() {
      return new d.h(this.e, g());
    }
    
    public SortedSet<K> f() {
      SortedSet<K> sortedSet2 = this.d;
      SortedSet<K> sortedSet1 = sortedSet2;
      if (sortedSet2 == null) {
        sortedSet1 = e();
        this.d = sortedSet1;
      } 
      return sortedSet1;
    }
    
    public K firstKey() {
      return g().firstKey();
    }
    
    SortedMap<K, Collection<V>> g() {
      return (SortedMap<K, Collection<V>>)this.a;
    }
    
    public SortedMap<K, Collection<V>> headMap(K param1K) {
      return new g(this.e, g().headMap(param1K));
    }
    
    public K lastKey() {
      return g().lastKey();
    }
    
    public SortedMap<K, Collection<V>> subMap(K param1K1, K param1K2) {
      return new g(this.e, g().subMap(param1K1, param1K2));
    }
    
    public SortedMap<K, Collection<V>> tailMap(K param1K) {
      return new g(this.e, g().tailMap(param1K));
    }
  }
  
  private class h extends c implements SortedSet<K> {
    h(d this$0, SortedMap<K, Collection<V>> param1SortedMap) {
      super(this$0, param1SortedMap);
    }
    
    SortedMap<K, Collection<V>> b() {
      return (SortedMap<K, Collection<V>>)c();
    }
    
    public Comparator<? super K> comparator() {
      return b().comparator();
    }
    
    public K first() {
      return b().firstKey();
    }
    
    public SortedSet<K> headSet(K param1K) {
      return new h(this.c, b().headMap(param1K));
    }
    
    public K last() {
      return b().lastKey();
    }
    
    public SortedSet<K> subSet(K param1K1, K param1K2) {
      return new h(this.c, b().subMap(param1K1, param1K2));
    }
    
    public SortedSet<K> tailSet(K param1K) {
      return new h(this.c, b().tailMap(param1K));
    }
  }
  
  class i extends AbstractCollection<V> {
    @NullableDecl
    final K b;
    
    Collection<V> c;
    
    @NullableDecl
    final i d;
    
    @NullableDecl
    final Collection<V> e;
    
    i(@NullableDecl d this$0, K param1K, @NullableDecl Collection<V> param1Collection, i param1i) {
      Collection<V> collection;
      this.b = param1K;
      this.c = param1Collection;
      this.d = param1i;
      if (param1i == null) {
        this$0 = null;
      } else {
        collection = param1i.e();
      } 
      this.e = collection;
    }
    
    void a() {
      i i1 = this.d;
      if (i1 != null) {
        i1.a();
        if (this.d.e() == this.e)
          return; 
        throw new ConcurrentModificationException();
      } 
      if (this.c.isEmpty()) {
        Collection<V> collection = (Collection)d.a(this.f).get(this.b);
        if (collection != null)
          this.c = collection; 
      } 
    }
    
    public boolean add(V param1V) {
      a();
      boolean bool1 = this.c.isEmpty();
      boolean bool2 = this.c.add(param1V);
      if (bool2) {
        d.c(this.f);
        if (bool1)
          d(); 
      } 
      return bool2;
    }
    
    public boolean addAll(Collection<? extends V> param1Collection) {
      if (param1Collection.isEmpty())
        return false; 
      int j = size();
      boolean bool = this.c.addAll(param1Collection);
      if (bool) {
        int k = this.c.size();
        d.a(this.f, k - j);
        if (j == 0)
          d(); 
      } 
      return bool;
    }
    
    void b() {
      i i1 = this.d;
      if (i1 != null) {
        i1.b();
        return;
      } 
      if (this.c.isEmpty())
        d.a(this.f).remove(this.b); 
    }
    
    K c() {
      return this.b;
    }
    
    public void clear() {
      int j = size();
      if (j == 0)
        return; 
      this.c.clear();
      d.b(this.f, j);
      b();
    }
    
    public boolean contains(Object param1Object) {
      a();
      return this.c.contains(param1Object);
    }
    
    public boolean containsAll(Collection<?> param1Collection) {
      a();
      return this.c.containsAll(param1Collection);
    }
    
    void d() {
      i i1 = this.d;
      if (i1 != null) {
        i1.d();
        return;
      } 
      d.a(this.f).put(this.b, this.c);
    }
    
    Collection<V> e() {
      return this.c;
    }
    
    public boolean equals(@NullableDecl Object param1Object) {
      if (param1Object == this)
        return true; 
      a();
      return this.c.equals(param1Object);
    }
    
    i f() {
      return this.d;
    }
    
    public int hashCode() {
      a();
      return this.c.hashCode();
    }
    
    public Iterator<V> iterator() {
      a();
      return new a(this);
    }
    
    public boolean remove(Object param1Object) {
      a();
      boolean bool = this.c.remove(param1Object);
      if (bool) {
        d.b(this.f);
        b();
      } 
      return bool;
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      if (param1Collection.isEmpty())
        return false; 
      int j = size();
      boolean bool = this.c.removeAll(param1Collection);
      if (bool) {
        int k = this.c.size();
        d.a(this.f, k - j);
        b();
      } 
      return bool;
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      Preconditions.checkNotNull(param1Collection);
      int j = size();
      boolean bool = this.c.retainAll(param1Collection);
      if (bool) {
        int k = this.c.size();
        d.a(this.f, k - j);
        b();
      } 
      return bool;
    }
    
    public int size() {
      a();
      return this.c.size();
    }
    
    public String toString() {
      a();
      return this.c.toString();
    }
    
    class a implements Iterator<V> {
      final Iterator<V> a;
      
      final Collection<V> b = this.c.c;
      
      a(d.i this$0) {
        this.a = d.b(this$0.c);
      }
      
      a(d.i this$0, Iterator<V> param2Iterator) {
        this.a = param2Iterator;
      }
      
      void a() {
        this.c.a();
        if (this.c.c == this.b)
          return; 
        throw new ConcurrentModificationException();
      }
      
      Iterator<V> b() {
        a();
        return this.a;
      }
      
      public boolean hasNext() {
        a();
        return this.a.hasNext();
      }
      
      public V next() {
        a();
        return this.a.next();
      }
      
      public void remove() {
        this.a.remove();
        d.b(this.c.f);
        this.c.b();
      }
    }
  }
  
  class a implements Iterator<V> {
    final Iterator<V> a;
    
    final Collection<V> b = this.c.c;
    
    a(d this$0) {
      this.a = d.b(((d.i)this$0).c);
    }
    
    a(d this$0, Iterator<V> param1Iterator) {
      this.a = param1Iterator;
    }
    
    void a() {
      this.c.a();
      if (this.c.c == this.b)
        return; 
      throw new ConcurrentModificationException();
    }
    
    Iterator<V> b() {
      a();
      return this.a;
    }
    
    public boolean hasNext() {
      a();
      return this.a.hasNext();
    }
    
    public V next() {
      a();
      return this.a.next();
    }
    
    public void remove() {
      this.a.remove();
      d.b(this.c.f);
      this.c.b();
    }
  }
  
  class j extends i implements List<V> {
    j(@NullableDecl d this$0, K param1K, @NullableDecl List<V> param1List, d<K, V>.i param1i) {
      super(this$0, param1K, param1List, param1i);
    }
    
    public void add(int param1Int, V param1V) {
      a();
      boolean bool = e().isEmpty();
      g().add(param1Int, param1V);
      d.c(this.g);
      if (bool)
        d(); 
    }
    
    public boolean addAll(int param1Int, Collection<? extends V> param1Collection) {
      if (param1Collection.isEmpty())
        return false; 
      int k = size();
      boolean bool = g().addAll(param1Int, param1Collection);
      if (bool) {
        param1Int = e().size();
        d.a(this.g, param1Int - k);
        if (k == 0)
          d(); 
      } 
      return bool;
    }
    
    List<V> g() {
      return (List<V>)e();
    }
    
    public V get(int param1Int) {
      a();
      return g().get(param1Int);
    }
    
    public int indexOf(Object param1Object) {
      a();
      return g().indexOf(param1Object);
    }
    
    public int lastIndexOf(Object param1Object) {
      a();
      return g().lastIndexOf(param1Object);
    }
    
    public ListIterator<V> listIterator() {
      a();
      return new a(this);
    }
    
    public ListIterator<V> listIterator(int param1Int) {
      a();
      return new a(this, param1Int);
    }
    
    public V remove(int param1Int) {
      a();
      V v = g().remove(param1Int);
      d.b(this.g);
      b();
      return v;
    }
    
    public V set(int param1Int, V param1V) {
      a();
      return g().set(param1Int, param1V);
    }
    
    public List<V> subList(int param1Int1, int param1Int2) {
      d<K, V>.i i1;
      a();
      d<K, V> d1 = this.g;
      K k = c();
      List<V> list = g().subList(param1Int1, param1Int2);
      if (f() == null) {
        i1 = this;
      } else {
        i1 = f();
      } 
      return d1.a(k, list, i1);
    }
    
    private class a extends d<K, V>.i.a implements ListIterator<V> {
      a(d.j this$0) {
        super(this$0);
      }
      
      public a(d.j this$0, int param2Int) {
        super(this$0, this$0.g().listIterator(param2Int));
      }
      
      private ListIterator<V> c() {
        return (ListIterator<V>)b();
      }
      
      public void add(V param2V) {
        boolean bool = this.d.isEmpty();
        c().add(param2V);
        d.c(this.d.g);
        if (bool)
          this.d.d(); 
      }
      
      public boolean hasPrevious() {
        return c().hasPrevious();
      }
      
      public int nextIndex() {
        return c().nextIndex();
      }
      
      public V previous() {
        return c().previous();
      }
      
      public int previousIndex() {
        return c().previousIndex();
      }
      
      public void set(V param2V) {
        c().set(param2V);
      }
    }
  }
  
  private class a extends i.a implements ListIterator<V> {
    a(d this$0) {
      super((d.i)this$0);
    }
    
    public a(d this$0, int param1Int) {
      super((d.i)this$0, this$0.g().listIterator(param1Int));
    }
    
    private ListIterator<V> c() {
      return (ListIterator<V>)b();
    }
    
    public void add(V param1V) {
      boolean bool = this.d.isEmpty();
      c().add(param1V);
      d.c(this.d.g);
      if (bool)
        this.d.d(); 
    }
    
    public boolean hasPrevious() {
      return c().hasPrevious();
    }
    
    public int nextIndex() {
      return c().nextIndex();
    }
    
    public V previous() {
      return c().previous();
    }
    
    public int previousIndex() {
      return c().previousIndex();
    }
    
    public void set(V param1V) {
      c().set(param1V);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */