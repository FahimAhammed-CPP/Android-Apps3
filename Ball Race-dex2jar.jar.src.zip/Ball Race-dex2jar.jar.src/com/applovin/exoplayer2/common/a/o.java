package com.applovin.exoplayer2.common.a;

class o extends t<Object, Object> {
  static final o a = new o();
  
  private o() {
    super(u.a(), 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */