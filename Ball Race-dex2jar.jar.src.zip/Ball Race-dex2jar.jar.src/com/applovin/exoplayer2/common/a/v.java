package com.applovin.exoplayer2.common.a;

import com.google.errorprone.annotations.CanIgnoreReturnValue;
import com.google.j2objc.annotations.Weak;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class v<K, V> extends g<K, V> implements Serializable {
  final transient u<K, ? extends q<V>> b;
  
  final transient int c;
  
  v(u<K, ? extends q<V>> paramu, int paramInt) {
    this.b = paramu;
    this.c = paramInt;
  }
  
  @Deprecated
  @CanIgnoreReturnValue
  public boolean a(K paramK, V paramV) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  @CanIgnoreReturnValue
  public boolean c(Object paramObject1, Object paramObject2) {
    throw new UnsupportedOperationException();
  }
  
  public int d() {
    return this.c;
  }
  
  public boolean d(@NullableDecl Object paramObject) {
    return (paramObject != null && super.d(paramObject));
  }
  
  public abstract q<V> e(K paramK);
  
  @Deprecated
  public void e() {
    throw new UnsupportedOperationException();
  }
  
  Set<K> f() {
    throw new AssertionError("unreachable");
  }
  
  boolean g() {
    return this.b.i();
  }
  
  Map<K, Collection<V>> n() {
    throw new AssertionError("should never be called");
  }
  
  public w<K> o() {
    return this.b.e();
  }
  
  public u<K, Collection<V>> q() {
    return (u)this.b;
  }
  
  public q<Map.Entry<K, V>> r() {
    return (q<Map.Entry<K, V>>)super.k();
  }
  
  q<Map.Entry<K, V>> s() {
    return new b<K, V>(this);
  }
  
  ax<Map.Entry<K, V>> t() {
    return new ax<Map.Entry<K, V>>(this) {
        final Iterator<? extends Map.Entry<K, ? extends q<V>>> a = (Iterator<? extends Map.Entry<K, ? extends q<V>>>)this.d.b.c().a();
        
        K b = null;
        
        Iterator<V> c = (Iterator)y.a();
        
        public Map.Entry<K, V> a() {
          if (!this.c.hasNext()) {
            Map.Entry entry = this.a.next();
            this.b = (K)entry.getKey();
            this.c = (Iterator<V>)((q)entry.getValue()).a();
          } 
          return ab.a(this.b, this.c.next());
        }
        
        public boolean hasNext() {
          return (this.c.hasNext() || this.a.hasNext());
        }
      };
  }
  
  public q<V> u() {
    return (q<V>)super.h();
  }
  
  q<V> v() {
    return new c<Object, V>(this);
  }
  
  ax<V> w() {
    return new ax<V>(this) {
        Iterator<? extends q<V>> a = (Iterator<? extends q<V>>)this.c.b.g().a();
        
        Iterator<V> b = (Iterator)y.a();
        
        public boolean hasNext() {
          return (this.b.hasNext() || this.a.hasNext());
        }
        
        public V next() {
          if (!this.b.hasNext())
            this.b = (Iterator<V>)((q)this.a.next()).a(); 
          return this.b.next();
        }
      };
  }
  
  public static class a<K, V> {
    Map<K, Collection<V>> a = aj.a();
    
    @MonotonicNonNullDecl
    Comparator<? super K> b;
    
    @MonotonicNonNullDecl
    Comparator<? super V> c;
    
    @CanIgnoreReturnValue
    public a<K, V> b(K param1K, Iterable<? extends V> param1Iterable) {
      // Byte code:
      //   0: aload_1
      //   1: ifnull -> 138
      //   4: aload_0
      //   5: getfield a : Ljava/util/Map;
      //   8: aload_1
      //   9: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   14: checkcast java/util/Collection
      //   17: astore_3
      //   18: aload_3
      //   19: ifnull -> 66
      //   22: aload_2
      //   23: invokeinterface iterator : ()Ljava/util/Iterator;
      //   28: astore_2
      //   29: aload_2
      //   30: invokeinterface hasNext : ()Z
      //   35: ifeq -> 64
      //   38: aload_2
      //   39: invokeinterface next : ()Ljava/lang/Object;
      //   44: astore #4
      //   46: aload_1
      //   47: aload #4
      //   49: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   52: aload_3
      //   53: aload #4
      //   55: invokeinterface add : (Ljava/lang/Object;)Z
      //   60: pop
      //   61: goto -> 29
      //   64: aload_0
      //   65: areturn
      //   66: aload_2
      //   67: invokeinterface iterator : ()Ljava/util/Iterator;
      //   72: astore_2
      //   73: aload_2
      //   74: invokeinterface hasNext : ()Z
      //   79: ifne -> 84
      //   82: aload_0
      //   83: areturn
      //   84: aload_0
      //   85: invokevirtual c : ()Ljava/util/Collection;
      //   88: astore_3
      //   89: aload_2
      //   90: invokeinterface hasNext : ()Z
      //   95: ifeq -> 124
      //   98: aload_2
      //   99: invokeinterface next : ()Ljava/lang/Object;
      //   104: astore #4
      //   106: aload_1
      //   107: aload #4
      //   109: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)V
      //   112: aload_3
      //   113: aload #4
      //   115: invokeinterface add : (Ljava/lang/Object;)Z
      //   120: pop
      //   121: goto -> 89
      //   124: aload_0
      //   125: getfield a : Ljava/util/Map;
      //   128: aload_1
      //   129: aload_3
      //   130: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   135: pop
      //   136: aload_0
      //   137: areturn
      //   138: new java/lang/StringBuilder
      //   141: dup
      //   142: invokespecial <init> : ()V
      //   145: astore_1
      //   146: aload_1
      //   147: ldc 'null key in entry: null='
      //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   152: pop
      //   153: aload_1
      //   154: aload_2
      //   155: invokestatic a : (Ljava/lang/Iterable;)Ljava/lang/String;
      //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   161: pop
      //   162: new java/lang/NullPointerException
      //   165: dup
      //   166: aload_1
      //   167: invokevirtual toString : ()Ljava/lang/String;
      //   170: invokespecial <init> : (Ljava/lang/String;)V
      //   173: athrow
    }
    
    @CanIgnoreReturnValue
    public a<K, V> b(K param1K, V... param1VarArgs) {
      return b(param1K, Arrays.asList(param1VarArgs));
    }
    
    public v<K, V> b() {
      s<? extends Map.Entry<? extends K, ? extends Collection<? extends V>>> s;
      Set<Map.Entry<K, Collection<V>>> set2 = this.a.entrySet();
      Comparator<? super K> comparator = this.b;
      Set<Map.Entry<K, Collection<V>>> set1 = set2;
      if (comparator != null)
        s = ai.a(comparator).c().a(set2); 
      return t.a(s, this.c);
    }
    
    Collection<V> c() {
      return new ArrayList<V>();
    }
  }
  
  private static class b<K, V> extends q<Map.Entry<K, V>> {
    @Weak
    final v<K, V> a;
    
    b(v<K, V> param1v) {
      this.a = param1v;
    }
    
    public ax<Map.Entry<K, V>> a() {
      return this.a.t();
    }
    
    public boolean contains(Object param1Object) {
      if (param1Object instanceof Map.Entry) {
        param1Object = param1Object;
        return this.a.b(param1Object.getKey(), param1Object.getValue());
      } 
      return false;
    }
    
    boolean f() {
      return this.a.g();
    }
    
    public int size() {
      return this.a.d();
    }
  }
  
  private static final class c<K, V> extends q<V> {
    @Weak
    private final transient v<K, V> a;
    
    c(v<K, V> param1v) {
      this.a = param1v;
    }
    
    int a(Object[] param1ArrayOfObject, int param1Int) {
      ax<q> ax = this.a.b.g().a();
      while (ax.hasNext())
        param1Int = ((q)ax.next()).a(param1ArrayOfObject, param1Int); 
      return param1Int;
    }
    
    public ax<V> a() {
      return this.a.w();
    }
    
    public boolean contains(@NullableDecl Object param1Object) {
      return this.a.d(param1Object);
    }
    
    boolean f() {
      return true;
    }
    
    public int size() {
      return this.a.d();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */