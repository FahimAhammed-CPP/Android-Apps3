package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import com.google.errorprone.annotations.concurrent.LazyInit;
import com.google.j2objc.annotations.RetainedWith;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public abstract class w<E> extends q<E> implements Set<E> {
  @LazyInit
  @NullableDecl
  @RetainedWith
  private transient s<E> a;
  
  static int a(int paramInt) {
    int i = Math.max(paramInt, 2);
    boolean bool = true;
    if (i < 751619276) {
      for (paramInt = Integer.highestOneBit(i - 1) << 1; paramInt * 0.7D < i; paramInt <<= 1);
      return paramInt;
    } 
    if (i >= 1073741824)
      bool = false; 
    Preconditions.checkArgument(bool, "collection too large");
    return 1073741824;
  }
  
  private static <E> w<E> a(int paramInt, Object... paramVarArgs) {
    if (paramInt != 0) {
      if (paramInt != 1) {
        int m = a(paramInt);
        Object[] arrayOfObject2 = new Object[m];
        int n = m - 1;
        int i = 0;
        int k = 0;
        int j = 0;
        label28: while (i < paramInt) {
          Object object = ah.a(paramVarArgs[i], i);
          int i2 = object.hashCode();
          int i1 = p.a(i2);
          while (true) {
            int i3 = i1 & n;
            Object object1 = arrayOfObject2[i3];
            if (object1 == null) {
              paramVarArgs[j] = object;
              arrayOfObject2[i3] = object;
              k += i2;
              j++;
            } else if (!object1.equals(object)) {
              i1++;
              continue;
            } 
            i++;
            continue label28;
          } 
        } 
        Arrays.fill(paramVarArgs, j, paramInt, (Object)null);
        if (j == 1)
          return (w<E>)new ar(paramVarArgs[0], k); 
        if (a(j) < m / 2)
          return a(j, paramVarArgs); 
        Object[] arrayOfObject1 = paramVarArgs;
        if (a(j, paramVarArgs.length))
          arrayOfObject1 = Arrays.copyOf(paramVarArgs, j); 
        return (w<E>)new am(arrayOfObject1, k, arrayOfObject2, n, j);
      } 
      return a((E)paramVarArgs[0]);
    } 
    return g();
  }
  
  public static <E> w<E> a(E paramE) {
    return (w<E>)new ar(paramE);
  }
  
  public static <E> w<E> a(E paramE1, E paramE2) {
    return a(2, new Object[] { paramE1, paramE2 });
  }
  
  public static <E> w<E> a(E paramE1, E paramE2, E paramE3) {
    return a(3, new Object[] { paramE1, paramE2, paramE3 });
  }
  
  public static <E> w<E> a(Collection<? extends E> paramCollection) {
    if (paramCollection instanceof w && !(paramCollection instanceof java.util.SortedSet)) {
      w<E> w1 = (w)paramCollection;
      if (!w1.f())
        return w1; 
    } 
    Object[] arrayOfObject = paramCollection.toArray();
    return a(arrayOfObject.length, arrayOfObject);
  }
  
  public static <E> w<E> a(E[] paramArrayOfE) {
    int i = paramArrayOfE.length;
    return (i != 0) ? ((i != 1) ? a(paramArrayOfE.length, (Object[])paramArrayOfE.clone()) : a(paramArrayOfE[0])) : g();
  }
  
  private static boolean a(int paramInt1, int paramInt2) {
    return (paramInt1 < (paramInt2 >> 1) + (paramInt2 >> 2));
  }
  
  public static <E> w<E> g() {
    return (w<E>)am.a;
  }
  
  public abstract ax<E> a();
  
  public s<E> e() {
    s<E> s2 = this.a;
    s<E> s1 = s2;
    if (s2 == null) {
      s1 = i();
      this.a = s1;
    } 
    return s1;
  }
  
  public boolean equals(@NullableDecl Object paramObject) {
    return (paramObject == this) ? true : ((paramObject instanceof w && h() && ((w)paramObject).h() && hashCode() != paramObject.hashCode()) ? false : aq.a(this, paramObject));
  }
  
  boolean h() {
    return false;
  }
  
  public int hashCode() {
    return aq.a(this);
  }
  
  s<E> i() {
    return s.b(toArray());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */