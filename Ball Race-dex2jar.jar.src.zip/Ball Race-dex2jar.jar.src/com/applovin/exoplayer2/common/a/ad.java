package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import com.applovin.exoplayer2.common.base.Supplier;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public abstract class ad<K0, V0> {
  private ad() {}
  
  public static c<Comparable> a() {
    return a((Comparator<Comparable>)ai.b());
  }
  
  public static <K0> c<K0> a(Comparator<K0> paramComparator) {
    Preconditions.checkNotNull(paramComparator);
    return new c<K0>(paramComparator) {
        <K extends K0, V> Map<K, Collection<V>> a() {
          return new TreeMap<K, Collection<V>>(this.a);
        }
      };
  }
  
  private static final class a<V> implements Supplier<List<V>>, Serializable {
    private final int a;
    
    a(int param1Int) {
      this.a = j.a(param1Int, "expectedValuesPerKey");
    }
    
    public List<V> a() {
      return new ArrayList<V>(this.a);
    }
  }
  
  public static abstract class b<K0, V0> extends ad<K0, V0> {
    public abstract <K extends K0, V extends V0> z<K, V> b();
  }
  
  public static abstract class c<K0> {
    public ad.b<K0, Object> a(int param1Int) {
      j.a(param1Int, "expectedValuesPerKey");
      return new ad.b<K0, Object>(this, param1Int) {
          public <K extends K0, V> z<K, V> b() {
            return ae.a(this.b.a(), new ad.a(this.a));
          }
        };
    }
    
    abstract <K extends K0, V> Map<K, Collection<V>> a();
    
    public ad.b<K0, Object> b() {
      return a(2);
    }
  }
  
  class null extends b<K0, Object> {
    null(ad this$0, int param1Int) {}
    
    public <K extends K0, V> z<K, V> b() {
      return ae.a(this.b.a(), new ad.a(this.a));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */