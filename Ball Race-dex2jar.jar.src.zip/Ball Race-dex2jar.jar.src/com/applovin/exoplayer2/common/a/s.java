package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public abstract class s<E> extends q<E> implements List<E>, RandomAccess {
  private static final ay<Object> a = new b(ak.a, 0);
  
  public static <E> s<E> a(E paramE) {
    return c(new Object[] { paramE });
  }
  
  public static <E> s<E> a(E paramE1, E paramE2) {
    return c(new Object[] { paramE1, paramE2 });
  }
  
  public static <E> s<E> a(E paramE1, E paramE2, E paramE3, E paramE4, E paramE5) {
    return c(new Object[] { paramE1, paramE2, paramE3, paramE4, paramE5 });
  }
  
  public static <E> s<E> a(E paramE1, E paramE2, E paramE3, E paramE4, E paramE5, E paramE6) {
    return c(new Object[] { paramE1, paramE2, paramE3, paramE4, paramE5, paramE6 });
  }
  
  public static <E> s<E> a(Collection<? extends E> paramCollection) {
    if (paramCollection instanceof q) {
      s<? extends E> s1 = ((q)paramCollection).e();
      paramCollection = s1;
      if (s1.f())
        paramCollection = b(s1.toArray()); 
      return (s)paramCollection;
    } 
    return c(paramCollection.toArray());
  }
  
  public static <E> s<E> a(Comparator<? super E> paramComparator, Iterable<? extends E> paramIterable) {
    Preconditions.checkNotNull(paramComparator);
    Object[] arrayOfObject = x.b(paramIterable);
    ah.a(arrayOfObject);
    Arrays.sort(arrayOfObject, (Comparator)paramComparator);
    return b(arrayOfObject);
  }
  
  public static <E> s<E> a(E[] paramArrayOfE) {
    return (paramArrayOfE.length == 0) ? g() : c((Object[])paramArrayOfE.clone());
  }
  
  static <E> s<E> b(Object[] paramArrayOfObject) {
    return b(paramArrayOfObject, paramArrayOfObject.length);
  }
  
  static <E> s<E> b(Object[] paramArrayOfObject, int paramInt) {
    return (s<E>)((paramInt == 0) ? g() : new ak(paramArrayOfObject, paramInt));
  }
  
  private static <E> s<E> c(Object... paramVarArgs) {
    return b(ah.a(paramVarArgs));
  }
  
  public static <E> s<E> g() {
    return ak.a;
  }
  
  public static <E> a<E> i() {
    return new a<E>();
  }
  
  int a(Object[] paramArrayOfObject, int paramInt) {
    int j = size();
    for (int i = 0; i < j; i++)
      paramArrayOfObject[paramInt + i] = get(i); 
    return paramInt + j;
  }
  
  public ax<E> a() {
    return (ax<E>)h();
  }
  
  public ay<E> a(int paramInt) {
    Preconditions.checkPositionIndex(paramInt, size());
    return (ay<E>)(isEmpty() ? a : new b<E>(this, paramInt));
  }
  
  public s<E> a(int paramInt1, int paramInt2) {
    Preconditions.checkPositionIndexes(paramInt1, paramInt2, size());
    int i = paramInt2 - paramInt1;
    return (i == size()) ? this : ((i == 0) ? g() : b(paramInt1, paramInt2));
  }
  
  @Deprecated
  public final void add(int paramInt, E paramE) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
    throw new UnsupportedOperationException();
  }
  
  s<E> b(int paramInt1, int paramInt2) {
    return new c(this, paramInt1, paramInt2 - paramInt1);
  }
  
  public boolean contains(Object paramObject) {
    return (indexOf(paramObject) >= 0);
  }
  
  public final s<E> e() {
    return this;
  }
  
  public boolean equals(Object paramObject) {
    return aa.a(this, paramObject);
  }
  
  public ay<E> h() {
    return a(0);
  }
  
  public int hashCode() {
    int k = size();
    int j = 1;
    for (int i = 0; i < k; i++)
      j = j * 31 + get(i).hashCode(); 
    return j;
  }
  
  public int indexOf(Object paramObject) {
    return (paramObject == null) ? -1 : aa.b(this, paramObject);
  }
  
  public int lastIndexOf(Object paramObject) {
    return (paramObject == null) ? -1 : aa.c(this, paramObject);
  }
  
  @Deprecated
  public final E remove(int paramInt) {
    throw new UnsupportedOperationException();
  }
  
  @Deprecated
  public final E set(int paramInt, E paramE) {
    throw new UnsupportedOperationException();
  }
  
  public static final class a<E> extends q.a<E> {
    public a() {
      this(4);
    }
    
    a(int param1Int) {
      super(param1Int);
    }
    
    public s<E> a() {
      this.c = true;
      return s.b(this.a, this.b);
    }
    
    public a<E> b(E param1E) {
      super.a(param1E);
      return this;
    }
  }
  
  static class b<E> extends a<E> {
    private final s<E> a;
    
    b(s<E> param1s, int param1Int) {
      super(param1s.size(), param1Int);
      this.a = param1s;
    }
    
    protected E a(int param1Int) {
      return this.a.get(param1Int);
    }
  }
  
  class c extends s<E> {
    final transient int a;
    
    final transient int b;
    
    c(s this$0, int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
    
    public s<E> a(int param1Int1, int param1Int2) {
      Preconditions.checkPositionIndexes(param1Int1, param1Int2, this.b);
      s<E> s1 = this.c;
      int i = this.a;
      return s1.a(param1Int1 + i, param1Int2 + i);
    }
    
    Object[] b() {
      return this.c.b();
    }
    
    int c() {
      return this.c.c() + this.a;
    }
    
    int d() {
      return this.c.c() + this.a + this.b;
    }
    
    boolean f() {
      return true;
    }
    
    public E get(int param1Int) {
      Preconditions.checkElementIndex(param1Int, this.b);
      return this.c.get(param1Int + this.a);
    }
    
    public int size() {
      return this.b;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */