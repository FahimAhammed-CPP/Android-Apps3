package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.io.Serializable;
import java.util.Comparator;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

final class m<T> extends ai<T> implements Serializable {
  final Comparator<T> a;
  
  m(Comparator<T> paramComparator) {
    this.a = (Comparator<T>)Preconditions.checkNotNull(paramComparator);
  }
  
  public int compare(T paramT1, T paramT2) {
    return this.a.compare(paramT1, paramT2);
  }
  
  public boolean equals(@NullableDecl Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof m) {
      paramObject = paramObject;
      return this.a.equals(((m)paramObject).a);
    } 
    return false;
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    return this.a.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */