package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;

final class j {
  static int a(int paramInt, String paramString) {
    if (paramInt >= 0)
      return paramInt; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(" cannot be negative but was: ");
    stringBuilder.append(paramInt);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  static void a(Object paramObject1, Object paramObject2) {
    if (paramObject1 != null) {
      if (paramObject2 != null)
        return; 
      paramObject2 = new StringBuilder();
      paramObject2.append("null value in entry: ");
      paramObject2.append(paramObject1);
      paramObject2.append("=null");
      throw new NullPointerException(paramObject2.toString());
    } 
    paramObject1 = new StringBuilder();
    paramObject1.append("null key in entry: null=");
    paramObject1.append(paramObject2);
    throw new NullPointerException(paramObject1.toString());
  }
  
  static void a(boolean paramBoolean) {
    Preconditions.checkState(paramBoolean, "no calls to next() since the last call to remove()");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */