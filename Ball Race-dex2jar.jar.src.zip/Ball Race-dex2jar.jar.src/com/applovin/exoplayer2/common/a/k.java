package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Preconditions;
import java.util.Collection;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class k {
  static StringBuilder a(int paramInt) {
    j.a(paramInt, "size");
    return new StringBuilder((int)Math.min(paramInt * 8L, 1073741824L));
  }
  
  static boolean a(Collection<?> paramCollection, @NullableDecl Object paramObject) {
    Preconditions.checkNotNull(paramCollection);
    try {
      return paramCollection.contains(paramObject);
    } catch (ClassCastException|NullPointerException classCastException) {
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */