package com.applovin.exoplayer2.common.a;

import com.applovin.exoplayer2.common.base.Function;
import com.applovin.exoplayer2.common.base.Objects;
import com.applovin.exoplayer2.common.base.Preconditions;
import com.google.j2objc.annotations.Weak;
import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.checkerframework.checker.nullness.compatqual.MonotonicNonNullDecl;
import org.checkerframework.checker.nullness.compatqual.NullableDecl;

public final class ab {
  static int a(int paramInt) {
    if (paramInt < 3) {
      j.a(paramInt, "expectedSize");
      return paramInt + 1;
    } 
    return (paramInt < 1073741824) ? (int)(paramInt / 0.75F + 1.0F) : Integer.MAX_VALUE;
  }
  
  static <K> Function<Map.Entry<K, ?>, K> a() {
    return a.a;
  }
  
  static <V> V a(Map<?, V> paramMap, @NullableDecl Object paramObject) {
    Preconditions.checkNotNull(paramMap);
    try {
      return paramMap.get(paramObject);
    } catch (ClassCastException|NullPointerException classCastException) {
      return null;
    } 
  }
  
  static String a(Map<?, ?> paramMap) {
    StringBuilder stringBuilder = k.a(paramMap.size());
    stringBuilder.append('{');
    Iterator<Map.Entry> iterator = paramMap.entrySet().iterator();
    boolean bool = true;
    while (iterator.hasNext()) {
      Map.Entry entry = iterator.next();
      if (!bool)
        stringBuilder.append(", "); 
      bool = false;
      stringBuilder.append(entry.getKey());
      stringBuilder.append('=');
      stringBuilder.append(entry.getValue());
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  static <K, V> Iterator<K> a(Iterator<Map.Entry<K, V>> paramIterator) {
    return (Iterator)new aw<Map.Entry<K, V>, K>(paramIterator) {
        K a(Map.Entry<K, V> param1Entry) {
          return param1Entry.getKey();
        }
      };
  }
  
  public static <K, V> Map.Entry<K, V> a(@NullableDecl K paramK, @NullableDecl V paramV) {
    return new r<K, V>(paramK, paramV);
  }
  
  static <V> Function<Map.Entry<?, V>, V> b() {
    return a.b;
  }
  
  static <K, V> Iterator<V> b(Iterator<Map.Entry<K, V>> paramIterator) {
    return (Iterator)new aw<Map.Entry<K, V>, V>(paramIterator) {
        V a(Map.Entry<K, V> param1Entry) {
          return param1Entry.getValue();
        }
      };
  }
  
  static boolean b(Map<?, ?> paramMap, Object paramObject) {
    Preconditions.checkNotNull(paramMap);
    try {
      return paramMap.containsKey(paramObject);
    } catch (ClassCastException|NullPointerException classCastException) {
      return false;
    } 
  }
  
  static <V> V c(Map<?, V> paramMap, Object paramObject) {
    Preconditions.checkNotNull(paramMap);
    try {
      return paramMap.remove(paramObject);
    } catch (ClassCastException|NullPointerException classCastException) {
      return null;
    } 
  }
  
  public static <K, V> IdentityHashMap<K, V> c() {
    return new IdentityHashMap<K, V>();
  }
  
  static boolean d(Map<?, ?> paramMap, Object paramObject) {
    if (paramMap == paramObject)
      return true; 
    if (paramObject instanceof Map) {
      paramObject = paramObject;
      return paramMap.entrySet().equals(paramObject.entrySet());
    } 
    return false;
  }
  
  private enum a implements Function<Map.Entry<?, ?>, Object> {
    a {
      @NullableDecl
      public Object a(Map.Entry<?, ?> param2Entry) {
        return param2Entry.getKey();
      }
    },
    b {
      @NullableDecl
      public Object a(Map.Entry<?, ?> param2Entry) {
        return param2Entry.getValue();
      }
    };
  }
  
  enum null {
    @NullableDecl
    public Object a(Map.Entry<?, ?> param1Entry) {
      return param1Entry.getKey();
    }
  }
  
  enum null {
    @NullableDecl
    public Object a(Map.Entry<?, ?> param1Entry) {
      return param1Entry.getValue();
    }
  }
  
  static abstract class b<K, V> extends aq.a<Map.Entry<K, V>> {
    abstract Map<K, V> a();
    
    public void clear() {
      a().clear();
    }
    
    public boolean contains(Object param1Object) {
      boolean bool1 = param1Object instanceof Map.Entry;
      boolean bool = false;
      null = bool;
      if (bool1) {
        param1Object = param1Object;
        Object object = param1Object.getKey();
        Object object1 = ab.a((Map)a(), object);
        null = bool;
        if (Objects.equal(object1, param1Object.getValue())) {
          if (object1 == null) {
            null = bool;
            return a().containsKey(object) ? true : null;
          } 
        } else {
          return null;
        } 
      } else {
        return null;
      } 
      return true;
    }
    
    public boolean isEmpty() {
      return a().isEmpty();
    }
    
    public boolean remove(Object param1Object) {
      if (contains(param1Object)) {
        param1Object = param1Object;
        return a().keySet().remove(param1Object.getKey());
      } 
      return false;
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      try {
        return super.removeAll((Collection)Preconditions.checkNotNull(param1Collection));
      } catch (UnsupportedOperationException unsupportedOperationException) {
        return aq.a(this, param1Collection.iterator());
      } 
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      try {
        return super.retainAll((Collection)Preconditions.checkNotNull(param1Collection));
      } catch (UnsupportedOperationException unsupportedOperationException) {
        HashSet<?> hashSet = aq.a(param1Collection.size());
        for (Object object : param1Collection) {
          if (contains(object))
            hashSet.add(((Map.Entry)object).getKey()); 
        } 
        return a().keySet().retainAll(hashSet);
      } 
    }
    
    public int size() {
      return a().size();
    }
  }
  
  static class c<K, V> extends aq.a<K> {
    @Weak
    final Map<K, V> d;
    
    c(Map<K, V> param1Map) {
      this.d = (Map<K, V>)Preconditions.checkNotNull(param1Map);
    }
    
    Map<K, V> c() {
      return this.d;
    }
    
    public void clear() {
      c().clear();
    }
    
    public boolean contains(Object param1Object) {
      return c().containsKey(param1Object);
    }
    
    public boolean isEmpty() {
      return c().isEmpty();
    }
    
    public Iterator<K> iterator() {
      return ab.a(c().entrySet().iterator());
    }
    
    public boolean remove(Object param1Object) {
      if (contains(param1Object)) {
        c().remove(param1Object);
        return true;
      } 
      return false;
    }
    
    public int size() {
      return c().size();
    }
  }
  
  static class d<K, V> extends AbstractCollection<V> {
    @Weak
    final Map<K, V> a;
    
    d(Map<K, V> param1Map) {
      this.a = (Map<K, V>)Preconditions.checkNotNull(param1Map);
    }
    
    final Map<K, V> a() {
      return this.a;
    }
    
    public void clear() {
      a().clear();
    }
    
    public boolean contains(@NullableDecl Object param1Object) {
      return a().containsValue(param1Object);
    }
    
    public boolean isEmpty() {
      return a().isEmpty();
    }
    
    public Iterator<V> iterator() {
      return ab.b(a().entrySet().iterator());
    }
    
    public boolean remove(Object param1Object) {
      try {
        return super.remove(param1Object);
      } catch (UnsupportedOperationException unsupportedOperationException) {
        for (Map.Entry<K, V> entry : a().entrySet()) {
          if (Objects.equal(param1Object, entry.getValue())) {
            a().remove(entry.getKey());
            return true;
          } 
        } 
        return false;
      } 
    }
    
    public boolean removeAll(Collection<?> param1Collection) {
      try {
        return super.removeAll((Collection)Preconditions.checkNotNull(param1Collection));
      } catch (UnsupportedOperationException unsupportedOperationException) {
        HashSet<?> hashSet = aq.a();
        for (Map.Entry<K, V> entry : a().entrySet()) {
          if (param1Collection.contains(entry.getValue()))
            hashSet.add(entry.getKey()); 
        } 
        return a().keySet().removeAll(hashSet);
      } 
    }
    
    public boolean retainAll(Collection<?> param1Collection) {
      try {
        return super.retainAll((Collection)Preconditions.checkNotNull(param1Collection));
      } catch (UnsupportedOperationException unsupportedOperationException) {
        HashSet<?> hashSet = aq.a();
        for (Map.Entry<K, V> entry : a().entrySet()) {
          if (param1Collection.contains(entry.getValue()))
            hashSet.add(entry.getKey()); 
        } 
        return a().keySet().retainAll(hashSet);
      } 
    }
    
    public int size() {
      return a().size();
    }
  }
  
  static abstract class e<K, V> extends AbstractMap<K, V> {
    @MonotonicNonNullDecl
    private transient Set<Map.Entry<K, V>> a;
    
    @MonotonicNonNullDecl
    private transient Set<K> b;
    
    @MonotonicNonNullDecl
    private transient Collection<V> c;
    
    abstract Set<Map.Entry<K, V>> a();
    
    public Set<Map.Entry<K, V>> entrySet() {
      Set<Map.Entry<K, V>> set2 = this.a;
      Set<Map.Entry<K, V>> set1 = set2;
      if (set2 == null) {
        set1 = a();
        this.a = set1;
      } 
      return set1;
    }
    
    Set<K> h() {
      return new ab.c<K, Object>(this);
    }
    
    Collection<V> i() {
      return new ab.d<Object, V>(this);
    }
    
    public Set<K> keySet() {
      Set<K> set2 = this.b;
      Set<K> set1 = set2;
      if (set2 == null) {
        set1 = h();
        this.b = set1;
      } 
      return set1;
    }
    
    public Collection<V> values() {
      Collection<V> collection2 = this.c;
      Collection<V> collection1 = collection2;
      if (collection2 == null) {
        collection1 = i();
        this.c = collection1;
      } 
      return collection1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\exoplayer2\common\a\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */