package com.applovin.impl.adview.activity.a;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import androidx.annotation.Nullable;
import com.applovin.adview.AppLovinAdView;
import com.applovin.impl.adview.a;
import com.applovin.impl.adview.m;
import com.applovin.impl.adview.t;
import com.applovin.impl.adview.u;
import com.applovin.impl.adview.v;
import com.applovin.impl.c.a;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.r;
import com.applovin.sdk.AppLovinSdkUtils;

public class c extends a {
  public c(e parame, Activity paramActivity, p paramp) {
    super(parame, paramActivity, paramp);
  }
  
  public void a(ImageView paramImageView1, m paramm, v paramv, a parama, ProgressBar paramProgressBar, View paramView, AppLovinAdView paramAppLovinAdView, @Nullable u paramu, @Nullable ImageView paramImageView2, @Nullable ViewGroup paramViewGroup) {
    View view;
    FrameLayout.LayoutParams layoutParams;
    if (this.c.aN() == e.d.b) {
      layoutParams = new FrameLayout.LayoutParams(-1, -2, 48);
    } else if (this.c.aN() == e.d.c) {
      layoutParams = new FrameLayout.LayoutParams(-1, -2, 80);
    } else if (this.c.aN() == e.d.d) {
      layoutParams = new FrameLayout.LayoutParams(-2, -1, 3);
    } else if (this.c.aN() == e.d.e) {
      layoutParams = new FrameLayout.LayoutParams(-2, -1, 5);
    } else {
      layoutParams = this.e;
    } 
    if (this.c.aK()) {
      paramAppLovinAdView.setLayoutParams((ViewGroup.LayoutParams)this.e);
      this.d.addView((View)paramAppLovinAdView);
      view = new View((Context)this.b);
      view.setLayoutParams((ViewGroup.LayoutParams)this.e);
      view.setBackgroundColor(Color.argb(254, 0, 0, 0));
      view.setOnTouchListener(new View.OnTouchListener(this) {
            public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
              return true;
            }
          });
      this.d.addView(view);
      paramView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      this.d.addView(paramView);
    } else {
      paramView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
      this.d.addView(paramView);
      view.setLayoutParams((ViewGroup.LayoutParams)this.e);
      this.d.addView(view);
      view.setVisibility(4);
    } 
    if (paramv != null) {
      int j;
      t t = this.c.D();
      double d1 = t.a() / 100.0D;
      double d2 = t.b() / 100.0D;
      if (paramViewGroup != null) {
        i = paramViewGroup.getWidth();
        j = paramViewGroup.getHeight();
      } else {
        Point point = h.a((Context)this.b);
        i = point.x;
        j = point.y;
      } 
      FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams((int)(i * d1), (int)(j * d2), t.d());
      int i = AppLovinSdkUtils.dpToPx((Context)this.b, t.c());
      layoutParams1.setMargins(i, i, i, i);
      this.d.addView((View)paramv, (ViewGroup.LayoutParams)layoutParams1);
      if (t.i() > 0.0F) {
        paramv.setVisibility(4);
        long l = Utils.secondsToMillisLong(t.i());
        AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, paramv, t.g()) {
              public void run() {
                r.a((View)this.a, this.b, null);
              }
            }l);
      } 
      if (t.j() > 0.0F) {
        long l = Utils.secondsToMillisLong(t.j());
        AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, paramv, t.h()) {
              public void run() {
                r.b((View)this.a, this.b, null);
              }
            }l);
      } 
    } 
    if (paramm != null) {
      byte b;
      if (this.c.ac()) {
        b = 3;
      } else {
        b = 5;
      } 
      a(this.c.X(), b | 0x30, paramm);
    } 
    if (paramImageView1 != null) {
      int i = AppLovinSdkUtils.dpToPx((Context)this.b, ((Integer)this.a.a(b.cK)).intValue());
      FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(i, i, ((Integer)this.a.a(b.cM)).intValue());
      i = AppLovinSdkUtils.dpToPx((Context)this.b, ((Integer)this.a.a(b.cL)).intValue());
      layoutParams1.setMargins(i, i, i, i);
      this.d.addView((View)paramImageView1, (ViewGroup.LayoutParams)layoutParams1);
    } 
    if (parama != null)
      this.d.addView((View)parama, (ViewGroup.LayoutParams)this.e); 
    if (paramProgressBar != null) {
      FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(-1, 20, 80);
      layoutParams1.setMargins(0, 0, 0, ((Integer)this.a.a(b.cP)).intValue());
      this.d.addView((View)paramProgressBar, (ViewGroup.LayoutParams)layoutParams1);
    } 
    if (paramImageView2 != null) {
      a a1 = (a)this.c;
      if (a1.aS()) {
        int i = AppLovinSdkUtils.dpToPx((Context)this.b, a1.aR().c());
        int j = AppLovinSdkUtils.dpToPx((Context)this.b, a1.aR().d());
        int k = AppLovinSdkUtils.dpToPx((Context)this.b, ((Integer)this.a.a(b.eS)).intValue());
        FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(i, j, 83);
        layoutParams1.setMargins(k, k, k, k);
        this.d.addView((View)paramImageView2, (ViewGroup.LayoutParams)layoutParams1);
      } 
    } 
    if (paramu != null)
      this.d.addView((View)paramu, (ViewGroup.LayoutParams)this.e); 
    if (paramViewGroup != null) {
      paramViewGroup.addView((View)this.d);
      return;
    } 
    this.b.setContentView((View)this.d);
  }
  
  public void a(m paramm, @Nullable u paramu, View paramView) {
    if (paramView != null)
      paramView.setVisibility(0); 
    com.applovin.impl.sdk.utils.c.a(this.d, paramView);
    if (paramm != null) {
      byte b;
      if (this.c.ab()) {
        b = 3;
      } else {
        b = 5;
      } 
      a(this.c.X(), b | 0x30, paramm);
    } 
    if (paramu != null)
      this.d.addView((View)paramu, (ViewGroup.LayoutParams)this.e); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\adview\activity\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */