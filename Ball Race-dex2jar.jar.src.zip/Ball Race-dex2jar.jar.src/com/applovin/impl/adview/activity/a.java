package com.applovin.impl.adview.activity;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.text.TextUtils;
import com.applovin.adview.AppLovinFullscreenActivity;
import com.applovin.impl.adview.activity.b.a;
import com.applovin.impl.adview.p;
import com.applovin.impl.sdk.ad.d;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.e.p;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdClickListener;
import com.applovin.sdk.AppLovinAdDisplayListener;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdVideoPlaybackListener;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONException;
import org.json.JSONObject;

public class a implements ServiceConnection {
  private final p a;
  
  private final y b;
  
  private final WeakReference<AppLovinFullscreenActivity> c;
  
  private final AtomicBoolean d = new AtomicBoolean();
  
  private Messenger e;
  
  public a(AppLovinFullscreenActivity paramAppLovinFullscreenActivity, p paramp) {
    this.a = paramp;
    this.b = paramp.L();
    this.c = new WeakReference<AppLovinFullscreenActivity>(paramAppLovinFullscreenActivity);
  }
  
  private void a() {
    AppLovinFullscreenActivity appLovinFullscreenActivity = this.c.get();
    if (appLovinFullscreenActivity != null) {
      y y2 = this.b;
      if (y.a())
        this.b.b("AppLovinFullscreenActivity", "Dismissing..."); 
      appLovinFullscreenActivity.dismiss();
      return;
    } 
    y y1 = this.b;
    if (y.a())
      this.b.e("AppLovinFullscreenActivity", "Unable to dismiss parent Activity"); 
  }
  
  private void a(com.applovin.impl.sdk.ad.b paramb, String paramString) {
    try {
      JSONObject jSONObject = new JSONObject(paramString);
      String str = JsonUtils.getString(jSONObject, "zone_id", "");
      if (!TextUtils.isEmpty(str)) {
        this.a.M().a((com.applovin.impl.sdk.e.a)new p(jSONObject, d.a(str), paramb, new AppLovinAdLoadListener(this) {
                public void adReceived(AppLovinAd param1AppLovinAd) {
                  AppLovinFullscreenActivity appLovinFullscreenActivity = a.a(this.a).get();
                  if (appLovinFullscreenActivity != null) {
                    a.b(this.a);
                    if (y.a())
                      a.b(this.a).b("AppLovinFullscreenActivity", "Presenting ad..."); 
                    a.a a1 = new a.a();
                    a.a((e)param1AppLovinAd, a1, a1, a1, null, a.c(this.a), (Activity)appLovinFullscreenActivity, new a.a(this, appLovinFullscreenActivity, param1AppLovinAd, a1) {
                          public void a(a param2a) {
                            this.a.setPresenter(param2a);
                            param2a.d();
                          }
                          
                          public void a(String param2String, Throwable param2Throwable) {
                            p.a((e)this.b, this.c, param2String, param2Throwable, this.a);
                          }
                        });
                    return;
                  } 
                  a.b(this.a);
                  if (y.a()) {
                    y y = a.b(this.a);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Unable to present ad, parent activity has been GC'd - ");
                    stringBuilder.append(param1AppLovinAd);
                    y.e("AppLovinFullscreenActivity", stringBuilder.toString());
                  } 
                }
                
                public void failedToReceiveAd(int param1Int) {
                  a.d(this.a);
                }
              }this.a));
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("No zone identifier found in ad response: ");
      stringBuilder.append(jSONObject);
      throw new IllegalStateException(stringBuilder.toString());
    } catch (JSONException jSONException) {
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to process ad: ");
        stringBuilder.append(paramString);
        y1.b("AppLovinFullscreenActivity", stringBuilder.toString(), (Throwable)jSONException);
      } 
      a();
      return;
    } 
  }
  
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    if (this.d.compareAndSet(false, true)) {
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fullscreen ad service connected to ");
        stringBuilder.append(paramComponentName);
        y1.b("AppLovinFullscreenActivity", stringBuilder.toString());
      } 
      this.e = new Messenger(paramIBinder);
      Message message = Message.obtain(null, FullscreenAdService.b.a.a());
      message.replyTo = new Messenger(new b(this));
      try {
        y y2 = this.b;
        if (y.a())
          this.b.b("AppLovinFullscreenActivity", "Requesting ad from FullscreenAdService..."); 
        this.e.send(message);
        return;
      } catch (RemoteException remoteException) {
        y y2 = this.b;
        if (y.a())
          this.b.b("AppLovinFullscreenActivity", "Failed to send ad request message to FullscreenAdService", (Throwable)remoteException); 
        a();
      } 
    } 
  }
  
  public void onServiceDisconnected(ComponentName paramComponentName) {
    if (this.d.compareAndSet(true, false)) {
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FullscreenAdService disconnected from ");
        stringBuilder.append(paramComponentName);
        y1.b("AppLovinFullscreenActivity", stringBuilder.toString());
      } 
    } 
  }
  
  private class a implements AppLovinAdClickListener, AppLovinAdDisplayListener, AppLovinAdVideoPlaybackListener {
    private a(a this$0) {}
    
    private void a(Bundle param1Bundle, FullscreenAdService.b param1b) {
      Message message = Message.obtain(null, param1b.a());
      if (param1Bundle != null)
        message.setData(param1Bundle); 
      try {
        a.e(this.a).send(message);
        return;
      } catch (RemoteException remoteException) {
        a.b(this.a);
        if (y.a()) {
          y y = a.b(this.a);
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to forward callback (");
          stringBuilder.append(param1b.a());
          stringBuilder.append(")");
          y.b("AppLovinFullscreenActivity", stringBuilder.toString(), (Throwable)remoteException);
        } 
        return;
      } 
    }
    
    private void a(FullscreenAdService.b param1b) {
      a(null, param1b);
    }
    
    public void adClicked(AppLovinAd param1AppLovinAd) {
      a(FullscreenAdService.b.c);
    }
    
    public void adDisplayed(AppLovinAd param1AppLovinAd) {
      a(FullscreenAdService.b.b);
    }
    
    public void adHidden(AppLovinAd param1AppLovinAd) {
      a(FullscreenAdService.b.f);
    }
    
    public void videoPlaybackBegan(AppLovinAd param1AppLovinAd) {
      a(FullscreenAdService.b.d);
    }
    
    public void videoPlaybackEnded(AppLovinAd param1AppLovinAd, double param1Double, boolean param1Boolean) {
      Bundle bundle = new Bundle();
      bundle.putDouble("percent_viewed", param1Double);
      bundle.putBoolean("fully_watched", param1Boolean);
      a(bundle, FullscreenAdService.b.e);
    }
  }
  
  private static class b extends Handler {
    private final WeakReference<a> a;
    
    private b(a param1a) {
      this.a = new WeakReference<a>(param1a);
    }
    
    public void handleMessage(Message param1Message) {
      if (param1Message.what == FullscreenAdService.b.a.a()) {
        a a = this.a.get();
        if (a != null) {
          String str = param1Message.getData().getString("raw_full_ad_response");
          a.a(a, com.applovin.impl.sdk.ad.b.a(param1Message.getData().getInt("ad_source")), str);
          return;
        } 
      } 
      super.handleMessage(param1Message);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\adview\activity\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */