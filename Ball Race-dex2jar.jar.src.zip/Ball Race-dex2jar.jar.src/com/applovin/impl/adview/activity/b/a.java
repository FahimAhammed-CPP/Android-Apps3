package com.applovin.impl.adview.activity.b;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.annotation.Nullable;
import com.applovin.adview.AppLovinAdView;
import com.applovin.impl.adview.d;
import com.applovin.impl.adview.i;
import com.applovin.impl.adview.m;
import com.applovin.impl.adview.n;
import com.applovin.impl.adview.o;
import com.applovin.impl.adview.p;
import com.applovin.impl.adview.u;
import com.applovin.impl.sdk.AppLovinBroadcastManager;
import com.applovin.impl.sdk.ad.AppLovinAdImpl;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.b.b;
import com.applovin.impl.sdk.d.d;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.e.v;
import com.applovin.impl.sdk.e.z;
import com.applovin.impl.sdk.k;
import com.applovin.impl.sdk.l;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.t;
import com.applovin.impl.sdk.utils.AppKilledService;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.utils.p;
import com.applovin.impl.sdk.utils.r;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdClickListener;
import com.applovin.sdk.AppLovinAdDisplayListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinAdType;
import com.applovin.sdk.AppLovinAdVideoPlaybackListener;
import com.applovin.sdk.AppLovinSdkUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class a implements AppLovinBroadcastManager.Receiver, b.a {
  private final AtomicBoolean A = new AtomicBoolean();
  
  private long B;
  
  private boolean C;
  
  private int D = 0;
  
  private final ArrayList<Long> E = new ArrayList<Long>();
  
  private final l F;
  
  private boolean G = false;
  
  protected final e a;
  
  protected final p b;
  
  protected final y c;
  
  protected final d d;
  
  protected Activity e;
  
  protected AppLovinAdView f;
  
  @Nullable
  protected u g;
  
  @Nullable
  protected final m h;
  
  protected final m i;
  
  protected final long j = SystemClock.elapsedRealtime();
  
  protected long k = -1L;
  
  protected boolean l;
  
  protected int m = 0;
  
  protected int n = 0;
  
  protected int o = k.a;
  
  protected boolean p;
  
  protected AppLovinAdClickListener q;
  
  protected AppLovinAdDisplayListener r;
  
  protected AppLovinAdVideoPlaybackListener s;
  
  protected final b t;
  
  @Nullable
  protected p u;
  
  private final Handler v = new Handler(Looper.getMainLooper());
  
  @Nullable
  private final com.applovin.impl.sdk.utils.a w;
  
  @Nullable
  private final AppLovinBroadcastManager.Receiver x;
  
  @Nullable
  private final k.a y;
  
  private final AtomicBoolean z = new AtomicBoolean();
  
  a(e parame, Activity paramActivity, @Nullable Map<String, Object> paramMap, p paramp, AppLovinAdClickListener paramAppLovinAdClickListener, AppLovinAdDisplayListener paramAppLovinAdDisplayListener, AppLovinAdVideoPlaybackListener paramAppLovinAdVideoPlaybackListener) {
    this.a = parame;
    this.b = paramp;
    this.c = paramp.L();
    this.e = paramActivity;
    this.q = paramAppLovinAdClickListener;
    this.r = paramAppLovinAdDisplayListener;
    this.s = paramAppLovinAdVideoPlaybackListener;
    this.t = new b(paramActivity, paramp);
    this.t.a(this);
    this.d = new d((AppLovinAdImpl)parame, paramp);
    this.F = new l(paramp);
    paramAppLovinAdClickListener = new b();
    if (((Boolean)paramp.a(com.applovin.impl.sdk.c.b.cU)).booleanValue())
      AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.render_process_gone")); 
    this.f = (AppLovinAdView)new n(paramp.K(), AppLovinAdSize.INTERSTITIAL, (Context)paramActivity);
    this.f.setAdClickListener(paramAppLovinAdClickListener);
    this.f.setAdDisplayListener(new AppLovinAdDisplayListener(this) {
          public void adDisplayed(AppLovinAd param1AppLovinAd) {
            y y = this.a.c;
            if (y.a())
              this.a.c.b("AppLovinFullscreenActivity", "Web content rendered"); 
          }
          
          public void adHidden(AppLovinAd param1AppLovinAd) {
            y y = this.a.c;
            if (y.a())
              this.a.c.b("AppLovinFullscreenActivity", "Closing from WebView"); 
            this.a.h();
          }
        });
    this.f.getController().a(this.d);
    if (((Boolean)paramp.a(com.applovin.impl.sdk.c.b.az)).booleanValue())
      this.g = new u(new o(paramMap, paramp), (Context)paramActivity); 
    paramp.E().trackImpression(parame);
    List list = parame.u();
    if (parame.t() >= 0L || list != null) {
      this.h = new m(parame.v(), paramActivity);
      this.h.setVisibility(8);
      this.h.setOnClickListener((View.OnClickListener)paramAppLovinAdClickListener);
    } else {
      this.h = null;
    } 
    this.i = new m(i.a.b, paramActivity);
    this.i.setOnClickListener(new View.OnClickListener(this) {
          public void onClick(View param1View) {
            this.a.h();
          }
        });
    if (((Boolean)paramp.a(com.applovin.impl.sdk.c.b.cE)).booleanValue()) {
      this.x = new AppLovinBroadcastManager.Receiver(this, paramp, parame) {
          public void onReceive(Intent param1Intent, @Nullable Map<String, Object> param1Map) {
            this.a.E().trackAppKilled(this.b);
            AppLovinBroadcastManager.unregisterReceiver(this);
          }
        };
    } else {
      this.x = null;
    } 
    if (parame.al()) {
      this.y = new k.a(this) {
          public void a(int param1Int) {
            if (this.a.o != k.a)
              this.a.p = true; 
            d d = this.a.f.getController().s();
            if (k.a(param1Int) && !k.a(this.a.o)) {
              d.a("javascript:al_muteSwitchOn();");
            } else if (param1Int == 2) {
              d.a("javascript:al_muteSwitchOff();");
            } 
            this.a.o = param1Int;
          }
        };
    } else {
      this.y = null;
    } 
    if (((Boolean)paramp.a(com.applovin.impl.sdk.c.b.fo)).booleanValue()) {
      this.w = new com.applovin.impl.sdk.utils.a(this) {
          public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
            if (!a.a(this.a).get()) {
              String str = Utils.retrieveLauncherActivityFullyQualifiedName(param1Activity.getApplicationContext());
              if (param1Activity.getClass().getName().equals(str))
                AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
                      public void run() {
                        y.i("AppLovinFullscreenActivity", "Dismissing on-screen ad due to app relaunched via launcher.");
                        try {
                          this.a.a.h();
                          return;
                        } catch (Throwable throwable) {
                          y.c("AppLovinFullscreenActivity", "Failed to dismiss ad.", throwable);
                          try {
                            this.a.a.n();
                            return;
                          } catch (Throwable throwable1) {
                            return;
                          } 
                        } 
                      }
                    }); 
            } 
          }
        };
      return;
    } 
    this.w = null;
  }
  
  public static void a(e parame, AppLovinAdClickListener paramAppLovinAdClickListener, AppLovinAdDisplayListener paramAppLovinAdDisplayListener, AppLovinAdVideoPlaybackListener paramAppLovinAdVideoPlaybackListener, @Nullable Map<String, Object> paramMap, p paramp, Activity paramActivity, a parama) {
    StringBuilder stringBuilder;
    boolean bool = parame.aJ();
    if (parame instanceof com.applovin.impl.c.a) {
      if (bool) {
        c c;
        try {
          c c1 = new c(parame, paramActivity, paramMap, paramp, paramAppLovinAdClickListener, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
          c = c1;
        } catch (Throwable throwable1) {
          paramp.L();
          if (y.a())
            paramp.L().a("AppLovinFullscreenActivity", "Failed to create ExoPlayer presenter to show the ad. Falling back to using native media player presenter.", throwable1); 
          try {
            d d1 = new d((e)c, paramActivity, paramMap, paramp, paramAppLovinAdClickListener, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
          } catch (Throwable null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to create FullscreenVastVideoAdPresenter with sdk: ");
            stringBuilder.append(paramp);
            stringBuilder.append(" and throwable: ");
            stringBuilder.append(throwable.getMessage());
            parama.a(stringBuilder.toString(), throwable);
            return;
          } 
        } 
      } else {
        try {
          d d1 = new d((e)throwable, paramActivity, paramMap, paramp, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
        } catch (Throwable null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to create FullscreenVastVideoAdPresenter with sdk: ");
          stringBuilder.append(paramp);
          stringBuilder.append(" and throwable: ");
          stringBuilder.append(throwable.getMessage());
          parama.a(stringBuilder.toString(), throwable);
          return;
        } 
      } 
    } else if (throwable.hasVideoUrl()) {
      if (throwable.aM()) {
        try {
          g g = new g((e)throwable, paramActivity, paramMap, paramp, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
        } catch (Throwable null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to create FullscreenWebVideoAdPresenter with sdk: ");
          stringBuilder.append(paramp);
          stringBuilder.append(" and throwable: ");
          stringBuilder.append(throwable1.getMessage());
          parama.a(stringBuilder.toString(), throwable1);
          return;
        } 
      } else if (bool) {
        e e1;
        try {
          e e2 = new e((e)throwable1, paramActivity, paramMap, paramp, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
          e1 = e2;
        } catch (Throwable throwable3) {
          paramp.L();
          if (y.a())
            paramp.L().a("AppLovinFullscreenActivity", "Failed to create ExoPlayer presenter to show the ad. Falling back to using native media player presenter.", throwable3); 
          try {
            f f = new f((e)e1, paramActivity, paramMap, paramp, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
          } catch (Throwable throwable2) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to create FullscreenVideoAdExoPlayerPresenter with sdk: ");
            stringBuilder.append(paramp);
            stringBuilder.append(" and throwable: ");
            stringBuilder.append(throwable2.getMessage());
            parama.a(stringBuilder.toString(), throwable2);
            return;
          } 
        } 
      } else {
        try {
          f f = new f((e)throwable2, paramActivity, paramMap, paramp, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
        } catch (Throwable throwable1) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to create FullscreenVideoAdPresenter with sdk: ");
          stringBuilder.append(paramp);
          stringBuilder.append(" and throwable: ");
          stringBuilder.append(throwable1.getMessage());
          parama.a(stringBuilder.toString(), throwable1);
          return;
        } 
      } 
    } else {
      try {
        b b1 = new b((e)throwable1, paramActivity, paramMap, paramp, (AppLovinAdClickListener)stringBuilder, paramAppLovinAdDisplayListener, paramAppLovinAdVideoPlaybackListener);
        b1.c();
        parama.a((a)b1);
        return;
      } catch (Throwable throwable) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to create FullscreenGraphicAdPresenter with sdk: ");
        stringBuilder.append(paramp);
        stringBuilder.append(" and throwable: ");
        stringBuilder.append(throwable.getMessage());
        parama.a(stringBuilder.toString(), throwable);
        return;
      } 
    } 
    throwable.c();
    parama.a((a)throwable);
  }
  
  private void c() {
    AppLovinBroadcastManager.Receiver receiver = this.x;
    if (receiver != null)
      AppLovinBroadcastManager.registerReceiver(receiver, new IntentFilter("com.applovin.app_killed")); 
    if (this.y != null)
      this.b.ad().a(this.y); 
    if (this.w != null)
      this.b.w().a(this.w); 
  }
  
  public void a(int paramInt, KeyEvent paramKeyEvent) {
    if (this.c != null && y.a()) {
      y y1 = this.c;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onKeyDown(int, KeyEvent) -  ");
      stringBuilder.append(paramInt);
      stringBuilder.append(", ");
      stringBuilder.append(paramKeyEvent);
      y1.c("AppLovinFullscreenActivity", stringBuilder.toString());
    } 
  }
  
  protected void a(int paramInt, boolean paramBoolean1, boolean paramBoolean2, long paramLong) {
    if (this.z.compareAndSet(false, true)) {
      if (this.a.hasVideoUrl() || t())
        k.a(this.s, (AppLovinAd)this.a, paramInt, paramBoolean2); 
      if (this.a.hasVideoUrl())
        this.d.c(paramInt); 
      long l2 = SystemClock.elapsedRealtime() - this.j;
      this.b.E().trackVideoEnd(this.a, TimeUnit.MILLISECONDS.toSeconds(l2), paramInt, paramBoolean1);
      long l3 = this.k;
      long l1 = -1L;
      if (l3 != -1L)
        l1 = SystemClock.elapsedRealtime() - this.k; 
      this.b.E().trackFullScreenAdClosed(this.a, l1, this.E, paramLong, this.p, this.o);
      y y1 = this.c;
      if (y.a()) {
        y1 = this.c;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Video ad ended at percent: ");
        stringBuilder.append(paramInt);
        stringBuilder.append("%, elapsedTime: ");
        stringBuilder.append(l2);
        stringBuilder.append("ms, skipTimeMillis: ");
        stringBuilder.append(paramLong);
        stringBuilder.append("ms, closeTimeMillis: ");
        stringBuilder.append(l1);
        stringBuilder.append("ms");
        y1.b("AppLovinFullscreenActivity", stringBuilder.toString());
      } 
    } 
  }
  
  public abstract void a(long paramLong);
  
  public void a(Configuration paramConfiguration) {
    y y1 = this.c;
    if (y.a()) {
      y1 = this.c;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onConfigurationChanged(Configuration) -  ");
      stringBuilder.append(paramConfiguration);
      y1.c("AppLovinFullscreenActivity", stringBuilder.toString());
    } 
  }
  
  public abstract void a(@Nullable ViewGroup paramViewGroup);
  
  protected void a(m paramm, long paramLong, Runnable paramRunnable) {
    if (paramLong >= ((Long)this.b.a(com.applovin.impl.sdk.c.b.cB)).longValue())
      return; 
    Runnable runnable = new Runnable(this, paramm, paramRunnable) {
        public void run() {
          AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
                public void run() {
                  r.a((View)this.a.a, 400L, new Runnable(this) {
                        public void run() {
                          this.a.a.a.bringToFront();
                          this.a.a.b.run();
                        }
                      });
                }
              });
        }
      };
    this.b.M().a((com.applovin.impl.sdk.e.a)new z(this.b, runnable), o.a.a, TimeUnit.SECONDS.toMillis(paramLong), true);
  }
  
  protected void a(Runnable paramRunnable, long paramLong) {
    AppLovinSdkUtils.runOnUiThreadDelayed(paramRunnable, paramLong, this.v);
  }
  
  protected void a(String paramString) {
    if (this.a.W())
      a(paramString, 0L); 
  }
  
  protected void a(String paramString, long paramLong) {
    if (paramLong >= 0L)
      a(new Runnable(this, paramString) {
            public void run() {
              if (StringUtils.isValidString(this.a) && this.b.f != null) {
                d d = this.b.f.getController().s();
                if (d != null)
                  d.a(this.a); 
              } 
            }
          }paramLong); 
  }
  
  protected void a(boolean paramBoolean) {
    List list = Utils.checkCachedResourcesExist(paramBoolean, this.a, this.b, (Context)this.e);
    if (!list.isEmpty()) {
      if (((Boolean)this.b.a(com.applovin.impl.sdk.c.b.ft)).booleanValue()) {
        y y2 = this.c;
        if (y.a()) {
          y2 = this.c;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Dismissing ad due to missing resources: ");
          stringBuilder.append(list);
          y2.e("AppLovinFullscreenActivity", stringBuilder.toString());
        } 
        p.a(this.a, this.r, "Missing ad resources", null, null);
        h();
        return;
      } 
      y y1 = this.c;
      if (y.a()) {
        y1 = this.c;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Streaming ad due to missing ad resources: ");
        stringBuilder.append(list);
        y1.e("AppLovinFullscreenActivity", stringBuilder.toString());
      } 
      this.a.a();
    } 
  }
  
  protected void a(boolean paramBoolean, long paramLong) {
    if (this.a.U()) {
      String str;
      if (paramBoolean) {
        str = "javascript:al_mute();";
      } else {
        str = "javascript:al_unmute();";
      } 
      a(str, paramLong);
    } 
  }
  
  protected void b(long paramLong) {
    y y1 = this.c;
    if (y.a()) {
      y1 = this.c;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Scheduling report reward in ");
      stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(paramLong));
      stringBuilder.append(" seconds...");
      y1.b("AppLovinFullscreenActivity", stringBuilder.toString());
    } 
    this.u = p.a(paramLong, this.b, new Runnable(this) {
          public void run() {
            if (!this.a.a.ag().getAndSet(true)) {
              v v = new v(this.a.a, this.a.b);
              this.a.b.M().a((com.applovin.impl.sdk.e.a)v, o.a.j);
            } 
          }
        });
  }
  
  protected void b(String paramString) {
    a(paramString, 0L);
  }
  
  protected void b(boolean paramBoolean) {
    a(paramBoolean, ((Long)this.b.a(com.applovin.impl.sdk.c.b.cR)).longValue());
    k.a(this.r, (AppLovinAd)this.a);
    this.b.Z().a(this.a);
    if (this.a.hasVideoUrl() || t())
      k.a(this.s, (AppLovinAd)this.a); 
    (new com.applovin.impl.adview.activity.b(this.e)).a(this.a);
    this.d.a();
    this.a.setHasShown(true);
  }
  
  public void c(boolean paramBoolean) {
    y y1 = this.c;
    if (y.a()) {
      y1 = this.c;
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("onWindowFocusChanged(boolean) - ");
      stringBuilder1.append(paramBoolean);
      y1.c("AppLovinFullscreenActivity", stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("javascript:al_onWindowFocusChanged( ");
    stringBuilder.append(paramBoolean);
    stringBuilder.append(" );");
    a(stringBuilder.toString());
  }
  
  public abstract void d();
  
  public abstract void e();
  
  public void f() {
    y y1 = this.c;
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "onResume()"); 
    this.d.d(SystemClock.elapsedRealtime() - this.B);
    a("javascript:al_onAppResumed();");
    q();
    if (this.t.c())
      this.t.a(); 
  }
  
  public void g() {
    y y1 = this.c;
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "onPause()"); 
    this.B = SystemClock.elapsedRealtime();
    a("javascript:al_onAppPaused();");
    if (this.t.c())
      this.t.a(); 
    p();
  }
  
  public void h() {
    this.C = true;
    y y1 = this.c;
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "dismiss()"); 
    e e1 = this.a;
    if (e1 != null)
      e1.o().e(); 
    this.v.removeCallbacksAndMessages(null);
    a("javascript:al_onPoststitialDismiss();", this.a.T());
    n();
    this.d.c();
    this.F.a();
    if (this.x != null)
      p.a(TimeUnit.SECONDS.toMillis(2L), this.b, new Runnable(this) {
            public void run() {
              Intent intent = new Intent(this.a.e.getApplicationContext(), AppKilledService.class);
              this.a.e.stopService(intent);
              AppLovinBroadcastManager.unregisterReceiver(a.b(this.a));
            }
          }); 
    if (this.y != null)
      this.b.ad().b(this.y); 
    if (this.w != null)
      this.b.w().b(this.w); 
    if (o()) {
      this.e.finish();
      return;
    } 
    this.b.L();
    if (y.a())
      this.b.L().b("AppLovinFullscreenActivity", "Fullscreen ad shown in container view dismissed, destroying the presenter."); 
    k();
  }
  
  public boolean i() {
    return this.C;
  }
  
  public void j() {
    y y1 = this.c;
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "onStop()"); 
  }
  
  public void k() {
    AppLovinAdView appLovinAdView = this.f;
    if (appLovinAdView != null) {
      ViewParent viewParent = appLovinAdView.getParent();
      this.f.destroy();
      this.f = null;
      if (viewParent instanceof ViewGroup && o())
        ((ViewGroup)viewParent).removeAllViews(); 
    } 
    m();
    n();
    this.q = null;
    this.r = null;
    this.s = null;
    this.e = null;
    AppLovinBroadcastManager.unregisterReceiver(this);
  }
  
  public void l() {
    y y1 = this.c;
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "onBackPressed()"); 
    if (this.G)
      h(); 
    if (this.a.V())
      b("javascript:onBackPressed();"); 
  }
  
  protected abstract void m();
  
  protected void n() {
    if (this.A.compareAndSet(false, true)) {
      k.b(this.r, (AppLovinAd)this.a);
      this.b.Z().b(this.a);
    } 
  }
  
  protected boolean o() {
    return this.e instanceof com.applovin.adview.AppLovinFullscreenActivity;
  }
  
  public void onReceive(Intent paramIntent, @Nullable Map<String, Object> paramMap) {
    if ("com.applovin.render_process_gone".equals(paramIntent.getAction()) && !this.l)
      w(); 
  }
  
  protected void p() {
    p p1 = this.u;
    if (p1 != null)
      p1.b(); 
  }
  
  protected void q() {
    p p1 = this.u;
    if (p1 != null)
      p1.c(); 
  }
  
  protected abstract boolean r();
  
  protected abstract boolean s();
  
  protected boolean t() {
    return (AppLovinAdType.INCENTIVIZED == this.a.getType() || AppLovinAdType.AUTO_INCENTIVIZED == this.a.getType());
  }
  
  protected abstract void u();
  
  protected void v() {
    AppLovinAdView appLovinAdView = this.f;
    if (appLovinAdView == null)
      return; 
    d d1 = appLovinAdView.getController().s();
    if (d1 == null)
      return; 
    this.F.a((View)d1, new l.a(this) {
          public void a(View param1View) {
            this.a.b.aj().a(t.a.a, CollectionUtils.map("clcode", this.a.a.getClCode()));
            if (((Boolean)this.a.b.a(com.applovin.impl.sdk.c.b.fK)).booleanValue()) {
              this.a.h();
              return;
            } 
            a a1 = this.a;
            a.a(a1, ((Boolean)a1.b.a(com.applovin.impl.sdk.c.b.fL)).booleanValue());
            if (((Boolean)this.a.b.a(com.applovin.impl.sdk.c.b.fM)).booleanValue() && this.a.h != null)
              this.a.h.setVisibility(0); 
          }
        });
  }
  
  public void w() {
    y y1 = this.c;
    if (y.a())
      this.c.c("AppLovinFullscreenActivity", "Handling render process crash"); 
    this.l = true;
  }
  
  public static interface a {
    void a(a param1a);
    
    void a(String param1String, Throwable param1Throwable);
  }
  
  private class b implements View.OnClickListener, AppLovinAdClickListener {
    private b(a this$0) {}
    
    public void adClicked(AppLovinAd param1AppLovinAd) {
      y y = this.a.c;
      if (y.a())
        this.a.c.b("AppLovinFullscreenActivity", "Clicking through graphic"); 
      k.a(this.a.q, param1AppLovinAd);
      this.a.d.b();
      a a1 = this.a;
      a1.n++;
    }
    
    public void onClick(View param1View) {
      List<Integer> list;
      if (param1View == this.a.h && ((Boolean)this.a.b.a(com.applovin.impl.sdk.c.b.cC)).booleanValue()) {
        a.c(this.a);
        if (this.a.a.V()) {
          a a2 = this.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("javascript:al_onCloseButtonTapped(");
          stringBuilder.append(a.d(this.a));
          stringBuilder.append(",");
          stringBuilder.append(this.a.m);
          stringBuilder.append(",");
          stringBuilder.append(this.a.n);
          stringBuilder.append(");");
          a2.b(stringBuilder.toString());
        } 
        list = this.a.a.u();
        y y2 = this.a.c;
        if (y.a()) {
          y2 = this.a.c;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Handling close button tap ");
          stringBuilder.append(a.d(this.a));
          stringBuilder.append(" with multi close delay: ");
          stringBuilder.append(list);
          y2.b("AppLovinFullscreenActivity", stringBuilder.toString());
        } 
        if (list == null || list.size() <= a.d(this.a)) {
          this.a.h();
          return;
        } 
        a.e(this.a).add(Long.valueOf(SystemClock.elapsedRealtime() - this.a.k));
        List<i.a> list1 = this.a.a.w();
        if (list1 != null && list1.size() > a.d(this.a))
          this.a.h.a(list1.get(a.d(this.a))); 
        y y1 = this.a.c;
        if (y.a()) {
          y1 = this.a.c;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Scheduling next close button with delay: ");
          stringBuilder.append(list.get(a.d(this.a)));
          y1.b("AppLovinFullscreenActivity", stringBuilder.toString());
        } 
        this.a.h.setVisibility(8);
        a a1 = this.a;
        a1.a(a1.h, ((Integer)list.get(a.d(this.a))).intValue(), new Runnable(this) {
              public void run() {
                this.a.a.k = SystemClock.elapsedRealtime();
              }
            });
        return;
      } 
      y y = this.a.c;
      if (y.a()) {
        y = this.a.c;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unhandled click on widget: ");
        stringBuilder.append(list);
        y.e("AppLovinFullscreenActivity", stringBuilder.toString());
      } 
    }
  }
  
  class null implements Runnable {
    null(a this$0) {}
    
    public void run() {
      this.a.a.k = SystemClock.elapsedRealtime();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\adview\activity\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */