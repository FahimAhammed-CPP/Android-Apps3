package com.applovin.impl.adview;

import android.os.Handler;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.y;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public final class j {
  private final y a;
  
  private final Handler b;
  
  private final Set<b> c = new HashSet<b>();
  
  private final AtomicInteger d = new AtomicInteger();
  
  public j(Handler paramHandler, p paramp) {
    if (paramHandler != null) {
      if (paramp != null) {
        this.b = paramHandler;
        this.a = paramp.L();
        return;
      } 
      throw new IllegalArgumentException("No sdk specified.");
    } 
    throw new IllegalArgumentException("No handler specified.");
  }
  
  private void a(b paramb, int paramInt) {
    this.b.postDelayed(new Runnable(this, paramb, paramInt) {
          public void run() {
            j.a a = j.b.b(this.a);
            if (a.b()) {
              if (j.a(this.c).get() == this.b)
                try {
                  a.a();
                  j.a(this.c, this.a, this.b);
                  return;
                } catch (Throwable throwable) {
                  j.b(this.c);
                  if (y.a()) {
                    y y = j.b(this.c);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Encountered error on countdown step for: ");
                    stringBuilder.append(j.b.a(this.a));
                    y.b("CountdownManager", stringBuilder.toString(), throwable);
                  } 
                  this.c.b();
                  return;
                }  
              j.b(this.c);
              if (y.a()) {
                y y = j.b(this.c);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Killing duplicate countdown from previous generation: ");
                stringBuilder.append(j.b.a(this.a));
                y.d("CountdownManager", stringBuilder.toString());
                return;
              } 
            } else {
              j.b(this.c);
              if (y.a()) {
                y y = j.b(this.c);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Ending countdown for ");
                stringBuilder.append(j.b.a(this.a));
                y.b("CountdownManager", stringBuilder.toString());
              } 
            } 
          }
        }b.c(paramb));
  }
  
  public void a() {
    HashSet<b> hashSet = new HashSet<b>(this.c);
    y y1 = this.a;
    if (y.a()) {
      y1 = this.a;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Starting ");
      stringBuilder.append(hashSet.size());
      stringBuilder.append(" countdowns...");
      y1.b("CountdownManager", stringBuilder.toString());
    } 
    int i = this.d.incrementAndGet();
    for (b b : hashSet) {
      y y2 = this.a;
      if (y.a()) {
        y2 = this.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Starting countdown: ");
        stringBuilder.append(b.a(b));
        stringBuilder.append(" for generation ");
        stringBuilder.append(i);
        stringBuilder.append("...");
        y2.b("CountdownManager", stringBuilder.toString());
      } 
      a(b, i);
    } 
  }
  
  public void a(String paramString, long paramLong, a parama) {
    if (paramLong > 0L) {
      if (this.b != null) {
        y y1 = this.a;
        if (y.a()) {
          y1 = this.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Adding countdown: ");
          stringBuilder.append(paramString);
          y1.b("CountdownManager", stringBuilder.toString());
        } 
        b b = new b(paramString, paramLong, parama);
        this.c.add(b);
        return;
      } 
      throw new IllegalArgumentException("No handler specified.");
    } 
    throw new IllegalArgumentException("Invalid step specified.");
  }
  
  public void b() {
    y y1 = this.a;
    if (y.a())
      this.a.b("CountdownManager", "Removing all countdowns..."); 
    c();
    this.c.clear();
  }
  
  public void c() {
    y y1 = this.a;
    if (y.a())
      this.a.b("CountdownManager", "Stopping countdowns..."); 
    this.d.incrementAndGet();
    this.b.removeCallbacksAndMessages(null);
  }
  
  public static interface a {
    void a();
    
    boolean b();
  }
  
  private static class b {
    private final String a;
    
    private final j.a b;
    
    private final long c;
    
    private b(String param1String, long param1Long, j.a param1a) {
      this.a = param1String;
      this.c = param1Long;
      this.b = param1a;
    }
    
    private String a() {
      return this.a;
    }
    
    private long b() {
      return this.c;
    }
    
    private j.a c() {
      return this.b;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      param1Object = param1Object;
      String str = this.a;
      return (str != null) ? str.equalsIgnoreCase(((b)param1Object).a) : ((((b)param1Object).a == null));
    }
    
    public int hashCode() {
      String str = this.a;
      return (str != null) ? str.hashCode() : 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("CountdownProxy{identifier='");
      stringBuilder.append(this.a);
      stringBuilder.append('\'');
      stringBuilder.append(", countdownStepMillis=");
      stringBuilder.append(this.c);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\adview\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */