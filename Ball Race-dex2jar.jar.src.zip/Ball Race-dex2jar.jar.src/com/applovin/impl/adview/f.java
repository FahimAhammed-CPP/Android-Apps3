package com.applovin.impl.adview;

import android.annotation.TargetApi;
import android.webkit.WebView;
import android.webkit.WebViewRenderProcess;
import android.webkit.WebViewRenderProcessClient;
import com.applovin.impl.sdk.AppLovinAdBase;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.d.b;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.y;

@TargetApi(29)
class f {
  private final p a;
  
  private final WebViewRenderProcessClient b = new WebViewRenderProcessClient(this) {
      public void onRenderProcessResponsive(WebView param1WebView, WebViewRenderProcess param1WebViewRenderProcess) {}
      
      public void onRenderProcessUnresponsive(WebView param1WebView, WebViewRenderProcess param1WebViewRenderProcess) {
        if (param1WebView instanceof d) {
          e e = ((d)param1WebView).getCurrentAd();
          f.a(this.a).X().a((AppLovinAdBase)e).a(b.C).a();
          f.a(this.a).L();
          if (y.a()) {
            y y = f.a(this.a).L();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("WebView render process unresponsive for ad: ");
            stringBuilder.append(e);
            y.e("AdWebViewRenderProcessClient", stringBuilder.toString());
          } 
        } 
      }
    };
  
  f(p paramp) {
    this.a = paramp;
  }
  
  WebViewRenderProcessClient a() {
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\adview\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */