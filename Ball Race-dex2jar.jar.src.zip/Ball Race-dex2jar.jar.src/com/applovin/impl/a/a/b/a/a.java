package com.applovin.impl.a.a.b.a;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.applovin.creative.MaxCreativeDebuggerDisplayedAdActivity;
import com.applovin.impl.mediation.debugger.ui.d.c;
import com.applovin.impl.mediation.debugger.ui.d.d;
import com.applovin.impl.sdk.utils.b;
import com.applovin.sdk.R;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;

public class a extends Activity {
  private b a;
  
  private FrameLayout b;
  
  private ListView c;
  
  private void a(int paramInt) {
    TextView textView = new TextView((Context)this);
    textView.setGravity(17);
    textView.setTextSize(18.0F);
    textView.setText(paramInt);
    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1, 17);
    this.b.addView((View)textView, (ViewGroup.LayoutParams)layoutParams);
    this.b.bringChildToFront((View)textView);
  }
  
  public void a(b paramb, com.applovin.impl.sdk.a parama) {
    this.a = paramb;
    this.a.a(new d.a(this, parama) {
          public void a(com.applovin.impl.mediation.debugger.ui.d.a param1a, c param1c) {
            if (param1a.a() != b.a.a.ordinal())
              return; 
            b.a((Context)this.b, MaxCreativeDebuggerDisplayedAdActivity.class, this.a, new b.a<MaxCreativeDebuggerDisplayedAdActivity>(this, param1a) {
                  public void a(MaxCreativeDebuggerDisplayedAdActivity param2MaxCreativeDebuggerDisplayedAdActivity) {
                    param2MaxCreativeDebuggerDisplayedAdActivity.a(a.a(this.b.b).d().get(this.a.b()), a.a(this.b.b).c());
                  }
                });
          }
        });
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.activityOnTouch("com.applovin", paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setTitle("MAX Creative Debugger");
    setContentView(R.layout.mediation_debugger_list_view);
    this.b = (FrameLayout)findViewById(16908290);
    this.c = (ListView)findViewById(R.id.listView);
  }
  
  protected void onDestroy() {
    super.onDestroy();
    b b1 = this.a;
    if (b1 != null) {
      b1.a((d.a)null);
      this.a.a();
    } 
  }
  
  protected void onStart() {
    super.onStart();
    this.c.setAdapter((ListAdapter)this.a);
    b b1 = this.a;
    if (b1 != null && !b1.c().af().c()) {
      a(R.string.applovin_creative_debugger_disabled_text);
      return;
    } 
    b1 = this.a;
    if (b1 != null && b1.b())
      a(R.string.applovin_creative_debugger_no_ads_text); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\a\a\b\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */