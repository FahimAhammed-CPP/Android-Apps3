package com.applovin.impl.c;

import android.annotation.TargetApi;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.t;
import com.applovin.impl.sdk.y;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class n {
  private List<o> a = Collections.emptyList();
  
  private List<String> b = Collections.emptyList();
  
  private int c;
  
  private Uri d;
  
  private final Set<k> e = new HashSet<k>();
  
  private g f;
  
  private final Map<String, Set<k>> g = CollectionUtils.map();
  
  private n() {}
  
  private n(e parame) {
    this.b = parame.g();
  }
  
  private static int a(String paramString, p paramp) {
    try {
      List<String> list = CollectionUtils.explode(paramString, ":");
      if (list.size() == 3) {
        int i = StringUtils.parseInt(list.get(0));
        int j = StringUtils.parseInt(list.get(1));
        int k = StringUtils.parseInt(list.get(2));
        long l1 = TimeUnit.HOURS.toSeconds(i);
        long l2 = TimeUnit.MINUTES.toSeconds(j);
        return (int)(l1 + l2 + k);
      } 
    } catch (Throwable throwable) {
      paramp.L();
      if (y.a()) {
        y y = paramp.L();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to parse duration from \"");
        stringBuilder.append(paramString);
        stringBuilder.append("\"");
        y.e("VastVideoCreative", stringBuilder.toString());
      } 
    } 
    return 0;
  }
  
  public static n a(t paramt, n paramn, e parame, p paramp) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 370
    //   4: aload_2
    //   5: ifnull -> 360
    //   8: aload_3
    //   9: ifnull -> 350
    //   12: aload_1
    //   13: ifnull -> 19
    //   16: goto -> 28
    //   19: new com/applovin/impl/c/n
    //   22: dup
    //   23: aload_2
    //   24: invokespecial <init> : (Lcom/applovin/impl/c/e;)V
    //   27: astore_1
    //   28: aload_1
    //   29: getfield c : I
    //   32: ifne -> 70
    //   35: aload_0
    //   36: ldc 'Duration'
    //   38: invokevirtual b : (Ljava/lang/String;)Lcom/applovin/impl/sdk/utils/t;
    //   41: astore #5
    //   43: aload #5
    //   45: ifnull -> 70
    //   48: aload #5
    //   50: invokevirtual c : ()Ljava/lang/String;
    //   53: aload_3
    //   54: invokestatic a : (Ljava/lang/String;Lcom/applovin/impl/sdk/p;)I
    //   57: istore #4
    //   59: iload #4
    //   61: ifle -> 70
    //   64: aload_1
    //   65: iload #4
    //   67: putfield c : I
    //   70: aload_0
    //   71: ldc 'MediaFiles'
    //   73: invokevirtual b : (Ljava/lang/String;)Lcom/applovin/impl/sdk/utils/t;
    //   76: astore #5
    //   78: aload #5
    //   80: ifnull -> 131
    //   83: aload #5
    //   85: aload_3
    //   86: invokestatic a : (Lcom/applovin/impl/sdk/utils/t;Lcom/applovin/impl/sdk/p;)Ljava/util/List;
    //   89: astore #5
    //   91: aload #5
    //   93: ifnull -> 131
    //   96: aload #5
    //   98: invokeinterface size : ()I
    //   103: ifle -> 131
    //   106: aload_1
    //   107: getfield a : Ljava/util/List;
    //   110: ifnull -> 125
    //   113: aload #5
    //   115: aload_1
    //   116: getfield a : Ljava/util/List;
    //   119: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   124: pop
    //   125: aload_1
    //   126: aload #5
    //   128: putfield a : Ljava/util/List;
    //   131: aload_0
    //   132: ldc 'VideoClicks'
    //   134: invokevirtual b : (Ljava/lang/String;)Lcom/applovin/impl/sdk/utils/t;
    //   137: astore #5
    //   139: aload #5
    //   141: ifnull -> 205
    //   144: aload_1
    //   145: getfield d : Landroid/net/Uri;
    //   148: ifnonnull -> 189
    //   151: aload #5
    //   153: ldc 'ClickThrough'
    //   155: invokevirtual b : (Ljava/lang/String;)Lcom/applovin/impl/sdk/utils/t;
    //   158: astore #6
    //   160: aload #6
    //   162: ifnull -> 189
    //   165: aload #6
    //   167: invokevirtual c : ()Ljava/lang/String;
    //   170: astore #6
    //   172: aload #6
    //   174: invokestatic isValidString : (Ljava/lang/String;)Z
    //   177: ifeq -> 189
    //   180: aload_1
    //   181: aload #6
    //   183: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   186: putfield d : Landroid/net/Uri;
    //   189: aload #5
    //   191: ldc 'ClickTracking'
    //   193: invokevirtual a : (Ljava/lang/String;)Ljava/util/List;
    //   196: aload_1
    //   197: getfield e : Ljava/util/Set;
    //   200: aload_2
    //   201: aload_3
    //   202: invokestatic a : (Ljava/util/List;Ljava/util/Set;Lcom/applovin/impl/c/e;Lcom/applovin/impl/sdk/p;)V
    //   205: aload_0
    //   206: ldc 'Icons'
    //   208: invokevirtual b : (Ljava/lang/String;)Lcom/applovin/impl/sdk/utils/t;
    //   211: astore #5
    //   213: aload #5
    //   215: ifnull -> 312
    //   218: aload #5
    //   220: ldc 'Icon'
    //   222: invokevirtual b : (Ljava/lang/String;)Lcom/applovin/impl/sdk/utils/t;
    //   225: astore #6
    //   227: aload #6
    //   229: aload_3
    //   230: invokestatic a : (Lcom/applovin/impl/sdk/utils/t;Lcom/applovin/impl/sdk/p;)Lcom/applovin/impl/c/g;
    //   233: astore #5
    //   235: aload #5
    //   237: ifnull -> 312
    //   240: aload #6
    //   242: ldc 'IconClicks'
    //   244: invokevirtual b : (Ljava/lang/String;)Lcom/applovin/impl/sdk/utils/t;
    //   247: astore #7
    //   249: aload #7
    //   251: ifnull -> 280
    //   254: aload #7
    //   256: ldc 'IconClickTracking'
    //   258: invokevirtual a : (Ljava/lang/String;)Ljava/util/List;
    //   261: astore #7
    //   263: aload #7
    //   265: ifnull -> 280
    //   268: aload #7
    //   270: aload #5
    //   272: getfield a : Ljava/util/Set;
    //   275: aload_2
    //   276: aload_3
    //   277: invokestatic a : (Ljava/util/List;Ljava/util/Set;Lcom/applovin/impl/c/e;Lcom/applovin/impl/sdk/p;)V
    //   280: aload #6
    //   282: ldc 'IconViewTracking'
    //   284: invokevirtual a : (Ljava/lang/String;)Ljava/util/List;
    //   287: astore #6
    //   289: aload #6
    //   291: ifnull -> 306
    //   294: aload #6
    //   296: aload #5
    //   298: getfield b : Ljava/util/Set;
    //   301: aload_2
    //   302: aload_3
    //   303: invokestatic a : (Ljava/util/List;Ljava/util/Set;Lcom/applovin/impl/c/e;Lcom/applovin/impl/sdk/p;)V
    //   306: aload_1
    //   307: aload #5
    //   309: putfield f : Lcom/applovin/impl/c/g;
    //   312: aload_0
    //   313: aload_1
    //   314: getfield g : Ljava/util/Map;
    //   317: aload_2
    //   318: aload_3
    //   319: invokestatic a : (Lcom/applovin/impl/sdk/utils/t;Ljava/util/Map;Lcom/applovin/impl/c/e;Lcom/applovin/impl/sdk/p;)V
    //   322: aload_1
    //   323: areturn
    //   324: astore_0
    //   325: aload_3
    //   326: invokevirtual L : ()Lcom/applovin/impl/sdk/y;
    //   329: pop
    //   330: invokestatic a : ()Z
    //   333: ifeq -> 348
    //   336: aload_3
    //   337: invokevirtual L : ()Lcom/applovin/impl/sdk/y;
    //   340: ldc 'VastVideoCreative'
    //   342: ldc 'Error occurred while initializing'
    //   344: aload_0
    //   345: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   348: aconst_null
    //   349: areturn
    //   350: new java/lang/IllegalArgumentException
    //   353: dup
    //   354: ldc 'No sdk specified.'
    //   356: invokespecial <init> : (Ljava/lang/String;)V
    //   359: athrow
    //   360: new java/lang/IllegalArgumentException
    //   363: dup
    //   364: ldc 'No context specified.'
    //   366: invokespecial <init> : (Ljava/lang/String;)V
    //   369: athrow
    //   370: new java/lang/IllegalArgumentException
    //   373: dup
    //   374: ldc 'No node specified.'
    //   376: invokespecial <init> : (Ljava/lang/String;)V
    //   379: athrow
    // Exception table:
    //   from	to	target	type
    //   19	28	324	java/lang/Throwable
    //   28	43	324	java/lang/Throwable
    //   48	59	324	java/lang/Throwable
    //   64	70	324	java/lang/Throwable
    //   70	78	324	java/lang/Throwable
    //   83	91	324	java/lang/Throwable
    //   96	125	324	java/lang/Throwable
    //   125	131	324	java/lang/Throwable
    //   131	139	324	java/lang/Throwable
    //   144	160	324	java/lang/Throwable
    //   165	189	324	java/lang/Throwable
    //   189	205	324	java/lang/Throwable
    //   205	213	324	java/lang/Throwable
    //   218	235	324	java/lang/Throwable
    //   240	249	324	java/lang/Throwable
    //   254	263	324	java/lang/Throwable
    //   268	280	324	java/lang/Throwable
    //   280	289	324	java/lang/Throwable
    //   294	306	324	java/lang/Throwable
    //   306	312	324	java/lang/Throwable
    //   312	322	324	java/lang/Throwable
  }
  
  private static List<o> a(t paramt, p paramp) {
    List list3 = paramt.a("MediaFile");
    ArrayList<o> arrayList = new ArrayList(list3.size());
    List list1 = CollectionUtils.explode((String)paramp.a(b.eM));
    List list2 = CollectionUtils.explode((String)paramp.a(b.eL));
    Iterator<t> iterator = list3.iterator();
    while (iterator.hasNext()) {
      o o = o.a(iterator.next(), paramp);
      if (o == null)
        continue; 
      try {
        String str = o.c();
        if (StringUtils.isValidString(str) && !list1.contains(str)) {
          arrayList.add(o);
          continue;
        } 
        if (((Boolean)paramp.a(b.eN)).booleanValue()) {
          str = MimeTypeMap.getFileExtensionFromUrl(o.b().toString());
          if (StringUtils.isValidString(str) && !list2.contains(str)) {
            arrayList.add(o);
            continue;
          } 
        } 
        paramp.L();
        if (y.a()) {
          y y = paramp.L();
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Video file not supported: ");
          stringBuilder.append(o);
          y.d("VastVideoCreative", stringBuilder.toString());
        } 
      } catch (Throwable throwable) {
        paramp.L();
        if (y.a()) {
          y y = paramp.L();
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to validate video file: ");
          stringBuilder.append(o);
          y.b("VastVideoCreative", stringBuilder.toString(), throwable);
        } 
      } 
    } 
    return arrayList;
  }
  
  public o a(a parama) {
    List<o> list = this.a;
    if (list == null || list.size() == 0)
      return null; 
    list = new ArrayList<o>(3);
    for (String str : this.b) {
      for (o o : this.a) {
        String str1 = o.c();
        if (StringUtils.isValidString(str1) && str.equalsIgnoreCase(str1))
          list.add(o); 
      } 
      if (!list.isEmpty())
        break; 
    } 
    if (list.isEmpty())
      list = this.a; 
    if (h.c())
      Collections.sort(list, new Comparator<o>(this) {
            @TargetApi(19)
            public int a(o param1o1, o param1o2) {
              return Integer.compare(param1o1.d(), param1o2.d());
            }
          }); 
    return (parama == a.b) ? list.get(0) : ((parama == a.c) ? list.get(list.size() / 2) : list.get(list.size() - 1));
  }
  
  public List<o> a() {
    return this.a;
  }
  
  public int b() {
    return this.c;
  }
  
  public Uri c() {
    return this.d;
  }
  
  public Set<k> d() {
    return this.e;
  }
  
  public Map<String, Set<k>> e() {
    return this.g;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof n))
      return false; 
    paramObject = paramObject;
    if (this.c != ((n)paramObject).c)
      return false; 
    List<o> list = this.a;
    if (list != null) {
      if (!list.equals(((n)paramObject).a))
        return false; 
    } else if (((n)paramObject).a != null) {
      return false;
    } 
    Uri uri = this.d;
    if (uri != null) {
      if (!uri.equals(((n)paramObject).d))
        return false; 
    } else if (((n)paramObject).d != null) {
      return false;
    } 
    Set<k> set = this.e;
    if (set != null) {
      if (!set.equals(((n)paramObject).e))
        return false; 
    } else if (((n)paramObject).e != null) {
      return false;
    } 
    Map<String, Set<k>> map = this.g;
    return (map != null) ? map.equals(((n)paramObject).g) : ((((n)paramObject).g == null));
  }
  
  @Nullable
  public g f() {
    return this.f;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    List<o> list = this.a;
    int i = 0;
    if (list != null) {
      b1 = list.hashCode();
    } else {
      b1 = 0;
    } 
    int j = this.c;
    Uri uri = this.d;
    if (uri != null) {
      b2 = uri.hashCode();
    } else {
      b2 = 0;
    } 
    Set<k> set = this.e;
    if (set != null) {
      b3 = set.hashCode();
    } else {
      b3 = 0;
    } 
    Map<String, Set<k>> map = this.g;
    if (map != null)
      i = map.hashCode(); 
    return (((b1 * 31 + j) * 31 + b2) * 31 + b3) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("VastVideoCreative{videoFiles=");
    stringBuilder.append(this.a);
    stringBuilder.append(", durationSeconds=");
    stringBuilder.append(this.c);
    stringBuilder.append(", destinationUri=");
    stringBuilder.append(this.d);
    stringBuilder.append(", clickTrackers=");
    stringBuilder.append(this.e);
    stringBuilder.append(", eventTrackers=");
    stringBuilder.append(this.g);
    stringBuilder.append(", industryIcon=");
    stringBuilder.append(this.f);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public enum a {
    a, b, c, d;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\c\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */