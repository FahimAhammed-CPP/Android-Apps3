package com.applovin.impl.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import com.applovin.impl.mediation.MaxErrorImpl;
import com.applovin.impl.mediation.f;
import com.applovin.impl.mediation.k;
import com.applovin.impl.sdk.ad.g;
import com.applovin.impl.sdk.b;
import com.applovin.impl.sdk.d;
import com.applovin.impl.sdk.g;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.i;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.sdk.AppLovinSdkUtils;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;

public class MaxFullscreenAdImpl extends a implements b.a, d.a, g.a {
  private final a a;
  
  private final b b;
  
  private final com.applovin.impl.mediation.b c;
  
  private final Object d = new Object();
  
  private com.applovin.impl.mediation.a.c e = null;
  
  private c f = c.a;
  
  private final AtomicBoolean g = new AtomicBoolean();
  
  private boolean h;
  
  private boolean i;
  
  private WeakReference<Activity> j = new WeakReference<Activity>(null);
  
  private WeakReference<ViewGroup> k = new WeakReference<ViewGroup>(null);
  
  private WeakReference<Lifecycle> l = new WeakReference<Lifecycle>(null);
  
  protected final b listenerWrapper;
  
  public MaxFullscreenAdImpl(String paramString1, MaxAdFormat paramMaxAdFormat, a parama, String paramString2, p paramp) {
    super(paramString1, paramMaxAdFormat, paramString2, paramp);
    this.a = parama;
    this.listenerWrapper = new b();
    this.c = new com.applovin.impl.mediation.b(paramp, this.listenerWrapper);
    if (paramp.V() != null) {
      this.b = null;
    } else {
      this.b = new b(paramp, this);
    } 
    paramp.am().a(this);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Created new ");
    stringBuilder.append(paramString2);
    stringBuilder.append(" (");
    stringBuilder.append(this);
    stringBuilder.append(")");
    y.f(paramString2, stringBuilder.toString());
  }
  
  private void a() {
    Activity activity = this.j.get();
    if (activity == null)
      activity = this.sdk.x(); 
    if (this.h) {
      showAd(this.e.getPlacement(), this.e.am(), this.k.get(), this.l.get(), activity);
      return;
    } 
    showAd(this.e.getPlacement(), this.e.am(), activity);
  }
  
  private void a(com.applovin.impl.mediation.a.c paramc) {
    boolean bool;
    if (this.sdk.V() != null) {
      bool = this.sdk.V().a((g)paramc, this);
    } else {
      bool = this.b.a((com.applovin.impl.mediation.a.a)paramc);
    } 
    if (bool) {
      y y1 = this.logger;
      if (y.a()) {
        y1 = this.logger;
        String str = this.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Handle ad loaded for regular ad: ");
        stringBuilder.append(paramc);
        y1.b(str, stringBuilder.toString());
      } 
      this.e = paramc;
      return;
    } 
    y y = this.logger;
    if (y.a())
      this.logger.b(this.tag, "Loaded an expired ad, running expire logic..."); 
    onAdExpired((g)paramc);
  }
  
  private void a(c paramc, Runnable paramRunnable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   4: astore #6
    //   6: aload_0
    //   7: getfield d : Ljava/lang/Object;
    //   10: astore #5
    //   12: aload #5
    //   14: monitorenter
    //   15: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   18: astore #7
    //   20: iconst_0
    //   21: istore #4
    //   23: aload #6
    //   25: aload #7
    //   27: if_acmpne -> 141
    //   30: aload_1
    //   31: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   34: if_acmpne -> 40
    //   37: goto -> 944
    //   40: aload_1
    //   41: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   44: if_acmpne -> 50
    //   47: goto -> 944
    //   50: aload_1
    //   51: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   54: if_acmpne -> 72
    //   57: aload_0
    //   58: getfield tag : Ljava/lang/String;
    //   61: ldc 'No ad is loading or loaded'
    //   63: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   66: iload #4
    //   68: istore_3
    //   69: goto -> 739
    //   72: aload_0
    //   73: getfield logger : Lcom/applovin/impl/sdk/y;
    //   76: astore #6
    //   78: iload #4
    //   80: istore_3
    //   81: invokestatic a : ()Z
    //   84: ifeq -> 739
    //   87: aload_0
    //   88: getfield logger : Lcom/applovin/impl/sdk/y;
    //   91: astore #6
    //   93: aload_0
    //   94: getfield tag : Ljava/lang/String;
    //   97: astore #7
    //   99: new java/lang/StringBuilder
    //   102: dup
    //   103: invokespecial <init> : ()V
    //   106: astore #8
    //   108: aload #8
    //   110: ldc 'Unable to transition to: '
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: pop
    //   116: aload #8
    //   118: aload_1
    //   119: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   122: pop
    //   123: aload #6
    //   125: aload #7
    //   127: aload #8
    //   129: invokevirtual toString : ()Ljava/lang/String;
    //   132: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   135: iload #4
    //   137: istore_3
    //   138: goto -> 739
    //   141: aload #6
    //   143: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   146: if_acmpne -> 292
    //   149: aload_1
    //   150: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   153: if_acmpne -> 159
    //   156: goto -> 944
    //   159: aload_1
    //   160: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   163: if_acmpne -> 181
    //   166: aload_0
    //   167: getfield tag : Ljava/lang/String;
    //   170: ldc 'An ad is already loading'
    //   172: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   175: iload #4
    //   177: istore_3
    //   178: goto -> 739
    //   181: aload_1
    //   182: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   185: if_acmpne -> 191
    //   188: goto -> 944
    //   191: aload_1
    //   192: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   195: if_acmpne -> 213
    //   198: aload_0
    //   199: getfield tag : Ljava/lang/String;
    //   202: ldc 'An ad is not ready to be shown yet'
    //   204: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   207: iload #4
    //   209: istore_3
    //   210: goto -> 739
    //   213: aload_1
    //   214: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   217: if_acmpne -> 223
    //   220: goto -> 944
    //   223: aload_0
    //   224: getfield logger : Lcom/applovin/impl/sdk/y;
    //   227: astore #6
    //   229: iload #4
    //   231: istore_3
    //   232: invokestatic a : ()Z
    //   235: ifeq -> 739
    //   238: aload_0
    //   239: getfield logger : Lcom/applovin/impl/sdk/y;
    //   242: astore #6
    //   244: aload_0
    //   245: getfield tag : Ljava/lang/String;
    //   248: astore #7
    //   250: new java/lang/StringBuilder
    //   253: dup
    //   254: invokespecial <init> : ()V
    //   257: astore #8
    //   259: aload #8
    //   261: ldc 'Unable to transition to: '
    //   263: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   266: pop
    //   267: aload #8
    //   269: aload_1
    //   270: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: aload #6
    //   276: aload #7
    //   278: aload #8
    //   280: invokevirtual toString : ()Ljava/lang/String;
    //   283: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   286: iload #4
    //   288: istore_3
    //   289: goto -> 739
    //   292: aload #6
    //   294: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   297: if_acmpne -> 462
    //   300: aload_1
    //   301: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   304: if_acmpne -> 310
    //   307: goto -> 944
    //   310: aload_1
    //   311: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   314: if_acmpne -> 332
    //   317: aload_0
    //   318: getfield tag : Ljava/lang/String;
    //   321: ldc 'An ad is already loaded'
    //   323: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   326: iload #4
    //   328: istore_3
    //   329: goto -> 739
    //   332: aload_1
    //   333: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   336: if_acmpne -> 373
    //   339: aload_0
    //   340: getfield logger : Lcom/applovin/impl/sdk/y;
    //   343: astore #6
    //   345: iload #4
    //   347: istore_3
    //   348: invokestatic a : ()Z
    //   351: ifeq -> 739
    //   354: aload_0
    //   355: getfield logger : Lcom/applovin/impl/sdk/y;
    //   358: aload_0
    //   359: getfield tag : Ljava/lang/String;
    //   362: ldc 'An ad is already marked as ready'
    //   364: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   367: iload #4
    //   369: istore_3
    //   370: goto -> 739
    //   373: aload_1
    //   374: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   377: if_acmpne -> 383
    //   380: goto -> 944
    //   383: aload_1
    //   384: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   387: if_acmpne -> 393
    //   390: goto -> 944
    //   393: aload_0
    //   394: getfield logger : Lcom/applovin/impl/sdk/y;
    //   397: astore #6
    //   399: iload #4
    //   401: istore_3
    //   402: invokestatic a : ()Z
    //   405: ifeq -> 739
    //   408: aload_0
    //   409: getfield logger : Lcom/applovin/impl/sdk/y;
    //   412: astore #6
    //   414: aload_0
    //   415: getfield tag : Ljava/lang/String;
    //   418: astore #7
    //   420: new java/lang/StringBuilder
    //   423: dup
    //   424: invokespecial <init> : ()V
    //   427: astore #8
    //   429: aload #8
    //   431: ldc 'Unable to transition to: '
    //   433: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   436: pop
    //   437: aload #8
    //   439: aload_1
    //   440: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   443: pop
    //   444: aload #6
    //   446: aload #7
    //   448: aload #8
    //   450: invokevirtual toString : ()Ljava/lang/String;
    //   453: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   456: iload #4
    //   458: istore_3
    //   459: goto -> 739
    //   462: aload #6
    //   464: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   467: if_acmpne -> 645
    //   470: aload_1
    //   471: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.a : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   474: if_acmpne -> 480
    //   477: goto -> 944
    //   480: aload_1
    //   481: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.b : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   484: if_acmpne -> 502
    //   487: aload_0
    //   488: getfield tag : Ljava/lang/String;
    //   491: ldc 'Can not load another ad while the ad is showing'
    //   493: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   496: iload #4
    //   498: istore_3
    //   499: goto -> 739
    //   502: aload_1
    //   503: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.c : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   506: if_acmpne -> 543
    //   509: aload_0
    //   510: getfield logger : Lcom/applovin/impl/sdk/y;
    //   513: astore #6
    //   515: iload #4
    //   517: istore_3
    //   518: invokestatic a : ()Z
    //   521: ifeq -> 739
    //   524: aload_0
    //   525: getfield logger : Lcom/applovin/impl/sdk/y;
    //   528: aload_0
    //   529: getfield tag : Ljava/lang/String;
    //   532: ldc 'An ad is already showing, ignoring'
    //   534: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   537: iload #4
    //   539: istore_3
    //   540: goto -> 739
    //   543: aload_1
    //   544: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.d : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   547: if_acmpne -> 566
    //   550: aload_0
    //   551: getfield tag : Ljava/lang/String;
    //   554: ldc_w 'The ad is already showing, not showing another one'
    //   557: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   560: iload #4
    //   562: istore_3
    //   563: goto -> 739
    //   566: aload_1
    //   567: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   570: if_acmpne -> 576
    //   573: goto -> 944
    //   576: aload_0
    //   577: getfield logger : Lcom/applovin/impl/sdk/y;
    //   580: astore #6
    //   582: iload #4
    //   584: istore_3
    //   585: invokestatic a : ()Z
    //   588: ifeq -> 739
    //   591: aload_0
    //   592: getfield logger : Lcom/applovin/impl/sdk/y;
    //   595: astore #6
    //   597: aload_0
    //   598: getfield tag : Ljava/lang/String;
    //   601: astore #7
    //   603: new java/lang/StringBuilder
    //   606: dup
    //   607: invokespecial <init> : ()V
    //   610: astore #8
    //   612: aload #8
    //   614: ldc 'Unable to transition to: '
    //   616: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   619: pop
    //   620: aload #8
    //   622: aload_1
    //   623: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   626: pop
    //   627: aload #6
    //   629: aload #7
    //   631: aload #8
    //   633: invokevirtual toString : ()Ljava/lang/String;
    //   636: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   639: iload #4
    //   641: istore_3
    //   642: goto -> 739
    //   645: aload #6
    //   647: getstatic com/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c.e : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   650: if_acmpne -> 669
    //   653: aload_0
    //   654: getfield tag : Ljava/lang/String;
    //   657: ldc_w 'No operations are allowed on a destroyed instance'
    //   660: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   663: iload #4
    //   665: istore_3
    //   666: goto -> 739
    //   669: aload_0
    //   670: getfield logger : Lcom/applovin/impl/sdk/y;
    //   673: astore #6
    //   675: iload #4
    //   677: istore_3
    //   678: invokestatic a : ()Z
    //   681: ifeq -> 739
    //   684: aload_0
    //   685: getfield logger : Lcom/applovin/impl/sdk/y;
    //   688: astore #6
    //   690: aload_0
    //   691: getfield tag : Ljava/lang/String;
    //   694: astore #7
    //   696: new java/lang/StringBuilder
    //   699: dup
    //   700: invokespecial <init> : ()V
    //   703: astore #8
    //   705: aload #8
    //   707: ldc_w 'Unknown state: '
    //   710: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   713: pop
    //   714: aload #8
    //   716: aload_0
    //   717: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   720: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   723: pop
    //   724: aload #6
    //   726: aload #7
    //   728: aload #8
    //   730: invokevirtual toString : ()Ljava/lang/String;
    //   733: invokevirtual e : (Ljava/lang/String;Ljava/lang/String;)V
    //   736: iload #4
    //   738: istore_3
    //   739: iload_3
    //   740: ifeq -> 840
    //   743: aload_0
    //   744: getfield logger : Lcom/applovin/impl/sdk/y;
    //   747: astore #6
    //   749: invokestatic a : ()Z
    //   752: ifeq -> 832
    //   755: aload_0
    //   756: getfield logger : Lcom/applovin/impl/sdk/y;
    //   759: astore #6
    //   761: aload_0
    //   762: getfield tag : Ljava/lang/String;
    //   765: astore #7
    //   767: new java/lang/StringBuilder
    //   770: dup
    //   771: invokespecial <init> : ()V
    //   774: astore #8
    //   776: aload #8
    //   778: ldc_w 'Transitioning from '
    //   781: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   784: pop
    //   785: aload #8
    //   787: aload_0
    //   788: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   791: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   794: pop
    //   795: aload #8
    //   797: ldc_w ' to '
    //   800: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   803: pop
    //   804: aload #8
    //   806: aload_1
    //   807: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   810: pop
    //   811: aload #8
    //   813: ldc_w '...'
    //   816: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   819: pop
    //   820: aload #6
    //   822: aload #7
    //   824: aload #8
    //   826: invokevirtual toString : ()Ljava/lang/String;
    //   829: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   832: aload_0
    //   833: aload_1
    //   834: putfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   837: goto -> 920
    //   840: aload_0
    //   841: getfield logger : Lcom/applovin/impl/sdk/y;
    //   844: astore #6
    //   846: invokestatic a : ()Z
    //   849: ifeq -> 920
    //   852: aload_0
    //   853: getfield logger : Lcom/applovin/impl/sdk/y;
    //   856: astore #6
    //   858: aload_0
    //   859: getfield tag : Ljava/lang/String;
    //   862: astore #7
    //   864: new java/lang/StringBuilder
    //   867: dup
    //   868: invokespecial <init> : ()V
    //   871: astore #8
    //   873: aload #8
    //   875: ldc_w 'Not allowed transition from '
    //   878: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   881: pop
    //   882: aload #8
    //   884: aload_0
    //   885: getfield f : Lcom/applovin/impl/mediation/ads/MaxFullscreenAdImpl$c;
    //   888: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   891: pop
    //   892: aload #8
    //   894: ldc_w ' to '
    //   897: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   900: pop
    //   901: aload #8
    //   903: aload_1
    //   904: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   907: pop
    //   908: aload #6
    //   910: aload #7
    //   912: aload #8
    //   914: invokevirtual toString : ()Ljava/lang/String;
    //   917: invokevirtual d : (Ljava/lang/String;Ljava/lang/String;)V
    //   920: aload #5
    //   922: monitorexit
    //   923: iload_3
    //   924: ifeq -> 937
    //   927: aload_2
    //   928: ifnull -> 937
    //   931: aload_2
    //   932: invokeinterface run : ()V
    //   937: return
    //   938: astore_1
    //   939: aload #5
    //   941: monitorexit
    //   942: aload_1
    //   943: athrow
    //   944: iconst_1
    //   945: istore_3
    //   946: goto -> 739
    // Exception table:
    //   from	to	target	type
    //   15	20	938	finally
    //   30	37	938	finally
    //   40	47	938	finally
    //   50	66	938	finally
    //   72	78	938	finally
    //   81	135	938	finally
    //   141	156	938	finally
    //   159	175	938	finally
    //   181	188	938	finally
    //   191	207	938	finally
    //   213	220	938	finally
    //   223	229	938	finally
    //   232	286	938	finally
    //   292	307	938	finally
    //   310	326	938	finally
    //   332	345	938	finally
    //   348	367	938	finally
    //   373	380	938	finally
    //   383	390	938	finally
    //   393	399	938	finally
    //   402	456	938	finally
    //   462	477	938	finally
    //   480	496	938	finally
    //   502	515	938	finally
    //   518	537	938	finally
    //   543	560	938	finally
    //   566	573	938	finally
    //   576	582	938	finally
    //   585	639	938	finally
    //   645	663	938	finally
    //   669	675	938	finally
    //   678	736	938	finally
    //   743	832	938	finally
    //   832	837	938	finally
    //   840	920	938	finally
    //   920	923	938	finally
    //   939	942	938	finally
  }
  
  private void a(MaxAd paramMaxAd) {
    if (this.sdk.V() != null) {
      this.sdk.V().a((g)paramMaxAd);
    } else {
      this.b.a();
    } 
    b();
    this.sdk.at().b((com.applovin.impl.mediation.a.a)paramMaxAd);
  }
  
  private void a(String paramString1, String paramString2) {
    this.c.b(this.e);
    this.e.e(paramString1);
    this.e.f(paramString2);
    this.sdk.af().a(this.e);
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      paramString2 = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Showing ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("'; loaded ad: ");
      stringBuilder.append(this.e);
      stringBuilder.append("...");
      y.b(paramString2, stringBuilder.toString());
    } 
    a((com.applovin.impl.mediation.a.a)this.e);
  }
  
  private boolean a(Activity paramActivity, String paramString) {
    if (paramActivity != null || MaxAdFormat.APP_OPEN == this.adFormat) {
      MaxErrorImpl maxErrorImpl;
      boolean bool;
      if (!isReady()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attempting to show ad before it is ready - please check ad readiness using ");
        stringBuilder.append(this.tag);
        stringBuilder.append("#isReady()");
        String str1 = stringBuilder.toString();
        y.i(this.tag, str1);
        this.sdk.Z().a(this.adUnitId);
        maxErrorImpl = new MaxErrorImpl(-24, str1);
        k k = new k(this.adUnitId, this.adFormat, paramString);
        y y = this.logger;
        if (y.a()) {
          y = this.logger;
          String str2 = this.tag;
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder1.append(k);
          stringBuilder1.append(", error=");
          stringBuilder1.append(maxErrorImpl);
          stringBuilder1.append("), listener=");
          stringBuilder1.append(this.adListener);
          y.b(str2, stringBuilder1.toString());
        } 
        k.a(this.adListener, (MaxAd)k, (MaxError)maxErrorImpl, true);
        if (this.e != null)
          this.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.e); 
        return false;
      } 
      p p = this.sdk;
      if (Utils.getAlwaysFinishActivitiesSetting(p.y()) != 0 && this.sdk.C().shouldFailAdDisplayIfDontKeepActivitiesIsEnabled()) {
        p = this.sdk;
        if (!Utils.isPubInDebugMode(p.y(), this.sdk)) {
          if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.S)).booleanValue()) {
            y.i(this.tag, "Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
            maxErrorImpl = new MaxErrorImpl(-5602, "Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
            y y = this.logger;
            if (y.a()) {
              y = this.logger;
              String str1 = this.tag;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
              stringBuilder.append(this.e);
              stringBuilder.append(", error=");
              stringBuilder.append(maxErrorImpl);
              stringBuilder.append("), listener=");
              stringBuilder.append(this.adListener);
              y.b(str1, stringBuilder.toString());
            } 
            k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
            this.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.e);
            return false;
          } 
        } else {
          throw new IllegalStateException("Ad failed to display! Please disable the \"Don't Keep Activities\" setting in your developer settings!");
        } 
      } 
      if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.z)).booleanValue() && (this.sdk.Z().a() || this.sdk.Z().b())) {
        y.i(this.tag, "Attempting to show ad when another fullscreen ad is already showing");
        maxErrorImpl = new MaxErrorImpl(-23, "Attempting to show ad when another fullscreen ad is already showing");
        y y = this.logger;
        if (y.a()) {
          y = this.logger;
          String str1 = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder.append(this.e);
          stringBuilder.append(", error=");
          stringBuilder.append(maxErrorImpl);
          stringBuilder.append("), listener=");
          stringBuilder.append(this.adListener);
          y.b(str1, stringBuilder.toString());
        } 
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        this.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.e);
        return false;
      } 
      if (((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.A)).booleanValue()) {
        p = this.sdk;
        if (!i.a(p.y())) {
          y.i(this.tag, "Attempting to show ad with no internet connection");
          maxErrorImpl = new MaxErrorImpl(-1009);
          y y = this.logger;
          if (y.a()) {
            y = this.logger;
            String str1 = this.tag;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
            stringBuilder.append(this.e);
            stringBuilder.append(", error=");
            stringBuilder.append(maxErrorImpl);
            stringBuilder.append("), listener=");
            stringBuilder.append(this.adListener);
            y.b(str1, stringBuilder.toString());
          } 
          k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
          this.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.e);
          return false;
        } 
      } 
      String str = (String)this.sdk.C().getExtraParameters().get("fullscreen_ads_block_showing_if_activity_is_finishing");
      if (StringUtils.isValidString(str) && Boolean.valueOf(str).booleanValue()) {
        bool = true;
      } else {
        bool = false;
      } 
      if ((bool || ((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.B)).booleanValue()) && maxErrorImpl != null && maxErrorImpl.isFinishing()) {
        y.i(this.tag, "Attempting to show ad when activity is finishing");
        maxErrorImpl = new MaxErrorImpl(-5601, "Attempting to show ad when activity is finishing");
        y y = this.logger;
        if (y.a()) {
          y = this.logger;
          String str1 = this.tag;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
          stringBuilder.append(this.e);
          stringBuilder.append(", error=");
          stringBuilder.append(maxErrorImpl);
          stringBuilder.append("), listener=");
          stringBuilder.append(this.adListener);
          y.b(str1, stringBuilder.toString());
        } 
        k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
        this.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.e);
        return false;
      } 
      return true;
    } 
    throw new IllegalArgumentException("Attempting to show ad without a valid activity.");
  }
  
  private void b() {
    synchronized (this.d) {
      com.applovin.impl.mediation.a.c c1 = this.e;
      this.e = null;
      this.sdk.ap().destroyAd((MaxAd)c1);
      return;
    } 
  }
  
  private void c() {
    if (this.g.compareAndSet(true, false))
      synchronized (this.d) {
        com.applovin.impl.mediation.a.c c1 = this.e;
        this.e = null;
        this.sdk.ap().destroyAd((MaxAd)c1);
        this.extraParameters.remove("expired_ad_ad_unit_id");
        return;
      }  
  }
  
  public void destroy() {
    a(c.e, new Runnable(this) {
          public void run() {
            synchronized (MaxFullscreenAdImpl.a(this.a)) {
              if (MaxFullscreenAdImpl.b(this.a) != null) {
                y y = this.a.logger;
                if (y.a()) {
                  y = this.a.logger;
                  String str = this.a.tag;
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Destroying ad for '");
                  stringBuilder.append(this.a.adUnitId);
                  stringBuilder.append("'; current ad: ");
                  stringBuilder.append(MaxFullscreenAdImpl.b(this.a));
                  stringBuilder.append("...");
                  y.b(str, stringBuilder.toString());
                } 
                this.a.sdk.ap().destroyAd((MaxAd)MaxFullscreenAdImpl.b(this.a));
              } 
              this.a.sdk.am().b(this.a);
              MaxFullscreenAdImpl.c(this.a);
              return;
            } 
          }
        });
  }
  
  public boolean isReady() {
    synchronized (this.d) {
      boolean bool;
      if (this.e != null && this.e.g() && this.f == c.c) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool)
        this.sdk.Z().a(this.adUnitId); 
      return bool;
    } 
  }
  
  public void loadAd(Activity paramActivity) {
    loadAd(paramActivity, f.a.a);
  }
  
  public void loadAd(Activity paramActivity, f.a parama) {
    y y1;
    String str;
    y y2 = this.logger;
    if (y.a()) {
      y2 = this.logger;
      String str1 = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Loading ad for '");
      stringBuilder.append(this.adUnitId);
      stringBuilder.append("'...");
      y2.b(str1, stringBuilder.toString());
    } 
    if (isReady()) {
      y1 = this.logger;
      if (y.a()) {
        y1 = this.logger;
        str = this.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("An ad is already loaded for '");
        stringBuilder.append(this.adUnitId);
        stringBuilder.append("'");
        y1.b(str, stringBuilder.toString());
      } 
      y1 = this.logger;
      if (y.a()) {
        y1 = this.logger;
        str = this.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdLoaded(ad=");
        stringBuilder.append(this.e);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.adListener);
        y1.b(str, stringBuilder.toString());
      } 
      k.a(this.adListener, (MaxAd)this.e, true);
      return;
    } 
    a(c.b, new Runnable(this, (Activity)y1, (f.a)str) {
          public void run() {
            Context context;
            Activity activity = this.a;
            if (activity == null)
              if (this.c.sdk.x() != null) {
                activity = this.c.sdk.x();
              } else {
                p p = this.c.sdk;
                context = p.y();
              }  
            this.c.sdk.ap().loadAd(this.c.adUnitId, null, this.c.adFormat, this.b, this.c.localExtraParameters, this.c.extraParameters, context, this.c.listenerWrapper);
          }
        });
  }
  
  public void onAdExpired() {
    Activity activity;
    y y = this.logger;
    if (y.a()) {
      y = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Ad expired ");
      stringBuilder.append(getAdUnitId());
      y.b(str, stringBuilder.toString());
    } 
    this.g.set(true);
    a a1 = this.a;
    if (a1 != null) {
      Activity activity1 = a1.getActivity();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null) {
      Activity activity1 = this.sdk.w().a();
      activity = activity1;
      if (activity1 == null) {
        c();
        this.listenerWrapper.onAdLoadFailed(this.adUnitId, (MaxError)MaxAdapterError.MISSING_ACTIVITY);
        return;
      } 
    } 
    this.extraParameters.put("expired_ad_ad_unit_id", getAdUnitId());
    this.sdk.ap().loadAd(this.adUnitId, null, this.adFormat, f.a.e, this.localExtraParameters, this.extraParameters, (Context)activity, this.listenerWrapper);
  }
  
  public void onAdExpired(g paramg) {
    onAdExpired();
  }
  
  public void onCreativeIdGenerated(String paramString1, String paramString2) {
    com.applovin.impl.mediation.a.c c1 = this.e;
    if (c1 != null && c1.h().equalsIgnoreCase(paramString1)) {
      this.e.b(paramString2);
      k.a(this.adReviewListener, paramString2, (MaxAd)this.e);
    } 
  }
  
  public void showAd(String paramString1, String paramString2, Activity paramActivity) {
    String str1;
    String str2 = this.sdk.av().c();
    if (this.sdk.av().b() && str2 != null && !str2.equals(this.e.Y())) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Attempting to show ad from <");
      stringBuilder.append(this.e.Y());
      stringBuilder.append("> which does not match selected ad network <");
      stringBuilder.append(str2);
      stringBuilder.append(">");
      str1 = stringBuilder.toString();
      y.i(this.tag, str1);
      a(c.a, new Runnable(this, str1) {
            public void run() {
              com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.b);
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.b;
              MaxFullscreenAdImpl.a(maxFullscreenAdImpl, (MaxAd)MaxFullscreenAdImpl.b(maxFullscreenAdImpl));
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-4205, this.a);
              y y = this.b.logger;
              if (y.a()) {
                y = this.b.logger;
                String str = this.b.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(c);
                stringBuilder.append(", error=");
                stringBuilder.append(maxErrorImpl);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.b.adListener, (MaxAd)c, (MaxError)maxErrorImpl, true);
              this.b.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)c);
            }
          });
      return;
    } 
    if (paramActivity == null)
      paramActivity = this.sdk.x(); 
    if (!a(paramActivity, str1))
      return; 
    a(c.d, new Runnable(this, str1, paramString2, paramActivity) {
          public void run() {
            MaxFullscreenAdImpl.a(this.d, this.a, this.b);
            MaxFullscreenAdImpl.a(this.d, false);
            MaxFullscreenAdImpl.a(this.d, new WeakReference<Activity>(this.c));
            this.d.sdk.ap().showFullscreenAd(MaxFullscreenAdImpl.b(this.d), this.c, this.d.listenerWrapper);
          }
        });
  }
  
  public void showAd(String paramString1, String paramString2, ViewGroup paramViewGroup, Lifecycle paramLifecycle, Activity paramActivity) {
    String str1;
    y y;
    String str2;
    StringBuilder stringBuilder;
    if (paramViewGroup == null || paramLifecycle == null) {
      y.i(this.tag, "Attempting to show ad with null containerView or lifecycle.");
      MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, "Attempting to show ad with null containerView or lifecycle.");
      y = this.logger;
      if (y.a()) {
        y = this.logger;
        str2 = this.tag;
        stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
        stringBuilder.append(this.e);
        stringBuilder.append(", error=");
        stringBuilder.append(maxErrorImpl);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.adListener);
        y.b(str2, stringBuilder.toString());
      } 
      k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
      this.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.e);
      return;
    } 
    if (!str2.isShown() && ((Boolean)this.sdk.a(com.applovin.impl.sdk.c.a.T)).booleanValue()) {
      y.i(this.tag, "Attempting to show ad when containerView and/or its ancestors are not visible");
      MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, "Attempting to show ad when containerView and/or its ancestors are not visible");
      k.a(this.adListener, (MaxAd)this.e, (MaxError)maxErrorImpl, true);
      this.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)this.e);
      return;
    } 
    String str3 = this.sdk.av().c();
    if (this.sdk.av().b() && str3 != null && !str3.equals(this.e.Y())) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Attempting to show ad from <");
      stringBuilder1.append(this.e.Y());
      stringBuilder1.append("> which does not match selected ad network <");
      stringBuilder1.append(str3);
      stringBuilder1.append(">");
      str1 = stringBuilder1.toString();
      y.i(this.tag, str1);
      a(c.a, new Runnable(this, str1) {
            public void run() {
              com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.b);
              MaxFullscreenAdImpl maxFullscreenAdImpl = this.b;
              MaxFullscreenAdImpl.a(maxFullscreenAdImpl, (MaxAd)MaxFullscreenAdImpl.b(maxFullscreenAdImpl));
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-4205, this.a);
              y y = this.b.logger;
              if (y.a()) {
                y = this.b.logger;
                String str = this.b.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(c);
                stringBuilder.append(", error=");
                stringBuilder.append(maxErrorImpl);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.b.adListener, (MaxAd)c, (MaxError)maxErrorImpl, true);
              this.b.sdk.ap().processAdDisplayErrorPostbackForUserError((MaxError)maxErrorImpl, (com.applovin.impl.mediation.a.a)c);
            }
          });
      return;
    } 
    if (paramActivity == null)
      paramActivity = this.sdk.x(); 
    if (!a(paramActivity, str1))
      return; 
    a(c.d, new Runnable(this, str1, (String)y, paramActivity, (ViewGroup)str2, (Lifecycle)stringBuilder) {
          public void run() {
            MaxFullscreenAdImpl.a(this.f, this.a, this.b);
            MaxFullscreenAdImpl.a(this.f, true);
            MaxFullscreenAdImpl.a(this.f, new WeakReference<Activity>(this.c));
            MaxFullscreenAdImpl.b(this.f, new WeakReference<ViewGroup>(this.d));
            MaxFullscreenAdImpl.c(this.f, new WeakReference<Lifecycle>(this.e));
            this.f.sdk.ap().showFullscreenAd(MaxFullscreenAdImpl.b(this.f), this.d, this.e, this.c, this.f.listenerWrapper);
          }
        });
  }
  
  @NonNull
  public String toString() {
    MaxAdListener maxAdListener;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.tag);
    stringBuilder.append("{adUnitId='");
    stringBuilder.append(this.adUnitId);
    stringBuilder.append('\'');
    stringBuilder.append(", adListener=");
    if (this.adListener == this.a) {
      String str = "this";
    } else {
      maxAdListener = this.adListener;
    } 
    stringBuilder.append(maxAdListener);
    stringBuilder.append(", revenueListener=");
    stringBuilder.append(this.revenueListener);
    stringBuilder.append(", requestListener");
    stringBuilder.append(this.requestListener);
    stringBuilder.append(", adReviewListener");
    stringBuilder.append(this.adReviewListener);
    stringBuilder.append(", isReady=");
    stringBuilder.append(isReady());
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public static interface a {
    Activity getActivity();
  }
  
  private class b implements a.a, MaxAdListener, MaxAdRevenueListener, MaxRewardedAdListener {
    private b(MaxFullscreenAdImpl this$0) {}
    
    public void a(@Nullable MaxAd param1MaxAd) {
      if (param1MaxAd != null) {
        if (param1MaxAd == MaxFullscreenAdImpl.b(this.a))
          return; 
        null = (com.applovin.impl.mediation.a.c)param1MaxAd;
        null.i().e().a(this);
        if (null.f().endsWith("load"))
          onAdRevenuePaid((MaxAd)null); 
        synchronized (MaxFullscreenAdImpl.a(this.a)) {
          com.applovin.impl.mediation.a.c c = MaxFullscreenAdImpl.b(this.a);
          MaxFullscreenAdImpl.b(this.a, null);
          if (this.a.sdk.V() != null) {
            this.a.sdk.V().a((g)c);
            this.a.sdk.V().a((g)MaxFullscreenAdImpl.b(this.a), this.a);
          } else {
            MaxFullscreenAdImpl.h(this.a).a((com.applovin.impl.mediation.a.a)MaxFullscreenAdImpl.b(this.a));
          } 
          this.a.sdk.ap().destroyAd((MaxAd)c);
          return;
        } 
      } 
    }
    
    public void onAdClicked(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdClicked(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.d(this.a.adListener, param1MaxAd, true);
    }
    
    public void onAdDisplayFailed(MaxAd param1MaxAd, MaxError param1MaxError) {
      boolean bool = MaxFullscreenAdImpl.e(this.a);
      MaxFullscreenAdImpl.b(this.a, false);
      com.applovin.impl.mediation.a.c c = (com.applovin.impl.mediation.a.c)param1MaxAd;
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1MaxAd, bool, c, param1MaxError) {
            public void run() {
              MaxFullscreenAdImpl.a(this.e.a, this.a);
              if (!this.b && this.c.J() && this.e.a.sdk.au().a(this.e.a.adUnitId)) {
                AppLovinSdkUtils.runOnUiThread(true, new Runnable(this) {
                      public void run() {
                        Activity activity;
                        MaxFullscreenAdImpl.b(this.a.e.a, true);
                        if (MaxFullscreenAdImpl.j(this.a.e.a) != null) {
                          activity = MaxFullscreenAdImpl.j(this.a.e.a).getActivity();
                        } else {
                          activity = null;
                        } 
                        this.a.e.a.loadAd(activity);
                      }
                    });
                return;
              } 
              y y = this.e.a.logger;
              if (y.a()) {
                y = this.e.a.logger;
                String str = this.e.a.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append(", error=");
                stringBuilder.append(this.d);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.e.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.e.a.adListener, this.a, this.d, true);
            }
          });
    }
    
    public void onAdDisplayed(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.b(this.a, false);
      if (this.a.sdk.V() != null) {
        this.a.sdk.V().a((g)param1MaxAd);
      } else {
        MaxFullscreenAdImpl.h(this.a).a();
      } 
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdDisplayed(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.b(this.a.adListener, param1MaxAd, true);
    }
    
    public void onAdHidden(MaxAd param1MaxAd) {
      MaxFullscreenAdImpl.b(this.a, false);
      MaxFullscreenAdImpl.i(this.a).a(param1MaxAd);
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1MaxAd) {
            public void run() {
              MaxFullscreenAdImpl.a(this.b.a, this.a);
              y y = this.b.a.logger;
              if (y.a()) {
                y = this.b.a.logger;
                String str = this.b.a.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdHidden(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.c(this.b.a.adListener, this.a, true);
            }
          });
    }
    
    public void onAdLoadFailed(String param1String, MaxError param1MaxError) {
      MaxFullscreenAdImpl.g(this.a);
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.a, new Runnable(this, param1String, param1MaxError) {
            public void run() {
              y y = this.c.a.logger;
              if (y.a()) {
                y = this.c.a.logger;
                String str = this.c.a.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdLoadFailed(adUnitId=");
                stringBuilder.append(this.a);
                stringBuilder.append(", error=");
                stringBuilder.append(this.b);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.c.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.c.a.adListener, this.a, this.b, true);
            }
          });
    }
    
    public void onAdLoaded(MaxAd param1MaxAd) {
      this.a.sdk.Z().c(this.a.adUnitId);
      MaxFullscreenAdImpl.a(this.a, (com.applovin.impl.mediation.a.c)param1MaxAd);
      if (MaxFullscreenAdImpl.d(this.a).compareAndSet(true, false)) {
        this.a.extraParameters.remove("expired_ad_ad_unit_id");
        return;
      } 
      MaxFullscreenAdImpl.a(this.a, MaxFullscreenAdImpl.c.c, new Runnable(this, param1MaxAd) {
            public void run() {
              if (MaxFullscreenAdImpl.e(this.b.a)) {
                MaxFullscreenAdImpl.f(this.b.a);
                return;
              } 
              y y = this.b.a.logger;
              if (y.a()) {
                y = this.b.a.logger;
                String str = this.b.a.tag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MaxAdListener.onAdLoaded(ad=");
                stringBuilder.append(this.a);
                stringBuilder.append("), listener=");
                stringBuilder.append(this.b.a.adListener);
                y.b(str, stringBuilder.toString());
              } 
              k.a(this.b.a.adListener, this.a, true);
            }
          });
    }
    
    public void onAdRequestStarted(String param1String) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdRequestListener.onAdRequestStarted(adUnitId=");
        stringBuilder.append(param1String);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.requestListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.a.requestListener, param1String, true);
    }
    
    public void onAdRevenuePaid(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdRevenueListener.onAdRevenuePaid(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.revenueListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.a.revenueListener, param1MaxAd);
    }
    
    public void onRewardedVideoCompleted(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxRewardedAdListener.onRewardedVideoCompleted(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.f(this.a.adListener, param1MaxAd, true);
    }
    
    public void onRewardedVideoStarted(MaxAd param1MaxAd) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxRewardedAdListener.onRewardedVideoStarted(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.e(this.a.adListener, param1MaxAd, true);
    }
    
    public void onUserRewarded(MaxAd param1MaxAd, MaxReward param1MaxReward) {
      y y = this.a.logger;
      if (y.a()) {
        y = this.a.logger;
        String str = this.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxRewardedAdListener.onUserRewarded(ad=");
        stringBuilder.append(param1MaxAd);
        stringBuilder.append(", reward=");
        stringBuilder.append(param1MaxReward);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.a.adListener, param1MaxAd, param1MaxReward, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      if (MaxFullscreenAdImpl.e(this.b.a)) {
        MaxFullscreenAdImpl.f(this.b.a);
        return;
      } 
      y y = this.b.a.logger;
      if (y.a()) {
        y = this.b.a.logger;
        String str = this.b.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdLoaded(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.b.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.b.a.adListener, this.a, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, String param1String, MaxError param1MaxError) {}
    
    public void run() {
      y y = this.c.a.logger;
      if (y.a()) {
        y = this.c.a.logger;
        String str = this.c.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdLoadFailed(adUnitId=");
        stringBuilder.append(this.a);
        stringBuilder.append(", error=");
        stringBuilder.append(this.b);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.c.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.c.a.adListener, this.a, this.b, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      MaxFullscreenAdImpl.a(this.b.a, this.a);
      y y = this.b.a.logger;
      if (y.a()) {
        y = this.b.a.logger;
        String str = this.b.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdHidden(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.b.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.c(this.b.a.adListener, this.a, true);
    }
  }
  
  class null implements Runnable {
    null(MaxFullscreenAdImpl this$0, MaxAd param1MaxAd, boolean param1Boolean, com.applovin.impl.mediation.a.c param1c, MaxError param1MaxError) {}
    
    public void run() {
      MaxFullscreenAdImpl.a(this.e.a, this.a);
      if (!this.b && this.c.J() && this.e.a.sdk.au().a(this.e.a.adUnitId)) {
        AppLovinSdkUtils.runOnUiThread(true, new Runnable(this) {
              public void run() {
                Activity activity;
                MaxFullscreenAdImpl.b(this.a.e.a, true);
                if (MaxFullscreenAdImpl.j(this.a.e.a) != null) {
                  activity = MaxFullscreenAdImpl.j(this.a.e.a).getActivity();
                } else {
                  activity = null;
                } 
                this.a.e.a.loadAd(activity);
              }
            });
        return;
      } 
      y y = this.e.a.logger;
      if (y.a()) {
        y = this.e.a.logger;
        String str = this.e.a.tag;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MaxAdListener.onAdDisplayFailed(ad=");
        stringBuilder.append(this.a);
        stringBuilder.append(", error=");
        stringBuilder.append(this.d);
        stringBuilder.append("), listener=");
        stringBuilder.append(this.e.a.adListener);
        y.b(str, stringBuilder.toString());
      } 
      k.a(this.e.a.adListener, this.a, this.d, true);
    }
  }
  
  class null implements Runnable {
    public void run() {
      Activity activity;
      MaxFullscreenAdImpl.b(this.a.e.a, true);
      if (MaxFullscreenAdImpl.j(this.a.e.a) != null) {
        activity = MaxFullscreenAdImpl.j(this.a.e.a).getActivity();
      } else {
        activity = null;
      } 
      this.a.e.a.loadAd(activity);
    }
  }
  
  public enum c {
    a, b, c, d, e;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\ads\MaxFullscreenAdImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */