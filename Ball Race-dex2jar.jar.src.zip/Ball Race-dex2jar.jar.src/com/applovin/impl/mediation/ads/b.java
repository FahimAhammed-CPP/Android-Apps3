package com.applovin.impl.mediation.ads;

import android.view.View;
import android.view.ViewGroup;
import com.applovin.impl.mediation.a.a;
import com.applovin.impl.mediation.a.d;
import com.applovin.impl.mediation.a.e;
import com.applovin.impl.sdk.ac;
import com.applovin.impl.sdk.ad;
import com.applovin.impl.sdk.ad.g;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.y;

public class b implements ad.a {
  private final p a;
  
  private final d b;
  
  private final ad c;
  
  private final ac d;
  
  private final a.a e;
  
  public b(d paramd, ViewGroup paramViewGroup, a.a parama, p paramp) {
    this.a = paramp;
    this.b = paramd;
    this.e = parama;
    this.d = new ac((View)paramViewGroup, paramp);
    this.c = new ad((View)paramViewGroup, paramp, this);
    this.c.a((e)this.b);
    paramp.L();
    if (y.a()) {
      y y = paramp.L();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Created new MaxNativeAdView (");
      stringBuilder.append(this);
      stringBuilder.append(")");
      y.b("MaxNativeAdView", stringBuilder.toString());
    } 
  }
  
  private void a(long paramLong) {
    if (this.b.I().compareAndSet(false, true)) {
      this.a.L();
      if (y.a())
        this.a.L().b("MaxNativeAdView", "Scheduling viewability impression for ad..."); 
      this.a.ap().processViewabilityAdImpressionPostback((e)this.b, paramLong, this.e);
    } 
  }
  
  public void a() {
    this.c.a();
  }
  
  public void b() {
    this.a.L();
    if (y.a())
      this.a.L().b("MaxNativeAdView", "Handling view attached to window"); 
    if (this.b.H().compareAndSet(false, true)) {
      this.a.L();
      if (y.a())
        this.a.L().b("MaxNativeAdView", "Scheduling impression for ad manually..."); 
      if (this.b.getNativeAd().isExpired()) {
        y.i("MaxNativeAdView", "Attempting to display an expired native ad. Check if an ad is expired before displaying using `MaxAd.getNativeAd().isExpired()`");
      } else if (this.a.V() != null) {
        this.a.V().a((g)this.b);
      } else {
        this.b.K();
      } 
      this.a.ap().processRawAdImpressionPostback((a)this.b, this.e);
    } 
  }
  
  public d c() {
    return this.b;
  }
  
  public void onLogVisibilityImpression() {
    a(this.d.a((e)this.b));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\ads\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */