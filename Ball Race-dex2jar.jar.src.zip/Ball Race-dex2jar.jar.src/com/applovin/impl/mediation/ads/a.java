package com.applovin.impl.mediation.ads;

import androidx.annotation.Nullable;
import com.applovin.impl.mediation.f;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.l;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdRequestListener;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxAdReviewListener;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public abstract class a {
  protected final MaxAdFormat adFormat;
  
  protected MaxAdListener adListener;
  
  @Nullable
  protected MaxAdReviewListener adReviewListener;
  
  protected final String adUnitId;
  
  protected final Map<String, Object> extraParameters = Collections.synchronizedMap(CollectionUtils.map());
  
  protected final Map<String, Object> localExtraParameters = Collections.synchronizedMap(CollectionUtils.map());
  
  protected final y logger;
  
  @Nullable
  protected MaxAdRequestListener requestListener;
  
  @Nullable
  protected MaxAdRevenueListener revenueListener;
  
  protected final p sdk;
  
  protected final String tag;
  
  protected a(String paramString1, MaxAdFormat paramMaxAdFormat, String paramString2, p paramp) {
    this.adUnitId = paramString1;
    this.adFormat = paramMaxAdFormat;
    this.sdk = paramp;
    this.tag = paramString2;
    this.logger = paramp.L();
  }
  
  public static void logApiCall(String paramString1, String paramString2) {
    if (p.a != null) {
      p.a.L();
      if (y.a())
        p.a.L().b(paramString1, paramString2); 
    } 
  }
  
  void a(com.applovin.impl.mediation.a.a parama) {
    l l = new l();
    l.a().a("MAX Ad").a(parama).a();
    y y1 = this.logger;
    if (y.a())
      this.logger.b(this.tag, l.toString()); 
  }
  
  protected void destroy() {
    this.localExtraParameters.clear();
    this.adListener = null;
    this.revenueListener = null;
    this.requestListener = null;
    this.adReviewListener = null;
  }
  
  public String getAdUnitId() {
    return this.adUnitId;
  }
  
  public void logApiCall(String paramString) {
    y y1 = this.logger;
    if (y.a())
      this.logger.b(this.tag, paramString); 
  }
  
  public void setAdReviewListener(MaxAdReviewListener paramMaxAdReviewListener) {
    y y1 = this.logger;
    if (y.a()) {
      y1 = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Setting Ad Review creative id listener: ");
      stringBuilder.append(paramMaxAdReviewListener);
      y1.b(str, stringBuilder.toString());
    } 
    this.adReviewListener = paramMaxAdReviewListener;
  }
  
  public void setExtraParameter(String paramString1, String paramString2) {
    if (paramString1 != null) {
      p p1 = this.sdk;
      if (!Utils.isPubInDebugMode(p.y(), this.sdk) || (!"amazon_ad_response".equals(paramString1) && !"amazon_ad_error".equals(paramString1))) {
        if (this.adFormat.isAdViewAd() && "ad_refresh_seconds".equals(paramString1) && StringUtils.isValidString(paramString2)) {
          int i = Integer.parseInt(paramString2);
          if (i > TimeUnit.MINUTES.toSeconds(2L)) {
            String str = this.tag;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Attempting to set extra parameter \"ad_refresh_seconds\" to over 2 minutes (");
            stringBuilder.append(i);
            stringBuilder.append("s) - this will be ignored");
            y.i(str, stringBuilder.toString());
          } 
        } 
        this.extraParameters.put(paramString1, paramString2);
        return;
      } 
      throw new IllegalArgumentException("`setExtraParameter()` is an incorrect method for passing `amazon_ad_response` or `amazon_ad_error`. Please use the following method: `setLocalExtraParameter()`. Also note that this exception occurs in development builds only.");
    } 
    throw new IllegalArgumentException("No key specified");
  }
  
  public void setListener(MaxAdListener paramMaxAdListener) {
    y y1 = this.logger;
    if (y.a()) {
      y1 = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Setting listener: ");
      stringBuilder.append(paramMaxAdListener);
      y1.b(str, stringBuilder.toString());
    } 
    this.adListener = paramMaxAdListener;
  }
  
  public void setLocalExtraParameter(String paramString, Object paramObject) {
    if (paramString != null) {
      y y1;
      if (paramObject instanceof android.app.Activity) {
        y1 = this.logger;
        if (y.a())
          this.logger.e(this.tag, "Ignoring setting local extra parameter to Activity instance - please pass a WeakReference of it instead!"); 
        return;
      } 
      if ("amazon_ad_response".equals(y1) || "amazon_ad_error".equals(y1))
        setExtraParameter("is_amazon_integration", Boolean.toString(true)); 
      this.localExtraParameters.put(y1, paramObject);
      return;
    } 
    throw new IllegalArgumentException("No key specified");
  }
  
  public void setRequestListener(MaxAdRequestListener paramMaxAdRequestListener) {
    y y1 = this.logger;
    if (y.a()) {
      y1 = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Setting request listener: ");
      stringBuilder.append(paramMaxAdRequestListener);
      y1.b(str, stringBuilder.toString());
    } 
    this.requestListener = paramMaxAdRequestListener;
  }
  
  public void setRevenueListener(MaxAdRevenueListener paramMaxAdRevenueListener) {
    y y1 = this.logger;
    if (y.a()) {
      y1 = this.logger;
      String str = this.tag;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Setting revenue listener: ");
      stringBuilder.append(paramMaxAdRevenueListener);
      y1.b(str, stringBuilder.toString());
    } 
    this.revenueListener = paramMaxAdRevenueListener;
  }
  
  public static interface a extends f.b, MaxAdListener, MaxAdRequestListener, MaxAdRevenueListener {}
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\ads\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */