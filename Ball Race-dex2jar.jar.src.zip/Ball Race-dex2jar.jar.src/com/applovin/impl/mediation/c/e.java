package com.applovin.impl.mediation.c;

import android.app.Activity;
import android.content.Context;
import android.os.SystemClock;
import androidx.annotation.Nullable;
import com.applovin.impl.mediation.MaxAdWaterfallInfoImpl;
import com.applovin.impl.mediation.MaxErrorImpl;
import com.applovin.impl.mediation.MaxMediatedNetworkInfoImpl;
import com.applovin.impl.mediation.MaxNetworkResponseInfoImpl;
import com.applovin.impl.mediation.d.c;
import com.applovin.impl.sdk.d.f;
import com.applovin.impl.sdk.e.a;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.f;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdWaterfallInfo;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxMediatedNetworkInfo;
import com.applovin.mediation.MaxNetworkResponseInfo;
import com.applovin.sdk.AppLovinSdkUtils;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;

public class e extends a {
  private static final AtomicBoolean a = new AtomicBoolean();
  
  private final String b;
  
  private final MaxAdFormat c;
  
  private final JSONObject d;
  
  private final List<com.applovin.impl.mediation.a.a> e;
  
  private final com.applovin.impl.mediation.ads.a.a i;
  
  private final WeakReference<Context> j;
  
  private long k;
  
  private final List<MaxNetworkResponseInfo> l;
  
  e(String paramString, MaxAdFormat paramMaxAdFormat, Map<String, Object> paramMap, JSONObject paramJSONObject, Context paramContext, p paramp, com.applovin.impl.mediation.ads.a.a parama) {
    super(stringBuilder.toString(), paramp);
    this.b = paramString;
    this.c = paramMaxAdFormat;
    this.d = paramJSONObject;
    this.i = parama;
    this.j = new WeakReference<Context>(paramContext);
    JSONArray jSONArray = JsonUtils.getJSONArray(paramJSONObject, "ads", new JSONArray());
    this.e = new ArrayList<com.applovin.impl.mediation.a.a>(jSONArray.length());
    int i;
    for (i = 0; i < jSONArray.length(); i++) {
      JSONObject jSONObject = JsonUtils.getJSONObject(jSONArray, i, null);
      this.e.add(com.applovin.impl.mediation.a.a.a(i, paramMap, jSONObject, paramJSONObject, paramp));
    } 
    this.l = new ArrayList<MaxNetworkResponseInfo>(this.e.size());
  }
  
  private void a(com.applovin.impl.mediation.a.a parama) {
    this.f.at().a(parama);
    long l = SystemClock.elapsedRealtime() - this.k;
    y y = this.h;
    if (y.a()) {
      y = this.h;
      String str = this.g;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Waterfall loaded in ");
      stringBuilder.append(l);
      stringBuilder.append("ms for ");
      stringBuilder.append(parama.Y());
      y.c(str, stringBuilder.toString());
    } 
    parama.a((MaxAdWaterfallInfo)new MaxAdWaterfallInfoImpl(parama, l, this.l));
    k.a((MaxAdListener)this.i, (MaxAd)parama);
  }
  
  private void a(MaxError paramMaxError) {
    if (paramMaxError.getCode() == 204) {
      this.f.P().a(f.r);
    } else if (paramMaxError.getCode() == -5001) {
      this.f.P().a(f.s);
    } else {
      this.f.P().a(f.t);
    } 
    ArrayList<MaxNetworkResponseInfo> arrayList = new ArrayList(this.l.size());
    for (MaxNetworkResponseInfo maxNetworkResponseInfo : this.l) {
      if (maxNetworkResponseInfo.getAdLoadState() == MaxNetworkResponseInfo.AdLoadState.FAILED_TO_LOAD)
        arrayList.add(maxNetworkResponseInfo); 
    } 
    if (arrayList.size() > 0) {
      StringBuilder stringBuilder = new StringBuilder("======FAILED AD LOADS======");
      stringBuilder.append("\n");
      int i = 0;
      while (i < arrayList.size()) {
        MaxNetworkResponseInfo maxNetworkResponseInfo = arrayList.get(i);
        stringBuilder.append(++i);
        stringBuilder.append(") ");
        stringBuilder.append(maxNetworkResponseInfo.getMediatedNetwork().getName());
        stringBuilder.append("\n");
        stringBuilder.append("..code: ");
        stringBuilder.append(maxNetworkResponseInfo.getError().getCode());
        stringBuilder.append("\n");
        stringBuilder.append("..message: ");
        stringBuilder.append(maxNetworkResponseInfo.getError().getMessage());
        stringBuilder.append("\n");
      } 
      ((MaxErrorImpl)paramMaxError).setAdLoadFailureInfo(stringBuilder.toString());
    } 
    long l = SystemClock.elapsedRealtime() - this.k;
    y y = this.h;
    if (y.a()) {
      y = this.h;
      String str = this.g;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Waterfall failed in ");
      stringBuilder.append(l);
      stringBuilder.append("ms with error: ");
      stringBuilder.append(paramMaxError);
      y.c(str, stringBuilder.toString());
    } 
    ((MaxErrorImpl)paramMaxError).setWaterfall((MaxAdWaterfallInfo)new MaxAdWaterfallInfoImpl(null, JsonUtils.getString(this.d, "waterfall_name", ""), JsonUtils.getString(this.d, "waterfall_test_name", ""), l, this.l));
    k.a((MaxAdListener)this.i, this.b, paramMaxError);
  }
  
  public void run() {
    Runnable runnable;
    this.k = SystemClock.elapsedRealtime();
    if (this.d.optBoolean("is_testing", false) && !this.f.av().a() && a.compareAndSet(false, true))
      AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
            public void run() {
              Utils.showAlert("MAX SDK Not Initialized In Test Mode", "Test ads may not load. Please force close and restart the app if you experience issues.", (Context)e.a(this.a).x());
            }
          }); 
    if (this.e.size() > 0) {
      y y1 = this.h;
      if (y.a()) {
        y1 = this.h;
        String str = this.g;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Starting waterfall for ");
        stringBuilder.append(this.e.size());
        stringBuilder.append(" ad(s)...");
        y1.b(str, stringBuilder.toString());
      } 
      a a1 = new a(this, 0, this.e);
      this.f.M().a(a1);
      return;
    } 
    y y = this.h;
    if (y.a())
      this.h.d(this.g, "No ads were returned from the server"); 
    Utils.maybeHandleNoFillResponseForPublisher(this.b, this.c, this.d, this.f);
    JSONObject jSONObject = JsonUtils.getJSONObject(this.d, "settings", new JSONObject());
    long l = JsonUtils.getLong(jSONObject, "alfdcs", 0L);
    MaxErrorImpl maxErrorImpl = new MaxErrorImpl(204, "MAX returned no eligible ads from any mediated networks for this app/device.");
    if (l > 0L) {
      l = TimeUnit.SECONDS.toMillis(l);
      runnable = new Runnable(this, (MaxError)maxErrorImpl) {
          public void run() {
            e.a(this.b, this.a);
          }
        };
      if (JsonUtils.getBoolean(jSONObject, "alfdcs_iba", Boolean.valueOf(false)).booleanValue()) {
        f.a(l, this.f, runnable);
        return;
      } 
      AppLovinSdkUtils.runOnUiThreadDelayed(runnable, l);
      return;
    } 
    a((MaxError)runnable);
  }
  
  private class a extends a {
    private final long b = SystemClock.elapsedRealtime();
    
    private final int c;
    
    private final com.applovin.impl.mediation.a.a d;
    
    private final List<com.applovin.impl.mediation.a.a> e;
    
    a(e this$0, int param1Int, List<com.applovin.impl.mediation.a.a> param1List) {
      super(e.b(this$0), e.c(this$0));
      this.c = param1Int;
      this.d = param1List.get(param1Int);
      this.e = param1List;
    }
    
    private void a(com.applovin.impl.mediation.a.a param1a, MaxNetworkResponseInfo.AdLoadState param1AdLoadState, long param1Long, @Nullable MaxError param1MaxError) {
      boolean bool = param1a.m();
      MaxNetworkResponseInfoImpl maxNetworkResponseInfoImpl = new MaxNetworkResponseInfoImpl(param1AdLoadState, (MaxMediatedNetworkInfo)new MaxMediatedNetworkInfoImpl(c.a(param1a.X(), this.f)), param1a.k(), bool, param1Long, param1MaxError);
      e.h(this.a).add(maxNetworkResponseInfoImpl);
    }
    
    private void a(String param1String) {}
    
    public void run() {
      Activity activity;
      y y = this.h;
      if (y.a()) {
        y = this.h;
        String str = this.g;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Loading ad ");
        stringBuilder.append(this.c + 1);
        stringBuilder.append(" of ");
        stringBuilder.append(this.e.size());
        stringBuilder.append(": ");
        stringBuilder.append(this.d.Y());
        y.b(str, stringBuilder.toString());
      } 
      a("started to load ad");
      Context context = e.d(this.a).get();
      if (context instanceof Activity) {
        activity = (Activity)context;
      } else {
        activity = this.f.x();
      } 
      this.f.ap().loadThirdPartyMediatedAd(e.e(this.a), this.d, activity, (com.applovin.impl.mediation.ads.a.a)new com.applovin.impl.mediation.d.a(this, e.f(this.a)) {
            public void onAdLoadFailed(String param2String, MaxError param2MaxError) {
              long l = SystemClock.elapsedRealtime() - e.a.a(this.a);
              e.a.g(this.a);
              if (y.a()) {
                y y = e.a.i(this.a);
                String str = e.a.h(this.a);
                StringBuilder stringBuilder1 = new StringBuilder();
                stringBuilder1.append("Ad failed to load in ");
                stringBuilder1.append(l);
                stringBuilder1.append(" ms with error: ");
                stringBuilder1.append(param2MaxError);
                y.b(str, stringBuilder1.toString());
              } 
              e.a a1 = this.a;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("failed to load ad: ");
              stringBuilder.append(param2MaxError.getCode());
              e.a.a(a1, stringBuilder.toString());
              a1 = this.a;
              e.a.a(a1, e.a.j(a1), MaxNetworkResponseInfo.AdLoadState.FAILED_TO_LOAD, l, param2MaxError);
              if (e.a.e(this.a) < e.a.f(this.a).size() - 1) {
                a1 = new e.a(this.a.a, e.a.e(this.a) + 1, e.a.f(this.a));
                o.a a2 = c.a(e.g(this.a.a));
                e.a.k(this.a).M().a(a1, a2);
                return;
              } 
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-5001, "MAX returned eligible ads from mediated networks, but all ads failed to load. Inspect getWaterfall() for more info.");
              e.a(this.a.a, (MaxError)maxErrorImpl);
            }
            
            public void onAdLoaded(MaxAd param2MaxAd) {
              e.a.a(this.a, "loaded ad");
              long l = SystemClock.elapsedRealtime() - e.a.a(this.a);
              e.a.b(this.a);
              if (y.a()) {
                y y = e.a.d(this.a);
                String str = e.a.c(this.a);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Ad loaded in ");
                stringBuilder.append(l);
                stringBuilder.append("ms");
                y.b(str, stringBuilder.toString());
              } 
              e.a a2 = this.a;
              com.applovin.impl.mediation.a.a a1 = (com.applovin.impl.mediation.a.a)param2MaxAd;
              e.a.a(a2, a1, MaxNetworkResponseInfo.AdLoadState.AD_LOADED, l, (MaxError)null);
              int i = e.a.e(this.a);
              while (true) {
                if (++i < e.a.f(this.a).size()) {
                  a2 = this.a;
                  e.a.a(a2, e.a.f(a2).get(i), MaxNetworkResponseInfo.AdLoadState.AD_LOAD_NOT_ATTEMPTED, -1L, (MaxError)null);
                  continue;
                } 
                e.a(this.a.a, a1);
                return;
              } 
            }
          });
    }
  }
  
  class null extends com.applovin.impl.mediation.d.a {
    null(e this$0, com.applovin.impl.mediation.ads.a.a param1a) {
      super(param1a);
    }
    
    public void onAdLoadFailed(String param1String, MaxError param1MaxError) {
      long l = SystemClock.elapsedRealtime() - e.a.a(this.a);
      e.a.g(this.a);
      if (y.a()) {
        y y = e.a.i(this.a);
        String str = e.a.h(this.a);
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Ad failed to load in ");
        stringBuilder1.append(l);
        stringBuilder1.append(" ms with error: ");
        stringBuilder1.append(param1MaxError);
        y.b(str, stringBuilder1.toString());
      } 
      e.a a1 = this.a;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("failed to load ad: ");
      stringBuilder.append(param1MaxError.getCode());
      e.a.a(a1, stringBuilder.toString());
      a1 = this.a;
      e.a.a(a1, e.a.j(a1), MaxNetworkResponseInfo.AdLoadState.FAILED_TO_LOAD, l, param1MaxError);
      if (e.a.e(this.a) < e.a.f(this.a).size() - 1) {
        a1 = new e.a(this.a.a, e.a.e(this.a) + 1, e.a.f(this.a));
        o.a a2 = c.a(e.g(this.a.a));
        e.a.k(this.a).M().a(a1, a2);
        return;
      } 
      MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-5001, "MAX returned eligible ads from mediated networks, but all ads failed to load. Inspect getWaterfall() for more info.");
      e.a(this.a.a, (MaxError)maxErrorImpl);
    }
    
    public void onAdLoaded(MaxAd param1MaxAd) {
      e.a.a(this.a, "loaded ad");
      long l = SystemClock.elapsedRealtime() - e.a.a(this.a);
      e.a.b(this.a);
      if (y.a()) {
        y y = e.a.d(this.a);
        String str = e.a.c(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ad loaded in ");
        stringBuilder.append(l);
        stringBuilder.append("ms");
        y.b(str, stringBuilder.toString());
      } 
      e.a a2 = this.a;
      com.applovin.impl.mediation.a.a a1 = (com.applovin.impl.mediation.a.a)param1MaxAd;
      e.a.a(a2, a1, MaxNetworkResponseInfo.AdLoadState.AD_LOADED, l, (MaxError)null);
      int i = e.a.e(this.a);
      while (true) {
        if (++i < e.a.f(this.a).size()) {
          a2 = this.a;
          e.a.a(a2, e.a.f(a2).get(i), MaxNetworkResponseInfo.AdLoadState.AD_LOAD_NOT_ATTEMPTED, -1L, (MaxError)null);
          continue;
        } 
        e.a(this.a.a, a1);
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\c\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */