package com.applovin.impl.mediation;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.ViewGroup;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import com.applovin.impl.mediation.a.a;
import com.applovin.impl.mediation.a.c;
import com.applovin.impl.mediation.a.e;
import com.applovin.impl.mediation.a.f;
import com.applovin.impl.mediation.a.g;
import com.applovin.impl.mediation.a.h;
import com.applovin.impl.mediation.ads.a;
import com.applovin.impl.mediation.c.d;
import com.applovin.impl.mediation.c.g;
import com.applovin.impl.mediation.c.h;
import com.applovin.impl.sdk.AppLovinBroadcastManager;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.d.f;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.w;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdRequestListener;
import com.applovin.mediation.MaxAdRevenueListener;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.listeners.MaxSignalCollectionListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterSignalCollectionParameters;
import com.applovin.sdk.AppLovinSdkUtils;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.json.JSONObject;

public class MediationServiceImpl implements AppLovinBroadcastManager.Receiver {
  private final p a;
  
  private final y b;
  
  private final AtomicReference<JSONObject> c = new AtomicReference<JSONObject>();
  
  public MediationServiceImpl(p paramp) {
    this.a = paramp;
    this.b = paramp.L();
    AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.render_process_gone"));
  }
  
  private i a(c paramc) {
    StringBuilder stringBuilder;
    i i = paramc.i();
    if (i == null) {
      this.a.Z().a(false);
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Failed to show ");
        stringBuilder1.append(paramc);
        stringBuilder1.append(": adapter not found");
        y1.d("MediationService", stringBuilder1.toString());
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("There may be an integration problem with the adapter for ad unit id '");
      stringBuilder.append(paramc.getAdUnitId());
      stringBuilder.append("'. Please check if you have a supported version of that SDK integrated into your project.");
      y.i("MediationService", stringBuilder.toString());
      throw new IllegalStateException("Could not find adapter for provided ad");
    } 
    return (i)stringBuilder;
  }
  
  private void a(a parama) {
    this.a.ab().a(parama, "DID_LOAD");
    if (parama.f().endsWith("load"))
      this.a.ab().a(parama); 
    Map<String, String> map = CollectionUtils.map(3);
    map.put("{LOAD_TIME_MS}", String.valueOf(parama.v()));
    if (parama.getFormat().isFullscreenAd()) {
      w.a a1 = this.a.Z().b(parama.getAdUnitId());
      map.put("{SHOW_ATTEMPT_COUNT}", String.valueOf(a1.b()));
      map.put("{SHOW_ATTEMPT_TIMESTAMP_MS}", String.valueOf(a1.a()));
    } 
    a("load", map, (f)parama);
  }
  
  private void a(a parama, a.a parama1) {
    this.a.ab().a(parama, "DID_CLICKED");
    this.a.ab().a(parama, "DID_CLICK");
    if (parama.f().endsWith("click")) {
      this.a.ab().a(parama);
      k.a((MaxAdRevenueListener)parama1, (MaxAd)parama);
    } 
    Map<String, String> map = CollectionUtils.map(1);
    String str = StringUtils.emptyIfNull(this.a.o());
    if (!((Boolean)this.a.a(b.dR)).booleanValue())
      str = ""; 
    map.put("{CUID}", str);
    List<String> list = Arrays.asList(new String[] { "1", "12", "123", "1234" });
    if (((Boolean)this.a.a(b.fT)).booleanValue())
      Collections.sort(list, (Comparator<? super String>)-$.Lambda.MediationServiceImpl.HGgqDpGsfvUHjrsOpF9-3qm17hk.INSTANCE); 
    if (((Boolean)this.a.a(b.fU)).booleanValue())
      Collections.sort(list, -$$Lambda$kBmSQXBMDwoUmxLlngPKMLmJRxE.INSTANCE); 
    if (h.f()) {
      if (((Boolean)this.a.a(b.fV)).booleanValue())
        List list1 = (List)list.stream().filter((Predicate)-$.Lambda.MediationServiceImpl.Jo7gSmfSHZMF2d_C32XZ3zdCdy0.INSTANCE).collect(Collectors.toList()); 
      if (((Boolean)this.a.a(b.fW)).booleanValue()) {
        Optional<String> optional = Optional.ofNullable(list.get(0));
        if (optional.isPresent()) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Java 8 Optional feature test: ");
          stringBuilder.append(optional.get());
          Log.d("MediationService", stringBuilder.toString());
        } 
      } 
    } 
    if (((Boolean)this.a.a(b.fX)).booleanValue())
      (new d(3)).b(); 
    a("mclick", map, (f)parama);
  }
  
  private void a(a parama, MaxError paramMaxError, MaxAdListener paramMaxAdListener) {
    a(paramMaxError, parama);
    destroyAd((MaxAd)parama);
    k.a(paramMaxAdListener, parama.getAdUnitId(), paramMaxError);
  }
  
  private void a(c paramc, a.a parama) {
    this.a.Z().a(false);
    a(paramc, (MaxAdListener)parama);
    y y1 = this.b;
    if (y.a())
      this.b.b("MediationService", "Scheduling impression for ad manually..."); 
    processRawAdImpressionPostback((a)paramc, parama);
    if (paramc.p() != null && paramc.z().get()) {
      y1 = this.b;
      if (y.a())
        this.b.b("MediationService", "Running ad displayed logic"); 
      this.a.ab().a((a)paramc, "DID_DISPLAY");
      this.a.Z().a(paramc);
      k.b((MaxAdListener)parama, (MaxAd)paramc, true);
    } 
  }
  
  private void a(c paramc, MaxAdListener paramMaxAdListener) {
    long l = ((Long)this.a.a(com.applovin.impl.sdk.c.a.F)).longValue();
    if (l <= 0L)
      return; 
    AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, paramc, l, paramMaxAdListener) {
          public void run() {
            if (this.a.z().get())
              return; 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Ad (");
            stringBuilder.append(this.a.Z());
            stringBuilder.append(") has not been displayed after ");
            stringBuilder.append(this.b);
            stringBuilder.append("ms. Failing ad display...");
            String str = stringBuilder.toString();
            y.i("MediationService", str);
            MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, str);
            MediationServiceImpl.a(this.d, (a)this.a, (MaxError)maxErrorImpl, this.c);
            MediationServiceImpl.a(this.d).Z().b(this.a);
          }
        }l);
  }
  
  private void a(MaxError paramMaxError, a parama) {
    Map<String, String> map = CollectionUtils.map(3);
    map.put("{LOAD_TIME_MS}", String.valueOf(parama.v()));
    if (parama.getFormat().isFullscreenAd()) {
      w.a a1 = this.a.Z().b(parama.getAdUnitId());
      map.put("{SHOW_ATTEMPT_COUNT}", String.valueOf(a1.b()));
      map.put("{SHOW_ATTEMPT_TIMESTAMP_MS}", String.valueOf(a1.a()));
    } 
    a("mlerr", map, paramMaxError, (f)parama);
  }
  
  private void a(MaxError paramMaxError, a parama, boolean paramBoolean) {
    a("mierr", Collections.EMPTY_MAP, paramMaxError, (f)parama, paramBoolean);
  }
  
  private void a(String paramString, h paramh, i parami) {
    Map<String, String> map = CollectionUtils.map(2);
    CollectionUtils.putStringIfValid("{ADAPTER_VERSION}", parami.i(), map);
    CollectionUtils.putStringIfValid("{SDK_VERSION}", parami.h(), map);
    a("serr", map, (MaxError)new MaxErrorImpl(paramString), (f)paramh);
  }
  
  private void a(String paramString, Map<String, String> paramMap, f paramf) {
    a(paramString, paramMap, (MaxError)null, paramf);
  }
  
  private void a(String paramString, Map<String, String> paramMap, MaxError paramMaxError, f paramf) {
    a(paramString, paramMap, paramMaxError, paramf, true);
  }
  
  private void a(String paramString, Map<String, String> paramMap, MaxError paramMaxError, f paramf, boolean paramBoolean) {
    String str1;
    Map<String, String> map = CollectionUtils.map(paramMap);
    String str2 = "";
    if (paramBoolean) {
      str1 = StringUtils.emptyIfNull(paramf.getPlacement());
    } else {
      str1 = "";
    } 
    map.put("{PLACEMENT}", str1);
    if (paramBoolean) {
      str1 = StringUtils.emptyIfNull(paramf.am());
    } else {
      str1 = "";
    } 
    map.put("{CUSTOM_DATA}", str1);
    if (paramf instanceof a) {
      a a = (a)paramf;
      str1 = str2;
      if (paramBoolean)
        str1 = StringUtils.emptyIfNull(a.getCreativeId()); 
      map.put("{CREATIVE_ID}", str1);
    } 
    d d = new d(paramString, map, paramMaxError, paramf, this.a, paramBoolean);
    this.a.M().a((com.applovin.impl.sdk.e.a)d, o.a.n);
  }
  
  private void b(a parama, MaxError paramMaxError, MaxAdListener paramMaxAdListener) {
    y y1;
    if (parama.p() != null) {
      y1 = this.b;
      if (y.a())
        this.b.e("MediationService", "Ignoring ad display failure for hybrid ad..."); 
      return;
    } 
    this.a.ab().a((a)y1, "DID_FAIL_DISPLAY");
    a(paramMaxError, (a)y1, true);
    if (y1.z().compareAndSet(false, true))
      k.a(paramMaxAdListener, (MaxAd)y1, paramMaxError); 
  }
  
  private void b(c paramc) {
    if (paramc.getFormat() == MaxAdFormat.REWARDED || paramc.getFormat() == MaxAdFormat.REWARDED_INTERSTITIAL) {
      h h = new h(paramc, this.a);
      this.a.M().a((com.applovin.impl.sdk.e.a)h, o.a.t);
    } 
  }
  
  public void collectSignal(String paramString, MaxAdFormat paramMaxAdFormat, h paramh, Context paramContext, g.a parama) {
    if (paramh != null) {
      if (paramContext != null) {
        if (parama != null) {
          y y1;
          boolean bool = paramh.b();
          i i = this.a.an().a((f)paramh, bool);
          if (i != null) {
            y y2;
            StringBuilder stringBuilder;
            Activity activity;
            if (paramContext instanceof Activity) {
              activity = (Activity)paramContext;
            } else {
              activity = this.a.x();
            } 
            MaxAdapterParametersImpl maxAdapterParametersImpl = MaxAdapterParametersImpl.a(paramh, paramString, paramMaxAdFormat);
            if (((Boolean)this.a.a(com.applovin.impl.sdk.c.a.Q)).booleanValue())
              this.a.ao().a((f)paramh, activity); 
            MaxSignalCollectionListener maxSignalCollectionListener = new MaxSignalCollectionListener(this, parama, paramh, i) {
                public void onSignalCollected(String param1String) {
                  this.a.a(g.a(this.b, this.c, param1String));
                  this.c.j();
                }
                
                public void onSignalCollectionFailed(String param1String) {
                  MediationServiceImpl.a(this.d, param1String, this.b, this.c);
                  this.a.a(g.b(this.b, this.c, param1String));
                  this.c.j();
                }
              };
            if (paramh.a()) {
              y y3;
              if (this.a.ao().a((f)paramh)) {
                y3 = this.b;
                if (y.a()) {
                  y3 = this.b;
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append("Collecting signal for now-initialized adapter: ");
                  stringBuilder1.append(i.d());
                  y3.b("MediationService", stringBuilder1.toString());
                } 
                i.a((MaxAdapterSignalCollectionParameters)maxAdapterParametersImpl, paramh, activity, maxSignalCollectionListener);
                return;
              } 
              y2 = this.b;
              if (y.a()) {
                y2 = this.b;
                stringBuilder = new StringBuilder();
                stringBuilder.append("Skip collecting signal for not-initialized adapter: ");
                stringBuilder.append(i.d());
                y2.e("MediationService", stringBuilder.toString());
              } 
              y3.a(g.a(paramh, "Adapter not initialized yet"));
              return;
            } 
            y1 = this.b;
            if (y.a()) {
              y1 = this.b;
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Collecting signal for adapter: ");
              stringBuilder1.append(i.d());
              y1.b("MediationService", stringBuilder1.toString());
            } 
            i.a((MaxAdapterSignalCollectionParameters)y2, paramh, activity, (MaxSignalCollectionListener)stringBuilder);
            return;
          } 
          y1.a(g.a(paramh, "Could not load adapter"));
          return;
        } 
        throw new IllegalArgumentException("No callback specified");
      } 
      throw new IllegalArgumentException("No context specified");
    } 
    throw new IllegalArgumentException("No spec specified");
  }
  
  public void destroyAd(MaxAd paramMaxAd) {
    if (!(paramMaxAd instanceof a))
      return; 
    y y1 = this.b;
    if (y.a()) {
      y1 = this.b;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Destroying ");
      stringBuilder.append(paramMaxAd);
      y1.c("MediationService", stringBuilder.toString());
    } 
    a a = (a)paramMaxAd;
    i i = a.i();
    if (i != null) {
      i.j();
      a.B();
    } 
    this.a.am().b(a.h());
  }
  
  public JSONObject getAndResetCustomPostBodyData() {
    return this.c.getAndSet(null);
  }
  
  public void loadAd(String paramString1, @Nullable String paramString2, MaxAdFormat paramMaxAdFormat, f.a parama, Map<String, Object> paramMap1, Map<String, Object> paramMap2, Context paramContext, a.a parama1) {
    if (!TextUtils.isEmpty(paramString1)) {
      if (paramContext != null) {
        if (parama1 != null) {
          StringBuilder stringBuilder;
          if (TextUtils.isEmpty(this.a.s()))
            y.i("AppLovinSdk", "Mediation provider is null. Please set AppLovin SDK mediation provider via AppLovinSdk.getInstance(context).setMediationProvider()"); 
          if (!this.a.d())
            y.h("AppLovinSdk", "Attempted to load ad before SDK initialization. Please wait until after the SDK has initialized, e.g. AppLovinSdk.initializeSdk(Context, SdkInitializationListener)."); 
          this.a.a();
          if (paramString1.length() != 16 && !paramString1.startsWith("test_mode") && !this.a.B().startsWith("05TMD")) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Please double-check the ad unit ");
            stringBuilder1.append(paramString1);
            stringBuilder1.append(" for ");
            stringBuilder1.append(paramMaxAdFormat.getLabel());
            stringBuilder1.append(" : ");
            stringBuilder1.append(Log.getStackTraceString(new Throwable("")));
            y.i("MediationService", stringBuilder1.toString());
          } 
          if (this.a.a(paramMaxAdFormat)) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Ad load failed due to disabled ad format ");
            stringBuilder.append(paramMaxAdFormat.getLabel());
            y.i("MediationService", stringBuilder.toString());
            stringBuilder = new StringBuilder();
            stringBuilder.append("Disabled ad format ");
            stringBuilder.append(paramMaxAdFormat.getLabel());
            k.a((MaxAdListener)parama1, paramString1, (MaxError)new MaxErrorImpl(-1, stringBuilder.toString()));
            return;
          } 
          k.a((MaxAdRequestListener)parama1, paramString1, true);
          this.a.au().a(paramString1, (String)stringBuilder, paramMaxAdFormat, parama, paramMap1, paramMap2, paramContext, parama1);
          return;
        } 
        throw new IllegalArgumentException("No listener specified");
      } 
      throw new IllegalArgumentException("No context specified");
    } 
    throw new IllegalArgumentException("No ad unit ID specified");
  }
  
  public void loadThirdPartyMediatedAd(String paramString, a parama, Activity paramActivity, a.a parama1) {
    if (parama != null) {
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Loading ");
        stringBuilder1.append(parama);
        stringBuilder1.append("...");
        y1.b("MediationService", stringBuilder1.toString());
      } 
      this.a.ab().a(parama, "WILL_LOAD");
      i i = this.a.an().a((f)parama);
      if (i != null) {
        MaxAdapterParametersImpl maxAdapterParametersImpl = MaxAdapterParametersImpl.a(parama);
        if (((Boolean)this.a.a(com.applovin.impl.sdk.c.a.R)).booleanValue())
          this.a.ao().a((f)parama, paramActivity); 
        parama = parama.a(i);
        i.a(paramString, parama);
        parama.w();
        i.a(paramString, (MaxAdapterResponseParameters)maxAdapterParametersImpl, parama, paramActivity, new a(this, parama, parama1));
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to load ");
      stringBuilder.append(parama);
      stringBuilder.append(": adapter not loaded");
      String str = stringBuilder.toString();
      y.i("MediationService", str);
      a(parama, (MaxError)new MaxErrorImpl(-5001, str), (MaxAdListener)parama1);
      return;
    } 
    throw new IllegalArgumentException("No mediated ad specified");
  }
  
  public void onReceive(Intent paramIntent, @Nullable Map<String, Object> paramMap) {
    if ("com.applovin.render_process_gone".equals(paramIntent.getAction())) {
      Object object = this.a.Z().c();
      if (object instanceof a) {
        object = object;
        a((MaxError)MaxAdapterError.WEBVIEW_ERROR, (a)object, true);
      } 
    } 
  }
  
  public void processAdDisplayErrorPostbackForUserError(MaxError paramMaxError, a parama) {
    a(paramMaxError, parama, false);
  }
  
  public void processAdLossPostback(a parama, @Nullable Float paramFloat) {
    String str;
    if (paramFloat != null) {
      str = paramFloat.toString();
    } else {
      str = "";
    } 
    Map<String, String> map = CollectionUtils.map(1);
    map.put("{MBR}", str);
    a("mloss", map, (f)parama);
  }
  
  public void processAdapterInitializationPostback(f paramf, long paramLong, MaxAdapter.InitializationStatus paramInitializationStatus, String paramString) {
    Map<String, String> map = CollectionUtils.map(2);
    map.put("{INIT_STATUS}", String.valueOf(paramInitializationStatus.getCode()));
    map.put("{INIT_TIME_MS}", String.valueOf(paramLong));
    a("minit", map, (MaxError)new MaxErrorImpl(paramString), paramf);
  }
  
  public void processCallbackAdImpressionPostback(a parama, a.a parama1) {
    if (parama.f().endsWith("cimp")) {
      this.a.ab().a(parama);
      k.a((MaxAdRevenueListener)parama1, (MaxAd)parama);
    } 
    Map<String, String> map = CollectionUtils.map(1);
    String str = StringUtils.emptyIfNull(this.a.o());
    if (!((Boolean)this.a.a(b.dR)).booleanValue())
      str = ""; 
    map.put("{CUID}", str);
    a("mcimp", map, (f)parama);
  }
  
  public void processRawAdImpressionPostback(a parama, a.a parama1) {
    this.a.ab().a(parama, "WILL_DISPLAY");
    if (parama.f().endsWith("mimp")) {
      this.a.ab().a(parama);
      k.a((MaxAdRevenueListener)parama1, (MaxAd)parama);
    } 
    Map<String, String> map = CollectionUtils.map(2);
    if (parama instanceof c)
      map.put("{TIME_TO_SHOW_MS}", String.valueOf(((c)parama).G())); 
    String str = StringUtils.emptyIfNull(this.a.o());
    if (!((Boolean)this.a.a(b.dR)).booleanValue())
      str = ""; 
    map.put("{CUID}", str);
    a("mimp", map, (f)parama);
  }
  
  public void processViewabilityAdImpressionPostback(e parame, long paramLong, a.a parama) {
    if (parame.f().endsWith("vimp")) {
      this.a.ab().a((a)parame);
      k.a((MaxAdRevenueListener)parama, (MaxAd)parame);
    } 
    Map<String, String> map = CollectionUtils.map(3);
    map.put("{VIEWABILITY_FLAGS}", String.valueOf(paramLong));
    map.put("{USED_VIEWABILITY_TIMER}", String.valueOf(parame.T()));
    String str = StringUtils.emptyIfNull(this.a.o());
    if (!((Boolean)this.a.a(b.dR)).booleanValue())
      str = ""; 
    map.put("{CUID}", str);
    a("mvimp", map, (f)parame);
  }
  
  public void setCustomPostBodyData(JSONObject paramJSONObject) {
    this.c.set(paramJSONObject);
  }
  
  public void showFullscreenAd(c paramc, Activity paramActivity, a.a parama) {
    if (paramc != null) {
      if (paramActivity != null || MaxAdFormat.APP_OPEN == paramc.getFormat()) {
        this.a.Z().a(true);
        i i = a(paramc);
        long l = paramc.H();
        y y1 = this.b;
        if (y.a()) {
          y1 = this.b;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Showing ad ");
          stringBuilder.append(paramc.getAdUnitId());
          stringBuilder.append(" with delay of ");
          stringBuilder.append(l);
          stringBuilder.append("ms...");
          y1.c("MediationService", stringBuilder.toString());
        } 
        AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, paramc, i, paramActivity, parama) {
              public void run() {
                this.a.a(true);
                MediationServiceImpl.a(this.e, this.a);
                this.b.a((a)this.a, this.c);
                MediationServiceImpl.a(this.e, this.a, this.d);
              }
            }l);
        return;
      } 
      throw new IllegalArgumentException("No activity specified");
    } 
    throw new IllegalArgumentException("No ad specified");
  }
  
  public void showFullscreenAd(c paramc, ViewGroup paramViewGroup, Lifecycle paramLifecycle, Activity paramActivity, a.a parama) {
    if (paramc != null) {
      if (paramActivity != null) {
        this.a.Z().a(true);
        i i = a(paramc);
        long l = paramc.H();
        y y1 = this.b;
        if (y.a()) {
          y1 = this.b;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Showing ad ");
          stringBuilder.append(paramc.getAdUnitId());
          stringBuilder.append(" with delay of ");
          stringBuilder.append(l);
          stringBuilder.append("ms...");
          y1.c("MediationService", stringBuilder.toString());
        } 
        AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, paramc, i, paramViewGroup, paramLifecycle, paramActivity, parama) {
              public void run() {
                this.a.a(true);
                MediationServiceImpl.a(this.g, this.a);
                this.b.a((a)this.a, this.c, this.d, this.e);
                MediationServiceImpl.a(this.g, this.a, this.f);
              }
            }l);
        return;
      } 
      throw new IllegalArgumentException("No activity specified");
    } 
    throw new IllegalArgumentException("No ad specified");
  }
  
  public class a implements a.a, MaxAdListener, MaxAdRevenueListener, MaxAdViewAdListener, MaxRewardedAdListener {
    private final a b;
    
    private a.a c;
    
    public a(MediationServiceImpl this$0, a param1a, a.a param1a1) {
      this.b = param1a;
      this.c = param1a1;
    }
    
    public void a(a.a param1a) {
      this.c = param1a;
    }
    
    public void a(@Nullable MaxAd param1MaxAd) {}
    
    public void a(MaxAd param1MaxAd, @Nullable Bundle param1Bundle) {
      this.b.a(param1Bundle);
      this.b.y();
      MediationServiceImpl.a(this.a, this.b);
      k.a((MaxAdListener)this.c, param1MaxAd);
    }
    
    public void a(MaxAd param1MaxAd, MaxError param1MaxError, @Nullable Bundle param1Bundle) {
      this.b.a(param1Bundle);
      MediationServiceImpl.a(this.a, this.b, param1MaxError, (MaxAdListener)this.c);
      if ((param1MaxAd.getFormat() == MaxAdFormat.REWARDED || param1MaxAd.getFormat() == MaxAdFormat.REWARDED_INTERSTITIAL) && param1MaxAd instanceof c)
        ((c)param1MaxAd).N(); 
    }
    
    public void a(MaxAd param1MaxAd, MaxReward param1MaxReward, @Nullable Bundle param1Bundle) {
      this.b.a(param1Bundle);
      k.a((MaxAdListener)this.c, param1MaxAd, param1MaxReward);
      g g = new g((c)param1MaxAd, MediationServiceImpl.a(this.a));
      MediationServiceImpl.a(this.a).M().a((com.applovin.impl.sdk.e.a)g, o.a.t);
    }
    
    public void b(MaxAd param1MaxAd, @Nullable Bundle param1Bundle) {
      String str;
      this.b.a(param1Bundle);
      MediationServiceImpl.b(this.a);
      if (y.a())
        MediationServiceImpl.b(this.a).b("MediationService", "Scheduling impression for ad via callback..."); 
      this.a.processCallbackAdImpressionPostback(this.b, this.c);
      MediationServiceImpl.a(this.a).P().a(f.c);
      MediationServiceImpl.a(this.a).P().a(f.f);
      if (param1MaxAd.getFormat().isFullscreenAd()) {
        c c = (c)param1MaxAd;
        if (c.T()) {
          MediationServiceImpl.a(this.a).ab().a(this.b, "DID_DISPLAY");
          MediationServiceImpl.a(this.a).Z().a(this.b);
          k.b((MaxAdListener)this.c, param1MaxAd);
          return;
        } 
        MediationServiceImpl.b(this.a);
        if (y.a()) {
          y y = MediationServiceImpl.b(this.a);
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Received ad display callback before attempting show");
          if (c.p() != null) {
            str = " for hybrid ad";
          } else {
            str = "";
          } 
          stringBuilder.append(str);
          y.d("MediationService", stringBuilder.toString());
          return;
        } 
      } else {
        MediationServiceImpl.a(this.a).ab().a(this.b, "DID_DISPLAY");
        k.b((MaxAdListener)this.c, (MaxAd)str);
      } 
    }
    
    public void c(MaxAd param1MaxAd, @Nullable Bundle param1Bundle) {
      long l;
      this.b.a(param1Bundle);
      MediationServiceImpl.a(this.a).ab().a((a)param1MaxAd, "DID_HIDE");
      if (param1MaxAd instanceof c) {
        l = ((c)param1MaxAd).I();
      } else {
        l = 0L;
      } 
      AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, param1MaxAd) {
            public void run() {
              if (this.a.getFormat().isFullscreenAd())
                MediationServiceImpl.a(this.b.a).Z().b(this.a); 
              k.c((MaxAdListener)MediationServiceImpl.a.a(this.b), this.a);
            }
          }l);
    }
    
    public void d(MaxAd param1MaxAd, @Nullable Bundle param1Bundle) {
      this.b.a(param1Bundle);
      MediationServiceImpl.a(this.a, this.b, this.c);
      k.d((MaxAdListener)this.c, param1MaxAd);
    }
    
    public void e(MaxAd param1MaxAd, @Nullable Bundle param1Bundle) {
      this.b.a(param1Bundle);
      k.g((MaxAdListener)this.c, param1MaxAd);
    }
    
    public void f(MaxAd param1MaxAd, @Nullable Bundle param1Bundle) {
      this.b.a(param1Bundle);
      k.h((MaxAdListener)this.c, param1MaxAd);
    }
    
    public void onAdClicked(MaxAd param1MaxAd) {
      d(param1MaxAd, null);
    }
    
    public void onAdCollapsed(MaxAd param1MaxAd) {
      f(param1MaxAd, null);
    }
    
    public void onAdDisplayFailed(MaxAd param1MaxAd, MaxError param1MaxError) {
      a(param1MaxAd, param1MaxError, (Bundle)null);
    }
    
    public void onAdDisplayed(MaxAd param1MaxAd) {
      b(param1MaxAd, null);
    }
    
    public void onAdExpanded(MaxAd param1MaxAd) {
      e(param1MaxAd, null);
    }
    
    public void onAdHidden(MaxAd param1MaxAd) {
      c(param1MaxAd, null);
    }
    
    public void onAdLoadFailed(String param1String, MaxError param1MaxError) {
      this.b.y();
      MediationServiceImpl.b(this.a, this.b, param1MaxError, (MaxAdListener)this.c);
    }
    
    public void onAdLoaded(MaxAd param1MaxAd) {
      a(param1MaxAd, null);
    }
    
    public void onAdRequestStarted(String param1String) {}
    
    public void onAdRevenuePaid(MaxAd param1MaxAd) {}
    
    public void onRewardedVideoCompleted(MaxAd param1MaxAd) {
      k.f((MaxAdListener)this.c, param1MaxAd);
    }
    
    public void onRewardedVideoStarted(MaxAd param1MaxAd) {
      k.e((MaxAdListener)this.c, param1MaxAd);
    }
    
    public void onUserRewarded(MaxAd param1MaxAd, MaxReward param1MaxReward) {
      a(param1MaxAd, param1MaxReward, (Bundle)null);
    }
  }
  
  class null implements Runnable {
    null(MediationServiceImpl this$0, MaxAd param1MaxAd) {}
    
    public void run() {
      if (this.a.getFormat().isFullscreenAd())
        MediationServiceImpl.a(this.b.a).Z().b(this.a); 
      k.c((MaxAdListener)MediationServiceImpl.a.a(this.b), this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\MediationServiceImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */