package com.applovin.impl.mediation;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.Nullable;
import androidx.lifecycle.Lifecycle;
import com.applovin.impl.mediation.a.a;
import com.applovin.impl.mediation.a.c;
import com.applovin.impl.mediation.a.f;
import com.applovin.impl.mediation.a.h;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.e.z;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.adapter.MaxAdViewAdapter;
import com.applovin.mediation.adapter.MaxAdapter;
import com.applovin.mediation.adapter.MaxAdapterError;
import com.applovin.mediation.adapter.MaxAppOpenAdapter;
import com.applovin.mediation.adapter.MaxInterstitialAdViewAdapter;
import com.applovin.mediation.adapter.MaxInterstitialAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdViewAdapter;
import com.applovin.mediation.adapter.MaxRewardedAdapter;
import com.applovin.mediation.adapter.MaxRewardedInterstitialAdapter;
import com.applovin.mediation.adapter.MaxSignalProvider;
import com.applovin.mediation.adapter.listeners.MaxAdViewAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxAppOpenAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxNativeAdAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxRewardedInterstitialAdapterListener;
import com.applovin.mediation.adapter.listeners.MaxSignalCollectionListener;
import com.applovin.mediation.adapter.parameters.MaxAdapterInitializationParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterResponseParameters;
import com.applovin.mediation.adapter.parameters.MaxAdapterSignalCollectionParameters;
import com.applovin.mediation.adapters.MediationAdapterBase;
import com.applovin.mediation.nativeAds.MaxNativeAd;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.sdk.AppLovinSdkUtils;
import java.util.concurrent.atomic.AtomicBoolean;

public class i {
  private final Handler a = new Handler(Looper.getMainLooper());
  
  private final p b;
  
  private final y c;
  
  private final String d;
  
  private final f e;
  
  private final String f;
  
  private MaxAdapter g;
  
  private String h;
  
  private a i;
  
  private View j;
  
  private MaxNativeAd k;
  
  private MaxNativeAdView l;
  
  private final a m = new a();
  
  private MaxAdapterResponseParameters n;
  
  private final AtomicBoolean o = new AtomicBoolean(true);
  
  private final AtomicBoolean p = new AtomicBoolean(false);
  
  private final AtomicBoolean q = new AtomicBoolean(false);
  
  private final boolean r;
  
  i(f paramf, MaxAdapter paramMaxAdapter, boolean paramBoolean, p paramp) {
    if (paramf != null) {
      if (paramMaxAdapter != null) {
        if (paramp != null) {
          this.d = paramf.Y();
          this.g = paramMaxAdapter;
          this.b = paramp;
          this.c = paramp.L();
          this.e = paramf;
          this.f = paramMaxAdapter.getClass().getSimpleName();
          this.r = paramBoolean;
          return;
        } 
        throw new IllegalArgumentException("No sdk specified");
      } 
      throw new IllegalArgumentException("No adapter specified");
    } 
    throw new IllegalArgumentException("No adapter name specified");
  }
  
  private void a(Runnable paramRunnable, a parama) {
    a("show_ad", parama.getFormat(), new Runnable(this, paramRunnable) {
          public void run() {
            try {
              this.a.run();
              return;
            } catch (Throwable throwable) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Failed to start displaying ad for ");
              stringBuilder.append(i.g(this.b));
              stringBuilder.append(" due to: ");
              stringBuilder.append(throwable);
              String str = stringBuilder.toString();
              y.i("MediationAdapterWrapper", str);
              MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, str);
              i.a.a(i.f(this.b), "show_ad", (MaxError)maxErrorImpl, null);
              i.a(this.b, "show_ad");
              i.d(this.b).an().a(i.c(this.b).X(), "show_ad", i.h(this.b));
              return;
            } 
          }
        });
  }
  
  private void a(String paramString) {
    y y1 = this.c;
    if (y.a()) {
      y1 = this.c;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Marking ");
      stringBuilder.append(this.f);
      stringBuilder.append(" as disabled due to: ");
      stringBuilder.append(paramString);
      y1.c("MediationAdapterWrapper", stringBuilder.toString());
    } 
    this.o.set(false);
  }
  
  private void a(String paramString, c paramc) {
    if (c.a(paramc).compareAndSet(false, true) && c.b(paramc) != null)
      c.b(paramc).onSignalCollected(paramString); 
  }
  
  private void a(String paramString, @Nullable MaxAdFormat paramMaxAdFormat, Runnable paramRunnable) {
    paramRunnable = new Runnable(this, paramString, paramRunnable) {
        public void run() {
          try {
            i.a(this.c);
            if (y.a()) {
              y y = i.a(this.c);
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(i.b(this.c));
              stringBuilder.append(": running ");
              stringBuilder.append(this.a);
              stringBuilder.append("...");
              y.b("MediationAdapterWrapper", stringBuilder.toString());
            } 
            this.b.run();
            i.a(this.c);
            if (y.a()) {
              y y = i.a(this.c);
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(i.b(this.c));
              stringBuilder.append(": finished ");
              stringBuilder.append(this.a);
              stringBuilder.append("");
              y.b("MediationAdapterWrapper", stringBuilder.toString());
              return;
            } 
          } catch (Throwable throwable) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failed operation ");
            stringBuilder.append(this.a);
            stringBuilder.append(" for ");
            stringBuilder.append(i.g(this.c));
            y.c("MediationAdapterWrapper", stringBuilder.toString(), throwable);
            i i1 = this.c;
            stringBuilder = new StringBuilder();
            stringBuilder.append("fail_");
            stringBuilder.append(this.a);
            i.a(i1, stringBuilder.toString());
            if (!this.a.equals("destroy"))
              i.d(this.c).an().a(i.c(this.c).X(), this.a, i.h(this.c)); 
          } 
        }
      };
    if (a(paramString, paramMaxAdFormat)) {
      this.a.post(paramRunnable);
      return;
    } 
    paramRunnable.run();
  }
  
  private void a(String paramString, Runnable paramRunnable) {
    a(paramString, (MaxAdFormat)null, paramRunnable);
  }
  
  private boolean a(String paramString, @Nullable MaxAdFormat paramMaxAdFormat) {
    Boolean bool;
    MaxAdapter maxAdapter = this.g;
    if (maxAdapter == null)
      return this.e.af(); 
    if ("initialize".equals(paramString)) {
      bool = maxAdapter.shouldInitializeOnUiThread();
      if (bool != null)
        return bool.booleanValue(); 
    } else if ("collect_signal".equals(bool)) {
      bool = maxAdapter.shouldCollectSignalsOnUiThread();
      if (bool != null)
        return bool.booleanValue(); 
    } else if ("load_ad".equals(bool) && paramMaxAdFormat != null) {
      bool = maxAdapter.shouldLoadAdsOnUiThread(paramMaxAdFormat);
      if (bool != null)
        return bool.booleanValue(); 
    } else if ("show_ad".equals(bool) && paramMaxAdFormat != null) {
      bool = maxAdapter.shouldShowAdsOnUiThread(paramMaxAdFormat);
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return this.e.af();
  }
  
  private void b(String paramString, c paramc) {
    if (c.a(paramc).compareAndSet(false, true) && c.b(paramc) != null)
      c.b(paramc).onSignalCollectionFailed(paramString); 
  }
  
  private boolean b(a parama, Activity paramActivity) {
    if (parama != null) {
      MaxErrorImpl maxErrorImpl;
      if (parama.i() == null) {
        y.i("MediationAdapterWrapper", "Adapter has been garbage collected");
        maxErrorImpl = new MaxErrorImpl(-1, "Adapter has been garbage collected");
        a.a(this.m, "ad_show", (MaxError)maxErrorImpl, null);
        return false;
      } 
      if (maxErrorImpl.i() == this) {
        if (paramActivity != null || MaxAdFormat.APP_OPEN == maxErrorImpl.getFormat()) {
          if (!this.o.get()) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Mediation adapter '");
            stringBuilder1.append(this.f);
            stringBuilder1.append("' is disabled. Showing ads with this adapter is disabled.");
            String str = stringBuilder1.toString();
            y.i("MediationAdapterWrapper", str);
            MaxErrorImpl maxErrorImpl1 = new MaxErrorImpl(-1, str);
            a.a(this.m, "ad_show", (MaxError)maxErrorImpl1, null);
            return false;
          } 
          if (g())
            return true; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Mediation adapter '");
          stringBuilder.append(this.f);
          stringBuilder.append("' does not have an ad loaded. Please load an ad first");
          throw new IllegalStateException(stringBuilder.toString());
        } 
        throw new IllegalArgumentException("No activity specified");
      } 
      throw new IllegalArgumentException("Mediated ad belongs to a different adapter");
    } 
    throw new IllegalArgumentException("No mediated ad specified");
  }
  
  public View a() {
    return this.j;
  }
  
  public void a(a parama, Activity paramActivity) {
    if (b(parama, paramActivity)) {
      Runnable runnable;
      StringBuilder stringBuilder;
      if (parama.p() != null) {
        runnable = new Runnable(this, parama, paramActivity) {
            public void run() {
              i.d(this.c).aq().a((c)this.a, this.b, (MaxAdapterListener)i.f(this.c));
            }
          };
      } else if (parama.getFormat() == MaxAdFormat.INTERSTITIAL) {
        runnable = new Runnable(this, (Activity)runnable) {
            public void run() {
              ((MaxInterstitialAdapter)i.e(this.b)).showInterstitialAd(i.j(this.b), this.a, i.f(this.b));
            }
          };
      } else if (parama.getFormat() == MaxAdFormat.APP_OPEN) {
        runnable = new Runnable(this, (Activity)runnable) {
            public void run() {
              ((MaxAppOpenAdapter)i.e(this.b)).showAppOpenAd(i.j(this.b), this.a, i.f(this.b));
            }
          };
      } else if (parama.getFormat() == MaxAdFormat.REWARDED) {
        runnable = new Runnable(this, (Activity)runnable) {
            public void run() {
              ((MaxRewardedAdapter)i.e(this.b)).showRewardedAd(i.j(this.b), this.a, i.f(this.b));
            }
          };
      } else if (parama.getFormat() == MaxAdFormat.REWARDED_INTERSTITIAL) {
        runnable = new Runnable(this, (Activity)runnable) {
            public void run() {
              ((MaxRewardedInterstitialAdapter)i.e(this.b)).showRewardedInterstitialAd(i.j(this.b), this.a, i.f(this.b));
            }
          };
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to show ");
        stringBuilder.append(parama);
        stringBuilder.append(": ");
        stringBuilder.append(parama.getFormat());
        stringBuilder.append(" is not a supported ad format");
        throw new IllegalStateException(stringBuilder.toString());
      } 
      a((Runnable)stringBuilder, parama);
      return;
    } 
  }
  
  public void a(a parama, ViewGroup paramViewGroup, Lifecycle paramLifecycle, Activity paramActivity) {
    if (b(parama, paramActivity)) {
      Runnable runnable;
      StringBuilder stringBuilder;
      if (parama.getFormat() == MaxAdFormat.INTERSTITIAL) {
        runnable = new Runnable(this, paramViewGroup, paramLifecycle, paramActivity) {
            public void run() {
              ((MaxInterstitialAdViewAdapter)i.e(this.d)).showInterstitialAd(i.j(this.d), this.a, this.b, this.c, i.f(this.d));
            }
          };
      } else if (parama.getFormat() == MaxAdFormat.REWARDED) {
        runnable = new Runnable(this, (ViewGroup)runnable, paramLifecycle, paramActivity) {
            public void run() {
              ((MaxRewardedAdViewAdapter)i.e(this.d)).showRewardedAd(i.j(this.d), this.a, this.b, this.c, i.f(this.d));
            }
          };
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to show ");
        stringBuilder.append(parama);
        stringBuilder.append(": ");
        stringBuilder.append(parama.getFormat());
        stringBuilder.append(" is not a supported ad format");
        throw new IllegalStateException(stringBuilder.toString());
      } 
      a((Runnable)stringBuilder, parama);
      return;
    } 
  }
  
  void a(MaxAdapterInitializationParameters paramMaxAdapterInitializationParameters, Activity paramActivity, @Nullable Runnable paramRunnable) {
    a("initialize", new Runnable(this, paramRunnable, paramMaxAdapterInitializationParameters, paramActivity) {
          public void run() {
            long l = SystemClock.elapsedRealtime();
            i.a(this.d);
            if (y.a()) {
              y y = i.a(this.d);
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Initializing ");
              stringBuilder.append(i.b(this.d));
              stringBuilder.append(" on thread: ");
              stringBuilder.append(Thread.currentThread());
              stringBuilder.append(" with 'run_on_ui_thread' value: ");
              stringBuilder.append(i.c(this.d).af());
              y.b("MediationAdapterWrapper", stringBuilder.toString());
            } 
            i.b b = new i.b(i.d(this.d), i.c(this.d), l, this.a);
            i.e(this.d).initialize(this.b, this.c, b);
          }
        });
  }
  
  void a(MaxAdapterSignalCollectionParameters paramMaxAdapterSignalCollectionParameters, h paramh, Activity paramActivity, MaxSignalCollectionListener paramMaxSignalCollectionListener) {
    if (paramMaxSignalCollectionListener != null) {
      if (!this.o.get()) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Mediation adapter '");
        stringBuilder.append(this.f);
        stringBuilder.append("' is disabled. Signal collection ads with this adapter is disabled.");
        y.i("MediationAdapterWrapper", stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("The adapter (");
        stringBuilder.append(this.f);
        stringBuilder.append(") is disabled");
        paramMaxSignalCollectionListener.onSignalCollectionFailed(stringBuilder.toString());
        return;
      } 
      c c = new c(paramh, paramMaxSignalCollectionListener);
      MaxAdapter maxAdapter = this.g;
      if (maxAdapter instanceof MaxSignalProvider) {
        a("collect_signal", new Runnable(this, (MaxSignalProvider)maxAdapter, (MaxAdapterSignalCollectionParameters)stringBuilder, paramActivity, c, paramh) {
              public void run() {
                try {
                  this.a.collectSignal(this.b, this.c, new MaxSignalCollectionListener(this) {
                        public void onSignalCollected(String param2String) {
                          i.a(this.a.f, param2String, this.a.d);
                        }
                        
                        public void onSignalCollectionFailed(String param2String) {
                          i.b(this.a.f, param2String, this.a.d);
                        }
                      });
                } catch (Throwable throwable) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Failed signal collection for ");
                  stringBuilder.append(i.g(this.f));
                  stringBuilder.append(" due to: ");
                  stringBuilder.append(throwable);
                  String str = stringBuilder.toString();
                  y.i("MediationAdapterWrapper", str);
                  i.b(this.f, str, this.d);
                  i.a(this.f, "collect_signal");
                  i.d(this.f).an().a(i.c(this.f).X(), "collect_signal", i.h(this.f));
                } 
                if (!i.c.a(this.d).get()) {
                  if (this.e.aj() == 0L) {
                    i.a(this.f);
                    if (y.a()) {
                      y y = i.a(this.f);
                      StringBuilder stringBuilder1 = new StringBuilder();
                      stringBuilder1.append("Failing signal collection ");
                      stringBuilder1.append(this.e);
                      stringBuilder1.append(" since it has 0 timeout");
                      y.b("MediationAdapterWrapper", stringBuilder1.toString());
                    } 
                    i i1 = this.f;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("The adapter (");
                    stringBuilder.append(i.b(this.f));
                    stringBuilder.append(") has 0 timeout");
                    i.b(i1, stringBuilder.toString(), this.d);
                    return;
                  } 
                  if (this.e.aj() > 0L) {
                    i.a(this.f);
                    if (y.a()) {
                      y y = i.a(this.f);
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("Setting timeout ");
                      stringBuilder.append(this.e.aj());
                      stringBuilder.append("ms. for ");
                      stringBuilder.append(this.e);
                      y.b("MediationAdapterWrapper", stringBuilder.toString());
                    } 
                    long l = this.e.aj();
                    i.d(this.f).M().a(new i.e(this.d), o.a.l, l);
                    return;
                  } 
                  i.a(this.f);
                  if (y.a()) {
                    y y = i.a(this.f);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Negative timeout set for ");
                    stringBuilder.append(this.e);
                    stringBuilder.append(", not scheduling a timeout");
                    y.b("MediationAdapterWrapper", stringBuilder.toString());
                  } 
                } 
              }
            });
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The adapter (");
      stringBuilder.append(this.f);
      stringBuilder.append(") does not support signal collection");
      b(stringBuilder.toString(), c);
      return;
    } 
    throw new IllegalArgumentException("No callback specified");
  }
  
  public void a(MaxNativeAdView paramMaxNativeAdView) {
    this.l = paramMaxNativeAdView;
  }
  
  void a(String paramString, a parama) {
    this.h = paramString;
    this.i = parama;
  }
  
  public void a(String paramString, MaxAdapterResponseParameters paramMaxAdapterResponseParameters, a parama, Activity paramActivity, MediationServiceImpl.a parama1) {
    if (parama != null) {
      StringBuilder stringBuilder;
      String str;
      MaxAdFormat maxAdFormat;
      if (!this.o.get()) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Mediation adapter '");
        stringBuilder1.append(this.f);
        stringBuilder1.append("' was disabled due to earlier failures. Loading ads with this adapter is disabled.");
        str = stringBuilder1.toString();
        y.i("MediationAdapterWrapper", str);
        parama1.onAdLoadFailed(paramString, (MaxError)new MaxErrorImpl(-1, str));
        return;
      } 
      this.n = (MaxAdapterResponseParameters)str;
      a.a(this.m, parama1);
      if (parama.p() != null) {
        maxAdFormat = parama.p();
      } else {
        maxAdFormat = parama.getFormat();
      } 
      if (maxAdFormat == MaxAdFormat.INTERSTITIAL) {
        Runnable runnable = new Runnable(this, (MaxAdapterResponseParameters)str, paramActivity) {
            public void run() {
              ((MaxInterstitialAdapter)i.e(this.c)).loadInterstitialAd(this.a, this.b, i.f(this.c));
            }
          };
      } else if (maxAdFormat == MaxAdFormat.APP_OPEN) {
        Runnable runnable = new Runnable(this, (MaxAdapterResponseParameters)str, paramActivity) {
            public void run() {
              ((MaxAppOpenAdapter)i.e(this.c)).loadAppOpenAd(this.a, this.b, i.f(this.c));
            }
          };
      } else if (maxAdFormat == MaxAdFormat.REWARDED) {
        Runnable runnable = new Runnable(this, (MaxAdapterResponseParameters)str, paramActivity) {
            public void run() {
              ((MaxRewardedAdapter)i.e(this.c)).loadRewardedAd(this.a, this.b, i.f(this.c));
            }
          };
      } else if (maxAdFormat == MaxAdFormat.REWARDED_INTERSTITIAL) {
        Runnable runnable = new Runnable(this, (MaxAdapterResponseParameters)str, paramActivity) {
            public void run() {
              ((MaxRewardedInterstitialAdapter)i.e(this.c)).loadRewardedInterstitialAd(this.a, this.b, i.f(this.c));
            }
          };
      } else if (maxAdFormat == MaxAdFormat.NATIVE) {
        Runnable runnable = new Runnable(this, (MaxAdapterResponseParameters)str, paramActivity) {
            public void run() {
              ((MediationAdapterBase)i.e(this.c)).loadNativeAd(this.a, this.b, i.f(this.c));
            }
          };
      } else if (maxAdFormat.isAdViewAd()) {
        Runnable runnable = new Runnable(this, (MaxAdapterResponseParameters)str, maxAdFormat, paramActivity) {
            public void run() {
              ((MaxAdViewAdapter)i.e(this.d)).loadAdViewAd(this.a, this.b, this.c, i.f(this.d));
            }
          };
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to load ");
        stringBuilder.append(parama);
        stringBuilder.append(": ");
        stringBuilder.append(parama.getFormat());
        stringBuilder.append(" (");
        stringBuilder.append(parama.p());
        stringBuilder.append(") is not a supported ad format");
        throw new IllegalStateException(stringBuilder.toString());
      } 
      a("load_ad", maxAdFormat, new Runnable(this, (Runnable)stringBuilder, parama) {
            public void run() {
              try {
                this.a.run();
              } catch (Throwable throwable) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Failed to start loading ad for ");
                stringBuilder.append(i.g(this.c));
                stringBuilder.append(" due to: ");
                stringBuilder.append(throwable);
                String str = stringBuilder.toString();
                y.i("MediationAdapterWrapper", str);
                MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-1, str);
                i.a.a(i.f(this.c), "load_ad", (MaxError)maxErrorImpl);
                i.a(this.c, "load_ad");
                i.d(this.c).an().a(i.c(this.c).X(), "load_ad", i.h(this.c));
              } 
              if (!i.i(this.c).get()) {
                long l = i.c(this.c).aj();
                if (l > 0L) {
                  i.a(this.c);
                  if (y.a()) {
                    y y = i.a(this.c);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Setting timeout ");
                    stringBuilder.append(l);
                    stringBuilder.append("ms. for ");
                    stringBuilder.append(this.b);
                    y.b("MediationAdapterWrapper", stringBuilder.toString());
                  } 
                  i.d(this.c).M().a(new i.d(), o.a.l, l);
                  return;
                } 
                i.a(this.c);
                if (y.a()) {
                  y y = i.a(this.c);
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Negative timeout set for ");
                  stringBuilder.append(this.b);
                  stringBuilder.append(", not scheduling a timeout");
                  y.b("MediationAdapterWrapper", stringBuilder.toString());
                } 
              } 
            }
          });
      return;
    } 
    throw new IllegalArgumentException("No mediated ad specified");
  }
  
  public MaxNativeAd b() {
    return this.k;
  }
  
  @Nullable
  public MaxNativeAdView c() {
    return this.l;
  }
  
  public String d() {
    return this.d;
  }
  
  public MediationServiceImpl.a e() {
    return a.a(this.m);
  }
  
  public boolean f() {
    return this.o.get();
  }
  
  public boolean g() {
    return (this.p.get() && this.q.get());
  }
  
  public String h() {
    MaxAdapter maxAdapter = this.g;
    if (maxAdapter != null)
      try {
        return maxAdapter.getSdkVersion();
      } catch (Throwable throwable) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get adapter's SDK version for ");
        stringBuilder.append(this.d);
        y.c("MediationAdapterWrapper", stringBuilder.toString(), throwable);
        a("sdk_version");
        this.b.an().a(this.e.X(), "sdk_version", this.i);
      }  
    return null;
  }
  
  public String i() {
    MaxAdapter maxAdapter = this.g;
    if (maxAdapter != null)
      try {
        return maxAdapter.getAdapterVersion();
      } catch (Throwable throwable) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get adapter version for ");
        stringBuilder.append(this.d);
        y.c("MediationAdapterWrapper", stringBuilder.toString(), throwable);
        a("adapter_version");
        this.b.an().a(this.e.X(), "adapter_version", this.i);
      }  
    return null;
  }
  
  void j() {
    if (this.r)
      return; 
    a("destroy", new Runnable(this) {
          public void run() {
            i.a(this.a, "destroy");
            i.e(this.a).onDestroy();
            i.a(this.a, (MaxAdapter)null);
            i.a(this.a, (View)null);
            i.a(this.a, (MaxNativeAd)null);
            i.a(this.a, (MaxNativeAdView)null);
          }
        });
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MediationAdapterWrapper{adapterTag='");
    stringBuilder.append(this.f);
    stringBuilder.append("'");
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  private class a implements MaxAdViewAdapterListener, MaxAppOpenAdapterListener, MaxInterstitialAdapterListener, MaxNativeAdAdapterListener, MaxRewardedAdapterListener, MaxRewardedInterstitialAdapterListener {
    private MediationServiceImpl.a b;
    
    private a(i this$0) {}
    
    private void a(MediationServiceImpl.a param1a) {
      if (param1a != null) {
        this.b = param1a;
        return;
      } 
      throw new IllegalArgumentException("No listener specified");
    }
    
    private void a(String param1String, @Nullable Bundle param1Bundle) {
      y y;
      if (i.h(this.a).A().get()) {
        i.a(this.a);
        if (y.a()) {
          y = i.a(this.a);
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(i.b(this.a));
          stringBuilder.append(": blocking ad loaded callback for ");
          stringBuilder.append(i.h(this.a));
          stringBuilder.append(" since onAdHidden() has been called");
          y.e("MediationAdapterWrapper", stringBuilder.toString());
        } 
        i.d(this.a).ab().b(i.h(this.a), param1String);
        return;
      } 
      i.k(this.a).set(true);
      a(param1String, this.b, new Runnable(this, (Bundle)y) {
            public void run() {
              if (i.i(this.b.a).compareAndSet(false, true))
                i.a.a(this.b).a((MaxAd)i.h(this.b.a), this.a); 
            }
          });
    }
    
    private void a(String param1String, MaxAdListener param1MaxAdListener, Runnable param1Runnable) {
      i.m(this.a).post(new Runnable(this, param1Runnable, param1MaxAdListener, param1String) {
            public void run() {
              try {
                this.a.run();
                return;
              } catch (Exception exception) {
                MaxAdListener maxAdListener = this.b;
                if (maxAdListener != null) {
                  String str = maxAdListener.getClass().getName();
                } else {
                  maxAdListener = null;
                } 
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Failed to forward call (");
                stringBuilder.append(this.c);
                stringBuilder.append(") to ");
                stringBuilder.append((String)maxAdListener);
                y.c("MediationAdapterWrapper", stringBuilder.toString(), exception);
                return;
              } 
            }
          });
    }
    
    private void a(String param1String, MaxError param1MaxError) {
      y y;
      if (i.h(this.a).A().get()) {
        i.a(this.a);
        if (y.a()) {
          y = i.a(this.a);
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(i.b(this.a));
          stringBuilder.append(": blocking ad load failed callback for ");
          stringBuilder.append(i.h(this.a));
          stringBuilder.append(" since onAdHidden() has been called");
          y.e("MediationAdapterWrapper", stringBuilder.toString());
        } 
        i.d(this.a).ab().b(i.h(this.a), param1String);
        return;
      } 
      a(param1String, this.b, new Runnable(this, (MaxError)y) {
            public void run() {
              if (i.i(this.b.a).compareAndSet(false, true))
                i.a.a(this.b).onAdLoadFailed(i.l(this.b.a), this.a); 
            }
          });
    }
    
    private void a(String param1String, MaxError param1MaxError, @Nullable Bundle param1Bundle) {
      y y;
      StringBuilder stringBuilder;
      if (i.h(this.a).A().get()) {
        i.a(this.a);
        if (y.a()) {
          y = i.a(this.a);
          stringBuilder = new StringBuilder();
          stringBuilder.append(i.b(this.a));
          stringBuilder.append(": blocking ad display failed callback for ");
          stringBuilder.append(i.h(this.a));
          stringBuilder.append(" since onAdHidden() has been called");
          y.e("MediationAdapterWrapper", stringBuilder.toString());
        } 
        i.d(this.a).ab().b(i.h(this.a), param1String);
        return;
      } 
      a(param1String, this.b, new Runnable(this, (MaxError)y, (Bundle)stringBuilder) {
            public void run() {
              i.a.a(this.c).a((MaxAd)i.h(this.c.a), this.a, this.b);
            }
          });
    }
    
    private void b(String param1String, @Nullable Bundle param1Bundle) {
      y y;
      if (i.h(this.a).A().get()) {
        i.a(this.a);
        if (y.a()) {
          y = i.a(this.a);
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(i.b(this.a));
          stringBuilder.append(": blocking ad displayed callback for ");
          stringBuilder.append(i.h(this.a));
          stringBuilder.append(" since onAdHidden() has been called");
          y.e("MediationAdapterWrapper", stringBuilder.toString());
        } 
        i.d(this.a).ab().b(i.h(this.a), param1String);
        return;
      } 
      if (i.h(this.a).z().compareAndSet(false, true))
        a(param1String, this.b, new Runnable(this, (Bundle)y) {
              public void run() {
                i.a.a(this.b).b((MaxAd)i.h(this.b.a), this.a);
              }
            }); 
    }
    
    private void c(String param1String, @Nullable Bundle param1Bundle) {
      if (i.h(this.a).A().compareAndSet(false, true))
        a(param1String, this.b, new Runnable(this, param1Bundle) {
              public void run() {
                i.a.a(this.b).c((MaxAd)i.h(this.b.a), this.a);
              }
            }); 
    }
    
    public void onAdViewAdClicked() {
      onAdViewAdClicked(null);
    }
    
    public void onAdViewAdClicked(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": adview ad clicked with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAdViewAdClicked", this.b, new Runnable(this, param1Bundle) {
            public void run() {
              i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
            }
          });
    }
    
    public void onAdViewAdCollapsed() {
      onAdViewAdCollapsed(null);
    }
    
    public void onAdViewAdCollapsed(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": adview ad collapsed");
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAdViewAdCollapsed", this.b, new Runnable(this) {
            public void run() {
              i.a.a(this.a).onAdCollapsed((MaxAd)i.h(this.a.a));
            }
          });
    }
    
    public void onAdViewAdDisplayFailed(MaxAdapterError param1MaxAdapterError) {
      onAdViewAdDisplayFailed(param1MaxAdapterError, null);
    }
    
    public void onAdViewAdDisplayFailed(MaxAdapterError param1MaxAdapterError, @Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": adview ad failed to display with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAdViewAdDisplayFailed", (MaxError)param1MaxAdapterError, param1Bundle);
    }
    
    public void onAdViewAdDisplayed() {
      onAdViewAdDisplayed(null);
    }
    
    public void onAdViewAdDisplayed(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": adview ad displayed with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      b("onAdViewAdDisplayed", param1Bundle);
    }
    
    public void onAdViewAdExpanded() {
      onAdViewAdExpanded(null);
    }
    
    public void onAdViewAdExpanded(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": adview ad expanded");
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAdViewAdExpanded", this.b, new Runnable(this, param1Bundle) {
            public void run() {
              i.a.a(this.b).e((MaxAd)i.h(this.b.a), this.a);
            }
          });
    }
    
    public void onAdViewAdHidden() {
      onAdViewAdHidden(null);
    }
    
    public void onAdViewAdHidden(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": adview ad hidden with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      c("onAdViewAdHidden", param1Bundle);
    }
    
    public void onAdViewAdLoadFailed(MaxAdapterError param1MaxAdapterError) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": adview ad ad failed to load with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAdViewAdLoadFailed", (MaxError)param1MaxAdapterError);
    }
    
    public void onAdViewAdLoaded(View param1View) {
      onAdViewAdLoaded(param1View, null);
    }
    
    public void onAdViewAdLoaded(View param1View, @Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": adview ad loaded with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      i.a(this.a, param1View);
      a("onAdViewAdLoaded", param1Bundle);
    }
    
    public void onAppOpenAdClicked() {
      onAppOpenAdClicked(null);
    }
    
    public void onAppOpenAdClicked(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": app open ad clicked with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAppOpenAdClicked", this.b, new Runnable(this, param1Bundle) {
            public void run() {
              i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
            }
          });
    }
    
    public void onAppOpenAdDisplayFailed(MaxAdapterError param1MaxAdapterError) {
      onAppOpenAdDisplayFailed(param1MaxAdapterError, null);
    }
    
    public void onAppOpenAdDisplayFailed(MaxAdapterError param1MaxAdapterError, @Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": app open ad display failed with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAppOpenAdDisplayFailed", (MaxError)param1MaxAdapterError, param1Bundle);
    }
    
    public void onAppOpenAdDisplayed() {
      onAppOpenAdDisplayed(null);
    }
    
    public void onAppOpenAdDisplayed(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": app open ad displayed with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      b("onAppOpenAdDisplayed", param1Bundle);
    }
    
    public void onAppOpenAdHidden() {
      onAppOpenAdHidden(null);
    }
    
    public void onAppOpenAdHidden(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": app open ad hidden with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      c("onAppOpenAdHidden", param1Bundle);
    }
    
    public void onAppOpenAdLoadFailed(MaxAdapterError param1MaxAdapterError) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": app open ad failed to load with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAppOpenAdLoadFailed", (MaxError)param1MaxAdapterError);
    }
    
    public void onAppOpenAdLoaded() {
      onAppOpenAdLoaded(null);
    }
    
    public void onAppOpenAdLoaded(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": app open ad loaded with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onAppOpenAdLoaded", param1Bundle);
    }
    
    public void onInterstitialAdClicked() {
      onInterstitialAdClicked(null);
    }
    
    public void onInterstitialAdClicked(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": interstitial ad clicked with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onInterstitialAdClicked", this.b, new Runnable(this, param1Bundle) {
            public void run() {
              i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
            }
          });
    }
    
    public void onInterstitialAdDisplayFailed(MaxAdapterError param1MaxAdapterError) {
      onInterstitialAdDisplayFailed(param1MaxAdapterError, null);
    }
    
    public void onInterstitialAdDisplayFailed(MaxAdapterError param1MaxAdapterError, @Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": interstitial ad failed to display with error ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onInterstitialAdDisplayFailed", (MaxError)param1MaxAdapterError, param1Bundle);
    }
    
    public void onInterstitialAdDisplayed() {
      onInterstitialAdDisplayed(null);
    }
    
    public void onInterstitialAdDisplayed(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": interstitial ad displayed with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      b("onInterstitialAdDisplayed", param1Bundle);
    }
    
    public void onInterstitialAdHidden() {
      onInterstitialAdHidden(null);
    }
    
    public void onInterstitialAdHidden(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": interstitial ad hidden with extra info ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      c("onInterstitialAdHidden", param1Bundle);
    }
    
    public void onInterstitialAdLoadFailed(MaxAdapterError param1MaxAdapterError) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": interstitial ad failed to load with error ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onInterstitialAdLoadFailed", (MaxError)param1MaxAdapterError);
    }
    
    public void onInterstitialAdLoaded() {
      onInterstitialAdLoaded(null);
    }
    
    public void onInterstitialAdLoaded(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": interstitial ad loaded with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onInterstitialAdLoaded", param1Bundle);
    }
    
    public void onNativeAdClicked() {
      onNativeAdClicked(null);
    }
    
    public void onNativeAdClicked(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": native ad clicked");
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onNativeAdClicked", this.b, new Runnable(this, param1Bundle) {
            public void run() {
              i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
            }
          });
    }
    
    public void onNativeAdDisplayed(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": native ad displayed with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      b("onNativeAdDisplayed", param1Bundle);
    }
    
    public void onNativeAdLoadFailed(MaxAdapterError param1MaxAdapterError) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": native ad ad failed to load with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onNativeAdLoadFailed", (MaxError)param1MaxAdapterError);
    }
    
    public void onNativeAdLoaded(MaxNativeAd param1MaxNativeAd, @Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": native ad loaded with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      i.a(this.a, param1MaxNativeAd);
      a("onNativeAdLoaded", param1Bundle);
    }
    
    public void onRewardedAdClicked() {
      onRewardedAdClicked(null);
    }
    
    public void onRewardedAdClicked(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded ad clicked with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedAdClicked", this.b, new Runnable(this, param1Bundle) {
            public void run() {
              i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
            }
          });
    }
    
    public void onRewardedAdDisplayFailed(MaxAdapterError param1MaxAdapterError) {
      onRewardedAdDisplayFailed(param1MaxAdapterError, null);
    }
    
    public void onRewardedAdDisplayFailed(MaxAdapterError param1MaxAdapterError, @Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded ad display failed with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedAdDisplayFailed", (MaxError)param1MaxAdapterError, param1Bundle);
    }
    
    public void onRewardedAdDisplayed() {
      onRewardedAdDisplayed(null);
    }
    
    public void onRewardedAdDisplayed(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded ad displayed with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      b("onRewardedAdDisplayed", param1Bundle);
    }
    
    public void onRewardedAdHidden() {
      onRewardedAdHidden(null);
    }
    
    public void onRewardedAdHidden(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded ad hidden with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      c("onRewardedAdHidden", param1Bundle);
    }
    
    public void onRewardedAdLoadFailed(MaxAdapterError param1MaxAdapterError) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded ad failed to load with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedAdLoadFailed", (MaxError)param1MaxAdapterError);
    }
    
    public void onRewardedAdLoaded() {
      onRewardedAdLoaded(null);
    }
    
    public void onRewardedAdLoaded(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded ad loaded with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedAdLoaded", param1Bundle);
    }
    
    public void onRewardedAdVideoCompleted() {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded video completed");
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedAdVideoCompleted", this.b, new Runnable(this) {
            public void run() {
              i.a.a(this.a).onRewardedVideoCompleted((MaxAd)i.h(this.a.a));
            }
          });
    }
    
    public void onRewardedAdVideoStarted() {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded video started");
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedAdVideoStarted", this.b, new Runnable(this) {
            public void run() {
              i.a.a(this.a).onRewardedVideoStarted((MaxAd)i.h(this.a.a));
            }
          });
    }
    
    public void onRewardedInterstitialAdClicked() {
      onRewardedInterstitialAdClicked(null);
    }
    
    public void onRewardedInterstitialAdClicked(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded interstitial ad clicked with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedInterstitialAdClicked", this.b, new Runnable(this, param1Bundle) {
            public void run() {
              i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
            }
          });
    }
    
    public void onRewardedInterstitialAdDisplayFailed(MaxAdapterError param1MaxAdapterError) {
      onRewardedInterstitialAdDisplayFailed(param1MaxAdapterError, null);
    }
    
    public void onRewardedInterstitialAdDisplayFailed(MaxAdapterError param1MaxAdapterError, @Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded interstitial ad display failed with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedInterstitialAdDisplayFailed", (MaxError)param1MaxAdapterError, param1Bundle);
    }
    
    public void onRewardedInterstitialAdDisplayed() {
      onRewardedInterstitialAdDisplayed(null);
    }
    
    public void onRewardedInterstitialAdDisplayed(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded interstitial ad displayed with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      b("onRewardedInterstitialAdDisplayed", param1Bundle);
    }
    
    public void onRewardedInterstitialAdHidden() {
      onRewardedInterstitialAdHidden(null);
    }
    
    public void onRewardedInterstitialAdHidden(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded interstitial ad hidden with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      c("onRewardedInterstitialAdHidden", param1Bundle);
    }
    
    public void onRewardedInterstitialAdLoadFailed(MaxAdapterError param1MaxAdapterError) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded ad failed to load with error: ");
        stringBuilder.append(param1MaxAdapterError);
        y.d("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedInterstitialAdLoadFailed", (MaxError)param1MaxAdapterError);
    }
    
    public void onRewardedInterstitialAdLoaded() {
      onRewardedInterstitialAdLoaded(null);
    }
    
    public void onRewardedInterstitialAdLoaded(@Nullable Bundle param1Bundle) {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded interstitial ad loaded with extra info: ");
        stringBuilder.append(param1Bundle);
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedInterstitialAdLoaded", param1Bundle);
    }
    
    public void onRewardedInterstitialAdVideoCompleted() {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded interstitial completed");
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedInterstitialAdVideoCompleted", this.b, new Runnable(this) {
            public void run() {
              i.a.a(this.a).onRewardedVideoCompleted((MaxAd)i.h(this.a.a));
            }
          });
    }
    
    public void onRewardedInterstitialAdVideoStarted() {
      i.a(this.a);
      if (y.a()) {
        y y = i.a(this.a);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(": rewarded interstitial started");
        y.c("MediationAdapterWrapper", stringBuilder.toString());
      } 
      a("onRewardedInterstitialAdVideoStarted", this.b, new Runnable(this) {
            public void run() {
              i.a.a(this.a).onRewardedVideoStarted((MaxAd)i.h(this.a.a));
            }
          });
    }
    
    public void onUserRewarded(MaxReward param1MaxReward) {
      onUserRewarded(param1MaxReward, null);
    }
    
    public void onUserRewarded(MaxReward param1MaxReward, @Nullable Bundle param1Bundle) {
      if (!(i.h(this.a) instanceof c))
        return; 
      c c = (c)i.h(this.a);
      if (c.P().compareAndSet(false, true)) {
        i.a(this.a);
        if (y.a()) {
          y y = i.a(this.a);
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(i.b(this.a));
          stringBuilder.append(": user was rewarded: ");
          stringBuilder.append(param1MaxReward);
          y.c("MediationAdapterWrapper", stringBuilder.toString());
        } 
        a("onUserRewarded", this.b, new Runnable(this, c, param1MaxReward, param1Bundle) {
              public void run() {
                i.a.a(this.d).a((MaxAd)this.a, this.b, this.c);
              }
            });
      } 
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      if (i.i(this.b.a).compareAndSet(false, true))
        i.a.a(this.b).a((MaxAd)i.h(this.b.a), this.a); 
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0, Runnable param1Runnable, MaxAdListener param1MaxAdListener, String param1String) {}
    
    public void run() {
      try {
        this.a.run();
        return;
      } catch (Exception exception) {
        MaxAdListener maxAdListener = this.b;
        if (maxAdListener != null) {
          String str = maxAdListener.getClass().getName();
        } else {
          maxAdListener = null;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to forward call (");
        stringBuilder.append(this.c);
        stringBuilder.append(") to ");
        stringBuilder.append((String)maxAdListener);
        y.c("MediationAdapterWrapper", stringBuilder.toString(), exception);
        return;
      } 
    }
  }
  
  class null implements Runnable {
    null(i this$0, MaxError param1MaxError) {}
    
    public void run() {
      if (i.i(this.b.a).compareAndSet(false, true))
        i.a.a(this.b).onAdLoadFailed(i.l(this.b.a), this.a); 
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).b((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0, MaxError param1MaxError, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.c).a((MaxAd)i.h(this.c.a), this.a, this.b);
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).c((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0, c param1c, MaxReward param1MaxReward, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.d).a((MaxAd)this.a, this.b, this.c);
    }
  }
  
  class null implements Runnable {
    null(i this$0) {}
    
    public void run() {
      i.a.a(this.a).onRewardedVideoStarted((MaxAd)i.h(this.a.a));
    }
  }
  
  class null implements Runnable {
    null(i this$0) {}
    
    public void run() {
      i.a.a(this.a).onRewardedVideoCompleted((MaxAd)i.h(this.a.a));
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0) {}
    
    public void run() {
      i.a.a(this.a).onRewardedVideoStarted((MaxAd)i.h(this.a.a));
    }
  }
  
  class null implements Runnable {
    null(i this$0) {}
    
    public void run() {
      i.a.a(this.a).onRewardedVideoCompleted((MaxAd)i.h(this.a.a));
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).d((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0, Bundle param1Bundle) {}
    
    public void run() {
      i.a.a(this.b).e((MaxAd)i.h(this.b.a), this.a);
    }
  }
  
  class null implements Runnable {
    null(i this$0) {}
    
    public void run() {
      i.a.a(this.a).onAdCollapsed((MaxAd)i.h(this.a.a));
    }
  }
  
  private static class b implements MaxAdapter.OnCompletionListener {
    private final p a;
    
    private final f b;
    
    private final long c;
    
    @Nullable
    private final Runnable d;
    
    public b(p param1p, f param1f, long param1Long, @Nullable Runnable param1Runnable) {
      this.a = param1p;
      this.b = param1f;
      this.c = param1Long;
      this.d = param1Runnable;
    }
    
    public void onCompletion(MaxAdapter.InitializationStatus param1InitializationStatus, String param1String) {
      long l = this.b.ak();
      Runnable runnable = new Runnable(this, param1InitializationStatus, param1String) {
          public void run() {
            long l1 = SystemClock.elapsedRealtime();
            long l2 = i.b.a(this.c);
            i.b.c(this.c).ao().a(i.b.b(this.c), l1 - l2, this.a, this.b);
            if (i.b.d(this.c) != null)
              i.b.d(this.c).run(); 
          }
        };
      if (((Boolean)this.a.a(com.applovin.impl.sdk.c.b.fS)).booleanValue()) {
        this.a.M().a((com.applovin.impl.sdk.e.a)new z(this.a, runnable), o.a.c, Math.max(l, 0L));
        return;
      } 
      AppLovinSdkUtils.runOnUiThreadDelayed(runnable, l);
    }
  }
  
  class null implements Runnable {
    null(i this$0, MaxAdapter.InitializationStatus param1InitializationStatus, String param1String) {}
    
    public void run() {
      long l1 = SystemClock.elapsedRealtime();
      long l2 = i.b.a(this.c);
      i.b.c(this.c).ao().a(i.b.b(this.c), l1 - l2, this.a, this.b);
      if (i.b.d(this.c) != null)
        i.b.d(this.c).run(); 
    }
  }
  
  private static class c {
    private final h a;
    
    private final MaxSignalCollectionListener b;
    
    private final AtomicBoolean c = new AtomicBoolean();
    
    c(h param1h, MaxSignalCollectionListener param1MaxSignalCollectionListener) {
      this.a = param1h;
      this.b = param1MaxSignalCollectionListener;
    }
  }
  
  private class d extends com.applovin.impl.sdk.e.a {
    private d(i this$0) {
      super("TaskTimeoutMediatedAd", i.d(i.this));
    }
    
    private void a(a param1a) {
      if (param1a != null)
        this.f.ar().a(param1a); 
    }
    
    public void run() {
      if (!i.i(this.a).get()) {
        if (i.h(this.a).o()) {
          y y1 = this.h;
          if (y.a()) {
            y1 = this.h;
            String str = this.g;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(i.b(this.a));
            stringBuilder.append(" is timing out, considering JS Tag ad loaded: ");
            stringBuilder.append(i.h(this.a));
            y1.b(str, stringBuilder.toString());
          } 
          a(i.h(this.a));
          return;
        } 
        y y = this.h;
        if (y.a()) {
          y = this.h;
          String str = this.g;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(i.b(this.a));
          stringBuilder.append(" is timing out ");
          stringBuilder.append(i.h(this.a));
          stringBuilder.append("...");
          y.e(str, stringBuilder.toString());
        } 
        a(i.h(this.a));
        MaxErrorImpl maxErrorImpl = new MaxErrorImpl(-5101, "Adapter timed out");
        i.a.a(i.f(this.a), this.g, (MaxError)maxErrorImpl);
      } 
    }
  }
  
  private class e extends com.applovin.impl.sdk.e.a {
    private final i.c b;
    
    private e(i this$0, i.c param1c) {
      super("TaskTimeoutSignalCollection", i.d(i.this));
      this.b = param1c;
    }
    
    public void run() {
      if (!i.c.a(this.b).get()) {
        y y = this.h;
        if (y.a()) {
          y = this.h;
          String str = this.g;
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(i.b(this.a));
          stringBuilder1.append(" is timing out ");
          stringBuilder1.append(i.c.c(this.b));
          stringBuilder1.append("...");
          y.e(str, stringBuilder1.toString());
        } 
        i i1 = this.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("The adapter (");
        stringBuilder.append(i.b(this.a));
        stringBuilder.append(") timed out");
        i.b(i1, stringBuilder.toString(), this.b);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */