package com.applovin.impl.mediation.debugger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import com.applovin.impl.mediation.debugger.b.a.a;
import com.applovin.impl.mediation.debugger.b.b.b;
import com.applovin.impl.mediation.debugger.b.c.b;
import com.applovin.impl.mediation.debugger.c.c;
import com.applovin.impl.mediation.debugger.ui.b.b;
import com.applovin.impl.sdk.e.a;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.network.b;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.a;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxDebuggerActivity;
import com.applovin.sdk.AppLovinSdkUtils;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.utils.Logger;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;

public class b implements b.c<JSONObject> {
  private static WeakReference<MaxDebuggerActivity> a;
  
  private static final AtomicBoolean b = new AtomicBoolean();
  
  private final p c;
  
  private final y d;
  
  private final Context e;
  
  private final b f;
  
  private final Map<String, b> g = CollectionUtils.map();
  
  private final AtomicBoolean h = new AtomicBoolean();
  
  private boolean i;
  
  private int j = 2;
  
  private boolean k;
  
  @Nullable
  private Map<String, List<?>> l;
  
  private final a m;
  
  public b(p paramp) {
    this.c = paramp;
    this.d = paramp.L();
    this.e = p.y();
    this.f = new b(this.e);
    this.m = new a(paramp, (a.a)this.f);
  }
  
  private b a(JSONObject paramJSONObject) {
    return new b(JsonUtils.getString(paramJSONObject, "required_app_ads_txt_entry", ""));
  }
  
  private List<a> a(List<a> paramList, p paramp) {
    List list = paramp.C().getInitializationAdUnitIds();
    if (list == null || list.isEmpty())
      return Collections.emptyList(); 
    ArrayList<a> arrayList = new ArrayList(list.size());
    for (a a1 : paramList) {
      if (list.contains(a1.a()))
        arrayList.add(a1); 
    } 
    return arrayList;
  }
  
  private List<b> a(JSONObject paramJSONObject, p paramp) {
    JSONArray jSONArray = JsonUtils.getJSONArray(paramJSONObject, "networks", new JSONArray());
    ArrayList<b> arrayList = new ArrayList(jSONArray.length());
    for (int i = 0; i < jSONArray.length(); i++) {
      JSONObject jSONObject = JsonUtils.getJSONObject(jSONArray, i, null);
      if (jSONObject != null) {
        b b1 = new b(jSONObject, paramp);
        arrayList.add(b1);
        this.g.put(b1.m(), b1);
      } 
    } 
    Collections.sort(arrayList);
    return arrayList;
  }
  
  private List<a> a(JSONObject paramJSONObject, List<b> paramList, p paramp) {
    JSONArray jSONArray = JsonUtils.getJSONArray(paramJSONObject, "ad_units", new JSONArray());
    paramList = new ArrayList<b>(jSONArray.length());
    int i;
    for (i = 0; i < jSONArray.length(); i++) {
      JSONObject jSONObject = JsonUtils.getJSONObject(jSONArray, i, null);
      if (jSONObject != null)
        paramList.add(new a(jSONObject, this.g, paramp)); 
    } 
    Collections.sort(paramList);
    return (List)paramList;
  }
  
  private void a(List<b> paramList) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface iterator : ()Ljava/util/Iterator;
    //   6: astore_1
    //   7: aload_1
    //   8: invokeinterface hasNext : ()Z
    //   13: ifeq -> 48
    //   16: aload_1
    //   17: invokeinterface next : ()Ljava/lang/Object;
    //   22: checkcast com/applovin/impl/mediation/debugger/b/c/b
    //   25: astore_3
    //   26: aload_3
    //   27: invokevirtual e : ()Z
    //   30: ifeq -> 7
    //   33: aload_3
    //   34: invokevirtual a : ()Lcom/applovin/impl/mediation/debugger/b/c/b$a;
    //   37: getstatic com/applovin/impl/mediation/debugger/b/c/b$a.c : Lcom/applovin/impl/mediation/debugger/b/c/b$a;
    //   40: if_acmpne -> 7
    //   43: iconst_1
    //   44: istore_2
    //   45: goto -> 50
    //   48: iconst_0
    //   49: istore_2
    //   50: iload_2
    //   51: ifeq -> 74
    //   54: new com/applovin/impl/mediation/debugger/b$2
    //   57: dup
    //   58: aload_0
    //   59: invokespecial <init> : (Lcom/applovin/impl/mediation/debugger/b;)V
    //   62: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   65: ldc2_w 2
    //   68: invokevirtual toMillis : (J)J
    //   71: invokestatic runOnUiThreadDelayed : (Ljava/lang/Runnable;J)V
    //   74: return
  }
  
  private void f() {
    this.c.w().a(new a(this) {
          public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
            if (param1Activity instanceof MaxDebuggerActivity) {
              y.f("AppLovinSdk", "Started mediation debugger");
              if (!b.a(this.a) || b.d().get() != param1Activity) {
                MaxDebuggerActivity maxDebuggerActivity = (MaxDebuggerActivity)param1Activity;
                b.a(new WeakReference<MaxDebuggerActivity>(maxDebuggerActivity));
                maxDebuggerActivity.setListAdapter(b.b(this.a), b.c(this.a).w());
              } 
              b.e().set(false);
            } 
          }
          
          public void onActivityDestroyed(Activity param1Activity) {
            if (param1Activity instanceof MaxDebuggerActivity) {
              y.f("AppLovinSdk", "Mediation debugger destroyed");
              b.a((WeakReference)null);
            } 
          }
        });
  }
  
  private boolean g() {
    WeakReference<MaxDebuggerActivity> weakReference = a;
    return (weakReference != null && weakReference.get() != null);
  }
  
  public static void safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(Context paramContext, Intent paramIntent) {
    Logger.d("SafeDK-Special|SafeDK: Call> Landroid/content/Context;->startActivity(Landroid/content/Intent;)V");
    if (paramIntent == null)
      return; 
    BrandSafetyUtils.detectAdClick(paramIntent, "com.applovin");
    paramContext.startActivity(paramIntent);
  }
  
  @Nullable
  public List<?> a(String paramString) {
    Map<String, List<?>> map = this.l;
    return (map == null || map.isEmpty()) ? null : this.l.get(paramString);
  }
  
  public void a() {
    if (this.h.compareAndSet(false, true)) {
      c c1 = new c(this, this.c);
      this.c.M().a((a)c1, o.a.k);
    } 
  }
  
  public void a(int paramInt, String paramString, JSONObject paramJSONObject) {
    y y1 = this.d;
    if (y.a()) {
      y1 = this.d;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to fetch mediation debugger info: server returned ");
      stringBuilder.append(paramInt);
      y1.e("MediationDebuggerService", stringBuilder.toString());
    } 
    y.i("AppLovinSdk", "Unable to show mediation debugger.");
    this.f.a(null, null, null, null, null, null, null, this.c);
    this.h.set(false);
  }
  
  public void a(@Nullable Map<String, List<?>> paramMap) {
    this.l = paramMap;
    a();
    if (!g() && b.compareAndSet(false, true)) {
      if (!this.k) {
        f();
        this.k = true;
      } 
      Intent intent = new Intent(this.e, MaxDebuggerActivity.class);
      intent.setFlags(268435456);
      y.f("AppLovinSdk", "Starting mediation debugger...");
      safedk_Context_startActivity_97cb3195734cf5c9cc3418feeafa6dd6(this.e, intent);
      return;
    } 
    y.i("AppLovinSdk", "Mediation debugger is already showing");
  }
  
  public void a(JSONObject paramJSONObject, int paramInt) {
    List<b> list = a(paramJSONObject, this.c);
    List<a> list1 = a(paramJSONObject, list, this.c);
    List<a> list2 = a(list1, this.c);
    b b1 = a(paramJSONObject);
    JSONObject jSONObject = JsonUtils.getJSONObject(paramJSONObject, "alert", null);
    String str2 = JsonUtils.getString(jSONObject, "title", null);
    String str3 = JsonUtils.getString(jSONObject, "message", null);
    String str1 = JsonUtils.getString(paramJSONObject, "account_id", null);
    this.f.a(list, list1, list2, b1, str2, str3, str1, this.c);
    if (b1.g())
      this.m.a(); 
    if (b()) {
      AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this) {
            public void run() {
              this.a.c();
            }
          },  TimeUnit.SECONDS.toMillis(this.j));
      return;
    } 
    a(list);
  }
  
  public void a(boolean paramBoolean, int paramInt) {
    this.i = paramBoolean;
    this.j = paramInt;
  }
  
  public boolean b() {
    return this.i;
  }
  
  public void c() {
    a((Map<String, List<?>>)null);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MediationDebuggerService{, listAdapter=");
    stringBuilder.append(this.f);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugger\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */