package com.applovin.impl.mediation.debugger.ui.testmode;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.applovin.impl.sdk.utils.g;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.sdk.R;

public class AdControlButton extends RelativeLayout implements View.OnClickListener {
  private final Button a = new Button(getContext());
  
  private final com.applovin.impl.adview.a b = new com.applovin.impl.adview.a(getContext(), 20, 16842873);
  
  private b c = b.a;
  
  private MaxAdFormat d;
  
  private a e;
  
  public AdControlButton(Context paramContext) {
    this(paramContext, (AttributeSet)null, 0);
  }
  
  public AdControlButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public AdControlButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setBackgroundColor(0);
    FrameLayout frameLayout = new FrameLayout(paramContext);
    addView((View)frameLayout, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1, 17));
    this.a.setTextColor(-1);
    this.a.setOnClickListener(this);
    FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-1, -1, 17);
    frameLayout.addView((View)this.a, (ViewGroup.LayoutParams)layoutParams2);
    this.b.setColor(-1);
    FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(-1, -1, 17);
    addView((View)this.b, (ViewGroup.LayoutParams)layoutParams1);
    a(b.a);
  }
  
  private void a(b paramb) {
    if (b.b == paramb) {
      setEnabled(false);
      this.b.a();
    } else {
      setEnabled(true);
      this.b.b();
    } 
    this.a.setText(b(paramb));
    this.a.setBackgroundColor(c(paramb));
  }
  
  private String b(b paramb) {
    return (b.a == paramb) ? "Load" : ((b.b == paramb) ? "" : "Show");
  }
  
  private int c(b paramb) {
    return (b.a == paramb) ? g.a(R.color.applovin_sdk_brand_color, getContext()) : ((b.b == paramb) ? g.a(R.color.applovin_sdk_brand_color, getContext()) : g.a(R.color.applovin_sdk_adControlbutton_brightBlueColor, getContext()));
  }
  
  public b getControlState() {
    return this.c;
  }
  
  public MaxAdFormat getFormat() {
    return this.d;
  }
  
  public void onClick(View paramView) {
    a a1 = this.e;
    if (a1 != null)
      a1.onClick(this); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setControlState(b paramb) {
    if (this.c != paramb)
      a(paramb); 
    this.c = paramb;
  }
  
  public void setFormat(MaxAdFormat paramMaxAdFormat) {
    this.d = paramMaxAdFormat;
  }
  
  public void setOnClickListener(a parama) {
    this.e = parama;
  }
  
  public static interface a {
    void onClick(AdControlButton param1AdControlButton);
  }
  
  public enum b {
    a, b, c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugge\\ui\testmode\AdControlButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */