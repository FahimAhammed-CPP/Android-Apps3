package com.applovin.impl.mediation.debugger.ui.b.a;

import android.content.Context;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.SpannedString;
import android.text.TextUtils;
import com.applovin.impl.mediation.debugger.b.c.b;
import com.applovin.impl.mediation.debugger.ui.d.c;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.g;
import com.applovin.sdk.R;

public class a extends c {
  private final b a;
  
  private final Context o;
  
  public a(b paramb, Context paramContext) {
    super(c.b.d);
    this.a = paramb;
    this.o = paramContext;
    this.d = q();
    this.e = r();
  }
  
  private SpannedString q() {
    int i;
    if (c()) {
      i = -16777216;
    } else {
      i = -7829368;
    } 
    return StringUtils.createSpannedString(this.a.i(), i, 18, 1);
  }
  
  private SpannedString r() {
    if (!c())
      return null; 
    SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
    spannableStringBuilder.append((CharSequence)s());
    spannableStringBuilder.append((CharSequence)new SpannableString("\n"));
    spannableStringBuilder.append((CharSequence)t());
    if (this.a.a() == b.a.c) {
      spannableStringBuilder.append((CharSequence)new SpannableString("\n"));
      spannableStringBuilder.append((CharSequence)StringUtils.createListItemDetailSpannedString("Invalid Integration", -65536));
    } 
    return new SpannedString((CharSequence)spannableStringBuilder);
  }
  
  private SpannedString s() {
    if (this.a.d()) {
      String str;
      if (!TextUtils.isEmpty(this.a.j())) {
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder((CharSequence)StringUtils.createListItemDetailSubSpannedString("SDK\t\t\t\t\t  ", -7829368));
        spannableStringBuilder.append((CharSequence)StringUtils.createListItemDetailSpannedString(this.a.j(), -16777216));
        return new SpannedString((CharSequence)spannableStringBuilder);
      } 
      if (this.a.e()) {
        str = "Retrieving SDK Version...";
      } else {
        str = "SDK Found";
      } 
      return StringUtils.createListItemDetailSpannedString(str, -16777216);
    } 
    return StringUtils.createListItemDetailSpannedString("SDK Missing", -65536);
  }
  
  private SpannedString t() {
    if (this.a.e()) {
      if (!TextUtils.isEmpty(this.a.k())) {
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder((CharSequence)StringUtils.createListItemDetailSubSpannedString("ADAPTER  ", -7829368));
        spannableStringBuilder.append((CharSequence)StringUtils.createListItemDetailSpannedString(this.a.k(), -16777216));
        if (this.a.f()) {
          spannableStringBuilder.append((CharSequence)StringUtils.createListItemDetailSubSpannedString("  LATEST  ", Color.rgb(255, 127, 0)));
          spannableStringBuilder.append((CharSequence)StringUtils.createListItemDetailSpannedString(this.a.l(), -16777216));
        } 
        return new SpannedString((CharSequence)spannableStringBuilder);
      } 
      return StringUtils.createListItemDetailSpannedString("Adapter Found", -16777216);
    } 
    return StringUtils.createListItemDetailSpannedString("Adapter Missing", -65536);
  }
  
  public int a() {
    return c() ? R.drawable.applovin_ic_disclosure_arrow : super.g();
  }
  
  public int b() {
    return g.a(R.color.applovin_sdk_disclosureButtonColor, this.o);
  }
  
  public boolean c() {
    return (this.a.a() != b.a.a);
  }
  
  public b f() {
    return this.a;
  }
  
  public int g() {
    int i = this.a.o();
    return (i > 0) ? i : R.drawable.applovin_ic_mediation_placeholder;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MediatedNetworkListItemViewModel{text=");
    stringBuilder.append(this.d);
    stringBuilder.append(", detailText=");
    stringBuilder.append(this.e);
    stringBuilder.append(", network=");
    stringBuilder.append(this.a);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugge\\ui\b\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */