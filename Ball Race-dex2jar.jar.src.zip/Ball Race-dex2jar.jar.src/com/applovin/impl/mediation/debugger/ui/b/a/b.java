package com.applovin.impl.mediation.debugger.ui.b.a;

import android.content.Context;
import android.text.SpannedString;
import com.applovin.impl.b.a;
import com.applovin.impl.mediation.debugger.ui.d.c;

public class b extends c {
  private final a.a a;
  
  private final Context o;
  
  private final boolean p;
  
  public b(a.a parama, boolean paramBoolean, Context paramContext) {
    super(c.b.e);
    this.a = parama;
    this.o = paramContext;
    this.d = new SpannedString(parama.a());
    this.p = paramBoolean;
  }
  
  public boolean c() {
    return true;
  }
  
  public SpannedString i_() {
    return new SpannedString(this.a.b(this.o));
  }
  
  public boolean j_() {
    Boolean bool = this.a.a(this.o);
    return (bool != null) ? bool.equals(Boolean.valueOf(this.p)) : false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugge\\ui\b\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */