package com.applovin.impl.mediation.debugger.b.b;

public class b {
  private final String a;
  
  private final String b;
  
  private final String c;
  
  private final String d;
  
  private final boolean e;
  
  private final String f;
  
  private final int g;
  
  public b(String paramString) {
    this(paramString, -1);
  }
  
  public b(String paramString, int paramInt) {
    this.f = paramString;
    this.g = paramInt;
    String[] arrayOfString = paramString.split(",");
    if (arrayOfString.length == 3 || arrayOfString.length == 4) {
      bool = true;
    } else {
      bool = false;
    } 
    this.e = bool;
    boolean bool = this.e;
    paramString = "";
    if (bool) {
      this.a = a(arrayOfString[0]);
      this.b = a(arrayOfString[1]);
      this.c = a(arrayOfString[2]);
      if (arrayOfString.length == 4)
        paramString = a(arrayOfString[3]); 
      this.d = paramString;
      return;
    } 
    this.a = "";
    this.b = "";
    this.c = "";
    this.d = "";
  }
  
  private String a(String paramString) {
    return paramString.replace('­', ' ').trim();
  }
  
  public String a() {
    return this.a;
  }
  
  protected boolean a(Object paramObject) {
    return paramObject instanceof b;
  }
  
  public String b() {
    return this.b;
  }
  
  public String c() {
    return this.c;
  }
  
  public String d() {
    return this.d;
  }
  
  public String e() {
    return this.f;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof b))
      return false; 
    paramObject = paramObject;
    if (!paramObject.a(this))
      return false; 
    if (g() != paramObject.g())
      return false; 
    String str1 = a();
    String str2 = paramObject.a();
    if (str1 == null) {
      if (str2 != null)
        return false; 
    } else if (!str1.equals(str2)) {
      return false;
    } 
    str1 = b();
    str2 = paramObject.b();
    if (str1 == null) {
      if (str2 != null)
        return false; 
    } else if (!str1.equals(str2)) {
      return false;
    } 
    str1 = c();
    str2 = paramObject.c();
    if (str1 == null) {
      if (str2 != null)
        return false; 
    } else if (!str1.equals(str2)) {
      return false;
    } 
    str1 = d();
    paramObject = paramObject.d();
    if (str1 == null) {
      if (paramObject != null)
        return false; 
    } else if (!str1.equals(paramObject)) {
      return false;
    } 
    return true;
  }
  
  public int f() {
    return this.g;
  }
  
  public boolean g() {
    return this.e;
  }
  
  public int hashCode() {
    byte b1;
    int i;
    int j;
    int k;
    if (g()) {
      b1 = 79;
    } else {
      b1 = 97;
    } 
    String str = a();
    int m = 43;
    if (str == null) {
      i = 43;
    } else {
      i = str.hashCode();
    } 
    str = b();
    if (str == null) {
      j = 43;
    } else {
      j = str.hashCode();
    } 
    str = c();
    if (str == null) {
      k = 43;
    } else {
      k = str.hashCode();
    } 
    str = d();
    if (str != null)
      m = str.hashCode(); 
    return ((((b1 + 59) * 59 + i) * 59 + j) * 59 + k) * 59 + m;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppAdsTxtEntry(domainName=");
    stringBuilder.append(a());
    stringBuilder.append(", publisherId=");
    stringBuilder.append(b());
    stringBuilder.append(", relationship=");
    stringBuilder.append(c());
    stringBuilder.append(", certificateAuthorityId=");
    stringBuilder.append(d());
    stringBuilder.append(", valid=");
    stringBuilder.append(g());
    stringBuilder.append(", rawValue=");
    stringBuilder.append(e());
    stringBuilder.append(", rowNumber=");
    stringBuilder.append(f());
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugger\b\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */