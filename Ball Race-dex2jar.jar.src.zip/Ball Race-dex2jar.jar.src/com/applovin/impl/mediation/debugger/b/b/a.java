package com.applovin.impl.mediation.debugger.b.b;

import java.util.List;
import java.util.Map;

public class a {
  private final Map<String, List<b>> a;
  
  private final List<b> b;
  
  public a(Map<String, List<b>> paramMap, List<b> paramList) {
    this.a = paramMap;
    this.b = paramList;
  }
  
  public Map<String, List<b>> a() {
    return this.a;
  }
  
  protected boolean a(Object paramObject) {
    return paramObject instanceof a;
  }
  
  public List<b> b() {
    return this.b;
  }
  
  public boolean equals(Object<b> paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof a))
      return false; 
    paramObject = paramObject;
    if (!paramObject.a(this))
      return false; 
    Map<String, List<b>> map1 = a();
    Map<String, List<b>> map2 = paramObject.a();
    if (map1 == null) {
      if (map2 != null)
        return false; 
    } else if (!map1.equals(map2)) {
      return false;
    } 
    List<b> list = b();
    paramObject = (Object<b>)paramObject.b();
    if (list == null) {
      if (paramObject != null)
        return false; 
    } else if (!list.equals(paramObject)) {
      return false;
    } 
    return true;
  }
  
  public int hashCode() {
    int i;
    Map<String, List<b>> map = a();
    int j = 43;
    if (map == null) {
      i = 43;
    } else {
      i = map.hashCode();
    } 
    List<b> list = b();
    if (list != null)
      j = list.hashCode(); 
    return (i + 59) * 59 + j;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppAdsTxt(domainEntries=");
    stringBuilder.append(a());
    stringBuilder.append(", invalidEntries=");
    stringBuilder.append(b());
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugger\b\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */