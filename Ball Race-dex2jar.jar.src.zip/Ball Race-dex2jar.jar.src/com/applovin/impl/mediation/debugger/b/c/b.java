package com.applovin.impl.mediation.debugger.b.c;

import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.applovin.communicator.AppLovinCommunicator;
import com.applovin.communicator.AppLovinCommunicatorMessage;
import com.applovin.communicator.AppLovinCommunicatorSubscriber;
import com.applovin.impl.mediation.d.c;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.adapter.MaxAdapter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class b implements AppLovinCommunicatorSubscriber, Comparable<b> {
  private final Map<MaxAdFormat, String> A;
  
  private final boolean B;
  
  private final String C;
  
  private final Map<MaxAdFormat, com.applovin.impl.mediation.debugger.a.b> D;
  
  private final p a;
  
  private final a b;
  
  private int c;
  
  private final boolean d;
  
  private final boolean e;
  
  private final boolean f;
  
  private final boolean g;
  
  private final boolean h;
  
  private final boolean i;
  
  private final boolean j;
  
  private final boolean k;
  
  private final boolean l;
  
  private final boolean m;
  
  private final String n;
  
  private final String o;
  
  private final String p;
  
  private String q;
  
  private final String r;
  
  private final String s;
  
  private final String t;
  
  private final int u;
  
  private final List<MaxAdFormat> v;
  
  private final List<d> w;
  
  private final List<a> x;
  
  private final List<String> y;
  
  private final c z;
  
  public b(JSONObject paramJSONObject, p paramp) {
    String str1;
    this.a = paramp;
    this.n = JsonUtils.getString(paramJSONObject, "name", "");
    this.o = JsonUtils.getString(paramJSONObject, "display_name", "");
    this.p = JsonUtils.getString(paramJSONObject, "adapter_class", "");
    this.s = JsonUtils.getString(paramJSONObject, "latest_adapter_version", "");
    this.y = a(paramJSONObject);
    Boolean bool = Boolean.valueOf(false);
    this.j = JsonUtils.getBoolean(paramJSONObject, "hide_if_missing", bool).booleanValue();
    JSONObject jSONObject3 = JsonUtils.getJSONObject(paramJSONObject, "configuration", new JSONObject());
    this.w = a(jSONObject3, paramp);
    this.z = new c(jSONObject3, paramp);
    this.m = JsonUtils.getBoolean(jSONObject3, "java_8_required", bool).booleanValue();
    JSONObject jSONObject2 = JsonUtils.getJSONObject(jSONObject3, "test_mode", new JSONObject());
    this.l = JsonUtils.getBoolean(jSONObject2, "false_coppa_required", bool).booleanValue();
    jSONObject2 = JsonUtils.getJSONObject(jSONObject2, "network_names", null);
    if (jSONObject2 != null && jSONObject2.length() > 0) {
      Map<MaxAdFormat, String> map = CollectionUtils.map(jSONObject2.length());
      Iterator<String> iterator = jSONObject2.keys();
      while (iterator.hasNext()) {
        String str = iterator.next();
        MaxAdFormat maxAdFormat = MaxAdFormat.formatFromString(str);
        str = JsonUtils.getString(jSONObject2, str, null);
        if (maxAdFormat == null || TextUtils.isEmpty(str))
          continue; 
        map.put(maxAdFormat, str);
      } 
      this.A = map;
    } else {
      this.A = null;
    } 
    jSONObject2 = JsonUtils.getJSONObject(paramJSONObject, "test_mode", new JSONObject());
    this.h = JsonUtils.getBoolean(jSONObject2, "supported", Boolean.valueOf(true)).booleanValue();
    this.i = JsonUtils.getBoolean(paramJSONObject, "test_mode_requires_init", bool).booleanValue();
    this.t = JsonUtils.getString(jSONObject2, "message", null);
    List list = JsonUtils.getList(paramJSONObject, "existence_classes", null);
    if (list != null) {
      this.d = Utils.checkClassesExistence(list);
    } else {
      this.d = Utils.checkClassExistence(JsonUtils.getString(paramJSONObject, "existence_class", ""));
    } 
    List<?> list1 = Collections.emptyList();
    MaxAdapter maxAdapter = c.b(this.p, paramp);
    if (maxAdapter != null) {
      this.e = true;
      try {
        String str = maxAdapter.getAdapterVersion();
        try {
          if (maxAdapter.getSdkVersion() != null) {
            String str5 = maxAdapter.getSdkVersion();
          } else {
            String str5 = "";
          } 
          try {
            List<MaxAdFormat> list2 = a(maxAdapter);
            list1 = list2;
            boolean bool4 = maxAdapter.isBeta();
            list1 = list2;
          } catch (Throwable null) {}
        } catch (Throwable null) {
          String str5 = "";
        } 
      } catch (Throwable throwable) {
        String str6 = "";
        String str5 = str6;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Failed to load adapter for network ");
      stringBuilder1.append(this.n);
      stringBuilder1.append(". Please check that you have a compatible network SDK integrated. Error: ");
      stringBuilder1.append(throwable);
      y.i("MediatedNetwork", stringBuilder1.toString());
      boolean bool3 = false;
    } 
    this.e = false;
    String str2 = "";
    String str3 = str2;
    boolean bool2 = false;
    boolean bool1 = false;
    String str4 = str3;
    str3 = str2;
    this.r = str3;
    this.q = str4;
    this.v = (List)list1;
    this.k = bool2;
    this.x = a(jSONObject3, str3, paramp);
    this.g = Utils.checkClassExistence(JsonUtils.getString(JsonUtils.getJSONObject(paramJSONObject, "alternative_network", null), "adapter_class", ""));
    this.b = D();
    if (!str3.equals(this.s) && !bool1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.f = bool1;
    Context context = p.y();
    int i = this.n.lastIndexOf("_");
    if (i != -1) {
      str1 = this.n.toLowerCase().substring(0, i);
    } else {
      str1 = this.n.toLowerCase();
    } 
    Resources resources = context.getResources();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("applovin_ic_mediation_");
    stringBuilder.append(str1);
    this.u = resources.getIdentifier(stringBuilder.toString(), "drawable", context.getPackageName());
    this.c = MaxAdapter.InitializationStatus.NOT_INITIALIZED.getCode();
    AppLovinCommunicator.getInstance(context).subscribe(this, "adapter_initialization_status");
    LinkedHashMap linkedHashMap = paramp.ao().b();
    if (linkedHashMap.containsKey(this.p))
      this.c = ((Integer)linkedHashMap.get(this.p)).intValue(); 
    JSONObject jSONObject1 = JsonUtils.getJSONObject(jSONObject3, "amazon_marketplace", null);
    if (jSONObject1 != null && this.d) {
      this.B = true;
      this.C = JsonUtils.getString(jSONObject1, "test_mode_app_id", null);
      jSONObject1 = JsonUtils.getJSONObject(jSONObject1, "test_mode_slot_ids", new JSONObject());
      Map<MaxAdFormat, com.applovin.impl.mediation.debugger.a.b> map = CollectionUtils.map(jSONObject1.length());
      Iterator<String> iterator = jSONObject1.keys();
      while (iterator.hasNext()) {
        String str = iterator.next();
        MaxAdFormat maxAdFormat = MaxAdFormat.formatFromString(str);
        JSONObject jSONObject = JsonUtils.getJSONObject(jSONObject1, str, null);
        if (maxAdFormat == null || jSONObject == null)
          continue; 
        str4 = JsonUtils.getString(jSONObject, "uuid", null);
        if (str4 == null)
          continue; 
        map.put(maxAdFormat, new com.applovin.impl.mediation.debugger.a.b(str4, jSONObject, maxAdFormat));
      } 
      this.D = map;
      return;
    } 
    this.B = false;
    this.C = null;
    this.D = null;
  }
  
  private a D() {
    a a1;
    if (this.d) {
      if (this.e) {
        a1 = a.d;
      } else if (this.g) {
        a1 = a.a;
      } else {
        a1 = a.b;
      } 
    } else if (this.e) {
      a1 = a.b;
    } else {
      a1 = a.a;
    } 
    if (a1 == a.a)
      return a1; 
    Iterator<d> iterator = this.w.iterator();
    while (iterator.hasNext()) {
      if (!((d)iterator.next()).c())
        return a.c; 
    } 
    iterator = (Iterator)this.x.iterator();
    while (iterator.hasNext()) {
      if (!((a)iterator.next()).c())
        return a.c; 
    } 
    if (this.m && !p.A())
      return a.c; 
    a a2 = a1;
    if (this.z.a()) {
      a2 = a1;
      if (!this.z.b())
        a2 = a.b; 
    } 
    return a2;
  }
  
  private List<MaxAdFormat> a(MaxAdapter paramMaxAdapter) {
    ArrayList<MaxAdFormat> arrayList = new ArrayList(5);
    if (paramMaxAdapter instanceof com.applovin.mediation.adapter.MaxInterstitialAdapter)
      arrayList.add(MaxAdFormat.INTERSTITIAL); 
    if (paramMaxAdapter instanceof com.applovin.mediation.adapter.MaxAppOpenAdapter)
      arrayList.add(MaxAdFormat.APP_OPEN); 
    if (paramMaxAdapter instanceof com.applovin.mediation.adapter.MaxRewardedAdapter)
      arrayList.add(MaxAdFormat.REWARDED); 
    if (paramMaxAdapter instanceof com.applovin.mediation.adapter.MaxRewardedInterstitialAdapter)
      arrayList.add(MaxAdFormat.REWARDED_INTERSTITIAL); 
    if (paramMaxAdapter instanceof com.applovin.mediation.adapter.MaxAdViewAdapter) {
      arrayList.add(MaxAdFormat.BANNER);
      arrayList.add(MaxAdFormat.LEADER);
      arrayList.add(MaxAdFormat.MREC);
    } 
    if (paramMaxAdapter instanceof com.applovin.mediation.adapter.MaxNativeAdAdapter)
      arrayList.add(MaxAdFormat.NATIVE); 
    return arrayList;
  }
  
  @Nullable
  private List<String> a(JSONObject paramJSONObject) {
    return JsonUtils.optList(JsonUtils.getJSONArray(paramJSONObject, "supported_regions", null), null);
  }
  
  private List<d> a(JSONObject paramJSONObject, p paramp) {
    ArrayList<d> arrayList = new ArrayList();
    if (this.p.equals("com.applovin.mediation.adapters.AppLovinMediationAdapter")) {
      d d = new d("com.google.android.gms.permission.AD_ID", "Please add\n<uses-permission android:name=\"com.google.android.gms.permission.AD_ID\" />\nto your AndroidManifest.xml", p.y());
      if (d.c())
        arrayList.add(d); 
    } 
    paramJSONObject = JsonUtils.getJSONObject(paramJSONObject, "permissions", new JSONObject());
    Iterator<String> iterator = paramJSONObject.keys();
    while (true) {
      if (iterator.hasNext()) {
        try {
          String str = iterator.next();
          arrayList.add(new d(str, paramJSONObject.getString(str), p.y()));
        } catch (JSONException jSONException) {}
        continue;
      } 
      return arrayList;
    } 
  }
  
  private List<a> a(JSONObject paramJSONObject, String paramString, p paramp) {
    int j;
    JSONArray jSONArray2 = JsonUtils.getJSONArray(paramJSONObject, "dependencies", new JSONArray());
    JSONArray jSONArray1 = JsonUtils.getJSONArray(paramJSONObject, "dependencies_v2", new JSONArray());
    ArrayList<a> arrayList = new ArrayList(jSONArray2.length() + jSONArray1.length());
    byte b1 = 0;
    int i = 0;
    while (true) {
      j = b1;
      if (i < jSONArray2.length()) {
        JSONObject jSONObject = JsonUtils.getJSONObject(jSONArray2, i, null);
        if (jSONObject != null)
          arrayList.add(new a(jSONObject, paramp)); 
        i++;
        continue;
      } 
      break;
    } 
    while (j < jSONArray1.length()) {
      JSONObject jSONObject = JsonUtils.getJSONObject(jSONArray1, j, null);
      if (jSONObject != null && a.a(paramString, JsonUtils.getString(jSONObject, "min_adapter_version", null), JsonUtils.getString(jSONObject, "max_adapter_version", null)))
        arrayList.add(new a(jSONObject, paramp)); 
      j++;
    } 
    return arrayList;
  }
  
  public boolean A() {
    return this.B;
  }
  
  public String B() {
    return this.C;
  }
  
  public Map<MaxAdFormat, com.applovin.impl.mediation.debugger.a.b> C() {
    return this.D;
  }
  
  public int a(b paramb) {
    return this.o.compareToIgnoreCase(paramb.o);
  }
  
  public a a() {
    return this.b;
  }
  
  public int b() {
    return this.c;
  }
  
  public b c() {
    return !this.h ? b.a : ((this.b != a.d && (this.b != a.b || !d() || !e())) ? b.b : (!this.a.av().a() ? b.d : ((this.i && (this.c == MaxAdapter.InitializationStatus.INITIALIZED_FAILURE.getCode() || this.c == MaxAdapter.InitializationStatus.INITIALIZING.getCode())) ? b.c : b.e)));
  }
  
  public boolean d() {
    return this.d;
  }
  
  public boolean e() {
    return this.e;
  }
  
  public boolean f() {
    return this.f;
  }
  
  public boolean g() {
    return (this.b == a.a && this.j);
  }
  
  public String getCommunicatorId() {
    return "MediatedNetwork";
  }
  
  public String h() {
    return this.n;
  }
  
  public String i() {
    return this.o;
  }
  
  public String j() {
    return this.q;
  }
  
  public String k() {
    return this.r;
  }
  
  public String l() {
    return this.s;
  }
  
  public String m() {
    return this.p;
  }
  
  @Nullable
  public List<String> n() {
    return this.y;
  }
  
  public int o() {
    return this.u;
  }
  
  public void onMessageReceived(AppLovinCommunicatorMessage paramAppLovinCommunicatorMessage) {
    String str = paramAppLovinCommunicatorMessage.getMessageData().getString("adapter_class", "");
    if (this.p.equals(str)) {
      this.c = paramAppLovinCommunicatorMessage.getMessageData().getInt("init_status", 0);
      MaxAdapter maxAdapter = c.b(str, this.a);
      if (maxAdapter != null && !this.q.equals(maxAdapter.getSdkVersion())) {
        this.q = maxAdapter.getSdkVersion();
        this.a.ab().a(this.q, str);
      } 
    } 
  }
  
  public List<MaxAdFormat> p() {
    return this.v;
  }
  
  public boolean q() {
    return this.k;
  }
  
  public List<d> r() {
    return this.w;
  }
  
  public List<a> s() {
    return this.x;
  }
  
  public boolean t() {
    return this.m;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MediatedNetwork{name=");
    stringBuilder.append(this.n);
    stringBuilder.append(", displayName=");
    stringBuilder.append(this.o);
    stringBuilder.append(", sdkAvailable=");
    stringBuilder.append(this.d);
    stringBuilder.append(", sdkVersion=");
    stringBuilder.append(this.q);
    stringBuilder.append(", adapterAvailable=");
    stringBuilder.append(this.e);
    stringBuilder.append(", adapterVersion=");
    stringBuilder.append(this.r);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public final c u() {
    return this.z;
  }
  
  @Nullable
  public Map<MaxAdFormat, String> v() {
    return this.A;
  }
  
  public String w() {
    return this.t;
  }
  
  public boolean x() {
    return this.l;
  }
  
  public final p y() {
    return this.a;
  }
  
  public final String z() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("\n---------- ");
    stringBuilder.append(this.n);
    stringBuilder.append(" ----------");
    stringBuilder.append("\nStatus  - ");
    stringBuilder.append(a.a(this.b));
    stringBuilder.append("\nSDK     - ");
    boolean bool = this.d;
    String str2 = "UNAVAILABLE";
    if (bool && !TextUtils.isEmpty(this.q)) {
      str1 = this.q;
    } else {
      str1 = "UNAVAILABLE";
    } 
    stringBuilder.append(str1);
    stringBuilder.append("\nAdapter - ");
    String str1 = str2;
    if (this.e) {
      str1 = str2;
      if (!TextUtils.isEmpty(this.r))
        str1 = this.r; 
    } 
    stringBuilder.append(str1);
    if (this.z.a() && !this.z.b()) {
      stringBuilder.append("\n* ");
      stringBuilder.append(this.z.c());
    } 
    for (d d : r()) {
      if (!d.c()) {
        stringBuilder.append("\n* MISSING ");
        stringBuilder.append(d.a());
        stringBuilder.append(": ");
        stringBuilder.append(d.b());
      } 
    } 
    for (a a1 : s()) {
      if (!a1.c()) {
        stringBuilder.append("\n* MISSING ");
        stringBuilder.append(a1.a());
        stringBuilder.append(": ");
        stringBuilder.append(a1.b());
      } 
    } 
    return stringBuilder.toString();
  }
  
  public enum a {
    a("MISSING"),
    b("INCOMPLETE INTEGRATION"),
    c("INVALID INTEGRATION"),
    d("COMPLETE");
    
    private final String e;
    
    a(String param1String1) {
      this.e = param1String1;
    }
    
    private String a() {
      return this.e;
    }
  }
  
  public enum b {
    a("Not Supported", -65536, "This network does not support test mode."),
    b("Invalid Integration", -65536, "Please address all the integration issue(s) marked in red above."),
    c("Not Initialized", -65536, "Please configure this network in your MAX dashboard."),
    d("Enable", -16776961, "Please re-launch the app to enable test ads."),
    e("", -16776961, "");
    
    private final String f;
    
    private final int g;
    
    private final String h;
    
    b(String param1String1, int param1Int1, String param1String2) {
      this.f = param1String1;
      this.g = param1Int1;
      this.h = param1String2;
    }
    
    public String a() {
      return this.f;
    }
    
    public int b() {
      return this.g;
    }
    
    public String c() {
      return this.h;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugger\b\c\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */