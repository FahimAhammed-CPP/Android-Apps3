package com.applovin.impl.mediation.debugger;

import androidx.annotation.Nullable;
import com.applovin.impl.mediation.debugger.b.b.a;
import com.applovin.impl.mediation.debugger.b.b.b;
import com.applovin.impl.mediation.debugger.c.a;
import com.applovin.impl.mediation.debugger.c.b;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.y;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class a implements a.a, b.a {
  private final p a;
  
  private final a b;
  
  private a c;
  
  private String d;
  
  public a(p paramp, a parama) {
    this.a = paramp;
    this.b = parama;
  }
  
  public void a() {
    a a1 = this.c;
    if (a1 != null) {
      this.b.a(a1, this.d);
      return;
    } 
    b b = new b(this.a, this);
    this.a.M().a((com.applovin.impl.sdk.e.a)b);
  }
  
  public void a(b paramb) {
    this.b.a(paramb, (String)null);
  }
  
  public void a(b paramb, String paramString) {
    this.b.a(paramb, paramString);
  }
  
  public void a(String paramString) {
    a a1 = new a(this.a, paramString, this);
    this.a.M().a((com.applovin.impl.sdk.e.a)a1);
  }
  
  public void a(String paramString1, String paramString2) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    ArrayList<b> arrayList = new ArrayList();
    String[] arrayOfString = paramString1.split("\n");
    int k = arrayOfString.length;
    int i = 1;
    int j = 0;
    while (j < k) {
      b b = new b(arrayOfString[j], i);
      if (b.g()) {
        List<b> list;
        String str = b.a();
        if (hashMap.containsKey(str)) {
          list = (List)hashMap.get(str);
        } else {
          list = new ArrayList();
        } 
        if (list != null) {
          list.add(b);
          hashMap.put(str, list);
        } 
      } else {
        arrayList.add(b);
      } 
      j++;
      i++;
    } 
    this.c = new a(hashMap, arrayList);
    this.d = paramString2;
    this.a.L();
    if (y.a()) {
      y y = this.a.L();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("app-ads.txt fetched: ");
      stringBuilder.append(this.c);
      y.b("AppAdsTxtService", stringBuilder.toString());
    } 
    this.b.a(this.c, paramString2);
  }
  
  public static interface a {
    void a(a.b param1b, @Nullable String param1String);
    
    void a(a param1a, String param1String);
  }
  
  public enum b {
    a, b, c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugger\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */