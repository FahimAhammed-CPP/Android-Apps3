package com.applovin.impl.mediation.debugger.a;

import androidx.annotation.Nullable;
import com.amazon.device.ads.AdError;
import com.amazon.device.ads.DTBAdCallback;
import com.amazon.device.ads.DTBAdRequest;
import com.amazon.device.ads.DTBAdResponse;
import com.amazon.device.ads.DTBAdSize;
import com.applovin.mediation.MaxAdFormat;
import java.util.Arrays;
import java.util.List;

public class a implements DTBAdCallback {
  private final MaxAdFormat a;
  
  private final a b;
  
  @Nullable
  private DTBAdRequest c;
  
  public a(b paramb, MaxAdFormat paramMaxAdFormat, a parama) {
    this(Arrays.asList((Object[])new DTBAdSize[] { paramb.a() }, ), paramMaxAdFormat, parama);
  }
  
  public a(List<?> paramList, MaxAdFormat paramMaxAdFormat, a parama) {
    this.a = paramMaxAdFormat;
    this.b = parama;
    try {
      DTBAdSize[] arrayOfDTBAdSize = new DTBAdSize[paramList.size()];
      int i;
      for (i = 0;; i++) {
        if (i < paramList.size()) {
          parama = (a)paramList.get(i);
          if (parama instanceof DTBAdSize)
            arrayOfDTBAdSize[i] = (DTBAdSize)parama; 
        } else {
          this.c = new DTBAdRequest();
          this.c.setSizes(arrayOfDTBAdSize);
          return;
        } 
      } 
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  public void a() {
    DTBAdRequest dTBAdRequest = this.c;
    if (dTBAdRequest == null) {
      this.b.onAdLoadFailed(null, this.a);
      return;
    } 
    dTBAdRequest.loadAd(this);
  }
  
  public void onFailure(AdError paramAdError) {
    this.b.onAdLoadFailed(paramAdError, this.a);
  }
  
  public void onSuccess(DTBAdResponse paramDTBAdResponse) {
    this.b.onAdResponseLoaded(paramDTBAdResponse, this.a);
  }
  
  public static interface a {
    void onAdLoadFailed(AdError param1AdError, MaxAdFormat param1MaxAdFormat);
    
    void onAdResponseLoaded(DTBAdResponse param1DTBAdResponse, MaxAdFormat param1MaxAdFormat);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugger\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */