package com.applovin.impl.mediation.debugger.a;

import androidx.annotation.Nullable;
import com.amazon.device.ads.DTBAdSize;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.mediation.MaxAdFormat;
import org.json.JSONObject;

public class b {
  private final String a;
  
  @Nullable
  private final DTBAdSize b;
  
  public b(String paramString, @Nullable JSONObject paramJSONObject, MaxAdFormat paramMaxAdFormat) {
    this.a = paramString;
    this.b = a(JsonUtils.getInt(paramJSONObject, "type", a(paramMaxAdFormat).ordinal()), paramMaxAdFormat, paramString);
  }
  
  @Nullable
  private DTBAdSize a(int paramInt, MaxAdFormat paramMaxAdFormat, String paramString) {
    try {
      if (a.a.ordinal() == paramInt)
        return (DTBAdSize)new DTBAdSize.DTBVideo(320, 480, paramString); 
      if (a.b.ordinal() == paramInt)
        return new DTBAdSize(paramMaxAdFormat.getSize().getWidth(), paramMaxAdFormat.getSize().getHeight(), paramString); 
      if (a.c.ordinal() == paramInt)
        return (DTBAdSize)new DTBAdSize.DTBInterstitialAdSize(paramString); 
    } catch (Throwable throwable) {}
    return null;
  }
  
  private a a(MaxAdFormat paramMaxAdFormat) {
    return paramMaxAdFormat.isAdViewAd() ? a.b : a.c;
  }
  
  @Nullable
  public DTBAdSize a() {
    return this.b;
  }
  
  private enum a {
    a, b, c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\debugger\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */