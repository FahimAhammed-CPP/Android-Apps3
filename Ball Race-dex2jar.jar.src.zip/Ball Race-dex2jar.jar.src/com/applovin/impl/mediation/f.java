package com.applovin.impl.mediation;

import android.content.Context;
import android.os.SystemClock;
import androidx.annotation.Nullable;
import com.applovin.impl.mediation.a.a;
import com.applovin.impl.mediation.a.c;
import com.applovin.impl.mediation.ads.a;
import com.applovin.impl.mediation.c.b;
import com.applovin.impl.mediation.c.c;
import com.applovin.impl.mediation.d.c;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.k;
import com.applovin.impl.sdk.y;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdFormat;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.sdk.AppLovinSdkUtils;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;

public class f {
  private final p a;
  
  private final Map<String, d> b = CollectionUtils.map(4);
  
  private final Object c = new Object();
  
  private final Map<String, a> d = CollectionUtils.map(4);
  
  private final Object e = new Object();
  
  public f(p paramp) {
    this.a = paramp;
  }
  
  private void a(a parama) {
    synchronized (this.e) {
      if (this.d.containsKey(parama.getAdUnitId())) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ad in cache already: ");
        stringBuilder.append(parama.getAdUnitId());
        y.i("AppLovinSdk", stringBuilder.toString());
      } 
      this.d.put(parama.getAdUnitId(), parama);
      return;
    } 
  }
  
  private void a(String paramString, MaxAdFormat paramMaxAdFormat, Map<String, Object> paramMap1, Map<String, Object> paramMap2, Map<String, Object> paramMap3, Context paramContext, a.a parama) {
    b b = new b(paramString, paramMaxAdFormat, paramMap1, paramContext, this.a, new b.a(this, paramString, paramMaxAdFormat, paramMap1, paramMap2, paramMap3, paramContext, parama) {
          public void a(JSONArray param1JSONArray) {
            c c = new c(this.a, this.b, this.c, this.d, this.e, param1JSONArray, this.f, f.a(this.h), this.g);
            f.a(this.h).M().a((com.applovin.impl.sdk.e.a)c);
          }
        });
    o.a a1 = c.a(paramMaxAdFormat);
    this.a.M().a((com.applovin.impl.sdk.e.a)b, a1);
  }
  
  @Nullable
  private a b(String paramString) {
    synchronized (this.e) {
      a a = this.d.get(paramString);
      this.d.remove(paramString);
      return a;
    } 
  }
  
  private d b(String paramString1, String paramString2) {
    synchronized (this.c) {
      String str = c(paramString1, paramString2);
      d d2 = this.b.get(str);
      d d1 = d2;
      if (d2 == null) {
        d1 = new d(paramString2);
        this.b.put(str, d1);
      } 
      return d1;
    } 
  }
  
  private String c(String paramString1, @Nullable String paramString2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    if (paramString2 != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("-");
      stringBuilder1.append(paramString2);
      String str = stringBuilder1.toString();
    } else {
      paramString1 = "";
    } 
    stringBuilder.append(paramString1);
    return stringBuilder.toString();
  }
  
  public void a(String paramString1, String paramString2) {
    synchronized (this.c) {
      paramString1 = c(paramString1, paramString2);
      this.b.remove(paramString1);
      return;
    } 
  }
  
  public void a(String paramString1, @Nullable String paramString2, MaxAdFormat paramMaxAdFormat, a parama, Map<String, Object> paramMap1, Map<String, Object> paramMap2, Context paramContext, a.a parama1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lcom/applovin/impl/sdk/p;
    //   4: invokevirtual av : ()Lcom/applovin/impl/mediation/debugger/ui/testmode/c;
    //   7: invokevirtual b : ()Z
    //   10: ifne -> 41
    //   13: aload_0
    //   14: getfield a : Lcom/applovin/impl/sdk/p;
    //   17: astore #9
    //   19: invokestatic y : ()Landroid/content/Context;
    //   22: invokestatic isDspDemoApp : (Landroid/content/Context;)Z
    //   25: ifeq -> 31
    //   28: goto -> 41
    //   31: aload_0
    //   32: aload_1
    //   33: invokespecial b : (Ljava/lang/String;)Lcom/applovin/impl/mediation/a/a;
    //   36: astore #9
    //   38: goto -> 44
    //   41: aconst_null
    //   42: astore #9
    //   44: aload #9
    //   46: ifnull -> 99
    //   49: aload #9
    //   51: aload_2
    //   52: invokevirtual a : (Ljava/lang/String;)V
    //   55: aload #9
    //   57: invokevirtual i : ()Lcom/applovin/impl/mediation/i;
    //   60: invokevirtual e : ()Lcom/applovin/impl/mediation/MediationServiceImpl$a;
    //   63: aload #8
    //   65: invokevirtual a : (Lcom/applovin/impl/mediation/ads/a$a;)V
    //   68: aload #8
    //   70: aload #9
    //   72: invokeinterface onAdLoaded : (Lcom/applovin/mediation/MaxAd;)V
    //   77: aload #9
    //   79: invokevirtual f : ()Ljava/lang/String;
    //   82: ldc 'load'
    //   84: invokevirtual endsWith : (Ljava/lang/String;)Z
    //   87: ifeq -> 99
    //   90: aload #8
    //   92: aload #9
    //   94: invokeinterface onAdRevenuePaid : (Lcom/applovin/mediation/MaxAd;)V
    //   99: aload_0
    //   100: aload_1
    //   101: aload_2
    //   102: invokespecial b : (Ljava/lang/String;Ljava/lang/String;)Lcom/applovin/impl/mediation/f$d;
    //   105: astore #10
    //   107: aload #10
    //   109: invokestatic a : (Lcom/applovin/impl/mediation/f$d;)Ljava/util/concurrent/atomic/AtomicBoolean;
    //   112: iconst_0
    //   113: iconst_1
    //   114: invokevirtual compareAndSet : (ZZ)Z
    //   117: ifeq -> 216
    //   120: aload #9
    //   122: ifnonnull -> 133
    //   125: aload #10
    //   127: aload #8
    //   129: invokestatic a : (Lcom/applovin/impl/mediation/f$d;Lcom/applovin/impl/mediation/ads/a$a;)Lcom/applovin/impl/mediation/ads/a$a;
    //   132: pop
    //   133: invokestatic map : ()Ljava/util/Map;
    //   136: invokestatic synchronizedMap : (Ljava/util/Map;)Ljava/util/Map;
    //   139: astore #8
    //   141: aload #8
    //   143: ldc 'art'
    //   145: aload #4
    //   147: invokevirtual a : ()Ljava/lang/String;
    //   150: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   155: pop
    //   156: aload_2
    //   157: invokestatic isValidString : (Ljava/lang/String;)Z
    //   160: ifeq -> 174
    //   163: aload #8
    //   165: ldc 'alt'
    //   167: aload_2
    //   168: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   173: pop
    //   174: aload_0
    //   175: aload_1
    //   176: aload_3
    //   177: aload #5
    //   179: aload #6
    //   181: aload #8
    //   183: aload #7
    //   185: new com/applovin/impl/mediation/f$c
    //   188: dup
    //   189: aload #5
    //   191: aload #6
    //   193: aload #8
    //   195: aload #10
    //   197: aload_3
    //   198: invokestatic elapsedRealtime : ()J
    //   201: aload_0
    //   202: aload_0
    //   203: getfield a : Lcom/applovin/impl/sdk/p;
    //   206: aload #7
    //   208: aconst_null
    //   209: invokespecial <init> : (Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Lcom/applovin/impl/mediation/f$d;Lcom/applovin/mediation/MaxAdFormat;JLcom/applovin/impl/mediation/f;Lcom/applovin/impl/sdk/p;Landroid/content/Context;Lcom/applovin/impl/mediation/f$1;)V
    //   212: invokespecial a : (Ljava/lang/String;Lcom/applovin/mediation/MaxAdFormat;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;Landroid/content/Context;Lcom/applovin/impl/mediation/ads/a$a;)V
    //   215: return
    //   216: aload #10
    //   218: invokestatic b : (Lcom/applovin/impl/mediation/f$d;)Lcom/applovin/impl/mediation/ads/a$a;
    //   221: ifnull -> 271
    //   224: aload #10
    //   226: invokestatic b : (Lcom/applovin/impl/mediation/f$d;)Lcom/applovin/impl/mediation/ads/a$a;
    //   229: aload #8
    //   231: if_acmpeq -> 271
    //   234: new java/lang/StringBuilder
    //   237: dup
    //   238: invokespecial <init> : ()V
    //   241: astore_2
    //   242: aload_2
    //   243: ldc 'Attempting to load ad for same ad unit id ('
    //   245: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   248: pop
    //   249: aload_2
    //   250: aload_1
    //   251: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   254: pop
    //   255: aload_2
    //   256: ldc ') while another ad load is already in progress!'
    //   258: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   261: pop
    //   262: ldc 'MediationAdLoadManager'
    //   264: aload_2
    //   265: invokevirtual toString : ()Ljava/lang/String;
    //   268: invokestatic h : (Ljava/lang/String;Ljava/lang/String;)V
    //   271: aload #10
    //   273: aload #8
    //   275: invokestatic a : (Lcom/applovin/impl/mediation/f$d;Lcom/applovin/impl/mediation/ads/a$a;)Lcom/applovin/impl/mediation/ads/a$a;
    //   278: pop
    //   279: return
  }
  
  public boolean a(String paramString) {
    synchronized (this.e) {
      if (this.d.get(paramString) != null)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
    return bool;
  }
  
  public enum a {
    a("publisher_initiated"),
    b("sequential_or_precache"),
    c("refresh"),
    d("exponential_retry"),
    e("expired"),
    f("native_ad_placer");
    
    private final String g;
    
    a(String param1String1) {
      this.g = param1String1;
    }
    
    public String a() {
      return this.g;
    }
  }
  
  public static interface b {
    void a(@Nullable MaxAd param1MaxAd);
  }
  
  private static class c implements a.a {
    private final p a;
    
    private final WeakReference<Context> b;
    
    private final f c;
    
    private final f.d d;
    
    private final MaxAdFormat e;
    
    private final Map<String, Object> f;
    
    private final Map<String, Object> g;
    
    private final Map<String, Object> h;
    
    private final int i;
    
    private long j;
    
    private c(Map<String, Object> param1Map1, Map<String, Object> param1Map2, Map<String, Object> param1Map3, f.d param1d, MaxAdFormat param1MaxAdFormat, long param1Long, f param1f, p param1p, Context param1Context) {
      this.a = param1p;
      this.b = new WeakReference<Context>(param1Context);
      this.c = param1f;
      this.d = param1d;
      this.e = param1MaxAdFormat;
      this.g = param1Map2;
      this.f = param1Map1;
      this.h = param1Map3;
      this.j = param1Long;
      if (CollectionUtils.getBoolean(param1Map2, "disable_auto_retries")) {
        this.i = -1;
        return;
      } 
      if (param1MaxAdFormat.isAdViewAd() && CollectionUtils.getBoolean(param1Map2, "auto_refresh_stopped")) {
        this.i = Math.min(2, ((Integer)param1p.a(com.applovin.impl.sdk.c.a.N)).intValue());
        return;
      } 
      this.i = ((Integer)param1p.a(com.applovin.impl.sdk.c.a.N)).intValue();
    }
    
    private void b(MaxAd param1MaxAd) {
      if ((this.a.b(com.applovin.impl.sdk.c.a.M).contains(param1MaxAd.getAdUnitId()) || this.a.a(com.applovin.impl.sdk.c.a.L, param1MaxAd.getFormat())) && !this.a.av().a() && !this.a.av().b()) {
        Context context = this.b.get();
        if (context == null) {
          p p1 = this.a;
          context = p.y();
        } 
        this.j = SystemClock.elapsedRealtime();
        this.h.put("art", f.a.b.a());
        f.a(this.c, param1MaxAd.getAdUnitId(), param1MaxAd.getFormat(), this.f, this.g, this.h, context, this);
        return;
      } 
      f.d.a(this.d).set(false);
    }
    
    public void a(@Nullable MaxAd param1MaxAd) {
      if (param1MaxAd == null) {
        f.d.a(this.d, (f.b)null);
        return;
      } 
      if (param1MaxAd instanceof c && ((c)param1MaxAd).T()) {
        f.d.a(this.d, (f.b)null);
        b(param1MaxAd);
        return;
      } 
      if (f.d.d(this.d) == null) {
        f.a(this.c, (a)param1MaxAd);
        return;
      } 
      f.d.d(this.d).a(param1MaxAd);
      f.d.a(this.d, (f.b)null);
      b(param1MaxAd);
    }
    
    public void onAdClicked(MaxAd param1MaxAd) {}
    
    public void onAdDisplayFailed(MaxAd param1MaxAd, MaxError param1MaxError) {}
    
    public void onAdDisplayed(MaxAd param1MaxAd) {}
    
    public void onAdHidden(MaxAd param1MaxAd) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Wrong callback invoked for ad: ");
      stringBuilder.append(param1MaxAd);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void onAdLoadFailed(String param1String, MaxError param1MaxError) {
      if (!this.a.a(com.applovin.impl.sdk.c.a.O, this.e) || f.d.e(this.d) >= this.i) {
        f.d.a(this.d, 0);
        f.d.a(this.d).set(false);
        if (f.d.b(this.d) != null) {
          MaxErrorImpl maxErrorImpl = (MaxErrorImpl)param1MaxError;
          maxErrorImpl.setLoadTag(f.d.c(this.d));
          maxErrorImpl.setRequestLatencyMillis(SystemClock.elapsedRealtime() - this.j);
          k.a((MaxAdListener)f.d.b(this.d), param1String, param1MaxError);
          f.d.a(this.d, (a.a)null);
        } 
        return;
      } 
      f.d.f(this.d);
      int i = (int)Math.pow(2.0D, f.d.e(this.d));
      AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, i, param1String) {
            public void run() {
              f.c.a(this.c).put("retry_delay_sec", Integer.valueOf(this.a));
              f.c.a(this.c).put("retry_attempt", Integer.valueOf(f.d.e(f.c.b(this.c))));
              Context context = f.c.c(this.c).get();
              if (context == null) {
                f.c.d(this.c);
                context = p.y();
              } 
              f.c.e(this.c).put("art", f.a.d.a());
              f.c.e(this.c).put("era", Integer.valueOf(f.d.e(f.c.b(this.c))));
              f.a(f.c.h(this.c), this.b, f.c.f(this.c), f.c.g(this.c), f.c.a(this.c), f.c.e(this.c), context, this.c);
            }
          }TimeUnit.SECONDS.toMillis(i));
    }
    
    public void onAdLoaded(MaxAd param1MaxAd) {
      a.a a1;
      a a2 = (a)param1MaxAd;
      a2.a(f.d.c(this.d));
      a2.a(SystemClock.elapsedRealtime() - this.j);
      f.d.a(this.d, 0);
      if (f.d.b(this.d) != null) {
        a2.i().e().a(f.d.b(this.d));
        f.d.b(this.d).onAdLoaded((MaxAd)a2);
        if (a2.f().endsWith("load"))
          f.d.b(this.d).onAdRevenuePaid((MaxAd)a2); 
        a1 = f.d.b(this.d);
        f.d.a(this.d, (a.a)null);
        if (((Boolean)this.a.a(com.applovin.impl.sdk.c.a.W)).booleanValue()) {
          f.d.a(this.d, (f.b)a1);
          return;
        } 
        b(param1MaxAd);
        return;
      } 
      f.a(this.c, (a)a1);
      f.d.a(this.d).set(false);
    }
    
    public void onAdRequestStarted(String param1String) {}
    
    public void onAdRevenuePaid(MaxAd param1MaxAd) {}
  }
  
  class null implements Runnable {
    null(f this$0, int param1Int, String param1String) {}
    
    public void run() {
      f.c.a(this.c).put("retry_delay_sec", Integer.valueOf(this.a));
      f.c.a(this.c).put("retry_attempt", Integer.valueOf(f.d.e(f.c.b(this.c))));
      Context context = f.c.c(this.c).get();
      if (context == null) {
        f.c.d(this.c);
        context = p.y();
      } 
      f.c.e(this.c).put("art", f.a.d.a());
      f.c.e(this.c).put("era", Integer.valueOf(f.d.e(f.c.b(this.c))));
      f.a(f.c.h(this.c), this.b, f.c.f(this.c), f.c.g(this.c), f.c.a(this.c), f.c.e(this.c), context, this.c);
    }
  }
  
  private static class d {
    private final String a;
    
    private final AtomicBoolean b = new AtomicBoolean();
    
    private int c;
    
    private volatile a.a d;
    
    private volatile f.b e;
    
    private d(String param1String) {
      this.a = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\mediation\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */