package com.applovin.impl.sdk;

import androidx.annotation.Nullable;
import com.applovin.impl.sdk.ad.g;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.utils.p;
import java.lang.ref.WeakReference;

public class c {
  private final p a;
  
  private final WeakReference<g> b;
  
  private final WeakReference<d.a> c;
  
  @Nullable
  private p d;
  
  private c(g paramg, d.a parama, p paramp) {
    this.b = new WeakReference<g>(paramg);
    this.c = new WeakReference<d.a>(parama);
    this.a = paramp;
  }
  
  public static c a(g paramg, d.a parama, p paramp) {
    c c1 = new c(paramg, parama, paramp);
    c1.a(paramg.Q());
    return c1;
  }
  
  @Nullable
  public g a() {
    return this.b.get();
  }
  
  public void a(long paramLong) {
    b();
    if (!((Boolean)this.a.a(b.bG)).booleanValue() && this.a.Y().isApplicationPaused())
      return; 
    this.d = p.a(paramLong, this.a, new Runnable(this) {
          public void run() {
            this.a.c();
            c.a(this.a).V().a(this.a);
          }
        });
  }
  
  public void b() {
    p p1 = this.d;
    if (p1 != null) {
      p1.d();
      this.d = null;
    } 
  }
  
  public void c() {
    b();
    g g = a();
    if (g == null)
      return; 
    g.S();
    d.a a = this.c.get();
    if (a == null)
      return; 
    a.onAdExpired(g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */