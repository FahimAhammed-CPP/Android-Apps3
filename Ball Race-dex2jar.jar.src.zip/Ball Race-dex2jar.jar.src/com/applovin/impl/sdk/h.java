package com.applovin.impl.sdk;

import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.sdk.AppLovinSdkUtils;
import com.safedk.android.internal.partials.AppLovinNetworkBridge;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public class h {
  private static final int a = (int)TimeUnit.SECONDS.toMillis(30L);
  
  private static final h m = new h();
  
  private final AtomicLong b = new AtomicLong(0L);
  
  private Handler c;
  
  private final HandlerThread d = new HandlerThread("applovin-anr-detector");
  
  private Handler e;
  
  private final AtomicBoolean f = new AtomicBoolean();
  
  private final AtomicBoolean g = new AtomicBoolean();
  
  private p h;
  
  private Thread i;
  
  private long j = TimeUnit.SECONDS.toMillis(4L);
  
  private long k = TimeUnit.SECONDS.toMillis(3L);
  
  private long l = TimeUnit.SECONDS.toMillis(3L);
  
  private static String a(String paramString) {
    try {
      return URLEncoder.encode(paramString, "UTF-8");
    } catch (Throwable throwable) {
      return "";
    } 
  }
  
  private void a() {
    if (this.g.get())
      this.f.set(true); 
  }
  
  public static void a(p paramp) {
    if (paramp != null) {
      if (((Boolean)paramp.a(b.fB)).booleanValue() && !Utils.isPubInDebugMode(p.y(), paramp)) {
        m.b(paramp);
        return;
      } 
      m.a();
    } 
  }
  
  private void b() {
    try {
      HttpURLConnection httpURLConnection = (HttpURLConnection)c().openConnection();
      httpURLConnection.setConnectTimeout(a);
      httpURLConnection.setReadTimeout(a);
      httpURLConnection.setDefaultUseCaches(false);
      httpURLConnection.setAllowUserInteraction(false);
      httpURLConnection.setUseCaches(false);
      httpURLConnection.setInstanceFollowRedirects(true);
      httpURLConnection.setDoOutput(false);
      int i = AppLovinNetworkBridge.httpUrlConnectionGetResponseCode(httpURLConnection);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ANR reported with code ");
      stringBuilder.append(i);
      Log.d("applovin-anr-detector", stringBuilder.toString());
      return;
    } catch (Throwable throwable) {
      Log.w("applovin-anr-detector", "Failed to report ANR", throwable);
      return;
    } 
  }
  
  private void b(p paramp) {
    if (this.g.compareAndSet(false, true)) {
      this.h = paramp;
      AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
            public void run() {
              h.a(this.a, Thread.currentThread());
            }
          });
      this.j = ((Long)paramp.a(b.fC)).longValue();
      this.k = ((Long)paramp.a(b.fD)).longValue();
      this.l = ((Long)paramp.a(b.fE)).longValue();
      this.c = new Handler(p.y().getMainLooper());
      this.d.start();
      this.c.post(new b());
      this.e = new Handler(this.d.getLooper());
      this.e.postDelayed(new a(), this.l / 2L);
    } 
  }
  
  private URL c() {
    // Byte code:
    //   0: ldc ''
    //   2: astore #8
    //   4: aload_0
    //   5: getfield h : Lcom/applovin/impl/sdk/p;
    //   8: astore_3
    //   9: invokestatic y : ()Landroid/content/Context;
    //   12: astore_3
    //   13: iconst_0
    //   14: istore_1
    //   15: aload_3
    //   16: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   19: astore #4
    //   21: aload_3
    //   22: invokevirtual getPackageName : ()Ljava/lang/String;
    //   25: astore_3
    //   26: aload #4
    //   28: aload_3
    //   29: iconst_0
    //   30: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   33: astore #5
    //   35: aload_3
    //   36: astore #6
    //   38: goto -> 50
    //   41: ldc ''
    //   43: astore_3
    //   44: aconst_null
    //   45: astore #5
    //   47: aload_3
    //   48: astore #6
    //   50: aload_0
    //   51: getfield h : Lcom/applovin/impl/sdk/p;
    //   54: invokevirtual Z : ()Lcom/applovin/impl/sdk/w;
    //   57: invokevirtual c : ()Ljava/lang/Object;
    //   60: astore_3
    //   61: aload_3
    //   62: instanceof com/applovin/impl/sdk/ad/e
    //   65: istore_2
    //   66: ldc_w 'None'
    //   69: astore #9
    //   71: iload_2
    //   72: ifeq -> 96
    //   75: aload_3
    //   76: checkcast com/applovin/impl/sdk/ad/e
    //   79: astore_3
    //   80: ldc_w 'AppLovin'
    //   83: astore #4
    //   85: aload_3
    //   86: invokevirtual getAdIdNumber : ()J
    //   89: invokestatic toString : (J)Ljava/lang/String;
    //   92: astore_3
    //   93: goto -> 122
    //   96: aload_3
    //   97: instanceof com/applovin/impl/mediation/a/a
    //   100: ifeq -> 668
    //   103: aload_3
    //   104: checkcast com/applovin/impl/mediation/a/a
    //   107: astore_3
    //   108: aload_3
    //   109: invokevirtual getNetworkName : ()Ljava/lang/String;
    //   112: astore #4
    //   114: aload_3
    //   115: invokevirtual getCreativeId : ()Ljava/lang/String;
    //   118: astore_3
    //   119: goto -> 122
    //   122: aload #9
    //   124: astore #7
    //   126: aload_0
    //   127: getfield i : Ljava/lang/Thread;
    //   130: ifnull -> 206
    //   133: aload #9
    //   135: astore #7
    //   137: aload_0
    //   138: getfield i : Ljava/lang/Thread;
    //   141: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   144: arraylength
    //   145: ifle -> 206
    //   148: aload_0
    //   149: getfield i : Ljava/lang/Thread;
    //   152: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   155: iconst_0
    //   156: aaload
    //   157: astore #7
    //   159: new java/lang/StringBuilder
    //   162: dup
    //   163: invokespecial <init> : ()V
    //   166: astore #9
    //   168: aload #9
    //   170: aload #7
    //   172: invokevirtual getClassName : ()Ljava/lang/String;
    //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   178: pop
    //   179: aload #9
    //   181: ldc_w '.'
    //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: pop
    //   188: aload #9
    //   190: aload #7
    //   192: invokevirtual getMethodName : ()Ljava/lang/String;
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: pop
    //   199: aload #9
    //   201: invokevirtual toString : ()Ljava/lang/String;
    //   204: astore #7
    //   206: new java/lang/StringBuilder
    //   209: dup
    //   210: invokespecial <init> : ()V
    //   213: astore #9
    //   215: aload #9
    //   217: aload_0
    //   218: getfield h : Lcom/applovin/impl/sdk/p;
    //   221: getstatic com/applovin/impl/sdk/c/b.bn : Lcom/applovin/impl/sdk/c/b;
    //   224: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   227: checkcast java/lang/String
    //   230: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   233: pop
    //   234: aload #9
    //   236: ldc_w '?type=anr&platform=android&package_name='
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: aload #9
    //   245: aload #6
    //   247: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: pop
    //   254: aload #9
    //   256: ldc_w '&applovin_random_token='
    //   259: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   262: pop
    //   263: aload #9
    //   265: aload_0
    //   266: getfield h : Lcom/applovin/impl/sdk/p;
    //   269: invokevirtual q : ()Ljava/lang/String;
    //   272: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: pop
    //   279: aload #9
    //   281: ldc_w '&compass_random_token='
    //   284: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   287: pop
    //   288: aload #9
    //   290: aload_0
    //   291: getfield h : Lcom/applovin/impl/sdk/p;
    //   294: invokevirtual p : ()Ljava/lang/String;
    //   297: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   300: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: pop
    //   304: aload #9
    //   306: ldc_w '&model='
    //   309: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   312: pop
    //   313: aload #9
    //   315: getstatic android/os/Build.MODEL : Ljava/lang/String;
    //   318: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   321: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   324: pop
    //   325: aload #9
    //   327: ldc_w '&brand='
    //   330: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   333: pop
    //   334: aload #9
    //   336: getstatic android/os/Build.MANUFACTURER : Ljava/lang/String;
    //   339: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   342: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   345: pop
    //   346: aload #9
    //   348: ldc_w '&brand_name='
    //   351: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: pop
    //   355: aload #9
    //   357: getstatic android/os/Build.BRAND : Ljava/lang/String;
    //   360: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   363: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   366: pop
    //   367: aload #9
    //   369: ldc_w '&hardware='
    //   372: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   375: pop
    //   376: aload #9
    //   378: getstatic android/os/Build.HARDWARE : Ljava/lang/String;
    //   381: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   384: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   387: pop
    //   388: aload #9
    //   390: ldc_w '&revision='
    //   393: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   396: pop
    //   397: aload #9
    //   399: getstatic android/os/Build.DEVICE : Ljava/lang/String;
    //   402: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   405: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   408: pop
    //   409: aload #9
    //   411: ldc_w '&app_version='
    //   414: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   417: pop
    //   418: aload #8
    //   420: astore #6
    //   422: aload #5
    //   424: ifnull -> 434
    //   427: aload #5
    //   429: getfield versionName : Ljava/lang/String;
    //   432: astore #6
    //   434: aload #9
    //   436: aload #6
    //   438: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   441: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: pop
    //   445: aload #9
    //   447: ldc_w '&app_version_code='
    //   450: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   453: pop
    //   454: aload #5
    //   456: ifnull -> 465
    //   459: aload #5
    //   461: getfield versionCode : I
    //   464: istore_1
    //   465: aload #9
    //   467: iload_1
    //   468: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   471: pop
    //   472: aload #9
    //   474: ldc_w '&os='
    //   477: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   480: pop
    //   481: aload #9
    //   483: getstatic android/os/Build$VERSION.RELEASE : Ljava/lang/String;
    //   486: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   489: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   492: pop
    //   493: aload #9
    //   495: ldc_w '&api_level='
    //   498: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   501: pop
    //   502: aload #9
    //   504: getstatic android/os/Build$VERSION.SDK_INT : I
    //   507: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   510: pop
    //   511: aload #9
    //   513: ldc_w '&sdk_version='
    //   516: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   519: pop
    //   520: aload #9
    //   522: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   525: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   528: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   531: pop
    //   532: aload #9
    //   534: ldc_w '&fs_ad_network='
    //   537: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   540: pop
    //   541: aload #9
    //   543: aload #4
    //   545: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   548: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   551: pop
    //   552: aload #9
    //   554: ldc_w '&fs_ad_creative_id='
    //   557: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   560: pop
    //   561: aload #9
    //   563: aload_3
    //   564: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   567: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   570: pop
    //   571: aload #9
    //   573: ldc_w '&top_main_method='
    //   576: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   579: pop
    //   580: aload #9
    //   582: aload #7
    //   584: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   587: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   590: pop
    //   591: aload #9
    //   593: ldc_w '&aei='
    //   596: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   599: pop
    //   600: aload #9
    //   602: aload_0
    //   603: getfield h : Lcom/applovin/impl/sdk/p;
    //   606: getstatic com/applovin/impl/sdk/c/b.ax : Lcom/applovin/impl/sdk/c/b;
    //   609: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   612: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   615: pop
    //   616: aload #9
    //   618: ldc_w '&mei='
    //   621: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   624: pop
    //   625: aload #9
    //   627: aload_0
    //   628: getfield h : Lcom/applovin/impl/sdk/p;
    //   631: getstatic com/applovin/impl/sdk/c/b.ay : Lcom/applovin/impl/sdk/c/b;
    //   634: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   637: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   640: pop
    //   641: new java/net/URL
    //   644: dup
    //   645: aload #9
    //   647: invokevirtual toString : ()Ljava/lang/String;
    //   650: invokespecial <init> : (Ljava/lang/String;)V
    //   653: astore_3
    //   654: aload_3
    //   655: areturn
    //   656: astore_3
    //   657: goto -> 41
    //   660: astore_3
    //   661: aconst_null
    //   662: areturn
    //   663: astore #4
    //   665: goto -> 44
    //   668: ldc_w 'None'
    //   671: astore_3
    //   672: aload_3
    //   673: astore #4
    //   675: goto -> 122
    // Exception table:
    //   from	to	target	type
    //   15	26	656	java/lang/Throwable
    //   15	26	660	java/net/MalformedURLException
    //   26	35	663	java/lang/Throwable
    //   26	35	660	java/net/MalformedURLException
    //   50	66	660	java/net/MalformedURLException
    //   75	80	660	java/net/MalformedURLException
    //   85	93	660	java/net/MalformedURLException
    //   96	119	660	java/net/MalformedURLException
    //   126	133	660	java/net/MalformedURLException
    //   137	206	660	java/net/MalformedURLException
    //   206	418	660	java/net/MalformedURLException
    //   427	434	660	java/net/MalformedURLException
    //   434	454	660	java/net/MalformedURLException
    //   459	465	660	java/net/MalformedURLException
    //   465	654	660	java/net/MalformedURLException
  }
  
  private class a implements Runnable {
    private a(h this$0) {}
    
    public void run() {
      if (!h.a(this.a).get()) {
        long l = System.currentTimeMillis() - h.b(this.a).get();
        if (l < 0L || l > h.e(this.a)) {
          h.f(this.a);
          h.g(this.a);
        } 
        h.i(this.a).postDelayed(this, h.h(this.a));
      } 
    }
  }
  
  private class b implements Runnable {
    private b(h this$0) {}
    
    public void run() {
      if (!h.a(this.a).get()) {
        h.b(this.a).set(System.currentTimeMillis());
        h.d(this.a).postDelayed(this, h.c(this.a));
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */