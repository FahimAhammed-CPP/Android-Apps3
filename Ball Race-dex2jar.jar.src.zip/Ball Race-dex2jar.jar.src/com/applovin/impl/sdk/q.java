package com.applovin.impl.sdk;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.hardware.SensorManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.LocaleList;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.c.d;
import com.applovin.impl.sdk.c.e;
import com.applovin.impl.sdk.d.f;
import com.applovin.impl.sdk.d.g;
import com.applovin.impl.sdk.e.a;
import com.applovin.impl.sdk.e.f;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.e.z;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.d;
import com.applovin.impl.sdk.utils.h;
import com.applovin.impl.sdk.utils.n;
import com.applovin.impl.sdk.utils.q;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.google.android.gms.appset.AppSet;
import com.google.android.gms.appset.AppSetIdInfo;
import com.google.android.gms.tasks.OnSuccessListener;
import java.io.File;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONObject;

public class q {
  private static final AtomicReference<d.a> h = new AtomicReference<d.a>();
  
  private static final AtomicReference<a> j = new AtomicReference<a>();
  
  private final p a;
  
  private final y b;
  
  private final Context c;
  
  private final Map<String, Object> d;
  
  private final Object e = new Object();
  
  private final Map<String, Object> f;
  
  private boolean g;
  
  private final AtomicReference<Integer> i = new AtomicReference<Integer>();
  
  protected q(p paramp) {
    if (paramp != null) {
      this.a = paramp;
      this.b = paramp.L();
      this.c = p.y();
      this.d = q();
      this.f = s();
      return;
    } 
    throw new IllegalArgumentException("No sdk specified");
  }
  
  @Nullable
  private Integer A() {
    AudioManager audioManager = (AudioManager)this.c.getSystemService("audio");
    if (audioManager == null)
      return null; 
    Float float_ = (Float)this.a.a(b.eh);
    try {
      int i = (int)(audioManager.getStreamVolume(3) * float_.floatValue());
      return Integer.valueOf(i);
    } catch (Throwable throwable) {
      this.a.L();
      if (y.a())
        this.a.L().b("DataCollector", "Unable to collect device volume", throwable); 
      return null;
    } 
  }
  
  private double B() {
    return Math.round(TimeZone.getDefault().getOffset((new Date()).getTime()) * 10.0D / 3600000.0D) / 10.0D;
  }
  
  private boolean C() {
    SensorManager sensorManager = (SensorManager)this.c.getSystemService("sensor");
    return (sensorManager != null && sensorManager.getDefaultSensor(4) != null);
  }
  
  private String D() {
    TelephonyManager telephonyManager = (TelephonyManager)this.c.getSystemService("phone");
    return (telephonyManager != null) ? telephonyManager.getSimCountryIso().toUpperCase(Locale.ENGLISH) : "";
  }
  
  private String E() {
    TelephonyManager telephonyManager = (TelephonyManager)this.c.getSystemService("phone");
    if (telephonyManager != null)
      try {
        null = telephonyManager.getNetworkOperator();
        return null.substring(0, Math.min(3, null.length()));
      } catch (Throwable throwable) {
        y y1 = this.b;
        if (y.a())
          this.b.b("DataCollector", "Unable to collect mobile country code", throwable); 
      }  
    return "";
  }
  
  private String F() {
    TelephonyManager telephonyManager = (TelephonyManager)this.c.getSystemService("phone");
    if (telephonyManager != null)
      try {
        null = telephonyManager.getNetworkOperator();
        return null.substring(Math.min(3, null.length()));
      } catch (Throwable throwable) {
        y y1 = this.b;
        if (y.a())
          this.b.b("DataCollector", "Unable to collect mobile network code", throwable); 
      }  
    return "";
  }
  
  private String G() {
    TelephonyManager telephonyManager = (TelephonyManager)this.c.getSystemService("phone");
    if (telephonyManager != null)
      try {
        return telephonyManager.getNetworkOperatorName();
      } catch (Throwable throwable) {
        y y1 = this.b;
        if (y.a())
          this.b.b("DataCollector", "Unable to collect carrier", throwable); 
      }  
    return "";
  }
  
  private boolean H() {
    boolean bool = false;
    try {
      if (!I()) {
        boolean bool1 = J();
        return bool1 ? true : bool;
      } 
      return true;
    } catch (Throwable throwable) {
      return false;
    } 
  }
  
  private boolean I() {
    String str = Build.TAGS;
    return (str != null && str.contains(b("lz}$blpz")));
  }
  
  private boolean J() {
    String[] arrayOfString = new String[9];
    arrayOfString[0] = "&zpz}ld&hyy&Z|yl{|zl{'hyb";
    arrayOfString[1] = "&zk`g&z|";
    arrayOfString[2] = "&zpz}ld&k`g&z|";
    arrayOfString[3] = "&zpz}ld&qk`g&z|";
    arrayOfString[4] = "&mh}h&efjhe&qk`g&z|";
    arrayOfString[5] = "&mh}h&efjhe&k`g&z|";
    arrayOfString[6] = "&zpz}ld&zm&qk`g&z|";
    arrayOfString[7] = "&zpz}ld&k`g&oh`ezhol&z|";
    arrayOfString[8] = "&mh}h&efjhe&z|";
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      if ((new File(b(arrayOfString[i]))).exists())
        return true; 
    } 
    return false;
  }
  
  private Map<String, Object> a(Map<String, Object> paramMap, boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public static void a(Context paramContext) {
    (new Thread(new Runnable(paramContext) {
          public void run() {
            q.n().set(d.a(this.a));
          }
        })).start();
  }
  
  private void a(Map<String, Object> paramMap) {
    if (((Boolean)this.a.a(b.eb)).booleanValue() && !paramMap.containsKey("af"))
      paramMap.put("af", Long.valueOf(w())); 
    if (((Boolean)this.a.a(b.ec)).booleanValue() && !paramMap.containsKey("font"))
      paramMap.put("font", Float.valueOf(x())); 
    if (((Boolean)this.a.a(b.ej)).booleanValue() && Utils.isUserAgentCollectionEnabled(this.a))
      af.b(this.a); 
    if (((Boolean)this.a.a(b.ei)).booleanValue() && !paramMap.containsKey("sua"))
      paramMap.put("sua", System.getProperty("http.agent")); 
    if (((Boolean)this.a.a(b.ee)).booleanValue() && !paramMap.containsKey("network_restricted"))
      paramMap.put("network_restricted", Boolean.valueOf(u())); 
  }
  
  private boolean a(String paramString) {
    boolean bool = false;
    try {
      int i = Settings.Secure.getInt(this.c.getContentResolver(), paramString);
      if (i == 1)
        bool = true; 
      return bool;
    } catch (Throwable throwable) {
      return false;
    } 
  }
  
  private String b(String paramString) {
    int j = paramString.length();
    int[] arrayOfInt = new int[10];
    arrayOfInt[0] = 11;
    arrayOfInt[1] = 12;
    arrayOfInt[2] = 10;
    arrayOfInt[3] = 3;
    arrayOfInt[4] = 2;
    arrayOfInt[5] = 1;
    arrayOfInt[6] = 15;
    arrayOfInt[7] = 10;
    arrayOfInt[8] = 15;
    arrayOfInt[9] = 14;
    int k = arrayOfInt.length;
    char[] arrayOfChar = new char[j];
    for (int i = 0; i < j; i++) {
      arrayOfChar[i] = paramString.charAt(i);
      for (int m = k - 1; m >= 0; m--)
        arrayOfChar[i] = (char)(arrayOfChar[i] ^ arrayOfInt[m]); 
    } 
    return new String(arrayOfChar);
  }
  
  public static void b(Context paramContext) {
    if (!Utils.checkClassExistence("com.google.android.gms.appset.AppSet"))
      return; 
    (new Thread(new Runnable(paramContext) {
          public void run() {
            try {
              AppSet.getClient(this.a).getAppSetIdInfo().addOnSuccessListener(new OnSuccessListener<AppSetIdInfo>(this) {
                    public void a(AppSetIdInfo param2AppSetIdInfo) {
                      q.a a = new q.a(param2AppSetIdInfo.getId(), param2AppSetIdInfo.getScope());
                      q.o().set(a);
                    }
                  });
              return;
            } catch (Throwable throwable) {
              y.f("DataCollector", "Could not collect AppSet ID.");
              return;
            } 
          }
        })).start();
  }
  
  private Map<String, String> p() {
    return Utils.stringifyObjectMap(a(null, true, false));
  }
  
  private Map<String, Object> q() {
    Map<String, Integer> map = CollectionUtils.map(32);
    map.put("api_level", Integer.valueOf(Build.VERSION.SDK_INT));
    map.put("brand", Build.MANUFACTURER);
    map.put("brand_name", Build.BRAND);
    map.put("hardware", Build.HARDWARE);
    map.put("sim", Boolean.valueOf(AppLovinSdkUtils.isEmulator()));
    map.put("aida", Boolean.valueOf(d.a()));
    map.put("locale", Locale.getDefault().toString());
    map.put("model", Build.MODEL);
    map.put("os", Build.VERSION.RELEASE);
    map.put("platform", f());
    map.put("revision", Build.DEVICE);
    map.put("tz_offset", Double.valueOf(B()));
    map.put("gy", Boolean.valueOf(C()));
    map.put("country_code", D());
    map.put("mcc", E());
    map.put("mnc", F());
    map.put("carrier", G());
    map.put("is_tablet", Boolean.valueOf(AppLovinSdkUtils.isTablet(this.c)));
    map.put("tv", Boolean.valueOf(AppLovinSdkUtils.isTv(this.c)));
    DisplayMetrics displayMetrics = this.c.getResources().getDisplayMetrics();
    if (displayMetrics != null) {
      map.put("adns", Float.valueOf(displayMetrics.density));
      map.put("adnsd", Integer.valueOf(displayMetrics.densityDpi));
      map.put("xdpi", Float.valueOf(displayMetrics.xdpi));
      map.put("ydpi", Float.valueOf(displayMetrics.ydpi));
      Point point = h.a(this.c);
      map.put("screen_size_in", Double.valueOf(Math.sqrt(Math.pow(point.x, 2.0D) + Math.pow(point.y, 2.0D)) / displayMetrics.xdpi));
      h.a a = h.a(this.c, this.a);
      if (a != null) {
        map.put("tl_cr", Integer.valueOf(a.a()));
        map.put("tr_cr", Integer.valueOf(a.b()));
        map.put("bl_cr", Integer.valueOf(a.c()));
        map.put("br_cr", Integer.valueOf(a.d()));
      } 
    } 
    map.put("bt_ms", Long.valueOf(System.currentTimeMillis() - SystemClock.elapsedRealtime()));
    a((Map)map);
    return (Map)map;
  }
  
  private String r() {
    int i = AppLovinSdkUtils.getOrientation(this.c);
    return (i == 1) ? "portrait" : ((i == 2) ? "landscape" : "none");
  }
  
  private Map<String, Object> s() {
    byte b;
    Long long_1;
    String str3;
    Map<String, CharSequence> map = CollectionUtils.map();
    PackageManager packageManager = this.c.getPackageManager();
    ApplicationInfo applicationInfo = this.c.getApplicationInfo();
    long l = (new File(applicationInfo.sourceDir)).lastModified();
    String str2 = null;
    try {
      PackageInfo packageInfo = packageManager.getPackageInfo(this.c.getPackageName(), 0);
      try {
        str3 = packageManager.getInstallerPackageName(applicationInfo.packageName);
        str2 = str3;
      } catch (Throwable throwable1) {}
    } catch (Throwable throwable) {
      throwable = null;
    } 
    map.put("app_name", packageManager.getApplicationLabel(applicationInfo));
    String str4 = "";
    if (throwable != null) {
      str3 = ((PackageInfo)throwable).versionName;
    } else {
      str3 = "";
    } 
    map.put("app_version", str3);
    if (throwable != null) {
      b = ((PackageInfo)throwable).versionCode;
    } else {
      b = -1;
    } 
    map.put("app_version_code", Integer.valueOf(b));
    map.put("package_name", applicationInfo.packageName);
    map.put("vz", StringUtils.toShortSHA1Hash(applicationInfo.packageName));
    if (str2 == null)
      str2 = ""; 
    map.put("installer_name", str2);
    map.put("tg", q.a(this.a));
    p p1 = this.a;
    map.put("debug", Boolean.valueOf(Utils.isPubInDebugMode(p.y(), this.a)));
    map.put("ia", Long.valueOf(l));
    map.put("alts_ms", Long.valueOf(p.z()));
    map.put("j8", Boolean.valueOf(p.A()));
    Long long_2 = (Long)this.a.a(d.g);
    if (long_2 != null) {
      map.put("ia_v2", long_2);
    } else {
      this.a.a(d.g, Long.valueOf(l));
    } 
    map.put("sdk_version", AppLovinSdk.VERSION);
    map.put("omid_sdk_version", this.a.ag().c());
    map.put("api_did", this.a.a(b.ad));
    String str1 = str4;
    if (throwable != null)
      long_1 = Long.valueOf(((PackageInfo)throwable).firstInstallTime); 
    map.put("first_install_v3_ms", long_1);
    map.put("target_sdk", Integer.valueOf(applicationInfo.targetSdkVersion));
    map.put("epv", Integer.valueOf(Utils.getExoPlayerVersionCode()));
    return (Map)map;
  }
  
  private Map<String, Object> t() {
    Map<String, String> map = CollectionUtils.map();
    SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.c);
    String str1 = (String)this.a.b(d.q, null, sharedPreferences);
    if (StringUtils.isValidString(str1))
      map.put("IABTCF_TCString", str1); 
    String str2 = d.r.a();
    if (sharedPreferences.contains(str2)) {
      str1 = (String)e.a(str2, "", String.class, sharedPreferences);
      Integer integer = (Integer)e.a(str2, Integer.valueOf(2147483647), Integer.class, sharedPreferences);
      Long long_ = (Long)e.a(str2, Long.valueOf(Long.MAX_VALUE), Long.class, sharedPreferences);
      Boolean bool = (Boolean)e.a(str2, Boolean.valueOf(false), Boolean.class, sharedPreferences);
      if (StringUtils.isValidString(str1)) {
        map.put("IABTCF_gdprApplies", str1);
        return (Map)map;
      } 
      if (integer != null && integer.intValue() != Integer.MAX_VALUE) {
        map.put("IABTCF_gdprApplies", integer);
        return (Map)map;
      } 
      if (long_ != null && long_.longValue() != Long.MAX_VALUE) {
        map.put("IABTCF_gdprApplies", long_);
        return (Map)map;
      } 
      map.put("IABTCF_gdprApplies", bool);
    } 
    return (Map)map;
  }
  
  private boolean u() {
    boolean bool1 = h.f();
    boolean bool = false;
    if (!bool1)
      return false; 
    ConnectivityManager connectivityManager = (ConnectivityManager)this.c.getSystemService("connectivity");
    if (connectivityManager != null)
      try {
        int i = connectivityManager.getRestrictBackgroundStatus();
        if (i == 3)
          bool = true; 
        return bool;
      } catch (Throwable throwable) {
        this.a.L();
        if (y.a())
          this.a.L().b("DataCollector", "Unable to collect constrained network info.", throwable); 
      }  
    return false;
  }
  
  private b v() {
    byte b1;
    b b = new b();
    IntentFilter intentFilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
    Intent intent = this.c.registerReceiver(null, intentFilter);
    byte b2 = -1;
    if (intent != null) {
      i = intent.getIntExtra("level", -1);
    } else {
      i = -1;
    } 
    if (intent != null) {
      b1 = intent.getIntExtra("scale", -1);
    } else {
      b1 = -1;
    } 
    if (i > 0 && b1 > 0) {
      b.b = (int)(i / b1 * 100.0F);
    } else {
      b.b = -1;
    } 
    int i = b2;
    if (intent != null)
      i = intent.getIntExtra("status", -1); 
    b.a = i;
    return b;
  }
  
  private long w() {
    List<String> list = Arrays.asList(StringUtils.emptyIfNull(Settings.Secure.getString(this.c.getContentResolver(), "enabled_accessibility_services")).split(":"));
    if (list.contains("AccessibilityMenuService")) {
      l2 = 256L;
    } else {
      l2 = 0L;
    } 
    long l1 = l2;
    if (list.contains("SelectToSpeakService"))
      l1 = l2 | 0x200L; 
    long l2 = l1;
    if (list.contains("SoundAmplifierService"))
      l2 = l1 | 0x2L; 
    l1 = l2;
    if (list.contains("SpeechToTextAccessibilityService"))
      l1 = l2 | 0x80L; 
    l2 = l1;
    if (list.contains("SwitchAccessService"))
      l2 = l1 | 0x4L; 
    l1 = l2;
    if (((this.c.getResources().getConfiguration()).uiMode & 0x30) == 32)
      l1 = l2 | 0x400L; 
    l2 = l1;
    if (a("accessibility_enabled"))
      l2 = l1 | 0x8L; 
    l1 = l2;
    if (a("touch_exploration_enabled"))
      l1 = l2 | 0x10L; 
    l2 = l1;
    if (h.d()) {
      long l = l1;
      if (a("accessibility_display_inversion_enabled"))
        l = l1 | 0x20L; 
      l2 = l;
      if (a("skip_first_use_hints"))
        l2 = l | 0x40L; 
    } 
    l1 = l2;
    if (a("lock_screen_allow_remote_input"))
      l1 = l2 | 0x800L; 
    l2 = l1;
    if (a("enabled_accessibility_audio_description_by_default"))
      l2 = l1 | 0x1000L; 
    l1 = l2;
    if (a("accessibility_shortcut_on_lock_screen"))
      l1 = l2 | 0x2000L; 
    l2 = l1;
    if (a("wear_talkback_enabled"))
      l2 = l1 | 0x4000L; 
    l1 = l2;
    if (a("hush_gesture_used"))
      l1 = l2 | 0x8000L; 
    l2 = l1;
    if (a("high_text_contrast_enabled"))
      l2 = l1 | 0x10000L; 
    l1 = l2;
    if (a("accessibility_display_magnification_enabled"))
      l1 = l2 | 0x20000L; 
    l2 = l1;
    if (a("accessibility_display_magnification_navbar_enabled"))
      l2 = l1 | 0x40000L; 
    l1 = l2;
    if (a("accessibility_captioning_enabled"))
      l1 = l2 | 0x80000L; 
    l2 = l1;
    if (a("accessibility_display_daltonizer_enabled"))
      l2 = l1 | 0x100000L; 
    l1 = l2;
    if (a("accessibility_autoclick_enabled"))
      l1 = l2 | 0x200000L; 
    l2 = l1;
    if (a("accessibility_large_pointer_icon"))
      l2 = l1 | 0x400000L; 
    l1 = l2;
    if (a("reduce_bright_colors_activated"))
      l1 = l2 | 0x800000L; 
    l2 = l1;
    if (a("reduce_bright_colors_persist_across_reboots"))
      l2 = l1 | 0x1000000L; 
    l1 = l2;
    if (a("tty_mode_enabled"))
      l1 = l2 | 0x2000000L; 
    l2 = l1;
    if (a("rtt_calling_mode"))
      l2 = l1 | 0x4000000L; 
    return l2;
  }
  
  private float x() {
    try {
      return Settings.System.getFloat(this.c.getContentResolver(), "font_scale");
    } catch (android.provider.Settings.SettingNotFoundException settingNotFoundException) {
      y y1 = this.b;
      if (y.a())
        this.b.b("DataCollector", "Error collecting font scale", (Throwable)settingNotFoundException); 
      return -1.0F;
    } 
  }
  
  private String y() {
    AudioManager audioManager = (AudioManager)this.c.getSystemService("audio");
    if (audioManager != null) {
      AudioDeviceInfo[] arrayOfAudioDeviceInfo;
      StringBuilder stringBuilder = new StringBuilder();
      if (h.e()) {
        arrayOfAudioDeviceInfo = audioManager.getDevices(2);
        int j = arrayOfAudioDeviceInfo.length;
        for (int i = 0; i < j; i++) {
          stringBuilder.append(arrayOfAudioDeviceInfo[i].getType());
          stringBuilder.append(",");
        } 
      } else {
        if (arrayOfAudioDeviceInfo.isWiredHeadsetOn()) {
          stringBuilder.append(3);
          stringBuilder.append(",");
        } 
        if (arrayOfAudioDeviceInfo.isBluetoothScoOn()) {
          stringBuilder.append(7);
          stringBuilder.append(",");
        } 
        if (arrayOfAudioDeviceInfo.isBluetoothA2dpOn())
          stringBuilder.append(8); 
      } 
      if (stringBuilder.length() > 0 && stringBuilder.charAt(stringBuilder.length() - 1) == ',')
        stringBuilder.deleteCharAt(stringBuilder.length() - 1); 
      String str = stringBuilder.toString();
      if (TextUtils.isEmpty(str)) {
        y y1 = this.b;
        if (y.a())
          this.b.b("DataCollector", "No sound outputs detected"); 
      } 
      return str;
    } 
    return null;
  }
  
  private String z() {
    if (!h.f())
      return null; 
    try {
      StringBuilder stringBuilder = new StringBuilder();
      LocaleList localeList = this.c.getResources().getConfiguration().getLocales();
      for (int i = 0; i < localeList.size(); i++) {
        stringBuilder.append(localeList.get(i));
        stringBuilder.append(",");
      } 
      if (stringBuilder.length() > 0 && stringBuilder.charAt(stringBuilder.length() - 1) == ',')
        stringBuilder.deleteCharAt(stringBuilder.length() - 1); 
      return stringBuilder.toString();
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  String a() {
    String str2 = Base64.encodeToString((new JSONObject(p())).toString().getBytes(Charset.defaultCharset()), 2);
    String str1 = str2;
    if (((Boolean)this.a.a(b.fc)).booleanValue()) {
      long l = Utils.getServerAdjustedUnixTimestampMillis(this.a);
      str1 = n.a(str2, this.a.B(), l);
    } 
    return str1;
  }
  
  public Map<String, Object> a(@Nullable Map<String, String> paramMap, boolean paramBoolean1, boolean paramBoolean2) {
    Map<String, Map<String, Object>> map = CollectionUtils.map(64);
    Map<String, Object> map1 = a(paramBoolean1);
    Map<String, Object> map2 = h();
    Map<String, Object> map3 = j();
    Map<String, Object> map4 = this.a.r().getAllData();
    if (paramBoolean2) {
      map.put("device_info", map1);
      map.put("app_info", map2);
      if (paramMap != null)
        map.put("ad_info", paramMap); 
      if (map3 != null)
        map.put("location_info", map3); 
      if (!map4.isEmpty())
        map.put("targeting_data", map4); 
    } else {
      map.putAll(map1);
      map.putAll(map2);
      if (paramMap != null)
        map.putAll(paramMap); 
      if (map3 != null)
        map.putAll(map3); 
      if (!map4.isEmpty())
        map.putAll(map4); 
    } 
    map.put("accept", "custom_size,launch_app,video");
    map.put("format", "json");
    CollectionUtils.putStringIfValid("mediation_provider", this.a.s(), map);
    CollectionUtils.putStringIfValid("plugin_version", (String)this.a.a(b.dU), map);
    if (!((Boolean)this.a.a(b.fb)).booleanValue())
      map.put("sdk_key", this.a.B()); 
    map.putAll(i());
    if (((Boolean)this.a.a(b.eB)).booleanValue()) {
      g g = this.a.P();
      map.put("li", Long.valueOf(g.b(f.b)));
      map.put("si", Long.valueOf(g.b(f.e)));
      map.put("mad", Long.valueOf(g.b(f.c)));
      map.put("msad", Long.valueOf(g.b(f.f)));
      map.put("pf", Long.valueOf(g.b(f.j)));
      map.put("mpf", Long.valueOf(g.b(f.q)));
      map.put("gpf", Long.valueOf(g.b(f.k)));
      map.put("asoac", Long.valueOf(g.b(f.o)));
    } 
    map.put("rid", UUID.randomUUID().toString());
    return (Map)map;
  }
  
  public Map<String, Object> a(boolean paramBoolean) {
    synchronized (this.e) {
      Map<String, Object> map = CollectionUtils.map(this.d);
      return a(map, paramBoolean);
    } 
  }
  
  public Map<String, Object> b() {
    return CollectionUtils.map(this.d);
  }
  
  public Map<String, Object> c() {
    return CollectionUtils.map(this.f);
  }
  
  public Map<String, Object> d() {
    return a(false);
  }
  
  public void e() {
    synchronized (this.e) {
      a(this.d);
      return;
    } 
  }
  
  public String f() {
    return AppLovinSdkUtils.isFireOS(this.c) ? "fireos" : "android";
  }
  
  public boolean g() {
    return this.g;
  }
  
  public Map<String, Object> h() {
    Map<String, Boolean> map = CollectionUtils.map(this.f);
    map.put("first_install", Boolean.valueOf(this.a.aw()));
    map.put("first_install_v2", Boolean.valueOf(this.a.u() ^ true));
    map.put("test_ads", Boolean.valueOf(this.g));
    map.put("muted", Boolean.valueOf(this.a.C().isMuted()));
    if (((Boolean)this.a.a(b.dK)).booleanValue())
      CollectionUtils.putStringIfValid("cuid", this.a.o(), map); 
    if (((Boolean)this.a.a(b.dN)).booleanValue())
      map.put("compass_random_token", this.a.p()); 
    if (((Boolean)this.a.a(b.dP)).booleanValue())
      map.put("applovin_random_token", this.a.q()); 
    String str = this.a.D().getName();
    if (StringUtils.isValidString(str))
      map.put("user_segment_name", str); 
    map.putAll(t());
    return (Map)map;
  }
  
  public Map<String, Object> i() {
    Map<String, Object> map = CollectionUtils.map();
    map.put("sc", this.a.a(b.ai));
    map.put("sc2", this.a.a(b.aj));
    map.put("sc3", this.a.a(b.ak));
    map.put("server_installed_at", this.a.a(b.al));
    CollectionUtils.putStringIfValid("persisted_data", (String)this.a.a(d.H), map);
    return map;
  }
  
  @Nullable
  public Map<String, Object> j() {
    if (!this.a.C().isLocationCollectionEnabled())
      return null; 
    if (!((Boolean)this.a.a(b.ey)).booleanValue())
      return null; 
    Map<String, Boolean> map = CollectionUtils.map();
    x x = this.a.ah();
    boolean bool = x.b();
    map.put("loc_services_enabled", Boolean.valueOf(bool));
    if (!bool)
      return (Map)map; 
    map.put("loc_auth", Boolean.valueOf(x.a()));
    if (x.c()) {
      map.put("loc_lat", Utils.formatDoubleValue(x.d(), ((Integer)this.a.a(b.eA)).intValue()));
      map.put("loc_long", Utils.formatDoubleValue(x.e(), ((Integer)this.a.a(b.eA)).intValue()));
    } 
    return (Map)map;
  }
  
  public d.a k() {
    d.a a = d.a(this.c);
    if (a == null)
      return new d.a(); 
    if (((Boolean)this.a.a(b.dI)).booleanValue()) {
      if (a.a() && !((Boolean)this.a.a(b.dH)).booleanValue())
        a.a(""); 
      h.set(a);
    } else {
      a = new d.a();
    } 
    boolean bool = StringUtils.isValidString(a.b());
    boolean bool1 = false;
    if (bool) {
      List list = this.a.C().getTestDeviceAdvertisingIds();
      bool = bool1;
      if (list != null) {
        bool = bool1;
        if (list.contains(a.b()))
          bool = true; 
      } 
      this.g = bool;
      return a;
    } 
    this.g = false;
    return a;
  }
  
  @Nullable
  public a l() {
    return j.get();
  }
  
  public void m() {
    this.a.M().a((a)new f(this.a, new f.a(this) {
            public void a(d.a param1a) {
              q.n().set(param1a);
            }
          }), o.a.d);
    this.a.M().a((a)new z(this.a, true, new Runnable(this) {
            public void run() {
              q.b(this.a).set(q.a(this.a));
            }
          }), o.a.i);
  }
  
  public static class a {
    public final String a;
    
    public final int b;
    
    public a(String param1String, int param1Int) {
      this.a = param1String;
      this.b = param1Int;
    }
  }
  
  public static class b {
    public int a = -1;
    
    public int b = -1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */