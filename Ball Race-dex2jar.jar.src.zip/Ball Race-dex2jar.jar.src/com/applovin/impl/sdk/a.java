package com.applovin.impl.sdk;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import com.applovin.impl.sdk.utils.a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class a implements Application.ActivityLifecycleCallbacks {
  private final List<a> a = Collections.synchronizedList(new ArrayList<a>());
  
  private WeakReference<Activity> b = new WeakReference<Activity>(null);
  
  private WeakReference<Activity> c = new WeakReference<Activity>(null);
  
  public a(Context paramContext) {
    y.f("AppLovinSdk", "Attaching Activity lifecycle manager...");
    if (paramContext instanceof Activity) {
      Activity activity = (Activity)paramContext;
      this.b = new WeakReference<Activity>(activity);
      if (activity.hasWindowFocus())
        this.c = this.b; 
    } 
    ((Application)paramContext.getApplicationContext()).registerActivityLifecycleCallbacks(this);
  }
  
  public Activity a() {
    return this.b.get();
  }
  
  public void a(a parama) {
    this.a.add(parama);
  }
  
  public Activity b() {
    return this.c.get();
  }
  
  public void b(a parama) {
    this.a.remove(parama);
  }
  
  public void onActivityCreated(@NonNull Activity paramActivity, Bundle paramBundle) {
    Iterator<?> iterator = (new ArrayList(this.a)).iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).onActivityCreated(paramActivity, paramBundle); 
  }
  
  public void onActivityDestroyed(@NonNull Activity paramActivity) {
    Iterator<?> iterator = (new ArrayList(this.a)).iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).onActivityDestroyed(paramActivity); 
  }
  
  public void onActivityPaused(@NonNull Activity paramActivity) {
    this.c = new WeakReference<Activity>(null);
    Iterator<?> iterator = (new ArrayList(this.a)).iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).onActivityPaused(paramActivity); 
  }
  
  public void onActivityResumed(@NonNull Activity paramActivity) {
    this.b = new WeakReference<Activity>(paramActivity);
    this.c = this.b;
    Iterator<?> iterator = (new ArrayList(this.a)).iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).onActivityResumed(paramActivity); 
  }
  
  public void onActivitySaveInstanceState(@NonNull Activity paramActivity, @NonNull Bundle paramBundle) {
    Iterator<?> iterator = (new ArrayList(this.a)).iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).onActivitySaveInstanceState(paramActivity, paramBundle); 
  }
  
  public void onActivityStarted(@NonNull Activity paramActivity) {
    Iterator<?> iterator = (new ArrayList(this.a)).iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).onActivityStarted(paramActivity); 
  }
  
  public void onActivityStopped(@NonNull Activity paramActivity) {
    Iterator<?> iterator = (new ArrayList(this.a)).iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).onActivityStopped(paramActivity); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */