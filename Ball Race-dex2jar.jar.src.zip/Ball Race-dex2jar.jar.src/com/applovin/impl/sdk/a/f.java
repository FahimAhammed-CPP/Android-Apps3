package com.applovin.impl.sdk.a;

import android.content.Context;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.iab.omid.library.applovin.Omid;
import com.iab.omid.library.applovin.ScriptInjector;
import com.iab.omid.library.applovin.adsession.Partner;

public class f {
  private final p a;
  
  private final Context b;
  
  private String c;
  
  public f(p paramp) {
    this.a = paramp;
    this.b = p.y();
  }
  
  public String a(String paramString) {
    try {
      return ScriptInjector.injectScriptContentIntoHtml(this.c, paramString);
    } catch (Throwable throwable) {
      this.a.L();
      if (y.a())
        this.a.L().b("OpenMeasurementService", "Failed to inject JavaScript SDK into HTML", throwable); 
      return paramString;
    } 
  }
  
  public void a() {
    if (((Boolean)this.a.a(b.aD)).booleanValue()) {
      this.a.L();
      if (y.a()) {
        y y = this.a.L();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Initializing Open Measurement SDK v");
        stringBuilder.append(c());
        stringBuilder.append("...");
        y.b("OpenMeasurementService", stringBuilder.toString());
      } 
      AppLovinSdkUtils.runOnUiThread(new Runnable(this) {
            public void run() {
              // Byte code:
              //   0: invokestatic currentTimeMillis : ()J
              //   3: lstore_1
              //   4: aload_0
              //   5: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   8: invokestatic a : (Lcom/applovin/impl/sdk/a/f;)Landroid/content/Context;
              //   11: invokestatic activate : (Landroid/content/Context;)V
              //   14: aload_0
              //   15: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   18: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/p;
              //   21: invokevirtual L : ()Lcom/applovin/impl/sdk/y;
              //   24: pop
              //   25: invokestatic a : ()Z
              //   28: ifeq -> 125
              //   31: aload_0
              //   32: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   35: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/p;
              //   38: invokevirtual L : ()Lcom/applovin/impl/sdk/y;
              //   41: astore #4
              //   43: new java/lang/StringBuilder
              //   46: dup
              //   47: invokespecial <init> : ()V
              //   50: astore #5
              //   52: aload #5
              //   54: ldc 'Init '
              //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   59: pop
              //   60: aload_0
              //   61: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   64: invokevirtual b : ()Z
              //   67: ifeq -> 76
              //   70: ldc 'succeeded'
              //   72: astore_3
              //   73: goto -> 79
              //   76: ldc 'failed'
              //   78: astore_3
              //   79: aload #5
              //   81: aload_3
              //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   85: pop
              //   86: aload #5
              //   88: ldc ' and took '
              //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   93: pop
              //   94: aload #5
              //   96: invokestatic currentTimeMillis : ()J
              //   99: lload_1
              //   100: lsub
              //   101: invokevirtual append : (J)Ljava/lang/StringBuilder;
              //   104: pop
              //   105: aload #5
              //   107: ldc 'ms'
              //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   112: pop
              //   113: aload #4
              //   115: ldc 'OpenMeasurementService'
              //   117: aload #5
              //   119: invokevirtual toString : ()Ljava/lang/String;
              //   122: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
              //   125: new java/io/BufferedReader
              //   128: dup
              //   129: new java/io/InputStreamReader
              //   132: dup
              //   133: aload_0
              //   134: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   137: invokestatic a : (Lcom/applovin/impl/sdk/a/f;)Landroid/content/Context;
              //   140: invokevirtual getResources : ()Landroid/content/res/Resources;
              //   143: getstatic com/applovin/sdk/R$raw.omsdk_v_1_0 : I
              //   146: invokevirtual openRawResource : (I)Ljava/io/InputStream;
              //   149: invokespecial <init> : (Ljava/io/InputStream;)V
              //   152: invokespecial <init> : (Ljava/io/Reader;)V
              //   155: astore_3
              //   156: new java/lang/StringBuilder
              //   159: dup
              //   160: invokespecial <init> : ()V
              //   163: astore #4
              //   165: aload_3
              //   166: invokevirtual readLine : ()Ljava/lang/String;
              //   169: astore #5
              //   171: aload #5
              //   173: ifnull -> 187
              //   176: aload #4
              //   178: aload #5
              //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
              //   183: pop
              //   184: goto -> 165
              //   187: aload_0
              //   188: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   191: aload #4
              //   193: invokevirtual toString : ()Ljava/lang/String;
              //   196: invokestatic a : (Lcom/applovin/impl/sdk/a/f;Ljava/lang/String;)Ljava/lang/String;
              //   199: pop
              //   200: aload_3
              //   201: invokevirtual close : ()V
              //   204: return
              //   205: astore #4
              //   207: goto -> 238
              //   210: astore #4
              //   212: ldc 'OpenMeasurementService'
              //   214: ldc 'Failed to load JavaScript Open Measurement SDK'
              //   216: aload #4
              //   218: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   221: pop
              //   222: aload_3
              //   223: invokevirtual close : ()V
              //   226: return
              //   227: astore_3
              //   228: ldc 'OpenMeasurementService'
              //   230: ldc 'Failed to close the BufferReader for reading JavaScript Open Measurement SDK'
              //   232: aload_3
              //   233: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   236: pop
              //   237: return
              //   238: aload_3
              //   239: invokevirtual close : ()V
              //   242: goto -> 255
              //   245: astore_3
              //   246: ldc 'OpenMeasurementService'
              //   248: ldc 'Failed to close the BufferReader for reading JavaScript Open Measurement SDK'
              //   250: aload_3
              //   251: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
              //   254: pop
              //   255: aload #4
              //   257: athrow
              //   258: astore_3
              //   259: aload_0
              //   260: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   263: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/p;
              //   266: invokevirtual L : ()Lcom/applovin/impl/sdk/y;
              //   269: pop
              //   270: invokestatic a : ()Z
              //   273: ifeq -> 294
              //   276: aload_0
              //   277: getfield a : Lcom/applovin/impl/sdk/a/f;
              //   280: invokestatic b : (Lcom/applovin/impl/sdk/a/f;)Lcom/applovin/impl/sdk/p;
              //   283: invokevirtual L : ()Lcom/applovin/impl/sdk/y;
              //   286: ldc 'OpenMeasurementService'
              //   288: ldc 'Failed to retrieve resource omskd_v_1_0.js'
              //   290: aload_3
              //   291: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
              //   294: return
              // Exception table:
              //   from	to	target	type
              //   125	156	258	java/lang/Throwable
              //   156	165	210	java/lang/Throwable
              //   156	165	205	finally
              //   165	171	210	java/lang/Throwable
              //   165	171	205	finally
              //   176	184	210	java/lang/Throwable
              //   176	184	205	finally
              //   187	200	210	java/lang/Throwable
              //   187	200	205	finally
              //   200	204	227	java/io/IOException
              //   212	222	205	finally
              //   222	226	227	java/io/IOException
              //   238	242	245	java/io/IOException
            }
          });
    } 
  }
  
  public boolean b() {
    return Omid.isActive();
  }
  
  public String c() {
    return Omid.getVersion();
  }
  
  public Partner d() {
    return Partner.createPartner((String)this.a.a(b.aE), AppLovinSdk.VERSION);
  }
  
  @Nullable
  public String e() {
    return this.c;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\a\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */