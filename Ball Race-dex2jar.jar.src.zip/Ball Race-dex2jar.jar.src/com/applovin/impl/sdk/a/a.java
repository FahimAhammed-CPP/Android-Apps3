package com.applovin.impl.sdk.a;

import androidx.annotation.Nullable;
import com.iab.omid.library.applovin.adsession.VerificationScriptResource;
import java.util.List;

public interface a {
  @Nullable
  String getOpenMeasurementContentUrl();
  
  String getOpenMeasurementCustomReferenceData();
  
  List<VerificationScriptResource> getOpenMeasurementVerificationScriptResources();
  
  boolean isOpenMeasurementEnabled();
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */