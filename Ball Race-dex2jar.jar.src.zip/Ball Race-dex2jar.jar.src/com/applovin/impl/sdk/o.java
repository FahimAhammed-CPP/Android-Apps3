package com.applovin.impl.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.webkit.WebView;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.a;
import com.applovin.impl.sdk.utils.i;
import com.applovin.sdk.AppLovinPrivacySettings;
import com.applovin.sdk.AppLovinSdkUtils;
import com.applovin.sdk.AppLovinUserService;
import com.applovin.sdk.AppLovinWebViewActivity;
import com.safedk.android.analytics.brandsafety.BrandSafetyUtils;
import com.safedk.android.internal.partials.AppLovinNetworkBridge;
import com.safedk.android.utils.Logger;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;

public class o implements n.a, AppLovinWebViewActivity.EventListener {
  private static final AtomicBoolean a = new AtomicBoolean();
  
  private static WeakReference<AppLovinWebViewActivity> b;
  
  private final p c;
  
  private final y d;
  
  private AppLovinUserService.OnConsentDialogDismissListener e;
  
  private n f;
  
  private WeakReference<Activity> g = new WeakReference<Activity>(null);
  
  private a h;
  
  private AtomicBoolean i = new AtomicBoolean();
  
  o(p paramp) {
    this.c = paramp;
    this.d = paramp.L();
    if (paramp.t() != null)
      this.g = new WeakReference<Activity>(paramp.t()); 
    p.a(p.y()).a(new a(this) {
          public void onActivityStarted(Activity param1Activity) {
            o.a(this.a, new WeakReference<Activity>(param1Activity));
          }
        });
    this.f = new n(this, paramp);
  }
  
  private void a(boolean paramBoolean, long paramLong) {
    g();
    if (paramBoolean)
      a(paramLong); 
  }
  
  private boolean a(p paramp) {
    y y1;
    if (d()) {
      y.i("AppLovinSdk", "Consent dialog already showing");
      return false;
    } 
    if (!i.a(p.y())) {
      y.i("AppLovinSdk", "No internet available, skip showing of consent dialog");
      return false;
    } 
    if (!((Boolean)paramp.a(b.aF)).booleanValue()) {
      y1 = this.d;
      if (y.a())
        this.d.e("ConsentDialogManager", "Blocked publisher from showing consent dialog"); 
      return false;
    } 
    if (!StringUtils.isValidString((String)y1.a(b.aG))) {
      y1 = this.d;
      if (y.a())
        this.d.e("ConsentDialogManager", "AdServer returned empty consent dialog URL"); 
      return false;
    } 
    return true;
  }
  
  private void g() {
    this.c.w().b(this.h);
    if (d()) {
      AppLovinWebViewActivity appLovinWebViewActivity = b.get();
      b = null;
      if (appLovinWebViewActivity != null) {
        appLovinWebViewActivity.finish();
        AppLovinUserService.OnConsentDialogDismissListener onConsentDialogDismissListener = this.e;
        if (onConsentDialogDismissListener != null) {
          onConsentDialogDismissListener.onDismiss();
          this.e = null;
        } 
      } 
    } 
  }
  
  public void a() {
    Activity activity = this.g.get();
    if (activity != null) {
      long l = ((Long)this.c.a(b.aI)).longValue();
      AppLovinSdkUtils.runOnUiThreadDelayed(new Runnable(this, activity) {
            public void run() {
              this.b.a(this.a, (AppLovinUserService.OnConsentDialogDismissListener)null);
            }
          }l);
    } 
  }
  
  public void a(long paramLong) {
    AppLovinSdkUtils.runOnUiThread(new Runnable(this, paramLong) {
          public void run() {
            o.c(this.b);
            if (y.a())
              o.c(this.b).b("ConsentDialogManager", "Scheduling repeating consent alert"); 
            o.d(this.b).a(this.a, o.a(this.b), this.b);
          }
        });
  }
  
  public void a(Activity paramActivity, AppLovinUserService.OnConsentDialogDismissListener paramOnConsentDialogDismissListener) {
    paramActivity.runOnUiThread(new Runnable(this, paramOnConsentDialogDismissListener, paramActivity) {
          public static void safedk_Activity_startActivity_9d898b58165fa4ba0e12c3900a2b8533(Activity param1Activity, Intent param1Intent) {
            Logger.d("SafeDK-Special|SafeDK: Call> Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V");
            if (param1Intent == null)
              return; 
            BrandSafetyUtils.detectAdClick(param1Intent, "com.applovin");
            param1Activity.startActivity(param1Intent);
          }
          
          public void run() {
            o o1 = this.c;
            if (!o.a(o1, o.a(o1)) || o.e().getAndSet(true)) {
              AppLovinUserService.OnConsentDialogDismissListener onConsentDialogDismissListener = this.a;
              if (onConsentDialogDismissListener != null)
                onConsentDialogDismissListener.onDismiss(); 
              return;
            } 
            o.a(this.c, new WeakReference<Activity>(this.b));
            o.a(this.c, this.a);
            o.a(this.c, new a(this) {
                  public void onActivityStarted(Activity param2Activity) {
                    if (param2Activity instanceof AppLovinWebViewActivity) {
                      if (!this.a.c.d() || o.f().get() != param2Activity) {
                        AppLovinWebViewActivity appLovinWebViewActivity = (AppLovinWebViewActivity)param2Activity;
                        o.a(new WeakReference<AppLovinWebViewActivity>(appLovinWebViewActivity));
                        appLovinWebViewActivity.loadUrl((String)o.a(this.a.c).a(b.aG), this.a.c);
                      } 
                      o.e().set(false);
                    } 
                  }
                });
            o.a(this.c).w().a(o.b(this.c));
            Intent intent = new Intent((Context)this.b, AppLovinWebViewActivity.class);
            intent.putExtra("sdk_key", o.a(this.c).B());
            intent.putExtra("immersive_mode_on", (Serializable)o.a(this.c).a(b.aH));
            safedk_Activity_startActivity_9d898b58165fa4ba0e12c3900a2b8533(this.b, intent);
          }
        });
  }
  
  public void b() {}
  
  public void c() {
    if (this.i.getAndSet(true))
      return; 
    AppLovinSdkUtils.runOnUiThread(new Runnable(this, (String)this.c.a(b.aG)) {
          public void run() {
            o.a(this.b);
            WebView webView = Utils.tryToCreateWebView(p.y(), "preloading consent dialog", true);
            if (webView == null)
              return; 
            AppLovinNetworkBridge.webviewLoadUrl(webView, this.a);
          }
        });
  }
  
  boolean d() {
    WeakReference<AppLovinWebViewActivity> weakReference = b;
    return (weakReference != null && weakReference.get() != null);
  }
  
  public void onReceivedEvent(String paramString) {
    p p1;
    if ("accepted".equalsIgnoreCase(paramString)) {
      p1 = this.c;
      AppLovinPrivacySettings.setHasUserConsent(true, p.y());
      g();
      return;
    } 
    if ("rejected".equalsIgnoreCase((String)p1)) {
      p1 = this.c;
      AppLovinPrivacySettings.setHasUserConsent(false, p.y());
      a(((Boolean)this.c.a(b.aJ)).booleanValue(), ((Long)this.c.a(b.aO)).longValue());
      return;
    } 
    if ("closed".equalsIgnoreCase((String)p1)) {
      a(((Boolean)this.c.a(b.aK)).booleanValue(), ((Long)this.c.a(b.aP)).longValue());
      return;
    } 
    if ("dismissed_via_back_button".equalsIgnoreCase((String)p1))
      a(((Boolean)this.c.a(b.aL)).booleanValue(), ((Long)this.c.a(b.aQ)).longValue()); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */