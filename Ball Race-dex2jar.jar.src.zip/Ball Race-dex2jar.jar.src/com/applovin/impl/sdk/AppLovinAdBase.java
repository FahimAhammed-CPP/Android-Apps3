package com.applovin.impl.sdk;

import android.graphics.Color;
import com.applovin.impl.sdk.a.a;
import com.applovin.impl.sdk.array.ArrayDirectDownloadAd;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import java.util.List;
import org.json.JSONObject;

public abstract class AppLovinAdBase implements a, ArrayDirectDownloadAd {
  protected final JSONObject adObject;
  
  protected final Object adObjectLock;
  
  private final long createdAtMillis;
  
  protected final JSONObject fullResponse;
  
  protected final Object fullResponseLock;
  
  protected final p sdk;
  
  protected AppLovinAdBase(JSONObject paramJSONObject1, JSONObject paramJSONObject2, p paramp) {
    if (paramJSONObject1 != null) {
      if (paramJSONObject2 != null) {
        if (paramp != null) {
          this.adObject = paramJSONObject1;
          this.fullResponse = paramJSONObject2;
          this.sdk = paramp;
          this.adObjectLock = new Object();
          this.fullResponseLock = new Object();
          this.createdAtMillis = System.currentTimeMillis();
          return;
        } 
        throw new IllegalArgumentException("No sdk specified");
      } 
      throw new IllegalArgumentException("No response specified");
    } 
    throw new IllegalArgumentException("No ad object specified");
  }
  
  protected boolean containsKeyForAdObject(String paramString) {
    synchronized (this.adObjectLock) {
      return this.adObject.has(paramString);
    } 
  }
  
  public abstract long getAdIdNumber();
  
  protected boolean getBooleanFromAdObject(String paramString, Boolean paramBoolean) {
    synchronized (this.adObjectLock) {
      return JsonUtils.getBoolean(this.adObject, paramString, paramBoolean).booleanValue();
    } 
  }
  
  protected boolean getBooleanFromFullResponse(String paramString, boolean paramBoolean) {
    synchronized (this.fullResponseLock) {
      paramBoolean = JsonUtils.getBoolean(this.fullResponse, paramString, Boolean.valueOf(paramBoolean)).booleanValue();
      return paramBoolean;
    } 
  }
  
  public String getClCode() {
    String str = getStringFromAdObject("clcode", "");
    return StringUtils.isValidString(str) ? str : getStringFromFullResponse("clcode", "");
  }
  
  protected int getColorFromAdObject(String paramString, int paramInt) {
    paramString = getStringFromAdObject(paramString, null);
    if (StringUtils.isValidString(paramString))
      paramInt = Color.parseColor(paramString); 
    return paramInt;
  }
  
  public long getCreatedAtMillis() {
    return this.createdAtMillis;
  }
  
  public String getDspName() {
    return getStringFromFullResponse("dsp_name", "");
  }
  
  public long getFetchLatencyMillis() {
    return getLongFromFullResponse("ad_fetch_latency_millis", -1L);
  }
  
  public long getFetchResponseSize() {
    return getLongFromFullResponse("ad_fetch_response_size", -1L);
  }
  
  protected float getFloatFromAdObject(String paramString, float paramFloat) {
    synchronized (this.adObjectLock) {
      paramFloat = JsonUtils.getFloat(this.adObject, paramString, paramFloat);
      return paramFloat;
    } 
  }
  
  protected float getFloatFromFullResponse(String paramString, float paramFloat) {
    synchronized (this.fullResponseLock) {
      paramFloat = JsonUtils.getFloat(this.fullResponse, paramString, paramFloat);
      return paramFloat;
    } 
  }
  
  protected int getIntFromAdObject(String paramString, int paramInt) {
    synchronized (this.adObjectLock) {
      paramInt = JsonUtils.getInt(this.adObject, paramString, paramInt);
      return paramInt;
    } 
  }
  
  protected int getIntFromFullResponse(String paramString, int paramInt) {
    synchronized (this.fullResponseLock) {
      paramInt = JsonUtils.getInt(this.fullResponse, paramString, paramInt);
      return paramInt;
    } 
  }
  
  protected List<Integer> getIntegerListFromAdObject(String paramString, List<Integer> paramList) {
    synchronized (this.adObjectLock) {
      return JsonUtils.getIntegerList(this.adObject, paramString, paramList);
    } 
  }
  
  protected JSONObject getJsonObjectFromAdObject(String paramString, JSONObject paramJSONObject) {
    synchronized (this.adObjectLock) {
      return JsonUtils.getJSONObject(this.adObject, paramString, paramJSONObject);
    } 
  }
  
  protected JSONObject getJsonObjectFromFullResponse(String paramString, JSONObject paramJSONObject) {
    synchronized (this.fullResponseLock) {
      return JsonUtils.getJSONObject(this.fullResponse, paramString, paramJSONObject);
    } 
  }
  
  protected long getLongFromAdObject(String paramString, long paramLong) {
    synchronized (this.adObjectLock) {
      paramLong = JsonUtils.getLong(this.adObject, paramString, paramLong);
      return paramLong;
    } 
  }
  
  protected long getLongFromFullResponse(String paramString, long paramLong) {
    synchronized (this.fullResponseLock) {
      paramLong = JsonUtils.getLong(this.fullResponse, paramString, paramLong);
      return paramLong;
    } 
  }
  
  public String getPrimaryKey() {
    return getStringFromAdObject("pk", "NA");
  }
  
  public p getSdk() {
    return this.sdk;
  }
  
  public String getSecondaryKey1() {
    return getStringFromAdObject("sk1", null);
  }
  
  public String getSecondaryKey2() {
    return getStringFromAdObject("sk2", null);
  }
  
  protected String getStringFromAdObject(String paramString1, String paramString2) {
    synchronized (this.adObjectLock) {
      paramString1 = JsonUtils.getString(this.adObject, paramString1, paramString2);
      return paramString1;
    } 
  }
  
  protected String getStringFromFullResponse(String paramString1, String paramString2) {
    synchronized (this.fullResponseLock) {
      paramString1 = JsonUtils.getString(this.fullResponse, paramString1, paramString2);
      return paramString1;
    } 
  }
  
  public boolean shouldUrlEncodeResourcePath() {
    return getBooleanFromAdObject("uerp", Boolean.valueOf(false));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\AppLovinAdBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */