package com.applovin.impl.sdk.array;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import androidx.annotation.Nullable;
import com.applovin.array.apphub.aidl.IAppHubDirectDownloadServiceCallback;
import com.applovin.array.apphub.aidl.IAppHubService;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.a;
import com.applovin.impl.sdk.y;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class ArrayService extends IAppHubDirectDownloadServiceCallback.Stub {
  private static final int MAX_RECONNECT_RETRY_COUNT = 3;
  
  private static final String SERVICE_INTENT_CLASS_NAME = "com.applovin.oem.am.android.external.AppHubService";
  
  private static final String SERVICE_INTENT_FILTER_ACTION = "com.applovin.am.intent.action.APPHUB_SERVICE";
  
  private static final String TAG = "ArrayService";
  
  @Nullable
  private IAppHubService appHubService;
  
  @Nullable
  private final Intent appHubServiceIntent;
  
  private long appHubVersionCode = -1L;
  
  @Nullable
  private DirectDownloadState currentDownloadState;
  
  private int currentRetryCount;
  
  private final ArrayDataCollector dataCollector;
  
  private boolean isDirectDownloadEnabled;
  
  private final y logger;
  
  @Nullable
  private String randomUserToken;
  
  private final p sdk;
  
  public ArrayService(p paramp) {
    this.sdk = paramp;
    this.logger = paramp.L();
    this.dataCollector = new ArrayDataCollector(paramp);
    this.appHubServiceIntent = createAppHubServiceIntent();
    if (this.appHubServiceIntent != null)
      bindAppHubService(); 
    paramp.w().a(new a() {
          public void onActivityStopped(Activity param1Activity) {
            ArrayService.DirectDownloadState directDownloadState = ArrayService.this.currentDownloadState;
            if (ArrayService.this.isAppHubInstalled()) {
              if (directDownloadState == null)
                return; 
              try {
                ArrayService.this.logger;
                if (y.a())
                  ArrayService.this.logger.b("ArrayService", "Dismissing Direct Download Activity"); 
                ArrayService.this.appHubService.dismissDirectDownloadAppDetails(directDownloadState.adToken);
                directDownloadState.listener.onAppDetailsDismissed();
                ArrayService.access$002(ArrayService.this, null);
                return;
              } catch (RemoteException remoteException) {
                ArrayService.this.logger;
                if (y.a())
                  ArrayService.this.logger.b("ArrayService", "Failed dismiss Direct Download Activity", (Throwable)remoteException); 
              } 
            } 
          }
        });
  }
  
  private void bindAppHubService() {
    if (this.currentRetryCount > 3) {
      y y2 = this.logger;
      if (y.a())
        this.logger.d("ArrayService", "Exceeded maximum retry count"); 
      return;
    } 
    y y1 = this.logger;
    if (y.a())
      this.logger.b("ArrayService", "Attempting connection to App Hub service..."); 
    this.currentRetryCount++;
    try {
      p p1 = this.sdk;
      if (!p.y().bindService(this.appHubServiceIntent, new ServiceConnection() {
            public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
              ArrayService.this.logger;
              if (y.a()) {
                y y = ArrayService.this.logger;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Connection successful: ");
                stringBuilder.append(param1ComponentName);
                y.b("ArrayService", stringBuilder.toString());
              } 
              ArrayService.access$302(ArrayService.this, IAppHubService.Stub.asInterface(param1IBinder));
            }
            
            public void onServiceDisconnected(ComponentName param1ComponentName) {
              ArrayService.this.logger;
              if (y.a()) {
                y y = ArrayService.this.logger;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Service disconnected: ");
                stringBuilder.append(param1ComponentName);
                y.e("ArrayService", stringBuilder.toString());
              } 
              ArrayService.access$302(ArrayService.this, null);
              ArrayService.this.logger;
              if (y.a())
                ArrayService.this.logger.e("ArrayService", "Retrying..."); 
              ArrayService.this.bindAppHubService();
            }
          }1)) {
        y y2 = this.logger;
        if (y.a()) {
          this.logger.e("ArrayService", "App Hub not available");
          return;
        } 
      } 
    } catch (Throwable throwable) {
      y y2 = this.logger;
      if (y.a())
        this.logger.b("ArrayService", "Failed to bind to service", throwable); 
    } 
  }
  
  @Nullable
  private Intent createAppHubServiceIntent() {
    y y1;
    Intent intent = new Intent("com.applovin.am.intent.action.APPHUB_SERVICE");
    p p1 = this.sdk;
    List list = p.y().getPackageManager().queryIntentServices(intent, 0);
    if (list == null || list.isEmpty()) {
      y1 = this.logger;
      if (y.a())
        this.logger.e("ArrayService", "App Hub not available"); 
      return null;
    } 
    y1.setClassName(((ResolveInfo)list.get(0)).serviceInfo.packageName, "com.applovin.oem.am.android.external.AppHubService");
    return (Intent)y1;
  }
  
  private boolean isOneClickDownloadEnabled() {
    DirectDownloadState directDownloadState = this.currentDownloadState;
    return (directDownloadState != null) ? ((directDownloadState.parameters == null) ? false : directDownloadState.parameters.getBoolean("array_one_click_download", false)) : false;
  }
  
  public void collectAppHubData() {
    if (!isAppHubInstalled())
      return; 
    y y1 = this.logger;
    if (y.a())
      this.logger.b("ArrayService", "Collecting data..."); 
    this.appHubVersionCode = this.dataCollector.maybeCollectAppHubVersionCode(this.appHubService);
    this.isDirectDownloadEnabled = this.dataCollector.maybeCollectDirectDownloadEnabled(this.appHubService);
    this.randomUserToken = this.dataCollector.maybeCollectRandomUserToken(this.appHubService);
  }
  
  public long getAppHubVersionCode() {
    return this.appHubVersionCode;
  }
  
  @Nullable
  public String getRandomUserToken() {
    return this.randomUserToken;
  }
  
  public boolean isAppHubInstalled() {
    return (this.appHubService != null);
  }
  
  public boolean isDirectDownloadEnabled() {
    return this.isDirectDownloadEnabled;
  }
  
  public void onAppDetailsDismissed(String paramString) {
    y y1 = this.logger;
    if (y.a())
      this.logger.b("ArrayService", "App details dismissed"); 
    DirectDownloadState directDownloadState = this.currentDownloadState;
    if (directDownloadState == null)
      return; 
    directDownloadState.listener.onAppDetailsDismissed();
    this.currentDownloadState = null;
  }
  
  public void onAppDetailsShown(String paramString) {
    y y1 = this.logger;
    if (y.a())
      this.logger.b("ArrayService", "App details shown"); 
    DirectDownloadState directDownloadState = this.currentDownloadState;
    if (directDownloadState == null)
      return; 
    directDownloadState.listener.onAppDetailsDisplayed();
  }
  
  public void onDownloadStarted(String paramString) {
    y y1 = this.logger;
    if (y.a())
      this.logger.b("ArrayService", "Download started"); 
  }
  
  public void onError(String paramString1, String paramString2) {
    y y1 = this.logger;
    if (y.a()) {
      y1 = this.logger;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Encountered error: ");
      stringBuilder.append(paramString2);
      y1.e("ArrayService", stringBuilder.toString());
    } 
    DirectDownloadState directDownloadState = this.currentDownloadState;
    if (directDownloadState == null)
      return; 
    if (directDownloadState.errorCallbackInvoked.compareAndSet(false, true)) {
      directDownloadState.listener.onFailure();
      this.currentDownloadState = null;
    } 
  }
  
  public void startDirectInstallOrDownloadProcess(ArrayDirectDownloadAd paramArrayDirectDownloadAd, boolean paramBoolean, DirectDownloadListener paramDirectDownloadListener) {
    y y1;
    if (!isAppHubInstalled()) {
      y1 = this.logger;
      if (y.a())
        this.logger.e("ArrayService", "Cannot begin Direct Install / Download process - service disconnected"); 
      paramDirectDownloadListener.onFailure();
      return;
    } 
    if (!y1.isDirectDownloadEnabled()) {
      y1 = this.logger;
      if (y.a())
        this.logger.e("ArrayService", "Cannot begin Direct Install / Download process - missing token"); 
      paramDirectDownloadListener.onFailure();
      return;
    } 
    try {
      this.currentDownloadState = new DirectDownloadState(y1.getDirectDownloadToken(), y1.getDirectDownloadParameters(), paramDirectDownloadListener);
      if (this.appHubVersionCode >= 33L && (isOneClickDownloadEnabled() || paramBoolean)) {
        y1 = this.logger;
        if (y.a())
          this.logger.b("ArrayService", "Starting Direct Install process"); 
        this.appHubService.directInstall(this.currentDownloadState.adToken, this.currentDownloadState.parameters, (IAppHubDirectDownloadServiceCallback)this);
        y1 = this.logger;
        if (y.a()) {
          this.logger.b("ArrayService", "Direct Install started");
          return;
        } 
      } else {
        y1 = this.logger;
        if (y.a())
          this.logger.b("ArrayService", "Starting Direct Download Activity"); 
        if (this.appHubVersionCode >= 21L) {
          this.appHubService.showDirectDownloadAppDetailsWithExtra(this.currentDownloadState.adToken, this.currentDownloadState.parameters, (IAppHubDirectDownloadServiceCallback)this);
        } else {
          this.appHubService.showDirectDownloadAppDetails(this.currentDownloadState.adToken, (IAppHubDirectDownloadServiceCallback)this);
        } 
        y1 = this.logger;
        if (y.a()) {
          this.logger.b("ArrayService", "Activity started");
          return;
        } 
      } 
    } catch (Throwable throwable) {
      y y2 = this.logger;
      if (y.a())
        this.logger.b("ArrayService", "Failed to execute Direct Install / Download process", throwable); 
      this.currentDownloadState = null;
      paramDirectDownloadListener.onFailure();
    } 
  }
  
  public static interface DirectDownloadListener {
    void onAppDetailsDismissed();
    
    void onAppDetailsDisplayed();
    
    void onFailure();
  }
  
  private static class DirectDownloadState {
    private final String adToken;
    
    private final AtomicBoolean errorCallbackInvoked = new AtomicBoolean();
    
    private final ArrayService.DirectDownloadListener listener;
    
    @Nullable
    private final Bundle parameters;
    
    public DirectDownloadState(String param1String, @Nullable Bundle param1Bundle, ArrayService.DirectDownloadListener param1DirectDownloadListener) {
      this.adToken = param1String;
      this.parameters = param1Bundle;
      this.listener = param1DirectDownloadListener;
    }
    
    protected boolean canEqual(Object param1Object) {
      return param1Object instanceof DirectDownloadState;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof DirectDownloadState))
        return false; 
      param1Object = param1Object;
      if (!param1Object.canEqual(this))
        return false; 
      AtomicBoolean atomicBoolean1 = getErrorCallbackInvoked();
      AtomicBoolean atomicBoolean2 = param1Object.getErrorCallbackInvoked();
      if (atomicBoolean1 == null) {
        if (atomicBoolean2 != null)
          return false; 
      } else if (!atomicBoolean1.equals(atomicBoolean2)) {
        return false;
      } 
      String str1 = getAdToken();
      String str2 = param1Object.getAdToken();
      if (str1 == null) {
        if (str2 != null)
          return false; 
      } else if (!str1.equals(str2)) {
        return false;
      } 
      Bundle bundle1 = getParameters();
      Bundle bundle2 = param1Object.getParameters();
      if (bundle1 == null) {
        if (bundle2 != null)
          return false; 
      } else if (!bundle1.equals(bundle2)) {
        return false;
      } 
      ArrayService.DirectDownloadListener directDownloadListener = getListener();
      param1Object = param1Object.getListener();
      if (directDownloadListener == null) {
        if (param1Object != null)
          return false; 
      } else if (!directDownloadListener.equals(param1Object)) {
        return false;
      } 
      return true;
    }
    
    public String getAdToken() {
      return this.adToken;
    }
    
    public AtomicBoolean getErrorCallbackInvoked() {
      return this.errorCallbackInvoked;
    }
    
    public ArrayService.DirectDownloadListener getListener() {
      return this.listener;
    }
    
    @Nullable
    public Bundle getParameters() {
      return this.parameters;
    }
    
    public int hashCode() {
      int i;
      int j;
      int k;
      AtomicBoolean atomicBoolean = getErrorCallbackInvoked();
      int m = 43;
      if (atomicBoolean == null) {
        i = 43;
      } else {
        i = atomicBoolean.hashCode();
      } 
      String str = getAdToken();
      if (str == null) {
        j = 43;
      } else {
        j = str.hashCode();
      } 
      Bundle bundle = getParameters();
      if (bundle == null) {
        k = 43;
      } else {
        k = bundle.hashCode();
      } 
      ArrayService.DirectDownloadListener directDownloadListener = getListener();
      if (directDownloadListener != null)
        m = directDownloadListener.hashCode(); 
      return (((i + 59) * 59 + j) * 59 + k) * 59 + m;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ArrayService.DirectDownloadState(errorCallbackInvoked=");
      stringBuilder.append(getErrorCallbackInvoked());
      stringBuilder.append(", adToken=");
      stringBuilder.append(getAdToken());
      stringBuilder.append(", parameters=");
      stringBuilder.append(getParameters());
      stringBuilder.append(", listener=");
      stringBuilder.append(getListener());
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\array\ArrayService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */