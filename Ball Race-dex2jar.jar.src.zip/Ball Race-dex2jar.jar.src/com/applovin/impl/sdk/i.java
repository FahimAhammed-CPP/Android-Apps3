package com.applovin.impl.sdk;

import android.app.Activity;
import com.applovin.impl.sdk.c.b;
import com.applovin.sdk.AppLovinCFError;
import com.applovin.sdk.AppLovinCFService;
import com.applovin.sdk.AppLovinSdkConfiguration;

class i implements AppLovinCFService {
  private p a;
  
  public i(p paramp) {
    this.a = paramp;
  }
  
  public AppLovinCFService.CFType getCFType() {
    String str = (String)this.a.a(b.fY);
    return "applies".equalsIgnoreCase(str) ? AppLovinCFService.CFType.DETAILED : ("does_not_apply".equalsIgnoreCase(str) ? AppLovinCFService.CFType.STANDARD : AppLovinCFService.CFType.UNKNOWN);
  }
  
  public void scf(Activity paramActivity, AppLovinCFService.OnCFCompletionCallback paramOnCFCompletionCallback) {
    if (this.a.ax().getConsentDialogState() != AppLovinSdkConfiguration.ConsentDialogState.APPLIES) {
      paramOnCFCompletionCallback.onFlowCompleted((AppLovinCFError)new AppLovinCFErrorImpl(-300, "Re-showing a consent flow is only allowed in GDPR region."));
      return;
    } 
    this.a.ae().a(true);
    this.a.ae().a(paramActivity, new AppLovinCFService.OnCFCompletionCallback(this, paramOnCFCompletionCallback) {
          public void onFlowCompleted(AppLovinCFError param1AppLovinCFError) {
            this.a.onFlowCompleted(param1AppLovinCFError);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */