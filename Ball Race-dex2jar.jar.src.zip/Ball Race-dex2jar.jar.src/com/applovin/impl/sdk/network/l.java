package com.applovin.impl.sdk.network;

import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.p;
import java.util.Map;
import org.json.JSONObject;

public class l<T> extends c {
  private String a;
  
  private boolean b;
  
  protected l(a parama) {
    super(parama);
    this.a = a.a(parama);
    this.b = a.b(parama);
  }
  
  public static a b(p paramp) {
    return new a(paramp);
  }
  
  public boolean p() {
    return (this.a != null);
  }
  
  public String q() {
    return this.a;
  }
  
  public boolean r() {
    return this.b;
  }
  
  public static class a<T> extends c.a<T> {
    private String o;
    
    private boolean p;
    
    public a(p param1p) {
      super(param1p);
      this.h = ((Integer)param1p.a(b.cX)).intValue();
      this.i = ((Integer)param1p.a(b.cW)).intValue();
      this.j = ((Integer)param1p.a(b.de)).intValue();
    }
    
    public a b(T param1T) {
      this.g = param1T;
      return this;
    }
    
    public a b(JSONObject param1JSONObject) {
      this.f = param1JSONObject;
      return this;
    }
    
    public l<T> b() {
      return new l<T>(this);
    }
    
    public a c(Map<String, String> param1Map) {
      this.d = param1Map;
      return this;
    }
    
    public a d(int param1Int) {
      this.h = param1Int;
      return this;
    }
    
    public a d(String param1String) {
      this.b = param1String;
      return this;
    }
    
    public a d(Map<String, String> param1Map) {
      this.e = param1Map;
      return this;
    }
    
    public a e(int param1Int) {
      this.i = param1Int;
      return this;
    }
    
    public a e(String param1String) {
      this.c = param1String;
      return this;
    }
    
    public a e(boolean param1Boolean) {
      this.m = param1Boolean;
      return this;
    }
    
    public a f(int param1Int) {
      this.j = param1Int;
      return this;
    }
    
    public a f(String param1String) {
      this.a = param1String;
      return this;
    }
    
    public a f(boolean param1Boolean) {
      this.n = param1Boolean;
      return this;
    }
    
    public a g(String param1String) {
      this.o = param1String;
      return this;
    }
    
    public a g(boolean param1Boolean) {
      this.p = param1Boolean;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\network\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */