package com.applovin.impl.sdk;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.SystemClock;
import androidx.annotation.Nullable;
import com.applovin.impl.mediation.a.c;
import com.applovin.impl.mediation.a.d;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.utils.p;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class b implements AppLovinBroadcastManager.Receiver {
  private final p a;
  
  private final y b;
  
  private final a c;
  
  private p d;
  
  private final Object e = new Object();
  
  private long f;
  
  public b(p paramp, a parama) {
    this.a = paramp;
    this.b = paramp.L();
    this.c = parama;
  }
  
  private void a(long paramLong) {
    synchronized (this.e) {
      a();
      this.f = System.currentTimeMillis() + paramLong;
      AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.application_paused"));
      AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.application_resumed"));
      if (!((Boolean)this.a.a(b.bG)).booleanValue() && this.a.Y().isApplicationPaused())
        return; 
      this.d = p.a(paramLong, this.a, new Runnable(this) {
            public void run() {
              this.a.a();
              b.a(this.a).onAdExpired();
            }
          });
      return;
    } 
  }
  
  private void b() {
    p p1 = this.d;
    if (p1 != null) {
      p1.d();
      this.d = null;
    } 
  }
  
  private void c() {
    synchronized (this.e) {
      b();
      return;
    } 
  }
  
  private void d() {
    synchronized (this.e) {
      boolean bool;
      long l = this.f - System.currentTimeMillis();
      if (l <= 0L) {
        a();
        bool = true;
      } else {
        a(l);
        bool = false;
      } 
      if (bool)
        this.c.onAdExpired(); 
      return;
    } 
  }
  
  public void a() {
    synchronized (this.e) {
      b();
      AppLovinBroadcastManager.unregisterReceiver(this);
      return;
    } 
  }
  
  public boolean a(com.applovin.impl.mediation.a.a parama) {
    long l;
    if (parama instanceof c) {
      l = ((c)parama).R();
    } else if (parama instanceof d) {
      l = ((d)parama).J();
    } else {
      throw new IllegalArgumentException("Ad does not support scheduling expiration");
    } 
    l -= SystemClock.elapsedRealtime() - parama.x();
    if (l > 2000L) {
      y y2 = this.b;
      if (y.a()) {
        y2 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scheduling ad expiration ");
        stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(l));
        stringBuilder.append(" seconds from now for ");
        stringBuilder.append(parama.getAdUnitId());
        stringBuilder.append("...");
        y2.b("AdExpirationManager", stringBuilder.toString());
      } 
      a(l);
      return true;
    } 
    y y1 = this.b;
    if (y.a())
      this.b.b("AdExpirationManager", "Ad is already expired"); 
    return false;
  }
  
  public void onReceive(Intent paramIntent, @Nullable Map<String, Object> paramMap) {
    String str = paramIntent.getAction();
    if ("com.applovin.application_paused".equals(str)) {
      c();
      return;
    } 
    if ("com.applovin.application_resumed".equals(str))
      d(); 
  }
  
  public static interface a {
    void onAdExpired();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */