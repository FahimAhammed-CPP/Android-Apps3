package com.applovin.impl.sdk;

import androidx.annotation.Nullable;
import com.applovin.impl.sdk.ad.AppLovinAdImpl;
import com.applovin.impl.sdk.ad.d;
import com.applovin.impl.sdk.ad.f;
import com.applovin.impl.sdk.utils.CollectionUtils;
import java.util.Map;

public class e {
  private final p a;
  
  private final y b;
  
  private final Object c;
  
  private final Map<d, aa> d;
  
  private final Map<d, aa> e;
  
  e(p paramp) {
    this.a = paramp;
    this.b = paramp.L();
    this.d = CollectionUtils.map();
    this.e = CollectionUtils.map();
    this.c = new Object();
    for (d d : d.f()) {
      this.d.put(d, new aa());
      this.e.put(d, new aa());
    } 
  }
  
  private aa d(d paramd) {
    synchronized (this.c) {
      aa aa2 = this.d.get(paramd);
      aa aa1 = aa2;
      if (aa2 == null) {
        aa1 = new aa();
        this.d.put(paramd, aa1);
      } 
      return aa1;
    } 
  }
  
  private aa e(d paramd) {
    synchronized (this.c) {
      aa aa2 = this.e.get(paramd);
      aa aa1 = aa2;
      if (aa2 == null) {
        aa1 = new aa();
        this.e.put(paramd, aa1);
      } 
      return aa1;
    } 
  }
  
  private aa f(d paramd) {
    synchronized (this.c) {
      aa aa = e(paramd);
      if (aa.a() > 0)
        return aa; 
      return d(paramd);
    } 
  }
  
  @Nullable
  public AppLovinAdImpl a(d paramd) {
    synchronized (this.c) {
      aa aa = d(paramd);
      if (aa.a() > 0) {
        e(paramd).a(aa.c());
        f f = new f(paramd, this.a);
      } else {
        aa = null;
      } 
      if (aa != null) {
        null = this.b;
        if (y.a()) {
          null = this.b;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Retrieved ad of zone ");
          stringBuilder.append(paramd);
          stringBuilder.append("...");
          null.b("AdPreloadManager", stringBuilder.toString());
          return (AppLovinAdImpl)aa;
        } 
      } else {
        null = this.b;
        if (y.a()) {
          null = this.b;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to retrieve ad of zone ");
          stringBuilder.append(paramd);
          stringBuilder.append("...");
          null.b("AdPreloadManager", stringBuilder.toString());
        } 
      } 
      return (AppLovinAdImpl)aa;
    } 
  }
  
  void a(AppLovinAdImpl paramAppLovinAdImpl) {
    synchronized (this.c) {
      d(paramAppLovinAdImpl.getAdZone()).a(paramAppLovinAdImpl);
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ad enqueued: ");
        stringBuilder.append(paramAppLovinAdImpl);
        y1.b("AdPreloadManager", stringBuilder.toString());
      } 
      return;
    } 
  }
  
  @Nullable
  public AppLovinAdImpl b(d paramd) {
    synchronized (this.c) {
      return f(paramd).c();
    } 
  }
  
  public AppLovinAdBase c(d paramd) {
    synchronized (this.c) {
      return (AppLovinAdBase)f(paramd).d();
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */