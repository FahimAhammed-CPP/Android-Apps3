package com.applovin.impl.sdk;

import android.content.Intent;
import android.content.IntentFilter;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.ad.g;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class d implements AppLovinBroadcastManager.Receiver {
  private static final long a = TimeUnit.SECONDS.toMillis(2L);
  
  private final p b;
  
  private final y c;
  
  private final HashSet<c> d = new HashSet<c>();
  
  private final Object e = new Object();
  
  public d(p paramp) {
    this.b = paramp;
    this.c = paramp.L();
  }
  
  private void a() {
    synchronized (this.e) {
      Iterator<c> iterator = this.d.iterator();
      while (iterator.hasNext())
        ((c)iterator.next()).b(); 
      return;
    } 
  }
  
  @Nullable
  private c b(g paramg) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Ljava/lang/Object;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_1
    //   8: ifnonnull -> 15
    //   11: aload_2
    //   12: monitorexit
    //   13: aconst_null
    //   14: areturn
    //   15: aload_0
    //   16: getfield d : Ljava/util/HashSet;
    //   19: invokevirtual iterator : ()Ljava/util/Iterator;
    //   22: astore_3
    //   23: aload_3
    //   24: invokeinterface hasNext : ()Z
    //   29: ifeq -> 57
    //   32: aload_3
    //   33: invokeinterface next : ()Ljava/lang/Object;
    //   38: checkcast com/applovin/impl/sdk/c
    //   41: astore #4
    //   43: aload_1
    //   44: aload #4
    //   46: invokevirtual a : ()Lcom/applovin/impl/sdk/ad/g;
    //   49: if_acmpne -> 23
    //   52: aload_2
    //   53: monitorexit
    //   54: aload #4
    //   56: areturn
    //   57: aload_2
    //   58: monitorexit
    //   59: aconst_null
    //   60: areturn
    //   61: astore_1
    //   62: aload_2
    //   63: monitorexit
    //   64: aload_1
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   11	13	61	finally
    //   15	23	61	finally
    //   23	54	61	finally
    //   57	59	61	finally
    //   62	64	61	finally
  }
  
  private void b() {
    null = new HashSet();
    synchronized (this.e) {
      for (c c : this.d) {
        g g = c.a();
        if (g == null) {
          null.add(c);
          continue;
        } 
        long l = g.Q();
        if (l <= 0L) {
          y y2 = this.c;
          if (y.a()) {
            y2 = this.c;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Ad expired while app was paused. Preparing to notify listener for ad: ");
            stringBuilder.append(g);
            y2.b("AdNewExpirationManager", stringBuilder.toString());
          } 
          null.add(c);
          continue;
        } 
        y y1 = this.c;
        if (y.a()) {
          y1 = this.c;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Rescheduling expiration with remaining ");
          stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(l));
          stringBuilder.append(" seconds for ad: ");
          stringBuilder.append(g);
          y1.b("AdNewExpirationManager", stringBuilder.toString());
        } 
        c.a(l);
      } 
      for (c c : null) {
        a(c);
        c.c();
      } 
      return;
    } 
  }
  
  public void a(g paramg) {
    synchronized (this.e) {
      c c = b(paramg);
      if (c != null) {
        y y1 = this.c;
        if (y.a()) {
          y1 = this.c;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Cancelling expiration timer for ad: ");
          stringBuilder.append(paramg);
          y1.b("AdNewExpirationManager", stringBuilder.toString());
        } 
        c.b();
        a(c);
      } 
      return;
    } 
  }
  
  public void a(c paramc) {
    synchronized (this.e) {
      this.d.remove(paramc);
      if (this.d.isEmpty())
        AppLovinBroadcastManager.unregisterReceiver(this); 
      return;
    } 
  }
  
  public boolean a(g paramg, a parama) {
    synchronized (this.e) {
      y y1;
      if (b(paramg) != null) {
        y1 = this.c;
        if (y.a()) {
          y1 = this.c;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Ad expiration already scheduled for ad: ");
          stringBuilder.append(paramg);
          y1.b("AdNewExpirationManager", stringBuilder.toString());
        } 
        return true;
      } 
      if (paramg.Q() <= a) {
        y1 = this.c;
        if (y.a()) {
          y1 = this.c;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Ad has already expired: ");
          stringBuilder.append(paramg);
          y1.b("AdNewExpirationManager", stringBuilder.toString());
        } 
        paramg.S();
        return false;
      } 
      y y2 = this.c;
      if (y.a()) {
        y2 = this.c;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scheduling ad expiration ");
        stringBuilder.append(TimeUnit.MILLISECONDS.toSeconds(paramg.Q()));
        stringBuilder.append(" seconds from now for ");
        stringBuilder.append(paramg);
        stringBuilder.append("...");
        y2.b("AdNewExpirationManager", stringBuilder.toString());
      } 
      if (this.d.isEmpty()) {
        AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.application_paused"));
        AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.application_resumed"));
      } 
      c c = c.a(paramg, (a)y1, this.b);
      this.d.add(c);
      return true;
    } 
  }
  
  public void onReceive(Intent paramIntent, @Nullable Map<String, Object> paramMap) {
    String str = paramIntent.getAction();
    if ("com.applovin.application_paused".equals(str)) {
      a();
      return;
    } 
    if ("com.applovin.application_resumed".equals(str))
      b(); 
  }
  
  public static interface a {
    void onAdExpired(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */