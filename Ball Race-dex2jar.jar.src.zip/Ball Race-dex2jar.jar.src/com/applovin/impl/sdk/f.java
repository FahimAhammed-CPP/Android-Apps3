package com.applovin.impl.sdk;

import android.content.Intent;
import android.content.IntentFilter;
import androidx.annotation.Nullable;
import com.applovin.impl.sdk.c.a;
import com.applovin.impl.sdk.utils.p;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class f implements AppLovinBroadcastManager.Receiver {
  private p a;
  
  private final Object b = new Object();
  
  private final AtomicBoolean c = new AtomicBoolean();
  
  private boolean d;
  
  private final p e;
  
  private final WeakReference<a> f;
  
  private long g;
  
  public f(p paramp, a parama) {
    this.f = new WeakReference<a>(parama);
    this.e = paramp;
  }
  
  private void i() {
    synchronized (this.b) {
      if (this.a != null) {
        this.a.b();
      } else {
        this.e.L();
        if (y.a())
          this.e.L().b("AdRefreshManager", "An ad load is in progress. Will pause refresh once the ad finishes loading."); 
        this.c.set(true);
      } 
      return;
    } 
  }
  
  private void j() {
    synchronized (this.b) {
      if (this.a != null) {
        this.a.c();
      } else {
        this.c.set(false);
      } 
      return;
    } 
  }
  
  private void k() {
    synchronized (this.b) {
      this.a = null;
      if (!((Boolean)this.e.a(a.r)).booleanValue())
        AppLovinBroadcastManager.unregisterReceiver(this); 
      return;
    } 
  }
  
  private void l() {
    if (((Boolean)this.e.a(a.q)).booleanValue())
      i(); 
  }
  
  private void m() {
    if (((Boolean)this.e.a(a.q)).booleanValue())
      synchronized (this.b) {
        if (this.d) {
          this.e.L();
          if (y.a())
            this.e.L().b("AdRefreshManager", "Fullscreen ad dismissed but banner ad refresh paused by publisher. Waiting for publisher to resume banner ad refresh."); 
          return;
        } 
        if (this.e.Y().isApplicationPaused()) {
          this.e.L();
          if (y.a())
            this.e.L().b("AdRefreshManager", "Waiting for the application to enter foreground to resume the timer."); 
          return;
        } 
        if (this.a != null)
          this.a.c(); 
        return;
      }  
  }
  
  public void a(long paramLong) {
    synchronized (this.b) {
      c();
      this.g = paramLong;
      this.a = p.a(paramLong, this.e, new Runnable(this) {
            public void run() {
              f.a(this.a);
              f.a a = f.b(this.a).get();
              if (a != null)
                a.onAdRefresh(); 
            }
          });
      if (!((Boolean)this.e.a(a.r)).booleanValue()) {
        AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.application_paused"));
        AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.application_resumed"));
        AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.fullscreen_ad_displayed"));
        AppLovinBroadcastManager.registerReceiver(this, new IntentFilter("com.applovin.fullscreen_ad_hidden"));
      } 
      if (((Boolean)this.e.a(a.q)).booleanValue() && (this.e.Z().b() || this.e.Y().isApplicationPaused()))
        this.a.b(); 
      if (this.c.compareAndSet(true, false) && ((Boolean)this.e.a(a.s)).booleanValue()) {
        this.e.L();
        if (y.a())
          this.e.L().b("AdRefreshManager", "Pausing refresh for a previous request."); 
        this.a.b();
      } 
      return;
    } 
  }
  
  public boolean a() {
    synchronized (this.b) {
      if (this.a != null)
        return true; 
    } 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return bool;
  }
  
  public long b() {
    synchronized (this.b) {
      if (this.a != null)
        return this.a.a(); 
    } 
    long l = -1L;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
    return l;
  }
  
  public void c() {
    synchronized (this.b) {
      if (this.a != null) {
        this.a.d();
        k();
      } 
      return;
    } 
  }
  
  public void d() {
    synchronized (this.b) {
      i();
      this.d = true;
      return;
    } 
  }
  
  public void e() {
    synchronized (this.b) {
      j();
      this.d = false;
      return;
    } 
  }
  
  public boolean f() {
    return this.d;
  }
  
  public void g() {
    if (((Boolean)this.e.a(a.p)).booleanValue())
      i(); 
  }
  
  public void h() {
    if (((Boolean)this.e.a(a.p)).booleanValue())
      synchronized (this.b) {
        if (this.d) {
          this.e.L();
          if (y.a())
            this.e.L().b("AdRefreshManager", "Application resumed but banner ad refresh paused by publisher. Waiting for publisher to resume banner ad refresh."); 
          return;
        } 
        if (this.e.Z().b()) {
          this.e.L();
          if (y.a())
            this.e.L().b("AdRefreshManager", "Waiting for the full screen ad to be dismissed to resume the timer."); 
          return;
        } 
        p p1 = this.a;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (p1 != null) {
          long l1 = this.g;
          long l2 = b();
          long l3 = ((Long)this.e.a(a.o)).longValue();
          if (l3 >= 0L && l1 - l2 > l3) {
            c();
            bool1 = true;
          } else {
            this.a.c();
            bool1 = bool2;
          } 
        } 
        if (bool1) {
          null = this.f.get();
          if (null != null) {
            null.onAdRefresh();
            return;
          } 
        } 
      }  
  }
  
  public void onReceive(Intent paramIntent, @Nullable Map<String, Object> paramMap) {
    String str = paramIntent.getAction();
    if ("com.applovin.application_paused".equals(str)) {
      g();
      return;
    } 
    if ("com.applovin.application_resumed".equals(str)) {
      h();
      return;
    } 
    if ("com.applovin.fullscreen_ad_displayed".equals(str)) {
      l();
      return;
    } 
    if ("com.applovin.fullscreen_ad_hidden".equals(str))
      m(); 
  }
  
  public static interface a {
    void onAdRefresh();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */