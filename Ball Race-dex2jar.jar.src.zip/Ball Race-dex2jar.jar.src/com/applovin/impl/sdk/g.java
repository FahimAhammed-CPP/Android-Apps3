package com.applovin.impl.sdk;

import android.os.Bundle;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.applovin.communicator.AppLovinCommunicator;
import com.applovin.communicator.AppLovinCommunicatorMessage;
import com.applovin.communicator.AppLovinCommunicatorSubscriber;
import com.applovin.impl.sdk.e.a;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.e.z;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.mediation.MaxAdFormat;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class g implements AppLovinCommunicatorSubscriber {
  private final p a;
  
  private final Object b = new Object();
  
  private final LinkedHashMap<String, Bundle> c = new LinkedHashMap<String, Bundle>(this) {
      protected boolean removeEldestEntry(Map.Entry param1Entry) {
        return (size() > 16);
      }
    };
  
  private final Set<a> d = Collections.synchronizedSet(new HashSet<a>());
  
  public g(p paramp) {
    this.a = paramp;
    if (StringUtils.isValidString(a()))
      AppLovinCommunicator.getInstance(p.y()).subscribe(this, "safedk_ad_info"); 
  }
  
  public static String a() {
    return c("getVersion");
  }
  
  public static String b() {
    return c("getSdkKey");
  }
  
  private static String c(String paramString) {
    try {
      Class<?> clazz = Class.forName("com.applovin.quality.AppLovinQualityService");
      return (String)clazz.getMethod(paramString, new Class[0]).invoke(null, new Object[0]);
    } catch (Throwable throwable) {
      try {
        Class<?> clazz = Class.forName("com.safedk.android.SafeDK");
        return (String)clazz.getMethod(paramString, new Class[0]).invoke(null, new Object[0]);
      } catch (Throwable throwable1) {
        return "";
      } 
    } 
  }
  
  @Nullable
  public Bundle a(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return null; 
    synchronized (this.b) {
      return this.c.get(paramString);
    } 
  }
  
  public void a(a parama) {
    this.d.add(parama);
  }
  
  public void b(a parama) {
    this.d.remove(parama);
  }
  
  public void b(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return; 
    synchronized (this.b) {
      this.c.remove(paramString);
      return;
    } 
  }
  
  public String getCommunicatorId() {
    return g.class.getSimpleName();
  }
  
  public void onMessageReceived(AppLovinCommunicatorMessage paramAppLovinCommunicatorMessage) {
    if ("safedk_ad_info".equals(paramAppLovinCommunicatorMessage.getTopic())) {
      Bundle bundle2 = paramAppLovinCommunicatorMessage.getMessageData().getBundle("public");
      if (bundle2 == null) {
        this.a.L();
        if (y.a())
          this.a.L().d("AppLovinSdk", "Received SafeDK ad info without public data"); 
        return;
      } 
      Bundle bundle1 = paramAppLovinCommunicatorMessage.getMessageData().getBundle("private");
      if (bundle1 == null) {
        this.a.L();
        if (y.a())
          this.a.L().d("AppLovinSdk", "Received SafeDK ad info without private data"); 
        return;
      } 
      if (MaxAdFormat.formatFromString(bundle1.getString("ad_format")) == null) {
        this.a.L();
        if (y.a())
          this.a.L().d("AppLovinSdk", "Received SafeDK ad info without ad format"); 
        return;
      } 
      null = bundle1.getString("id");
      if (TextUtils.isEmpty(null)) {
        this.a.L();
        if (y.a())
          this.a.L().d("AppLovinSdk", "Received SafeDK ad info without serve id"); 
        return;
      } 
      synchronized (this.b) {
        this.a.L();
        if (y.a()) {
          y y = this.a.L();
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Storing current SafeDK ad info for serve id: ");
          stringBuilder.append(null);
          y.b("AppLovinSdk", stringBuilder.toString());
        } 
        this.c.put(null, bundle2);
        String str = bundle2.getString("ad_review_creative_id");
        if (StringUtils.isValidString(str) && !this.d.isEmpty())
          for (a a : new HashSet(this.d)) {
            this.a.M().a((a)new z(this.a, new Runnable(this, a, null, str) {
                    public void run() {
                      this.a.onCreativeIdGenerated(this.b, this.c);
                    }
                  }), o.a.c);
          }  
      } 
    } 
  }
  
  public static interface a {
    void onCreativeIdGenerated(String param1String1, String param1String2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */