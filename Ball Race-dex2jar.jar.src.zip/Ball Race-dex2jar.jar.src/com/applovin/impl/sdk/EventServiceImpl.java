package com.applovin.impl.sdk;

import android.content.Intent;
import android.text.TextUtils;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.c.d;
import com.applovin.impl.sdk.e.a;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.e.z;
import com.applovin.impl.sdk.network.j;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.sdk.AppLovinEventService;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class EventServiceImpl implements AppLovinEventService {
  public static final List<String> ALLOW_PRE_INIT_EVENT_TYPES = Arrays.asList(new String[] { "landing", "paused", "resumed", "cf_start", "tos_ok", "gdpr_ok" });
  
  private final p a;
  
  private final Map<String, Object> b;
  
  private final AtomicBoolean c = new AtomicBoolean();
  
  public EventServiceImpl(p paramp) {
    this.a = paramp;
    if (((Boolean)paramp.a(b.bs)).booleanValue()) {
      this.b = JsonUtils.toStringObjectMap((String)this.a.b(d.B, "{}"));
      return;
    } 
    this.b = CollectionUtils.map();
    paramp.a(d.B, "{}");
  }
  
  private String a() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append((String)this.a.a(b.bj));
    stringBuilder.append("4.0/pix");
    return stringBuilder.toString();
  }
  
  private Map<String, String> a(u paramu, Map<String, String> paramMap) {
    String str;
    Map<String, String> map = CollectionUtils.map(paramMap);
    boolean bool = this.a.b(b.bq).contains(paramu.a());
    if (bool) {
      str = paramu.a();
    } else {
      str = "postinstall";
    } 
    map.put("AppLovin-Event", str);
    if (!bool)
      map.put("AppLovin-Sub-Event", paramu.a()); 
    return map;
  }
  
  private Map<String, String> a(u paramu, boolean paramBoolean) {
    Map<String, Object> map;
    String str;
    boolean bool = this.a.b(b.bq).contains(paramu.a());
    if (this.a.S() != null) {
      map = this.a.S().a(null, paramBoolean, false);
    } else {
      map = this.a.R().a(null, paramBoolean, false);
    } 
    if (bool) {
      str = paramu.a();
    } else {
      str = "postinstall";
    } 
    map.put("event", str);
    map.put("event_id", paramu.d());
    map.put("ts", Long.toString(paramu.c()));
    if (!bool)
      map.put("sub_event", paramu.a()); 
    return Utils.stringifyObjectMap(map);
  }
  
  private String b() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append((String)this.a.a(b.bk));
    stringBuilder.append("4.0/pix");
    return stringBuilder.toString();
  }
  
  private void c() {
    if (((Boolean)this.a.a(b.bs)).booleanValue()) {
      String str = CollectionUtils.toJsonString(this.b, "{}");
      this.a.a(d.B, str);
    } 
  }
  
  public Map<String, Object> getSuperProperties() {
    return CollectionUtils.map(this.b);
  }
  
  public void maybeTrackAppOpenEvent() {
    if (this.c.compareAndSet(false, true))
      this.a.G().trackEvent("landing"); 
  }
  
  public void setSuperProperty(Object paramObject, String paramString) {
    if (TextUtils.isEmpty(paramString)) {
      y.i("AppLovinEventService", "Super property key cannot be null or empty");
      return;
    } 
    if (paramObject == null) {
      this.b.remove(paramString);
      c();
      return;
    } 
    List list = this.a.b(b.br);
    if (!Utils.objectIsOfType(paramObject, list, this.a)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to set super property '");
      stringBuilder.append(paramObject);
      stringBuilder.append("' for key '");
      stringBuilder.append(paramString);
      stringBuilder.append("' - valid super property types include: ");
      stringBuilder.append(list);
      y.i("AppLovinEventService", stringBuilder.toString());
      return;
    } 
    this.b.put(paramString, Utils.sanitizeSuperProperty(paramObject, this.a));
    c();
  }
  
  public String toString() {
    return "EventService{}";
  }
  
  public void trackCheckout(String paramString, Map<String, String> paramMap) {
    paramMap = CollectionUtils.map(paramMap);
    paramMap.put("transaction_id", paramString);
    trackEvent("checkout", paramMap);
  }
  
  public void trackEvent(String paramString) {
    trackEvent(paramString, CollectionUtils.map());
  }
  
  public void trackEvent(String paramString, Map<String, String> paramMap) {
    trackEvent(paramString, paramMap, null);
  }
  
  public void trackEvent(String paramString, Map<String, String> paramMap1, Map<String, String> paramMap2) {
    this.a.L();
    if (y.a()) {
      y y = this.a.L();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Tracking event: \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\" with parameters: ");
      stringBuilder.append(paramMap1);
      y.b("AppLovinEventService", stringBuilder.toString());
    } 
    u u = new u(paramString, paramMap1, this.b);
    boolean bool = ALLOW_PRE_INIT_EVENT_TYPES.contains(paramString);
    try {
      this.a.M().a((a)new z(this.a, bool, new Runnable(this, u, paramMap2, bool) {
              public void run() {
                j j = j.o().c(EventServiceImpl.c(this.d)).d(EventServiceImpl.b(this.d)).a(EventServiceImpl.a(this.d, this.a, false)).b(EventServiceImpl.a(this.d, this.a, this.b)).c(this.a.b()).b(((Boolean)EventServiceImpl.a(this.d).a(b.fk)).booleanValue()).a(((Boolean)EventServiceImpl.a(this.d).a(b.fb)).booleanValue()).c(this.c).a();
                EventServiceImpl.a(this.d).al().a(j);
              }
            }), o.a.c);
      return;
    } catch (Throwable throwable) {
      this.a.L();
      if (y.a()) {
        y y = this.a.L();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to track event: ");
        stringBuilder.append(u);
        y.b("AppLovinEventService", stringBuilder.toString(), throwable);
      } 
      return;
    } 
  }
  
  public void trackEventSynchronously(String paramString) {
    this.a.L();
    if (y.a()) {
      y y = this.a.L();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Tracking event: \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\" synchronously");
      y.b("AppLovinEventService", stringBuilder.toString());
    } 
    u u = new u(paramString, CollectionUtils.map(), this.b);
    j j = j.o().c(a()).d(b()).a(a(u, true)).b(a(u, (Map<String, String>)null)).c(u.b()).b(((Boolean)this.a.a(b.fk)).booleanValue()).a(((Boolean)this.a.a(b.fb)).booleanValue()).a();
    this.a.al().a(j);
  }
  
  public void trackInAppPurchase(Intent paramIntent, Map<String, String> paramMap) {
    paramMap = CollectionUtils.map(paramMap);
    try {
      paramMap.put("receipt_data", paramIntent.getStringExtra("INAPP_PURCHASE_DATA"));
      paramMap.put("receipt_data_signature", paramIntent.getStringExtra("INAPP_DATA_SIGNATURE"));
    } catch (Throwable throwable) {
      y.c("AppLovinEventService", "Unable to track in app purchase - invalid purchase intent", throwable);
    } 
    trackEvent("iap", paramMap);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\EventServiceImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */