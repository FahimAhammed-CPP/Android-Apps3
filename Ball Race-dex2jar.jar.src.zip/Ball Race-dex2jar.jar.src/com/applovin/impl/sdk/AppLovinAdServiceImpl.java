package com.applovin.impl.sdk;

import android.content.Context;
import android.graphics.PointF;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.applovin.adview.AppLovinAdView;
import com.applovin.impl.sdk.ad.AppLovinAdImpl;
import com.applovin.impl.sdk.ad.b;
import com.applovin.impl.sdk.ad.c;
import com.applovin.impl.sdk.ad.d;
import com.applovin.impl.sdk.ad.e;
import com.applovin.impl.sdk.ad.f;
import com.applovin.impl.sdk.ad.i;
import com.applovin.impl.sdk.array.ArrayDirectDownloadAd;
import com.applovin.impl.sdk.array.ArrayService;
import com.applovin.impl.sdk.d.a;
import com.applovin.impl.sdk.e.a;
import com.applovin.impl.sdk.e.j;
import com.applovin.impl.sdk.e.k;
import com.applovin.impl.sdk.e.l;
import com.applovin.impl.sdk.e.o;
import com.applovin.impl.sdk.e.p;
import com.applovin.impl.sdk.network.j;
import com.applovin.impl.sdk.utils.CollectionUtils;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.utils.StringUtils;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.i;
import com.applovin.impl.sdk.utils.k;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdService;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinAdType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;

public class AppLovinAdServiceImpl implements AppLovinAdService {
  private final p a;
  
  private final y b;
  
  private final Handler c = new Handler(Looper.getMainLooper());
  
  private final Map<d, b> d;
  
  private final Object e = new Object();
  
  private final Map<String, String> f = CollectionUtils.map();
  
  private final AtomicReference<JSONObject> g = new AtomicReference<JSONObject>();
  
  AppLovinAdServiceImpl(p paramp) {
    this.a = paramp;
    this.b = paramp.L();
    this.d = CollectionUtils.map(6);
    this.d.put(d.g(), new b());
    this.d.put(d.h(), new b());
    this.d.put(d.i(), new b());
    this.d.put(d.j(), new b());
    this.d.put(d.k(), new b());
    this.d.put(d.l(), new b());
  }
  
  @Nullable
  private Uri a(Uri paramUri, String paramString) {
    try {
      return Uri.parse(paramUri.getQueryParameter(paramString));
    } catch (Throwable throwable) {
      this.a.L();
      if (y.a()) {
        y y1 = this.a.L();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to parse query parameter into Uri: ");
        stringBuilder.append(paramString);
        y1.d("AppLovinAdService", stringBuilder.toString());
      } 
      return null;
    } 
  }
  
  private b a(d paramd) {
    synchronized (this.e) {
      b b2 = this.d.get(paramd);
      b b1 = b2;
      if (b2 == null) {
        b1 = new b();
        this.d.put(paramd, b1);
      } 
      return b1;
    } 
  }
  
  private String a(String paramString1, long paramLong, int paramInt, String paramString2, boolean paramBoolean) {
    try {
      if (StringUtils.isValidString(paramString1)) {
        if (paramInt >= 0) {
          int i = paramInt;
          if (paramInt > 100) {
            i = 0;
            return Uri.parse(paramString1).buildUpon().appendQueryParameter("et_s", Long.toString(paramLong)).appendQueryParameter("pv", Integer.toString(i)).appendQueryParameter("vid_ts", paramString2).appendQueryParameter("uvs", Boolean.toString(paramBoolean)).build().toString();
          } 
          return Uri.parse(paramString1).buildUpon().appendQueryParameter("et_s", Long.toString(paramLong)).appendQueryParameter("pv", Integer.toString(i)).appendQueryParameter("vid_ts", paramString2).appendQueryParameter("uvs", Boolean.toString(paramBoolean)).build().toString();
        } 
      } else {
        return null;
      } 
    } catch (Throwable throwable) {
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unknown error parsing the video end url: ");
        stringBuilder.append(paramString1);
        y1.b("AppLovinAdService", stringBuilder.toString(), throwable);
      } 
      return null;
    } 
    boolean bool = false;
    return Uri.parse(paramString1).buildUpon().appendQueryParameter("et_s", Long.toString(paramLong)).appendQueryParameter("pv", Integer.toString(bool)).appendQueryParameter("vid_ts", (String)throwable).appendQueryParameter("uvs", Boolean.toString(paramBoolean)).build().toString();
  }
  
  private String a(String paramString, long paramLong1, long paramLong2, List<Long> paramList, boolean paramBoolean, int paramInt) {
    if (StringUtils.isValidString(paramString)) {
      Uri.Builder builder = Uri.parse(paramString).buildUpon().appendQueryParameter("et_ms", Long.toString(paramLong1)).appendQueryParameter("vs_ms", Long.toString(paramLong2));
      if (paramList != null && paramList.size() > 0)
        builder.appendQueryParameter("ec_ms", paramList.toString()); 
      if (paramInt != k.a) {
        builder.appendQueryParameter("musw_ch", Boolean.toString(paramBoolean));
        builder.appendQueryParameter("musw_st", Boolean.toString(k.a(paramInt)));
      } 
      return builder.build().toString();
    } 
    return null;
  }
  
  private void a(int paramInt, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    this.c.post(new Runnable(this, paramAppLovinAdLoadListener, paramInt) {
          public void run() {
            try {
              if (this.a instanceof i) {
                ((i)this.a).failedToReceiveAdV2(new AppLovinError(this.b, ""));
                return;
              } 
              this.a.failedToReceiveAd(this.b);
              return;
            } catch (Throwable throwable) {
              y.c("AppLovinAdService", "Unable to notify listener about ad load failure", throwable);
              return;
            } 
          }
        });
  }
  
  private void a(Uri paramUri, e parame, AppLovinAdView paramAppLovinAdView, com.applovin.impl.adview.b paramb) {
    if (Utils.openUri(paramAppLovinAdView.getContext(), paramUri, this.a))
      k.c(paramb.g(), (AppLovinAd)parame, paramAppLovinAdView); 
    paramb.o();
  }
  
  private void a(Uri paramUri, e parame, @Nullable AppLovinAdView paramAppLovinAdView, @Nullable com.applovin.impl.adview.b paramb, Context paramContext, p paramp) {
    if (paramUri != null && StringUtils.isValidString(paramUri.getQuery())) {
      Uri uri1 = a(paramUri, "primaryUrl");
      List<Uri> list2 = b(paramUri, "primaryTrackingUrl");
      Uri uri2 = a(paramUri, "fallbackUrl");
      List<Uri> list1 = b(paramUri, "fallbackTrackingUrl");
      if (uri1 == null && uri2 == null) {
        paramp.L();
        if (y.a())
          paramp.L().e("AppLovinAdService", "Failed to parse both primary and backup URLs for Deep Link+ command"); 
        return;
      } 
      if (!a(uri1, "primary", list2, parame, paramAppLovinAdView, paramb, paramContext, paramp))
        a(uri2, "backup", list1, parame, paramAppLovinAdView, paramb, paramContext, paramp); 
      if (paramb != null) {
        paramb.o();
        return;
      } 
    } else {
      paramp.L();
      if (y.a())
        paramp.L().e("AppLovinAdService", "Failed to execute Deep Link+ command - no query parameters found"); 
    } 
  }
  
  private void a(Uri paramUri, e parame, com.applovin.impl.adview.b paramb, com.applovin.impl.adview.activity.b.a parama) {
    y y1 = this.b;
    if (y.a()) {
      y1 = this.b;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Forwarding click ");
      stringBuilder.append(paramUri);
      y1.b("AppLovinAdService", stringBuilder.toString());
    } 
    parame.setMaxAdValue("forwarding_clicked_url", paramUri.toString());
    String str = (String)this.a.C().getExtraParameters().get("close_ad_on_forwarding_click_scheme");
    if (StringUtils.isValidString(str) && Boolean.parseBoolean(str)) {
      if (parama != null) {
        this.c.post(new Runnable(this, parama) {
              public void run() {
                if (this.a != null) {
                  AppLovinAdServiceImpl.b(this.b);
                  if (y.a())
                    AppLovinAdServiceImpl.b(this.b).b("AppLovinAdService", "Dismissing ad after forwarding click"); 
                  this.a.h();
                } 
              }
            });
        return;
      } 
      if (paramb != null && !Utils.isBML(parame.getSize())) {
        y y2 = this.b;
        if (y.a())
          this.b.b("AppLovinAdService", "Closing ad after forwarding click"); 
        paramb.l();
      } 
    } 
  }
  
  private void a(AppLovinError paramAppLovinError, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    if (paramAppLovinAdLoadListener instanceof i) {
      ((i)paramAppLovinAdLoadListener).failedToReceiveAdV2(paramAppLovinError);
      return;
    } 
    paramAppLovinAdLoadListener.failedToReceiveAd(paramAppLovinError.getCode());
  }
  
  private void a(d paramd, a parama) {
    AppLovinAdImpl appLovinAdImpl = this.a.U().a(paramd);
    if (appLovinAdImpl != null) {
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Using pre-loaded ad: ");
        stringBuilder.append(appLovinAdImpl);
        stringBuilder.append(" for ");
        stringBuilder.append(paramd);
        y1.b("AppLovinAdService", stringBuilder.toString());
      } 
      parama.adReceived((AppLovinAd)appLovinAdImpl);
      return;
    } 
    a((a)new k(paramd, (AppLovinAdLoadListener)parama, this.a));
  }
  
  private void a(d paramd, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    if (paramd != null) {
      if (paramAppLovinAdLoadListener != null) {
        this.a.L();
        if (y.a()) {
          y y1 = this.a.L();
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Loading next ad of zone {");
          stringBuilder.append(paramd);
          stringBuilder.append("}...");
          y1.b("AppLovinAdService", stringBuilder.toString());
        } 
        b b = a(paramd);
        synchronized (b.a) {
          b.c.add(paramAppLovinAdLoadListener);
          if (!b.b) {
            b.b = true;
            a(paramd, new a(b));
          } else {
            y y1 = this.b;
            if (y.a())
              this.b.b("AppLovinAdService", "Already waiting on an ad load..."); 
          } 
          return;
        } 
      } 
      throw new IllegalArgumentException("No callback specified");
    } 
    throw new IllegalArgumentException("No zone specified");
  }
  
  private void a(e parame, Uri paramUri, com.applovin.impl.adview.activity.b.a parama, Context paramContext) {
    if (a(paramUri.getScheme())) {
      a(paramUri, parame, (com.applovin.impl.adview.b)null, parama);
      return;
    } 
    if (Utils.isDeepLinkPlusUrl(paramUri)) {
      a(paramUri, parame, (AppLovinAdView)null, (com.applovin.impl.adview.b)null, paramContext, this.a);
      return;
    } 
    Utils.openUri(paramContext, paramUri, this.a);
  }
  
  private void a(e parame, AppLovinAdView paramAppLovinAdView, com.applovin.impl.adview.b paramb, Uri paramUri) {
    if (a(paramUri.getScheme())) {
      a(paramUri, parame, paramb, (com.applovin.impl.adview.activity.b.a)null);
      return;
    } 
    if (Utils.isDeepLinkPlusUrl(paramUri)) {
      a(paramUri, parame, paramAppLovinAdView, paramb, paramAppLovinAdView.getContext(), this.a);
      return;
    } 
    a(paramUri, parame, paramAppLovinAdView, paramb);
  }
  
  private void a(a parama) {
    if (StringUtils.isValidString(parama.a())) {
      String str1;
      String str2 = parama.a();
      if (StringUtils.isValidString(parama.b())) {
        str1 = parama.b();
      } else {
        str1 = null;
      } 
      this.a.al().a(j.o().c(str2).d(str1).b(parama.c()).a(false).d(parama.d()).a());
      return;
    } 
    y y1 = this.b;
    if (y.a())
      this.b.d("AppLovinAdService", "Requested a postback dispatch for a null URL; nothing to do..."); 
  }
  
  private void a(a parama) {
    if (!this.a.d())
      y.h("AppLovinSdk", "Attempted to load ad before SDK initialization. Please wait until after the SDK has initialized, e.g. AppLovinSdk.initializeSdk(Context, SdkInitializationListener)."); 
    this.a.a();
    this.a.M().a(parama, o.a.a);
  }
  
  private void a(AppLovinAd paramAppLovinAd, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    this.c.post(new Runnable(this, paramAppLovinAdLoadListener, paramAppLovinAd) {
          public void run() {
            try {
              this.a.adReceived(this.b);
              return;
            } catch (Throwable throwable) {
              y.c("AppLovinAdService", "Unable to notify listener about a newly loaded ad", throwable);
              return;
            } 
          }
        });
  }
  
  private boolean a(Uri paramUri, String paramString, List<Uri> paramList, e parame, @Nullable AppLovinAdView paramAppLovinAdView, @Nullable com.applovin.impl.adview.b paramb, Context paramContext, p paramp) {
    paramp.L();
    if (y.a()) {
      y y1 = paramp.L();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Opening ");
      stringBuilder.append(paramString);
      stringBuilder.append(" URL: ");
      stringBuilder.append(paramUri);
      y1.b("AppLovinAdService", stringBuilder.toString());
    } 
    boolean bool = Utils.openUri(paramContext, paramUri, paramp);
    if (bool) {
      paramp.L();
      if (y.a()) {
        y y1 = paramp.L();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("URL opened successfully, dispatching tracking URLs: ");
        stringBuilder.append(paramList);
        y1.b("AppLovinAdService", stringBuilder.toString());
      } 
      for (Uri uri : paramList)
        paramp.ak().dispatchPostbackAsync(uri.toString(), null); 
      if (paramb != null) {
        k.c(paramb.g(), (AppLovinAd)parame, paramAppLovinAdView);
        return bool;
      } 
    } else {
      paramp.L();
      if (y.a())
        paramp.L().e("AppLovinAdService", "URL failed to open"); 
    } 
    return bool;
  }
  
  private boolean a(String paramString) {
    String str = (String)this.a.C().getExtraParameters().get("forwarding_click_scheme");
    return (StringUtils.isValidString(str) && StringUtils.isValidString(paramString) && paramString.equalsIgnoreCase(str));
  }
  
  private List<Uri> b(Uri paramUri, String paramString) {
    List list = paramUri.getQueryParameters(paramString);
    ArrayList<Uri> arrayList = new ArrayList(list.size());
    Iterator<String> iterator = list.iterator();
    while (true) {
      if (iterator.hasNext()) {
        String str = iterator.next();
        try {
          arrayList.add(Uri.parse(str));
        } catch (Throwable throwable) {
          this.a.L();
          if (y.a()) {
            y y1 = this.a.L();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to parse query parameter into Uri: ");
            stringBuilder.append(paramString);
            y1.d("AppLovinAdService", stringBuilder.toString());
          } 
        } 
        continue;
      } 
      return arrayList;
    } 
  }
  
  private void b(AppLovinError paramAppLovinError, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    this.c.post(new Runnable(this, paramAppLovinAdLoadListener, paramAppLovinError) {
          public void run() {
            try {
              if (this.a instanceof i) {
                ((i)this.a).failedToReceiveAdV2(this.b);
                return;
              } 
              this.a.failedToReceiveAd(this.b.getCode());
              return;
            } catch (Throwable throwable) {
              y.c("AppLovinAdService", "Unable to notify listener about ad load failure", throwable);
              return;
            } 
          }
        });
  }
  
  public void addCustomQueryParams(Map<String, String> paramMap) {
    synchronized (this.f) {
      this.f.putAll(paramMap);
      return;
    } 
  }
  
  public AppLovinAd dequeueAd(d paramd) {
    AppLovinAdImpl appLovinAdImpl = this.a.U().b(paramd);
    y y1 = this.b;
    if (y.a()) {
      y1 = this.b;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dequeued ad: ");
      stringBuilder.append(appLovinAdImpl);
      stringBuilder.append(" for zone: ");
      stringBuilder.append(paramd);
      stringBuilder.append("...");
      y1.b("AppLovinAdService", stringBuilder.toString());
    } 
    return (AppLovinAd)appLovinAdImpl;
  }
  
  public JSONObject getAndResetCustomPostBody() {
    return this.g.getAndSet(null);
  }
  
  public Map<String, String> getAndResetCustomQueryParams() {
    synchronized (this.f) {
      Map<String, String> map = CollectionUtils.map(this.f);
      this.f.clear();
      return map;
    } 
  }
  
  public String getBidToken() {
    String str;
    StrictMode.ThreadPolicy threadPolicy = StrictMode.allowThreadDiskReads();
    if (this.a.S() != null) {
      str = this.a.S().a();
    } else {
      str = this.a.R().a();
    } 
    StrictMode.setThreadPolicy(threadPolicy);
    return str;
  }
  
  public void loadNextAd(AppLovinAdSize paramAppLovinAdSize, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    a(d.a(paramAppLovinAdSize, AppLovinAdType.REGULAR), paramAppLovinAdLoadListener);
  }
  
  public void loadNextAd(String paramString, AppLovinAdSize paramAppLovinAdSize, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    y y1 = this.b;
    if (y.a()) {
      y1 = this.b;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Loading next ad of zone {");
      stringBuilder.append(paramString);
      stringBuilder.append("} with size ");
      stringBuilder.append(paramAppLovinAdSize);
      y1.b("AppLovinAdService", stringBuilder.toString());
    } 
    a(d.a(paramAppLovinAdSize, AppLovinAdType.REGULAR, paramString), paramAppLovinAdLoadListener);
  }
  
  public void loadNextAdForAdToken(String paramString, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    if (paramString != null) {
      paramString = paramString.trim();
    } else {
      paramString = null;
    } 
    if (TextUtils.isEmpty(paramString)) {
      y.i("AppLovinAdService", "Empty ad token");
      a(new AppLovinError(-8, "Empty ad token"), paramAppLovinAdLoadListener);
      return;
    } 
    c c = new c(paramString, this.a);
    if (c.b() == c.a.b) {
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Loading next ad for token: ");
        stringBuilder.append(c);
        y1.b("AppLovinAdService", stringBuilder.toString());
      } 
      a((a)new l(c, paramAppLovinAdLoadListener, this.a));
      return;
    } 
    if (c.b() == c.a.c) {
      JSONObject jSONObject = c.d();
      if (jSONObject != null) {
        i.f(jSONObject, this.a);
        i.d(jSONObject, this.a);
        i.c(jSONObject, this.a);
        i.e(jSONObject, this.a);
        h.a(this.a);
        if (JsonUtils.getJSONArray(jSONObject, "ads", new JSONArray()).length() > 0) {
          y y2 = this.b;
          if (y.a()) {
            y2 = this.b;
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Rendering ad for token: ");
            stringBuilder1.append(c);
            y2.b("AppLovinAdService", stringBuilder1.toString());
          } 
          a((a)new p(jSONObject, Utils.getZone(jSONObject, this.a), b.f, paramAppLovinAdLoadListener, this.a));
          return;
        } 
        y y1 = this.b;
        if (y.a()) {
          y1 = this.b;
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("No ad returned from the server for token: ");
          stringBuilder1.append(c);
          y1.e("AppLovinAdService", stringBuilder1.toString());
        } 
        a(AppLovinError.NO_FILL, paramAppLovinAdLoadListener);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to retrieve ad response JSON from token: ");
      stringBuilder.append(c.a());
      String str = stringBuilder.toString();
      AppLovinError appLovinError1 = new AppLovinError(-8, str);
      y.i("AppLovinAdService", str);
      a(appLovinError1, paramAppLovinAdLoadListener);
      return;
    } 
    AppLovinError appLovinError = new AppLovinError(-8, "Invalid token type");
    y.i("AppLovinAdService", "Invalid token type");
    a(appLovinError, paramAppLovinAdLoadListener);
  }
  
  public void loadNextAdForZoneId(String paramString, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    if (!TextUtils.isEmpty(paramString)) {
      y y1 = this.b;
      if (y.a()) {
        y1 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Loading next ad of zone {");
        stringBuilder.append(paramString);
        stringBuilder.append("}");
        y1.b("AppLovinAdService", stringBuilder.toString());
      } 
      a(d.a(paramString), paramAppLovinAdLoadListener);
      return;
    } 
    throw new IllegalArgumentException("No zone id specified");
  }
  
  public void loadNextAdForZoneIds(List<String> paramList, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    paramList = CollectionUtils.removeTrimmedEmptyStrings(paramList);
    if (paramList == null || paramList.isEmpty()) {
      y.i("AppLovinAdService", "No zones were provided");
      a(-7, paramAppLovinAdLoadListener);
      return;
    } 
    y y1 = this.b;
    if (y.a()) {
      y1 = this.b;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Loading next ad for zones: ");
      stringBuilder.append(paramList);
      y1.b("AppLovinAdService", stringBuilder.toString());
    } 
    a((a)new j(paramList, paramAppLovinAdLoadListener, this.a));
  }
  
  public void loadNextIncentivizedAd(String paramString, AppLovinAdLoadListener paramAppLovinAdLoadListener) {
    y y1 = this.b;
    if (y.a()) {
      y1 = this.b;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Loading next incentivized ad of zone {");
      stringBuilder.append(paramString);
      stringBuilder.append("}");
      y1.b("AppLovinAdService", stringBuilder.toString());
    } 
    a(d.b(paramString), paramAppLovinAdLoadListener);
  }
  
  public void maybeSubmitPersistentPostbacks(List<a> paramList) {
    if (paramList != null && !paramList.isEmpty()) {
      Iterator<a> iterator = paramList.iterator();
      while (iterator.hasNext())
        a(iterator.next()); 
    } 
  }
  
  public void setCustomPostBody(JSONObject paramJSONObject) {
    this.g.set(paramJSONObject);
  }
  
  @NonNull
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppLovinAdService{adLoadStates=");
    stringBuilder.append(this.d);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void trackAndLaunchClick(e parame, AppLovinAdView paramAppLovinAdView, com.applovin.impl.adview.b paramb, Uri paramUri, PointF paramPointF, boolean paramBoolean1, boolean paramBoolean2) {
    if (parame == null) {
      y1 = this.b;
      if (y.a())
        this.b.e("AppLovinAdService", "Unable to track ad view click. No ad specified"); 
      return;
    } 
    y y2 = this.b;
    if (y.a())
      this.b.b("AppLovinAdService", "Tracking click on an ad..."); 
    maybeSubmitPersistentPostbacks(y1.a(paramPointF, paramBoolean1, paramBoolean2));
    if (paramAppLovinAdView != null && paramUri != null) {
      if (y1.isDirectDownloadEnabled()) {
        this.a.ai().startDirectInstallOrDownloadProcess((ArrayDirectDownloadAd)y1, paramBoolean2, new ArrayService.DirectDownloadListener(this, paramb, (e)y1, paramAppLovinAdView, paramUri) {
              public void onAppDetailsDismissed() {
                if (this.a != null) {
                  AppLovinAdServiceImpl.a(this.e).Y().resumeForClick();
                  k.b(this.a.g(), (AppLovinAd)this.b, this.c);
                } 
              }
              
              public void onAppDetailsDisplayed() {
                AppLovinAdServiceImpl.a(this.e).Y().pauseForClick();
                com.applovin.impl.adview.b b1 = this.a;
                if (b1 != null) {
                  b1.o();
                  k.a(this.a.g(), (AppLovinAd)this.b, this.c);
                } 
              }
              
              public void onFailure() {
                AppLovinAdServiceImpl.b(this.e);
                if (y.a())
                  AppLovinAdServiceImpl.b(this.e).b("AppLovinAdService", "Could not execute Direct Install/Direct Download - falling back to normal click logic"); 
                AppLovinAdServiceImpl.a(this.e, this.b, this.c, this.a, this.d);
              }
            });
        return;
      } 
      a((e)y1, paramAppLovinAdView, paramb, paramUri);
      return;
    } 
    y y1 = this.b;
    if (y.a())
      this.b.e("AppLovinAdService", "Unable to launch click - adView has been prematurely destroyed"); 
  }
  
  public void trackAndLaunchVideoClick(e parame, Uri paramUri, PointF paramPointF, boolean paramBoolean, com.applovin.impl.adview.activity.b.a parama, Context paramContext) {
    y y1;
    if (parame == null) {
      y1 = this.b;
      if (y.a())
        this.b.e("AppLovinAdService", "Unable to track video click. No ad specified"); 
      return;
    } 
    y y2 = this.b;
    if (y.a())
      this.b.b("AppLovinAdService", "Tracking VIDEO click on an ad..."); 
    maybeSubmitPersistentPostbacks(y1.a(paramPointF, paramBoolean));
    if (y1.isDirectDownloadEnabled()) {
      this.a.ai().startDirectInstallOrDownloadProcess((ArrayDirectDownloadAd)y1, paramBoolean, new ArrayService.DirectDownloadListener(this, (e)y1, paramUri, parama, paramContext) {
            public void onAppDetailsDismissed() {
              AppLovinAdServiceImpl.a(this.e).Y().resumeForClick();
            }
            
            public void onAppDetailsDisplayed() {
              AppLovinAdServiceImpl.a(this.e).Y().pauseForClick();
            }
            
            public void onFailure() {
              AppLovinAdServiceImpl.b(this.e);
              if (y.a())
                AppLovinAdServiceImpl.b(this.e).b("AppLovinAdService", "Could not execute Direct Install/Direct Download - falling back to normal click logic"); 
              AppLovinAdServiceImpl.a(this.e, this.a, this.b, this.c, this.d);
            }
          });
      return;
    } 
    a((e)y1, paramUri, parama, paramContext);
  }
  
  public void trackAppKilled(e parame) {
    y y1;
    if (parame == null) {
      y1 = this.b;
      if (y.a())
        this.b.e("AppLovinAdService", "Unable to track app killed. No ad specified"); 
      return;
    } 
    y y2 = this.b;
    if (y.a())
      this.b.b("AppLovinAdService", "Tracking app killed during ad..."); 
    List list = y1.as();
    if (list != null && !list.isEmpty()) {
      for (a a : list)
        a(new a(a.a(), a.b())); 
    } else {
      y y3 = this.b;
      if (y.a()) {
        y3 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to track app killed during AD #");
        stringBuilder.append(y1.getAdIdNumber());
        stringBuilder.append(". Missing app killed tracking URL.");
        y3.d("AppLovinAdService", stringBuilder.toString());
      } 
    } 
  }
  
  public void trackFullScreenAdClosed(e parame, long paramLong1, List<Long> paramList, long paramLong2, boolean paramBoolean, int paramInt) {
    y y1;
    if (parame == null) {
      y1 = this.b;
      if (y.a())
        this.b.e("AppLovinAdService", "Unable to track ad closed. No ad specified."); 
      return;
    } 
    y y2 = this.b;
    if (y.a())
      this.b.b("AppLovinAdService", "Tracking ad closed..."); 
    List list = y1.ar();
    if (list != null && !list.isEmpty()) {
      for (a a : list) {
        String str1 = a(a.a(), paramLong1, paramLong2, paramList, paramBoolean, paramInt);
        String str2 = a(a.b(), paramLong1, paramLong2, paramList, paramBoolean, paramInt);
        if (StringUtils.isValidString(str1)) {
          a(new a(str1, str2));
          continue;
        } 
        y y3 = this.b;
        if (y.a()) {
          y3 = this.b;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to parse url: ");
          stringBuilder.append(a.a());
          y3.e("AppLovinAdService", stringBuilder.toString());
        } 
      } 
    } else {
      y y3 = this.b;
      if (y.a()) {
        y3 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to track ad closed for AD #");
        stringBuilder.append(y1.getAdIdNumber());
        stringBuilder.append(". Missing ad close tracking URL.");
        stringBuilder.append(y1.getAdIdNumber());
        y3.d("AppLovinAdService", stringBuilder.toString());
      } 
    } 
  }
  
  public void trackImpression(e parame) {
    y y1;
    if (parame == null) {
      y1 = this.b;
      if (y.a())
        this.b.e("AppLovinAdService", "Unable to track impression click. No ad specified"); 
      return;
    } 
    y y2 = this.b;
    if (y.a())
      this.b.b("AppLovinAdService", "Tracking impression on ad..."); 
    maybeSubmitPersistentPostbacks(y1.at());
  }
  
  public void trackVideoEnd(e parame, long paramLong, int paramInt, boolean paramBoolean) {
    y y1;
    String str;
    if (parame == null) {
      y1 = this.b;
      if (y.a())
        this.b.e("AppLovinAdService", "Unable to track video end. No ad specified"); 
      return;
    } 
    y y2 = this.b;
    if (y.a())
      this.b.b("AppLovinAdService", "Tracking video end on ad..."); 
    List list = y1.aq();
    if (list != null && !list.isEmpty()) {
      str = Long.toString(System.currentTimeMillis());
      for (a a : list) {
        if (StringUtils.isValidString(a.a())) {
          String str1 = a(a.a(), paramLong, paramInt, str, paramBoolean);
          String str2 = a(a.b(), paramLong, paramInt, str, paramBoolean);
          if (str1 != null) {
            a(new a(str1, str2));
            continue;
          } 
          y y4 = this.b;
          if (y.a()) {
            y4 = this.b;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to parse url: ");
            stringBuilder.append(a.a());
            y4.e("AppLovinAdService", stringBuilder.toString());
          } 
          continue;
        } 
        y y3 = this.b;
        if (y.a())
          this.b.d("AppLovinAdService", "Requested a postback dispatch for an empty video end URL; nothing to do..."); 
      } 
    } else {
      y y3 = this.b;
      if (y.a()) {
        y3 = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to submit persistent postback for AD #");
        stringBuilder.append(str.getAdIdNumber());
        stringBuilder.append(". Missing video end tracking URL.");
        y3.d("AppLovinAdService", stringBuilder.toString());
      } 
    } 
  }
  
  private class a implements i {
    private final AppLovinAdServiceImpl.b b;
    
    private a(AppLovinAdServiceImpl this$0, AppLovinAdServiceImpl.b param1b) {
      this.b = param1b;
    }
    
    public void adReceived(AppLovinAd param1AppLovinAd) {
      AppLovinAdImpl appLovinAdImpl = (AppLovinAdImpl)param1AppLovinAd;
      d d = appLovinAdImpl.getAdZone();
      AppLovinAd appLovinAd = param1AppLovinAd;
      if (!(param1AppLovinAd instanceof f)) {
        AppLovinAdServiceImpl.a(this.a).U().a(appLovinAdImpl);
        null = new f(d, AppLovinAdServiceImpl.a(this.a));
      } 
      synchronized (this.b.a) {
        HashSet<AppLovinAdLoadListener> hashSet = new HashSet<AppLovinAdLoadListener>(this.b.c);
        this.b.c.clear();
        this.b.b = false;
        for (AppLovinAdLoadListener appLovinAdLoadListener : hashSet)
          AppLovinAdServiceImpl.a(this.a, (AppLovinAd)null, appLovinAdLoadListener); 
        return;
      } 
    }
    
    public void failedToReceiveAd(int param1Int) {
      synchronized (this.b.a) {
        HashSet<AppLovinAdLoadListener> hashSet = new HashSet<AppLovinAdLoadListener>(this.b.c);
        this.b.c.clear();
        this.b.b = false;
        for (AppLovinAdLoadListener appLovinAdLoadListener : hashSet)
          AppLovinAdServiceImpl.a(this.a, param1Int, appLovinAdLoadListener); 
        return;
      } 
    }
    
    public void failedToReceiveAdV2(AppLovinError param1AppLovinError) {
      synchronized (this.b.a) {
        HashSet<AppLovinAdLoadListener> hashSet = new HashSet<AppLovinAdLoadListener>(this.b.c);
        this.b.c.clear();
        this.b.b = false;
        for (AppLovinAdLoadListener appLovinAdLoadListener : hashSet) {
          if (appLovinAdLoadListener instanceof i) {
            AppLovinAdServiceImpl.a(this.a, param1AppLovinError, appLovinAdLoadListener);
            continue;
          } 
          AppLovinAdServiceImpl.a(this.a, param1AppLovinError.getCode(), appLovinAdLoadListener);
        } 
        return;
      } 
    }
  }
  
  private static class b {
    final Object a = new Object();
    
    boolean b;
    
    final Collection<AppLovinAdLoadListener> c = new HashSet<AppLovinAdLoadListener>();
    
    private b() {}
    
    @NonNull
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AdLoadState{, isWaitingForAd=");
      stringBuilder.append(this.b);
      stringBuilder.append(", pendingAdListeners=");
      stringBuilder.append(this.c);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\AppLovinAdServiceImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */