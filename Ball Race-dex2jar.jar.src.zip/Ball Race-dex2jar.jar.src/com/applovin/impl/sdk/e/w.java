package com.applovin.impl.sdk.e;

import com.applovin.impl.sdk.b.c;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.network.b;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.utils.JsonUtils;
import com.applovin.impl.sdk.y;
import java.util.Map;
import org.json.JSONObject;

public abstract class w extends y {
  protected w(String paramString, p paramp) {
    super(paramString, paramp);
  }
  
  private JSONObject a(c paramc) {
    JSONObject jSONObject = i();
    JsonUtils.putString(jSONObject, "result", paramc.b());
    Map map = paramc.a();
    if (map != null)
      JsonUtils.putJSONObject(jSONObject, "params", new JSONObject(map)); 
    return jSONObject;
  }
  
  protected abstract c b();
  
  protected abstract void b(JSONObject paramJSONObject);
  
  protected abstract void c();
  
  protected int h() {
    return ((Integer)this.f.a(b.bJ)).intValue();
  }
  
  public void run() {
    c c = b();
    if (c != null) {
      y y2 = this.h;
      if (y.a()) {
        y2 = this.h;
        String str = this.g;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Reporting pending reward: ");
        stringBuilder.append(c);
        stringBuilder.append("...");
        y2.b(str, stringBuilder.toString());
      } 
      a(a(c), new b.c<JSONObject>(this) {
            public void a(int param1Int, String param1String, JSONObject param1JSONObject) {
              this.a.a(param1Int);
            }
            
            public void a(JSONObject param1JSONObject, int param1Int) {
              this.a.b(param1JSONObject);
            }
          });
      return;
    } 
    y y1 = this.h;
    if (y.a())
      this.h.e(this.g, "Pending reward not found"); 
    c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\e\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */