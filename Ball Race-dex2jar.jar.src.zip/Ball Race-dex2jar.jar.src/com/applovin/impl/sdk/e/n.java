package com.applovin.impl.sdk.e;

import android.app.Activity;
import com.applovin.impl.b.a;
import com.applovin.impl.b.a.b;
import com.applovin.impl.sdk.af;
import com.applovin.impl.sdk.c.b;
import com.applovin.impl.sdk.g;
import com.applovin.impl.sdk.p;
import com.applovin.impl.sdk.r;
import com.applovin.impl.sdk.utils.Utils;
import com.applovin.impl.sdk.utils.l;
import com.applovin.impl.sdk.utils.q;
import com.applovin.impl.sdk.y;
import com.applovin.sdk.AppLovinSdk;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class n extends a {
  private final p a;
  
  public n(p paramp) {
    super("TaskInitializeSdk", paramp);
    this.a = paramp;
  }
  
  private void a() {
    if (this.a.ao().a())
      return; 
    Activity activity = this.a.x();
    if (activity != null) {
      this.a.ao().a(activity);
      return;
    } 
    this.a.M().a((a)new z(this.a, true, new Runnable(this) {
            public void run() {
              n.a(this.a).ao().a(n.a(this.a).w().a());
            }
          }), o.a.a, TimeUnit.SECONDS.toMillis(1L));
  }
  
  private void b() {
    if (!this.a.e()) {
      Map map1;
      Map map2;
      boolean bool = this.a.N().d();
      r r = this.a.S();
      String str = "<Enable verbose logging to see the GAID to use for test devices - https://monetization-support.applovin.com/hc/en-us/articles/236114328-How-can-I-expose-verbose-logging-for-the-SDK>";
      if (r != null) {
        if (bool) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(this.a.Q().d().b());
          stringBuilder.append(" (use this for test devices)");
          String str1 = stringBuilder.toString();
        } 
        map1 = this.a.S().b();
        map2 = this.a.S().g();
      } else {
        if (bool) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(this.a.R().k().b());
          stringBuilder.append(" (use this for test devices)");
          str = stringBuilder.toString();
        } 
        map1 = this.a.R().d();
        map2 = this.a.R().c();
      } 
      l l = new l();
      l.a().a("=====AppLovin SDK=====");
      l.a("===SDK Versions===").a("Version", AppLovinSdk.VERSION).a("Plugin Version", this.a.a(b.dU)).a("Ad Review Version", g.a()).a("OM SDK Version", this.a.ag().c());
      l.a("===Device Info===").a("OS", Utils.getAndroidOSInfo()).a("GAID", str).a("Model", map1.get("model")).a("Locale", map1.get("locale")).a("Emulator", map1.get("sim")).a("Tablet", map1.get("is_tablet"));
      l.a("===App Info===").a("Application ID", map2.get("package_name")).a("Target SDK", map2.get("target_sdk")).a("ExoPlayer Version", Integer.valueOf(Utils.getExoPlayerVersionCode()));
      l.a("===SDK Settings===").a("SDK Key", this.a.B()).a("Mediation Provider", this.a.s()).a("TG", q.a(this.a)).a("AEI", this.a.a(b.ax)).a("MEI", this.a.a(b.ay)).a("Test Mode On", Boolean.valueOf(this.a.av().a())).a("Verbose Logging On", Boolean.valueOf(bool));
      l.a("===Privacy States===\nPlease review AppLovin MAX documentation to be compliant with regional privacy policies.").a(a.a(f()));
      b b = this.a.ae();
      l.a("===Max Terms Flow===").a("Enabled", Boolean.valueOf(b.b())).a("Privacy Policy URI", b.d()).a("Terms of Service URI", b.e());
      l.a();
      y.f("AppLovinSdk", l.toString());
    } 
  }
  
  public void run() {
    // Byte code:
    //   0: ldc_w 'succeeded'
    //   3: astore #8
    //   5: invokestatic currentTimeMillis : ()J
    //   8: lstore_1
    //   9: aload_0
    //   10: getfield h : Lcom/applovin/impl/sdk/y;
    //   13: astore #5
    //   15: invokestatic a : ()Z
    //   18: ifeq -> 81
    //   21: aload_0
    //   22: getfield h : Lcom/applovin/impl/sdk/y;
    //   25: astore #5
    //   27: aload_0
    //   28: getfield g : Ljava/lang/String;
    //   31: astore #6
    //   33: new java/lang/StringBuilder
    //   36: dup
    //   37: invokespecial <init> : ()V
    //   40: astore #7
    //   42: aload #7
    //   44: ldc_w 'Initializing AppLovin SDK v'
    //   47: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: pop
    //   51: aload #7
    //   53: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: aload #7
    //   62: ldc_w '...'
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: pop
    //   69: aload #5
    //   71: aload #6
    //   73: aload #7
    //   75: invokevirtual toString : ()Ljava/lang/String;
    //   78: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   81: aload_0
    //   82: getfield a : Lcom/applovin/impl/sdk/p;
    //   85: invokevirtual P : ()Lcom/applovin/impl/sdk/d/g;
    //   88: invokevirtual d : ()V
    //   91: aload_0
    //   92: getfield a : Lcom/applovin/impl/sdk/p;
    //   95: invokevirtual P : ()Lcom/applovin/impl/sdk/d/g;
    //   98: getstatic com/applovin/impl/sdk/d/f.e : Lcom/applovin/impl/sdk/d/f;
    //   101: invokevirtual c : (Lcom/applovin/impl/sdk/d/f;)V
    //   104: aload_0
    //   105: getfield a : Lcom/applovin/impl/sdk/p;
    //   108: invokevirtual P : ()Lcom/applovin/impl/sdk/d/g;
    //   111: getstatic com/applovin/impl/sdk/d/f.f : Lcom/applovin/impl/sdk/d/f;
    //   114: invokevirtual c : (Lcom/applovin/impl/sdk/d/f;)V
    //   117: aload_0
    //   118: getfield a : Lcom/applovin/impl/sdk/p;
    //   121: invokevirtual W : ()Lcom/applovin/impl/sdk/v;
    //   124: aload_0
    //   125: invokevirtual f : ()Landroid/content/Context;
    //   128: invokevirtual a : (Landroid/content/Context;)V
    //   131: aload_0
    //   132: getfield a : Lcom/applovin/impl/sdk/p;
    //   135: invokevirtual W : ()Lcom/applovin/impl/sdk/v;
    //   138: aload_0
    //   139: invokevirtual f : ()Landroid/content/Context;
    //   142: invokevirtual b : (Landroid/content/Context;)V
    //   145: aload_0
    //   146: getfield a : Lcom/applovin/impl/sdk/p;
    //   149: invokevirtual M : ()Lcom/applovin/impl/sdk/e/o;
    //   152: new com/applovin/impl/sdk/e/b
    //   155: dup
    //   156: aload_0
    //   157: getfield a : Lcom/applovin/impl/sdk/p;
    //   160: invokespecial <init> : (Lcom/applovin/impl/sdk/p;)V
    //   163: getstatic com/applovin/impl/sdk/e/o$a.a : Lcom/applovin/impl/sdk/e/o$a;
    //   166: invokevirtual a : (Lcom/applovin/impl/sdk/e/a;Lcom/applovin/impl/sdk/e/o$a;)V
    //   169: aload_0
    //   170: getfield a : Lcom/applovin/impl/sdk/p;
    //   173: invokevirtual S : ()Lcom/applovin/impl/sdk/r;
    //   176: ifnull -> 192
    //   179: aload_0
    //   180: getfield a : Lcom/applovin/impl/sdk/p;
    //   183: invokevirtual S : ()Lcom/applovin/impl/sdk/r;
    //   186: invokevirtual c : ()V
    //   189: goto -> 202
    //   192: aload_0
    //   193: getfield a : Lcom/applovin/impl/sdk/p;
    //   196: invokevirtual R : ()Lcom/applovin/impl/sdk/q;
    //   199: invokevirtual e : ()V
    //   202: aload_0
    //   203: getfield a : Lcom/applovin/impl/sdk/p;
    //   206: invokevirtual ac : ()Lcom/applovin/impl/sdk/utils/o;
    //   209: invokevirtual a : ()V
    //   212: aload_0
    //   213: getfield a : Lcom/applovin/impl/sdk/p;
    //   216: invokevirtual af : ()Lcom/applovin/impl/a/a/a;
    //   219: invokevirtual a : ()V
    //   222: aload_0
    //   223: invokevirtual f : ()Landroid/content/Context;
    //   226: aload_0
    //   227: getfield a : Lcom/applovin/impl/sdk/p;
    //   230: invokestatic isPubInDebugMode : (Landroid/content/Context;Lcom/applovin/impl/sdk/p;)Z
    //   233: ifeq -> 243
    //   236: aload_0
    //   237: getfield a : Lcom/applovin/impl/sdk/p;
    //   240: invokevirtual i : ()V
    //   243: aload_0
    //   244: getfield a : Lcom/applovin/impl/sdk/p;
    //   247: invokevirtual ai : ()Lcom/applovin/impl/sdk/array/ArrayService;
    //   250: invokevirtual collectAppHubData : ()V
    //   253: aload_0
    //   254: invokespecial b : ()V
    //   257: aload_0
    //   258: getfield a : Lcom/applovin/impl/sdk/p;
    //   261: getstatic com/applovin/impl/sdk/c/b.ep : Lcom/applovin/impl/sdk/c/b;
    //   264: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   267: checkcast java/lang/Boolean
    //   270: invokevirtual booleanValue : ()Z
    //   273: ifeq -> 287
    //   276: new com/applovin/impl/sdk/e/n$1
    //   279: dup
    //   280: aload_0
    //   281: invokespecial <init> : (Lcom/applovin/impl/sdk/e/n;)V
    //   284: invokestatic runOnUiThread : (Ljava/lang/Runnable;)V
    //   287: aload_0
    //   288: invokespecial a : ()V
    //   291: aload_0
    //   292: getfield a : Lcom/applovin/impl/sdk/p;
    //   295: iconst_1
    //   296: invokevirtual a : (Z)V
    //   299: aload_0
    //   300: getfield a : Lcom/applovin/impl/sdk/p;
    //   303: invokevirtual al : ()Lcom/applovin/impl/sdk/network/k;
    //   306: invokeinterface c : ()V
    //   311: aload_0
    //   312: getfield a : Lcom/applovin/impl/sdk/p;
    //   315: invokevirtual G : ()Lcom/applovin/impl/sdk/EventServiceImpl;
    //   318: invokevirtual maybeTrackAppOpenEvent : ()V
    //   321: aload_0
    //   322: getfield a : Lcom/applovin/impl/sdk/p;
    //   325: invokevirtual as : ()Lcom/applovin/impl/mediation/debugger/b;
    //   328: invokevirtual b : ()Z
    //   331: ifeq -> 344
    //   334: aload_0
    //   335: getfield a : Lcom/applovin/impl/sdk/p;
    //   338: invokevirtual e : ()Z
    //   341: ifeq -> 392
    //   344: aload_0
    //   345: getfield a : Lcom/applovin/impl/sdk/p;
    //   348: getstatic com/applovin/impl/sdk/c/a.h : Lcom/applovin/impl/sdk/c/b;
    //   351: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   354: checkcast java/lang/Boolean
    //   357: invokevirtual booleanValue : ()Z
    //   360: ifeq -> 402
    //   363: aload_0
    //   364: getfield a : Lcom/applovin/impl/sdk/p;
    //   367: astore #5
    //   369: invokestatic y : ()Landroid/content/Context;
    //   372: aload_0
    //   373: getfield a : Lcom/applovin/impl/sdk/p;
    //   376: invokestatic isPubInDebugMode : (Landroid/content/Context;Lcom/applovin/impl/sdk/p;)Z
    //   379: ifeq -> 402
    //   382: aload_0
    //   383: getfield a : Lcom/applovin/impl/sdk/p;
    //   386: invokevirtual f : ()Z
    //   389: ifeq -> 402
    //   392: aload_0
    //   393: getfield a : Lcom/applovin/impl/sdk/p;
    //   396: invokevirtual as : ()Lcom/applovin/impl/mediation/debugger/b;
    //   399: invokevirtual a : ()V
    //   402: aload_0
    //   403: getfield a : Lcom/applovin/impl/sdk/p;
    //   406: invokevirtual ag : ()Lcom/applovin/impl/sdk/a/f;
    //   409: invokevirtual a : ()V
    //   412: aload_0
    //   413: getfield a : Lcom/applovin/impl/sdk/p;
    //   416: getstatic com/applovin/impl/sdk/c/b.aM : Lcom/applovin/impl/sdk/c/b;
    //   419: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   422: checkcast java/lang/Boolean
    //   425: invokevirtual booleanValue : ()Z
    //   428: ifeq -> 456
    //   431: aload_0
    //   432: getfield a : Lcom/applovin/impl/sdk/p;
    //   435: getstatic com/applovin/impl/sdk/c/b.aN : Lcom/applovin/impl/sdk/c/b;
    //   438: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   441: checkcast java/lang/Long
    //   444: invokevirtual longValue : ()J
    //   447: lstore_3
    //   448: aload_0
    //   449: getfield a : Lcom/applovin/impl/sdk/p;
    //   452: lload_3
    //   453: invokevirtual a : (J)V
    //   456: aload_0
    //   457: getfield h : Lcom/applovin/impl/sdk/y;
    //   460: astore #5
    //   462: invokestatic a : ()Z
    //   465: ifeq -> 784
    //   468: aload_0
    //   469: getfield h : Lcom/applovin/impl/sdk/y;
    //   472: astore #11
    //   474: aload_0
    //   475: getfield g : Ljava/lang/String;
    //   478: astore #10
    //   480: new java/lang/StringBuilder
    //   483: dup
    //   484: invokespecial <init> : ()V
    //   487: astore #9
    //   489: aload #9
    //   491: ldc_w 'AppLovin SDK '
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: aload #9
    //   500: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   506: pop
    //   507: aload #9
    //   509: ldc_w ' initialization '
    //   512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   515: pop
    //   516: aload #11
    //   518: astore #5
    //   520: aload #10
    //   522: astore #6
    //   524: aload #9
    //   526: astore #7
    //   528: aload_0
    //   529: getfield a : Lcom/applovin/impl/sdk/p;
    //   532: invokevirtual d : ()Z
    //   535: ifeq -> 730
    //   538: aload #11
    //   540: astore #5
    //   542: aload #10
    //   544: astore #6
    //   546: aload #9
    //   548: astore #7
    //   550: goto -> 735
    //   553: astore #5
    //   555: goto -> 785
    //   558: astore #5
    //   560: ldc_w 'AppLovinSdk'
    //   563: ldc_w 'Failed to initialize SDK!'
    //   566: aload #5
    //   568: invokestatic c : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   571: aload_0
    //   572: getfield a : Lcom/applovin/impl/sdk/p;
    //   575: iconst_0
    //   576: invokevirtual a : (Z)V
    //   579: aload_0
    //   580: getfield a : Lcom/applovin/impl/sdk/p;
    //   583: invokevirtual ag : ()Lcom/applovin/impl/sdk/a/f;
    //   586: invokevirtual a : ()V
    //   589: aload_0
    //   590: getfield a : Lcom/applovin/impl/sdk/p;
    //   593: getstatic com/applovin/impl/sdk/c/b.aM : Lcom/applovin/impl/sdk/c/b;
    //   596: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   599: checkcast java/lang/Boolean
    //   602: invokevirtual booleanValue : ()Z
    //   605: ifeq -> 633
    //   608: aload_0
    //   609: getfield a : Lcom/applovin/impl/sdk/p;
    //   612: getstatic com/applovin/impl/sdk/c/b.aN : Lcom/applovin/impl/sdk/c/b;
    //   615: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   618: checkcast java/lang/Long
    //   621: invokevirtual longValue : ()J
    //   624: lstore_3
    //   625: aload_0
    //   626: getfield a : Lcom/applovin/impl/sdk/p;
    //   629: lload_3
    //   630: invokevirtual a : (J)V
    //   633: aload_0
    //   634: getfield h : Lcom/applovin/impl/sdk/y;
    //   637: astore #5
    //   639: invokestatic a : ()Z
    //   642: ifeq -> 784
    //   645: aload_0
    //   646: getfield h : Lcom/applovin/impl/sdk/y;
    //   649: astore #11
    //   651: aload_0
    //   652: getfield g : Ljava/lang/String;
    //   655: astore #10
    //   657: new java/lang/StringBuilder
    //   660: dup
    //   661: invokespecial <init> : ()V
    //   664: astore #9
    //   666: aload #9
    //   668: ldc_w 'AppLovin SDK '
    //   671: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   674: pop
    //   675: aload #9
    //   677: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   680: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   683: pop
    //   684: aload #9
    //   686: ldc_w ' initialization '
    //   689: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   692: pop
    //   693: aload #11
    //   695: astore #5
    //   697: aload #10
    //   699: astore #6
    //   701: aload #9
    //   703: astore #7
    //   705: aload_0
    //   706: getfield a : Lcom/applovin/impl/sdk/p;
    //   709: invokevirtual d : ()Z
    //   712: ifeq -> 730
    //   715: aload #11
    //   717: astore #5
    //   719: aload #10
    //   721: astore #6
    //   723: aload #9
    //   725: astore #7
    //   727: goto -> 735
    //   730: ldc_w 'failed'
    //   733: astore #8
    //   735: aload #7
    //   737: aload #8
    //   739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   742: pop
    //   743: aload #7
    //   745: ldc_w ' in '
    //   748: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   751: pop
    //   752: aload #7
    //   754: invokestatic currentTimeMillis : ()J
    //   757: lload_1
    //   758: lsub
    //   759: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   762: pop
    //   763: aload #7
    //   765: ldc_w 'ms'
    //   768: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   771: pop
    //   772: aload #5
    //   774: aload #6
    //   776: aload #7
    //   778: invokevirtual toString : ()Ljava/lang/String;
    //   781: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   784: return
    //   785: aload_0
    //   786: getfield a : Lcom/applovin/impl/sdk/p;
    //   789: invokevirtual ag : ()Lcom/applovin/impl/sdk/a/f;
    //   792: invokevirtual a : ()V
    //   795: aload_0
    //   796: getfield a : Lcom/applovin/impl/sdk/p;
    //   799: getstatic com/applovin/impl/sdk/c/b.aM : Lcom/applovin/impl/sdk/c/b;
    //   802: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   805: checkcast java/lang/Boolean
    //   808: invokevirtual booleanValue : ()Z
    //   811: ifeq -> 839
    //   814: aload_0
    //   815: getfield a : Lcom/applovin/impl/sdk/p;
    //   818: getstatic com/applovin/impl/sdk/c/b.aN : Lcom/applovin/impl/sdk/c/b;
    //   821: invokevirtual a : (Lcom/applovin/impl/sdk/c/b;)Ljava/lang/Object;
    //   824: checkcast java/lang/Long
    //   827: invokevirtual longValue : ()J
    //   830: lstore_3
    //   831: aload_0
    //   832: getfield a : Lcom/applovin/impl/sdk/p;
    //   835: lload_3
    //   836: invokevirtual a : (J)V
    //   839: aload_0
    //   840: getfield h : Lcom/applovin/impl/sdk/y;
    //   843: astore #6
    //   845: invokestatic a : ()Z
    //   848: ifeq -> 966
    //   851: aload_0
    //   852: getfield h : Lcom/applovin/impl/sdk/y;
    //   855: astore #6
    //   857: aload_0
    //   858: getfield g : Ljava/lang/String;
    //   861: astore #7
    //   863: new java/lang/StringBuilder
    //   866: dup
    //   867: invokespecial <init> : ()V
    //   870: astore #9
    //   872: aload #9
    //   874: ldc_w 'AppLovin SDK '
    //   877: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   880: pop
    //   881: aload #9
    //   883: getstatic com/applovin/sdk/AppLovinSdk.VERSION : Ljava/lang/String;
    //   886: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   889: pop
    //   890: aload #9
    //   892: ldc_w ' initialization '
    //   895: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   898: pop
    //   899: aload_0
    //   900: getfield a : Lcom/applovin/impl/sdk/p;
    //   903: invokevirtual d : ()Z
    //   906: ifeq -> 912
    //   909: goto -> 917
    //   912: ldc_w 'failed'
    //   915: astore #8
    //   917: aload #9
    //   919: aload #8
    //   921: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   924: pop
    //   925: aload #9
    //   927: ldc_w ' in '
    //   930: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   933: pop
    //   934: aload #9
    //   936: invokestatic currentTimeMillis : ()J
    //   939: lload_1
    //   940: lsub
    //   941: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   944: pop
    //   945: aload #9
    //   947: ldc_w 'ms'
    //   950: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   953: pop
    //   954: aload #6
    //   956: aload #7
    //   958: aload #9
    //   960: invokevirtual toString : ()Ljava/lang/String;
    //   963: invokevirtual b : (Ljava/lang/String;Ljava/lang/String;)V
    //   966: aload #5
    //   968: athrow
    // Exception table:
    //   from	to	target	type
    //   81	189	558	java/lang/Throwable
    //   81	189	553	finally
    //   192	202	558	java/lang/Throwable
    //   192	202	553	finally
    //   202	243	558	java/lang/Throwable
    //   202	243	553	finally
    //   243	287	558	java/lang/Throwable
    //   243	287	553	finally
    //   287	344	558	java/lang/Throwable
    //   287	344	553	finally
    //   344	392	558	java/lang/Throwable
    //   344	392	553	finally
    //   392	402	558	java/lang/Throwable
    //   392	402	553	finally
    //   560	579	553	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\applovin\impl\sdk\e\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */