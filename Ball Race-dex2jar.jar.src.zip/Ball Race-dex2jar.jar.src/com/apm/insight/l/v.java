package com.apm.insight.l;

import android.os.Build;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.apm.insight.nativecrash.NativeImpl;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public final class v {
  private static final StackTraceElement a = new StackTraceElement("", "", "", 0);
  
  public static String a(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return null; 
    File file = new File(paramString);
    if (!file.exists())
      return null; 
    LinkedList<String> linkedList2 = new LinkedList();
    LinkedList<String> linkedList1 = new LinkedList();
    StringBuilder stringBuilder = new StringBuilder();
    int j = 0;
    int i = 0;
    try {
      int k;
      BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
    } catch (Throwable throwable) {
    
    } finally {
      file = null;
      k.a((Closeable)file);
    } 
    k.a((Closeable)SYNTHETIC_LOCAL_VARIABLE_4);
    if (!linkedList1.isEmpty()) {
      if (j != 0) {
        stringBuilder.append("\t... skip ");
        stringBuilder.append(j);
        stringBuilder.append(" lines\n");
      } 
      Iterator<String> iterator = linkedList1.iterator();
      while (iterator.hasNext()) {
        stringBuilder.append(iterator.next());
        stringBuilder.append('\n');
      } 
    } 
    return stringBuilder.toString();
  }
  
  @NonNull
  public static String a(@NonNull Throwable paramThrowable) {
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    try {
      a(paramThrowable, printWriter);
      return stringWriter.toString();
    } catch (Throwable throwable) {
      return "";
    } finally {
      printWriter.close();
    } 
  }
  
  @NonNull
  public static String a(@NonNull Throwable paramThrowable, Thread paramThread, PrintStream paramPrintStream, e.a parama) {
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
    } catch (Throwable throwable) {
      throwable = null;
    } 
    e e = new e(paramPrintStream, (MessageDigest)throwable, parama);
    try {
    
    } catch (Throwable throwable1) {
    
    } finally {
      e.close();
    } 
    e.close();
    return (throwable != null) ? a(throwable.digest()) : null;
  }
  
  private static String a(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length <= 0)
      return ""; 
    char[] arrayOfChar1 = new char[16];
    arrayOfChar1[0] = '0';
    arrayOfChar1[1] = '1';
    arrayOfChar1[2] = '2';
    arrayOfChar1[3] = '3';
    arrayOfChar1[4] = '4';
    arrayOfChar1[5] = '5';
    arrayOfChar1[6] = '6';
    arrayOfChar1[7] = '7';
    arrayOfChar1[8] = '8';
    arrayOfChar1[9] = '9';
    arrayOfChar1[10] = 'a';
    arrayOfChar1[11] = 'b';
    arrayOfChar1[12] = 'c';
    arrayOfChar1[13] = 'd';
    arrayOfChar1[14] = 'e';
    arrayOfChar1[15] = 'f';
    char[] arrayOfChar2 = new char[paramArrayOfbyte.length * 2];
    int k = paramArrayOfbyte.length;
    int i = 0;
    int j = 0;
    while (i < k) {
      byte b = paramArrayOfbyte[i];
      int m = j + 1;
      arrayOfChar2[j] = arrayOfChar1[b >>> 4 & 0xF];
      j = m + 1;
      arrayOfChar2[m] = arrayOfChar1[b & 0xF];
      i++;
    } 
    return new String(arrayOfChar2);
  }
  
  public static String a(StackTraceElement[] paramArrayOfStackTraceElement) {
    StringBuilder stringBuilder = new StringBuilder();
    int j = paramArrayOfStackTraceElement.length;
    for (int i = 0; i < j; i++)
      a(paramArrayOfStackTraceElement[i], stringBuilder); 
    return stringBuilder.toString();
  }
  
  public static StringBuilder a(StackTraceElement paramStackTraceElement, StringBuilder paramStringBuilder) {
    String str = paramStackTraceElement.getClassName();
    paramStringBuilder.append("  at ");
    paramStringBuilder.append(str);
    paramStringBuilder.append(".");
    paramStringBuilder.append(paramStackTraceElement.getMethodName());
    paramStringBuilder.append("(");
    paramStringBuilder.append(paramStackTraceElement.getFileName());
    paramStringBuilder.append(":");
    paramStringBuilder.append(paramStackTraceElement.getLineNumber());
    paramStringBuilder.append(")\n");
    return paramStringBuilder;
  }
  
  public static JSONArray a(StackTraceElement[] paramArrayOfStackTraceElement, String[] paramArrayOfString) {
    a a = new a(-1, -1);
    JSONArray jSONArray = new JSONArray();
    int i = 0;
    while (i < paramArrayOfStackTraceElement.length) {
      a a1;
      if (a.a == -1) {
        a1 = a;
        if (a(paramArrayOfStackTraceElement[i].getClassName(), paramArrayOfString)) {
          a.a = i;
          a.b = i;
          a1 = a;
        } 
      } else {
        a1 = a;
        if (!a(paramArrayOfStackTraceElement[i].getClassName(), paramArrayOfString)) {
          a.b = i;
          jSONArray.put(a.a());
          a1 = new a(-1, -1);
        } 
      } 
      i++;
      a = a1;
    } 
    if (a.a != -1) {
      a.b = paramArrayOfStackTraceElement.length;
      jSONArray.put(a.a());
    } 
    return jSONArray;
  }
  
  public static JSONArray a(String[] paramArrayOfString1, String[] paramArrayOfString2) {
    a a = new a(-1, -1);
    JSONArray jSONArray = new JSONArray();
    int i = 0;
    while (i < paramArrayOfString1.length) {
      a a1;
      if (a.a == -1) {
        a1 = a;
        if (a(paramArrayOfString1[i], paramArrayOfString2)) {
          a.a = i;
          a.b = i;
          a1 = a;
        } 
      } else {
        a1 = a;
        if (!a(paramArrayOfString1[i], paramArrayOfString2)) {
          a.b = i;
          jSONArray.put(a.a());
          a1 = new a(-1, -1);
        } 
      } 
      i++;
      a = a1;
    } 
    if (a.a != -1) {
      a.b = paramArrayOfString1.length;
      jSONArray.put(a.a());
    } 
    return jSONArray;
  }
  
  private static void a(StackTraceElement paramStackTraceElement, int paramInt) {
    try {
      String str;
      a("\tat ", paramInt);
      a(paramStackTraceElement.getClassName(), paramInt);
      a(".", paramInt);
      a(paramStackTraceElement.getMethodName(), paramInt);
      if (paramStackTraceElement.isNativeMethod()) {
        str = "(Native Method)";
      } else {
        String str1 = str.getFileName();
        if (str1 != null) {
          int i = str.getLineNumber();
          if (i >= 0) {
            a("(", paramInt);
            a(str.getFileName(), paramInt);
            a(":", paramInt);
            str = String.valueOf(str.getLineNumber());
          } else {
            a("(", paramInt);
            str = str.getFileName();
          } 
        } else if (str.getLineNumber() >= 0) {
          a("(Unknown Source:", paramInt);
          str = String.valueOf(str.getLineNumber());
        } else {
          str = "(Unknown Source)";
          a(str, paramInt);
        } 
        a(str, paramInt);
        a(")", paramInt);
        a("\n", paramInt);
      } 
      a(str, paramInt);
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  private static void a(String paramString, int paramInt) {
    NativeImpl.a(paramInt, paramString);
  }
  
  public static void a(@NonNull Throwable paramThrowable, int paramInt) {
    try {
      c(paramThrowable, paramInt);
      return;
    } catch (Throwable throwable) {
      return;
    } finally {}
  }
  
  private static void a(Throwable paramThrowable, int paramInt, String paramString1, String paramString2) {
    StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
    try {
      NativeImpl.a(paramInt, paramString2);
      NativeImpl.a(paramInt, paramString1);
    } catch (Throwable throwable) {}
    b(paramThrowable, paramInt);
    int j = arrayOfStackTraceElement.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++)
      a(arrayOfStackTraceElement[i], paramInt); 
    if (Build.VERSION.SDK_INT >= 19) {
      Throwable[] arrayOfThrowable = paramThrowable.getSuppressed();
      j = arrayOfThrowable.length;
      for (i = bool; i < j; i++) {
        Throwable throwable = arrayOfThrowable[i];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString2);
        stringBuilder.append("\t");
        a(throwable, paramInt, "Suppressed: ", stringBuilder.toString());
      } 
    } 
    paramThrowable = paramThrowable.getCause();
    if (paramThrowable != null)
      a(paramThrowable, paramInt, "Caused by: ", paramString2); 
  }
  
  private static void a(Throwable paramThrowable, PrintWriter paramPrintWriter) {
    if (paramThrowable != null) {
      int i;
      if (paramPrintWriter == null)
        return; 
      Set<?> set = Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>());
      set.add(paramThrowable);
      paramPrintWriter.println(paramThrowable);
      StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
      if (arrayOfStackTraceElement.length > 384) {
        i = 1;
      } else {
        i = 0;
      } 
      int m = arrayOfStackTraceElement.length;
      int j = 0;
      int k = 0;
      while (j < m) {
        StringBuilder stringBuilder1;
        StackTraceElement stackTraceElement = arrayOfStackTraceElement[j];
        if (i && k > 256) {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("\t... skip ");
          stringBuilder1.append(arrayOfStackTraceElement.length - k - 128);
          stringBuilder1.append(" lines");
          paramPrintWriter.println(stringBuilder1.toString());
          break;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("\tat ");
        stringBuilder2.append(stringBuilder1);
        paramPrintWriter.println(stringBuilder2.toString());
        k++;
        j++;
      } 
      if (i)
        for (i = arrayOfStackTraceElement.length - 128; i < arrayOfStackTraceElement.length; i++) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("\tat ");
          stringBuilder.append(arrayOfStackTraceElement[i]);
          paramPrintWriter.println(stringBuilder.toString());
        }  
      if (Build.VERSION.SDK_INT >= 19) {
        Throwable[] arrayOfThrowable = paramThrowable.getSuppressed();
        j = arrayOfThrowable.length;
        for (i = 0; i < j; i++)
          a(arrayOfThrowable[i], paramPrintWriter, arrayOfStackTraceElement, "Suppressed: ", "\t", (Set)set, 128); 
      } 
      paramThrowable = paramThrowable.getCause();
      if (paramThrowable != null)
        a(paramThrowable, paramPrintWriter, arrayOfStackTraceElement, "Caused by: ", "", (Set)set, 128); 
    } 
  }
  
  private static void a(Throwable paramThrowable, PrintWriter paramPrintWriter, StackTraceElement[] paramArrayOfStackTraceElement, String paramString1, String paramString2, Set<Throwable> paramSet, int paramInt) {
    int i;
    if (paramSet.contains(paramThrowable)) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("\t[CIRCULAR REFERENCE:");
      stringBuilder1.append(paramThrowable);
      stringBuilder1.append("]");
      paramPrintWriter.println(stringBuilder1.toString());
      return;
    } 
    paramSet.add(paramThrowable);
    paramArrayOfStackTraceElement = paramThrowable.getStackTrace();
    if (paramArrayOfStackTraceElement.length > paramInt) {
      i = 1;
    } else {
      i = 0;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString2);
    stringBuilder.append(paramString1);
    stringBuilder.append(paramThrowable);
    paramPrintWriter.println(stringBuilder.toString());
    int m = paramArrayOfStackTraceElement.length;
    int j = 0;
    int k = 0;
    while (j < m) {
      StringBuilder stringBuilder1;
      StackTraceElement stackTraceElement = paramArrayOfStackTraceElement[j];
      if (i && k > paramInt) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append("\t... skip ");
        stringBuilder1.append(paramArrayOfStackTraceElement.length - k - paramInt / 2);
        stringBuilder1.append(" lines");
        paramPrintWriter.println(stringBuilder1.toString());
        break;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("\tat ");
      stringBuilder.append(stringBuilder1);
      paramPrintWriter.println(stringBuilder.toString());
      k++;
      j++;
    } 
    if (i)
      for (i = paramArrayOfStackTraceElement.length - paramInt / 2; i < paramArrayOfStackTraceElement.length; i++) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("\tat ");
        stringBuilder1.append(paramArrayOfStackTraceElement[i]);
        paramPrintWriter.println(stringBuilder1.toString());
      }  
    if (Build.VERSION.SDK_INT >= 19)
      for (Throwable throwable : paramThrowable.getSuppressed()) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(paramString2);
        stringBuilder1.append("\t");
        String str = stringBuilder1.toString();
        j = paramInt / 2;
        if (j <= 10)
          j = 10; 
        a(throwable, paramPrintWriter, paramArrayOfStackTraceElement, "Suppressed: ", str, paramSet, j);
      }  
    paramThrowable = paramThrowable.getCause();
    if (paramThrowable != null) {
      paramInt /= 2;
      if (paramInt <= 10)
        paramInt = 10; 
      a(paramThrowable, paramPrintWriter, paramArrayOfStackTraceElement, "Caused by: ", paramString2, paramSet, paramInt);
    } 
  }
  
  private static void a(Throwable paramThrowable, List<StackTraceElement> paramList) {
    if (paramThrowable != null) {
      int i;
      if (paramList == null)
        return; 
      Set<?> set = Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>());
      set.add(paramThrowable);
      paramList.add(a);
      StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
      if (arrayOfStackTraceElement.length > 384) {
        i = 1;
      } else {
        i = 0;
      } 
      int m = arrayOfStackTraceElement.length;
      int j = 0;
      int k = 0;
      while (j < m) {
        StackTraceElement stackTraceElement = arrayOfStackTraceElement[j];
        if (i && k > 256) {
          paramList.add(a);
          break;
        } 
        paramList.add(stackTraceElement);
        k++;
        j++;
      } 
      if (i)
        for (i = arrayOfStackTraceElement.length - 128; i < arrayOfStackTraceElement.length; i++)
          paramList.add(arrayOfStackTraceElement[i]);  
      if (Build.VERSION.SDK_INT >= 19) {
        Throwable[] arrayOfThrowable = paramThrowable.getSuppressed();
        j = arrayOfThrowable.length;
        for (i = 0; i < j; i++)
          a(arrayOfThrowable[i], paramList, arrayOfStackTraceElement, "Suppressed: ", "\t", (Set)set, 128); 
      } 
      paramThrowable = paramThrowable.getCause();
      if (paramThrowable != null)
        a(paramThrowable, paramList, arrayOfStackTraceElement, "Caused by: ", "", (Set)set, 128); 
    } 
  }
  
  private static void a(Throwable paramThrowable, List<StackTraceElement> paramList, StackTraceElement[] paramArrayOfStackTraceElement, String paramString1, String paramString2, Set<Throwable> paramSet, int paramInt) {
    int i;
    if (paramSet.contains(paramThrowable)) {
      paramList.add(a);
      return;
    } 
    paramSet.add(paramThrowable);
    paramArrayOfStackTraceElement = paramThrowable.getStackTrace();
    if (paramArrayOfStackTraceElement.length > paramInt) {
      i = 1;
    } else {
      i = 0;
    } 
    paramList.add(a);
    int m = paramArrayOfStackTraceElement.length;
    int j = 0;
    int k = 0;
    while (j < m) {
      StackTraceElement stackTraceElement = paramArrayOfStackTraceElement[j];
      if (i && k > paramInt) {
        paramList.add(a);
        break;
      } 
      paramList.add(stackTraceElement);
      k++;
      j++;
    } 
    if (i)
      for (i = paramArrayOfStackTraceElement.length - paramInt / 2; i < paramArrayOfStackTraceElement.length; i++)
        paramList.add(paramArrayOfStackTraceElement[i]);  
    if (Build.VERSION.SDK_INT >= 19)
      for (Throwable throwable : paramThrowable.getSuppressed()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString2);
        stringBuilder.append("\t");
        String str = stringBuilder.toString();
        j = paramInt / 2;
        if (j <= 10)
          j = 10; 
        a(throwable, paramList, paramArrayOfStackTraceElement, "Suppressed: ", str, paramSet, j);
      }  
    paramThrowable = paramThrowable.getCause();
    if (paramThrowable != null) {
      paramInt /= 2;
      if (paramInt <= 10)
        paramInt = 10; 
      a(paramThrowable, paramList, paramArrayOfStackTraceElement, "Caused by: ", paramString2, paramSet, paramInt);
    } 
  }
  
  public static boolean a(String paramString, String[] paramArrayOfString) {
    if (paramArrayOfString != null) {
      if (TextUtils.isEmpty(paramString))
        return false; 
      int j = paramArrayOfString.length;
      for (int i = 0; i < j; i++) {
        if (paramString.contains(paramArrayOfString[i]))
          return true; 
      } 
    } 
    return false;
  }
  
  @Nullable
  public static JSONObject b(String paramString) {
    try {
      Map<Thread, StackTraceElement[]> map = Thread.getAllStackTraces();
      JSONObject jSONObject = new JSONObject();
      if (map == null)
        return null; 
      jSONObject.put("thread_all_count", map.size());
      JSONArray jSONArray = new JSONArray();
      Iterator<Map.Entry> iterator = map.entrySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          boolean bool;
          Map.Entry entry = iterator.next();
          JSONObject jSONObject1 = new JSONObject();
          Thread thread = (Thread)entry.getKey();
          String str = thread.getName();
          if (c(str) || (paramString != null && (paramString.equals(str) || str.startsWith(paramString) || str.endsWith(paramString))))
            continue; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(thread.getName());
          stringBuilder.append("(");
          stringBuilder.append(thread.getId());
          stringBuilder.append(")");
          jSONObject1.put("thread_name", stringBuilder.toString());
          StackTraceElement[] arrayOfStackTraceElement = (StackTraceElement[])entry.getValue();
          if (arrayOfStackTraceElement != null) {
            JSONArray jSONArray1 = new JSONArray();
            int i = arrayOfStackTraceElement.length;
            for (bool = false; bool < i; bool++) {
              StackTraceElement stackTraceElement = arrayOfStackTraceElement[bool];
              String str1 = stackTraceElement.getClassName();
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append(str1);
              stringBuilder1.append(".");
              stringBuilder1.append(stackTraceElement.getMethodName());
              stringBuilder1.append("(");
              stringBuilder1.append(stackTraceElement.getLineNumber());
              stringBuilder1.append(")");
              jSONArray1.put(stringBuilder1.toString());
            } 
            jSONObject1.put("thread_stack", jSONArray1);
            if (jSONArray1.length() > 0) {
              bool = true;
            } else {
              bool = false;
            } 
          } else {
            bool = true;
          } 
          if (bool)
            jSONArray.put(jSONObject1); 
          continue;
        } 
        jSONObject.put("thread_stacks", jSONArray);
        return jSONObject;
      } 
    } catch (Throwable throwable) {
      return null;
    } 
  }
  
  private static void b(Throwable paramThrowable, int paramInt) {
    paramThrowable.getClass().getName();
    String str = paramThrowable.getLocalizedMessage();
    try {
      a(paramThrowable.getClass().getName(), paramInt);
      if (str != null) {
        a(": ", paramInt);
        a(str, paramInt);
      } 
      a("\n", paramInt);
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  public static StackTraceElement[] b(@NonNull Throwable paramThrowable) {
    ArrayList<StackTraceElement> arrayList = new ArrayList();
    try {
      a(paramThrowable, arrayList);
    } catch (Throwable throwable) {}
    return arrayList.<StackTraceElement>toArray(new StackTraceElement[arrayList.size()]);
  }
  
  private static void c(Throwable paramThrowable, int paramInt) {
    if (paramThrowable != null) {
      if (paramInt <= 0)
        return; 
      b(paramThrowable, paramInt);
      StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
      int j = arrayOfStackTraceElement.length;
      boolean bool = false;
      int i;
      for (i = 0; i < j; i++)
        a(arrayOfStackTraceElement[i], paramInt); 
      if (Build.VERSION.SDK_INT >= 19) {
        Throwable[] arrayOfThrowable = paramThrowable.getSuppressed();
        j = arrayOfThrowable.length;
        for (i = bool; i < j; i++)
          a(arrayOfThrowable[i], paramInt, "Suppressed: ", "\t"); 
      } 
      paramThrowable = paramThrowable.getCause();
      if (paramThrowable != null)
        a(paramThrowable, paramInt, "Caused by: ", ""); 
    } 
  }
  
  private static boolean c(String paramString) {
    Set set = j.a();
    if (set.contains(paramString))
      return true; 
    for (String str : set) {
      if (!TextUtils.isEmpty(paramString) && paramString.startsWith(str))
        return true; 
    } 
    return false;
  }
  
  public static boolean c(Throwable paramThrowable) {
    if (paramThrowable == null)
      return false; 
    int i = 0;
    while (true) {
      if (paramThrowable != null) {
        try {
          if (paramThrowable instanceof OutOfMemoryError)
            return true; 
        } catch (Throwable throwable) {
          return false;
        } 
      } else {
        return false;
      } 
      if (i > 20)
        return false; 
      i++;
      throwable = throwable.getCause();
    } 
  }
  
  public static boolean d(Throwable paramThrowable) {
    if (paramThrowable == null)
      return false; 
    int i = 0;
    while (true) {
      if (paramThrowable != null) {
        try {
          if (paramThrowable instanceof OutOfMemoryError)
            if (!paramThrowable.getMessage().contains("allocate")) {
              if (paramThrowable.getMessage().contains("thrown"))
                return true; 
            } else {
              return true;
            }  
        } catch (Throwable throwable) {
          return true;
        } 
      } else {
        return false;
      } 
      if (i > 20)
        return false; 
      i++;
      throwable = throwable.getCause();
    } 
  }
  
  public static class a {
    public int a = -1;
    
    public int b = -1;
    
    public a(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
    
    public JSONObject a() {
      JSONObject jSONObject = new JSONObject();
      try {
        jSONObject.put("start", this.a);
        jSONObject.put("end", this.b);
        return jSONObject;
      } catch (Throwable throwable) {
        return jSONObject;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\l\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */