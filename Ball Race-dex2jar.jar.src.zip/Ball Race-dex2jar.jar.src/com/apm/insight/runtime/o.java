package com.apm.insight.runtime;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.apm.insight.CrashType;
import com.apm.insight.ICrashCallback;
import com.apm.insight.IOOMCallback;
import com.apm.insight.a.a;
import com.apm.insight.a.b;
import com.apm.insight.a.c;
import com.apm.insight.b.c;
import com.apm.insight.b.d;
import com.apm.insight.b.g;
import com.apm.insight.d.a;
import com.apm.insight.e;
import com.apm.insight.f;
import com.apm.insight.g;
import com.apm.insight.g.a;
import com.apm.insight.g.c;
import com.apm.insight.g.d;
import com.apm.insight.i;
import com.apm.insight.i.b;
import com.apm.insight.k.e;
import com.apm.insight.k.h;
import com.apm.insight.l.a;
import com.apm.insight.nativecrash.NativeImpl;
import java.io.File;
import java.util.Map;

public class o {
  private static boolean a;
  
  private static boolean b;
  
  private static boolean c;
  
  private static boolean d;
  
  private static boolean e;
  
  private static c f = new c();
  
  private static volatile boolean g = false;
  
  private static boolean h = false;
  
  public static c a() {
    return f;
  }
  
  public static void a(long paramLong) {
    NativeImpl.a(paramLong);
  }
  
  public static void a(@NonNull Application paramApplication, @NonNull Context paramContext, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, long paramLong) {
    // Byte code:
    //   0: ldc com/apm/insight/runtime/o
    //   2: monitorenter
    //   3: invokestatic uptimeMillis : ()J
    //   6: lstore #6
    //   8: getstatic com/apm/insight/runtime/o.a : Z
    //   11: istore #8
    //   13: iload #8
    //   15: ifeq -> 22
    //   18: ldc com/apm/insight/runtime/o
    //   20: monitorexit
    //   21: return
    //   22: iconst_1
    //   23: putstatic com/apm/insight/runtime/o.a : Z
    //   26: aload_1
    //   27: ifnull -> 178
    //   30: aload_0
    //   31: ifnull -> 178
    //   34: aload_0
    //   35: aload_1
    //   36: invokestatic a : (Landroid/app/Application;Landroid/content/Context;)V
    //   39: iload_2
    //   40: ifne -> 47
    //   43: iload_3
    //   44: ifeq -> 87
    //   47: invokestatic a : ()Lcom/apm/insight/g/a;
    //   50: astore_0
    //   51: iload_3
    //   52: ifeq -> 67
    //   55: aload_0
    //   56: new com/apm/insight/i/b
    //   59: dup
    //   60: aload_1
    //   61: invokespecial <init> : (Landroid/content/Context;)V
    //   64: invokevirtual a : (Lcom/apm/insight/g/c;)V
    //   67: iload_2
    //   68: ifeq -> 83
    //   71: aload_0
    //   72: new com/apm/insight/g/d
    //   75: dup
    //   76: aload_1
    //   77: invokespecial <init> : (Landroid/content/Context;)V
    //   80: invokevirtual b : (Lcom/apm/insight/g/c;)V
    //   83: iconst_1
    //   84: putstatic com/apm/insight/runtime/o.b : Z
    //   87: invokestatic a : ()Z
    //   90: pop
    //   91: iload #4
    //   93: ifeq -> 113
    //   96: aload_1
    //   97: invokestatic a : (Landroid/content/Context;)Z
    //   100: putstatic com/apm/insight/runtime/o.d : Z
    //   103: getstatic com/apm/insight/runtime/o.d : Z
    //   106: ifne -> 113
    //   109: iconst_1
    //   110: putstatic com/apm/insight/runtime/o.e : Z
    //   113: invokestatic myLooper : ()Landroid/os/Looper;
    //   116: invokestatic getMainLooper : ()Landroid/os/Looper;
    //   119: if_acmpne -> 129
    //   122: iconst_1
    //   123: putstatic com/apm/insight/runtime/o.g : Z
    //   126: invokestatic h : ()V
    //   129: iload #5
    //   131: invokestatic c : (Z)V
    //   134: new java/lang/StringBuilder
    //   137: dup
    //   138: invokespecial <init> : ()V
    //   141: astore_0
    //   142: aload_0
    //   143: ldc 'Npth.init takes '
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: pop
    //   149: aload_0
    //   150: invokestatic uptimeMillis : ()J
    //   153: lload #6
    //   155: lsub
    //   156: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   159: pop
    //   160: aload_0
    //   161: ldc ' ms.'
    //   163: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: pop
    //   167: aload_0
    //   168: invokevirtual toString : ()Ljava/lang/String;
    //   171: invokestatic a : (Ljava/lang/Object;)V
    //   174: ldc com/apm/insight/runtime/o
    //   176: monitorexit
    //   177: return
    //   178: new java/lang/IllegalArgumentException
    //   181: dup
    //   182: ldc 'context or Application must be not null.'
    //   184: invokespecial <init> : (Ljava/lang/String;)V
    //   187: athrow
    //   188: astore_0
    //   189: ldc com/apm/insight/runtime/o
    //   191: monitorexit
    //   192: aload_0
    //   193: athrow
    // Exception table:
    //   from	to	target	type
    //   3	13	188	finally
    //   22	26	188	finally
    //   34	39	188	finally
    //   47	51	188	finally
    //   55	67	188	finally
    //   71	83	188	finally
    //   83	87	188	finally
    //   87	91	188	finally
    //   96	113	188	finally
    //   113	129	188	finally
    //   129	174	188	finally
    //   178	188	188	finally
  }
  
  public static void a(@NonNull Context paramContext, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, long paramLong) {
    // Byte code:
    //   0: ldc com/apm/insight/runtime/o
    //   2: monitorenter
    //   3: invokestatic h : ()Landroid/app/Application;
    //   6: ifnull -> 17
    //   9: invokestatic h : ()Landroid/app/Application;
    //   12: astore #7
    //   14: goto -> 137
    //   17: aload_0
    //   18: instanceof android/app/Application
    //   21: ifeq -> 51
    //   24: aload_0
    //   25: checkcast android/app/Application
    //   28: astore #7
    //   30: aload #7
    //   32: invokevirtual getBaseContext : ()Landroid/content/Context;
    //   35: ifnull -> 41
    //   38: goto -> 137
    //   41: new java/lang/IllegalArgumentException
    //   44: dup
    //   45: ldc 'The Application passed in when init has not been attached, please pass a attachBaseContext as param and call Npth.setApplication(Application) before init.'
    //   47: invokespecial <init> : (Ljava/lang/String;)V
    //   50: athrow
    //   51: aload_0
    //   52: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   55: checkcast android/app/Application
    //   58: astore #8
    //   60: aload #8
    //   62: ifnull -> 107
    //   65: aload #8
    //   67: astore #7
    //   69: aload #8
    //   71: invokevirtual getBaseContext : ()Landroid/content/Context;
    //   74: ifnull -> 137
    //   77: aload #8
    //   79: invokevirtual getBaseContext : ()Landroid/content/Context;
    //   82: astore_0
    //   83: aload #8
    //   85: astore #7
    //   87: goto -> 137
    //   90: aload #7
    //   92: aload_0
    //   93: iload_1
    //   94: iload_2
    //   95: iload_3
    //   96: iload #4
    //   98: lload #5
    //   100: invokestatic a : (Landroid/app/Application;Landroid/content/Context;ZZZZJ)V
    //   103: ldc com/apm/insight/runtime/o
    //   105: monitorexit
    //   106: return
    //   107: new java/lang/IllegalArgumentException
    //   110: dup
    //   111: ldc 'Can not get the Application instance since a baseContext was passed in when init, please call Npth.setApplication(Application) before init.'
    //   113: invokespecial <init> : (Ljava/lang/String;)V
    //   116: athrow
    //   117: new java/lang/IllegalArgumentException
    //   120: dup
    //   121: ldc 'Can not get the Application instance since a baseContext was passed in when init, please call Npth.setApplication(Application) before init.'
    //   123: invokespecial <init> : (Ljava/lang/String;)V
    //   126: athrow
    //   127: astore_0
    //   128: ldc com/apm/insight/runtime/o
    //   130: monitorexit
    //   131: aload_0
    //   132: athrow
    //   133: astore_0
    //   134: goto -> 117
    //   137: goto -> 90
    // Exception table:
    //   from	to	target	type
    //   3	14	127	finally
    //   17	38	127	finally
    //   41	51	127	finally
    //   51	60	133	java/lang/Throwable
    //   51	60	127	finally
    //   69	83	127	finally
    //   90	103	127	finally
    //   107	117	127	finally
    //   117	127	127	finally
  }
  
  public static void a(ICrashCallback paramICrashCallback, CrashType paramCrashType) {
    a().a(paramICrashCallback, paramCrashType);
  }
  
  public static void a(IOOMCallback paramIOOMCallback) {
    a().a(paramIOOMCallback);
  }
  
  public static void a(IOOMCallback paramIOOMCallback, CrashType paramCrashType) {
    a().b(paramIOOMCallback);
  }
  
  public static void a(@NonNull e parame) {
    i.i().setEncryptImpl(parame);
  }
  
  public static void a(h paramh) {
    e.a(paramh);
  }
  
  public static void a(j paramj) {
    k.a(paramj);
  }
  
  public static void a(String paramString) {
    if (!TextUtils.isEmpty(paramString))
      a.a(paramString); 
  }
  
  public static void a(String paramString, b paramb, c paramc) {
    if (!TextUtils.isEmpty(paramString) && (new File(paramString)).exists())
      a.a().a(paramString, paramb, paramc); 
  }
  
  public static void a(String paramString, f paramf) {
    p.b().a(new Runnable(paramString, paramf) {
          public void run() {
            if (a.b(i.g()))
              d.a(this.a, this.b); 
          }
        });
  }
  
  public static void a(String paramString, @Nullable Map<? extends String, ? extends String> paramMap, @Nullable Map<String, String> paramMap1, @Nullable g paramg) {
    if (!TextUtils.isEmpty(paramString))
      a.a(paramString, paramMap, paramMap1, paramg); 
  }
  
  public static void a(String paramString, @Nullable Map<? extends String, ? extends String> paramMap, @Nullable Map<String, String> paramMap1, @Nullable Map<String, String> paramMap2, @Nullable g paramg) {
    if (!TextUtils.isEmpty(paramString))
      a.a(paramString, paramMap, paramMap1, paramMap2, paramg); 
  }
  
  @Deprecated
  public static void a(@NonNull Throwable paramThrowable) {
    if (!i.i().isReportErrorEnable())
      return; 
    a.a(paramThrowable);
  }
  
  public static void b(long paramLong) {
    NativeImpl.b(paramLong);
  }
  
  public static void b(ICrashCallback paramICrashCallback, CrashType paramCrashType) {
    a().b(paramICrashCallback, paramCrashType);
  }
  
  @Deprecated
  public static void b(String paramString) {
    if (!i.i().isReportErrorEnable())
      return; 
    a.c(paramString);
  }
  
  public static boolean b() {
    return b;
  }
  
  public static void c(long paramLong) {
    NativeImpl.c(paramLong);
  }
  
  public static void c(String paramString) {
    NativeImpl.b(paramString);
  }
  
  private static void c(boolean paramBoolean) {
    p.b().a(new Runnable(paramBoolean) {
          public void run() {
            if (!o.p())
              (new Handler(Looper.getMainLooper())).post(new Runnable(this) {
                    public void run() {
                      o.a(true);
                      NativeImpl.h();
                    }
                  },  ); 
            o.b(this.a);
          }
        },  0L);
  }
  
  public static boolean c() {
    return c;
  }
  
  private static void d(boolean paramBoolean) {
    // Byte code:
    //   0: invokestatic g : ()Landroid/content/Context;
    //   3: astore #4
    //   5: invokestatic a : ()Lcom/apm/insight/runtime/a/f;
    //   8: pop
    //   9: invokestatic a : ()Lcom/apm/insight/MonitorCrash;
    //   12: pop
    //   13: ldc_w 'Npth.initAsync-createCallbackThread'
    //   16: invokestatic a : (Ljava/lang/String;)V
    //   19: invokestatic b : ()I
    //   22: istore_1
    //   23: invokestatic a : ()V
    //   26: invokestatic c : ()V
    //   29: getstatic com/apm/insight/runtime/o.e : Z
    //   32: ifeq -> 51
    //   35: invokestatic a : ()Lcom/apm/insight/d;
    //   38: astore_2
    //   39: ldc_w 'NativeLibraryLoad faild'
    //   42: astore_3
    //   43: aload_2
    //   44: aload_3
    //   45: invokevirtual a : (Ljava/lang/String;)V
    //   48: goto -> 66
    //   51: iload_1
    //   52: ifge -> 66
    //   55: invokestatic a : ()Lcom/apm/insight/d;
    //   58: astore_2
    //   59: ldc_w 'createCallbackThread faild'
    //   62: astore_3
    //   63: goto -> 43
    //   66: ldc_w 'Npth.initAsync-NpthDataManager'
    //   69: invokestatic a : (Ljava/lang/String;)V
    //   72: invokestatic a : ()Lcom/apm/insight/e/a;
    //   75: aload #4
    //   77: invokevirtual a : (Landroid/content/Context;)V
    //   80: invokestatic a : ()V
    //   83: invokestatic a : ()Lcom/apm/insight/d;
    //   86: pop
    //   87: ldc_w 'Npth.initAsync-LaunchScanner'
    //   90: invokestatic a : (Ljava/lang/String;)V
    //   93: aload #4
    //   95: invokestatic a : (Landroid/content/Context;)V
    //   98: invokestatic a : ()V
    //   101: iload_0
    //   102: ifeq -> 126
    //   105: ldc_w 'Npth.initAsync-CrashANRHandler'
    //   108: invokestatic a : (Ljava/lang/String;)V
    //   111: aload #4
    //   113: invokestatic a : (Landroid/content/Context;)Lcom/apm/insight/b/g;
    //   116: invokevirtual c : ()V
    //   119: invokestatic a : ()V
    //   122: iload_0
    //   123: putstatic com/apm/insight/runtime/o.c : Z
    //   126: ldc_w 'Npth.initAsync-EventUploadQueue'
    //   129: invokestatic a : (Ljava/lang/String;)V
    //   132: invokestatic a : ()Lcom/apm/insight/k/g;
    //   135: invokevirtual b : ()V
    //   138: invokestatic a : ()V
    //   141: ldc_w 'Npth.initAsync-BlockMonitor'
    //   144: invokestatic a : (Ljava/lang/String;)V
    //   147: invokestatic a : ()V
    //   150: ldc_w 'Npth.initAsync-OriginExceptionMonitor'
    //   153: invokestatic a : (Ljava/lang/String;)V
    //   156: invokestatic a : ()V
    //   159: invokestatic f : ()V
    //   162: invokestatic a : ()V
    //   165: invokestatic d : ()V
    //   168: invokestatic j : ()V
    //   171: ldc_w 'afterNpthInitAsync'
    //   174: ldc_w 'noValue'
    //   177: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   180: return
  }
  
  public static boolean d() {
    return d;
  }
  
  public static boolean e() {
    return a;
  }
  
  public static void f() {
    if (a && !b) {
      Context context = i.g();
      a a = a.a();
      a.a((c)new b(context));
      a.b((c)new d(context));
    } 
  }
  
  public static void g() {
    if (a) {
      g.a(i.g()).c();
      c = true;
    } 
  }
  
  public static boolean h() {
    if (a && !d) {
      d = NativeImpl.a(i.g());
      if (!d)
        e = true; 
    } 
    return d;
  }
  
  public static boolean i() {
    return c.c();
  }
  
  public static void j() {
    if (a) {
      g.a(i.g()).d();
      c = false;
    } 
  }
  
  public static boolean k() {
    return (a.b() || NativeImpl.d());
  }
  
  public static boolean l() {
    return (a.c() || NativeImpl.d());
  }
  
  public static boolean m() {
    return a.b();
  }
  
  public static boolean n() {
    return h;
  }
  
  public static void o() {
    h = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\runtime\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */