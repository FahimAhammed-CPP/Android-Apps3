package com.apm.insight.runtime;

import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.apm.insight.ICommonParams;
import com.apm.insight.e;
import com.apm.insight.i;
import com.apm.insight.j.b;
import com.apm.insight.k.a;
import com.apm.insight.l.a;
import com.apm.insight.l.g;
import com.apm.insight.l.j;
import com.apm.insight.l.p;
import java.util.Set;
import java.util.concurrent.ThreadPoolExecutor;

public class ConfigManager {
  public static final long BLOCK_MONITOR_INTERVAL = 1000L;
  
  private static final long BLOCK_MONITOR_MIN_INTERVAL = 10L;
  
  public static final String CONFIG_URL_SUFFIX = "/settings/get";
  
  public static final String EXCEPTION_URL_SUFFIX = "/monitor/collect/c/exception";
  
  public static final String JAVA_URL_SUFFIX = "/monitor/collect/c/crash";
  
  private static final long LAUNCH_CRASH_INTERVAL = 8000L;
  
  public static final String LAUNCH_URL_SUFFIX = "/monitor/collect/c/exception/dump_collection";
  
  public static final String LOG_TYPE_ALL_STACK = "npth_enable_all_thread_stack";
  
  public static final String NATIVE_URL_SUFFIX = "/monitor/collect/c/native_bin_crash";
  
  private String mAlogUploadUrl = "";
  
  private String mAsanReportUploadUrl = "";
  
  private boolean mBlockMonitorEnable = false;
  
  private long mBlockMonitorInterval = 1000L;
  
  private String mConfigUrl = "";
  
  private String mCoreDumpUrl = "";
  
  private e mEncryptImpl = new e(this) {
      public byte[] a(byte[] param1ArrayOfbyte) {
        return g.a(param1ArrayOfbyte);
      }
    };
  
  private boolean mEnsureEnable = true;
  
  private boolean mEnsureWithLogcat = false;
  
  private String mExceptionUploadUrl = "";
  
  private boolean mIsDebugMode = false;
  
  private String mJavaCrashUploadUrl = "";
  
  private long mLaunchCrashInterval = 8000L;
  
  private String mLaunchCrashUploadUrl = "";
  
  private int mLogcatDumpCount = 512;
  
  private int mLogcatLevel = 1;
  
  private boolean mNativeCrashMiniDump = true;
  
  private String mNativeCrashUploadUrl = "";
  
  private String mNativeMemUrl = "";
  
  private ThreadPoolExecutor mThreadPoolExecutor;
  
  private boolean reportErrorEnable = true;
  
  public static void setDefaultCommonParams(ICommonParams paramICommonParams, Context paramContext) {
    i.a(new d(paramContext, paramICommonParams));
  }
  
  public static void updateDid(String paramString) {
    p.b().a(new Runnable(paramString) {
          public void run() {
            i.c().a(this.a);
            b.d();
          }
        });
  }
  
  public String getAlogUploadUrl() {
    return this.mAlogUploadUrl;
  }
  
  public String getAsanReportUploadUrl() {
    return this.mAsanReportUploadUrl;
  }
  
  public long getBlockInterval() {
    return this.mBlockMonitorInterval;
  }
  
  public String getConfigUrl() {
    return this.mConfigUrl;
  }
  
  public String getCoreDumpUrl() {
    return this.mCoreDumpUrl;
  }
  
  @NonNull
  public e getEncryptImpl() {
    return this.mEncryptImpl;
  }
  
  public String getExceptionUploadUrl() {
    return this.mExceptionUploadUrl;
  }
  
  public Set<String> getFilterThreadSet() {
    return j.a();
  }
  
  public String getJavaCrashUploadUrl() {
    return this.mJavaCrashUploadUrl;
  }
  
  public long getLaunchCrashInterval() {
    return this.mLaunchCrashInterval;
  }
  
  public String getLaunchCrashUploadUrl() {
    return this.mLaunchCrashUploadUrl;
  }
  
  public int getLogcatDumpCount() {
    return this.mLogcatDumpCount;
  }
  
  public int getLogcatLevel() {
    return this.mLogcatLevel;
  }
  
  public String getNativeCrashUploadUrl() {
    return this.mNativeCrashUploadUrl;
  }
  
  public String getNativeMemUrl() {
    return this.mNativeMemUrl;
  }
  
  public ThreadPoolExecutor getThreadPoolExecutor() {
    return this.mThreadPoolExecutor;
  }
  
  public boolean isApmExists() {
    return a.c();
  }
  
  public boolean isBlockMonitorEnable() {
    return this.mBlockMonitorEnable;
  }
  
  public boolean isCrashIgnored(String paramString) {
    try {
      f f = new f(this, paramString) {
          @Nullable
          public Object a(String param1String) {
            return param1String.equals("md5") ? this.a : super.a(param1String);
          }
        };
      if (n.a("java_crash_ignore", f))
        return true; 
      if (p.b(i.g())) {
        a.d();
        return n.a("java_crash_ignore", f);
      } 
    } catch (Throwable throwable) {}
    return false;
  }
  
  public boolean isDebugMode() {
    return this.mIsDebugMode;
  }
  
  public boolean isEnsureEnable() {
    return this.mEnsureEnable;
  }
  
  public boolean isEnsureWithLogcat() {
    return this.mEnsureWithLogcat;
  }
  
  public boolean isNativeCrashMiniDump() {
    return this.mNativeCrashMiniDump;
  }
  
  public boolean isReportErrorEnable() {
    return this.reportErrorEnable;
  }
  
  public void setAlogUploadUrl(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return; 
    this.mAlogUploadUrl = paramString;
  }
  
  public void setBlockMonitorEnable(boolean paramBoolean) {
    this.mBlockMonitorEnable = paramBoolean;
  }
  
  public void setBlockMonitorInterval(long paramLong) {
    this.mBlockMonitorInterval = paramLong;
  }
  
  public void setConfigUrl(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return; 
    this.mConfigUrl = paramString;
  }
  
  public void setCurrentProcessName(String paramString) {
    a.a(paramString);
  }
  
  public void setDebugMode(boolean paramBoolean) {
    this.mIsDebugMode = paramBoolean;
  }
  
  public void setEncryptImpl(e parame) {
    if (parame != null)
      this.mEncryptImpl = parame; 
  }
  
  public void setEnsureEnable(boolean paramBoolean) {
    this.mEnsureEnable = paramBoolean;
  }
  
  public void setEnsureWithLogcat(boolean paramBoolean) {
    this.mEnsureWithLogcat = paramBoolean;
  }
  
  public void setJavaCrashUploadUrl(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return; 
    this.mJavaCrashUploadUrl = paramString;
  }
  
  public void setLaunchCrashInterval(long paramLong) {
    if (paramLong > 0L)
      this.mLaunchCrashInterval = paramLong; 
  }
  
  public void setLaunchCrashUrl(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return; 
    this.mExceptionUploadUrl = paramString;
    int i = paramString.indexOf("//");
    if (i == -1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString.substring(0, paramString.indexOf("/") + 1));
      stringBuilder.append("monitor/collect/c/exception/dump_collection");
      paramString = stringBuilder.toString();
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString.substring(0, paramString.indexOf("/", i + 2) + 1));
      stringBuilder.append("monitor/collect/c/exception/dump_collection");
      paramString = stringBuilder.toString();
    } 
    this.mLaunchCrashUploadUrl = paramString;
  }
  
  public void setLogcatDumpCount(int paramInt) {
    if (paramInt > 0)
      this.mLogcatDumpCount = paramInt; 
  }
  
  public void setLogcatLevel(int paramInt) {
    if (paramInt >= 0 && paramInt <= 4)
      this.mLogcatLevel = paramInt; 
  }
  
  public void setNativeCrashUrl(String paramString) {
    if (TextUtils.isEmpty(paramString))
      return; 
    this.mNativeCrashUploadUrl = paramString;
  }
  
  public void setReportErrorEnable(boolean paramBoolean) {
    this.reportErrorEnable = paramBoolean;
  }
  
  public void setThreadPoolExecutor(ThreadPoolExecutor paramThreadPoolExecutor) {
    this.mThreadPoolExecutor = paramThreadPoolExecutor;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\runtime\ConfigManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */