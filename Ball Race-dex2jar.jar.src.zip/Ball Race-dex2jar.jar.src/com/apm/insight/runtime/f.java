package com.apm.insight.runtime;

import androidx.annotation.Nullable;
import com.apm.insight.entity.Header;
import com.apm.insight.i;

public class f {
  private static final f b = new f() {
      Header a = null;
      
      @Nullable
      public Object b(String param1String) {
        if (this.a == null)
          this.a = Header.b(i.g()); 
        return this.a.f().opt(param1String);
      }
    };
  
  private f a = null;
  
  f() {
    this(b);
  }
  
  f(f paramf) {
    this.a = paramf;
  }
  
  @Nullable
  public Object a(String paramString) {
    f f1 = this.a;
    return (f1 != null) ? f1.a(paramString) : null;
  }
  
  @Nullable
  public Object b(String paramString) {
    f f1 = this.a;
    return (f1 != null) ? f1.b(paramString) : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\runtime\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */