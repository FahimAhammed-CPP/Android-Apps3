package com.apm.insight.runtime.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.apm.insight.c;
import com.apm.insight.runtime.p;

class d {
  private int a;
  
  d(Context paramContext) {
    p.b().a(new Runnable(this, paramContext) {
          public void run() {
            try {
              d.a(this.b, this.a);
              return;
            } catch (Throwable throwable) {
              c.a().a("NPTH_CATCH", throwable);
              return;
            } 
          }
        });
  }
  
  private void a(Context paramContext) {
    paramContext.registerReceiver(new a(), new IntentFilter("android.intent.action.BATTERY_CHANGED"));
  }
  
  public int a() {
    return this.a;
  }
  
  private class a extends BroadcastReceiver {
    private a(d this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      try {
        if ("android.intent.action.BATTERY_CHANGED".equals(param1Intent.getAction())) {
          int i = param1Intent.getIntExtra("level", 0);
          int j = param1Intent.getIntExtra("scale", 100);
          d.a(this.a, (int)(i * 100.0F / j));
        } 
        return;
      } catch (Throwable throwable) {
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\runtime\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */