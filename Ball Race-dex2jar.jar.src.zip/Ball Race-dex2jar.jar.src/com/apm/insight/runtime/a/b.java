package com.apm.insight.runtime.a;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import androidx.annotation.NonNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class b {
  private static boolean a = true;
  
  private static boolean b = false;
  
  private static boolean c = false;
  
  private static int d = 1;
  
  private static boolean e = false;
  
  private static long f = -1L;
  
  private static volatile b z;
  
  private int A = 50;
  
  private int B;
  
  private Application g;
  
  private Context h;
  
  private List<String> i = new ArrayList<String>();
  
  private List<Long> j = new ArrayList<Long>();
  
  private List<String> k = new ArrayList<String>();
  
  private List<Long> l = new ArrayList<Long>();
  
  private LinkedList<a> m = new LinkedList<a>();
  
  private String n;
  
  private long o;
  
  private String p;
  
  private long q;
  
  private String r;
  
  private long s;
  
  private String t;
  
  private long u;
  
  private String v;
  
  private long w;
  
  private boolean x = false;
  
  private long y = -1L;
  
  private b(@NonNull Application paramApplication) {
    this.h = (Context)paramApplication;
    this.g = paramApplication;
    try {
      m();
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  private a a(String paramString1, String paramString2, long paramLong) {
    a a1;
    if (this.m.size() >= this.A) {
      a a = this.m.poll();
      a1 = a;
      if (a != null) {
        this.m.add(a);
        a1 = a;
      } 
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null) {
      a2 = new a(paramString1, paramString2, paramLong);
      this.m.add(a2);
    } 
    return a2;
  }
  
  private JSONObject a(String paramString, long paramLong) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("name", paramString);
      jSONObject.put("time", paramLong);
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
  
  public static void a() {
    e = true;
  }
  
  private void a(String paramString1, long paramLong, String paramString2) {
    try {
      a a = a(paramString1, paramString2, paramLong);
      a.b = paramString2;
      a.a = paramString1;
      a.c = paramLong;
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  public static int b() {
    int i = d;
    byte b1 = 1;
    if (i == 1) {
      if (e)
        b1 = 2; 
      return b1;
    } 
    return i;
  }
  
  public static long c() {
    return f;
  }
  
  public static b d() {
    // Byte code:
    //   0: getstatic com/apm/insight/runtime/a/b.z : Lcom/apm/insight/runtime/a/b;
    //   3: ifnonnull -> 40
    //   6: ldc com/apm/insight/runtime/a/b
    //   8: monitorenter
    //   9: getstatic com/apm/insight/runtime/a/b.z : Lcom/apm/insight/runtime/a/b;
    //   12: ifnonnull -> 28
    //   15: new com/apm/insight/runtime/a/b
    //   18: dup
    //   19: invokestatic h : ()Landroid/app/Application;
    //   22: invokespecial <init> : (Landroid/app/Application;)V
    //   25: putstatic com/apm/insight/runtime/a/b.z : Lcom/apm/insight/runtime/a/b;
    //   28: ldc com/apm/insight/runtime/a/b
    //   30: monitorexit
    //   31: goto -> 40
    //   34: astore_0
    //   35: ldc com/apm/insight/runtime/a/b
    //   37: monitorexit
    //   38: aload_0
    //   39: athrow
    //   40: getstatic com/apm/insight/runtime/a/b.z : Lcom/apm/insight/runtime/a/b;
    //   43: areturn
    // Exception table:
    //   from	to	target	type
    //   9	28	34	finally
    //   28	31	34	finally
    //   35	38	34	finally
  }
  
  private void m() {
    if (Build.VERSION.SDK_INT >= 14 && this.g != null) {
      Application.ActivityLifecycleCallbacks activityLifecycleCallbacks = new Application.ActivityLifecycleCallbacks(this) {
          public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
            boolean bool;
            b.a(this.a, param1Activity.getClass().getName());
            b.a(this.a, System.currentTimeMillis());
            if (param1Bundle != null) {
              bool = true;
            } else {
              bool = false;
            } 
            b.a(bool);
            b.b(true);
            b.b(this.a).add(b.a(this.a));
            b.d(this.a).add(Long.valueOf(b.c(this.a)));
            b b1 = this.a;
            b.a(b1, b.a(b1), b.c(this.a), "onCreate");
          }
          
          public void onActivityDestroyed(Activity param1Activity) {
            String str = param1Activity.getClass().getName();
            int i = b.b(this.a).indexOf(str);
            if (i > -1 && i < b.b(this.a).size()) {
              b.b(this.a).remove(i);
              b.d(this.a).remove(i);
            } 
            b.q(this.a).add(str);
            long l = System.currentTimeMillis();
            b.r(this.a).add(Long.valueOf(l));
            b.a(this.a, str, l, "onDestroy");
          }
          
          public void onActivityPaused(Activity param1Activity) {
            // Byte code:
            //   0: aload_0
            //   1: getfield a : Lcom/apm/insight/runtime/a/b;
            //   4: aload_1
            //   5: invokevirtual getClass : ()Ljava/lang/Class;
            //   8: invokevirtual getName : ()Ljava/lang/String;
            //   11: invokestatic d : (Lcom/apm/insight/runtime/a/b;Ljava/lang/String;)Ljava/lang/String;
            //   14: pop
            //   15: aload_0
            //   16: getfield a : Lcom/apm/insight/runtime/a/b;
            //   19: invokestatic currentTimeMillis : ()J
            //   22: invokestatic d : (Lcom/apm/insight/runtime/a/b;J)J
            //   25: pop2
            //   26: aload_0
            //   27: getfield a : Lcom/apm/insight/runtime/a/b;
            //   30: invokestatic l : (Lcom/apm/insight/runtime/a/b;)I
            //   33: pop
            //   34: aload_0
            //   35: getfield a : Lcom/apm/insight/runtime/a/b;
            //   38: invokestatic m : (Lcom/apm/insight/runtime/a/b;)I
            //   41: ifne -> 72
            //   44: aload_0
            //   45: getfield a : Lcom/apm/insight/runtime/a/b;
            //   48: iconst_0
            //   49: invokestatic a : (Lcom/apm/insight/runtime/a/b;Z)Z
            //   52: pop
            //   53: iconst_0
            //   54: invokestatic b : (Z)Z
            //   57: pop
            //   58: aload_0
            //   59: getfield a : Lcom/apm/insight/runtime/a/b;
            //   62: invokestatic uptimeMillis : ()J
            //   65: invokestatic e : (Lcom/apm/insight/runtime/a/b;J)J
            //   68: pop2
            //   69: goto -> 94
            //   72: aload_0
            //   73: getfield a : Lcom/apm/insight/runtime/a/b;
            //   76: invokestatic m : (Lcom/apm/insight/runtime/a/b;)I
            //   79: ifge -> 94
            //   82: aload_0
            //   83: getfield a : Lcom/apm/insight/runtime/a/b;
            //   86: iconst_0
            //   87: invokestatic a : (Lcom/apm/insight/runtime/a/b;I)I
            //   90: pop
            //   91: goto -> 44
            //   94: aload_0
            //   95: getfield a : Lcom/apm/insight/runtime/a/b;
            //   98: astore_1
            //   99: aload_1
            //   100: aload_1
            //   101: invokestatic j : (Lcom/apm/insight/runtime/a/b;)Ljava/lang/String;
            //   104: aload_0
            //   105: getfield a : Lcom/apm/insight/runtime/a/b;
            //   108: invokestatic n : (Lcom/apm/insight/runtime/a/b;)J
            //   111: ldc 'onPause'
            //   113: invokestatic a : (Lcom/apm/insight/runtime/a/b;Ljava/lang/String;JLjava/lang/String;)V
            //   116: return
          }
          
          public void onActivityResumed(Activity param1Activity) {
            b.c(this.a, param1Activity.getClass().getName());
            b.c(this.a, System.currentTimeMillis());
            b.g(this.a);
            if (!b.h(this.a)) {
              if (b.j()) {
                b.c(false);
                b.a(1);
                b.a(b.i(this.a));
              } 
              if (!b.k(this.a).equals(b.j(this.a)))
                return; 
              if (b.k() && !b.l()) {
                b.a(4);
                b.a(b.i(this.a));
                return;
              } 
              if (!b.k()) {
                b.a(3);
                b.a(b.i(this.a));
                return;
              } 
            } 
            b.a(this.a, true);
            b b1 = this.a;
            b.a(b1, b.k(b1), b.i(this.a), "onResume");
          }
          
          public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
          
          public void onActivityStarted(Activity param1Activity) {
            b.b(this.a, param1Activity.getClass().getName());
            b.b(this.a, System.currentTimeMillis());
            b b1 = this.a;
            b.a(b1, b.e(b1), b.f(this.a), "onStart");
          }
          
          public void onActivityStopped(Activity param1Activity) {
            b.e(this.a, param1Activity.getClass().getName());
            b.f(this.a, System.currentTimeMillis());
            b b1 = this.a;
            b.a(b1, b.o(b1), b.p(this.a), "onStop");
          }
        };
      this.g.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
    } 
  }
  
  private JSONArray n() {
    JSONArray jSONArray = new JSONArray();
    List<String> list = this.i;
    if (list != null) {
      if (list.isEmpty())
        return jSONArray; 
      int i = 0;
      while (true) {
        if (i < this.i.size()) {
          try {
            jSONArray.put(a(this.i.get(i), ((Long)this.j.get(i)).longValue()));
            i++;
          } catch (Throwable throwable) {
            return jSONArray;
          } 
          continue;
        } 
        return jSONArray;
      } 
    } 
    return jSONArray;
  }
  
  private JSONArray o() {
    JSONArray jSONArray = new JSONArray();
    List<String> list = this.k;
    if (list != null) {
      if (list.isEmpty())
        return jSONArray; 
      int i = 0;
      while (true) {
        if (i < this.k.size()) {
          try {
            jSONArray.put(a(this.k.get(i), ((Long)this.l.get(i)).longValue()));
            i++;
          } catch (Throwable throwable) {
            return jSONArray;
          } 
          continue;
        } 
        return jSONArray;
      } 
    } 
    return jSONArray;
  }
  
  public long e() {
    return SystemClock.uptimeMillis() - this.y;
  }
  
  public boolean f() {
    return this.x;
  }
  
  public JSONObject g() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("last_create_activity", a(this.n, this.o));
      jSONObject.put("last_start_activity", a(this.p, this.q));
      jSONObject.put("last_resume_activity", a(this.r, this.s));
      jSONObject.put("last_pause_activity", a(this.t, this.u));
      jSONObject.put("last_stop_activity", a(this.v, this.w));
      jSONObject.put("alive_activities", n());
      jSONObject.put("finish_activities", o());
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
  
  @NonNull
  public String h() {
    return String.valueOf(this.r);
  }
  
  public JSONArray i() {
    JSONArray jSONArray = new JSONArray();
    Iterator<?> iterator = (new ArrayList(this.m)).iterator();
    while (iterator.hasNext())
      jSONArray.put(((a)iterator.next()).toString()); 
    return jSONArray;
  }
  
  private static class a {
    String a;
    
    String b;
    
    long c;
    
    a(String param1String1, String param1String2, long param1Long) {
      this.b = param1String2;
      this.c = param1Long;
      this.a = param1String1;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(com.apm.insight.l.b.a().format(new Date(this.c)));
      stringBuilder.append(" : ");
      stringBuilder.append(this.a);
      stringBuilder.append(' ');
      stringBuilder.append(this.b);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\runtime\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */