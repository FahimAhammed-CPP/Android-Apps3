package com.apm.insight.runtime;

import android.os.Build;
import android.system.Os;
import android.system.OsConstants;

public class q {
  private static long a = -1L;
  
  public static class a {
    private static long a = -1L;
    
    public static long a() {
      if (q.a() == -1L)
        q.a(1000L / b()); 
      return q.a();
    }
    
    public static long a(long param1Long) {
      long l = a;
      if (l > 0L)
        return l; 
      if (Build.VERSION.SDK_INT >= 21) {
        l = Os.sysconf(OsConstants._SC_CLK_TCK);
      } else if (Build.VERSION.SDK_INT >= 14) {
        l = a("_SC_CLK_TCK", param1Long);
      } else {
        l = param1Long;
      } 
      if (l > 0L)
        param1Long = l; 
      a = param1Long;
      return a;
    }
    
    private static long a(String param1String, long param1Long) {
      try {
        int i = Class.forName("libcore.io.OsConstants").getField(param1String).getInt(null);
        Class<?> clazz2 = Class.forName("libcore.io.Libcore");
        Class<?> clazz1 = Class.forName("libcore.io.Os");
        Object object = clazz2.getField("os").get(null);
        return ((Long)clazz1.getMethod("sysconf", new Class[] { int.class }).invoke(object, new Object[] { Integer.valueOf(i) })).longValue();
      } catch (Throwable throwable) {
        throwable.printStackTrace();
        return param1Long;
      } 
    }
    
    public static long b() {
      return a(100L);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\runtime\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */