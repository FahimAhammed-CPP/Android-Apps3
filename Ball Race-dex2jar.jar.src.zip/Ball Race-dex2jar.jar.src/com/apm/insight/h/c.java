package com.apm.insight.h;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import androidx.annotation.Nullable;
import com.apm.insight.l.i;
import com.apm.insight.l.k;
import dalvik.system.BaseDexClassLoader;
import java.io.Closeable;
import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipFile;

public class c {
  private static List<String> a = new ArrayList<String>();
  
  @Nullable
  public static String a(Context paramContext, String paramString, File paramFile) {
    ApplicationInfo applicationInfo = paramContext.getApplicationInfo();
    String str = a(applicationInfo.sourceDir, paramString, paramFile);
    if (str == null)
      return null; 
    if (Build.VERSION.SDK_INT < 21)
      return "low"; 
    String[] arrayOfString = applicationInfo.splitSourceDirs;
    int j = arrayOfString.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      str = a(arrayOfString[i], paramString, paramFile);
      if (str == null)
        return null; 
    } 
    try {
      ClassLoader classLoader;
      for (classLoader = c.class.getClassLoader(); !(classLoader instanceof BaseDexClassLoader) && classLoader.getParent() != null; classLoader = classLoader.getParent());
      if (classLoader instanceof BaseDexClassLoader) {
        Field field1 = BaseDexClassLoader.class.getDeclaredField("pathList");
        field1.setAccessible(true);
        Object object = field1.get(classLoader);
        Field field2 = object.getClass().getDeclaredField("nativeLibraryDirectories");
        field2.setAccessible(true);
        object = field2.get(object);
        j = object.length;
        for (i = bool;; i++) {
          if (i < j) {
            File file = new File((String)object[i], System.mapLibraryName(paramString));
            if (file.exists()) {
              i.a(file, paramFile);
              k.a(paramFile.getAbsolutePath(), 493);
              return null;
            } 
          } else {
            return "not_found";
          } 
        } 
      } 
    } catch (Throwable throwable) {
      str = throwable.getMessage();
    } 
    return str;
  }
  
  public static String a(String paramString1, String paramString2, File paramFile) {
    Exception exception;
    String str;
    Throwable throwable1;
    throwable2 = null;
    byte[] arrayOfByte = null;
    try {
      ZipFile zipFile;
    } catch (Throwable throwable) {
    
    } finally {
      paramString1 = null;
      paramString2 = null;
      str = paramString2;
    } 
    try {
      paramString2 = paramString2.getMessage();
      k.a((Closeable)throwable1);
    } finally {
      Exception exception1 = null;
      paramString2 = paramString1;
    } 
    k.a((ZipFile)str);
    return (String)exception;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\h\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */