package com.apm.insight.h;

import com.apm.insight.c;
import com.apm.insight.i;
import com.apm.insight.l.i;
import com.apm.insight.l.q;
import com.apm.insight.runtime.p;
import com.apm.insight.runtime.r;
import java.io.File;
import java.util.HashMap;

public class b {
  private static HashMap<String, String> a;
  
  public static String a() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(i.g().getFilesDir());
    stringBuilder.append("/apminsight/selflib/");
    return stringBuilder.toString();
  }
  
  public static String a(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(i.g().getFilesDir());
    stringBuilder.append("/apminsight/selflib/");
    stringBuilder.append("lib");
    stringBuilder.append(paramString);
    stringBuilder.append(".so");
    return stringBuilder.toString();
  }
  
  public static void b(String paramString) {
    p.b().a(new Runnable(paramString) {
          boolean a = false;
          
          public void run() {
            b.b();
            if (!b.c(this.b)) {
              String str1;
              String str2;
              r.a("updateSo", this.b);
              File file = new File(b.a(this.b));
              file.getParentFile().mkdirs();
              if (file.exists())
                file.delete(); 
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("doUnpackLibrary: ");
              stringBuilder.append(this.b);
              q.a(stringBuilder.toString());
              stringBuilder = null;
              try {
                str2 = c.a(i.g(), this.b, file);
                str1 = str2;
              } catch (Throwable throwable) {
                r.a("updateSoError", this.b);
                c.a().a("NPTH_CATCH", throwable);
              } 
              if (str1 == null) {
                b.c().put(file.getName(), "1.3.8.nourl-alpha.9");
                try {
                  i.a(new File(b.d(this.b)), "1.3.8.nourl-alpha.9", false);
                } catch (Throwable throwable) {}
                str1 = this.b;
                str2 = "updateSoSuccess";
              } else {
                if (!this.a) {
                  this.a = true;
                  r.a("updateSoPostRetry", this.b);
                  p.b().a(this, 3000L);
                  return;
                } 
                str1 = this.b;
                str2 = "updateSoFailed";
              } 
              r.a(str2, str1);
            } 
          }
        });
  }
  
  private static void d() {
    if (a != null)
      return; 
    a = new HashMap<String, String>();
    File file = new File(i.g().getFilesDir(), "/apminsight/selflib/");
    String[] arrayOfString = file.list();
    if (arrayOfString == null)
      return; 
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str = arrayOfString[i];
      if (str.endsWith(".ver")) {
        String str1 = str.substring(0, str.length() - 4);
        try {
          HashMap<String, String> hashMap = a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(file.getAbsolutePath());
          stringBuilder.append("/");
          stringBuilder.append(str);
          hashMap.put(str1, i.c(stringBuilder.toString()));
        } catch (Throwable throwable) {
          c.a().a("NPTH_CATCH", throwable);
        } 
      } else if (!throwable.endsWith(".so")) {
        i.a(new File(file, (String)throwable));
      } 
    } 
  }
  
  private static String e(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(i.g().getFilesDir());
    stringBuilder.append("/apminsight/selflib/");
    stringBuilder.append(paramString);
    stringBuilder.append(".ver");
    return stringBuilder.toString();
  }
  
  private static boolean f(String paramString) {
    return !"1.3.8.nourl-alpha.9".equals(a.get(paramString)) ? false : (!!(new File(a(paramString))).exists());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\h\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */