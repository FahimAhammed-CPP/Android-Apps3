package com.apm.insight.k;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.NonNull;
import com.apm.insight.CrashType;
import com.apm.insight.Npth;
import com.apm.insight.h.b;
import com.apm.insight.i;
import com.apm.insight.l.a;
import com.apm.insight.l.i;
import com.apm.insight.l.o;
import com.apm.insight.l.q;
import com.apm.insight.l.r;
import com.apm.insight.runtime.a;
import com.apm.insight.runtime.p;
import com.apm.insight.runtime.r;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class d {
  @SuppressLint({"StaticFieldLeak"})
  private static volatile d a;
  
  private volatile Context b;
  
  private d(@NonNull Context paramContext) {
    this.b = paramContext;
  }
  
  public static d a() {
    if (a == null)
      a = new d(i.g()); 
    return a;
  }
  
  public void a(JSONObject paramJSONObject) {
    if (paramJSONObject != null) {
      if (paramJSONObject.length() <= 0)
        return; 
      try {
        String str = e.f();
        File file = new File(o.a(this.b), o.c());
        i.a(file, file.getName(), str, paramJSONObject, e.b());
        if (e.a(str, paramJSONObject.toString()).a()) {
          i.a(file);
          return;
        } 
      } catch (Throwable throwable) {
        q.b(throwable);
      } 
    } 
  }
  
  public void a(JSONObject paramJSONObject, long paramLong, boolean paramBoolean) {
    if (paramJSONObject != null) {
      if (paramJSONObject.length() <= 0)
        return; 
      try {
        String str = e.c();
        File file1 = o.a(this.b);
        CrashType crashType = CrashType.ANR;
        int i = 0;
        File file2 = new File(file1, i.a(paramLong, crashType, false, false));
        i.a(file2, file2.getName(), str, paramJSONObject, e.b());
        if (paramBoolean) {
          File[] arrayOfFile;
          if (Npth.isStopUpload())
            return; 
          paramJSONObject.put("upload_scene", "direct");
          paramJSONObject.put("crash_uuid", file2.getName());
          r.a(paramJSONObject);
          if (a.j()) {
            HashMap hashMap = r.a(paramLong, "anr_trace");
            File[] arrayOfFile1 = new File[hashMap.size() + 2];
            Iterator<Map.Entry> iterator = hashMap.entrySet().iterator();
            while (true) {
              arrayOfFile = arrayOfFile1;
              if (iterator.hasNext()) {
                Map.Entry entry = iterator.next();
                if (((String)entry.getKey()).equals(a.c(this.b)))
                  continue; 
                arrayOfFile1[i] = o.a(this.b, ((r.a)entry.getValue()).b);
                i++;
                continue;
              } 
              break;
            } 
          } else {
            arrayOfFile = new File[2];
          } 
          arrayOfFile[arrayOfFile.length - 1] = o.a(this.b, i.f());
          arrayOfFile[arrayOfFile.length - 2] = r.a(paramLong);
          if (e.a(str, paramJSONObject.toString(), arrayOfFile).a()) {
            i.a(file2);
            if (!Npth.hasCrash())
              i.a(o.e(i.g())); 
          } 
        } 
        return;
      } catch (Throwable throwable) {
        return;
      } 
    } 
  }
  
  public boolean a(long paramLong, JSONObject paramJSONObject) {
    boolean bool = false;
    if (paramJSONObject != null) {
      if (paramJSONObject.length() <= 0)
        return false; 
      try {
        String str = e.c();
        File file = new File(o.a(this.b), o.a(i.e()));
        i.a(file, file.getName(), str, paramJSONObject, e.a());
        paramJSONObject.put("upload_scene", "direct");
        r.a(paramJSONObject);
        if (e.b(str, paramJSONObject.toString()).a()) {
          i.a(file);
          bool = true;
        } 
        return bool;
      } catch (Throwable throwable) {
        q.b(throwable);
      } 
    } 
    return false;
  }
  
  public boolean a(JSONObject paramJSONObject, File paramFile1, File paramFile2) {
    try {
      String str = e.g();
      r.a(paramJSONObject);
      return e.a(str, paramJSONObject.toString(), new File[] { paramFile1, paramFile2, r.a(System.currentTimeMillis()), new File(b.a()) }).a();
    } catch (Throwable throwable) {
      q.b(throwable);
      return false;
    } 
  }
  
  public void b(JSONObject paramJSONObject) {
    if (paramJSONObject != null) {
      if (paramJSONObject.length() == 0)
        return; 
      p.b().a(new Runnable(this, paramJSONObject) {
            public void run() {
              String str = e.c();
              try {
                this.a.put("upload_scene", "direct");
              } catch (JSONException jSONException) {
                jSONException.printStackTrace();
              } 
              e.b(str, this.a.toString());
            }
          });
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\k\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */