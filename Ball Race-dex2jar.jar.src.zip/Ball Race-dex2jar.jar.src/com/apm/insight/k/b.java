package com.apm.insight.k;

import android.content.Context;
import android.text.TextUtils;
import androidx.annotation.Nullable;
import com.apm.insight.CrashType;
import com.apm.insight.Npth;
import com.apm.insight.c;
import com.apm.insight.d;
import com.apm.insight.entity.Header;
import com.apm.insight.entity.d;
import com.apm.insight.entity.e;
import com.apm.insight.i;
import com.apm.insight.l.i;
import com.apm.insight.l.l;
import com.apm.insight.l.o;
import com.apm.insight.l.p;
import com.apm.insight.l.w;
import com.apm.insight.nativecrash.NativeImpl;
import com.apm.insight.nativecrash.c;
import com.apm.insight.nativecrash.d;
import com.apm.insight.runtime.h;
import com.apm.insight.runtime.k;
import com.apm.insight.runtime.p;
import com.apm.insight.runtime.q;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public final class b {
  private static volatile b d;
  
  List<File> a = new ArrayList<File>();
  
  List<File> b = new ArrayList<File>();
  
  private Context c;
  
  private int e = -1;
  
  private b f;
  
  private HashMap<String, b> g;
  
  private volatile boolean h = false;
  
  private Runnable i = new Runnable(this) {
      public void run() {
        b.a(this.a);
      }
    };
  
  private Runnable j = new Runnable(this) {
      public void run() {
        b.b(this.a);
      }
    };
  
  private b(Context paramContext) {
    this.c = paramContext;
  }
  
  @Nullable
  private e a(File paramFile, CrashType paramCrashType, String paramString, long paramLong1, long paramLong2) {
    try {
      boolean bool = paramFile.isFile();
      if (bool) {
        try {
          i.a(paramFile);
          return null;
        } catch (Throwable null) {}
      } else {
        boolean bool1;
        CrashType crashType = CrashType.LAUNCH;
        if (throwable == crashType) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (throwable == null) {
          try {
            String str = paramFile.getName();
            return i.d((new File(paramFile, str)).getAbsolutePath());
          } catch (Throwable throwable1) {}
        } else {
          e e1;
          e e2 = i.a(paramFile, (CrashType)throwable1);
          try {
            JSONObject jSONObject = e2.b();
            if (e2.b() != null) {
              JSONObject jSONObject1;
              if (throwable1 == CrashType.ANR)
                return e2; 
              jSONObject.put("crash_time", paramLong1);
              jSONObject.put("app_start_time", paramLong2);
              JSONObject jSONObject2 = jSONObject.optJSONObject("header");
              if (jSONObject2 == null) {
                jSONObject1 = Header.a(this.c, paramLong1).f();
              } else {
                jSONObject1 = jSONObject2;
                if (bool1) {
                  jSONObject.remove("header");
                  jSONObject1 = jSONObject2;
                } 
              } 
              String str2 = jSONObject1.optString("sdk_version_name", null);
              String str1 = str2;
              if (str2 == null)
                str1 = "1.3.8.nourl-alpha.9"; 
              com.apm.insight.entity.a.a(jSONObject, "filters", "sdk_version", str1);
              if (i.a(jSONObject.optJSONArray("logcat")))
                jSONObject.put("logcat", k.b(paramString)); 
              com.apm.insight.entity.a.a(jSONObject, "filters", "has_dump", "true");
              if (!l.a(jSONObject, "logcat")) {
                bool = true;
              } else {
                bool = false;
              } 
              com.apm.insight.entity.a.a(jSONObject, "filters", "has_logcat", String.valueOf(bool));
              com.apm.insight.entity.a.a(jSONObject, "filters", "memory_leak", String.valueOf(com.apm.insight.entity.a.b(paramString)));
              com.apm.insight.entity.a.a(jSONObject, "filters", "fd_leak", String.valueOf(com.apm.insight.entity.a.c(paramString)));
              com.apm.insight.entity.a.a(jSONObject, "filters", "threads_leak", String.valueOf(com.apm.insight.entity.a.d(paramString)));
              com.apm.insight.entity.a.a(jSONObject, "filters", "is_64_devices", String.valueOf(Header.a()));
              com.apm.insight.entity.a.a(jSONObject, "filters", "is_64_runtime", String.valueOf(NativeImpl.e()));
              com.apm.insight.entity.a.a(jSONObject, "filters", "is_x86_devices", String.valueOf(Header.b()));
              com.apm.insight.entity.a.a(jSONObject, "filters", "has_meminfo_file", String.valueOf(com.apm.insight.entity.a.a(paramString)));
              com.apm.insight.entity.a.a(jSONObject, "filters", "is_root", String.valueOf(c.m()));
              jSONObject.put("launch_did", com.apm.insight.i.a.a(this.c));
              jSONObject.put("crash_uuid", paramFile.getName());
              jSONObject.put("jiffy", q.a.a());
              try {
                paramLong2 = Long.parseLong(com.apm.insight.runtime.b.a(paramLong1, paramString));
                if (Math.abs(paramLong2 - paramLong1) < 60000L) {
                  paramString = "< 60s";
                } else {
                  paramString = "> 60s";
                } 
                com.apm.insight.entity.a.a(jSONObject, "filters", "lastAliveTime", paramString);
                jSONObject.put("lastAliveTime", String.valueOf(paramLong2));
              } catch (Throwable throwable3) {
                jSONObject.put("lastAliveTime", "unknown");
                com.apm.insight.entity.a.a(jSONObject, "filters", "lastAliveTime", "unknown");
              } 
              jSONObject.put("has_dump", "true");
              if (jSONObject.opt("storage") == null)
                com.apm.insight.entity.a.a(jSONObject, w.a(i.g())); 
              if (Header.b(jSONObject1))
                com.apm.insight.entity.a.a(jSONObject, "filters", "unauthentic_version", "unauthentic_version"); 
              d.b(jSONObject);
              e2.b().put("upload_scene", "launch_scan");
              if (bool1) {
                JSONObject jSONObject3 = new JSONObject();
                jSONObject.put("event_type", "start_crash");
                jSONObject.put("stack", jSONObject.remove("data"));
                jSONObject3.put("data", (new JSONArray()).put(jSONObject));
                jSONObject3.put("header", jSONObject1);
                e2.a(jSONObject3);
              } else {
                jSONObject.put("isJava", 1);
              } 
            } else {
              i.a(paramFile);
            } 
            return e2;
          } catch (Throwable throwable2) {
            e1 = e2;
          } 
          i.a(paramFile);
          c.a().a("NPTH_CATCH", throwable2);
          return e1;
        } 
      } 
      paramString = null;
    } catch (Throwable throwable) {
      paramString = null;
    } 
    i.a(paramFile);
    c.a().a("NPTH_CATCH", throwable);
    return (e)paramString;
  }
  
  public static b a() {
    // Byte code:
    //   0: getstatic com/apm/insight/k/b.d : Lcom/apm/insight/k/b;
    //   3: ifnonnull -> 40
    //   6: ldc com/apm/insight/k/b
    //   8: monitorenter
    //   9: getstatic com/apm/insight/k/b.d : Lcom/apm/insight/k/b;
    //   12: ifnonnull -> 28
    //   15: new com/apm/insight/k/b
    //   18: dup
    //   19: invokestatic g : ()Landroid/content/Context;
    //   22: invokespecial <init> : (Landroid/content/Context;)V
    //   25: putstatic com/apm/insight/k/b.d : Lcom/apm/insight/k/b;
    //   28: ldc com/apm/insight/k/b
    //   30: monitorexit
    //   31: goto -> 40
    //   34: astore_0
    //   35: ldc com/apm/insight/k/b
    //   37: monitorexit
    //   38: aload_0
    //   39: athrow
    //   40: getstatic com/apm/insight/k/b.d : Lcom/apm/insight/k/b;
    //   43: areturn
    // Exception table:
    //   from	to	target	type
    //   9	28	34	finally
    //   28	31	34	finally
    //   35	38	34	finally
  }
  
  private JSONObject a(c paramc) {
    JSONObject jSONObject = paramc.d();
    if (jSONObject != null) {
      JSONObject jSONObject1 = jSONObject;
      if (jSONObject.length() == 0) {
        if (i.d())
          paramc.l(); 
        if (!paramc.c()) {
          paramc.k();
          return null;
        } 
        if (!paramc.f()) {
          paramc.k();
          return null;
        } 
        if (paramc.g()) {
          paramc.k();
          return null;
        } 
        paramc.e();
        return paramc.j();
      } 
      return jSONObject1;
    } 
    if (i.d())
      paramc.l(); 
    if (!paramc.c()) {
      paramc.k();
      return null;
    } 
    if (!paramc.f()) {
      paramc.k();
      return null;
    } 
    if (paramc.g()) {
      paramc.k();
      return null;
    } 
    paramc.e();
    return paramc.j();
  }
  
  private void a(b paramb) {
    i.a(o.a(this.c, paramb.a));
  }
  
  private void a(b paramb, boolean paramBoolean, @Nullable h paramh) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Ljava/util/List;
    //   4: invokeinterface isEmpty : ()Z
    //   9: ifeq -> 13
    //   12: return
    //   13: aload_1
    //   14: getfield e : Lcom/apm/insight/k/b$a;
    //   17: ifnonnull -> 28
    //   20: aload_1
    //   21: aload_1
    //   22: getfield d : Lcom/apm/insight/k/b$a;
    //   25: putfield e : Lcom/apm/insight/k/b$a;
    //   28: aload_1
    //   29: getfield b : Ljava/util/List;
    //   32: invokeinterface iterator : ()Ljava/util/Iterator;
    //   37: astore #10
    //   39: aload #10
    //   41: invokeinterface hasNext : ()Z
    //   46: ifeq -> 602
    //   49: aload #10
    //   51: invokeinterface next : ()Ljava/lang/Object;
    //   56: checkcast com/apm/insight/k/b$a
    //   59: astore #14
    //   61: aload #14
    //   63: getfield a : Ljava/io/File;
    //   66: astore #9
    //   68: aload #14
    //   70: getfield d : Lcom/apm/insight/CrashType;
    //   73: astore #15
    //   75: aload_1
    //   76: getfield a : Ljava/lang/String;
    //   79: astore #11
    //   81: aload #14
    //   83: getfield b : J
    //   86: lstore #5
    //   88: aload #14
    //   90: getfield c : J
    //   93: lstore #7
    //   95: aload_0
    //   96: aload #9
    //   98: aload #15
    //   100: aload #11
    //   102: lload #5
    //   104: lload #7
    //   106: invokespecial a : (Ljava/io/File;Lcom/apm/insight/CrashType;Ljava/lang/String;JJ)Lcom/apm/insight/entity/e;
    //   109: astore #16
    //   111: aload #16
    //   113: ifnonnull -> 125
    //   116: aload #9
    //   118: invokestatic a : (Ljava/io/File;)Z
    //   121: pop
    //   122: goto -> 599
    //   125: aload #16
    //   127: invokevirtual b : ()Lorg/json/JSONObject;
    //   130: astore #12
    //   132: aload #12
    //   134: ifnonnull -> 140
    //   137: goto -> 116
    //   140: aload #12
    //   142: ldc 'header'
    //   144: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   147: astore #17
    //   149: aload #17
    //   151: ifnonnull -> 157
    //   154: goto -> 116
    //   157: aload #15
    //   159: ifnonnull -> 608
    //   162: aload #9
    //   164: invokevirtual getName : ()Ljava/lang/String;
    //   167: astore #13
    //   169: aload #9
    //   171: astore #11
    //   173: new java/io/File
    //   176: dup
    //   177: aload #11
    //   179: aload #13
    //   181: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   184: invokevirtual exists : ()Z
    //   187: ifne -> 206
    //   190: aload #11
    //   192: invokevirtual getName : ()Ljava/lang/String;
    //   195: ldc_w '_'
    //   198: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   201: arraylength
    //   202: iconst_5
    //   203: if_icmpge -> 234
    //   206: aload #16
    //   208: invokevirtual a : ()Ljava/lang/String;
    //   211: aload #12
    //   213: invokevirtual toString : ()Ljava/lang/String;
    //   216: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)Lcom/apm/insight/k/l;
    //   219: invokevirtual a : ()Z
    //   222: ifeq -> 599
    //   225: aload #9
    //   227: invokestatic a : (Ljava/io/File;)Z
    //   230: pop
    //   231: goto -> 599
    //   234: aload #9
    //   236: astore #13
    //   238: aload #13
    //   240: invokestatic a : (Ljava/io/File;)Ljava/io/File;
    //   243: astore #11
    //   245: aload #11
    //   247: invokevirtual exists : ()Z
    //   250: istore #4
    //   252: iload #4
    //   254: ifne -> 260
    //   257: goto -> 225
    //   260: new org/json/JSONArray
    //   263: dup
    //   264: aload #11
    //   266: invokestatic c : (Ljava/io/File;)Ljava/lang/String;
    //   269: invokespecial <init> : (Ljava/lang/String;)V
    //   272: astore #18
    //   274: aload #15
    //   276: getstatic com/apm/insight/CrashType.LAUNCH : Lcom/apm/insight/CrashType;
    //   279: if_acmpne -> 302
    //   282: aload #12
    //   284: ldc_w 'data'
    //   287: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   290: checkcast org/json/JSONArray
    //   293: iconst_0
    //   294: invokevirtual optJSONObject : (I)Lorg/json/JSONObject;
    //   297: astore #9
    //   299: goto -> 306
    //   302: aload #12
    //   304: astore #9
    //   306: iload_2
    //   307: ifne -> 319
    //   310: aload_1
    //   311: getfield e : Lcom/apm/insight/k/b$a;
    //   314: aload #14
    //   316: if_acmpne -> 337
    //   319: aload #14
    //   321: getfield e : Ljava/lang/String;
    //   324: ldc_w 'ignore'
    //   327: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   330: istore #4
    //   332: iload #4
    //   334: ifeq -> 421
    //   337: aload #9
    //   339: ldc 'filters'
    //   341: ldc_w 'aid'
    //   344: aload #17
    //   346: ldc_w 'aid'
    //   349: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   352: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   355: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   358: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   361: aload #9
    //   363: ldc 'filters'
    //   365: ldc_w 'has_ignore'
    //   368: aload #14
    //   370: getfield e : Ljava/lang/String;
    //   373: ldc_w 'ignore'
    //   376: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   379: invokestatic valueOf : (Z)Ljava/lang/String;
    //   382: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   385: aload #17
    //   387: ldc_w 'aid'
    //   390: sipush #2010
    //   393: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   396: pop
    //   397: goto -> 455
    //   400: astore #11
    //   402: goto -> 407
    //   405: astore #11
    //   407: invokestatic a : ()Lcom/apm/insight/d;
    //   410: ldc_w 'NPTH_CATCH'
    //   413: aload #11
    //   415: invokevirtual a : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   418: goto -> 455
    //   421: aload_3
    //   422: ifnull -> 455
    //   425: aload_3
    //   426: aload #9
    //   428: ldc_w 'crash_md5'
    //   431: ldc_w 'default'
    //   434: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   437: invokevirtual a : (Ljava/lang/String;)Z
    //   440: ifne -> 455
    //   443: aload #14
    //   445: getfield a : Ljava/io/File;
    //   448: invokestatic a : (Ljava/io/File;)Z
    //   451: pop
    //   452: goto -> 599
    //   455: aload #9
    //   457: ldc 'filters'
    //   459: ldc_w 'start_uuid'
    //   462: aload_1
    //   463: getfield a : Ljava/lang/String;
    //   466: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   469: aload #9
    //   471: ldc 'filters'
    //   473: ldc_w 'leak_threads_count'
    //   476: aload_1
    //   477: getfield g : I
    //   480: invokestatic valueOf : (I)Ljava/lang/String;
    //   483: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   486: aload #9
    //   488: ldc 'filters'
    //   490: ldc_w 'crash_thread_name'
    //   493: aload #9
    //   495: ldc_w 'crash_thread_name'
    //   498: ldc_w 'unknown'
    //   501: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   504: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   507: aload #12
    //   509: invokestatic a : (Lorg/json/JSONObject;)V
    //   512: aload #12
    //   514: aload #18
    //   516: new com/apm/insight/k/b$3
    //   519: dup
    //   520: aload_0
    //   521: aload #16
    //   523: aload #13
    //   525: aload_1
    //   526: invokespecial <init> : (Lcom/apm/insight/k/b;Lcom/apm/insight/entity/e;Ljava/io/File;Lcom/apm/insight/k/b$b;)V
    //   529: invokestatic a : (Lorg/json/JSONObject;Lorg/json/JSONArray;Lcom/apm/insight/entity/b$a;)V
    //   532: aload #13
    //   534: invokestatic a : (Ljava/io/File;)Z
    //   537: ifne -> 554
    //   540: invokestatic a : ()Lcom/apm/insight/e/a;
    //   543: aload #13
    //   545: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   548: invokestatic a : (Ljava/lang/String;)Lcom/apm/insight/e/a/a;
    //   551: invokevirtual a : (Lcom/apm/insight/e/a/a;)V
    //   554: aload #15
    //   556: aload #12
    //   558: invokestatic a : (Lcom/apm/insight/CrashType;Lorg/json/JSONObject;)V
    //   561: goto -> 599
    //   564: astore #9
    //   566: goto -> 579
    //   569: goto -> 599
    //   572: astore #9
    //   574: goto -> 579
    //   577: astore #9
    //   579: invokestatic a : ()Lcom/apm/insight/d;
    //   582: ldc_w 'NPTH_CATCH'
    //   585: aload #9
    //   587: invokevirtual a : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   590: aload #14
    //   592: getfield a : Ljava/io/File;
    //   595: invokestatic a : (Ljava/io/File;)Z
    //   598: pop
    //   599: goto -> 39
    //   602: return
    //   603: astore #9
    //   605: goto -> 569
    //   608: goto -> 234
    // Exception table:
    //   from	to	target	type
    //   61	95	577	java/lang/Throwable
    //   95	111	572	java/lang/Throwable
    //   116	122	572	java/lang/Throwable
    //   125	132	572	java/lang/Throwable
    //   140	149	572	java/lang/Throwable
    //   162	169	572	java/lang/Throwable
    //   173	206	572	java/lang/Throwable
    //   206	225	572	java/lang/Throwable
    //   225	231	572	java/lang/Throwable
    //   238	252	572	java/lang/Throwable
    //   260	274	603	java/lang/Throwable
    //   274	299	572	java/lang/Throwable
    //   310	319	572	java/lang/Throwable
    //   319	332	572	java/lang/Throwable
    //   337	361	405	java/lang/Throwable
    //   361	397	400	java/lang/Throwable
    //   407	418	572	java/lang/Throwable
    //   425	452	572	java/lang/Throwable
    //   455	512	572	java/lang/Throwable
    //   512	554	564	java/lang/Throwable
    //   554	561	564	java/lang/Throwable
  }
  
  private void a(File paramFile, b paramb) {}
  
  private void a(HashMap<String, b> paramHashMap) {
    File[] arrayOfFile = o.f(this.c).listFiles();
    if (arrayOfFile != null) {
      if (arrayOfFile.length == 0)
        return; 
      int i = 0;
      while (true) {
        if (i < arrayOfFile.length && i < 5) {
          File file = arrayOfFile[i];
          try {
            if (file.isDirectory() && file.getName().endsWith("G")) {
              String str = file.getName();
              b b2 = paramHashMap.get(str);
              b b1 = b2;
              if (b2 == null) {
                b1 = new b(str);
                paramHashMap.put(str, b1);
              } 
              JSONArray jSONArray = d.a(o.l(file), o.m(file));
              b1.g = jSONArray.length();
              int j = b1.g;
              if (j > 0)
                try {
                  i.a(o.n(file), jSONArray, false);
                } catch (Throwable throwable) {} 
            } else {
              i.a(file);
            } 
          } catch (Throwable throwable) {
            c.a().a("NPTH_CATCH", throwable);
            i.a(file);
          } 
          i++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  private void a(HashMap<String, b> paramHashMap, b paramb) {
    File[] arrayOfFile = o.d(this.c).listFiles();
    if (arrayOfFile != null) {
      if (arrayOfFile.length == 0)
        return; 
      for (int i = 0; i < arrayOfFile.length && i < 5; i++) {
        File file = arrayOfFile[i];
        try {
          if (file.isDirectory() && file.getName().endsWith("G")) {
            String str = file.getName();
            b b1 = paramHashMap.get(str);
            paramb = b1;
            if (b1 == null) {
              paramb = new b(str);
              paramHashMap.put(str, paramb);
            } 
            paramb.c.add(new a(file, CrashType.NATIVE));
          } else {
            i.a(file);
          } 
        } catch (Throwable throwable) {
          c.a().a("NPTH_CATCH", throwable);
          i.a(file);
        } 
      } 
    } 
  }
  
  private void a(HashMap<String, b> paramHashMap, b paramb, File paramFile, String paramString) {
    if (paramString.endsWith("G")) {
      CrashType crashType;
      String[] arrayOfString = paramString.split("_");
      int i = arrayOfString.length;
      String str = null;
      if (i < 5) {
        paramb.b.add(new a(paramFile, null));
        return;
      } 
      try {
        long l1 = Long.parseLong(arrayOfString[0]);
        long l2 = Long.parseLong(arrayOfString[4]);
        String str2 = arrayOfString[2];
        String str1 = arrayOfString[1];
        i = -1;
        int j = str1.hashCode();
        if (j != -1109843021) {
          if (j != 96741) {
            if (j == 3254818 && str1.equals("java"))
              i = 1; 
          } else if (str1.equals("anr")) {
            i = 2;
          } 
        } else if (str1.equals("launch")) {
          i = 0;
        } 
        if (i != 0) {
          if (i != 1) {
            if (i != 2) {
              str1 = str;
            } else {
              crashType = CrashType.ANR;
            } 
          } else {
            crashType = CrashType.JAVA;
          } 
        } else {
          crashType = CrashType.LAUNCH;
        } 
        b b2 = paramHashMap.get(str2);
        b b1 = b2;
        if (b2 == null) {
          b1 = new b(str2);
          paramHashMap.put(str2, b1);
        } 
        a a = new a(paramFile, l1, crashType);
        a.c = l2;
        if ((b1.d == null || b1.d.b > a.b) && crashType != null && crashType != CrashType.ANR && !paramString.contains("ignore"))
          b1.d = a; 
        b1.b.add(a);
        return;
      } catch (Throwable throwable) {
        ((b)crashType).b.add(new a(paramFile, null));
        d d = c.a();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("err format crashTime:");
        stringBuilder.append(paramString);
        d.a("NPTH_CATCH", new RuntimeException(stringBuilder.toString()));
        return;
      } 
    } 
    i.a(paramFile);
  }
  
  private boolean a(File paramFile) {
    String[] arrayOfString = paramFile.list();
    if (arrayOfString == null)
      return false; 
    int j = arrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str = arrayOfString[i];
      if (!TextUtils.isEmpty(str) && str.endsWith(""))
        return true; 
    } 
    return false;
  }
  
  private void b(b paramb, boolean paramBoolean, @Nullable h paramh) {
    // Byte code:
    //   0: aload_1
    //   1: getfield c : Ljava/util/List;
    //   4: invokeinterface size : ()I
    //   9: iconst_1
    //   10: if_icmple -> 16
    //   13: goto -> 37
    //   16: aload_1
    //   17: getfield c : Ljava/util/List;
    //   20: invokeinterface isEmpty : ()Z
    //   25: ifeq -> 37
    //   28: aload_1
    //   29: aload_1
    //   30: getfield d : Lcom/apm/insight/k/b$a;
    //   33: putfield e : Lcom/apm/insight/k/b$a;
    //   36: return
    //   37: aload_0
    //   38: getfield c : Landroid/content/Context;
    //   41: invokestatic b : (Landroid/content/Context;)Z
    //   44: istore #5
    //   46: aload_1
    //   47: aload_1
    //   48: getfield d : Lcom/apm/insight/k/b$a;
    //   51: putfield e : Lcom/apm/insight/k/b$a;
    //   54: new com/apm/insight/nativecrash/c
    //   57: dup
    //   58: aload_0
    //   59: getfield c : Landroid/content/Context;
    //   62: invokespecial <init> : (Landroid/content/Context;)V
    //   65: astore #9
    //   67: aload_1
    //   68: getfield c : Ljava/util/List;
    //   71: invokeinterface iterator : ()Ljava/util/Iterator;
    //   76: astore #10
    //   78: aload #10
    //   80: invokeinterface hasNext : ()Z
    //   85: ifeq -> 530
    //   88: aload #10
    //   90: invokeinterface next : ()Ljava/lang/Object;
    //   95: checkcast com/apm/insight/k/b$a
    //   98: astore #12
    //   100: aload #12
    //   102: getfield a : Ljava/io/File;
    //   105: astore #11
    //   107: aload #9
    //   109: aload #11
    //   111: invokevirtual a : (Ljava/io/File;)V
    //   114: aload_0
    //   115: aload #9
    //   117: invokespecial a : (Lcom/apm/insight/nativecrash/c;)Lorg/json/JSONObject;
    //   120: astore #8
    //   122: aload #8
    //   124: ifnull -> 553
    //   127: aload #8
    //   129: invokevirtual length : ()I
    //   132: ifne -> 138
    //   135: goto -> 553
    //   138: aload #8
    //   140: invokevirtual length : ()I
    //   143: istore #4
    //   145: iload #4
    //   147: ifeq -> 550
    //   150: iload_2
    //   151: ifne -> 327
    //   154: aload #8
    //   156: ldc 'crash_time'
    //   158: invokevirtual optLong : (Ljava/lang/String;)J
    //   161: lstore #6
    //   163: aload_1
    //   164: getfield e : Lcom/apm/insight/k/b$a;
    //   167: ifnonnull -> 204
    //   170: aload_1
    //   171: aload #12
    //   173: putfield e : Lcom/apm/insight/k/b$a;
    //   176: aload_1
    //   177: iconst_1
    //   178: putfield f : Z
    //   181: aload_3
    //   182: ifnull -> 534
    //   185: aload_3
    //   186: ldc_w 'default'
    //   189: invokevirtual a : (Ljava/lang/String;)Z
    //   192: ifne -> 534
    //   195: aload #9
    //   197: invokevirtual k : ()Z
    //   200: pop
    //   201: goto -> 531
    //   204: aload_1
    //   205: getfield f : Z
    //   208: ifne -> 542
    //   211: aload_1
    //   212: getfield e : Lcom/apm/insight/k/b$a;
    //   215: astore #13
    //   217: lload #6
    //   219: aload #13
    //   221: getfield b : J
    //   224: lcmp
    //   225: ifge -> 281
    //   228: aload_1
    //   229: aload #12
    //   231: putfield e : Lcom/apm/insight/k/b$a;
    //   234: aload_3
    //   235: ifnull -> 257
    //   238: aload_3
    //   239: ldc_w 'default'
    //   242: invokevirtual a : (Ljava/lang/String;)Z
    //   245: ifne -> 257
    //   248: aload #9
    //   250: invokevirtual k : ()Z
    //   253: pop
    //   254: goto -> 531
    //   257: aload_0
    //   258: aload #11
    //   260: invokespecial a : (Ljava/io/File;)Z
    //   263: ifne -> 273
    //   266: aload_0
    //   267: aload #11
    //   269: aload_1
    //   270: invokespecial a : (Ljava/io/File;Lcom/apm/insight/k/b$b;)V
    //   273: aload_1
    //   274: iconst_1
    //   275: putfield f : Z
    //   278: goto -> 344
    //   281: aload #8
    //   283: ldc 'filters'
    //   285: ldc_w 'aid'
    //   288: aload #8
    //   290: ldc 'header'
    //   292: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   295: ldc_w 'aid'
    //   298: invokevirtual opt : (Ljava/lang/String;)Ljava/lang/Object;
    //   301: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   304: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   307: aload #8
    //   309: ldc 'header'
    //   311: invokevirtual optJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   314: ldc_w 'aid'
    //   317: sipush #2010
    //   320: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   323: pop
    //   324: goto -> 344
    //   327: aload_3
    //   328: ifnull -> 344
    //   331: aload_3
    //   332: ldc_w 'default'
    //   335: invokevirtual a : (Ljava/lang/String;)Z
    //   338: ifne -> 344
    //   341: goto -> 494
    //   344: aload #8
    //   346: ldc 'filters'
    //   348: ldc_w 'start_uuid'
    //   351: aload_1
    //   352: getfield a : Ljava/lang/String;
    //   355: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   358: aload #8
    //   360: ldc 'filters'
    //   362: ldc_w 'crash_thread_name'
    //   365: aload #8
    //   367: ldc_w 'crash_thread_name'
    //   370: ldc_w 'unknown'
    //   373: invokevirtual optString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   376: invokestatic a : (Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   379: iload #5
    //   381: ifeq -> 483
    //   384: new com/apm/insight/k/c$a
    //   387: dup
    //   388: aload #8
    //   390: getstatic com/apm/insight/CrashType.NATIVE : Lcom/apm/insight/CrashType;
    //   393: invokespecial <init> : (Lorg/json/JSONObject;Lcom/apm/insight/CrashType;)V
    //   396: astore #12
    //   398: invokestatic a : ()Lcom/apm/insight/runtime/s;
    //   401: astore #13
    //   403: aload #12
    //   405: invokevirtual b : ()J
    //   408: ldc2_w -1
    //   411: lcmp
    //   412: ifne -> 423
    //   415: invokestatic currentTimeMillis : ()J
    //   418: lstore #6
    //   420: goto -> 430
    //   423: aload #12
    //   425: invokevirtual b : ()J
    //   428: lstore #6
    //   430: aload #13
    //   432: lload #6
    //   434: invokevirtual b : (J)Lorg/json/JSONArray;
    //   437: astore #13
    //   439: aload #8
    //   441: aload #12
    //   443: invokevirtual c : ()Ljava/lang/String;
    //   446: aload #12
    //   448: invokevirtual a : ()Ljava/lang/String;
    //   451: aload #13
    //   453: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONArray;)Lorg/json/JSONArray;
    //   456: new com/apm/insight/k/b$4
    //   459: dup
    //   460: aload_0
    //   461: aload #11
    //   463: aload_1
    //   464: invokespecial <init> : (Lcom/apm/insight/k/b;Ljava/io/File;Lcom/apm/insight/k/b$b;)V
    //   467: invokestatic a : (Lorg/json/JSONObject;Lorg/json/JSONArray;Lcom/apm/insight/entity/b$a;)V
    //   470: aload #9
    //   472: invokevirtual k : ()Z
    //   475: ifne -> 483
    //   478: aload #9
    //   480: invokevirtual h : ()V
    //   483: getstatic com/apm/insight/CrashType.NATIVE : Lcom/apm/insight/CrashType;
    //   486: aload #8
    //   488: invokestatic a : (Lcom/apm/insight/CrashType;Lorg/json/JSONObject;)V
    //   491: goto -> 527
    //   494: aload #9
    //   496: invokevirtual k : ()Z
    //   499: pop
    //   500: goto -> 527
    //   503: astore #8
    //   505: goto -> 510
    //   508: astore #8
    //   510: invokestatic a : ()Lcom/apm/insight/d;
    //   513: ldc_w 'NPTH_CATCH'
    //   516: aload #8
    //   518: invokevirtual a : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   521: aload #11
    //   523: invokestatic a : (Ljava/io/File;)Z
    //   526: pop
    //   527: goto -> 78
    //   530: return
    //   531: goto -> 78
    //   534: goto -> 344
    //   537: astore #8
    //   539: goto -> 547
    //   542: goto -> 281
    //   545: astore #8
    //   547: goto -> 510
    //   550: goto -> 527
    //   553: goto -> 494
    // Exception table:
    //   from	to	target	type
    //   107	122	508	java/lang/Throwable
    //   127	135	508	java/lang/Throwable
    //   138	145	508	java/lang/Throwable
    //   154	163	508	java/lang/Throwable
    //   163	176	545	java/lang/Throwable
    //   176	181	508	java/lang/Throwable
    //   185	201	545	java/lang/Throwable
    //   204	217	545	java/lang/Throwable
    //   217	234	537	java/lang/Throwable
    //   238	254	537	java/lang/Throwable
    //   257	273	537	java/lang/Throwable
    //   273	278	503	java/lang/Throwable
    //   281	324	503	java/lang/Throwable
    //   331	341	503	java/lang/Throwable
    //   344	379	503	java/lang/Throwable
    //   384	420	503	java/lang/Throwable
    //   423	430	503	java/lang/Throwable
    //   430	483	503	java/lang/Throwable
    //   483	491	503	java/lang/Throwable
    //   494	500	503	java/lang/Throwable
  }
  
  private void b(HashMap<String, b> paramHashMap, b paramb) {
    File[] arrayOfFile = o.a(this.c).listFiles();
    if (arrayOfFile == null)
      return; 
    Arrays.sort(arrayOfFile, Collections.reverseOrder());
    for (int i = 0; i < arrayOfFile.length; i++) {
      File file = arrayOfFile[i];
      try {
        if (!com.apm.insight.e.a.a().a(file.getAbsolutePath())) {
          if (i.g(file) || com.apm.insight.g.a.a().b(file.getName()))
            continue; 
          if (!file.isFile()) {
            a(paramHashMap, paramb, file, file.getName());
            continue;
          } 
        } 
        i.a(file);
      } catch (Throwable throwable) {
        c.a().a("NPTH_CATCH", throwable);
      } 
      continue;
    } 
  }
  
  private void c(HashMap<String, b> paramHashMap, b paramb) {
    i.a(o.b(this.c));
  }
  
  private void d() {
    if (this.f != null)
      return; 
    this.f = new b("old_uuid");
    this.g = new HashMap<String, b>();
    a(this.g);
    b(this.g, this.f);
    c(this.g, this.f);
    a(this.g, this.f);
    b(this.f, true, null);
    a(this.f, true, null);
    this.f = null;
    if (this.g.isEmpty()) {
      f();
      return;
    } 
    g();
  }
  
  private void e() {
    if (!this.h) {
      if (this.g == null)
        return; 
      if (!p.b(this.c))
        f(); 
      boolean bool = h();
      h h = new h(this.c);
      Iterator<b> iterator = this.g.values().iterator();
      while (iterator.hasNext())
        b(iterator.next(), bool, h); 
      iterator = this.g.values().iterator();
      while (iterator.hasNext())
        a(iterator.next(), bool, h); 
      iterator = this.g.values().iterator();
      while (iterator.hasNext())
        a(iterator.next()); 
      h.a();
      com.apm.insight.runtime.b.a();
      f();
    } 
  }
  
  private void f() {
    this.h = true;
    this.g = null;
    NativeImpl.i();
  }
  
  private void g() {
    if (this.h)
      return; 
    if (p.b(this.c) && (System.currentTimeMillis() - i.j() > 5000L || !i.i().isApmExists() || Npth.hasCrash())) {
      e();
      return;
    } 
    p.b().a(this.i, 5000L);
  }
  
  private boolean h() {
    int i = this.e;
    boolean bool = false;
    if (i == -1)
      if (com.apm.insight.runtime.a.b() && com.apm.insight.runtime.a.g()) {
        this.e = 1;
      } else {
        this.e = 0;
      }  
    if (this.e == 1)
      bool = true; 
    return bool;
  }
  
  private void i() {
    File[] arrayOfFile = o.i(this.c).listFiles();
    if (arrayOfFile == null)
      return; 
    for (int i = 0; i < arrayOfFile.length && i < 5; i++) {
      File file = arrayOfFile[i];
      if (file.getName().endsWith(".atmp")) {
        com.apm.insight.a.a.a().a(file.getAbsolutePath());
      } else {
        try {
          e e = i.e(file.getAbsolutePath());
          if (e != null) {
            if (e.b() != null)
              e.b().put("upload_scene", "launch_scan"); 
            if (e.a(e.d(), e.e(), e.d(), e.f(), e.g())) {
              i.a(file);
              i.a(e.c());
            } 
          } else {
            i.a(file);
          } 
        } catch (Throwable throwable) {
          c.a().a("NPTH_CATCH", throwable);
        } 
      } 
    } 
  }
  
  public void a(boolean paramBoolean) {
    if (Npth.isStopUpload())
      return; 
    if (paramBoolean) {
      d();
      i();
      com.apm.insight.c.a.a();
    } 
  }
  
  public void b() {
    try {
      if (!this.h) {
        if (!com.apm.insight.l.a.b(i.g()))
          return; 
        p.b().a(this.j);
      } 
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  public boolean c() {
    return this.h;
  }
  
  static class a {
    File a;
    
    long b = -1L;
    
    long c = -1L;
    
    @Nullable
    CrashType d;
    
    String e;
    
    a(File param1File, long param1Long, @Nullable CrashType param1CrashType) {
      this.a = param1File;
      this.b = param1Long;
      this.d = param1CrashType;
      this.e = param1File.getName();
    }
    
    a(File param1File, @Nullable CrashType param1CrashType) {
      this.a = param1File;
      this.d = param1CrashType;
      this.e = param1File.getName();
    }
  }
  
  static class b {
    String a;
    
    List<b.a> b = new ArrayList<b.a>();
    
    List<b.a> c = new ArrayList<b.a>();
    
    b.a d;
    
    b.a e;
    
    boolean f = false;
    
    int g = 0;
    
    b(String param1String) {
      this.a = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\k\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */