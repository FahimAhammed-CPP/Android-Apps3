package com.apm.insight.nativecrash;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import com.apm.insight.l.i;
import com.apm.insight.l.k;
import com.apm.insight.l.o;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;

public class d {
  public static int a(String paramString) {
    return (new a(o.b(paramString))).a();
  }
  
  @NonNull
  public static JSONArray a(File paramFile1, File paramFile2) {
    HashMap<String, List<String>> hashMap = (new d(paramFile1)).b();
    return (new e(paramFile2)).a(hashMap);
  }
  
  public static int b(String paramString) {
    return (new f(o.c(paramString))).a();
  }
  
  public static int c(String paramString) {
    return (new b(o.d(paramString))).a();
  }
  
  public static class a extends c {
    a(File param1File) {
      super(param1File);
    }
  }
  
  public static class b extends c {
    b(File param1File) {
      super(param1File);
    }
  }
  
  public static class c {
    protected File a;
    
    protected String b;
    
    protected String c;
    
    protected int d;
    
    public c(File param1File) {
      this.a = param1File;
    }
    
    public int a() {
      boolean bool = this.a.exists();
      int i = -1;
      if (bool) {
        String str2;
        Throwable throwable;
        if (!this.a.isFile())
          return -1; 
        Object object = null;
        String str1 = null;
        try {
          BufferedReader bufferedReader = new BufferedReader(new FileReader(this.a));
        } catch (Throwable null) {
        
        } finally {
          Exception exception;
          throwable = null;
          str2 = str1;
        } 
        str1 = str2;
        com.apm.insight.c.a().a("NPTH_CATCH", throwable);
        if (str2 != null)
          k.a((Closeable)str2); 
        return i;
      } 
      return -1;
    }
    
    public int a(String param1String) {
      int j = this.d;
      int i = j;
      if (param1String.startsWith(this.b)) {
        String[] arrayOfString = param1String.split(this.c);
        try {
          i = Integer.parseInt(arrayOfString[1].trim());
          j = i;
        } catch (NumberFormatException numberFormatException) {
          com.apm.insight.c.a().a("NPTH_CATCH", numberFormatException);
        } 
        i = j;
        if (j < 0)
          i = -2; 
      } 
      return i;
    }
  }
  
  public static class d extends c {
    d(File param1File) {
      super(param1File);
    }
    
    @NonNull
    public HashMap<String, List<String>> b() {
      JSONArray jSONArray;
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      try {
        jSONArray = i.b(this.a.getAbsolutePath());
        if (jSONArray == null)
          return (HashMap)hashMap; 
      } catch (IOException iOException) {
        return (HashMap)hashMap;
      } catch (Throwable throwable) {
        com.apm.insight.c.a().a("NPTH_CATCH", throwable);
        return (HashMap)hashMap;
      } 
      int i = 0;
      while (true) {
        if (i < jSONArray.length()) {
          String str = jSONArray.optString(i);
          if (!TextUtils.isEmpty(str) && str.startsWith("[tid:0") && str.endsWith("sigstack:0x0]")) {
            String str1;
            int j = str.indexOf("[routine:0x");
            int k = j + 11;
            int m = str.indexOf(']', k);
            if (j > 0) {
              str1 = str.substring(k, m);
            } else {
              str1 = "unknown addr";
            } 
            List<String> list2 = (List)hashMap.get(str1);
            List<String> list1 = list2;
            if (list2 == null) {
              list1 = new ArrayList();
              hashMap.put(str1, list1);
            } 
            list1.add(str);
          } 
          i++;
          continue;
        } 
        return (HashMap)hashMap;
      } 
    }
  }
  
  public static class e extends c {
    e(File param1File) {
      super(param1File);
    }
    
    @NonNull
    public JSONArray a(HashMap<String, List<String>> param1HashMap) {
      JSONArray jSONArray2;
      JSONArray jSONArray1 = new JSONArray();
      if (param1HashMap.isEmpty())
        return jSONArray1; 
      try {
        jSONArray2 = i.b(this.a.getAbsolutePath());
        if (jSONArray2 == null)
          return jSONArray1; 
      } catch (IOException null) {
        return jSONArray1;
      } catch (Throwable throwable) {
        com.apm.insight.c.a().a("NPTH_CATCH", throwable);
        return jSONArray1;
      } 
      for (int i = 0;; i++) {
        if (i < jSONArray2.length()) {
          String str = jSONArray2.optString(i);
          if (!TextUtils.isEmpty(str)) {
            String str1 = str.substring(2, str.indexOf(":"));
            if (throwable.containsKey(str1)) {
              List list = (List)throwable.get(str1);
              if (list != null) {
                for (String str2 : list) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append(str2);
                  stringBuilder.append(" ");
                  stringBuilder.append(str);
                  jSONArray1.put(stringBuilder.toString());
                } 
                throwable.remove(str1);
              } 
            } 
          } 
        } else {
          Iterator<List> iterator = throwable.values().iterator();
          while (iterator.hasNext()) {
            for (String str : iterator.next()) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append(str);
              stringBuilder.append("  0x000000:unknown");
              jSONArray1.put(stringBuilder.toString());
            } 
          } 
          return jSONArray1;
        } 
      } 
    }
  }
  
  public static class f extends c {
    f(File param1File) {
      super(param1File);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\nativecrash\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */