package com.apm.insight.f;

import android.text.TextUtils;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.apm.insight.CrashType;
import com.apm.insight.entity.a;
import com.apm.insight.entity.c;
import com.apm.insight.k.g;
import com.apm.insight.l.q;
import com.apm.insight.l.v;
import com.apm.insight.runtime.a.f;
import com.apm.insight.runtime.p;
import java.util.Map;
import org.json.JSONObject;

public final class b {
  @Nullable
  private static String a(StackTraceElement[] paramArrayOfStackTraceElement, int paramInt) {
    if (paramArrayOfStackTraceElement == null || paramArrayOfStackTraceElement.length <= 0)
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    while (paramInt < paramArrayOfStackTraceElement.length) {
      v.a(paramArrayOfStackTraceElement[paramInt], stringBuilder);
      paramInt++;
    } 
    return stringBuilder.toString();
  }
  
  public static void a(Object paramObject, Throwable paramThrowable, String paramString1, boolean paramBoolean, Map<String, String> paramMap, String paramString2, @NonNull String paramString3) {
    try {
      p.b().a(new Runnable(paramObject, paramThrowable, paramString1, paramBoolean, paramMap, paramString2, paramString3) {
            public void run() {
              b.b(this.a, this.b, this.c, this.d, this.e, this.f, this.g);
            }
          });
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  public static void a(Throwable paramThrowable, String paramString, boolean paramBoolean) {
    a(paramThrowable, paramString, paramBoolean, "core_exception_monitor");
  }
  
  public static void a(Throwable paramThrowable, String paramString1, boolean paramBoolean, @NonNull String paramString2) {
    a(paramThrowable, paramString1, paramBoolean, (Map<String, String>)null, paramString2);
  }
  
  public static void a(Throwable paramThrowable, String paramString1, boolean paramBoolean, Map<String, String> paramMap, @NonNull String paramString2) {
    try {
      p.b().a(new Runnable(paramThrowable, paramString1, paramBoolean, paramMap, paramString2) {
            public void run() {
              b.a((Object)null, this.a, this.b, this.c, this.d, this.e);
            }
          });
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  private static void a(Map<String, String> paramMap, c paramc) {
    try {
      JSONObject jSONObject = new JSONObject();
      if (paramMap != null) {
        for (String str : paramMap.keySet())
          jSONObject.put(str, paramMap.get(str)); 
        paramc.a("custom", jSONObject);
      } 
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  public static void a(StackTraceElement[] paramArrayOfStackTraceElement, int paramInt, @Nullable String paramString1, String paramString2, Map<String, String> paramMap) {
    try {
      p.b().a(new Runnable(paramArrayOfStackTraceElement, paramInt, paramString1, paramString2, paramMap) {
            public void run() {
              b.a(this.a, this.b, this.c, this.d, "core_exception_monitor", this.e);
            }
          });
      return;
    } catch (Throwable throwable) {
      return;
    } 
  }
  
  private static void b(Object paramObject, Throwable paramThrowable, String paramString1, boolean paramBoolean, Map<String, String> paramMap, @NonNull String paramString2) {
    c(paramObject, paramThrowable, paramString1, paramBoolean, paramMap, "EnsureNotReachHere", paramString2);
  }
  
  private static void b(StackTraceElement[] paramArrayOfStackTraceElement, int paramInt, @Nullable String paramString1, String paramString2, @NonNull String paramString3, Map<String, String> paramMap) {
    if (paramArrayOfStackTraceElement != null) {
      try {
        if (paramArrayOfStackTraceElement.length <= paramInt + 1)
          return; 
      } catch (Throwable throwable1) {
        q.b(throwable1);
        return;
      } 
    } else {
      return;
    } 
    Throwable throwable2 = throwable1[paramInt];
    if (throwable2 == null)
      return; 
    String str = a((StackTraceElement[])throwable1, paramInt);
    if (TextUtils.isEmpty(str))
      return; 
    c c = c.a((StackTraceElement)throwable2, str, paramString1, Thread.currentThread().getName(), true, paramString2, paramString3);
    a(paramMap, c);
    f.a().a(CrashType.ENSURE, (a)c);
    g.a(c);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[report] ");
    stringBuilder.append(paramString1);
    q.b(stringBuilder.toString());
  }
  
  private static void c(Object paramObject, Throwable paramThrowable, String paramString1, boolean paramBoolean, Map<String, String> paramMap, String paramString2, @NonNull String paramString3) {
    if (paramThrowable == null)
      return; 
    try {
      StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
      StackTraceElement stackTraceElement = arrayOfStackTraceElement[0];
      if (stackTraceElement == null)
        return; 
      String str = v.a(paramThrowable);
      if (TextUtils.isEmpty(str))
        return; 
      c c = c.a(stackTraceElement, str, paramString1, Thread.currentThread().getName(), paramBoolean, paramString2, paramString3);
      if (paramObject != null)
        c.a("exception_line_num", com.apm.insight.entity.b.a(paramObject, paramThrowable, arrayOfStackTraceElement)); 
      a(paramMap, c);
      f.a().a(CrashType.ENSURE, (a)c);
      g.a(paramObject, c);
      paramObject = new StringBuilder();
      paramObject.append("[reportException] ");
      paramObject.append(paramString1);
      q.b(paramObject.toString());
      return;
    } catch (Throwable throwable) {
      q.b(throwable);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */