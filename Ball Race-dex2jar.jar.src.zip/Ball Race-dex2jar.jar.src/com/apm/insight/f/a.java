package com.apm.insight.f;

public class a {
  private static boolean a;
  
  public static void a() {
    if (a)
      return; 
    a = true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\apm\insight\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */