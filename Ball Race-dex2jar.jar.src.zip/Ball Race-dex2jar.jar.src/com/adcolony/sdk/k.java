package com.adcolony.sdk;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import androidx.annotation.NonNull;
import com.iab.omid.library.adcolony.Omid;
import com.iab.omid.library.adcolony.adsession.Partner;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;

class k {
  static String Z = "https://adc3-launch.adcolony.com/v4/launch";
  
  private static volatile String a0 = "";
  
  private boolean A;
  
  private boolean B;
  
  private boolean C;
  
  private f D = new f();
  
  private boolean E;
  
  private boolean F;
  
  private boolean G;
  
  private boolean H;
  
  private boolean I;
  
  private boolean J;
  
  private boolean K;
  
  private boolean L;
  
  private int M;
  
  private int N = 1;
  
  private Application.ActivityLifecycleCallbacks O;
  
  private Partner P = null;
  
  private f1 Q = new f1();
  
  private long R = 500L;
  
  private long S = 500L;
  
  private boolean T;
  
  private long U = 20000L;
  
  private long V = 300000L;
  
  private long W = 15000L;
  
  private int X;
  
  private boolean Y = false;
  
  private i0 a;
  
  private t b;
  
  private t0 c;
  
  private d d;
  
  private r e;
  
  private w f;
  
  private x0 g;
  
  private v0 h;
  
  private g0 i;
  
  private q j;
  
  private m0 k;
  
  private c l;
  
  private z m;
  
  private AdColonyAdView n;
  
  private AdColonyInterstitial o;
  
  private AdColonyRewardListener p;
  
  private HashMap<String, AdColonyCustomMessageListener> q = new HashMap<String, AdColonyCustomMessageListener>();
  
  private AdColonyAppOptions r;
  
  private h0 s;
  
  private f1 t;
  
  private HashMap<String, AdColonyZone> u = new HashMap<String, AdColonyZone>();
  
  private HashMap<Integer, c1> v = new HashMap<Integer, c1>();
  
  private String w;
  
  private String x;
  
  private String y;
  
  private String z = "";
  
  private void K() {
    (new Thread(new j(this))).start();
  }
  
  private boolean L() {
    this.a.a();
    return true;
  }
  
  private void M() {
    f1 f11 = c0.b();
    c0.a(f11, "type", "AdColony.on_configuration_completed");
    e1 e1 = new e1();
    Iterator<String> iterator = C().keySet().iterator();
    while (iterator.hasNext())
      e1.b(iterator.next()); 
    f1 f12 = c0.b();
    c0.a(f12, "zone_ids", e1);
    c0.a(f11, "message", f12);
    (new h0("CustomMessage.controller_send", 0, f11)).c();
  }
  
  private void N() {
    if (!a(this.x) && !l.H) {
      (new e0.a()).a("Downloaded controller sha1 does not match, retrying.").a(e0.f);
      S();
      return;
    } 
    if (!this.F && !this.I)
      z0.b(new o(this)); 
    if (this.F && this.I)
      Q(); 
  }
  
  private void O() {
    Context context = a.a();
    if (context != null && this.O == null && Build.VERSION.SDK_INT > 14) {
      Application application;
      this.O = new t(this);
      if (context instanceof Application) {
        application = (Application)context;
      } else {
        application = ((Activity)application).getApplication();
      } 
      application.registerActivityLifecycleCallbacks(this.O);
    } 
  }
  
  private void S() {
    if (a.b().x().f()) {
      int i = this.M + 1;
      this.M = i;
      this.N = Math.min(this.N * i, 120);
      z0.a(new m(this), this.N * 1000L);
      return;
    } 
    (new e0.a()).a("Max launch server download attempts hit, or AdColony is no longer").a(" active.").a(e0.g);
  }
  
  private void a(h0 paramh0) {
    a(c0.d(paramh0.a(), "id"));
  }
  
  private void a(s params) {
    if (params.n) {
      f1 f11 = c0.a(params.m, "Parsing launch response");
      c0.a(f11, "sdkVersion", n().I());
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.h.a());
      stringBuilder.append("026ae9c9824b3e483fa6c71fa88f57ae27816141");
      c0.j(f11, stringBuilder.toString());
      if (!c(f11)) {
        if (!this.F) {
          (new e0.a()).a("Incomplete or disabled launch server response. ").a("Disabling AdColony until next launch.").a(e0.h);
          b(true);
        } 
        return;
      } 
      if (a(f11)) {
        f1 f12 = c0.b();
        c0.a(f12, "url", this.w);
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(this.h.a());
        stringBuilder1.append("7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5");
        c0.a(f12, "filepath", stringBuilder1.toString());
        this.b.a(new s(new h0("WebServices.download", 0, f12), new n(this)));
      } 
      this.t = f11;
      return;
    } 
    S();
  }
  
  private boolean a(f1 paramf1) {
    if (!this.F)
      return true; 
    f1 f11 = this.t;
    if (f11 != null && c0.h(c0.f(f11, "controller"), "sha1").equals(c0.h(c0.f(paramf1, "controller"), "sha1")))
      return false; 
    (new e0.a()).a("Controller sha1 does not match, downloading new controller.").a(e0.g);
    return true;
  }
  
  private boolean a(String paramString) {
    Context context = a.a();
    if (context != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(context.getFilesDir().getAbsolutePath());
      stringBuilder.append("/adc3/");
      stringBuilder.append("7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5");
      File file = new File(stringBuilder.toString());
      if (file.exists())
        return z0.a(paramString, file); 
    } 
    return false;
  }
  
  private boolean a(boolean paramBoolean) {
    return a(paramBoolean, false);
  }
  
  private boolean a(boolean paramBoolean1, boolean paramBoolean2) {
    if (!a.c())
      return false; 
    this.I = paramBoolean2;
    this.F = paramBoolean1;
    if (paramBoolean1 && !paramBoolean2) {
      if (!L())
        return false; 
      this.I = true;
    } 
    K();
    return true;
  }
  
  private void b() {
    int i = this.X - 1;
    this.X = i;
    if (i == 0)
      P(); 
  }
  
  private void b(f1 paramf1) {
    if (!l.H) {
      f1 f12 = c0.f(paramf1, "logging");
      g0.h = c0.a(f12, "send_level", 1);
      g0.f = c0.b(f12, "log_private");
      g0.g = c0.a(f12, "print_level", 3);
      this.i.b(c0.a(f12, "modules"));
      this.i.c(c0.e(f12, "included_fields"));
    } 
    f1 f11 = c0.f(paramf1, "metadata");
    n().a(f11);
    x().a(c0.d(f11, "session_timeout"));
    a0 = c0.h(paramf1, "pie");
    this.z = c0.h(c0.f(paramf1, "controller"), "version");
    this.R = c0.a(f11, "signals_timeout", this.R);
    this.S = c0.a(f11, "calculate_odt_timeout", this.S);
    this.T = c0.a(f11, "async_odt_query", this.T);
    this.U = c0.a(f11, "ad_request_timeout", this.U);
    this.V = c0.a(f11, "controller_heartbeat_interval", this.V);
    this.W = c0.a(f11, "controller_heartbeat_timeout", this.W);
    this.Y = c0.a(f11, "enable_compression", false);
    v.a().a(f11.n("odt_config"), new r(this));
  }
  
  private void b(h0 paramh0) {
    f1 f11 = this.r.b();
    c0.a(f11, "app_id", this.r.a());
    f1 f12 = c0.b();
    c0.a(f12, "options", f11);
    paramh0.a(f12).c();
  }
  
  private boolean c(f1 paramf1) {
    if (paramf1 == null)
      return false; 
    try {
      f1 f11 = c0.f(paramf1, "controller");
      this.w = c0.h(f11, "url");
      this.x = c0.h(f11, "sha1");
      this.y = c0.h(paramf1, "status");
      b(paramf1);
      if (AdColonyEventTracker.a())
        AdColonyEventTracker.b(); 
    } catch (Exception exception) {
      try {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.h.a());
        stringBuilder.append("026ae9c9824b3e483fa6c71fa88f57ae27816141");
        (new File(stringBuilder.toString())).delete();
      } catch (Exception exception1) {}
    } 
    if (this.y.equals("disable") && !l.H) {
      try {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.h.a());
        stringBuilder.append("7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5");
        (new File(stringBuilder.toString())).delete();
      } catch (Exception exception) {}
      (new e0.a()).a("Launch server response with disabled status. Disabling AdColony ").a("until next launch.").a(e0.g);
      AdColony.disable();
      return false;
    } 
    if ((this.w.equals("") || this.y.equals("")) && !l.H) {
      (new e0.a()).a("Missing controller status or URL. Disabling AdColony until next ").a("launch.").a(e0.i);
      return false;
    } 
    return true;
  }
  
  private boolean c(h0 paramh0) {
    Context context = a.a();
    if (context == null)
      return false; 
    try {
      int i = paramh0.a().j("id");
      if (i > 0)
        a(i); 
      z0.b(new l(this, context, paramh0));
      return true;
    } catch (RuntimeException runtimeException) {
      e0.a a = new e0.a();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(runtimeException.toString());
      stringBuilder.append(": during WebView initialization.");
      a.a(stringBuilder.toString()).a(" Disabling AdColony.").a(e0.h);
      AdColony.disable();
      return false;
    } 
  }
  
  private void f(h0 paramh0) {
    AdColonyZone adColonyZone;
    if (this.C)
      return; 
    String str = c0.h(paramh0.a(), "zone_id");
    if (this.u.containsKey(str)) {
      adColonyZone = this.u.get(str);
    } else {
      adColonyZone = new AdColonyZone(str);
      this.u.put(str, adColonyZone);
    } 
    adColonyZone.a(paramh0);
  }
  
  x0 A() {
    if (this.g == null) {
      x0 x01 = new x0();
      this.g = x01;
      x01.a();
    } 
    return this.g;
  }
  
  HashMap<Integer, c1> B() {
    return this.v;
  }
  
  HashMap<String, AdColonyZone> C() {
    return this.u;
  }
  
  boolean D() {
    return (this.r != null);
  }
  
  boolean E() {
    return this.B;
  }
  
  boolean F() {
    return this.C;
  }
  
  boolean G() {
    return this.T;
  }
  
  boolean H() {
    return this.Y;
  }
  
  boolean I() {
    return this.D.a();
  }
  
  boolean J() {
    return this.A;
  }
  
  void P() {
    this.D.a(false);
    this.d.b();
    Object object = this.r.getOption("force_ad_id");
    if (object instanceof String && !((String)object).isEmpty())
      R(); 
    AdColony.a(a.a(), this.r);
    T();
    this.u.clear();
    this.a.a();
  }
  
  void Q() {
    this.X = 0;
    for (AdColonyInterstitial adColonyInterstitial : this.d.f().values()) {
      if (adColonyInterstitial.m()) {
        this.X++;
        adColonyInterstitial.a(new p(this));
      } 
    } 
    for (AdColonyAdView adColonyAdView : this.d.d().values()) {
      this.X++;
      adColonyAdView.setOnDestroyListenerOrCall(new q(this));
    } 
    if (this.X == 0)
      P(); 
  }
  
  void R() {
    synchronized (this.d.f()) {
      Iterator<AdColonyInterstitial> iterator = this.d.f().values().iterator();
      while (iterator.hasNext())
        ((AdColonyInterstitial)iterator.next()).p(); 
      this.d.f().clear();
      return;
    } 
  }
  
  void T() {
    a(1);
    for (k0 k0 : this.v.values())
      this.a.b(k0); 
    this.v.clear();
  }
  
  void a() {
    this.d.a();
    P();
  }
  
  void a(long paramLong) {
    this.D.a(paramLong);
  }
  
  void a(AdColonyAdView paramAdColonyAdView) {
    this.n = paramAdColonyAdView;
  }
  
  void a(AdColonyAppOptions paramAdColonyAppOptions) {
    this.D.a(false);
    this.d.b();
    R();
    AdColony.a(a.a(), paramAdColonyAppOptions);
    T();
    this.u.clear();
    this.r = paramAdColonyAppOptions;
    this.a.a();
    a(true, true);
  }
  
  void a(AdColonyAppOptions paramAdColonyAppOptions, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iload_2
    //   2: putfield C : Z
    //   5: aload_0
    //   6: aload_1
    //   7: putfield r : Lcom/adcolony/sdk/AdColonyAppOptions;
    //   10: aload_0
    //   11: new com/adcolony/sdk/i0
    //   14: dup
    //   15: invokespecial <init> : ()V
    //   18: putfield a : Lcom/adcolony/sdk/i0;
    //   21: new com/adcolony/sdk/m
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: pop
    //   29: new com/adcolony/sdk/q
    //   32: dup
    //   33: invokespecial <init> : ()V
    //   36: astore #5
    //   38: aload_0
    //   39: aload #5
    //   41: putfield j : Lcom/adcolony/sdk/q;
    //   44: aload #5
    //   46: invokevirtual M : ()V
    //   49: new com/adcolony/sdk/t
    //   52: dup
    //   53: invokespecial <init> : ()V
    //   56: astore #5
    //   58: aload_0
    //   59: aload #5
    //   61: putfield b : Lcom/adcolony/sdk/t;
    //   64: aload #5
    //   66: invokevirtual a : ()V
    //   69: new com/adcolony/sdk/t0
    //   72: dup
    //   73: invokespecial <init> : ()V
    //   76: astore #5
    //   78: aload_0
    //   79: aload #5
    //   81: putfield c : Lcom/adcolony/sdk/t0;
    //   84: aload #5
    //   86: invokevirtual d : ()V
    //   89: new com/adcolony/sdk/d
    //   92: dup
    //   93: invokespecial <init> : ()V
    //   96: astore #5
    //   98: aload_0
    //   99: aload #5
    //   101: putfield d : Lcom/adcolony/sdk/d;
    //   104: aload #5
    //   106: invokevirtual h : ()V
    //   109: aload_0
    //   110: new com/adcolony/sdk/r
    //   113: dup
    //   114: invokespecial <init> : ()V
    //   117: putfield e : Lcom/adcolony/sdk/r;
    //   120: new com/adcolony/sdk/w
    //   123: dup
    //   124: invokespecial <init> : ()V
    //   127: astore #5
    //   129: aload_0
    //   130: aload #5
    //   132: putfield f : Lcom/adcolony/sdk/w;
    //   135: aload #5
    //   137: invokevirtual b : ()V
    //   140: new com/adcolony/sdk/g0
    //   143: dup
    //   144: invokespecial <init> : ()V
    //   147: astore #5
    //   149: aload_0
    //   150: aload #5
    //   152: putfield i : Lcom/adcolony/sdk/g0;
    //   155: aload #5
    //   157: invokevirtual c : ()V
    //   160: new com/adcolony/sdk/v0
    //   163: dup
    //   164: invokespecial <init> : ()V
    //   167: astore #5
    //   169: aload_0
    //   170: aload #5
    //   172: putfield h : Lcom/adcolony/sdk/v0;
    //   175: aload #5
    //   177: invokevirtual e : ()Z
    //   180: pop
    //   181: new com/adcolony/sdk/x0
    //   184: dup
    //   185: invokespecial <init> : ()V
    //   188: astore #5
    //   190: aload_0
    //   191: aload #5
    //   193: putfield g : Lcom/adcolony/sdk/x0;
    //   196: aload #5
    //   198: invokevirtual a : ()V
    //   201: aload_0
    //   202: new com/adcolony/sdk/m0
    //   205: dup
    //   206: invokespecial <init> : ()V
    //   209: putfield k : Lcom/adcolony/sdk/m0;
    //   212: aload_0
    //   213: new com/adcolony/sdk/z
    //   216: dup
    //   217: invokespecial <init> : ()V
    //   220: putfield m : Lcom/adcolony/sdk/z;
    //   223: aload_0
    //   224: getfield k : Lcom/adcolony/sdk/m0;
    //   227: invokevirtual b : ()V
    //   230: invokestatic a : ()Landroid/content/Context;
    //   233: aload_1
    //   234: invokestatic a : (Landroid/content/Context;Lcom/adcolony/sdk/AdColonyAppOptions;)V
    //   237: iconst_0
    //   238: istore #4
    //   240: iload_2
    //   241: ifne -> 495
    //   244: new java/lang/StringBuilder
    //   247: dup
    //   248: invokespecial <init> : ()V
    //   251: astore_1
    //   252: aload_1
    //   253: aload_0
    //   254: getfield h : Lcom/adcolony/sdk/v0;
    //   257: invokevirtual a : ()Ljava/lang/String;
    //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   263: pop
    //   264: aload_1
    //   265: ldc_w '026ae9c9824b3e483fa6c71fa88f57ae27816141'
    //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   271: pop
    //   272: aload_0
    //   273: new java/io/File
    //   276: dup
    //   277: aload_1
    //   278: invokevirtual toString : ()Ljava/lang/String;
    //   281: invokespecial <init> : (Ljava/lang/String;)V
    //   284: invokevirtual exists : ()Z
    //   287: putfield G : Z
    //   290: new java/lang/StringBuilder
    //   293: dup
    //   294: invokespecial <init> : ()V
    //   297: astore_1
    //   298: aload_1
    //   299: aload_0
    //   300: getfield h : Lcom/adcolony/sdk/v0;
    //   303: invokevirtual a : ()Ljava/lang/String;
    //   306: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: pop
    //   310: aload_1
    //   311: ldc_w '7bf3a1e7bbd31e612eda3310c2cdb8075c43c6b5'
    //   314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: pop
    //   318: new java/io/File
    //   321: dup
    //   322: aload_1
    //   323: invokevirtual toString : ()Ljava/lang/String;
    //   326: invokespecial <init> : (Ljava/lang/String;)V
    //   329: invokevirtual exists : ()Z
    //   332: istore_2
    //   333: aload_0
    //   334: iload_2
    //   335: putfield H : Z
    //   338: aload_0
    //   339: getfield G : Z
    //   342: ifeq -> 408
    //   345: iload_2
    //   346: ifeq -> 408
    //   349: new java/lang/StringBuilder
    //   352: dup
    //   353: invokespecial <init> : ()V
    //   356: astore_1
    //   357: aload_1
    //   358: aload_0
    //   359: getfield h : Lcom/adcolony/sdk/v0;
    //   362: invokevirtual a : ()Ljava/lang/String;
    //   365: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   368: pop
    //   369: aload_1
    //   370: ldc_w '026ae9c9824b3e483fa6c71fa88f57ae27816141'
    //   373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: pop
    //   377: aload_1
    //   378: invokevirtual toString : ()Ljava/lang/String;
    //   381: invokestatic c : (Ljava/lang/String;)Lcom/adcolony/sdk/f1;
    //   384: ldc_w 'sdkVersion'
    //   387: invokestatic h : (Lcom/adcolony/sdk/f1;Ljava/lang/String;)Ljava/lang/String;
    //   390: aload_0
    //   391: getfield j : Lcom/adcolony/sdk/q;
    //   394: invokevirtual I : ()Ljava/lang/String;
    //   397: invokevirtual equals : (Ljava/lang/Object;)Z
    //   400: ifeq -> 408
    //   403: iconst_1
    //   404: istore_2
    //   405: goto -> 410
    //   408: iconst_0
    //   409: istore_2
    //   410: aload_0
    //   411: iload_2
    //   412: putfield F : Z
    //   415: invokestatic a : ()Lcom/adcolony/sdk/v;
    //   418: new com/adcolony/sdk/k$k
    //   421: dup
    //   422: aload_0
    //   423: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   426: invokevirtual a : (Lcom/adcolony/sdk/v$c;)V
    //   429: aload_0
    //   430: getfield G : Z
    //   433: ifeq -> 482
    //   436: new java/lang/StringBuilder
    //   439: dup
    //   440: invokespecial <init> : ()V
    //   443: astore_1
    //   444: aload_1
    //   445: aload_0
    //   446: getfield h : Lcom/adcolony/sdk/v0;
    //   449: invokevirtual a : ()Ljava/lang/String;
    //   452: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   455: pop
    //   456: aload_1
    //   457: ldc_w '026ae9c9824b3e483fa6c71fa88f57ae27816141'
    //   460: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   463: pop
    //   464: aload_1
    //   465: invokevirtual toString : ()Ljava/lang/String;
    //   468: invokestatic c : (Ljava/lang/String;)Lcom/adcolony/sdk/f1;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield t : Lcom/adcolony/sdk/f1;
    //   477: aload_0
    //   478: aload_1
    //   479: invokespecial b : (Lcom/adcolony/sdk/f1;)V
    //   482: aload_0
    //   483: aload_0
    //   484: getfield F : Z
    //   487: invokespecial a : (Z)Z
    //   490: pop
    //   491: aload_0
    //   492: invokespecial O : ()V
    //   495: ldc_w 'Module.load'
    //   498: new com/adcolony/sdk/k$u
    //   501: dup
    //   502: aload_0
    //   503: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   506: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   509: ldc_w 'Module.unload'
    //   512: new com/adcolony/sdk/k$v
    //   515: dup
    //   516: aload_0
    //   517: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   520: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   523: ldc_w 'AdColony.on_configured'
    //   526: new com/adcolony/sdk/k$w
    //   529: dup
    //   530: aload_0
    //   531: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   534: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   537: ldc_w 'AdColony.get_app_info'
    //   540: new com/adcolony/sdk/k$x
    //   543: dup
    //   544: aload_0
    //   545: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   548: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   551: ldc_w 'AdColony.v4vc_reward'
    //   554: new com/adcolony/sdk/k$y
    //   557: dup
    //   558: aload_0
    //   559: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   562: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   565: ldc_w 'AdColony.zone_info'
    //   568: new com/adcolony/sdk/k$z
    //   571: dup
    //   572: aload_0
    //   573: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   576: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   579: ldc_w 'AdColony.probe_launch_server'
    //   582: new com/adcolony/sdk/k$a0
    //   585: dup
    //   586: aload_0
    //   587: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   590: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   593: ldc_w 'Crypto.sha1'
    //   596: new com/adcolony/sdk/k$b0
    //   599: dup
    //   600: aload_0
    //   601: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   604: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   607: ldc_w 'Crypto.crc32'
    //   610: new com/adcolony/sdk/k$a
    //   613: dup
    //   614: aload_0
    //   615: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   618: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   621: ldc_w 'Crypto.uuid'
    //   624: new com/adcolony/sdk/k$b
    //   627: dup
    //   628: aload_0
    //   629: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   632: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   635: ldc_w 'Device.query_advertiser_info'
    //   638: new com/adcolony/sdk/k$c
    //   641: dup
    //   642: aload_0
    //   643: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   646: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   649: ldc_w 'AdColony.controller_version'
    //   652: new com/adcolony/sdk/k$d
    //   655: dup
    //   656: aload_0
    //   657: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   660: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   663: ldc_w 'AdColony.provide_signals'
    //   666: new com/adcolony/sdk/k$e
    //   669: dup
    //   670: aload_0
    //   671: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   674: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   677: ldc_w 'AdColony.odt_calculate'
    //   680: new com/adcolony/sdk/k$f
    //   683: dup
    //   684: aload_0
    //   685: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   688: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   691: ldc_w 'AdColony.odt_cache'
    //   694: new com/adcolony/sdk/k$g
    //   697: dup
    //   698: aload_0
    //   699: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   702: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   705: ldc_w 'AdColony.heartbeat'
    //   708: new com/adcolony/sdk/k$h
    //   711: dup
    //   712: aload_0
    //   713: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   716: invokestatic a : (Ljava/lang/String;Lcom/adcolony/sdk/j0;)V
    //   719: aload_0
    //   720: getfield h : Lcom/adcolony/sdk/v0;
    //   723: invokestatic b : (Lcom/adcolony/sdk/v0;)I
    //   726: istore_3
    //   727: iload_3
    //   728: iconst_1
    //   729: if_icmpne -> 737
    //   732: iconst_1
    //   733: istore_2
    //   734: goto -> 739
    //   737: iconst_0
    //   738: istore_2
    //   739: aload_0
    //   740: iload_2
    //   741: putfield J : Z
    //   744: iload #4
    //   746: istore_2
    //   747: iload_3
    //   748: iconst_2
    //   749: if_icmpne -> 754
    //   752: iconst_1
    //   753: istore_2
    //   754: aload_0
    //   755: iload_2
    //   756: putfield K : Z
    //   759: new com/adcolony/sdk/k$i
    //   762: dup
    //   763: aload_0
    //   764: invokespecial <init> : (Lcom/adcolony/sdk/k;)V
    //   767: invokestatic b : (Ljava/lang/Runnable;)Z
    //   770: pop
    //   771: return
  }
  
  void a(AdColonyInterstitial paramAdColonyInterstitial) {
    this.o = paramAdColonyInterstitial;
  }
  
  void a(AdColonyRewardListener paramAdColonyRewardListener) {
    this.p = paramAdColonyRewardListener;
  }
  
  void a(c paramc) {
    this.l = paramc;
  }
  
  boolean a(int paramInt) {
    this.v.remove(Integer.valueOf(paramInt));
    return this.a.b(paramInt);
  }
  
  boolean a(k0 paramk0) {
    this.v.remove(Integer.valueOf(paramk0.getModuleId()));
    return this.a.b(paramk0);
  }
  
  void b(@NonNull AdColonyAppOptions paramAdColonyAppOptions) {
    this.r = paramAdColonyAppOptions;
  }
  
  void b(boolean paramBoolean) {
    this.D.a(false);
    this.C = paramBoolean;
  }
  
  d c() {
    if (this.d == null) {
      d d1 = new d();
      this.d = d1;
      d1.h();
    } 
    return this.d;
  }
  
  void c(boolean paramBoolean) {
    this.B = paramBoolean;
  }
  
  long d() {
    return this.U;
  }
  
  void d(h0 paramh0) {
    this.s = paramh0;
  }
  
  void d(boolean paramBoolean) {
    this.E = paramBoolean;
  }
  
  f1 e() {
    return this.Q;
  }
  
  void e(boolean paramBoolean) {
    this.A = paramBoolean;
  }
  
  boolean e(h0 paramh0) {
    if (this.p != null) {
      z0.b(new s(this, paramh0));
      return true;
    } 
    return false;
  }
  
  String f() {
    return this.z;
  }
  
  long g() {
    return this.S;
  }
  
  long h() {
    return this.V;
  }
  
  long i() {
    return this.W;
  }
  
  AdColonyInterstitial j() {
    return this.o;
  }
  
  AdColonyAdView k() {
    return this.n;
  }
  
  c l() {
    return this.l;
  }
  
  HashMap<String, AdColonyCustomMessageListener> m() {
    return this.q;
  }
  
  q n() {
    if (this.j == null) {
      q q1 = new q();
      this.j = q1;
      q1.M();
    } 
    return this.j;
  }
  
  r o() {
    if (this.e == null)
      this.e = new r(); 
    return this.e;
  }
  
  w p() {
    if (this.f == null) {
      w w1 = new w();
      this.f = w1;
      w1.b();
    } 
    return this.f;
  }
  
  g0 q() {
    if (this.i == null) {
      g0 g01 = new g0();
      this.i = g01;
      g01.c();
    } 
    return this.i;
  }
  
  i0 r() {
    if (this.a == null) {
      i0 i01 = new i0();
      this.a = i01;
      i01.a();
    } 
    return this.a;
  }
  
  m0 s() {
    if (this.k == null)
      this.k = new m0(); 
    return this.k;
  }
  
  Partner t() {
    return this.P;
  }
  
  AdColonyAppOptions u() {
    if (this.r == null)
      this.r = new AdColonyAppOptions(); 
    return this.r;
  }
  
  String v() {
    return a0;
  }
  
  AdColonyRewardListener w() {
    return this.p;
  }
  
  t0 x() {
    if (this.c == null) {
      t0 t01 = new t0();
      this.c = t01;
      t01.d();
    } 
    return this.c;
  }
  
  long y() {
    return this.R;
  }
  
  v0 z() {
    if (this.h == null) {
      v0 v01 = new v0();
      this.h = v01;
      v01.e();
    } 
    return this.h;
  }
  
  class a implements j0 {
    a(k this$0) {}
    
    public void a(h0 param1h0) {
      f1 f1 = c0.b();
      c0.b(f1, "crc32", z0.a(c0.h(param1h0.a(), "data")));
      param1h0.a(f1).c();
    }
  }
  
  class a0 implements j0 {
    a0(k this$0) {}
    
    public void a(h0 param1h0) {
      k.a(this.a, true, true);
    }
  }
  
  class b implements j0 {
    b(k this$0) {}
    
    public void a(h0 param1h0) {
      int i = c0.d(param1h0.a(), "number");
      f1 f1 = c0.b();
      c0.a(f1, "uuids", z0.a(i));
      param1h0.a(f1).c();
    }
  }
  
  class b0 implements j0 {
    b0(k this$0) {}
    
    public void a(h0 param1h0) {
      f1 f1 = c0.b();
      c0.a(f1, "sha1", z0.b(c0.h(param1h0.a(), "data")));
      param1h0.a(f1).c();
    }
  }
  
  class c implements j0 {
    c(k this$0) {}
    
    public void a(h0 param1h0) {
      this.a.n().a(a.a(), new a(this, param1h0));
    }
    
    class a implements y<String> {
      a(k.c this$0, h0 param2h0) {}
      
      public void a(@NonNull String param2String) {
        f1 f1 = c0.b();
        c0.a(f1, "advertiser_id", this.b.a.n().f());
        c0.b(f1, "limit_ad_tracking", this.b.a.n().A());
        this.a.a(f1).c();
      }
      
      public void a(@NonNull Throwable param2Throwable) {
        (new e0.a()).a("Device.query_advertiser_info").a(" failed with error: ").a(Log.getStackTraceString(param2Throwable)).a(e0.g);
      }
    }
  }
  
  class a implements y<String> {
    a(k this$0, h0 param1h0) {}
    
    public void a(@NonNull String param1String) {
      f1 f1 = c0.b();
      c0.a(f1, "advertiser_id", this.b.a.n().f());
      c0.b(f1, "limit_ad_tracking", this.b.a.n().A());
      this.a.a(f1).c();
    }
    
    public void a(@NonNull Throwable param1Throwable) {
      (new e0.a()).a("Device.query_advertiser_info").a(" failed with error: ").a(Log.getStackTraceString(param1Throwable)).a(e0.g);
    }
  }
  
  class d implements j0 {
    d(k this$0) {}
    
    public void a(h0 param1h0) {
      s0 s0 = this.a.q().a();
      this.a.n().c(c0.h(param1h0.a(), "version"));
      if (s0 != null)
        s0.e(this.a.n().o()); 
    }
  }
  
  class e implements j0 {
    e(k this$0) {}
    
    public void a(h0 param1h0) {
      k.a(this.a, c0.f(param1h0.a(), "signals"));
    }
  }
  
  class f implements j0 {
    f(k this$0) {}
    
    public void a(h0 param1h0) {
      if (this.a.G()) {
        o0.c().a(new a(this, param1h0), this.a.g());
        return;
      } 
      o.b b = o0.c().b();
      f1 f1 = c0.b();
      if (b != null)
        c0.a(f1, "odt", b.b()); 
      param1h0.a(f1).c();
    }
    
    class a implements x<o.b> {
      a(k.f this$0, h0 param2h0) {}
      
      public void a(o.b param2b) {
        f1 f1 = c0.b();
        if (param2b != null)
          c0.a(f1, "odt", param2b.b()); 
        this.a.a(f1).c();
      }
    }
  }
  
  class a implements x<o.b> {
    a(k this$0, h0 param1h0) {}
    
    public void a(o.b param1b) {
      f1 f1 = c0.b();
      if (param1b != null)
        c0.a(f1, "odt", param1b.b()); 
      this.a.a(f1).c();
    }
  }
  
  class g implements j0 {
    g(k this$0) {}
    
    public void a(h0 param1h0) {
      o0.c().a();
    }
  }
  
  class h implements j0 {
    h(k this$0) {}
    
    public void a(h0 param1h0) {
      k.s(this.a).a(param1h0);
    }
  }
  
  class i implements Runnable {
    i(k this$0) {}
    
    public void run() {
      Context context = a.a();
      if (!k.a(this.a) && context != null)
        try {
          Omid.activate(context.getApplicationContext());
          k.a(this.a, true);
        } catch (IllegalArgumentException illegalArgumentException) {
          (new e0.a()).a("IllegalArgumentException when activating Omid").a(e0.i);
          k.a(this.a, false);
        }  
      if (k.a(this.a) && k.b(this.a) == null)
        try {
          k.a(this.a, Partner.createPartner("AdColony", "4.8.0"));
          return;
        } catch (IllegalArgumentException illegalArgumentException) {
          (new e0.a()).a("IllegalArgumentException when creating Omid Partner").a(e0.i);
          k.a(this.a, false);
        }  
    }
  }
  
  class j implements Runnable {
    j(k this$0) {}
    
    public void run() {
      f1 f1 = c0.b();
      c0.a(f1, "url", k.Z);
      c0.a(f1, "content_type", "application/json");
      c0.a(f1, "content", this.a.n().t().toString());
      c0.a(f1, "url", k.Z);
      if (k.c(this.a)) {
        f1 f11 = c0.b();
        c0.a(f11, "request", "la-req-01");
        c0.a(f11, "response", "la-res-01");
        c0.a(f1, "dictionaries_mapping", f11);
      } 
      k.r(this.a).a(new s(new h0("WebServices.post", 0, f1), new a(this)));
    }
    
    class a implements s.a {
      a(k.j this$0) {}
      
      public void a(s param2s, h0 param2h0, Map<String, List<String>> param2Map) {
        k.a(this.a.a, param2s);
      }
    }
  }
  
  class a implements s.a {
    a(k this$0) {}
    
    public void a(s param1s, h0 param1h0, Map<String, List<String>> param1Map) {
      k.a(this.a.a, param1s);
    }
  }
  
  class k implements v.c {
    k(k this$0) {}
    
    public void a() {
      o0.c().d();
    }
  }
  
  class l implements Runnable {
    l(k this$0, Context param1Context, h0 param1h0) {}
    
    public void run() {
      j j = j.a(this.a.getApplicationContext(), this.b);
      k.d(this.c).put(Integer.valueOf(j.getModuleId()), j);
    }
  }
  
  class m implements Runnable {
    m(k this$0) {}
    
    public void run() {
      if (a.b().x().f())
        k.e(this.a); 
    }
  }
  
  class n implements s.a {
    n(k this$0) {}
    
    public void a(s param1s, h0 param1h0, Map<String, List<String>> param1Map) {
      k.f(this.a);
    }
  }
  
  class o implements Runnable {
    o(k this$0) {}
    
    public void run() {
      k.g(this.a);
    }
  }
  
  class p implements AdColonyInterstitial.f {
    p(k this$0) {}
    
    public void a() {
      k.i(this.a);
    }
  }
  
  class q implements AdColonyAdView.c {
    q(k this$0) {}
    
    public void a() {
      k.i(this.a);
    }
  }
  
  class r implements x<n0> {
    r(k this$0) {}
    
    public void a(n0 param1n0) {
      o0.c().a(param1n0);
    }
  }
  
  class s implements Runnable {
    s(k this$0, h0 param1h0) {}
    
    public void run() {
      k.j(this.b).onReward(new AdColonyReward(this.a));
    }
  }
  
  class t implements Application.ActivityLifecycleCallbacks {
    private final Set<Integer> a = new HashSet<Integer>();
    
    t(k this$0) {}
    
    public void onActivityCreated(@NonNull Activity param1Activity, Bundle param1Bundle) {
      if (!k.k(this.b).f())
        k.k(this.b).c(true); 
      a.a((Context)param1Activity);
    }
    
    public void onActivityDestroyed(@NonNull Activity param1Activity) {}
    
    public void onActivityPaused(@NonNull Activity param1Activity) {
      a.d = false;
      k.k(this.b).d(false);
    }
    
    public void onActivityResumed(@NonNull Activity param1Activity) {
      this.a.add(Integer.valueOf(param1Activity.hashCode()));
      a.d = true;
      a.a((Context)param1Activity);
      s0 s0 = this.b.q().a();
      Context context = a.a();
      if (context != null && k.k(this.b).e() && context instanceof b && !((b)context).d)
        return; 
      a.a((Context)param1Activity);
      if (k.l(this.b) != null) {
        if (!Objects.equals(c0.h(k.l(this.b).a(), "m_origin"), ""))
          k.l(this.b).a(k.l(this.b).a()).c(); 
        k.c(this.b, (h0)null);
      } 
      k.b(this.b, false);
      k.k(this.b).g(false);
      if (k.m(this.b) && !k.k(this.b).f())
        k.k(this.b).c(true); 
      k.k(this.b).d(true);
      k.n(this.b).c();
      if (s0 != null) {
        ScheduledExecutorService scheduledExecutorService = s0.b;
        if (scheduledExecutorService == null || scheduledExecutorService.isShutdown() || s0.b.isTerminated()) {
          AdColony.a((Context)param1Activity, k.o(a.b()));
          return;
        } 
        return;
      } 
      AdColony.a((Context)param1Activity, k.o(a.b()));
    }
    
    public void onActivitySaveInstanceState(@NonNull Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(@NonNull Activity param1Activity) {
      k.k(this.b).e(true);
    }
    
    public void onActivityStopped(@NonNull Activity param1Activity) {
      this.a.remove(Integer.valueOf(param1Activity.hashCode()));
      if (this.a.isEmpty())
        k.k(this.b).e(false); 
    }
  }
  
  class u implements j0 {
    u(k this$0) {}
    
    public void a(h0 param1h0) {
      k.a(this.a, param1h0);
    }
  }
  
  class v implements j0 {
    v(k this$0) {}
    
    public void a(h0 param1h0) {
      k.b(this.a, param1h0);
    }
  }
  
  class w implements j0 {
    w(k this$0) {}
    
    public void a(h0 param1h0) {
      s0 s0 = this.a.q().a();
      k.h(this.a).a(true);
      if (k.p(this.a)) {
        f1 f11 = c0.b();
        f1 f12 = c0.b();
        c0.a(f12, "app_version", z0.c());
        c0.a(f11, "app_bundle_info", f12);
        (new h0("AdColony.on_update", 1, f11)).c();
        k.c(this.a, false);
      } 
      if (k.q(this.a))
        (new h0("AdColony.on_install", 1)).c(); 
      f1 f1 = param1h0.a();
      if (s0 != null)
        s0.f(c0.h(f1, "app_session_id")); 
      if (AdColonyEventTracker.a())
        AdColonyEventTracker.b(); 
      Integer integer = f1.i("base_download_threads");
      if (integer != null)
        k.r(this.a).a(integer.intValue()); 
      integer = f1.i("concurrent_requests");
      if (integer != null)
        k.r(this.a).b(integer.intValue()); 
      integer = f1.i("threads_keep_alive_time");
      if (integer != null)
        k.r(this.a).c(integer.intValue()); 
      double d = f1.h("thread_pool_scaling_factor");
      if (!Double.isNaN(d))
        k.r(this.a).a(d); 
      k.s(this.a).b();
      k.t(this.a);
    }
  }
  
  class x implements j0 {
    x(k this$0) {}
    
    public void a(h0 param1h0) {
      k.d(this.a, param1h0);
    }
  }
  
  class y implements j0 {
    y(k this$0) {}
    
    public void a(h0 param1h0) {
      this.a.e(param1h0);
    }
  }
  
  class z implements j0 {
    z(k this$0) {}
    
    public void a(h0 param1h0) {
      k.e(this.a, param1h0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */