package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.annotation.RequiresApi;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;
import com.safedk.android.analytics.brandsafety.creatives.CreativeInfoManager;
import com.safedk.android.internal.partials.AdColonyNetworkBridge;
import com.safedk.android.utils.Logger;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import kotlin.Unit;
import kotlin.jvm.JvmName;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class b1 extends WebView {
  @NotNull
  public static final g u = new g(null);
  
  private final int a;
  
  @Nullable
  private final h0 b;
  
  private int c;
  
  @NotNull
  private String d;
  
  @NotNull
  private String e;
  
  @NotNull
  private String f;
  
  @NotNull
  private String g;
  
  @NotNull
  private String h;
  
  @NotNull
  private String i;
  
  @NotNull
  private f1 j;
  
  private boolean k;
  
  @Nullable
  private c l;
  
  private int m;
  
  private int n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private int t;
  
  protected b1(@NotNull Context paramContext, int paramInt, @Nullable h0 paramh0) {
    super(paramContext);
    this.a = paramInt;
    this.b = paramh0;
    this.d = "";
    this.e = "";
    this.f = "";
    this.g = "";
    this.h = "";
    this.i = "";
    this.j = c0.b();
  }
  
  @JvmStatic
  @JvmName(name = "create")
  @NotNull
  public static final b1 a(@NotNull Context paramContext, @NotNull h0 paramh0, int paramInt, @NotNull c paramc) {
    return u.a(paramContext, paramh0, paramInt, paramc);
  }
  
  private final void a(int paramInt, String paramString1, String paramString2) {
    c c1 = this.l;
    if (c1 != null) {
      f1 f11 = c0.b();
      c0.b(f11, "id", this.c);
      c0.a(f11, "ad_session_id", getAdSessionId());
      c0.b(f11, "container_id", c1.c());
      c0.b(f11, "code", paramInt);
      c0.a(f11, "error", paramString1);
      c0.a(f11, "url", paramString2);
      (new h0("WebView.on_error", c1.k(), f11)).c();
    } 
    e0.a a = (new e0.a()).a("onReceivedError: ");
    paramString2 = paramString1;
    if (paramString1 == null)
      paramString2 = "WebViewErrorMessage: null description"; 
    a.a(paramString2).a(e0.i);
  }
  
  private final void a(h0 paramh0, Function0<Unit> paramFunction0) {
    f1 f11 = paramh0.a();
    if (c0.d(f11, "id") == this.c) {
      int i = c0.d(f11, "container_id");
      c c1 = this.l;
      if (c1 != null && i == c1.c()) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        String str1;
        String str2 = c0.h(f11, "ad_session_id");
        c c2 = this.l;
        if (c2 == null) {
          c2 = null;
        } else {
          str1 = c2.a();
        } 
        if (Intrinsics.areEqual(str2, str1))
          z0.b(new l(paramFunction0)); 
      } 
    } 
  }
  
  private final void a(Exception paramException) {
    (new e0.a()).a(paramException.getClass().toString()).a(" during metadata injection w/ metadata = ").a(c0.h(this.j, "metadata")).a(e0.i);
    c c1 = this.l;
    if (c1 == null)
      return; 
    f1 f11 = c0.b();
    c0.a(f11, "id", getAdSessionId());
    (new h0("AdSession.on_error", c1.k(), f11)).c();
  }
  
  private final void d() {
    c c1 = this.l;
    if (c1 != null) {
      ArrayList<j0> arrayList1 = c1.i();
      if (arrayList1 != null) {
        arrayList1.add(a.a("WebView.execute_js", new h(this), true));
        arrayList1.add(a.a("WebView.set_visible", new i(this), true));
        arrayList1.add(a.a("WebView.set_bounds", new j(this), true));
        arrayList1.add(a.a("WebView.set_transparent", new k(this), true));
      } 
    } 
    c1 = this.l;
    if (c1 == null)
      return; 
    ArrayList<String> arrayList = c1.j();
    if (arrayList == null)
      return; 
    arrayList.add("WebView.execute_js");
    arrayList.add("WebView.set_visible");
    arrayList.add("WebView.set_bounds");
    arrayList.add("WebView.set_transparent");
  }
  
  private final WebViewClient g() {
    int i = Build.VERSION.SDK_INT;
    return (i >= 26) ? getWebViewClientApi26() : ((i >= 24) ? getWebViewClientApi24() : ((i >= 23) ? getWebViewClientApi23() : ((i >= 21) ? getWebViewClientApi21() : getWebViewClientDefault())));
  }
  
  private final void setTransparent(boolean paramBoolean) {
    byte b;
    if (paramBoolean) {
      b = 0;
    } else {
      b = -1;
    } 
    setBackgroundColor(b);
  }
  
  @JvmName(name = "updateBounds")
  public final void a(@NotNull h0 paramh0) {
    setBounds(paramh0);
  }
  
  @JvmName(name = "updateCreateParams")
  public final void b(@NotNull h0 paramh0, int paramInt, @NotNull c paramc) {
    a(paramh0, paramInt, paramc);
    e();
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.webViewOnTouch("com.jirbo.adcolony", this, paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  @JvmName(name = "createOmidAdSession")
  public final void f() {
    a.b().c().a(this, this.h, this.l);
  }
  
  @JvmName(name = "getCurrentHeight")
  public final int getCurrentHeight() {
    return this.p;
  }
  
  @JvmName(name = "getCurrentWidth")
  public final int getCurrentWidth() {
    return this.o;
  }
  
  @JvmName(name = "getCurrentX")
  public final int getCurrentX() {
    return this.m;
  }
  
  @JvmName(name = "getCurrentY")
  public final int getCurrentY() {
    return this.n;
  }
  
  @JvmName(name = "getInitialHeight")
  public final int getInitialHeight() {
    return this.t;
  }
  
  @JvmName(name = "getInitialWidth")
  public final int getInitialWidth() {
    return this.s;
  }
  
  @JvmName(name = "getInitialX")
  public final int getInitialX() {
    return this.q;
  }
  
  @JvmName(name = "getInitialY")
  public final int getInitialY() {
    return this.r;
  }
  
  @JvmName(name = "getWebViewModuleId")
  public final int getWebViewModuleId() {
    return this.a;
  }
  
  @JvmName(name = "terminate")
  public final void l() {
    if (!this.k) {
      this.k = true;
      z0.b(new m(this));
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (!true) {
      setMeasuredDimension(0, 0);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public boolean onTouchEvent(@Nullable MotionEvent paramMotionEvent) {
    boolean bool;
    if (paramMotionEvent != null && paramMotionEvent.getAction() == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      AdColonyAdView adColonyAdView = getAdView();
      if (adColonyAdView != null && !adColonyAdView.c()) {
        f1 f11 = c0.b();
        c0.a(f11, "ad_session_id", getAdSessionId());
        (new h0("WebView.on_first_click", 1, f11)).c();
        adColonyAdView.setUserInteraction(true);
      } 
      AdColonyInterstitial adColonyInterstitial = getInterstitial();
      if (adColonyInterstitial != null)
        adColonyInterstitial.b(true); 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  private final class a extends WebChromeClient {
    public a(b1 this$0) {}
    
    public boolean onConsoleMessage(@Nullable ConsoleMessage param1ConsoleMessage) {
      // Byte code:
      //   0: aconst_null
      //   1: astore #9
      //   3: aload_1
      //   4: ifnonnull -> 13
      //   7: aconst_null
      //   8: astore #8
      //   10: goto -> 19
      //   13: aload_1
      //   14: invokevirtual messageLevel : ()Landroid/webkit/ConsoleMessage$MessageLevel;
      //   17: astore #8
      //   19: aload_1
      //   20: ifnonnull -> 29
      //   23: aconst_null
      //   24: astore #7
      //   26: goto -> 35
      //   29: aload_1
      //   30: invokevirtual message : ()Ljava/lang/String;
      //   33: astore #7
      //   35: iconst_0
      //   36: istore #6
      //   38: aload #7
      //   40: ifnonnull -> 46
      //   43: goto -> 65
      //   46: aload #7
      //   48: ldc 'Viewport target-densitydpi is not supported.'
      //   50: iconst_0
      //   51: iconst_2
      //   52: aconst_null
      //   53: invokestatic contains$default : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   56: iconst_1
      //   57: if_icmpne -> 65
      //   60: iconst_1
      //   61: istore_2
      //   62: goto -> 67
      //   65: iconst_0
      //   66: istore_2
      //   67: iload_2
      //   68: ifne -> 112
      //   71: aload #7
      //   73: ifnonnull -> 79
      //   76: goto -> 98
      //   79: aload #7
      //   81: ldc 'Viewport argument key "shrink-to-fit" not recognized and ignored'
      //   83: iconst_0
      //   84: iconst_2
      //   85: aconst_null
      //   86: invokestatic contains$default : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   89: iconst_1
      //   90: if_icmpne -> 98
      //   93: iconst_1
      //   94: istore_2
      //   95: goto -> 100
      //   98: iconst_0
      //   99: istore_2
      //   100: iload_2
      //   101: ifeq -> 107
      //   104: goto -> 112
      //   107: iconst_0
      //   108: istore_2
      //   109: goto -> 114
      //   112: iconst_1
      //   113: istore_2
      //   114: aload #8
      //   116: getstatic android/webkit/ConsoleMessage$MessageLevel.ERROR : Landroid/webkit/ConsoleMessage$MessageLevel;
      //   119: if_acmpne -> 127
      //   122: iconst_1
      //   123: istore_3
      //   124: goto -> 129
      //   127: iconst_0
      //   128: istore_3
      //   129: aload #8
      //   131: getstatic android/webkit/ConsoleMessage$MessageLevel.WARNING : Landroid/webkit/ConsoleMessage$MessageLevel;
      //   134: if_acmpne -> 143
      //   137: iconst_1
      //   138: istore #4
      //   140: goto -> 146
      //   143: iconst_0
      //   144: istore #4
      //   146: aload #7
      //   148: ifnonnull -> 154
      //   151: goto -> 174
      //   154: aload #7
      //   156: ldc 'ADC3_update is not defined'
      //   158: iconst_0
      //   159: iconst_2
      //   160: aconst_null
      //   161: invokestatic contains$default : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   164: iconst_1
      //   165: if_icmpne -> 174
      //   168: iconst_1
      //   169: istore #5
      //   171: goto -> 177
      //   174: iconst_0
      //   175: istore #5
      //   177: iload #5
      //   179: ifne -> 220
      //   182: aload #7
      //   184: ifnonnull -> 194
      //   187: iload #6
      //   189: istore #5
      //   191: goto -> 215
      //   194: iload #6
      //   196: istore #5
      //   198: aload #7
      //   200: ldc 'NativeLayer.dispatch_messages is not a function'
      //   202: iconst_0
      //   203: iconst_2
      //   204: aconst_null
      //   205: invokestatic contains$default : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
      //   208: iconst_1
      //   209: if_icmpne -> 215
      //   212: iconst_1
      //   213: istore #5
      //   215: iload #5
      //   217: ifeq -> 273
      //   220: aload_0
      //   221: getfield a : Lcom/adcolony/sdk/b1;
      //   224: astore #10
      //   226: aload #10
      //   228: invokevirtual getMessage : ()Lcom/adcolony/sdk/h0;
      //   231: astore_1
      //   232: aload_1
      //   233: ifnonnull -> 242
      //   236: aload #9
      //   238: astore_1
      //   239: goto -> 247
      //   242: aload_1
      //   243: invokevirtual a : ()Lcom/adcolony/sdk/f1;
      //   246: astore_1
      //   247: aload_1
      //   248: astore #8
      //   250: aload_1
      //   251: ifnonnull -> 263
      //   254: new com/adcolony/sdk/f1
      //   257: dup
      //   258: invokespecial <init> : ()V
      //   261: astore #8
      //   263: aload #10
      //   265: aload #8
      //   267: ldc 'Unable to communicate with AdColony. Please ensure that you have added an exception for our Javascript interface in your ProGuard configuration and that you do not have a faulty proxy enabled on your device.'
      //   269: invokevirtual a : (Lcom/adcolony/sdk/f1;Ljava/lang/String;)Z
      //   272: pop
      //   273: iload_2
      //   274: ifne -> 400
      //   277: iload #4
      //   279: ifne -> 286
      //   282: iload_3
      //   283: ifeq -> 400
      //   286: aload_0
      //   287: getfield a : Lcom/adcolony/sdk/b1;
      //   290: invokevirtual getInterstitial : ()Lcom/adcolony/sdk/AdColonyInterstitial;
      //   293: astore_1
      //   294: aload_1
      //   295: ifnonnull -> 301
      //   298: goto -> 315
      //   301: aload_1
      //   302: invokevirtual a : ()Ljava/lang/String;
      //   305: astore #8
      //   307: aload #8
      //   309: astore_1
      //   310: aload #8
      //   312: ifnonnull -> 318
      //   315: ldc 'unknown'
      //   317: astore_1
      //   318: new com/adcolony/sdk/e0$a
      //   321: dup
      //   322: invokespecial <init> : ()V
      //   325: astore #8
      //   327: new java/lang/StringBuilder
      //   330: dup
      //   331: invokespecial <init> : ()V
      //   334: astore #9
      //   336: aload #9
      //   338: ldc 'onConsoleMessage: '
      //   340: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   343: pop
      //   344: aload #9
      //   346: aload #7
      //   348: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   351: pop
      //   352: aload #9
      //   354: ldc ' with ad id: '
      //   356: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   359: pop
      //   360: aload #9
      //   362: aload_1
      //   363: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   366: pop
      //   367: aload #8
      //   369: aload #9
      //   371: invokevirtual toString : ()Ljava/lang/String;
      //   374: invokevirtual a : (Ljava/lang/String;)Lcom/adcolony/sdk/e0$a;
      //   377: astore #7
      //   379: iload_3
      //   380: ifeq -> 390
      //   383: getstatic com/adcolony/sdk/e0.i : Lcom/adcolony/sdk/e0;
      //   386: astore_1
      //   387: goto -> 394
      //   390: getstatic com/adcolony/sdk/e0.g : Lcom/adcolony/sdk/e0;
      //   393: astore_1
      //   394: aload #7
      //   396: aload_1
      //   397: invokevirtual a : (Lcom/adcolony/sdk/e0;)V
      //   400: iconst_1
      //   401: ireturn
    }
    
    public boolean onJsAlert(@Nullable WebView param1WebView, @Nullable String param1String1, @Nullable String param1String2, @Nullable JsResult param1JsResult) {
      if (param1JsResult != null)
        param1JsResult.confirm(); 
      return true;
    }
  }
  
  protected class b extends WebViewClient {
    public b(b1 this$0) {}
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    public void onPageFinished(@Nullable WebView param1WebView, @Nullable String param1String) {
      Logger.d("AdColony|SafeDK: Execution> Lcom/adcolony/sdk/b1$b;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V");
      CreativeInfoManager.onWebViewPageFinished("com.jirbo.adcolony", param1WebView, param1String);
      safedk_b1$b_onPageFinished_0e12afd155a1cf60bb162a0eb5225e6c(param1WebView, param1String);
    }
    
    public void onReceivedError(@Nullable WebView param1WebView, int param1Int, @Nullable String param1String1, @Nullable String param1String2) {
      b1.a(this.a, param1Int, param1String1, param1String2);
    }
    
    public void safedk_b1$b_onPageFinished_0e12afd155a1cf60bb162a0eb5225e6c(WebView param1WebView, String param1String) {
      Unit unit;
      f1 f1 = c0.b();
      c0.b(f1, "id", b1.b(this.a));
      c0.a(f1, "url", param1String);
      c c = this.a.getParentContainer();
      if (c == null) {
        c = null;
      } else {
        c0.a(f1, "ad_session_id", this.a.getAdSessionId());
        c0.b(f1, "container_id", c.c());
        (new h0("WebView.on_load", c.k(), f1)).c();
        unit = Unit.INSTANCE;
      } 
      if (unit == null)
        (new h0("WebView.on_load", this.a.getWebViewModuleId(), f1)).c(); 
    }
    
    @RequiresApi(11)
    @Nullable
    public WebResourceResponse safedk_b1$b_shouldInterceptRequest_0ca5ebfe38eda105850ffc849552c836(WebView param1WebView, String param1String) {
      boolean bool = true;
      if (param1String == null || StringsKt.endsWith$default(param1String, "mraid.js", false, 2, null) != true)
        bool = false; 
      if (bool) {
        param1String = b1.a(this.a);
        Charset charset = h.a;
        if (param1String != null) {
          ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(param1String.getBytes(charset));
          return new WebResourceResponse("text/javascript", charset.name(), byteArrayInputStream);
        } 
        throw new NullPointerException("null cannot be cast to non-null type java.lang.String");
      } 
      return null;
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.jirbo.adcolony", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
    }
    
    @RequiresApi(11)
    @Nullable
    public WebResourceResponse shouldInterceptRequest(@Nullable WebView param1WebView, @Nullable String param1String) {
      Logger.d("AdColony|SafeDK: Execution> Lcom/adcolony/sdk/b1$b;->shouldInterceptRequest(Landroid/webkit/WebView;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;");
      return CreativeInfoManager.onWebViewResponse("com.jirbo.adcolony", param1WebView, param1String, safedk_b1$b_shouldInterceptRequest_0ca5ebfe38eda105850ffc849552c836(param1WebView, param1String));
    }
  }
  
  protected class c extends b {
    public c(b1 this$0) {
      super(this$0);
    }
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      CreativeInfoManager.onWebViewPageFinished("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    @RequiresApi(11)
    @Nullable
    public WebResourceResponse safedk_b1$c_shouldInterceptRequest_a61a47777a4fd015f0516e049b64a00e(WebView param1WebView, String param1String) {
      return null;
    }
    
    @RequiresApi(21)
    @Nullable
    public WebResourceResponse safedk_b1$c_shouldInterceptRequest_cc7e34e898e9d23c776de5d72d322351(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      // Byte code:
      //   0: iconst_1
      //   1: istore_3
      //   2: aload_2
      //   3: ifnonnull -> 9
      //   6: goto -> 51
      //   9: aload_2
      //   10: invokeinterface getUrl : ()Landroid/net/Uri;
      //   15: astore_1
      //   16: aload_1
      //   17: ifnonnull -> 23
      //   20: goto -> 51
      //   23: aload_1
      //   24: invokevirtual toString : ()Ljava/lang/String;
      //   27: astore_1
      //   28: aload_1
      //   29: ifnonnull -> 35
      //   32: goto -> 51
      //   35: aload_1
      //   36: ldc 'mraid.js'
      //   38: iconst_0
      //   39: iconst_2
      //   40: aconst_null
      //   41: invokestatic endsWith$default : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
      //   44: iconst_1
      //   45: if_icmpne -> 51
      //   48: goto -> 53
      //   51: iconst_0
      //   52: istore_3
      //   53: iload_3
      //   54: ifeq -> 111
      //   57: aload_0
      //   58: getfield b : Lcom/adcolony/sdk/b1;
      //   61: invokestatic a : (Lcom/adcolony/sdk/b1;)Ljava/lang/String;
      //   64: astore_2
      //   65: getstatic com/adcolony/sdk/h.a : Ljava/nio/charset/Charset;
      //   68: astore_1
      //   69: aload_2
      //   70: ifnull -> 101
      //   73: new java/io/ByteArrayInputStream
      //   76: dup
      //   77: aload_2
      //   78: aload_1
      //   79: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
      //   82: invokespecial <init> : ([B)V
      //   85: astore_2
      //   86: new android/webkit/WebResourceResponse
      //   89: dup
      //   90: ldc 'text/javascript'
      //   92: aload_1
      //   93: invokevirtual name : ()Ljava/lang/String;
      //   96: aload_2
      //   97: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/io/InputStream;)V
      //   100: areturn
      //   101: new java/lang/NullPointerException
      //   104: dup
      //   105: ldc 'null cannot be cast to non-null type java.lang.String'
      //   107: invokespecial <init> : (Ljava/lang/String;)V
      //   110: athrow
      //   111: aconst_null
      //   112: areturn
    }
    
    @RequiresApi(21)
    @Nullable
    public WebResourceResponse shouldInterceptRequest(@Nullable WebView param1WebView, @Nullable WebResourceRequest param1WebResourceRequest) {
      Logger.d("AdColony|SafeDK: Execution> Lcom/adcolony/sdk/b1$c;->shouldInterceptRequest(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;");
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.jirbo.adcolony", param1WebView, param1WebResourceRequest, safedk_b1$c_shouldInterceptRequest_cc7e34e898e9d23c776de5d72d322351(param1WebView, param1WebResourceRequest));
    }
    
    @RequiresApi(11)
    @Nullable
    public WebResourceResponse shouldInterceptRequest(@Nullable WebView param1WebView, @Nullable String param1String) {
      Logger.d("AdColony|SafeDK: Execution> Lcom/adcolony/sdk/b1$c;->shouldInterceptRequest(Landroid/webkit/WebView;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;");
      return CreativeInfoManager.onWebViewResponse("com.jirbo.adcolony", param1WebView, param1String, safedk_b1$c_shouldInterceptRequest_a61a47777a4fd015f0516e049b64a00e(param1WebView, param1String));
    }
  }
  
  protected class d extends c {
    public d(b1 this$0) {
      super(this$0);
    }
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      CreativeInfoManager.onWebViewPageFinished("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    public void onReceivedError(@Nullable WebView param1WebView, int param1Int, @Nullable String param1String1, @Nullable String param1String2) {}
    
    @RequiresApi(23)
    public void onReceivedError(@Nullable WebView param1WebView, @Nullable WebResourceRequest param1WebResourceRequest, @Nullable WebResourceError param1WebResourceError) {
      // Byte code:
      //   0: aload_3
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_0
      //   6: getfield c : Lcom/adcolony/sdk/b1;
      //   9: astore #5
      //   11: aload_3
      //   12: invokevirtual getErrorCode : ()I
      //   15: istore #4
      //   17: aload_3
      //   18: invokevirtual getDescription : ()Ljava/lang/CharSequence;
      //   21: invokevirtual toString : ()Ljava/lang/String;
      //   24: astore_3
      //   25: aload_2
      //   26: ifnonnull -> 32
      //   29: goto -> 43
      //   32: aload_2
      //   33: invokeinterface getUrl : ()Landroid/net/Uri;
      //   38: astore_1
      //   39: aload_1
      //   40: ifnonnull -> 48
      //   43: aconst_null
      //   44: astore_1
      //   45: goto -> 53
      //   48: aload_1
      //   49: invokevirtual toString : ()Ljava/lang/String;
      //   52: astore_1
      //   53: aload #5
      //   55: iload #4
      //   57: aload_3
      //   58: aload_1
      //   59: invokestatic a : (Lcom/adcolony/sdk/b1;ILjava/lang/String;Ljava/lang/String;)V
      //   62: return
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.jirbo.adcolony", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      return CreativeInfoManager.onWebViewResponse("com.jirbo.adcolony", param1WebView, param1String, super.shouldInterceptRequest(param1WebView, param1String));
    }
  }
  
  protected class e extends d {
    public e(b1 this$0) {
      super(this$0);
    }
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      CreativeInfoManager.onWebViewPageFinished("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.jirbo.adcolony", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      return CreativeInfoManager.onWebViewResponse("com.jirbo.adcolony", param1WebView, param1String, super.shouldInterceptRequest(param1WebView, param1String));
    }
  }
  
  protected class f extends e {
    public f(b1 this$0) {
      super(this$0);
    }
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    public void onPageFinished(WebView param1WebView, String param1String) {
      super.onPageFinished(param1WebView, param1String);
      CreativeInfoManager.onWebViewPageFinished("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    @RequiresApi(26)
    public boolean onRenderProcessGone(@Nullable WebView param1WebView, @Nullable RenderProcessGoneDetail param1RenderProcessGoneDetail) {
      boolean bool;
      if (param1RenderProcessGoneDetail != null && param1RenderProcessGoneDetail.didCrash() == true) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool)
        this.d.a(c0.b(), "An error occurred while rendering the ad. Ad closing."); 
      return true;
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.jirbo.adcolony", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      return CreativeInfoManager.onWebViewResponse("com.jirbo.adcolony", param1WebView, param1String, super.shouldInterceptRequest(param1WebView, param1String));
    }
  }
  
  public static final class g {
    private g() {}
    
    @JvmStatic
    @JvmName(name = "create")
    @NotNull
    public final b1 a(@NotNull Context param1Context, @NotNull h0 param1h0, int param1Int, @NotNull c param1c) {
      l0 l0;
      b1 b1;
      int i = a.b().r().e();
      f1 f1 = param1h0.a();
      if (c0.b(f1, "use_mraid_module")) {
        l0 = new l0(param1Context, i, param1h0, a.b().r().e());
      } else {
        c1 c1;
        if (c0.b(f1, "enable_messages")) {
          c1 = new c1((Context)l0, i, param1h0);
        } else {
          b1 = new b1((Context)c1, i, param1h0);
        } 
      } 
      b1.a(param1h0, param1Int, param1c);
      b1.i();
      return b1;
    }
  }
  
  public static final class h implements j0 {
    h(b1 param1b1) {}
    
    public void a(@NotNull h0 param1h0) {
      b1 b11 = this.a;
      b1.a(b11, param1h0, new a(b11, param1h0));
    }
    
    static final class a extends Lambda implements Function0<Unit> {
      a(b1 param2b1, h0 param2h0) {
        super(0);
      }
      
      public final void a() {
        this.a.a(c0.h(this.b.a(), "custom_js"));
      }
    }
  }
  
  static final class a extends Lambda implements Function0<Unit> {
    a(b1 param1b1, h0 param1h0) {
      super(0);
    }
    
    public final void a() {
      this.a.a(c0.h(this.b.a(), "custom_js"));
    }
  }
  
  public static final class i implements j0 {
    i(b1 param1b1) {}
    
    public void a(@NotNull h0 param1h0) {
      b1 b11 = this.a;
      b1.a(b11, param1h0, new a(b11, param1h0));
    }
    
    static final class a extends Lambda implements Function0<Unit> {
      a(b1 param2b1, h0 param2h0) {
        super(0);
      }
      
      public final void a() {
        this.a.setVisible(this.b);
      }
    }
  }
  
  static final class a extends Lambda implements Function0<Unit> {
    a(b1 param1b1, h0 param1h0) {
      super(0);
    }
    
    public final void a() {
      this.a.setVisible(this.b);
    }
  }
  
  public static final class j implements j0 {
    j(b1 param1b1) {}
    
    public void a(@NotNull h0 param1h0) {
      b1 b11 = this.a;
      b1.a(b11, param1h0, new a(b11, param1h0));
    }
    
    static final class a extends Lambda implements Function0<Unit> {
      a(b1 param2b1, h0 param2h0) {
        super(0);
      }
      
      public final void a() {
        this.a.setBounds(this.b);
      }
    }
  }
  
  static final class a extends Lambda implements Function0<Unit> {
    a(b1 param1b1, h0 param1h0) {
      super(0);
    }
    
    public final void a() {
      this.a.setBounds(this.b);
    }
  }
  
  public static final class k implements j0 {
    k(b1 param1b1) {}
    
    public void a(@NotNull h0 param1h0) {
      b1 b11 = this.a;
      b1.a(b11, param1h0, new a(b11, param1h0));
    }
    
    static final class a extends Lambda implements Function0<Unit> {
      a(b1 param2b1, h0 param2h0) {
        super(0);
      }
      
      public final void a() {
        b1.a(this.a, c0.b(this.b.a(), "transparent"));
      }
    }
  }
  
  static final class a extends Lambda implements Function0<Unit> {
    a(b1 param1b1, h0 param1h0) {
      super(0);
    }
    
    public final void a() {
      b1.a(this.a, c0.b(this.b.a(), "transparent"));
    }
  }
  
  static final class m implements Runnable {
    m(b1 param1b1) {}
    
    public final void run() {
      this.a.setWebChromeClient(null);
      b1 b11 = this.a;
      b11.setWebViewClient(new a(b11));
      this.a.clearCache(true);
      this.a.removeAllViews();
      AdColonyNetworkBridge.webviewLoadUrl(this.a, "about:blank");
    }
    
    public static final class a extends WebViewClient {
      a(b1 param2b1) {}
      
      public void onLoadResource(WebView param2WebView, String param2String) {
        super.onLoadResource(param2WebView, param2String);
        CreativeInfoManager.onResourceLoaded("com.jirbo.adcolony", param2WebView, param2String);
      }
      
      public void onPageFinished(@Nullable WebView param2WebView, @Nullable String param2String) {
        Logger.d("AdColony|SafeDK: Execution> Lcom/adcolony/sdk/b1$m$a;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V");
        CreativeInfoManager.onWebViewPageFinished("com.jirbo.adcolony", param2WebView, param2String);
        safedk_b1$m$a_onPageFinished_dfa9d6c9a0fd59300f91b341d7038d79(param2WebView, param2String);
      }
      
      public void safedk_b1$m$a_onPageFinished_dfa9d6c9a0fd59300f91b341d7038d79(WebView param2WebView, String param2String) {
        this.a.destroy();
      }
      
      public WebResourceResponse shouldInterceptRequest(WebView param2WebView, WebResourceRequest param2WebResourceRequest) {
        return CreativeInfoManager.onWebViewResponseWithHeaders("com.jirbo.adcolony", param2WebView, param2WebResourceRequest, super.shouldInterceptRequest(param2WebView, param2WebResourceRequest));
      }
      
      public WebResourceResponse shouldInterceptRequest(WebView param2WebView, String param2String) {
        return CreativeInfoManager.onWebViewResponse("com.jirbo.adcolony", param2WebView, param2String, super.shouldInterceptRequest(param2WebView, param2String));
      }
    }
  }
  
  public static final class a extends WebViewClient {
    a(b1 param1b1) {}
    
    public void onLoadResource(WebView param1WebView, String param1String) {
      super.onLoadResource(param1WebView, param1String);
      CreativeInfoManager.onResourceLoaded("com.jirbo.adcolony", param1WebView, param1String);
    }
    
    public void onPageFinished(@Nullable WebView param1WebView, @Nullable String param1String) {
      Logger.d("AdColony|SafeDK: Execution> Lcom/adcolony/sdk/b1$m$a;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V");
      CreativeInfoManager.onWebViewPageFinished("com.jirbo.adcolony", param1WebView, param1String);
      safedk_b1$m$a_onPageFinished_dfa9d6c9a0fd59300f91b341d7038d79(param1WebView, param1String);
    }
    
    public void safedk_b1$m$a_onPageFinished_dfa9d6c9a0fd59300f91b341d7038d79(WebView param1WebView, String param1String) {
      this.a.destroy();
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, WebResourceRequest param1WebResourceRequest) {
      return CreativeInfoManager.onWebViewResponseWithHeaders("com.jirbo.adcolony", param1WebView, param1WebResourceRequest, super.shouldInterceptRequest(param1WebView, param1WebResourceRequest));
    }
    
    public WebResourceResponse shouldInterceptRequest(WebView param1WebView, String param1String) {
      return CreativeInfoManager.onWebViewResponse("com.jirbo.adcolony", param1WebView, param1String, super.shouldInterceptRequest(param1WebView, param1String));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */