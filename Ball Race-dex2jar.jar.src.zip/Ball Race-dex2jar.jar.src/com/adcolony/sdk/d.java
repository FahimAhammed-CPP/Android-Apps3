package com.adcolony.sdk;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class d {
  private ConcurrentHashMap<String, Runnable> a;
  
  private HashMap<String, c> b;
  
  private ConcurrentHashMap<String, AdColonyInterstitial> c;
  
  private ConcurrentHashMap<String, AdColonyAdViewListener> d;
  
  private ConcurrentHashMap<String, AdColonyAdViewListener> e;
  
  private Map<String, AdColonyAdView> f;
  
  private final Object g = new Object();
  
  private void a(AdColonyAdViewListener paramAdColonyAdViewListener) {
    z0.b(new n(this, paramAdColonyAdViewListener));
  }
  
  private void a(AdColonyInterstitial paramAdColonyInterstitial) {
    paramAdColonyInterstitial.q();
    if (!a.c()) {
      e0.a a = (new e0.a()).a("RequestNotFilled called due to a missing context. ");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Interstitial with adSessionId(");
      stringBuilder.append(paramAdColonyInterstitial.b());
      stringBuilder.append(").");
      a.a(stringBuilder.toString()).a(e0.i);
    } 
  }
  
  private boolean d(h0 paramh0) {
    String str = c0.h(paramh0.a(), "ad_session_id");
    c c = this.b.get(str);
    if (c == null) {
      a(paramh0.b(), str);
      return false;
    } 
    a(c);
    return true;
  }
  
  private boolean f(h0 paramh0) {
    f1 f1 = paramh0.a();
    int i = c0.d(f1, "status");
    if (i != 5 && i != 1 && i != 0) {
      AdColonyInterstitialListener adColonyInterstitialListener;
      if (i == 6)
        return false; 
      String str = c0.h(f1, "id");
      AdColonyInterstitial adColonyInterstitial = this.c.remove(str);
      if (adColonyInterstitial == null) {
        f1 = null;
      } else {
        adColonyInterstitialListener = adColonyInterstitial.getListener();
      } 
      if (adColonyInterstitialListener == null) {
        a(paramh0.b(), str);
        return false;
      } 
      z0.b(new q(this, adColonyInterstitialListener, adColonyInterstitial));
      adColonyInterstitial.o();
      adColonyInterstitial.a(null);
      return true;
    } 
    return false;
  }
  
  private boolean g(h0 paramh0) {
    String str = c0.h(paramh0.a(), "id");
    f1 f1 = c0.b();
    c0.a(f1, "id", str);
    Context context = a.a();
    if (context == null) {
      c0.b(f1, "has_audio", false);
      paramh0.a(f1).c();
      return false;
    } 
    boolean bool = z0.b(z0.a(context));
    double d1 = z0.a(z0.a(context));
    c0.b(f1, "has_audio", bool);
    c0.a(f1, "volume", d1);
    paramh0.a(f1).c();
    return bool;
  }
  
  private boolean j(h0 paramh0) {
    StringBuilder stringBuilder;
    f1 f1 = paramh0.a();
    String str1 = paramh0.b();
    String str2 = c0.h(f1, "ad_session_id");
    int i = c0.d(f1, "view_id");
    c c = this.b.get(str2);
    if (c == null) {
      a(str1, str2);
      return false;
    } 
    View view = (View)c.e().get(Integer.valueOf(i));
    if (view == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i);
      a(str1, stringBuilder.toString());
      return false;
    } 
    stringBuilder.removeView(view);
    stringBuilder.addView(view, view.getLayoutParams());
    return true;
  }
  
  private boolean k(h0 paramh0) {
    StringBuilder stringBuilder;
    f1 f1 = paramh0.a();
    String str1 = paramh0.b();
    String str2 = c0.h(f1, "ad_session_id");
    int i = c0.d(f1, "view_id");
    c c = this.b.get(str2);
    if (c == null) {
      a(str1, str2);
      return false;
    } 
    View view = (View)c.e().get(Integer.valueOf(i));
    if (view == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("");
      stringBuilder.append(i);
      a(str1, stringBuilder.toString());
      return false;
    } 
    stringBuilder.bringToFront();
    return true;
  }
  
  private boolean l(h0 paramh0) {
    boolean bool;
    f1 f1 = paramh0.a();
    String str = c0.h(f1, "id");
    AdColonyInterstitial adColonyInterstitial = this.c.get(str);
    AdColonyAdView adColonyAdView = this.f.get(str);
    int i = c0.a(f1, "orientation", -1);
    if (adColonyAdView != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (adColonyInterstitial == null && !bool) {
      a(paramh0.b(), str);
      return false;
    } 
    c0.a(c0.b(), "id", str);
    if (adColonyInterstitial != null) {
      adColonyInterstitial.a(i);
      adColonyInterstitial.n();
    } 
    return true;
  }
  
  AdColonyAdView a(String paramString) {
    synchronized (this.g) {
      return this.f.remove(paramString);
    } 
  }
  
  void a() {
    for (AdColonyInterstitial adColonyInterstitial : this.c.values()) {
      if (adColonyInterstitial != null && adColonyInterstitial.m()) {
        adColonyInterstitial.e("Controller was reloaded and current ad was closed");
        break;
      } 
    } 
  }
  
  void a(@NonNull Context paramContext, @NonNull f1 paramf1, @NonNull String paramString) {
    h0 h0 = new h0("AdSession.finish_fullscreen_ad", 0);
    c0.b(paramf1, "status", 1);
    h0.b(paramf1);
    (new e0.a()).a(paramString).a(e0.h);
    ((b)paramContext).a(h0);
  }
  
  void a(b1 paramb1, String paramString, c paramc) {
    z0.b(new r(this, paramString, paramb1, paramc));
  }
  
  void a(c paramc) {
    z0.b(new s(this, paramc));
    AdColonyAdView adColonyAdView = this.f.get(paramc.a());
    if (adColonyAdView == null || adColonyAdView.d()) {
      this.b.remove(paramc.a());
      paramc.y = null;
    } 
  }
  
  void a(@NonNull String paramString, @NonNull AdColonyAdViewListener paramAdColonyAdViewListener, @NonNull AdColonyAdSize paramAdColonyAdSize, @Nullable AdColonyAdOptions paramAdColonyAdOptions, long paramLong) {
    String str = z0.a();
    float f = a.b().n().s();
    f1 f1 = c0.b();
    c0.a(f1, "zone_id", paramString);
    c0.b(f1, "type", 1);
    c0.b(f1, "width_pixels", (int)(paramAdColonyAdSize.getWidth() * f));
    c0.b(f1, "height_pixels", (int)(paramAdColonyAdSize.getHeight() * f));
    c0.b(f1, "width", paramAdColonyAdSize.getWidth());
    c0.b(f1, "height", paramAdColonyAdSize.getHeight());
    c0.a(f1, "id", str);
    if (paramAdColonyAdOptions != null) {
      f1 f11 = paramAdColonyAdOptions.d;
      if (f11 != null)
        c0.a(f1, "options", f11); 
    } 
    paramAdColonyAdViewListener.a(paramString);
    paramAdColonyAdViewListener.a(paramAdColonyAdSize);
    this.d.put(str, paramAdColonyAdViewListener);
    this.a.put(str, new o(this, str, paramString, paramLong));
    (new h0("AdSession.on_request", 1, f1)).c();
    z0.a(this.a.get(str), paramLong);
  }
  
  void a(@NonNull String paramString, @NonNull AdColonyInterstitialListener paramAdColonyInterstitialListener, @Nullable AdColonyAdOptions paramAdColonyAdOptions, long paramLong) {
    String str = z0.a();
    k k = a.b();
    AdColonyInterstitial adColonyInterstitial = new AdColonyInterstitial(str, paramAdColonyInterstitialListener, paramString);
    f1 f1 = c0.b();
    c0.a(f1, "zone_id", paramString);
    c0.b(f1, "fullscreen", true);
    Rect rect = k.n().w();
    c0.b(f1, "width", rect.width());
    c0.b(f1, "height", rect.height());
    c0.b(f1, "type", 0);
    c0.a(f1, "id", str);
    if (paramAdColonyAdOptions != null && paramAdColonyAdOptions.d != null) {
      adColonyInterstitial.a(paramAdColonyAdOptions);
      c0.a(f1, "options", paramAdColonyAdOptions.d);
    } 
    this.c.put(str, adColonyInterstitial);
    this.a.put(str, new p(this, str, paramString, paramLong));
    (new h0("AdSession.on_request", 1, f1)).c();
    z0.a(this.a.get(str), paramLong);
  }
  
  void a(String paramString1, String paramString2) {
    (new e0.a()).a("Message '").a(paramString1).a("' sent with invalid id: ").a(paramString2).a(e0.h);
  }
  
  boolean a(h0 paramh0) {
    String str = c0.h(paramh0.a(), "id");
    AdColonyAdViewListener adColonyAdViewListener = this.d.remove(str);
    if (adColonyAdViewListener == null) {
      a(paramh0.b(), str);
      return false;
    } 
    z0.c(this.a.remove(str));
    a(adColonyAdViewListener);
    return true;
  }
  
  void b() {
    null = new HashSet();
    synchronized (this.g) {
      for (String str : this.e.keySet()) {
        AdColonyAdViewListener adColonyAdViewListener = this.e.remove(str);
        if (adColonyAdViewListener != null)
          null.add(adColonyAdViewListener); 
      } 
      for (String str : this.d.keySet()) {
        AdColonyAdViewListener adColonyAdViewListener = this.d.remove(str);
        if (adColonyAdViewListener != null)
          null.add(adColonyAdViewListener); 
      } 
      null = (Object<AdColonyAdViewListener>)null.iterator();
      while (null.hasNext())
        a(null.next()); 
      for (String str : this.c.keySet()) {
        AdColonyInterstitial adColonyInterstitial = this.c.get(str);
        if (adColonyInterstitial != null && adColonyInterstitial.l()) {
          this.c.remove(str);
          a(adColonyInterstitial);
        } 
      } 
      return;
    } 
  }
  
  boolean b(h0 paramh0) {
    String str = c0.h(paramh0.a(), "id");
    AdColonyAdViewListener adColonyAdViewListener = this.d.remove(str);
    if (adColonyAdViewListener == null) {
      a(paramh0.b(), str);
      return false;
    } 
    this.e.put(str, adColonyAdViewListener);
    z0.c(this.a.remove(str));
    Context context = a.a();
    if (context == null) {
      a(adColonyAdViewListener);
      return false;
    } 
    z0.b(new k(this, context, paramh0, adColonyAdViewListener, str));
    return true;
  }
  
  HashMap<String, c> c() {
    return this.b;
  }
  
  boolean c(h0 paramh0) {
    Context context = a.a();
    if (context == null)
      return false; 
    f1 f12 = paramh0.a();
    String str = c0.h(f12, "ad_session_id");
    c c = new c(context.getApplicationContext(), str);
    c.j(paramh0);
    this.b.put(str, c);
    if (c0.d(f12, "width") == 0) {
      AdColonyInterstitial adColonyInterstitial = this.c.get(str);
      if (adColonyInterstitial == null) {
        a(paramh0.b(), str);
        return false;
      } 
      adColonyInterstitial.a(c);
    } else {
      c.c(false);
    } 
    f1 f11 = c0.b();
    c0.b(f11, "success", true);
    paramh0.a(f11).c();
    return true;
  }
  
  Map<String, AdColonyAdView> d() {
    return this.f;
  }
  
  ConcurrentHashMap<String, AdColonyAdViewListener> e() {
    return this.d;
  }
  
  boolean e(h0 paramh0) {
    f1 f1 = paramh0.a();
    String str = c0.h(f1, "id");
    if (c0.d(f1, "type") == 0) {
      AdColonyInterstitial adColonyInterstitial = this.c.remove(str);
      if (a.c() && adColonyInterstitial != null && adColonyInterstitial.p()) {
        z0.b(new j(this));
      } else {
        a(paramh0.b(), str);
      } 
    } 
    return true;
  }
  
  ConcurrentHashMap<String, AdColonyInterstitial> f() {
    return this.c;
  }
  
  List<AdColonyInterstitial> g() {
    ArrayList<AdColonyInterstitial> arrayList = new ArrayList();
    for (AdColonyInterstitial adColonyInterstitial : f().values()) {
      if (!adColonyInterstitial.isExpired())
        arrayList.add(adColonyInterstitial); 
    } 
    return arrayList;
  }
  
  void h() {
    this.a = new ConcurrentHashMap<String, Runnable>();
    this.b = new HashMap<String, c>();
    this.c = new ConcurrentHashMap<String, AdColonyInterstitial>();
    this.d = new ConcurrentHashMap<String, AdColonyAdViewListener>();
    this.e = new ConcurrentHashMap<String, AdColonyAdViewListener>();
    this.f = Collections.synchronizedMap(new HashMap<String, AdColonyAdView>());
    a.a("AdContainer.create", new l(this));
    a.a("AdContainer.destroy", new t(this));
    a.a("AdContainer.move_view_to_index", new u(this));
    a.a("AdContainer.move_view_to_front", new v(this));
    a.a("AdSession.finish_fullscreen_ad", new w(this));
    a.a("AdSession.start_fullscreen_ad", new x(this));
    a.a("AdSession.ad_view_available", new y(this));
    a.a("AdSession.ad_view_unavailable", new z(this));
    a.a("AdSession.expiring", new a(this));
    a.a("AdSession.audio_stopped", new b(this));
    a.a("AdSession.audio_started", new c(this));
    a.a("AdSession.interstitial_available", new d(this));
    a.a("AdSession.interstitial_unavailable", new e(this));
    a.a("AdSession.has_audio", new f(this));
    a.a("WebView.prepare", new g(this));
    a.a("AdSession.expanded", new h(this));
    a.a("AdColony.odt_event", new i(this));
  }
  
  boolean h(h0 paramh0) {
    AdColonyInterstitialListener adColonyInterstitialListener;
    String str = c0.h(paramh0.a(), "id");
    AdColonyInterstitial adColonyInterstitial = this.c.remove(str);
    if (adColonyInterstitial == null) {
      adColonyInterstitialListener = null;
    } else {
      adColonyInterstitialListener = adColonyInterstitial.getListener();
    } 
    if (adColonyInterstitialListener == null) {
      a(paramh0.b(), str);
      return false;
    } 
    z0.c(this.a.remove(str));
    a(adColonyInterstitial);
    return true;
  }
  
  boolean i(h0 paramh0) {
    f1 f1 = paramh0.a();
    String str = c0.h(f1, "id");
    AdColonyInterstitial adColonyInterstitial = this.c.get(str);
    if (adColonyInterstitial != null) {
      if (adColonyInterstitial.j())
        return false; 
      AdColonyInterstitialListener adColonyInterstitialListener = adColonyInterstitial.getListener();
      if (adColonyInterstitialListener == null) {
        a(paramh0.b(), str);
        return false;
      } 
      z0.c(this.a.remove(str));
      if (!a.c()) {
        a(adColonyInterstitial);
        return false;
      } 
      adColonyInterstitial.t();
      adColonyInterstitial.a(c0.h(f1, "ad_id"));
      adColonyInterstitial.c(c0.h(f1, "creative_id"));
      adColonyInterstitial.d(c0.h(f1, "ad_request_id"));
      z0.b(new m(this, paramh0, adColonyInterstitial, adColonyInterstitialListener));
      return true;
    } 
    return false;
  }
  
  class a implements j0 {
    a(d this$0) {}
    
    public void a(h0 param1h0) {
      this.a.e(param1h0);
    }
  }
  
  class b implements j0 {
    b(d this$0) {}
    
    public void a(h0 param1h0) {
      z0.b(new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(d.b this$0, h0 param2h0) {}
      
      public void run() {
        AdColonyInterstitial adColonyInterstitial = (AdColonyInterstitial)d.f(this.b.a).get(c0.h(this.a.a(), "id"));
        if (adColonyInterstitial != null && adColonyInterstitial.getListener() != null)
          adColonyInterstitial.getListener().onAudioStopped(adColonyInterstitial); 
      }
    }
  }
  
  class a implements Runnable {
    a(d this$0, h0 param1h0) {}
    
    public void run() {
      AdColonyInterstitial adColonyInterstitial = (AdColonyInterstitial)d.f(this.b.a).get(c0.h(this.a.a(), "id"));
      if (adColonyInterstitial != null && adColonyInterstitial.getListener() != null)
        adColonyInterstitial.getListener().onAudioStopped(adColonyInterstitial); 
    }
  }
  
  class c implements j0 {
    c(d this$0) {}
    
    public void a(h0 param1h0) {
      z0.b(new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(d.c this$0, h0 param2h0) {}
      
      public void run() {
        AdColonyInterstitial adColonyInterstitial = (AdColonyInterstitial)d.f(this.b.a).get(c0.h(this.a.a(), "id"));
        if (adColonyInterstitial != null && adColonyInterstitial.getListener() != null)
          adColonyInterstitial.getListener().onAudioStarted(adColonyInterstitial); 
      }
    }
  }
  
  class a implements Runnable {
    a(d this$0, h0 param1h0) {}
    
    public void run() {
      AdColonyInterstitial adColonyInterstitial = (AdColonyInterstitial)d.f(this.b.a).get(c0.h(this.a.a(), "id"));
      if (adColonyInterstitial != null && adColonyInterstitial.getListener() != null)
        adColonyInterstitial.getListener().onAudioStarted(adColonyInterstitial); 
    }
  }
  
  class d implements j0 {
    d(d this$0) {}
    
    public void a(h0 param1h0) {
      this.a.i(param1h0);
    }
  }
  
  class e implements j0 {
    e(d this$0) {}
    
    public void a(h0 param1h0) {
      this.a.h(param1h0);
    }
  }
  
  class f implements j0 {
    f(d this$0) {}
    
    public void a(h0 param1h0) {
      d.a(this.a, param1h0);
    }
  }
  
  class g implements j0 {
    g(d this$0) {}
    
    public void a(h0 param1h0) {
      f1 f1 = c0.b();
      c0.b(f1, "success", true);
      param1h0.a(f1).c();
    }
  }
  
  class h implements j0 {
    h(d this$0) {}
    
    public void a(h0 param1h0) {
      z0.b(new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(d.h this$0, h0 param2h0) {}
      
      public void run() {
        h0 h01 = this.a;
        h01.a(h01.a()).c();
      }
    }
  }
  
  class a implements Runnable {
    a(d this$0, h0 param1h0) {}
    
    public void run() {
      h0 h01 = this.a;
      h01.a(h01.a()).c();
    }
  }
  
  class i implements j0 {
    i(d this$0) {}
    
    public void a(h0 param1h0) {
      o0.c().a(param1h0);
    }
  }
  
  class j implements Runnable {
    j(d this$0) {}
    
    public void run() {
      r r = a.b().o();
      if (r.a() != null) {
        r.a().dismiss();
        r.a(null);
      } 
    }
  }
  
  class k implements Runnable {
    k(d this$0, Context param1Context, h0 param1h0, AdColonyAdViewListener param1AdColonyAdViewListener, String param1String) {}
    
    public void run() {
      try {
        AdColonyAdView adColonyAdView = new AdColonyAdView(this.a, this.b, this.c);
      } catch (RuntimeException null) {
        (new e0.a()).a(null.toString()).a(e0.i);
        null = null;
      } 
      synchronized (d.a(this.e)) {
        if (d.b(this.e).remove(this.d) == null)
          return; 
        if (null == null) {
          d.a(this.e, this.c);
          return;
        } 
        d.e(this.e).put(this.d, null);
        null.setOmidManager(this.c.b());
        null.e();
        this.c.a((p0)null);
        this.c.onRequestFilled((AdColonyAdView)null);
        return;
      } 
    }
  }
  
  class l implements j0 {
    l(d this$0) {}
    
    public void a(h0 param1h0) {
      z0.b(new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(d.l this$0, h0 param2h0) {}
      
      public void run() {
        this.b.a.c(this.a);
      }
    }
  }
  
  class a implements Runnable {
    a(d this$0, h0 param1h0) {}
    
    public void run() {
      this.b.a.c(this.a);
    }
  }
  
  class m implements Runnable {
    m(d this$0, h0 param1h0, AdColonyInterstitial param1AdColonyInterstitial, AdColonyInterstitialListener param1AdColonyInterstitialListener) {}
    
    public void run() {
      f1 f1 = this.a.a();
      if (this.b.e() == null)
        this.b.a(c0.f(f1, "iab")); 
      this.b.a(c0.h(f1, "ad_id"));
      this.b.c(c0.h(f1, "creative_id"));
      this.b.setViewNetworkPassFilter(c0.h(f1, "view_network_pass_filter"));
      p0 p0 = this.b.e();
      if (p0 != null && p0.d() != 2)
        try {
          p0.a();
        } catch (IllegalArgumentException illegalArgumentException) {
          (new e0.a()).a("IllegalArgumentException when creating omid session").a(e0.i);
        }  
      this.c.onRequestFilled(this.b);
    }
  }
  
  class n implements Runnable {
    n(d this$0, AdColonyAdViewListener param1AdColonyAdViewListener) {}
    
    public void run() {
      AdColonyAdViewListener adColonyAdViewListener = this.a;
      adColonyAdViewListener.onRequestNotFilled(AdColony.a(adColonyAdViewListener.c()));
      if (!a.c())
        (new e0.a()).a("RequestNotFilled called for AdView due to a missing context. ").a(e0.i); 
    }
  }
  
  class o implements Runnable {
    o(d this$0, String param1String1, String param1String2, long param1Long) {}
    
    public void run() {
      d.c(this.d).remove(this.a);
      AdColonyAdViewListener adColonyAdViewListener = (AdColonyAdViewListener)d.d(this.d).remove(this.a);
      if (adColonyAdViewListener != null) {
        adColonyAdViewListener.onRequestNotFilled(AdColony.a(this.b));
        f1 f1 = c0.b();
        c0.a(f1, "id", this.a);
        c0.a(f1, "zone_id", this.b);
        c0.b(f1, "type", 1);
        c0.b(f1, "request_fail_reason", 26);
        (new h0("AdSession.on_request_failure", 1, f1)).c();
        e0.a a = (new e0.a()).a("RequestNotFilled called due to a native timeout. ");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Timeout set to: ");
        stringBuilder.append(a.b().d());
        stringBuilder.append(" ms. ");
        a = a.a(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("AdView request time allowed: ");
        stringBuilder.append(this.c);
        stringBuilder.append(" ms. ");
        a = a.a(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("AdView with adSessionId(");
        stringBuilder.append(this.a);
        stringBuilder.append(") - request failed.");
        a.a(stringBuilder.toString()).a(e0.i);
      } 
    }
  }
  
  class p implements Runnable {
    p(d this$0, String param1String1, String param1String2, long param1Long) {}
    
    public void run() {
      AdColonyInterstitialListener adColonyInterstitialListener;
      d.c(this.d).remove(this.a);
      AdColonyInterstitial adColonyInterstitial = (AdColonyInterstitial)d.f(this.d).remove(this.a);
      if (adColonyInterstitial == null) {
        adColonyInterstitial = null;
      } else {
        adColonyInterstitialListener = adColonyInterstitial.getListener();
      } 
      if (adColonyInterstitialListener != null) {
        adColonyInterstitialListener.onRequestNotFilled(AdColony.a(this.b));
        f1 f1 = c0.b();
        c0.a(f1, "id", this.a);
        c0.a(f1, "zone_id", this.b);
        c0.b(f1, "type", 0);
        c0.b(f1, "request_fail_reason", 26);
        (new h0("AdSession.on_request_failure", 1, f1)).c();
        e0.a a = (new e0.a()).a("RequestNotFilled called due to a native timeout. ");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Timeout set to: ");
        stringBuilder.append(a.b().d());
        stringBuilder.append(" ms. ");
        a = a.a(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("Interstitial request time allowed: ");
        stringBuilder.append(this.c);
        stringBuilder.append(" ms. ");
        a = a.a(stringBuilder.toString());
        stringBuilder = new StringBuilder();
        stringBuilder.append("Interstitial with adSessionId(");
        stringBuilder.append(this.a);
        stringBuilder.append(") - request failed.");
        a.a(stringBuilder.toString()).a(e0.i);
      } 
    }
  }
  
  class q implements Runnable {
    q(d this$0, AdColonyInterstitialListener param1AdColonyInterstitialListener, AdColonyInterstitial param1AdColonyInterstitial) {}
    
    public void run() {
      a.b().e(false);
      this.a.onClosed(this.b);
    }
  }
  
  class r implements Runnable {
    r(d this$0, String param1String, b1 param1b1, c param1c) {}
    
    public void run() {
      int i;
      p0 p0;
      try {
        p0 p01;
        AdColonyInterstitial adColonyInterstitial = this.d.f().get(this.a);
        AdColonyAdView adColonyAdView = this.d.d().get(this.a);
        if (adColonyInterstitial == null) {
          adColonyInterstitial = null;
        } else {
          p01 = adColonyInterstitial.e();
        } 
        p0 = p01;
        if (p01 == null) {
          p0 = p01;
          if (adColonyAdView != null)
            p0 = adColonyAdView.getOmidManager(); 
        } 
      } catch (IllegalArgumentException illegalArgumentException) {
        (new e0.a()).a("IllegalArgumentException when creating omid session").a(e0.i);
        return;
      } 
      if (p0 == null) {
        i = -1;
      } else {
        i = p0.d();
      } 
      if (p0 != null && i == 2) {
        p0.a(this.b);
        p0.a(this.c);
        return;
      } 
    }
  }
  
  class s implements Runnable {
    s(d this$0, c param1c) {}
    
    public void run() {
      for (int i = 0; i < this.a.i().size(); i++)
        a.b(this.a.j().get(i), this.a.i().get(i)); 
      this.a.j().clear();
      this.a.i().clear();
      this.a.removeAllViews();
      c c1 = this.a;
      c1.z = null;
      c1.y = null;
      for (b1 b1 : c1.n().values()) {
        if (!(b1 instanceof e)) {
          if (b1 instanceof c1) {
            a.b().a((k0)b1);
            continue;
          } 
          b1.l();
        } 
      } 
      for (a1 a1 : this.a.m().values()) {
        a1.j();
        a1.k();
      } 
      this.a.m().clear();
      this.a.l().clear();
      this.a.n().clear();
      this.a.h().clear();
      this.a.e().clear();
      this.a.f().clear();
      this.a.g().clear();
      this.a.m = true;
    }
  }
  
  class t implements j0 {
    t(d this$0) {}
    
    public void a(h0 param1h0) {
      z0.b(new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(d.t this$0, h0 param2h0) {}
      
      public void run() {
        d.b(this.b.a, this.a);
      }
    }
  }
  
  class a implements Runnable {
    a(d this$0, h0 param1h0) {}
    
    public void run() {
      d.b(this.b.a, this.a);
    }
  }
  
  class u implements j0 {
    u(d this$0) {}
    
    public void a(h0 param1h0) {
      d.c(this.a, param1h0);
    }
  }
  
  class v implements j0 {
    v(d this$0) {}
    
    public void a(h0 param1h0) {
      d.d(this.a, param1h0);
    }
  }
  
  class w implements j0 {
    w(d this$0) {}
    
    public void a(h0 param1h0) {
      d.e(this.a, param1h0);
    }
  }
  
  class x implements j0 {
    x(d this$0) {}
    
    public void a(h0 param1h0) {
      d.f(this.a, param1h0);
    }
  }
  
  class y implements j0 {
    y(d this$0) {}
    
    public void a(h0 param1h0) {
      this.a.b(param1h0);
    }
  }
  
  class z implements j0 {
    z(d this$0) {}
    
    public void a(h0 param1h0) {
      this.a.a(param1h0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */