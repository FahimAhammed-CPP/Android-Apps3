package com.adcolony.sdk;

import androidx.annotation.NonNull;

public abstract class AdColonyAdViewListener {
  @NonNull
  String a = "";
  
  AdColonyAdSize b;
  
  p0 c;
  
  AdColonyAdSize a() {
    return this.b;
  }
  
  void a(@NonNull AdColonyAdSize paramAdColonyAdSize) {
    this.b = paramAdColonyAdSize;
  }
  
  void a(p0 paramp0) {
    this.c = paramp0;
  }
  
  void a(@NonNull String paramString) {
    this.a = paramString;
  }
  
  p0 b() {
    return this.c;
  }
  
  @NonNull
  String c() {
    return this.a;
  }
  
  public void onClicked(AdColonyAdView paramAdColonyAdView) {}
  
  public void onClosed(AdColonyAdView paramAdColonyAdView) {}
  
  public void onLeftApplication(AdColonyAdView paramAdColonyAdView) {}
  
  public void onOpened(AdColonyAdView paramAdColonyAdView) {}
  
  public abstract void onRequestFilled(AdColonyAdView paramAdColonyAdView);
  
  public void onRequestNotFilled(AdColonyZone paramAdColonyZone) {}
  
  public void onShow(AdColonyAdView paramAdColonyAdView) {}
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\AdColonyAdViewListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */