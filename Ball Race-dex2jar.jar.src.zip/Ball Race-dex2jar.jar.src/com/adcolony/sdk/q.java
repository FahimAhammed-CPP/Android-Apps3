package com.adcolony.sdk;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Insets;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.provider.Settings;
import android.security.NetworkSecurityPolicy;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.WindowMetrics;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.appset.AppSet;
import com.google.android.gms.appset.AppSetIdInfo;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.Callable;

@SuppressLint({"ObsoleteSdkInt"})
class q {
  private final f a = new f();
  
  private final f b = new f();
  
  private String c = "";
  
  private boolean d;
  
  private String e = "";
  
  private f1 f = c0.b();
  
  private String g = "";
  
  boolean A() {
    return this.d;
  }
  
  String B() {
    return "";
  }
  
  String C() {
    return Build.MANUFACTURER;
  }
  
  int D() {
    Context context = a.a();
    if (context == null)
      return 0; 
    ActivityManager activityManager = (ActivityManager)context.getSystemService("activity");
    return (activityManager == null) ? 0 : activityManager.getMemoryClass();
  }
  
  long E() {
    Runtime runtime = Runtime.getRuntime();
    return (runtime.totalMemory() - runtime.freeMemory()) / 1048576L;
  }
  
  String F() {
    return Build.MODEL;
  }
  
  @SuppressLint({"SwitchIntDef"})
  int G() {
    Context context = a.a();
    if (context == null)
      return 2; 
    int i = (context.getResources().getConfiguration()).orientation;
    return (i != 1) ? ((i != 2) ? 2 : 1) : 0;
  }
  
  String H() {
    return Build.VERSION.RELEASE;
  }
  
  String I() {
    return "4.8.0";
  }
  
  String J() {
    Context context = a.a();
    if (context == null)
      return ""; 
    TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService("phone");
    return (telephonyManager == null) ? "" : telephonyManager.getSimCountryIso();
  }
  
  int K() {
    return TimeZone.getDefault().getOffset(15L) / 60000;
  }
  
  String L() {
    return TimeZone.getDefault().getID();
  }
  
  void M() {
    a(false);
    b(false);
    a.a("Device.get_info", new a(this));
  }
  
  boolean N() {
    return this.a.a();
  }
  
  boolean O() {
    return this.b.a();
  }
  
  boolean P() {
    Context context = a.a();
    boolean bool = false;
    if (context == null)
      return false; 
    DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
    float f2 = displayMetrics.widthPixels / displayMetrics.xdpi;
    float f3 = displayMetrics.heightPixels / displayMetrics.ydpi;
    if (Math.sqrt((f2 * f2 + f3 * f3)) >= 6.0D)
      bool = true; 
    return bool;
  }
  
  String a() {
    return System.getProperty("os.arch").toLowerCase(Locale.ENGLISH);
  }
  
  Callable<f1> a(long paramLong) {
    return new b(this, paramLong);
  }
  
  void a(@Nullable Context paramContext) {
    a(paramContext, null);
  }
  
  void a(@Nullable Context paramContext, @Nullable y<String> paramy) {
    if (paramContext == null) {
      if (paramy != null)
        paramy.a(new Throwable("Context cannot be null.")); 
    } else {
      if (f().isEmpty())
        a(false); 
      if (z0.a(new c(this, paramContext, paramy)))
        return; 
      (new e0.a()).a("Executing Query Advertising ID failed.").a(e0.i);
      if (paramy != null)
        paramy.a(new Throwable("Query Advertising ID failed on execute.")); 
    } 
    a(true);
  }
  
  void a(f1 paramf1) {
    this.f = paramf1;
  }
  
  void a(String paramString) {
    this.c = paramString;
  }
  
  void a(boolean paramBoolean) {
    this.a.a(paramBoolean);
  }
  
  f1 b() {
    f1 f11 = c0.b();
    String str = f();
    c0.a(f11, "advertiser_id", str);
    c0.b(f11, "limit_tracking", A());
    if (str == null || str.isEmpty())
      c0.a(f11, "android_id_sha1", z0.b(i())); 
    return f11;
  }
  
  Callable<f1> b(long paramLong) {
    return new d(this, paramLong);
  }
  
  void b(@Nullable Context paramContext) {
    b(paramContext, null);
  }
  
  void b(@Nullable Context paramContext, @Nullable y<String> paramy) {
    if (paramContext == null) {
      if (paramy != null)
        paramy.a(new Throwable("Context cannot be null.")); 
    } else if (!k().isEmpty()) {
      if (paramy != null)
        paramy.a(k()); 
    } else {
      b(false);
      try {
        AppSet.getClient(paramContext.getApplicationContext()).getAppSetIdInfo().addOnCompleteListener(new e(this, paramy));
        return;
      } catch (NoClassDefFoundError|NoSuchMethodError noClassDefFoundError) {
        (new e0.a()).a("Google Play Services App Set dependency is missing.").a(e0.f);
      } catch (Exception exception) {
        (new e0.a()).a("Query App Set ID failed with: ").a(Log.getStackTraceString(exception)).a(e0.g);
      } 
      (new e0.a()).a("App Set ID is not available.").a(e0.f);
      if (paramy != null)
        paramy.a(new Throwable("App Set ID is not available.")); 
    } 
    b(true);
  }
  
  public void b(String paramString) {
    this.e = paramString;
  }
  
  void b(boolean paramBoolean) {
    this.b.a(paramBoolean);
  }
  
  f1 c() {
    f1 f11 = c0.b();
    c0.a(f11, "app_set_id", k());
    return f11;
  }
  
  f1 c(long paramLong) {
    if (paramLong <= 0L)
      return c0.a(new f1[] { d(), b(), c() }); 
    ArrayList<f1> arrayList = new ArrayList(Collections.singletonList(d()));
    q0 q0 = new q0();
    if (N()) {
      arrayList.add(b());
    } else {
      q0.a(a(paramLong));
    } 
    if (O()) {
      arrayList.add(c());
    } else {
      q0.a(b(paramLong));
    } 
    if (!q0.b())
      arrayList.addAll(q0.a()); 
    return c0.a(arrayList.<f1>toArray(new f1[0]));
  }
  
  void c(String paramString) {
    this.g = paramString;
  }
  
  void c(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  f1 d() {
    f1 f11 = c0.b();
    k k = a.b();
    c0.a(f11, "carrier_name", m());
    c0.a(f11, "data_path", k.z().b());
    c0.b(f11, "device_api", j());
    Rect rect = w();
    c0.b(f11, "screen_width", rect.width());
    c0.b(f11, "screen_height", rect.height());
    c0.b(f11, "display_dpi", v());
    c0.a(f11, "device_type", u());
    c0.a(f11, "locale_language_code", y());
    c0.a(f11, "ln", y());
    c0.a(f11, "locale_country_code", p());
    c0.a(f11, "locale", p());
    c0.a(f11, "mac_address", B());
    c0.a(f11, "manufacturer", C());
    c0.a(f11, "device_brand", C());
    c0.a(f11, "media_path", k.z().c());
    c0.a(f11, "temp_storage_path", k.z().d());
    c0.b(f11, "memory_class", D());
    c0.b(f11, "memory_used_mb", E());
    c0.a(f11, "model", F());
    c0.a(f11, "device_model", F());
    c0.a(f11, "sdk_type", "android_native");
    c0.a(f11, "sdk_version", I());
    c0.a(f11, "network_type", k.s().e());
    c0.a(f11, "os_version", H());
    c0.a(f11, "os_name", "android");
    c0.a(f11, "platform", "android");
    c0.a(f11, "arch", a());
    c0.a(f11, "user_id", c0.h(k.u().b(), "user_id"));
    c0.a(f11, "app_id", k.u().a());
    c0.a(f11, "app_bundle_name", z0.b());
    c0.a(f11, "app_bundle_version", z0.c());
    c0.a(f11, "battery_level", l());
    c0.a(f11, "cell_service_country_code", J());
    c0.a(f11, "timezone_ietf", L());
    c0.b(f11, "timezone_gmt_m", K());
    c0.b(f11, "timezone_dst_m", q());
    c0.a(f11, "launch_metadata", z());
    c0.a(f11, "controller_version", k.f());
    c0.b(f11, "current_orientation", G());
    c0.b(f11, "cleartext_permitted", n());
    c0.a(f11, "density", s());
    c0.b(f11, "dark_mode", r());
    c0.a(f11, "adc_alt_id", e());
    e1 e1 = c0.a();
    if (z0.c("com.android.vending"))
      e1.b("google"); 
    if (z0.c("com.amazon.venezia"))
      e1.b("amazon"); 
    if (z0.c("com.huawei.appmarket"))
      e1.b("huawei"); 
    if (z0.c("com.sec.android.app.samsungapps"))
      e1.b("samsung"); 
    c0.a(f11, "available_stores", e1);
    return f11;
  }
  
  String e() {
    return z0.a(a.b().z());
  }
  
  String f() {
    return this.c;
  }
  
  @Nullable
  String g() {
    Context context = a.a();
    return (context == null) ? null : Settings.Secure.getString(context.getContentResolver(), "advertising_id");
  }
  
  boolean h() {
    Context context = a.a();
    boolean bool = false;
    if (context == null)
      return false; 
    try {
      int i = Settings.Secure.getInt(context.getContentResolver(), "limit_ad_tracking");
      if (i != 0)
        bool = true; 
      return bool;
    } catch (android.provider.Settings.SettingNotFoundException settingNotFoundException) {
      return false;
    } 
  }
  
  @SuppressLint({"HardwareIds"})
  String i() {
    Context context = a.a();
    return (context == null) ? "" : Settings.Secure.getString(context.getContentResolver(), "android_id");
  }
  
  int j() {
    return Build.VERSION.SDK_INT;
  }
  
  public String k() {
    return this.e;
  }
  
  double l() {
    Context context = a.a();
    double d = 0.0D;
    if (context == null)
      return 0.0D; 
    try {
      Intent intent = context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
      if (intent == null)
        return 0.0D; 
      int i = intent.getIntExtra("level", -1);
      int j = intent.getIntExtra("scale", -1);
      if (i >= 0) {
        if (j < 0)
          return 0.0D; 
        d = i / j;
      } 
      return d;
    } catch (RuntimeException runtimeException) {
      return 0.0D;
    } 
  }
  
  String m() {
    Context context = a.a();
    String str1 = "";
    if (context == null)
      return ""; 
    TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService("phone");
    if (telephonyManager != null)
      str1 = telephonyManager.getNetworkOperatorName(); 
    String str2 = str1;
    if (str1.length() == 0)
      str2 = "unknown"; 
    return str2;
  }
  
  boolean n() {
    return (Build.VERSION.SDK_INT < 23 || NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted());
  }
  
  String o() {
    return this.g;
  }
  
  String p() {
    return Locale.getDefault().getCountry();
  }
  
  int q() {
    TimeZone timeZone = TimeZone.getDefault();
    return !timeZone.inDaylightTime(new Date()) ? 0 : (timeZone.getDSTSavings() / 60000);
  }
  
  boolean r() {
    Context context = a.a();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (context != null) {
      if (Build.VERSION.SDK_INT < 29)
        return false; 
      int i = (context.getResources().getConfiguration()).uiMode & 0x30;
      bool1 = bool2;
      if (i != 16) {
        if (i != 32)
          return false; 
        bool1 = true;
      } 
    } 
    return bool1;
  }
  
  float s() {
    Context context = a.a();
    return (context == null) ? 0.0F : (context.getResources().getDisplayMetrics()).density;
  }
  
  f1 t() {
    if (!N())
      try {
        return z0.b(c0.a(new f1[] { d(), a(2000L).call() }));
      } catch (Exception exception) {} 
    return z0.b(c0.a(new f1[] { d(), b() }));
  }
  
  String u() {
    return P() ? "tablet" : "phone";
  }
  
  int v() {
    Context context = a.a();
    if (context != null)
      if (Build.VERSION.SDK_INT < 17) {
        try {
          WindowManager windowManager = (WindowManager)context.getSystemService("window");
          if (windowManager != null) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
            return displayMetrics.densityDpi;
          } 
        } catch (RuntimeException runtimeException) {}
      } else {
        return (runtimeException.getResources().getConfiguration()).densityDpi;
      }  
    return 0;
  }
  
  Rect w() {
    Rect rect2 = new Rect();
    Context context = a.a();
    Rect rect1 = rect2;
    if (context != null)
      try {
        Rect rect;
        WindowManager windowManager = (WindowManager)context.getSystemService("window");
        rect1 = rect2;
        if (windowManager != null) {
          DisplayMetrics displayMetrics = new DisplayMetrics();
          windowManager.getDefaultDisplay().getMetrics(displayMetrics);
          rect = new Rect(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        } 
        return rect;
      } catch (RuntimeException runtimeException) {
        return rect2;
      }  
    return (Rect)runtimeException;
  }
  
  Rect x() {
    int i;
    int j;
    int k;
    Point point1;
    Point point2;
    Rect rect = new Rect();
    Context context = a.a();
    if (context != null) {
      try {
        WindowManager windowManager = (WindowManager)context.getSystemService("window");
        if (windowManager != null) {
          Display display;
          i = Build.VERSION.SDK_INT;
          if (i < 17) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
            return new Rect(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels - z0.f(context));
          } 
          if (i < 30) {
            DisplayMetrics displayMetrics1 = new DisplayMetrics();
            DisplayMetrics displayMetrics2 = new DisplayMetrics();
            display = windowManager.getDefaultDisplay();
            display.getMetrics(displayMetrics1);
            display.getRealMetrics(displayMetrics2);
            i = z0.f(context);
            j = z0.b(context);
            k = displayMetrics2.heightPixels - displayMetrics1.heightPixels;
            if (k <= 0)
              return new Rect(0, 0, displayMetrics1.widthPixels, displayMetrics1.heightPixels - i); 
          } else {
            Rect rect1;
            WindowMetrics windowMetrics = display.getCurrentWindowMetrics();
            try {
              Point point;
              point1 = new Point();
              point2 = new Point();
              context.getDisplay().getCurrentSizeRange(point1, point2);
              if (windowMetrics.getBounds().width() > windowMetrics.getBounds().height()) {
                i = 2;
              } else {
                i = 1;
              } 
              if (i == 2) {
                point = new Point(point2.x, point1.y);
              } else {
                point = new Point(point1.x, point2.y);
              } 
              return new Rect(0, 0, point.x, point.y);
            } catch (UnsupportedOperationException unsupportedOperationException) {
              Insets insets = windowMetrics.getWindowInsets().getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.statusBars());
              rect1 = new Rect(0, 0, windowMetrics.getBounds().width() - insets.right + insets.left, windowMetrics.getBounds().height() - insets.top + insets.bottom);
            } 
            return rect1;
          } 
        } else {
          return rect;
        } 
      } catch (RuntimeException runtimeException) {
        return rect;
      } 
    } else {
      return rect;
    } 
    return (j <= 0 || (k <= i && j > i)) ? new Rect(0, 0, ((DisplayMetrics)point1).widthPixels, ((DisplayMetrics)point2).heightPixels - i) : new Rect(0, 0, ((DisplayMetrics)point1).widthPixels, ((DisplayMetrics)point2).heightPixels - j + i);
  }
  
  String y() {
    return Locale.getDefault().getLanguage();
  }
  
  f1 z() {
    return this.f;
  }
  
  class a implements j0 {
    a(q this$0) {}
    
    public void a(h0 param1h0) {
      if (!z0.a(new a(this, param1h0))) {
        (new e0.a()).a("Error retrieving device info, disabling AdColony.").a(e0.i);
        AdColony.disable();
      } 
    }
    
    class a implements Runnable {
      a(q.a this$0, h0 param2h0) {}
      
      public void run() {
        z0.b(new a(this, a.b().n().c(2000L)));
      }
      
      class a implements Runnable {
        a(q.a.a this$0, f1 param3f1) {}
        
        public void run() {
          this.b.a.a(this.a).c();
        }
      }
    }
    
    class a implements Runnable {
      a(q.a this$0, f1 param2f1) {}
      
      public void run() {
        this.b.a.a(this.a).c();
      }
    }
  }
  
  class a implements Runnable {
    a(q this$0, h0 param1h0) {}
    
    public void run() {
      z0.b(new a(this, a.b().n().c(2000L)));
    }
    
    class a implements Runnable {
      a(q.a.a this$0, f1 param3f1) {}
      
      public void run() {
        this.b.a.a(this.a).c();
      }
    }
  }
  
  class a implements Runnable {
    a(q this$0, f1 param1f1) {}
    
    public void run() {
      this.b.a.a(this.a).c();
    }
  }
  
  class b implements Callable<f1> {
    b(q this$0, long param1Long) {}
    
    public f1 b() {
      if (!this.b.N() && this.a > 0L)
        q.a(this.b).a(this.a); 
      return this.b.b();
    }
  }
  
  class c implements Runnable {
    c(q this$0, Context param1Context, y param1y) {}
    
    public void run() {
      boolean bool;
      String str;
      if (a.e) {
        str = "00000000-0000-0000-0000-000000000000";
        bool = true;
      } else {
        String str4 = null;
        String str5 = null;
        String str1 = null;
        boolean bool1 = false;
        str = str1;
        String str2 = str4;
        String str3 = str5;
        try {
          AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(this.a);
          str = str1;
          str2 = str4;
          str3 = str5;
          str1 = info.getId();
          str = str1;
          str2 = str1;
          str3 = str1;
          boolean bool2 = info.isLimitAdTrackingEnabled();
          bool1 = bool2;
        } catch (NoClassDefFoundError noClassDefFoundError) {
          (new e0.a()).a("Google Play Services Ads dependencies are missing.").a(e0.f);
          String str6 = str2;
        } catch (NoSuchMethodError noSuchMethodError) {
          (new e0.a()).a("Google Play Services is out of date, please update to GPS 4.0+.").a(e0.f);
          String str6 = str3;
        } catch (Exception exception) {
          (new e0.a()).a("Query Advertising ID failed with: ").a(Log.getStackTraceString(exception)).a(e0.g);
          str1 = str;
        } 
        str = str1;
        bool = bool1;
        if (str1 == null) {
          str = str1;
          bool = bool1;
          if (Build.MANUFACTURER.equals("Amazon")) {
            str = this.c.g();
            bool = this.c.h();
          } 
        } 
      } 
      if (str == null) {
        (new e0.a()).a("Advertising ID is not available. ").a("Collecting Android ID instead of Advertising ID.").a(e0.f);
        y y1 = this.b;
        if (y1 != null)
          y1.a(new Throwable("Advertising ID is not available.")); 
      } else {
        this.c.a(str);
        s0 s0 = a.b().q().a();
        if (s0 != null)
          s0.d.put("advertisingId", this.c.f()); 
        this.c.c(bool);
        y y1 = this.b;
        if (y1 != null)
          y1.a(this.c.f()); 
      } 
      this.c.a(true);
    }
  }
  
  class d implements Callable<f1> {
    d(q this$0, long param1Long) {}
    
    public f1 b() {
      if (!this.b.O() && this.a > 0L)
        q.b(this.b).a(this.a); 
      return this.b.c();
    }
  }
  
  class e implements OnCompleteListener<AppSetIdInfo> {
    e(q this$0, y param1y) {}
    
    public void onComplete(@NonNull Task<AppSetIdInfo> param1Task) {
      y y1;
      if (param1Task.isSuccessful()) {
        this.b.b(((AppSetIdInfo)param1Task.getResult()).getId());
        y1 = this.a;
        if (y1 != null)
          y1.a(this.b.k()); 
      } else {
        Throwable throwable;
        if (y1.getException() != null) {
          throwable = y1.getException();
        } else {
          throwable = new Throwable("Task failed with unknown exception.");
        } 
        (new e0.a()).a("App Set ID is not available. Unexpected exception occurred: ").a(Log.getStackTraceString(throwable)).a(e0.g);
        y y2 = this.a;
        if (y2 != null)
          y2.a(throwable); 
      } 
      this.b.b(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */