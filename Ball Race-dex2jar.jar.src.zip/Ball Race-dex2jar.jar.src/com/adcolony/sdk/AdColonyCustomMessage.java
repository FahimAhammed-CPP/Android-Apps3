package com.adcolony.sdk;

import androidx.annotation.NonNull;

public class AdColonyCustomMessage {
  private String a;
  
  private String b;
  
  public AdColonyCustomMessage(@NonNull String paramString1, @NonNull String paramString2) {
    if (z0.e(paramString1) || z0.e(paramString2)) {
      this.a = paramString1;
      this.b = paramString2;
    } 
  }
  
  public String getMessage() {
    return this.b;
  }
  
  public String getType() {
    return this.a;
  }
  
  public void send() {
    AdColony.a(new a(this));
  }
  
  public AdColonyCustomMessage set(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
    return this;
  }
  
  class a implements Runnable {
    a(AdColonyCustomMessage this$0) {}
    
    public void run() {
      AdColony.b();
      f1 f1 = c0.b();
      c0.a(f1, "type", AdColonyCustomMessage.a(this.a));
      c0.a(f1, "message", AdColonyCustomMessage.b(this.a));
      (new h0("CustomMessage.native_send", 1, f1)).c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\AdColonyCustomMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */