package com.adcolony.sdk;

public abstract class AdColonySignalsListener {
  public void onFailure() {}
  
  public abstract void onSuccess(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\AdColonySignalsListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */