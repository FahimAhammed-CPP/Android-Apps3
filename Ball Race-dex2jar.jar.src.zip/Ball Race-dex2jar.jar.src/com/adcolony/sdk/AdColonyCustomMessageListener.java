package com.adcolony.sdk;

public interface AdColonyCustomMessageListener {
  void onAdColonyCustomMessage(AdColonyCustomMessage paramAdColonyCustomMessage);
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\AdColonyCustomMessageListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */