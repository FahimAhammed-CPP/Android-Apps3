package com.adcolony.sdk;

import com.safedk.android.internal.partials.AdColonyFilesBridge;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.util.LinkedList;
import java.util.zip.GZIPInputStream;
import org.json.JSONException;

class w {
  private LinkedList<Runnable> a = new LinkedList<Runnable>();
  
  private boolean b;
  
  private void a() {
    this.b = false;
    if (!this.a.isEmpty()) {
      this.b = true;
      ((Runnable)this.a.removeLast()).run();
    } 
  }
  
  private void a(Runnable paramRunnable) {
    if (this.a.isEmpty() && !this.b) {
      this.b = true;
      paramRunnable.run();
      return;
    } 
    this.a.push(paramRunnable);
  }
  
  private boolean a(h0 paramh0) {
    String str = c0.h(paramh0.a(), "filepath");
    a.b().z().h();
    f1 f1 = c0.b();
    try {
      if ((new File(str)).mkdir()) {
        c0.b(f1, "success", true);
        paramh0.a(f1).c();
        return true;
      } 
      c0.b(f1, "success", false);
      return false;
    } catch (Exception exception) {
      c0.b(f1, "success", false);
      paramh0.a(f1).c();
      return false;
    } 
  }
  
  private boolean a(h0 paramh0, File paramFile) {
    a.b().z().h();
    f1 f1 = c0.b();
    if (a(paramFile)) {
      c0.b(f1, "success", true);
      paramh0.a(f1).c();
      return true;
    } 
    c0.b(f1, "success", false);
    paramh0.a(f1).c();
    return false;
  }
  
  private boolean a(String paramString) {
    return (new File(paramString)).exists();
  }
  
  private boolean b(h0 paramh0) {
    String str = c0.h(paramh0.a(), "filepath");
    a.b().z().h();
    f1 f1 = c0.b();
    try {
      boolean bool = a(str);
      c0.b(f1, "result", bool);
      c0.b(f1, "success", true);
      paramh0.a(f1).c();
      return bool;
    } catch (Exception exception) {
      c0.b(f1, "result", false);
      c0.b(f1, "success", false);
      paramh0.a(f1).c();
      exception.printStackTrace();
      return false;
    } 
  }
  
  private boolean c(h0 paramh0) {
    f1 f12 = paramh0.a();
    String str = c0.h(f12, "filepath");
    a.b().z().h();
    f1 f11 = c0.b();
    try {
      GZIPInputStream gZIPInputStream;
      StringBuilder stringBuilder;
      int i = c0.d(f12, "offset");
      int j = c0.d(f12, "size");
      boolean bool = c0.b(f12, "gunzip");
      String str1 = c0.h(f12, "output_filepath");
      w0 w0 = new w0(AdColonyFilesBridge.fileInputStreamCtor(str), i, j);
      if (bool)
        gZIPInputStream = new GZIPInputStream((InputStream)w0, 1024); 
      if (str1.equals("")) {
        stringBuilder = new StringBuilder(gZIPInputStream.available());
        byte[] arrayOfByte1 = new byte[1024];
        while (true) {
          i = gZIPInputStream.read(arrayOfByte1, 0, 1024);
          if (i >= 0) {
            stringBuilder.append(new String(arrayOfByte1, 0, i, "ISO-8859-1"));
            continue;
          } 
          c0.b(f11, "size", stringBuilder.length());
          c0.a(f11, "data", stringBuilder.toString());
          gZIPInputStream.close();
          c0.b(f11, "success", true);
          paramh0.a(f11).c();
          return true;
        } 
      } 
      FileOutputStream fileOutputStream = AdColonyFilesBridge.fileOutputStreamCtor((String)stringBuilder);
      byte[] arrayOfByte = new byte[1024];
      i = 0;
      while (true) {
        j = gZIPInputStream.read(arrayOfByte, 0, 1024);
        if (j >= 0) {
          fileOutputStream.write(arrayOfByte, 0, j);
          i += j;
          continue;
        } 
        fileOutputStream.close();
        c0.b(f11, "size", i);
        gZIPInputStream.close();
        c0.b(f11, "success", true);
        paramh0.a(f11).c();
        return true;
      } 
    } catch (IOException iOException) {
      c0.b(f11, "success", false);
      paramh0.a(f11).c();
      return false;
    } catch (OutOfMemoryError outOfMemoryError) {
      (new e0.a()).a("Out of memory error - disabling AdColony.").a(e0.h);
      a.b().b(true);
      c0.b(f11, "success", false);
      paramh0.a(f11).c();
      return false;
    } 
  }
  
  private boolean d(h0 paramh0) {
    String str = c0.h(paramh0.a(), "filepath");
    a.b().z().h();
    f1 f1 = c0.b();
    String[] arrayOfString = (new File(str)).list();
    if (arrayOfString != null) {
      e1 e1 = c0.a();
      int j = arrayOfString.length;
      for (int i = 0; i < j; i++) {
        String str1 = arrayOfString[i];
        f1 f11 = c0.b();
        c0.a(f11, "filename", str1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append(str1);
        if ((new File(stringBuilder.toString())).isDirectory()) {
          c0.b(f11, "is_folder", true);
        } else {
          c0.b(f11, "is_folder", false);
        } 
        c0.a(e1, f11);
      } 
      c0.b(f1, "success", true);
      c0.a(f1, "entries", e1);
      paramh0.a(f1).c();
      return true;
    } 
    c0.b(f1, "success", false);
    paramh0.a(f1).c();
    return false;
  }
  
  private String e(h0 paramh0) {
    boolean bool;
    f1 f12 = paramh0.a();
    String str2 = c0.h(f12, "filepath");
    String str1 = c0.h(f12, "encoding");
    if (str1 != null && str1.equals("utf8")) {
      bool = true;
    } else {
      bool = false;
    } 
    a.b().z().h();
    f1 f11 = c0.b();
    try {
      StringBuilder stringBuilder = a(str2, bool);
      c0.b(f11, "success", true);
      c0.a(f11, "data", stringBuilder.toString());
      paramh0.a(f11).c();
      return stringBuilder.toString();
    } catch (IOException iOException) {
      c0.b(f11, "success", false);
      paramh0.a(f11).c();
      return "";
    } 
  }
  
  private boolean f(h0 paramh0) {
    f1 f1 = paramh0.a();
    String str1 = c0.h(f1, "filepath");
    String str2 = c0.h(f1, "new_filepath");
    a.b().z().h();
    f1 = c0.b();
    try {
      if ((new File(str1)).renameTo(new File(str2))) {
        c0.b(f1, "success", true);
        paramh0.a(f1).c();
        return true;
      } 
      c0.b(f1, "success", false);
      paramh0.a(f1).c();
      return false;
    } catch (Exception exception) {
      c0.b(f1, "success", false);
      paramh0.a(f1).c();
      return false;
    } 
  }
  
  private boolean g(h0 paramh0) {
    f1 f1 = paramh0.a();
    String str1 = c0.h(f1, "filepath");
    String str2 = c0.h(f1, "data");
    boolean bool = c0.h(f1, "encoding").equals("utf8");
    a.b().z().h();
    f1 = c0.b();
    try {
      a(str1, str2, bool);
      c0.b(f1, "success", true);
      paramh0.a(f1).c();
      return true;
    } catch (IOException iOException) {
      c0.b(f1, "success", false);
      paramh0.a(f1).c();
      return false;
    } 
  }
  
  private boolean h(h0 paramh0) {
    f1 f11 = paramh0.a();
    String str1 = c0.h(f11, "filepath");
    String str2 = c0.h(f11, "bundle_path");
    e1 e1 = c0.a(f11, "bundle_filenames");
    a.b().z().h();
    f1 f12 = c0.b();
    try {
      File file = new File(str2);
      RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
      byte[] arrayOfByte1 = new byte[32];
      randomAccessFile.readInt();
      int j = randomAccessFile.readInt();
      e1 e11 = new e1();
      byte[] arrayOfByte2 = new byte[1024];
      int i = 0;
      while (true) {
        if (i < j) {
          randomAccessFile.seek((i * 44 + 8));
          randomAccessFile.read(arrayOfByte1);
          randomAccessFile.readInt();
          int k = randomAccessFile.readInt();
          int m = randomAccessFile.readInt();
          e11.f(m);
          try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str1);
            stringBuilder.append(e1.a(i));
            String str = stringBuilder.toString();
            long l = k;
            randomAccessFile.seek(l);
            FileOutputStream fileOutputStream = AdColonyFilesBridge.fileOutputStreamCtor(str);
            k = m / 1024;
            int n = m % 1024;
            for (m = 0; m < k; m++) {
              randomAccessFile.read(arrayOfByte2, 0, 1024);
              fileOutputStream.write(arrayOfByte2, 0, 1024);
            } 
            randomAccessFile.read(arrayOfByte2, 0, n);
            fileOutputStream.write(arrayOfByte2, 0, n);
            fileOutputStream.close();
            i++;
            continue;
          } catch (JSONException jSONException) {
            (new e0.a()).a("Couldn't extract file name at index ").a(i).a(" unpacking ad unit bundle at ").a(str2).a(e0.h);
            try {
              c0.b(f12, "success", false);
              paramh0.a(f12).c();
              return false;
            } catch (IOException iOException) {}
          } 
        } else {
          randomAccessFile.close();
          iOException.delete();
          c0.b(f12, "success", true);
          c0.a(f12, "file_sizes", e11);
          paramh0.a(f12).c();
          return true;
        } 
        (new e0.a()).a("Failed to find or open ad unit bundle at path: ").a(str2).a(e0.i);
        c0.b(f12, "success", false);
        paramh0.a(f12).c();
        return false;
      } 
    } catch (IOException iOException) {
      (new e0.a()).a("Failed to find or open ad unit bundle at path: ").a(str2).a(e0.i);
      c0.b(f12, "success", false);
      paramh0.a(f12).c();
      return false;
    } catch (OutOfMemoryError outOfMemoryError) {
      (new e0.a()).a("Out of memory error - disabling AdColony.").a(e0.h);
      a.b().b(true);
      c0.b(f12, "success", false);
      paramh0.a(f12).c();
      return false;
    } 
  }
  
  StringBuilder a(String paramString, boolean paramBoolean) throws IOException {
    BufferedReader bufferedReader;
    File file = new File(paramString);
    StringBuilder stringBuilder = new StringBuilder((int)file.length());
    if (paramBoolean) {
      bufferedReader = new BufferedReader(new InputStreamReader(AdColonyFilesBridge.fileInputStreamCtor(file.getAbsolutePath()), h.a));
    } else {
      bufferedReader = new BufferedReader(new InputStreamReader(AdColonyFilesBridge.fileInputStreamCtor(bufferedReader.getAbsolutePath())));
    } 
    while (true) {
      String str = bufferedReader.readLine();
      if (str != null) {
        stringBuilder.append(str);
        stringBuilder.append("\n");
        continue;
      } 
      bufferedReader.close();
      return stringBuilder;
    } 
  }
  
  void a(String paramString1, String paramString2, boolean paramBoolean) throws IOException {
    BufferedWriter bufferedWriter;
    if (paramBoolean) {
      bufferedWriter = new BufferedWriter(new OutputStreamWriter(AdColonyFilesBridge.fileOutputStreamCtor(paramString1), h.a));
    } else {
      bufferedWriter = new BufferedWriter(new OutputStreamWriter(AdColonyFilesBridge.fileOutputStreamCtor((String)bufferedWriter)));
    } 
    bufferedWriter.write(paramString2);
    bufferedWriter.flush();
    bufferedWriter.close();
  }
  
  boolean a(File paramFile) {
    try {
      if (paramFile.isDirectory()) {
        if ((paramFile.list()).length == 0)
          return paramFile.delete(); 
        String[] arrayOfString = paramFile.list();
        if (arrayOfString.length > 0)
          return a(new File(paramFile, arrayOfString[0])); 
        if ((paramFile.list()).length == 0)
          return paramFile.delete(); 
      } else {
        return paramFile.delete();
      } 
    } catch (Exception exception) {
      return false;
    } 
    return false;
  }
  
  void b() {
    a.a("FileSystem.save", new a(this));
    a.a("FileSystem.delete", new b(this));
    a.a("FileSystem.listing", new c(this));
    a.a("FileSystem.load", new d(this));
    a.a("FileSystem.rename", new e(this));
    a.a("FileSystem.exists", new f(this));
    a.a("FileSystem.extract", new g(this));
    a.a("FileSystem.unpack_bundle", new h(this));
    a.a("FileSystem.create_directory", new i(this));
  }
  
  class a implements j0 {
    a(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.a this$0, h0 param2h0) {}
      
      public void run() {
        w.a(this.b.a, this.a);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      w.a(this.b.a, this.a);
      w.a(this.b.a);
    }
  }
  
  class b implements j0 {
    b(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.b this$0, h0 param2h0) {}
      
      public void run() {
        File file = new File(c0.h(this.a.a(), "filepath"));
        w.a(this.b.a, this.a, file);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      File file = new File(c0.h(this.a.a(), "filepath"));
      w.a(this.b.a, this.a, file);
      w.a(this.b.a);
    }
  }
  
  class c implements j0 {
    c(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.c this$0, h0 param2h0) {}
      
      public void run() {
        w.c(this.b.a, this.a);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      w.c(this.b.a, this.a);
      w.a(this.b.a);
    }
  }
  
  class d implements j0 {
    d(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.d this$0, h0 param2h0) {}
      
      public void run() {
        w.d(this.b.a, this.a);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      w.d(this.b.a, this.a);
      w.a(this.b.a);
    }
  }
  
  class e implements j0 {
    e(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.e this$0, h0 param2h0) {}
      
      public void run() {
        w.e(this.b.a, this.a);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      w.e(this.b.a, this.a);
      w.a(this.b.a);
    }
  }
  
  class f implements j0 {
    f(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.f this$0, h0 param2h0) {}
      
      public void run() {
        w.f(this.b.a, this.a);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      w.f(this.b.a, this.a);
      w.a(this.b.a);
    }
  }
  
  class g implements j0 {
    g(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.g this$0, h0 param2h0) {}
      
      public void run() {
        w.g(this.b.a, this.a);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      w.g(this.b.a, this.a);
      w.a(this.b.a);
    }
  }
  
  class h implements j0 {
    h(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.h this$0, h0 param2h0) {}
      
      public void run() {
        w.h(this.b.a, this.a);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      w.h(this.b.a, this.a);
      w.a(this.b.a);
    }
  }
  
  class i implements j0 {
    i(w this$0) {}
    
    public void a(h0 param1h0) {
      w.a(this.a, new a(this, param1h0));
    }
    
    class a implements Runnable {
      a(w.i this$0, h0 param2h0) {}
      
      public void run() {
        w.b(this.b.a, this.a);
        w.a(this.b.a);
      }
    }
  }
  
  class a implements Runnable {
    a(w this$0, h0 param1h0) {}
    
    public void run() {
      w.b(this.b.a, this.a);
      w.a(this.b.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */