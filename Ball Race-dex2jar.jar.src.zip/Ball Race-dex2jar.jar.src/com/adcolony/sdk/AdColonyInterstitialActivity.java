package com.adcolony.sdk;

import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import androidx.annotation.NonNull;
import com.safedk.android.analytics.brandsafety.DetectTouchUtils;

public class AdColonyInterstitialActivity extends b {
  AdColonyInterstitial j;
  
  private i k;
  
  public AdColonyInterstitialActivity() {
    AdColonyInterstitial adColonyInterstitial;
    if (!a.d()) {
      adColonyInterstitial = null;
    } else {
      adColonyInterstitial = a.b().j();
    } 
    this.j = adColonyInterstitial;
  }
  
  void a(h0 paramh0) {
    super.a(paramh0);
    d d = a.b().c();
    f1 f1 = c0.f(paramh0.a(), "v4iap");
    e1 e1 = c0.a(f1, "product_ids");
    AdColonyInterstitial adColonyInterstitial = this.j;
    if (adColonyInterstitial != null && adColonyInterstitial.getListener() != null) {
      String str = e1.e(0);
      if (str != null)
        this.j.getListener().onIAPEvent(this.j, str, c0.d(f1, "engagement_type")); 
    } 
    d.a(this.a);
    if (this.j != null) {
      d.f().remove(this.j.b());
      if (this.j.getListener() != null) {
        this.j.getListener().onClosed(this.j);
        this.j.a(null);
        this.j.setListener(null);
      } 
      this.j.o();
      this.j = null;
    } 
    i i1 = this.k;
    if (i1 != null) {
      i1.a();
      this.k = null;
    } 
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    DetectTouchUtils.activityOnTouch("com.jirbo.adcolony", paramMotionEvent);
    return super.dispatchTouchEvent(paramMotionEvent);
  }
  
  public void onCreate(Bundle paramBundle) {
    int j;
    AdColonyInterstitial adColonyInterstitial = this.j;
    if (adColonyInterstitial == null) {
      j = -1;
    } else {
      j = adColonyInterstitial.f();
    } 
    this.b = j;
    super.onCreate(paramBundle);
    if (a.d()) {
      AdColonyInterstitial adColonyInterstitial1 = this.j;
      if (adColonyInterstitial1 == null)
        return; 
      p0 p0 = adColonyInterstitial1.e();
      if (p0 != null)
        p0.a(this.a); 
      this.k = new i(new Handler(Looper.getMainLooper()), this.j);
      if (this.j.getListener() != null)
        this.j.getListener().onOpened(this.j); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Ball Race-dex2jar.jar!\com\adcolony\sdk\AdColonyInterstitialActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */