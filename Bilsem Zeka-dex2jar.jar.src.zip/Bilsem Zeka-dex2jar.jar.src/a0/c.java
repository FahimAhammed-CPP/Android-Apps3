package a0;

final class c<T> extends n<T> {
  private final T a;
  
  private final int b;
  
  public c(T paramT, int paramInt) {
    super(null);
    this.a = paramT;
    this.b = paramInt;
  }
  
  public final void a() {
    boolean bool1;
    T t = this.a;
    boolean bool2 = false;
    if (t != null) {
      bool1 = t.hashCode();
    } else {
      bool1 = false;
    } 
    if (bool1 == this.b)
      bool2 = true; 
    if (bool2)
      return; 
    throw new IllegalStateException("Data in DataStore was mutated but DataStore is only compatible with Immutable types.".toString());
  }
  
  public final T b() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */