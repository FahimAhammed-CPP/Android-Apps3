package a0;

import ab.l0;
import ab.v;
import ab.x;
import ga.u;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.t;
import kotlin.jvm.internal.v;

public final class m<T> implements f<T> {
  public static final a k = new a(null);
  
  private static final Set<String> l = new LinkedHashSet<String>();
  
  private static final Object m = new Object();
  
  private final qa.a<File> a;
  
  private final k<T> b;
  
  private final b<T> c;
  
  private final l0 d;
  
  private final kotlinx.coroutines.flow.b<T> e;
  
  private final String f;
  
  private final ga.h g;
  
  private final kotlinx.coroutines.flow.j<n<T>> h;
  
  private List<? extends qa.p<? super i<T>, ? super ja.d<? super u>, ? extends Object>> i;
  
  private final l<b<T>> j;
  
  public m(qa.a<? extends File> parama, k<T> paramk, List<? extends qa.p<? super i<T>, ? super ja.d<? super u>, ? extends Object>> paramList, b<T> paramb, l0 paraml0) {
    this.a = (qa.a)parama;
    this.b = paramk;
    this.c = paramb;
    this.d = paraml0;
    this.e = kotlinx.coroutines.flow.d.e(new g(this, null));
    this.f = ".tmp";
    this.g = ga.i.a(new h(this));
    this.h = kotlinx.coroutines.flow.m.a(o.a);
    this.i = ha.k.b0(paramList);
    this.j = new l<b<T>>(paraml0, new d(this), e.a, new f(this, null));
  }
  
  private final void q(File paramFile) {
    File file = paramFile.getCanonicalFile().getParentFile();
    if (file == null)
      return; 
    file.mkdirs();
    if (file.isDirectory())
      return; 
    throw new IOException(kotlin.jvm.internal.l.m("Unable to create parent directories of ", paramFile));
  }
  
  private final File r() {
    return (File)this.g.getValue();
  }
  
  private final Object s(b.a<T> parama, ja.d<? super u> paramd) {
    n<T> n = (n)this.h.getValue();
    if (!(n instanceof c))
      if (n instanceof j) {
        if (n == parama.a()) {
          Object object = w(paramd);
          return (object == ka.b.c()) ? object : u.a;
        } 
      } else {
        if (kotlin.jvm.internal.l.b(n, o.a)) {
          Object object = w(paramd);
          return (object == ka.b.c()) ? object : u.a;
        } 
        if (n instanceof h)
          throw new IllegalStateException("Can't read in final state.".toString()); 
      }  
    return u.a;
  }
  
  private final Object t(b.b<T> paramb, ja.d<? super u> paramd) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof a0/m$i
    //   4: ifeq -> 40
    //   7: aload_2
    //   8: checkcast a0/m$i
    //   11: astore #6
    //   13: aload #6
    //   15: getfield f : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #6
    //   29: iload_3
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield f : I
    //   37: goto -> 51
    //   40: new a0/m$i
    //   43: dup
    //   44: aload_0
    //   45: aload_2
    //   46: invokespecial <init> : (La0/m;Lja/d;)V
    //   49: astore #6
    //   51: aload #6
    //   53: getfield d : Ljava/lang/Object;
    //   56: astore #5
    //   58: invokestatic c : ()Ljava/lang/Object;
    //   61: astore #9
    //   63: aload #6
    //   65: getfield f : I
    //   68: istore_3
    //   69: iconst_1
    //   70: istore #4
    //   72: iload_3
    //   73: ifeq -> 178
    //   76: iload_3
    //   77: iconst_1
    //   78: if_icmpeq -> 155
    //   81: iload_3
    //   82: iconst_2
    //   83: if_icmpeq -> 114
    //   86: iload_3
    //   87: iconst_3
    //   88: if_icmpne -> 103
    //   91: aload #6
    //   93: getfield a : Ljava/lang/Object;
    //   96: checkcast ab/v
    //   99: astore_2
    //   100: goto -> 164
    //   103: new java/lang/IllegalStateException
    //   106: dup
    //   107: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   110: invokespecial <init> : (Ljava/lang/String;)V
    //   113: athrow
    //   114: aload #6
    //   116: getfield c : Ljava/lang/Object;
    //   119: checkcast ab/v
    //   122: astore_2
    //   123: aload #6
    //   125: getfield b : Ljava/lang/Object;
    //   128: checkcast a0/m
    //   131: astore #7
    //   133: aload #6
    //   135: getfield a : Ljava/lang/Object;
    //   138: checkcast a0/m$b$b
    //   141: astore #8
    //   143: aload_2
    //   144: astore_1
    //   145: aload #5
    //   147: invokestatic b : (Ljava/lang/Object;)V
    //   150: aload_2
    //   151: astore_1
    //   152: goto -> 386
    //   155: aload #6
    //   157: getfield a : Ljava/lang/Object;
    //   160: checkcast ab/v
    //   163: astore_2
    //   164: aload_2
    //   165: astore_1
    //   166: aload #5
    //   168: invokestatic b : (Ljava/lang/Object;)V
    //   171: goto -> 464
    //   174: astore_2
    //   175: goto -> 536
    //   178: aload #5
    //   180: invokestatic b : (Ljava/lang/Object;)V
    //   183: aload_1
    //   184: invokevirtual a : ()Lab/v;
    //   187: astore #5
    //   189: aload #5
    //   191: astore_2
    //   192: getstatic ga/o.a : Lga/o$a;
    //   195: astore #7
    //   197: aload #5
    //   199: astore_2
    //   200: aload_0
    //   201: getfield h : Lkotlinx/coroutines/flow/j;
    //   204: invokeinterface getValue : ()Ljava/lang/Object;
    //   209: checkcast a0/n
    //   212: astore #7
    //   214: aload #5
    //   216: astore_2
    //   217: aload #7
    //   219: instanceof a0/c
    //   222: ifeq -> 291
    //   225: aload #5
    //   227: astore_2
    //   228: aload_1
    //   229: invokevirtual d : ()Lqa/p;
    //   232: astore #7
    //   234: aload #5
    //   236: astore_2
    //   237: aload_1
    //   238: invokevirtual b : ()Lja/g;
    //   241: astore_1
    //   242: aload #5
    //   244: astore_2
    //   245: aload #6
    //   247: aload #5
    //   249: putfield a : Ljava/lang/Object;
    //   252: aload #5
    //   254: astore_2
    //   255: aload #6
    //   257: iconst_1
    //   258: putfield f : I
    //   261: aload #5
    //   263: astore_2
    //   264: aload_0
    //   265: aload #7
    //   267: aload_1
    //   268: aload #6
    //   270: invokespecial z : (Lqa/p;Lja/g;Lja/d;)Ljava/lang/Object;
    //   273: astore #6
    //   275: aload #6
    //   277: astore_2
    //   278: aload #5
    //   280: astore_1
    //   281: aload #6
    //   283: aload #9
    //   285: if_acmpne -> 559
    //   288: aload #9
    //   290: areturn
    //   291: aload #5
    //   293: astore_2
    //   294: aload #7
    //   296: instanceof a0/j
    //   299: ifeq -> 305
    //   302: goto -> 315
    //   305: aload #5
    //   307: astore_2
    //   308: aload #7
    //   310: instanceof a0/o
    //   313: istore #4
    //   315: iload #4
    //   317: ifeq -> 493
    //   320: aload #5
    //   322: astore_2
    //   323: aload #7
    //   325: aload_1
    //   326: invokevirtual c : ()La0/n;
    //   329: if_acmpne -> 481
    //   332: aload #5
    //   334: astore_2
    //   335: aload #6
    //   337: aload_1
    //   338: putfield a : Ljava/lang/Object;
    //   341: aload #5
    //   343: astore_2
    //   344: aload #6
    //   346: aload_0
    //   347: putfield b : Ljava/lang/Object;
    //   350: aload #5
    //   352: astore_2
    //   353: aload #6
    //   355: aload #5
    //   357: putfield c : Ljava/lang/Object;
    //   360: aload #5
    //   362: astore_2
    //   363: aload #6
    //   365: iconst_2
    //   366: putfield f : I
    //   369: aload #5
    //   371: astore_2
    //   372: aload_0
    //   373: aload #6
    //   375: invokespecial v : (Lja/d;)Ljava/lang/Object;
    //   378: aload #9
    //   380: if_acmpne -> 567
    //   383: aload #9
    //   385: areturn
    //   386: aload_1
    //   387: astore_2
    //   388: aload #8
    //   390: invokevirtual d : ()Lqa/p;
    //   393: astore #5
    //   395: aload_1
    //   396: astore_2
    //   397: aload #8
    //   399: invokevirtual b : ()Lja/g;
    //   402: astore #8
    //   404: aload_1
    //   405: astore_2
    //   406: aload #6
    //   408: aload_1
    //   409: putfield a : Ljava/lang/Object;
    //   412: aload_1
    //   413: astore_2
    //   414: aload #6
    //   416: aconst_null
    //   417: putfield b : Ljava/lang/Object;
    //   420: aload_1
    //   421: astore_2
    //   422: aload #6
    //   424: aconst_null
    //   425: putfield c : Ljava/lang/Object;
    //   428: aload_1
    //   429: astore_2
    //   430: aload #6
    //   432: iconst_3
    //   433: putfield f : I
    //   436: aload_1
    //   437: astore_2
    //   438: aload #7
    //   440: aload #5
    //   442: aload #8
    //   444: aload #6
    //   446: invokespecial z : (Lqa/p;Lja/g;Lja/d;)Ljava/lang/Object;
    //   449: astore #5
    //   451: aload #5
    //   453: astore_2
    //   454: aload #5
    //   456: aload #9
    //   458: if_acmpne -> 559
    //   461: aload #9
    //   463: areturn
    //   464: aload_2
    //   465: astore_1
    //   466: aload #5
    //   468: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   471: astore #5
    //   473: aload_2
    //   474: astore_1
    //   475: aload #5
    //   477: astore_2
    //   478: goto -> 549
    //   481: aload #5
    //   483: astore_2
    //   484: aload #7
    //   486: checkcast a0/j
    //   489: invokevirtual a : ()Ljava/lang/Throwable;
    //   492: athrow
    //   493: aload #5
    //   495: astore_2
    //   496: aload #7
    //   498: instanceof a0/h
    //   501: ifeq -> 516
    //   504: aload #5
    //   506: astore_2
    //   507: aload #7
    //   509: checkcast a0/h
    //   512: invokevirtual a : ()Ljava/lang/Throwable;
    //   515: athrow
    //   516: aload #5
    //   518: astore_2
    //   519: new ga/l
    //   522: dup
    //   523: invokespecial <init> : ()V
    //   526: athrow
    //   527: astore_1
    //   528: aload_2
    //   529: astore #5
    //   531: aload_1
    //   532: astore_2
    //   533: aload #5
    //   535: astore_1
    //   536: getstatic ga/o.a : Lga/o$a;
    //   539: astore #5
    //   541: aload_2
    //   542: invokestatic a : (Ljava/lang/Throwable;)Ljava/lang/Object;
    //   545: invokestatic a : (Ljava/lang/Object;)Ljava/lang/Object;
    //   548: astore_2
    //   549: aload_1
    //   550: aload_2
    //   551: invokestatic c : (Lab/v;Ljava/lang/Object;)Z
    //   554: pop
    //   555: getstatic ga/u.a : Lga/u;
    //   558: areturn
    //   559: aload_2
    //   560: astore #5
    //   562: aload_1
    //   563: astore_2
    //   564: goto -> 464
    //   567: aload_0
    //   568: astore #7
    //   570: aload_1
    //   571: astore #8
    //   573: aload #5
    //   575: astore_1
    //   576: goto -> 386
    // Exception table:
    //   from	to	target	type
    //   145	150	174	finally
    //   166	171	174	finally
    //   192	197	527	finally
    //   200	214	527	finally
    //   217	225	527	finally
    //   228	234	527	finally
    //   237	242	527	finally
    //   245	252	527	finally
    //   255	261	527	finally
    //   264	275	527	finally
    //   294	302	527	finally
    //   308	315	527	finally
    //   323	332	527	finally
    //   335	341	527	finally
    //   344	350	527	finally
    //   353	360	527	finally
    //   363	369	527	finally
    //   372	383	527	finally
    //   388	395	527	finally
    //   397	404	527	finally
    //   406	412	527	finally
    //   414	420	527	finally
    //   422	428	527	finally
    //   430	436	527	finally
    //   438	451	527	finally
    //   466	473	174	finally
    //   484	493	527	finally
    //   496	504	527	finally
    //   507	516	527	finally
    //   519	527	527	finally
  }
  
  private final Object u(ja.d<? super u> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof a0/m$j
    //   4: ifeq -> 40
    //   7: aload_1
    //   8: checkcast a0/m$j
    //   11: astore #6
    //   13: aload #6
    //   15: getfield i : I
    //   18: istore_2
    //   19: iload_2
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #6
    //   29: iload_2
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield i : I
    //   37: goto -> 51
    //   40: new a0/m$j
    //   43: dup
    //   44: aload_0
    //   45: aload_1
    //   46: invokespecial <init> : (La0/m;Lja/d;)V
    //   49: astore #6
    //   51: aload #6
    //   53: getfield g : Ljava/lang/Object;
    //   56: astore #8
    //   58: invokestatic c : ()Ljava/lang/Object;
    //   61: astore #12
    //   63: aload #6
    //   65: getfield i : I
    //   68: istore_2
    //   69: iconst_0
    //   70: istore_3
    //   71: iload_2
    //   72: ifeq -> 270
    //   75: iload_2
    //   76: iconst_1
    //   77: if_icmpeq -> 223
    //   80: iload_2
    //   81: iconst_2
    //   82: if_icmpeq -> 152
    //   85: iload_2
    //   86: iconst_3
    //   87: if_icmpne -> 141
    //   90: aload #6
    //   92: getfield d : Ljava/lang/Object;
    //   95: checkcast kotlinx/coroutines/sync/b
    //   98: astore #5
    //   100: aload #6
    //   102: getfield c : Ljava/lang/Object;
    //   105: checkcast kotlin/jvm/internal/t
    //   108: astore #7
    //   110: aload #6
    //   112: getfield b : Ljava/lang/Object;
    //   115: checkcast kotlin/jvm/internal/v
    //   118: astore_1
    //   119: aload #6
    //   121: getfield a : Ljava/lang/Object;
    //   124: checkcast a0/m
    //   127: astore #4
    //   129: aload #8
    //   131: invokestatic b : (Ljava/lang/Object;)V
    //   134: aload #7
    //   136: astore #6
    //   138: goto -> 659
    //   141: new java/lang/IllegalStateException
    //   144: dup
    //   145: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   148: invokespecial <init> : (Ljava/lang/String;)V
    //   151: athrow
    //   152: aload #6
    //   154: getfield f : Ljava/lang/Object;
    //   157: checkcast java/util/Iterator
    //   160: astore #9
    //   162: aload #6
    //   164: getfield e : Ljava/lang/Object;
    //   167: checkcast a0/m$k
    //   170: astore #10
    //   172: aload #6
    //   174: getfield d : Ljava/lang/Object;
    //   177: checkcast kotlin/jvm/internal/t
    //   180: astore_1
    //   181: aload #6
    //   183: getfield c : Ljava/lang/Object;
    //   186: checkcast kotlin/jvm/internal/v
    //   189: astore #7
    //   191: aload #6
    //   193: getfield b : Ljava/lang/Object;
    //   196: checkcast kotlinx/coroutines/sync/b
    //   199: astore #5
    //   201: aload #6
    //   203: getfield a : Ljava/lang/Object;
    //   206: checkcast a0/m
    //   209: astore #4
    //   211: aload #8
    //   213: invokestatic b : (Ljava/lang/Object;)V
    //   216: aload #10
    //   218: astore #8
    //   220: goto -> 496
    //   223: aload #6
    //   225: getfield d : Ljava/lang/Object;
    //   228: checkcast kotlin/jvm/internal/v
    //   231: astore #7
    //   233: aload #6
    //   235: getfield c : Ljava/lang/Object;
    //   238: checkcast kotlin/jvm/internal/v
    //   241: astore_1
    //   242: aload #6
    //   244: getfield b : Ljava/lang/Object;
    //   247: checkcast kotlinx/coroutines/sync/b
    //   250: astore #4
    //   252: aload #6
    //   254: getfield a : Ljava/lang/Object;
    //   257: checkcast a0/m
    //   260: astore #5
    //   262: aload #8
    //   264: invokestatic b : (Ljava/lang/Object;)V
    //   267: goto -> 396
    //   270: aload #8
    //   272: invokestatic b : (Ljava/lang/Object;)V
    //   275: aload_0
    //   276: getfield h : Lkotlinx/coroutines/flow/j;
    //   279: invokeinterface getValue : ()Ljava/lang/Object;
    //   284: getstatic a0/o.a : La0/o;
    //   287: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   290: ifne -> 316
    //   293: aload_0
    //   294: getfield h : Lkotlinx/coroutines/flow/j;
    //   297: invokeinterface getValue : ()Ljava/lang/Object;
    //   302: instanceof a0/j
    //   305: ifeq -> 311
    //   308: goto -> 316
    //   311: iconst_0
    //   312: istore_2
    //   313: goto -> 318
    //   316: iconst_1
    //   317: istore_2
    //   318: iload_2
    //   319: ifeq -> 732
    //   322: iconst_0
    //   323: iconst_1
    //   324: aconst_null
    //   325: invokestatic b : (ZILjava/lang/Object;)Lkotlinx/coroutines/sync/b;
    //   328: astore #4
    //   330: new kotlin/jvm/internal/v
    //   333: dup
    //   334: invokespecial <init> : ()V
    //   337: astore #7
    //   339: aload #6
    //   341: aload_0
    //   342: putfield a : Ljava/lang/Object;
    //   345: aload #6
    //   347: aload #4
    //   349: putfield b : Ljava/lang/Object;
    //   352: aload #6
    //   354: aload #7
    //   356: putfield c : Ljava/lang/Object;
    //   359: aload #6
    //   361: aload #7
    //   363: putfield d : Ljava/lang/Object;
    //   366: aload #6
    //   368: iconst_1
    //   369: putfield i : I
    //   372: aload_0
    //   373: aload #6
    //   375: invokespecial y : (Lja/d;)Ljava/lang/Object;
    //   378: astore #8
    //   380: aload #8
    //   382: aload #12
    //   384: if_acmpne -> 390
    //   387: aload #12
    //   389: areturn
    //   390: aload_0
    //   391: astore #5
    //   393: aload #7
    //   395: astore_1
    //   396: aload #7
    //   398: aload #8
    //   400: putfield a : Ljava/lang/Object;
    //   403: new kotlin/jvm/internal/t
    //   406: dup
    //   407: invokespecial <init> : ()V
    //   410: astore #7
    //   412: new a0/m$k
    //   415: dup
    //   416: aload #4
    //   418: aload #7
    //   420: aload_1
    //   421: aload #5
    //   423: invokespecial <init> : (Lkotlinx/coroutines/sync/b;Lkotlin/jvm/internal/t;Lkotlin/jvm/internal/v;La0/m;)V
    //   426: astore #8
    //   428: aload #5
    //   430: getfield i : Ljava/util/List;
    //   433: astore #9
    //   435: aload #9
    //   437: ifnonnull -> 465
    //   440: aload #4
    //   442: astore #9
    //   444: aload #7
    //   446: astore #8
    //   448: aload #5
    //   450: astore #4
    //   452: aload #9
    //   454: astore #5
    //   456: aload_1
    //   457: astore #7
    //   459: aload #8
    //   461: astore_1
    //   462: goto -> 584
    //   465: aload #9
    //   467: invokeinterface iterator : ()Ljava/util/Iterator;
    //   472: astore #9
    //   474: aload #4
    //   476: astore #11
    //   478: aload #7
    //   480: astore #10
    //   482: aload #5
    //   484: astore #4
    //   486: aload #11
    //   488: astore #5
    //   490: aload_1
    //   491: astore #7
    //   493: aload #10
    //   495: astore_1
    //   496: aload #9
    //   498: invokeinterface hasNext : ()Z
    //   503: ifeq -> 584
    //   506: aload #9
    //   508: invokeinterface next : ()Ljava/lang/Object;
    //   513: checkcast qa/p
    //   516: astore #10
    //   518: aload #6
    //   520: aload #4
    //   522: putfield a : Ljava/lang/Object;
    //   525: aload #6
    //   527: aload #5
    //   529: putfield b : Ljava/lang/Object;
    //   532: aload #6
    //   534: aload #7
    //   536: putfield c : Ljava/lang/Object;
    //   539: aload #6
    //   541: aload_1
    //   542: putfield d : Ljava/lang/Object;
    //   545: aload #6
    //   547: aload #8
    //   549: putfield e : Ljava/lang/Object;
    //   552: aload #6
    //   554: aload #9
    //   556: putfield f : Ljava/lang/Object;
    //   559: aload #6
    //   561: iconst_2
    //   562: putfield i : I
    //   565: aload #10
    //   567: aload #8
    //   569: aload #6
    //   571: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   576: aload #12
    //   578: if_acmpne -> 496
    //   581: aload #12
    //   583: areturn
    //   584: aload #4
    //   586: aconst_null
    //   587: putfield i : Ljava/util/List;
    //   590: aload #6
    //   592: aload #4
    //   594: putfield a : Ljava/lang/Object;
    //   597: aload #6
    //   599: aload #7
    //   601: putfield b : Ljava/lang/Object;
    //   604: aload #6
    //   606: aload_1
    //   607: putfield c : Ljava/lang/Object;
    //   610: aload #6
    //   612: aload #5
    //   614: putfield d : Ljava/lang/Object;
    //   617: aload #6
    //   619: aconst_null
    //   620: putfield e : Ljava/lang/Object;
    //   623: aload #6
    //   625: aconst_null
    //   626: putfield f : Ljava/lang/Object;
    //   629: aload #6
    //   631: iconst_3
    //   632: putfield i : I
    //   635: aload #5
    //   637: aconst_null
    //   638: aload #6
    //   640: invokeinterface a : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
    //   645: aload #12
    //   647: if_acmpne -> 653
    //   650: aload #12
    //   652: areturn
    //   653: aload_1
    //   654: astore #6
    //   656: aload #7
    //   658: astore_1
    //   659: aload #6
    //   661: iconst_1
    //   662: putfield a : Z
    //   665: getstatic ga/u.a : Lga/u;
    //   668: astore #6
    //   670: aload #5
    //   672: aconst_null
    //   673: invokeinterface c : (Ljava/lang/Object;)V
    //   678: aload #4
    //   680: getfield h : Lkotlinx/coroutines/flow/j;
    //   683: astore #4
    //   685: aload_1
    //   686: getfield a : Ljava/lang/Object;
    //   689: astore_1
    //   690: iload_3
    //   691: istore_2
    //   692: aload_1
    //   693: ifnull -> 701
    //   696: aload_1
    //   697: invokevirtual hashCode : ()I
    //   700: istore_2
    //   701: aload #4
    //   703: new a0/c
    //   706: dup
    //   707: aload_1
    //   708: iload_2
    //   709: invokespecial <init> : (Ljava/lang/Object;I)V
    //   712: invokeinterface setValue : (Ljava/lang/Object;)V
    //   717: getstatic ga/u.a : Lga/u;
    //   720: areturn
    //   721: astore_1
    //   722: aload #5
    //   724: aconst_null
    //   725: invokeinterface c : (Ljava/lang/Object;)V
    //   730: aload_1
    //   731: athrow
    //   732: new java/lang/IllegalStateException
    //   735: dup
    //   736: ldc_w 'Check failed.'
    //   739: invokevirtual toString : ()Ljava/lang/String;
    //   742: invokespecial <init> : (Ljava/lang/String;)V
    //   745: athrow
    // Exception table:
    //   from	to	target	type
    //   659	670	721	finally
  }
  
  private final Object v(ja.d<? super u> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof a0/m$l
    //   4: ifeq -> 39
    //   7: aload_1
    //   8: checkcast a0/m$l
    //   11: astore_3
    //   12: aload_3
    //   13: getfield d : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc_w -2147483648
    //   21: iand
    //   22: ifeq -> 39
    //   25: aload_3
    //   26: iload_2
    //   27: ldc_w -2147483648
    //   30: iadd
    //   31: putfield d : I
    //   34: aload_3
    //   35: astore_1
    //   36: goto -> 49
    //   39: new a0/m$l
    //   42: dup
    //   43: aload_0
    //   44: aload_1
    //   45: invokespecial <init> : (La0/m;Lja/d;)V
    //   48: astore_1
    //   49: aload_1
    //   50: getfield b : Ljava/lang/Object;
    //   53: astore_3
    //   54: invokestatic c : ()Ljava/lang/Object;
    //   57: astore #4
    //   59: aload_1
    //   60: getfield d : I
    //   63: istore_2
    //   64: iload_2
    //   65: ifeq -> 103
    //   68: iload_2
    //   69: iconst_1
    //   70: if_icmpne -> 92
    //   73: aload_1
    //   74: getfield a : Ljava/lang/Object;
    //   77: checkcast a0/m
    //   80: astore_1
    //   81: aload_3
    //   82: invokestatic b : (Ljava/lang/Object;)V
    //   85: goto -> 132
    //   88: astore_3
    //   89: goto -> 139
    //   92: new java/lang/IllegalStateException
    //   95: dup
    //   96: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   99: invokespecial <init> : (Ljava/lang/String;)V
    //   102: athrow
    //   103: aload_3
    //   104: invokestatic b : (Ljava/lang/Object;)V
    //   107: aload_1
    //   108: aload_0
    //   109: putfield a : Ljava/lang/Object;
    //   112: aload_1
    //   113: iconst_1
    //   114: putfield d : I
    //   117: aload_0
    //   118: aload_1
    //   119: invokespecial u : (Lja/d;)Ljava/lang/Object;
    //   122: astore_1
    //   123: aload_1
    //   124: aload #4
    //   126: if_acmpne -> 132
    //   129: aload #4
    //   131: areturn
    //   132: getstatic ga/u.a : Lga/u;
    //   135: areturn
    //   136: astore_3
    //   137: aload_0
    //   138: astore_1
    //   139: aload_1
    //   140: getfield h : Lkotlinx/coroutines/flow/j;
    //   143: new a0/j
    //   146: dup
    //   147: aload_3
    //   148: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   151: invokeinterface setValue : (Ljava/lang/Object;)V
    //   156: aload_3
    //   157: athrow
    // Exception table:
    //   from	to	target	type
    //   81	85	88	finally
    //   107	123	136	finally
  }
  
  private final Object w(ja.d<? super u> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof a0/m$m
    //   4: ifeq -> 39
    //   7: aload_1
    //   8: checkcast a0/m$m
    //   11: astore_3
    //   12: aload_3
    //   13: getfield d : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc_w -2147483648
    //   21: iand
    //   22: ifeq -> 39
    //   25: aload_3
    //   26: iload_2
    //   27: ldc_w -2147483648
    //   30: iadd
    //   31: putfield d : I
    //   34: aload_3
    //   35: astore_1
    //   36: goto -> 49
    //   39: new a0/m$m
    //   42: dup
    //   43: aload_0
    //   44: aload_1
    //   45: invokespecial <init> : (La0/m;Lja/d;)V
    //   48: astore_1
    //   49: aload_1
    //   50: getfield b : Ljava/lang/Object;
    //   53: astore_3
    //   54: invokestatic c : ()Ljava/lang/Object;
    //   57: astore #4
    //   59: aload_1
    //   60: getfield d : I
    //   63: istore_2
    //   64: iload_2
    //   65: ifeq -> 103
    //   68: iload_2
    //   69: iconst_1
    //   70: if_icmpne -> 92
    //   73: aload_1
    //   74: getfield a : Ljava/lang/Object;
    //   77: checkcast a0/m
    //   80: astore_1
    //   81: aload_3
    //   82: invokestatic b : (Ljava/lang/Object;)V
    //   85: goto -> 152
    //   88: astore_3
    //   89: goto -> 135
    //   92: new java/lang/IllegalStateException
    //   95: dup
    //   96: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   99: invokespecial <init> : (Ljava/lang/String;)V
    //   102: athrow
    //   103: aload_3
    //   104: invokestatic b : (Ljava/lang/Object;)V
    //   107: aload_1
    //   108: aload_0
    //   109: putfield a : Ljava/lang/Object;
    //   112: aload_1
    //   113: iconst_1
    //   114: putfield d : I
    //   117: aload_0
    //   118: aload_1
    //   119: invokespecial u : (Lja/d;)Ljava/lang/Object;
    //   122: astore_1
    //   123: aload_1
    //   124: aload #4
    //   126: if_acmpne -> 152
    //   129: aload #4
    //   131: areturn
    //   132: astore_3
    //   133: aload_0
    //   134: astore_1
    //   135: aload_1
    //   136: getfield h : Lkotlinx/coroutines/flow/j;
    //   139: new a0/j
    //   142: dup
    //   143: aload_3
    //   144: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   147: invokeinterface setValue : (Ljava/lang/Object;)V
    //   152: getstatic ga/u.a : Lga/u;
    //   155: areturn
    // Exception table:
    //   from	to	target	type
    //   81	85	88	finally
    //   107	123	132	finally
  }
  
  private final Object x(ja.d<? super T> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof a0/m$n
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast a0/m$n
    //   11: astore_3
    //   12: aload_3
    //   13: getfield f : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc_w -2147483648
    //   21: iand
    //   22: ifeq -> 37
    //   25: aload_3
    //   26: iload_2
    //   27: ldc_w -2147483648
    //   30: iadd
    //   31: putfield f : I
    //   34: goto -> 47
    //   37: new a0/m$n
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (La0/m;Lja/d;)V
    //   46: astore_3
    //   47: aload_3
    //   48: getfield d : Ljava/lang/Object;
    //   51: astore #5
    //   53: invokestatic c : ()Ljava/lang/Object;
    //   56: astore #4
    //   58: aload_3
    //   59: getfield f : I
    //   62: istore_2
    //   63: iload_2
    //   64: ifeq -> 127
    //   67: iload_2
    //   68: iconst_1
    //   69: if_icmpne -> 116
    //   72: aload_3
    //   73: getfield c : Ljava/lang/Object;
    //   76: checkcast java/lang/Throwable
    //   79: astore #6
    //   81: aload_3
    //   82: getfield b : Ljava/lang/Object;
    //   85: checkcast java/io/Closeable
    //   88: astore #4
    //   90: aload_3
    //   91: getfield a : Ljava/lang/Object;
    //   94: checkcast a0/m
    //   97: astore_1
    //   98: aload #5
    //   100: invokestatic b : (Ljava/lang/Object;)V
    //   103: aload #6
    //   105: astore_3
    //   106: goto -> 202
    //   109: astore #5
    //   111: aload_1
    //   112: astore_3
    //   113: goto -> 222
    //   116: new java/lang/IllegalStateException
    //   119: dup
    //   120: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   123: invokespecial <init> : (Ljava/lang/String;)V
    //   126: athrow
    //   127: aload #5
    //   129: invokestatic b : (Ljava/lang/Object;)V
    //   132: new java/io/FileInputStream
    //   135: dup
    //   136: aload_0
    //   137: invokespecial r : ()Ljava/io/File;
    //   140: invokespecial <init> : (Ljava/io/File;)V
    //   143: astore_1
    //   144: aload_0
    //   145: getfield b : La0/k;
    //   148: astore #5
    //   150: aload_3
    //   151: aload_0
    //   152: putfield a : Ljava/lang/Object;
    //   155: aload_3
    //   156: aload_1
    //   157: putfield b : Ljava/lang/Object;
    //   160: aload_3
    //   161: aconst_null
    //   162: putfield c : Ljava/lang/Object;
    //   165: aload_3
    //   166: iconst_1
    //   167: putfield f : I
    //   170: aload #5
    //   172: aload_1
    //   173: aload_3
    //   174: invokeinterface c : (Ljava/io/InputStream;Lja/d;)Ljava/lang/Object;
    //   179: astore #5
    //   181: aload #5
    //   183: aload #4
    //   185: if_acmpne -> 191
    //   188: aload #4
    //   190: areturn
    //   191: aload_0
    //   192: astore #6
    //   194: aconst_null
    //   195: astore_3
    //   196: aload_1
    //   197: astore #4
    //   199: aload #6
    //   201: astore_1
    //   202: aload #4
    //   204: aload_3
    //   205: invokestatic a : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   208: aload #5
    //   210: areturn
    //   211: astore_3
    //   212: goto -> 244
    //   215: astore #5
    //   217: aload_0
    //   218: astore_3
    //   219: aload_1
    //   220: astore #4
    //   222: aload #5
    //   224: athrow
    //   225: astore #6
    //   227: aload_3
    //   228: astore_1
    //   229: aload #4
    //   231: aload #5
    //   233: invokestatic a : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   236: aload_3
    //   237: astore_1
    //   238: aload #6
    //   240: athrow
    //   241: astore_3
    //   242: aload_0
    //   243: astore_1
    //   244: aload_1
    //   245: invokespecial r : ()Ljava/io/File;
    //   248: invokevirtual exists : ()Z
    //   251: ifne -> 264
    //   254: aload_1
    //   255: getfield b : La0/k;
    //   258: invokeinterface a : ()Ljava/lang/Object;
    //   263: areturn
    //   264: aload_3
    //   265: athrow
    // Exception table:
    //   from	to	target	type
    //   98	103	109	finally
    //   132	144	241	java/io/FileNotFoundException
    //   144	181	215	finally
    //   202	208	211	java/io/FileNotFoundException
    //   222	225	225	finally
    //   229	236	211	java/io/FileNotFoundException
    //   238	241	211	java/io/FileNotFoundException
  }
  
  private final Object y(ja.d<? super T> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof a0/m$o
    //   4: ifeq -> 40
    //   7: aload_1
    //   8: checkcast a0/m$o
    //   11: astore #4
    //   13: aload #4
    //   15: getfield e : I
    //   18: istore_2
    //   19: iload_2
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #4
    //   29: iload_2
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield e : I
    //   37: goto -> 51
    //   40: new a0/m$o
    //   43: dup
    //   44: aload_0
    //   45: aload_1
    //   46: invokespecial <init> : (La0/m;Lja/d;)V
    //   49: astore #4
    //   51: aload #4
    //   53: getfield c : Ljava/lang/Object;
    //   56: astore #5
    //   58: invokestatic c : ()Ljava/lang/Object;
    //   61: astore #7
    //   63: aload #4
    //   65: getfield e : I
    //   68: istore_2
    //   69: iload_2
    //   70: ifeq -> 173
    //   73: iload_2
    //   74: iconst_1
    //   75: if_icmpeq -> 152
    //   78: iload_2
    //   79: iconst_2
    //   80: if_icmpeq -> 125
    //   83: iload_2
    //   84: iconst_3
    //   85: if_icmpne -> 114
    //   88: aload #4
    //   90: getfield b : Ljava/lang/Object;
    //   93: astore_3
    //   94: aload #4
    //   96: getfield a : Ljava/lang/Object;
    //   99: checkcast a0/a
    //   102: astore_1
    //   103: aload #5
    //   105: invokestatic b : (Ljava/lang/Object;)V
    //   108: aload_3
    //   109: areturn
    //   110: astore_3
    //   111: goto -> 304
    //   114: new java/lang/IllegalStateException
    //   117: dup
    //   118: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   121: invokespecial <init> : (Ljava/lang/String;)V
    //   124: athrow
    //   125: aload #4
    //   127: getfield b : Ljava/lang/Object;
    //   130: checkcast a0/a
    //   133: astore_1
    //   134: aload #4
    //   136: getfield a : Ljava/lang/Object;
    //   139: checkcast a0/m
    //   142: astore #6
    //   144: aload #5
    //   146: invokestatic b : (Ljava/lang/Object;)V
    //   149: goto -> 262
    //   152: aload #4
    //   154: getfield a : Ljava/lang/Object;
    //   157: checkcast a0/m
    //   160: astore_1
    //   161: aload #5
    //   163: invokestatic b : (Ljava/lang/Object;)V
    //   166: aload #5
    //   168: areturn
    //   169: astore_3
    //   170: goto -> 211
    //   173: aload #5
    //   175: invokestatic b : (Ljava/lang/Object;)V
    //   178: aload #4
    //   180: aload_0
    //   181: putfield a : Ljava/lang/Object;
    //   184: aload #4
    //   186: iconst_1
    //   187: putfield e : I
    //   190: aload_0
    //   191: aload #4
    //   193: invokespecial x : (Lja/d;)Ljava/lang/Object;
    //   196: astore_1
    //   197: aload_1
    //   198: aload #7
    //   200: if_acmpne -> 206
    //   203: aload #7
    //   205: areturn
    //   206: aload_1
    //   207: areturn
    //   208: astore_3
    //   209: aload_0
    //   210: astore_1
    //   211: aload_1
    //   212: getfield c : La0/b;
    //   215: astore #5
    //   217: aload #4
    //   219: aload_1
    //   220: putfield a : Ljava/lang/Object;
    //   223: aload #4
    //   225: aload_3
    //   226: putfield b : Ljava/lang/Object;
    //   229: aload #4
    //   231: iconst_2
    //   232: putfield e : I
    //   235: aload #5
    //   237: aload_3
    //   238: aload #4
    //   240: invokeinterface a : (La0/a;Lja/d;)Ljava/lang/Object;
    //   245: astore #5
    //   247: aload #5
    //   249: aload #7
    //   251: if_acmpne -> 257
    //   254: aload #7
    //   256: areturn
    //   257: aload_1
    //   258: astore #6
    //   260: aload_3
    //   261: astore_1
    //   262: aload #4
    //   264: aload_1
    //   265: putfield a : Ljava/lang/Object;
    //   268: aload #4
    //   270: aload #5
    //   272: putfield b : Ljava/lang/Object;
    //   275: aload #4
    //   277: iconst_3
    //   278: putfield e : I
    //   281: aload #6
    //   283: aload #5
    //   285: aload #4
    //   287: invokevirtual A : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
    //   290: astore_3
    //   291: aload_3
    //   292: aload #7
    //   294: if_acmpne -> 300
    //   297: aload #7
    //   299: areturn
    //   300: aload #5
    //   302: areturn
    //   303: astore_3
    //   304: aload_1
    //   305: aload_3
    //   306: invokestatic a : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   309: aload_1
    //   310: athrow
    // Exception table:
    //   from	to	target	type
    //   103	108	110	java/io/IOException
    //   161	166	169	a0/a
    //   178	197	208	a0/a
    //   262	291	303	java/io/IOException
  }
  
  private final Object z(qa.p<? super T, ? super ja.d<? super T>, ? extends Object> paramp, ja.g paramg, ja.d<? super T> paramd) {
    // Byte code:
    //   0: aload_3
    //   1: instanceof a0/m$p
    //   4: ifeq -> 46
    //   7: aload_3
    //   8: checkcast a0/m$p
    //   11: astore #5
    //   13: aload #5
    //   15: getfield f : I
    //   18: istore #4
    //   20: iload #4
    //   22: ldc_w -2147483648
    //   25: iand
    //   26: ifeq -> 46
    //   29: aload #5
    //   31: iload #4
    //   33: ldc_w -2147483648
    //   36: iadd
    //   37: putfield f : I
    //   40: aload #5
    //   42: astore_3
    //   43: goto -> 56
    //   46: new a0/m$p
    //   49: dup
    //   50: aload_0
    //   51: aload_3
    //   52: invokespecial <init> : (La0/m;Lja/d;)V
    //   55: astore_3
    //   56: aload_3
    //   57: getfield d : Ljava/lang/Object;
    //   60: astore #5
    //   62: invokestatic c : ()Ljava/lang/Object;
    //   65: astore #8
    //   67: aload_3
    //   68: getfield f : I
    //   71: istore #4
    //   73: iload #4
    //   75: ifeq -> 156
    //   78: iload #4
    //   80: iconst_1
    //   81: if_icmpeq -> 122
    //   84: iload #4
    //   86: iconst_2
    //   87: if_icmpne -> 111
    //   90: aload_3
    //   91: getfield b : Ljava/lang/Object;
    //   94: astore_2
    //   95: aload_3
    //   96: getfield a : Ljava/lang/Object;
    //   99: checkcast a0/m
    //   102: astore_1
    //   103: aload #5
    //   105: invokestatic b : (Ljava/lang/Object;)V
    //   108: goto -> 300
    //   111: new java/lang/IllegalStateException
    //   114: dup
    //   115: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   118: invokespecial <init> : (Ljava/lang/String;)V
    //   121: athrow
    //   122: aload_3
    //   123: getfield c : Ljava/lang/Object;
    //   126: astore #6
    //   128: aload_3
    //   129: getfield b : Ljava/lang/Object;
    //   132: checkcast a0/c
    //   135: astore #7
    //   137: aload_3
    //   138: getfield a : Ljava/lang/Object;
    //   141: checkcast a0/m
    //   144: astore_1
    //   145: aload #5
    //   147: invokestatic b : (Ljava/lang/Object;)V
    //   150: aload #5
    //   152: astore_2
    //   153: goto -> 249
    //   156: aload #5
    //   158: invokestatic b : (Ljava/lang/Object;)V
    //   161: aload_0
    //   162: getfield h : Lkotlinx/coroutines/flow/j;
    //   165: invokeinterface getValue : ()Ljava/lang/Object;
    //   170: checkcast a0/c
    //   173: astore #5
    //   175: aload #5
    //   177: invokevirtual a : ()V
    //   180: aload #5
    //   182: invokevirtual b : ()Ljava/lang/Object;
    //   185: astore #6
    //   187: new a0/m$q
    //   190: dup
    //   191: aload_1
    //   192: aload #6
    //   194: aconst_null
    //   195: invokespecial <init> : (Lqa/p;Ljava/lang/Object;Lja/d;)V
    //   198: astore_1
    //   199: aload_3
    //   200: aload_0
    //   201: putfield a : Ljava/lang/Object;
    //   204: aload_3
    //   205: aload #5
    //   207: putfield b : Ljava/lang/Object;
    //   210: aload_3
    //   211: aload #6
    //   213: putfield c : Ljava/lang/Object;
    //   216: aload_3
    //   217: iconst_1
    //   218: putfield f : I
    //   221: aload_2
    //   222: aload_1
    //   223: aload_3
    //   224: invokestatic e : (Lja/g;Lqa/p;Lja/d;)Ljava/lang/Object;
    //   227: astore_2
    //   228: aload_2
    //   229: aload #8
    //   231: if_acmpne -> 237
    //   234: aload #8
    //   236: areturn
    //   237: aload #5
    //   239: astore_1
    //   240: aload_0
    //   241: astore #5
    //   243: aload_1
    //   244: astore #7
    //   246: aload #5
    //   248: astore_1
    //   249: aload #7
    //   251: invokevirtual a : ()V
    //   254: aload #6
    //   256: aload_2
    //   257: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   260: ifeq -> 266
    //   263: aload #6
    //   265: areturn
    //   266: aload_3
    //   267: aload_1
    //   268: putfield a : Ljava/lang/Object;
    //   271: aload_3
    //   272: aload_2
    //   273: putfield b : Ljava/lang/Object;
    //   276: aload_3
    //   277: aconst_null
    //   278: putfield c : Ljava/lang/Object;
    //   281: aload_3
    //   282: iconst_2
    //   283: putfield f : I
    //   286: aload_1
    //   287: aload_2
    //   288: aload_3
    //   289: invokevirtual A : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
    //   292: aload #8
    //   294: if_acmpne -> 300
    //   297: aload #8
    //   299: areturn
    //   300: aload_1
    //   301: getfield h : Lkotlinx/coroutines/flow/j;
    //   304: astore_1
    //   305: aload_2
    //   306: ifnull -> 318
    //   309: aload_2
    //   310: invokevirtual hashCode : ()I
    //   313: istore #4
    //   315: goto -> 321
    //   318: iconst_0
    //   319: istore #4
    //   321: aload_1
    //   322: new a0/c
    //   325: dup
    //   326: aload_2
    //   327: iload #4
    //   329: invokespecial <init> : (Ljava/lang/Object;I)V
    //   332: invokeinterface setValue : (Ljava/lang/Object;)V
    //   337: aload_2
    //   338: areturn
  }
  
  public final Object A(T paramT, ja.d<? super u> paramd) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof a0/m$r
    //   4: ifeq -> 40
    //   7: aload_2
    //   8: checkcast a0/m$r
    //   11: astore #6
    //   13: aload #6
    //   15: getfield h : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #6
    //   29: iload_3
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield h : I
    //   37: goto -> 51
    //   40: new a0/m$r
    //   43: dup
    //   44: aload_0
    //   45: aload_2
    //   46: invokespecial <init> : (La0/m;Lja/d;)V
    //   49: astore #6
    //   51: aload #6
    //   53: getfield f : Ljava/lang/Object;
    //   56: astore #11
    //   58: invokestatic c : ()Ljava/lang/Object;
    //   61: astore #7
    //   63: aload #6
    //   65: getfield h : I
    //   68: istore_3
    //   69: iload_3
    //   70: ifeq -> 167
    //   73: iload_3
    //   74: iconst_1
    //   75: if_icmpne -> 156
    //   78: aload #6
    //   80: getfield e : Ljava/lang/Object;
    //   83: checkcast java/io/FileOutputStream
    //   86: astore #10
    //   88: aload #6
    //   90: getfield d : Ljava/lang/Object;
    //   93: checkcast java/lang/Throwable
    //   96: astore #8
    //   98: aload #6
    //   100: getfield c : Ljava/lang/Object;
    //   103: checkcast java/io/Closeable
    //   106: astore #9
    //   108: aload #6
    //   110: getfield b : Ljava/lang/Object;
    //   113: checkcast java/io/File
    //   116: astore_1
    //   117: aload #6
    //   119: getfield a : Ljava/lang/Object;
    //   122: checkcast a0/m
    //   125: astore #7
    //   127: aload #9
    //   129: astore #5
    //   131: aload_1
    //   132: astore_2
    //   133: aload #11
    //   135: invokestatic b : (Ljava/lang/Object;)V
    //   138: aload #9
    //   140: astore #6
    //   142: aload #10
    //   144: astore #9
    //   146: goto -> 303
    //   149: astore #6
    //   151: aload_2
    //   152: astore_1
    //   153: goto -> 424
    //   156: new java/lang/IllegalStateException
    //   159: dup
    //   160: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   163: invokespecial <init> : (Ljava/lang/String;)V
    //   166: athrow
    //   167: aload #11
    //   169: invokestatic b : (Ljava/lang/Object;)V
    //   172: aload_0
    //   173: aload_0
    //   174: invokespecial r : ()Ljava/io/File;
    //   177: invokespecial q : (Ljava/io/File;)V
    //   180: new java/io/File
    //   183: dup
    //   184: aload_0
    //   185: invokespecial r : ()Ljava/io/File;
    //   188: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   191: aload_0
    //   192: getfield f : Ljava/lang/String;
    //   195: invokestatic m : (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
    //   198: invokespecial <init> : (Ljava/lang/String;)V
    //   201: astore #5
    //   203: new java/io/FileOutputStream
    //   206: dup
    //   207: aload #5
    //   209: invokespecial <init> : (Ljava/io/File;)V
    //   212: astore_2
    //   213: aload_0
    //   214: getfield b : La0/k;
    //   217: astore #8
    //   219: new a0/m$c
    //   222: dup
    //   223: aload_2
    //   224: invokespecial <init> : (Ljava/io/FileOutputStream;)V
    //   227: astore #9
    //   229: aload #6
    //   231: aload_0
    //   232: putfield a : Ljava/lang/Object;
    //   235: aload #6
    //   237: aload #5
    //   239: putfield b : Ljava/lang/Object;
    //   242: aload #6
    //   244: aload_2
    //   245: putfield c : Ljava/lang/Object;
    //   248: aload #6
    //   250: aconst_null
    //   251: putfield d : Ljava/lang/Object;
    //   254: aload #6
    //   256: aload_2
    //   257: putfield e : Ljava/lang/Object;
    //   260: aload #6
    //   262: iconst_1
    //   263: putfield h : I
    //   266: aload #8
    //   268: aload_1
    //   269: aload #9
    //   271: aload #6
    //   273: invokeinterface b : (Ljava/lang/Object;Ljava/io/OutputStream;Lja/d;)Ljava/lang/Object;
    //   278: astore_1
    //   279: aload_1
    //   280: aload #7
    //   282: if_acmpne -> 288
    //   285: aload #7
    //   287: areturn
    //   288: aload_0
    //   289: astore #7
    //   291: aload #5
    //   293: astore_1
    //   294: aload_2
    //   295: astore #9
    //   297: aconst_null
    //   298: astore #8
    //   300: aload_2
    //   301: astore #6
    //   303: aload #6
    //   305: astore #5
    //   307: aload_1
    //   308: astore_2
    //   309: aload #9
    //   311: invokevirtual getFD : ()Ljava/io/FileDescriptor;
    //   314: invokevirtual sync : ()V
    //   317: aload #6
    //   319: astore #5
    //   321: aload_1
    //   322: astore_2
    //   323: getstatic ga/u.a : Lga/u;
    //   326: astore #9
    //   328: aload_1
    //   329: astore_2
    //   330: aload #6
    //   332: aload #8
    //   334: invokestatic a : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   337: aload_1
    //   338: astore_2
    //   339: aload_1
    //   340: aload #7
    //   342: invokespecial r : ()Ljava/io/File;
    //   345: invokevirtual renameTo : (Ljava/io/File;)Z
    //   348: istore #4
    //   350: iload #4
    //   352: ifeq -> 359
    //   355: getstatic ga/u.a : Lga/u;
    //   358: areturn
    //   359: aload_1
    //   360: astore_2
    //   361: new java/lang/StringBuilder
    //   364: dup
    //   365: invokespecial <init> : ()V
    //   368: astore #5
    //   370: aload_1
    //   371: astore_2
    //   372: aload #5
    //   374: ldc_w 'Unable to rename '
    //   377: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   380: pop
    //   381: aload_1
    //   382: astore_2
    //   383: aload #5
    //   385: aload_1
    //   386: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   389: pop
    //   390: aload_1
    //   391: astore_2
    //   392: aload #5
    //   394: ldc_w '.This likely means that there are multiple instances of DataStore for this file. Ensure that you are only creating a single instance of datastore for this file.'
    //   397: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   400: pop
    //   401: aload_1
    //   402: astore_2
    //   403: new java/io/IOException
    //   406: dup
    //   407: aload #5
    //   409: invokevirtual toString : ()Ljava/lang/String;
    //   412: invokespecial <init> : (Ljava/lang/String;)V
    //   415: athrow
    //   416: astore #6
    //   418: aload #5
    //   420: astore_1
    //   421: aload_2
    //   422: astore #5
    //   424: aload #6
    //   426: athrow
    //   427: astore #7
    //   429: aload_1
    //   430: astore_2
    //   431: aload #5
    //   433: aload #6
    //   435: invokestatic a : (Ljava/io/Closeable;Ljava/lang/Throwable;)V
    //   438: aload_1
    //   439: astore_2
    //   440: aload #7
    //   442: athrow
    //   443: astore_1
    //   444: goto -> 451
    //   447: astore_1
    //   448: aload #5
    //   450: astore_2
    //   451: aload_2
    //   452: invokevirtual exists : ()Z
    //   455: ifeq -> 463
    //   458: aload_2
    //   459: invokevirtual delete : ()Z
    //   462: pop
    //   463: aload_1
    //   464: athrow
    // Exception table:
    //   from	to	target	type
    //   133	138	149	finally
    //   203	213	447	java/io/IOException
    //   213	279	416	finally
    //   309	317	149	finally
    //   323	328	149	finally
    //   330	337	443	java/io/IOException
    //   339	350	443	java/io/IOException
    //   361	370	443	java/io/IOException
    //   372	381	443	java/io/IOException
    //   383	390	443	java/io/IOException
    //   392	401	443	java/io/IOException
    //   403	416	443	java/io/IOException
    //   424	427	427	finally
    //   431	438	443	java/io/IOException
    //   440	443	443	java/io/IOException
  }
  
  public Object a(qa.p<? super T, ? super ja.d<? super T>, ? extends Object> paramp, ja.d<? super T> paramd) {
    v<T> v = x.b(null, 1, null);
    b.b<T> b1 = new b.b<T>(paramp, v, (n<T>)this.h.getValue(), paramd.getContext());
    this.j.e(b1);
    return v.M(paramd);
  }
  
  public kotlinx.coroutines.flow.b<T> b() {
    return this.e;
  }
  
  public static final class a {
    private a() {}
    
    public final Set<String> a() {
      return m.c();
    }
    
    public final Object b() {
      return m.d();
    }
  }
  
  private static abstract class b<T> {
    private b() {}
    
    public static final class a<T> extends b<T> {
      private final n<T> a;
      
      public a(n<T> param2n) {
        super(null);
        this.a = param2n;
      }
      
      public n<T> a() {
        return this.a;
      }
    }
    
    public static final class b<T> extends b<T> {
      private final qa.p<T, ja.d<? super T>, Object> a;
      
      private final v<T> b;
      
      private final n<T> c;
      
      private final ja.g d;
      
      public b(qa.p<? super T, ? super ja.d<? super T>, ? extends Object> param2p, v<T> param2v, n<T> param2n, ja.g param2g) {
        super(null);
        this.a = (qa.p)param2p;
        this.b = param2v;
        this.c = param2n;
        this.d = param2g;
      }
      
      public final v<T> a() {
        return this.b;
      }
      
      public final ja.g b() {
        return this.d;
      }
      
      public n<T> c() {
        return this.c;
      }
      
      public final qa.p<T, ja.d<? super T>, Object> d() {
        return this.a;
      }
    }
  }
  
  public static final class a<T> extends b<T> {
    private final n<T> a;
    
    public a(n<T> param1n) {
      super(null);
      this.a = param1n;
    }
    
    public n<T> a() {
      return this.a;
    }
  }
  
  public static final class b<T> extends b<T> {
    private final qa.p<T, ja.d<? super T>, Object> a;
    
    private final v<T> b;
    
    private final n<T> c;
    
    private final ja.g d;
    
    public b(qa.p<? super T, ? super ja.d<? super T>, ? extends Object> param1p, v<T> param1v, n<T> param1n, ja.g param1g) {
      super(null);
      this.a = (qa.p)param1p;
      this.b = param1v;
      this.c = param1n;
      this.d = param1g;
    }
    
    public final v<T> a() {
      return this.b;
    }
    
    public final ja.g b() {
      return this.d;
    }
    
    public n<T> c() {
      return this.c;
    }
    
    public final qa.p<T, ja.d<? super T>, Object> d() {
      return this.a;
    }
  }
  
  private static final class c extends OutputStream {
    private final FileOutputStream a;
    
    public c(FileOutputStream param1FileOutputStream) {
      this.a = param1FileOutputStream;
    }
    
    public void close() {}
    
    public void flush() {
      this.a.flush();
    }
    
    public void write(int param1Int) {
      this.a.write(param1Int);
    }
    
    public void write(byte[] param1ArrayOfbyte) {
      kotlin.jvm.internal.l.f(param1ArrayOfbyte, "b");
      this.a.write(param1ArrayOfbyte);
    }
    
    public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
      kotlin.jvm.internal.l.f(param1ArrayOfbyte, "bytes");
      this.a.write(param1ArrayOfbyte, param1Int1, param1Int2);
    }
  }
  
  static final class d extends kotlin.jvm.internal.m implements qa.l<Throwable, u> {
    d(m<T> param1m) {
      super(1);
    }
    
    public final void a(Throwable param1Throwable) {
      if (param1Throwable != null)
        m.f(this.a).setValue(new h(param1Throwable)); 
      null = m.k;
      Object object = null.b();
      synchronized (this.a) {
        null.a().remove(m.g(null).getAbsolutePath());
        u u = u.a;
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        return;
      } 
    }
  }
  
  static final class e extends kotlin.jvm.internal.m implements qa.p<b<T>, Throwable, u> {
    public static final e a = new e();
    
    e() {
      super(2);
    }
    
    public final void a(m.b<T> param1b, Throwable param1Throwable) {
      kotlin.jvm.internal.l.f(param1b, "msg");
      if (param1b instanceof m.b.b) {
        v v = ((m.b.b)param1b).a();
        Throwable throwable = param1Throwable;
        if (param1Throwable == null)
          throwable = new CancellationException("DataStore scope was cancelled before updateData could complete"); 
        v.F(throwable);
      } 
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$actor$3", f = "SingleProcessDataStore.kt", l = {239, 242}, m = "invokeSuspend")
  static final class f extends kotlin.coroutines.jvm.internal.k implements qa.p<b<T>, ja.d<? super u>, Object> {
    int a;
    
    f(m<T> param1m, ja.d<? super f> param1d) {
      super(2, param1d);
    }
    
    public final Object a(m.b<T> param1b, ja.d<? super u> param1d) {
      return ((f)create(param1b, param1d)).invokeSuspend(u.a);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      f f1 = new f(this.c, (ja.d)param1d);
      f1.b = param1Object;
      return (ja.d<u>)f1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = ka.b.c();
      int i = this.a;
      if (i != 0) {
        if (i == 1 || i == 2) {
          ga.p.b(param1Object);
          return u.a;
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
      ga.p.b(param1Object);
      param1Object = this.b;
      if (param1Object instanceof m.b.a) {
        m<T> m1 = this.c;
        param1Object = param1Object;
        this.a = 1;
        if (m.i(m1, (m.b.a)param1Object, (ja.d)this) == object)
          return object; 
      } else if (param1Object instanceof m.b.b) {
        m<T> m1 = this.c;
        param1Object = param1Object;
        this.a = 2;
        if (m.j(m1, (m.b.b)param1Object, (ja.d)this) == object)
          return object; 
      } 
      return u.a;
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1", f = "SingleProcessDataStore.kt", l = {117}, m = "invokeSuspend")
  static final class g extends kotlin.coroutines.jvm.internal.k implements qa.p<kotlinx.coroutines.flow.c<? super T>, ja.d<? super u>, Object> {
    int a;
    
    g(m<T> param1m, ja.d<? super g> param1d) {
      super(2, param1d);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      g g1 = new g(this.c, (ja.d)param1d);
      g1.b = param1Object;
      return (ja.d<u>)g1;
    }
    
    public final Object invoke(kotlinx.coroutines.flow.c<? super T> param1c, ja.d<? super u> param1d) {
      return ((g)create(param1c, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = ka.b.c();
      int i = this.a;
      if (i != 0) {
        if (i == 1) {
          ga.p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ga.p.b(param1Object);
        param1Object = this.b;
        n<?> n = (n)m.f(this.c).getValue();
        if (!(n instanceof c))
          m.e(this.c).e(new m.b.a(n)); 
        b b = new b(kotlinx.coroutines.flow.d.a((kotlinx.coroutines.flow.b)m.f(this.c), new a((n)n, null)));
        this.a = 1;
        if (kotlinx.coroutines.flow.d.b((kotlinx.coroutines.flow.c)param1Object, b, (ja.d)this) == object)
          return object; 
      } 
      return u.a;
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$1", f = "SingleProcessDataStore.kt", l = {}, m = "invokeSuspend")
    static final class a extends kotlin.coroutines.jvm.internal.k implements qa.p<n<T>, ja.d<? super Boolean>, Object> {
      int a;
      
      a(n<T> param2n, ja.d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final Object a(n<T> param2n, ja.d<? super Boolean> param2d) {
        return ((a)create(param2n, param2d)).invokeSuspend(u.a);
      }
      
      public final ja.d<u> create(Object param2Object, ja.d<?> param2d) {
        a a1 = new a(this.c, (ja.d)param2d);
        a1.b = param2Object;
        return (ja.d<u>)a1;
      }
      
      public final Object invokeSuspend(Object param2Object) {
        ka.b.c();
        if (this.a == 0) {
          ga.p.b(param2Object);
          param2Object = this.b;
          n<T> n1 = this.c;
          boolean bool = n1 instanceof c;
          boolean bool2 = false;
          boolean bool1 = bool2;
          if (!bool)
            if (n1 instanceof h) {
              bool1 = bool2;
            } else {
              bool1 = bool2;
              if (param2Object == n1)
                bool1 = true; 
            }  
          return kotlin.coroutines.jvm.internal.b.a(bool1);
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      }
    }
    
    public static final class b implements kotlinx.coroutines.flow.b<T> {
      public b(kotlinx.coroutines.flow.b param2b) {}
      
      public Object a(kotlinx.coroutines.flow.c param2c, ja.d param2d) {
        Object object = this.a.a(new a(param2c), param2d);
        return (object == ka.b.c()) ? object : u.a;
      }
      
      public static final class a implements kotlinx.coroutines.flow.c<n<T>> {
        public a(kotlinx.coroutines.flow.c param3c) {}
        
        public Object emit(Object param3Object, ja.d param3d) {
          // Byte code:
          //   0: aload_2
          //   1: instanceof a0/m$g$b$a$a
          //   4: ifeq -> 41
          //   7: aload_2
          //   8: checkcast a0/m$g$b$a$a
          //   11: astore #4
          //   13: aload #4
          //   15: getfield b : I
          //   18: istore_3
          //   19: iload_3
          //   20: ldc -2147483648
          //   22: iand
          //   23: ifeq -> 41
          //   26: aload #4
          //   28: iload_3
          //   29: ldc -2147483648
          //   31: iadd
          //   32: putfield b : I
          //   35: aload #4
          //   37: astore_2
          //   38: goto -> 51
          //   41: new a0/m$g$b$a$a
          //   44: dup
          //   45: aload_0
          //   46: aload_2
          //   47: invokespecial <init> : (La0/m$g$b$a;Lja/d;)V
          //   50: astore_2
          //   51: aload_2
          //   52: getfield a : Ljava/lang/Object;
          //   55: astore #5
          //   57: invokestatic c : ()Ljava/lang/Object;
          //   60: astore #4
          //   62: aload_2
          //   63: getfield b : I
          //   66: istore_3
          //   67: iload_3
          //   68: ifeq -> 94
          //   71: iload_3
          //   72: iconst_1
          //   73: if_icmpne -> 84
          //   76: aload #5
          //   78: invokestatic b : (Ljava/lang/Object;)V
          //   81: goto -> 161
          //   84: new java/lang/IllegalStateException
          //   87: dup
          //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   90: invokespecial <init> : (Ljava/lang/String;)V
          //   93: athrow
          //   94: aload #5
          //   96: invokestatic b : (Ljava/lang/Object;)V
          //   99: aload_0
          //   100: getfield a : Lkotlinx/coroutines/flow/c;
          //   103: astore #5
          //   105: aload_1
          //   106: checkcast a0/n
          //   109: astore_1
          //   110: aload_1
          //   111: instanceof a0/j
          //   114: ifne -> 201
          //   117: aload_1
          //   118: instanceof a0/h
          //   121: ifne -> 193
          //   124: aload_1
          //   125: instanceof a0/c
          //   128: ifeq -> 165
          //   131: aload_1
          //   132: checkcast a0/c
          //   135: invokevirtual b : ()Ljava/lang/Object;
          //   138: astore_1
          //   139: aload_2
          //   140: iconst_1
          //   141: putfield b : I
          //   144: aload #5
          //   146: aload_1
          //   147: aload_2
          //   148: invokeinterface emit : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
          //   153: aload #4
          //   155: if_acmpne -> 161
          //   158: aload #4
          //   160: areturn
          //   161: getstatic ga/u.a : Lga/u;
          //   164: areturn
          //   165: aload_1
          //   166: instanceof a0/o
          //   169: ifeq -> 185
          //   172: new java/lang/IllegalStateException
          //   175: dup
          //   176: ldc 'This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542'
          //   178: invokevirtual toString : ()Ljava/lang/String;
          //   181: invokespecial <init> : (Ljava/lang/String;)V
          //   184: athrow
          //   185: new ga/l
          //   188: dup
          //   189: invokespecial <init> : ()V
          //   192: athrow
          //   193: aload_1
          //   194: checkcast a0/h
          //   197: invokevirtual a : ()Ljava/lang/Throwable;
          //   200: athrow
          //   201: aload_1
          //   202: checkcast a0/j
          //   205: invokevirtual a : ()Ljava/lang/Throwable;
          //   208: athrow
        }
        
        @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
        public static final class a extends kotlin.coroutines.jvm.internal.d {
          int b;
          
          public a(m.g.b.a param4a, ja.d param4d) {
            super(param4d);
          }
          
          public final Object invokeSuspend(Object param4Object) {
            this.a = param4Object;
            this.b |= Integer.MIN_VALUE;
            return this.c.emit(null, (ja.d)this);
          }
        }
      }
      
      @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
      public static final class a extends kotlin.coroutines.jvm.internal.d {
        int b;
        
        public a(m.g.b.a param3a, ja.d param3d) {
          super(param3d);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          this.a = param3Object;
          this.b |= Integer.MIN_VALUE;
          return this.c.emit(null, (ja.d)this);
        }
      }
    }
    
    public static final class a implements kotlinx.coroutines.flow.c<n<T>> {
      public a(kotlinx.coroutines.flow.c param2c) {}
      
      public Object emit(Object param2Object, ja.d param2d) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof a0/m$g$b$a$a
        //   4: ifeq -> 41
        //   7: aload_2
        //   8: checkcast a0/m$g$b$a$a
        //   11: astore #4
        //   13: aload #4
        //   15: getfield b : I
        //   18: istore_3
        //   19: iload_3
        //   20: ldc -2147483648
        //   22: iand
        //   23: ifeq -> 41
        //   26: aload #4
        //   28: iload_3
        //   29: ldc -2147483648
        //   31: iadd
        //   32: putfield b : I
        //   35: aload #4
        //   37: astore_2
        //   38: goto -> 51
        //   41: new a0/m$g$b$a$a
        //   44: dup
        //   45: aload_0
        //   46: aload_2
        //   47: invokespecial <init> : (La0/m$g$b$a;Lja/d;)V
        //   50: astore_2
        //   51: aload_2
        //   52: getfield a : Ljava/lang/Object;
        //   55: astore #5
        //   57: invokestatic c : ()Ljava/lang/Object;
        //   60: astore #4
        //   62: aload_2
        //   63: getfield b : I
        //   66: istore_3
        //   67: iload_3
        //   68: ifeq -> 94
        //   71: iload_3
        //   72: iconst_1
        //   73: if_icmpne -> 84
        //   76: aload #5
        //   78: invokestatic b : (Ljava/lang/Object;)V
        //   81: goto -> 161
        //   84: new java/lang/IllegalStateException
        //   87: dup
        //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   90: invokespecial <init> : (Ljava/lang/String;)V
        //   93: athrow
        //   94: aload #5
        //   96: invokestatic b : (Ljava/lang/Object;)V
        //   99: aload_0
        //   100: getfield a : Lkotlinx/coroutines/flow/c;
        //   103: astore #5
        //   105: aload_1
        //   106: checkcast a0/n
        //   109: astore_1
        //   110: aload_1
        //   111: instanceof a0/j
        //   114: ifne -> 201
        //   117: aload_1
        //   118: instanceof a0/h
        //   121: ifne -> 193
        //   124: aload_1
        //   125: instanceof a0/c
        //   128: ifeq -> 165
        //   131: aload_1
        //   132: checkcast a0/c
        //   135: invokevirtual b : ()Ljava/lang/Object;
        //   138: astore_1
        //   139: aload_2
        //   140: iconst_1
        //   141: putfield b : I
        //   144: aload #5
        //   146: aload_1
        //   147: aload_2
        //   148: invokeinterface emit : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
        //   153: aload #4
        //   155: if_acmpne -> 161
        //   158: aload #4
        //   160: areturn
        //   161: getstatic ga/u.a : Lga/u;
        //   164: areturn
        //   165: aload_1
        //   166: instanceof a0/o
        //   169: ifeq -> 185
        //   172: new java/lang/IllegalStateException
        //   175: dup
        //   176: ldc 'This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542'
        //   178: invokevirtual toString : ()Ljava/lang/String;
        //   181: invokespecial <init> : (Ljava/lang/String;)V
        //   184: athrow
        //   185: new ga/l
        //   188: dup
        //   189: invokespecial <init> : ()V
        //   192: athrow
        //   193: aload_1
        //   194: checkcast a0/h
        //   197: invokevirtual a : ()Ljava/lang/Throwable;
        //   200: athrow
        //   201: aload_1
        //   202: checkcast a0/j
        //   205: invokevirtual a : ()Ljava/lang/Throwable;
        //   208: athrow
      }
      
      @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
      public static final class a extends kotlin.coroutines.jvm.internal.d {
        int b;
        
        public a(m.g.b.a param4a, ja.d param4d) {
          super(param4d);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          this.a = param4Object;
          this.b |= Integer.MIN_VALUE;
          return this.c.emit(null, (ja.d)this);
        }
      }
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
    public static final class a extends kotlin.coroutines.jvm.internal.d {
      int b;
      
      public a(m.g.b.a param2a, ja.d param2d) {
        super(param2d);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        this.a = param2Object;
        this.b |= Integer.MIN_VALUE;
        return this.c.emit(null, (ja.d)this);
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$1", f = "SingleProcessDataStore.kt", l = {}, m = "invokeSuspend")
  static final class a extends kotlin.coroutines.jvm.internal.k implements qa.p<n<T>, ja.d<? super Boolean>, Object> {
    int a;
    
    a(n<T> param1n, ja.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final Object a(n<T> param1n, ja.d<? super Boolean> param1d) {
      return ((a)create(param1n, param1d)).invokeSuspend(u.a);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      a a1 = new a(this.c, (ja.d)param1d);
      a1.b = param1Object;
      return (ja.d<u>)a1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      ka.b.c();
      if (this.a == 0) {
        ga.p.b(param1Object);
        param1Object = this.b;
        n<T> n1 = this.c;
        boolean bool = n1 instanceof c;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (!bool)
          if (n1 instanceof h) {
            bool1 = bool2;
          } else {
            bool1 = bool2;
            if (param1Object == n1)
              bool1 = true; 
          }  
        return kotlin.coroutines.jvm.internal.b.a(bool1);
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  public static final class b implements kotlinx.coroutines.flow.b<T> {
    public b(kotlinx.coroutines.flow.b param1b) {}
    
    public Object a(kotlinx.coroutines.flow.c param1c, ja.d param1d) {
      Object object = this.a.a(new a(param1c), param1d);
      return (object == ka.b.c()) ? object : u.a;
    }
    
    public static final class a implements kotlinx.coroutines.flow.c<n<T>> {
      public a(kotlinx.coroutines.flow.c param3c) {}
      
      public Object emit(Object param3Object, ja.d param3d) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof a0/m$g$b$a$a
        //   4: ifeq -> 41
        //   7: aload_2
        //   8: checkcast a0/m$g$b$a$a
        //   11: astore #4
        //   13: aload #4
        //   15: getfield b : I
        //   18: istore_3
        //   19: iload_3
        //   20: ldc -2147483648
        //   22: iand
        //   23: ifeq -> 41
        //   26: aload #4
        //   28: iload_3
        //   29: ldc -2147483648
        //   31: iadd
        //   32: putfield b : I
        //   35: aload #4
        //   37: astore_2
        //   38: goto -> 51
        //   41: new a0/m$g$b$a$a
        //   44: dup
        //   45: aload_0
        //   46: aload_2
        //   47: invokespecial <init> : (La0/m$g$b$a;Lja/d;)V
        //   50: astore_2
        //   51: aload_2
        //   52: getfield a : Ljava/lang/Object;
        //   55: astore #5
        //   57: invokestatic c : ()Ljava/lang/Object;
        //   60: astore #4
        //   62: aload_2
        //   63: getfield b : I
        //   66: istore_3
        //   67: iload_3
        //   68: ifeq -> 94
        //   71: iload_3
        //   72: iconst_1
        //   73: if_icmpne -> 84
        //   76: aload #5
        //   78: invokestatic b : (Ljava/lang/Object;)V
        //   81: goto -> 161
        //   84: new java/lang/IllegalStateException
        //   87: dup
        //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   90: invokespecial <init> : (Ljava/lang/String;)V
        //   93: athrow
        //   94: aload #5
        //   96: invokestatic b : (Ljava/lang/Object;)V
        //   99: aload_0
        //   100: getfield a : Lkotlinx/coroutines/flow/c;
        //   103: astore #5
        //   105: aload_1
        //   106: checkcast a0/n
        //   109: astore_1
        //   110: aload_1
        //   111: instanceof a0/j
        //   114: ifne -> 201
        //   117: aload_1
        //   118: instanceof a0/h
        //   121: ifne -> 193
        //   124: aload_1
        //   125: instanceof a0/c
        //   128: ifeq -> 165
        //   131: aload_1
        //   132: checkcast a0/c
        //   135: invokevirtual b : ()Ljava/lang/Object;
        //   138: astore_1
        //   139: aload_2
        //   140: iconst_1
        //   141: putfield b : I
        //   144: aload #5
        //   146: aload_1
        //   147: aload_2
        //   148: invokeinterface emit : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
        //   153: aload #4
        //   155: if_acmpne -> 161
        //   158: aload #4
        //   160: areturn
        //   161: getstatic ga/u.a : Lga/u;
        //   164: areturn
        //   165: aload_1
        //   166: instanceof a0/o
        //   169: ifeq -> 185
        //   172: new java/lang/IllegalStateException
        //   175: dup
        //   176: ldc 'This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542'
        //   178: invokevirtual toString : ()Ljava/lang/String;
        //   181: invokespecial <init> : (Ljava/lang/String;)V
        //   184: athrow
        //   185: new ga/l
        //   188: dup
        //   189: invokespecial <init> : ()V
        //   192: athrow
        //   193: aload_1
        //   194: checkcast a0/h
        //   197: invokevirtual a : ()Ljava/lang/Throwable;
        //   200: athrow
        //   201: aload_1
        //   202: checkcast a0/j
        //   205: invokevirtual a : ()Ljava/lang/Throwable;
        //   208: athrow
      }
      
      @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
      public static final class a extends kotlin.coroutines.jvm.internal.d {
        int b;
        
        public a(m.g.b.a param4a, ja.d param4d) {
          super(param4d);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          this.a = param4Object;
          this.b |= Integer.MIN_VALUE;
          return this.c.emit(null, (ja.d)this);
        }
      }
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
    public static final class a extends kotlin.coroutines.jvm.internal.d {
      int b;
      
      public a(m.g.b.a param3a, ja.d param3d) {
        super(param3d);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        this.a = param3Object;
        this.b |= Integer.MIN_VALUE;
        return this.c.emit(null, (ja.d)this);
      }
    }
  }
  
  public static final class a implements kotlinx.coroutines.flow.c<n<T>> {
    public a(kotlinx.coroutines.flow.c param1c) {}
    
    public Object emit(Object param1Object, ja.d param1d) {
      // Byte code:
      //   0: aload_2
      //   1: instanceof a0/m$g$b$a$a
      //   4: ifeq -> 41
      //   7: aload_2
      //   8: checkcast a0/m$g$b$a$a
      //   11: astore #4
      //   13: aload #4
      //   15: getfield b : I
      //   18: istore_3
      //   19: iload_3
      //   20: ldc -2147483648
      //   22: iand
      //   23: ifeq -> 41
      //   26: aload #4
      //   28: iload_3
      //   29: ldc -2147483648
      //   31: iadd
      //   32: putfield b : I
      //   35: aload #4
      //   37: astore_2
      //   38: goto -> 51
      //   41: new a0/m$g$b$a$a
      //   44: dup
      //   45: aload_0
      //   46: aload_2
      //   47: invokespecial <init> : (La0/m$g$b$a;Lja/d;)V
      //   50: astore_2
      //   51: aload_2
      //   52: getfield a : Ljava/lang/Object;
      //   55: astore #5
      //   57: invokestatic c : ()Ljava/lang/Object;
      //   60: astore #4
      //   62: aload_2
      //   63: getfield b : I
      //   66: istore_3
      //   67: iload_3
      //   68: ifeq -> 94
      //   71: iload_3
      //   72: iconst_1
      //   73: if_icmpne -> 84
      //   76: aload #5
      //   78: invokestatic b : (Ljava/lang/Object;)V
      //   81: goto -> 161
      //   84: new java/lang/IllegalStateException
      //   87: dup
      //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   90: invokespecial <init> : (Ljava/lang/String;)V
      //   93: athrow
      //   94: aload #5
      //   96: invokestatic b : (Ljava/lang/Object;)V
      //   99: aload_0
      //   100: getfield a : Lkotlinx/coroutines/flow/c;
      //   103: astore #5
      //   105: aload_1
      //   106: checkcast a0/n
      //   109: astore_1
      //   110: aload_1
      //   111: instanceof a0/j
      //   114: ifne -> 201
      //   117: aload_1
      //   118: instanceof a0/h
      //   121: ifne -> 193
      //   124: aload_1
      //   125: instanceof a0/c
      //   128: ifeq -> 165
      //   131: aload_1
      //   132: checkcast a0/c
      //   135: invokevirtual b : ()Ljava/lang/Object;
      //   138: astore_1
      //   139: aload_2
      //   140: iconst_1
      //   141: putfield b : I
      //   144: aload #5
      //   146: aload_1
      //   147: aload_2
      //   148: invokeinterface emit : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
      //   153: aload #4
      //   155: if_acmpne -> 161
      //   158: aload #4
      //   160: areturn
      //   161: getstatic ga/u.a : Lga/u;
      //   164: areturn
      //   165: aload_1
      //   166: instanceof a0/o
      //   169: ifeq -> 185
      //   172: new java/lang/IllegalStateException
      //   175: dup
      //   176: ldc 'This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542'
      //   178: invokevirtual toString : ()Ljava/lang/String;
      //   181: invokespecial <init> : (Ljava/lang/String;)V
      //   184: athrow
      //   185: new ga/l
      //   188: dup
      //   189: invokespecial <init> : ()V
      //   192: athrow
      //   193: aload_1
      //   194: checkcast a0/h
      //   197: invokevirtual a : ()Ljava/lang/Throwable;
      //   200: athrow
      //   201: aload_1
      //   202: checkcast a0/j
      //   205: invokevirtual a : ()Ljava/lang/Throwable;
      //   208: athrow
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
    public static final class a extends kotlin.coroutines.jvm.internal.d {
      int b;
      
      public a(m.g.b.a param4a, ja.d param4d) {
        super(param4d);
      }
      
      public final Object invokeSuspend(Object param4Object) {
        this.a = param4Object;
        this.b |= Integer.MIN_VALUE;
        return this.c.emit(null, (ja.d)this);
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$data$1$invokeSuspend$$inlined$map$1$2", f = "SingleProcessDataStore.kt", l = {137}, m = "emit")
  public static final class a extends kotlin.coroutines.jvm.internal.d {
    int b;
    
    public a(m.g.b.a param1a, ja.d param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.a = param1Object;
      this.b |= Integer.MIN_VALUE;
      return this.c.emit(null, (ja.d)this);
    }
  }
  
  static final class h extends kotlin.jvm.internal.m implements qa.a<File> {
    h(m<T> param1m) {
      super(0);
    }
    
    public final File a() {
      null = (File)m.h(this.a).invoke();
      String str = null.getAbsolutePath();
      m.a a1 = m.k;
      synchronized (a1.b()) {
        if ((a1.a().contains(str) ^ true) != 0) {
          Set<String> set = a1.a();
          kotlin.jvm.internal.l.e(str, "it");
          set.add(str);
          return null;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("There are multiple DataStores active for the same file: ");
        stringBuilder.append(null);
        stringBuilder.append(". You should either maintain your DataStore as a singleton or confirm that there is no two DataStore's active on the same file (by confirming that the scope is cancelled).");
        throw new IllegalStateException(stringBuilder.toString().toString());
      } 
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {276, 281, 284}, m = "handleUpdate")
  static final class i extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    Object b;
    
    Object c;
    
    int f;
    
    i(m<T> param1m, ja.d<? super i> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.d = param1Object;
      this.f |= Integer.MIN_VALUE;
      return m.j(this.e, null, (ja.d)this);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {322, 348, 505}, m = "readAndInit")
  static final class j extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    Object b;
    
    Object c;
    
    Object d;
    
    Object e;
    
    Object f;
    
    int i;
    
    j(m<T> param1m, ja.d<? super j> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.g = param1Object;
      this.i |= Integer.MIN_VALUE;
      return m.k(this.h, (ja.d)this);
    }
  }
  
  public static final class k implements i<T> {
    k(kotlinx.coroutines.sync.b param1b, t param1t, v<T> param1v, m<T> param1m) {}
    
    public Object a(qa.p<? super T, ? super ja.d<? super T>, ? extends Object> param1p, ja.d<? super T> param1d) {
      // Byte code:
      //   0: aload_2
      //   1: instanceof a0/m$k$a
      //   4: ifeq -> 38
      //   7: aload_2
      //   8: checkcast a0/m$k$a
      //   11: astore #6
      //   13: aload #6
      //   15: getfield h : I
      //   18: istore_3
      //   19: iload_3
      //   20: ldc -2147483648
      //   22: iand
      //   23: ifeq -> 38
      //   26: aload #6
      //   28: iload_3
      //   29: ldc -2147483648
      //   31: iadd
      //   32: putfield h : I
      //   35: goto -> 49
      //   38: new a0/m$k$a
      //   41: dup
      //   42: aload_0
      //   43: aload_2
      //   44: invokespecial <init> : (La0/m$k;Lja/d;)V
      //   47: astore #6
      //   49: aload #6
      //   51: getfield f : Ljava/lang/Object;
      //   54: astore #5
      //   56: invokestatic c : ()Ljava/lang/Object;
      //   59: astore #9
      //   61: aload #6
      //   63: getfield h : I
      //   66: istore_3
      //   67: iload_3
      //   68: ifeq -> 246
      //   71: iload_3
      //   72: iconst_1
      //   73: if_icmpeq -> 186
      //   76: iload_3
      //   77: iconst_2
      //   78: if_icmpeq -> 140
      //   81: iload_3
      //   82: iconst_3
      //   83: if_icmpne -> 130
      //   86: aload #6
      //   88: getfield c : Ljava/lang/Object;
      //   91: astore #7
      //   93: aload #6
      //   95: getfield b : Ljava/lang/Object;
      //   98: checkcast kotlin/jvm/internal/v
      //   101: astore #4
      //   103: aload #6
      //   105: getfield a : Ljava/lang/Object;
      //   108: checkcast kotlinx/coroutines/sync/b
      //   111: astore_2
      //   112: aload_2
      //   113: astore_1
      //   114: aload #5
      //   116: invokestatic b : (Ljava/lang/Object;)V
      //   119: aload #7
      //   121: astore #5
      //   123: goto -> 508
      //   126: astore_2
      //   127: goto -> 563
      //   130: new java/lang/IllegalStateException
      //   133: dup
      //   134: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   136: invokespecial <init> : (Ljava/lang/String;)V
      //   139: athrow
      //   140: aload #6
      //   142: getfield c : Ljava/lang/Object;
      //   145: checkcast a0/m
      //   148: astore #7
      //   150: aload #6
      //   152: getfield b : Ljava/lang/Object;
      //   155: checkcast kotlin/jvm/internal/v
      //   158: astore_2
      //   159: aload #6
      //   161: getfield a : Ljava/lang/Object;
      //   164: checkcast kotlinx/coroutines/sync/b
      //   167: astore_1
      //   168: aload_1
      //   169: astore #4
      //   171: aload #5
      //   173: invokestatic b : (Ljava/lang/Object;)V
      //   176: goto -> 427
      //   179: astore_2
      //   180: aload #4
      //   182: astore_1
      //   183: goto -> 563
      //   186: aload #6
      //   188: getfield e : Ljava/lang/Object;
      //   191: checkcast a0/m
      //   194: astore_1
      //   195: aload #6
      //   197: getfield d : Ljava/lang/Object;
      //   200: checkcast kotlin/jvm/internal/v
      //   203: astore #4
      //   205: aload #6
      //   207: getfield c : Ljava/lang/Object;
      //   210: checkcast kotlin/jvm/internal/t
      //   213: astore #8
      //   215: aload #6
      //   217: getfield b : Ljava/lang/Object;
      //   220: checkcast kotlinx/coroutines/sync/b
      //   223: astore_2
      //   224: aload #6
      //   226: getfield a : Ljava/lang/Object;
      //   229: checkcast qa/p
      //   232: astore #7
      //   234: aload #5
      //   236: invokestatic b : (Ljava/lang/Object;)V
      //   239: aload #7
      //   241: astore #5
      //   243: goto -> 344
      //   246: aload #5
      //   248: invokestatic b : (Ljava/lang/Object;)V
      //   251: aload_0
      //   252: getfield a : Lkotlinx/coroutines/sync/b;
      //   255: astore_2
      //   256: aload_0
      //   257: getfield b : Lkotlin/jvm/internal/t;
      //   260: astore #4
      //   262: aload_0
      //   263: getfield c : Lkotlin/jvm/internal/v;
      //   266: astore #7
      //   268: aload_0
      //   269: getfield d : La0/m;
      //   272: astore #8
      //   274: aload #6
      //   276: aload_1
      //   277: putfield a : Ljava/lang/Object;
      //   280: aload #6
      //   282: aload_2
      //   283: putfield b : Ljava/lang/Object;
      //   286: aload #6
      //   288: aload #4
      //   290: putfield c : Ljava/lang/Object;
      //   293: aload #6
      //   295: aload #7
      //   297: putfield d : Ljava/lang/Object;
      //   300: aload #6
      //   302: aload #8
      //   304: putfield e : Ljava/lang/Object;
      //   307: aload #6
      //   309: iconst_1
      //   310: putfield h : I
      //   313: aload_2
      //   314: aconst_null
      //   315: aload #6
      //   317: invokeinterface a : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
      //   322: aload #9
      //   324: if_acmpne -> 330
      //   327: aload #9
      //   329: areturn
      //   330: aload_1
      //   331: astore #5
      //   333: aload #8
      //   335: astore_1
      //   336: aload #4
      //   338: astore #8
      //   340: aload #7
      //   342: astore #4
      //   344: aload #8
      //   346: getfield a : Z
      //   349: ifne -> 546
      //   352: aload #4
      //   354: getfield a : Ljava/lang/Object;
      //   357: astore #7
      //   359: aload #6
      //   361: aload_2
      //   362: putfield a : Ljava/lang/Object;
      //   365: aload #6
      //   367: aload #4
      //   369: putfield b : Ljava/lang/Object;
      //   372: aload #6
      //   374: aload_1
      //   375: putfield c : Ljava/lang/Object;
      //   378: aload #6
      //   380: aconst_null
      //   381: putfield d : Ljava/lang/Object;
      //   384: aload #6
      //   386: aconst_null
      //   387: putfield e : Ljava/lang/Object;
      //   390: aload #6
      //   392: iconst_2
      //   393: putfield h : I
      //   396: aload #5
      //   398: aload #7
      //   400: aload #6
      //   402: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   407: astore #5
      //   409: aload #5
      //   411: aload #9
      //   413: if_acmpne -> 419
      //   416: aload #9
      //   418: areturn
      //   419: aload_1
      //   420: astore #7
      //   422: aload_2
      //   423: astore_1
      //   424: aload #4
      //   426: astore_2
      //   427: aload_1
      //   428: astore #4
      //   430: aload #5
      //   432: aload_2
      //   433: getfield a : Ljava/lang/Object;
      //   436: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
      //   439: ifne -> 572
      //   442: aload_1
      //   443: astore #4
      //   445: aload #6
      //   447: aload_1
      //   448: putfield a : Ljava/lang/Object;
      //   451: aload_1
      //   452: astore #4
      //   454: aload #6
      //   456: aload_2
      //   457: putfield b : Ljava/lang/Object;
      //   460: aload_1
      //   461: astore #4
      //   463: aload #6
      //   465: aload #5
      //   467: putfield c : Ljava/lang/Object;
      //   470: aload_1
      //   471: astore #4
      //   473: aload #6
      //   475: iconst_3
      //   476: putfield h : I
      //   479: aload_1
      //   480: astore #4
      //   482: aload #7
      //   484: aload #5
      //   486: aload #6
      //   488: invokevirtual A : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
      //   491: astore #6
      //   493: aload #6
      //   495: aload #9
      //   497: if_acmpne -> 503
      //   500: aload #9
      //   502: areturn
      //   503: aload_2
      //   504: astore #4
      //   506: aload_1
      //   507: astore_2
      //   508: aload_2
      //   509: astore_1
      //   510: aload #4
      //   512: aload #5
      //   514: putfield a : Ljava/lang/Object;
      //   517: aload #4
      //   519: astore_1
      //   520: aload_2
      //   521: astore #4
      //   523: aload_1
      //   524: astore_2
      //   525: goto -> 528
      //   528: aload #4
      //   530: astore_1
      //   531: aload_2
      //   532: getfield a : Ljava/lang/Object;
      //   535: astore_2
      //   536: aload #4
      //   538: aconst_null
      //   539: invokeinterface c : (Ljava/lang/Object;)V
      //   544: aload_2
      //   545: areturn
      //   546: new java/lang/IllegalStateException
      //   549: dup
      //   550: ldc 'InitializerApi.updateData should not be called after initialization is complete.'
      //   552: invokespecial <init> : (Ljava/lang/String;)V
      //   555: athrow
      //   556: astore #4
      //   558: aload_2
      //   559: astore_1
      //   560: aload #4
      //   562: astore_2
      //   563: aload_1
      //   564: aconst_null
      //   565: invokeinterface c : (Ljava/lang/Object;)V
      //   570: aload_2
      //   571: athrow
      //   572: aload_1
      //   573: astore #4
      //   575: goto -> 528
      // Exception table:
      //   from	to	target	type
      //   114	119	126	finally
      //   171	176	179	finally
      //   344	409	556	finally
      //   430	442	179	finally
      //   445	451	179	finally
      //   454	460	179	finally
      //   463	470	179	finally
      //   473	479	179	finally
      //   482	493	179	finally
      //   510	517	126	finally
      //   531	536	126	finally
      //   546	556	556	finally
    }
    
    @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$readAndInit$api$1", f = "SingleProcessDataStore.kt", l = {503, 337, 339}, m = "updateData")
    static final class a extends kotlin.coroutines.jvm.internal.d {
      Object a;
      
      Object b;
      
      Object c;
      
      Object d;
      
      Object e;
      
      int h;
      
      a(m.k param2k, ja.d<? super a> param2d) {
        super(param2d);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        this.f = param2Object;
        this.h |= Integer.MIN_VALUE;
        return this.g.a(null, (ja.d<? super T>)this);
      }
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$readAndInit$api$1", f = "SingleProcessDataStore.kt", l = {503, 337, 339}, m = "updateData")
  static final class a extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    Object b;
    
    Object c;
    
    Object d;
    
    Object e;
    
    int h;
    
    a(m.k param1k, ja.d<? super a> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.f = param1Object;
      this.h |= Integer.MIN_VALUE;
      return this.g.a(null, (ja.d<? super T>)this);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {302}, m = "readAndInitOrPropagateAndThrowFailure")
  static final class l extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    int d;
    
    l(m<T> param1m, ja.d<? super l> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.b = param1Object;
      this.d |= Integer.MIN_VALUE;
      return m.l(this.c, (ja.d)this);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {311}, m = "readAndInitOrPropagateFailure")
  static final class m extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    int d;
    
    m(m<T> param1m, ja.d<? super m> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.b = param1Object;
      this.d |= Integer.MIN_VALUE;
      return m.m(this.c, (ja.d)this);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {381}, m = "readData")
  static final class n extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    Object b;
    
    Object c;
    
    int f;
    
    n(m<T> param1m, ja.d<? super n> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.d = param1Object;
      this.f |= Integer.MIN_VALUE;
      return m.n(this.e, (ja.d)this);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {359, 362, 365}, m = "readDataOrHandleCorruption")
  static final class o extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    Object b;
    
    int e;
    
    o(m<T> param1m, ja.d<? super o> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.c = param1Object;
      this.e |= Integer.MIN_VALUE;
      return m.o(this.d, (ja.d)this);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {402, 410}, m = "transformAndWrite")
  static final class p extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    Object b;
    
    Object c;
    
    int f;
    
    p(m<T> param1m, ja.d<? super p> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.d = param1Object;
      this.f |= Integer.MIN_VALUE;
      return m.p(this.e, null, null, (ja.d)this);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore$transformAndWrite$newData$1", f = "SingleProcessDataStore.kt", l = {402}, m = "invokeSuspend")
  static final class q extends kotlin.coroutines.jvm.internal.k implements qa.p<l0, ja.d<? super T>, Object> {
    int a;
    
    q(qa.p<? super T, ? super ja.d<? super T>, ? extends Object> param1p, T param1T, ja.d<? super q> param1d) {
      super(2, param1d);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      return (ja.d<u>)new q(this.b, this.c, (ja.d)param1d);
    }
    
    public final Object invoke(l0 param1l0, ja.d<? super T> param1d) {
      return ((q)create(param1l0, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object<T, ja.d<? super T>, Object> param1Object) {
      Object object = ka.b.c();
      int i = this.a;
      if (i != 0) {
        if (i == 1) {
          ga.p.b(param1Object);
          return param1Object;
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
      ga.p.b(param1Object);
      param1Object = (Object<T, ja.d<? super T>, Object>)this.b;
      T t = this.c;
      this.a = 1;
      param1Object = (Object<T, ja.d<? super T>, Object>)param1Object.invoke(t, this);
      return (param1Object == object) ? object : param1Object;
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "androidx.datastore.core.SingleProcessDataStore", f = "SingleProcessDataStore.kt", l = {426}, m = "writeData$datastore_core")
  static final class r extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    Object b;
    
    Object c;
    
    Object d;
    
    Object e;
    
    int h;
    
    r(m<T> param1m, ja.d<? super r> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.f = param1Object;
      this.h |= Integer.MIN_VALUE;
      return this.g.A(null, (ja.d<? super u>)this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */