package a0;

import ga.p;
import ga.u;
import ja.d;
import java.util.List;
import kotlin.coroutines.jvm.internal.d;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.k;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import qa.l;
import qa.p;

public final class e<T> {
  public static final a a = new a(null);
  
  public static final class a {
    private a() {}
    
    private final <T> Object c(List<? extends d<T>> param1List, i<T> param1i, d<? super u> param1d) {
      // Byte code:
      //   0: aload_3
      //   1: instanceof a0/e$a$b
      //   4: ifeq -> 44
      //   7: aload_3
      //   8: checkcast a0/e$a$b
      //   11: astore #5
      //   13: aload #5
      //   15: getfield e : I
      //   18: istore #4
      //   20: iload #4
      //   22: ldc -2147483648
      //   24: iand
      //   25: ifeq -> 44
      //   28: aload #5
      //   30: iload #4
      //   32: ldc -2147483648
      //   34: iadd
      //   35: putfield e : I
      //   38: aload #5
      //   40: astore_3
      //   41: goto -> 54
      //   44: new a0/e$a$b
      //   47: dup
      //   48: aload_0
      //   49: aload_3
      //   50: invokespecial <init> : (La0/e$a;Lja/d;)V
      //   53: astore_3
      //   54: aload_3
      //   55: getfield c : Ljava/lang/Object;
      //   58: astore #9
      //   60: invokestatic c : ()Ljava/lang/Object;
      //   63: astore #8
      //   65: aload_3
      //   66: getfield e : I
      //   69: istore #4
      //   71: iload #4
      //   73: ifeq -> 151
      //   76: iload #4
      //   78: iconst_1
      //   79: if_icmpeq -> 135
      //   82: iload #4
      //   84: iconst_2
      //   85: if_icmpne -> 125
      //   88: aload_3
      //   89: getfield b : Ljava/lang/Object;
      //   92: checkcast java/util/Iterator
      //   95: astore_1
      //   96: aload_3
      //   97: getfield a : Ljava/lang/Object;
      //   100: checkcast kotlin/jvm/internal/v
      //   103: astore_2
      //   104: aload_3
      //   105: astore #5
      //   107: aload_1
      //   108: astore #6
      //   110: aload_2
      //   111: astore #7
      //   113: aload #9
      //   115: invokestatic b : (Ljava/lang/Object;)V
      //   118: goto -> 222
      //   121: astore_1
      //   122: goto -> 313
      //   125: new java/lang/IllegalStateException
      //   128: dup
      //   129: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   131: invokespecial <init> : (Ljava/lang/String;)V
      //   134: athrow
      //   135: aload_3
      //   136: getfield a : Ljava/lang/Object;
      //   139: checkcast java/util/List
      //   142: astore_1
      //   143: aload #9
      //   145: invokestatic b : (Ljava/lang/Object;)V
      //   148: goto -> 207
      //   151: aload #9
      //   153: invokestatic b : (Ljava/lang/Object;)V
      //   156: new java/util/ArrayList
      //   159: dup
      //   160: invokespecial <init> : ()V
      //   163: astore #5
      //   165: new a0/e$a$c
      //   168: dup
      //   169: aload_1
      //   170: aload #5
      //   172: aconst_null
      //   173: invokespecial <init> : (Ljava/util/List;Ljava/util/List;Lja/d;)V
      //   176: astore_1
      //   177: aload_3
      //   178: aload #5
      //   180: putfield a : Ljava/lang/Object;
      //   183: aload_3
      //   184: iconst_1
      //   185: putfield e : I
      //   188: aload_2
      //   189: aload_1
      //   190: aload_3
      //   191: invokeinterface a : (Lqa/p;Lja/d;)Ljava/lang/Object;
      //   196: aload #8
      //   198: if_acmpne -> 204
      //   201: aload #8
      //   203: areturn
      //   204: aload #5
      //   206: astore_1
      //   207: new kotlin/jvm/internal/v
      //   210: dup
      //   211: invokespecial <init> : ()V
      //   214: astore_2
      //   215: aload_1
      //   216: invokeinterface iterator : ()Ljava/util/Iterator;
      //   221: astore_1
      //   222: aload_1
      //   223: invokeinterface hasNext : ()Z
      //   228: ifeq -> 369
      //   231: aload_1
      //   232: invokeinterface next : ()Ljava/lang/Object;
      //   237: checkcast qa/l
      //   240: astore #9
      //   242: aload_3
      //   243: astore #5
      //   245: aload_1
      //   246: astore #6
      //   248: aload_2
      //   249: astore #7
      //   251: aload_3
      //   252: aload_2
      //   253: putfield a : Ljava/lang/Object;
      //   256: aload_3
      //   257: astore #5
      //   259: aload_1
      //   260: astore #6
      //   262: aload_2
      //   263: astore #7
      //   265: aload_3
      //   266: aload_1
      //   267: putfield b : Ljava/lang/Object;
      //   270: aload_3
      //   271: astore #5
      //   273: aload_1
      //   274: astore #6
      //   276: aload_2
      //   277: astore #7
      //   279: aload_3
      //   280: iconst_2
      //   281: putfield e : I
      //   284: aload_3
      //   285: astore #5
      //   287: aload_1
      //   288: astore #6
      //   290: aload_2
      //   291: astore #7
      //   293: aload #9
      //   295: aload_3
      //   296: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
      //   301: astore #9
      //   303: aload #9
      //   305: aload #8
      //   307: if_acmpne -> 222
      //   310: aload #8
      //   312: areturn
      //   313: aload #7
      //   315: getfield a : Ljava/lang/Object;
      //   318: astore_2
      //   319: aload_2
      //   320: ifnonnull -> 341
      //   323: aload #7
      //   325: aload_1
      //   326: putfield a : Ljava/lang/Object;
      //   329: aload #5
      //   331: astore_3
      //   332: aload #6
      //   334: astore_1
      //   335: aload #7
      //   337: astore_2
      //   338: goto -> 222
      //   341: aload_2
      //   342: invokestatic c : (Ljava/lang/Object;)V
      //   345: aload #7
      //   347: getfield a : Ljava/lang/Object;
      //   350: checkcast java/lang/Throwable
      //   353: aload_1
      //   354: invokestatic a : (Ljava/lang/Throwable;Ljava/lang/Throwable;)V
      //   357: aload #5
      //   359: astore_3
      //   360: aload #6
      //   362: astore_1
      //   363: aload #7
      //   365: astore_2
      //   366: goto -> 222
      //   369: aload_2
      //   370: getfield a : Ljava/lang/Object;
      //   373: checkcast java/lang/Throwable
      //   376: astore_1
      //   377: aload_1
      //   378: ifnonnull -> 385
      //   381: getstatic ga/u.a : Lga/u;
      //   384: areturn
      //   385: aload_1
      //   386: athrow
      // Exception table:
      //   from	to	target	type
      //   113	118	121	finally
      //   251	256	121	finally
      //   265	270	121	finally
      //   279	284	121	finally
      //   293	303	121	finally
    }
    
    public final <T> p<i<T>, d<? super u>, Object> b(List<? extends d<T>> param1List) {
      l.f(param1List, "migrations");
      return new a(param1List, null);
    }
    
    @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion$getInitializer$1", f = "DataMigrationInitializer.kt", l = {33}, m = "invokeSuspend")
    static final class a extends k implements p<i<T>, d<? super u>, Object> {
      int a;
      
      a(List<? extends d<T>> param2List, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final Object a(i<T> param2i, d<? super u> param2d) {
        return ((a)create(param2i, param2d)).invokeSuspend(u.a);
      }
      
      public final d<u> create(Object param2Object, d<?> param2d) {
        a a1 = new a(this.c, (d)param2d);
        a1.b = param2Object;
        return (d<u>)a1;
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = ka.b.c();
        int i = this.a;
        if (i != 0) {
          if (i == 1) {
            p.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param2Object);
          param2Object = this.b;
          e.a a1 = e.a;
          List<d<T>> list = this.c;
          this.a = 1;
          if (e.a.a(a1, list, (i)param2Object, (d)this) == object)
            return object; 
        } 
        return u.a;
      }
    }
    
    @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion", f = "DataMigrationInitializer.kt", l = {42, 57}, m = "runMigrations")
    static final class b<T> extends d {
      Object a;
      
      Object b;
      
      int e;
      
      b(e.a param2a, d<? super b> param2d) {
        super(param2d);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        this.c = param2Object;
        this.e |= Integer.MIN_VALUE;
        return e.a.a(this.d, null, null, (d)this);
      }
    }
    
    @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion$runMigrations$2", f = "DataMigrationInitializer.kt", l = {44, 46}, m = "invokeSuspend")
    static final class c extends k implements p<T, d<? super T>, Object> {
      Object a;
      
      Object b;
      
      Object c;
      
      int d;
      
      c(List<? extends d<T>> param2List, List<l<d<? super u>, Object>> param2List1, d<? super c> param2d) {
        super(2, param2d);
      }
      
      public final Object a(T param2T, d<? super T> param2d) {
        return ((c)create(param2T, param2d)).invokeSuspend(u.a);
      }
      
      public final d<u> create(Object param2Object, d<?> param2d) {
        c c1 = new c(this.f, this.g, (d)param2d);
        c1.e = param2Object;
        return (d<u>)c1;
      }
      
      public final Object invokeSuspend(Object<l<d<? super u>, Object>> param2Object) {
        // Byte code:
        //   0: invokestatic c : ()Ljava/lang/Object;
        //   3: astore #9
        //   5: aload_0
        //   6: getfield d : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 109
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpeq -> 64
        //   19: iload_2
        //   20: iconst_2
        //   21: if_icmpne -> 54
        //   24: aload_0
        //   25: getfield a : Ljava/lang/Object;
        //   28: checkcast java/util/Iterator
        //   31: astore #5
        //   33: aload_0
        //   34: getfield e : Ljava/lang/Object;
        //   37: checkcast java/util/List
        //   40: astore #4
        //   42: aload_1
        //   43: invokestatic b : (Ljava/lang/Object;)V
        //   46: aload_0
        //   47: astore_3
        //   48: aload_1
        //   49: astore #6
        //   51: goto -> 308
        //   54: new java/lang/IllegalStateException
        //   57: dup
        //   58: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   60: invokespecial <init> : (Ljava/lang/String;)V
        //   63: athrow
        //   64: aload_0
        //   65: getfield c : Ljava/lang/Object;
        //   68: astore #6
        //   70: aload_0
        //   71: getfield b : Ljava/lang/Object;
        //   74: checkcast a0/d
        //   77: astore #7
        //   79: aload_0
        //   80: getfield a : Ljava/lang/Object;
        //   83: checkcast java/util/Iterator
        //   86: astore #5
        //   88: aload_0
        //   89: getfield e : Ljava/lang/Object;
        //   92: checkcast java/util/List
        //   95: astore #4
        //   97: aload_1
        //   98: invokestatic b : (Ljava/lang/Object;)V
        //   101: aload_0
        //   102: astore_3
        //   103: aload_1
        //   104: astore #8
        //   106: goto -> 227
        //   109: aload_1
        //   110: invokestatic b : (Ljava/lang/Object;)V
        //   113: aload_0
        //   114: getfield e : Ljava/lang/Object;
        //   117: astore #5
        //   119: aload_0
        //   120: getfield f : Ljava/util/List;
        //   123: astore_3
        //   124: aload_0
        //   125: getfield g : Ljava/util/List;
        //   128: astore_1
        //   129: aload_3
        //   130: invokeinterface iterator : ()Ljava/util/Iterator;
        //   135: astore_3
        //   136: aload_0
        //   137: astore #4
        //   139: aload_3
        //   140: invokeinterface hasNext : ()Z
        //   145: ifeq -> 337
        //   148: aload_3
        //   149: invokeinterface next : ()Ljava/lang/Object;
        //   154: checkcast a0/d
        //   157: astore #7
        //   159: aload #4
        //   161: aload_1
        //   162: putfield e : Ljava/lang/Object;
        //   165: aload #4
        //   167: aload_3
        //   168: putfield a : Ljava/lang/Object;
        //   171: aload #4
        //   173: aload #7
        //   175: putfield b : Ljava/lang/Object;
        //   178: aload #4
        //   180: aload #5
        //   182: putfield c : Ljava/lang/Object;
        //   185: aload #4
        //   187: iconst_1
        //   188: putfield d : I
        //   191: aload #7
        //   193: aload #5
        //   195: aload #4
        //   197: invokeinterface b : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
        //   202: astore #8
        //   204: aload #8
        //   206: aload #9
        //   208: if_acmpne -> 214
        //   211: aload #9
        //   213: areturn
        //   214: aload #5
        //   216: astore #6
        //   218: aload_3
        //   219: astore #5
        //   221: aload #4
        //   223: astore_3
        //   224: aload_1
        //   225: astore #4
        //   227: aload #8
        //   229: checkcast java/lang/Boolean
        //   232: invokevirtual booleanValue : ()Z
        //   235: ifeq -> 328
        //   238: aload #4
        //   240: new a0/e$a$c$a
        //   243: dup
        //   244: aload #7
        //   246: aconst_null
        //   247: invokespecial <init> : (La0/d;Lja/d;)V
        //   250: invokeinterface add : (Ljava/lang/Object;)Z
        //   255: pop
        //   256: aload_3
        //   257: aload #4
        //   259: putfield e : Ljava/lang/Object;
        //   262: aload_3
        //   263: aload #5
        //   265: putfield a : Ljava/lang/Object;
        //   268: aload_3
        //   269: aconst_null
        //   270: putfield b : Ljava/lang/Object;
        //   273: aload_3
        //   274: aconst_null
        //   275: putfield c : Ljava/lang/Object;
        //   278: aload_3
        //   279: iconst_2
        //   280: putfield d : I
        //   283: aload #7
        //   285: aload #6
        //   287: aload_3
        //   288: invokeinterface a : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
        //   293: astore #6
        //   295: aload #6
        //   297: astore_1
        //   298: aload #6
        //   300: aload #9
        //   302: if_acmpne -> 331
        //   305: aload #9
        //   307: areturn
        //   308: aload_3
        //   309: astore #7
        //   311: aload #5
        //   313: astore_3
        //   314: aload #4
        //   316: astore_1
        //   317: aload #7
        //   319: astore #4
        //   321: aload #6
        //   323: astore #5
        //   325: goto -> 139
        //   328: aload #6
        //   330: astore_1
        //   331: aload_1
        //   332: astore #6
        //   334: goto -> 308
        //   337: aload #5
        //   339: areturn
      }
      
      @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion$runMigrations$2$1$1", f = "DataMigrationInitializer.kt", l = {45}, m = "invokeSuspend")
      static final class a extends k implements l<d<? super u>, Object> {
        int a;
        
        a(d<T> param3d, d<? super a> param3d1) {
          super(1, param3d1);
        }
        
        public final Object a(d<? super u> param3d) {
          return ((a)create(param3d)).invokeSuspend(u.a);
        }
        
        public final d<u> create(d<?> param3d) {
          return (d<u>)new a(this.b, (d)param3d);
        }
        
        public final Object invokeSuspend(Object<T> param3Object) {
          Object object = ka.b.c();
          int i = this.a;
          if (i != 0) {
            if (i == 1) {
              p.b(param3Object);
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            p.b(param3Object);
            param3Object = (Object<T>)this.b;
            this.a = 1;
            if (param3Object.c((d<? super u>)this) == object)
              return object; 
          } 
          return u.a;
        }
      }
    }
    
    @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion$runMigrations$2$1$1", f = "DataMigrationInitializer.kt", l = {45}, m = "invokeSuspend")
    static final class a extends k implements l<d<? super u>, Object> {
      int a;
      
      a(d<T> param2d, d<? super a> param2d1) {
        super(1, param2d1);
      }
      
      public final Object a(d<? super u> param2d) {
        return ((a)create(param2d)).invokeSuspend(u.a);
      }
      
      public final d<u> create(d<?> param2d) {
        return (d<u>)new a(this.b, (d)param2d);
      }
      
      public final Object invokeSuspend(Object<T> param2Object) {
        Object object = ka.b.c();
        int i = this.a;
        if (i != 0) {
          if (i == 1) {
            p.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param2Object);
          param2Object = (Object<T>)this.b;
          this.a = 1;
          if (param2Object.c((d<? super u>)this) == object)
            return object; 
        } 
        return u.a;
      }
    }
  }
  
  @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion$getInitializer$1", f = "DataMigrationInitializer.kt", l = {33}, m = "invokeSuspend")
  static final class a extends k implements p<i<T>, d<? super u>, Object> {
    int a;
    
    a(List<? extends d<T>> param1List, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final Object a(i<T> param1i, d<? super u> param1d) {
      return ((a)create(param1i, param1d)).invokeSuspend(u.a);
    }
    
    public final d<u> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.c, (d)param1d);
      a1.b = param1Object;
      return (d<u>)a1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = ka.b.c();
      int i = this.a;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = this.b;
        e.a a1 = e.a;
        List<d<T>> list = this.c;
        this.a = 1;
        if (e.a.a(a1, list, (i)param1Object, (d)this) == object)
          return object; 
      } 
      return u.a;
    }
  }
  
  @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion", f = "DataMigrationInitializer.kt", l = {42, 57}, m = "runMigrations")
  static final class b<T> extends d {
    Object a;
    
    Object b;
    
    int e;
    
    b(e.a param1a, d<? super b> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.c = param1Object;
      this.e |= Integer.MIN_VALUE;
      return e.a.a(this.d, null, null, (d)this);
    }
  }
  
  @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion$runMigrations$2", f = "DataMigrationInitializer.kt", l = {44, 46}, m = "invokeSuspend")
  static final class c extends k implements p<T, d<? super T>, Object> {
    Object a;
    
    Object b;
    
    Object c;
    
    int d;
    
    c(List<? extends d<T>> param1List, List<l<d<? super u>, Object>> param1List1, d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final Object a(T param1T, d<? super T> param1d) {
      return ((c)create(param1T, param1d)).invokeSuspend(u.a);
    }
    
    public final d<u> create(Object param1Object, d<?> param1d) {
      c c1 = new c(this.f, this.g, (d)param1d);
      c1.e = param1Object;
      return (d<u>)c1;
    }
    
    public final Object invokeSuspend(Object<l<d<? super u>, Object>> param1Object) {
      // Byte code:
      //   0: invokestatic c : ()Ljava/lang/Object;
      //   3: astore #9
      //   5: aload_0
      //   6: getfield d : I
      //   9: istore_2
      //   10: iload_2
      //   11: ifeq -> 109
      //   14: iload_2
      //   15: iconst_1
      //   16: if_icmpeq -> 64
      //   19: iload_2
      //   20: iconst_2
      //   21: if_icmpne -> 54
      //   24: aload_0
      //   25: getfield a : Ljava/lang/Object;
      //   28: checkcast java/util/Iterator
      //   31: astore #5
      //   33: aload_0
      //   34: getfield e : Ljava/lang/Object;
      //   37: checkcast java/util/List
      //   40: astore #4
      //   42: aload_1
      //   43: invokestatic b : (Ljava/lang/Object;)V
      //   46: aload_0
      //   47: astore_3
      //   48: aload_1
      //   49: astore #6
      //   51: goto -> 308
      //   54: new java/lang/IllegalStateException
      //   57: dup
      //   58: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   60: invokespecial <init> : (Ljava/lang/String;)V
      //   63: athrow
      //   64: aload_0
      //   65: getfield c : Ljava/lang/Object;
      //   68: astore #6
      //   70: aload_0
      //   71: getfield b : Ljava/lang/Object;
      //   74: checkcast a0/d
      //   77: astore #7
      //   79: aload_0
      //   80: getfield a : Ljava/lang/Object;
      //   83: checkcast java/util/Iterator
      //   86: astore #5
      //   88: aload_0
      //   89: getfield e : Ljava/lang/Object;
      //   92: checkcast java/util/List
      //   95: astore #4
      //   97: aload_1
      //   98: invokestatic b : (Ljava/lang/Object;)V
      //   101: aload_0
      //   102: astore_3
      //   103: aload_1
      //   104: astore #8
      //   106: goto -> 227
      //   109: aload_1
      //   110: invokestatic b : (Ljava/lang/Object;)V
      //   113: aload_0
      //   114: getfield e : Ljava/lang/Object;
      //   117: astore #5
      //   119: aload_0
      //   120: getfield f : Ljava/util/List;
      //   123: astore_3
      //   124: aload_0
      //   125: getfield g : Ljava/util/List;
      //   128: astore_1
      //   129: aload_3
      //   130: invokeinterface iterator : ()Ljava/util/Iterator;
      //   135: astore_3
      //   136: aload_0
      //   137: astore #4
      //   139: aload_3
      //   140: invokeinterface hasNext : ()Z
      //   145: ifeq -> 337
      //   148: aload_3
      //   149: invokeinterface next : ()Ljava/lang/Object;
      //   154: checkcast a0/d
      //   157: astore #7
      //   159: aload #4
      //   161: aload_1
      //   162: putfield e : Ljava/lang/Object;
      //   165: aload #4
      //   167: aload_3
      //   168: putfield a : Ljava/lang/Object;
      //   171: aload #4
      //   173: aload #7
      //   175: putfield b : Ljava/lang/Object;
      //   178: aload #4
      //   180: aload #5
      //   182: putfield c : Ljava/lang/Object;
      //   185: aload #4
      //   187: iconst_1
      //   188: putfield d : I
      //   191: aload #7
      //   193: aload #5
      //   195: aload #4
      //   197: invokeinterface b : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
      //   202: astore #8
      //   204: aload #8
      //   206: aload #9
      //   208: if_acmpne -> 214
      //   211: aload #9
      //   213: areturn
      //   214: aload #5
      //   216: astore #6
      //   218: aload_3
      //   219: astore #5
      //   221: aload #4
      //   223: astore_3
      //   224: aload_1
      //   225: astore #4
      //   227: aload #8
      //   229: checkcast java/lang/Boolean
      //   232: invokevirtual booleanValue : ()Z
      //   235: ifeq -> 328
      //   238: aload #4
      //   240: new a0/e$a$c$a
      //   243: dup
      //   244: aload #7
      //   246: aconst_null
      //   247: invokespecial <init> : (La0/d;Lja/d;)V
      //   250: invokeinterface add : (Ljava/lang/Object;)Z
      //   255: pop
      //   256: aload_3
      //   257: aload #4
      //   259: putfield e : Ljava/lang/Object;
      //   262: aload_3
      //   263: aload #5
      //   265: putfield a : Ljava/lang/Object;
      //   268: aload_3
      //   269: aconst_null
      //   270: putfield b : Ljava/lang/Object;
      //   273: aload_3
      //   274: aconst_null
      //   275: putfield c : Ljava/lang/Object;
      //   278: aload_3
      //   279: iconst_2
      //   280: putfield d : I
      //   283: aload #7
      //   285: aload #6
      //   287: aload_3
      //   288: invokeinterface a : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
      //   293: astore #6
      //   295: aload #6
      //   297: astore_1
      //   298: aload #6
      //   300: aload #9
      //   302: if_acmpne -> 331
      //   305: aload #9
      //   307: areturn
      //   308: aload_3
      //   309: astore #7
      //   311: aload #5
      //   313: astore_3
      //   314: aload #4
      //   316: astore_1
      //   317: aload #7
      //   319: astore #4
      //   321: aload #6
      //   323: astore #5
      //   325: goto -> 139
      //   328: aload #6
      //   330: astore_1
      //   331: aload_1
      //   332: astore #6
      //   334: goto -> 308
      //   337: aload #5
      //   339: areturn
    }
    
    @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion$runMigrations$2$1$1", f = "DataMigrationInitializer.kt", l = {45}, m = "invokeSuspend")
    static final class a extends k implements l<d<? super u>, Object> {
      int a;
      
      a(d<T> param3d, d<? super a> param3d1) {
        super(1, param3d1);
      }
      
      public final Object a(d<? super u> param3d) {
        return ((a)create(param3d)).invokeSuspend(u.a);
      }
      
      public final d<u> create(d<?> param3d) {
        return (d<u>)new a(this.b, (d)param3d);
      }
      
      public final Object invokeSuspend(Object<T> param3Object) {
        Object object = ka.b.c();
        int i = this.a;
        if (i != 0) {
          if (i == 1) {
            p.b(param3Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param3Object);
          param3Object = (Object<T>)this.b;
          this.a = 1;
          if (param3Object.c((d<? super u>)this) == object)
            return object; 
        } 
        return u.a;
      }
    }
  }
  
  @f(c = "androidx.datastore.core.DataMigrationInitializer$Companion$runMigrations$2$1$1", f = "DataMigrationInitializer.kt", l = {45}, m = "invokeSuspend")
  static final class a extends k implements l<d<? super u>, Object> {
    int a;
    
    a(d<T> param1d, d<? super a> param1d1) {
      super(1, param1d1);
    }
    
    public final Object a(d<? super u> param1d) {
      return ((a)create(param1d)).invokeSuspend(u.a);
    }
    
    public final d<u> create(d<?> param1d) {
      return (d<u>)new a(this.b, (d)param1d);
    }
    
    public final Object invokeSuspend(Object<T> param1Object) {
      Object object = ka.b.c();
      int i = this.a;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = (Object<T>)this.b;
        this.a = 1;
        if (param1Object.c((d<? super u>)this) == object)
          return object; 
      } 
      return u.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */