package a0;

final class j<T> extends n<T> {
  private final Throwable a;
  
  public j(Throwable paramThrowable) {
    super(null);
    this.a = paramThrowable;
  }
  
  public final Throwable a() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */