package a0;

import ga.u;

public interface d<T> {
  Object a(T paramT, ja.d<? super T> paramd);
  
  Object b(T paramT, ja.d<? super Boolean> paramd);
  
  Object c(ja.d<? super u> paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */