package a0;

import ja.d;

public interface b<T> {
  Object a(a parama, d<? super T> paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */