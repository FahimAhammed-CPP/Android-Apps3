package a0;

import kotlin.jvm.internal.g;

abstract class n<T> {
  private n() {}
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */