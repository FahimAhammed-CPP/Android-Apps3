package a0;

import ab.h;
import ab.l0;
import ab.m0;
import ab.t1;
import cb.f;
import cb.h;
import cb.i;
import ga.p;
import ga.u;
import ja.d;
import ja.g;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.k;
import kotlin.jvm.internal.m;
import qa.p;

public final class l<T> {
  private final l0 a;
  
  private final p<T, d<? super u>, Object> b;
  
  private final f<T> c;
  
  private final AtomicInteger d;
  
  public l(l0 paraml0, qa.l<? super Throwable, u> paraml, p<? super T, ? super Throwable, u> paramp, p<? super T, ? super d<? super u>, ? extends Object> paramp1) {
    this.a = paraml0;
    this.b = (p)paramp1;
    this.c = h.b(2147483647, null, null, 6, null);
    this.d = new AtomicInteger(0);
    t1 t1 = (t1)paraml0.k().b((g.c)t1.K);
    if (t1 == null)
      return; 
    t1.D(new a(paraml, this, paramp));
  }
  
  public final void e(T paramT) {
    cb.l l1;
    paramT = (T)this.c.d(paramT);
    if (paramT instanceof i.a) {
      Throwable throwable2 = i.e(paramT);
      Throwable throwable1 = throwable2;
      if (throwable2 == null)
        l1 = new cb.l("Channel was closed normally"); 
      throw l1;
    } 
    if (i.h(l1)) {
      if (this.d.getAndIncrement() == 0)
        h.b(this.a, null, null, new b(this, null), 3, null); 
      return;
    } 
    throw new IllegalStateException("Check failed.".toString());
  }
  
  static final class a extends m implements qa.l<Throwable, u> {
    a(qa.l<? super Throwable, u> param1l, l<T> param1l1, p<? super T, ? super Throwable, u> param1p) {
      super(1);
    }
    
    public final void a(Throwable param1Throwable) {
      Object object;
      this.a.invoke(param1Throwable);
      l.b(this.b).c(param1Throwable);
      do {
        object = i.f(l.b(this.b).a());
        if (object == null) {
          object = null;
        } else {
          this.c.invoke(object, param1Throwable);
          object = u.a;
        } 
      } while (object != null);
    }
  }
  
  @f(c = "androidx.datastore.core.SimpleActor$offer$2", f = "SimpleActor.kt", l = {122, 122}, m = "invokeSuspend")
  static final class b extends k implements p<l0, d<? super u>, Object> {
    Object a;
    
    int b;
    
    b(l<T> param1l, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<u> create(Object param1Object, d<?> param1d) {
      return (d<u>)new b(this.c, (d)param1d);
    }
    
    public final Object invoke(l0 param1l0, d<? super u> param1d) {
      return ((b)create(param1l0, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object1 = ka.b.c();
      int i = this.b;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            p.b(param1Object);
            b b1 = this;
            param1Object = object1;
            object1 = b1;
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p p2 = (p)this.a;
          p.b(param1Object);
          b b1 = this;
          b1.a = null;
          b1.b = 2;
        } 
      } else {
        b b1;
        p.b(param1Object);
        if (l.c(this.c).get() > 0) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 0) {
          b1 = this;
          param1Object = object1;
        } else {
          throw new IllegalStateException("Check failed.".toString());
        } 
        m0.d(l.d(b1.c));
        p p2 = l.a(b1.c);
        object1 = l.b(b1.c);
        b1.a = p2;
        b1.b = 1;
        object1 = object1.b((d)b1);
      } 
      Object object2 = object1;
      if (l.c(((b)object1).c).decrementAndGet() == 0)
        return u.a; 
      m0.d(l.d(((b)object2).c));
      p p1 = l.a(((b)object2).c);
      object1 = l.b(((b)object2).c);
      ((b)object2).a = p1;
      ((b)object2).b = 1;
      object1 = object1.b((d)object2);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */