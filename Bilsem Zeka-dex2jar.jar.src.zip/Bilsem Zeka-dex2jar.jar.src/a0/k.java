package a0;

import ga.u;
import ja.d;
import java.io.InputStream;
import java.io.OutputStream;

public interface k<T> {
  T a();
  
  Object b(T paramT, OutputStream paramOutputStream, d<? super u> paramd);
  
  Object c(InputStream paramInputStream, d<? super T> paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */