package a0;

import ab.l0;
import b0.a;
import b0.b;
import ha.k;
import java.io.File;
import java.util.List;
import kotlin.jvm.internal.l;
import qa.a;

public final class g {
  public static final g a = new g();
  
  public final <T> f<T> a(k<T> paramk, b<T> paramb, List<? extends d<T>> paramList, l0 paraml0, a<? extends File> parama) {
    l.f(paramk, "serializer");
    l.f(paramList, "migrations");
    l.f(paraml0, "scope");
    l.f(parama, "produceFile");
    a a1 = new a();
    return new m<T>(parama, paramk, k.b(e.a.b(paramList)), (b<T>)a1, paraml0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */