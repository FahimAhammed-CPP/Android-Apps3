package a0;

final class o extends n<Object> {
  public static final o a = new o();
  
  private o() {
    super(null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a0\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */