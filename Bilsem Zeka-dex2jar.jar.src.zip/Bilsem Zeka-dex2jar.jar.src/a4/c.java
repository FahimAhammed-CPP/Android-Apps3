package a4;

import android.text.Layout;
import f4.r;
import f4.t0;
import f4.u0;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import t3.g;
import t3.h;
import t3.j;

public final class c extends g {
  private static final Pattern p = Pattern.compile("^([0-9][0-9]+):([0-9][0-9]):([0-9][0-9])(?:(\\.[0-9]+)|:([0-9][0-9])(?:\\.([0-9]+))?)?$");
  
  private static final Pattern q = Pattern.compile("^([0-9]+(?:\\.[0-9]+)?)(h|m|s|ms|f|t)$");
  
  private static final Pattern r = Pattern.compile("^(([0-9]*.)?[0-9]+)(px|em|%)$");
  
  static final Pattern s = Pattern.compile("^([-+]?\\d+\\.?\\d*?)%$");
  
  static final Pattern t = Pattern.compile("^(\\d+\\.?\\d*?)% (\\d+\\.?\\d*?)%$");
  
  private static final Pattern u = Pattern.compile("^(\\d+\\.?\\d*?)px (\\d+\\.?\\d*?)px$");
  
  private static final Pattern v = Pattern.compile("^(\\d+) (\\d+)$");
  
  private static final b w = new b(30.0F, 1, 1);
  
  private static final a x = new a(32, 15);
  
  private final XmlPullParserFactory o;
  
  public c() {
    super("TtmlDecoder");
    try {
      XmlPullParserFactory xmlPullParserFactory = XmlPullParserFactory.newInstance();
      this.o = xmlPullParserFactory;
      xmlPullParserFactory.setNamespaceAware(true);
      return;
    } catch (XmlPullParserException xmlPullParserException) {
      throw new RuntimeException("Couldn't create XmlPullParserFactory instance", xmlPullParserException);
    } 
  }
  
  private static g C(g paramg) {
    g g1 = paramg;
    if (paramg == null)
      g1 = new g(); 
    return g1;
  }
  
  private static boolean D(String paramString) {
    return (paramString.equals("tt") || paramString.equals("head") || paramString.equals("body") || paramString.equals("div") || paramString.equals("p") || paramString.equals("span") || paramString.equals("br") || paramString.equals("style") || paramString.equals("styling") || paramString.equals("layout") || paramString.equals("region") || paramString.equals("metadata") || paramString.equals("image") || paramString.equals("data") || paramString.equals("information"));
  }
  
  private static Layout.Alignment E(String paramString) {
    paramString = s5.b.e(paramString);
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b1 = -1;
    switch (i) {
      case 109757538:
        if (!paramString.equals("start"))
          break; 
        b1 = 4;
        break;
      case 108511772:
        if (!paramString.equals("right"))
          break; 
        b1 = 3;
        break;
      case 3317767:
        if (!paramString.equals("left"))
          break; 
        b1 = 2;
        break;
      case 100571:
        if (!paramString.equals("end"))
          break; 
        b1 = 1;
        break;
      case -1364013995:
        if (!paramString.equals("center"))
          break; 
        b1 = 0;
        break;
    } 
    switch (b1) {
      default:
        return null;
      case 2:
      case 4:
        return Layout.Alignment.ALIGN_NORMAL;
      case 1:
      case 3:
        return Layout.Alignment.ALIGN_OPPOSITE;
      case 0:
        break;
    } 
    return Layout.Alignment.ALIGN_CENTER;
  }
  
  private static a F(XmlPullParser paramXmlPullParser, a parama) {
    StringBuilder stringBuilder;
    String str = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "cellResolution");
    if (str == null)
      return parama; 
    Matcher matcher = v.matcher(str);
    if (!matcher.matches()) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Ignoring malformed cell resolution: ");
      stringBuilder.append(str);
      r.i("TtmlDecoder", stringBuilder.toString());
      return parama;
    } 
    try {
      int i = Integer.parseInt((String)f4.a.e(stringBuilder.group(1)));
      int j = Integer.parseInt((String)f4.a.e(stringBuilder.group(2)));
      if (i != 0 && j != 0)
        return new a(i, j); 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid cell resolution ");
      stringBuilder.append(i);
      stringBuilder.append(" ");
      stringBuilder.append(j);
      throw new j(stringBuilder.toString());
    } catch (NumberFormatException numberFormatException) {}
    numberFormatException.append("Ignoring malformed cell resolution: ");
    numberFormatException.append(str);
    r.i("TtmlDecoder", numberFormatException.toString());
    return parama;
  }
  
  private static void G(String paramString, g paramg) {
    Matcher matcher;
    String[] arrayOfString = t0.P0(paramString, "\\s+");
    if (arrayOfString.length == 1) {
      matcher = r.matcher(paramString);
    } else if (matcher.length == 2) {
      matcher = r.matcher((CharSequence)matcher[1]);
      r.i("TtmlDecoder", "Multiple values in fontSize attribute. Picking the second value for vertical font size and ignoring the first.");
    } else {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid number of entries for fontSize: ");
      stringBuilder1.append(matcher.length);
      stringBuilder1.append(".");
      throw new j(stringBuilder1.toString());
    } 
    if (matcher.matches()) {
      StringBuilder stringBuilder1;
      paramString = (String)f4.a.e(matcher.group(3));
      paramString.hashCode();
      int i = paramString.hashCode();
      byte b1 = -1;
      switch (i) {
        case 3592:
          if (!paramString.equals("px"))
            break; 
          b1 = 2;
          break;
        case 3240:
          if (!paramString.equals("em"))
            break; 
          b1 = 1;
          break;
        case 37:
          if (!paramString.equals("%"))
            break; 
          b1 = 0;
          break;
      } 
      switch (b1) {
        default:
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Invalid unit for fontSize: '");
          stringBuilder1.append(paramString);
          stringBuilder1.append("'.");
          throw new j(stringBuilder1.toString());
        case 2:
          stringBuilder1.z(1);
          break;
        case 1:
          stringBuilder1.z(2);
          break;
        case 0:
          stringBuilder1.z(3);
          break;
      } 
      stringBuilder1.y(Float.parseFloat((String)f4.a.e(matcher.group(1))));
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid expression for fontSize: '");
    stringBuilder.append(paramString);
    stringBuilder.append("'.");
    throw new j(stringBuilder.toString());
  }
  
  private static b H(XmlPullParser paramXmlPullParser) {
    float f;
    byte b1;
    String str2 = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "frameRate");
    if (str2 != null) {
      b1 = Integer.parseInt(str2);
    } else {
      b1 = 30;
    } 
    str2 = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "frameRateMultiplier");
    if (str2 != null) {
      String[] arrayOfString = t0.P0(str2, " ");
      if (arrayOfString.length == 2) {
        f = Integer.parseInt(arrayOfString[0]) / Integer.parseInt(arrayOfString[1]);
      } else {
        throw new j("frameRateMultiplier doesn't have 2 parts");
      } 
    } else {
      f = 1.0F;
    } 
    b b2 = w;
    int i = b2.b;
    String str3 = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "subFrameRate");
    if (str3 != null)
      i = Integer.parseInt(str3); 
    int j = b2.c;
    String str1 = paramXmlPullParser.getAttributeValue("http://www.w3.org/ns/ttml#parameter", "tickRate");
    if (str1 != null)
      j = Integer.parseInt(str1); 
    return new b(b1 * f, i, j);
  }
  
  private static Map<String, g> I(XmlPullParser paramXmlPullParser, Map<String, g> paramMap, a parama, c paramc, Map<String, e> paramMap1, Map<String, String> paramMap2) {
    while (true) {
      paramXmlPullParser.next();
      if (u0.f(paramXmlPullParser, "style")) {
        String str = u0.a(paramXmlPullParser, "style");
        g g1 = N(paramXmlPullParser, new g());
        if (str != null) {
          String[] arrayOfString = O(str);
          int j = arrayOfString.length;
          int i;
          for (i = 0; i < j; i++)
            g1.a(paramMap.get(arrayOfString[i])); 
        } 
        str = g1.g();
        if (str != null)
          paramMap.put(str, g1); 
      } else if (u0.f(paramXmlPullParser, "region")) {
        e e = L(paramXmlPullParser, parama, paramc);
        if (e != null)
          paramMap1.put(e.a, e); 
      } else if (u0.f(paramXmlPullParser, "metadata")) {
        J(paramXmlPullParser, paramMap2);
      } 
      if (u0.d(paramXmlPullParser, "head"))
        return paramMap; 
    } 
  }
  
  private static void J(XmlPullParser paramXmlPullParser, Map<String, String> paramMap) {
    do {
      paramXmlPullParser.next();
      if (!u0.f(paramXmlPullParser, "image"))
        continue; 
      String str = u0.a(paramXmlPullParser, "id");
      if (str == null)
        continue; 
      paramMap.put(str, paramXmlPullParser.nextText());
    } while (!u0.d(paramXmlPullParser, "metadata"));
  }
  
  private static d K(XmlPullParser paramXmlPullParser, d paramd, Map<String, e> paramMap, b paramb) {
    long l4;
    long l5;
    String[] arrayOfString;
    int j = paramXmlPullParser.getAttributeCount();
    g g1 = N(paramXmlPullParser, null);
    String str2 = null;
    String str1 = str2;
    String str3 = "";
    int i = 0;
    long l1 = -9223372036854775807L;
    long l2 = -9223372036854775807L;
    long l3;
    for (l3 = -9223372036854775807L; i < j; l3 = l4) {
      byte b1;
      long l;
      String str5;
      String[] arrayOfString1;
      String str4 = paramXmlPullParser.getAttributeName(i);
      String str6 = paramXmlPullParser.getAttributeValue(i);
      str4.hashCode();
      switch (str4.hashCode()) {
        default:
          b1 = -1;
          break;
        case 1292595405:
          if (str4.equals("backgroundImage")) {
            b1 = 5;
            break;
          } 
        case 109780401:
          if (str4.equals("style")) {
            b1 = 4;
            break;
          } 
        case 93616297:
          if (str4.equals("begin")) {
            b1 = 3;
            break;
          } 
        case 100571:
          if (str4.equals("end")) {
            b1 = 2;
            break;
          } 
        case 99841:
          if (str4.equals("dur")) {
            b1 = 1;
            break;
          } 
        case -934795532:
          if (str4.equals("region")) {
            b1 = 0;
            break;
          } 
      } 
      switch (b1) {
        default:
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          l4 = l3;
          break;
        case 5:
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          l4 = l3;
          if (str6.startsWith("#")) {
            str4 = str6.substring(1);
            str5 = str2;
            l5 = l1;
            l = l2;
            l4 = l3;
          } 
          break;
        case 4:
          arrayOfString1 = O(str6);
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          l4 = l3;
          if (arrayOfString1.length > 0) {
            String[] arrayOfString2 = arrayOfString1;
            str4 = str1;
            l5 = l1;
            l = l2;
            l4 = l3;
          } 
          break;
        case 3:
          l5 = P((String)arrayOfString1, paramb);
          l4 = l3;
          l = l2;
          str4 = str1;
          str5 = str2;
          break;
        case 2:
          l = P((String)arrayOfString1, paramb);
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l4 = l3;
          break;
        case 1:
          l4 = P((String)arrayOfString1, paramb);
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          break;
        case 0:
          str5 = str2;
          str4 = str1;
          l5 = l1;
          l = l2;
          l4 = l3;
          if (paramMap.containsKey(arrayOfString1)) {
            arrayOfString = arrayOfString1;
            l4 = l3;
            l = l2;
            l5 = l1;
            str4 = str1;
            str5 = str2;
          } 
          break;
      } 
      i++;
      str2 = str5;
      str1 = str4;
      l1 = l5;
      l2 = l;
    } 
    if (paramd != null) {
      long l = paramd.d;
      l5 = l1;
      l4 = l2;
      if (l != -9223372036854775807L) {
        long l6 = l1;
        if (l1 != -9223372036854775807L)
          l6 = l1 + l; 
        l5 = l6;
        l4 = l2;
        if (l2 != -9223372036854775807L) {
          l4 = l2 + l;
          l5 = l6;
        } 
      } 
    } else {
      l4 = l2;
      l5 = l1;
    } 
    if (l4 == -9223372036854775807L) {
      if (l3 != -9223372036854775807L) {
        l1 = l5 + l3;
      } else {
        if (paramd != null) {
          l1 = paramd.e;
          if (l1 != -9223372036854775807L)
            return d.c(paramXmlPullParser.getName(), l5, l1, g1, (String[])str2, (String)arrayOfString, str1, paramd); 
        } 
        l1 = l4;
      } 
      return d.c(paramXmlPullParser.getName(), l5, l1, g1, (String[])str2, (String)arrayOfString, str1, paramd);
    } 
    l1 = l4;
  }
  
  private static e L(XmlPullParser paramXmlPullParser, a parama, c paramc) {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 'id'
    //   4: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   7: astore #13
    //   9: aload #13
    //   11: ifnonnull -> 16
    //   14: aconst_null
    //   15: areturn
    //   16: aload_0
    //   17: ldc_w 'origin'
    //   20: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   23: astore #12
    //   25: aload #12
    //   27: ifnull -> 792
    //   30: getstatic a4/c.t : Ljava/util/regex/Pattern;
    //   33: astore #15
    //   35: aload #15
    //   37: aload #12
    //   39: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   42: astore #16
    //   44: getstatic a4/c.u : Ljava/util/regex/Pattern;
    //   47: astore #14
    //   49: aload #14
    //   51: aload #12
    //   53: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   56: astore #17
    //   58: aload #16
    //   60: invokevirtual matches : ()Z
    //   63: istore #10
    //   65: ldc_w 'Ignoring region with malformed origin: '
    //   68: astore #11
    //   70: iload #10
    //   72: ifeq -> 158
    //   75: aload #16
    //   77: iconst_1
    //   78: invokevirtual group : (I)Ljava/lang/String;
    //   81: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   84: checkcast java/lang/String
    //   87: invokestatic parseFloat : (Ljava/lang/String;)F
    //   90: ldc_w 100.0
    //   93: fdiv
    //   94: fstore #4
    //   96: aload #16
    //   98: iconst_2
    //   99: invokevirtual group : (I)Ljava/lang/String;
    //   102: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   105: checkcast java/lang/String
    //   108: invokestatic parseFloat : (Ljava/lang/String;)F
    //   111: fstore_3
    //   112: fload_3
    //   113: ldc_w 100.0
    //   116: fdiv
    //   117: fstore_3
    //   118: goto -> 250
    //   121: new java/lang/StringBuilder
    //   124: dup
    //   125: invokespecial <init> : ()V
    //   128: astore_0
    //   129: aload #11
    //   131: astore_1
    //   132: aload_0
    //   133: aload_1
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: pop
    //   138: aload_0
    //   139: aload #12
    //   141: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   144: pop
    //   145: aload_0
    //   146: invokevirtual toString : ()Ljava/lang/String;
    //   149: astore_0
    //   150: ldc 'TtmlDecoder'
    //   152: aload_0
    //   153: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   156: aconst_null
    //   157: areturn
    //   158: aload #17
    //   160: invokevirtual matches : ()Z
    //   163: ifeq -> 777
    //   166: aload_2
    //   167: ifnonnull -> 189
    //   170: new java/lang/StringBuilder
    //   173: dup
    //   174: invokespecial <init> : ()V
    //   177: astore_0
    //   178: aload_0
    //   179: ldc_w 'Ignoring region with missing tts:extent: '
    //   182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: pop
    //   186: goto -> 138
    //   189: aload #17
    //   191: iconst_1
    //   192: invokevirtual group : (I)Ljava/lang/String;
    //   195: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   198: checkcast java/lang/String
    //   201: invokestatic parseInt : (Ljava/lang/String;)I
    //   204: istore #8
    //   206: aload #17
    //   208: iconst_2
    //   209: invokevirtual group : (I)Ljava/lang/String;
    //   212: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   215: checkcast java/lang/String
    //   218: invokestatic parseInt : (Ljava/lang/String;)I
    //   221: istore #9
    //   223: iload #8
    //   225: i2f
    //   226: aload_2
    //   227: getfield a : I
    //   230: i2f
    //   231: fdiv
    //   232: fstore #4
    //   234: iload #9
    //   236: i2f
    //   237: fstore_3
    //   238: aload_2
    //   239: getfield b : I
    //   242: istore #8
    //   244: fload_3
    //   245: iload #8
    //   247: i2f
    //   248: fdiv
    //   249: fstore_3
    //   250: aload_0
    //   251: ldc_w 'extent'
    //   254: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   257: astore #11
    //   259: aload #11
    //   261: ifnull -> 756
    //   264: aload #15
    //   266: aload #11
    //   268: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   271: astore #15
    //   273: aload #14
    //   275: aload #11
    //   277: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   280: astore #14
    //   282: aload #15
    //   284: invokevirtual matches : ()Z
    //   287: istore #10
    //   289: ldc_w 'Ignoring region with malformed extent: '
    //   292: astore #11
    //   294: iload #10
    //   296: ifeq -> 362
    //   299: aload #15
    //   301: iconst_1
    //   302: invokevirtual group : (I)Ljava/lang/String;
    //   305: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   308: checkcast java/lang/String
    //   311: invokestatic parseFloat : (Ljava/lang/String;)F
    //   314: ldc_w 100.0
    //   317: fdiv
    //   318: fstore #5
    //   320: aload #15
    //   322: iconst_2
    //   323: invokevirtual group : (I)Ljava/lang/String;
    //   326: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   329: checkcast java/lang/String
    //   332: invokestatic parseFloat : (Ljava/lang/String;)F
    //   335: fstore #6
    //   337: fload #6
    //   339: ldc_w 100.0
    //   342: fdiv
    //   343: fstore #6
    //   345: goto -> 449
    //   348: new java/lang/StringBuilder
    //   351: dup
    //   352: invokespecial <init> : ()V
    //   355: astore_0
    //   356: aload #11
    //   358: astore_1
    //   359: goto -> 132
    //   362: aload #14
    //   364: invokevirtual matches : ()Z
    //   367: ifeq -> 735
    //   370: aload_2
    //   371: ifnonnull -> 385
    //   374: new java/lang/StringBuilder
    //   377: dup
    //   378: invokespecial <init> : ()V
    //   381: astore_0
    //   382: goto -> 178
    //   385: aload #14
    //   387: iconst_1
    //   388: invokevirtual group : (I)Ljava/lang/String;
    //   391: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   394: checkcast java/lang/String
    //   397: invokestatic parseInt : (Ljava/lang/String;)I
    //   400: istore #8
    //   402: aload #14
    //   404: iconst_2
    //   405: invokevirtual group : (I)Ljava/lang/String;
    //   408: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   411: checkcast java/lang/String
    //   414: invokestatic parseInt : (Ljava/lang/String;)I
    //   417: istore #9
    //   419: iload #8
    //   421: i2f
    //   422: aload_2
    //   423: getfield a : I
    //   426: i2f
    //   427: fdiv
    //   428: fstore #5
    //   430: iload #9
    //   432: i2f
    //   433: fstore #6
    //   435: aload_2
    //   436: getfield b : I
    //   439: istore #8
    //   441: fload #6
    //   443: iload #8
    //   445: i2f
    //   446: fdiv
    //   447: fstore #6
    //   449: aload_0
    //   450: ldc_w 'displayAlign'
    //   453: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   456: astore_2
    //   457: iconst_0
    //   458: istore #8
    //   460: aload_2
    //   461: ifnull -> 520
    //   464: aload_2
    //   465: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   468: astore_2
    //   469: aload_2
    //   470: invokevirtual hashCode : ()I
    //   473: pop
    //   474: aload_2
    //   475: ldc 'center'
    //   477: invokevirtual equals : (Ljava/lang/Object;)Z
    //   480: ifne -> 507
    //   483: aload_2
    //   484: ldc_w 'after'
    //   487: invokevirtual equals : (Ljava/lang/Object;)Z
    //   490: ifne -> 496
    //   493: goto -> 520
    //   496: fload_3
    //   497: fload #6
    //   499: fadd
    //   500: fstore_3
    //   501: iconst_2
    //   502: istore #9
    //   504: goto -> 523
    //   507: fload_3
    //   508: fload #6
    //   510: fconst_2
    //   511: fdiv
    //   512: fadd
    //   513: fstore_3
    //   514: iconst_1
    //   515: istore #9
    //   517: goto -> 523
    //   520: iconst_0
    //   521: istore #9
    //   523: fconst_1
    //   524: aload_1
    //   525: getfield b : I
    //   528: i2f
    //   529: fdiv
    //   530: fstore #7
    //   532: aload_0
    //   533: ldc_w 'writingMode'
    //   536: invokestatic a : (Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    //   539: astore_0
    //   540: aload_0
    //   541: ifnull -> 691
    //   544: aload_0
    //   545: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   548: astore_0
    //   549: aload_0
    //   550: invokevirtual hashCode : ()I
    //   553: pop
    //   554: aload_0
    //   555: invokevirtual hashCode : ()I
    //   558: lookupswitch default -> 592, 3694 -> 636, 3553396 -> 617, 3553576 -> 598
    //   592: iconst_m1
    //   593: istore #8
    //   595: goto -> 649
    //   598: aload_0
    //   599: ldc_w 'tbrl'
    //   602: invokevirtual equals : (Ljava/lang/Object;)Z
    //   605: ifne -> 611
    //   608: goto -> 592
    //   611: iconst_2
    //   612: istore #8
    //   614: goto -> 649
    //   617: aload_0
    //   618: ldc_w 'tblr'
    //   621: invokevirtual equals : (Ljava/lang/Object;)Z
    //   624: ifne -> 630
    //   627: goto -> 592
    //   630: iconst_1
    //   631: istore #8
    //   633: goto -> 649
    //   636: aload_0
    //   637: ldc_w 'tb'
    //   640: invokevirtual equals : (Ljava/lang/Object;)Z
    //   643: ifne -> 649
    //   646: goto -> 592
    //   649: iload #8
    //   651: tableswitch default -> 676, 0 -> 685, 1 -> 685, 2 -> 679
    //   676: goto -> 691
    //   679: iconst_1
    //   680: istore #8
    //   682: goto -> 696
    //   685: iconst_2
    //   686: istore #8
    //   688: goto -> 696
    //   691: ldc_w -2147483648
    //   694: istore #8
    //   696: new a4/e
    //   699: dup
    //   700: aload #13
    //   702: fload #4
    //   704: fload_3
    //   705: iconst_0
    //   706: iload #9
    //   708: fload #5
    //   710: fload #6
    //   712: iconst_1
    //   713: fload #7
    //   715: iload #8
    //   717: invokespecial <init> : (Ljava/lang/String;FFIIFFIFI)V
    //   720: areturn
    //   721: new java/lang/StringBuilder
    //   724: dup
    //   725: invokespecial <init> : ()V
    //   728: astore_0
    //   729: aload #11
    //   731: astore_1
    //   732: goto -> 132
    //   735: new java/lang/StringBuilder
    //   738: dup
    //   739: invokespecial <init> : ()V
    //   742: astore_0
    //   743: ldc_w 'Ignoring region with unsupported extent: '
    //   746: astore_1
    //   747: aload_0
    //   748: aload_1
    //   749: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   752: pop
    //   753: goto -> 138
    //   756: ldc_w 'Ignoring region without an extent'
    //   759: astore_0
    //   760: goto -> 150
    //   763: new java/lang/StringBuilder
    //   766: dup
    //   767: invokespecial <init> : ()V
    //   770: astore_0
    //   771: aload #11
    //   773: astore_1
    //   774: goto -> 132
    //   777: new java/lang/StringBuilder
    //   780: dup
    //   781: invokespecial <init> : ()V
    //   784: astore_0
    //   785: ldc_w 'Ignoring region with unsupported origin: '
    //   788: astore_1
    //   789: goto -> 747
    //   792: ldc_w 'Ignoring region without an origin'
    //   795: astore_0
    //   796: goto -> 150
    //   799: astore_0
    //   800: goto -> 121
    //   803: astore_0
    //   804: goto -> 763
    //   807: astore_0
    //   808: goto -> 348
    //   811: astore_0
    //   812: goto -> 721
    // Exception table:
    //   from	to	target	type
    //   75	112	799	java/lang/NumberFormatException
    //   189	234	803	java/lang/NumberFormatException
    //   238	244	803	java/lang/NumberFormatException
    //   299	337	807	java/lang/NumberFormatException
    //   385	430	811	java/lang/NumberFormatException
    //   435	441	811	java/lang/NumberFormatException
  }
  
  private static float M(String paramString) {
    StringBuilder stringBuilder;
    Matcher matcher = s.matcher(paramString);
    if (!matcher.matches()) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid value for shear: ");
      stringBuilder.append(paramString);
      r.i("TtmlDecoder", stringBuilder.toString());
      return Float.MAX_VALUE;
    } 
    try {
      return Math.min(100.0F, Math.max(-100.0F, Float.parseFloat((String)f4.a.e(stringBuilder.group(1)))));
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Failed to parse shear: ");
      stringBuilder1.append(paramString);
      r.j("TtmlDecoder", stringBuilder1.toString(), numberFormatException);
      return Float.MAX_VALUE;
    } 
  }
  
  private static g N(XmlPullParser paramXmlPullParser, g paramg) {
    // Byte code:
    //   0: aload_0
    //   1: invokeinterface getAttributeCount : ()I
    //   6: istore #6
    //   8: iconst_0
    //   9: istore_3
    //   10: aload_1
    //   11: astore #7
    //   13: iload_3
    //   14: iload #6
    //   16: if_icmpge -> 1488
    //   19: aload_0
    //   20: iload_3
    //   21: invokeinterface getAttributeValue : (I)Ljava/lang/String;
    //   26: astore #9
    //   28: aload_0
    //   29: iload_3
    //   30: invokeinterface getAttributeName : (I)Ljava/lang/String;
    //   35: astore_1
    //   36: aload_1
    //   37: invokevirtual hashCode : ()I
    //   40: pop
    //   41: aload_1
    //   42: invokevirtual hashCode : ()I
    //   45: istore_2
    //   46: iconst_5
    //   47: istore #4
    //   49: iconst_m1
    //   50: istore #5
    //   52: iload_2
    //   53: lookupswitch default -> 184, -1550943582 -> 450, -1224696685 -> 432, -1065511464 -> 414, -879295043 -> 396, -734428249 -> 378, 3355 -> 360, 3511770 -> 341, 94842723 -> 322, 109403361 -> 303, 110138194 -> 284, 365601008 -> 265, 921125321 -> 246, 1115953443 -> 227, 1287124693 -> 208, 1754920356 -> 189
    //   184: iconst_m1
    //   185: istore_2
    //   186: goto -> 465
    //   189: aload_1
    //   190: ldc_w 'multiRowAlign'
    //   193: invokevirtual equals : (Ljava/lang/Object;)Z
    //   196: ifne -> 202
    //   199: goto -> 184
    //   202: bipush #14
    //   204: istore_2
    //   205: goto -> 465
    //   208: aload_1
    //   209: ldc_w 'backgroundColor'
    //   212: invokevirtual equals : (Ljava/lang/Object;)Z
    //   215: ifne -> 221
    //   218: goto -> 184
    //   221: bipush #13
    //   223: istore_2
    //   224: goto -> 465
    //   227: aload_1
    //   228: ldc_w 'rubyPosition'
    //   231: invokevirtual equals : (Ljava/lang/Object;)Z
    //   234: ifne -> 240
    //   237: goto -> 184
    //   240: bipush #12
    //   242: istore_2
    //   243: goto -> 465
    //   246: aload_1
    //   247: ldc_w 'textEmphasis'
    //   250: invokevirtual equals : (Ljava/lang/Object;)Z
    //   253: ifne -> 259
    //   256: goto -> 184
    //   259: bipush #11
    //   261: istore_2
    //   262: goto -> 465
    //   265: aload_1
    //   266: ldc_w 'fontSize'
    //   269: invokevirtual equals : (Ljava/lang/Object;)Z
    //   272: ifne -> 278
    //   275: goto -> 184
    //   278: bipush #10
    //   280: istore_2
    //   281: goto -> 465
    //   284: aload_1
    //   285: ldc_w 'textCombine'
    //   288: invokevirtual equals : (Ljava/lang/Object;)Z
    //   291: ifne -> 297
    //   294: goto -> 184
    //   297: bipush #9
    //   299: istore_2
    //   300: goto -> 465
    //   303: aload_1
    //   304: ldc_w 'shear'
    //   307: invokevirtual equals : (Ljava/lang/Object;)Z
    //   310: ifne -> 316
    //   313: goto -> 184
    //   316: bipush #8
    //   318: istore_2
    //   319: goto -> 465
    //   322: aload_1
    //   323: ldc_w 'color'
    //   326: invokevirtual equals : (Ljava/lang/Object;)Z
    //   329: ifne -> 335
    //   332: goto -> 184
    //   335: bipush #7
    //   337: istore_2
    //   338: goto -> 465
    //   341: aload_1
    //   342: ldc_w 'ruby'
    //   345: invokevirtual equals : (Ljava/lang/Object;)Z
    //   348: ifne -> 354
    //   351: goto -> 184
    //   354: bipush #6
    //   356: istore_2
    //   357: goto -> 465
    //   360: aload_1
    //   361: ldc_w 'id'
    //   364: invokevirtual equals : (Ljava/lang/Object;)Z
    //   367: ifne -> 373
    //   370: goto -> 184
    //   373: iconst_5
    //   374: istore_2
    //   375: goto -> 465
    //   378: aload_1
    //   379: ldc_w 'fontWeight'
    //   382: invokevirtual equals : (Ljava/lang/Object;)Z
    //   385: ifne -> 391
    //   388: goto -> 184
    //   391: iconst_4
    //   392: istore_2
    //   393: goto -> 465
    //   396: aload_1
    //   397: ldc_w 'textDecoration'
    //   400: invokevirtual equals : (Ljava/lang/Object;)Z
    //   403: ifne -> 409
    //   406: goto -> 184
    //   409: iconst_3
    //   410: istore_2
    //   411: goto -> 465
    //   414: aload_1
    //   415: ldc_w 'textAlign'
    //   418: invokevirtual equals : (Ljava/lang/Object;)Z
    //   421: ifne -> 427
    //   424: goto -> 184
    //   427: iconst_2
    //   428: istore_2
    //   429: goto -> 465
    //   432: aload_1
    //   433: ldc_w 'fontFamily'
    //   436: invokevirtual equals : (Ljava/lang/Object;)Z
    //   439: ifne -> 445
    //   442: goto -> 184
    //   445: iconst_1
    //   446: istore_2
    //   447: goto -> 465
    //   450: aload_1
    //   451: ldc_w 'fontStyle'
    //   454: invokevirtual equals : (Ljava/lang/Object;)Z
    //   457: ifne -> 463
    //   460: goto -> 184
    //   463: iconst_0
    //   464: istore_2
    //   465: iload_2
    //   466: tableswitch default -> 540, 0 -> 1461, 1 -> 1447, 2 -> 1430, 3 -> 1193, 4 -> 1173, 5 -> 1142, 6 -> 864, 7 -> 828, 8 -> 811, 9 -> 748, 10 -> 679, 11 -> 662, 12 -> 599, 13 -> 563, 14 -> 546
    //   540: aload #7
    //   542: astore_1
    //   543: goto -> 1478
    //   546: aload #7
    //   548: invokestatic C : (La4/g;)La4/g;
    //   551: aload #9
    //   553: invokestatic E : (Ljava/lang/String;)Landroid/text/Layout$Alignment;
    //   556: invokevirtual D : (Landroid/text/Layout$Alignment;)La4/g;
    //   559: astore_1
    //   560: goto -> 1478
    //   563: aload #7
    //   565: invokestatic C : (La4/g;)La4/g;
    //   568: astore_1
    //   569: aload_1
    //   570: aload #9
    //   572: invokestatic c : (Ljava/lang/String;)I
    //   575: invokevirtual u : (I)La4/g;
    //   578: pop
    //   579: goto -> 1478
    //   582: new java/lang/StringBuilder
    //   585: dup
    //   586: invokespecial <init> : ()V
    //   589: astore #7
    //   591: ldc_w 'Failed parsing background value: '
    //   594: astore #8
    //   596: goto -> 719
    //   599: aload #9
    //   601: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   604: astore_1
    //   605: aload_1
    //   606: invokevirtual hashCode : ()I
    //   609: pop
    //   610: aload_1
    //   611: ldc_w 'before'
    //   614: invokevirtual equals : (Ljava/lang/Object;)Z
    //   617: ifne -> 649
    //   620: aload_1
    //   621: ldc_w 'after'
    //   624: invokevirtual equals : (Ljava/lang/Object;)Z
    //   627: ifne -> 636
    //   630: aload #7
    //   632: astore_1
    //   633: goto -> 1478
    //   636: aload #7
    //   638: invokestatic C : (La4/g;)La4/g;
    //   641: iconst_2
    //   642: invokevirtual E : (I)La4/g;
    //   645: astore_1
    //   646: goto -> 1478
    //   649: aload #7
    //   651: invokestatic C : (La4/g;)La4/g;
    //   654: iconst_1
    //   655: invokevirtual E : (I)La4/g;
    //   658: astore_1
    //   659: goto -> 1478
    //   662: aload #7
    //   664: invokestatic C : (La4/g;)La4/g;
    //   667: aload #9
    //   669: invokestatic a : (Ljava/lang/String;)La4/b;
    //   672: invokevirtual J : (La4/b;)La4/g;
    //   675: astore_1
    //   676: goto -> 1478
    //   679: aload #7
    //   681: astore_1
    //   682: aload #7
    //   684: invokestatic C : (La4/g;)La4/g;
    //   687: astore #7
    //   689: aload #7
    //   691: astore_1
    //   692: aload #9
    //   694: aload #7
    //   696: invokestatic G : (Ljava/lang/String;La4/g;)V
    //   699: aload #7
    //   701: astore_1
    //   702: goto -> 1478
    //   705: new java/lang/StringBuilder
    //   708: dup
    //   709: invokespecial <init> : ()V
    //   712: astore #7
    //   714: ldc_w 'Failed parsing fontSize value: '
    //   717: astore #8
    //   719: aload #7
    //   721: aload #8
    //   723: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   726: pop
    //   727: aload #7
    //   729: aload #9
    //   731: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   734: pop
    //   735: ldc 'TtmlDecoder'
    //   737: aload #7
    //   739: invokevirtual toString : ()Ljava/lang/String;
    //   742: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)V
    //   745: goto -> 1478
    //   748: aload #9
    //   750: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   753: astore_1
    //   754: aload_1
    //   755: invokevirtual hashCode : ()I
    //   758: pop
    //   759: aload_1
    //   760: ldc_w 'all'
    //   763: invokevirtual equals : (Ljava/lang/Object;)Z
    //   766: ifne -> 798
    //   769: aload_1
    //   770: ldc_w 'none'
    //   773: invokevirtual equals : (Ljava/lang/Object;)Z
    //   776: ifne -> 785
    //   779: aload #7
    //   781: astore_1
    //   782: goto -> 1478
    //   785: aload #7
    //   787: invokestatic C : (La4/g;)La4/g;
    //   790: iconst_0
    //   791: invokevirtual I : (Z)La4/g;
    //   794: astore_1
    //   795: goto -> 1478
    //   798: aload #7
    //   800: invokestatic C : (La4/g;)La4/g;
    //   803: iconst_1
    //   804: invokevirtual I : (Z)La4/g;
    //   807: astore_1
    //   808: goto -> 1478
    //   811: aload #7
    //   813: invokestatic C : (La4/g;)La4/g;
    //   816: aload #9
    //   818: invokestatic M : (Ljava/lang/String;)F
    //   821: invokevirtual G : (F)La4/g;
    //   824: astore_1
    //   825: goto -> 1478
    //   828: aload #7
    //   830: invokestatic C : (La4/g;)La4/g;
    //   833: astore_1
    //   834: aload_1
    //   835: aload #9
    //   837: invokestatic c : (Ljava/lang/String;)I
    //   840: invokevirtual w : (I)La4/g;
    //   843: pop
    //   844: goto -> 1478
    //   847: new java/lang/StringBuilder
    //   850: dup
    //   851: invokespecial <init> : ()V
    //   854: astore #7
    //   856: ldc_w 'Failed parsing color value: '
    //   859: astore #8
    //   861: goto -> 719
    //   864: aload #9
    //   866: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   869: astore_1
    //   870: aload_1
    //   871: invokevirtual hashCode : ()I
    //   874: pop
    //   875: aload_1
    //   876: invokevirtual hashCode : ()I
    //   879: lookupswitch default -> 936, -618561360 -> 1029, -410956671 -> 1011, -250518009 -> 993, -136074796 -> 975, 3016401 -> 957, 3556653 -> 941
    //   936: iconst_m1
    //   937: istore_2
    //   938: goto -> 1044
    //   941: iload #4
    //   943: istore_2
    //   944: aload_1
    //   945: ldc_w 'text'
    //   948: invokevirtual equals : (Ljava/lang/Object;)Z
    //   951: ifne -> 1044
    //   954: goto -> 936
    //   957: aload_1
    //   958: ldc_w 'base'
    //   961: invokevirtual equals : (Ljava/lang/Object;)Z
    //   964: ifne -> 970
    //   967: goto -> 936
    //   970: iconst_4
    //   971: istore_2
    //   972: goto -> 1044
    //   975: aload_1
    //   976: ldc_w 'textContainer'
    //   979: invokevirtual equals : (Ljava/lang/Object;)Z
    //   982: ifne -> 988
    //   985: goto -> 936
    //   988: iconst_3
    //   989: istore_2
    //   990: goto -> 1044
    //   993: aload_1
    //   994: ldc_w 'delimiter'
    //   997: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1000: ifne -> 1006
    //   1003: goto -> 936
    //   1006: iconst_2
    //   1007: istore_2
    //   1008: goto -> 1044
    //   1011: aload_1
    //   1012: ldc_w 'container'
    //   1015: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1018: ifne -> 1024
    //   1021: goto -> 936
    //   1024: iconst_1
    //   1025: istore_2
    //   1026: goto -> 1044
    //   1029: aload_1
    //   1030: ldc_w 'baseContainer'
    //   1033: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1036: ifne -> 1042
    //   1039: goto -> 936
    //   1042: iconst_0
    //   1043: istore_2
    //   1044: iload_2
    //   1045: tableswitch default -> 1084, 0 -> 1129, 1 -> 1116, 2 -> 1103, 3 -> 1090, 4 -> 1129, 5 -> 1090
    //   1084: aload #7
    //   1086: astore_1
    //   1087: goto -> 1478
    //   1090: aload #7
    //   1092: invokestatic C : (La4/g;)La4/g;
    //   1095: iconst_3
    //   1096: invokevirtual F : (I)La4/g;
    //   1099: astore_1
    //   1100: goto -> 1478
    //   1103: aload #7
    //   1105: invokestatic C : (La4/g;)La4/g;
    //   1108: iconst_4
    //   1109: invokevirtual F : (I)La4/g;
    //   1112: astore_1
    //   1113: goto -> 1478
    //   1116: aload #7
    //   1118: invokestatic C : (La4/g;)La4/g;
    //   1121: iconst_1
    //   1122: invokevirtual F : (I)La4/g;
    //   1125: astore_1
    //   1126: goto -> 1478
    //   1129: aload #7
    //   1131: invokestatic C : (La4/g;)La4/g;
    //   1134: iconst_2
    //   1135: invokevirtual F : (I)La4/g;
    //   1138: astore_1
    //   1139: goto -> 1478
    //   1142: aload #7
    //   1144: astore_1
    //   1145: ldc 'style'
    //   1147: aload_0
    //   1148: invokeinterface getName : ()Ljava/lang/String;
    //   1153: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1156: ifeq -> 1478
    //   1159: aload #7
    //   1161: invokestatic C : (La4/g;)La4/g;
    //   1164: aload #9
    //   1166: invokevirtual A : (Ljava/lang/String;)La4/g;
    //   1169: astore_1
    //   1170: goto -> 1478
    //   1173: aload #7
    //   1175: invokestatic C : (La4/g;)La4/g;
    //   1178: ldc_w 'bold'
    //   1181: aload #9
    //   1183: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1186: invokevirtual v : (Z)La4/g;
    //   1189: astore_1
    //   1190: goto -> 1478
    //   1193: aload #9
    //   1195: invokestatic e : (Ljava/lang/String;)Ljava/lang/String;
    //   1198: astore_1
    //   1199: aload_1
    //   1200: invokevirtual hashCode : ()I
    //   1203: pop
    //   1204: aload_1
    //   1205: invokevirtual hashCode : ()I
    //   1208: lookupswitch default -> 1252, -1461280213 -> 1321, -1026963764 -> 1300, 913457136 -> 1279, 1679736913 -> 1258
    //   1252: iload #5
    //   1254: istore_2
    //   1255: goto -> 1339
    //   1258: aload_1
    //   1259: ldc_w 'linethrough'
    //   1262: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1265: ifne -> 1274
    //   1268: iload #5
    //   1270: istore_2
    //   1271: goto -> 1339
    //   1274: iconst_3
    //   1275: istore_2
    //   1276: goto -> 1339
    //   1279: aload_1
    //   1280: ldc_w 'nolinethrough'
    //   1283: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1286: ifne -> 1295
    //   1289: iload #5
    //   1291: istore_2
    //   1292: goto -> 1339
    //   1295: iconst_2
    //   1296: istore_2
    //   1297: goto -> 1339
    //   1300: aload_1
    //   1301: ldc_w 'underline'
    //   1304: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1307: ifne -> 1316
    //   1310: iload #5
    //   1312: istore_2
    //   1313: goto -> 1339
    //   1316: iconst_1
    //   1317: istore_2
    //   1318: goto -> 1339
    //   1321: aload_1
    //   1322: ldc_w 'nounderline'
    //   1325: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1328: ifne -> 1337
    //   1331: iload #5
    //   1333: istore_2
    //   1334: goto -> 1339
    //   1337: iconst_0
    //   1338: istore_2
    //   1339: iload_2
    //   1340: tableswitch default -> 1372, 0 -> 1417, 1 -> 1404, 2 -> 1391, 3 -> 1378
    //   1372: aload #7
    //   1374: astore_1
    //   1375: goto -> 1478
    //   1378: aload #7
    //   1380: invokestatic C : (La4/g;)La4/g;
    //   1383: iconst_1
    //   1384: invokevirtual C : (Z)La4/g;
    //   1387: astore_1
    //   1388: goto -> 1478
    //   1391: aload #7
    //   1393: invokestatic C : (La4/g;)La4/g;
    //   1396: iconst_0
    //   1397: invokevirtual C : (Z)La4/g;
    //   1400: astore_1
    //   1401: goto -> 1478
    //   1404: aload #7
    //   1406: invokestatic C : (La4/g;)La4/g;
    //   1409: iconst_1
    //   1410: invokevirtual K : (Z)La4/g;
    //   1413: astore_1
    //   1414: goto -> 1478
    //   1417: aload #7
    //   1419: invokestatic C : (La4/g;)La4/g;
    //   1422: iconst_0
    //   1423: invokevirtual K : (Z)La4/g;
    //   1426: astore_1
    //   1427: goto -> 1478
    //   1430: aload #7
    //   1432: invokestatic C : (La4/g;)La4/g;
    //   1435: aload #9
    //   1437: invokestatic E : (Ljava/lang/String;)Landroid/text/Layout$Alignment;
    //   1440: invokevirtual H : (Landroid/text/Layout$Alignment;)La4/g;
    //   1443: astore_1
    //   1444: goto -> 1478
    //   1447: aload #7
    //   1449: invokestatic C : (La4/g;)La4/g;
    //   1452: aload #9
    //   1454: invokevirtual x : (Ljava/lang/String;)La4/g;
    //   1457: astore_1
    //   1458: goto -> 1478
    //   1461: aload #7
    //   1463: invokestatic C : (La4/g;)La4/g;
    //   1466: ldc_w 'italic'
    //   1469: aload #9
    //   1471: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   1474: invokevirtual B : (Z)La4/g;
    //   1477: astore_1
    //   1478: iload_3
    //   1479: iconst_1
    //   1480: iadd
    //   1481: istore_3
    //   1482: aload_1
    //   1483: astore #7
    //   1485: goto -> 13
    //   1488: aload #7
    //   1490: areturn
    //   1491: astore #7
    //   1493: goto -> 582
    //   1496: astore #7
    //   1498: goto -> 705
    //   1501: astore #7
    //   1503: goto -> 847
    // Exception table:
    //   from	to	target	type
    //   569	579	1491	java/lang/IllegalArgumentException
    //   682	689	1496	t3/j
    //   692	699	1496	t3/j
    //   834	844	1501	java/lang/IllegalArgumentException
  }
  
  private static String[] O(String paramString) {
    paramString = paramString.trim();
    return paramString.isEmpty() ? new String[0] : t0.P0(paramString, "\\s+");
  }
  
  private static long P(String paramString, b paramb) {
    // Byte code:
    //   0: getstatic a4/c.p : Ljava/util/regex/Pattern;
    //   3: aload_0
    //   4: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   7: astore #16
    //   9: aload #16
    //   11: invokevirtual matches : ()Z
    //   14: istore #15
    //   16: iconst_4
    //   17: istore #14
    //   19: iload #15
    //   21: ifeq -> 193
    //   24: aload #16
    //   26: iconst_1
    //   27: invokevirtual group : (I)Ljava/lang/String;
    //   30: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   33: checkcast java/lang/String
    //   36: invokestatic parseLong : (Ljava/lang/String;)J
    //   39: ldc2_w 3600
    //   42: lmul
    //   43: l2d
    //   44: dstore #8
    //   46: aload #16
    //   48: iconst_2
    //   49: invokevirtual group : (I)Ljava/lang/String;
    //   52: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   55: checkcast java/lang/String
    //   58: invokestatic parseLong : (Ljava/lang/String;)J
    //   61: ldc2_w 60
    //   64: lmul
    //   65: l2d
    //   66: dstore #10
    //   68: aload #16
    //   70: iconst_3
    //   71: invokevirtual group : (I)Ljava/lang/String;
    //   74: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   77: checkcast java/lang/String
    //   80: invokestatic parseLong : (Ljava/lang/String;)J
    //   83: l2d
    //   84: dstore #12
    //   86: aload #16
    //   88: iconst_4
    //   89: invokevirtual group : (I)Ljava/lang/String;
    //   92: astore_0
    //   93: dconst_0
    //   94: dstore #6
    //   96: aload_0
    //   97: ifnull -> 108
    //   100: aload_0
    //   101: invokestatic parseDouble : (Ljava/lang/String;)D
    //   104: dstore_2
    //   105: goto -> 110
    //   108: dconst_0
    //   109: dstore_2
    //   110: aload #16
    //   112: iconst_5
    //   113: invokevirtual group : (I)Ljava/lang/String;
    //   116: astore_0
    //   117: aload_0
    //   118: ifnull -> 137
    //   121: aload_0
    //   122: invokestatic parseLong : (Ljava/lang/String;)J
    //   125: l2f
    //   126: aload_1
    //   127: getfield a : F
    //   130: fdiv
    //   131: f2d
    //   132: dstore #4
    //   134: goto -> 140
    //   137: dconst_0
    //   138: dstore #4
    //   140: aload #16
    //   142: bipush #6
    //   144: invokevirtual group : (I)Ljava/lang/String;
    //   147: astore_0
    //   148: aload_0
    //   149: ifnull -> 171
    //   152: aload_0
    //   153: invokestatic parseLong : (Ljava/lang/String;)J
    //   156: l2d
    //   157: aload_1
    //   158: getfield b : I
    //   161: i2d
    //   162: ddiv
    //   163: aload_1
    //   164: getfield a : F
    //   167: f2d
    //   168: ddiv
    //   169: dstore #6
    //   171: dload #8
    //   173: dload #10
    //   175: dadd
    //   176: dload #12
    //   178: dadd
    //   179: dload_2
    //   180: dadd
    //   181: dload #4
    //   183: dadd
    //   184: dload #6
    //   186: dadd
    //   187: ldc2_w 1000000.0
    //   190: dmul
    //   191: d2l
    //   192: lreturn
    //   193: getstatic a4/c.q : Ljava/util/regex/Pattern;
    //   196: aload_0
    //   197: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   200: astore #16
    //   202: aload #16
    //   204: invokevirtual matches : ()Z
    //   207: ifeq -> 490
    //   210: aload #16
    //   212: iconst_1
    //   213: invokevirtual group : (I)Ljava/lang/String;
    //   216: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   219: checkcast java/lang/String
    //   222: invokestatic parseDouble : (Ljava/lang/String;)D
    //   225: dstore #4
    //   227: aload #16
    //   229: iconst_2
    //   230: invokevirtual group : (I)Ljava/lang/String;
    //   233: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   236: checkcast java/lang/String
    //   239: astore_0
    //   240: aload_0
    //   241: invokevirtual hashCode : ()I
    //   244: pop
    //   245: aload_0
    //   246: invokevirtual hashCode : ()I
    //   249: lookupswitch default -> 300, 102 -> 376, 104 -> 357, 109 -> 338, 116 -> 319, 3494 -> 306
    //   300: iconst_m1
    //   301: istore #14
    //   303: goto -> 392
    //   306: aload_0
    //   307: ldc_w 'ms'
    //   310: invokevirtual equals : (Ljava/lang/Object;)Z
    //   313: ifne -> 392
    //   316: goto -> 300
    //   319: aload_0
    //   320: ldc_w 't'
    //   323: invokevirtual equals : (Ljava/lang/Object;)Z
    //   326: ifne -> 332
    //   329: goto -> 300
    //   332: iconst_3
    //   333: istore #14
    //   335: goto -> 392
    //   338: aload_0
    //   339: ldc_w 'm'
    //   342: invokevirtual equals : (Ljava/lang/Object;)Z
    //   345: ifne -> 351
    //   348: goto -> 300
    //   351: iconst_2
    //   352: istore #14
    //   354: goto -> 392
    //   357: aload_0
    //   358: ldc_w 'h'
    //   361: invokevirtual equals : (Ljava/lang/Object;)Z
    //   364: ifne -> 370
    //   367: goto -> 300
    //   370: iconst_1
    //   371: istore #14
    //   373: goto -> 392
    //   376: aload_0
    //   377: ldc_w 'f'
    //   380: invokevirtual equals : (Ljava/lang/Object;)Z
    //   383: ifne -> 389
    //   386: goto -> 300
    //   389: iconst_0
    //   390: istore #14
    //   392: iload #14
    //   394: tableswitch default -> 428, 0 -> 474, 1 -> 462, 2 -> 455, 3 -> 446, 4 -> 434
    //   428: dload #4
    //   430: dstore_2
    //   431: goto -> 483
    //   434: ldc2_w 1000.0
    //   437: dstore_2
    //   438: dload #4
    //   440: dload_2
    //   441: ddiv
    //   442: dstore_2
    //   443: goto -> 483
    //   446: aload_1
    //   447: getfield c : I
    //   450: i2d
    //   451: dstore_2
    //   452: goto -> 438
    //   455: ldc2_w 60.0
    //   458: dstore_2
    //   459: goto -> 466
    //   462: ldc2_w 3600.0
    //   465: dstore_2
    //   466: dload #4
    //   468: dload_2
    //   469: dmul
    //   470: dstore_2
    //   471: goto -> 483
    //   474: aload_1
    //   475: getfield a : F
    //   478: f2d
    //   479: dstore_2
    //   480: goto -> 438
    //   483: dload_2
    //   484: ldc2_w 1000000.0
    //   487: dmul
    //   488: d2l
    //   489: lreturn
    //   490: new java/lang/StringBuilder
    //   493: dup
    //   494: invokespecial <init> : ()V
    //   497: astore_1
    //   498: aload_1
    //   499: ldc_w 'Malformed time expression: '
    //   502: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   505: pop
    //   506: aload_1
    //   507: aload_0
    //   508: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   511: pop
    //   512: new t3/j
    //   515: dup
    //   516: aload_1
    //   517: invokevirtual toString : ()Ljava/lang/String;
    //   520: invokespecial <init> : (Ljava/lang/String;)V
    //   523: athrow
  }
  
  private static c Q(XmlPullParser paramXmlPullParser) {
    StringBuilder stringBuilder;
    String str1;
    String str2 = u0.a(paramXmlPullParser, "extent");
    if (str2 == null)
      return null; 
    Matcher matcher = u.matcher(str2);
    if (!matcher.matches()) {
      stringBuilder = new StringBuilder();
      str1 = "Ignoring non-pixel tts extent: ";
      stringBuilder.append(str1);
      stringBuilder.append(str2);
      r.i("TtmlDecoder", stringBuilder.toString());
      return null;
    } 
    try {
      return new c(Integer.parseInt((String)f4.a.e(stringBuilder.group(1))), Integer.parseInt((String)f4.a.e(stringBuilder.group(2))));
    } catch (NumberFormatException numberFormatException) {}
    numberFormatException.append(str1);
    numberFormatException.append(str2);
    r.i("TtmlDecoder", numberFormatException.toString());
    return null;
  }
  
  protected h A(byte[] paramArrayOfbyte, int paramInt, boolean paramBoolean) {
    h h;
    try {
      XmlPullParser xmlPullParser = this.o.newPullParser();
      HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>();
      HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>();
      HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>();
      hashMap2.put("", new e(""));
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte, 0, paramInt);
      c c1 = null;
      xmlPullParser.setInput(byteArrayInputStream, null);
      ArrayDeque<d> arrayDeque = new ArrayDeque();
      int j = xmlPullParser.getEventType();
      b b1 = w;
      a a1 = x;
      h = null;
      int i = 0;
      while (true) {
        if (j != 1) {
          d d = arrayDeque.peek();
          if (!i) {
            c c3;
            String str = xmlPullParser.getName();
            if (j == 2) {
              StringBuilder stringBuilder;
              if ("tt".equals(str)) {
                b1 = H(xmlPullParser);
                a1 = F(xmlPullParser, x);
                c1 = Q(xmlPullParser);
              } 
              paramBoolean = D(str);
              if (!paramBoolean) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("Ignoring unsupported tag: ");
                stringBuilder.append(xmlPullParser.getName());
                r.f("TtmlDecoder", stringBuilder.toString());
                paramInt = i + 1;
              } else if ("head".equals(str)) {
                I(xmlPullParser, (Map)hashMap1, a1, c1, (Map)hashMap2, (Map)hashMap3);
                paramInt = i;
              } else {
                b b3;
                a a3;
                h h2;
                try {
                  d d1 = K(xmlPullParser, (d)stringBuilder, (Map)hashMap2, b1);
                  arrayDeque.push(d1);
                  paramInt = i;
                  if (stringBuilder != null) {
                    stringBuilder.a(d1);
                    paramInt = i;
                  } 
                  c3 = c1;
                  b3 = b1;
                  a3 = a1;
                  h2 = h;
                } catch (j j1) {
                  r.j("TtmlDecoder", "Suppressing parser error", (Throwable)j1);
                  paramInt = i + 1;
                  c3 = c1;
                  b3 = b1;
                  a3 = a1;
                  h2 = h;
                } 
                xmlPullParser.next();
                j = xmlPullParser.getEventType();
                c1 = c3;
                b1 = b3;
                a1 = a3;
                i = paramInt;
                h = h2;
              } 
            } else {
              b b3;
              a a3;
              h h2;
              if (j == 4) {
                ((d)f4.a.e(c3)).a(d.d(xmlPullParser.getText()));
                c3 = c1;
                b3 = b1;
                a3 = a1;
                paramInt = i;
                h2 = h;
              } else {
                c3 = c1;
                b3 = b1;
                a3 = a1;
                paramInt = i;
                h2 = h;
                if (j == 3) {
                  if (xmlPullParser.getName().equals("tt"))
                    h = new h((d)f4.a.e(arrayDeque.peek()), (Map)hashMap1, (Map)hashMap2, (Map)hashMap3); 
                  arrayDeque.pop();
                  c3 = c1;
                  b3 = b1;
                  a3 = a1;
                  paramInt = i;
                  h2 = h;
                } 
              } 
              xmlPullParser.next();
              j = xmlPullParser.getEventType();
              c1 = c3;
              b1 = b3;
              a1 = a3;
              i = paramInt;
              h = h2;
            } 
          } else {
            c c3;
            b b3;
            a a3;
            h h2;
            if (j == 2) {
              paramInt = i + 1;
              c3 = c1;
              b3 = b1;
              a3 = a1;
              h2 = h;
            } else {
              c3 = c1;
              b3 = b1;
              a3 = a1;
              paramInt = i;
              h2 = h;
              if (j == 3) {
                paramInt = i - 1;
                c3 = c1;
                b3 = b1;
                a3 = a1;
                h2 = h;
              } 
            } 
            xmlPullParser.next();
            j = xmlPullParser.getEventType();
            c1 = c3;
            b1 = b3;
            a1 = a3;
            i = paramInt;
            h = h2;
          } 
        } else {
          break;
        } 
        c c2 = c1;
        b b2 = b1;
        a a2 = a1;
        h h1 = h;
      } 
    } catch (XmlPullParserException xmlPullParserException) {
      throw new j("Unable to decode source", xmlPullParserException);
    } catch (IOException iOException) {
      throw new IllegalStateException("Unexpected error when reading input.", iOException);
    } 
    if (h != null)
      return h; 
    throw new j("No TTML subtitles found");
  }
  
  private static final class a {
    final int a;
    
    final int b;
    
    a(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
  }
  
  private static final class b {
    final float a;
    
    final int b;
    
    final int c;
    
    b(float param1Float, int param1Int1, int param1Int2) {
      this.a = param1Float;
      this.b = param1Int1;
      this.c = param1Int2;
    }
  }
  
  private static final class c {
    final int a;
    
    final int b;
    
    c(int param1Int1, int param1Int2) {
      this.a = param1Int1;
      this.b = param1Int2;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a4\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */