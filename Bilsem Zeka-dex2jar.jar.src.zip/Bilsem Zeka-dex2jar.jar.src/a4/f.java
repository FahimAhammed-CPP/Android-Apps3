package a4;

import android.text.Spannable;
import android.text.SpannableStringBuilder;
import java.util.ArrayDeque;
import java.util.Map;

final class f {
  public static void a(Spannable paramSpannable, int paramInt1, int paramInt2, g paramg, d paramd, Map<String, g> paramMap, int paramInt3) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual l : ()I
    //   4: iconst_m1
    //   5: if_icmpeq -> 29
    //   8: aload_0
    //   9: new android/text/style/StyleSpan
    //   12: dup
    //   13: aload_3
    //   14: invokevirtual l : ()I
    //   17: invokespecial <init> : (I)V
    //   20: iload_1
    //   21: iload_2
    //   22: bipush #33
    //   24: invokeinterface setSpan : (Ljava/lang/Object;III)V
    //   29: aload_3
    //   30: invokevirtual s : ()Z
    //   33: ifeq -> 53
    //   36: aload_0
    //   37: new android/text/style/StrikethroughSpan
    //   40: dup
    //   41: invokespecial <init> : ()V
    //   44: iload_1
    //   45: iload_2
    //   46: bipush #33
    //   48: invokeinterface setSpan : (Ljava/lang/Object;III)V
    //   53: aload_3
    //   54: invokevirtual t : ()Z
    //   57: ifeq -> 77
    //   60: aload_0
    //   61: new android/text/style/UnderlineSpan
    //   64: dup
    //   65: invokespecial <init> : ()V
    //   68: iload_1
    //   69: iload_2
    //   70: bipush #33
    //   72: invokeinterface setSpan : (Ljava/lang/Object;III)V
    //   77: aload_3
    //   78: invokevirtual q : ()Z
    //   81: ifeq -> 103
    //   84: aload_0
    //   85: new android/text/style/ForegroundColorSpan
    //   88: dup
    //   89: aload_3
    //   90: invokevirtual c : ()I
    //   93: invokespecial <init> : (I)V
    //   96: iload_1
    //   97: iload_2
    //   98: bipush #33
    //   100: invokestatic a : (Landroid/text/Spannable;Ljava/lang/Object;III)V
    //   103: aload_3
    //   104: invokevirtual p : ()Z
    //   107: ifeq -> 129
    //   110: aload_0
    //   111: new android/text/style/BackgroundColorSpan
    //   114: dup
    //   115: aload_3
    //   116: invokevirtual b : ()I
    //   119: invokespecial <init> : (I)V
    //   122: iload_1
    //   123: iload_2
    //   124: bipush #33
    //   126: invokestatic a : (Landroid/text/Spannable;Ljava/lang/Object;III)V
    //   129: aload_3
    //   130: invokevirtual d : ()Ljava/lang/String;
    //   133: ifnull -> 155
    //   136: aload_0
    //   137: new android/text/style/TypefaceSpan
    //   140: dup
    //   141: aload_3
    //   142: invokevirtual d : ()Ljava/lang/String;
    //   145: invokespecial <init> : (Ljava/lang/String;)V
    //   148: iload_1
    //   149: iload_2
    //   150: bipush #33
    //   152: invokestatic a : (Landroid/text/Spannable;Ljava/lang/Object;III)V
    //   155: aload_3
    //   156: invokevirtual o : ()La4/b;
    //   159: ifnull -> 270
    //   162: aload_3
    //   163: invokevirtual o : ()La4/b;
    //   166: invokestatic e : (Ljava/lang/Object;)Ljava/lang/Object;
    //   169: checkcast a4/b
    //   172: astore #10
    //   174: aload #10
    //   176: getfield a : I
    //   179: istore #8
    //   181: iload #8
    //   183: iconst_m1
    //   184: if_icmpne -> 217
    //   187: iload #6
    //   189: iconst_2
    //   190: if_icmpeq -> 208
    //   193: iload #6
    //   195: iconst_1
    //   196: if_icmpne -> 202
    //   199: goto -> 208
    //   202: iconst_1
    //   203: istore #6
    //   205: goto -> 211
    //   208: iconst_3
    //   209: istore #6
    //   211: iconst_1
    //   212: istore #7
    //   214: goto -> 228
    //   217: aload #10
    //   219: getfield b : I
    //   222: istore #7
    //   224: iload #8
    //   226: istore #6
    //   228: aload #10
    //   230: getfield c : I
    //   233: istore #9
    //   235: iload #9
    //   237: istore #8
    //   239: iload #9
    //   241: bipush #-2
    //   243: if_icmpne -> 249
    //   246: iconst_1
    //   247: istore #8
    //   249: aload_0
    //   250: new x3/d
    //   253: dup
    //   254: iload #6
    //   256: iload #7
    //   258: iload #8
    //   260: invokespecial <init> : (III)V
    //   263: iload_1
    //   264: iload_2
    //   265: bipush #33
    //   267: invokestatic a : (Landroid/text/Spannable;Ljava/lang/Object;III)V
    //   270: aload_3
    //   271: invokevirtual j : ()I
    //   274: istore #6
    //   276: iload #6
    //   278: iconst_2
    //   279: if_icmpeq -> 321
    //   282: iload #6
    //   284: iconst_3
    //   285: if_icmpeq -> 297
    //   288: iload #6
    //   290: iconst_4
    //   291: if_icmpeq -> 297
    //   294: goto -> 494
    //   297: new a4/a
    //   300: dup
    //   301: invokespecial <init> : ()V
    //   304: astore #4
    //   306: aload_0
    //   307: aload #4
    //   309: iload_1
    //   310: iload_2
    //   311: bipush #33
    //   313: invokeinterface setSpan : (Ljava/lang/Object;III)V
    //   318: goto -> 494
    //   321: aload #4
    //   323: aload #5
    //   325: invokestatic d : (La4/d;Ljava/util/Map;)La4/d;
    //   328: astore #10
    //   330: aload #10
    //   332: ifnonnull -> 338
    //   335: goto -> 494
    //   338: aload #10
    //   340: aload #5
    //   342: invokestatic e : (La4/d;Ljava/util/Map;)La4/d;
    //   345: astore #11
    //   347: aload #11
    //   349: ifnonnull -> 355
    //   352: goto -> 494
    //   355: aload #11
    //   357: invokevirtual g : ()I
    //   360: iconst_1
    //   361: if_icmpne -> 487
    //   364: aload #11
    //   366: iconst_0
    //   367: invokevirtual f : (I)La4/d;
    //   370: getfield b : Ljava/lang/String;
    //   373: ifnull -> 487
    //   376: aload #11
    //   378: iconst_0
    //   379: invokevirtual f : (I)La4/d;
    //   382: getfield b : Ljava/lang/String;
    //   385: invokestatic j : (Ljava/lang/Object;)Ljava/lang/Object;
    //   388: checkcast java/lang/String
    //   391: astore #4
    //   393: aload #11
    //   395: getfield f : La4/g;
    //   398: aload #11
    //   400: invokevirtual l : ()[Ljava/lang/String;
    //   403: aload #5
    //   405: invokestatic f : (La4/g;[Ljava/lang/String;Ljava/util/Map;)La4/g;
    //   408: astore #11
    //   410: aload #11
    //   412: ifnull -> 425
    //   415: aload #11
    //   417: invokevirtual i : ()I
    //   420: istore #6
    //   422: goto -> 428
    //   425: iconst_m1
    //   426: istore #6
    //   428: iload #6
    //   430: istore #7
    //   432: iload #6
    //   434: iconst_m1
    //   435: if_icmpne -> 471
    //   438: aload #10
    //   440: getfield f : La4/g;
    //   443: aload #10
    //   445: invokevirtual l : ()[Ljava/lang/String;
    //   448: aload #5
    //   450: invokestatic f : (La4/g;[Ljava/lang/String;Ljava/util/Map;)La4/g;
    //   453: astore #5
    //   455: iload #6
    //   457: istore #7
    //   459: aload #5
    //   461: ifnull -> 471
    //   464: aload #5
    //   466: invokevirtual i : ()I
    //   469: istore #7
    //   471: new x3/b
    //   474: dup
    //   475: aload #4
    //   477: iload #7
    //   479: invokespecial <init> : (Ljava/lang/String;I)V
    //   482: astore #4
    //   484: goto -> 306
    //   487: ldc 'TtmlRenderUtil'
    //   489: ldc 'Skipping rubyText node without exactly one text child.'
    //   491: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)V
    //   494: aload_3
    //   495: invokevirtual n : ()Z
    //   498: ifeq -> 516
    //   501: aload_0
    //   502: new x3/a
    //   505: dup
    //   506: invokespecial <init> : ()V
    //   509: iload_1
    //   510: iload_2
    //   511: bipush #33
    //   513: invokestatic a : (Landroid/text/Spannable;Ljava/lang/Object;III)V
    //   516: aload_3
    //   517: invokevirtual f : ()I
    //   520: istore #6
    //   522: iload #6
    //   524: iconst_1
    //   525: if_icmpeq -> 574
    //   528: iload #6
    //   530: iconst_2
    //   531: if_icmpeq -> 559
    //   534: iload #6
    //   536: iconst_3
    //   537: if_icmpeq -> 541
    //   540: return
    //   541: new android/text/style/RelativeSizeSpan
    //   544: dup
    //   545: aload_3
    //   546: invokevirtual e : ()F
    //   549: ldc 100.0
    //   551: fdiv
    //   552: invokespecial <init> : (F)V
    //   555: astore_3
    //   556: goto -> 588
    //   559: new android/text/style/RelativeSizeSpan
    //   562: dup
    //   563: aload_3
    //   564: invokevirtual e : ()F
    //   567: invokespecial <init> : (F)V
    //   570: astore_3
    //   571: goto -> 588
    //   574: new android/text/style/AbsoluteSizeSpan
    //   577: dup
    //   578: aload_3
    //   579: invokevirtual e : ()F
    //   582: f2i
    //   583: iconst_1
    //   584: invokespecial <init> : (IZ)V
    //   587: astore_3
    //   588: aload_0
    //   589: aload_3
    //   590: iload_1
    //   591: iload_2
    //   592: bipush #33
    //   594: invokestatic a : (Landroid/text/Spannable;Ljava/lang/Object;III)V
    //   597: return
  }
  
  static String b(String paramString) {
    return paramString.replaceAll("\r\n", "\n").replaceAll(" *\n *", "\n").replaceAll("\n", " ").replaceAll("[ \t\\x0B\f\r]+", " ");
  }
  
  static void c(SpannableStringBuilder paramSpannableStringBuilder) {
    int i;
    for (i = paramSpannableStringBuilder.length() - 1; i >= 0 && paramSpannableStringBuilder.charAt(i) == ' '; i--);
    if (i >= 0 && paramSpannableStringBuilder.charAt(i) != '\n')
      paramSpannableStringBuilder.append('\n'); 
  }
  
  private static d d(d paramd, Map<String, g> paramMap) {
    while (paramd != null) {
      g g = f(paramd.f, paramd.l(), paramMap);
      if (g != null && g.j() == 1)
        return paramd; 
      paramd = paramd.j;
    } 
    return null;
  }
  
  private static d e(d paramd, Map<String, g> paramMap) {
    ArrayDeque<d> arrayDeque = new ArrayDeque();
    arrayDeque.push(paramd);
    while (!arrayDeque.isEmpty()) {
      paramd = arrayDeque.pop();
      g g = f(paramd.f, paramd.l(), paramMap);
      if (g != null && g.j() == 3)
        return paramd; 
      for (int i = paramd.g() - 1; i >= 0; i--)
        arrayDeque.push(paramd.f(i)); 
    } 
    return null;
  }
  
  public static g f(g paramg, String[] paramArrayOfString, Map<String, g> paramMap) {
    int j = 0;
    int i = 0;
    if (paramg == null) {
      if (paramArrayOfString == null)
        return null; 
      if (paramArrayOfString.length == 1)
        return paramMap.get(paramArrayOfString[0]); 
      if (paramArrayOfString.length > 1) {
        paramg = new g();
        j = paramArrayOfString.length;
        while (i < j) {
          paramg.a(paramMap.get(paramArrayOfString[i]));
          i++;
        } 
        return paramg;
      } 
    } else {
      if (paramArrayOfString != null && paramArrayOfString.length == 1)
        return paramg.a(paramMap.get(paramArrayOfString[0])); 
      if (paramArrayOfString != null && paramArrayOfString.length > 1) {
        int k = paramArrayOfString.length;
        for (i = j; i < k; i++)
          paramg.a(paramMap.get(paramArrayOfString[i])); 
      } 
    } 
    return paramg;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a4\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */