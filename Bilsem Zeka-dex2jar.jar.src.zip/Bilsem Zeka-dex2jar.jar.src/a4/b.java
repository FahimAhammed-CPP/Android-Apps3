package a4;

import android.text.TextUtils;
import com.google.common.collect.s;
import java.util.regex.Pattern;

final class b {
  private static final Pattern d = Pattern.compile("\\s+");
  
  private static final s<String> e = s.J("auto", "none");
  
  private static final s<String> f = s.K("dot", "sesame", "circle");
  
  private static final s<String> g = s.J("filled", "open");
  
  private static final s<String> h = s.K("after", "before", "outside");
  
  public final int a;
  
  public final int b;
  
  public final int c;
  
  private b(int paramInt1, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
  }
  
  public static b a(String paramString) {
    if (paramString == null)
      return null; 
    paramString = s5.b.e(paramString.trim());
    return paramString.isEmpty() ? null : b(s.E((Object[])TextUtils.split(paramString, d)));
  }
  
  private static b b(s<String> params) {
    // Byte code:
    //   0: getstatic a4/b.h : Lcom/google/common/collect/s;
    //   3: aload_0
    //   4: invokestatic e : (Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/p0$e;
    //   7: ldc 'outside'
    //   9: invokestatic b : (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object;
    //   12: checkcast java/lang/String
    //   15: astore #7
    //   17: aload #7
    //   19: invokevirtual hashCode : ()I
    //   22: istore_1
    //   23: iconst_2
    //   24: istore_3
    //   25: iconst_0
    //   26: istore #5
    //   28: iconst_1
    //   29: istore #6
    //   31: iconst_m1
    //   32: istore #4
    //   34: iload_1
    //   35: ldc -1392885889
    //   37: if_icmpeq -> 85
    //   40: iload_1
    //   41: ldc -1106037339
    //   43: if_icmpeq -> 70
    //   46: iload_1
    //   47: ldc 92734940
    //   49: if_icmpeq -> 55
    //   52: goto -> 100
    //   55: aload #7
    //   57: ldc 'after'
    //   59: invokevirtual equals : (Ljava/lang/Object;)Z
    //   62: ifeq -> 100
    //   65: iconst_0
    //   66: istore_1
    //   67: goto -> 102
    //   70: aload #7
    //   72: ldc 'outside'
    //   74: invokevirtual equals : (Ljava/lang/Object;)Z
    //   77: ifeq -> 100
    //   80: iconst_1
    //   81: istore_1
    //   82: goto -> 102
    //   85: aload #7
    //   87: ldc 'before'
    //   89: invokevirtual equals : (Ljava/lang/Object;)Z
    //   92: ifeq -> 100
    //   95: iconst_2
    //   96: istore_1
    //   97: goto -> 102
    //   100: iconst_m1
    //   101: istore_1
    //   102: iload_1
    //   103: ifeq -> 122
    //   106: iload_1
    //   107: iconst_1
    //   108: if_icmpeq -> 116
    //   111: iconst_1
    //   112: istore_2
    //   113: goto -> 124
    //   116: bipush #-2
    //   118: istore_2
    //   119: goto -> 124
    //   122: iconst_2
    //   123: istore_2
    //   124: getstatic a4/b.e : Lcom/google/common/collect/s;
    //   127: aload_0
    //   128: invokestatic e : (Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/p0$e;
    //   131: astore #7
    //   133: aload #7
    //   135: invokeinterface isEmpty : ()Z
    //   140: ifne -> 233
    //   143: aload #7
    //   145: invokeinterface iterator : ()Ljava/util/Iterator;
    //   150: invokeinterface next : ()Ljava/lang/Object;
    //   155: checkcast java/lang/String
    //   158: astore_0
    //   159: aload_0
    //   160: invokevirtual hashCode : ()I
    //   163: istore_1
    //   164: iload_1
    //   165: ldc 3005871
    //   167: if_icmpeq -> 193
    //   170: iload_1
    //   171: ldc 3387192
    //   173: if_icmpeq -> 179
    //   176: goto -> 208
    //   179: aload_0
    //   180: ldc 'none'
    //   182: invokevirtual equals : (Ljava/lang/Object;)Z
    //   185: ifeq -> 208
    //   188: iconst_0
    //   189: istore_1
    //   190: goto -> 210
    //   193: aload_0
    //   194: ldc 'auto'
    //   196: invokevirtual equals : (Ljava/lang/Object;)Z
    //   199: ifeq -> 208
    //   202: iload #6
    //   204: istore_1
    //   205: goto -> 210
    //   208: iconst_m1
    //   209: istore_1
    //   210: iload_1
    //   211: ifeq -> 220
    //   214: iload #4
    //   216: istore_1
    //   217: goto -> 222
    //   220: iconst_0
    //   221: istore_1
    //   222: new a4/b
    //   225: dup
    //   226: iload_1
    //   227: iconst_0
    //   228: iload_2
    //   229: invokespecial <init> : (III)V
    //   232: areturn
    //   233: getstatic a4/b.g : Lcom/google/common/collect/s;
    //   236: aload_0
    //   237: invokestatic e : (Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/p0$e;
    //   240: astore #7
    //   242: getstatic a4/b.f : Lcom/google/common/collect/s;
    //   245: aload_0
    //   246: invokestatic e : (Ljava/util/Set;Ljava/util/Set;)Lcom/google/common/collect/p0$e;
    //   249: astore_0
    //   250: aload #7
    //   252: invokeinterface isEmpty : ()Z
    //   257: ifeq -> 280
    //   260: aload_0
    //   261: invokeinterface isEmpty : ()Z
    //   266: ifeq -> 280
    //   269: new a4/b
    //   272: dup
    //   273: iconst_m1
    //   274: iconst_0
    //   275: iload_2
    //   276: invokespecial <init> : (III)V
    //   279: areturn
    //   280: aload #7
    //   282: ldc 'filled'
    //   284: invokestatic b : (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object;
    //   287: checkcast java/lang/String
    //   290: astore #7
    //   292: aload #7
    //   294: invokevirtual hashCode : ()I
    //   297: istore_1
    //   298: iload_1
    //   299: ldc -1274499742
    //   301: if_icmpeq -> 328
    //   304: iload_1
    //   305: ldc 3417674
    //   307: if_icmpeq -> 313
    //   310: goto -> 343
    //   313: aload #7
    //   315: ldc 'open'
    //   317: invokevirtual equals : (Ljava/lang/Object;)Z
    //   320: ifeq -> 343
    //   323: iconst_0
    //   324: istore_1
    //   325: goto -> 345
    //   328: aload #7
    //   330: ldc 'filled'
    //   332: invokevirtual equals : (Ljava/lang/Object;)Z
    //   335: ifeq -> 343
    //   338: iconst_1
    //   339: istore_1
    //   340: goto -> 345
    //   343: iconst_m1
    //   344: istore_1
    //   345: iload_1
    //   346: ifeq -> 355
    //   349: iconst_1
    //   350: istore #4
    //   352: goto -> 358
    //   355: iconst_2
    //   356: istore #4
    //   358: aload_0
    //   359: ldc 'circle'
    //   361: invokestatic b : (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object;
    //   364: checkcast java/lang/String
    //   367: astore_0
    //   368: aload_0
    //   369: invokevirtual hashCode : ()I
    //   372: istore_1
    //   373: iload_1
    //   374: ldc -1360216880
    //   376: if_icmpeq -> 423
    //   379: iload_1
    //   380: ldc -905816648
    //   382: if_icmpeq -> 409
    //   385: iload_1
    //   386: ldc 99657
    //   388: if_icmpeq -> 394
    //   391: goto -> 437
    //   394: aload_0
    //   395: ldc 'dot'
    //   397: invokevirtual equals : (Ljava/lang/Object;)Z
    //   400: ifeq -> 437
    //   403: iload #5
    //   405: istore_1
    //   406: goto -> 439
    //   409: aload_0
    //   410: ldc 'sesame'
    //   412: invokevirtual equals : (Ljava/lang/Object;)Z
    //   415: ifeq -> 437
    //   418: iconst_1
    //   419: istore_1
    //   420: goto -> 439
    //   423: aload_0
    //   424: ldc 'circle'
    //   426: invokevirtual equals : (Ljava/lang/Object;)Z
    //   429: ifeq -> 437
    //   432: iconst_2
    //   433: istore_1
    //   434: goto -> 439
    //   437: iconst_m1
    //   438: istore_1
    //   439: iload_1
    //   440: ifeq -> 455
    //   443: iload_1
    //   444: iconst_1
    //   445: if_icmpeq -> 453
    //   448: iconst_1
    //   449: istore_3
    //   450: goto -> 455
    //   453: iconst_3
    //   454: istore_3
    //   455: new a4/b
    //   458: dup
    //   459: iload_3
    //   460: iload #4
    //   462: iload_2
    //   463: invokespecial <init> : (III)V
    //   466: areturn
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a4\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */