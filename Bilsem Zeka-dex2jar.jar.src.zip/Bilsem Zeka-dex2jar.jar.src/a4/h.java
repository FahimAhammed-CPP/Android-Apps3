package a4;

import f4.t0;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import t3.b;
import t3.h;

final class h implements h {
  private final d a;
  
  private final long[] b;
  
  private final Map<String, g> c;
  
  private final Map<String, e> d;
  
  private final Map<String, String> e;
  
  public h(d paramd, Map<String, g> paramMap, Map<String, e> paramMap1, Map<String, String> paramMap2) {
    this.a = paramd;
    this.d = paramMap1;
    this.e = paramMap2;
    if (paramMap != null) {
      paramMap = Collections.unmodifiableMap(paramMap);
    } else {
      paramMap = Collections.emptyMap();
    } 
    this.c = paramMap;
    this.b = paramd.j();
  }
  
  public int a(long paramLong) {
    int i = t0.e(this.b, paramLong, false, false);
    return (i < this.b.length) ? i : -1;
  }
  
  public long f(int paramInt) {
    return this.b[paramInt];
  }
  
  public List<b> i(long paramLong) {
    return this.a.h(paramLong, this.c, this.d, this.e);
  }
  
  public int l() {
    return this.b.length;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a4\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */