package a1;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import kotlin.jvm.internal.g;
import r0.f0;

public final class o {
  public static final a c = new a(null);
  
  private final String a;
  
  private final boolean b;
  
  private o(String paramString, boolean paramBoolean) {
    this.a = paramString;
    this.b = paramBoolean;
  }
  
  public final void a() {
    SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(f0.l()).edit();
    editor.putString("com.facebook.appevents.SourceApplicationInfo.callingApplicationPackage", this.a);
    editor.putBoolean("com.facebook.appevents.SourceApplicationInfo.openedByApplink", this.b);
    editor.apply();
  }
  
  public String toString() {
    String str1;
    if (this.b) {
      str1 = "Applink";
    } else {
      str1 = "Unclassified";
    } 
    String str2 = str1;
    if (this.a != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append('(');
      stringBuilder.append(this.a);
      stringBuilder.append(')');
      str2 = stringBuilder.toString();
    } 
    return str2;
  }
  
  public static final class a {
    private a() {}
    
    public final void a() {
      SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(f0.l()).edit();
      editor.remove("com.facebook.appevents.SourceApplicationInfo.callingApplicationPackage");
      editor.remove("com.facebook.appevents.SourceApplicationInfo.openedByApplink");
      editor.apply();
    }
    
    public final o b() {
      SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(f0.l());
      return !sharedPreferences.contains("com.facebook.appevents.SourceApplicationInfo.callingApplicationPackage") ? null : new o(sharedPreferences.getString("com.facebook.appevents.SourceApplicationInfo.callingApplicationPackage", null), sharedPreferences.getBoolean("com.facebook.appevents.SourceApplicationInfo.openedByApplink", false), null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */