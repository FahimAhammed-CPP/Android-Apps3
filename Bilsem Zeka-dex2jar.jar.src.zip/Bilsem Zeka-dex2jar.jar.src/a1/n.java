package a1;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import h1.c0;
import java.util.Arrays;
import java.util.Locale;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.y;
import q1.a;
import r0.r0;
import s0.e0;
import s0.o;

public final class n {
  public static final n a = new n();
  
  private static final String b = n.class.getCanonicalName();
  
  private static final long[] c = new long[] { 
      300000L, 900000L, 1800000L, 3600000L, 21600000L, 43200000L, 86400000L, 172800000L, 259200000L, 604800000L, 
      1209600000L, 1814400000L, 2419200000L, 5184000000L, 7776000000L, 10368000000L, 12960000000L, 15552000000L, 31536000000L };
  
  private final String a(Context paramContext) {
    try {
      String str1;
      PackageManager packageManager = paramContext.getPackageManager();
      String str3 = l.m("PCKGCHKSUM;", (packageManager.getPackageInfo(paramContext.getPackageName(), 0)).versionName);
      SharedPreferences sharedPreferences = paramContext.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0);
      String str2 = sharedPreferences.getString(str3, null);
      if (str2 != null && str2.length() == 32)
        return str2; 
      str2 = l.c(paramContext, null);
      if (str2 != null) {
        str1 = str2;
      } else {
        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(str1.getPackageName(), 0);
        l.e(applicationInfo, "pm.getApplicationInfo(context.packageName, 0)");
        str1 = l.b(applicationInfo.sourceDir);
      } 
      sharedPreferences.edit().putString(str3, str1).apply();
      return str1;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static final int b(long paramLong) {
    int i = 0;
    while (true) {
      long[] arrayOfLong = c;
      if (i < arrayOfLong.length && arrayOfLong[i] < paramLong) {
        i++;
        continue;
      } 
      break;
    } 
    return i;
  }
  
  public static final void c(String paramString1, o paramo, String paramString2, Context paramContext) {
    String str1;
    l.f(paramString1, "activityName");
    l.f(paramContext, "context");
    String str2 = "Unclassified";
    if (paramo == null) {
      str1 = str2;
    } else {
      str1 = str1.toString();
      if (str1 == null)
        str1 = str2; 
    } 
    Bundle bundle = new Bundle();
    bundle.putString("fb_mobile_launch_source", str1);
    bundle.putString("fb_mobile_pckg_fp", a.a(paramContext));
    bundle.putString("fb_mobile_app_cert_hash", a.a(paramContext));
    e0.a a = e0.b;
    e0 e0 = a.a(paramString1, paramString2, null);
    e0.d("fb_mobile_activate_app", bundle);
    if (a.c() != o.b.b)
      e0.a(); 
  }
  
  private final void d() {
    c0.a a = c0.e;
    r0 r0 = r0.e;
    String str = b;
    l.c(str);
    a.b(r0, str, "Clock skew detected");
  }
  
  public static final void e(String paramString1, m paramm, String paramString2) {
    l.f(paramString1, "activityName");
    if (paramm == null)
      return; 
    Long long_2 = paramm.b();
    long l3 = 0L;
    if (long_2 == null) {
      long_2 = paramm.e();
      if (long_2 == null) {
        l1 = 0L;
      } else {
        l1 = long_2.longValue();
      } 
      l1 = 0L - l1;
    } else {
      l1 = long_2.longValue();
    } 
    long l2 = l1;
    if (l1 < 0L) {
      a.d();
      l2 = 0L;
    } 
    long l4 = paramm.f();
    long l1 = l4;
    if (l4 < 0L) {
      a.d();
      l1 = 0L;
    } 
    Bundle bundle = new Bundle();
    bundle.putInt("fb_mobile_app_interruptions", paramm.c());
    y y = y.a;
    String str = String.format(Locale.ROOT, "session_quanta_%d", Arrays.copyOf(new Object[] { Integer.valueOf(b(l2)) }, 1));
    l.e(str, "java.lang.String.format(locale, format, *args)");
    bundle.putString("fb_mobile_time_between_sessions", str);
    o o = paramm.g();
    str = "Unclassified";
    if (o != null) {
      String str1 = o.toString();
      if (str1 != null)
        str = str1; 
    } 
    bundle.putString("fb_mobile_launch_source", str);
    Long long_1 = paramm.e();
    if (long_1 == null) {
      l2 = l3;
    } else {
      l2 = long_1.longValue();
    } 
    bundle.putLong("_logTime", l2 / 1000L);
    e0.b.a(paramString1, paramString2, null).c("fb_mobile_deactivate_app", l1 / 1000L, bundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */