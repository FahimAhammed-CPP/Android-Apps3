package a1;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import e1.e;
import ga.u;
import h1.c0;
import h1.n;
import h1.n0;
import h1.r;
import h1.v;
import java.lang.ref.WeakReference;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.jvm.internal.l;
import r0.f0;
import r0.r0;
import s0.o;
import t0.b;
import v0.e;
import y0.k;

public final class f {
  public static final f a = new f();
  
  private static final String b;
  
  private static final ScheduledExecutorService c = Executors.newSingleThreadScheduledExecutor();
  
  private static volatile ScheduledFuture<?> d;
  
  private static final Object e = new Object();
  
  private static final AtomicInteger f = new AtomicInteger(0);
  
  private static volatile m g;
  
  private static final AtomicBoolean h = new AtomicBoolean(false);
  
  private static String i;
  
  private static long j;
  
  private static int k;
  
  private static WeakReference<Activity> l;
  
  private final void k() {
    synchronized (e) {
      if (d != null) {
        ScheduledFuture<?> scheduledFuture = d;
        if (scheduledFuture != null)
          scheduledFuture.cancel(false); 
      } 
      d = null;
      u u = u.a;
      return;
    } 
  }
  
  public static final Activity l() {
    WeakReference<Activity> weakReference = l;
    Activity activity = null;
    if (weakReference != null) {
      if (weakReference == null)
        return null; 
      activity = weakReference.get();
    } 
    return activity;
  }
  
  public static final UUID m() {
    UUID uUID;
    m m2 = g;
    m m1 = null;
    if (m2 != null) {
      m1 = g;
      if (m1 == null)
        return null; 
      uUID = m1.d();
    } 
    return uUID;
  }
  
  private final int n() {
    v v = v.a;
    r r = v.f(f0.m());
    return (r == null) ? j.a() : r.k();
  }
  
  public static final boolean o() {
    return (k == 0);
  }
  
  public static final void p(Activity paramActivity) {
    c.execute(new d());
  }
  
  private static final void q() {
    if (g == null)
      g = m.g.b(); 
  }
  
  private final void r(Activity paramActivity) {
    e.j(paramActivity);
  }
  
  private final void s(Activity paramActivity) {
    AtomicInteger atomicInteger = f;
    if (atomicInteger.decrementAndGet() < 0) {
      atomicInteger.set(0);
      Log.w(b, "Unexpected activity pause without a matching activity resume. Logging data may be incorrect. Make sure you call activateApp from your Application's onCreate method");
    } 
    k();
    long l = System.currentTimeMillis();
    String str = n0.t((Context)paramActivity);
    e.k(paramActivity);
    b b = new b(l, str);
    c.execute(b);
  }
  
  private static final void t(long paramLong, String paramString) {
    l.f(paramString, "$activityName");
    if (g == null)
      g = new m(Long.valueOf(paramLong), null, null, 4, null); 
    m m2 = g;
    if (m2 != null)
      m2.k(Long.valueOf(paramLong)); 
    if (f.get() <= 0) {
      e e = new e(paramLong, paramString);
      synchronized (e) {
        d = c.schedule(e, a.n(), TimeUnit.SECONDS);
        u u = u.a;
      } 
    } 
    long l2 = j;
    long l1 = 0L;
    if (l2 > 0L)
      l1 = (paramLong - l2) / 1000L; 
    i.e(paramString, l1);
    m m1 = g;
    if (m1 == null)
      return; 
    m1.m();
  }
  
  private static final void u(long paramLong, String paramString) {
    l.f(paramString, "$activityName");
    if (g == null)
      g = new m(Long.valueOf(paramLong), null, null, 4, null); 
    if (f.get() <= 0) {
      n n = n.a;
      n.e(paramString, g, i);
      m.g.a();
      g = null;
    } 
    synchronized (e) {
      d = null;
      u u = u.a;
      return;
    } 
  }
  
  public static final void v(Activity paramActivity) {
    l.f(paramActivity, "activity");
    l = new WeakReference<Activity>(paramActivity);
    f.incrementAndGet();
    a.k();
    long l = System.currentTimeMillis();
    j = l;
    String str = n0.t((Context)paramActivity);
    e.l(paramActivity);
    b.d(paramActivity);
    e.h(paramActivity);
    k.b();
    c c = new c(l, str, paramActivity.getApplicationContext());
    c.execute(c);
  }
  
  private static final void w(long paramLong, String paramString, Context paramContext) {
    String str;
    l.f(paramString, "$activityName");
    m m2 = g;
    if (m2 == null) {
      m2 = null;
    } else {
      Long long_ = m2.e();
    } 
    if (g == null) {
      g = new m(Long.valueOf(paramLong), null, null, 4, null);
      n n = n.a;
      str = i;
      l.e(paramContext, "appContext");
      n.c(paramString, null, str, paramContext);
    } else if (str != null) {
      long l = paramLong - str.longValue();
      if (l > (a.n() * 1000)) {
        n n = n.a;
        n.e(paramString, g, i);
        String str1 = i;
        l.e(paramContext, "appContext");
        n.c(paramString, null, str1, paramContext);
        g = new m(Long.valueOf(paramLong), null, null, 4, null);
      } else if (l > 1000L) {
        m m3 = g;
        if (m3 != null)
          m3.h(); 
      } 
    } 
    m m1 = g;
    if (m1 != null)
      m1.k(Long.valueOf(paramLong)); 
    m1 = g;
    if (m1 == null)
      return; 
    m1.m();
  }
  
  public static final void x(Application paramApplication, String paramString) {
    l.f(paramApplication, "application");
    if (!h.compareAndSet(false, true))
      return; 
    n n = n.a;
    n.a(n.b.f, new a());
    i = paramString;
    paramApplication.registerActivityLifecycleCallbacks(new a());
  }
  
  private static final void y(boolean paramBoolean) {
    if (paramBoolean) {
      e.f();
      return;
    } 
    e.e();
  }
  
  static {
    String str2 = f.class.getCanonicalName();
    String str1 = str2;
    if (str2 == null)
      str1 = "com.facebook.appevents.internal.ActivityLifecycleTracker"; 
    b = str1;
  }
  
  public static final class a implements Application.ActivityLifecycleCallbacks {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      l.f(param1Activity, "activity");
      c0.e.b(r0.e, f.g(), "onActivityCreated");
      g.a();
      f.p(param1Activity);
    }
    
    public void onActivityDestroyed(Activity param1Activity) {
      l.f(param1Activity, "activity");
      c0.e.b(r0.e, f.g(), "onActivityDestroyed");
      f.h(f.a, param1Activity);
    }
    
    public void onActivityPaused(Activity param1Activity) {
      l.f(param1Activity, "activity");
      c0.e.b(r0.e, f.g(), "onActivityPaused");
      g.a();
      f.i(f.a, param1Activity);
    }
    
    public void onActivityResumed(Activity param1Activity) {
      l.f(param1Activity, "activity");
      c0.e.b(r0.e, f.g(), "onActivityResumed");
      g.a();
      f.v(param1Activity);
    }
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {
      l.f(param1Activity, "activity");
      l.f(param1Bundle, "outState");
      c0.e.b(r0.e, f.g(), "onActivitySaveInstanceState");
    }
    
    public void onActivityStarted(Activity param1Activity) {
      l.f(param1Activity, "activity");
      f.j(f.f() + 1);
      c0.e.b(r0.e, f.g(), "onActivityStarted");
    }
    
    public void onActivityStopped(Activity param1Activity) {
      l.f(param1Activity, "activity");
      c0.e.b(r0.e, f.g(), "onActivityStopped");
      o.b.g();
      f.j(f.f() - 1);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */