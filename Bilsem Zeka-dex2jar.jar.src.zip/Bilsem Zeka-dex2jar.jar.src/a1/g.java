package a1;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.view.View;
import android.view.Window;
import h1.n0;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.y;
import r0.f0;

public final class g {
  public static final g a = new g();
  
  public static final void a() {}
  
  public static final void b() {}
  
  public static final String c(byte[] paramArrayOfbyte) {
    l.f(paramArrayOfbyte, "bytes");
    StringBuffer stringBuffer = new StringBuffer();
    int j = paramArrayOfbyte.length;
    int i = 0;
    while (i < j) {
      byte b = paramArrayOfbyte[i];
      i++;
      y y = y.a;
      String str1 = String.format("%02x", Arrays.copyOf(new Object[] { Byte.valueOf(b) }, 1));
      l.e(str1, "java.lang.String.format(format, *args)");
      stringBuffer.append(str1);
    } 
    String str = stringBuffer.toString();
    l.e(str, "sb.toString()");
    return str;
  }
  
  public static final String d() {
    Context context = f0.l();
    try {
      String str = (context.getPackageManager().getPackageInfo(context.getPackageName(), 0)).versionName;
      l.e(str, "{\n      val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)\n      packageInfo.versionName\n    }");
      return str;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return "";
    } 
  }
  
  public static final View e(Activity paramActivity) {
    if (paramActivity == null)
      return null; 
    try {
      Window window = paramActivity.getWindow();
      return (window == null) ? null : window.getDecorView().getRootView();
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static final boolean f() {
    // Byte code:
    //   0: getstatic android/os/Build.FINGERPRINT : Ljava/lang/String;
    //   3: astore_1
    //   4: aload_1
    //   5: ldc 'FINGERPRINT'
    //   7: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   10: iconst_0
    //   11: istore_0
    //   12: aload_1
    //   13: ldc 'generic'
    //   15: iconst_0
    //   16: iconst_2
    //   17: aconst_null
    //   18: invokestatic t : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
    //   21: ifne -> 177
    //   24: aload_1
    //   25: ldc 'FINGERPRINT'
    //   27: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   30: aload_1
    //   31: ldc 'unknown'
    //   33: iconst_0
    //   34: iconst_2
    //   35: aconst_null
    //   36: invokestatic t : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
    //   39: ifne -> 177
    //   42: getstatic android/os/Build.MODEL : Ljava/lang/String;
    //   45: astore_1
    //   46: aload_1
    //   47: ldc 'MODEL'
    //   49: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   52: aload_1
    //   53: ldc 'google_sdk'
    //   55: iconst_0
    //   56: iconst_2
    //   57: aconst_null
    //   58: invokestatic y : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   61: ifne -> 177
    //   64: aload_1
    //   65: ldc 'MODEL'
    //   67: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   70: aload_1
    //   71: ldc 'Emulator'
    //   73: iconst_0
    //   74: iconst_2
    //   75: aconst_null
    //   76: invokestatic y : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   79: ifne -> 177
    //   82: aload_1
    //   83: ldc 'MODEL'
    //   85: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   88: aload_1
    //   89: ldc 'Android SDK built for x86'
    //   91: iconst_0
    //   92: iconst_2
    //   93: aconst_null
    //   94: invokestatic y : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   97: ifne -> 177
    //   100: getstatic android/os/Build.MANUFACTURER : Ljava/lang/String;
    //   103: astore_1
    //   104: aload_1
    //   105: ldc 'MANUFACTURER'
    //   107: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   110: aload_1
    //   111: ldc 'Genymotion'
    //   113: iconst_0
    //   114: iconst_2
    //   115: aconst_null
    //   116: invokestatic y : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z
    //   119: ifne -> 177
    //   122: getstatic android/os/Build.BRAND : Ljava/lang/String;
    //   125: astore_1
    //   126: aload_1
    //   127: ldc 'BRAND'
    //   129: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   132: aload_1
    //   133: ldc 'generic'
    //   135: iconst_0
    //   136: iconst_2
    //   137: aconst_null
    //   138: invokestatic t : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
    //   141: ifeq -> 166
    //   144: getstatic android/os/Build.DEVICE : Ljava/lang/String;
    //   147: astore_1
    //   148: aload_1
    //   149: ldc 'DEVICE'
    //   151: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   154: aload_1
    //   155: ldc 'generic'
    //   157: iconst_0
    //   158: iconst_2
    //   159: aconst_null
    //   160: invokestatic t : (Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
    //   163: ifne -> 177
    //   166: ldc 'google_sdk'
    //   168: getstatic android/os/Build.PRODUCT : Ljava/lang/String;
    //   171: invokestatic b : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   174: ifeq -> 179
    //   177: iconst_1
    //   178: istore_0
    //   179: iload_0
    //   180: ireturn
  }
  
  public static final double g(String paramString) {
    double d = 0.0D;
    try {
      Matcher matcher = Pattern.compile("[-+]*\\d+([.,]\\d+)*([.,]\\d+)?", 8).matcher(paramString);
      if (matcher.find()) {
        String str = matcher.group(0);
        d = NumberFormat.getNumberInstance(n0.A()).parse(str).doubleValue();
      } 
      return d;
    } catch (ParseException parseException) {
      return 0.0D;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */