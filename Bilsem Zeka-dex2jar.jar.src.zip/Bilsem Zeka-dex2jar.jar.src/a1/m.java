package a1;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.util.UUID;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import r0.f0;

public final class m {
  public static final a g = new a(null);
  
  private final Long a;
  
  private Long b;
  
  private UUID c;
  
  private int d;
  
  private Long e;
  
  private o f;
  
  public m(Long paramLong1, Long paramLong2, UUID paramUUID) {
    this.a = paramLong1;
    this.b = paramLong2;
    this.c = paramUUID;
  }
  
  public final Long b() {
    Long long_2 = this.e;
    Long long_1 = long_2;
    if (long_2 == null)
      long_1 = Long.valueOf(0L); 
    return long_1;
  }
  
  public final int c() {
    return this.d;
  }
  
  public final UUID d() {
    return this.c;
  }
  
  public final Long e() {
    return this.b;
  }
  
  public final long f() {
    if (this.a != null) {
      Long long_ = this.b;
      if (long_ != null) {
        if (long_ != null)
          return long_.longValue() - this.a.longValue(); 
        throw new IllegalStateException("Required value was null.".toString());
      } 
    } 
    return 0L;
  }
  
  public final o g() {
    return this.f;
  }
  
  public final void h() {
    this.d++;
  }
  
  public final void i(Long paramLong) {
    this.e = paramLong;
  }
  
  public final void j(UUID paramUUID) {
    l.f(paramUUID, "<set-?>");
    this.c = paramUUID;
  }
  
  public final void k(Long paramLong) {
    this.b = paramLong;
  }
  
  public final void l(o paramo) {
    this.f = paramo;
  }
  
  public final void m() {
    long l1;
    SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(f0.l()).edit();
    Long long_ = this.a;
    long l2 = 0L;
    if (long_ == null) {
      l1 = 0L;
    } else {
      l1 = long_.longValue();
    } 
    editor.putLong("com.facebook.appevents.SessionInfo.sessionStartTime", l1);
    long_ = this.b;
    if (long_ == null) {
      l1 = l2;
    } else {
      l1 = long_.longValue();
    } 
    editor.putLong("com.facebook.appevents.SessionInfo.sessionEndTime", l1);
    editor.putInt("com.facebook.appevents.SessionInfo.interruptionCount", this.d);
    editor.putString("com.facebook.appevents.SessionInfo.sessionId", this.c.toString());
    editor.apply();
    o o1 = this.f;
    if (o1 != null) {
      if (o1 == null)
        return; 
      o1.a();
    } 
  }
  
  public static final class a {
    private a() {}
    
    public final void a() {
      SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(f0.l()).edit();
      editor.remove("com.facebook.appevents.SessionInfo.sessionStartTime");
      editor.remove("com.facebook.appevents.SessionInfo.sessionEndTime");
      editor.remove("com.facebook.appevents.SessionInfo.interruptionCount");
      editor.remove("com.facebook.appevents.SessionInfo.sessionId");
      editor.apply();
      o.c.a();
    }
    
    public final m b() {
      SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(f0.l());
      long l1 = sharedPreferences.getLong("com.facebook.appevents.SessionInfo.sessionStartTime", 0L);
      long l2 = sharedPreferences.getLong("com.facebook.appevents.SessionInfo.sessionEndTime", 0L);
      String str = sharedPreferences.getString("com.facebook.appevents.SessionInfo.sessionId", null);
      if (l1 != 0L && l2 != 0L) {
        if (str == null)
          return null; 
        m m = new m(Long.valueOf(l1), Long.valueOf(l2), null, 4, null);
        m.a(m, sharedPreferences.getInt("com.facebook.appevents.SessionInfo.interruptionCount", 0));
        m.l(o.c.b());
        m.i(Long.valueOf(System.currentTimeMillis()));
        UUID uUID = UUID.fromString(str);
        l.e(uUID, "fromString(sessionIDStr)");
        m.j(uUID);
        return m;
      } 
      return null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */