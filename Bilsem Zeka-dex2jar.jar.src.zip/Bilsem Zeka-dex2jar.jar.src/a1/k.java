package a1;

import android.os.AsyncTask;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import kotlin.jvm.internal.l;

public final class k extends AsyncTask<String, Void, Boolean> {
  private final String a;
  
  private final File b;
  
  private final a c;
  
  public k(String paramString, File paramFile, a parama) {
    this.a = paramString;
    this.b = paramFile;
    this.c = parama;
  }
  
  public Boolean a(String... paramVarArgs) {
    l.f(paramVarArgs, "args");
    try {
      URL uRL = new URL(this.a);
      int i = uRL.openConnection().getContentLength();
      DataInputStream dataInputStream = new DataInputStream(uRL.openStream());
      byte[] arrayOfByte = new byte[i];
      dataInputStream.readFully(arrayOfByte);
      dataInputStream.close();
      DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(this.b));
      dataOutputStream.write(arrayOfByte);
      dataOutputStream.flush();
      dataOutputStream.close();
      return Boolean.TRUE;
    } catch (Exception exception) {
      return Boolean.FALSE;
    } 
  }
  
  protected void b(boolean paramBoolean) {
    if (paramBoolean)
      this.c.a(this.b); 
  }
  
  public static interface a {
    void a(File param1File);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */