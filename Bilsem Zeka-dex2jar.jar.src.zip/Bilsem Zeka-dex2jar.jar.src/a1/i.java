package a1;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import h1.q;
import h1.r;
import h1.v;
import java.math.BigDecimal;
import java.util.Currency;
import java.util.HashMap;
import java.util.Map;
import kotlin.jvm.internal.l;
import org.json.JSONException;
import org.json.JSONObject;
import r0.f0;
import s0.e0;
import s0.o;

public final class i {
  public static final i a = new i();
  
  private static final String b = i.class.getCanonicalName();
  
  private static final e0 c = new e0(f0.l());
  
  private final a a(String paramString1, String paramString2) {
    return b(paramString1, paramString2, new HashMap<String, String>());
  }
  
  private final a b(String paramString1, String paramString2, Map<String, String> paramMap) {
    try {
      JSONObject jSONObject2 = new JSONObject(paramString1);
      JSONObject jSONObject1 = new JSONObject(paramString2);
      boolean bool = true;
      Bundle bundle = new Bundle(1);
      bundle.putCharSequence("fb_iap_product_id", jSONObject2.getString("productId"));
      bundle.putCharSequence("fb_iap_purchase_time", jSONObject2.getString("purchaseTime"));
      bundle.putCharSequence("fb_iap_purchase_token", jSONObject2.getString("purchaseToken"));
      bundle.putCharSequence("fb_iap_package_name", jSONObject2.optString("packageName"));
      bundle.putCharSequence("fb_iap_product_title", jSONObject1.optString("title"));
      bundle.putCharSequence("fb_iap_product_description", jSONObject1.optString("description"));
      String str = jSONObject1.optString("type");
      bundle.putCharSequence("fb_iap_product_type", str);
      if (l.b(str, "subs")) {
        bundle.putCharSequence("fb_iap_subs_auto_renewing", Boolean.toString(jSONObject2.optBoolean("autoRenewing", false)));
        bundle.putCharSequence("fb_iap_subs_period", jSONObject1.optString("subscriptionPeriod"));
        bundle.putCharSequence("fb_free_trial_period", jSONObject1.optString("freeTrialPeriod"));
        String str1 = jSONObject1.optString("introductoryPriceCycles");
        l.e(str1, "introductoryPriceCycles");
        if (str1.length() != 0)
          bool = false; 
        if (!bool) {
          bundle.putCharSequence("fb_intro_price_amount_micros", jSONObject1.optString("introductoryPriceAmountMicros"));
          bundle.putCharSequence("fb_intro_price_cycles", str1);
        } 
      } 
      for (Map.Entry<String, String> entry : paramMap.entrySet())
        bundle.putCharSequence((String)entry.getKey(), (String)entry.getValue()); 
      BigDecimal bigDecimal = new BigDecimal(jSONObject1.getLong("price_amount_micros") / 1000000.0D);
      Currency currency = Currency.getInstance(jSONObject1.getString("price_currency_code"));
      l.e(currency, "getInstance(skuDetailsJSON.getString(\"price_currency_code\"))");
      return new a(bigDecimal, currency, bundle);
    } catch (JSONException jSONException) {
      Log.e(b, "Error parsing in-app subscription data.", (Throwable)jSONException);
      return null;
    } 
  }
  
  public static final boolean c() {
    r r = v.f(f0.m());
    return (r != null && f0.p() && r.e());
  }
  
  public static final void d() {
    Context context = f0.l();
    String str = f0.m();
    if (f0.p()) {
      if (context instanceof Application) {
        o.b.a((Application)context, str);
        return;
      } 
      Log.w(b, "Automatic logging of basic events will not happen, because FacebookSdk.getApplicationContext() returns object that is not instance of android.app.Application. Make sure you call FacebookSdk.sdkInitialize() from Application class and pass application context.");
    } 
  }
  
  public static final void e(String paramString, long paramLong) {
    Context context = f0.l();
    r r = v.o(f0.m(), false);
    if (r != null && r.a() && paramLong > 0L) {
      e0 e01 = new e0(context);
      Bundle bundle = new Bundle(1);
      bundle.putCharSequence("fb_aa_time_spent_view_name", paramString);
      e01.c("fb_aa_time_spent_on_view", paramLong, bundle);
    } 
  }
  
  public static final void f(String paramString1, String paramString2, boolean paramBoolean) {
    l.f(paramString1, "purchase");
    l.f(paramString2, "skuDetails");
    if (!c())
      return; 
    a a = a.a(paramString1, paramString2);
    if (a == null)
      return; 
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramBoolean) {
      q q = q.a;
      bool1 = bool2;
      if (q.d("app_events_if_auto_log_subs", f0.m(), false))
        bool1 = true; 
    } 
    if (bool1) {
      if (y0.i.a.m(paramString2)) {
        paramString1 = "StartTrial";
      } else {
        paramString1 = "Subscribe";
      } 
      c.i(paramString1, a.c(), a.a(), a.b());
      return;
    } 
    c.j(a.c(), a.a(), a.b());
  }
  
  private static final class a {
    private BigDecimal a;
    
    private Currency b;
    
    private Bundle c;
    
    public a(BigDecimal param1BigDecimal, Currency param1Currency, Bundle param1Bundle) {
      this.a = param1BigDecimal;
      this.b = param1Currency;
      this.c = param1Bundle;
    }
    
    public final Currency a() {
      return this.b;
    }
    
    public final Bundle b() {
      return this.c;
    }
    
    public final BigDecimal c() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */