package a1;

import android.content.Context;
import ga.n;
import ga.r;
import h1.c0;
import h1.n0;
import ha.b0;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import kotlin.jvm.internal.l;
import org.json.JSONObject;
import r0.r0;
import s0.o;

public final class h {
  public static final h a = new h();
  
  private static final Map<a, String> b = b0.e(new n[] { r.a(a.a, "MOBILE_APP_INSTALL"), r.a(a.b, "CUSTOM_APP_EVENTS") });
  
  public static final JSONObject a(a parama, h1.a parama1, String paramString, boolean paramBoolean, Context paramContext) {
    l.f(parama, "activityType");
    l.f(paramContext, "context");
    JSONObject jSONObject2 = new JSONObject();
    jSONObject2.put("event", b.get(parama));
    String str = o.b.d();
    if (str != null)
      jSONObject2.put("app_user_id", str); 
    n0.C0(jSONObject2, parama1, paramString, paramBoolean, paramContext);
    try {
      n0.D0(jSONObject2, paramContext);
    } catch (Exception exception) {
      c0.e.c(r0.e, "AppEvents", "Fetching extended device info parameters failed: '%s'", new Object[] { exception.toString() });
    } 
    JSONObject jSONObject1 = n0.C();
    if (jSONObject1 != null) {
      Iterator<String> iterator = jSONObject1.keys();
      while (iterator.hasNext()) {
        paramString = iterator.next();
        jSONObject2.put(paramString, jSONObject1.get(paramString));
      } 
    } 
    jSONObject2.put("application_package_name", paramContext.getPackageName());
    return jSONObject2;
  }
  
  public enum a {
    a, b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */