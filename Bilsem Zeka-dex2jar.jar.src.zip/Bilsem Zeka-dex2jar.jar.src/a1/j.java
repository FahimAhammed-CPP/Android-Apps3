package a1;

public final class j {
  public static final j a = new j();
  
  public static final int a() {
    return 60;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a1\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */