package a3;

import android.os.Parcel;
import android.os.Parcelable;
import f4.t0;
import i2.h2;
import i2.u1;
import java.util.Arrays;
import java.util.List;

public final class a implements Parcelable {
  public static final Parcelable.Creator<a> CREATOR = new a();
  
  private final b[] a;
  
  a(Parcel paramParcel) {
    this.a = new b[paramParcel.readInt()];
    int i = 0;
    while (true) {
      b[] arrayOfB = this.a;
      if (i < arrayOfB.length) {
        arrayOfB[i] = (b)paramParcel.readParcelable(b.class.getClassLoader());
        i++;
        continue;
      } 
      break;
    } 
  }
  
  public a(List<? extends b> paramList) {
    this.a = paramList.<b>toArray(new b[0]);
  }
  
  public a(b... paramVarArgs) {
    this.a = paramVarArgs;
  }
  
  public a a(b... paramVarArgs) {
    return (paramVarArgs.length == 0) ? this : new a((b[])t0.E0((Object[])this.a, (Object[])paramVarArgs));
  }
  
  public a b(a parama) {
    return (parama == null) ? this : a(parama.a);
  }
  
  public b c(int paramInt) {
    return this.a[paramInt];
  }
  
  public int d() {
    return this.a.length;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || a.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return Arrays.equals((Object[])this.a, (Object[])((a)paramObject).a);
  }
  
  public int hashCode() {
    return Arrays.hashCode((Object[])this.a);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("entries=");
    stringBuilder.append(Arrays.toString((Object[])this.a));
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.a.length);
    b[] arrayOfB = this.a;
    int i = arrayOfB.length;
    for (paramInt = 0; paramInt < i; paramInt++)
      paramParcel.writeParcelable(arrayOfB[paramInt], 0); 
  }
  
  class a implements Parcelable.Creator<a> {
    public a a(Parcel param1Parcel) {
      return new a(param1Parcel);
    }
    
    public a[] b(int param1Int) {
      return new a[param1Int];
    }
  }
  
  public static interface b extends Parcelable {
    u1 l();
    
    void u(h2.b param1b);
    
    byte[] w();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a3\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */