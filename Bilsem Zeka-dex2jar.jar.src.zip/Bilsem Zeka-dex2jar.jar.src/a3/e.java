package a3;

import l2.i;

public final class e extends i {
  public long i;
  
  public e() {
    super(1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a3\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */