package a3;

import f4.a;
import java.nio.ByteBuffer;

public abstract class h implements c {
  public final a a(e parame) {
    boolean bool;
    ByteBuffer byteBuffer = (ByteBuffer)a.e(parame.c);
    if (byteBuffer.position() == 0 && byteBuffer.hasArray() && byteBuffer.arrayOffset() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    a.a(bool);
    return parame.t() ? null : b(parame, byteBuffer);
  }
  
  protected abstract a b(e parame, ByteBuffer paramByteBuffer);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a3\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */