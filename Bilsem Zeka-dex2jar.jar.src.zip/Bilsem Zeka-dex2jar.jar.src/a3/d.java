package a3;

import b3.b;
import c3.b;
import f3.h;
import h3.c;
import i2.u1;

public interface d {
  public static final d a = new a();
  
  boolean a(u1 paramu1);
  
  c b(u1 paramu1);
  
  class a implements d {
    public boolean a(u1 param1u1) {
      String str = param1u1.l;
      return ("application/id3".equals(str) || "application/x-emsg".equals(str) || "application/x-scte35".equals(str) || "application/x-icy".equals(str) || "application/vnd.dvb.ait".equals(str));
    }
    
    public c b(u1 param1u1) {
      String str = param1u1.l;
      if (str != null) {
        StringBuilder stringBuilder;
        int i = str.hashCode();
        byte b = -1;
        switch (i) {
          case 1652648887:
            if (!str.equals("application/x-scte35"))
              break; 
            b = 4;
            break;
          case 1154383568:
            if (!str.equals("application/x-emsg"))
              break; 
            b = 3;
            break;
          case -1248341703:
            if (!str.equals("application/id3"))
              break; 
            b = 2;
            break;
          case -1348231605:
            if (!str.equals("application/x-icy"))
              break; 
            b = 1;
            break;
          case -1354451219:
            if (!str.equals("application/vnd.dvb.ait"))
              break; 
            b = 0;
            break;
        } 
        switch (b) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("Attempted to create decoder for unsupported MIME type: ");
            stringBuilder.append(str);
            throw new IllegalArgumentException(stringBuilder.toString());
          case 4:
            return (c)new c();
          case 3:
            return (c)new b();
          case 2:
            return (c)new h();
          case 1:
            return (c)new e3.a();
          case 0:
            break;
        } 
        return (c)new b();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a3\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */