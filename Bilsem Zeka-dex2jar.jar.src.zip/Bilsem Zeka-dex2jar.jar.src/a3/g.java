package a3;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import f4.a;
import f4.t0;
import i2.h3;
import i2.l;
import i2.u1;
import i2.v1;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public final class g extends l implements Handler.Callback {
  private final d n;
  
  private final f o;
  
  private final Handler p;
  
  private final e q;
  
  private c r;
  
  private boolean s;
  
  private boolean t;
  
  private long u;
  
  private long v;
  
  private a w;
  
  public g(f paramf, Looper paramLooper) {
    this(paramf, paramLooper, d.a);
  }
  
  public g(f paramf, Looper paramLooper, d paramd) {
    super(5);
    Handler handler;
    this.o = (f)a.e(paramf);
    if (paramLooper == null) {
      paramf = null;
    } else {
      handler = t0.v(paramLooper, this);
    } 
    this.p = handler;
    this.n = (d)a.e(paramd);
    this.q = new e();
    this.v = -9223372036854775807L;
  }
  
  private void Q(a parama, List<a.b> paramList) {
    for (int i = 0; i < parama.d(); i++) {
      u1 u1 = parama.c(i).l();
      if (u1 != null && this.n.a(u1)) {
        c c1 = this.n.b(u1);
        byte[] arrayOfByte = (byte[])a.e(parama.c(i).w());
        this.q.p();
        this.q.z(arrayOfByte.length);
        ((ByteBuffer)t0.j(this.q.c)).put(arrayOfByte);
        this.q.A();
        a a1 = c1.a(this.q);
        if (a1 != null)
          Q(a1, paramList); 
      } else {
        paramList.add(parama.c(i));
      } 
    } 
  }
  
  private void R(a parama) {
    Handler handler = this.p;
    if (handler != null) {
      handler.obtainMessage(0, parama).sendToTarget();
      return;
    } 
    S(parama);
  }
  
  private void S(a parama) {
    this.o.w(parama);
  }
  
  private boolean T(long paramLong) {
    boolean bool;
    a a1 = this.w;
    if (a1 != null && this.v <= paramLong) {
      R(a1);
      this.w = null;
      this.v = -9223372036854775807L;
      bool = true;
    } else {
      bool = false;
    } 
    if (this.s && this.w == null)
      this.t = true; 
    return bool;
  }
  
  private void U() {
    if (!this.s && this.w == null) {
      a a1;
      this.q.p();
      v1 v1 = B();
      int i = N(v1, this.q, 0);
      if (i == -4) {
        if (this.q.u()) {
          this.s = true;
          return;
        } 
        e e1 = this.q;
        e1.i = this.u;
        e1.A();
        a1 = ((c)t0.j(this.r)).a(this.q);
        if (a1 != null) {
          ArrayList<a.b> arrayList = new ArrayList(a1.d());
          Q(a1, arrayList);
          if (!arrayList.isEmpty()) {
            this.w = new a(arrayList);
            this.v = this.q.e;
            return;
          } 
        } 
      } else if (i == -5) {
        this.u = ((u1)a.e(((v1)a1).b)).p;
      } 
    } 
  }
  
  protected void G() {
    this.w = null;
    this.v = -9223372036854775807L;
    this.r = null;
  }
  
  protected void I(long paramLong, boolean paramBoolean) {
    this.w = null;
    this.v = -9223372036854775807L;
    this.s = false;
    this.t = false;
  }
  
  protected void M(u1[] paramArrayOfu1, long paramLong1, long paramLong2) {
    this.r = this.n.b(paramArrayOfu1[0]);
  }
  
  public int a(u1 paramu1) {
    if (this.n.a(paramu1)) {
      byte b;
      if (paramu1.E == 0) {
        b = 4;
      } else {
        b = 2;
      } 
      return h3.a(b);
    } 
    return h3.a(0);
  }
  
  public boolean c() {
    return this.t;
  }
  
  public boolean d() {
    return true;
  }
  
  public String getName() {
    return "MetadataRenderer";
  }
  
  public boolean handleMessage(Message paramMessage) {
    if (paramMessage.what == 0) {
      S((a)paramMessage.obj);
      return true;
    } 
    throw new IllegalStateException();
  }
  
  public void r(long paramLong1, long paramLong2) {
    boolean bool;
    for (bool = true; bool; bool = T(paramLong1))
      U(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a3\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */