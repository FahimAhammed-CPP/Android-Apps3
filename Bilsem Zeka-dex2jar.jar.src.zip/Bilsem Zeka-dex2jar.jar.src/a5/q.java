package a5;

public final class q {
  public static int a(int paramInt) {
    return (paramInt == -1) ? -1 : (paramInt / 1000);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */