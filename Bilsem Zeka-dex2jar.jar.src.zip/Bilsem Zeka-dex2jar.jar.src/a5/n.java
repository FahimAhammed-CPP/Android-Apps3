package a5;

import java.util.regex.Pattern;

public class n {
  private static final Pattern a = Pattern.compile("\\$\\{(.*?)\\}");
  
  public static boolean a(String paramString) {
    return (paramString == null || paramString.trim().isEmpty());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */