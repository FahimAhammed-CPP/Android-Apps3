package a5;

import android.content.Context;
import android.util.Log;
import com.google.errorprone.annotations.ResultIgnorabilityUnspecified;
import v4.p;

public final class f {
  private static final String[] a = new String[] { "android.", "com.android.", "dalvik.", "java.", "javax." };
  
  @ResultIgnorabilityUnspecified
  public static boolean a(Context paramContext, Throwable paramThrowable) {
    try {
      p.j(paramContext);
      p.j(paramThrowable);
    } catch (Exception exception) {
      Log.e("CrashUtils", "Error adding exception to DropBox!", exception);
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */