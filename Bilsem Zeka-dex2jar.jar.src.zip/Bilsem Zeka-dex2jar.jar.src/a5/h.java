package a5;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import com.google.android.apps.common.proguard.SideEffectFree;
import s4.n;

public final class h {
  private static Boolean a;
  
  private static Boolean b;
  
  private static Boolean c;
  
  private static Boolean d;
  
  public static boolean a(Context paramContext) {
    PackageManager packageManager = paramContext.getPackageManager();
    if (d == null) {
      boolean bool = k.h();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        bool1 = bool2;
        if (packageManager.hasSystemFeature("android.hardware.type.automotive"))
          bool1 = true; 
      } 
      d = Boolean.valueOf(bool1);
    } 
    return d.booleanValue();
  }
  
  public static boolean b() {
    int i = n.a;
    return "user".equals(Build.TYPE);
  }
  
  @TargetApi(20)
  @SideEffectFree
  public static boolean c(Context paramContext) {
    return g(paramContext.getPackageManager());
  }
  
  @TargetApi(26)
  public static boolean d(Context paramContext) {
    return ((c(paramContext) && !k.g()) || (e(paramContext) && (!k.h() || k.k())));
  }
  
  @TargetApi(21)
  public static boolean e(Context paramContext) {
    if (b == null) {
      boolean bool = k.f();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        bool1 = bool2;
        if (paramContext.getPackageManager().hasSystemFeature("cn.google"))
          bool1 = true; 
      } 
      b = Boolean.valueOf(bool1);
    } 
    return b.booleanValue();
  }
  
  public static boolean f(Context paramContext) {
    if (c == null) {
      boolean bool = paramContext.getPackageManager().hasSystemFeature("android.hardware.type.iot");
      boolean bool2 = true;
      boolean bool1 = bool2;
      if (!bool)
        if (paramContext.getPackageManager().hasSystemFeature("android.hardware.type.embedded")) {
          bool1 = bool2;
        } else {
          bool1 = false;
        }  
      c = Boolean.valueOf(bool1);
    } 
    return c.booleanValue();
  }
  
  @TargetApi(20)
  @SideEffectFree
  public static boolean g(PackageManager paramPackageManager) {
    if (a == null) {
      boolean bool = k.e();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        bool1 = bool2;
        if (paramPackageManager.hasSystemFeature("android.hardware.type.watch"))
          bool1 = true; 
      } 
      a = Boolean.valueOf(bool1);
    } 
    return a.booleanValue();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */