package a5;

public class i {
  private static final char[] a = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'A', 'B', 'C', 'D', 'E', 'F' };
  
  private static final char[] b = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'a', 'b', 'c', 'd', 'e', 'f' };
  
  public static String a(byte[] paramArrayOfbyte) {
    int j = paramArrayOfbyte.length;
    char[] arrayOfChar = new char[j + j];
    j = 0;
    int k = 0;
    while (j < paramArrayOfbyte.length) {
      int m = paramArrayOfbyte[j] & 0xFF;
      int n = k + 1;
      char[] arrayOfChar1 = b;
      arrayOfChar[k] = arrayOfChar1[m >>> 4];
      arrayOfChar[n] = arrayOfChar1[m & 0xF];
      k = n + 1;
      j++;
    } 
    return new String(arrayOfChar);
  }
  
  public static String b(byte[] paramArrayOfbyte, boolean paramBoolean) {
    int k = paramArrayOfbyte.length;
    StringBuilder stringBuilder = new StringBuilder(k + k);
    for (int j = 0; j < k && (!paramBoolean || j != k - 1 || (paramArrayOfbyte[j] & 0xFF) != 0); j++) {
      char[] arrayOfChar = a;
      stringBuilder.append(arrayOfChar[(paramArrayOfbyte[j] & 0xF0) >>> 4]);
      stringBuilder.append(arrayOfChar[paramArrayOfbyte[j] & 0xF]);
    } 
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */