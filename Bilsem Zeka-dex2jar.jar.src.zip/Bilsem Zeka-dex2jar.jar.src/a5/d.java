package a5;

public interface d {
  long a();
  
  long b();
  
  long c();
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */