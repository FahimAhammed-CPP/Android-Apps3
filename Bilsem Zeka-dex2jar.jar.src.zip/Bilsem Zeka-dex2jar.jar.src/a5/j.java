package a5;

import java.io.Closeable;
import java.io.IOException;

@Deprecated
public final class j {
  public static void a(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
        return;
      } catch (IOException iOException) {
        return;
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */