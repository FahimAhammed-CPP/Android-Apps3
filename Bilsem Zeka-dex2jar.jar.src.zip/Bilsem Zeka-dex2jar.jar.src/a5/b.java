package a5;

import v4.n;

public final class b {
  public static boolean a(int[] paramArrayOfint, int paramInt) {
    if (paramArrayOfint != null)
      for (int i = 0; i < paramArrayOfint.length; i++) {
        if (paramArrayOfint[i] == paramInt)
          return true; 
      }  
    return false;
  }
  
  public static <T> boolean b(T[] paramArrayOfT, T paramT) {
    byte b1;
    if (paramArrayOfT != null) {
      b1 = paramArrayOfT.length;
    } else {
      b1 = 0;
    } 
    for (int i = 0; i < b1; i++) {
      if (n.b(paramArrayOfT[i], paramT)) {
        if (i >= 0)
          return true; 
        break;
      } 
    } 
    return false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */