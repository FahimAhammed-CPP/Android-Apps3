package a5;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class e {
  @Deprecated
  public static <T> List<T> a(T paramT) {
    return Collections.singletonList(paramT);
  }
  
  @Deprecated
  public static <T> List<T> b(T... paramVarArgs) {
    int i = paramVarArgs.length;
    return (i != 0) ? ((i != 1) ? Collections.unmodifiableList(Arrays.asList(paramVarArgs)) : Collections.singletonList(paramVarArgs[0])) : Collections.emptyList();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */