package a5;

import android.os.Build;
import android.os.Process;
import android.os.StrictMode;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileReader;
import java.io.IOException;

public class m {
  private static String a;
  
  private static int b;
  
  public static String a() {
    if (a == null)
      if (Build.VERSION.SDK_INT >= 28) {
        a = l.a();
      } else {
        int j = b;
        int i = j;
        if (j == 0) {
          i = Process.myPid();
          b = i;
        } 
        StringBuilder stringBuilder1 = null;
        StringBuilder stringBuilder2 = null;
        String str = null;
        if (i <= 0) {
          stringBuilder1 = stringBuilder2;
        } else {
          IOException iOException1;
          try {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("/proc/");
            stringBuilder2.append(i);
            stringBuilder2.append("/cmdline");
            null = stringBuilder2.toString();
            StrictMode.ThreadPolicy threadPolicy = StrictMode.allowThreadDiskReads();
            try {
              BufferedReader bufferedReader = new BufferedReader(new FileReader(null));
              StrictMode.setThreadPolicy(threadPolicy);
            } finally {
              StrictMode.setThreadPolicy(threadPolicy);
            } 
            j.a((Closeable)stringBuilder2);
            throw stringBuilder1;
          } catch (IOException null) {
          
          } finally {
            iOException1 = iOException2;
            j.a((Closeable)iOException1);
          } 
          j.a((Closeable)iOException1);
        } 
        a = (String)stringBuilder1;
      }  
    return a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */