package a5;

import android.os.Build;

public final class k {
  public static boolean a() {
    return true;
  }
  
  public static boolean b() {
    return true;
  }
  
  public static boolean c() {
    return true;
  }
  
  public static boolean d() {
    return true;
  }
  
  public static boolean e() {
    return true;
  }
  
  public static boolean f() {
    return true;
  }
  
  public static boolean g() {
    return (Build.VERSION.SDK_INT >= 24);
  }
  
  public static boolean h() {
    return (Build.VERSION.SDK_INT >= 26);
  }
  
  public static boolean i() {
    return (Build.VERSION.SDK_INT >= 28);
  }
  
  public static boolean j() {
    return (Build.VERSION.SDK_INT >= 29);
  }
  
  public static boolean k() {
    return (Build.VERSION.SDK_INT >= 30);
  }
  
  public static boolean l() {
    return (Build.VERSION.SDK_INT >= 31);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */