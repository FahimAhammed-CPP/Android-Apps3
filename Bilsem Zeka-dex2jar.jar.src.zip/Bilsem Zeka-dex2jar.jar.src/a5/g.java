package a5;

import android.os.SystemClock;

public class g implements d {
  private static final g a = new g();
  
  public static d d() {
    return a;
  }
  
  public final long a() {
    return System.currentTimeMillis();
  }
  
  public final long b() {
    return SystemClock.elapsedRealtime();
  }
  
  public final long c() {
    return System.nanoTime();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */