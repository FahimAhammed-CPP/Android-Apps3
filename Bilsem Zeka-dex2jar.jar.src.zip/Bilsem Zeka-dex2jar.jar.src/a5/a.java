package a5;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import c5.e;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class a {
  static {
  
  }
  
  @Deprecated
  public static byte[] a(Context paramContext, String paramString) {
    PackageInfo packageInfo = e.a(paramContext).e(paramString, 64);
    Signature[] arrayOfSignature = packageInfo.signatures;
    if (arrayOfSignature != null && arrayOfSignature.length == 1) {
      MessageDigest messageDigest = b("SHA1");
      if (messageDigest != null)
        return messageDigest.digest(packageInfo.signatures[0].toByteArray()); 
    } 
    return null;
  }
  
  public static MessageDigest b(String paramString) {
    int i = 0;
    while (true) {
      if (i < 2) {
        try {
          MessageDigest messageDigest = MessageDigest.getInstance(paramString);
          if (messageDigest != null)
            return messageDigest; 
        } catch (NoSuchAlgorithmException noSuchAlgorithmException) {}
        i++;
        continue;
      } 
      return null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */