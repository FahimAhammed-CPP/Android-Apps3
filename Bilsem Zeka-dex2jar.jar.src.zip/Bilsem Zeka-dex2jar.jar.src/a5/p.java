package a5;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.WorkSource;
import android.util.Log;
import c5.e;
import java.lang.reflect.Method;

public class p {
  private static final int a;
  
  private static final Method b;
  
  private static final Method c;
  
  private static final Method d;
  
  private static final Method e;
  
  private static final Method f;
  
  private static final Method g;
  
  private static final Method h;
  
  private static final Method i;
  
  private static Boolean j;
  
  static {
    // Byte code:
    //   0: invokestatic myUid : ()I
    //   3: putstatic a5/p.a : I
    //   6: ldc android/os/WorkSource
    //   8: ldc 'add'
    //   10: iconst_1
    //   11: anewarray java/lang/Class
    //   14: dup
    //   15: iconst_0
    //   16: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   19: aastore
    //   20: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   23: astore_0
    //   24: goto -> 29
    //   27: aconst_null
    //   28: astore_0
    //   29: aload_0
    //   30: putstatic a5/p.b : Ljava/lang/reflect/Method;
    //   33: invokestatic c : ()Z
    //   36: ifeq -> 65
    //   39: ldc android/os/WorkSource
    //   41: ldc 'add'
    //   43: iconst_2
    //   44: anewarray java/lang/Class
    //   47: dup
    //   48: iconst_0
    //   49: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   52: aastore
    //   53: dup
    //   54: iconst_1
    //   55: ldc java/lang/String
    //   57: aastore
    //   58: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   61: astore_0
    //   62: goto -> 67
    //   65: aconst_null
    //   66: astore_0
    //   67: aload_0
    //   68: putstatic a5/p.c : Ljava/lang/reflect/Method;
    //   71: ldc android/os/WorkSource
    //   73: ldc 'size'
    //   75: iconst_0
    //   76: anewarray java/lang/Class
    //   79: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   82: astore_0
    //   83: goto -> 88
    //   86: aconst_null
    //   87: astore_0
    //   88: aload_0
    //   89: putstatic a5/p.d : Ljava/lang/reflect/Method;
    //   92: ldc android/os/WorkSource
    //   94: ldc 'get'
    //   96: iconst_1
    //   97: anewarray java/lang/Class
    //   100: dup
    //   101: iconst_0
    //   102: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   105: aastore
    //   106: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   109: astore_0
    //   110: goto -> 115
    //   113: aconst_null
    //   114: astore_0
    //   115: aload_0
    //   116: putstatic a5/p.e : Ljava/lang/reflect/Method;
    //   119: invokestatic c : ()Z
    //   122: ifeq -> 146
    //   125: ldc android/os/WorkSource
    //   127: ldc 'getName'
    //   129: iconst_1
    //   130: anewarray java/lang/Class
    //   133: dup
    //   134: iconst_0
    //   135: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   138: aastore
    //   139: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   142: astore_0
    //   143: goto -> 148
    //   146: aconst_null
    //   147: astore_0
    //   148: aload_0
    //   149: putstatic a5/p.f : Ljava/lang/reflect/Method;
    //   152: invokestatic i : ()Z
    //   155: ifeq -> 183
    //   158: ldc android/os/WorkSource
    //   160: ldc 'createWorkChain'
    //   162: iconst_0
    //   163: anewarray java/lang/Class
    //   166: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   169: astore_0
    //   170: goto -> 185
    //   173: astore_0
    //   174: ldc 'WorkSourceUtil'
    //   176: ldc 'Missing WorkChain API createWorkChain'
    //   178: aload_0
    //   179: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   182: pop
    //   183: aconst_null
    //   184: astore_0
    //   185: aload_0
    //   186: putstatic a5/p.g : Ljava/lang/reflect/Method;
    //   189: invokestatic i : ()Z
    //   192: ifeq -> 234
    //   195: ldc 'android.os.WorkSource$WorkChain'
    //   197: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   200: ldc 'addNode'
    //   202: iconst_2
    //   203: anewarray java/lang/Class
    //   206: dup
    //   207: iconst_0
    //   208: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   211: aastore
    //   212: dup
    //   213: iconst_1
    //   214: ldc java/lang/String
    //   216: aastore
    //   217: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   220: astore_0
    //   221: goto -> 236
    //   224: astore_0
    //   225: ldc 'WorkSourceUtil'
    //   227: ldc 'Missing WorkChain class'
    //   229: aload_0
    //   230: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   233: pop
    //   234: aconst_null
    //   235: astore_0
    //   236: aload_0
    //   237: putstatic a5/p.h : Ljava/lang/reflect/Method;
    //   240: invokestatic i : ()Z
    //   243: ifeq -> 266
    //   246: ldc android/os/WorkSource
    //   248: ldc 'isEmpty'
    //   250: iconst_0
    //   251: anewarray java/lang/Class
    //   254: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   257: astore_0
    //   258: aload_0
    //   259: iconst_1
    //   260: invokevirtual setAccessible : (Z)V
    //   263: goto -> 268
    //   266: aconst_null
    //   267: astore_0
    //   268: aload_0
    //   269: putstatic a5/p.i : Ljava/lang/reflect/Method;
    //   272: aconst_null
    //   273: putstatic a5/p.j : Ljava/lang/Boolean;
    //   276: return
    //   277: astore_0
    //   278: goto -> 27
    //   281: astore_0
    //   282: goto -> 65
    //   285: astore_0
    //   286: goto -> 86
    //   289: astore_0
    //   290: goto -> 113
    //   293: astore_0
    //   294: goto -> 146
    //   297: astore_0
    //   298: goto -> 266
    //   301: astore_1
    //   302: goto -> 268
    // Exception table:
    //   from	to	target	type
    //   6	24	277	java/lang/Exception
    //   39	62	281	java/lang/Exception
    //   71	83	285	java/lang/Exception
    //   92	110	289	java/lang/Exception
    //   125	143	293	java/lang/Exception
    //   158	170	173	java/lang/Exception
    //   195	221	224	java/lang/Exception
    //   246	258	297	java/lang/Exception
    //   258	263	301	java/lang/Exception
  }
  
  public static void a(WorkSource paramWorkSource, int paramInt, String paramString) {
    Method method2 = c;
    if (method2 != null) {
      String str = paramString;
      if (paramString == null)
        str = ""; 
      try {
        method2.invoke(paramWorkSource, new Object[] { Integer.valueOf(paramInt), str });
        return;
      } catch (Exception exception) {
        Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", exception);
        return;
      } 
    } 
    Method method1 = b;
    if (method1 != null)
      try {
        method1.invoke(exception, new Object[] { Integer.valueOf(paramInt) });
        return;
      } catch (Exception exception1) {
        Log.wtf("WorkSourceUtil", "Unable to assign blame through WorkSource", exception1);
      }  
  }
  
  public static WorkSource b(Context paramContext, String paramString) {
    if (paramContext != null && paramContext.getPackageManager() != null && paramString != null) {
      try {
        String str;
        ApplicationInfo applicationInfo = e.a(paramContext).c(paramString, 0);
        if (applicationInfo == null) {
          str = "Could not get applicationInfo from package: ";
          Log.e("WorkSourceUtil", str.concat(paramString));
          return null;
        } 
        int i = ((ApplicationInfo)str).uid;
        WorkSource workSource = new WorkSource();
        a(workSource, i, paramString);
        return workSource;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
      Log.e("WorkSourceUtil", nameNotFoundException.concat(paramString));
      return null;
    } 
    return null;
  }
  
  public static boolean c(Context paramContext) {
    // Byte code:
    //   0: ldc a5/p
    //   2: monitorenter
    //   3: getstatic a5/p.j : Ljava/lang/Boolean;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 21
    //   11: aload_2
    //   12: invokevirtual booleanValue : ()Z
    //   15: istore_1
    //   16: ldc a5/p
    //   18: monitorexit
    //   19: iload_1
    //   20: ireturn
    //   21: iconst_0
    //   22: istore_1
    //   23: aload_0
    //   24: ifnonnull -> 32
    //   27: ldc a5/p
    //   29: monitorexit
    //   30: iconst_0
    //   31: ireturn
    //   32: aload_0
    //   33: ldc 'android.permission.UPDATE_DEVICE_STATS'
    //   35: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)I
    //   38: ifne -> 43
    //   41: iconst_1
    //   42: istore_1
    //   43: iload_1
    //   44: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   47: astore_0
    //   48: aload_0
    //   49: putstatic a5/p.j : Ljava/lang/Boolean;
    //   52: aload_0
    //   53: invokevirtual booleanValue : ()Z
    //   56: istore_1
    //   57: ldc a5/p
    //   59: monitorexit
    //   60: iload_1
    //   61: ireturn
    //   62: astore_0
    //   63: ldc a5/p
    //   65: monitorexit
    //   66: aload_0
    //   67: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	62	finally
    //   11	16	62	finally
    //   32	41	62	finally
    //   43	57	62	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */