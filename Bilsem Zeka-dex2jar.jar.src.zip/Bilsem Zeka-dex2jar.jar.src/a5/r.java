package a5;

import android.os.Looper;

public final class r {
  public static boolean a() {
    return (Looper.getMainLooper() == Looper.myLooper());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a5\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */