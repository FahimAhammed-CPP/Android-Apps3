package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.widget.c2;

public final class ExpandedMenuView extends ListView implements e.b, k, AdapterView.OnItemClickListener {
  private static final int[] c = new int[] { 16842964, 16843049 };
  
  private e a;
  
  private int b;
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842868);
  }
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    setOnItemClickListener(this);
    c2 c2 = c2.u(paramContext, paramAttributeSet, c, paramInt, 0);
    if (c2.r(0))
      setBackgroundDrawable(c2.f(0)); 
    if (c2.r(1))
      setDivider(c2.f(1)); 
    c2.v();
  }
  
  public boolean a(g paramg) {
    return this.a.L((MenuItem)paramg, 0);
  }
  
  public void b(e parame) {
    this.a = parame;
  }
  
  public int getWindowAnimations() {
    return this.b;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    setChildrenDrawingCacheEnabled(false);
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    a((g)getAdapter().getItem(paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\ExpandedMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */