package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

public class d extends BaseAdapter {
  e a;
  
  private int b = -1;
  
  private boolean c;
  
  private final boolean d;
  
  private final LayoutInflater e;
  
  private final int f;
  
  public d(e parame, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt) {
    this.d = paramBoolean;
    this.e = paramLayoutInflater;
    this.a = parame;
    this.f = paramInt;
    a();
  }
  
  void a() {
    g g = this.a.v();
    if (g != null) {
      ArrayList<g> arrayList = this.a.z();
      int j = arrayList.size();
      for (int i = 0; i < j; i++) {
        if ((g)arrayList.get(i) == g) {
          this.b = i;
          return;
        } 
      } 
    } 
    this.b = -1;
  }
  
  public e b() {
    return this.a;
  }
  
  public g c(int paramInt) {
    ArrayList<g> arrayList;
    if (this.d) {
      arrayList = this.a.z();
    } else {
      arrayList = this.a.E();
    } 
    int j = this.b;
    int i = paramInt;
    if (j >= 0) {
      i = paramInt;
      if (paramInt >= j)
        i = paramInt + 1; 
    } 
    return arrayList.get(i);
  }
  
  public void d(boolean paramBoolean) {
    this.c = paramBoolean;
  }
  
  public int getCount() {
    ArrayList<g> arrayList;
    if (this.d) {
      arrayList = this.a.z();
    } else {
      arrayList = this.a.E();
    } 
    int i = this.b;
    int j = arrayList.size();
    return (i < 0) ? j : (j - 1);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramView;
    if (paramView == null)
      view = this.e.inflate(this.f, paramViewGroup, false); 
    int j = c(paramInt).getGroupId();
    int i = paramInt - 1;
    if (i >= 0) {
      i = c(i).getGroupId();
    } else {
      i = j;
    } 
    ListMenuItemView listMenuItemView = (ListMenuItemView)view;
    if (this.a.F() && j != i) {
      bool = true;
    } else {
      bool = false;
    } 
    listMenuItemView.setGroupDividerEnabled(bool);
    k.a a = (k.a)view;
    if (this.c)
      listMenuItemView.setForceShowIcon(true); 
    a.d(c(paramInt), 0);
    return view;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */