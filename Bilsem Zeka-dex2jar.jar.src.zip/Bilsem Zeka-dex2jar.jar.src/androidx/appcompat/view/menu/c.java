package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import e.g;
import java.util.ArrayList;

public class c implements j, AdapterView.OnItemClickListener {
  Context a;
  
  LayoutInflater b;
  
  e c;
  
  ExpandedMenuView d;
  
  int e;
  
  int f;
  
  int g;
  
  private j.a h;
  
  a i;
  
  public c(int paramInt1, int paramInt2) {
    this.g = paramInt1;
    this.f = paramInt2;
  }
  
  public c(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.a = paramContext;
    this.b = LayoutInflater.from(paramContext);
  }
  
  public ListAdapter a() {
    if (this.i == null)
      this.i = new a(this); 
    return (ListAdapter)this.i;
  }
  
  public k b(ViewGroup paramViewGroup) {
    if (this.d == null) {
      this.d = (ExpandedMenuView)this.b.inflate(g.g, paramViewGroup, false);
      if (this.i == null)
        this.i = new a(this); 
      this.d.setAdapter((ListAdapter)this.i);
      this.d.setOnItemClickListener(this);
    } 
    return this.d;
  }
  
  public void c(e parame, boolean paramBoolean) {
    j.a a1 = this.h;
    if (a1 != null)
      a1.c(parame, paramBoolean); 
  }
  
  public void d(boolean paramBoolean) {
    a a1 = this.i;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean e() {
    return false;
  }
  
  public boolean f(e parame, g paramg) {
    return false;
  }
  
  public boolean g(e parame, g paramg) {
    return false;
  }
  
  public void h(j.a parama) {
    this.h = parama;
  }
  
  public void i(Context paramContext, e parame) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : I
    //   4: ifeq -> 38
    //   7: new android/view/ContextThemeWrapper
    //   10: dup
    //   11: aload_1
    //   12: aload_0
    //   13: getfield f : I
    //   16: invokespecial <init> : (Landroid/content/Context;I)V
    //   19: astore_1
    //   20: aload_0
    //   21: aload_1
    //   22: putfield a : Landroid/content/Context;
    //   25: aload_1
    //   26: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   29: astore_1
    //   30: aload_0
    //   31: aload_1
    //   32: putfield b : Landroid/view/LayoutInflater;
    //   35: goto -> 65
    //   38: aload_0
    //   39: getfield a : Landroid/content/Context;
    //   42: ifnull -> 65
    //   45: aload_0
    //   46: aload_1
    //   47: putfield a : Landroid/content/Context;
    //   50: aload_0
    //   51: getfield b : Landroid/view/LayoutInflater;
    //   54: ifnonnull -> 65
    //   57: aload_1
    //   58: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   61: astore_1
    //   62: goto -> 30
    //   65: aload_0
    //   66: aload_2
    //   67: putfield c : Landroidx/appcompat/view/menu/e;
    //   70: aload_0
    //   71: getfield i : Landroidx/appcompat/view/menu/c$a;
    //   74: astore_1
    //   75: aload_1
    //   76: ifnull -> 83
    //   79: aload_1
    //   80: invokevirtual notifyDataSetChanged : ()V
    //   83: return
  }
  
  public boolean k(m paramm) {
    if (!paramm.hasVisibleItems())
      return false; 
    (new f(paramm)).b(null);
    j.a a1 = this.h;
    if (a1 != null)
      a1.d(paramm); 
    return true;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.c.M((MenuItem)this.i.b(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int a = -1;
    
    public a(c this$0) {
      a();
    }
    
    void a() {
      g g = this.b.c.v();
      if (g != null) {
        ArrayList<g> arrayList = this.b.c.z();
        int j = arrayList.size();
        for (int i = 0; i < j; i++) {
          if ((g)arrayList.get(i) == g) {
            this.a = i;
            return;
          } 
        } 
      } 
      this.a = -1;
    }
    
    public g b(int param1Int) {
      ArrayList<g> arrayList = this.b.c.z();
      int i = param1Int + this.b.e;
      int j = this.a;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      int i = this.b.c.z().size() - this.b.e;
      return (this.a < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        c c1 = this.b;
        view = c1.b.inflate(c1.g, param1ViewGroup, false);
      } 
      ((k.a)view).d(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */