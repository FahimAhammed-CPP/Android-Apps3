package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.r1;
import androidx.core.view.t0;
import e.d;
import e.g;

final class l extends h implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int v = g.m;
  
  private final Context b;
  
  private final e c;
  
  private final d d;
  
  private final boolean e;
  
  private final int f;
  
  private final int g;
  
  private final int h;
  
  final r1 i;
  
  final ViewTreeObserver.OnGlobalLayoutListener j = new a(this);
  
  private final View.OnAttachStateChangeListener k = new b(this);
  
  private PopupWindow.OnDismissListener l;
  
  private View m;
  
  View n;
  
  private j.a o;
  
  ViewTreeObserver p;
  
  private boolean q;
  
  private boolean r;
  
  private int s;
  
  private int t = 0;
  
  private boolean u;
  
  public l(Context paramContext, e parame, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.b = paramContext;
    this.c = parame;
    this.e = paramBoolean;
    this.d = new d(parame, LayoutInflater.from(paramContext), paramBoolean, v);
    this.g = paramInt1;
    this.h = paramInt2;
    Resources resources = paramContext.getResources();
    this.f = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.m = paramView;
    this.i = new r1(paramContext, null, paramInt1, paramInt2);
    parame.c(this, paramContext);
  }
  
  private boolean z() {
    if (a())
      return true; 
    if (!this.q) {
      boolean bool;
      View view = this.m;
      if (view == null)
        return false; 
      this.n = view;
      this.i.G(this);
      this.i.H(this);
      this.i.F(true);
      view = this.n;
      if (this.p == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.p = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.j); 
      view.addOnAttachStateChangeListener(this.k);
      this.i.z(view);
      this.i.C(this.t);
      if (!this.r) {
        this.s = h.o((ListAdapter)this.d, null, this.b, this.f);
        this.r = true;
      } 
      this.i.B(this.s);
      this.i.E(2);
      this.i.D(n());
      this.i.b();
      ListView listView = this.i.j();
      listView.setOnKeyListener(this);
      if (this.u && this.c.x() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.b).inflate(g.l, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.c.x()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.i.p((ListAdapter)this.d);
      this.i.b();
      return true;
    } 
    return false;
  }
  
  public boolean a() {
    return (!this.q && this.i.a());
  }
  
  public void b() {
    if (z())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void c(e parame, boolean paramBoolean) {
    if (parame != this.c)
      return; 
    dismiss();
    j.a a1 = this.o;
    if (a1 != null)
      a1.c(parame, paramBoolean); 
  }
  
  public void d(boolean paramBoolean) {
    this.r = false;
    d d1 = this.d;
    if (d1 != null)
      d1.notifyDataSetChanged(); 
  }
  
  public void dismiss() {
    if (a())
      this.i.dismiss(); 
  }
  
  public boolean e() {
    return false;
  }
  
  public void h(j.a parama) {
    this.o = parama;
  }
  
  public ListView j() {
    return this.i.j();
  }
  
  public boolean k(m paramm) {
    if (paramm.hasVisibleItems()) {
      i i1 = new i(this.b, paramm, this.n, this.e, this.g, this.h);
      i1.j(this.o);
      i1.g(h.x(paramm));
      i1.i(this.l);
      this.l = null;
      this.c.e(false);
      int j = this.i.c();
      int k = this.i.o();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.t, t0.q(this.m)) & 0x7) == 5)
        i = j + this.m.getWidth(); 
      if (i1.n(i, k)) {
        j.a a1 = this.o;
        if (a1 != null)
          a1.d(paramm); 
        return true;
      } 
    } 
    return false;
  }
  
  public void l(e parame) {}
  
  public void onDismiss() {
    this.q = true;
    this.c.close();
    ViewTreeObserver viewTreeObserver = this.p;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.p = this.n.getViewTreeObserver(); 
      this.p.removeGlobalOnLayoutListener(this.j);
      this.p = null;
    } 
    this.n.removeOnAttachStateChangeListener(this.k);
    PopupWindow.OnDismissListener onDismissListener = this.l;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void p(View paramView) {
    this.m = paramView;
  }
  
  public void r(boolean paramBoolean) {
    this.d.d(paramBoolean);
  }
  
  public void s(int paramInt) {
    this.t = paramInt;
  }
  
  public void t(int paramInt) {
    this.i.e(paramInt);
  }
  
  public void u(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.l = paramOnDismissListener;
  }
  
  public void v(boolean paramBoolean) {
    this.u = paramBoolean;
  }
  
  public void w(int paramInt) {
    this.i.l(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(l this$0) {}
    
    public void onGlobalLayout() {
      if (this.a.a() && !this.a.i.x()) {
        View view = this.a.n;
        if (view == null || !view.isShown()) {
          this.a.dismiss();
          return;
        } 
        this.a.i.b();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(l this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.a.p;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.a.p = param1View.getViewTreeObserver(); 
        l l1 = this.a;
        l1.p.removeGlobalOnLayoutListener(l1.j);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */