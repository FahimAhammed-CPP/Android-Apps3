package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.h1;
import androidx.appcompat.widget.m0;
import e.j;
import k.e;

public class ActionMenuItemView extends m0 implements k.a, View.OnClickListener, ActionMenuView.a {
  g f;
  
  private CharSequence g;
  
  private Drawable h;
  
  e.b i;
  
  private h1 j;
  
  b k;
  
  private boolean l;
  
  private boolean m;
  
  private int n;
  
  private int o;
  
  private int p;
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public ActionMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Resources resources = paramContext.getResources();
    this.l = g();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.v, paramInt, 0);
    this.n = typedArray.getDimensionPixelSize(j.w, 0);
    typedArray.recycle();
    this.p = (int)((resources.getDisplayMetrics()).density * 32.0F + 0.5F);
    setOnClickListener(this);
    this.o = -1;
    setSaveEnabled(false);
  }
  
  private boolean g() {
    Configuration configuration = getContext().getResources().getConfiguration();
    int i = configuration.screenWidthDp;
    int j = configuration.screenHeightDp;
    return (i >= 480 || (i >= 640 && j >= 480) || configuration.orientation == 2);
  }
  
  private void h() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Ljava/lang/CharSequence;
    //   4: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   7: istore_3
    //   8: iconst_1
    //   9: istore_2
    //   10: iload_2
    //   11: istore_1
    //   12: aload_0
    //   13: getfield h : Landroid/graphics/drawable/Drawable;
    //   16: ifnull -> 52
    //   19: aload_0
    //   20: getfield f : Landroidx/appcompat/view/menu/g;
    //   23: invokevirtual B : ()Z
    //   26: ifeq -> 50
    //   29: iload_2
    //   30: istore_1
    //   31: aload_0
    //   32: getfield l : Z
    //   35: ifne -> 52
    //   38: aload_0
    //   39: getfield m : Z
    //   42: ifeq -> 50
    //   45: iload_2
    //   46: istore_1
    //   47: goto -> 52
    //   50: iconst_0
    //   51: istore_1
    //   52: iload_3
    //   53: iconst_1
    //   54: ixor
    //   55: iload_1
    //   56: iand
    //   57: istore_1
    //   58: aconst_null
    //   59: astore #5
    //   61: iload_1
    //   62: ifeq -> 74
    //   65: aload_0
    //   66: getfield g : Ljava/lang/CharSequence;
    //   69: astore #4
    //   71: goto -> 77
    //   74: aconst_null
    //   75: astore #4
    //   77: aload_0
    //   78: aload #4
    //   80: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   83: aload_0
    //   84: getfield f : Landroidx/appcompat/view/menu/g;
    //   87: invokevirtual getContentDescription : ()Ljava/lang/CharSequence;
    //   90: astore #6
    //   92: aload #6
    //   94: astore #4
    //   96: aload #6
    //   98: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   101: ifeq -> 123
    //   104: iload_1
    //   105: ifeq -> 114
    //   108: aconst_null
    //   109: astore #4
    //   111: goto -> 123
    //   114: aload_0
    //   115: getfield f : Landroidx/appcompat/view/menu/g;
    //   118: invokevirtual getTitle : ()Ljava/lang/CharSequence;
    //   121: astore #4
    //   123: aload_0
    //   124: aload #4
    //   126: invokevirtual setContentDescription : (Ljava/lang/CharSequence;)V
    //   129: aload_0
    //   130: getfield f : Landroidx/appcompat/view/menu/g;
    //   133: invokevirtual getTooltipText : ()Ljava/lang/CharSequence;
    //   136: astore #4
    //   138: aload #4
    //   140: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   143: ifeq -> 173
    //   146: iload_1
    //   147: ifeq -> 157
    //   150: aload #5
    //   152: astore #4
    //   154: goto -> 166
    //   157: aload_0
    //   158: getfield f : Landroidx/appcompat/view/menu/g;
    //   161: invokevirtual getTitle : ()Ljava/lang/CharSequence;
    //   164: astore #4
    //   166: aload_0
    //   167: aload #4
    //   169: invokestatic a : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   172: return
    //   173: aload_0
    //   174: aload #4
    //   176: invokestatic a : (Landroid/view/View;Ljava/lang/CharSequence;)V
    //   179: return
  }
  
  public boolean a() {
    return f();
  }
  
  public boolean b() {
    return (f() && this.f.getIcon() == null);
  }
  
  public boolean c() {
    return true;
  }
  
  public void d(g paramg, int paramInt) {
    this.f = paramg;
    setIcon(paramg.getIcon());
    setTitle(paramg.i(this));
    setId(paramg.getItemId());
    if (paramg.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setEnabled(paramg.isEnabled());
    if (paramg.hasSubMenu() && this.j == null)
      this.j = new a(this); 
  }
  
  public boolean f() {
    return TextUtils.isEmpty(getText()) ^ true;
  }
  
  public g getItemData() {
    return this.f;
  }
  
  public void onClick(View paramView) {
    e.b b1 = this.i;
    if (b1 != null)
      b1.a(this.f); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.l = g();
    h();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool = f();
    if (bool) {
      int k = this.o;
      if (k >= 0)
        super.setPadding(k, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
    } 
    super.onMeasure(paramInt1, paramInt2);
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = getMeasuredWidth();
    if (i == Integer.MIN_VALUE) {
      paramInt1 = Math.min(paramInt1, this.n);
    } else {
      paramInt1 = this.n;
    } 
    if (i != 1073741824 && this.n > 0 && j < paramInt1)
      super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2); 
    if (!bool && this.h != null)
      super.setPadding((getMeasuredWidth() - this.h.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    super.onRestoreInstanceState(null);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.f.hasSubMenu()) {
      h1 h11 = this.j;
      if (h11 != null && h11.onTouch((View)this, paramMotionEvent))
        return true; 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setCheckable(boolean paramBoolean) {}
  
  public void setChecked(boolean paramBoolean) {}
  
  public void setExpandedFormat(boolean paramBoolean) {
    if (this.m != paramBoolean) {
      this.m = paramBoolean;
      g g1 = this.f;
      if (g1 != null)
        g1.c(); 
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.h = paramDrawable;
    if (paramDrawable != null) {
      int m = paramDrawable.getIntrinsicWidth();
      int n = paramDrawable.getIntrinsicHeight();
      int k = this.p;
      int i = m;
      int j = n;
      if (m > k) {
        float f = k / m;
        j = (int)(n * f);
        i = k;
      } 
      if (j > k) {
        float f = k / j;
        i = (int)(i * f);
      } else {
        k = j;
      } 
      paramDrawable.setBounds(0, 0, i, k);
    } 
    setCompoundDrawables(paramDrawable, null, null, null);
    h();
  }
  
  public void setItemInvoker(e.b paramb) {
    this.i = paramb;
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.o = paramInt1;
    super.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void setPopupCallback(b paramb) {
    this.k = paramb;
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.g = paramCharSequence;
    h();
  }
  
  private class a extends h1 {
    public a(ActionMenuItemView this$0) {
      super((View)this$0);
    }
    
    public e b() {
      ActionMenuItemView.b b = this.j.k;
      return (b != null) ? b.a() : null;
    }
    
    protected boolean c() {
      ActionMenuItemView actionMenuItemView = this.j;
      e.b b = actionMenuItemView.i;
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (b != null) {
        bool1 = bool2;
        if (b.a(actionMenuItemView.f)) {
          e e = b();
          bool1 = bool2;
          if (e != null) {
            bool1 = bool2;
            if (e.a())
              bool1 = true; 
          } 
        } 
      } 
      return bool1;
    }
  }
  
  public static abstract class b {
    public abstract e a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\ActionMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */