package androidx.appcompat.view.menu;

import android.content.Context;

public interface j {
  void c(e parame, boolean paramBoolean);
  
  void d(boolean paramBoolean);
  
  boolean e();
  
  boolean f(e parame, g paramg);
  
  boolean g(e parame, g paramg);
  
  void h(a parama);
  
  void i(Context paramContext, e parame);
  
  boolean k(m paramm);
  
  public static interface a {
    void c(e param1e, boolean param1Boolean);
    
    boolean d(e param1e);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */