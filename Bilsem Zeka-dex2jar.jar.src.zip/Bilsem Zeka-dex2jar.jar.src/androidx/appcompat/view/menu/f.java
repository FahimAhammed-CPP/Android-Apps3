package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.b;
import e.g;

class f implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, j.a {
  private e a;
  
  private b b;
  
  c c;
  
  private j.a d;
  
  public f(e parame) {
    this.a = parame;
  }
  
  public void a() {
    b b1 = this.b;
    if (b1 != null)
      b1.dismiss(); 
  }
  
  public void b(IBinder paramIBinder) {
    e e1 = this.a;
    b.a a1 = new b.a(e1.u());
    c c1 = new c(a1.b(), g.j);
    this.c = c1;
    c1.h(this);
    this.a.b(this.c);
    a1.c(this.c.a(), this);
    View view = e1.y();
    if (view != null) {
      a1.d(view);
    } else {
      a1.e(e1.w()).h(e1.x());
    } 
    a1.f(this);
    b b1 = a1.a();
    this.b = b1;
    b1.setOnDismissListener(this);
    WindowManager.LayoutParams layoutParams = this.b.getWindow().getAttributes();
    layoutParams.type = 1003;
    if (paramIBinder != null)
      layoutParams.token = paramIBinder; 
    layoutParams.flags |= 0x20000;
    this.b.show();
  }
  
  public void c(e parame, boolean paramBoolean) {
    if (paramBoolean || parame == this.a)
      a(); 
    j.a a1 = this.d;
    if (a1 != null)
      a1.c(parame, paramBoolean); 
  }
  
  public boolean d(e parame) {
    j.a a1 = this.d;
    return (a1 != null) ? a1.d(parame) : false;
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.a.L((MenuItem)this.c.a().getItem(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    this.c.c(this.a, true);
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.b.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.b.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.a.e(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.a.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */