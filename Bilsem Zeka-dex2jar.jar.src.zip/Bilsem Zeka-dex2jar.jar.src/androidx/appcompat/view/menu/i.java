package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import androidx.core.view.r;
import androidx.core.view.t0;
import e.d;

public class i {
  private final Context a;
  
  private final e b;
  
  private final boolean c;
  
  private final int d;
  
  private final int e;
  
  private View f;
  
  private int g = 8388611;
  
  private boolean h;
  
  private j.a i;
  
  private h j;
  
  private PopupWindow.OnDismissListener k;
  
  private final PopupWindow.OnDismissListener l = new a(this);
  
  public i(Context paramContext, e parame, View paramView, boolean paramBoolean, int paramInt) {
    this(paramContext, parame, paramView, paramBoolean, paramInt, 0);
  }
  
  public i(Context paramContext, e parame, View paramView, boolean paramBoolean, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.b = parame;
    this.f = paramView;
    this.c = paramBoolean;
    this.d = paramInt1;
    this.e = paramInt2;
  }
  
  private h a() {
    boolean bool;
    l l;
    Display display = ((WindowManager)this.a.getSystemService("window")).getDefaultDisplay();
    Point point = new Point();
    display.getRealSize(point);
    if (Math.min(point.x, point.y) >= this.a.getResources().getDimensionPixelSize(d.c)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      b b = new b(this.a, this.f, this.d, this.e, this.c);
    } else {
      l = new l(this.a, this.b, this.f, this.d, this.e, this.c);
    } 
    l.l(this.b);
    l.u(this.l);
    l.p(this.f);
    l.h(this.i);
    l.r(this.h);
    l.s(this.g);
    return l;
  }
  
  private void l(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    h h1 = c();
    h1.v(paramBoolean2);
    if (paramBoolean1) {
      int j = paramInt1;
      if ((r.a(this.g, t0.q(this.f)) & 0x7) == 5)
        j = paramInt1 - this.f.getWidth(); 
      h1.t(j);
      h1.w(paramInt2);
      paramInt1 = (int)((this.a.getResources().getDisplayMetrics()).density * 48.0F / 2.0F);
      h1.q(new Rect(j - paramInt1, paramInt2 - paramInt1, j + paramInt1, paramInt2 + paramInt1));
    } 
    h1.b();
  }
  
  public void b() {
    if (d())
      this.j.dismiss(); 
  }
  
  public h c() {
    if (this.j == null)
      this.j = a(); 
    return this.j;
  }
  
  public boolean d() {
    h h1 = this.j;
    return (h1 != null && h1.a());
  }
  
  protected void e() {
    this.j = null;
    PopupWindow.OnDismissListener onDismissListener = this.k;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public void f(View paramView) {
    this.f = paramView;
  }
  
  public void g(boolean paramBoolean) {
    this.h = paramBoolean;
    h h1 = this.j;
    if (h1 != null)
      h1.r(paramBoolean); 
  }
  
  public void h(int paramInt) {
    this.g = paramInt;
  }
  
  public void i(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.k = paramOnDismissListener;
  }
  
  public void j(j.a parama) {
    this.i = parama;
    h h1 = this.j;
    if (h1 != null)
      h1.h(parama); 
  }
  
  public void k() {
    if (m())
      return; 
    throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
  }
  
  public boolean m() {
    if (d())
      return true; 
    if (this.f == null)
      return false; 
    l(0, 0, false, false);
    return true;
  }
  
  public boolean n(int paramInt1, int paramInt2) {
    if (d())
      return true; 
    if (this.f == null)
      return false; 
    l(paramInt1, paramInt2, true, true);
    return true;
  }
  
  class a implements PopupWindow.OnDismissListener {
    a(i this$0) {}
    
    public void onDismiss() {
      this.a.e();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */