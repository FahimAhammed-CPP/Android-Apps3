package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class a implements j {
  protected Context a;
  
  protected Context b;
  
  protected e c;
  
  protected LayoutInflater d;
  
  protected LayoutInflater e;
  
  private j.a f;
  
  private int g;
  
  private int h;
  
  protected k i;
  
  private int j;
  
  public a(Context paramContext, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.d = LayoutInflater.from(paramContext);
    this.g = paramInt1;
    this.h = paramInt2;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.i).addView(paramView, paramInt);
  }
  
  public abstract void b(g paramg, k.a parama);
  
  public void c(e parame, boolean paramBoolean) {
    j.a a1 = this.f;
    if (a1 != null)
      a1.c(parame, paramBoolean); 
  }
  
  public void d(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.i;
    if (viewGroup == null)
      return; 
    e e1 = this.c;
    int i = 0;
    if (e1 != null) {
      e1.r();
      ArrayList<g> arrayList = this.c.E();
      int n = arrayList.size();
      int m = 0;
      for (i = 0; m < n; i = i1) {
        g g = arrayList.get(m);
        int i1 = i;
        if (q(i, g)) {
          View view1 = viewGroup.getChildAt(i);
          if (view1 instanceof k.a) {
            g g1 = ((k.a)view1).getItemData();
          } else {
            e1 = null;
          } 
          View view2 = n(g, view1, viewGroup);
          if (g != e1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            a(view2, i); 
          i1 = i + 1;
        } 
        m++;
      } 
    } 
    while (i < viewGroup.getChildCount()) {
      if (!l(viewGroup, i))
        i++; 
    } 
  }
  
  public boolean f(e parame, g paramg) {
    return false;
  }
  
  public boolean g(e parame, g paramg) {
    return false;
  }
  
  public void h(j.a parama) {
    this.f = parama;
  }
  
  public void i(Context paramContext, e parame) {
    this.b = paramContext;
    this.e = LayoutInflater.from(paramContext);
    this.c = parame;
  }
  
  public k.a j(ViewGroup paramViewGroup) {
    return (k.a)this.d.inflate(this.h, paramViewGroup, false);
  }
  
  public boolean k(m paramm) {
    j.a a1 = this.f;
    if (a1 != null) {
      e e1;
      if (paramm == null)
        e1 = this.c; 
      return a1.d(e1);
    } 
    return false;
  }
  
  protected boolean l(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public j.a m() {
    return this.f;
  }
  
  public View n(g paramg, View paramView, ViewGroup paramViewGroup) {
    k.a a1;
    if (paramView instanceof k.a) {
      a1 = (k.a)paramView;
    } else {
      a1 = j(paramViewGroup);
    } 
    b(paramg, a1);
    return (View)a1;
  }
  
  public k o(ViewGroup paramViewGroup) {
    if (this.i == null) {
      k k1 = (k)this.d.inflate(this.g, paramViewGroup, false);
      this.i = k1;
      k1.b(this.c);
      d(true);
    } 
    return this.i;
  }
  
  public void p(int paramInt) {
    this.j = paramInt;
  }
  
  public abstract boolean q(int paramInt, g paramg);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\view\menu\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */