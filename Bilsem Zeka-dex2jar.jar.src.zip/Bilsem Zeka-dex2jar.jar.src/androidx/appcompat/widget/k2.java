package androidx.appcompat.widget;

public interface k2 {
  CharSequence a();
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\k2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */