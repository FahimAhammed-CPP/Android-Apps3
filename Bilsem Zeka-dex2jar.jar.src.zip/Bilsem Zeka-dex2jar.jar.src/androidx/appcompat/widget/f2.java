package androidx.appcompat.widget;

import android.os.Build;
import android.view.View;

public class f2 {
  public static void a(View paramView, CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26) {
      e2.a(paramView, paramCharSequence);
      return;
    } 
    g2.f(paramView, paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\f2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */