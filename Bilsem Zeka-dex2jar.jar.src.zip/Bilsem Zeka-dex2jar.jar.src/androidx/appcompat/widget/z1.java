package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class z1 extends ContextWrapper {
  private static final Object c = new Object();
  
  private static ArrayList<WeakReference<z1>> d;
  
  private final Resources a;
  
  private final Resources.Theme b;
  
  private z1(Context paramContext) {
    super(paramContext);
    if (i2.c()) {
      i2 i2 = new i2((Context)this, paramContext.getResources());
      this.a = i2;
      Resources.Theme theme = i2.newTheme();
      this.b = theme;
      theme.setTo(paramContext.getTheme());
      return;
    } 
    this.a = new b2((Context)this, paramContext.getResources());
    this.b = null;
  }
  
  private static boolean a(Context paramContext) {
    boolean bool = paramContext instanceof z1;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      bool1 = bool2;
      if (!(paramContext.getResources() instanceof b2)) {
        if (paramContext.getResources() instanceof i2)
          return false; 
        bool1 = bool2;
        if (i2.c())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public static Context b(Context paramContext) {
    if (a(paramContext))
      synchronized (c) {
        ArrayList<WeakReference<z1>> arrayList = d;
        if (arrayList == null) {
          d = new ArrayList<WeakReference<z1>>();
        } else {
          for (int i = arrayList.size() - 1;; i--) {
            if (i >= 0) {
              WeakReference weakReference = d.get(i);
              if (weakReference == null || weakReference.get() == null)
                d.remove(i); 
            } else {
              for (i = d.size() - 1;; i--) {
                if (i >= 0) {
                  WeakReference<z1> weakReference = d.get(i);
                  if (weakReference != null) {
                    z1 z12 = weakReference.get();
                  } else {
                    weakReference = null;
                  } 
                  if (weakReference != null && weakReference.getBaseContext() == paramContext)
                    return (Context)weakReference; 
                } else {
                  z11 = new z1(paramContext);
                  d.add(new WeakReference<z1>(z11));
                  return (Context)z11;
                } 
              } 
            } 
          } 
          i--;
        } 
        z1 z11 = new z1((Context)z11);
        d.add(new WeakReference<z1>(z11));
        return (Context)z11;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.a.getAssets();
  }
  
  public Resources getResources() {
    return this.a;
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme2 = this.b;
    Resources.Theme theme1 = theme2;
    if (theme2 == null)
      theme1 = super.getTheme(); 
    return theme1;
  }
  
  public void setTheme(int paramInt) {
    Resources.Theme theme = this.b;
    if (theme == null) {
      super.setTheme(paramInt);
      return;
    } 
    theme.applyStyle(paramInt, true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\z1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */