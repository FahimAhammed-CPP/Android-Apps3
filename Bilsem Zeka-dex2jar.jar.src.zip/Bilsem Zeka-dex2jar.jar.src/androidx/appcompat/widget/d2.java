package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.core.view.t0;
import androidx.core.view.x1;
import androidx.core.view.y1;
import androidx.core.view.z1;
import e.e;
import e.f;
import e.h;
import e.j;

public class d2 implements d1 {
  Toolbar a;
  
  private int b;
  
  private View c;
  
  private View d;
  
  private Drawable e;
  
  private Drawable f;
  
  private Drawable g;
  
  private boolean h;
  
  CharSequence i;
  
  private CharSequence j;
  
  private CharSequence k;
  
  Window.Callback l;
  
  boolean m;
  
  private c n;
  
  private int o;
  
  private int p;
  
  private Drawable q;
  
  public d2(Toolbar paramToolbar, boolean paramBoolean) {
    this(paramToolbar, paramBoolean, h.a, e.n);
  }
  
  public d2(Toolbar paramToolbar, boolean paramBoolean, int paramInt1, int paramInt2) {
    boolean bool;
    this.o = 0;
    this.p = 0;
    this.a = paramToolbar;
    this.i = paramToolbar.getTitle();
    this.j = paramToolbar.getSubtitle();
    if (this.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h = bool;
    this.g = paramToolbar.getNavigationIcon();
    c2 c2 = c2.u(paramToolbar.getContext(), null, j.a, e.a.c, 0);
    this.q = c2.f(j.l);
    if (paramBoolean) {
      CharSequence charSequence = c2.o(j.r);
      if (!TextUtils.isEmpty(charSequence))
        F(charSequence); 
      charSequence = c2.o(j.p);
      if (!TextUtils.isEmpty(charSequence))
        E(charSequence); 
      Drawable drawable = c2.f(j.n);
      if (drawable != null)
        A(drawable); 
      drawable = c2.f(j.m);
      if (drawable != null)
        setIcon(drawable); 
      if (this.g == null) {
        drawable = this.q;
        if (drawable != null)
          D(drawable); 
      } 
      k(c2.j(j.h, 0));
      paramInt2 = c2.m(j.g, 0);
      if (paramInt2 != 0) {
        y(LayoutInflater.from(this.a.getContext()).inflate(paramInt2, this.a, false));
        k(this.b | 0x10);
      } 
      paramInt2 = c2.l(j.j, 0);
      if (paramInt2 > 0) {
        ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
        layoutParams.height = paramInt2;
        this.a.setLayoutParams(layoutParams);
      } 
      paramInt2 = c2.d(j.f, -1);
      int i = c2.d(j.e, -1);
      if (paramInt2 >= 0 || i >= 0)
        this.a.H(Math.max(paramInt2, 0), Math.max(i, 0)); 
      paramInt2 = c2.m(j.s, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.L(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = c2.m(j.q, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.K(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = c2.m(j.o, 0);
      if (paramInt2 != 0)
        this.a.setPopupTheme(paramInt2); 
    } else {
      this.b = x();
    } 
    c2.v();
    z(paramInt1);
    this.k = this.a.getNavigationContentDescription();
    this.a.setNavigationOnClickListener(new a(this));
  }
  
  private void G(CharSequence paramCharSequence) {
    this.i = paramCharSequence;
    if ((this.b & 0x8) != 0)
      this.a.setTitle(paramCharSequence); 
  }
  
  private void H() {
    if ((this.b & 0x4) != 0) {
      if (TextUtils.isEmpty(this.k)) {
        this.a.setNavigationContentDescription(this.p);
        return;
      } 
      this.a.setNavigationContentDescription(this.k);
    } 
  }
  
  private void I() {
    Drawable drawable;
    Toolbar toolbar;
    if ((this.b & 0x4) != 0) {
      toolbar = this.a;
      drawable = this.g;
      if (drawable == null)
        drawable = this.q; 
    } else {
      toolbar = this.a;
      drawable = null;
    } 
    toolbar.setNavigationIcon(drawable);
  }
  
  private void J() {
    Drawable drawable;
    int i = this.b;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        Drawable drawable1 = this.f;
        if (drawable1 != null) {
          this.a.setLogo(drawable1);
          return;
        } 
      } 
      drawable = this.e;
    } else {
      drawable = null;
    } 
    this.a.setLogo(drawable);
  }
  
  private int x() {
    if (this.a.getNavigationIcon() != null) {
      this.q = this.a.getNavigationIcon();
      return 15;
    } 
    return 11;
  }
  
  public void A(Drawable paramDrawable) {
    this.f = paramDrawable;
    J();
  }
  
  public void B(int paramInt) {
    String str;
    if (paramInt == 0) {
      str = null;
    } else {
      str = getContext().getString(paramInt);
    } 
    C(str);
  }
  
  public void C(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    H();
  }
  
  public void D(Drawable paramDrawable) {
    this.g = paramDrawable;
    I();
  }
  
  public void E(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    if ((this.b & 0x8) != 0)
      this.a.setSubtitle(paramCharSequence); 
  }
  
  public void F(CharSequence paramCharSequence) {
    this.h = true;
    G(paramCharSequence);
  }
  
  public void a(Menu paramMenu, j.a parama) {
    if (this.n == null) {
      c c1 = new c(this.a.getContext());
      this.n = c1;
      c1.p(f.g);
    } 
    this.n.h(parama);
    this.a.I((e)paramMenu, this.n);
  }
  
  public boolean b() {
    return this.a.A();
  }
  
  public void c() {
    this.m = true;
  }
  
  public void collapseActionView() {
    this.a.e();
  }
  
  public boolean d() {
    return this.a.d();
  }
  
  public boolean e() {
    return this.a.z();
  }
  
  public boolean f() {
    return this.a.w();
  }
  
  public boolean g() {
    return this.a.O();
  }
  
  public Context getContext() {
    return this.a.getContext();
  }
  
  public CharSequence getTitle() {
    return this.a.getTitle();
  }
  
  public void h() {
    this.a.f();
  }
  
  public void i(v1 paramv1) {
    View view = this.c;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      Toolbar toolbar = this.a;
      if (viewParent == toolbar)
        toolbar.removeView(this.c); 
    } 
    this.c = (View)paramv1;
    if (paramv1 != null && this.o == 2) {
      this.a.addView((View)paramv1, 0);
      Toolbar.e e = (Toolbar.e)this.c.getLayoutParams();
      ((ViewGroup.MarginLayoutParams)e).width = -2;
      ((ViewGroup.MarginLayoutParams)e).height = -2;
      e.a = 8388691;
      paramv1.setAllowCollapse(true);
    } 
  }
  
  public boolean j() {
    return this.a.v();
  }
  
  public void k(int paramInt) {
    int i = this.b ^ paramInt;
    this.b = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          H(); 
        I();
      } 
      if ((i & 0x3) != 0)
        J(); 
      if ((i & 0x8) != 0) {
        Toolbar toolbar;
        CharSequence charSequence;
        if ((paramInt & 0x8) != 0) {
          this.a.setTitle(this.i);
          toolbar = this.a;
          charSequence = this.j;
        } else {
          toolbar = this.a;
          charSequence = null;
          toolbar.setTitle((CharSequence)null);
          toolbar = this.a;
        } 
        toolbar.setSubtitle(charSequence);
      } 
      if ((i & 0x10) != 0) {
        View view = this.d;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.a.addView(view);
            return;
          } 
          this.a.removeView(view);
        } 
      } 
    } 
  }
  
  public Menu l() {
    return this.a.getMenu();
  }
  
  public void m(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = g.b.d(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    A(drawable);
  }
  
  public int n() {
    return this.o;
  }
  
  public x1 o(int paramInt, long paramLong) {
    float f;
    x1 x1 = t0.c((View)this.a);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return x1.b(f).f(paramLong).h((y1)new b(this, paramInt));
  }
  
  public void p(j.a parama, e.a parama1) {
    this.a.J(parama, parama1);
  }
  
  public void q(int paramInt) {
    this.a.setVisibility(paramInt);
  }
  
  public ViewGroup r() {
    return this.a;
  }
  
  public void s(boolean paramBoolean) {}
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = g.b.d(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setIcon(drawable);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.e = paramDrawable;
    J();
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.l = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.h)
      G(paramCharSequence); 
  }
  
  public int t() {
    return this.b;
  }
  
  public void u() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void v() {
    Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
  }
  
  public void w(boolean paramBoolean) {
    this.a.setCollapsible(paramBoolean);
  }
  
  public void y(View paramView) {
    View view = this.d;
    if (view != null && (this.b & 0x10) != 0)
      this.a.removeView(view); 
    this.d = paramView;
    if (paramView != null && (this.b & 0x10) != 0)
      this.a.addView(paramView); 
  }
  
  public void z(int paramInt) {
    if (paramInt == this.p)
      return; 
    this.p = paramInt;
    if (TextUtils.isEmpty(this.a.getNavigationContentDescription()))
      B(this.p); 
  }
  
  class a implements View.OnClickListener {
    final k.a a;
    
    a(d2 this$0) {
      this.a = new k.a(this$0.a.getContext(), 0, 16908332, 0, 0, this$0.i);
    }
    
    public void onClick(View param1View) {
      d2 d21 = this.b;
      Window.Callback callback = d21.l;
      if (callback != null && d21.m)
        callback.onMenuItemSelected(0, (MenuItem)this.a); 
    }
  }
  
  class b extends z1 {
    private boolean a = false;
    
    b(d2 this$0, int param1Int) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (!this.a)
        this.c.a.setVisibility(this.b); 
    }
    
    public void c(View param1View) {
      this.c.a.setVisibility(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\d2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */