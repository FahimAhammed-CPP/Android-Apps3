package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import androidx.core.content.res.h;
import g.b;

public class c2 {
  private final Context a;
  
  private final TypedArray b;
  
  private TypedValue c;
  
  private c2(Context paramContext, TypedArray paramTypedArray) {
    this.a = paramContext;
    this.b = paramTypedArray;
  }
  
  public static c2 s(Context paramContext, int paramInt, int[] paramArrayOfint) {
    return new c2(paramContext, paramContext.obtainStyledAttributes(paramInt, paramArrayOfint));
  }
  
  public static c2 t(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return new c2(paramContext, paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfint));
  }
  
  public static c2 u(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfint, int paramInt1, int paramInt2) {
    return new c2(paramContext, paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, paramInt1, paramInt2));
  }
  
  public boolean a(int paramInt, boolean paramBoolean) {
    return this.b.getBoolean(paramInt, paramBoolean);
  }
  
  public int b(int paramInt1, int paramInt2) {
    return this.b.getColor(paramInt1, paramInt2);
  }
  
  public ColorStateList c(int paramInt) {
    if (this.b.hasValue(paramInt)) {
      int i = this.b.getResourceId(paramInt, 0);
      if (i != 0) {
        ColorStateList colorStateList = b.c(this.a, i);
        if (colorStateList != null)
          return colorStateList; 
      } 
    } 
    return this.b.getColorStateList(paramInt);
  }
  
  public int d(int paramInt1, int paramInt2) {
    return this.b.getDimensionPixelOffset(paramInt1, paramInt2);
  }
  
  public int e(int paramInt1, int paramInt2) {
    return this.b.getDimensionPixelSize(paramInt1, paramInt2);
  }
  
  public Drawable f(int paramInt) {
    if (this.b.hasValue(paramInt)) {
      int i = this.b.getResourceId(paramInt, 0);
      if (i != 0)
        return b.d(this.a, i); 
    } 
    return this.b.getDrawable(paramInt);
  }
  
  public Drawable g(int paramInt) {
    if (this.b.hasValue(paramInt)) {
      paramInt = this.b.getResourceId(paramInt, 0);
      if (paramInt != 0)
        return j.b().d(this.a, paramInt, true); 
    } 
    return null;
  }
  
  public float h(int paramInt, float paramFloat) {
    return this.b.getFloat(paramInt, paramFloat);
  }
  
  public Typeface i(int paramInt1, int paramInt2, h.e parame) {
    paramInt1 = this.b.getResourceId(paramInt1, 0);
    if (paramInt1 == 0)
      return null; 
    if (this.c == null)
      this.c = new TypedValue(); 
    return h.e(this.a, paramInt1, this.c, paramInt2, parame);
  }
  
  public int j(int paramInt1, int paramInt2) {
    return this.b.getInt(paramInt1, paramInt2);
  }
  
  public int k(int paramInt1, int paramInt2) {
    return this.b.getInteger(paramInt1, paramInt2);
  }
  
  public int l(int paramInt1, int paramInt2) {
    return this.b.getLayoutDimension(paramInt1, paramInt2);
  }
  
  public int m(int paramInt1, int paramInt2) {
    return this.b.getResourceId(paramInt1, paramInt2);
  }
  
  public String n(int paramInt) {
    return this.b.getString(paramInt);
  }
  
  public CharSequence o(int paramInt) {
    return this.b.getText(paramInt);
  }
  
  public CharSequence[] p(int paramInt) {
    return this.b.getTextArray(paramInt);
  }
  
  public TypedArray q() {
    return this.b;
  }
  
  public boolean r(int paramInt) {
    return this.b.hasValue(paramInt);
  }
  
  public void v() {
    this.b.recycle();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\c2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */