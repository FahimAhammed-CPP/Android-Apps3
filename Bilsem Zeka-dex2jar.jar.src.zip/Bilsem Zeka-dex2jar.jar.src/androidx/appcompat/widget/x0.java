package androidx.appcompat.widget;

import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;



/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */