package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

public class i2 extends Resources {
  private static boolean b = false;
  
  private final WeakReference<Context> a;
  
  public i2(Context paramContext, Resources paramResources) {
    super(paramResources.getAssets(), paramResources.getDisplayMetrics(), paramResources.getConfiguration());
    this.a = new WeakReference<Context>(paramContext);
  }
  
  public static boolean a() {
    return b;
  }
  
  public static void b(boolean paramBoolean) {
    b = paramBoolean;
  }
  
  public static boolean c() {
    a();
    return false;
  }
  
  final Drawable d(int paramInt) {
    return super.getDrawable(paramInt);
  }
  
  public Drawable getDrawable(int paramInt) {
    Context context = this.a.get();
    return (context != null) ? s1.h().t(context, this, paramInt) : super.getDrawable(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\i2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */