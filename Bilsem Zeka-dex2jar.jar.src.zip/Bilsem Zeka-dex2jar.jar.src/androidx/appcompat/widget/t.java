package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Selection;
import android.text.Spannable;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.view.inputmethod.InputContentInfo;
import android.widget.TextView;
import androidx.core.view.c;
import androidx.core.view.t0;
import w.e;
import w.j;

final class t {
  static e.c a(View paramView) {
    return new a(paramView);
  }
  
  static boolean b(View paramView, DragEvent paramDragEvent) {
    if (Build.VERSION.SDK_INT >= 24 && paramDragEvent.getLocalState() == null) {
      StringBuilder stringBuilder;
      if (t0.s(paramView) == null)
        return false; 
      Activity activity = d(paramView);
      if (activity == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Can't handle drop: no activity: view=");
        stringBuilder.append(paramView);
        Log.i("ReceiveContent", stringBuilder.toString());
        return false;
      } 
      if (stringBuilder.getAction() == 1)
        return paramView instanceof TextView ^ true; 
      if (stringBuilder.getAction() == 3)
        return (paramView instanceof TextView) ? b.a((DragEvent)stringBuilder, (TextView)paramView, activity) : b.b((DragEvent)stringBuilder, paramView, activity); 
    } 
    return false;
  }
  
  static boolean c(TextView paramTextView, int paramInt) {
    ClipData clipData;
    boolean bool = false;
    if ((paramInt != 16908322 && paramInt != 16908337) || t0.s((View)paramTextView) == null)
      return false; 
    ClipboardManager clipboardManager = (ClipboardManager)paramTextView.getContext().getSystemService("clipboard");
    if (clipboardManager == null) {
      clipboardManager = null;
    } else {
      clipData = clipboardManager.getPrimaryClip();
    } 
    if (clipData != null && clipData.getItemCount() > 0) {
      c.a a = new c.a(clipData, 1);
      if (paramInt == 16908322) {
        paramInt = bool;
      } else {
        paramInt = 1;
      } 
      t0.H((View)paramTextView, a.c(paramInt).a());
    } 
    return true;
  }
  
  static Activity d(View paramView) {
    for (Context context = paramView.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper)context).getBaseContext()) {
      if (context instanceof Activity)
        return (Activity)context; 
    } 
    return null;
  }
  
  class a implements e.c {
    a(t this$0) {}
    
    public boolean a(j param1j, int param1Int, Bundle param1Bundle) {
      int i = Build.VERSION.SDK_INT;
      boolean bool = false;
      Bundle bundle = param1Bundle;
      if (i >= 25) {
        bundle = param1Bundle;
        if ((param1Int & 0x1) != 0)
          try {
            param1j.d();
            InputContentInfo inputContentInfo = (InputContentInfo)param1j.e();
            if (param1Bundle == null) {
              param1Bundle = new Bundle();
            } else {
              param1Bundle = new Bundle(param1Bundle);
            } 
            param1Bundle.putParcelable("androidx.core.view.extra.INPUT_CONTENT_INFO", (Parcelable)inputContentInfo);
            bundle = param1Bundle;
          } catch (Exception exception) {
            Log.w("ReceiveContent", "Can't insert content from IME; requestPermission() failed", exception);
            return false;
          }  
      } 
      c c1 = (new c.a(new ClipData(exception.b(), new ClipData.Item(exception.a())), 2)).d(exception.c()).b(bundle).a();
      if (t0.H(this.a, c1) == null)
        bool = true; 
      return bool;
    }
  }
  
  private static final class b {
    static boolean a(DragEvent param1DragEvent, TextView param1TextView, Activity param1Activity) {
      u.a(param1Activity, param1DragEvent);
      int i = param1TextView.getOffsetForPosition(param1DragEvent.getX(), param1DragEvent.getY());
      param1TextView.beginBatchEdit();
      try {
        Selection.setSelection((Spannable)param1TextView.getText(), i);
        t0.H((View)param1TextView, (new c.a(param1DragEvent.getClipData(), 3)).a());
        return true;
      } finally {
        param1TextView.endBatchEdit();
      } 
    }
    
    static boolean b(DragEvent param1DragEvent, View param1View, Activity param1Activity) {
      u.a(param1Activity, param1DragEvent);
      t0.H(param1View, (new c.a(param1DragEvent.getClipData(), 3)).a());
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */