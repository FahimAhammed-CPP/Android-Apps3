package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.m;
import androidx.core.view.r;
import androidx.core.view.t0;
import androidx.core.view.u;
import e.j;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
  private ColorStateList A;
  
  private boolean B;
  
  private boolean C;
  
  private final ArrayList<View> D = new ArrayList<View>();
  
  private final ArrayList<View> E = new ArrayList<View>();
  
  private final int[] F = new int[2];
  
  f G;
  
  private final ActionMenuView.e H = new a(this);
  
  private d2 I;
  
  private ActionMenuView a;
  
  private c a0;
  
  private TextView b;
  
  private d b0;
  
  private TextView c;
  
  private j.a c0;
  
  private ImageButton d;
  
  private androidx.appcompat.view.menu.e.a d0;
  
  private ImageView e;
  
  private boolean e0;
  
  private Drawable f;
  
  private final Runnable f0 = new b(this);
  
  private CharSequence g;
  
  ImageButton h;
  
  View i;
  
  private Context j;
  
  private int k;
  
  private int l;
  
  private int m;
  
  int n;
  
  private int o;
  
  private int p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private u1 t;
  
  private int u;
  
  private int v;
  
  private int w = 8388627;
  
  private CharSequence x;
  
  private CharSequence y;
  
  private ColorStateList z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.L);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = j.W2;
    c2 c2 = c2.u(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    t0.M((View)this, paramContext, arrayOfInt, paramAttributeSet, c2.q(), paramInt, 0);
    this.l = c2.m(j.y3, 0);
    this.m = c2.m(j.p3, 0);
    this.w = c2.k(j.X2, this.w);
    this.n = c2.k(j.Y2, 48);
    int i = c2.d(j.s3, 0);
    int j = j.x3;
    paramInt = i;
    if (c2.r(j))
      paramInt = c2.d(j, i); 
    this.s = paramInt;
    this.r = paramInt;
    this.q = paramInt;
    this.p = paramInt;
    paramInt = c2.d(j.v3, -1);
    if (paramInt >= 0)
      this.p = paramInt; 
    paramInt = c2.d(j.u3, -1);
    if (paramInt >= 0)
      this.q = paramInt; 
    paramInt = c2.d(j.w3, -1);
    if (paramInt >= 0)
      this.r = paramInt; 
    paramInt = c2.d(j.t3, -1);
    if (paramInt >= 0)
      this.s = paramInt; 
    this.o = c2.e(j.j3, -1);
    paramInt = c2.d(j.f3, -2147483648);
    i = c2.d(j.b3, -2147483648);
    j = c2.e(j.d3, 0);
    int k = c2.e(j.e3, 0);
    h();
    this.t.e(j, k);
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.t.g(paramInt, i); 
    this.u = c2.d(j.g3, -2147483648);
    this.v = c2.d(j.c3, -2147483648);
    this.f = c2.f(j.a3);
    this.g = c2.o(j.Z2);
    CharSequence charSequence3 = c2.o(j.r3);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = c2.o(j.o3);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.j = getContext();
    setPopupTheme(c2.m(j.n3, 0));
    Drawable drawable2 = c2.f(j.m3);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = c2.o(j.l3);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = c2.f(j.h3);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = c2.o(j.i3);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = j.z3;
    if (c2.r(paramInt))
      setTitleTextColor(c2.c(paramInt)); 
    paramInt = j.q3;
    if (c2.r(paramInt))
      setSubtitleTextColor(c2.c(paramInt)); 
    paramInt = j.k3;
    if (c2.r(paramInt))
      x(c2.m(paramInt, 0)); 
    c2.v();
  }
  
  private int B(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + i + ((ViewGroup.MarginLayoutParams)e1).rightMargin;
  }
  
  private int C(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  private int D(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int j = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfint[0] = Math.max(0, -i);
    paramArrayOfint[1] = Math.max(0, -j);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + k + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + k;
  }
  
  private void E(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void F() {
    removeCallbacks(this.f0);
    post(this.f0);
  }
  
  private boolean M() {
    if (!this.e0)
      return false; 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (N(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean N(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  private void b(List<View> paramList, int paramInt) {
    int i = t0.q((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = r.a(paramInt, t0.q((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && N(view) && p(e1.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && N(view) && p(e1.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = m();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = o((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.i != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.E.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new j.g(getContext());
  }
  
  private void h() {
    if (this.t == null)
      this.t = new u1(); 
  }
  
  private void i() {
    if (this.e == null)
      this.e = new AppCompatImageView(getContext()); 
  }
  
  private void j() {
    k();
    if (this.a.J() == null) {
      androidx.appcompat.view.menu.e e1 = (androidx.appcompat.view.menu.e)this.a.getMenu();
      if (this.b0 == null)
        this.b0 = new d(this); 
      this.a.setExpandedActionViewsExclusive(true);
      e1.c(this.b0, this.j);
    } 
  }
  
  private void k() {
    if (this.a == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.a = actionMenuView;
      actionMenuView.setPopupTheme(this.k);
      this.a.setOnMenuItemClickListener(this.H);
      this.a.K(this.c0, this.d0);
      e e1 = m();
      e1.a = this.n & 0x70 | 0x800005;
      this.a.setLayoutParams((ViewGroup.LayoutParams)e1);
      c((View)this.a, false);
    } 
  }
  
  private void l() {
    if (this.d == null) {
      this.d = new m(getContext(), null, e.a.K);
      e e1 = m();
      e1.a = this.n & 0x70 | 0x800003;
      this.d.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  private int p(int paramInt) {
    int i = t0.q((View)this);
    int j = r.a(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  private int q(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = r(e1.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - k - m - j) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          j = n - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int r(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.w & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private int s(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return u.b(marginLayoutParams) + u.a(marginLayoutParams);
  }
  
  private int t(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int u(List<View> paramList, int[] paramArrayOfint) {
    int m = paramArrayOfint[0];
    int k = paramArrayOfint[1];
    int n = paramList.size();
    int i = 0;
    int j = 0;
    while (i < n) {
      View view = paramList.get(i);
      e e1 = (e)view.getLayoutParams();
      m = ((ViewGroup.MarginLayoutParams)e1).leftMargin - m;
      k = ((ViewGroup.MarginLayoutParams)e1).rightMargin - k;
      int i1 = Math.max(0, m);
      int i2 = Math.max(0, k);
      m = Math.max(0, -m);
      k = Math.max(0, -k);
      j += i1 + view.getMeasuredWidth() + i2;
      i++;
    } 
    return j;
  }
  
  private boolean y(View paramView) {
    return (paramView.getParent() == this || this.E.contains(paramView));
  }
  
  public boolean A() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.F());
  }
  
  void G() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((e)view.getLayoutParams()).b != 2 && view != this.a) {
        removeViewAt(i);
        this.E.add(view);
      } 
    } 
  }
  
  public void H(int paramInt1, int paramInt2) {
    h();
    this.t.g(paramInt1, paramInt2);
  }
  
  public void I(androidx.appcompat.view.menu.e parame, c paramc) {
    if (parame == null && this.a == null)
      return; 
    k();
    androidx.appcompat.view.menu.e e1 = this.a.J();
    if (e1 == parame)
      return; 
    if (e1 != null) {
      e1.O((j)this.a0);
      e1.O(this.b0);
    } 
    if (this.b0 == null)
      this.b0 = new d(this); 
    paramc.G(true);
    if (parame != null) {
      parame.c((j)paramc, this.j);
      parame.c(this.b0, this.j);
    } else {
      paramc.i(this.j, null);
      this.b0.i(this.j, null);
      paramc.d(true);
      this.b0.d(true);
    } 
    this.a.setPopupTheme(this.k);
    this.a.setPresenter(paramc);
    this.a0 = paramc;
  }
  
  public void J(j.a parama, androidx.appcompat.view.menu.e.a parama1) {
    this.c0 = parama;
    this.d0 = parama1;
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null)
      actionMenuView.K(parama, parama1); 
  }
  
  public void K(Context paramContext, int paramInt) {
    this.m = paramInt;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void L(Context paramContext, int paramInt) {
    this.l = paramInt;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean O() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.L());
  }
  
  void a() {
    for (int i = this.E.size() - 1; i >= 0; i--)
      addView(this.E.get(i)); 
    this.E.clear();
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public boolean d() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.a;
      if (actionMenuView != null && actionMenuView.G())
        return true; 
    } 
    return false;
  }
  
  public void e() {
    androidx.appcompat.view.menu.g g;
    d d1 = this.b0;
    if (d1 == null) {
      d1 = null;
    } else {
      g = d1.b;
    } 
    if (g != null)
      g.collapseActionView(); 
  }
  
  public void f() {
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null)
      actionMenuView.x(); 
  }
  
  void g() {
    if (this.h == null) {
      m m = new m(getContext(), null, e.a.K);
      this.h = m;
      m.setImageDrawable(this.f);
      this.h.setContentDescription(this.g);
      e e1 = m();
      e1.a = this.n & 0x70 | 0x800003;
      e1.b = 2;
      this.h.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.h.setOnClickListener(new c(this));
    } 
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    u1 u11 = this.t;
    return (u11 != null) ? u11.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.v;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    u1 u11 = this.t;
    return (u11 != null) ? u11.b() : 0;
  }
  
  public int getContentInsetRight() {
    u1 u11 = this.t;
    return (u11 != null) ? u11.c() : 0;
  }
  
  public int getContentInsetStart() {
    u1 u11 = this.t;
    return (u11 != null) ? u11.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.u;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual J : ()Landroidx/appcompat/view/menu/e;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield v : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (t0.q((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (t0.q((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.u, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    j();
    return this.a.getMenu();
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  c getOuterActionMenuPresenter() {
    return this.a0;
  }
  
  public Drawable getOverflowIcon() {
    j();
    return this.a.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.j;
  }
  
  public int getPopupTheme() {
    return this.k;
  }
  
  public CharSequence getSubtitle() {
    return this.y;
  }
  
  final TextView getSubtitleTextView() {
    return this.c;
  }
  
  public CharSequence getTitle() {
    return this.x;
  }
  
  public int getTitleMarginBottom() {
    return this.s;
  }
  
  public int getTitleMarginEnd() {
    return this.q;
  }
  
  public int getTitleMarginStart() {
    return this.p;
  }
  
  public int getTitleMarginTop() {
    return this.r;
  }
  
  final TextView getTitleTextView() {
    return this.b;
  }
  
  public d1 getWrapper() {
    if (this.I == null)
      this.I = new d2(this, true); 
    return this.I;
  }
  
  protected e m() {
    return new e(-2, -2);
  }
  
  public e n(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  protected e o(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof androidx.appcompat.app.a.a) ? new e((androidx.appcompat.app.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.f0);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.C = false; 
    if (!this.C) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.C = true; 
    } 
    if (i == 10 || i == 3)
      this.C = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (t0.q((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    int i = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.F;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = t0.r((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (N((View)this.d)) {
      ImageButton imageButton = this.d;
      if (k) {
        j = C((View)imageButton, m, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = B((View)imageButton, i, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      paramInt3 = i;
      j = m;
    } 
    paramInt1 = paramInt3;
    paramInt2 = j;
    if (N((View)this.h)) {
      ImageButton imageButton = this.h;
      if (k) {
        paramInt2 = C((View)imageButton, j, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = B((View)imageButton, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = j;
      } 
    } 
    int j = paramInt1;
    paramInt3 = paramInt2;
    if (N((View)this.a)) {
      ActionMenuView actionMenuView = this.a;
      if (k) {
        j = B((View)actionMenuView, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = C((View)actionMenuView, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      } 
    } 
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - paramInt3);
    paramInt2 = Math.max(j, paramInt2);
    paramInt3 = Math.min(paramInt3, m - paramInt1);
    paramInt1 = paramInt2;
    j = paramInt3;
    if (N(this.i)) {
      View view = this.i;
      if (k) {
        j = C(view, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = B(view, paramInt2, arrayOfInt, paramInt4);
        j = paramInt3;
      } 
    } 
    paramInt3 = paramInt1;
    paramInt2 = j;
    if (N((View)this.e)) {
      ImageView imageView = this.e;
      if (k) {
        paramInt2 = C((View)imageView, j, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = B((View)imageView, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = j;
      } 
    } 
    paramBoolean = N((View)this.b);
    boolean bool = N((View)this.c);
    if (paramBoolean) {
      e e1 = (e)this.b.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin + this.b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.c.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)e1).topMargin + this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.b;
      } else {
        textView1 = this.c;
      } 
      if (bool) {
        textView2 = this.c;
      } else {
        textView2 = this.b;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.b.getMeasuredWidth() > 0) || (bool && this.c.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.w & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i6 = this.r;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i5 = this.s;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.s - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.r;
      } 
      if (k) {
        if (j != 0) {
          k = this.p;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[1];
        paramInt2 -= Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.b.getLayoutParams();
          m = paramInt2 - this.b.getMeasuredWidth();
          k = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(m, paramInt1, paramInt2, k);
          paramInt1 = m - this.q;
          m = k + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.c.getLayoutParams()).topMargin;
          m = this.c.getMeasuredWidth();
          i2 = this.c.getMeasuredHeight();
          this.c.layout(paramInt2 - m, k, paramInt2, i2 + k);
          k = paramInt2 - this.q;
        } else {
          k = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, k); 
        paramInt1 = paramInt3;
      } else {
        if (j != 0) {
          k = this.p;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[0];
        paramInt3 += Math.max(0, k);
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.b.getLayoutParams();
          k = this.b.getMeasuredWidth() + paramInt3;
          m = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(paramInt3, paramInt1, k, m);
          k += this.q;
          paramInt1 = m + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.c.getLayoutParams()).topMargin;
          m = this.c.getMeasuredWidth() + paramInt3;
          i2 = this.c.getMeasuredHeight();
          this.c.layout(paramInt3, paramInt1, m, i2 + paramInt1);
          m += this.q;
        } else {
          m = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (j != 0) {
          paramInt1 = Math.max(k, m);
          paramInt3 = paramInt2;
        } 
        j = i;
        i = 0;
        b(this.D, 3);
        k = this.D.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    j = i;
    i = 0;
    b(this.D, 3);
    int k = this.D.size();
    paramInt2 = 0;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof g)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    g g = (g)paramParcelable;
    super.onRestoreInstanceState(g.a());
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.e e1 = actionMenuView.J();
    } else {
      actionMenuView = null;
    } 
    int i = g.c;
    if (i != 0 && this.b0 != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (g.d)
      F(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    h();
    u1 u11 = this.t;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    u11.f(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    g g = new g(super.onSaveInstanceState());
    d d1 = this.b0;
    if (d1 != null) {
      androidx.appcompat.view.menu.g g1 = d1.b;
      if (g1 != null)
        g.c = g1.getItemId(); 
    } 
    g.d = A();
    return (Parcelable)g;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.B = false; 
    if (!this.B) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.B = true; 
    } 
    if (i == 1 || i == 3)
      this.B = false; 
    return true;
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(g.b.d(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      this.h.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setImageDrawable(this.f); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.e0 = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.v) {
      this.v = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.u) {
      this.u = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(g.b.d(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      i();
      if (!y((View)this.e))
        c((View)this.e, true); 
    } else {
      ImageView imageView1 = this.e;
      if (imageView1 != null && y((View)imageView1)) {
        removeView((View)this.e);
        this.E.remove(this.e);
      } 
    } 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      i(); 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      l(); 
    ImageButton imageButton = this.d;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(g.b.d(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      l();
      if (!y((View)this.d))
        c((View)this.d, true); 
    } else {
      ImageButton imageButton1 = this.d;
      if (imageButton1 != null && y((View)imageButton1)) {
        removeView((View)this.d);
        this.E.remove(this.d);
      } 
    } 
    ImageButton imageButton = this.d;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    l();
    this.d.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.G = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    j();
    this.a.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.k != paramInt) {
      this.k = paramInt;
      if (paramInt == 0) {
        this.j = getContext();
        return;
      } 
      this.j = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.c == null) {
        Context context = getContext();
        m0 m0 = new m0(context);
        this.c = m0;
        m0.setSingleLine();
        this.c.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.m;
        if (i != 0)
          this.c.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.A;
        if (colorStateList != null)
          this.c.setTextColor(colorStateList); 
      } 
      if (!y((View)this.c))
        c((View)this.c, true); 
    } else {
      TextView textView1 = this.c;
      if (textView1 != null && y((View)textView1)) {
        removeView((View)this.c);
        this.E.remove(this.c);
      } 
    } 
    TextView textView = this.c;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.y = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.A = paramColorStateList;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.b == null) {
        Context context = getContext();
        m0 m0 = new m0(context);
        this.b = m0;
        m0.setSingleLine();
        this.b.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.l;
        if (i != 0)
          this.b.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.z;
        if (colorStateList != null)
          this.b.setTextColor(colorStateList); 
      } 
      if (!y((View)this.b))
        c((View)this.b, true); 
    } else {
      TextView textView1 = this.b;
      if (textView1 != null && y((View)textView1)) {
        removeView((View)this.b);
        this.E.remove(this.b);
      } 
    } 
    TextView textView = this.b;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.x = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.s = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.q = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.p = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.r = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.z = paramColorStateList;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public boolean v() {
    d d1 = this.b0;
    return (d1 != null && d1.b != null);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.D());
  }
  
  public void x(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public boolean z() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.E());
  }
  
  class a implements ActionMenuView.e {
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      Toolbar.f f = this.a.G;
      return (f != null) ? f.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    b(Toolbar this$0) {}
    
    public void run() {
      this.a.O();
    }
  }
  
  class c implements View.OnClickListener {
    c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.a.e();
    }
  }
  
  private class d implements j {
    androidx.appcompat.view.menu.e a;
    
    androidx.appcompat.view.menu.g b;
    
    d(Toolbar this$0) {}
    
    public void c(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {}
    
    public void d(boolean param1Boolean) {
      if (this.b != null) {
        androidx.appcompat.view.menu.e e1 = this.a;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (e1 != null) {
          int k = e1.size();
          int i = 0;
          while (true) {
            bool1 = bool2;
            if (i < k) {
              if (this.a.getItem(i) == this.b) {
                bool1 = true;
                break;
              } 
              i++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          f(this.a, this.b); 
      } 
    }
    
    public boolean e() {
      return false;
    }
    
    public boolean f(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      View view = this.c.i;
      if (view instanceof j.c)
        ((j.c)view).onActionViewCollapsed(); 
      Toolbar toolbar = this.c;
      toolbar.removeView(toolbar.i);
      toolbar = this.c;
      toolbar.removeView((View)toolbar.h);
      toolbar = this.c;
      toolbar.i = null;
      toolbar.a();
      this.b = null;
      this.c.requestLayout();
      param1g.r(false);
      return true;
    }
    
    public boolean g(androidx.appcompat.view.menu.e param1e, androidx.appcompat.view.menu.g param1g) {
      this.c.g();
      ViewParent viewParent = this.c.h.getParent();
      Toolbar toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.h); 
        Toolbar toolbar1 = this.c;
        toolbar1.addView((View)toolbar1.h);
      } 
      this.c.i = param1g.getActionView();
      this.b = param1g;
      viewParent = this.c.i.getParent();
      toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.i); 
        Toolbar.e e1 = this.c.m();
        toolbar = this.c;
        e1.a = toolbar.n & 0x70 | 0x800003;
        e1.b = 2;
        toolbar.i.setLayoutParams((ViewGroup.LayoutParams)e1);
        Toolbar toolbar1 = this.c;
        toolbar1.addView(toolbar1.i);
      } 
      this.c.G();
      this.c.requestLayout();
      param1g.r(true);
      View view = this.c.i;
      if (view instanceof j.c)
        ((j.c)view).onActionViewExpanded(); 
      return true;
    }
    
    public void i(Context param1Context, androidx.appcompat.view.menu.e param1e) {
      androidx.appcompat.view.menu.e e1 = this.a;
      if (e1 != null) {
        androidx.appcompat.view.menu.g g1 = this.b;
        if (g1 != null)
          e1.f(g1); 
      } 
      this.a = param1e;
    }
    
    public boolean k(m param1m) {
      return false;
    }
  }
  
  public static class e extends androidx.appcompat.app.a.a {
    int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public e(androidx.appcompat.app.a.a param1a) {
      super(param1a);
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class g extends y.a {
    public static final Parcelable.Creator<g> CREATOR = (Parcelable.Creator<g>)new a();
    
    int c;
    
    boolean d;
    
    public g(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.c = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.d = bool;
    }
    
    public g(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    class a implements Parcelable.ClassLoaderCreator<g> {
      public Toolbar.g a(Parcel param2Parcel) {
        return new Toolbar.g(param2Parcel, null);
      }
      
      public Toolbar.g b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.g(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.g[] c(int param2Int) {
        return new Toolbar.g[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator<g> {
    public Toolbar.g a(Parcel param1Parcel) {
      return new Toolbar.g(param1Parcel, null);
    }
    
    public Toolbar.g b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.g(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.g[] c(int param1Int) {
      return new Toolbar.g[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */