package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;
import androidx.core.view.t0;
import e.j;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

class y0 {
  private static final RectF l = new RectF();
  
  @SuppressLint({"BanConcurrentHashMap"})
  private static ConcurrentHashMap<String, Method> m = new ConcurrentHashMap<String, Method>();
  
  @SuppressLint({"BanConcurrentHashMap"})
  private static ConcurrentHashMap<String, Field> n = new ConcurrentHashMap<String, Field>();
  
  private int a;
  
  private boolean b;
  
  private float c;
  
  private float d;
  
  private float e;
  
  private int[] f;
  
  private boolean g;
  
  private TextPaint h;
  
  private final TextView i;
  
  private final Context j;
  
  private final c k;
  
  y0(TextView paramTextView) {
    c c1;
    this.a = 0;
    this.b = false;
    this.c = -1.0F;
    this.d = -1.0F;
    this.e = -1.0F;
    this.f = new int[0];
    this.g = false;
    this.i = paramTextView;
    this.j = paramTextView.getContext();
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      c1 = new b();
    } else if (i >= 23) {
      c1 = new a();
    } else {
      c1 = new c();
    } 
    this.k = c1;
  }
  
  private boolean A() {
    return this.i instanceof k ^ true;
  }
  
  private void B(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat1 > 0.0F) {
      if (paramFloat2 > paramFloat1) {
        if (paramFloat3 > 0.0F) {
          this.a = 1;
          this.d = paramFloat1;
          this.e = paramFloat2;
          this.c = paramFloat3;
          this.g = false;
          return;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("The auto-size step granularity (");
        stringBuilder2.append(paramFloat3);
        stringBuilder2.append("px) is less or equal to (0px)");
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Maximum auto-size text size (");
      stringBuilder1.append(paramFloat2);
      stringBuilder1.append("px) is less or equal to minimum auto-size text size (");
      stringBuilder1.append(paramFloat1);
      stringBuilder1.append("px)");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Minimum auto-size text size (");
    stringBuilder.append(paramFloat1);
    stringBuilder.append("px) is less or equal to (0px)");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private int[] b(int[] paramArrayOfint) {
    int j = paramArrayOfint.length;
    if (j == 0)
      return paramArrayOfint; 
    Arrays.sort(paramArrayOfint);
    ArrayList<? extends Comparable<? super Integer>> arrayList = new ArrayList();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      int k = paramArrayOfint[i];
      if (k > 0 && Collections.binarySearch(arrayList, Integer.valueOf(k)) < 0)
        arrayList.add(Integer.valueOf(k)); 
    } 
    if (j == arrayList.size())
      return paramArrayOfint; 
    j = arrayList.size();
    paramArrayOfint = new int[j];
    for (i = bool; i < j; i++)
      paramArrayOfint[i] = ((Integer)arrayList.get(i)).intValue(); 
    return paramArrayOfint;
  }
  
  private void c() {
    this.a = 0;
    this.d = -1.0F;
    this.e = -1.0F;
    this.c = -1.0F;
    this.f = new int[0];
    this.b = false;
  }
  
  private StaticLayout e(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt1, int paramInt2) {
    StaticLayout.Builder builder1 = n0.a(paramCharSequence, 0, paramCharSequence.length(), this.h, paramInt1);
    StaticLayout.Builder builder2 = u0.a(s0.a(q0.a(p0.a(o0.a(builder1, paramAlignment), this.i.getLineSpacingExtra(), this.i.getLineSpacingMultiplier()), this.i.getIncludeFontPadding()), r0.a(this.i)), t0.a(this.i));
    paramInt1 = paramInt2;
    if (paramInt2 == -1)
      paramInt1 = Integer.MAX_VALUE; 
    v0.a(builder2, paramInt1);
    try {
      this.k.a(builder1, this.i);
    } catch (ClassCastException classCastException) {
      Log.w("ACTVAutoSizeHelper", "Failed to obtain TextDirectionHeuristic, auto size may be incorrect");
    } 
    return w0.a(builder1);
  }
  
  private StaticLayout f(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt) {
    float f1 = this.i.getLineSpacingMultiplier();
    float f2 = this.i.getLineSpacingExtra();
    boolean bool = this.i.getIncludeFontPadding();
    return new StaticLayout(paramCharSequence, this.h, paramInt, paramAlignment, f1, f2, bool);
  }
  
  private int g(RectF paramRectF) {
    int i = this.f.length;
    if (i != 0) {
      int j = 1;
      int k = i - 1;
      i = 0;
      while (j <= k) {
        int m = (j + k) / 2;
        if (z(this.f[m], paramRectF)) {
          i = j;
          j = m + 1;
          continue;
        } 
        i = m - 1;
        k = i;
      } 
      return this.f[i];
    } 
    throw new IllegalStateException("No available text sizes to choose from.");
  }
  
  private static Method m(String paramString) {
    try {
      Method method2 = m.get(paramString);
      Method method1 = method2;
      if (method2 == null) {
        method2 = TextView.class.getDeclaredMethod(paramString, new Class[0]);
        method1 = method2;
        if (method2 != null) {
          method2.setAccessible(true);
          m.put(paramString, method2);
          method1 = method2;
        } 
      } 
      return method1;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to retrieve TextView#");
      stringBuilder.append(paramString);
      stringBuilder.append("() method");
      Log.w("ACTVAutoSizeHelper", stringBuilder.toString(), exception);
      return null;
    } 
  }
  
  static <T> T o(Object paramObject, String paramString, T paramT) {
    try {
      return (T)m(paramString).invoke(paramObject, new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to invoke TextView#");
      stringBuilder.append(paramString);
      stringBuilder.append("() method");
      Log.w("ACTVAutoSizeHelper", stringBuilder.toString(), exception);
      return paramT;
    } finally {}
    throw paramObject;
  }
  
  private void u(float paramFloat) {
    if (paramFloat != this.i.getPaint().getTextSize()) {
      this.i.getPaint().setTextSize(paramFloat);
      boolean bool = this.i.isInLayout();
      if (this.i.getLayout() != null) {
        this.b = false;
        try {
          Method method = m("nullLayouts");
          if (method != null)
            method.invoke(this.i, new Object[0]); 
        } catch (Exception exception) {
          Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", exception);
        } 
        if (!bool) {
          this.i.requestLayout();
        } else {
          this.i.forceLayout();
        } 
        this.i.invalidate();
      } 
    } 
  }
  
  private boolean w() {
    boolean bool = A();
    int i = 0;
    if (bool && this.a == 1) {
      if (!this.g || this.f.length == 0) {
        int j = (int)Math.floor(((this.e - this.d) / this.c)) + 1;
        int[] arrayOfInt = new int[j];
        while (i < j) {
          arrayOfInt[i] = Math.round(this.d + i * this.c);
          i++;
        } 
        this.f = b(arrayOfInt);
      } 
      this.b = true;
    } else {
      this.b = false;
    } 
    return this.b;
  }
  
  private void x(TypedArray paramTypedArray) {
    int i = paramTypedArray.length();
    int[] arrayOfInt = new int[i];
    if (i > 0) {
      for (int j = 0; j < i; j++)
        arrayOfInt[j] = paramTypedArray.getDimensionPixelSize(j, -1); 
      this.f = b(arrayOfInt);
      y();
    } 
  }
  
  private boolean y() {
    boolean bool;
    int[] arrayOfInt = this.f;
    int i = arrayOfInt.length;
    if (i > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.g = bool;
    if (bool) {
      this.a = 1;
      this.d = arrayOfInt[0];
      this.e = arrayOfInt[i - 1];
      this.c = -1.0F;
    } 
    return bool;
  }
  
  private boolean z(int paramInt, RectF paramRectF) {
    CharSequence charSequence2 = this.i.getText();
    TransformationMethod transformationMethod = this.i.getTransformationMethod();
    CharSequence charSequence1 = charSequence2;
    if (transformationMethod != null) {
      CharSequence charSequence = transformationMethod.getTransformation(charSequence2, (View)this.i);
      charSequence1 = charSequence2;
      if (charSequence != null)
        charSequence1 = charSequence; 
    } 
    int i = this.i.getMaxLines();
    n(paramInt);
    StaticLayout staticLayout = d(charSequence1, o(this.i, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL), Math.round(paramRectF.right), i);
    return (i != -1 && (staticLayout.getLineCount() > i || staticLayout.getLineEnd(staticLayout.getLineCount() - 1) != charSequence1.length())) ? false : (!(staticLayout.getHeight() > paramRectF.bottom));
  }
  
  void a() {
    if (!p())
      return; 
    if (this.b)
      if (this.i.getMeasuredHeight() > 0) {
        int i;
        if (this.i.getMeasuredWidth() <= 0)
          return; 
        if (this.k.b(this.i)) {
          i = 1048576;
        } else {
          i = this.i.getMeasuredWidth() - this.i.getTotalPaddingLeft() - this.i.getTotalPaddingRight();
        } 
        int j = this.i.getHeight() - this.i.getCompoundPaddingBottom() - this.i.getCompoundPaddingTop();
        if (i > 0) {
          if (j <= 0)
            return; 
          synchronized (l) {
            null.setEmpty();
            null.right = i;
            null.bottom = j;
            float f = g(null);
            if (f != this.i.getTextSize())
              v(0, f); 
          } 
        } else {
          return;
        } 
      } else {
        return;
      }  
    this.b = true;
  }
  
  StaticLayout d(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt1, int paramInt2) {
    return (Build.VERSION.SDK_INT >= 23) ? e(paramCharSequence, paramAlignment, paramInt1, paramInt2) : f(paramCharSequence, paramAlignment, paramInt1);
  }
  
  int h() {
    return Math.round(this.e);
  }
  
  int i() {
    return Math.round(this.d);
  }
  
  int j() {
    return Math.round(this.c);
  }
  
  int[] k() {
    return this.f;
  }
  
  int l() {
    return this.a;
  }
  
  void n(int paramInt) {
    TextPaint textPaint = this.h;
    if (textPaint == null) {
      this.h = new TextPaint();
    } else {
      textPaint.reset();
    } 
    this.h.set(this.i.getPaint());
    this.h.setTextSize(paramInt);
  }
  
  boolean p() {
    return (A() && this.a != 0);
  }
  
  void q(AttributeSet paramAttributeSet, int paramInt) {
    float f1;
    float f2;
    float f3;
    Context context = this.j;
    int[] arrayOfInt = j.i0;
    TypedArray typedArray = context.obtainStyledAttributes(paramAttributeSet, arrayOfInt, paramInt, 0);
    TextView textView = this.i;
    t0.M((View)textView, textView.getContext(), arrayOfInt, paramAttributeSet, typedArray, paramInt, 0);
    paramInt = j.n0;
    if (typedArray.hasValue(paramInt))
      this.a = typedArray.getInt(paramInt, 0); 
    paramInt = j.m0;
    if (typedArray.hasValue(paramInt)) {
      f1 = typedArray.getDimension(paramInt, -1.0F);
    } else {
      f1 = -1.0F;
    } 
    paramInt = j.k0;
    if (typedArray.hasValue(paramInt)) {
      f2 = typedArray.getDimension(paramInt, -1.0F);
    } else {
      f2 = -1.0F;
    } 
    paramInt = j.j0;
    if (typedArray.hasValue(paramInt)) {
      f3 = typedArray.getDimension(paramInt, -1.0F);
    } else {
      f3 = -1.0F;
    } 
    paramInt = j.l0;
    if (typedArray.hasValue(paramInt)) {
      paramInt = typedArray.getResourceId(paramInt, 0);
      if (paramInt > 0) {
        TypedArray typedArray1 = typedArray.getResources().obtainTypedArray(paramInt);
        x(typedArray1);
        typedArray1.recycle();
      } 
    } 
    typedArray.recycle();
    if (A()) {
      if (this.a == 1) {
        if (!this.g) {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          float f = f2;
          if (f2 == -1.0F)
            f = TypedValue.applyDimension(2, 12.0F, displayMetrics); 
          f2 = f3;
          if (f3 == -1.0F)
            f2 = TypedValue.applyDimension(2, 112.0F, displayMetrics); 
          f3 = f1;
          if (f1 == -1.0F)
            f3 = 1.0F; 
          B(f, f2, f3);
        } 
        w();
        return;
      } 
    } else {
      this.a = 0;
    } 
  }
  
  void r(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (A()) {
      DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
      B(TypedValue.applyDimension(paramInt4, paramInt1, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt2, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt3, displayMetrics));
      if (w())
        a(); 
    } 
  }
  
  void s(int[] paramArrayOfint, int paramInt) {
    if (A()) {
      int j = paramArrayOfint.length;
      int i = 0;
      if (j > 0) {
        int[] arrayOfInt1;
        int[] arrayOfInt2 = new int[j];
        if (paramInt == 0) {
          arrayOfInt1 = Arrays.copyOf(paramArrayOfint, j);
        } else {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          while (true) {
            arrayOfInt1 = arrayOfInt2;
            if (i < j) {
              arrayOfInt2[i] = Math.round(TypedValue.applyDimension(paramInt, paramArrayOfint[i], displayMetrics));
              i++;
              continue;
            } 
            break;
          } 
        } 
        this.f = b(arrayOfInt1);
        if (!y()) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("None of the preset sizes is valid: ");
          stringBuilder.append(Arrays.toString(paramArrayOfint));
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        this.g = false;
      } 
      if (w())
        a(); 
    } 
  }
  
  void t(int paramInt) {
    if (A())
      if (paramInt != 0) {
        if (paramInt == 1) {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          B(TypedValue.applyDimension(2, 12.0F, displayMetrics), TypedValue.applyDimension(2, 112.0F, displayMetrics), 1.0F);
          if (w()) {
            a();
            return;
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown auto-size text type: ");
          stringBuilder.append(paramInt);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        c();
      }  
  }
  
  void v(int paramInt, float paramFloat) {
    Resources resources;
    Context context = this.j;
    if (context == null) {
      resources = Resources.getSystem();
    } else {
      resources = resources.getResources();
    } 
    u(TypedValue.applyDimension(paramInt, paramFloat, resources.getDisplayMetrics()));
  }
  
  private static class a extends c {
    void a(StaticLayout.Builder param1Builder, TextView param1TextView) {
      x0.a(param1Builder, y0.<TextDirectionHeuristic>o(param1TextView, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR));
    }
  }
  
  private static class b extends a {
    void a(StaticLayout.Builder param1Builder, TextView param1TextView) {
      x0.a(param1Builder, a1.a(param1TextView));
    }
    
    boolean b(TextView param1TextView) {
      return z0.a(param1TextView);
    }
  }
  
  private static class c {
    void a(StaticLayout.Builder param1Builder, TextView param1TextView) {}
    
    boolean b(TextView param1TextView) {
      return ((Boolean)y0.<Boolean>o(param1TextView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */