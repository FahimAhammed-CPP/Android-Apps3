package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import androidx.core.view.r;
import androidx.core.view.t0;
import e.j;

public class i1 extends ViewGroup {
  private boolean a = true;
  
  private int b = -1;
  
  private int c = 0;
  
  private int d;
  
  private int e = 8388659;
  
  private int f;
  
  private float g;
  
  private boolean h;
  
  private int[] i;
  
  private int[] j;
  
  private Drawable k;
  
  private int l;
  
  private int m;
  
  private int n;
  
  private int o;
  
  public i1(Context paramContext) {
    this(paramContext, null);
  }
  
  public i1(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public i1(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    int[] arrayOfInt = j.d1;
    c2 c2 = c2.u(paramContext, paramAttributeSet, arrayOfInt, paramInt, 0);
    t0.M((View)this, paramContext, arrayOfInt, paramAttributeSet, c2.q(), paramInt, 0);
    paramInt = c2.j(j.f1, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = c2.j(j.e1, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = c2.a(j.g1, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.g = c2.h(j.i1, -1.0F);
    this.b = c2.j(j.h1, -1);
    this.h = c2.a(j.l1, false);
    setDividerDrawable(c2.f(j.j1));
    this.n = c2.j(j.m1, 0);
    this.o = c2.e(j.k1, 0);
    c2.v();
  }
  
  private void g(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = o(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.height == -1) {
          int k = a.width;
          a.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          a.width = k;
        } 
      } 
    } 
  }
  
  private void h(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = o(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.width == -1) {
          int k = a.height;
          a.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          a.height = k;
        } 
      } 
    } 
  }
  
  private void w(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  void c(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = j2.b((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = o(i);
      if (view != null && view.getVisibility() != 8 && p(i)) {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + a.rightMargin;
        } else {
          k = view.getLeft() - a.leftMargin - this.l;
        } 
        f(paramCanvas, k);
      } 
    } 
    if (p(j)) {
      View view = o(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth();
          int k = getPaddingRight();
          i = i - k - this.l;
        } 
      } else {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          i = view.getLeft();
          k = a.leftMargin;
        } else {
          i = view.getRight() + a.rightMargin;
          f(paramCanvas, i);
        } 
        i = i - k - this.l;
      } 
    } else {
      return;
    } 
    f(paramCanvas, i);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  void d(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = o(i);
      if (view != null && view.getVisibility() != 8 && p(i)) {
        a a = (a)view.getLayoutParams();
        e(paramCanvas, view.getTop() - a.topMargin - this.m);
      } 
    } 
    if (p(j)) {
      View view = o(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.m;
      } else {
        a a = (a)view.getLayoutParams();
        i = view.getBottom() + a.bottomMargin;
      } 
      e(paramCanvas, i);
    } 
  }
  
  void e(Canvas paramCanvas, int paramInt) {
    this.k.setBounds(getPaddingLeft() + this.o, paramInt, getWidth() - getPaddingRight() - this.o, this.m + paramInt);
    this.k.draw(paramCanvas);
  }
  
  void f(Canvas paramCanvas, int paramInt) {
    this.k.setBounds(paramInt, getPaddingTop() + this.o, this.l + paramInt, getHeight() - getPaddingBottom() - this.o);
    this.k.draw(paramCanvas);
  }
  
  public int getBaseline() {
    if (this.b < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.b;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.b == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.c;
      i = j;
      if (this.d == 1) {
        int m = this.e & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.f;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.f) / 2;
          }  
      } 
      return i + ((a)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.b;
  }
  
  public Drawable getDividerDrawable() {
    return this.k;
  }
  
  public int getDividerPadding() {
    return this.o;
  }
  
  public int getDividerWidth() {
    return this.l;
  }
  
  public int getGravity() {
    return this.e;
  }
  
  public int getOrientation() {
    return this.d;
  }
  
  public int getShowDividers() {
    return this.n;
  }
  
  int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.g;
  }
  
  protected a i() {
    int i = this.d;
    return (i == 0) ? new a(-2, -2) : ((i == 1) ? new a(-1, -2) : null);
  }
  
  public a j(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  protected a k(ViewGroup.LayoutParams paramLayoutParams) {
    return new a(paramLayoutParams);
  }
  
  int l(View paramView, int paramInt) {
    return 0;
  }
  
  int m(View paramView) {
    return 0;
  }
  
  int n(View paramView) {
    return 0;
  }
  
  View o(int paramInt) {
    return getChildAt(paramInt);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.k == null)
      return; 
    if (this.d == 1) {
      d(paramCanvas);
      return;
    } 
    c(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.d == 1) {
      r(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    q(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.d == 1) {
      v(paramInt1, paramInt2);
      return;
    } 
    t(paramInt1, paramInt2);
  }
  
  protected boolean p(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.n & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.n & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.n & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  void q(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = j2.b((View)this);
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2;
    int n = getPaddingBottom();
    int i2 = getPaddingBottom();
    int j = getVirtualChildCount();
    paramInt2 = this.e;
    paramInt4 = paramInt2 & 0x70;
    boolean bool2 = this.a;
    int[] arrayOfInt1 = this.i;
    int[] arrayOfInt2 = this.j;
    paramInt2 = r.a(0x800007 & paramInt2, t0.q((View)this));
    if (paramInt2 != 1) {
      if (paramInt2 != 5) {
        paramInt2 = getPaddingLeft();
      } else {
        paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.f;
      } 
    } else {
      paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.f) / 2;
    } 
    if (bool1) {
      b1 = j - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    int i = 0;
    paramInt3 = paramInt4;
    paramInt4 = k;
    while (i < j) {
      int i3 = b1 + b2 * i;
      View view = o(i3);
      if (view == null) {
        paramInt2 += u(i3);
      } else if (view.getVisibility() != 8) {
        int i6 = view.getMeasuredWidth();
        int i7 = view.getMeasuredHeight();
        a a = (a)view.getLayoutParams();
        if (bool2 && a.height != -1) {
          i4 = view.getBaseline();
        } else {
          i4 = -1;
        } 
        int i5 = a.gravity;
        paramInt1 = i5;
        if (i5 < 0)
          paramInt1 = paramInt3; 
        paramInt1 &= 0x70;
        if (paramInt1 != 16) {
          if (paramInt1 != 48) {
            if (paramInt1 != 80) {
              paramInt1 = paramInt4;
            } else {
              i5 = m - n - i7 - a.bottomMargin;
              paramInt1 = i5;
              if (i4 != -1) {
                paramInt1 = view.getMeasuredHeight();
                paramInt1 = i5 - arrayOfInt2[2] - paramInt1 - i4;
              } 
            } 
          } else {
            i5 = a.topMargin + paramInt4;
            paramInt1 = i5;
            if (i4 != -1)
              paramInt1 = i5 + arrayOfInt1[1] - i4; 
          } 
        } else {
          paramInt1 = (m - k - i2 - i7) / 2 + paramInt4 + a.topMargin - a.bottomMargin;
        } 
        int i4 = paramInt2;
        if (p(i3))
          i4 = paramInt2 + this.l; 
        paramInt2 = a.leftMargin + i4;
        w(view, paramInt2 + m(view), paramInt1, i6, i7);
        paramInt1 = a.rightMargin;
        i4 = n(view);
        i += l(view, i3);
        paramInt2 += i6 + paramInt1 + i4;
      } 
      i++;
    } 
  }
  
  void r(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i2 = this.e;
    paramInt1 = i2 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.f;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.f) / 2;
    } 
    paramInt2 = 0;
    while (paramInt2 < n) {
      View view = o(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + u(paramInt2);
        paramInt4 = paramInt2;
      } else {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (view.getVisibility() != 8) {
          int i4 = view.getMeasuredWidth();
          int i3 = view.getMeasuredHeight();
          a a = (a)view.getLayoutParams();
          paramInt4 = a.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i2 & 0x800007; 
          paramInt3 = r.a(paramInt3, t0.q((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = a.leftMargin + i;
            } else {
              paramInt3 = j - k - i4;
              paramInt3 -= a.rightMargin;
            } 
          } else {
            paramInt3 = (j - i - m - i4) / 2 + i + a.leftMargin;
            paramInt3 -= a.rightMargin;
          } 
          paramInt4 = paramInt1;
          if (p(paramInt2))
            paramInt4 = paramInt1 + this.m; 
          paramInt1 = paramInt4 + a.topMargin;
          w(view, paramInt3, paramInt1 + m(view), i4, i3);
          paramInt3 = a.bottomMargin;
          i4 = n(view);
          paramInt4 = paramInt2 + l(view, paramInt2);
          paramInt3 = paramInt1 + i3 + paramInt3 + i4;
        } 
      } 
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    } 
  }
  
  void s(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.b = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.k)
      return; 
    this.k = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.l = paramDrawable.getIntrinsicWidth();
      this.m = paramDrawable.getIntrinsicHeight();
    } else {
      this.l = 0;
      this.m = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.o = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.e != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.e = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.e;
    if ((0x800007 & i) != paramInt) {
      this.e = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.d != paramInt) {
      this.d = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.n)
      requestLayout(); 
    this.n = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.e;
    if ((i & 0x70) != paramInt) {
      this.e = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.g = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  void t(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield f : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #22
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #21
    //   23: aload_0
    //   24: getfield i : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield j : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield i : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield j : [I
    //   51: aload_0
    //   52: getfield i : [I
    //   55: astore #28
    //   57: aload_0
    //   58: getfield j : [I
    //   61: astore #26
    //   63: aload #28
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #28
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #28
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #28
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #26
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #26
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #26
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #26
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield a : Z
    //   107: istore #24
    //   109: aload_0
    //   110: getfield h : Z
    //   113: istore #25
    //   115: iload #22
    //   117: ldc 1073741824
    //   119: if_icmpne -> 128
    //   122: iconst_1
    //   123: istore #15
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #15
    //   131: fconst_0
    //   132: fstore_3
    //   133: iconst_0
    //   134: istore #8
    //   136: iconst_0
    //   137: istore #7
    //   139: iconst_0
    //   140: istore #13
    //   142: iconst_0
    //   143: istore #6
    //   145: iconst_0
    //   146: istore #11
    //   148: iconst_0
    //   149: istore #12
    //   151: iconst_0
    //   152: istore #9
    //   154: iconst_1
    //   155: istore #5
    //   157: iconst_0
    //   158: istore #10
    //   160: iload #8
    //   162: iload #16
    //   164: if_icmpge -> 847
    //   167: aload_0
    //   168: iload #8
    //   170: invokevirtual o : (I)Landroid/view/View;
    //   173: astore #27
    //   175: aload #27
    //   177: ifnonnull -> 198
    //   180: aload_0
    //   181: aload_0
    //   182: getfield f : I
    //   185: aload_0
    //   186: iload #8
    //   188: invokevirtual u : (I)I
    //   191: iadd
    //   192: putfield f : I
    //   195: goto -> 838
    //   198: aload #27
    //   200: invokevirtual getVisibility : ()I
    //   203: bipush #8
    //   205: if_icmpne -> 224
    //   208: iload #8
    //   210: aload_0
    //   211: aload #27
    //   213: iload #8
    //   215: invokevirtual l : (Landroid/view/View;I)I
    //   218: iadd
    //   219: istore #8
    //   221: goto -> 195
    //   224: aload_0
    //   225: iload #8
    //   227: invokevirtual p : (I)Z
    //   230: ifeq -> 246
    //   233: aload_0
    //   234: aload_0
    //   235: getfield f : I
    //   238: aload_0
    //   239: getfield l : I
    //   242: iadd
    //   243: putfield f : I
    //   246: aload #27
    //   248: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   251: checkcast androidx/appcompat/widget/i1$a
    //   254: astore #29
    //   256: aload #29
    //   258: getfield weight : F
    //   261: fstore #4
    //   263: fload_3
    //   264: fload #4
    //   266: fadd
    //   267: fstore_3
    //   268: iload #22
    //   270: ldc 1073741824
    //   272: if_icmpne -> 381
    //   275: aload #29
    //   277: getfield width : I
    //   280: ifne -> 381
    //   283: fload #4
    //   285: fconst_0
    //   286: fcmpl
    //   287: ifle -> 381
    //   290: aload_0
    //   291: getfield f : I
    //   294: istore #14
    //   296: iload #15
    //   298: ifeq -> 320
    //   301: iload #14
    //   303: aload #29
    //   305: getfield leftMargin : I
    //   308: aload #29
    //   310: getfield rightMargin : I
    //   313: iadd
    //   314: iadd
    //   315: istore #14
    //   317: goto -> 341
    //   320: iload #14
    //   322: aload #29
    //   324: getfield leftMargin : I
    //   327: iload #14
    //   329: iadd
    //   330: aload #29
    //   332: getfield rightMargin : I
    //   335: iadd
    //   336: invokestatic max : (II)I
    //   339: istore #14
    //   341: aload_0
    //   342: iload #14
    //   344: putfield f : I
    //   347: iload #24
    //   349: ifeq -> 375
    //   352: iconst_0
    //   353: iconst_0
    //   354: invokestatic makeMeasureSpec : (II)I
    //   357: istore #14
    //   359: aload #27
    //   361: iload #14
    //   363: iload #14
    //   365: invokevirtual measure : (II)V
    //   368: iload #7
    //   370: istore #14
    //   372: goto -> 564
    //   375: iconst_1
    //   376: istore #12
    //   378: goto -> 568
    //   381: aload #29
    //   383: getfield width : I
    //   386: ifne -> 409
    //   389: fload #4
    //   391: fconst_0
    //   392: fcmpl
    //   393: ifle -> 409
    //   396: aload #29
    //   398: bipush #-2
    //   400: putfield width : I
    //   403: iconst_0
    //   404: istore #14
    //   406: goto -> 414
    //   409: ldc_w -2147483648
    //   412: istore #14
    //   414: fload_3
    //   415: fconst_0
    //   416: fcmpl
    //   417: ifne -> 429
    //   420: aload_0
    //   421: getfield f : I
    //   424: istore #17
    //   426: goto -> 432
    //   429: iconst_0
    //   430: istore #17
    //   432: aload_0
    //   433: aload #27
    //   435: iload #8
    //   437: iload_1
    //   438: iload #17
    //   440: iload_2
    //   441: iconst_0
    //   442: invokevirtual s : (Landroid/view/View;IIIII)V
    //   445: iload #14
    //   447: ldc_w -2147483648
    //   450: if_icmpeq -> 460
    //   453: aload #29
    //   455: iload #14
    //   457: putfield width : I
    //   460: aload #27
    //   462: invokevirtual getMeasuredWidth : ()I
    //   465: istore #17
    //   467: iload #15
    //   469: ifeq -> 503
    //   472: aload_0
    //   473: getfield f : I
    //   476: aload #29
    //   478: getfield leftMargin : I
    //   481: iload #17
    //   483: iadd
    //   484: aload #29
    //   486: getfield rightMargin : I
    //   489: iadd
    //   490: aload_0
    //   491: aload #27
    //   493: invokevirtual n : (Landroid/view/View;)I
    //   496: iadd
    //   497: iadd
    //   498: istore #14
    //   500: goto -> 540
    //   503: aload_0
    //   504: getfield f : I
    //   507: istore #14
    //   509: iload #14
    //   511: iload #14
    //   513: iload #17
    //   515: iadd
    //   516: aload #29
    //   518: getfield leftMargin : I
    //   521: iadd
    //   522: aload #29
    //   524: getfield rightMargin : I
    //   527: iadd
    //   528: aload_0
    //   529: aload #27
    //   531: invokevirtual n : (Landroid/view/View;)I
    //   534: iadd
    //   535: invokestatic max : (II)I
    //   538: istore #14
    //   540: aload_0
    //   541: iload #14
    //   543: putfield f : I
    //   546: iload #7
    //   548: istore #14
    //   550: iload #25
    //   552: ifeq -> 564
    //   555: iload #17
    //   557: iload #7
    //   559: invokestatic max : (II)I
    //   562: istore #14
    //   564: iload #14
    //   566: istore #7
    //   568: iload #8
    //   570: istore #18
    //   572: iload #21
    //   574: ldc 1073741824
    //   576: if_icmpeq -> 597
    //   579: aload #29
    //   581: getfield height : I
    //   584: iconst_m1
    //   585: if_icmpne -> 597
    //   588: iconst_1
    //   589: istore #8
    //   591: iconst_1
    //   592: istore #10
    //   594: goto -> 600
    //   597: iconst_0
    //   598: istore #8
    //   600: aload #29
    //   602: getfield topMargin : I
    //   605: aload #29
    //   607: getfield bottomMargin : I
    //   610: iadd
    //   611: istore #14
    //   613: aload #27
    //   615: invokevirtual getMeasuredHeight : ()I
    //   618: iload #14
    //   620: iadd
    //   621: istore #17
    //   623: iload #9
    //   625: aload #27
    //   627: invokevirtual getMeasuredState : ()I
    //   630: invokestatic combineMeasuredStates : (II)I
    //   633: istore #19
    //   635: iload #24
    //   637: ifeq -> 722
    //   640: aload #27
    //   642: invokevirtual getBaseline : ()I
    //   645: istore #23
    //   647: iload #23
    //   649: iconst_m1
    //   650: if_icmpeq -> 722
    //   653: aload #29
    //   655: getfield gravity : I
    //   658: istore #20
    //   660: iload #20
    //   662: istore #9
    //   664: iload #20
    //   666: ifge -> 675
    //   669: aload_0
    //   670: getfield e : I
    //   673: istore #9
    //   675: iload #9
    //   677: bipush #112
    //   679: iand
    //   680: iconst_4
    //   681: ishr
    //   682: bipush #-2
    //   684: iand
    //   685: iconst_1
    //   686: ishr
    //   687: istore #9
    //   689: aload #28
    //   691: iload #9
    //   693: aload #28
    //   695: iload #9
    //   697: iaload
    //   698: iload #23
    //   700: invokestatic max : (II)I
    //   703: iastore
    //   704: aload #26
    //   706: iload #9
    //   708: aload #26
    //   710: iload #9
    //   712: iaload
    //   713: iload #17
    //   715: iload #23
    //   717: isub
    //   718: invokestatic max : (II)I
    //   721: iastore
    //   722: iload #13
    //   724: iload #17
    //   726: invokestatic max : (II)I
    //   729: istore #13
    //   731: iload #5
    //   733: ifeq -> 751
    //   736: aload #29
    //   738: getfield height : I
    //   741: iconst_m1
    //   742: if_icmpne -> 751
    //   745: iconst_1
    //   746: istore #5
    //   748: goto -> 754
    //   751: iconst_0
    //   752: istore #5
    //   754: aload #29
    //   756: getfield weight : F
    //   759: fconst_0
    //   760: fcmpl
    //   761: ifle -> 788
    //   764: iload #8
    //   766: ifeq -> 772
    //   769: goto -> 776
    //   772: iload #17
    //   774: istore #14
    //   776: iload #11
    //   778: iload #14
    //   780: invokestatic max : (II)I
    //   783: istore #8
    //   785: goto -> 813
    //   788: iload #8
    //   790: ifeq -> 796
    //   793: goto -> 800
    //   796: iload #17
    //   798: istore #14
    //   800: iload #6
    //   802: iload #14
    //   804: invokestatic max : (II)I
    //   807: istore #6
    //   809: iload #11
    //   811: istore #8
    //   813: aload_0
    //   814: aload #27
    //   816: iload #18
    //   818: invokevirtual l : (Landroid/view/View;I)I
    //   821: iload #18
    //   823: iadd
    //   824: istore #14
    //   826: iload #19
    //   828: istore #9
    //   830: iload #8
    //   832: istore #11
    //   834: iload #14
    //   836: istore #8
    //   838: iload #8
    //   840: iconst_1
    //   841: iadd
    //   842: istore #8
    //   844: goto -> 160
    //   847: aload_0
    //   848: getfield f : I
    //   851: ifle -> 876
    //   854: aload_0
    //   855: iload #16
    //   857: invokevirtual p : (I)Z
    //   860: ifeq -> 876
    //   863: aload_0
    //   864: aload_0
    //   865: getfield f : I
    //   868: aload_0
    //   869: getfield l : I
    //   872: iadd
    //   873: putfield f : I
    //   876: aload #28
    //   878: iconst_1
    //   879: iaload
    //   880: istore #8
    //   882: iload #8
    //   884: iconst_m1
    //   885: if_icmpne -> 922
    //   888: aload #28
    //   890: iconst_0
    //   891: iaload
    //   892: iconst_m1
    //   893: if_icmpne -> 922
    //   896: aload #28
    //   898: iconst_2
    //   899: iaload
    //   900: iconst_m1
    //   901: if_icmpne -> 922
    //   904: aload #28
    //   906: iconst_3
    //   907: iaload
    //   908: iconst_m1
    //   909: if_icmpeq -> 915
    //   912: goto -> 922
    //   915: iload #13
    //   917: istore #8
    //   919: goto -> 978
    //   922: iload #13
    //   924: aload #28
    //   926: iconst_3
    //   927: iaload
    //   928: aload #28
    //   930: iconst_0
    //   931: iaload
    //   932: iload #8
    //   934: aload #28
    //   936: iconst_2
    //   937: iaload
    //   938: invokestatic max : (II)I
    //   941: invokestatic max : (II)I
    //   944: invokestatic max : (II)I
    //   947: aload #26
    //   949: iconst_3
    //   950: iaload
    //   951: aload #26
    //   953: iconst_0
    //   954: iaload
    //   955: aload #26
    //   957: iconst_1
    //   958: iaload
    //   959: aload #26
    //   961: iconst_2
    //   962: iaload
    //   963: invokestatic max : (II)I
    //   966: invokestatic max : (II)I
    //   969: invokestatic max : (II)I
    //   972: iadd
    //   973: invokestatic max : (II)I
    //   976: istore #8
    //   978: iload #9
    //   980: istore #13
    //   982: iload #8
    //   984: istore #14
    //   986: iload #25
    //   988: ifeq -> 1178
    //   991: iload #22
    //   993: ldc_w -2147483648
    //   996: if_icmpeq -> 1008
    //   999: iload #8
    //   1001: istore #14
    //   1003: iload #22
    //   1005: ifne -> 1178
    //   1008: aload_0
    //   1009: iconst_0
    //   1010: putfield f : I
    //   1013: iconst_0
    //   1014: istore #9
    //   1016: iload #8
    //   1018: istore #14
    //   1020: iload #9
    //   1022: iload #16
    //   1024: if_icmpge -> 1178
    //   1027: aload_0
    //   1028: iload #9
    //   1030: invokevirtual o : (I)Landroid/view/View;
    //   1033: astore #27
    //   1035: aload #27
    //   1037: ifnonnull -> 1058
    //   1040: aload_0
    //   1041: aload_0
    //   1042: getfield f : I
    //   1045: aload_0
    //   1046: iload #9
    //   1048: invokevirtual u : (I)I
    //   1051: iadd
    //   1052: putfield f : I
    //   1055: goto -> 1081
    //   1058: aload #27
    //   1060: invokevirtual getVisibility : ()I
    //   1063: bipush #8
    //   1065: if_icmpne -> 1084
    //   1068: iload #9
    //   1070: aload_0
    //   1071: aload #27
    //   1073: iload #9
    //   1075: invokevirtual l : (Landroid/view/View;I)I
    //   1078: iadd
    //   1079: istore #9
    //   1081: goto -> 1169
    //   1084: aload #27
    //   1086: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1089: checkcast androidx/appcompat/widget/i1$a
    //   1092: astore #29
    //   1094: aload_0
    //   1095: getfield f : I
    //   1098: istore #14
    //   1100: iload #15
    //   1102: ifeq -> 1136
    //   1105: aload_0
    //   1106: iload #14
    //   1108: aload #29
    //   1110: getfield leftMargin : I
    //   1113: iload #7
    //   1115: iadd
    //   1116: aload #29
    //   1118: getfield rightMargin : I
    //   1121: iadd
    //   1122: aload_0
    //   1123: aload #27
    //   1125: invokevirtual n : (Landroid/view/View;)I
    //   1128: iadd
    //   1129: iadd
    //   1130: putfield f : I
    //   1133: goto -> 1081
    //   1136: aload_0
    //   1137: iload #14
    //   1139: iload #14
    //   1141: iload #7
    //   1143: iadd
    //   1144: aload #29
    //   1146: getfield leftMargin : I
    //   1149: iadd
    //   1150: aload #29
    //   1152: getfield rightMargin : I
    //   1155: iadd
    //   1156: aload_0
    //   1157: aload #27
    //   1159: invokevirtual n : (Landroid/view/View;)I
    //   1162: iadd
    //   1163: invokestatic max : (II)I
    //   1166: putfield f : I
    //   1169: iload #9
    //   1171: iconst_1
    //   1172: iadd
    //   1173: istore #9
    //   1175: goto -> 1016
    //   1178: aload_0
    //   1179: getfield f : I
    //   1182: aload_0
    //   1183: invokevirtual getPaddingLeft : ()I
    //   1186: aload_0
    //   1187: invokevirtual getPaddingRight : ()I
    //   1190: iadd
    //   1191: iadd
    //   1192: istore #8
    //   1194: aload_0
    //   1195: iload #8
    //   1197: putfield f : I
    //   1200: iload #8
    //   1202: aload_0
    //   1203: invokevirtual getSuggestedMinimumWidth : ()I
    //   1206: invokestatic max : (II)I
    //   1209: iload_1
    //   1210: iconst_0
    //   1211: invokestatic resolveSizeAndState : (III)I
    //   1214: istore #18
    //   1216: ldc_w 16777215
    //   1219: iload #18
    //   1221: iand
    //   1222: aload_0
    //   1223: getfield f : I
    //   1226: isub
    //   1227: istore #17
    //   1229: iload #12
    //   1231: ifne -> 1367
    //   1234: iload #17
    //   1236: ifeq -> 1248
    //   1239: fload_3
    //   1240: fconst_0
    //   1241: fcmpl
    //   1242: ifle -> 1248
    //   1245: goto -> 1367
    //   1248: iload #6
    //   1250: iload #11
    //   1252: invokestatic max : (II)I
    //   1255: istore #9
    //   1257: iload #25
    //   1259: ifeq -> 1352
    //   1262: iload #22
    //   1264: ldc 1073741824
    //   1266: if_icmpeq -> 1352
    //   1269: iconst_0
    //   1270: istore #6
    //   1272: iload #6
    //   1274: iload #16
    //   1276: if_icmpge -> 1352
    //   1279: aload_0
    //   1280: iload #6
    //   1282: invokevirtual o : (I)Landroid/view/View;
    //   1285: astore #26
    //   1287: aload #26
    //   1289: ifnull -> 1343
    //   1292: aload #26
    //   1294: invokevirtual getVisibility : ()I
    //   1297: bipush #8
    //   1299: if_icmpne -> 1305
    //   1302: goto -> 1343
    //   1305: aload #26
    //   1307: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1310: checkcast androidx/appcompat/widget/i1$a
    //   1313: getfield weight : F
    //   1316: fconst_0
    //   1317: fcmpl
    //   1318: ifle -> 1343
    //   1321: aload #26
    //   1323: iload #7
    //   1325: ldc 1073741824
    //   1327: invokestatic makeMeasureSpec : (II)I
    //   1330: aload #26
    //   1332: invokevirtual getMeasuredHeight : ()I
    //   1335: ldc 1073741824
    //   1337: invokestatic makeMeasureSpec : (II)I
    //   1340: invokevirtual measure : (II)V
    //   1343: iload #6
    //   1345: iconst_1
    //   1346: iadd
    //   1347: istore #6
    //   1349: goto -> 1272
    //   1352: iload #16
    //   1354: istore #8
    //   1356: iload #14
    //   1358: istore #7
    //   1360: iload #9
    //   1362: istore #6
    //   1364: goto -> 2080
    //   1367: aload_0
    //   1368: getfield g : F
    //   1371: fstore #4
    //   1373: fload #4
    //   1375: fconst_0
    //   1376: fcmpl
    //   1377: ifle -> 1383
    //   1380: fload #4
    //   1382: fstore_3
    //   1383: aload #28
    //   1385: iconst_3
    //   1386: iconst_m1
    //   1387: iastore
    //   1388: aload #28
    //   1390: iconst_2
    //   1391: iconst_m1
    //   1392: iastore
    //   1393: aload #28
    //   1395: iconst_1
    //   1396: iconst_m1
    //   1397: iastore
    //   1398: aload #28
    //   1400: iconst_0
    //   1401: iconst_m1
    //   1402: iastore
    //   1403: aload #26
    //   1405: iconst_3
    //   1406: iconst_m1
    //   1407: iastore
    //   1408: aload #26
    //   1410: iconst_2
    //   1411: iconst_m1
    //   1412: iastore
    //   1413: aload #26
    //   1415: iconst_1
    //   1416: iconst_m1
    //   1417: iastore
    //   1418: aload #26
    //   1420: iconst_0
    //   1421: iconst_m1
    //   1422: iastore
    //   1423: aload_0
    //   1424: iconst_0
    //   1425: putfield f : I
    //   1428: iload #13
    //   1430: istore #7
    //   1432: iconst_m1
    //   1433: istore #12
    //   1435: iconst_0
    //   1436: istore #13
    //   1438: iload #5
    //   1440: istore #9
    //   1442: iload #16
    //   1444: istore #8
    //   1446: iload #7
    //   1448: istore #5
    //   1450: iload #6
    //   1452: istore #11
    //   1454: iload #17
    //   1456: istore #6
    //   1458: iload #13
    //   1460: iload #8
    //   1462: if_icmpge -> 1944
    //   1465: aload_0
    //   1466: iload #13
    //   1468: invokevirtual o : (I)Landroid/view/View;
    //   1471: astore #27
    //   1473: aload #27
    //   1475: ifnull -> 1935
    //   1478: aload #27
    //   1480: invokevirtual getVisibility : ()I
    //   1483: bipush #8
    //   1485: if_icmpne -> 1491
    //   1488: goto -> 1935
    //   1491: aload #27
    //   1493: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1496: checkcast androidx/appcompat/widget/i1$a
    //   1499: astore #29
    //   1501: aload #29
    //   1503: getfield weight : F
    //   1506: fstore #4
    //   1508: fload #4
    //   1510: fconst_0
    //   1511: fcmpl
    //   1512: ifle -> 1655
    //   1515: iload #6
    //   1517: i2f
    //   1518: fload #4
    //   1520: fmul
    //   1521: fload_3
    //   1522: fdiv
    //   1523: f2i
    //   1524: istore #14
    //   1526: iload_2
    //   1527: aload_0
    //   1528: invokevirtual getPaddingTop : ()I
    //   1531: aload_0
    //   1532: invokevirtual getPaddingBottom : ()I
    //   1535: iadd
    //   1536: aload #29
    //   1538: getfield topMargin : I
    //   1541: iadd
    //   1542: aload #29
    //   1544: getfield bottomMargin : I
    //   1547: iadd
    //   1548: aload #29
    //   1550: getfield height : I
    //   1553: invokestatic getChildMeasureSpec : (III)I
    //   1556: istore #17
    //   1558: aload #29
    //   1560: getfield width : I
    //   1563: ifne -> 1588
    //   1566: iload #22
    //   1568: ldc 1073741824
    //   1570: if_icmpeq -> 1576
    //   1573: goto -> 1588
    //   1576: iload #14
    //   1578: ifle -> 1607
    //   1581: iload #14
    //   1583: istore #7
    //   1585: goto -> 1610
    //   1588: aload #27
    //   1590: invokevirtual getMeasuredWidth : ()I
    //   1593: iload #14
    //   1595: iadd
    //   1596: istore #16
    //   1598: iload #16
    //   1600: istore #7
    //   1602: iload #16
    //   1604: ifge -> 1610
    //   1607: iconst_0
    //   1608: istore #7
    //   1610: aload #27
    //   1612: iload #7
    //   1614: ldc 1073741824
    //   1616: invokestatic makeMeasureSpec : (II)I
    //   1619: iload #17
    //   1621: invokevirtual measure : (II)V
    //   1624: iload #5
    //   1626: aload #27
    //   1628: invokevirtual getMeasuredState : ()I
    //   1631: ldc_w -16777216
    //   1634: iand
    //   1635: invokestatic combineMeasuredStates : (II)I
    //   1638: istore #5
    //   1640: fload_3
    //   1641: fload #4
    //   1643: fsub
    //   1644: fstore_3
    //   1645: iload #6
    //   1647: iload #14
    //   1649: isub
    //   1650: istore #6
    //   1652: goto -> 1655
    //   1655: aload_0
    //   1656: getfield f : I
    //   1659: istore #7
    //   1661: iload #15
    //   1663: ifeq -> 1700
    //   1666: aload_0
    //   1667: iload #7
    //   1669: aload #27
    //   1671: invokevirtual getMeasuredWidth : ()I
    //   1674: aload #29
    //   1676: getfield leftMargin : I
    //   1679: iadd
    //   1680: aload #29
    //   1682: getfield rightMargin : I
    //   1685: iadd
    //   1686: aload_0
    //   1687: aload #27
    //   1689: invokevirtual n : (Landroid/view/View;)I
    //   1692: iadd
    //   1693: iadd
    //   1694: putfield f : I
    //   1697: goto -> 1736
    //   1700: aload_0
    //   1701: iload #7
    //   1703: aload #27
    //   1705: invokevirtual getMeasuredWidth : ()I
    //   1708: iload #7
    //   1710: iadd
    //   1711: aload #29
    //   1713: getfield leftMargin : I
    //   1716: iadd
    //   1717: aload #29
    //   1719: getfield rightMargin : I
    //   1722: iadd
    //   1723: aload_0
    //   1724: aload #27
    //   1726: invokevirtual n : (Landroid/view/View;)I
    //   1729: iadd
    //   1730: invokestatic max : (II)I
    //   1733: putfield f : I
    //   1736: iload #21
    //   1738: ldc 1073741824
    //   1740: if_icmpeq -> 1758
    //   1743: aload #29
    //   1745: getfield height : I
    //   1748: iconst_m1
    //   1749: if_icmpne -> 1758
    //   1752: iconst_1
    //   1753: istore #7
    //   1755: goto -> 1761
    //   1758: iconst_0
    //   1759: istore #7
    //   1761: aload #29
    //   1763: getfield topMargin : I
    //   1766: aload #29
    //   1768: getfield bottomMargin : I
    //   1771: iadd
    //   1772: istore #16
    //   1774: aload #27
    //   1776: invokevirtual getMeasuredHeight : ()I
    //   1779: iload #16
    //   1781: iadd
    //   1782: istore #14
    //   1784: iload #12
    //   1786: iload #14
    //   1788: invokestatic max : (II)I
    //   1791: istore #12
    //   1793: iload #7
    //   1795: ifeq -> 1805
    //   1798: iload #16
    //   1800: istore #7
    //   1802: goto -> 1809
    //   1805: iload #14
    //   1807: istore #7
    //   1809: iload #11
    //   1811: iload #7
    //   1813: invokestatic max : (II)I
    //   1816: istore #11
    //   1818: iload #9
    //   1820: ifeq -> 1838
    //   1823: aload #29
    //   1825: getfield height : I
    //   1828: iconst_m1
    //   1829: if_icmpne -> 1838
    //   1832: iconst_1
    //   1833: istore #7
    //   1835: goto -> 1841
    //   1838: iconst_0
    //   1839: istore #7
    //   1841: iload #24
    //   1843: ifeq -> 1928
    //   1846: aload #27
    //   1848: invokevirtual getBaseline : ()I
    //   1851: istore #17
    //   1853: iload #17
    //   1855: iconst_m1
    //   1856: if_icmpeq -> 1928
    //   1859: aload #29
    //   1861: getfield gravity : I
    //   1864: istore #16
    //   1866: iload #16
    //   1868: istore #9
    //   1870: iload #16
    //   1872: ifge -> 1881
    //   1875: aload_0
    //   1876: getfield e : I
    //   1879: istore #9
    //   1881: iload #9
    //   1883: bipush #112
    //   1885: iand
    //   1886: iconst_4
    //   1887: ishr
    //   1888: bipush #-2
    //   1890: iand
    //   1891: iconst_1
    //   1892: ishr
    //   1893: istore #9
    //   1895: aload #28
    //   1897: iload #9
    //   1899: aload #28
    //   1901: iload #9
    //   1903: iaload
    //   1904: iload #17
    //   1906: invokestatic max : (II)I
    //   1909: iastore
    //   1910: aload #26
    //   1912: iload #9
    //   1914: aload #26
    //   1916: iload #9
    //   1918: iaload
    //   1919: iload #14
    //   1921: iload #17
    //   1923: isub
    //   1924: invokestatic max : (II)I
    //   1927: iastore
    //   1928: iload #7
    //   1930: istore #9
    //   1932: goto -> 1935
    //   1935: iload #13
    //   1937: iconst_1
    //   1938: iadd
    //   1939: istore #13
    //   1941: goto -> 1458
    //   1944: aload_0
    //   1945: aload_0
    //   1946: getfield f : I
    //   1949: aload_0
    //   1950: invokevirtual getPaddingLeft : ()I
    //   1953: aload_0
    //   1954: invokevirtual getPaddingRight : ()I
    //   1957: iadd
    //   1958: iadd
    //   1959: putfield f : I
    //   1962: aload #28
    //   1964: iconst_1
    //   1965: iaload
    //   1966: istore #6
    //   1968: iload #6
    //   1970: iconst_m1
    //   1971: if_icmpne -> 2008
    //   1974: aload #28
    //   1976: iconst_0
    //   1977: iaload
    //   1978: iconst_m1
    //   1979: if_icmpne -> 2008
    //   1982: aload #28
    //   1984: iconst_2
    //   1985: iaload
    //   1986: iconst_m1
    //   1987: if_icmpne -> 2008
    //   1990: aload #28
    //   1992: iconst_3
    //   1993: iaload
    //   1994: iconst_m1
    //   1995: if_icmpeq -> 2001
    //   1998: goto -> 2008
    //   2001: iload #12
    //   2003: istore #6
    //   2005: goto -> 2064
    //   2008: iload #12
    //   2010: aload #28
    //   2012: iconst_3
    //   2013: iaload
    //   2014: aload #28
    //   2016: iconst_0
    //   2017: iaload
    //   2018: iload #6
    //   2020: aload #28
    //   2022: iconst_2
    //   2023: iaload
    //   2024: invokestatic max : (II)I
    //   2027: invokestatic max : (II)I
    //   2030: invokestatic max : (II)I
    //   2033: aload #26
    //   2035: iconst_3
    //   2036: iaload
    //   2037: aload #26
    //   2039: iconst_0
    //   2040: iaload
    //   2041: aload #26
    //   2043: iconst_1
    //   2044: iaload
    //   2045: aload #26
    //   2047: iconst_2
    //   2048: iaload
    //   2049: invokestatic max : (II)I
    //   2052: invokestatic max : (II)I
    //   2055: invokestatic max : (II)I
    //   2058: iadd
    //   2059: invokestatic max : (II)I
    //   2062: istore #6
    //   2064: iload #5
    //   2066: istore #13
    //   2068: iload #9
    //   2070: istore #5
    //   2072: iload #6
    //   2074: istore #7
    //   2076: iload #11
    //   2078: istore #6
    //   2080: iload #5
    //   2082: ifne -> 2095
    //   2085: iload #21
    //   2087: ldc 1073741824
    //   2089: if_icmpeq -> 2095
    //   2092: goto -> 2099
    //   2095: iload #7
    //   2097: istore #6
    //   2099: aload_0
    //   2100: iload #18
    //   2102: iload #13
    //   2104: ldc_w -16777216
    //   2107: iand
    //   2108: ior
    //   2109: iload #6
    //   2111: aload_0
    //   2112: invokevirtual getPaddingTop : ()I
    //   2115: aload_0
    //   2116: invokevirtual getPaddingBottom : ()I
    //   2119: iadd
    //   2120: iadd
    //   2121: aload_0
    //   2122: invokevirtual getSuggestedMinimumHeight : ()I
    //   2125: invokestatic max : (II)I
    //   2128: iload_2
    //   2129: iload #13
    //   2131: bipush #16
    //   2133: ishl
    //   2134: invokestatic resolveSizeAndState : (III)I
    //   2137: invokevirtual setMeasuredDimension : (II)V
    //   2140: iload #10
    //   2142: ifeq -> 2152
    //   2145: aload_0
    //   2146: iload #8
    //   2148: iload_1
    //   2149: invokespecial g : (II)V
    //   2152: return
  }
  
  int u(int paramInt) {
    return 0;
  }
  
  void v(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield f : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #12
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #20
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #15
    //   23: aload_0
    //   24: getfield b : I
    //   27: istore #21
    //   29: aload_0
    //   30: getfield h : Z
    //   33: istore #23
    //   35: fconst_0
    //   36: fstore_3
    //   37: iconst_0
    //   38: istore #5
    //   40: iconst_0
    //   41: istore #14
    //   43: iconst_0
    //   44: istore #9
    //   46: iconst_0
    //   47: istore #6
    //   49: iconst_0
    //   50: istore #8
    //   52: iconst_0
    //   53: istore #10
    //   55: iconst_0
    //   56: istore #13
    //   58: iconst_1
    //   59: istore #7
    //   61: iconst_0
    //   62: istore #11
    //   64: iload #10
    //   66: iload #12
    //   68: if_icmpge -> 624
    //   71: aload_0
    //   72: iload #10
    //   74: invokevirtual o : (I)Landroid/view/View;
    //   77: astore #24
    //   79: aload #24
    //   81: ifnonnull -> 102
    //   84: aload_0
    //   85: aload_0
    //   86: getfield f : I
    //   89: aload_0
    //   90: iload #10
    //   92: invokevirtual u : (I)I
    //   95: iadd
    //   96: putfield f : I
    //   99: goto -> 615
    //   102: aload #24
    //   104: invokevirtual getVisibility : ()I
    //   107: bipush #8
    //   109: if_icmpne -> 128
    //   112: iload #10
    //   114: aload_0
    //   115: aload #24
    //   117: iload #10
    //   119: invokevirtual l : (Landroid/view/View;I)I
    //   122: iadd
    //   123: istore #10
    //   125: goto -> 615
    //   128: aload_0
    //   129: iload #10
    //   131: invokevirtual p : (I)Z
    //   134: ifeq -> 150
    //   137: aload_0
    //   138: aload_0
    //   139: getfield f : I
    //   142: aload_0
    //   143: getfield m : I
    //   146: iadd
    //   147: putfield f : I
    //   150: aload #24
    //   152: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   155: checkcast androidx/appcompat/widget/i1$a
    //   158: astore #25
    //   160: aload #25
    //   162: getfield weight : F
    //   165: fstore #4
    //   167: fload_3
    //   168: fload #4
    //   170: fadd
    //   171: fstore_3
    //   172: iload #15
    //   174: ldc 1073741824
    //   176: if_icmpne -> 229
    //   179: aload #25
    //   181: getfield height : I
    //   184: ifne -> 229
    //   187: fload #4
    //   189: fconst_0
    //   190: fcmpl
    //   191: ifle -> 229
    //   194: aload_0
    //   195: getfield f : I
    //   198: istore #13
    //   200: aload_0
    //   201: iload #13
    //   203: aload #25
    //   205: getfield topMargin : I
    //   208: iload #13
    //   210: iadd
    //   211: aload #25
    //   213: getfield bottomMargin : I
    //   216: iadd
    //   217: invokestatic max : (II)I
    //   220: putfield f : I
    //   223: iconst_1
    //   224: istore #13
    //   226: goto -> 371
    //   229: aload #25
    //   231: getfield height : I
    //   234: ifne -> 257
    //   237: fload #4
    //   239: fconst_0
    //   240: fcmpl
    //   241: ifle -> 257
    //   244: aload #25
    //   246: bipush #-2
    //   248: putfield height : I
    //   251: iconst_0
    //   252: istore #16
    //   254: goto -> 262
    //   257: ldc_w -2147483648
    //   260: istore #16
    //   262: fload_3
    //   263: fconst_0
    //   264: fcmpl
    //   265: ifne -> 277
    //   268: aload_0
    //   269: getfield f : I
    //   272: istore #17
    //   274: goto -> 280
    //   277: iconst_0
    //   278: istore #17
    //   280: aload_0
    //   281: aload #24
    //   283: iload #10
    //   285: iload_1
    //   286: iconst_0
    //   287: iload_2
    //   288: iload #17
    //   290: invokevirtual s : (Landroid/view/View;IIIII)V
    //   293: iload #16
    //   295: ldc_w -2147483648
    //   298: if_icmpeq -> 308
    //   301: aload #25
    //   303: iload #16
    //   305: putfield height : I
    //   308: aload #24
    //   310: invokevirtual getMeasuredHeight : ()I
    //   313: istore #16
    //   315: aload_0
    //   316: getfield f : I
    //   319: istore #17
    //   321: aload_0
    //   322: iload #17
    //   324: iload #17
    //   326: iload #16
    //   328: iadd
    //   329: aload #25
    //   331: getfield topMargin : I
    //   334: iadd
    //   335: aload #25
    //   337: getfield bottomMargin : I
    //   340: iadd
    //   341: aload_0
    //   342: aload #24
    //   344: invokevirtual n : (Landroid/view/View;)I
    //   347: iadd
    //   348: invokestatic max : (II)I
    //   351: putfield f : I
    //   354: iload #23
    //   356: ifeq -> 371
    //   359: iload #16
    //   361: iload #9
    //   363: invokestatic max : (II)I
    //   366: istore #9
    //   368: goto -> 371
    //   371: iload #10
    //   373: istore #18
    //   375: iload #21
    //   377: iflt -> 397
    //   380: iload #21
    //   382: iload #18
    //   384: iconst_1
    //   385: iadd
    //   386: if_icmpne -> 397
    //   389: aload_0
    //   390: aload_0
    //   391: getfield f : I
    //   394: putfield c : I
    //   397: iload #18
    //   399: iload #21
    //   401: if_icmpge -> 428
    //   404: aload #25
    //   406: getfield weight : F
    //   409: fconst_0
    //   410: fcmpl
    //   411: ifgt -> 417
    //   414: goto -> 428
    //   417: new java/lang/RuntimeException
    //   420: dup
    //   421: ldc_w 'A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.'
    //   424: invokespecial <init> : (Ljava/lang/String;)V
    //   427: athrow
    //   428: iload #20
    //   430: ldc 1073741824
    //   432: if_icmpeq -> 453
    //   435: aload #25
    //   437: getfield width : I
    //   440: iconst_m1
    //   441: if_icmpne -> 453
    //   444: iconst_1
    //   445: istore #10
    //   447: iconst_1
    //   448: istore #11
    //   450: goto -> 456
    //   453: iconst_0
    //   454: istore #10
    //   456: aload #25
    //   458: getfield leftMargin : I
    //   461: aload #25
    //   463: getfield rightMargin : I
    //   466: iadd
    //   467: istore #16
    //   469: aload #24
    //   471: invokevirtual getMeasuredWidth : ()I
    //   474: iload #16
    //   476: iadd
    //   477: istore #17
    //   479: iload #14
    //   481: iload #17
    //   483: invokestatic max : (II)I
    //   486: istore #14
    //   488: iload #5
    //   490: aload #24
    //   492: invokevirtual getMeasuredState : ()I
    //   495: invokestatic combineMeasuredStates : (II)I
    //   498: istore #19
    //   500: iload #7
    //   502: ifeq -> 520
    //   505: aload #25
    //   507: getfield width : I
    //   510: iconst_m1
    //   511: if_icmpne -> 520
    //   514: iconst_1
    //   515: istore #5
    //   517: goto -> 523
    //   520: iconst_0
    //   521: istore #5
    //   523: aload #25
    //   525: getfield weight : F
    //   528: fconst_0
    //   529: fcmpl
    //   530: ifle -> 561
    //   533: iload #10
    //   535: ifeq -> 541
    //   538: goto -> 545
    //   541: iload #17
    //   543: istore #16
    //   545: iload #6
    //   547: iload #16
    //   549: invokestatic max : (II)I
    //   552: istore #6
    //   554: iload #8
    //   556: istore #7
    //   558: goto -> 582
    //   561: iload #10
    //   563: ifeq -> 569
    //   566: goto -> 573
    //   569: iload #17
    //   571: istore #16
    //   573: iload #8
    //   575: iload #16
    //   577: invokestatic max : (II)I
    //   580: istore #7
    //   582: aload_0
    //   583: aload #24
    //   585: iload #18
    //   587: invokevirtual l : (Landroid/view/View;I)I
    //   590: istore #10
    //   592: iload #7
    //   594: istore #8
    //   596: iload #19
    //   598: istore #16
    //   600: iload #10
    //   602: iload #18
    //   604: iadd
    //   605: istore #10
    //   607: iload #5
    //   609: istore #7
    //   611: iload #16
    //   613: istore #5
    //   615: iload #10
    //   617: iconst_1
    //   618: iadd
    //   619: istore #10
    //   621: goto -> 64
    //   624: aload_0
    //   625: getfield f : I
    //   628: ifle -> 656
    //   631: aload_0
    //   632: iload #12
    //   634: invokevirtual p : (I)Z
    //   637: ifeq -> 656
    //   640: aload_0
    //   641: aload_0
    //   642: getfield f : I
    //   645: aload_0
    //   646: getfield m : I
    //   649: iadd
    //   650: putfield f : I
    //   653: goto -> 656
    //   656: iload #12
    //   658: istore #16
    //   660: iload #23
    //   662: ifeq -> 813
    //   665: iload #15
    //   667: ldc_w -2147483648
    //   670: if_icmpeq -> 678
    //   673: iload #15
    //   675: ifne -> 813
    //   678: aload_0
    //   679: iconst_0
    //   680: putfield f : I
    //   683: iconst_0
    //   684: istore #10
    //   686: iload #10
    //   688: iload #16
    //   690: if_icmpge -> 813
    //   693: aload_0
    //   694: iload #10
    //   696: invokevirtual o : (I)Landroid/view/View;
    //   699: astore #24
    //   701: aload #24
    //   703: ifnonnull -> 728
    //   706: aload_0
    //   707: getfield f : I
    //   710: aload_0
    //   711: iload #10
    //   713: invokevirtual u : (I)I
    //   716: iadd
    //   717: istore #12
    //   719: aload_0
    //   720: iload #12
    //   722: putfield f : I
    //   725: goto -> 804
    //   728: aload #24
    //   730: invokevirtual getVisibility : ()I
    //   733: bipush #8
    //   735: if_icmpne -> 754
    //   738: iload #10
    //   740: aload_0
    //   741: aload #24
    //   743: iload #10
    //   745: invokevirtual l : (Landroid/view/View;I)I
    //   748: iadd
    //   749: istore #10
    //   751: goto -> 804
    //   754: aload #24
    //   756: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   759: checkcast androidx/appcompat/widget/i1$a
    //   762: astore #25
    //   764: aload_0
    //   765: getfield f : I
    //   768: istore #12
    //   770: iload #12
    //   772: iload #12
    //   774: iload #9
    //   776: iadd
    //   777: aload #25
    //   779: getfield topMargin : I
    //   782: iadd
    //   783: aload #25
    //   785: getfield bottomMargin : I
    //   788: iadd
    //   789: aload_0
    //   790: aload #24
    //   792: invokevirtual n : (Landroid/view/View;)I
    //   795: iadd
    //   796: invokestatic max : (II)I
    //   799: istore #12
    //   801: goto -> 719
    //   804: iload #10
    //   806: iconst_1
    //   807: iadd
    //   808: istore #10
    //   810: goto -> 686
    //   813: aload_0
    //   814: getfield f : I
    //   817: aload_0
    //   818: invokevirtual getPaddingTop : ()I
    //   821: aload_0
    //   822: invokevirtual getPaddingBottom : ()I
    //   825: iadd
    //   826: iadd
    //   827: istore #10
    //   829: aload_0
    //   830: iload #10
    //   832: putfield f : I
    //   835: iload #10
    //   837: aload_0
    //   838: invokevirtual getSuggestedMinimumHeight : ()I
    //   841: invokestatic max : (II)I
    //   844: iload_2
    //   845: iconst_0
    //   846: invokestatic resolveSizeAndState : (III)I
    //   849: istore #17
    //   851: ldc_w 16777215
    //   854: iload #17
    //   856: iand
    //   857: aload_0
    //   858: getfield f : I
    //   861: isub
    //   862: istore #10
    //   864: iload #13
    //   866: ifne -> 998
    //   869: iload #10
    //   871: ifeq -> 883
    //   874: fload_3
    //   875: fconst_0
    //   876: fcmpl
    //   877: ifle -> 883
    //   880: goto -> 998
    //   883: iload #8
    //   885: iload #6
    //   887: invokestatic max : (II)I
    //   890: istore #8
    //   892: iload #23
    //   894: ifeq -> 987
    //   897: iload #15
    //   899: ldc 1073741824
    //   901: if_icmpeq -> 987
    //   904: iconst_0
    //   905: istore #6
    //   907: iload #6
    //   909: iload #16
    //   911: if_icmpge -> 987
    //   914: aload_0
    //   915: iload #6
    //   917: invokevirtual o : (I)Landroid/view/View;
    //   920: astore #24
    //   922: aload #24
    //   924: ifnull -> 978
    //   927: aload #24
    //   929: invokevirtual getVisibility : ()I
    //   932: bipush #8
    //   934: if_icmpne -> 940
    //   937: goto -> 978
    //   940: aload #24
    //   942: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   945: checkcast androidx/appcompat/widget/i1$a
    //   948: getfield weight : F
    //   951: fconst_0
    //   952: fcmpl
    //   953: ifle -> 978
    //   956: aload #24
    //   958: aload #24
    //   960: invokevirtual getMeasuredWidth : ()I
    //   963: ldc 1073741824
    //   965: invokestatic makeMeasureSpec : (II)I
    //   968: iload #9
    //   970: ldc 1073741824
    //   972: invokestatic makeMeasureSpec : (II)I
    //   975: invokevirtual measure : (II)V
    //   978: iload #6
    //   980: iconst_1
    //   981: iadd
    //   982: istore #6
    //   984: goto -> 907
    //   987: iload #5
    //   989: istore #6
    //   991: iload #8
    //   993: istore #5
    //   995: goto -> 1424
    //   998: aload_0
    //   999: getfield g : F
    //   1002: fstore #4
    //   1004: fload #4
    //   1006: fconst_0
    //   1007: fcmpl
    //   1008: ifle -> 1014
    //   1011: fload #4
    //   1013: fstore_3
    //   1014: aload_0
    //   1015: iconst_0
    //   1016: putfield f : I
    //   1019: iload #10
    //   1021: istore #6
    //   1023: iconst_0
    //   1024: istore #9
    //   1026: iload #9
    //   1028: iload #16
    //   1030: if_icmpge -> 1398
    //   1033: aload_0
    //   1034: iload #9
    //   1036: invokevirtual o : (I)Landroid/view/View;
    //   1039: astore #24
    //   1041: aload #24
    //   1043: invokevirtual getVisibility : ()I
    //   1046: bipush #8
    //   1048: if_icmpne -> 1054
    //   1051: goto -> 1389
    //   1054: aload #24
    //   1056: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1059: checkcast androidx/appcompat/widget/i1$a
    //   1062: astore #25
    //   1064: aload #25
    //   1066: getfield weight : F
    //   1069: fstore #4
    //   1071: fload #4
    //   1073: fconst_0
    //   1074: fcmpl
    //   1075: ifle -> 1242
    //   1078: iload #6
    //   1080: i2f
    //   1081: fload #4
    //   1083: fmul
    //   1084: fload_3
    //   1085: fdiv
    //   1086: f2i
    //   1087: istore #12
    //   1089: aload_0
    //   1090: invokevirtual getPaddingLeft : ()I
    //   1093: istore #13
    //   1095: aload_0
    //   1096: invokevirtual getPaddingRight : ()I
    //   1099: istore #18
    //   1101: aload #25
    //   1103: getfield leftMargin : I
    //   1106: istore #19
    //   1108: aload #25
    //   1110: getfield rightMargin : I
    //   1113: istore #21
    //   1115: aload #25
    //   1117: getfield width : I
    //   1120: istore #22
    //   1122: iload #6
    //   1124: iload #12
    //   1126: isub
    //   1127: istore #10
    //   1129: iload_1
    //   1130: iload #13
    //   1132: iload #18
    //   1134: iadd
    //   1135: iload #19
    //   1137: iadd
    //   1138: iload #21
    //   1140: iadd
    //   1141: iload #22
    //   1143: invokestatic getChildMeasureSpec : (III)I
    //   1146: istore #13
    //   1148: aload #25
    //   1150: getfield height : I
    //   1153: ifne -> 1178
    //   1156: iload #15
    //   1158: ldc 1073741824
    //   1160: if_icmpeq -> 1166
    //   1163: goto -> 1178
    //   1166: iload #12
    //   1168: ifle -> 1197
    //   1171: iload #12
    //   1173: istore #6
    //   1175: goto -> 1200
    //   1178: aload #24
    //   1180: invokevirtual getMeasuredHeight : ()I
    //   1183: iload #12
    //   1185: iadd
    //   1186: istore #12
    //   1188: iload #12
    //   1190: istore #6
    //   1192: iload #12
    //   1194: ifge -> 1200
    //   1197: iconst_0
    //   1198: istore #6
    //   1200: aload #24
    //   1202: iload #13
    //   1204: iload #6
    //   1206: ldc 1073741824
    //   1208: invokestatic makeMeasureSpec : (II)I
    //   1211: invokevirtual measure : (II)V
    //   1214: iload #5
    //   1216: aload #24
    //   1218: invokevirtual getMeasuredState : ()I
    //   1221: sipush #-256
    //   1224: iand
    //   1225: invokestatic combineMeasuredStates : (II)I
    //   1228: istore #5
    //   1230: fload_3
    //   1231: fload #4
    //   1233: fsub
    //   1234: fstore_3
    //   1235: iload #10
    //   1237: istore #6
    //   1239: goto -> 1242
    //   1242: aload #25
    //   1244: getfield leftMargin : I
    //   1247: aload #25
    //   1249: getfield rightMargin : I
    //   1252: iadd
    //   1253: istore #12
    //   1255: aload #24
    //   1257: invokevirtual getMeasuredWidth : ()I
    //   1260: iload #12
    //   1262: iadd
    //   1263: istore #13
    //   1265: iload #14
    //   1267: iload #13
    //   1269: invokestatic max : (II)I
    //   1272: istore #14
    //   1274: iload #20
    //   1276: ldc 1073741824
    //   1278: if_icmpeq -> 1296
    //   1281: aload #25
    //   1283: getfield width : I
    //   1286: iconst_m1
    //   1287: if_icmpne -> 1296
    //   1290: iconst_1
    //   1291: istore #10
    //   1293: goto -> 1299
    //   1296: iconst_0
    //   1297: istore #10
    //   1299: iload #10
    //   1301: ifeq -> 1311
    //   1304: iload #12
    //   1306: istore #10
    //   1308: goto -> 1315
    //   1311: iload #13
    //   1313: istore #10
    //   1315: iload #8
    //   1317: iload #10
    //   1319: invokestatic max : (II)I
    //   1322: istore #8
    //   1324: iload #7
    //   1326: ifeq -> 1344
    //   1329: aload #25
    //   1331: getfield width : I
    //   1334: iconst_m1
    //   1335: if_icmpne -> 1344
    //   1338: iconst_1
    //   1339: istore #7
    //   1341: goto -> 1347
    //   1344: iconst_0
    //   1345: istore #7
    //   1347: aload_0
    //   1348: getfield f : I
    //   1351: istore #10
    //   1353: aload_0
    //   1354: iload #10
    //   1356: aload #24
    //   1358: invokevirtual getMeasuredHeight : ()I
    //   1361: iload #10
    //   1363: iadd
    //   1364: aload #25
    //   1366: getfield topMargin : I
    //   1369: iadd
    //   1370: aload #25
    //   1372: getfield bottomMargin : I
    //   1375: iadd
    //   1376: aload_0
    //   1377: aload #24
    //   1379: invokevirtual n : (Landroid/view/View;)I
    //   1382: iadd
    //   1383: invokestatic max : (II)I
    //   1386: putfield f : I
    //   1389: iload #9
    //   1391: iconst_1
    //   1392: iadd
    //   1393: istore #9
    //   1395: goto -> 1026
    //   1398: aload_0
    //   1399: aload_0
    //   1400: getfield f : I
    //   1403: aload_0
    //   1404: invokevirtual getPaddingTop : ()I
    //   1407: aload_0
    //   1408: invokevirtual getPaddingBottom : ()I
    //   1411: iadd
    //   1412: iadd
    //   1413: putfield f : I
    //   1416: iload #5
    //   1418: istore #6
    //   1420: iload #8
    //   1422: istore #5
    //   1424: iload #7
    //   1426: ifne -> 1439
    //   1429: iload #20
    //   1431: ldc 1073741824
    //   1433: if_icmpeq -> 1439
    //   1436: goto -> 1443
    //   1439: iload #14
    //   1441: istore #5
    //   1443: aload_0
    //   1444: iload #5
    //   1446: aload_0
    //   1447: invokevirtual getPaddingLeft : ()I
    //   1450: aload_0
    //   1451: invokevirtual getPaddingRight : ()I
    //   1454: iadd
    //   1455: iadd
    //   1456: aload_0
    //   1457: invokevirtual getSuggestedMinimumWidth : ()I
    //   1460: invokestatic max : (II)I
    //   1463: iload_1
    //   1464: iload #6
    //   1466: invokestatic resolveSizeAndState : (III)I
    //   1469: iload #17
    //   1471: invokevirtual setMeasuredDimension : (II)V
    //   1474: iload #11
    //   1476: ifeq -> 1486
    //   1479: aload_0
    //   1480: iload #16
    //   1482: iload_2
    //   1483: invokespecial h : (II)V
    //   1486: return
  }
  
  public static class a extends LinearLayout.LayoutParams {
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */