package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.core.view.t0;

public class x extends Spinner {
  private static final int[] i = new int[] { 16843505 };
  
  private final e a;
  
  private final Context b;
  
  private h1 c;
  
  private SpinnerAdapter d;
  
  private final boolean e;
  
  private g f;
  
  int g;
  
  final Rect h;
  
  public x(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, e.a.I);
  }
  
  public x(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public x(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public x(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield h : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic e/j.A2 : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokestatic u : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/c2;
    //   36: astore #9
    //   38: aload_0
    //   39: new androidx/appcompat/widget/e
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield a : Landroidx/appcompat/widget/e;
    //   50: aload #5
    //   52: ifnull -> 76
    //   55: new j/d
    //   58: dup
    //   59: aload_1
    //   60: aload #5
    //   62: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/Resources$Theme;)V
    //   65: astore #5
    //   67: aload_0
    //   68: aload #5
    //   70: putfield b : Landroid/content/Context;
    //   73: goto -> 112
    //   76: aload #9
    //   78: getstatic e/j.F2 : I
    //   81: iconst_0
    //   82: invokevirtual m : (II)I
    //   85: istore #6
    //   87: iload #6
    //   89: ifeq -> 107
    //   92: new j/d
    //   95: dup
    //   96: aload_1
    //   97: iload #6
    //   99: invokespecial <init> : (Landroid/content/Context;I)V
    //   102: astore #5
    //   104: goto -> 67
    //   107: aload_0
    //   108: aload_1
    //   109: putfield b : Landroid/content/Context;
    //   112: aconst_null
    //   113: astore #7
    //   115: iload #4
    //   117: istore #6
    //   119: iload #4
    //   121: iconst_m1
    //   122: if_icmpne -> 244
    //   125: aload_1
    //   126: aload_2
    //   127: getstatic androidx/appcompat/widget/x.i : [I
    //   130: iload_3
    //   131: iconst_0
    //   132: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   135: astore #5
    //   137: iload #4
    //   139: istore #6
    //   141: aload #5
    //   143: astore #8
    //   145: aload #5
    //   147: astore #7
    //   149: aload #5
    //   151: iconst_0
    //   152: invokevirtual hasValue : (I)Z
    //   155: ifeq -> 175
    //   158: aload #5
    //   160: astore #7
    //   162: aload #5
    //   164: iconst_0
    //   165: iconst_0
    //   166: invokevirtual getInt : (II)I
    //   169: istore #6
    //   171: aload #5
    //   173: astore #8
    //   175: aload #8
    //   177: invokevirtual recycle : ()V
    //   180: goto -> 244
    //   183: astore #8
    //   185: goto -> 197
    //   188: astore_1
    //   189: goto -> 232
    //   192: astore #8
    //   194: aconst_null
    //   195: astore #5
    //   197: aload #5
    //   199: astore #7
    //   201: ldc 'AppCompatSpinner'
    //   203: ldc 'Could not read android:spinnerMode'
    //   205: aload #8
    //   207: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   210: pop
    //   211: iload #4
    //   213: istore #6
    //   215: aload #5
    //   217: ifnull -> 244
    //   220: iload #4
    //   222: istore #6
    //   224: aload #5
    //   226: astore #8
    //   228: goto -> 175
    //   231: astore_1
    //   232: aload #7
    //   234: ifnull -> 242
    //   237: aload #7
    //   239: invokevirtual recycle : ()V
    //   242: aload_1
    //   243: athrow
    //   244: iload #6
    //   246: ifeq -> 358
    //   249: iload #6
    //   251: iconst_1
    //   252: if_icmpeq -> 258
    //   255: goto -> 389
    //   258: new androidx/appcompat/widget/x$e
    //   261: dup
    //   262: aload_0
    //   263: aload_0
    //   264: getfield b : Landroid/content/Context;
    //   267: aload_2
    //   268: iload_3
    //   269: invokespecial <init> : (Landroidx/appcompat/widget/x;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   272: astore #5
    //   274: aload_0
    //   275: getfield b : Landroid/content/Context;
    //   278: aload_2
    //   279: getstatic e/j.A2 : [I
    //   282: iload_3
    //   283: iconst_0
    //   284: invokestatic u : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/c2;
    //   287: astore #7
    //   289: aload_0
    //   290: aload #7
    //   292: getstatic e/j.E2 : I
    //   295: bipush #-2
    //   297: invokevirtual l : (II)I
    //   300: putfield g : I
    //   303: aload #5
    //   305: aload #7
    //   307: getstatic e/j.C2 : I
    //   310: invokevirtual f : (I)Landroid/graphics/drawable/Drawable;
    //   313: invokevirtual k : (Landroid/graphics/drawable/Drawable;)V
    //   316: aload #5
    //   318: aload #9
    //   320: getstatic e/j.D2 : I
    //   323: invokevirtual n : (I)Ljava/lang/String;
    //   326: invokevirtual i : (Ljava/lang/CharSequence;)V
    //   329: aload #7
    //   331: invokevirtual v : ()V
    //   334: aload_0
    //   335: aload #5
    //   337: putfield f : Landroidx/appcompat/widget/x$g;
    //   340: aload_0
    //   341: new androidx/appcompat/widget/x$a
    //   344: dup
    //   345: aload_0
    //   346: aload_0
    //   347: aload #5
    //   349: invokespecial <init> : (Landroidx/appcompat/widget/x;Landroid/view/View;Landroidx/appcompat/widget/x$e;)V
    //   352: putfield c : Landroidx/appcompat/widget/h1;
    //   355: goto -> 389
    //   358: new androidx/appcompat/widget/x$c
    //   361: dup
    //   362: aload_0
    //   363: invokespecial <init> : (Landroidx/appcompat/widget/x;)V
    //   366: astore #5
    //   368: aload_0
    //   369: aload #5
    //   371: putfield f : Landroidx/appcompat/widget/x$g;
    //   374: aload #5
    //   376: aload #9
    //   378: getstatic e/j.D2 : I
    //   381: invokevirtual n : (I)Ljava/lang/String;
    //   384: invokeinterface i : (Ljava/lang/CharSequence;)V
    //   389: aload #9
    //   391: getstatic e/j.B2 : I
    //   394: invokevirtual p : (I)[Ljava/lang/CharSequence;
    //   397: astore #5
    //   399: aload #5
    //   401: ifnull -> 429
    //   404: new android/widget/ArrayAdapter
    //   407: dup
    //   408: aload_1
    //   409: ldc 17367048
    //   411: aload #5
    //   413: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   416: astore_1
    //   417: aload_1
    //   418: getstatic e/g.t : I
    //   421: invokevirtual setDropDownViewResource : (I)V
    //   424: aload_0
    //   425: aload_1
    //   426: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   429: aload #9
    //   431: invokevirtual v : ()V
    //   434: aload_0
    //   435: iconst_1
    //   436: putfield e : Z
    //   439: aload_0
    //   440: getfield d : Landroid/widget/SpinnerAdapter;
    //   443: astore_1
    //   444: aload_1
    //   445: ifnull -> 458
    //   448: aload_0
    //   449: aload_1
    //   450: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   453: aload_0
    //   454: aconst_null
    //   455: putfield d : Landroid/widget/SpinnerAdapter;
    //   458: aload_0
    //   459: getfield a : Landroidx/appcompat/widget/e;
    //   462: aload_2
    //   463: iload_3
    //   464: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   467: return
    // Exception table:
    //   from	to	target	type
    //   125	137	192	java/lang/Exception
    //   125	137	188	finally
    //   149	158	183	java/lang/Exception
    //   149	158	231	finally
    //   162	171	183	java/lang/Exception
    //   162	171	231	finally
    //   201	211	231	finally
  }
  
  int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int k = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int m = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i1 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int j = Math.max(0, i - 15 - i1 - i);
    View view = null;
    i = 0;
    while (j < i1) {
      int i3 = paramSpinnerAdapter.getItemViewType(j);
      int i2 = k;
      if (i3 != k) {
        view = null;
        i2 = i3;
      } 
      view = paramSpinnerAdapter.getView(j, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(m, n);
      i = Math.max(i, view.getMeasuredWidth());
      j++;
      k = i2;
    } 
    j = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.h);
      Rect rect = this.h;
      j = i + rect.left + rect.right;
    } 
    return j;
  }
  
  void b() {
    this.f.n(getTextDirection(), getTextAlignment());
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.a;
    if (e1 != null)
      e1.b(); 
  }
  
  public int getDropDownHorizontalOffset() {
    g g1 = this.f;
    return (g1 != null) ? g1.c() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    g g1 = this.f;
    return (g1 != null) ? g1.o() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.f != null) ? this.g : super.getDropDownWidth();
  }
  
  final g getInternalPopup() {
    return this.f;
  }
  
  public Drawable getPopupBackground() {
    g g1 = this.f;
    return (g1 != null) ? g1.h() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.b;
  }
  
  public CharSequence getPrompt() {
    g g1 = this.f;
    return (g1 != null) ? g1.f() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.a;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.a;
    return (e1 != null) ? e1.d() : null;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    g g1 = this.f;
    if (g1 != null && g1.a())
      this.f.dismiss(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.f != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    f f = (f)paramParcelable;
    super.onRestoreInstanceState(f.getSuperState());
    if (f.a) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new b(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    f f = new f(super.onSaveInstanceState());
    g g1 = this.f;
    if (g1 != null && g1.a()) {
      bool = true;
    } else {
      bool = false;
    } 
    f.a = bool;
    return (Parcelable)f;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    h1 h11 = this.c;
    return (h11 != null && h11.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    g g1 = this.f;
    if (g1 != null) {
      if (!g1.a())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.e) {
      this.d = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.f != null) {
      Context context2 = this.b;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.f.p(new d(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.a;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.a;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    g g1 = this.f;
    if (g1 != null) {
      g1.m(paramInt);
      this.f.e(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    g g1 = this.f;
    if (g1 != null) {
      g1.l(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.f != null) {
      this.g = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    g g1 = this.f;
    if (g1 != null) {
      g1.k(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(g.b.d(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    g g1 = this.f;
    if (g1 != null) {
      g1.i(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.a;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.a;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  class a extends h1 {
    a(x this$0, View param1View, x.e param1e) {
      super(param1View);
    }
    
    public k.e b() {
      return this.j;
    }
    
    @SuppressLint({"SyntheticAccessor"})
    public boolean c() {
      if (!this.k.getInternalPopup().a())
        this.k.b(); 
      return true;
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(x this$0) {}
    
    public void onGlobalLayout() {
      if (!this.a.getInternalPopup().a())
        this.a.b(); 
      ViewTreeObserver viewTreeObserver = this.a.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeOnGlobalLayoutListener(this); 
    }
  }
  
  class c implements g, DialogInterface.OnClickListener {
    androidx.appcompat.app.b a;
    
    private ListAdapter b;
    
    private CharSequence c;
    
    c(x this$0) {}
    
    public boolean a() {
      androidx.appcompat.app.b b1 = this.a;
      return (b1 != null) ? b1.isShowing() : false;
    }
    
    public int c() {
      return 0;
    }
    
    public void dismiss() {
      androidx.appcompat.app.b b1 = this.a;
      if (b1 != null) {
        b1.dismiss();
        this.a = null;
      } 
    }
    
    public void e(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public CharSequence f() {
      return this.c;
    }
    
    public Drawable h() {
      return null;
    }
    
    public void i(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
    }
    
    public void k(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public void l(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
    
    public void m(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void n(int param1Int1, int param1Int2) {
      if (this.b == null)
        return; 
      androidx.appcompat.app.b.a a = new androidx.appcompat.app.b.a(this.d.getPopupContext());
      CharSequence charSequence = this.c;
      if (charSequence != null)
        a.h(charSequence); 
      androidx.appcompat.app.b b1 = a.g(this.b, this.d.getSelectedItemPosition(), this).a();
      this.a = b1;
      ListView listView = b1.f();
      listView.setTextDirection(param1Int1);
      listView.setTextAlignment(param1Int2);
      this.a.show();
    }
    
    public int o() {
      return 0;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.d.setSelection(param1Int);
      if (this.d.getOnItemClickListener() != null)
        this.d.performItemClick(null, param1Int, this.b.getItemId(param1Int)); 
      dismiss();
    }
    
    public void p(ListAdapter param1ListAdapter) {
      this.b = param1ListAdapter;
    }
  }
  
  private static class d implements ListAdapter, SpinnerAdapter {
    private SpinnerAdapter a;
    
    private ListAdapter b;
    
    public d(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.a = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.b = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        ThemedSpinnerAdapter themedSpinnerAdapter;
        if (Build.VERSION.SDK_INT >= 23 && param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          themedSpinnerAdapter = (ThemedSpinnerAdapter)param1SpinnerAdapter;
          if (y.a(themedSpinnerAdapter) != param1Theme) {
            z.a(themedSpinnerAdapter, param1Theme);
            return;
          } 
        } else if (themedSpinnerAdapter instanceof y1) {
          y1 y1 = (y1)themedSpinnerAdapter;
          if (y1.getDropDownViewTheme() == null)
            y1.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.b;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.b;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.a;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.a;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  class e extends m1 implements g {
    private CharSequence X;
    
    ListAdapter Y;
    
    private final Rect Z = new Rect();
    
    private int a0;
    
    public e(x this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      z((View)this$0);
      F(true);
      K(0);
      H(new a(this, this$0));
    }
    
    void O() {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual h : ()Landroid/graphics/drawable/Drawable;
      //   4: astore #8
      //   6: aload #8
      //   8: ifnull -> 63
      //   11: aload #8
      //   13: aload_0
      //   14: getfield b0 : Landroidx/appcompat/widget/x;
      //   17: getfield h : Landroid/graphics/Rect;
      //   20: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
      //   23: pop
      //   24: aload_0
      //   25: getfield b0 : Landroidx/appcompat/widget/x;
      //   28: invokestatic b : (Landroid/view/View;)Z
      //   31: ifeq -> 48
      //   34: aload_0
      //   35: getfield b0 : Landroidx/appcompat/widget/x;
      //   38: getfield h : Landroid/graphics/Rect;
      //   41: getfield right : I
      //   44: istore_1
      //   45: goto -> 86
      //   48: aload_0
      //   49: getfield b0 : Landroidx/appcompat/widget/x;
      //   52: getfield h : Landroid/graphics/Rect;
      //   55: getfield left : I
      //   58: ineg
      //   59: istore_1
      //   60: goto -> 86
      //   63: aload_0
      //   64: getfield b0 : Landroidx/appcompat/widget/x;
      //   67: getfield h : Landroid/graphics/Rect;
      //   70: astore #8
      //   72: aload #8
      //   74: iconst_0
      //   75: putfield right : I
      //   78: aload #8
      //   80: iconst_0
      //   81: putfield left : I
      //   84: iconst_0
      //   85: istore_1
      //   86: aload_0
      //   87: getfield b0 : Landroidx/appcompat/widget/x;
      //   90: invokevirtual getPaddingLeft : ()I
      //   93: istore #5
      //   95: aload_0
      //   96: getfield b0 : Landroidx/appcompat/widget/x;
      //   99: invokevirtual getPaddingRight : ()I
      //   102: istore #6
      //   104: aload_0
      //   105: getfield b0 : Landroidx/appcompat/widget/x;
      //   108: invokevirtual getWidth : ()I
      //   111: istore #7
      //   113: aload_0
      //   114: getfield b0 : Landroidx/appcompat/widget/x;
      //   117: astore #8
      //   119: aload #8
      //   121: getfield g : I
      //   124: istore_2
      //   125: iload_2
      //   126: bipush #-2
      //   128: if_icmpne -> 216
      //   131: aload #8
      //   133: aload_0
      //   134: getfield Y : Landroid/widget/ListAdapter;
      //   137: checkcast android/widget/SpinnerAdapter
      //   140: aload_0
      //   141: invokevirtual h : ()Landroid/graphics/drawable/Drawable;
      //   144: invokevirtual a : (Landroid/widget/SpinnerAdapter;Landroid/graphics/drawable/Drawable;)I
      //   147: istore_3
      //   148: aload_0
      //   149: getfield b0 : Landroidx/appcompat/widget/x;
      //   152: invokevirtual getContext : ()Landroid/content/Context;
      //   155: invokevirtual getResources : ()Landroid/content/res/Resources;
      //   158: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
      //   161: getfield widthPixels : I
      //   164: istore_2
      //   165: aload_0
      //   166: getfield b0 : Landroidx/appcompat/widget/x;
      //   169: getfield h : Landroid/graphics/Rect;
      //   172: astore #8
      //   174: iload_2
      //   175: aload #8
      //   177: getfield left : I
      //   180: isub
      //   181: aload #8
      //   183: getfield right : I
      //   186: isub
      //   187: istore #4
      //   189: iload_3
      //   190: istore_2
      //   191: iload_3
      //   192: iload #4
      //   194: if_icmple -> 200
      //   197: iload #4
      //   199: istore_2
      //   200: iload_2
      //   201: iload #7
      //   203: iload #5
      //   205: isub
      //   206: iload #6
      //   208: isub
      //   209: invokestatic max : (II)I
      //   212: istore_2
      //   213: goto -> 230
      //   216: iload_2
      //   217: iconst_m1
      //   218: if_icmpne -> 238
      //   221: iload #7
      //   223: iload #5
      //   225: isub
      //   226: iload #6
      //   228: isub
      //   229: istore_2
      //   230: aload_0
      //   231: iload_2
      //   232: invokevirtual B : (I)V
      //   235: goto -> 243
      //   238: aload_0
      //   239: iload_2
      //   240: invokevirtual B : (I)V
      //   243: aload_0
      //   244: getfield b0 : Landroidx/appcompat/widget/x;
      //   247: invokestatic b : (Landroid/view/View;)Z
      //   250: ifeq -> 274
      //   253: iload_1
      //   254: iload #7
      //   256: iload #6
      //   258: isub
      //   259: aload_0
      //   260: invokevirtual v : ()I
      //   263: isub
      //   264: aload_0
      //   265: invokevirtual P : ()I
      //   268: isub
      //   269: iadd
      //   270: istore_1
      //   271: goto -> 284
      //   274: iload_1
      //   275: iload #5
      //   277: aload_0
      //   278: invokevirtual P : ()I
      //   281: iadd
      //   282: iadd
      //   283: istore_1
      //   284: aload_0
      //   285: iload_1
      //   286: invokevirtual e : (I)V
      //   289: return
    }
    
    public int P() {
      return this.a0;
    }
    
    boolean Q(View param1View) {
      return (t0.A(param1View) && param1View.getGlobalVisibleRect(this.Z));
    }
    
    public CharSequence f() {
      return this.X;
    }
    
    public void i(CharSequence param1CharSequence) {
      this.X = param1CharSequence;
    }
    
    public void m(int param1Int) {
      this.a0 = param1Int;
    }
    
    public void n(int param1Int1, int param1Int2) {
      boolean bool = a();
      O();
      E(2);
      b();
      ListView listView = j();
      listView.setChoiceMode(1);
      listView.setTextDirection(param1Int1);
      listView.setTextAlignment(param1Int2);
      L(this.b0.getSelectedItemPosition());
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.b0.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        G(new c(this, b));
      } 
    }
    
    public void p(ListAdapter param1ListAdapter) {
      super.p(param1ListAdapter);
      this.Y = param1ListAdapter;
    }
    
    class a implements AdapterView.OnItemClickListener {
      a(x.e this$0, x param2x) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.b.b0.setSelection(param2Int);
        if (this.b.b0.getOnItemClickListener() != null) {
          x.e e1 = this.b;
          e1.b0.performItemClick(param2View, param2Int, e1.Y.getItemId(param2Int));
        } 
        this.b.dismiss();
      }
    }
    
    class b implements ViewTreeObserver.OnGlobalLayoutListener {
      b(x.e this$0) {}
      
      public void onGlobalLayout() {
        x.e e1 = this.a;
        if (!e1.Q((View)e1.b0)) {
          this.a.dismiss();
          return;
        } 
        this.a.O();
        x.e.N(this.a);
      }
    }
    
    class c implements PopupWindow.OnDismissListener {
      c(x.e this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.b.b0.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.a); 
      }
    }
  }
  
  class a implements AdapterView.OnItemClickListener {
    a(x this$0, x param1x) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.b.b0.setSelection(param1Int);
      if (this.b.b0.getOnItemClickListener() != null) {
        x.e e1 = this.b;
        e1.b0.performItemClick(param1View, param1Int, e1.Y.getItemId(param1Int));
      } 
      this.b.dismiss();
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(x this$0) {}
    
    public void onGlobalLayout() {
      x.e e1 = this.a;
      if (!e1.Q((View)e1.b0)) {
        this.a.dismiss();
        return;
      } 
      this.a.O();
      x.e.N(this.a);
    }
  }
  
  class c implements PopupWindow.OnDismissListener {
    c(x this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.b.b0.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.a); 
    }
  }
  
  static class f extends View.BaseSavedState {
    public static final Parcelable.Creator<f> CREATOR = new a();
    
    boolean a;
    
    f(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.a = bool;
    }
    
    f(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.a);
    }
    
    class a implements Parcelable.Creator<f> {
      public x.f a(Parcel param2Parcel) {
        return new x.f(param2Parcel);
      }
      
      public x.f[] b(int param2Int) {
        return new x.f[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<f> {
    public x.f a(Parcel param1Parcel) {
      return new x.f(param1Parcel);
    }
    
    public x.f[] b(int param1Int) {
      return new x.f[param1Int];
    }
  }
  
  static interface g {
    boolean a();
    
    int c();
    
    void dismiss();
    
    void e(int param1Int);
    
    CharSequence f();
    
    Drawable h();
    
    void i(CharSequence param1CharSequence);
    
    void k(Drawable param1Drawable);
    
    void l(int param1Int);
    
    void m(int param1Int);
    
    void n(int param1Int1, int param1Int2);
    
    int o();
    
    void p(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */