package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import e.a;
import g.b;

public class r extends RadioButton {
  private final i a;
  
  private final e b;
  
  private final l0 c;
  
  public r(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.E);
  }
  
  public r(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(z1.b(paramContext), paramAttributeSet, paramInt);
    x1.a((View)this, getContext());
    i i1 = new i((CompoundButton)this);
    this.a = i1;
    i1.e(paramAttributeSet, paramInt);
    e e1 = new e((View)this);
    this.b = e1;
    e1.e(paramAttributeSet, paramInt);
    l0 l01 = new l0((TextView)this);
    this.c = l01;
    l01.m(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.b;
    if (e1 != null)
      e1.b(); 
    l0 l01 = this.c;
    if (l01 != null)
      l01.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int k = super.getCompoundPaddingLeft();
    i i1 = this.a;
    int j = k;
    if (i1 != null)
      j = i1.b(k); 
    return j;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.b;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.b;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    i i1 = this.a;
    return (i1 != null) ? i1.c() : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    i i1 = this.a;
    return (i1 != null) ? i1.d() : null;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.b;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.b;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(b.d(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    i i1 = this.a;
    if (i1 != null)
      i1.f(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.b;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.b;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    i i1 = this.a;
    if (i1 != null)
      i1.g(paramColorStateList); 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    i i1 = this.a;
    if (i1 != null)
      i1.h(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */