package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.core.view.x1;
import androidx.core.widget.i;
import h.c;
import java.lang.reflect.Field;

class f1 extends ListView {
  private final Rect a = new Rect();
  
  private int b = 0;
  
  private int c = 0;
  
  private int d = 0;
  
  private int e = 0;
  
  private int f;
  
  private Field g;
  
  private a h;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private x1 l;
  
  private i m;
  
  b n;
  
  f1(Context paramContext, boolean paramBoolean) {
    super(paramContext, null, e.a.z);
    this.j = paramBoolean;
    setCacheColorHint(0);
    try {
      Field field = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      this.g = field;
      field.setAccessible(true);
      return;
    } catch (NoSuchFieldException noSuchFieldException) {
      noSuchFieldException.printStackTrace();
      return;
    } 
  }
  
  private void a() {
    this.k = false;
    setPressed(false);
    drawableStateChanged();
    View view = getChildAt(this.f - getFirstVisiblePosition());
    if (view != null)
      view.setPressed(false); 
    x1 x11 = this.l;
    if (x11 != null) {
      x11.c();
      this.l = null;
    } 
  }
  
  private void b(View paramView, int paramInt) {
    performItemClick(paramView, paramInt, getItemIdAtPosition(paramInt));
  }
  
  private void c(Canvas paramCanvas) {
    if (!this.a.isEmpty()) {
      Drawable drawable = getSelector();
      if (drawable != null) {
        drawable.setBounds(this.a);
        drawable.draw(paramCanvas);
      } 
    } 
  }
  
  private void f(int paramInt, View paramView) {
    Rect rect = this.a;
    rect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    rect.left -= this.b;
    rect.top -= this.c;
    rect.right += this.d;
    rect.bottom += this.e;
    try {
      boolean bool = this.g.getBoolean(this);
      if (paramView.isEnabled() != bool) {
        Field field = this.g;
        if (!bool) {
          bool = true;
        } else {
          bool = false;
        } 
        field.set(this, Boolean.valueOf(bool));
        if (paramInt != -1) {
          refreshDrawableState();
          return;
        } 
      } 
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
    } 
  }
  
  private void g(int paramInt, View paramView) {
    boolean bool1;
    Drawable drawable = getSelector();
    boolean bool2 = true;
    if (drawable != null && paramInt != -1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1)
      drawable.setVisible(false, false); 
    f(paramInt, paramView);
    if (bool1) {
      Rect rect = this.a;
      float f2 = rect.exactCenterX();
      float f3 = rect.exactCenterY();
      if (getVisibility() != 0)
        bool2 = false; 
      drawable.setVisible(bool2, false);
      androidx.core.graphics.drawable.a.j(drawable, f2, f3);
    } 
  }
  
  private void h(int paramInt, View paramView, float paramFloat1, float paramFloat2) {
    g(paramInt, paramView);
    Drawable drawable = getSelector();
    if (drawable != null && paramInt != -1)
      androidx.core.graphics.drawable.a.j(drawable, paramFloat1, paramFloat2); 
  }
  
  private void i(View paramView, int paramInt, float paramFloat1, float paramFloat2) {
    this.k = true;
    drawableHotspotChanged(paramFloat1, paramFloat2);
    if (!isPressed())
      setPressed(true); 
    layoutChildren();
    int j = this.f;
    if (j != -1) {
      View view = getChildAt(j - getFirstVisiblePosition());
      if (view != null && view != paramView && view.isPressed())
        view.setPressed(false); 
    } 
    this.f = paramInt;
    paramView.drawableHotspotChanged(paramFloat1 - paramView.getLeft(), paramFloat2 - paramView.getTop());
    if (!paramView.isPressed())
      paramView.setPressed(true); 
    h(paramInt, paramView, paramFloat1, paramFloat2);
    setSelectorEnabled(false);
    refreshDrawableState();
  }
  
  private boolean j() {
    return this.k;
  }
  
  private void k() {
    Drawable drawable = getSelector();
    if (drawable != null && j() && isPressed())
      drawable.setState(getDrawableState()); 
  }
  
  private void setSelectorEnabled(boolean paramBoolean) {
    a a1 = this.h;
    if (a1 != null)
      a1.c(paramBoolean); 
  }
  
  public int d(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    paramInt2 = getListPaddingTop();
    paramInt3 = getListPaddingBottom();
    int j = getDividerHeight();
    Drawable drawable = getDivider();
    ListAdapter listAdapter = getAdapter();
    paramInt3 = paramInt2 + paramInt3;
    if (listAdapter == null)
      return paramInt3; 
    if (j <= 0 || drawable == null)
      j = 0; 
    int n = listAdapter.getCount();
    drawable = null;
    int k = 0;
    int m = 0;
    for (paramInt2 = 0; k < n; paramInt2 = i2) {
      int i2 = listAdapter.getItemViewType(k);
      int i1 = m;
      if (i2 != m) {
        drawable = null;
        i1 = i2;
      } 
      View view2 = listAdapter.getView(k, (View)drawable, (ViewGroup)this);
      ViewGroup.LayoutParams layoutParams2 = view2.getLayoutParams();
      ViewGroup.LayoutParams layoutParams1 = layoutParams2;
      if (layoutParams2 == null) {
        layoutParams1 = generateDefaultLayoutParams();
        view2.setLayoutParams(layoutParams1);
      } 
      m = layoutParams1.height;
      if (m > 0) {
        m = View.MeasureSpec.makeMeasureSpec(m, 1073741824);
      } else {
        m = View.MeasureSpec.makeMeasureSpec(0, 0);
      } 
      view2.measure(paramInt1, m);
      view2.forceLayout();
      m = paramInt3;
      if (k > 0)
        m = paramInt3 + j; 
      paramInt3 = m + view2.getMeasuredHeight();
      if (paramInt3 >= paramInt4) {
        paramInt1 = paramInt4;
        if (paramInt5 >= 0) {
          paramInt1 = paramInt4;
          if (k > paramInt5) {
            paramInt1 = paramInt4;
            if (paramInt2 > 0) {
              paramInt1 = paramInt4;
              if (paramInt3 != paramInt4)
                paramInt1 = paramInt2; 
            } 
          } 
        } 
        return paramInt1;
      } 
      i2 = paramInt2;
      if (paramInt5 >= 0) {
        i2 = paramInt2;
        if (k >= paramInt5)
          i2 = paramInt3; 
      } 
      k++;
      m = i1;
      View view1 = view2;
    } 
    return paramInt3;
  }
  
  protected void dispatchDraw(Canvas paramCanvas) {
    c(paramCanvas);
    super.dispatchDraw(paramCanvas);
  }
  
  protected void drawableStateChanged() {
    if (this.n != null)
      return; 
    super.drawableStateChanged();
    setSelectorEnabled(true);
    k();
  }
  
  public boolean e(MotionEvent paramMotionEvent, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_3
    //   5: iload_3
    //   6: iconst_1
    //   7: if_icmpeq -> 42
    //   10: iload_3
    //   11: iconst_2
    //   12: if_icmpeq -> 36
    //   15: iload_3
    //   16: iconst_3
    //   17: if_icmpeq -> 28
    //   20: iconst_0
    //   21: istore_2
    //   22: iconst_1
    //   23: istore #6
    //   25: goto -> 139
    //   28: iconst_0
    //   29: istore_2
    //   30: iconst_0
    //   31: istore #6
    //   33: goto -> 139
    //   36: iconst_1
    //   37: istore #6
    //   39: goto -> 45
    //   42: iconst_0
    //   43: istore #6
    //   45: aload_1
    //   46: iload_2
    //   47: invokevirtual findPointerIndex : (I)I
    //   50: istore #4
    //   52: iload #4
    //   54: ifge -> 60
    //   57: goto -> 28
    //   60: aload_1
    //   61: iload #4
    //   63: invokevirtual getX : (I)F
    //   66: f2i
    //   67: istore_2
    //   68: aload_1
    //   69: iload #4
    //   71: invokevirtual getY : (I)F
    //   74: f2i
    //   75: istore #4
    //   77: aload_0
    //   78: iload_2
    //   79: iload #4
    //   81: invokevirtual pointToPosition : (II)I
    //   84: istore #5
    //   86: iload #5
    //   88: iconst_m1
    //   89: if_icmpne -> 97
    //   92: iconst_1
    //   93: istore_2
    //   94: goto -> 139
    //   97: aload_0
    //   98: iload #5
    //   100: aload_0
    //   101: invokevirtual getFirstVisiblePosition : ()I
    //   104: isub
    //   105: invokevirtual getChildAt : (I)Landroid/view/View;
    //   108: astore #7
    //   110: aload_0
    //   111: aload #7
    //   113: iload #5
    //   115: iload_2
    //   116: i2f
    //   117: iload #4
    //   119: i2f
    //   120: invokespecial i : (Landroid/view/View;IFF)V
    //   123: iload_3
    //   124: iconst_1
    //   125: if_icmpne -> 20
    //   128: aload_0
    //   129: aload #7
    //   131: iload #5
    //   133: invokespecial b : (Landroid/view/View;I)V
    //   136: goto -> 20
    //   139: iload #6
    //   141: ifeq -> 148
    //   144: iload_2
    //   145: ifeq -> 152
    //   148: aload_0
    //   149: invokespecial a : ()V
    //   152: iload #6
    //   154: ifeq -> 198
    //   157: aload_0
    //   158: getfield m : Landroidx/core/widget/i;
    //   161: ifnonnull -> 176
    //   164: aload_0
    //   165: new androidx/core/widget/i
    //   168: dup
    //   169: aload_0
    //   170: invokespecial <init> : (Landroid/widget/ListView;)V
    //   173: putfield m : Landroidx/core/widget/i;
    //   176: aload_0
    //   177: getfield m : Landroidx/core/widget/i;
    //   180: iconst_1
    //   181: invokevirtual m : (Z)Landroidx/core/widget/a;
    //   184: pop
    //   185: aload_0
    //   186: getfield m : Landroidx/core/widget/i;
    //   189: aload_0
    //   190: aload_1
    //   191: invokevirtual onTouch : (Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   194: pop
    //   195: iload #6
    //   197: ireturn
    //   198: aload_0
    //   199: getfield m : Landroidx/core/widget/i;
    //   202: astore_1
    //   203: aload_1
    //   204: ifnull -> 213
    //   207: aload_1
    //   208: iconst_0
    //   209: invokevirtual m : (Z)Landroidx/core/widget/a;
    //   212: pop
    //   213: iload #6
    //   215: ireturn
  }
  
  public boolean hasFocus() {
    return (this.j || super.hasFocus());
  }
  
  public boolean hasWindowFocus() {
    return (this.j || super.hasWindowFocus());
  }
  
  public boolean isFocused() {
    return (this.j || super.isFocused());
  }
  
  public boolean isInTouchMode() {
    return ((this.j && this.i) || super.isInTouchMode());
  }
  
  protected void onDetachedFromWindow() {
    this.n = null;
    super.onDetachedFromWindow();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    if (Build.VERSION.SDK_INT < 26)
      return super.onHoverEvent(paramMotionEvent); 
    int j = paramMotionEvent.getActionMasked();
    if (j == 10 && this.n == null) {
      b b1 = new b(this);
      this.n = b1;
      b1.b();
    } 
    boolean bool = super.onHoverEvent(paramMotionEvent);
    if (j == 9 || j == 7) {
      j = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
      if (j != -1 && j != getSelectedItemPosition()) {
        View view = getChildAt(j - getFirstVisiblePosition());
        if (view.isEnabled())
          setSelectionFromTop(j, view.getTop() - getTop()); 
        k();
      } 
      return bool;
    } 
    setSelection(-1);
    return bool;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 0)
      this.f = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()); 
    b b1 = this.n;
    if (b1 != null)
      b1.a(); 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  void setListSelectionHidden(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  public void setSelector(Drawable paramDrawable) {
    a a1;
    if (paramDrawable != null) {
      a1 = new a(paramDrawable);
    } else {
      a1 = null;
    } 
    this.h = a1;
    super.setSelector((Drawable)a1);
    Rect rect = new Rect();
    if (paramDrawable != null)
      paramDrawable.getPadding(rect); 
    this.b = rect.left;
    this.c = rect.top;
    this.d = rect.right;
    this.e = rect.bottom;
  }
  
  private static class a extends c {
    private boolean b = true;
    
    a(Drawable param1Drawable) {
      super(param1Drawable);
    }
    
    void c(boolean param1Boolean) {
      this.b = param1Boolean;
    }
    
    public void draw(Canvas param1Canvas) {
      if (this.b)
        super.draw(param1Canvas); 
    }
    
    public void setHotspot(float param1Float1, float param1Float2) {
      if (this.b)
        super.setHotspot(param1Float1, param1Float2); 
    }
    
    public void setHotspotBounds(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (this.b)
        super.setHotspotBounds(param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public boolean setState(int[] param1ArrayOfint) {
      return this.b ? super.setState(param1ArrayOfint) : false;
    }
    
    public boolean setVisible(boolean param1Boolean1, boolean param1Boolean2) {
      return this.b ? super.setVisible(param1Boolean1, param1Boolean2) : false;
    }
  }
  
  private class b implements Runnable {
    b(f1 this$0) {}
    
    public void a() {
      f1 f11 = this.a;
      f11.n = null;
      f11.removeCallbacks(this);
    }
    
    public void b() {
      this.a.post(this);
    }
    
    public void run() {
      f1 f11 = this.a;
      f11.n = null;
      f11.drawableStateChanged();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */