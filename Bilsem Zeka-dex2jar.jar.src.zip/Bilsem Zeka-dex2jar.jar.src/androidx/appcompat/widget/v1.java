package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class v1 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  private static final Interpolator j = (Interpolator)new DecelerateInterpolator();
  
  Runnable a;
  
  private c b;
  
  i1 c;
  
  private Spinner d;
  
  private boolean e;
  
  int f;
  
  int g;
  
  private int h;
  
  private int i;
  
  private Spinner b() {
    x x = new x(getContext(), null, e.a.h);
    x.setLayoutParams((ViewGroup.LayoutParams)new i1.a(-2, -1));
    x.setOnItemSelectedListener(this);
    return x;
  }
  
  private boolean d() {
    Spinner spinner = this.d;
    return (spinner != null && spinner.getParent() == this);
  }
  
  private void e() {
    if (d())
      return; 
    if (this.d == null)
      this.d = b(); 
    removeView((View)this.c);
    addView((View)this.d, new ViewGroup.LayoutParams(-2, -1));
    if (this.d.getAdapter() == null)
      this.d.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.a;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.a = null;
    } 
    this.d.setSelection(this.i);
  }
  
  private boolean f() {
    if (!d())
      return false; 
    removeView((View)this.d);
    addView((View)this.c, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.d.getSelectedItemPosition());
    return false;
  }
  
  public void a(int paramInt) {
    View view = this.c.getChildAt(paramInt);
    Runnable runnable = this.a;
    if (runnable != null)
      removeCallbacks(runnable); 
    a a = new a(this, view);
    this.a = a;
    post(a);
  }
  
  d c(androidx.appcompat.app.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.h));
      return d;
    } 
    d.setFocusable(true);
    if (this.b == null)
      this.b = new c(this); 
    d.setOnClickListener(this.b);
    return d;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.a;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    j.a a = j.a.b(getContext());
    setContentHeight(a.f());
    this.g = a.e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.a;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).b().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore_2
    //   5: iconst_1
    //   6: istore_3
    //   7: iload_2
    //   8: ldc 1073741824
    //   10: if_icmpne -> 19
    //   13: iconst_1
    //   14: istore #5
    //   16: goto -> 22
    //   19: iconst_0
    //   20: istore #5
    //   22: aload_0
    //   23: iload #5
    //   25: invokevirtual setFillViewport : (Z)V
    //   28: aload_0
    //   29: getfield c : Landroidx/appcompat/widget/i1;
    //   32: invokevirtual getChildCount : ()I
    //   35: istore #4
    //   37: iload #4
    //   39: iconst_1
    //   40: if_icmple -> 102
    //   43: iload_2
    //   44: ldc 1073741824
    //   46: if_icmpeq -> 55
    //   49: iload_2
    //   50: ldc -2147483648
    //   52: if_icmpne -> 102
    //   55: iload #4
    //   57: iconst_2
    //   58: if_icmple -> 77
    //   61: aload_0
    //   62: iload_1
    //   63: invokestatic getSize : (I)I
    //   66: i2f
    //   67: ldc 0.4
    //   69: fmul
    //   70: f2i
    //   71: putfield f : I
    //   74: goto -> 87
    //   77: aload_0
    //   78: iload_1
    //   79: invokestatic getSize : (I)I
    //   82: iconst_2
    //   83: idiv
    //   84: putfield f : I
    //   87: aload_0
    //   88: getfield f : I
    //   91: aload_0
    //   92: getfield g : I
    //   95: invokestatic min : (II)I
    //   98: istore_2
    //   99: goto -> 104
    //   102: iconst_m1
    //   103: istore_2
    //   104: aload_0
    //   105: iload_2
    //   106: putfield f : I
    //   109: aload_0
    //   110: getfield h : I
    //   113: ldc 1073741824
    //   115: invokestatic makeMeasureSpec : (II)I
    //   118: istore #4
    //   120: iload #5
    //   122: ifne -> 137
    //   125: aload_0
    //   126: getfield e : Z
    //   129: ifeq -> 137
    //   132: iload_3
    //   133: istore_2
    //   134: goto -> 139
    //   137: iconst_0
    //   138: istore_2
    //   139: iload_2
    //   140: ifeq -> 174
    //   143: aload_0
    //   144: getfield c : Landroidx/appcompat/widget/i1;
    //   147: iconst_0
    //   148: iload #4
    //   150: invokevirtual measure : (II)V
    //   153: aload_0
    //   154: getfield c : Landroidx/appcompat/widget/i1;
    //   157: invokevirtual getMeasuredWidth : ()I
    //   160: iload_1
    //   161: invokestatic getSize : (I)I
    //   164: if_icmple -> 174
    //   167: aload_0
    //   168: invokespecial e : ()V
    //   171: goto -> 179
    //   174: aload_0
    //   175: invokespecial f : ()Z
    //   178: pop
    //   179: aload_0
    //   180: invokevirtual getMeasuredWidth : ()I
    //   183: istore_2
    //   184: aload_0
    //   185: iload_1
    //   186: iload #4
    //   188: invokespecial onMeasure : (II)V
    //   191: aload_0
    //   192: invokevirtual getMeasuredWidth : ()I
    //   195: istore_1
    //   196: iload #5
    //   198: ifeq -> 214
    //   201: iload_2
    //   202: iload_1
    //   203: if_icmpeq -> 214
    //   206: aload_0
    //   207: aload_0
    //   208: getfield i : I
    //   211: invokevirtual setTabSelected : (I)V
    //   214: return
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.h = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.i = paramInt;
    int j = this.c.getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      View view = this.c.getChildAt(i);
      if (i == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        a(paramInt); 
    } 
    Spinner spinner = this.d;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  class a implements Runnable {
    a(v1 this$0, View param1View) {}
    
    public void run() {
      int i = this.a.getLeft();
      int j = (this.b.getWidth() - this.a.getWidth()) / 2;
      this.b.smoothScrollTo(i - j, 0);
      this.b.a = null;
    }
  }
  
  private class b extends BaseAdapter {
    b(v1 this$0) {}
    
    public int getCount() {
      return this.a.c.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((v1.d)this.a.c.getChildAt(param1Int)).b();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        return (View)this.a.c((androidx.appcompat.app.a.c)getItem(param1Int), true); 
      ((v1.d)param1View).a((androidx.appcompat.app.a.c)getItem(param1Int));
      return param1View;
    }
  }
  
  private class c implements View.OnClickListener {
    c(v1 this$0) {}
    
    public void onClick(View param1View) {
      ((v1.d)param1View).b().e();
      int j = this.a.c.getChildCount();
      for (int i = 0; i < j; i++) {
        boolean bool;
        View view = this.a.c.getChildAt(i);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] a;
    
    private androidx.appcompat.app.a.c b;
    
    private TextView c;
    
    private ImageView d;
    
    private View e;
    
    public d(v1 this$0, Context param1Context, androidx.appcompat.app.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, i);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 16842964;
      this.a = arrayOfInt;
      this.b = param1c;
      c2 c2 = c2.u(param1Context, null, arrayOfInt, i, 0);
      if (c2.r(0))
        setBackgroundDrawable(c2.f(0)); 
      c2.v();
      if (param1Boolean)
        setGravity(8388627); 
      c();
    }
    
    public void a(androidx.appcompat.app.a.c param1c) {
      this.b = param1c;
      c();
    }
    
    public androidx.appcompat.app.a.c b() {
      return this.b;
    }
    
    public void c() {
      androidx.appcompat.app.a.c c1 = this.b;
      View view = c1.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.e = view;
        TextView textView = this.c;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.d;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.d.setImageDrawable(null);
          return;
        } 
      } else {
        CharSequence charSequence1;
        view = this.e;
        if (view != null) {
          removeView(view);
          this.e = null;
        } 
        Drawable drawable = c1.c();
        CharSequence charSequence2 = c1.d();
        if (drawable != null) {
          if (this.d == null) {
            AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatImageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatImageView, 0);
            this.d = appCompatImageView;
          } 
          this.d.setImageDrawable(drawable);
          this.d.setVisibility(0);
        } else {
          ImageView imageView1 = this.d;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.d.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.c == null) {
            m0 m0 = new m0(getContext(), null, e.a.e);
            m0.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            m0.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)m0);
            this.c = m0;
          } 
          this.c.setText(charSequence2);
          this.c.setVisibility(0);
        } else {
          TextView textView = this.c;
          if (textView != null) {
            textView.setVisibility(8);
            this.c.setText(null);
          } 
        } 
        ImageView imageView = this.d;
        if (imageView != null)
          imageView.setContentDescription(c1.a()); 
        if (i == 0)
          charSequence1 = c1.a(); 
        f2.a((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.f.f > 0) {
        param1Int1 = getMeasuredWidth();
        int i = this.f.f;
        if (param1Int1 > i)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\v1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */