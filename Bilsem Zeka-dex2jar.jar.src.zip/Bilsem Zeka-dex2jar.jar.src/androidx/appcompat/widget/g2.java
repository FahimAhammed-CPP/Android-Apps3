package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.t0;
import androidx.core.view.t1;

class g2 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  private static g2 j;
  
  private static g2 k;
  
  private final View a;
  
  private final CharSequence b;
  
  private final int c;
  
  private final Runnable d = new a(this);
  
  private final Runnable e = new b(this);
  
  private int f;
  
  private int g;
  
  private h2 h;
  
  private boolean i;
  
  private g2(View paramView, CharSequence paramCharSequence) {
    this.a = paramView;
    this.b = paramCharSequence;
    this.c = t1.a(ViewConfiguration.get(paramView.getContext()));
    b();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  private void a() {
    this.a.removeCallbacks(this.d);
  }
  
  private void b() {
    this.f = Integer.MAX_VALUE;
    this.g = Integer.MAX_VALUE;
  }
  
  private void d() {
    this.a.postDelayed(this.d, ViewConfiguration.getLongPressTimeout());
  }
  
  private static void e(g2 paramg2) {
    g2 g21 = j;
    if (g21 != null)
      g21.a(); 
    j = paramg2;
    if (paramg2 != null)
      paramg2.d(); 
  }
  
  public static void f(View paramView, CharSequence paramCharSequence) {
    g2 g21;
    g2 g22 = j;
    if (g22 != null && g22.a == paramView)
      e(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      g21 = k;
      if (g21 != null && g21.a == paramView)
        g21.c(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new g2(paramView, (CharSequence)g21);
  }
  
  private boolean h(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (Math.abs(i - this.f) <= this.c && Math.abs(j - this.g) <= this.c)
      return false; 
    this.f = i;
    this.g = j;
    return true;
  }
  
  void c() {
    if (k == this) {
      k = null;
      h2 h21 = this.h;
      if (h21 != null) {
        h21.c();
        this.h = null;
        b();
        this.a.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (j == this)
      e(null); 
    this.a.removeCallbacks(this.e);
  }
  
  void g(boolean paramBoolean) {
    long l;
    if (!t0.A(this.a))
      return; 
    e(null);
    g2 g21 = k;
    if (g21 != null)
      g21.c(); 
    k = this;
    this.i = paramBoolean;
    h2 h21 = new h2(this.a.getContext());
    this.h = h21;
    h21.e(this.a, this.f, this.g, this.i, this.b);
    this.a.addOnAttachStateChangeListener(this);
    if (this.i) {
      l = 2500L;
    } else {
      long l1;
      if ((t0.w(this.a) & 0x1) == 1) {
        l = ViewConfiguration.getLongPressTimeout();
        l1 = 3000L;
      } else {
        l = ViewConfiguration.getLongPressTimeout();
        l1 = 15000L;
      } 
      l = l1 - l;
    } 
    this.a.removeCallbacks(this.e);
    this.a.postDelayed(this.e, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.h != null && this.i)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.a.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      b();
      c();
      return false;
    } 
    if (this.a.isEnabled() && this.h == null && h(paramMotionEvent))
      e(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.f = paramView.getWidth() / 2;
    this.g = paramView.getHeight() / 2;
    g(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    c();
  }
  
  class a implements Runnable {
    a(g2 this$0) {}
    
    public void run() {
      this.a.g(false);
    }
  }
  
  class b implements Runnable {
    b(g2 this$0) {}
    
    public void run() {
      this.a.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\g2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */