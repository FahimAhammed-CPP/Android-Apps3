package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import e.c;
import e.d;
import e.e;
import g.b;

public final class j {
  private static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;
  
  private static j c;
  
  private s1 a;
  
  public static j b() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/j
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   6: ifnonnull -> 12
    //   9: invokestatic h : ()V
    //   12: getstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   15: astore_0
    //   16: ldc androidx/appcompat/widget/j
    //   18: monitorexit
    //   19: aload_0
    //   20: areturn
    //   21: astore_0
    //   22: ldc androidx/appcompat/widget/j
    //   24: monitorexit
    //   25: aload_0
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   3	12	21	finally
    //   12	16	21	finally
  }
  
  public static PorterDuffColorFilter e(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/j
    //   2: monitorenter
    //   3: iload_0
    //   4: aload_1
    //   5: invokestatic l : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   8: astore_1
    //   9: ldc androidx/appcompat/widget/j
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: ldc androidx/appcompat/widget/j
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	14	finally
  }
  
  public static void h() {
    // Byte code:
    //   0: ldc androidx/appcompat/widget/j
    //   2: monitorenter
    //   3: getstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   6: ifnonnull -> 44
    //   9: new androidx/appcompat/widget/j
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   21: aload_0
    //   22: invokestatic h : ()Landroidx/appcompat/widget/s1;
    //   25: putfield a : Landroidx/appcompat/widget/s1;
    //   28: getstatic androidx/appcompat/widget/j.c : Landroidx/appcompat/widget/j;
    //   31: getfield a : Landroidx/appcompat/widget/s1;
    //   34: new androidx/appcompat/widget/j$a
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: invokevirtual u : (Landroidx/appcompat/widget/s1$f;)V
    //   44: ldc androidx/appcompat/widget/j
    //   46: monitorexit
    //   47: return
    //   48: astore_0
    //   49: ldc androidx/appcompat/widget/j
    //   51: monitorexit
    //   52: aload_0
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   3	44	48	finally
  }
  
  static void i(Drawable paramDrawable, a2 parama2, int[] paramArrayOfint) {
    s1.w(paramDrawable, parama2, paramArrayOfint);
  }
  
  public Drawable c(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/s1;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual j : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  Drawable d(Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/s1;
    //   6: aload_1
    //   7: iload_2
    //   8: iload_3
    //   9: invokevirtual k : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  ColorStateList f(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/s1;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual m : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public void g(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroidx/appcompat/widget/s1;
    //   6: aload_1
    //   7: invokevirtual s : (Landroid/content/Context;)V
    //   10: aload_0
    //   11: monitorexit
    //   12: return
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	13	finally
  }
  
  class a implements s1.f {
    private final int[] a = new int[] { e.R, e.P, e.a };
    
    private final int[] b = new int[] { e.o, e.B, e.t, e.p, e.q, e.s, e.r };
    
    private final int[] c = new int[] { e.O, e.Q, e.k, e.K, e.L, e.M, e.N };
    
    private final int[] d = new int[] { e.w, e.i, e.v };
    
    private final int[] e = new int[] { e.J, e.S };
    
    private final int[] f = new int[] { e.c, e.g, e.d, e.h };
    
    private boolean f(int[] param1ArrayOfint, int param1Int) {
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++) {
        if (param1ArrayOfint[i] == param1Int)
          return true; 
      } 
      return false;
    }
    
    private ColorStateList g(Context param1Context) {
      return h(param1Context, 0);
    }
    
    private ColorStateList h(Context param1Context, int param1Int) {
      int k = x1.c(param1Context, e.a.v);
      int i = x1.b(param1Context, e.a.t);
      int[] arrayOfInt1 = x1.b;
      int[] arrayOfInt2 = x1.e;
      int j = androidx.core.graphics.a.c(k, param1Int);
      int[] arrayOfInt3 = x1.c;
      k = androidx.core.graphics.a.c(k, param1Int);
      return new ColorStateList(new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, x1.i }, new int[] { i, j, k, param1Int });
    }
    
    private ColorStateList i(Context param1Context) {
      return h(param1Context, x1.c(param1Context, e.a.s));
    }
    
    private ColorStateList j(Context param1Context) {
      return h(param1Context, x1.c(param1Context, e.a.t));
    }
    
    private ColorStateList k(Context param1Context) {
      int[][] arrayOfInt = new int[3][];
      int[] arrayOfInt1 = new int[3];
      int i = e.a.x;
      ColorStateList colorStateList = x1.e(param1Context, i);
      if (colorStateList != null && colorStateList.isStateful()) {
        int[] arrayOfInt2 = x1.b;
        arrayOfInt[0] = arrayOfInt2;
        arrayOfInt1[0] = colorStateList.getColorForState(arrayOfInt2, 0);
        arrayOfInt[1] = x1.f;
        arrayOfInt1[1] = x1.c(param1Context, e.a.u);
        arrayOfInt[2] = x1.i;
        arrayOfInt1[2] = colorStateList.getDefaultColor();
      } else {
        arrayOfInt[0] = x1.b;
        arrayOfInt1[0] = x1.b(param1Context, i);
        arrayOfInt[1] = x1.f;
        arrayOfInt1[1] = x1.c(param1Context, e.a.u);
        arrayOfInt[2] = x1.i;
        arrayOfInt1[2] = x1.c(param1Context, i);
      } 
      return new ColorStateList(arrayOfInt, arrayOfInt1);
    }
    
    private LayerDrawable l(s1 param1s1, Context param1Context, int param1Int) {
      BitmapDrawable bitmapDrawable1;
      BitmapDrawable bitmapDrawable2;
      BitmapDrawable bitmapDrawable3;
      param1Int = param1Context.getResources().getDimensionPixelSize(param1Int);
      Drawable drawable2 = param1s1.j(param1Context, e.F);
      Drawable drawable1 = param1s1.j(param1Context, e.G);
      if (drawable2 instanceof BitmapDrawable && drawable2.getIntrinsicWidth() == param1Int && drawable2.getIntrinsicHeight() == param1Int) {
        bitmapDrawable1 = (BitmapDrawable)drawable2;
        bitmapDrawable2 = new BitmapDrawable(bitmapDrawable1.getBitmap());
      } else {
        Bitmap bitmap = Bitmap.createBitmap(param1Int, param1Int, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, param1Int, param1Int);
        drawable2.draw(canvas);
        bitmapDrawable1 = new BitmapDrawable(bitmap);
        bitmapDrawable2 = new BitmapDrawable(bitmap);
      } 
      bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
      if (drawable1 instanceof BitmapDrawable && drawable1.getIntrinsicWidth() == param1Int && drawable1.getIntrinsicHeight() == param1Int) {
        bitmapDrawable3 = (BitmapDrawable)drawable1;
      } else {
        Bitmap bitmap = Bitmap.createBitmap(param1Int, param1Int, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        bitmapDrawable3.setBounds(0, 0, param1Int, param1Int);
        bitmapDrawable3.draw(canvas);
        bitmapDrawable3 = new BitmapDrawable(bitmap);
      } 
      LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { (Drawable)bitmapDrawable1, (Drawable)bitmapDrawable3, (Drawable)bitmapDrawable2 });
      layerDrawable.setId(0, 16908288);
      layerDrawable.setId(1, 16908303);
      layerDrawable.setId(2, 16908301);
      return layerDrawable;
    }
    
    private void m(Drawable param1Drawable, int param1Int, PorterDuff.Mode param1Mode) {
      Drawable drawable = param1Drawable;
      if (e1.a(param1Drawable))
        drawable = param1Drawable.mutate(); 
      PorterDuff.Mode mode = param1Mode;
      if (param1Mode == null)
        mode = j.a(); 
      drawable.setColorFilter((ColorFilter)j.e(param1Int, mode));
    }
    
    public boolean a(Context param1Context, int param1Int, Drawable param1Drawable) {
      // Byte code:
      //   0: invokestatic a : ()Landroid/graphics/PorterDuff$Mode;
      //   3: astore #6
      //   5: aload_0
      //   6: aload_0
      //   7: getfield a : [I
      //   10: iload_2
      //   11: invokespecial f : ([II)Z
      //   14: ifeq -> 30
      //   17: getstatic e/a.w : I
      //   20: istore #5
      //   22: iconst_m1
      //   23: istore_2
      //   24: iconst_1
      //   25: istore #4
      //   27: goto -> 118
      //   30: aload_0
      //   31: aload_0
      //   32: getfield c : [I
      //   35: iload_2
      //   36: invokespecial f : ([II)Z
      //   39: ifeq -> 50
      //   42: getstatic e/a.u : I
      //   45: istore #5
      //   47: goto -> 22
      //   50: aload_0
      //   51: aload_0
      //   52: getfield d : [I
      //   55: iload_2
      //   56: invokespecial f : ([II)Z
      //   59: ifeq -> 75
      //   62: getstatic android/graphics/PorterDuff$Mode.MULTIPLY : Landroid/graphics/PorterDuff$Mode;
      //   65: astore #6
      //   67: ldc_w 16842801
      //   70: istore #5
      //   72: goto -> 22
      //   75: iload_2
      //   76: getstatic e/e.u : I
      //   79: if_icmpne -> 100
      //   82: ldc_w 40.8
      //   85: invokestatic round : (F)I
      //   88: istore_2
      //   89: iconst_1
      //   90: istore #4
      //   92: ldc_w 16842800
      //   95: istore #5
      //   97: goto -> 118
      //   100: iload_2
      //   101: getstatic e/e.l : I
      //   104: if_icmpne -> 110
      //   107: goto -> 67
      //   110: iconst_0
      //   111: istore #5
      //   113: iconst_m1
      //   114: istore_2
      //   115: iconst_0
      //   116: istore #4
      //   118: iload #4
      //   120: ifeq -> 168
      //   123: aload_3
      //   124: astore #7
      //   126: aload_3
      //   127: invokestatic a : (Landroid/graphics/drawable/Drawable;)Z
      //   130: ifeq -> 139
      //   133: aload_3
      //   134: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
      //   137: astore #7
      //   139: aload #7
      //   141: aload_1
      //   142: iload #5
      //   144: invokestatic c : (Landroid/content/Context;I)I
      //   147: aload #6
      //   149: invokestatic e : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
      //   152: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
      //   155: iload_2
      //   156: iconst_m1
      //   157: if_icmpeq -> 166
      //   160: aload #7
      //   162: iload_2
      //   163: invokevirtual setAlpha : (I)V
      //   166: iconst_1
      //   167: ireturn
      //   168: iconst_0
      //   169: ireturn
    }
    
    public PorterDuff.Mode b(int param1Int) {
      return (param1Int == e.H) ? PorterDuff.Mode.MULTIPLY : null;
    }
    
    public Drawable c(s1 param1s1, Context param1Context, int param1Int) {
      if (param1Int == e.j)
        return (Drawable)new LayerDrawable(new Drawable[] { param1s1.j(param1Context, e.i), param1s1.j(param1Context, e.k) }); 
      if (param1Int == e.y) {
        param1Int = d.i;
        return (Drawable)l(param1s1, param1Context, param1Int);
      } 
      if (param1Int == e.x) {
        param1Int = d.j;
        return (Drawable)l(param1s1, param1Context, param1Int);
      } 
      if (param1Int == e.z) {
        param1Int = d.k;
        return (Drawable)l(param1s1, param1Context, param1Int);
      } 
      return null;
    }
    
    public ColorStateList d(Context param1Context, int param1Int) {
      return (param1Int == e.m) ? b.c(param1Context, c.e) : ((param1Int == e.I) ? b.c(param1Context, c.h) : ((param1Int == e.H) ? k(param1Context) : ((param1Int == e.f) ? j(param1Context) : ((param1Int == e.b) ? g(param1Context) : ((param1Int == e.e) ? i(param1Context) : ((param1Int == e.D || param1Int == e.E) ? b.c(param1Context, c.g) : (f(this.b, param1Int) ? x1.e(param1Context, e.a.w) : (f(this.e, param1Int) ? b.c(param1Context, c.d) : (f(this.f, param1Int) ? b.c(param1Context, c.c) : ((param1Int == e.A) ? b.c(param1Context, c.f) : null))))))))));
    }
    
    public boolean e(Context param1Context, int param1Int, Drawable param1Drawable) {
      Drawable drawable1;
      Drawable drawable2;
      if (param1Int == e.C) {
        LayerDrawable layerDrawable = (LayerDrawable)param1Drawable;
        Drawable drawable = layerDrawable.findDrawableByLayerId(16908288);
        param1Int = e.a.w;
        m(drawable, x1.c(param1Context, param1Int), j.a());
        m(layerDrawable.findDrawableByLayerId(16908303), x1.c(param1Context, param1Int), j.a());
        drawable2 = layerDrawable.findDrawableByLayerId(16908301);
        param1Int = x1.c(param1Context, e.a.u);
        drawable1 = drawable2;
        m(drawable1, param1Int, j.a());
        return true;
      } 
      if (param1Int == e.y || param1Int == e.x || param1Int == e.z) {
        LayerDrawable layerDrawable = (LayerDrawable)drawable2;
        m(layerDrawable.findDrawableByLayerId(16908288), x1.b((Context)drawable1, e.a.w), j.a());
        Drawable drawable4 = layerDrawable.findDrawableByLayerId(16908303);
        param1Int = e.a.u;
        m(drawable4, x1.c((Context)drawable1, param1Int), j.a());
        Drawable drawable3 = layerDrawable.findDrawableByLayerId(16908301);
        param1Int = x1.c((Context)drawable1, param1Int);
        drawable1 = drawable3;
        m(drawable1, param1Int, j.a());
        return true;
      } 
      return false;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */