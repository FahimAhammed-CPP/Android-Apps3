package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.e;

public interface n1 {
  void d(e parame, MenuItem paramMenuItem);
  
  void g(e parame, MenuItem paramMenuItem);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\n1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */