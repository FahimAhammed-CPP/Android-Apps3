package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import e.a;

public class m extends ImageButton {
  private final e a;
  
  private final n b;
  
  public m(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.B);
  }
  
  public m(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(z1.b(paramContext), paramAttributeSet, paramInt);
    x1.a((View)this, getContext());
    e e1 = new e((View)this);
    this.a = e1;
    e1.e(paramAttributeSet, paramInt);
    n n1 = new n((ImageView)this);
    this.b = n1;
    n1.f(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.a;
    if (e1 != null)
      e1.b(); 
    n n1 = this.b;
    if (n1 != null)
      n1.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.a;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.a;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    n n1 = this.b;
    return (n1 != null) ? n1.c() : null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    n n1 = this.b;
    return (n1 != null) ? n1.d() : null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.b.e() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.a;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.a;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    n n1 = this.b;
    if (n1 != null)
      n1.b(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    super.setImageDrawable(paramDrawable);
    n n1 = this.b;
    if (n1 != null)
      n1.b(); 
  }
  
  public void setImageResource(int paramInt) {
    this.b.g(paramInt);
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    n n1 = this.b;
    if (n1 != null)
      n1.b(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.a;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.a;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    n n1 = this.b;
    if (n1 != null)
      n1.h(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    n n1 = this.b;
    if (n1 != null)
      n1.i(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */