package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.j;
import androidx.core.view.x1;

public interface d1 {
  void a(Menu paramMenu, j.a parama);
  
  boolean b();
  
  void c();
  
  void collapseActionView();
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  Context getContext();
  
  CharSequence getTitle();
  
  void h();
  
  void i(v1 paramv1);
  
  boolean j();
  
  void k(int paramInt);
  
  Menu l();
  
  void m(int paramInt);
  
  int n();
  
  x1 o(int paramInt, long paramLong);
  
  void p(j.a parama, e.a parama1);
  
  void q(int paramInt);
  
  ViewGroup r();
  
  void s(boolean paramBoolean);
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
  
  int t();
  
  void u();
  
  void v();
  
  void w(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */