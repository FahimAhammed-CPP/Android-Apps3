package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import androidx.core.widget.p;
import g.b;

public class h extends CheckedTextView {
  private static final int[] b = new int[] { 16843016 };
  
  private final l0 a;
  
  public h(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16843720);
  }
  
  public h(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(z1.b(paramContext), paramAttributeSet, paramInt);
    x1.a((View)this, getContext());
    l0 l01 = new l0((TextView)this);
    this.a = l01;
    l01.m(paramAttributeSet, paramInt);
    l01.b();
    c2 c2 = c2.u(getContext(), paramAttributeSet, b, paramInt, 0);
    setCheckMarkDrawable(c2.f(0));
    c2.v();
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    l0 l01 = this.a;
    if (l01 != null)
      l01.b(); 
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return l.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(b.d(getContext(), paramInt));
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(p.m((TextView)this, paramCallback));
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    l0 l01 = this.a;
    if (l01 != null)
      l01.q(paramContext, paramInt); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */