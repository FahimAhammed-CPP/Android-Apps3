package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.core.view.t0;
import androidx.core.widget.k;
import e.j;
import java.lang.reflect.Method;
import k.e;

public class m1 implements e {
  private static Method G;
  
  private static Method H;
  
  private static Method I;
  
  private Runnable A;
  
  final Handler B;
  
  private final Rect C = new Rect();
  
  private Rect D;
  
  private boolean E;
  
  PopupWindow F;
  
  private Context a;
  
  private ListAdapter b;
  
  f1 c;
  
  private int d = -2;
  
  private int e = -2;
  
  private int f;
  
  private int g;
  
  private int h = 1002;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private int l = 0;
  
  private boolean m = false;
  
  private boolean n = false;
  
  int o = Integer.MAX_VALUE;
  
  private View p;
  
  private int q = 0;
  
  private DataSetObserver r;
  
  private View s;
  
  private Drawable t;
  
  private AdapterView.OnItemClickListener u;
  
  private AdapterView.OnItemSelectedListener v;
  
  final g w = new g(this);
  
  private final f x = new f(this);
  
  private final e y = new e(this);
  
  private final c z = new c(this);
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        G = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        I = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        H = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public m1(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public m1(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.B = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.o1, paramInt1, paramInt2);
    this.f = typedArray.getDimensionPixelOffset(j.p1, 0);
    int i = typedArray.getDimensionPixelOffset(j.q1, 0);
    this.g = i;
    if (i != 0)
      this.i = true; 
    typedArray.recycle();
    p p = new p(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.F = p;
    p.setInputMethodMode(1);
  }
  
  private void J(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = G;
      if (method != null)
        try {
          method.invoke(this.F, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      l1.a(this.F, paramBoolean);
    } 
  }
  
  private int q() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/appcompat/widget/f1;
    //   4: astore #7
    //   6: ldc -2147483648
    //   8: istore_3
    //   9: iconst_1
    //   10: istore #6
    //   12: aload #7
    //   14: ifnonnull -> 373
    //   17: aload_0
    //   18: getfield a : Landroid/content/Context;
    //   21: astore #7
    //   23: aload_0
    //   24: new androidx/appcompat/widget/m1$a
    //   27: dup
    //   28: aload_0
    //   29: invokespecial <init> : (Landroidx/appcompat/widget/m1;)V
    //   32: putfield A : Ljava/lang/Runnable;
    //   35: aload_0
    //   36: aload #7
    //   38: aload_0
    //   39: getfield E : Z
    //   42: iconst_1
    //   43: ixor
    //   44: invokevirtual s : (Landroid/content/Context;Z)Landroidx/appcompat/widget/f1;
    //   47: astore #8
    //   49: aload_0
    //   50: aload #8
    //   52: putfield c : Landroidx/appcompat/widget/f1;
    //   55: aload_0
    //   56: getfield t : Landroid/graphics/drawable/Drawable;
    //   59: astore #9
    //   61: aload #9
    //   63: ifnull -> 73
    //   66: aload #8
    //   68: aload #9
    //   70: invokevirtual setSelector : (Landroid/graphics/drawable/Drawable;)V
    //   73: aload_0
    //   74: getfield c : Landroidx/appcompat/widget/f1;
    //   77: aload_0
    //   78: getfield b : Landroid/widget/ListAdapter;
    //   81: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   84: aload_0
    //   85: getfield c : Landroidx/appcompat/widget/f1;
    //   88: aload_0
    //   89: getfield u : Landroid/widget/AdapterView$OnItemClickListener;
    //   92: invokevirtual setOnItemClickListener : (Landroid/widget/AdapterView$OnItemClickListener;)V
    //   95: aload_0
    //   96: getfield c : Landroidx/appcompat/widget/f1;
    //   99: iconst_1
    //   100: invokevirtual setFocusable : (Z)V
    //   103: aload_0
    //   104: getfield c : Landroidx/appcompat/widget/f1;
    //   107: iconst_1
    //   108: invokevirtual setFocusableInTouchMode : (Z)V
    //   111: aload_0
    //   112: getfield c : Landroidx/appcompat/widget/f1;
    //   115: new androidx/appcompat/widget/m1$b
    //   118: dup
    //   119: aload_0
    //   120: invokespecial <init> : (Landroidx/appcompat/widget/m1;)V
    //   123: invokevirtual setOnItemSelectedListener : (Landroid/widget/AdapterView$OnItemSelectedListener;)V
    //   126: aload_0
    //   127: getfield c : Landroidx/appcompat/widget/f1;
    //   130: aload_0
    //   131: getfield y : Landroidx/appcompat/widget/m1$e;
    //   134: invokevirtual setOnScrollListener : (Landroid/widget/AbsListView$OnScrollListener;)V
    //   137: aload_0
    //   138: getfield v : Landroid/widget/AdapterView$OnItemSelectedListener;
    //   141: astore #8
    //   143: aload #8
    //   145: ifnull -> 157
    //   148: aload_0
    //   149: getfield c : Landroidx/appcompat/widget/f1;
    //   152: aload #8
    //   154: invokevirtual setOnItemSelectedListener : (Landroid/widget/AdapterView$OnItemSelectedListener;)V
    //   157: aload_0
    //   158: getfield c : Landroidx/appcompat/widget/f1;
    //   161: astore #8
    //   163: aload_0
    //   164: getfield p : Landroid/view/View;
    //   167: astore #9
    //   169: aload #9
    //   171: ifnull -> 355
    //   174: new android/widget/LinearLayout
    //   177: dup
    //   178: aload #7
    //   180: invokespecial <init> : (Landroid/content/Context;)V
    //   183: astore #7
    //   185: aload #7
    //   187: iconst_1
    //   188: invokevirtual setOrientation : (I)V
    //   191: new android/widget/LinearLayout$LayoutParams
    //   194: dup
    //   195: iconst_m1
    //   196: iconst_0
    //   197: fconst_1
    //   198: invokespecial <init> : (IIF)V
    //   201: astore #10
    //   203: aload_0
    //   204: getfield q : I
    //   207: istore_1
    //   208: iload_1
    //   209: ifeq -> 278
    //   212: iload_1
    //   213: iconst_1
    //   214: if_icmpeq -> 259
    //   217: new java/lang/StringBuilder
    //   220: dup
    //   221: invokespecial <init> : ()V
    //   224: astore #8
    //   226: aload #8
    //   228: ldc_w 'Invalid hint position '
    //   231: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   234: pop
    //   235: aload #8
    //   237: aload_0
    //   238: getfield q : I
    //   241: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   244: pop
    //   245: ldc 'ListPopupWindow'
    //   247: aload #8
    //   249: invokevirtual toString : ()Ljava/lang/String;
    //   252: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   255: pop
    //   256: goto -> 294
    //   259: aload #7
    //   261: aload #8
    //   263: aload #10
    //   265: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   268: aload #7
    //   270: aload #9
    //   272: invokevirtual addView : (Landroid/view/View;)V
    //   275: goto -> 294
    //   278: aload #7
    //   280: aload #9
    //   282: invokevirtual addView : (Landroid/view/View;)V
    //   285: aload #7
    //   287: aload #8
    //   289: aload #10
    //   291: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   294: aload_0
    //   295: getfield e : I
    //   298: istore_1
    //   299: iload_1
    //   300: iflt -> 309
    //   303: ldc -2147483648
    //   305: istore_2
    //   306: goto -> 313
    //   309: iconst_0
    //   310: istore_1
    //   311: iconst_0
    //   312: istore_2
    //   313: aload #9
    //   315: iload_1
    //   316: iload_2
    //   317: invokestatic makeMeasureSpec : (II)I
    //   320: iconst_0
    //   321: invokevirtual measure : (II)V
    //   324: aload #9
    //   326: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   329: checkcast android/widget/LinearLayout$LayoutParams
    //   332: astore #8
    //   334: aload #9
    //   336: invokevirtual getMeasuredHeight : ()I
    //   339: aload #8
    //   341: getfield topMargin : I
    //   344: iadd
    //   345: aload #8
    //   347: getfield bottomMargin : I
    //   350: iadd
    //   351: istore_1
    //   352: goto -> 361
    //   355: iconst_0
    //   356: istore_1
    //   357: aload #8
    //   359: astore #7
    //   361: aload_0
    //   362: getfield F : Landroid/widget/PopupWindow;
    //   365: aload #7
    //   367: invokevirtual setContentView : (Landroid/view/View;)V
    //   370: goto -> 429
    //   373: aload_0
    //   374: getfield F : Landroid/widget/PopupWindow;
    //   377: invokevirtual getContentView : ()Landroid/view/View;
    //   380: checkcast android/view/ViewGroup
    //   383: astore #7
    //   385: aload_0
    //   386: getfield p : Landroid/view/View;
    //   389: astore #7
    //   391: aload #7
    //   393: ifnull -> 427
    //   396: aload #7
    //   398: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   401: checkcast android/widget/LinearLayout$LayoutParams
    //   404: astore #8
    //   406: aload #7
    //   408: invokevirtual getMeasuredHeight : ()I
    //   411: aload #8
    //   413: getfield topMargin : I
    //   416: iadd
    //   417: aload #8
    //   419: getfield bottomMargin : I
    //   422: iadd
    //   423: istore_1
    //   424: goto -> 429
    //   427: iconst_0
    //   428: istore_1
    //   429: aload_0
    //   430: getfield F : Landroid/widget/PopupWindow;
    //   433: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   436: astore #7
    //   438: aload #7
    //   440: ifnull -> 499
    //   443: aload #7
    //   445: aload_0
    //   446: getfield C : Landroid/graphics/Rect;
    //   449: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   452: pop
    //   453: aload_0
    //   454: getfield C : Landroid/graphics/Rect;
    //   457: astore #7
    //   459: aload #7
    //   461: getfield top : I
    //   464: istore #5
    //   466: aload #7
    //   468: getfield bottom : I
    //   471: iload #5
    //   473: iadd
    //   474: istore #4
    //   476: iload #4
    //   478: istore_2
    //   479: aload_0
    //   480: getfield i : Z
    //   483: ifne -> 508
    //   486: aload_0
    //   487: iload #5
    //   489: ineg
    //   490: putfield g : I
    //   493: iload #4
    //   495: istore_2
    //   496: goto -> 508
    //   499: aload_0
    //   500: getfield C : Landroid/graphics/Rect;
    //   503: invokevirtual setEmpty : ()V
    //   506: iconst_0
    //   507: istore_2
    //   508: aload_0
    //   509: getfield F : Landroid/widget/PopupWindow;
    //   512: invokevirtual getInputMethodMode : ()I
    //   515: iconst_2
    //   516: if_icmpne -> 522
    //   519: goto -> 525
    //   522: iconst_0
    //   523: istore #6
    //   525: aload_0
    //   526: aload_0
    //   527: invokevirtual t : ()Landroid/view/View;
    //   530: aload_0
    //   531: getfield g : I
    //   534: iload #6
    //   536: invokespecial u : (Landroid/view/View;IZ)I
    //   539: istore #4
    //   541: aload_0
    //   542: getfield m : Z
    //   545: ifne -> 683
    //   548: aload_0
    //   549: getfield d : I
    //   552: iconst_m1
    //   553: if_icmpne -> 559
    //   556: goto -> 683
    //   559: aload_0
    //   560: getfield e : I
    //   563: istore #5
    //   565: iload #5
    //   567: bipush #-2
    //   569: if_icmpeq -> 594
    //   572: ldc_w 1073741824
    //   575: istore_3
    //   576: iload #5
    //   578: iconst_m1
    //   579: if_icmpeq -> 594
    //   582: iload #5
    //   584: ldc_w 1073741824
    //   587: invokestatic makeMeasureSpec : (II)I
    //   590: istore_3
    //   591: goto -> 634
    //   594: aload_0
    //   595: getfield a : Landroid/content/Context;
    //   598: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   601: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   604: getfield widthPixels : I
    //   607: istore #5
    //   609: aload_0
    //   610: getfield C : Landroid/graphics/Rect;
    //   613: astore #7
    //   615: iload #5
    //   617: aload #7
    //   619: getfield left : I
    //   622: aload #7
    //   624: getfield right : I
    //   627: iadd
    //   628: isub
    //   629: iload_3
    //   630: invokestatic makeMeasureSpec : (II)I
    //   633: istore_3
    //   634: aload_0
    //   635: getfield c : Landroidx/appcompat/widget/f1;
    //   638: iload_3
    //   639: iconst_0
    //   640: iconst_m1
    //   641: iload #4
    //   643: iload_1
    //   644: isub
    //   645: iconst_m1
    //   646: invokevirtual d : (IIIII)I
    //   649: istore #4
    //   651: iload_1
    //   652: istore_3
    //   653: iload #4
    //   655: ifle -> 678
    //   658: iload_1
    //   659: iload_2
    //   660: aload_0
    //   661: getfield c : Landroidx/appcompat/widget/f1;
    //   664: invokevirtual getPaddingTop : ()I
    //   667: aload_0
    //   668: getfield c : Landroidx/appcompat/widget/f1;
    //   671: invokevirtual getPaddingBottom : ()I
    //   674: iadd
    //   675: iadd
    //   676: iadd
    //   677: istore_3
    //   678: iload #4
    //   680: iload_3
    //   681: iadd
    //   682: ireturn
    //   683: iload #4
    //   685: iload_2
    //   686: iadd
    //   687: ireturn
  }
  
  private int u(View paramView, int paramInt, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 23) {
      Method method = H;
      if (method != null)
        try {
          return ((Integer)method.invoke(this.F, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
        }  
      return this.F.getMaxAvailableHeight(paramView, paramInt);
    } 
    return k1.a(this.F, paramView, paramInt, paramBoolean);
  }
  
  private void y() {
    View view = this.p;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.p); 
    } 
  }
  
  public void A(int paramInt) {
    this.F.setAnimationStyle(paramInt);
  }
  
  public void B(int paramInt) {
    Drawable drawable = this.F.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.C);
      Rect rect = this.C;
      this.e = rect.left + rect.right + paramInt;
      return;
    } 
    M(paramInt);
  }
  
  public void C(int paramInt) {
    this.l = paramInt;
  }
  
  public void D(Rect paramRect) {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    } 
    this.D = paramRect;
  }
  
  public void E(int paramInt) {
    this.F.setInputMethodMode(paramInt);
  }
  
  public void F(boolean paramBoolean) {
    this.E = paramBoolean;
    this.F.setFocusable(paramBoolean);
  }
  
  public void G(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.F.setOnDismissListener(paramOnDismissListener);
  }
  
  public void H(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.u = paramOnItemClickListener;
  }
  
  public void I(boolean paramBoolean) {
    this.k = true;
    this.j = paramBoolean;
  }
  
  public void K(int paramInt) {
    this.q = paramInt;
  }
  
  public void L(int paramInt) {
    f1 f11 = this.c;
    if (a() && f11 != null) {
      f11.setListSelectionHidden(false);
      f11.setSelection(paramInt);
      if (f11.getChoiceMode() != 0)
        f11.setItemChecked(paramInt, true); 
    } 
  }
  
  public void M(int paramInt) {
    this.e = paramInt;
  }
  
  public boolean a() {
    return this.F.isShowing();
  }
  
  public void b() {
    int i;
    int j = q();
    boolean bool1 = w();
    k.b(this.F, this.h);
    boolean bool2 = this.F.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!t0.A(t()))
        return; 
      int m = this.e;
      if (m == -1) {
        i = -1;
      } else {
        i = m;
        if (m == -2)
          i = t().getWidth(); 
      } 
      m = this.d;
      if (m == -1) {
        if (!bool1)
          j = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.F;
          if (this.e == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.F.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.F;
          if (this.e == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.F.setHeight(-1);
        } 
      } else if (m != -2) {
        j = m;
      } 
      PopupWindow popupWindow1 = this.F;
      if (this.n || this.m)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.F;
      View view = t();
      m = this.f;
      int n = this.g;
      if (i < 0)
        i = -1; 
      if (j < 0)
        j = -1; 
      popupWindow1.update(view, m, n, i, j);
      return;
    } 
    int k = this.e;
    if (k == -1) {
      i = -1;
    } else {
      i = k;
      if (k == -2)
        i = t().getWidth(); 
    } 
    k = this.d;
    if (k == -1) {
      j = -1;
    } else if (k != -2) {
      j = k;
    } 
    this.F.setWidth(i);
    this.F.setHeight(j);
    J(true);
    PopupWindow popupWindow = this.F;
    if (!this.n && !this.m) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.F.setTouchInterceptor(this.x);
    if (this.k)
      k.a(this.F, this.j); 
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = I;
      if (method != null)
        try {
          method.invoke(this.F, new Object[] { this.D });
        } catch (Exception exception) {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", exception);
        }  
    } else {
      j1.a(this.F, this.D);
    } 
    k.c(this.F, t(), this.f, this.g, this.l);
    this.c.setSelection(-1);
    if (!this.E || this.c.isInTouchMode())
      r(); 
    if (!this.E)
      this.B.post(this.z); 
  }
  
  public int c() {
    return this.f;
  }
  
  public void dismiss() {
    this.F.dismiss();
    y();
    this.F.setContentView(null);
    this.c = null;
    this.B.removeCallbacks(this.w);
  }
  
  public void e(int paramInt) {
    this.f = paramInt;
  }
  
  public Drawable h() {
    return this.F.getBackground();
  }
  
  public ListView j() {
    return this.c;
  }
  
  public void k(Drawable paramDrawable) {
    this.F.setBackgroundDrawable(paramDrawable);
  }
  
  public void l(int paramInt) {
    this.g = paramInt;
    this.i = true;
  }
  
  public int o() {
    return !this.i ? 0 : this.g;
  }
  
  public void p(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.r;
    if (dataSetObserver == null) {
      this.r = new d(this);
    } else {
      ListAdapter listAdapter = this.b;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.b = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.r); 
    f1 f11 = this.c;
    if (f11 != null)
      f11.setAdapter(this.b); 
  }
  
  public void r() {
    f1 f11 = this.c;
    if (f11 != null) {
      f11.setListSelectionHidden(true);
      f11.requestLayout();
    } 
  }
  
  f1 s(Context paramContext, boolean paramBoolean) {
    return new f1(paramContext, paramBoolean);
  }
  
  public View t() {
    return this.s;
  }
  
  public int v() {
    return this.e;
  }
  
  public boolean w() {
    return (this.F.getInputMethodMode() == 2);
  }
  
  public boolean x() {
    return this.E;
  }
  
  public void z(View paramView) {
    this.s = paramView;
  }
  
  class a implements Runnable {
    a(m1 this$0) {}
    
    public void run() {
      View view = this.a.t();
      if (view != null && view.getWindowToken() != null)
        this.a.b(); 
    }
  }
  
  class b implements AdapterView.OnItemSelectedListener {
    b(m1 this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        f1 f1 = this.a.c;
        if (f1 != null)
          f1.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  private class c implements Runnable {
    c(m1 this$0) {}
    
    public void run() {
      this.a.r();
    }
  }
  
  private class d extends DataSetObserver {
    d(m1 this$0) {}
    
    public void onChanged() {
      if (this.a.a())
        this.a.b(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  private class e implements AbsListView.OnScrollListener {
    e(m1 this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.w() && this.a.F.getContentView() != null) {
        m1 m11 = this.a;
        m11.B.removeCallbacks(m11.w);
        this.a.w.run();
      } 
    }
  }
  
  private class f implements View.OnTouchListener {
    f(m1 this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.a.F;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.a.F.getWidth() && k >= 0 && k < this.a.F.getHeight()) {
          m1 m11 = this.a;
          m11.B.postDelayed(m11.w, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        m1 m11 = this.a;
        m11.B.removeCallbacks(m11.w);
      } 
      return false;
    }
  }
  
  private class g implements Runnable {
    g(m1 this$0) {}
    
    public void run() {
      f1 f1 = this.a.c;
      if (f1 != null && t0.A((View)f1) && this.a.c.getCount() > this.a.c.getChildCount()) {
        int i = this.a.c.getChildCount();
        m1 m11 = this.a;
        if (i <= m11.o) {
          m11.F.setInputMethodMode(2);
          this.a.b();
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\m1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */