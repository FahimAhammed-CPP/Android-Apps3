package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.core.view.t0;
import androidx.core.widget.h;
import e.j;
import g.b;

public class n {
  private final ImageView a;
  
  private a2 b;
  
  private a2 c;
  
  private a2 d;
  
  public n(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.d == null)
      this.d = new a2(); 
    a2 a21 = this.d;
    a21.a();
    ColorStateList colorStateList = h.a(this.a);
    if (colorStateList != null) {
      a21.d = true;
      a21.a = colorStateList;
    } 
    PorterDuff.Mode mode = h.b(this.a);
    if (mode != null) {
      a21.c = true;
      a21.b = mode;
    } 
    if (a21.d || a21.c) {
      j.i(paramDrawable, a21, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean j() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.b != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      e1.b(drawable); 
    if (drawable != null) {
      if (j() && a(drawable))
        return; 
      a2 a21 = this.c;
      if (a21 != null) {
        j.i(drawable, a21, this.a.getDrawableState());
        return;
      } 
      a21 = this.b;
      if (a21 != null)
        j.i(drawable, a21, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    a2 a21 = this.c;
    return (a21 != null) ? a21.a : null;
  }
  
  PorterDuff.Mode d() {
    a2 a21 = this.c;
    return (a21 != null) ? a21.b : null;
  }
  
  boolean e() {
    return !(this.a.getBackground() instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void f(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.R;
    c2 c2 = c2.u(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    t0.M((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, c2.q(), paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = c2.m(j.S, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = b.d(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        e1.b(drawable1); 
      paramInt = j.T;
      if (c2.r(paramInt))
        h.c(this.a, c2.c(paramInt)); 
      paramInt = j.U;
      if (c2.r(paramInt))
        h.d(this.a, e1.d(c2.j(paramInt, -1), null)); 
      return;
    } finally {
      c2.v();
    } 
  }
  
  public void g(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = b.d(this.a.getContext(), paramInt);
      if (drawable != null)
        e1.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new a2(); 
    a2 a21 = this.c;
    a21.a = paramColorStateList;
    a21.d = true;
    b();
  }
  
  void i(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new a2(); 
    a2 a21 = this.c;
    a21.b = paramMode;
    a21.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */