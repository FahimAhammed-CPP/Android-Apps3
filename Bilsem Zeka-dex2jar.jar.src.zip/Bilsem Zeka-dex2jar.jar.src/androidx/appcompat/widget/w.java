package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import androidx.core.graphics.drawable.a;
import androidx.core.view.t0;
import e.j;

class w extends q {
  private final SeekBar d;
  
  private Drawable e;
  
  private ColorStateList f = null;
  
  private PorterDuff.Mode g = null;
  
  private boolean h = false;
  
  private boolean i = false;
  
  w(SeekBar paramSeekBar) {
    super((ProgressBar)paramSeekBar);
    this.d = paramSeekBar;
  }
  
  private void f() {
    Drawable drawable = this.e;
    if (drawable != null && (this.h || this.i)) {
      drawable = a.p(drawable.mutate());
      this.e = drawable;
      if (this.h)
        a.n(drawable, this.f); 
      if (this.i)
        a.o(this.e, this.g); 
      if (this.e.isStateful())
        this.e.setState(this.d.getDrawableState()); 
    } 
  }
  
  void c(AttributeSet paramAttributeSet, int paramInt) {
    super.c(paramAttributeSet, paramInt);
    Context context = this.d.getContext();
    int[] arrayOfInt = j.V;
    c2 c2 = c2.u(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    SeekBar seekBar = this.d;
    t0.M((View)seekBar, seekBar.getContext(), arrayOfInt, paramAttributeSet, c2.q(), paramInt, 0);
    Drawable drawable = c2.g(j.W);
    if (drawable != null)
      this.d.setThumb(drawable); 
    j(c2.f(j.X));
    paramInt = j.Z;
    if (c2.r(paramInt)) {
      this.g = e1.d(c2.j(paramInt, -1), this.g);
      this.i = true;
    } 
    paramInt = j.Y;
    if (c2.r(paramInt)) {
      this.f = c2.c(paramInt);
      this.h = true;
    } 
    c2.v();
    f();
  }
  
  void g(Canvas paramCanvas) {
    if (this.e != null) {
      int j = this.d.getMax();
      int i = 1;
      if (j > 1) {
        int k = this.e.getIntrinsicWidth();
        int m = this.e.getIntrinsicHeight();
        if (k >= 0) {
          k /= 2;
        } else {
          k = 1;
        } 
        if (m >= 0)
          i = m / 2; 
        this.e.setBounds(-k, -i, k, i);
        float f = (this.d.getWidth() - this.d.getPaddingLeft() - this.d.getPaddingRight()) / j;
        i = paramCanvas.save();
        paramCanvas.translate(this.d.getPaddingLeft(), (this.d.getHeight() / 2));
        for (k = 0; k <= j; k++) {
          this.e.draw(paramCanvas);
          paramCanvas.translate(f, 0.0F);
        } 
        paramCanvas.restoreToCount(i);
      } 
    } 
  }
  
  void h() {
    Drawable drawable = this.e;
    if (drawable != null && drawable.isStateful() && drawable.setState(this.d.getDrawableState()))
      this.d.invalidateDrawable(drawable); 
  }
  
  void i() {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  void j(Drawable paramDrawable) {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.setCallback(null); 
    this.e = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this.d);
      a.l(paramDrawable, t0.q((View)this.d));
      if (paramDrawable.isStateful())
        paramDrawable.setState(this.d.getDrawableState()); 
      f();
    } 
    this.d.invalidate();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */