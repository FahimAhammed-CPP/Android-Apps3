package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.j;

public interface c1 {
  void a(Menu paramMenu, j.a parama);
  
  boolean b();
  
  void c();
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  void h(int paramInt);
  
  void i();
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */