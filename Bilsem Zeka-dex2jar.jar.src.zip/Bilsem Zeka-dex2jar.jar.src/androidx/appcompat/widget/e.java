package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.t0;
import e.j;

class e {
  private final View a;
  
  private final j b;
  
  private int c = -1;
  
  private a2 d;
  
  private a2 e;
  
  private a2 f;
  
  e(View paramView) {
    this.a = paramView;
    this.b = j.b();
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new a2(); 
    a2 a21 = this.f;
    a21.a();
    ColorStateList colorStateList = t0.l(this.a);
    if (colorStateList != null) {
      a21.d = true;
      a21.a = colorStateList;
    } 
    PorterDuff.Mode mode = t0.m(this.a);
    if (mode != null) {
      a21.c = true;
      a21.b = mode;
    } 
    if (a21.d || a21.c) {
      j.i(paramDrawable, a21, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.d != null)) : ((i == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      a2 a21 = this.e;
      if (a21 != null) {
        j.i(drawable, a21, this.a.getDrawableState());
        return;
      } 
      a21 = this.d;
      if (a21 != null)
        j.i(drawable, a21, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    a2 a21 = this.e;
    return (a21 != null) ? a21.a : null;
  }
  
  PorterDuff.Mode d() {
    a2 a21 = this.e;
    return (a21 != null) ? a21.b : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.D3;
    c2 c2 = c2.u(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    t0.M(view, view.getContext(), arrayOfInt, paramAttributeSet, c2.q(), paramInt, 0);
    try {
      paramInt = j.E3;
      if (c2.r(paramInt)) {
        this.c = c2.m(paramInt, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.F3;
      if (c2.r(paramInt))
        t0.Q(this.a, c2.c(paramInt)); 
      paramInt = j.G3;
      if (c2.r(paramInt))
        t0.R(this.a, e1.d(c2.j(paramInt, -1), null)); 
      return;
    } finally {
      c2.v();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    j j1 = this.b;
    if (j1 != null) {
      ColorStateList colorStateList = j1.f(this.a.getContext(), paramInt);
    } else {
      j1 = null;
    } 
    h((ColorStateList)j1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new a2(); 
      a2 a21 = this.d;
      a21.a = paramColorStateList;
      a21.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new a2(); 
    a2 a21 = this.e;
    a21.a = paramColorStateList;
    a21.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new a2(); 
    a2 a21 = this.e;
    a21.b = paramMode;
    a21.c = true;
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */