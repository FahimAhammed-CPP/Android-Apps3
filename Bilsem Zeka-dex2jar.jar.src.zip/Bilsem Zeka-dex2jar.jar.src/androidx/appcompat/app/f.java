package androidx.appcompat.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.b1;
import androidx.appcompat.widget.d;
import androidx.appcompat.widget.g;
import androidx.appcompat.widget.h;
import androidx.appcompat.widget.k;
import androidx.appcompat.widget.m;
import androidx.appcompat.widget.m0;
import androidx.appcompat.widget.o;
import androidx.appcompat.widget.r;
import androidx.appcompat.widget.s;
import androidx.appcompat.widget.v;
import androidx.appcompat.widget.x;
import androidx.core.view.t0;
import e.j;
import j.d;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import r.g;

public class f {
  private static final Class<?>[] b = new Class[] { Context.class, AttributeSet.class };
  
  private static final int[] c = new int[] { 16843375 };
  
  private static final String[] d = new String[] { "android.widget.", "android.view.", "android.webkit." };
  
  private static final g<String, Constructor<? extends View>> e = new g();
  
  private final Object[] a = new Object[2];
  
  private void a(View paramView, AttributeSet paramAttributeSet) {
    Context context = paramView.getContext();
    if (context instanceof ContextWrapper) {
      if (!t0.x(paramView))
        return; 
      TypedArray typedArray = context.obtainStyledAttributes(paramAttributeSet, c);
      String str = typedArray.getString(0);
      if (str != null)
        paramView.setOnClickListener(new a(paramView, str)); 
      typedArray.recycle();
    } 
  }
  
  private View r(Context paramContext, String paramString1, String paramString2) {
    g<String, Constructor<? extends View>> g1 = e;
    Constructor constructor1 = (Constructor)g1.get(paramString1);
    Constructor<View> constructor = constructor1;
    if (constructor1 == null) {
      if (paramString2 != null)
        try {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramString2);
          stringBuilder.append(paramString1);
          paramString2 = stringBuilder.toString();
          constructor = Class.forName(paramString2, false, paramContext.getClassLoader()).<View>asSubclass(View.class).getConstructor(b);
          g1.put(paramString1, constructor);
          constructor.setAccessible(true);
          return constructor.newInstance(this.a);
        } catch (Exception exception) {
          return null;
        }  
    } else {
      constructor.setAccessible(true);
      return constructor.newInstance(this.a);
    } 
    paramString2 = paramString1;
    constructor = Class.forName(paramString2, false, paramContext.getClassLoader()).<View>asSubclass(View.class).getConstructor(b);
    g1.put(paramString1, constructor);
    constructor.setAccessible(true);
    return constructor.newInstance(this.a);
  }
  
  private View s(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    String str = paramString;
    if (paramString.equals("view"))
      str = paramAttributeSet.getAttributeValue(null, "class"); 
    try {
      Object[] arrayOfObject1;
      Object[] arrayOfObject2 = this.a;
      arrayOfObject2[0] = paramContext;
      arrayOfObject2[1] = paramAttributeSet;
      if (-1 == str.indexOf('.')) {
        int i = 0;
        while (true) {
          String[] arrayOfString = d;
          if (i < arrayOfString.length) {
            View view = r(paramContext, str, arrayOfString[i]);
            if (view != null)
              return view; 
            i++;
            continue;
          } 
          return null;
        } 
      } 
      return r((Context)arrayOfObject1, str, null);
    } catch (Exception exception) {
      return null;
    } finally {
      Object[] arrayOfObject = this.a;
      arrayOfObject[0] = null;
      arrayOfObject[1] = null;
    } 
  }
  
  private static Context t(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2) {
    int i;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.A3, 0, 0);
    if (paramBoolean1) {
      i = typedArray.getResourceId(j.B3, 0);
    } else {
      i = 0;
    } 
    int j = i;
    if (paramBoolean2) {
      j = i;
      if (!i) {
        i = typedArray.getResourceId(j.C3, 0);
        j = i;
        if (i != 0) {
          Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
          j = i;
        } 
      } 
    } 
    typedArray.recycle();
    Context context = paramContext;
    if (j != 0) {
      if (paramContext instanceof d) {
        context = paramContext;
        return (Context)((((d)paramContext).c() != j) ? new d(paramContext, j) : context);
      } 
    } else {
      return context;
    } 
    return (Context)new d(paramContext, j);
  }
  
  private void u(View paramView, String paramString) {
    if (paramView != null)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getName());
    stringBuilder.append(" asked to inflate view for <");
    stringBuilder.append(paramString);
    stringBuilder.append(">, but returned null");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected d b(Context paramContext, AttributeSet paramAttributeSet) {
    return new d(paramContext, paramAttributeSet);
  }
  
  protected androidx.appcompat.widget.f c(Context paramContext, AttributeSet paramAttributeSet) {
    return new androidx.appcompat.widget.f(paramContext, paramAttributeSet);
  }
  
  protected g d(Context paramContext, AttributeSet paramAttributeSet) {
    return new g(paramContext, paramAttributeSet);
  }
  
  protected h e(Context paramContext, AttributeSet paramAttributeSet) {
    return new h(paramContext, paramAttributeSet);
  }
  
  protected k f(Context paramContext, AttributeSet paramAttributeSet) {
    return new k(paramContext, paramAttributeSet);
  }
  
  protected m g(Context paramContext, AttributeSet paramAttributeSet) {
    return new m(paramContext, paramAttributeSet);
  }
  
  protected AppCompatImageView h(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageView(paramContext, paramAttributeSet);
  }
  
  protected o i(Context paramContext, AttributeSet paramAttributeSet) {
    return new o(paramContext, paramAttributeSet);
  }
  
  protected r j(Context paramContext, AttributeSet paramAttributeSet) {
    return new r(paramContext, paramAttributeSet);
  }
  
  protected s k(Context paramContext, AttributeSet paramAttributeSet) {
    return new s(paramContext, paramAttributeSet);
  }
  
  protected v l(Context paramContext, AttributeSet paramAttributeSet) {
    return new v(paramContext, paramAttributeSet);
  }
  
  protected x m(Context paramContext, AttributeSet paramAttributeSet) {
    return new x(paramContext, paramAttributeSet);
  }
  
  protected m0 n(Context paramContext, AttributeSet paramAttributeSet) {
    return new m0(paramContext, paramAttributeSet);
  }
  
  protected b1 o(Context paramContext, AttributeSet paramAttributeSet) {
    return new b1(paramContext, paramAttributeSet);
  }
  
  protected View p(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    return null;
  }
  
  final View q(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: iload #5
    //   2: ifeq -> 18
    //   5: aload_1
    //   6: ifnull -> 18
    //   9: aload_1
    //   10: invokevirtual getContext : ()Landroid/content/Context;
    //   13: astore #11
    //   15: goto -> 21
    //   18: aload_3
    //   19: astore #11
    //   21: iload #6
    //   23: ifne -> 34
    //   26: aload #11
    //   28: astore_1
    //   29: iload #7
    //   31: ifeq -> 46
    //   34: aload #11
    //   36: aload #4
    //   38: iload #6
    //   40: iload #7
    //   42: invokestatic t : (Landroid/content/Context;Landroid/util/AttributeSet;ZZ)Landroid/content/Context;
    //   45: astore_1
    //   46: aload_1
    //   47: astore #11
    //   49: iload #8
    //   51: ifeq -> 60
    //   54: aload_1
    //   55: invokestatic b : (Landroid/content/Context;)Landroid/content/Context;
    //   58: astore #11
    //   60: aload_2
    //   61: invokevirtual hashCode : ()I
    //   64: pop
    //   65: aload_2
    //   66: invokevirtual hashCode : ()I
    //   69: istore #10
    //   71: iconst_m1
    //   72: istore #9
    //   74: iload #10
    //   76: lookupswitch default -> 200, -1946472170 -> 458, -1455429095 -> 439, -1346021293 -> 420, -938935918 -> 401, -937446323 -> 382, -658531749 -> 363, -339785223 -> 343, 776382189 -> 323, 799298502 -> 303, 1125864064 -> 283, 1413872058 -> 263, 1601505219 -> 243, 1666676343 -> 223, 2001146706 -> 203
    //   200: goto -> 474
    //   203: aload_2
    //   204: ldc_w 'Button'
    //   207: invokevirtual equals : (Ljava/lang/Object;)Z
    //   210: ifne -> 216
    //   213: goto -> 474
    //   216: bipush #13
    //   218: istore #9
    //   220: goto -> 474
    //   223: aload_2
    //   224: ldc_w 'EditText'
    //   227: invokevirtual equals : (Ljava/lang/Object;)Z
    //   230: ifne -> 236
    //   233: goto -> 474
    //   236: bipush #12
    //   238: istore #9
    //   240: goto -> 474
    //   243: aload_2
    //   244: ldc_w 'CheckBox'
    //   247: invokevirtual equals : (Ljava/lang/Object;)Z
    //   250: ifne -> 256
    //   253: goto -> 474
    //   256: bipush #11
    //   258: istore #9
    //   260: goto -> 474
    //   263: aload_2
    //   264: ldc_w 'AutoCompleteTextView'
    //   267: invokevirtual equals : (Ljava/lang/Object;)Z
    //   270: ifne -> 276
    //   273: goto -> 474
    //   276: bipush #10
    //   278: istore #9
    //   280: goto -> 474
    //   283: aload_2
    //   284: ldc_w 'ImageView'
    //   287: invokevirtual equals : (Ljava/lang/Object;)Z
    //   290: ifne -> 296
    //   293: goto -> 474
    //   296: bipush #9
    //   298: istore #9
    //   300: goto -> 474
    //   303: aload_2
    //   304: ldc_w 'ToggleButton'
    //   307: invokevirtual equals : (Ljava/lang/Object;)Z
    //   310: ifne -> 316
    //   313: goto -> 474
    //   316: bipush #8
    //   318: istore #9
    //   320: goto -> 474
    //   323: aload_2
    //   324: ldc_w 'RadioButton'
    //   327: invokevirtual equals : (Ljava/lang/Object;)Z
    //   330: ifne -> 336
    //   333: goto -> 474
    //   336: bipush #7
    //   338: istore #9
    //   340: goto -> 474
    //   343: aload_2
    //   344: ldc_w 'Spinner'
    //   347: invokevirtual equals : (Ljava/lang/Object;)Z
    //   350: ifne -> 356
    //   353: goto -> 474
    //   356: bipush #6
    //   358: istore #9
    //   360: goto -> 474
    //   363: aload_2
    //   364: ldc_w 'SeekBar'
    //   367: invokevirtual equals : (Ljava/lang/Object;)Z
    //   370: ifne -> 376
    //   373: goto -> 474
    //   376: iconst_5
    //   377: istore #9
    //   379: goto -> 474
    //   382: aload_2
    //   383: ldc_w 'ImageButton'
    //   386: invokevirtual equals : (Ljava/lang/Object;)Z
    //   389: ifne -> 395
    //   392: goto -> 474
    //   395: iconst_4
    //   396: istore #9
    //   398: goto -> 474
    //   401: aload_2
    //   402: ldc_w 'TextView'
    //   405: invokevirtual equals : (Ljava/lang/Object;)Z
    //   408: ifne -> 414
    //   411: goto -> 474
    //   414: iconst_3
    //   415: istore #9
    //   417: goto -> 474
    //   420: aload_2
    //   421: ldc_w 'MultiAutoCompleteTextView'
    //   424: invokevirtual equals : (Ljava/lang/Object;)Z
    //   427: ifne -> 433
    //   430: goto -> 474
    //   433: iconst_2
    //   434: istore #9
    //   436: goto -> 474
    //   439: aload_2
    //   440: ldc_w 'CheckedTextView'
    //   443: invokevirtual equals : (Ljava/lang/Object;)Z
    //   446: ifne -> 452
    //   449: goto -> 474
    //   452: iconst_1
    //   453: istore #9
    //   455: goto -> 474
    //   458: aload_2
    //   459: ldc_w 'RatingBar'
    //   462: invokevirtual equals : (Ljava/lang/Object;)Z
    //   465: ifne -> 471
    //   468: goto -> 474
    //   471: iconst_0
    //   472: istore #9
    //   474: iload #9
    //   476: tableswitch default -> 548, 0 -> 723, 1 -> 711, 2 -> 699, 3 -> 681, 4 -> 669, 5 -> 657, 6 -> 645, 7 -> 633, 8 -> 621, 9 -> 609, 10 -> 597, 11 -> 585, 12 -> 573, 13 -> 561
    //   548: aload_0
    //   549: aload #11
    //   551: aload_2
    //   552: aload #4
    //   554: invokevirtual p : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   557: astore_1
    //   558: goto -> 735
    //   561: aload_0
    //   562: aload #11
    //   564: aload #4
    //   566: invokevirtual c : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/f;
    //   569: astore_1
    //   570: goto -> 690
    //   573: aload_0
    //   574: aload #11
    //   576: aload #4
    //   578: invokevirtual f : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/k;
    //   581: astore_1
    //   582: goto -> 690
    //   585: aload_0
    //   586: aload #11
    //   588: aload #4
    //   590: invokevirtual d : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/g;
    //   593: astore_1
    //   594: goto -> 690
    //   597: aload_0
    //   598: aload #11
    //   600: aload #4
    //   602: invokevirtual b : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/d;
    //   605: astore_1
    //   606: goto -> 690
    //   609: aload_0
    //   610: aload #11
    //   612: aload #4
    //   614: invokevirtual h : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatImageView;
    //   617: astore_1
    //   618: goto -> 690
    //   621: aload_0
    //   622: aload #11
    //   624: aload #4
    //   626: invokevirtual o : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/b1;
    //   629: astore_1
    //   630: goto -> 690
    //   633: aload_0
    //   634: aload #11
    //   636: aload #4
    //   638: invokevirtual j : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/r;
    //   641: astore_1
    //   642: goto -> 690
    //   645: aload_0
    //   646: aload #11
    //   648: aload #4
    //   650: invokevirtual m : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/x;
    //   653: astore_1
    //   654: goto -> 690
    //   657: aload_0
    //   658: aload #11
    //   660: aload #4
    //   662: invokevirtual l : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/v;
    //   665: astore_1
    //   666: goto -> 690
    //   669: aload_0
    //   670: aload #11
    //   672: aload #4
    //   674: invokevirtual g : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/m;
    //   677: astore_1
    //   678: goto -> 690
    //   681: aload_0
    //   682: aload #11
    //   684: aload #4
    //   686: invokevirtual n : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/m0;
    //   689: astore_1
    //   690: aload_0
    //   691: aload_1
    //   692: aload_2
    //   693: invokespecial u : (Landroid/view/View;Ljava/lang/String;)V
    //   696: goto -> 735
    //   699: aload_0
    //   700: aload #11
    //   702: aload #4
    //   704: invokevirtual i : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/o;
    //   707: astore_1
    //   708: goto -> 690
    //   711: aload_0
    //   712: aload #11
    //   714: aload #4
    //   716: invokevirtual e : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/h;
    //   719: astore_1
    //   720: goto -> 690
    //   723: aload_0
    //   724: aload #11
    //   726: aload #4
    //   728: invokevirtual k : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/s;
    //   731: astore_1
    //   732: goto -> 690
    //   735: aload_1
    //   736: astore #12
    //   738: aload_1
    //   739: ifnonnull -> 762
    //   742: aload_1
    //   743: astore #12
    //   745: aload_3
    //   746: aload #11
    //   748: if_acmpeq -> 762
    //   751: aload_0
    //   752: aload #11
    //   754: aload_2
    //   755: aload #4
    //   757: invokespecial s : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   760: astore #12
    //   762: aload #12
    //   764: ifnull -> 775
    //   767: aload_0
    //   768: aload #12
    //   770: aload #4
    //   772: invokespecial a : (Landroid/view/View;Landroid/util/AttributeSet;)V
    //   775: aload #12
    //   777: areturn
  }
  
  private static class a implements View.OnClickListener {
    private final View a;
    
    private final String b;
    
    private Method c;
    
    private Context d;
    
    public a(View param1View, String param1String) {
      this.a = param1View;
      this.b = param1String;
    }
    
    private void a(Context param1Context) {
      while (true) {
        String str;
        if (param1Context != null) {
          try {
            if (!param1Context.isRestricted()) {
              Method method = param1Context.getClass().getMethod(this.b, new Class[] { View.class });
              if (method != null) {
                this.c = method;
                this.d = param1Context;
                return;
              } 
            } 
          } catch (NoSuchMethodException noSuchMethodException) {}
          if (param1Context instanceof ContextWrapper) {
            param1Context = ((ContextWrapper)param1Context).getBaseContext();
            continue;
          } 
          param1Context = null;
          continue;
        } 
        int i = this.a.getId();
        if (i == -1) {
          str = "";
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" with id '");
          stringBuilder1.append(this.a.getContext().getResources().getResourceEntryName(i));
          stringBuilder1.append("'");
          str = stringBuilder1.toString();
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not find method ");
        stringBuilder.append(this.b);
        stringBuilder.append("(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
        stringBuilder.append(this.a.getClass());
        stringBuilder.append(str);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    }
    
    public void onClick(View param1View) {
      if (this.c == null)
        a(this.a.getContext()); 
      try {
        this.c.invoke(this.d, new Object[] { param1View });
        return;
      } catch (IllegalAccessException illegalAccessException) {
        throw new IllegalStateException("Could not execute non-public method for android:onClick", illegalAccessException);
      } catch (InvocationTargetException invocationTargetException) {
        throw new IllegalStateException("Could not execute method for android:onClick", invocationTargetException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\app\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */