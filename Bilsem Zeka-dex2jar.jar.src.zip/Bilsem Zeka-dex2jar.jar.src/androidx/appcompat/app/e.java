package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.c1;
import androidx.appcompat.widget.c2;
import androidx.appcompat.widget.j2;
import androidx.core.view.b2;
import androidx.core.view.o0;
import androidx.core.view.t;
import androidx.core.view.t0;
import androidx.core.view.x1;
import androidx.core.view.y1;
import androidx.core.view.z1;
import java.util.List;

class e extends d implements e.a, LayoutInflater.Factory2 {
  private static final r.g<String, Integer> p0 = new r.g();
  
  private static final boolean q0 = false;
  
  private static final int[] r0 = new int[] { 16842836 };
  
  private static final boolean s0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  private static final boolean t0 = true;
  
  boolean A;
  
  boolean B;
  
  boolean C;
  
  boolean D;
  
  boolean E;
  
  private boolean F;
  
  private r[] G;
  
  private r H;
  
  private boolean I;
  
  private boolean X;
  
  private boolean Y;
  
  private boolean Z;
  
  boolean a0;
  
  private int b0 = -100;
  
  private int c0;
  
  final Object d;
  
  private boolean d0;
  
  final Context e;
  
  private boolean e0;
  
  Window f;
  
  private n f0;
  
  private l g;
  
  private n g0;
  
  final f.a h;
  
  boolean h0;
  
  a i;
  
  int i0;
  
  MenuInflater j;
  
  private final Runnable j0 = new a(this);
  
  private CharSequence k;
  
  private boolean k0;
  
  private c1 l;
  
  private Rect l0;
  
  private f m;
  
  private Rect m0;
  
  private s n;
  
  private f n0;
  
  j.b o;
  
  private g o0;
  
  ActionBarContextView p;
  
  PopupWindow q;
  
  Runnable r;
  
  x1 s = null;
  
  private boolean t = true;
  
  private boolean u;
  
  ViewGroup v;
  
  private TextView w;
  
  private View x;
  
  private boolean y;
  
  private boolean z;
  
  e(Activity paramActivity, f.a parama) {
    this((Context)paramActivity, null, parama, paramActivity);
  }
  
  e(Dialog paramDialog, f.a parama) {
    this(paramDialog.getContext(), paramDialog.getWindow(), parama, paramDialog);
  }
  
  private e(Context paramContext, Window paramWindow, f.a parama, Object paramObject) {
    this.e = paramContext;
    this.h = parama;
    this.d = paramObject;
    if (this.b0 == -100 && paramObject instanceof Dialog) {
      c c = K0();
      if (c != null)
        this.b0 = c.A().k(); 
    } 
    if (this.b0 == -100) {
      r.g<String, Integer> g1 = p0;
      Integer integer = (Integer)g1.get(paramObject.getClass().getName());
      if (integer != null) {
        this.b0 = integer.intValue();
        g1.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      K(paramWindow); 
    androidx.appcompat.widget.j.h();
  }
  
  private boolean B0(r paramr, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokespecial C0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/e;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield l : Landroidx/appcompat/widget/c1;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual Q : (Landroidx/appcompat/app/e$r;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  private boolean C0(r paramr, KeyEvent paramKeyEvent) {
    c1 c11;
    if (this.a0)
      return false; 
    if (paramr.m)
      return true; 
    r r1 = this.H;
    if (r1 != null && r1 != paramr)
      Q(r1, false); 
    Window.Callback callback = h0();
    if (callback != null)
      paramr.i = callback.onCreatePanelView(paramr.a); 
    int i = paramr.a;
    if (i == 0 || i == 108) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      c1 c12 = this.l;
      if (c12 != null)
        c12.c(); 
    } 
    if (paramr.i == null && (i == 0 || !(A0() instanceof i))) {
      c1 c12;
      boolean bool;
      e e1 = paramr.j;
      if (e1 == null || paramr.r) {
        if (e1 == null && (!l0(paramr) || paramr.j == null))
          return false; 
        if (i != 0 && this.l != null) {
          if (this.m == null)
            this.m = new f(this); 
          this.l.a((Menu)paramr.j, this.m);
        } 
        paramr.j.d0();
        if (!callback.onCreatePanelMenu(paramr.a, (Menu)paramr.j)) {
          paramr.c(null);
          if (i != 0) {
            c11 = this.l;
            if (c11 != null)
              c11.a(null, this.m); 
          } 
          return false;
        } 
        ((r)c11).r = false;
      } 
      ((r)c11).j.d0();
      Bundle bundle = ((r)c11).s;
      if (bundle != null) {
        ((r)c11).j.P(bundle);
        ((r)c11).s = null;
      } 
      if (!callback.onPreparePanel(0, ((r)c11).i, (Menu)((r)c11).j)) {
        if (i != 0) {
          c12 = this.l;
          if (c12 != null)
            c12.a(null, this.m); 
        } 
        ((r)c11).j.c0();
        return false;
      } 
      if (c12 != null) {
        i = c12.getDeviceId();
      } else {
        i = -1;
      } 
      if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((r)c11).p = bool;
      ((r)c11).j.setQwertyMode(bool);
      ((r)c11).j.c0();
    } 
    ((r)c11).m = true;
    ((r)c11).n = false;
    this.H = (r)c11;
    return true;
  }
  
  private void D0(boolean paramBoolean) {
    c1 c11 = this.l;
    if (c11 != null && c11.d() && (!ViewConfiguration.get(this.e).hasPermanentMenuKey() || this.l.e())) {
      Window.Callback callback = h0();
      if (!this.l.b() || !paramBoolean) {
        if (callback != null && !this.a0) {
          if (this.h0 && (this.i0 & 0x1) != 0) {
            this.f.getDecorView().removeCallbacks(this.j0);
            this.j0.run();
          } 
          r r2 = f0(0, true);
          e e1 = r2.j;
          if (e1 != null && !r2.r && callback.onPreparePanel(0, r2.i, (Menu)e1)) {
            callback.onMenuOpened(108, (Menu)r2.j);
            this.l.g();
          } 
        } 
        return;
      } 
      this.l.f();
      if (!this.a0) {
        callback.onPanelClosed(108, (Menu)(f0(0, true)).j);
        return;
      } 
      return;
    } 
    r r1 = f0(0, true);
    r1.q = true;
    Q(r1, false);
    z0(r1, null);
  }
  
  private int E0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int i = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      i = 109;
    } 
    return i;
  }
  
  private boolean G0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.f.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (t0.A((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private boolean I(boolean paramBoolean) {
    if (this.a0)
      return false; 
    int i = L();
    paramBoolean = L0(p0(this.e, i), paramBoolean);
    if (i == 0) {
      e0(this.e).e();
    } else {
      n n2 = this.f0;
      if (n2 != null)
        n2.a(); 
    } 
    if (i == 3) {
      d0(this.e).e();
      return paramBoolean;
    } 
    n n1 = this.g0;
    if (n1 != null)
      n1.a(); 
    return paramBoolean;
  }
  
  private void J() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.v.findViewById(16908290);
    View view = this.f.getDecorView();
    contentFrameLayout.a(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.e.obtainStyledAttributes(e.j.z0);
    typedArray.getValue(e.j.L0, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(e.j.M0, contentFrameLayout.getMinWidthMinor());
    int i = e.j.J0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMajor()); 
    i = e.j.K0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMinor()); 
    i = e.j.H0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMajor()); 
    i = e.j.I0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private void J0() {
    if (!this.u)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private void K(Window paramWindow) {
    if (this.f == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof l)) {
        l l1 = new l(this, callback);
        this.g = l1;
        paramWindow.setCallback((Window.Callback)l1);
        c2 c2 = c2.t(this.e, null, r0);
        Drawable drawable = c2.g(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        c2.v();
        this.f = paramWindow;
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private c K0() {
    Context context = this.e;
    while (context != null) {
      if (context instanceof c)
        return (c)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  private int L() {
    int i = this.b0;
    return (i != -100) ? i : d.j();
  }
  
  private boolean L0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield e : Landroid/content/Context;
    //   5: iload_1
    //   6: aconst_null
    //   7: invokespecial R : (Landroid/content/Context;ILandroid/content/res/Configuration;)Landroid/content/res/Configuration;
    //   10: astore #7
    //   12: aload_0
    //   13: invokespecial n0 : ()Z
    //   16: istore #6
    //   18: aload_0
    //   19: getfield e : Landroid/content/Context;
    //   22: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   25: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   28: getfield uiMode : I
    //   31: bipush #48
    //   33: iand
    //   34: istore_3
    //   35: aload #7
    //   37: getfield uiMode : I
    //   40: bipush #48
    //   42: iand
    //   43: istore #4
    //   45: iconst_1
    //   46: istore #5
    //   48: iload_3
    //   49: iload #4
    //   51: if_icmpeq -> 123
    //   54: iload_2
    //   55: ifeq -> 123
    //   58: iload #6
    //   60: ifne -> 123
    //   63: aload_0
    //   64: getfield X : Z
    //   67: ifeq -> 123
    //   70: getstatic androidx/appcompat/app/e.s0 : Z
    //   73: ifne -> 83
    //   76: aload_0
    //   77: getfield Y : Z
    //   80: ifeq -> 123
    //   83: aload_0
    //   84: getfield d : Ljava/lang/Object;
    //   87: astore #7
    //   89: aload #7
    //   91: instanceof android/app/Activity
    //   94: ifeq -> 123
    //   97: aload #7
    //   99: checkcast android/app/Activity
    //   102: invokevirtual isChild : ()Z
    //   105: ifne -> 123
    //   108: aload_0
    //   109: getfield d : Ljava/lang/Object;
    //   112: checkcast android/app/Activity
    //   115: invokestatic o : (Landroid/app/Activity;)V
    //   118: iconst_1
    //   119: istore_2
    //   120: goto -> 125
    //   123: iconst_0
    //   124: istore_2
    //   125: iload_2
    //   126: ifne -> 150
    //   129: iload_3
    //   130: iload #4
    //   132: if_icmpeq -> 150
    //   135: aload_0
    //   136: iload #4
    //   138: iload #6
    //   140: aconst_null
    //   141: invokespecial M0 : (IZLandroid/content/res/Configuration;)V
    //   144: iload #5
    //   146: istore_2
    //   147: goto -> 150
    //   150: iload_2
    //   151: ifeq -> 177
    //   154: aload_0
    //   155: getfield d : Ljava/lang/Object;
    //   158: astore #7
    //   160: aload #7
    //   162: instanceof androidx/appcompat/app/c
    //   165: ifeq -> 177
    //   168: aload #7
    //   170: checkcast androidx/appcompat/app/c
    //   173: iload_1
    //   174: invokevirtual E : (I)V
    //   177: iload_2
    //   178: ireturn
  }
  
  private void M0(int paramInt, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.e.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    resources.updateConfiguration(configuration, null);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 26)
      h.a(resources); 
    int i = this.c0;
    if (i != 0) {
      this.e.setTheme(i);
      if (paramInt >= 23)
        this.e.getTheme().applyStyle(this.c0, true); 
    } 
    if (paramBoolean) {
      Object object = this.d;
      if (object instanceof Activity) {
        object = object;
        if ((object instanceof androidx.lifecycle.i) ? ((androidx.lifecycle.i)object).a().b().a(androidx.lifecycle.e.c.d) : this.Z)
          object.onConfigurationChanged(configuration); 
      } 
    } 
  }
  
  private void O() {
    n n1 = this.f0;
    if (n1 != null)
      n1.a(); 
    n1 = this.g0;
    if (n1 != null)
      n1.a(); 
  }
  
  private void O0(View paramView) {
    int i;
    Context context;
    if ((t0.w(paramView) & 0x2000) != 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i) {
      context = this.e;
      i = e.c.b;
    } else {
      context = this.e;
      i = e.c.a;
    } 
    paramView.setBackgroundColor(androidx.core.content.a.c(context, i));
  }
  
  private Configuration R(Context paramContext, int paramInt, Configuration paramConfiguration) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    return configuration;
  }
  
  private ViewGroup S() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.e.obtainStyledAttributes(e.j.z0);
    int i = e.j.E0;
    if (typedArray.hasValue(i)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(e.j.N0, false)) {
        z(1);
      } else if (typedArray.getBoolean(i, false)) {
        z(108);
      } 
      if (typedArray.getBoolean(e.j.F0, false))
        z(109); 
      if (typedArray.getBoolean(e.j.G0, false))
        z(10); 
      this.D = typedArray.getBoolean(e.j.A0, false);
      typedArray.recycle();
      Z();
      this.f.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.e);
      if (!this.E) {
        if (this.D) {
          viewGroup = (ViewGroup)layoutInflater.inflate(e.g.f, null);
          this.B = false;
          this.A = false;
        } else if (this.A) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.e.getTheme().resolveAttribute(e.a.f, typedValue, true);
          if (typedValue.resourceId != 0) {
            j.d d1 = new j.d(this.e, typedValue.resourceId);
          } else {
            context = this.e;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(e.g.p, null);
          c1 c11 = (c1)viewGroup1.findViewById(e.f.p);
          this.l = c11;
          c11.setWindowCallback(h0());
          if (this.B)
            this.l.h(109); 
          if (this.y)
            this.l.h(2); 
          viewGroup = viewGroup1;
          if (this.z) {
            this.l.h(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else {
        if (this.C) {
          i = e.g.o;
        } else {
          i = e.g.n;
        } 
        viewGroup = (ViewGroup)layoutInflater.inflate(i, null);
      } 
      if (viewGroup != null) {
        t0.W((View)viewGroup, new b(this));
        if (this.l == null)
          this.w = (TextView)viewGroup.findViewById(e.f.M); 
        j2.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(e.f.b);
        ViewGroup viewGroup1 = (ViewGroup)this.f.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.f.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new c(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.A);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.B);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.D);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.C);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.E);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  private void Y() {
    if (!this.u) {
      this.v = S();
      CharSequence charSequence = g0();
      if (!TextUtils.isEmpty(charSequence)) {
        c1 c11 = this.l;
        if (c11 != null) {
          c11.setWindowTitle(charSequence);
        } else if (A0() != null) {
          A0().u(charSequence);
        } else {
          TextView textView = this.w;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      J();
      y0(this.v);
      this.u = true;
      r r1 = f0(0, false);
      if (!this.a0 && (r1 == null || r1.j == null))
        m0(108); 
    } 
  }
  
  private void Z() {
    if (this.f == null) {
      Object object = this.d;
      if (object instanceof Activity)
        K(((Activity)object).getWindow()); 
    } 
    if (this.f != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  private static Configuration b0(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null) {
      if (paramConfiguration1.diff(paramConfiguration2) == 0)
        return configuration; 
      float f1 = paramConfiguration1.fontScale;
      float f2 = paramConfiguration2.fontScale;
      if (f1 != f2)
        configuration.fontScale = f2; 
      int i = paramConfiguration1.mcc;
      int j = paramConfiguration2.mcc;
      if (i != j)
        configuration.mcc = j; 
      i = paramConfiguration1.mnc;
      j = paramConfiguration2.mnc;
      if (i != j)
        configuration.mnc = j; 
      i = Build.VERSION.SDK_INT;
      if (i >= 24) {
        j.a(paramConfiguration1, paramConfiguration2, configuration);
      } else if (!androidx.core.util.c.a(paramConfiguration1.locale, paramConfiguration2.locale)) {
        configuration.locale = paramConfiguration2.locale;
      } 
      j = paramConfiguration1.touchscreen;
      int k = paramConfiguration2.touchscreen;
      if (j != k)
        configuration.touchscreen = k; 
      j = paramConfiguration1.keyboard;
      k = paramConfiguration2.keyboard;
      if (j != k)
        configuration.keyboard = k; 
      j = paramConfiguration1.keyboardHidden;
      k = paramConfiguration2.keyboardHidden;
      if (j != k)
        configuration.keyboardHidden = k; 
      j = paramConfiguration1.navigation;
      k = paramConfiguration2.navigation;
      if (j != k)
        configuration.navigation = k; 
      j = paramConfiguration1.navigationHidden;
      k = paramConfiguration2.navigationHidden;
      if (j != k)
        configuration.navigationHidden = k; 
      j = paramConfiguration1.orientation;
      k = paramConfiguration2.orientation;
      if (j != k)
        configuration.orientation = k; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xF) != (k & 0xF))
        configuration.screenLayout |= k & 0xF; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0xC0) != (k & 0xC0))
        configuration.screenLayout |= k & 0xC0; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x30) != (k & 0x30))
        configuration.screenLayout |= k & 0x30; 
      j = paramConfiguration1.screenLayout;
      k = paramConfiguration2.screenLayout;
      if ((j & 0x300) != (k & 0x300))
        configuration.screenLayout |= k & 0x300; 
      if (i >= 26)
        k.a(paramConfiguration1, paramConfiguration2, configuration); 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0xF) != (j & 0xF))
        configuration.uiMode |= j & 0xF; 
      i = paramConfiguration1.uiMode;
      j = paramConfiguration2.uiMode;
      if ((i & 0x30) != (j & 0x30))
        configuration.uiMode |= j & 0x30; 
      i = paramConfiguration1.screenWidthDp;
      j = paramConfiguration2.screenWidthDp;
      if (i != j)
        configuration.screenWidthDp = j; 
      i = paramConfiguration1.screenHeightDp;
      j = paramConfiguration2.screenHeightDp;
      if (i != j)
        configuration.screenHeightDp = j; 
      i = paramConfiguration1.smallestScreenWidthDp;
      j = paramConfiguration2.smallestScreenWidthDp;
      if (i != j)
        configuration.smallestScreenWidthDp = j; 
      h.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  private n d0(Context paramContext) {
    if (this.g0 == null)
      this.g0 = new m(this, paramContext); 
    return this.g0;
  }
  
  private n e0(Context paramContext) {
    if (this.f0 == null)
      this.f0 = new o(this, k.a(paramContext)); 
    return this.f0;
  }
  
  private void i0() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial Y : ()V
    //   4: aload_0
    //   5: getfield A : Z
    //   8: ifeq -> 100
    //   11: aload_0
    //   12: getfield i : Landroidx/appcompat/app/a;
    //   15: ifnull -> 19
    //   18: return
    //   19: aload_0
    //   20: getfield d : Ljava/lang/Object;
    //   23: astore_1
    //   24: aload_1
    //   25: instanceof android/app/Activity
    //   28: ifeq -> 58
    //   31: new androidx/appcompat/app/l
    //   34: dup
    //   35: aload_0
    //   36: getfield d : Ljava/lang/Object;
    //   39: checkcast android/app/Activity
    //   42: aload_0
    //   43: getfield B : Z
    //   46: invokespecial <init> : (Landroid/app/Activity;Z)V
    //   49: astore_1
    //   50: aload_0
    //   51: aload_1
    //   52: putfield i : Landroidx/appcompat/app/a;
    //   55: goto -> 83
    //   58: aload_1
    //   59: instanceof android/app/Dialog
    //   62: ifeq -> 83
    //   65: new androidx/appcompat/app/l
    //   68: dup
    //   69: aload_0
    //   70: getfield d : Ljava/lang/Object;
    //   73: checkcast android/app/Dialog
    //   76: invokespecial <init> : (Landroid/app/Dialog;)V
    //   79: astore_1
    //   80: goto -> 50
    //   83: aload_0
    //   84: getfield i : Landroidx/appcompat/app/a;
    //   87: astore_1
    //   88: aload_1
    //   89: ifnull -> 100
    //   92: aload_1
    //   93: aload_0
    //   94: getfield k0 : Z
    //   97: invokevirtual r : (Z)V
    //   100: return
  }
  
  private boolean j0(r paramr) {
    View view = paramr.i;
    if (view != null) {
      paramr.h = view;
      return true;
    } 
    if (paramr.j == null)
      return false; 
    if (this.n == null)
      this.n = new s(this); 
    view = (View)paramr.a(this.n);
    paramr.h = view;
    return (view != null);
  }
  
  private boolean k0(r paramr) {
    paramr.d(c0());
    paramr.g = (ViewGroup)new q(this, paramr.l);
    paramr.c = 81;
    return true;
  }
  
  private boolean l0(r paramr) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield l : Landroidx/appcompat/widget/c1;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic e/a.f : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aload #6
    //   64: getfield resourceId : I
    //   67: ifeq -> 109
    //   70: aload #5
    //   72: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   75: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   78: astore_3
    //   79: aload_3
    //   80: aload #7
    //   82: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   85: aload_3
    //   86: aload #6
    //   88: getfield resourceId : I
    //   91: iconst_1
    //   92: invokevirtual applyStyle : (IZ)V
    //   95: aload_3
    //   96: getstatic e/a.g : I
    //   99: aload #6
    //   101: iconst_1
    //   102: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   105: pop
    //   106: goto -> 123
    //   109: aload #7
    //   111: getstatic e/a.g : I
    //   114: aload #6
    //   116: iconst_1
    //   117: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   120: pop
    //   121: aconst_null
    //   122: astore_3
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new j/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/e
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual R : (Landroidx/appcompat/view/menu/e$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/e;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private void m0(int paramInt) {
    this.i0 = 1 << paramInt | this.i0;
    if (!this.h0) {
      t0.J(this.f.getDecorView(), this.j0);
      this.h0 = true;
    } 
  }
  
  private boolean n0() {
    if (!this.e0 && this.d instanceof Activity) {
      PackageManager packageManager = this.e.getPackageManager();
      if (packageManager == null)
        return false; 
      try {
        boolean bool;
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
          i = 269221888;
        } else if (i >= 24) {
          i = 786432;
        } else {
          i = 0;
        } 
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(this.e, this.d.getClass()), i);
        if (activityInfo != null && (activityInfo.configChanges & 0x200) != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.d0 = bool;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        this.d0 = false;
      } 
    } 
    this.e0 = true;
    return this.d0;
  }
  
  private boolean s0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      r r1 = f0(paramInt, true);
      if (!r1.o)
        return C0(r1, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean v0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Lj/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual f0 : (IZ)Landroidx/appcompat/app/e$r;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield l : Landroidx/appcompat/widget/c1;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface d : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield e : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield l : Landroidx/appcompat/widget/c1;
    //   62: invokeinterface b : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield a0 : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokespecial C0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield l : Landroidx/appcompat/widget/c1;
    //   91: invokeinterface g : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield l : Landroidx/appcompat/widget/c1;
    //   104: invokeinterface f : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokespecial C0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokespecial z0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual Q : (Landroidx/appcompat/app/e$r;Z)V
    //   198: iload_3
    //   199: ifeq -> 240
    //   202: aload_0
    //   203: getfield e : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 230
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: iload_3
    //   229: ireturn
    //   230: ldc_w 'AppCompatDelegate'
    //   233: ldc_w 'Couldn't get audio manager'
    //   236: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: iload_3
    //   241: ireturn
  }
  
  private void z0(r paramr, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 405
    //   7: aload_0
    //   8: getfield a0 : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield e : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual h0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroidx/appcompat/view/menu/e;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual Q : (Landroidx/appcompat/app/e$r;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield e : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial C0 : (Landroidx/appcompat/app/e$r;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 331
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 331
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 331
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 334
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial k0 : (Landroidx/appcompat/app/e$r;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokespecial j0 : (Landroidx/appcompat/app/e$r;)Z
    //   217: ifeq -> 400
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 230
    //   227: goto -> 400
    //   230: aload_1
    //   231: getfield h : Landroid/view/View;
    //   234: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   237: astore #4
    //   239: aload #4
    //   241: astore_2
    //   242: aload #4
    //   244: ifnonnull -> 259
    //   247: new android/view/ViewGroup$LayoutParams
    //   250: dup
    //   251: bipush #-2
    //   253: bipush #-2
    //   255: invokespecial <init> : (II)V
    //   258: astore_2
    //   259: aload_1
    //   260: getfield b : I
    //   263: istore_3
    //   264: aload_1
    //   265: getfield g : Landroid/view/ViewGroup;
    //   268: iload_3
    //   269: invokevirtual setBackgroundResource : (I)V
    //   272: aload_1
    //   273: getfield h : Landroid/view/View;
    //   276: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   279: astore #4
    //   281: aload #4
    //   283: instanceof android/view/ViewGroup
    //   286: ifeq -> 301
    //   289: aload #4
    //   291: checkcast android/view/ViewGroup
    //   294: aload_1
    //   295: getfield h : Landroid/view/View;
    //   298: invokevirtual removeView : (Landroid/view/View;)V
    //   301: aload_1
    //   302: getfield g : Landroid/view/ViewGroup;
    //   305: aload_1
    //   306: getfield h : Landroid/view/View;
    //   309: aload_2
    //   310: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   313: aload_1
    //   314: getfield h : Landroid/view/View;
    //   317: invokevirtual hasFocus : ()Z
    //   320: ifne -> 331
    //   323: aload_1
    //   324: getfield h : Landroid/view/View;
    //   327: invokevirtual requestFocus : ()Z
    //   330: pop
    //   331: bipush #-2
    //   333: istore_3
    //   334: aload_1
    //   335: iconst_0
    //   336: putfield n : Z
    //   339: new android/view/WindowManager$LayoutParams
    //   342: dup
    //   343: iload_3
    //   344: bipush #-2
    //   346: aload_1
    //   347: getfield d : I
    //   350: aload_1
    //   351: getfield e : I
    //   354: sipush #1002
    //   357: ldc_w 8519680
    //   360: bipush #-3
    //   362: invokespecial <init> : (IIIIIII)V
    //   365: astore_2
    //   366: aload_2
    //   367: aload_1
    //   368: getfield c : I
    //   371: putfield gravity : I
    //   374: aload_2
    //   375: aload_1
    //   376: getfield f : I
    //   379: putfield windowAnimations : I
    //   382: aload #5
    //   384: aload_1
    //   385: getfield g : Landroid/view/ViewGroup;
    //   388: aload_2
    //   389: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   394: aload_1
    //   395: iconst_1
    //   396: putfield o : Z
    //   399: return
    //   400: aload_1
    //   401: iconst_1
    //   402: putfield q : Z
    //   405: return
  }
  
  final a A0() {
    return this.i;
  }
  
  public void B(int paramInt) {
    Y();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.e).inflate(paramInt, viewGroup);
    this.g.a().onContentChanged();
  }
  
  public void C(View paramView) {
    Y();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.g.a().onContentChanged();
  }
  
  public void D(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    Y();
    ViewGroup viewGroup = (ViewGroup)this.v.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.g.a().onContentChanged();
  }
  
  public void E(Toolbar paramToolbar) {
    if (!(this.d instanceof Activity))
      return; 
    a a1 = m();
    if (!(a1 instanceof l)) {
      l l1;
      Window window;
      this.j = null;
      if (a1 != null)
        a1.n(); 
      if (paramToolbar != null) {
        i i = new i(paramToolbar, g0(), (Window.Callback)this.g);
        this.i = i;
        window = this.f;
        Window.Callback callback = i.x();
      } else {
        this.i = null;
        window = this.f;
        l1 = this.g;
      } 
      window.setCallback((Window.Callback)l1);
      o();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  public void F(int paramInt) {
    this.c0 = paramInt;
  }
  
  final boolean F0() {
    if (this.u) {
      ViewGroup viewGroup = this.v;
      if (viewGroup != null && t0.B((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  public final void G(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    c1 c11 = this.l;
    if (c11 != null) {
      c11.setWindowTitle(paramCharSequence);
      return;
    } 
    if (A0() != null) {
      A0().u(paramCharSequence);
      return;
    } 
    TextView textView = this.w;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public boolean H() {
    return I(true);
  }
  
  public j.b H0(j.b.a parama) {
    if (parama != null) {
      j.b b1 = this.o;
      if (b1 != null)
        b1.c(); 
      parama = new g(this, parama);
      a a1 = m();
      if (a1 != null) {
        j.b b2 = a1.v(parama);
        this.o = b2;
        if (b2 != null) {
          f.a a2 = this.h;
          if (a2 != null)
            a2.e(b2); 
        } 
      } 
      if (this.o == null)
        this.o = I0(parama); 
      return this.o;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  j.b I0(j.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual X : ()V
    //   4: aload_0
    //   5: getfield o : Lj/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/e$g
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/e$g
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/e;Lj/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield h : Lf/a;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield a0 : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface j : (Lj/b$a;)Lj/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield o : Lj/b;
    //   80: goto -> 574
    //   83: aload_0
    //   84: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield D : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield e : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic e/a.f : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield e : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new j/d
    //   169: dup
    //   170: aload_0
    //   171: getfield e : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield e : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic e/a.i : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield q : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield q : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield q : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic e/a.b : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield q : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/e$d
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/e;)V
    //   309: putfield r : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield v : Landroid/view/ViewGroup;
    //   319: getstatic e/f.h : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual c0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 574
    //   362: aload_0
    //   363: invokevirtual X : ()V
    //   366: aload_0
    //   367: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield q : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new j/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Lj/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface a : (Lj/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 569
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Lj/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield o : Lj/b;
    //   445: aload_0
    //   446: invokevirtual F0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic c : (Landroid/view/View;)Landroidx/core/view/x1;
    //   467: fconst_1
    //   468: invokevirtual b : (F)Landroidx/core/view/x1;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield s : Landroidx/core/view/x1;
    //   477: aload_1
    //   478: new androidx/appcompat/app/e$e
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/e;)V
    //   486: invokevirtual h : (Landroidx/core/view/y1;)Landroidx/core/view/x1;
    //   489: pop
    //   490: goto -> 544
    //   493: aload_0
    //   494: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: bipush #32
    //   515: invokevirtual sendAccessibilityEvent : (I)V
    //   518: aload_0
    //   519: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   522: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   525: instanceof android/view/View
    //   528: ifeq -> 544
    //   531: aload_0
    //   532: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   535: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   538: checkcast android/view/View
    //   541: invokestatic L : (Landroid/view/View;)V
    //   544: aload_0
    //   545: getfield q : Landroid/widget/PopupWindow;
    //   548: ifnull -> 574
    //   551: aload_0
    //   552: getfield f : Landroid/view/Window;
    //   555: invokevirtual getDecorView : ()Landroid/view/View;
    //   558: aload_0
    //   559: getfield r : Ljava/lang/Runnable;
    //   562: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   565: pop
    //   566: goto -> 574
    //   569: aload_0
    //   570: aconst_null
    //   571: putfield o : Lj/b;
    //   574: aload_0
    //   575: getfield o : Lj/b;
    //   578: astore_1
    //   579: aload_1
    //   580: ifnull -> 602
    //   583: aload_0
    //   584: getfield h : Lf/a;
    //   587: astore #4
    //   589: aload #4
    //   591: ifnull -> 602
    //   594: aload #4
    //   596: aload_1
    //   597: invokeinterface e : (Lj/b;)V
    //   602: aload_0
    //   603: getfield o : Lj/b;
    //   606: areturn
    //   607: astore_1
    //   608: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	607	java/lang/AbstractMethodError
  }
  
  void M(int paramInt, r paramr, Menu paramMenu) {
    e e1;
    r r1 = paramr;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      r r2 = paramr;
      if (paramr == null) {
        r2 = paramr;
        if (paramInt >= 0) {
          r[] arrayOfR = this.G;
          r2 = paramr;
          if (paramInt < arrayOfR.length)
            r2 = arrayOfR[paramInt]; 
        } 
      } 
      r1 = r2;
      menu = paramMenu;
      if (r2 != null) {
        e1 = r2.j;
        r1 = r2;
      } 
    } 
    if (r1 != null && !r1.o)
      return; 
    if (!this.a0)
      this.g.a().onPanelClosed(paramInt, (Menu)e1); 
  }
  
  void N(e parame) {
    if (this.F)
      return; 
    this.F = true;
    this.l.i();
    Window.Callback callback = h0();
    if (callback != null && !this.a0)
      callback.onPanelClosed(108, (Menu)parame); 
    this.F = false;
  }
  
  final int N0(b2 paramb2, Rect paramRect) {
    int i;
    int j;
    boolean bool1;
    boolean bool2 = false;
    if (paramb2 != null) {
      i = paramb2.k();
    } else if (paramRect != null) {
      i = paramRect.top;
    } else {
      i = 0;
    } 
    ActionBarContextView actionBarContextView = this.p;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.p.getLayoutParams();
      boolean bool3 = this.p.isShown();
      int k = 1;
      bool1 = true;
      if (bool3) {
        int m;
        if (this.l0 == null) {
          this.l0 = new Rect();
          this.m0 = new Rect();
        } 
        Rect rect1 = this.l0;
        Rect rect2 = this.m0;
        if (paramb2 == null) {
          rect1.set(paramRect);
        } else {
          rect1.set(paramb2.i(), paramb2.k(), paramb2.j(), paramb2.h());
        } 
        j2.a((View)this.v, rect1, rect2);
        int i1 = rect1.top;
        bool = rect1.left;
        int i2 = rect1.right;
        paramb2 = t0.t((View)this.v);
        if (paramb2 == null) {
          k = 0;
        } else {
          k = paramb2.i();
        } 
        if (paramb2 == null) {
          m = 0;
        } else {
          m = paramb2.j();
        } 
        if (marginLayoutParams.topMargin != i1 || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i2) {
          marginLayoutParams.topMargin = i1;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i2;
          bool = true;
        } else {
          bool = false;
        } 
        if (i1 > 0 && this.x == null) {
          View view2 = new View(this.e);
          this.x = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = k;
          layoutParams.rightMargin = m;
          this.v.addView(this.x, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.x;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            i1 = marginLayoutParams1.height;
            i2 = marginLayoutParams.topMargin;
            if (i1 != i2 || marginLayoutParams1.leftMargin != k || marginLayoutParams1.rightMargin != m) {
              marginLayoutParams1.height = i2;
              marginLayoutParams1.leftMargin = k;
              marginLayoutParams1.rightMargin = m;
              this.x.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.x;
        if (view1 != null) {
          m = bool1;
        } else {
          m = 0;
        } 
        if (m != 0 && view1.getVisibility() != 0)
          O0(this.x); 
        k = i;
        if (!this.C) {
          k = i;
          if (m != 0)
            k = 0; 
        } 
        i = k;
        k = bool;
        bool = m;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        k = 0;
      } 
      j = i;
      bool1 = bool;
      if (k != 0) {
        this.p.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        j = i;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      j = i;
    } 
    View view = this.x;
    if (view != null) {
      if (bool1) {
        i = bool2;
      } else {
        i = 8;
      } 
      view.setVisibility(i);
    } 
    return j;
  }
  
  void P(int paramInt) {
    Q(f0(paramInt, true), true);
  }
  
  void Q(r paramr, boolean paramBoolean) {
    if (paramBoolean && paramr.a == 0) {
      c1 c11 = this.l;
      if (c11 != null && c11.b()) {
        N(paramr.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.e.getSystemService("window");
    if (windowManager != null && paramr.o) {
      ViewGroup viewGroup = paramr.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          M(paramr.a, paramr, null); 
      } 
    } 
    paramr.m = false;
    paramr.n = false;
    paramr.o = false;
    paramr.h = null;
    paramr.q = true;
    if (this.H == paramr)
      this.H = null; 
  }
  
  public View T(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: getfield n0 : Landroidx/appcompat/app/f;
    //   4: astore #7
    //   6: iconst_0
    //   7: istore #5
    //   9: aload #7
    //   11: ifnonnull -> 147
    //   14: aload_0
    //   15: getfield e : Landroid/content/Context;
    //   18: getstatic e/j.z0 : [I
    //   21: invokevirtual obtainStyledAttributes : ([I)Landroid/content/res/TypedArray;
    //   24: getstatic e/j.D0 : I
    //   27: invokevirtual getString : (I)Ljava/lang/String;
    //   30: astore #7
    //   32: aload #7
    //   34: ifnonnull -> 55
    //   37: new androidx/appcompat/app/f
    //   40: dup
    //   41: invokespecial <init> : ()V
    //   44: astore #7
    //   46: aload_0
    //   47: aload #7
    //   49: putfield n0 : Landroidx/appcompat/app/f;
    //   52: goto -> 147
    //   55: aload_0
    //   56: aload #7
    //   58: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   61: iconst_0
    //   62: anewarray java/lang/Class
    //   65: invokevirtual getDeclaredConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   68: iconst_0
    //   69: anewarray java/lang/Object
    //   72: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   75: checkcast androidx/appcompat/app/f
    //   78: putfield n0 : Landroidx/appcompat/app/f;
    //   81: goto -> 147
    //   84: astore #8
    //   86: new java/lang/StringBuilder
    //   89: dup
    //   90: invokespecial <init> : ()V
    //   93: astore #9
    //   95: aload #9
    //   97: ldc_w 'Failed to instantiate custom view inflater '
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: pop
    //   104: aload #9
    //   106: aload #7
    //   108: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: pop
    //   112: aload #9
    //   114: ldc_w '. Falling back to default.'
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: pop
    //   121: ldc_w 'AppCompatDelegate'
    //   124: aload #9
    //   126: invokevirtual toString : ()Ljava/lang/String;
    //   129: aload #8
    //   131: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   134: pop
    //   135: new androidx/appcompat/app/f
    //   138: dup
    //   139: invokespecial <init> : ()V
    //   142: astore #7
    //   144: goto -> 46
    //   147: getstatic androidx/appcompat/app/e.q0 : Z
    //   150: istore #6
    //   152: iload #6
    //   154: ifeq -> 234
    //   157: aload_0
    //   158: getfield o0 : Landroidx/appcompat/app/g;
    //   161: ifnonnull -> 175
    //   164: aload_0
    //   165: new androidx/appcompat/app/g
    //   168: dup
    //   169: invokespecial <init> : ()V
    //   172: putfield o0 : Landroidx/appcompat/app/g;
    //   175: aload_0
    //   176: getfield o0 : Landroidx/appcompat/app/g;
    //   179: aload #4
    //   181: invokevirtual a : (Landroid/util/AttributeSet;)Z
    //   184: ifeq -> 193
    //   187: iconst_1
    //   188: istore #5
    //   190: goto -> 237
    //   193: aload #4
    //   195: instanceof org/xmlpull/v1/XmlPullParser
    //   198: ifeq -> 221
    //   201: aload #4
    //   203: checkcast org/xmlpull/v1/XmlPullParser
    //   206: invokeinterface getDepth : ()I
    //   211: iconst_1
    //   212: if_icmple -> 231
    //   215: iconst_1
    //   216: istore #5
    //   218: goto -> 231
    //   221: aload_0
    //   222: aload_1
    //   223: checkcast android/view/ViewParent
    //   226: invokespecial G0 : (Landroid/view/ViewParent;)Z
    //   229: istore #5
    //   231: goto -> 237
    //   234: iconst_0
    //   235: istore #5
    //   237: aload_0
    //   238: getfield n0 : Landroidx/appcompat/app/f;
    //   241: aload_1
    //   242: aload_2
    //   243: aload_3
    //   244: aload #4
    //   246: iload #5
    //   248: iload #6
    //   250: iconst_1
    //   251: invokestatic c : ()Z
    //   254: invokevirtual q : (Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;ZZZZ)Landroid/view/View;
    //   257: areturn
    // Exception table:
    //   from	to	target	type
    //   55	81	84	finally
  }
  
  void U() {
    c1 c11 = this.l;
    if (c11 != null)
      c11.i(); 
    if (this.q != null) {
      this.f.getDecorView().removeCallbacks(this.r);
      if (this.q.isShowing())
        try {
          this.q.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.q = null;
    } 
    X();
    r r1 = f0(0, false);
    if (r1 != null) {
      e e1 = r1.j;
      if (e1 != null)
        e1.close(); 
    } 
  }
  
  boolean V(KeyEvent paramKeyEvent) {
    Object object = this.d;
    boolean bool1 = object instanceof androidx.core.view.s.a;
    boolean bool = true;
    if (bool1 || object instanceof f.g) {
      object = this.f.getDecorView();
      if (object != null && androidx.core.view.s.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.g.a().dispatchKeyEvent(paramKeyEvent))
      return true; 
    int i = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? r0(i, paramKeyEvent) : u0(i, paramKeyEvent);
  }
  
  void W(int paramInt) {
    r r1 = f0(paramInt, true);
    if (r1.j != null) {
      Bundle bundle = new Bundle();
      r1.j.Q(bundle);
      if (bundle.size() > 0)
        r1.s = bundle; 
      r1.j.d0();
      r1.j.clear();
    } 
    r1.r = true;
    r1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.l != null) {
      r1 = f0(0, false);
      if (r1 != null) {
        r1.m = false;
        C0(r1, null);
      } 
    } 
  }
  
  void X() {
    x1 x11 = this.s;
    if (x11 != null)
      x11.c(); 
  }
  
  public boolean a(e parame, MenuItem paramMenuItem) {
    Window.Callback callback = h0();
    if (callback != null && !this.a0) {
      r r1 = a0((Menu)parame.D());
      if (r1 != null)
        return callback.onMenuItemSelected(r1.a, paramMenuItem); 
    } 
    return false;
  }
  
  r a0(Menu paramMenu) {
    byte b1;
    r[] arrayOfR = this.G;
    int i = 0;
    if (arrayOfR != null) {
      b1 = arrayOfR.length;
    } else {
      b1 = 0;
    } 
    while (i < b1) {
      r r1 = arrayOfR[i];
      if (r1 != null && r1.j == paramMenu)
        return r1; 
      i++;
    } 
    return null;
  }
  
  public void b(e parame) {
    D0(true);
  }
  
  final Context c0() {
    Context context;
    a a1 = m();
    if (a1 != null) {
      Context context1 = a1.k();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.e; 
    return context;
  }
  
  public void d(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    Y();
    ((ViewGroup)this.v.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.g.a().onContentChanged();
  }
  
  public Context f(Context paramContext) {
    int i = 1;
    this.X = true;
    int j = p0(paramContext, L());
    boolean bool = t0;
    Configuration configuration1 = null;
    if (bool && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = R(paramContext, j, null);
      try {
        p.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof j.d) {
      Configuration configuration = R(paramContext, j, null);
      try {
        ((j.d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!s0)
      return super.f(paramContext); 
    Configuration configuration2 = new Configuration();
    configuration2.uiMode = -1;
    configuration2.fontScale = 0.0F;
    configuration2 = h.a(paramContext, configuration2).getResources().getConfiguration();
    Configuration configuration3 = paramContext.getResources().getConfiguration();
    configuration2.uiMode = configuration3.uiMode;
    if (!configuration2.equals(configuration3))
      configuration1 = b0(configuration2, configuration3); 
    configuration2 = R(paramContext, j, configuration1);
    j.d d1 = new j.d(paramContext, e.i.c);
    d1.a(configuration2);
    j = 0;
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme == null)
        i = 0; 
    } catch (NullPointerException nullPointerException) {
      i = j;
    } 
    if (i != 0)
      androidx.core.content.res.h.f.a(d1.getTheme()); 
    return super.f((Context)d1);
  }
  
  protected r f0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield G : [Landroidx/appcompat/app/e$r;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/e$r
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield G : [Landroidx/appcompat/app/e$r;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/e$r
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  final CharSequence g0() {
    Object object = this.d;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.k;
  }
  
  final Window.Callback h0() {
    return this.f.getCallback();
  }
  
  public <T extends View> T i(int paramInt) {
    Y();
    return (T)this.f.findViewById(paramInt);
  }
  
  public int k() {
    return this.b0;
  }
  
  public MenuInflater l() {
    if (this.j == null) {
      Context context;
      i0();
      a a1 = this.i;
      if (a1 != null) {
        context = a1.k();
      } else {
        context = this.e;
      } 
      this.j = (MenuInflater)new j.g(context);
    } 
    return this.j;
  }
  
  public a m() {
    i0();
    return this.i;
  }
  
  public void n() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.e);
    if (layoutInflater.getFactory() == null) {
      t.a(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof e))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  public void o() {
    a a1 = m();
    if (a1 != null && a1.l())
      return; 
    m0(0);
  }
  
  public boolean o0() {
    return this.t;
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return T(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void p(Configuration paramConfiguration) {
    if (this.A && this.u) {
      a a1 = m();
      if (a1 != null)
        a1.m(paramConfiguration); 
    } 
    androidx.appcompat.widget.j.b().g(this.e);
    I(false);
  }
  
  int p0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1) {
        n n1;
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3) {
              n1 = d0(paramContext);
              return n1.c();
            } 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          if (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)n1.getApplicationContext().getSystemService("uimode")).getNightMode() == 0)
            return -1; 
          n1 = e0((Context)n1);
          return n1.c();
        } 
      } 
      return paramInt;
    } 
    return -1;
  }
  
  public void q(Bundle paramBundle) {
    this.X = true;
    I(false);
    Z();
    Object object = this.d;
    if (object instanceof Activity) {
      try {
        object = androidx.core.app.o.c((Activity)object);
      } catch (IllegalArgumentException illegalArgumentException) {
        illegalArgumentException = null;
      } 
      if (illegalArgumentException != null) {
        a a1 = A0();
        if (a1 == null) {
          this.k0 = true;
        } else {
          a1.r(true);
        } 
      } 
      d.c(this);
    } 
    this.Y = true;
  }
  
  boolean q0() {
    j.b b1 = this.o;
    if (b1 != null) {
      b1.c();
      return true;
    } 
    a a1 = m();
    return (a1 != null && a1.h());
  }
  
  public void r() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic x : (Landroidx/appcompat/app/d;)V
    //   14: aload_0
    //   15: getfield h0 : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield f : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield j0 : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_0
    //   38: putfield Z : Z
    //   41: aload_0
    //   42: iconst_1
    //   43: putfield a0 : Z
    //   46: aload_0
    //   47: getfield b0 : I
    //   50: bipush #-100
    //   52: if_icmpeq -> 104
    //   55: aload_0
    //   56: getfield d : Ljava/lang/Object;
    //   59: astore_1
    //   60: aload_1
    //   61: instanceof android/app/Activity
    //   64: ifeq -> 104
    //   67: aload_1
    //   68: checkcast android/app/Activity
    //   71: invokevirtual isChangingConfigurations : ()Z
    //   74: ifeq -> 104
    //   77: getstatic androidx/appcompat/app/e.p0 : Lr/g;
    //   80: aload_0
    //   81: getfield d : Ljava/lang/Object;
    //   84: invokevirtual getClass : ()Ljava/lang/Class;
    //   87: invokevirtual getName : ()Ljava/lang/String;
    //   90: aload_0
    //   91: getfield b0 : I
    //   94: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   97: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   100: pop
    //   101: goto -> 121
    //   104: getstatic androidx/appcompat/app/e.p0 : Lr/g;
    //   107: aload_0
    //   108: getfield d : Ljava/lang/Object;
    //   111: invokevirtual getClass : ()Ljava/lang/Class;
    //   114: invokevirtual getName : ()Ljava/lang/String;
    //   117: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   120: pop
    //   121: aload_0
    //   122: getfield i : Landroidx/appcompat/app/a;
    //   125: astore_1
    //   126: aload_1
    //   127: ifnull -> 134
    //   130: aload_1
    //   131: invokevirtual n : ()V
    //   134: aload_0
    //   135: invokespecial O : ()V
    //   138: return
  }
  
  boolean r0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      s0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.I = bool;
    return false;
  }
  
  public void s(Bundle paramBundle) {
    Y();
  }
  
  public void t() {
    a a1 = m();
    if (a1 != null)
      a1.t(true); 
  }
  
  boolean t0(int paramInt, KeyEvent paramKeyEvent) {
    r r1;
    a a1 = m();
    if (a1 != null && a1.o(paramInt, paramKeyEvent))
      return true; 
    r r2 = this.H;
    if (r2 != null && B0(r2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      r1 = this.H;
      if (r1 != null)
        r1.n = true; 
      return true;
    } 
    if (this.H == null) {
      r2 = f0(0, true);
      C0(r2, (KeyEvent)r1);
      boolean bool = B0(r2, r1.getKeyCode(), (KeyEvent)r1, 1);
      r2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void u(Bundle paramBundle) {}
  
  boolean u0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      v0(0, paramKeyEvent);
      return true;
    } 
    boolean bool = this.I;
    this.I = false;
    r r1 = f0(0, false);
    if (r1 != null && r1.o) {
      if (!bool)
        Q(r1, true); 
      return true;
    } 
    return q0();
  }
  
  public void v() {
    this.Z = true;
    H();
  }
  
  public void w() {
    this.Z = false;
    a a1 = m();
    if (a1 != null)
      a1.t(false); 
  }
  
  void w0(int paramInt) {
    if (paramInt == 108) {
      a a1 = m();
      if (a1 != null)
        a1.i(true); 
    } 
  }
  
  void x0(int paramInt) {
    if (paramInt == 108) {
      a a1 = m();
      if (a1 != null) {
        a1.i(false);
        return;
      } 
    } else if (paramInt == 0) {
      r r1 = f0(paramInt, true);
      if (r1.o)
        Q(r1, false); 
    } 
  }
  
  void y0(ViewGroup paramViewGroup) {}
  
  public boolean z(int paramInt) {
    paramInt = E0(paramInt);
    if (this.E && paramInt == 108)
      return false; 
    if (this.A && paramInt == 1)
      this.A = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.f.requestFeature(paramInt); 
              J0();
              this.B = true;
              return true;
            } 
            J0();
            this.A = true;
            return true;
          } 
          J0();
          this.C = true;
          return true;
        } 
        J0();
        this.z = true;
        return true;
      } 
      J0();
      this.y = true;
      return true;
    } 
    J0();
    this.E = true;
    return true;
  }
  
  class a implements Runnable {
    a(e this$0) {}
    
    public void run() {
      e e1 = this.a;
      if ((e1.i0 & 0x1) != 0)
        e1.W(0); 
      e1 = this.a;
      if ((e1.i0 & 0x1000) != 0)
        e1.W(108); 
      e1 = this.a;
      e1.h0 = false;
      e1.i0 = 0;
    }
  }
  
  class b implements o0 {
    b(e this$0) {}
    
    public b2 a(View param1View, b2 param1b2) {
      int i = param1b2.k();
      int j = this.a.N0(param1b2, null);
      b2 b21 = param1b2;
      if (i != j)
        b21 = param1b2.o(param1b2.i(), j, param1b2.j(), param1b2.h()); 
      return t0.F(param1View, b21);
    }
  }
  
  class c implements ContentFrameLayout.a {
    c(e this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.U();
    }
  }
  
  class d implements Runnable {
    d(e this$0) {}
    
    public void run() {
      e e1 = this.a;
      e1.q.showAtLocation((View)e1.p, 55, 0, 0);
      this.a.X();
      if (this.a.F0()) {
        this.a.p.setAlpha(0.0F);
        e1 = this.a;
        e1.s = t0.c((View)e1.p).b(1.0F);
        this.a.s.h((y1)new a(this));
        return;
      } 
      this.a.p.setAlpha(1.0F);
      this.a.p.setVisibility(0);
    }
    
    class a extends z1 {
      a(e.d this$0) {}
      
      public void b(View param2View) {
        this.a.a.p.setAlpha(1.0F);
        this.a.a.s.h(null);
        this.a.a.s = null;
      }
      
      public void c(View param2View) {
        this.a.a.p.setVisibility(0);
      }
    }
  }
  
  class a extends z1 {
    a(e this$0) {}
    
    public void b(View param1View) {
      this.a.a.p.setAlpha(1.0F);
      this.a.a.s.h(null);
      this.a.a.s = null;
    }
    
    public void c(View param1View) {
      this.a.a.p.setVisibility(0);
    }
  }
  
  class e extends z1 {
    e(e this$0) {}
    
    public void b(View param1View) {
      this.a.p.setAlpha(1.0F);
      this.a.s.h(null);
      this.a.s = null;
    }
    
    public void c(View param1View) {
      this.a.p.setVisibility(0);
      this.a.p.sendAccessibilityEvent(32);
      if (this.a.p.getParent() instanceof View)
        t0.L((View)this.a.p.getParent()); 
    }
  }
  
  private final class f implements androidx.appcompat.view.menu.j.a {
    f(e this$0) {}
    
    public void c(e param1e, boolean param1Boolean) {
      this.a.N(param1e);
    }
    
    public boolean d(e param1e) {
      Window.Callback callback = this.a.h0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1e); 
      return true;
    }
  }
  
  class g implements j.b.a {
    private j.b.a a;
    
    public g(e this$0, j.b.a param1a) {
      this.a = param1a;
    }
    
    public boolean a(j.b param1b, Menu param1Menu) {
      return this.a.a(param1b, param1Menu);
    }
    
    public void b(j.b param1b) {
      this.a.b(param1b);
      e e1 = this.b;
      if (e1.q != null)
        e1.f.getDecorView().removeCallbacks(this.b.r); 
      e1 = this.b;
      if (e1.p != null) {
        e1.X();
        e1 = this.b;
        e1.s = t0.c((View)e1.p).b(0.0F);
        this.b.s.h((y1)new a(this));
      } 
      e1 = this.b;
      f.a a1 = e1.h;
      if (a1 != null)
        a1.i(e1.o); 
      e1 = this.b;
      e1.o = null;
      t0.L((View)e1.v);
    }
    
    public boolean c(j.b param1b, MenuItem param1MenuItem) {
      return this.a.c(param1b, param1MenuItem);
    }
    
    public boolean d(j.b param1b, Menu param1Menu) {
      t0.L((View)this.b.v);
      return this.a.d(param1b, param1Menu);
    }
    
    class a extends z1 {
      a(e.g this$0) {}
      
      public void b(View param2View) {
        this.a.b.p.setVisibility(8);
        e e = this.a.b;
        PopupWindow popupWindow = e.q;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (e.p.getParent() instanceof View) {
          t0.L((View)this.a.b.p.getParent());
        } 
        this.a.b.p.k();
        this.a.b.s.h(null);
        e = this.a.b;
        e.s = null;
        t0.L((View)e.v);
      }
    }
  }
  
  class a extends z1 {
    a(e this$0) {}
    
    public void b(View param1View) {
      this.a.b.p.setVisibility(8);
      e e = this.a.b;
      PopupWindow popupWindow = e.q;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (e.p.getParent() instanceof View) {
        t0.L((View)this.a.b.p.getParent());
      } 
      this.a.b.p.k();
      this.a.b.s.h(null);
      e = this.a.b;
      e.s = null;
      t0.L((View)e.v);
    }
  }
  
  static class h {
    static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.densityDpi;
      int j = param1Configuration2.densityDpi;
      if (i != j)
        param1Configuration3.densityDpi = j; 
    }
  }
  
  static class i {
    static boolean a(PowerManager param1PowerManager) {
      return param1PowerManager.isPowerSaveMode();
    }
  }
  
  static class j {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList1 = f.b.a(param1Configuration1);
      LocaleList localeList2 = f.b.a(param1Configuration2);
      if (!f.c.a(localeList1, localeList2)) {
        f.d.a(param1Configuration3, localeList2);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
  }
  
  static class k {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      if ((f.e.a(param1Configuration1) & 0x3) != (f.e.a(param1Configuration2) & 0x3))
        f.f.a(param1Configuration3, f.e.a(param1Configuration3) | f.e.a(param1Configuration2) & 0x3); 
      if ((f.e.a(param1Configuration1) & 0xC) != (f.e.a(param1Configuration2) & 0xC))
        f.f.a(param1Configuration3, f.e.a(param1Configuration3) | f.e.a(param1Configuration2) & 0xC); 
    }
  }
  
  class l extends j.m {
    l(e this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    final ActionMode b(ActionMode.Callback param1Callback) {
      j.f.a a = new j.f.a(this.b.e, param1Callback);
      j.b b = this.b.H0((j.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.b.V(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.b.t0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    public void onContentChanged() {}
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof e)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.b.w0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      super.onPanelClosed(param1Int, param1Menu);
      this.b.x0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      e e1;
      if (param1Menu instanceof e) {
        e1 = (e)param1Menu;
      } else {
        e1 = null;
      } 
      if (param1Int == 0 && e1 == null)
        return false; 
      if (e1 != null)
        e1.a0(true); 
      boolean bool = super.onPreparePanel(param1Int, param1View, param1Menu);
      if (e1 != null)
        e1.a0(false); 
      return bool;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      e.r r = this.b.f0(0, true);
      if (r != null) {
        e e1 = r.j;
        if (e1 != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)e1, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.b.o0() ? b(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.b.o0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : b(param1Callback);
    }
  }
  
  private class m extends n {
    private final PowerManager c;
    
    m(e this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getApplicationContext().getSystemService("power");
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
      return intentFilter;
    }
    
    public int c() {
      return e.i.a(this.c) ? 2 : 1;
    }
    
    public void d() {
      this.d.H();
    }
  }
  
  abstract class n {
    private BroadcastReceiver a;
    
    n(e this$0) {}
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.e.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    abstract IntentFilter b();
    
    abstract int c();
    
    abstract void d();
    
    void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.e.registerReceiver(this.a, intentFilter);
      } 
    }
    
    class a extends BroadcastReceiver {
      a(e.n this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    a(e this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  private class o extends n {
    private final k c;
    
    o(e this$0, k param1k) {
      super(this$0);
      this.c = param1k;
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.H();
    }
  }
  
  private static class p {
    static void a(ContextThemeWrapper param1ContextThemeWrapper, Configuration param1Configuration) {
      param1ContextThemeWrapper.applyOverrideConfiguration(param1Configuration);
    }
  }
  
  private class q extends ContentFrameLayout {
    public q(e this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean b(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.i.V(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && b((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.i.P(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(g.b.d(getContext(), param1Int));
    }
  }
  
  protected static final class r {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    e j;
    
    androidx.appcompat.view.menu.c k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    r(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    androidx.appcompat.view.menu.k a(androidx.appcompat.view.menu.j.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.c c1 = new androidx.appcompat.view.menu.c(this.l, e.g.j);
        this.k = c1;
        c1.h(param1a);
        this.j.b((androidx.appcompat.view.menu.j)this.k);
      } 
      return this.k.b(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    void c(e param1e) {
      e e1 = this.j;
      if (param1e == e1)
        return; 
      if (e1 != null)
        e1.O((androidx.appcompat.view.menu.j)this.k); 
      this.j = param1e;
      if (param1e != null) {
        androidx.appcompat.view.menu.c c1 = this.k;
        if (c1 != null)
          param1e.b((androidx.appcompat.view.menu.j)c1); 
      } 
    }
    
    void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(e.a.a, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(e.a.D, typedValue, true);
      i = typedValue.resourceId;
      if (i == 0)
        i = e.i.b; 
      theme.applyStyle(i, true);
      j.d d = new j.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(e.j.z0);
      this.b = typedArray.getResourceId(e.j.C0, 0);
      this.f = typedArray.getResourceId(e.j.B0, 0);
      typedArray.recycle();
    }
  }
  
  private final class s implements androidx.appcompat.view.menu.j.a {
    s(e this$0) {}
    
    public void c(e param1e, boolean param1Boolean) {
      boolean bool;
      e e1 = param1e.D();
      if (e1 != param1e) {
        bool = true;
      } else {
        bool = false;
      } 
      e e2 = this.a;
      if (bool)
        param1e = e1; 
      e.r r = e2.a0((Menu)param1e);
      if (r != null) {
        if (bool) {
          this.a.M(r.a, r, (Menu)e1);
          this.a.Q(r, true);
          return;
        } 
        this.a.Q(r, param1Boolean);
      } 
    }
    
    public boolean d(e param1e) {
      if (param1e == param1e.D()) {
        e e1 = this.a;
        if (e1.A) {
          Window.Callback callback = e1.h0();
          if (callback != null && !this.a.a0)
            callback.onMenuOpened(108, (Menu)param1e); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */