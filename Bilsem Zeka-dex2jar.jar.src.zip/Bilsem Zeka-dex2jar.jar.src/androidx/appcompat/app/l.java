package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.d1;
import androidx.appcompat.widget.v1;
import androidx.core.view.a2;
import androidx.core.view.t0;
import androidx.core.view.x1;
import androidx.core.view.y1;
import androidx.core.view.z1;
import e.f;
import e.j;
import j.g;
import j.h;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class l extends a implements ActionBarOverlayLayout.d {
  private static final Interpolator E = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator F = (Interpolator)new DecelerateInterpolator();
  
  boolean A;
  
  final y1 B = (y1)new a(this);
  
  final y1 C = (y1)new b(this);
  
  final a2 D = new c(this);
  
  Context a;
  
  private Context b;
  
  private Activity c;
  
  ActionBarOverlayLayout d;
  
  ActionBarContainer e;
  
  d1 f;
  
  ActionBarContextView g;
  
  View h;
  
  v1 i;
  
  private ArrayList<Object> j = new ArrayList();
  
  private int k = -1;
  
  private boolean l;
  
  d m;
  
  j.b n;
  
  j.b.a o;
  
  private boolean p;
  
  private ArrayList<a.b> q = new ArrayList<a.b>();
  
  private boolean r;
  
  private int s = 0;
  
  boolean t = true;
  
  boolean u;
  
  boolean v;
  
  private boolean w;
  
  private boolean x = true;
  
  h y;
  
  private boolean z;
  
  public l(Activity paramActivity, boolean paramBoolean) {
    this.c = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    E(view);
    if (!paramBoolean)
      this.h = view.findViewById(16908290); 
  }
  
  public l(Dialog paramDialog) {
    E(paramDialog.getWindow().getDecorView());
  }
  
  private d1 B(View paramView) {
    String str;
    if (paramView instanceof d1)
      return (d1)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void D() {
    if (this.w) {
      this.w = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      N(false);
    } 
  }
  
  private void E(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.p);
    this.d = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.f = B(paramView.findViewById(f.a));
    this.g = (ActionBarContextView)paramView.findViewById(f.f);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.c);
    this.e = actionBarContainer;
    d1 d11 = this.f;
    if (d11 != null && this.g != null && actionBarContainer != null) {
      boolean bool;
      this.a = d11.getContext();
      if ((this.f.t() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.l = true; 
      j.a a1 = j.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      K(bool);
      I(a1.g());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.a, e.a.c, 0);
      if (typedArray.getBoolean(j.k, false))
        J(true); 
      int i = typedArray.getDimensionPixelSize(j.i, 0);
      if (i != 0)
        H(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void I(boolean paramBoolean) {
    this.r = paramBoolean;
    if (!paramBoolean) {
      this.f.i(null);
      this.e.setTabContainer(this.i);
    } else {
      this.e.setTabContainer(null);
      this.f.i(this.i);
    } 
    int i = C();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    v1 v11 = this.i;
    if (v11 != null) {
      ActionBarOverlayLayout actionBarOverlayLayout1;
      if (i != 0) {
        v11.setVisibility(0);
        actionBarOverlayLayout1 = this.d;
        if (actionBarOverlayLayout1 != null)
          t0.L((View)actionBarOverlayLayout1); 
      } else {
        actionBarOverlayLayout1.setVisibility(8);
      } 
    } 
    d1 d11 = this.f;
    if (!this.r && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    d11.w(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (!this.r && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  private boolean L() {
    return t0.B((View)this.e);
  }
  
  private void M() {
    if (!this.w) {
      this.w = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      N(false);
    } 
  }
  
  private void N(boolean paramBoolean) {
    if (x(this.u, this.v, this.w)) {
      if (!this.x) {
        this.x = true;
        A(paramBoolean);
        return;
      } 
    } else if (this.x) {
      this.x = false;
      z(paramBoolean);
    } 
  }
  
  static boolean x(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  public void A(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    this.e.setVisibility(0);
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setTranslationY(0.0F);
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.e.setTranslationY(f1);
      h1 = new h();
      x1 x1 = t0.c((View)this.e).m(0.0F);
      x1.k(this.D);
      h1.c(x1);
      if (this.t) {
        View view = this.h;
        if (view != null) {
          view.setTranslationY(f1);
          h1.c(t0.c(this.h).m(0.0F));
        } 
      } 
      h1.f(F);
      h1.e(250L);
      h1.g(this.C);
      this.y = h1;
      h1.h();
    } else {
      this.e.setAlpha(1.0F);
      this.e.setTranslationY(0.0F);
      if (this.t) {
        View view = this.h;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.C.b(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (actionBarOverlayLayout != null)
      t0.L((View)actionBarOverlayLayout); 
  }
  
  public int C() {
    return this.f.n();
  }
  
  public void F(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    G(bool, 4);
  }
  
  public void G(int paramInt1, int paramInt2) {
    int i = this.f.t();
    if ((paramInt2 & 0x4) != 0)
      this.l = true; 
    this.f.k(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public void H(float paramFloat) {
    t0.T((View)this.e, paramFloat);
  }
  
  public void J(boolean paramBoolean) {
    if (!paramBoolean || this.d.w()) {
      this.A = paramBoolean;
      this.d.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void K(boolean paramBoolean) {
    this.f.s(paramBoolean);
  }
  
  public void a() {
    if (this.v) {
      this.v = false;
      N(true);
    } 
  }
  
  public void b() {}
  
  public void c(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public void d() {
    if (!this.v) {
      this.v = true;
      N(true);
    } 
  }
  
  public void e() {
    h h1 = this.y;
    if (h1 != null) {
      h1.a();
      this.y = null;
    } 
  }
  
  public void f(int paramInt) {
    this.s = paramInt;
  }
  
  public boolean h() {
    d1 d11 = this.f;
    if (d11 != null && d11.j()) {
      this.f.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean == this.p)
      return; 
    this.p = paramBoolean;
    int j = this.q.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.q.get(i)).onMenuVisibilityChanged(paramBoolean); 
  }
  
  public int j() {
    return this.f.t();
  }
  
  public Context k() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(e.a.g, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void m(Configuration paramConfiguration) {
    I(j.a.b(this.a).g());
  }
  
  public boolean o(int paramInt, KeyEvent paramKeyEvent) {
    d d2 = this.m;
    if (d2 == null)
      return false; 
    Menu menu = d2.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void r(boolean paramBoolean) {
    if (!this.l)
      F(paramBoolean); 
  }
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    G(bool, 8);
  }
  
  public void t(boolean paramBoolean) {
    this.z = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.y;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void u(CharSequence paramCharSequence) {
    this.f.setWindowTitle(paramCharSequence);
  }
  
  public j.b v(j.b.a parama) {
    d d3 = this.m;
    if (d3 != null)
      d3.c(); 
    this.d.setHideOnContentScrollEnabled(false);
    this.g.k();
    d d2 = new d(this, this.g.getContext(), parama);
    if (d2.t()) {
      this.m = d2;
      d2.k();
      this.g.h(d2);
      w(true);
      this.g.sendAccessibilityEvent(32);
      return d2;
    } 
    return null;
  }
  
  public void w(boolean paramBoolean) {
    if (paramBoolean) {
      M();
    } else {
      D();
    } 
    if (L()) {
      x1 x11;
      x1 x12;
      if (paramBoolean) {
        x12 = this.f.o(4, 100L);
        x11 = this.g.f(0, 200L);
      } else {
        x11 = this.f.o(0, 200L);
        x12 = this.g.f(8, 100L);
      } 
      h h1 = new h();
      h1.d(x12, x11);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.f.q(4);
      this.g.setVisibility(0);
      return;
    } 
    this.f.q(0);
    this.g.setVisibility(8);
  }
  
  void y() {
    j.b.a a1 = this.o;
    if (a1 != null) {
      a1.b(this.n);
      this.n = null;
      this.o = null;
    } 
  }
  
  public void z(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setAlpha(1.0F);
      this.e.setTransitioning(true);
      h1 = new h();
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      x1 x1 = t0.c((View)this.e).m(f1);
      x1.k(this.D);
      h1.c(x1);
      if (this.t) {
        View view = this.h;
        if (view != null)
          h1.c(t0.c(view).m(f1)); 
      } 
      h1.f(E);
      h1.e(250L);
      h1.g(this.B);
      this.y = h1;
      h1.h();
      return;
    } 
    this.B.b(null);
  }
  
  class a extends z1 {
    a(l this$0) {}
    
    public void b(View param1View) {
      l l1 = this.a;
      if (l1.t) {
        View view = l1.h;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.e.setTranslationY(0.0F);
        } 
      } 
      this.a.e.setVisibility(8);
      this.a.e.setTransitioning(false);
      l1 = this.a;
      l1.y = null;
      l1.y();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.d;
      if (actionBarOverlayLayout != null)
        t0.L((View)actionBarOverlayLayout); 
    }
  }
  
  class b extends z1 {
    b(l this$0) {}
    
    public void b(View param1View) {
      l l1 = this.a;
      l1.y = null;
      l1.e.requestLayout();
    }
  }
  
  class c implements a2 {
    c(l this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.e.getParent()).invalidate();
    }
  }
  
  public class d extends j.b implements e.a {
    private final Context c;
    
    private final e d;
    
    private j.b.a e;
    
    private WeakReference<View> f;
    
    public d(l this$0, Context param1Context, j.b.a param1a) {
      this.c = param1Context;
      this.e = param1a;
      e e1 = (new e(param1Context)).S(1);
      this.d = e1;
      e1.R(this);
    }
    
    public boolean a(e param1e, MenuItem param1MenuItem) {
      j.b.a a1 = this.e;
      return (a1 != null) ? a1.c(this, param1MenuItem) : false;
    }
    
    public void b(e param1e) {
      if (this.e == null)
        return; 
      k();
      this.g.g.l();
    }
    
    public void c() {
      l l1 = this.g;
      if (l1.m != this)
        return; 
      if (!l.x(l1.u, l1.v, false)) {
        l1 = this.g;
        l1.n = this;
        l1.o = this.e;
      } else {
        this.e.b(this);
      } 
      this.e = null;
      this.g.w(false);
      this.g.g.g();
      this.g.f.r().sendAccessibilityEvent(32);
      l1 = this.g;
      l1.d.setHideOnContentScrollEnabled(l1.A);
      this.g.m = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.f;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.d;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.c);
    }
    
    public CharSequence g() {
      return this.g.g.getSubtitle();
    }
    
    public CharSequence i() {
      return this.g.g.getTitle();
    }
    
    public void k() {
      if (this.g.m != this)
        return; 
      this.d.d0();
      try {
        this.e.d(this, (Menu)this.d);
        return;
      } finally {
        this.d.c0();
      } 
    }
    
    public boolean l() {
      return this.g.g.j();
    }
    
    public void m(View param1View) {
      this.g.g.setCustomView(param1View);
      this.f = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.g.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.g.g.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.g.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.g.g.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.g.g.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.d.d0();
      try {
        return this.e.a(this, (Menu)this.d);
      } finally {
        this.d.c0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\app\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */