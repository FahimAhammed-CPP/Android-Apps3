package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.i2;
import androidx.core.app.i1;
import androidx.core.app.o;
import androidx.fragment.app.e;
import androidx.lifecycle.i;
import androidx.lifecycle.w;
import androidx.lifecycle.x;
import androidx.lifecycle.y;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.d;
import f.a;

public class c extends e implements a, i1.a {
  private d p;
  
  private Resources q;
  
  public c() {
    C();
  }
  
  private void C() {
    s().d("androidx:appcompat", new a(this));
    l(new b(this));
  }
  
  private boolean I(KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  private void n() {
    x.a(getWindow().getDecorView(), (i)this);
    y.a(getWindow().getDecorView(), (w)this);
    d.a(getWindow().getDecorView(), (androidx.savedstate.c)this);
  }
  
  public d A() {
    if (this.p == null)
      this.p = d.g((Activity)this, this); 
    return this.p;
  }
  
  public a B() {
    return A().m();
  }
  
  public void D(i1 parami1) {
    parami1.m((Activity)this);
  }
  
  protected void E(int paramInt) {}
  
  public void F(i1 parami1) {}
  
  @Deprecated
  public void G() {}
  
  public boolean H() {
    Intent intent = d();
    if (intent != null) {
      if (L(intent)) {
        i1 i1 = i1.r((Context)this);
        D(i1);
        F(i1);
        i1.u();
        try {
          androidx.core.app.b.m((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        K((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  public void J(Toolbar paramToolbar) {
    A().E(paramToolbar);
  }
  
  public void K(Intent paramIntent) {
    o.e((Activity)this, paramIntent);
  }
  
  public boolean L(Intent paramIntent) {
    return o.f((Activity)this, paramIntent);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    n();
    A().d(paramView, paramLayoutParams);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(A().f(paramContext));
  }
  
  public void closeOptionsMenu() {
    a a1 = B();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.g()))
      super.closeOptionsMenu(); 
  }
  
  public Intent d() {
    return o.a((Activity)this);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a1 = B();
    return (i == 82 && a1 != null && a1.p(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public void e(j.b paramb) {}
  
  public <T extends View> T findViewById(int paramInt) {
    return A().i(paramInt);
  }
  
  public MenuInflater getMenuInflater() {
    return A().l();
  }
  
  public Resources getResources() {
    if (this.q == null && i2.c())
      this.q = (Resources)new i2((Context)this, super.getResources()); 
    Resources resources2 = this.q;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public void i(j.b paramb) {}
  
  public void invalidateOptionsMenu() {
    A().o();
  }
  
  public j.b j(j.b.a parama) {
    return null;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (this.q != null) {
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.q.updateConfiguration(paramConfiguration, displayMetrics);
    } 
    A().p(paramConfiguration);
  }
  
  public void onContentChanged() {
    G();
  }
  
  protected void onDestroy() {
    super.onDestroy();
    A().r();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return I(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a1 = B();
    return (paramMenuItem.getItemId() == 16908332 && a1 != null && (a1.j() & 0x4) != 0) ? H() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    A().s(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    A().t();
  }
  
  protected void onStart() {
    super.onStart();
    A().v();
  }
  
  protected void onStop() {
    super.onStop();
    A().w();
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    A().G(paramCharSequence);
  }
  
  public void openOptionsMenu() {
    a a1 = B();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.q()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    n();
    A().B(paramInt);
  }
  
  public void setContentView(View paramView) {
    n();
    A().C(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    n();
    A().D(paramView, paramLayoutParams);
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    A().F(paramInt);
  }
  
  public void z() {
    A().o();
  }
  
  class a implements SavedStateRegistry.b {
    a(c this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.A().u(bundle);
      return bundle;
    }
  }
  
  class b implements c.b {
    b(c this$0) {}
    
    public void a(Context param1Context) {
      d d = this.a.A();
      d.n();
      d.q(this.a.s().a("androidx:appcompat"));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\app\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */