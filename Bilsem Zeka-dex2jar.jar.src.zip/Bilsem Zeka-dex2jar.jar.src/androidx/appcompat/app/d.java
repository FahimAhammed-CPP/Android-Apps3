package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.i2;
import f.a;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import r.b;

public abstract class d {
  private static int a = -100;
  
  private static final b<WeakReference<d>> b = new b();
  
  private static final Object c = new Object();
  
  public static void A(boolean paramBoolean) {
    i2.b(paramBoolean);
  }
  
  static void c(d paramd) {
    synchronized (c) {
      y(paramd);
      b.add(new WeakReference<d>(paramd));
      return;
    } 
  }
  
  public static d g(Activity paramActivity, a parama) {
    return new e(paramActivity, parama);
  }
  
  public static d h(Dialog paramDialog, a parama) {
    return new e(paramDialog, parama);
  }
  
  public static int j() {
    return a;
  }
  
  static void x(d paramd) {
    synchronized (c) {
      y(paramd);
      return;
    } 
  }
  
  private static void y(d paramd) {
    synchronized (c) {
      Iterator<WeakReference<d>> iterator = b.iterator();
      while (iterator.hasNext()) {
        d d1 = ((WeakReference<d>)iterator.next()).get();
        if (d1 == paramd || d1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  public abstract void B(int paramInt);
  
  public abstract void C(View paramView);
  
  public abstract void D(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void E(Toolbar paramToolbar);
  
  public void F(int paramInt) {}
  
  public abstract void G(CharSequence paramCharSequence);
  
  public abstract void d(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  @Deprecated
  public void e(Context paramContext) {}
  
  public Context f(Context paramContext) {
    e(paramContext);
    return paramContext;
  }
  
  public abstract <T extends View> T i(int paramInt);
  
  public int k() {
    return -100;
  }
  
  public abstract MenuInflater l();
  
  public abstract a m();
  
  public abstract void n();
  
  public abstract void o();
  
  public abstract void p(Configuration paramConfiguration);
  
  public abstract void q(Bundle paramBundle);
  
  public abstract void r();
  
  public abstract void s(Bundle paramBundle);
  
  public abstract void t();
  
  public abstract void u(Bundle paramBundle);
  
  public abstract void v();
  
  public abstract void w();
  
  public abstract boolean z(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */