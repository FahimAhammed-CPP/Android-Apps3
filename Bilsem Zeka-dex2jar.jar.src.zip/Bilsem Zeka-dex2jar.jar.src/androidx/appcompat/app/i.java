package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.d1;
import androidx.appcompat.widget.d2;
import androidx.core.view.t0;
import j.m;
import java.util.ArrayList;

class i extends a {
  d1 a;
  
  boolean b;
  
  Window.Callback c;
  
  private boolean d;
  
  private boolean e;
  
  private ArrayList<a.b> f = new ArrayList<a.b>();
  
  private final Runnable g = new a(this);
  
  private final Toolbar.f h;
  
  i(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    b b = new b(this);
    this.h = b;
    this.a = (d1)new d2(paramToolbar, false);
    e e = new e(this, paramCallback);
    this.c = (Window.Callback)e;
    this.a.setWindowCallback((Window.Callback)e);
    paramToolbar.setOnMenuItemClickListener(b);
    this.a.setWindowTitle(paramCharSequence);
  }
  
  private Menu w() {
    if (!this.d) {
      this.a.p(new c(this), new d(this));
      this.d = true;
    } 
    return this.a.l();
  }
  
  public boolean g() {
    return this.a.f();
  }
  
  public boolean h() {
    if (this.a.j()) {
      this.a.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean == this.e)
      return; 
    this.e = paramBoolean;
    int k = this.f.size();
    for (int j = 0; j < k; j++)
      ((a.b)this.f.get(j)).onMenuVisibilityChanged(paramBoolean); 
  }
  
  public int j() {
    return this.a.t();
  }
  
  public Context k() {
    return this.a.getContext();
  }
  
  public boolean l() {
    this.a.r().removeCallbacks(this.g);
    t0.J((View)this.a.r(), this.g);
    return true;
  }
  
  public void m(Configuration paramConfiguration) {
    super.m(paramConfiguration);
  }
  
  void n() {
    this.a.r().removeCallbacks(this.g);
  }
  
  public boolean o(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = w();
    if (menu != null) {
      if (paramKeyEvent != null) {
        j = paramKeyEvent.getDeviceId();
      } else {
        j = -1;
      } 
      int j = KeyCharacterMap.load(j).getKeyboardType();
      boolean bool = true;
      if (j == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean p(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      q(); 
    return true;
  }
  
  public boolean q() {
    return this.a.g();
  }
  
  public void r(boolean paramBoolean) {}
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    z(bool, 8);
  }
  
  public void t(boolean paramBoolean) {}
  
  public void u(CharSequence paramCharSequence) {
    this.a.setWindowTitle(paramCharSequence);
  }
  
  public Window.Callback x() {
    return this.c;
  }
  
  void y() {
    androidx.appcompat.view.menu.e e;
    null = w();
    if (null instanceof androidx.appcompat.view.menu.e) {
      e = (androidx.appcompat.view.menu.e)null;
    } else {
      e = null;
    } 
    if (e != null)
      e.d0(); 
    try {
      null.clear();
      if (!this.c.onCreatePanelMenu(0, null) || !this.c.onPreparePanel(0, null, null))
        null.clear(); 
      return;
    } finally {
      if (e != null)
        e.c0(); 
    } 
  }
  
  public void z(int paramInt1, int paramInt2) {
    int j = this.a.t();
    this.a.k(paramInt1 & paramInt2 | paramInt2 & j);
  }
  
  class a implements Runnable {
    a(i this$0) {}
    
    public void run() {
      this.a.y();
    }
  }
  
  class b implements Toolbar.f {
    b(i this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return this.a.c.onMenuItemSelected(0, param1MenuItem);
    }
  }
  
  private final class c implements j.a {
    private boolean a;
    
    c(i this$0) {}
    
    public void c(androidx.appcompat.view.menu.e param1e, boolean param1Boolean) {
      if (this.a)
        return; 
      this.a = true;
      this.b.a.h();
      Window.Callback callback = this.b.c;
      if (callback != null)
        callback.onPanelClosed(108, (Menu)param1e); 
      this.a = false;
    }
    
    public boolean d(androidx.appcompat.view.menu.e param1e) {
      Window.Callback callback = this.b.c;
      if (callback != null) {
        callback.onMenuOpened(108, (Menu)param1e);
        return true;
      } 
      return false;
    }
  }
  
  private final class d implements androidx.appcompat.view.menu.e.a {
    d(i this$0) {}
    
    public boolean a(androidx.appcompat.view.menu.e param1e, MenuItem param1MenuItem) {
      return false;
    }
    
    public void b(androidx.appcompat.view.menu.e param1e) {
      i i1 = this.a;
      if (i1.c != null) {
        if (i1.a.b()) {
          this.a.c.onPanelClosed(108, (Menu)param1e);
          return;
        } 
        if (this.a.c.onPreparePanel(0, null, (Menu)param1e))
          this.a.c.onMenuOpened(108, (Menu)param1e); 
      } 
    }
  }
  
  private class e extends m {
    public e(i this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public View onCreatePanelView(int param1Int) {
      return (param1Int == 0) ? new View(this.b.a.getContext()) : super.onCreatePanelView(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      boolean bool = super.onPreparePanel(param1Int, param1View, param1Menu);
      if (bool) {
        i i1 = this.b;
        if (!i1.b) {
          i1.a.c();
          this.b.b = true;
        } 
      } 
      return bool;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\appcompat\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */