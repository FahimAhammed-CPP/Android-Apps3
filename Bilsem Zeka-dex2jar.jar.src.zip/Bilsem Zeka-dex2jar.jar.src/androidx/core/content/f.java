package androidx.core.content;

import android.content.Context;
import java.io.File;



/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\content\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */