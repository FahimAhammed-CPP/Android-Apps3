package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import u.a;

public final class c {
  private static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static ColorStateList a(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme) {
    int i;
    AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return b(paramResources, paramXmlPullParser, attributeSet, paramTheme); 
    throw new XmlPullParserException("No start tag found");
  }
  
  public static ColorStateList b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
      return e(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid color state list tag ");
    stringBuilder.append(str);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  private static TypedValue c() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
  
  public static ColorStateList d(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    try {
      return a(paramResources, (XmlPullParser)paramResources.getXml(paramInt), paramTheme);
    } catch (Exception exception) {
      Log.e("CSLCompat", "Failed to inflate ColorStateList.", exception);
      return null;
    } 
  }
  
  private static ColorStateList e(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface getDepth : ()I
    //   6: iconst_1
    //   7: iadd
    //   8: istore #12
    //   10: bipush #20
    //   12: anewarray [I
    //   15: astore #15
    //   17: bipush #20
    //   19: newarray int
    //   21: astore #16
    //   23: iconst_0
    //   24: istore #6
    //   26: aload_0
    //   27: astore #19
    //   29: aload_1
    //   30: invokeinterface next : ()I
    //   35: istore #8
    //   37: iload #8
    //   39: iconst_1
    //   40: if_icmpeq -> 513
    //   43: aload_1
    //   44: invokeinterface getDepth : ()I
    //   49: istore #9
    //   51: iload #9
    //   53: iload #12
    //   55: if_icmpge -> 64
    //   58: iload #8
    //   60: iconst_3
    //   61: if_icmpeq -> 513
    //   64: aload #16
    //   66: astore #18
    //   68: aload #15
    //   70: astore #17
    //   72: iload #6
    //   74: istore #7
    //   76: iload #8
    //   78: iconst_2
    //   79: if_icmpne -> 498
    //   82: aload #16
    //   84: astore #18
    //   86: aload #15
    //   88: astore #17
    //   90: iload #6
    //   92: istore #7
    //   94: iload #9
    //   96: iload #12
    //   98: if_icmpgt -> 498
    //   101: aload_1
    //   102: invokeinterface getName : ()Ljava/lang/String;
    //   107: ldc 'item'
    //   109: invokevirtual equals : (Ljava/lang/Object;)Z
    //   112: ifne -> 130
    //   115: aload #16
    //   117: astore #18
    //   119: aload #15
    //   121: astore #17
    //   123: iload #6
    //   125: istore #7
    //   127: goto -> 498
    //   130: aload #19
    //   132: aload_3
    //   133: aload_2
    //   134: getstatic s/d.b : [I
    //   137: invokestatic h : (Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   140: astore #17
    //   142: getstatic s/d.c : I
    //   145: istore #8
    //   147: aload #17
    //   149: iload #8
    //   151: iconst_m1
    //   152: invokevirtual getResourceId : (II)I
    //   155: istore #9
    //   157: iload #8
    //   159: istore #7
    //   161: iload #9
    //   163: iconst_m1
    //   164: if_icmpeq -> 207
    //   167: iload #8
    //   169: istore #7
    //   171: aload #19
    //   173: iload #9
    //   175: invokestatic f : (Landroid/content/res/Resources;I)Z
    //   178: ifne -> 207
    //   181: aload #19
    //   183: aload #19
    //   185: iload #9
    //   187: invokevirtual getXml : (I)Landroid/content/res/XmlResourceParser;
    //   190: aload_3
    //   191: invokestatic a : (Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    //   194: invokevirtual getDefaultColor : ()I
    //   197: istore #7
    //   199: goto -> 218
    //   202: getstatic s/d.c : I
    //   205: istore #7
    //   207: aload #17
    //   209: iload #7
    //   211: ldc -65281
    //   213: invokevirtual getColor : (II)I
    //   216: istore #7
    //   218: getstatic s/d.d : I
    //   221: istore #8
    //   223: aload #17
    //   225: iload #8
    //   227: invokevirtual hasValue : (I)Z
    //   230: istore #14
    //   232: fconst_1
    //   233: fstore #4
    //   235: iload #14
    //   237: ifeq -> 253
    //   240: aload #17
    //   242: iload #8
    //   244: fconst_1
    //   245: invokevirtual getFloat : (IF)F
    //   248: fstore #4
    //   250: goto -> 271
    //   253: getstatic s/d.f : I
    //   256: istore #8
    //   258: aload #17
    //   260: iload #8
    //   262: invokevirtual hasValue : (I)Z
    //   265: ifeq -> 271
    //   268: goto -> 240
    //   271: getstatic android/os/Build$VERSION.SDK_INT : I
    //   274: bipush #31
    //   276: if_icmplt -> 297
    //   279: getstatic s/d.e : I
    //   282: istore #8
    //   284: aload #17
    //   286: iload #8
    //   288: invokevirtual hasValue : (I)Z
    //   291: ifeq -> 297
    //   294: goto -> 302
    //   297: getstatic s/d.g : I
    //   300: istore #8
    //   302: aload #17
    //   304: iload #8
    //   306: ldc -1.0
    //   308: invokevirtual getFloat : (IF)F
    //   311: fstore #5
    //   313: aload #17
    //   315: invokevirtual recycle : ()V
    //   318: aload_2
    //   319: invokeinterface getAttributeCount : ()I
    //   324: istore #13
    //   326: iload #13
    //   328: newarray int
    //   330: astore #17
    //   332: iconst_0
    //   333: istore #8
    //   335: iconst_0
    //   336: istore #9
    //   338: iload #8
    //   340: iload #13
    //   342: if_icmpge -> 451
    //   345: aload_2
    //   346: iload #8
    //   348: invokeinterface getAttributeNameResource : (I)I
    //   353: istore #11
    //   355: iload #9
    //   357: istore #10
    //   359: iload #11
    //   361: ldc 16843173
    //   363: if_icmpeq -> 438
    //   366: iload #9
    //   368: istore #10
    //   370: iload #11
    //   372: ldc 16843551
    //   374: if_icmpeq -> 438
    //   377: iload #9
    //   379: istore #10
    //   381: iload #11
    //   383: getstatic s/a.a : I
    //   386: if_icmpeq -> 438
    //   389: iload #9
    //   391: istore #10
    //   393: iload #11
    //   395: getstatic s/a.b : I
    //   398: if_icmpeq -> 438
    //   401: aload_2
    //   402: iload #8
    //   404: iconst_0
    //   405: invokeinterface getAttributeBooleanValue : (IZ)Z
    //   410: ifeq -> 420
    //   413: iload #11
    //   415: istore #10
    //   417: goto -> 425
    //   420: iload #11
    //   422: ineg
    //   423: istore #10
    //   425: aload #17
    //   427: iload #9
    //   429: iload #10
    //   431: iastore
    //   432: iload #9
    //   434: iconst_1
    //   435: iadd
    //   436: istore #10
    //   438: iload #8
    //   440: iconst_1
    //   441: iadd
    //   442: istore #8
    //   444: iload #10
    //   446: istore #9
    //   448: goto -> 338
    //   451: aload #17
    //   453: iload #9
    //   455: invokestatic trimStateSet : ([II)[I
    //   458: astore #17
    //   460: aload #16
    //   462: iload #6
    //   464: iload #7
    //   466: fload #4
    //   468: fload #5
    //   470: invokestatic g : (IFF)I
    //   473: invokestatic a : ([III)[I
    //   476: astore #18
    //   478: aload #15
    //   480: iload #6
    //   482: aload #17
    //   484: invokestatic b : ([Ljava/lang/Object;ILjava/lang/Object;)[Ljava/lang/Object;
    //   487: checkcast [[I
    //   490: astore #17
    //   492: iload #6
    //   494: iconst_1
    //   495: iadd
    //   496: istore #7
    //   498: aload #18
    //   500: astore #16
    //   502: aload #17
    //   504: astore #15
    //   506: iload #7
    //   508: istore #6
    //   510: goto -> 26
    //   513: iload #6
    //   515: newarray int
    //   517: astore_0
    //   518: iload #6
    //   520: anewarray [I
    //   523: astore_1
    //   524: aload #16
    //   526: iconst_0
    //   527: aload_0
    //   528: iconst_0
    //   529: iload #6
    //   531: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   534: aload #15
    //   536: iconst_0
    //   537: aload_1
    //   538: iconst_0
    //   539: iload #6
    //   541: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   544: new android/content/res/ColorStateList
    //   547: dup
    //   548: aload_1
    //   549: aload_0
    //   550: invokespecial <init> : ([[I[I)V
    //   553: areturn
    //   554: astore #18
    //   556: goto -> 202
    // Exception table:
    //   from	to	target	type
    //   181	199	554	java/lang/Exception
  }
  
  private static boolean f(Resources paramResources, int paramInt) {
    TypedValue typedValue = c();
    paramResources.getValue(paramInt, typedValue, true);
    paramInt = typedValue.type;
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  private static int g(int paramInt, float paramFloat1, float paramFloat2) {
    boolean bool;
    if (paramFloat2 >= 0.0F && paramFloat2 <= 100.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramFloat1 == 1.0F && !bool)
      return paramInt; 
    int j = a.a((int)(Color.alpha(paramInt) * paramFloat1 + 0.5F), 0, 255);
    int i = paramInt;
    if (bool) {
      a a = a.c(paramInt);
      i = a.m(a.j(), a.i(), paramFloat2);
    } 
    return i & 0xFFFFFF | j << 24;
  }
  
  private static TypedArray h(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return (paramTheme == null) ? paramResources.obtainAttributes(paramAttributeSet, paramArrayOfint) : paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, 0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\content\res\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */