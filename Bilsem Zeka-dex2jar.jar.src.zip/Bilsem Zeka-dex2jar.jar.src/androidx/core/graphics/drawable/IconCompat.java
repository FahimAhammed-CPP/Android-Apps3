package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {
  static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;
  
  public int a;
  
  Object b;
  
  public byte[] c;
  
  public Parcelable d;
  
  public int e;
  
  public int f;
  
  public ColorStateList g;
  
  PorterDuff.Mode h;
  
  public String i;
  
  public String j;
  
  public IconCompat() {
    this.a = -1;
    this.c = null;
    this.d = null;
    this.e = 0;
    this.f = 0;
    this.g = null;
    this.h = k;
    this.i = null;
  }
  
  IconCompat(int paramInt) {
    this.c = null;
    this.d = null;
    this.e = 0;
    this.f = 0;
    this.g = null;
    this.h = k;
    this.i = null;
    this.a = paramInt;
  }
  
  public static IconCompat a(Icon paramIcon) {
    return a.a(paramIcon);
  }
  
  static Bitmap b(Bitmap paramBitmap, boolean paramBoolean) {
    int i = (int)(Math.min(paramBitmap.getWidth(), paramBitmap.getHeight()) * 0.6666667F);
    Bitmap bitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    Paint paint = new Paint(3);
    float f1 = i;
    float f2 = 0.5F * f1;
    float f3 = 0.9166667F * f2;
    if (paramBoolean) {
      float f = 0.010416667F * f1;
      paint.setColor(0);
      paint.setShadowLayer(f, 0.0F, f1 * 0.020833334F, 1023410176);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.setShadowLayer(f, 0.0F, 0.0F, 503316480);
      canvas.drawCircle(f2, f2, f3, paint);
      paint.clearShadowLayer();
    } 
    paint.setColor(-16777216);
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    BitmapShader bitmapShader = new BitmapShader(paramBitmap, tileMode, tileMode);
    Matrix matrix = new Matrix();
    matrix.setTranslate(-(paramBitmap.getWidth() - i) / 2.0F, -(paramBitmap.getHeight() - i) / 2.0F);
    bitmapShader.setLocalMatrix(matrix);
    paint.setShader((Shader)bitmapShader);
    canvas.drawCircle(f2, f2, f3, paint);
    canvas.setBitmap(null);
    return bitmap;
  }
  
  public static IconCompat c(Uri paramUri) {
    androidx.core.util.c.c(paramUri);
    return d(paramUri.toString());
  }
  
  public static IconCompat d(String paramString) {
    androidx.core.util.c.c(paramString);
    IconCompat iconCompat = new IconCompat(6);
    iconCompat.b = paramString;
    return iconCompat;
  }
  
  public static IconCompat e(Bitmap paramBitmap) {
    androidx.core.util.c.c(paramBitmap);
    IconCompat iconCompat = new IconCompat(1);
    iconCompat.b = paramBitmap;
    return iconCompat;
  }
  
  public static IconCompat f(Uri paramUri) {
    androidx.core.util.c.c(paramUri);
    return g(paramUri.toString());
  }
  
  public static IconCompat g(String paramString) {
    androidx.core.util.c.c(paramString);
    IconCompat iconCompat = new IconCompat(4);
    iconCompat.b = paramString;
    return iconCompat;
  }
  
  public static IconCompat h(Resources paramResources, String paramString, int paramInt) {
    androidx.core.util.c.c(paramString);
    if (paramInt != 0) {
      IconCompat iconCompat = new IconCompat(2);
      iconCompat.e = paramInt;
      if (paramResources != null)
        try {
          iconCompat.b = paramResources.getResourceName(paramInt);
          iconCompat.j = paramString;
          return iconCompat;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw new IllegalArgumentException("Icon resource cannot be found");
        }  
      iconCompat.b = paramString;
      iconCompat.j = paramString;
      return iconCompat;
    } 
    throw new IllegalArgumentException("Drawable resource ID must not be 0");
  }
  
  private static String s(int paramInt) {
    switch (paramInt) {
      default:
        return "UNKNOWN";
      case 6:
        return "URI_MASKABLE";
      case 5:
        return "BITMAP_MASKABLE";
      case 4:
        return "URI";
      case 3:
        return "DATA";
      case 2:
        return "RESOURCE";
      case 1:
        break;
    } 
    return "BITMAP";
  }
  
  public Bitmap i() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23) {
      Object object = this.b;
      return (object instanceof Bitmap) ? (Bitmap)object : null;
    } 
    if (i == 1)
      return (Bitmap)this.b; 
    if (i == 5)
      return b((Bitmap)this.b, true); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getBitmap() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int j() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.b(this.b); 
    if (i == 2)
      return this.e; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResId() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String k() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.c(this.b); 
    if (i == 2) {
      String str = this.j;
      return (str == null || TextUtils.isEmpty(str)) ? ((String)this.b).split(":", -1)[0] : this.j;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getResPackage() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int l() {
    int j = this.a;
    int i = j;
    if (j == -1) {
      i = j;
      if (Build.VERSION.SDK_INT >= 23)
        i = a.d(this.b); 
    } 
    return i;
  }
  
  public Uri m() {
    int i = this.a;
    if (i == -1 && Build.VERSION.SDK_INT >= 23)
      return a.e(this.b); 
    if (i == 4 || i == 6)
      return Uri.parse((String)this.b); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("called getUri() on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public InputStream n(Context paramContext) {
    StringBuilder stringBuilder;
    Uri uri = m();
    String str = uri.getScheme();
    if ("content".equals(str) || "file".equals(str)) {
      try {
        return paramContext.getContentResolver().openInputStream(uri);
      } catch (Exception null) {
        stringBuilder = new StringBuilder();
        str = "Unable to load image from URI: ";
      } 
      stringBuilder.append(str);
      stringBuilder.append(uri);
      Log.w("IconCompat", stringBuilder.toString(), exception);
      return null;
    } 
    try {
      return new FileInputStream(new File((String)this.b));
    } catch (FileNotFoundException exception) {
      stringBuilder = new StringBuilder();
      str = "Unable to load image from path: ";
    } 
    stringBuilder.append(str);
    stringBuilder.append(uri);
    Log.w("IconCompat", stringBuilder.toString(), exception);
    return null;
  }
  
  public void o() {
    String str;
    Parcelable parcelable2;
    byte[] arrayOfByte;
    Parcelable parcelable1;
    this.h = PorterDuff.Mode.valueOf(this.i);
    switch (this.a) {
      default:
        return;
      case 3:
        this.b = this.c;
        return;
      case 2:
      case 4:
      case 6:
        str = new String(this.c, Charset.forName("UTF-16"));
        this.b = str;
        if (this.a == 2 && this.j == null) {
          this.j = str.split(":", -1)[0];
          return;
        } 
        return;
      case 1:
      case 5:
        parcelable2 = this.d;
        if (parcelable2 != null)
          break; 
        arrayOfByte = this.c;
        this.b = arrayOfByte;
        this.a = 3;
        this.e = 0;
        this.f = arrayOfByte.length;
        return;
      case -1:
        parcelable1 = this.d;
        if (parcelable1 != null)
          break; 
        throw new IllegalArgumentException("Invalid icon");
    } 
    this.b = parcelable1;
  }
  
  public void p(boolean paramBoolean) {
    this.i = this.h.name();
    switch (this.a) {
      default:
        return;
      case 4:
      case 6:
        this.c = this.b.toString().getBytes(Charset.forName("UTF-16"));
        return;
      case 3:
        this.c = (byte[])this.b;
        return;
      case 2:
        this.c = ((String)this.b).getBytes(Charset.forName("UTF-16"));
        return;
      case 1:
      case 5:
        if (paramBoolean) {
          Bitmap bitmap = (Bitmap)this.b;
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
          this.c = byteArrayOutputStream.toByteArray();
          return;
        } 
        break;
      case -1:
        if (!paramBoolean)
          break; 
        throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
    } 
    this.d = (Parcelable)this.b;
  }
  
  @Deprecated
  public Icon q() {
    return r(null);
  }
  
  public Icon r(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 23)
      return a.g(this, paramContext); 
    throw new UnsupportedOperationException("This method is only supported on API level 23+");
  }
  
  public String toString() {
    int i;
    if (this.a == -1)
      return String.valueOf(this.b); 
    StringBuilder stringBuilder = new StringBuilder("Icon(typ=");
    stringBuilder.append(s(this.a));
    switch (this.a) {
      case 4:
      case 6:
        stringBuilder.append(" uri=");
        stringBuilder.append(this.b);
        break;
      case 3:
        stringBuilder.append(" len=");
        stringBuilder.append(this.e);
        if (this.f != 0) {
          stringBuilder.append(" off=");
          i = this.f;
        } else {
          break;
        } 
        stringBuilder.append(i);
        break;
      case 2:
        stringBuilder.append(" pkg=");
        stringBuilder.append(this.j);
        stringBuilder.append(" id=");
        stringBuilder.append(String.format("0x%08x", new Object[] { Integer.valueOf(j()) }));
        break;
      case 1:
      case 5:
        stringBuilder.append(" size=");
        stringBuilder.append(((Bitmap)this.b).getWidth());
        stringBuilder.append("x");
        i = ((Bitmap)this.b).getHeight();
        stringBuilder.append(i);
        break;
    } 
    if (this.g != null) {
      stringBuilder.append(" tint=");
      stringBuilder.append(this.g);
    } 
    if (this.h != k) {
      stringBuilder.append(" mode=");
      stringBuilder.append(this.h);
    } 
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  static class a {
    static IconCompat a(Object param1Object) {
      androidx.core.util.d.d(param1Object);
      int i = d(param1Object);
      if (i != 2) {
        if (i != 4) {
          if (i != 6) {
            IconCompat iconCompat = new IconCompat(-1);
            iconCompat.b = param1Object;
            return iconCompat;
          } 
          return IconCompat.c(e(param1Object));
        } 
        return IconCompat.f(e(param1Object));
      } 
      return IconCompat.h(null, c(param1Object), b(param1Object));
    }
    
    static int b(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.a(param1Object); 
      try {
        return ((Integer)param1Object.getClass().getMethod("getResId", new Class[0]).invoke(param1Object, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon resource", illegalAccessException);
        return 0;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon resource", invocationTargetException);
        return 0;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon resource", noSuchMethodException);
        return 0;
      } 
    }
    
    static String c(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.b(param1Object); 
      try {
        return (String)param1Object.getClass().getMethod("getResPackage", new Class[0]).invoke(param1Object, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon package", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon package", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon package", noSuchMethodException);
        return null;
      } 
    }
    
    static int d(Object param1Object) {
      StringBuilder stringBuilder;
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.c(param1Object); 
      try {
        return ((Integer)param1Object.getClass().getMethod("getType", new Class[0]).invoke(param1Object, new Object[0])).intValue();
      } catch (IllegalAccessException illegalAccessException) {
        stringBuilder = new StringBuilder();
      } catch (InvocationTargetException invocationTargetException) {
        stringBuilder = new StringBuilder();
      } catch (NoSuchMethodException noSuchMethodException) {
        stringBuilder = new StringBuilder();
      } 
      stringBuilder.append("Unable to get icon type ");
      stringBuilder.append(param1Object);
      Log.e("IconCompat", stringBuilder.toString(), noSuchMethodException);
      return -1;
    }
    
    static Uri e(Object param1Object) {
      if (Build.VERSION.SDK_INT >= 28)
        return IconCompat.c.d(param1Object); 
      try {
        return (Uri)param1Object.getClass().getMethod("getUri", new Class[0]).invoke(param1Object, new Object[0]);
      } catch (IllegalAccessException illegalAccessException) {
        Log.e("IconCompat", "Unable to get icon uri", illegalAccessException);
        return null;
      } catch (InvocationTargetException invocationTargetException) {
        Log.e("IconCompat", "Unable to get icon uri", invocationTargetException);
        return null;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("IconCompat", "Unable to get icon uri", noSuchMethodException);
        return null;
      } 
    }
    
    static Drawable f(Icon param1Icon, Context param1Context) {
      return d.a(param1Icon, param1Context);
    }
    
    static Icon g(IconCompat param1IconCompat, Context param1Context) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : I
      //   4: tableswitch default -> 52, -1 -> 334, 0 -> 52, 1 -> 288, 2 -> 273, 3 -> 251, 4 -> 237, 5 -> 195, 6 -> 62
      //   52: new java/lang/IllegalArgumentException
      //   55: dup
      //   56: ldc 'Unknown type'
      //   58: invokespecial <init> : (Ljava/lang/String;)V
      //   61: athrow
      //   62: getstatic android/os/Build$VERSION.SDK_INT : I
      //   65: istore_2
      //   66: iload_2
      //   67: bipush #30
      //   69: if_icmplt -> 83
      //   72: aload_0
      //   73: invokevirtual m : ()Landroid/net/Uri;
      //   76: invokestatic a : (Landroid/net/Uri;)Landroid/graphics/drawable/Icon;
      //   79: astore_1
      //   80: goto -> 299
      //   83: aload_1
      //   84: ifnull -> 159
      //   87: aload_0
      //   88: aload_1
      //   89: invokevirtual n : (Landroid/content/Context;)Ljava/io/InputStream;
      //   92: astore_1
      //   93: aload_1
      //   94: ifnull -> 123
      //   97: aload_1
      //   98: invokestatic decodeStream : (Ljava/io/InputStream;)Landroid/graphics/Bitmap;
      //   101: astore_1
      //   102: iload_2
      //   103: bipush #26
      //   105: if_icmplt -> 111
      //   108: goto -> 211
      //   111: aload_1
      //   112: iconst_0
      //   113: invokestatic b : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
      //   116: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   119: astore_1
      //   120: goto -> 299
      //   123: new java/lang/StringBuilder
      //   126: dup
      //   127: invokespecial <init> : ()V
      //   130: astore_1
      //   131: aload_1
      //   132: ldc 'Cannot load adaptive icon from uri: '
      //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   137: pop
      //   138: aload_1
      //   139: aload_0
      //   140: invokevirtual m : ()Landroid/net/Uri;
      //   143: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   146: pop
      //   147: new java/lang/IllegalStateException
      //   150: dup
      //   151: aload_1
      //   152: invokevirtual toString : ()Ljava/lang/String;
      //   155: invokespecial <init> : (Ljava/lang/String;)V
      //   158: athrow
      //   159: new java/lang/StringBuilder
      //   162: dup
      //   163: invokespecial <init> : ()V
      //   166: astore_1
      //   167: aload_1
      //   168: ldc 'Context is required to resolve the file uri of the icon: '
      //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   173: pop
      //   174: aload_1
      //   175: aload_0
      //   176: invokevirtual m : ()Landroid/net/Uri;
      //   179: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   182: pop
      //   183: new java/lang/IllegalArgumentException
      //   186: dup
      //   187: aload_1
      //   188: invokevirtual toString : ()Ljava/lang/String;
      //   191: invokespecial <init> : (Ljava/lang/String;)V
      //   194: athrow
      //   195: getstatic android/os/Build$VERSION.SDK_INT : I
      //   198: bipush #26
      //   200: if_icmplt -> 219
      //   203: aload_0
      //   204: getfield b : Ljava/lang/Object;
      //   207: checkcast android/graphics/Bitmap
      //   210: astore_1
      //   211: aload_1
      //   212: invokestatic b : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   215: astore_1
      //   216: goto -> 299
      //   219: aload_0
      //   220: getfield b : Ljava/lang/Object;
      //   223: checkcast android/graphics/Bitmap
      //   226: iconst_0
      //   227: invokestatic b : (Landroid/graphics/Bitmap;Z)Landroid/graphics/Bitmap;
      //   230: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   233: astore_1
      //   234: goto -> 299
      //   237: aload_0
      //   238: getfield b : Ljava/lang/Object;
      //   241: checkcast java/lang/String
      //   244: invokestatic a : (Ljava/lang/String;)Landroid/graphics/drawable/Icon;
      //   247: astore_1
      //   248: goto -> 299
      //   251: aload_0
      //   252: getfield b : Ljava/lang/Object;
      //   255: checkcast [B
      //   258: aload_0
      //   259: getfield e : I
      //   262: aload_0
      //   263: getfield f : I
      //   266: invokestatic a : ([BII)Landroid/graphics/drawable/Icon;
      //   269: astore_1
      //   270: goto -> 299
      //   273: aload_0
      //   274: invokevirtual k : ()Ljava/lang/String;
      //   277: aload_0
      //   278: getfield e : I
      //   281: invokestatic a : (Ljava/lang/String;I)Landroid/graphics/drawable/Icon;
      //   284: astore_1
      //   285: goto -> 299
      //   288: aload_0
      //   289: getfield b : Ljava/lang/Object;
      //   292: checkcast android/graphics/Bitmap
      //   295: invokestatic a : (Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;
      //   298: astore_1
      //   299: aload_0
      //   300: getfield g : Landroid/content/res/ColorStateList;
      //   303: astore_3
      //   304: aload_3
      //   305: ifnull -> 314
      //   308: aload_1
      //   309: aload_3
      //   310: invokestatic a : (Landroid/graphics/drawable/Icon;Landroid/content/res/ColorStateList;)Landroid/graphics/drawable/Icon;
      //   313: pop
      //   314: aload_0
      //   315: getfield h : Landroid/graphics/PorterDuff$Mode;
      //   318: astore_0
      //   319: aload_0
      //   320: getstatic androidx/core/graphics/drawable/IconCompat.k : Landroid/graphics/PorterDuff$Mode;
      //   323: if_acmpeq -> 332
      //   326: aload_1
      //   327: aload_0
      //   328: invokestatic a : (Landroid/graphics/drawable/Icon;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Icon;
      //   331: pop
      //   332: aload_1
      //   333: areturn
      //   334: aload_0
      //   335: getfield b : Ljava/lang/Object;
      //   338: checkcast android/graphics/drawable/Icon
      //   341: areturn
    }
  }
  
  static class b {
    static Drawable a(Drawable param1Drawable1, Drawable param1Drawable2) {
      return (Drawable)new AdaptiveIconDrawable(param1Drawable1, param1Drawable2);
    }
    
    static Icon b(Bitmap param1Bitmap) {
      return k.a(param1Bitmap);
    }
  }
  
  static class c {
    static int a(Object param1Object) {
      return l.a((Icon)param1Object);
    }
    
    static String b(Object param1Object) {
      return o.a((Icon)param1Object);
    }
    
    static int c(Object param1Object) {
      return n.a((Icon)param1Object);
    }
    
    static Uri d(Object param1Object) {
      return m.a((Icon)param1Object);
    }
  }
  
  static class d {
    static Icon a(Uri param1Uri) {
      return p.a(param1Uri);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\graphics\drawable\IconCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */