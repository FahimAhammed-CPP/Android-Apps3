package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;

final class u extends Drawable.ConstantState {
  int a;
  
  Drawable.ConstantState b;
  
  ColorStateList c = null;
  
  PorterDuff.Mode d = s.g;
  
  u(u paramu) {
    if (paramu != null) {
      this.a = paramu.a;
      this.b = paramu.b;
      this.c = paramu.c;
      this.d = paramu.d;
    } 
  }
  
  boolean a() {
    return (this.b != null);
  }
  
  public int getChangingConfigurations() {
    byte b;
    int i = this.a;
    Drawable.ConstantState constantState = this.b;
    if (constantState != null) {
      b = constantState.getChangingConfigurations();
    } else {
      b = 0;
    } 
    return i | b;
  }
  
  public Drawable newDrawable() {
    return newDrawable(null);
  }
  
  public Drawable newDrawable(Resources paramResources) {
    return new t(this, paramResources);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\graphics\drawabl\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */