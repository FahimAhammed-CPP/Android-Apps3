package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.InsetDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;

public final class a {
  private static Method a;
  
  private static boolean b;
  
  private static Method c;
  
  private static boolean d;
  
  public static void a(Drawable paramDrawable, Resources.Theme paramTheme) {
    b.a(paramDrawable, paramTheme);
  }
  
  public static boolean b(Drawable paramDrawable) {
    return b.b(paramDrawable);
  }
  
  public static int c(Drawable paramDrawable) {
    return a.a(paramDrawable);
  }
  
  public static ColorFilter d(Drawable paramDrawable) {
    return b.c(paramDrawable);
  }
  
  public static int e(Drawable paramDrawable) {
    if (Build.VERSION.SDK_INT >= 23)
      return c.a(paramDrawable); 
    if (!d) {
      try {
        Method method1 = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
        c = method1;
        method1.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("DrawableCompat", "Failed to retrieve getLayoutDirection() method", noSuchMethodException);
      } 
      d = true;
    } 
    Method method = c;
    if (method != null)
      try {
        return ((Integer)method.invoke(paramDrawable, new Object[0])).intValue();
      } catch (Exception exception) {
        Log.i("DrawableCompat", "Failed to invoke getLayoutDirection() via reflection", exception);
        c = null;
      }  
    return 0;
  }
  
  public static void f(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    b.d(paramDrawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
  }
  
  public static boolean g(Drawable paramDrawable) {
    return a.d(paramDrawable);
  }
  
  @Deprecated
  public static void h(Drawable paramDrawable) {
    paramDrawable.jumpToCurrentState();
  }
  
  public static void i(Drawable paramDrawable, boolean paramBoolean) {
    a.e(paramDrawable, paramBoolean);
  }
  
  public static void j(Drawable paramDrawable, float paramFloat1, float paramFloat2) {
    b.e(paramDrawable, paramFloat1, paramFloat2);
  }
  
  public static void k(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    b.f(paramDrawable, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static boolean l(Drawable paramDrawable, int paramInt) {
    if (Build.VERSION.SDK_INT >= 23)
      return c.b(paramDrawable, paramInt); 
    if (!b) {
      try {
        Method method1 = Drawable.class.getDeclaredMethod("setLayoutDirection", new Class[] { int.class });
        a = method1;
        method1.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("DrawableCompat", "Failed to retrieve setLayoutDirection(int) method", noSuchMethodException);
      } 
      b = true;
    } 
    Method method = a;
    if (method != null)
      try {
        method.invoke(paramDrawable, new Object[] { Integer.valueOf(paramInt) });
        return true;
      } catch (Exception exception) {
        Log.i("DrawableCompat", "Failed to invoke setLayoutDirection(int) via reflection", exception);
        a = null;
      }  
    return false;
  }
  
  public static void m(Drawable paramDrawable, int paramInt) {
    b.g(paramDrawable, paramInt);
  }
  
  public static void n(Drawable paramDrawable, ColorStateList paramColorStateList) {
    b.h(paramDrawable, paramColorStateList);
  }
  
  public static void o(Drawable paramDrawable, PorterDuff.Mode paramMode) {
    b.i(paramDrawable, paramMode);
  }
  
  public static Drawable p(Drawable paramDrawable) {
    return (Build.VERSION.SDK_INT >= 23) ? paramDrawable : (!(paramDrawable instanceof q) ? new t(paramDrawable) : paramDrawable);
  }
  
  static class a {
    static int a(Drawable param1Drawable) {
      return param1Drawable.getAlpha();
    }
    
    static Drawable b(DrawableContainer.DrawableContainerState param1DrawableContainerState, int param1Int) {
      return param1DrawableContainerState.getChild(param1Int);
    }
    
    static Drawable c(InsetDrawable param1InsetDrawable) {
      return param1InsetDrawable.getDrawable();
    }
    
    static boolean d(Drawable param1Drawable) {
      return param1Drawable.isAutoMirrored();
    }
    
    static void e(Drawable param1Drawable, boolean param1Boolean) {
      param1Drawable.setAutoMirrored(param1Boolean);
    }
  }
  
  static class b {
    static void a(Drawable param1Drawable, Resources.Theme param1Theme) {
      param1Drawable.applyTheme(param1Theme);
    }
    
    static boolean b(Drawable param1Drawable) {
      return param1Drawable.canApplyTheme();
    }
    
    static ColorFilter c(Drawable param1Drawable) {
      return param1Drawable.getColorFilter();
    }
    
    static void d(Drawable param1Drawable, Resources param1Resources, XmlPullParser param1XmlPullParser, AttributeSet param1AttributeSet, Resources.Theme param1Theme) {
      param1Drawable.inflate(param1Resources, param1XmlPullParser, param1AttributeSet, param1Theme);
    }
    
    static void e(Drawable param1Drawable, float param1Float1, float param1Float2) {
      param1Drawable.setHotspot(param1Float1, param1Float2);
    }
    
    static void f(Drawable param1Drawable, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1Drawable.setHotspotBounds(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    static void g(Drawable param1Drawable, int param1Int) {
      param1Drawable.setTint(param1Int);
    }
    
    static void h(Drawable param1Drawable, ColorStateList param1ColorStateList) {
      param1Drawable.setTintList(param1ColorStateList);
    }
    
    static void i(Drawable param1Drawable, PorterDuff.Mode param1Mode) {
      param1Drawable.setTintMode(param1Mode);
    }
  }
  
  static class c {
    static int a(Drawable param1Drawable) {
      return c.a(param1Drawable);
    }
    
    static boolean b(Drawable param1Drawable, int param1Int) {
      return b.a(param1Drawable, param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\graphics\drawable\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */