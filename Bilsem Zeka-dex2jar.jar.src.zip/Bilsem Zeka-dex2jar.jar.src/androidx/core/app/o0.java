package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import r.b;

class o0 implements p {
  private final Context a;
  
  private final Notification.Builder b;
  
  private final q.e c;
  
  private RemoteViews d;
  
  private RemoteViews e;
  
  private final List<Bundle> f;
  
  private final Bundle g;
  
  private int h;
  
  private RemoteViews i;
  
  o0(q.e parame) {
    boolean bool;
    List<String> list;
    this.f = new ArrayList<Bundle>();
    this.g = new Bundle();
    this.c = parame;
    this.a = parame.a;
    if (Build.VERSION.SDK_INT >= 26) {
      builder = new Notification.Builder(parame.a, parame.K);
    } else {
      builder = new Notification.Builder(parame.a);
    } 
    this.b = builder;
    Notification notification = parame.R;
    Notification.Builder builder = this.b.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, parame.i).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((notification.flags & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOngoing(bool);
    if ((notification.flags & 0x8) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setOnlyAlertOnce(bool);
    if ((notification.flags & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder = builder.setAutoCancel(bool).setDefaults(notification.defaults).setContentTitle(parame.e).setContentText(parame.f).setContentInfo(parame.k).setContentIntent(parame.g).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = parame.h;
    if ((notification.flags & 0x80) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    builder.setFullScreenIntent(pendingIntent, bool).setLargeIcon(parame.j).setNumber(parame.l).setProgress(parame.t, parame.u, parame.v);
    this.b.setSubText(parame.q).setUsesChronometer(parame.o).setPriority(parame.m);
    Iterator<q.a> iterator = parame.b.iterator();
    while (iterator.hasNext())
      b(iterator.next()); 
    Bundle bundle = parame.D;
    if (bundle != null)
      this.g.putAll(bundle); 
    int i = Build.VERSION.SDK_INT;
    this.d = parame.H;
    this.e = parame.I;
    this.b.setShowWhen(parame.n);
    this.b.setLocalOnly(parame.z).setGroup(parame.w).setGroupSummary(parame.x).setSortKey(parame.y);
    this.h = parame.O;
    this.b.setCategory(parame.C).setColor(parame.E).setVisibility(parame.F).setPublicVersion(parame.G).setSound(notification.sound, notification.audioAttributes);
    if (i < 28) {
      list = e(g(parame.c), parame.U);
    } else {
      list = parame.U;
    } 
    if (list != null && !list.isEmpty())
      for (String str : list)
        this.b.addPerson(str);  
    this.i = parame.J;
    if (parame.d.size() > 0) {
      Bundle bundle2 = parame.c().getBundle("android.car.EXTENSIONS");
      Bundle bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle2 = new Bundle(bundle1);
      Bundle bundle3 = new Bundle();
      for (i = 0; i < parame.d.size(); i++)
        bundle3.putBundle(Integer.toString(i), p0.a(parame.d.get(i))); 
      bundle1.putBundle("invisible_actions", bundle3);
      bundle2.putBundle("invisible_actions", bundle3);
      parame.c().putBundle("android.car.EXTENSIONS", bundle1);
      this.g.putBundle("android.car.EXTENSIONS", bundle2);
    } 
    i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      Icon icon = parame.T;
      if (icon != null)
        v.a(this.b, icon); 
    } 
    if (i >= 24) {
      l0.a(this.b.setExtras(parame.D), parame.s);
      RemoteViews remoteViews = parame.H;
      if (remoteViews != null)
        m0.a(this.b, remoteViews); 
      remoteViews = parame.I;
      if (remoteViews != null)
        n0.a(this.b, remoteViews); 
      remoteViews = parame.J;
      if (remoteViews != null)
        w.a(this.b, remoteViews); 
    } 
    if (i >= 26) {
      k0.a(a0.a(z.a(y.a(x.a(this.b, parame.L), parame.r), parame.M), parame.N), parame.O);
      if (parame.B)
        f0.a(this.b, parame.A); 
      if (!TextUtils.isEmpty(parame.K))
        this.b.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
    if (i >= 28)
      for (f1 f1 : parame.c)
        g0.a(this.b, f1.h());  
    i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      h0.a(this.b, parame.Q);
      i0.a(this.b, q.d.a(null));
    } 
    if (i >= 31) {
      int j = parame.P;
      if (j != 0)
        j0.a(this.b, j); 
    } 
    if (parame.S) {
      if (this.c.x) {
        this.h = 2;
      } else {
        this.h = 1;
      } 
      this.b.setVibrate(null);
      this.b.setSound(null);
      int j = notification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
      notification.defaults = j;
      this.b.setDefaults(j);
      if (i >= 26) {
        if (TextUtils.isEmpty(this.c.w))
          this.b.setGroup("silent"); 
        k0.a(this.b, this.h);
      } 
    } 
  }
  
  private void b(q.a parama) {
    Notification.Action.Builder builder;
    Bundle bundle;
    int i = Build.VERSION.SDK_INT;
    IconCompat iconCompat = parama.d();
    boolean bool = false;
    if (i >= 23) {
      if (iconCompat != null) {
        Icon icon = iconCompat.q();
      } else {
        iconCompat = null;
      } 
      builder = new Notification.Action.Builder((Icon)iconCompat, parama.h(), parama.a());
    } else {
      if (builder != null) {
        i = builder.j();
      } else {
        i = 0;
      } 
      builder = new Notification.Action.Builder(i, parama.h(), parama.a());
    } 
    if (parama.e() != null) {
      RemoteInput[] arrayOfRemoteInput = g1.b(parama.e());
      int j = arrayOfRemoteInput.length;
      for (i = bool; i < j; i++)
        builder.addRemoteInput(arrayOfRemoteInput[i]); 
    } 
    if (parama.c() != null) {
      bundle = new Bundle(parama.c());
    } else {
      bundle = new Bundle();
    } 
    bundle.putBoolean("android.support.allowGeneratedReplies", parama.b());
    i = Build.VERSION.SDK_INT;
    if (i >= 24)
      b0.a(builder, parama.b()); 
    bundle.putInt("android.support.action.semanticAction", parama.f());
    if (i >= 28)
      c0.a(builder, parama.f()); 
    if (i >= 29)
      d0.a(builder, parama.j()); 
    if (i >= 31)
      e0.a(builder, parama.i()); 
    bundle.putBoolean("android.support.action.showsUserInterface", parama.g());
    builder.addExtras(bundle);
    this.b.addAction(builder.build());
  }
  
  private static List<String> e(List<String> paramList1, List<String> paramList2) {
    if (paramList1 == null)
      return paramList2; 
    if (paramList2 == null)
      return paramList1; 
    b b = new b(paramList1.size() + paramList2.size());
    b.addAll(paramList1);
    b.addAll(paramList2);
    return new ArrayList<String>((Collection<? extends String>)b);
  }
  
  private static List<String> g(List<f1> paramList) {
    if (paramList == null)
      return null; 
    ArrayList<String> arrayList = new ArrayList(paramList.size());
    Iterator<f1> iterator = paramList.iterator();
    while (iterator.hasNext())
      arrayList.add(((f1)iterator.next()).g()); 
    return arrayList;
  }
  
  private void h(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults = paramNotification.defaults & 0xFFFFFFFE & 0xFFFFFFFD;
  }
  
  public Notification.Builder a() {
    return this.b;
  }
  
  public Notification c() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroidx/core/app/q$e;
    //   4: getfield p : Landroidx/core/app/q$f;
    //   7: astore_2
    //   8: aload_2
    //   9: ifnull -> 17
    //   12: aload_2
    //   13: aload_0
    //   14: invokevirtual b : (Landroidx/core/app/p;)V
    //   17: aload_2
    //   18: ifnull -> 30
    //   21: aload_2
    //   22: aload_0
    //   23: invokevirtual e : (Landroidx/core/app/p;)Landroid/widget/RemoteViews;
    //   26: astore_1
    //   27: goto -> 32
    //   30: aconst_null
    //   31: astore_1
    //   32: aload_0
    //   33: invokevirtual d : ()Landroid/app/Notification;
    //   36: astore_3
    //   37: aload_1
    //   38: ifnull -> 49
    //   41: aload_3
    //   42: aload_1
    //   43: putfield contentView : Landroid/widget/RemoteViews;
    //   46: goto -> 64
    //   49: aload_0
    //   50: getfield c : Landroidx/core/app/q$e;
    //   53: getfield H : Landroid/widget/RemoteViews;
    //   56: astore_1
    //   57: aload_1
    //   58: ifnull -> 64
    //   61: goto -> 41
    //   64: aload_2
    //   65: ifnull -> 83
    //   68: aload_2
    //   69: aload_0
    //   70: invokevirtual d : (Landroidx/core/app/p;)Landroid/widget/RemoteViews;
    //   73: astore_1
    //   74: aload_1
    //   75: ifnull -> 83
    //   78: aload_3
    //   79: aload_1
    //   80: putfield bigContentView : Landroid/widget/RemoteViews;
    //   83: aload_2
    //   84: ifnull -> 108
    //   87: aload_0
    //   88: getfield c : Landroidx/core/app/q$e;
    //   91: getfield p : Landroidx/core/app/q$f;
    //   94: aload_0
    //   95: invokevirtual f : (Landroidx/core/app/p;)Landroid/widget/RemoteViews;
    //   98: astore_1
    //   99: aload_1
    //   100: ifnull -> 108
    //   103: aload_3
    //   104: aload_1
    //   105: putfield headsUpContentView : Landroid/widget/RemoteViews;
    //   108: aload_2
    //   109: ifnull -> 126
    //   112: aload_3
    //   113: invokestatic a : (Landroid/app/Notification;)Landroid/os/Bundle;
    //   116: astore_1
    //   117: aload_1
    //   118: ifnull -> 126
    //   121: aload_2
    //   122: aload_1
    //   123: invokevirtual a : (Landroid/os/Bundle;)V
    //   126: aload_3
    //   127: areturn
  }
  
  protected Notification d() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 26)
      return this.b.build(); 
    if (i >= 24) {
      Notification notification1 = this.b.build();
      if (this.h != 0) {
        if (notification1.getGroup() != null && (notification1.flags & 0x200) != 0 && this.h == 2)
          h(notification1); 
        if (notification1.getGroup() != null && (notification1.flags & 0x200) == 0 && this.h == 1)
          h(notification1); 
      } 
      return notification1;
    } 
    this.b.setExtras(this.g);
    Notification notification = this.b.build();
    RemoteViews remoteViews = this.d;
    if (remoteViews != null)
      notification.contentView = remoteViews; 
    remoteViews = this.e;
    if (remoteViews != null)
      notification.bigContentView = remoteViews; 
    remoteViews = this.i;
    if (remoteViews != null)
      notification.headsUpContentView = remoteViews; 
    if (this.h != 0) {
      if (notification.getGroup() != null && (notification.flags & 0x200) != 0 && this.h == 2)
        h(notification); 
      if (notification.getGroup() != null && (notification.flags & 0x200) == 0 && this.h == 1)
        h(notification); 
    } 
    return notification;
  }
  
  Context f() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\app\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */