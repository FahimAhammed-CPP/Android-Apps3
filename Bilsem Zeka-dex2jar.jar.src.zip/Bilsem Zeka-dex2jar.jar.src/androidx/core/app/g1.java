package androidx.core.app;

import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;

public final class g1 {
  static RemoteInput a(g1 paramg1) {
    return a.b(paramg1);
  }
  
  static RemoteInput[] b(g1[] paramArrayOfg1) {
    if (paramArrayOfg1 == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfg1.length];
    for (int i = 0; i < paramArrayOfg1.length; i++) {
      g1 g11 = paramArrayOfg1[i];
      arrayOfRemoteInput[i] = a(null);
    } 
    return arrayOfRemoteInput;
  }
  
  static class a {
    static void a(Object param1Object, Intent param1Intent, Bundle param1Bundle) {
      RemoteInput.addResultsToIntent((RemoteInput[])param1Object, param1Intent, param1Bundle);
    }
    
    public static RemoteInput b(g1 param1g1) {
      throw null;
    }
    
    static Bundle c(Intent param1Intent) {
      return RemoteInput.getResultsFromIntent(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\app\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */