package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class i1 implements Iterable<Intent> {
  private final ArrayList<Intent> a = new ArrayList<Intent>();
  
  private final Context b;
  
  private i1(Context paramContext) {
    this.b = paramContext;
  }
  
  public static i1 r(Context paramContext) {
    return new i1(paramContext);
  }
  
  @Deprecated
  public Iterator<Intent> iterator() {
    return this.a.iterator();
  }
  
  public i1 l(Intent paramIntent) {
    this.a.add(paramIntent);
    return this;
  }
  
  public i1 m(Activity paramActivity) {
    Intent intent1;
    if (paramActivity instanceof a) {
      intent1 = ((a)paramActivity).d();
    } else {
      intent1 = null;
    } 
    Intent intent2 = intent1;
    if (intent1 == null)
      intent2 = o.a(paramActivity); 
    if (intent2 != null) {
      ComponentName componentName2 = intent2.getComponent();
      ComponentName componentName1 = componentName2;
      if (componentName2 == null)
        componentName1 = intent2.resolveActivity(this.b.getPackageManager()); 
      n(componentName1);
      l(intent2);
    } 
    return this;
  }
  
  public i1 n(ComponentName paramComponentName) {
    int i = this.a.size();
    try {
      Context context2 = this.b;
      ComponentName componentName = paramComponentName;
      Context context1 = context2;
      while (true) {
        Intent intent = o.b(context1, componentName);
        if (intent != null) {
          this.a.add(i, intent);
          context1 = this.b;
          ComponentName componentName1 = intent.getComponent();
          continue;
        } 
        return this;
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
      throw new IllegalArgumentException(nameNotFoundException);
    } 
  }
  
  public void u() {
    w(null);
  }
  
  public void w(Bundle paramBundle) {
    if (!this.a.isEmpty()) {
      Intent[] arrayOfIntent = this.a.<Intent>toArray(new Intent[0]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      if (!androidx.core.content.a.j(this.b, arrayOfIntent, paramBundle)) {
        Intent intent = new Intent(arrayOfIntent[arrayOfIntent.length - 1]);
        intent.addFlags(268435456);
        this.b.startActivity(intent);
      } 
      return;
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
  }
  
  public static interface a {
    Intent d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\app\i1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */