package androidx.core.app;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import java.util.HashSet;
import java.util.Set;

public final class r0 {
  private static final Object c = new Object();
  
  private static Set<String> d = new HashSet<String>();
  
  private static final Object e = new Object();
  
  private final Context a;
  
  private final NotificationManager b;
  
  private r0(Context paramContext) {
    this.a = paramContext;
    this.b = (NotificationManager)paramContext.getSystemService("notification");
  }
  
  public static r0 b(Context paramContext) {
    return new r0(paramContext);
  }
  
  public boolean a() {
    if (Build.VERSION.SDK_INT >= 24)
      return q0.a(this.b); 
    AppOpsManager appOpsManager = (AppOpsManager)this.a.getSystemService("appops");
    ApplicationInfo applicationInfo = this.a.getApplicationInfo();
    String str = this.a.getApplicationContext().getPackageName();
    int i = applicationInfo.uid;
    try {
      Class<?> clazz = Class.forName(AppOpsManager.class.getName());
      Class<int> clazz1 = int.class;
      i = ((Integer)clazz.getMethod("checkOpNoThrow", new Class[] { clazz1, clazz1, String.class }).invoke(appOpsManager, new Object[] { Integer.valueOf(((Integer)clazz.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue()), Integer.valueOf(i), str })).intValue();
      return (i == 0);
    } catch (ClassNotFoundException|NoSuchMethodException|NoSuchFieldException|java.lang.reflect.InvocationTargetException|IllegalAccessException|RuntimeException classNotFoundException) {
      return true;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\app\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */