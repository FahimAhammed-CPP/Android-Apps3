package androidx.core.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.core.view.s;
import androidx.lifecycle.e;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.s;
import r.g;

public class n extends Activity implements i, s.a {
  private g<Class<Object>, Object> a = new g();
  
  private j b = new j(this);
  
  public e a() {
    return (e)this.b;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && s.d(view, paramKeyEvent)) ? true : s.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && s.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public boolean h(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  @SuppressLint({"RestrictedApi"})
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    s.g(this);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.b.j(e.c.c);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\app\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */