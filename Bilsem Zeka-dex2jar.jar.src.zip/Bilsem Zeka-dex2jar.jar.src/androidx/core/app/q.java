package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.util.ArrayList;

public class q {
  public static Bundle a(Notification paramNotification) {
    return paramNotification.extras;
  }
  
  public static class a {
    final Bundle a;
    
    private IconCompat b;
    
    private final g1[] c;
    
    private final g1[] d;
    
    private boolean e;
    
    boolean f = true;
    
    private final int g;
    
    private final boolean h;
    
    @Deprecated
    public int i;
    
    public CharSequence j;
    
    public PendingIntent k;
    
    private boolean l;
    
    public a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(iconCompat, param1CharSequence, param1PendingIntent);
    }
    
    public a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(param1IconCompat, param1CharSequence, param1PendingIntent, new Bundle(), null, null, true, 0, true, false, false);
    }
    
    a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent, Bundle param1Bundle, g1[] param1ArrayOfg11, g1[] param1ArrayOfg12, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this.b = param1IconCompat;
      if (param1IconCompat != null && param1IconCompat.l() == 2)
        this.i = param1IconCompat.j(); 
      this.j = q.e.d(param1CharSequence);
      this.k = param1PendingIntent;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      this.a = param1Bundle;
      this.c = param1ArrayOfg11;
      this.d = param1ArrayOfg12;
      this.e = param1Boolean1;
      this.g = param1Int;
      this.f = param1Boolean2;
      this.h = param1Boolean3;
      this.l = param1Boolean4;
    }
    
    public PendingIntent a() {
      return this.k;
    }
    
    public boolean b() {
      return this.e;
    }
    
    public Bundle c() {
      return this.a;
    }
    
    public IconCompat d() {
      if (this.b == null) {
        int i = this.i;
        if (i != 0)
          this.b = IconCompat.h(null, "", i); 
      } 
      return this.b;
    }
    
    public g1[] e() {
      return this.c;
    }
    
    public int f() {
      return this.g;
    }
    
    public boolean g() {
      return this.f;
    }
    
    public CharSequence h() {
      return this.j;
    }
    
    public boolean i() {
      return this.l;
    }
    
    public boolean j() {
      return this.h;
    }
  }
  
  public static class b extends f {
    private IconCompat e;
    
    private IconCompat f;
    
    private boolean g;
    
    private CharSequence h;
    
    private boolean i;
    
    public void b(p param1p) {
      // Byte code:
      //   0: getstatic android/os/Build$VERSION.SDK_INT : I
      //   3: istore_2
      //   4: new android/app/Notification$BigPictureStyle
      //   7: dup
      //   8: aload_1
      //   9: invokeinterface a : ()Landroid/app/Notification$Builder;
      //   14: invokespecial <init> : (Landroid/app/Notification$Builder;)V
      //   17: aload_0
      //   18: getfield b : Ljava/lang/CharSequence;
      //   21: invokevirtual setBigContentTitle : (Ljava/lang/CharSequence;)Landroid/app/Notification$BigPictureStyle;
      //   24: astore #5
      //   26: aload_0
      //   27: getfield e : Landroidx/core/graphics/drawable/IconCompat;
      //   30: astore #6
      //   32: aconst_null
      //   33: astore #4
      //   35: aload #5
      //   37: astore_3
      //   38: aload #6
      //   40: ifnull -> 113
      //   43: iload_2
      //   44: bipush #31
      //   46: if_icmplt -> 88
      //   49: aload_1
      //   50: instanceof androidx/core/app/o0
      //   53: ifeq -> 67
      //   56: aload_1
      //   57: checkcast androidx/core/app/o0
      //   60: invokevirtual f : ()Landroid/content/Context;
      //   63: astore_3
      //   64: goto -> 69
      //   67: aconst_null
      //   68: astore_3
      //   69: aload #5
      //   71: aload_0
      //   72: getfield e : Landroidx/core/graphics/drawable/IconCompat;
      //   75: aload_3
      //   76: invokevirtual r : (Landroid/content/Context;)Landroid/graphics/drawable/Icon;
      //   79: invokestatic a : (Landroid/app/Notification$BigPictureStyle;Landroid/graphics/drawable/Icon;)V
      //   82: aload #5
      //   84: astore_3
      //   85: goto -> 113
      //   88: aload #5
      //   90: astore_3
      //   91: aload #6
      //   93: invokevirtual l : ()I
      //   96: iconst_1
      //   97: if_icmpne -> 113
      //   100: aload #5
      //   102: aload_0
      //   103: getfield e : Landroidx/core/graphics/drawable/IconCompat;
      //   106: invokevirtual i : ()Landroid/graphics/Bitmap;
      //   109: invokevirtual bigPicture : (Landroid/graphics/Bitmap;)Landroid/app/Notification$BigPictureStyle;
      //   112: astore_3
      //   113: aload_0
      //   114: getfield g : Z
      //   117: ifeq -> 197
      //   120: aload_0
      //   121: getfield f : Landroidx/core/graphics/drawable/IconCompat;
      //   124: astore #5
      //   126: aload #5
      //   128: ifnonnull -> 139
      //   131: aload_3
      //   132: aconst_null
      //   133: invokestatic a : (Landroid/app/Notification$BigPictureStyle;Landroid/graphics/Bitmap;)V
      //   136: goto -> 197
      //   139: iload_2
      //   140: bipush #23
      //   142: if_icmplt -> 177
      //   145: aload_1
      //   146: instanceof androidx/core/app/o0
      //   149: ifeq -> 161
      //   152: aload_1
      //   153: checkcast androidx/core/app/o0
      //   156: invokevirtual f : ()Landroid/content/Context;
      //   159: astore #4
      //   161: aload_3
      //   162: aload_0
      //   163: getfield f : Landroidx/core/graphics/drawable/IconCompat;
      //   166: aload #4
      //   168: invokevirtual r : (Landroid/content/Context;)Landroid/graphics/drawable/Icon;
      //   171: invokestatic a : (Landroid/app/Notification$BigPictureStyle;Landroid/graphics/drawable/Icon;)V
      //   174: goto -> 197
      //   177: aload #5
      //   179: invokevirtual l : ()I
      //   182: iconst_1
      //   183: if_icmpne -> 131
      //   186: aload_3
      //   187: aload_0
      //   188: getfield f : Landroidx/core/graphics/drawable/IconCompat;
      //   191: invokevirtual i : ()Landroid/graphics/Bitmap;
      //   194: invokestatic a : (Landroid/app/Notification$BigPictureStyle;Landroid/graphics/Bitmap;)V
      //   197: aload_0
      //   198: getfield d : Z
      //   201: ifeq -> 212
      //   204: aload_3
      //   205: aload_0
      //   206: getfield c : Ljava/lang/CharSequence;
      //   209: invokestatic b : (Landroid/app/Notification$BigPictureStyle;Ljava/lang/CharSequence;)V
      //   212: iload_2
      //   213: bipush #31
      //   215: if_icmplt -> 234
      //   218: aload_3
      //   219: aload_0
      //   220: getfield i : Z
      //   223: invokestatic c : (Landroid/app/Notification$BigPictureStyle;Z)V
      //   226: aload_3
      //   227: aload_0
      //   228: getfield h : Ljava/lang/CharSequence;
      //   231: invokestatic b : (Landroid/app/Notification$BigPictureStyle;Ljava/lang/CharSequence;)V
      //   234: return
    }
    
    protected String c() {
      return "androidx.core.app.NotificationCompat$BigPictureStyle";
    }
    
    public b h(Bitmap param1Bitmap) {
      IconCompat iconCompat;
      if (param1Bitmap == null) {
        param1Bitmap = null;
      } else {
        iconCompat = IconCompat.e(param1Bitmap);
      } 
      this.f = iconCompat;
      this.g = true;
      return this;
    }
    
    public b i(Bitmap param1Bitmap) {
      IconCompat iconCompat;
      if (param1Bitmap == null) {
        param1Bitmap = null;
      } else {
        iconCompat = IconCompat.e(param1Bitmap);
      } 
      this.e = iconCompat;
      return this;
    }
    
    private static class a {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Bitmap param2Bitmap) {
        param2BigPictureStyle.bigLargeIcon(param2Bitmap);
      }
      
      static void b(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        param2BigPictureStyle.setSummaryText(param2CharSequence);
      }
    }
    
    private static class b {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Icon param2Icon) {
        r.a(param2BigPictureStyle, param2Icon);
      }
    }
    
    private static class c {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Icon param2Icon) {
        t.a(param2BigPictureStyle, param2Icon);
      }
      
      static void b(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        u.a(param2BigPictureStyle, param2CharSequence);
      }
      
      static void c(Notification.BigPictureStyle param2BigPictureStyle, boolean param2Boolean) {
        s.a(param2BigPictureStyle, param2Boolean);
      }
    }
  }
  
  private static class a {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Bitmap param1Bitmap) {
      param1BigPictureStyle.bigLargeIcon(param1Bitmap);
    }
    
    static void b(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      param1BigPictureStyle.setSummaryText(param1CharSequence);
    }
  }
  
  private static class b {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      r.a(param1BigPictureStyle, param1Icon);
    }
  }
  
  private static class c {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      t.a(param1BigPictureStyle, param1Icon);
    }
    
    static void b(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      u.a(param1BigPictureStyle, param1CharSequence);
    }
    
    static void c(Notification.BigPictureStyle param1BigPictureStyle, boolean param1Boolean) {
      s.a(param1BigPictureStyle, param1Boolean);
    }
  }
  
  public static class c extends f {
    private CharSequence e;
    
    public void a(Bundle param1Bundle) {
      super.a(param1Bundle);
    }
    
    public void b(p param1p) {
      Notification.BigTextStyle bigTextStyle = (new Notification.BigTextStyle(param1p.a())).setBigContentTitle(this.b).bigText(this.e);
      if (this.d)
        bigTextStyle.setSummaryText(this.c); 
    }
    
    protected String c() {
      return "androidx.core.app.NotificationCompat$BigTextStyle";
    }
    
    public c h(CharSequence param1CharSequence) {
      this.e = q.e.d(param1CharSequence);
      return this;
    }
  }
  
  public static final class d {
    public static Notification.BubbleMetadata a(d param1d) {
      return null;
    }
  }
  
  public static class e {
    boolean A;
    
    boolean B;
    
    String C;
    
    Bundle D;
    
    int E = 0;
    
    int F = 0;
    
    Notification G;
    
    RemoteViews H;
    
    RemoteViews I;
    
    RemoteViews J;
    
    String K;
    
    int L = 0;
    
    String M;
    
    long N;
    
    int O = 0;
    
    int P = 0;
    
    boolean Q;
    
    Notification R;
    
    boolean S;
    
    Icon T;
    
    @Deprecated
    public ArrayList<String> U;
    
    public Context a;
    
    public ArrayList<q.a> b = new ArrayList<q.a>();
    
    public ArrayList<f1> c = new ArrayList<f1>();
    
    ArrayList<q.a> d = new ArrayList<q.a>();
    
    CharSequence e;
    
    CharSequence f;
    
    PendingIntent g;
    
    PendingIntent h;
    
    RemoteViews i;
    
    Bitmap j;
    
    CharSequence k;
    
    int l;
    
    int m;
    
    boolean n = true;
    
    boolean o;
    
    q.f p;
    
    CharSequence q;
    
    CharSequence r;
    
    CharSequence[] s;
    
    int t;
    
    int u;
    
    boolean v;
    
    String w;
    
    boolean x;
    
    String y;
    
    boolean z = false;
    
    @Deprecated
    public e(Context param1Context) {
      this(param1Context, null);
    }
    
    public e(Context param1Context, String param1String) {
      Notification notification = new Notification();
      this.R = notification;
      this.a = param1Context;
      this.K = param1String;
      notification.when = System.currentTimeMillis();
      this.R.audioStreamType = -1;
      this.m = 0;
      this.U = new ArrayList<String>();
      this.Q = true;
    }
    
    protected static CharSequence d(CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence.length() > 5120)
        charSequence = param1CharSequence.subSequence(0, 5120); 
      return charSequence;
    }
    
    private Bitmap e(Bitmap param1Bitmap) {
      Bitmap bitmap = param1Bitmap;
      if (param1Bitmap != null) {
        if (Build.VERSION.SDK_INT >= 27)
          return param1Bitmap; 
        Resources resources = this.a.getResources();
        int i = resources.getDimensionPixelSize(s.b.b);
        int j = resources.getDimensionPixelSize(s.b.a);
        if (param1Bitmap.getWidth() <= i && param1Bitmap.getHeight() <= j)
          return param1Bitmap; 
        double d = Math.min(i / Math.max(1, param1Bitmap.getWidth()), j / Math.max(1, param1Bitmap.getHeight()));
        bitmap = Bitmap.createScaledBitmap(param1Bitmap, (int)Math.ceil(param1Bitmap.getWidth() * d), (int)Math.ceil(param1Bitmap.getHeight() * d), true);
      } 
      return bitmap;
    }
    
    private void n(int param1Int, boolean param1Boolean) {
      Notification notification;
      if (param1Boolean) {
        notification = this.R;
        param1Int |= notification.flags;
      } else {
        notification = this.R;
        param1Int &= notification.flags;
      } 
      notification.flags = param1Int;
    }
    
    public e A(long param1Long) {
      this.R.when = param1Long;
      return this;
    }
    
    public e a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.b.add(new q.a(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    public Notification b() {
      return (new o0(this)).c();
    }
    
    public Bundle c() {
      if (this.D == null)
        this.D = new Bundle(); 
      return this.D;
    }
    
    public e f(boolean param1Boolean) {
      n(16, param1Boolean);
      return this;
    }
    
    public e g(String param1String) {
      this.K = param1String;
      return this;
    }
    
    public e h(int param1Int) {
      this.E = param1Int;
      return this;
    }
    
    public e i(PendingIntent param1PendingIntent) {
      this.g = param1PendingIntent;
      return this;
    }
    
    public e j(CharSequence param1CharSequence) {
      this.f = d(param1CharSequence);
      return this;
    }
    
    public e k(CharSequence param1CharSequence) {
      this.e = d(param1CharSequence);
      return this;
    }
    
    public e l(int param1Int) {
      Notification notification = this.R;
      notification.defaults = param1Int;
      if ((param1Int & 0x4) != 0)
        notification.flags |= 0x1; 
      return this;
    }
    
    public e m(PendingIntent param1PendingIntent) {
      this.R.deleteIntent = param1PendingIntent;
      return this;
    }
    
    public e o(Bitmap param1Bitmap) {
      this.j = e(param1Bitmap);
      return this;
    }
    
    public e p(int param1Int1, int param1Int2, int param1Int3) {
      Notification notification = this.R;
      notification.ledARGB = param1Int1;
      notification.ledOnMS = param1Int2;
      notification.ledOffMS = param1Int3;
      if (param1Int2 != 0 && param1Int3 != 0) {
        param1Int1 = 1;
      } else {
        param1Int1 = 0;
      } 
      notification.flags = param1Int1 | notification.flags & 0xFFFFFFFE;
      return this;
    }
    
    public e q(boolean param1Boolean) {
      this.z = param1Boolean;
      return this;
    }
    
    public e r(int param1Int) {
      this.l = param1Int;
      return this;
    }
    
    public e s(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    public e t(boolean param1Boolean) {
      this.n = param1Boolean;
      return this;
    }
    
    public e u(int param1Int) {
      this.R.icon = param1Int;
      return this;
    }
    
    public e v(Uri param1Uri) {
      Notification notification = this.R;
      notification.sound = param1Uri;
      notification.audioStreamType = -1;
      notification.audioAttributes = (new AudioAttributes.Builder()).setContentType(4).setUsage(5).build();
      return this;
    }
    
    public e w(q.f param1f) {
      if (this.p != param1f) {
        this.p = param1f;
        if (param1f != null)
          param1f.g(this); 
      } 
      return this;
    }
    
    public e x(CharSequence param1CharSequence) {
      this.R.tickerText = d(param1CharSequence);
      return this;
    }
    
    public e y(long[] param1ArrayOflong) {
      this.R.vibrate = param1ArrayOflong;
      return this;
    }
    
    public e z(int param1Int) {
      this.F = param1Int;
      return this;
    }
  }
  
  public static abstract class f {
    protected q.e a;
    
    CharSequence b;
    
    CharSequence c;
    
    boolean d = false;
    
    public void a(Bundle param1Bundle) {
      if (this.d)
        param1Bundle.putCharSequence("android.summaryText", this.c); 
      CharSequence charSequence = this.b;
      if (charSequence != null)
        param1Bundle.putCharSequence("android.title.big", charSequence); 
      charSequence = c();
      if (charSequence != null)
        param1Bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", (String)charSequence); 
    }
    
    public abstract void b(p param1p);
    
    protected abstract String c();
    
    public RemoteViews d(p param1p) {
      return null;
    }
    
    public RemoteViews e(p param1p) {
      return null;
    }
    
    public RemoteViews f(p param1p) {
      return null;
    }
    
    public void g(q.e param1e) {
      if (this.a != param1e) {
        this.a = param1e;
        if (param1e != null)
          param1e.w(this); 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\app\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */