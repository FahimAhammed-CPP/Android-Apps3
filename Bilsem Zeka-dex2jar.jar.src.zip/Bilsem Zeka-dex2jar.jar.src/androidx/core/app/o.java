package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

public final class o {
  public static Intent a(Activity paramActivity) {
    Intent intent = a.a(paramActivity);
    if (intent != null)
      return intent; 
    String str = c(paramActivity);
    if (str == null)
      return null; 
    ComponentName componentName = new ComponentName((Context)paramActivity, str);
    try {
      return (d((Context)paramActivity, componentName) == null) ? Intent.makeMainActivity(componentName) : (new Intent()).setComponent(componentName);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getParentActivityIntent: bad parentActivityName '");
      stringBuilder.append(str);
      stringBuilder.append("' in manifest");
      Log.e("NavUtils", stringBuilder.toString());
      return null;
    } 
  }
  
  public static Intent b(Context paramContext, ComponentName paramComponentName) {
    String str = d(paramContext, paramComponentName);
    if (str == null)
      return null; 
    paramComponentName = new ComponentName(paramComponentName.getPackageName(), str);
    return (d(paramContext, paramComponentName) == null) ? Intent.makeMainActivity(paramComponentName) : (new Intent()).setComponent(paramComponentName);
  }
  
  public static String c(Activity paramActivity) {
    try {
      return d((Context)paramActivity, paramActivity.getComponentName());
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new IllegalArgumentException(nameNotFoundException);
    } 
  }
  
  public static String d(Context paramContext, ComponentName paramComponentName) {
    PackageManager packageManager = paramContext.getPackageManager();
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      i = 269222528;
    } else if (i >= 24) {
      i = 787072;
    } else {
      i = 640;
    } 
    ActivityInfo activityInfo = packageManager.getActivityInfo(paramComponentName, i);
    String str2 = activityInfo.parentActivityName;
    if (str2 != null)
      return str2; 
    Bundle bundle = activityInfo.metaData;
    if (bundle == null)
      return null; 
    str2 = bundle.getString("android.support.PARENT_ACTIVITY");
    if (str2 == null)
      return null; 
    String str1 = str2;
    if (str2.charAt(0) == '.') {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
    } 
    return str1;
  }
  
  public static void e(Activity paramActivity, Intent paramIntent) {
    a.b(paramActivity, paramIntent);
  }
  
  public static boolean f(Activity paramActivity, Intent paramIntent) {
    return a.c(paramActivity, paramIntent);
  }
  
  static class a {
    static Intent a(Activity param1Activity) {
      return param1Activity.getParentActivityIntent();
    }
    
    static boolean b(Activity param1Activity, Intent param1Intent) {
      return param1Activity.navigateUpTo(param1Intent);
    }
    
    static boolean c(Activity param1Activity, Intent param1Intent) {
      return param1Activity.shouldUpRecreateTask(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */