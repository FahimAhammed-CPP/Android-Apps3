package androidx.core.app;

import android.app.Notification;
import android.app.Person;



/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\core\app\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */