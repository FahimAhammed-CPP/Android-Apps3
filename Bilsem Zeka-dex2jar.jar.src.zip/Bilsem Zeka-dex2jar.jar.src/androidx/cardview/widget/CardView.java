package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import q.b;
import q.c;
import q.d;

public class CardView extends FrameLayout {
  private static final int[] h = new int[] { 16842801 };
  
  private static final c i;
  
  private boolean a;
  
  private boolean b;
  
  int c;
  
  int d;
  
  final Rect e;
  
  final Rect f;
  
  private final b g;
  
  static {
    a a = new a();
    i = a;
    a.i();
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, q.a.a);
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    ColorStateList colorStateList;
    Rect rect = new Rect();
    this.e = rect;
    this.f = new Rect();
    a a = new a(this);
    this.g = a;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, d.a, paramInt, c.a);
    paramInt = d.d;
    if (typedArray.hasValue(paramInt)) {
      colorStateList = typedArray.getColorStateList(paramInt);
    } else {
      Resources resources;
      TypedArray typedArray1 = getContext().obtainStyledAttributes(h);
      paramInt = typedArray1.getColor(0, 0);
      typedArray1.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(paramInt, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F) {
        resources = getResources();
        paramInt = b.b;
      } else {
        resources = getResources();
        paramInt = b.a;
      } 
      colorStateList = ColorStateList.valueOf(resources.getColor(paramInt));
    } 
    float f3 = typedArray.getDimension(d.e, 0.0F);
    float f2 = typedArray.getDimension(d.f, 0.0F);
    float f1 = typedArray.getDimension(d.g, 0.0F);
    this.a = typedArray.getBoolean(d.i, false);
    this.b = typedArray.getBoolean(d.h, true);
    paramInt = typedArray.getDimensionPixelSize(d.j, 0);
    rect.left = typedArray.getDimensionPixelSize(d.l, paramInt);
    rect.top = typedArray.getDimensionPixelSize(d.n, paramInt);
    rect.right = typedArray.getDimensionPixelSize(d.m, paramInt);
    rect.bottom = typedArray.getDimensionPixelSize(d.k, paramInt);
    if (f2 > f1)
      f1 = f2; 
    this.c = typedArray.getDimensionPixelSize(d.b, 0);
    this.d = typedArray.getDimensionPixelSize(d.c, 0);
    typedArray.recycle();
    i.a(a, paramContext, colorStateList, f3, f2, f1);
  }
  
  public ColorStateList getCardBackgroundColor() {
    return i.h(this.g);
  }
  
  public float getCardElevation() {
    return i.c(this.g);
  }
  
  public int getContentPaddingBottom() {
    return this.e.bottom;
  }
  
  public int getContentPaddingLeft() {
    return this.e.left;
  }
  
  public int getContentPaddingRight() {
    return this.e.right;
  }
  
  public int getContentPaddingTop() {
    return this.e.top;
  }
  
  public float getMaxCardElevation() {
    return i.g(this.g);
  }
  
  public boolean getPreventCornerOverlap() {
    return this.b;
  }
  
  public float getRadius() {
    return i.d(this.g);
  }
  
  public boolean getUseCompatPadding() {
    return this.a;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    c c1 = i;
    int j = paramInt1;
    int i = paramInt2;
    if (!(c1 instanceof a)) {
      i = View.MeasureSpec.getMode(paramInt1);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(c1.k(this.g)), View.MeasureSpec.getSize(paramInt1)), i); 
      i = View.MeasureSpec.getMode(paramInt2);
      if (i != Integer.MIN_VALUE && i != 1073741824) {
        j = paramInt1;
        i = paramInt2;
      } else {
        i = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(c1.j(this.g)), View.MeasureSpec.getSize(paramInt2)), i);
        j = paramInt1;
      } 
    } 
    super.onMeasure(j, i);
  }
  
  public void setCardBackgroundColor(int paramInt) {
    i.m(this.g, ColorStateList.valueOf(paramInt));
  }
  
  public void setCardBackgroundColor(ColorStateList paramColorStateList) {
    i.m(this.g, paramColorStateList);
  }
  
  public void setCardElevation(float paramFloat) {
    i.f(this.g, paramFloat);
  }
  
  public void setMaxCardElevation(float paramFloat) {
    i.n(this.g, paramFloat);
  }
  
  public void setMinimumHeight(int paramInt) {
    this.d = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setMinimumWidth(int paramInt) {
    this.c = paramInt;
    super.setMinimumWidth(paramInt);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPreventCornerOverlap(boolean paramBoolean) {
    if (paramBoolean != this.b) {
      this.b = paramBoolean;
      i.l(this.g);
    } 
  }
  
  public void setRadius(float paramFloat) {
    i.b(this.g, paramFloat);
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.a != paramBoolean) {
      this.a = paramBoolean;
      i.e(this.g);
    } 
  }
  
  class a implements b {
    private Drawable a;
    
    a(CardView this$0) {}
    
    public void a(Drawable param1Drawable) {
      this.a = param1Drawable;
      this.b.setBackgroundDrawable(param1Drawable);
    }
    
    public boolean b() {
      return this.b.getPreventCornerOverlap();
    }
    
    public boolean c() {
      return this.b.getUseCompatPadding();
    }
    
    public Drawable d() {
      return this.a;
    }
    
    public View e() {
      return (View)this.b;
    }
    
    public void f(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.b.f.set(param1Int1, param1Int2, param1Int3, param1Int4);
      CardView cardView = this.b;
      Rect rect = cardView.e;
      CardView.a(cardView, param1Int1 + rect.left, param1Int2 + rect.top, param1Int3 + rect.right, param1Int4 + rect.bottom);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\cardview\widget\CardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */