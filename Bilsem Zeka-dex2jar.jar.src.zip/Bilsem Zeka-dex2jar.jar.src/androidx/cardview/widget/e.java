package androidx.cardview.widget;

import android.graphics.drawable.Drawable;

class e extends Drawable {
  private static final double a = Math.cos(Math.toRadians(45.0D));
  
  static float a(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    float f = paramFloat1;
    if (paramBoolean)
      f = (float)(paramFloat1 + (1.0D - a) * paramFloat2); 
    return f;
  }
  
  static float b(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    float f = paramFloat1 * 1.5F;
    paramFloat1 = f;
    if (paramBoolean)
      paramFloat1 = (float)(f + (1.0D - a) * paramFloat2); 
    return paramFloat1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\cardview\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */