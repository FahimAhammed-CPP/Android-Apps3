package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;

interface c {
  void a(b paramb, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3);
  
  void b(b paramb, float paramFloat);
  
  float c(b paramb);
  
  float d(b paramb);
  
  void e(b paramb);
  
  void f(b paramb, float paramFloat);
  
  float g(b paramb);
  
  ColorStateList h(b paramb);
  
  void i();
  
  float j(b paramb);
  
  float k(b paramb);
  
  void l(b paramb);
  
  void m(b paramb, ColorStateList paramColorStateList);
  
  void n(b paramb, float paramFloat);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\cardview\widget\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */