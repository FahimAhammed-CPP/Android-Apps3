package androidx.cardview.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

interface b {
  void a(Drawable paramDrawable);
  
  boolean b();
  
  boolean c();
  
  Drawable d();
  
  View e();
  
  void f(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\cardview\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */