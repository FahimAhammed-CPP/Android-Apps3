package androidx.activity.result;

import android.annotation.SuppressLint;

public interface b<O> {
  void a(@SuppressLint({"UnknownNullness"}) O paramO);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\activity\result\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */