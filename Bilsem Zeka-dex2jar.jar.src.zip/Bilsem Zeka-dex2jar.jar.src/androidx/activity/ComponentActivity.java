package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.d;
import androidx.activity.result.e;
import androidx.core.app.f;
import androidx.core.app.n;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import androidx.lifecycle.j;
import androidx.lifecycle.s;
import androidx.lifecycle.v;
import androidx.lifecycle.w;
import androidx.lifecycle.x;
import androidx.lifecycle.y;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.c;
import androidx.savedstate.d;
import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

public class ComponentActivity extends n implements w, c, c, d {
  final c.a c = new c.a();
  
  private final j d = new j(this);
  
  final androidx.savedstate.b e = androidx.savedstate.b.a(this);
  
  private v f;
  
  private final OnBackPressedDispatcher g = new OnBackPressedDispatcher(new a(this));
  
  private int h;
  
  private final AtomicInteger i = new AtomicInteger();
  
  private final ActivityResultRegistry j = new b(this);
  
  public ComponentActivity() {
    if (a() != null) {
      int i = Build.VERSION.SDK_INT;
      a().a((h)new g(this) {
            public void a(i param1i, e.b param1b) {
              if (param1b == e.b.ON_STOP) {
                Window window = this.a.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  window.cancelPendingInputEvents(); 
              } 
            }
          });
      a().a((h)new g(this) {
            public void a(i param1i, e.b param1b) {
              if (param1b == e.b.ON_DESTROY) {
                this.a.c.b();
                if (!this.a.isChangingConfigurations())
                  this.a.f().a(); 
              } 
            }
          });
      a().a((h)new g(this) {
            public void a(i param1i, e.b param1b) {
              this.a.m();
              this.a.a().c((h)this);
            }
          });
      if (i <= 23)
        a().a((h)new ImmLeaksCleaner((Activity)this)); 
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  private void n() {
    x.a(getWindow().getDecorView(), this);
    y.a(getWindow().getDecorView(), this);
    d.a(getWindow().getDecorView(), this);
  }
  
  public e a() {
    return (e)this.d;
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    n();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public final ActivityResultRegistry c() {
    return this.j;
  }
  
  public v f() {
    if (getApplication() != null) {
      m();
      return this.f;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public final OnBackPressedDispatcher g() {
    return this.g;
  }
  
  public final void l(c.b paramb) {
    this.c.a(paramb);
  }
  
  void m() {
    if (this.f == null) {
      c c1 = (c)getLastNonConfigurationInstance();
      if (c1 != null)
        this.f = c1.b; 
      if (this.f == null)
        this.f = new v(); 
    } 
  }
  
  @Deprecated
  public Object o() {
    return null;
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.j.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.g.c();
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.e.c(paramBundle);
    this.c.c((Context)this);
    super.onCreate(paramBundle);
    this.j.g(paramBundle);
    s.g((Activity)this);
    int i = this.h;
    if (i != 0)
      setContentView(i); 
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.j.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = o();
    v v2 = this.f;
    v v1 = v2;
    if (v2 == null) {
      c c2 = (c)getLastNonConfigurationInstance();
      v1 = v2;
      if (c2 != null)
        v1 = c2.b; 
    } 
    if (v1 == null && object == null)
      return null; 
    c c1 = new c();
    c1.a = object;
    c1.b = v1;
    return c1;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    e e = a();
    if (e instanceof j)
      ((j)e).o(e.c.c); 
    super.onSaveInstanceState(paramBundle);
    this.e.d(paramBundle);
    this.j.h(paramBundle);
  }
  
  public void reportFullyDrawn() {
    try {
      if (l0.b.h()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("reportFullyDrawn() for ");
        stringBuilder.append(getComponentName());
        l0.b.c(stringBuilder.toString());
      } 
      super.reportFullyDrawn();
      return;
    } finally {
      l0.b.f();
    } 
  }
  
  public final SavedStateRegistry s() {
    return this.e.b();
  }
  
  public void setContentView(int paramInt) {
    n();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    n();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    n();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        ComponentActivity.k(this.a);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends ActivityResultRegistry {
    b(ComponentActivity this$0) {}
    
    public <I, O> void f(int param1Int, d.a<I, O> param1a, I param1I, f param1f) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      e e;
      ComponentActivity componentActivity = this.i;
      d.a.a a1 = param1a.b((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.a((Context)componentActivity, param1I);
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } else {
        param1a = null;
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        androidx.core.app.b.p((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        e = (e)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          androidx.core.app.b.r((Activity)componentActivity, e.d(), param1Int, e.a(), e.b(), e.c(), 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      androidx.core.app.b.q((Activity)componentActivity, (Intent)e, param1Int, (Bundle)sendIntentException);
    }
    
    class a implements Runnable {
      a(ComponentActivity.b this$0, int param2Int, d.a.a param2a) {}
      
      public void run() {
        this.c.c(this.a, this.b.a());
      }
    }
    
    class b implements Runnable {
      b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.c.b(this.a, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.b));
      }
    }
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0, int param1Int, d.a.a param1a) {}
    
    public void run() {
      this.c.c(this.a, this.b.a());
    }
  }
  
  class b implements Runnable {
    b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.c.b(this.a, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.b));
    }
  }
  
  static final class c {
    Object a;
    
    v b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */