package androidx.activity;

import android.annotation.SuppressLint;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import androidx.lifecycle.i;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  final ArrayDeque<b> b = new ArrayDeque<b>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  @SuppressLint({"LambdaLast"})
  public void a(i parami, b paramb) {
    e e = parami.a();
    if (e.b() == e.c.a)
      return; 
    paramb.a(new LifecycleOnBackPressedCancellable(this, e, paramb));
  }
  
  a b(b paramb) {
    this.b.add(paramb);
    a a = new a(this, paramb);
    paramb.a(a);
    return a;
  }
  
  public void c() {
    Iterator<b> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      b b = iterator.next();
      if (b.c()) {
        b.b();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  private class LifecycleOnBackPressedCancellable implements g, a {
    private final e a;
    
    private final b b;
    
    private a c;
    
    LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, e param1e, b param1b) {
      this.a = param1e;
      this.b = param1b;
      param1e.a((h)this);
    }
    
    public void a(i param1i, e.b param1b) {
      if (param1b == e.b.ON_START) {
        this.c = this.d.b(this.b);
        return;
      } 
      if (param1b == e.b.ON_STOP) {
        a a1 = this.c;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1b == e.b.ON_DESTROY) {
        cancel();
      } 
    }
    
    public void cancel() {
      this.a.c((h)this);
      this.b.e(this);
      a a1 = this.c;
      if (a1 != null) {
        a1.cancel();
        this.c = null;
      } 
    }
  }
  
  private class a implements a {
    private final b a;
    
    a(OnBackPressedDispatcher this$0, b param1b) {
      this.a = param1b;
    }
    
    public void cancel() {
      this.b.b.remove(this.a);
      this.a.e(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */