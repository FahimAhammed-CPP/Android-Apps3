package androidx.activity;

import androidx.lifecycle.i;

public interface c extends i {
  OnBackPressedDispatcher g();
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\androidx\activity\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */