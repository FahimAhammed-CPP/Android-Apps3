package android.support.v4.media;

import android.media.MediaDescription;
import android.net.Uri;

class d {
  public static Uri a(Object paramObject) {
    return b.a((MediaDescription)paramObject);
  }
  
  static class a {
    public static void a(Object param1Object, Uri param1Uri) {
      c.a((MediaDescription.Builder)param1Object, param1Uri);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\android\support\v4\media\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */