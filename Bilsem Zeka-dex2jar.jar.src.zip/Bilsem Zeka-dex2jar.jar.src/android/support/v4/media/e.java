package android.support.v4.media;

import android.media.MediaMetadata;
import android.os.Parcel;

class e {
  public static void a(Object paramObject, Parcel paramParcel, int paramInt) {
    ((MediaMetadata)paramObject).writeToParcel(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\android\support\v4\media\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */