package a8;

import a0.f;
import ab.h;
import ab.l0;
import d0.f;
import ga.p;
import ga.u;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.k;
import kotlin.jvm.internal.l;
import qa.p;

public final class g {
  private static final b c = new b(null);
  
  @Deprecated
  private static final d0.d.a<Boolean> d = f.a("firebase_sessions_enabled");
  
  @Deprecated
  private static final d0.d.a<Double> e = f.b("firebase_sessions_sampling_rate");
  
  @Deprecated
  private static final d0.d.a<Integer> f = f.d("firebase_sessions_restart_timeout");
  
  @Deprecated
  private static final d0.d.a<Integer> g = f.d("firebase_sessions_cache_duration");
  
  @Deprecated
  private static final d0.d.a<Long> h = f.e("firebase_sessions_cache_updated_time");
  
  private final f<d0.d> a;
  
  private e b;
  
  public g(f<d0.d> paramf) {
    this.a = paramf;
    h.d(null, new a(this, null), 1, null);
  }
  
  private final <T> Object h(d0.d.a<T> parama, T paramT, ja.d<? super u> paramd) {
    // Byte code:
    //   0: aload_3
    //   1: instanceof a8/g$c
    //   4: ifeq -> 44
    //   7: aload_3
    //   8: checkcast a8/g$c
    //   11: astore #5
    //   13: aload #5
    //   15: getfield c : I
    //   18: istore #4
    //   20: iload #4
    //   22: ldc -2147483648
    //   24: iand
    //   25: ifeq -> 44
    //   28: aload #5
    //   30: iload #4
    //   32: ldc -2147483648
    //   34: iadd
    //   35: putfield c : I
    //   38: aload #5
    //   40: astore_3
    //   41: goto -> 54
    //   44: new a8/g$c
    //   47: dup
    //   48: aload_0
    //   49: aload_3
    //   50: invokespecial <init> : (La8/g;Lja/d;)V
    //   53: astore_3
    //   54: aload_3
    //   55: getfield a : Ljava/lang/Object;
    //   58: astore #6
    //   60: invokestatic c : ()Ljava/lang/Object;
    //   63: astore #5
    //   65: aload_3
    //   66: getfield c : I
    //   69: istore #4
    //   71: iload #4
    //   73: ifeq -> 104
    //   76: iload #4
    //   78: iconst_1
    //   79: if_icmpne -> 94
    //   82: aload #6
    //   84: invokestatic b : (Ljava/lang/Object;)V
    //   87: goto -> 180
    //   90: astore_1
    //   91: goto -> 149
    //   94: new java/lang/IllegalStateException
    //   97: dup
    //   98: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   100: invokespecial <init> : (Ljava/lang/String;)V
    //   103: athrow
    //   104: aload #6
    //   106: invokestatic b : (Ljava/lang/Object;)V
    //   109: aload_0
    //   110: getfield a : La0/f;
    //   113: astore #6
    //   115: new a8/g$d
    //   118: dup
    //   119: aload_2
    //   120: aload_1
    //   121: aload_0
    //   122: aconst_null
    //   123: invokespecial <init> : (Ljava/lang/Object;Ld0/d$a;La8/g;Lja/d;)V
    //   126: astore_1
    //   127: aload_3
    //   128: iconst_1
    //   129: putfield c : I
    //   132: aload #6
    //   134: aload_1
    //   135: aload_3
    //   136: invokestatic a : (La0/f;Lqa/p;Lja/d;)Ljava/lang/Object;
    //   139: astore_1
    //   140: aload_1
    //   141: aload #5
    //   143: if_acmpne -> 180
    //   146: aload #5
    //   148: areturn
    //   149: new java/lang/StringBuilder
    //   152: dup
    //   153: invokespecial <init> : ()V
    //   156: astore_2
    //   157: aload_2
    //   158: ldc 'Failed to update cache config value: '
    //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: pop
    //   164: aload_2
    //   165: aload_1
    //   166: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   169: pop
    //   170: ldc 'SettingsCache'
    //   172: aload_2
    //   173: invokevirtual toString : ()Ljava/lang/String;
    //   176: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   179: pop
    //   180: getstatic ga/u.a : Lga/u;
    //   183: areturn
    // Exception table:
    //   from	to	target	type
    //   82	87	90	java/io/IOException
    //   109	140	90	java/io/IOException
  }
  
  private final void l(d0.d paramd) {
    this.b = new e((Boolean)paramd.b(d), (Double)paramd.b(e), (Integer)paramd.b(f), (Integer)paramd.b(g), (Long)paramd.b(h));
  }
  
  public final boolean d() {
    e e3 = this.b;
    e e2 = null;
    e e1 = e3;
    if (e3 == null) {
      l.t("sessionConfigs");
      e1 = null;
    } 
    Long long_ = e1.b();
    e1 = this.b;
    if (e1 == null) {
      l.t("sessionConfigs");
      e1 = e2;
    } 
    Integer integer = e1.a();
    return !(long_ != null && integer != null && (System.currentTimeMillis() - long_.longValue()) / 1000L < integer.intValue());
  }
  
  public final Integer e() {
    e e2 = this.b;
    e e1 = e2;
    if (e2 == null) {
      l.t("sessionConfigs");
      e1 = null;
    } 
    return e1.d();
  }
  
  public final Double f() {
    e e2 = this.b;
    e e1 = e2;
    if (e2 == null) {
      l.t("sessionConfigs");
      e1 = null;
    } 
    return e1.e();
  }
  
  public final Boolean g() {
    e e2 = this.b;
    e e1 = e2;
    if (e2 == null) {
      l.t("sessionConfigs");
      e1 = null;
    } 
    return e1.c();
  }
  
  public final Object i(Double paramDouble, ja.d<? super u> paramd) {
    Object object = h(e, paramDouble, paramd);
    return (object == ka.b.c()) ? object : u.a;
  }
  
  public final Object j(Integer paramInteger, ja.d<? super u> paramd) {
    Object object = h(g, paramInteger, paramd);
    return (object == ka.b.c()) ? object : u.a;
  }
  
  public final Object k(Long paramLong, ja.d<? super u> paramd) {
    Object object = h(h, paramLong, paramd);
    return (object == ka.b.c()) ? object : u.a;
  }
  
  public final Object m(Integer paramInteger, ja.d<? super u> paramd) {
    Object object = h(f, paramInteger, paramd);
    return (object == ka.b.c()) ? object : u.a;
  }
  
  public final Object n(Boolean paramBoolean, ja.d<? super u> paramd) {
    Object object = h(d, paramBoolean, paramd);
    return (object == ka.b.c()) ? object : u.a;
  }
  
  @f(c = "com.google.firebase.sessions.settings.SettingsCache$1", f = "SettingsCache.kt", l = {46}, m = "invokeSuspend")
  static final class a extends k implements p<l0, ja.d<? super u>, Object> {
    Object a;
    
    int b;
    
    a(g param1g, ja.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      return (ja.d<u>)new a(this.c, (ja.d)param1d);
    }
    
    public final Object invoke(l0 param1l0, ja.d<? super u> param1d) {
      return ((a)create(param1l0, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object2;
      Object object1 = ka.b.c();
      int i = this.b;
      if (i != 0) {
        if (i == 1) {
          object1 = this.a;
          p.b(param1Object);
          object2 = param1Object;
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = this.c;
        kotlinx.coroutines.flow.b b = g.a((g)param1Object).b();
        this.a = param1Object;
        this.b = 1;
        object2 = kotlinx.coroutines.flow.d.d(b, (ja.d)this);
        if (object2 == object1)
          return object1; 
        object1 = param1Object;
      } 
      g.c((g)object1, ((d0.d)object2).d());
      return u.a;
    }
  }
  
  private static final class b {
    private b() {}
  }
  
  @f(c = "com.google.firebase.sessions.settings.SettingsCache", f = "SettingsCache.kt", l = {112}, m = "updateConfigValue")
  static final class c<T> extends kotlin.coroutines.jvm.internal.d {
    int c;
    
    c(g param1g, ja.d<? super c> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.a = param1Object;
      this.c |= Integer.MIN_VALUE;
      return g.b(this.b, null, null, (ja.d)this);
    }
  }
  
  @f(c = "com.google.firebase.sessions.settings.SettingsCache$updateConfigValue$2", f = "SettingsCache.kt", l = {}, m = "invokeSuspend")
  static final class d extends k implements p<d0.a, ja.d<? super u>, Object> {
    int a;
    
    d(T param1T, d0.d.a<T> param1a, g param1g, ja.d<? super d> param1d) {
      super(2, param1d);
    }
    
    public final Object a(d0.a param1a, ja.d<? super u> param1d) {
      return ((d)create(param1a, param1d)).invokeSuspend(u.a);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      d d1 = new d(this.c, this.d, this.e, (ja.d)param1d);
      d1.b = param1Object;
      return (ja.d<u>)d1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      ka.b.c();
      if (this.a == 0) {
        p.b(param1Object);
        param1Object = this.b;
        T t = this.c;
        if (t != null) {
          param1Object.i(this.d, t);
        } else {
          param1Object.h(this.d);
        } 
        g.c(this.e, (d0.d)param1Object);
        return u.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a8\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */