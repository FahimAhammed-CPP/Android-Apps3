package a8;

import kotlin.jvm.internal.l;

public final class e {
  private final Boolean a;
  
  private final Double b;
  
  private final Integer c;
  
  private final Integer d;
  
  private final Long e;
  
  public e(Boolean paramBoolean, Double paramDouble, Integer paramInteger1, Integer paramInteger2, Long paramLong) {
    this.a = paramBoolean;
    this.b = paramDouble;
    this.c = paramInteger1;
    this.d = paramInteger2;
    this.e = paramLong;
  }
  
  public final Integer a() {
    return this.d;
  }
  
  public final Long b() {
    return this.e;
  }
  
  public final Boolean c() {
    return this.a;
  }
  
  public final Integer d() {
    return this.c;
  }
  
  public final Double e() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof e))
      return false; 
    paramObject = paramObject;
    return !l.b(this.a, ((e)paramObject).a) ? false : (!l.b(this.b, ((e)paramObject).b) ? false : (!l.b(this.c, ((e)paramObject).c) ? false : (!l.b(this.d, ((e)paramObject).d) ? false : (!!l.b(this.e, ((e)paramObject).e)))));
  }
  
  public int hashCode() {
    int i;
    int j;
    int k;
    int m;
    Boolean bool = this.a;
    int n = 0;
    if (bool == null) {
      i = 0;
    } else {
      i = bool.hashCode();
    } 
    Double double_ = this.b;
    if (double_ == null) {
      j = 0;
    } else {
      j = double_.hashCode();
    } 
    Integer integer = this.c;
    if (integer == null) {
      k = 0;
    } else {
      k = integer.hashCode();
    } 
    integer = this.d;
    if (integer == null) {
      m = 0;
    } else {
      m = integer.hashCode();
    } 
    Long long_ = this.e;
    if (long_ != null)
      n = long_.hashCode(); 
    return (((i * 31 + j) * 31 + k) * 31 + m) * 31 + n;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SessionConfigs(sessionEnabled=");
    stringBuilder.append(this.a);
    stringBuilder.append(", sessionSamplingRate=");
    stringBuilder.append(this.b);
    stringBuilder.append(", sessionRestartTimeout=");
    stringBuilder.append(this.c);
    stringBuilder.append(", cacheDuration=");
    stringBuilder.append(this.d);
    stringBuilder.append(", cacheUpdatedTime=");
    stringBuilder.append(this.e);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a8\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */