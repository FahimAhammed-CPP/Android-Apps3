package a8;

import a0.f;
import android.util.Log;
import ga.p;
import ga.u;
import ja.g;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.k;
import kotlin.jvm.internal.g;
import org.json.JSONObject;
import p7.e;
import qa.p;
import ya.j;

public final class c implements h {
  private static final a g = new a(null);
  
  private final g a;
  
  private final e b;
  
  private final y7.b c;
  
  private final a d;
  
  private final g e;
  
  private final kotlinx.coroutines.sync.b f;
  
  public c(g paramg, e parame, y7.b paramb, a parama, f<d0.d> paramf) {
    this.a = paramg;
    this.b = parame;
    this.c = paramb;
    this.d = parama;
    this.e = new g(paramf);
    this.f = kotlinx.coroutines.sync.d.b(false, 1, null);
  }
  
  private final String f(String paramString) {
    return (new j("/")).c(paramString, "");
  }
  
  public Boolean a() {
    return this.e.g();
  }
  
  public Object b(ja.d<? super u> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof a8/c$b
    //   4: ifeq -> 38
    //   7: aload_1
    //   8: checkcast a8/c$b
    //   11: astore #4
    //   13: aload #4
    //   15: getfield e : I
    //   18: istore_2
    //   19: iload_2
    //   20: ldc -2147483648
    //   22: iand
    //   23: ifeq -> 38
    //   26: aload #4
    //   28: iload_2
    //   29: ldc -2147483648
    //   31: iadd
    //   32: putfield e : I
    //   35: goto -> 49
    //   38: new a8/c$b
    //   41: dup
    //   42: aload_0
    //   43: aload_1
    //   44: invokespecial <init> : (La8/c;Lja/d;)V
    //   47: astore #4
    //   49: aload #4
    //   51: getfield c : Ljava/lang/Object;
    //   54: astore #6
    //   56: invokestatic c : ()Ljava/lang/Object;
    //   59: astore #7
    //   61: aload #4
    //   63: getfield e : I
    //   66: istore_2
    //   67: iload_2
    //   68: ifeq -> 184
    //   71: iload_2
    //   72: iconst_1
    //   73: if_icmpeq -> 158
    //   76: iload_2
    //   77: iconst_2
    //   78: if_icmpeq -> 119
    //   81: iload_2
    //   82: iconst_3
    //   83: if_icmpne -> 109
    //   86: aload #4
    //   88: getfield a : Ljava/lang/Object;
    //   91: checkcast kotlinx/coroutines/sync/b
    //   94: astore_3
    //   95: aload_3
    //   96: astore_1
    //   97: aload #6
    //   99: invokestatic b : (Ljava/lang/Object;)V
    //   102: goto -> 646
    //   105: astore_3
    //   106: goto -> 665
    //   109: new java/lang/IllegalStateException
    //   112: dup
    //   113: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   115: invokespecial <init> : (Ljava/lang/String;)V
    //   118: athrow
    //   119: aload #4
    //   121: getfield b : Ljava/lang/Object;
    //   124: checkcast kotlinx/coroutines/sync/b
    //   127: astore_1
    //   128: aload #4
    //   130: getfield a : Ljava/lang/Object;
    //   133: checkcast a8/c
    //   136: astore #5
    //   138: aload_1
    //   139: astore_3
    //   140: aload #6
    //   142: invokestatic b : (Ljava/lang/Object;)V
    //   145: goto -> 338
    //   148: astore #4
    //   150: aload_3
    //   151: astore_1
    //   152: aload #4
    //   154: astore_3
    //   155: goto -> 665
    //   158: aload #4
    //   160: getfield b : Ljava/lang/Object;
    //   163: checkcast kotlinx/coroutines/sync/b
    //   166: astore_1
    //   167: aload #4
    //   169: getfield a : Ljava/lang/Object;
    //   172: checkcast a8/c
    //   175: astore_3
    //   176: aload #6
    //   178: invokestatic b : (Ljava/lang/Object;)V
    //   181: goto -> 257
    //   184: aload #6
    //   186: invokestatic b : (Ljava/lang/Object;)V
    //   189: aload_0
    //   190: getfield f : Lkotlinx/coroutines/sync/b;
    //   193: invokeinterface b : ()Z
    //   198: ifne -> 215
    //   201: aload_0
    //   202: getfield e : La8/g;
    //   205: invokevirtual d : ()Z
    //   208: ifne -> 215
    //   211: getstatic ga/u.a : Lga/u;
    //   214: areturn
    //   215: aload_0
    //   216: getfield f : Lkotlinx/coroutines/sync/b;
    //   219: astore_1
    //   220: aload #4
    //   222: aload_0
    //   223: putfield a : Ljava/lang/Object;
    //   226: aload #4
    //   228: aload_1
    //   229: putfield b : Ljava/lang/Object;
    //   232: aload #4
    //   234: iconst_1
    //   235: putfield e : I
    //   238: aload_1
    //   239: aconst_null
    //   240: aload #4
    //   242: invokeinterface a : (Ljava/lang/Object;Lja/d;)Ljava/lang/Object;
    //   247: aload #7
    //   249: if_acmpne -> 255
    //   252: aload #7
    //   254: areturn
    //   255: aload_0
    //   256: astore_3
    //   257: aload_3
    //   258: getfield e : La8/g;
    //   261: invokevirtual d : ()Z
    //   264: ifne -> 280
    //   267: getstatic ga/u.a : Lga/u;
    //   270: astore_3
    //   271: aload_1
    //   272: aconst_null
    //   273: invokeinterface c : (Ljava/lang/Object;)V
    //   278: aload_3
    //   279: areturn
    //   280: aload_3
    //   281: getfield b : Lp7/e;
    //   284: invokeinterface getId : ()Lr5/j;
    //   289: astore #5
    //   291: aload #5
    //   293: ldc 'firebaseInstallationsApi.id'
    //   295: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   298: aload #4
    //   300: aload_3
    //   301: putfield a : Ljava/lang/Object;
    //   304: aload #4
    //   306: aload_1
    //   307: putfield b : Ljava/lang/Object;
    //   310: aload #4
    //   312: iconst_2
    //   313: putfield e : I
    //   316: aload #5
    //   318: aload #4
    //   320: invokestatic a : (Lr5/j;Lja/d;)Ljava/lang/Object;
    //   323: astore #6
    //   325: aload #6
    //   327: aload #7
    //   329: if_acmpne -> 335
    //   332: aload #7
    //   334: areturn
    //   335: aload_3
    //   336: astore #5
    //   338: aload_1
    //   339: astore_3
    //   340: aload #6
    //   342: checkcast java/lang/String
    //   345: astore #6
    //   347: aload #6
    //   349: ifnonnull -> 379
    //   352: aload_1
    //   353: astore_3
    //   354: ldc 'SessionConfigFetcher'
    //   356: ldc 'Error getting Firebase Installation ID. Skipping this Session Event.'
    //   358: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   361: pop
    //   362: aload_1
    //   363: astore_3
    //   364: getstatic ga/u.a : Lga/u;
    //   367: astore #4
    //   369: aload_1
    //   370: aconst_null
    //   371: invokeinterface c : (Ljava/lang/Object;)V
    //   376: aload #4
    //   378: areturn
    //   379: aload_1
    //   380: astore_3
    //   381: ldc 'X-Crashlytics-Installation-ID'
    //   383: aload #6
    //   385: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Lga/n;
    //   388: astore #6
    //   390: aload_1
    //   391: astore_3
    //   392: getstatic kotlin/jvm/internal/y.a : Lkotlin/jvm/internal/y;
    //   395: astore #8
    //   397: aload_1
    //   398: astore_3
    //   399: ldc '%s/%s'
    //   401: iconst_2
    //   402: anewarray java/lang/Object
    //   405: dup
    //   406: iconst_0
    //   407: getstatic android/os/Build.MANUFACTURER : Ljava/lang/String;
    //   410: aastore
    //   411: dup
    //   412: iconst_1
    //   413: getstatic android/os/Build.MODEL : Ljava/lang/String;
    //   416: aastore
    //   417: iconst_2
    //   418: invokestatic copyOf : ([Ljava/lang/Object;I)[Ljava/lang/Object;
    //   421: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   424: astore #8
    //   426: aload_1
    //   427: astore_3
    //   428: aload #8
    //   430: ldc 'format(format, *args)'
    //   432: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   435: aload_1
    //   436: astore_3
    //   437: ldc 'X-Crashlytics-Device-Model'
    //   439: aload #5
    //   441: aload #8
    //   443: invokespecial f : (Ljava/lang/String;)Ljava/lang/String;
    //   446: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Lga/n;
    //   449: astore #8
    //   451: aload_1
    //   452: astore_3
    //   453: getstatic android/os/Build$VERSION.INCREMENTAL : Ljava/lang/String;
    //   456: astore #9
    //   458: aload_1
    //   459: astore_3
    //   460: aload #9
    //   462: ldc 'INCREMENTAL'
    //   464: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   467: aload_1
    //   468: astore_3
    //   469: ldc 'X-Crashlytics-OS-Build-Version'
    //   471: aload #5
    //   473: aload #9
    //   475: invokespecial f : (Ljava/lang/String;)Ljava/lang/String;
    //   478: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Lga/n;
    //   481: astore #9
    //   483: aload_1
    //   484: astore_3
    //   485: getstatic android/os/Build$VERSION.RELEASE : Ljava/lang/String;
    //   488: astore #10
    //   490: aload_1
    //   491: astore_3
    //   492: aload #10
    //   494: ldc 'RELEASE'
    //   496: invokestatic e : (Ljava/lang/Object;Ljava/lang/String;)V
    //   499: aload_1
    //   500: astore_3
    //   501: iconst_5
    //   502: anewarray ga/n
    //   505: dup
    //   506: iconst_0
    //   507: aload #6
    //   509: aastore
    //   510: dup
    //   511: iconst_1
    //   512: aload #8
    //   514: aastore
    //   515: dup
    //   516: iconst_2
    //   517: aload #9
    //   519: aastore
    //   520: dup
    //   521: iconst_3
    //   522: ldc 'X-Crashlytics-OS-Display-Version'
    //   524: aload #5
    //   526: aload #10
    //   528: invokespecial f : (Ljava/lang/String;)Ljava/lang/String;
    //   531: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Lga/n;
    //   534: aastore
    //   535: dup
    //   536: iconst_4
    //   537: ldc 'X-Crashlytics-API-Client-Version'
    //   539: aload #5
    //   541: getfield c : Ly7/b;
    //   544: invokevirtual f : ()Ljava/lang/String;
    //   547: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Lga/n;
    //   550: aastore
    //   551: invokestatic f : ([Lga/n;)Ljava/util/Map;
    //   554: astore #6
    //   556: aload_1
    //   557: astore_3
    //   558: aload #5
    //   560: getfield d : La8/a;
    //   563: astore #8
    //   565: aload_1
    //   566: astore_3
    //   567: new a8/c$c
    //   570: dup
    //   571: aload #5
    //   573: aconst_null
    //   574: invokespecial <init> : (La8/c;Lja/d;)V
    //   577: astore #5
    //   579: aload_1
    //   580: astore_3
    //   581: new a8/c$d
    //   584: dup
    //   585: aconst_null
    //   586: invokespecial <init> : (Lja/d;)V
    //   589: astore #9
    //   591: aload_1
    //   592: astore_3
    //   593: aload #4
    //   595: aload_1
    //   596: putfield a : Ljava/lang/Object;
    //   599: aload_1
    //   600: astore_3
    //   601: aload #4
    //   603: aconst_null
    //   604: putfield b : Ljava/lang/Object;
    //   607: aload_1
    //   608: astore_3
    //   609: aload #4
    //   611: iconst_3
    //   612: putfield e : I
    //   615: aload_1
    //   616: astore_3
    //   617: aload #8
    //   619: aload #6
    //   621: aload #5
    //   623: aload #9
    //   625: aload #4
    //   627: invokeinterface a : (Ljava/util/Map;Lqa/p;Lqa/p;Lja/d;)Ljava/lang/Object;
    //   632: astore #4
    //   634: aload #4
    //   636: aload #7
    //   638: if_acmpne -> 644
    //   641: aload #7
    //   643: areturn
    //   644: aload_1
    //   645: astore_3
    //   646: aload_3
    //   647: astore_1
    //   648: getstatic ga/u.a : Lga/u;
    //   651: astore #4
    //   653: aload_3
    //   654: aconst_null
    //   655: invokeinterface c : (Ljava/lang/Object;)V
    //   660: getstatic ga/u.a : Lga/u;
    //   663: areturn
    //   664: astore_3
    //   665: aload_1
    //   666: aconst_null
    //   667: invokeinterface c : (Ljava/lang/Object;)V
    //   672: aload_3
    //   673: athrow
    // Exception table:
    //   from	to	target	type
    //   97	102	105	finally
    //   140	145	148	finally
    //   257	271	664	finally
    //   280	325	664	finally
    //   340	347	148	finally
    //   354	362	148	finally
    //   364	369	148	finally
    //   381	390	148	finally
    //   392	397	148	finally
    //   399	426	148	finally
    //   428	435	148	finally
    //   437	451	148	finally
    //   453	458	148	finally
    //   460	467	148	finally
    //   469	483	148	finally
    //   485	490	148	finally
    //   492	499	148	finally
    //   501	556	148	finally
    //   558	565	148	finally
    //   567	579	148	finally
    //   581	591	148	finally
    //   593	599	148	finally
    //   601	607	148	finally
    //   609	615	148	finally
    //   617	634	148	finally
    //   648	653	105	finally
  }
  
  public za.a c() {
    Integer integer = this.e.e();
    if (integer != null) {
      za.a.a a1 = za.a.b;
      return za.a.i(za.c.o(integer.intValue(), za.d.e));
    } 
    return null;
  }
  
  public Double d() {
    return this.e.f();
  }
  
  private static final class a {
    private a() {}
  }
  
  @f(c = "com.google.firebase.sessions.settings.RemoteSettings", f = "RemoteSettings.kt", l = {167, 75, 92}, m = "updateSettings")
  static final class b extends kotlin.coroutines.jvm.internal.d {
    Object a;
    
    Object b;
    
    int e;
    
    b(c param1c, ja.d<? super b> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.c = param1Object;
      this.e |= Integer.MIN_VALUE;
      return this.d.b((ja.d<? super u>)this);
    }
  }
  
  @f(c = "com.google.firebase.sessions.settings.RemoteSettings$updateSettings$2$1", f = "RemoteSettings.kt", l = {122, 125, 128, 130, 131, 133}, m = "invokeSuspend")
  static final class c extends k implements p<JSONObject, ja.d<? super u>, Object> {
    Object a;
    
    Object b;
    
    int c;
    
    c(c param1c, ja.d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final Object a(JSONObject param1JSONObject, ja.d<? super u> param1d) {
      return ((c)create(param1JSONObject, param1d)).invokeSuspend(u.a);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      c c1 = new c(this.e, (ja.d)param1d);
      c1.d = param1Object;
      return (ja.d<u>)c1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      // Byte code:
      //   0: invokestatic c : ()Ljava/lang/Object;
      //   3: astore #6
      //   5: aload_0
      //   6: getfield c : I
      //   9: tableswitch default -> 52, 0 -> 159, 1 -> 124, 2 -> 98, 3 -> 83, 4 -> 76, 5 -> 69, 6 -> 62
      //   52: new java/lang/IllegalStateException
      //   55: dup
      //   56: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   58: invokespecial <init> : (Ljava/lang/String;)V
      //   61: athrow
      //   62: aload_1
      //   63: invokestatic b : (Ljava/lang/Object;)V
      //   66: goto -> 780
      //   69: aload_1
      //   70: invokestatic b : (Ljava/lang/Object;)V
      //   73: goto -> 730
      //   76: aload_1
      //   77: invokestatic b : (Ljava/lang/Object;)V
      //   80: goto -> 669
      //   83: aload_0
      //   84: getfield d : Ljava/lang/Object;
      //   87: checkcast kotlin/jvm/internal/v
      //   90: astore_2
      //   91: aload_1
      //   92: invokestatic b : (Ljava/lang/Object;)V
      //   95: goto -> 600
      //   98: aload_0
      //   99: getfield a : Ljava/lang/Object;
      //   102: checkcast kotlin/jvm/internal/v
      //   105: astore_2
      //   106: aload_0
      //   107: getfield d : Ljava/lang/Object;
      //   110: checkcast kotlin/jvm/internal/v
      //   113: astore #4
      //   115: aload_1
      //   116: invokestatic b : (Ljava/lang/Object;)V
      //   119: aload_2
      //   120: astore_1
      //   121: goto -> 523
      //   124: aload_0
      //   125: getfield b : Ljava/lang/Object;
      //   128: checkcast kotlin/jvm/internal/v
      //   131: astore_2
      //   132: aload_0
      //   133: getfield a : Ljava/lang/Object;
      //   136: checkcast kotlin/jvm/internal/v
      //   139: astore_3
      //   140: aload_0
      //   141: getfield d : Ljava/lang/Object;
      //   144: checkcast kotlin/jvm/internal/v
      //   147: astore #4
      //   149: aload_1
      //   150: invokestatic b : (Ljava/lang/Object;)V
      //   153: aload #4
      //   155: astore_1
      //   156: goto -> 416
      //   159: aload_1
      //   160: invokestatic b : (Ljava/lang/Object;)V
      //   163: aload_0
      //   164: getfield d : Ljava/lang/Object;
      //   167: checkcast org/json/JSONObject
      //   170: astore_1
      //   171: new kotlin/jvm/internal/v
      //   174: dup
      //   175: invokespecial <init> : ()V
      //   178: astore #5
      //   180: new kotlin/jvm/internal/v
      //   183: dup
      //   184: invokespecial <init> : ()V
      //   187: astore_3
      //   188: new kotlin/jvm/internal/v
      //   191: dup
      //   192: invokespecial <init> : ()V
      //   195: astore #4
      //   197: aload_1
      //   198: ldc 'app_quality'
      //   200: invokevirtual has : (Ljava/lang/String;)Z
      //   203: ifeq -> 353
      //   206: aload_1
      //   207: ldc 'app_quality'
      //   209: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
      //   212: astore_1
      //   213: aload_1
      //   214: ldc 'null cannot be cast to non-null type org.json.JSONObject'
      //   216: invokestatic d : (Ljava/lang/Object;Ljava/lang/String;)V
      //   219: aload_1
      //   220: checkcast org/json/JSONObject
      //   223: astore #7
      //   225: aload #7
      //   227: ldc 'sessions_enabled'
      //   229: invokevirtual has : (Ljava/lang/String;)Z
      //   232: ifeq -> 249
      //   235: aload #7
      //   237: ldc 'sessions_enabled'
      //   239: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
      //   242: checkcast java/lang/Boolean
      //   245: astore_1
      //   246: goto -> 251
      //   249: aconst_null
      //   250: astore_1
      //   251: aload #7
      //   253: ldc 'sampling_rate'
      //   255: invokevirtual has : (Ljava/lang/String;)Z
      //   258: ifeq -> 276
      //   261: aload #5
      //   263: aload #7
      //   265: ldc 'sampling_rate'
      //   267: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
      //   270: checkcast java/lang/Double
      //   273: putfield a : Ljava/lang/Object;
      //   276: aload #7
      //   278: ldc 'session_timeout_seconds'
      //   280: invokevirtual has : (Ljava/lang/String;)Z
      //   283: ifeq -> 300
      //   286: aload_3
      //   287: aload #7
      //   289: ldc 'session_timeout_seconds'
      //   291: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
      //   294: checkcast java/lang/Integer
      //   297: putfield a : Ljava/lang/Object;
      //   300: aload_1
      //   301: astore_2
      //   302: aload #7
      //   304: ldc 'cache_duration'
      //   306: invokevirtual has : (Ljava/lang/String;)Z
      //   309: ifeq -> 355
      //   312: aload #4
      //   314: aload #7
      //   316: ldc 'cache_duration'
      //   318: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
      //   321: checkcast java/lang/Integer
      //   324: putfield a : Ljava/lang/Object;
      //   327: aload_1
      //   328: astore_2
      //   329: goto -> 355
      //   332: astore_2
      //   333: goto -> 339
      //   336: astore_2
      //   337: aconst_null
      //   338: astore_1
      //   339: ldc 'SessionConfigFetcher'
      //   341: ldc 'Error parsing the configs remotely fetched: '
      //   343: aload_2
      //   344: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   347: pop
      //   348: aload_1
      //   349: astore_2
      //   350: goto -> 355
      //   353: aconst_null
      //   354: astore_2
      //   355: aload_2
      //   356: ifnull -> 424
      //   359: aload_0
      //   360: getfield e : La8/c;
      //   363: astore_1
      //   364: aload_2
      //   365: invokevirtual booleanValue : ()Z
      //   368: pop
      //   369: aload_1
      //   370: invokestatic e : (La8/c;)La8/g;
      //   373: astore_1
      //   374: aload_0
      //   375: aload #5
      //   377: putfield d : Ljava/lang/Object;
      //   380: aload_0
      //   381: aload_3
      //   382: putfield a : Ljava/lang/Object;
      //   385: aload_0
      //   386: aload #4
      //   388: putfield b : Ljava/lang/Object;
      //   391: aload_0
      //   392: iconst_1
      //   393: putfield c : I
      //   396: aload_1
      //   397: aload_2
      //   398: aload_0
      //   399: invokevirtual n : (Ljava/lang/Boolean;Lja/d;)Ljava/lang/Object;
      //   402: aload #6
      //   404: if_acmpne -> 410
      //   407: aload #6
      //   409: areturn
      //   410: aload #5
      //   412: astore_1
      //   413: aload #4
      //   415: astore_2
      //   416: aload_3
      //   417: astore #5
      //   419: aload_1
      //   420: astore_3
      //   421: goto -> 435
      //   424: aload #5
      //   426: astore_1
      //   427: aload #4
      //   429: astore_2
      //   430: aload_3
      //   431: astore #5
      //   433: aload_1
      //   434: astore_3
      //   435: aload #5
      //   437: getfield a : Ljava/lang/Object;
      //   440: checkcast java/lang/Integer
      //   443: astore #7
      //   445: aload_2
      //   446: astore_1
      //   447: aload_3
      //   448: astore #4
      //   450: aload #7
      //   452: ifnull -> 523
      //   455: aload_0
      //   456: getfield e : La8/c;
      //   459: astore_1
      //   460: aload #7
      //   462: invokevirtual intValue : ()I
      //   465: pop
      //   466: aload_1
      //   467: invokestatic e : (La8/c;)La8/g;
      //   470: astore #7
      //   472: aload #5
      //   474: getfield a : Ljava/lang/Object;
      //   477: checkcast java/lang/Integer
      //   480: astore #5
      //   482: aload_0
      //   483: aload_3
      //   484: putfield d : Ljava/lang/Object;
      //   487: aload_0
      //   488: aload_2
      //   489: putfield a : Ljava/lang/Object;
      //   492: aload_0
      //   493: aconst_null
      //   494: putfield b : Ljava/lang/Object;
      //   497: aload_0
      //   498: iconst_2
      //   499: putfield c : I
      //   502: aload_2
      //   503: astore_1
      //   504: aload_3
      //   505: astore #4
      //   507: aload #7
      //   509: aload #5
      //   511: aload_0
      //   512: invokevirtual m : (Ljava/lang/Integer;Lja/d;)Ljava/lang/Object;
      //   515: aload #6
      //   517: if_acmpne -> 523
      //   520: aload #6
      //   522: areturn
      //   523: aload #4
      //   525: getfield a : Ljava/lang/Object;
      //   528: checkcast java/lang/Double
      //   531: astore_3
      //   532: aload_1
      //   533: astore_2
      //   534: aload_3
      //   535: ifnull -> 600
      //   538: aload_0
      //   539: getfield e : La8/c;
      //   542: astore_2
      //   543: aload_3
      //   544: invokevirtual doubleValue : ()D
      //   547: pop2
      //   548: aload_2
      //   549: invokestatic e : (La8/c;)La8/g;
      //   552: astore_3
      //   553: aload #4
      //   555: getfield a : Ljava/lang/Object;
      //   558: checkcast java/lang/Double
      //   561: astore #4
      //   563: aload_0
      //   564: aload_1
      //   565: putfield d : Ljava/lang/Object;
      //   568: aload_0
      //   569: aconst_null
      //   570: putfield a : Ljava/lang/Object;
      //   573: aload_0
      //   574: aconst_null
      //   575: putfield b : Ljava/lang/Object;
      //   578: aload_0
      //   579: iconst_3
      //   580: putfield c : I
      //   583: aload_1
      //   584: astore_2
      //   585: aload_3
      //   586: aload #4
      //   588: aload_0
      //   589: invokevirtual i : (Ljava/lang/Double;Lja/d;)Ljava/lang/Object;
      //   592: aload #6
      //   594: if_acmpne -> 600
      //   597: aload #6
      //   599: areturn
      //   600: aload_2
      //   601: getfield a : Ljava/lang/Object;
      //   604: checkcast java/lang/Integer
      //   607: astore_1
      //   608: aload_1
      //   609: ifnull -> 676
      //   612: aload_0
      //   613: getfield e : La8/c;
      //   616: astore_3
      //   617: aload_1
      //   618: invokevirtual intValue : ()I
      //   621: pop
      //   622: aload_3
      //   623: invokestatic e : (La8/c;)La8/g;
      //   626: astore_1
      //   627: aload_2
      //   628: getfield a : Ljava/lang/Object;
      //   631: checkcast java/lang/Integer
      //   634: astore_2
      //   635: aload_0
      //   636: aconst_null
      //   637: putfield d : Ljava/lang/Object;
      //   640: aload_0
      //   641: aconst_null
      //   642: putfield a : Ljava/lang/Object;
      //   645: aload_0
      //   646: aconst_null
      //   647: putfield b : Ljava/lang/Object;
      //   650: aload_0
      //   651: iconst_4
      //   652: putfield c : I
      //   655: aload_1
      //   656: aload_2
      //   657: aload_0
      //   658: invokevirtual j : (Ljava/lang/Integer;Lja/d;)Ljava/lang/Object;
      //   661: aload #6
      //   663: if_acmpne -> 669
      //   666: aload #6
      //   668: areturn
      //   669: getstatic ga/u.a : Lga/u;
      //   672: astore_1
      //   673: goto -> 678
      //   676: aconst_null
      //   677: astore_1
      //   678: aload_1
      //   679: ifnonnull -> 730
      //   682: aload_0
      //   683: getfield e : La8/c;
      //   686: invokestatic e : (La8/c;)La8/g;
      //   689: astore_1
      //   690: ldc 86400
      //   692: invokestatic b : (I)Ljava/lang/Integer;
      //   695: astore_2
      //   696: aload_0
      //   697: aconst_null
      //   698: putfield d : Ljava/lang/Object;
      //   701: aload_0
      //   702: aconst_null
      //   703: putfield a : Ljava/lang/Object;
      //   706: aload_0
      //   707: aconst_null
      //   708: putfield b : Ljava/lang/Object;
      //   711: aload_0
      //   712: iconst_5
      //   713: putfield c : I
      //   716: aload_1
      //   717: aload_2
      //   718: aload_0
      //   719: invokevirtual j : (Ljava/lang/Integer;Lja/d;)Ljava/lang/Object;
      //   722: aload #6
      //   724: if_acmpne -> 730
      //   727: aload #6
      //   729: areturn
      //   730: aload_0
      //   731: getfield e : La8/c;
      //   734: invokestatic e : (La8/c;)La8/g;
      //   737: astore_1
      //   738: invokestatic currentTimeMillis : ()J
      //   741: invokestatic c : (J)Ljava/lang/Long;
      //   744: astore_2
      //   745: aload_0
      //   746: aconst_null
      //   747: putfield d : Ljava/lang/Object;
      //   750: aload_0
      //   751: aconst_null
      //   752: putfield a : Ljava/lang/Object;
      //   755: aload_0
      //   756: aconst_null
      //   757: putfield b : Ljava/lang/Object;
      //   760: aload_0
      //   761: bipush #6
      //   763: putfield c : I
      //   766: aload_1
      //   767: aload_2
      //   768: aload_0
      //   769: invokevirtual k : (Ljava/lang/Long;Lja/d;)Ljava/lang/Object;
      //   772: aload #6
      //   774: if_acmpne -> 780
      //   777: aload #6
      //   779: areturn
      //   780: getstatic ga/u.a : Lga/u;
      //   783: areturn
      // Exception table:
      //   from	to	target	type
      //   225	246	336	org/json/JSONException
      //   251	276	332	org/json/JSONException
      //   276	300	332	org/json/JSONException
      //   302	327	332	org/json/JSONException
    }
  }
  
  @f(c = "com.google.firebase.sessions.settings.RemoteSettings$updateSettings$2$2", f = "RemoteSettings.kt", l = {}, m = "invokeSuspend")
  static final class d extends k implements p<String, ja.d<? super u>, Object> {
    int a;
    
    d(ja.d<? super d> param1d) {
      super(2, param1d);
    }
    
    public final Object a(String param1String, ja.d<? super u> param1d) {
      return ((d)create(param1String, param1d)).invokeSuspend(u.a);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      d d1 = new d((ja.d)param1d);
      d1.b = param1Object;
      return (ja.d<u>)d1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      ka.b.c();
      if (this.a == 0) {
        p.b(param1Object);
        param1Object = this.b;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error failing to fetch the remote configs: ");
        stringBuilder.append((String)param1Object);
        Log.e("SessionConfigFetcher", stringBuilder.toString());
        return u.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a8\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */