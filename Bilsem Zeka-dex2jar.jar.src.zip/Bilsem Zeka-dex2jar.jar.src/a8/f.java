package a8;

import android.content.Context;
import d0.d;
import ga.u;
import ja.d;
import ja.g;
import kotlin.coroutines.jvm.internal.d;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.q;
import kotlin.jvm.internal.r;
import kotlin.jvm.internal.w;
import p7.e;
import wa.h;
import za.c;
import za.d;

public final class f {
  private static final a c = new a(null);
  
  @Deprecated
  private static final sa.a<Context, a0.f<d>> d = c0.a.b("firebase_session_settings", null, null, null, 14, null);
  
  private final h a;
  
  private final h b;
  
  public f(h paramh1, h paramh2) {
    this.a = paramh1;
    this.b = paramh2;
  }
  
  public f(Context paramContext, g paramg1, g paramg2, e parame, y7.b paramb) {
    this(new b(paramContext), new c(paramg2, parame, paramb, new d(paramb, paramg1, null, 4, null), a.a(c, paramContext)));
  }
  
  private final boolean e(double paramDouble) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (0.0D <= paramDouble) {
      bool1 = bool2;
      if (paramDouble <= 1.0D)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private final boolean f(long paramLong) {
    return (za.a.J(paramLong) && za.a.E(paramLong));
  }
  
  public final double b() {
    Double double_ = this.a.d();
    if (double_ != null) {
      double d = double_.doubleValue();
      if (e(d))
        return d; 
    } 
    double_ = this.b.d();
    if (double_ != null) {
      double d = double_.doubleValue();
      if (e(d))
        return d; 
    } 
    return 1.0D;
  }
  
  public final long c() {
    za.a a2 = this.a.c();
    if (a2 != null) {
      long l = a2.P();
      if (f(l))
        return l; 
    } 
    a2 = this.b.c();
    if (a2 != null) {
      long l = a2.P();
      if (f(l))
        return l; 
    } 
    za.a.a a1 = za.a.b;
    return c.o(30, d.f);
  }
  
  public final boolean d() {
    Boolean bool = this.a.a();
    if (bool != null)
      return bool.booleanValue(); 
    bool = this.b.a();
    return (bool != null) ? bool.booleanValue() : true;
  }
  
  public final Object g(d<? super u> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof a8/f$b
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast a8/f$b
    //   11: astore_3
    //   12: aload_3
    //   13: getfield d : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield d : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 47
    //   37: new a8/f$b
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (La8/f;Lja/d;)V
    //   46: astore_1
    //   47: aload_1
    //   48: getfield b : Ljava/lang/Object;
    //   51: astore #5
    //   53: invokestatic c : ()Ljava/lang/Object;
    //   56: astore #4
    //   58: aload_1
    //   59: getfield d : I
    //   62: istore_2
    //   63: iload_2
    //   64: ifeq -> 111
    //   67: iload_2
    //   68: iconst_1
    //   69: if_icmpeq -> 95
    //   72: iload_2
    //   73: iconst_2
    //   74: if_icmpne -> 85
    //   77: aload #5
    //   79: invokestatic b : (Ljava/lang/Object;)V
    //   82: goto -> 178
    //   85: new java/lang/IllegalStateException
    //   88: dup
    //   89: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   91: invokespecial <init> : (Ljava/lang/String;)V
    //   94: athrow
    //   95: aload_1
    //   96: getfield a : Ljava/lang/Object;
    //   99: checkcast a8/f
    //   102: astore_3
    //   103: aload #5
    //   105: invokestatic b : (Ljava/lang/Object;)V
    //   108: goto -> 148
    //   111: aload #5
    //   113: invokestatic b : (Ljava/lang/Object;)V
    //   116: aload_0
    //   117: getfield a : La8/h;
    //   120: astore_3
    //   121: aload_1
    //   122: aload_0
    //   123: putfield a : Ljava/lang/Object;
    //   126: aload_1
    //   127: iconst_1
    //   128: putfield d : I
    //   131: aload_3
    //   132: aload_1
    //   133: invokeinterface b : (Lja/d;)Ljava/lang/Object;
    //   138: aload #4
    //   140: if_acmpne -> 146
    //   143: aload #4
    //   145: areturn
    //   146: aload_0
    //   147: astore_3
    //   148: aload_3
    //   149: getfield b : La8/h;
    //   152: astore_3
    //   153: aload_1
    //   154: aconst_null
    //   155: putfield a : Ljava/lang/Object;
    //   158: aload_1
    //   159: iconst_2
    //   160: putfield d : I
    //   163: aload_3
    //   164: aload_1
    //   165: invokeinterface b : (Lja/d;)Ljava/lang/Object;
    //   170: aload #4
    //   172: if_acmpne -> 178
    //   175: aload #4
    //   177: areturn
    //   178: getstatic ga/u.a : Lga/u;
    //   181: areturn
  }
  
  private static final class a {
    private a() {}
    
    private final a0.f<d> b(Context param1Context) {
      return (a0.f<d>)f.a().a(param1Context, a[0]);
    }
  }
  
  @kotlin.coroutines.jvm.internal.f(c = "com.google.firebase.sessions.settings.SessionsSettings", f = "SessionsSettings.kt", l = {116, 117}, m = "updateSettings")
  static final class b extends d {
    Object a;
    
    int d;
    
    b(f param1f, d<? super b> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.b = param1Object;
      this.d |= Integer.MIN_VALUE;
      return this.c.g((d<? super u>)this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a8\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */