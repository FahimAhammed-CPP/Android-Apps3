package a8;

import ga.u;
import ja.d;
import java.util.Map;
import org.json.JSONObject;
import qa.p;

public interface a {
  Object a(Map<String, String> paramMap, p<? super JSONObject, ? super d<? super u>, ? extends Object> paramp, p<? super String, ? super d<? super u>, ? extends Object> paramp1, d<? super u> paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a8\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */