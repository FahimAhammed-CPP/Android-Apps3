package a8;

import ab.h;
import ab.l0;
import android.net.Uri;
import ga.p;
import ga.u;
import ja.g;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Map;
import kotlin.coroutines.jvm.internal.f;
import kotlin.coroutines.jvm.internal.k;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.v;
import org.json.JSONObject;
import qa.p;

public final class d implements a {
  public static final a d = new a(null);
  
  private final y7.b a;
  
  private final g b;
  
  private final String c;
  
  public d(y7.b paramb, g paramg, String paramString) {
    this.a = paramb;
    this.b = paramg;
    this.c = paramString;
  }
  
  private final URL c() {
    return new URL((new Uri.Builder()).scheme("https").authority(this.c).appendPath("spi").appendPath("v2").appendPath("platforms").appendPath("android").appendPath("gmp").appendPath(this.a.b()).appendPath("settings").appendQueryParameter("build_version", this.a.a().a()).appendQueryParameter("display_version", this.a.a().d()).build().toString());
  }
  
  public Object a(Map<String, String> paramMap, p<? super JSONObject, ? super ja.d<? super u>, ? extends Object> paramp, p<? super String, ? super ja.d<? super u>, ? extends Object> paramp1, ja.d<? super u> paramd) {
    Object object = h.e(this.b, new b(this, paramMap, paramp, paramp1, null), paramd);
    return (object == ka.b.c()) ? object : u.a;
  }
  
  public static final class a {
    private a() {}
  }
  
  @f(c = "com.google.firebase.sessions.settings.RemoteSettingsFetcher$doConfigFetch$2", f = "RemoteSettingsFetcher.kt", l = {68, 70, 73}, m = "invokeSuspend")
  static final class b extends k implements p<l0, ja.d<? super u>, Object> {
    int a;
    
    b(d param1d, Map<String, String> param1Map, p<? super JSONObject, ? super ja.d<? super u>, ? extends Object> param1p, p<? super String, ? super ja.d<? super u>, ? extends Object> param1p1, ja.d<? super b> param1d1) {
      super(2, param1d1);
    }
    
    public final ja.d<u> create(Object param1Object, ja.d<?> param1d) {
      return (ja.d<u>)new b(this.b, this.c, this.d, this.e, (ja.d)param1d);
    }
    
    public final Object invoke(l0 param1l0, ja.d<? super u> param1d) {
      return ((b)create(param1l0, param1d)).invokeSuspend(u.a);
    }
    
    public final Object invokeSuspend(Object<String, ja.d<? super u>, Object> param1Object) {
      Object object = ka.b.c();
      int i = this.a;
      if (i != 0) {
        if (i != 1 && i != 2) {
          if (i == 3) {
            p.b(param1Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          try {
            p.b(param1Object);
          } catch (Exception exception) {
            p<String, ja.d<? super u>, Object> p1 = this.e;
            String str = exception.getMessage();
            param1Object = (Object<String, ja.d<? super u>, Object>)str;
            if (str == null)
              param1Object = (Object<String, ja.d<? super u>, Object>)exception.toString(); 
            this.a = 3;
            if (p1.invoke(param1Object, this) == object)
              return object; 
          } 
        } 
      } else {
        p.b(param1Object);
        param1Object = (Object<String, ja.d<? super u>, Object>)d.b(this.b).openConnection();
        l.d(param1Object, "null cannot be cast to non-null type javax.net.ssl.HttpsURLConnection");
        param1Object = param1Object;
        param1Object.setRequestMethod("GET");
        param1Object.setRequestProperty("Accept", "application/json");
        for (Map.Entry<String, String> entry : this.c.entrySet())
          param1Object.setRequestProperty((String)entry.getKey(), (String)entry.getValue()); 
        i = param1Object.getResponseCode();
        if (i == 200) {
          param1Object = (Object<String, ja.d<? super u>, Object>)param1Object.getInputStream();
          BufferedReader bufferedReader = new BufferedReader(new InputStreamReader((InputStream)param1Object));
          StringBuilder stringBuilder1 = new StringBuilder();
          v v = new v();
          while (true) {
            String str1 = bufferedReader.readLine();
            v.a = str1;
            if (str1 != null) {
              stringBuilder1.append(str1);
              continue;
            } 
            bufferedReader.close();
            param1Object.close();
            param1Object = (Object<String, ja.d<? super u>, Object>)new JSONObject(stringBuilder1.toString());
            p<JSONObject, ja.d<? super u>, Object> p1 = this.d;
            this.a = 1;
            return (p1.invoke(param1Object, this) == object) ? object : u.a;
          } 
        } 
        param1Object = (Object<String, ja.d<? super u>, Object>)this.e;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Bad response code: ");
        stringBuilder.append(i);
        String str = stringBuilder.toString();
        this.a = 2;
        param1Object = (Object<String, ja.d<? super u>, Object>)param1Object.invoke(str, this);
        if (param1Object == object)
          return object; 
      } 
      return u.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a8\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */