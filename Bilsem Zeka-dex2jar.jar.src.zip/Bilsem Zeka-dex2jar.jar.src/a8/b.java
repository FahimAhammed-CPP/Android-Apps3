package a8;

import android.content.Context;
import android.os.Bundle;
import ga.u;
import ja.d;
import kotlin.jvm.internal.g;
import za.c;
import za.d;

public final class b implements h {
  private static final a b = new a(null);
  
  private final Bundle a;
  
  public b(Context paramContext) {
    Bundle bundle2 = (paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128)).metaData;
    Bundle bundle1 = bundle2;
    if (bundle2 == null)
      bundle1 = Bundle.EMPTY; 
    this.a = bundle1;
  }
  
  public Boolean a() {
    return this.a.containsKey("firebase_sessions_enabled") ? Boolean.valueOf(this.a.getBoolean("firebase_sessions_enabled")) : null;
  }
  
  public Object b(d<? super u> paramd) {
    return h.a.a(this, paramd);
  }
  
  public za.a c() {
    return this.a.containsKey("firebase_sessions_sessions_restart_timeout") ? za.a.i(c.o(this.a.getInt("firebase_sessions_sessions_restart_timeout"), d.e)) : null;
  }
  
  public Double d() {
    return this.a.containsKey("firebase_sessions_sampling_rate") ? Double.valueOf(this.a.getDouble("firebase_sessions_sampling_rate")) : null;
  }
  
  private static final class a {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a8\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */