package a9;

import android.view.MotionEvent;

public class h {
  private float a;
  
  private float b;
  
  private float c;
  
  private float d;
  
  private int e;
  
  private int f;
  
  private float g;
  
  private boolean h;
  
  private a i;
  
  public h(a parama) {
    this.i = parama;
    this.e = -1;
    this.f = -1;
  }
  
  private float a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
    return b((float)Math.toDegrees((float)Math.atan2((paramFloat2 - paramFloat4), (paramFloat1 - paramFloat3))), (float)Math.toDegrees((float)Math.atan2((paramFloat6 - paramFloat8), (paramFloat5 - paramFloat7))));
  }
  
  private float b(float paramFloat1, float paramFloat2) {
    paramFloat1 = paramFloat2 % 360.0F - paramFloat1 % 360.0F;
    this.g = paramFloat1;
    if (paramFloat1 < -180.0F) {
      paramFloat1 += 360.0F;
    } else if (paramFloat1 > 180.0F) {
      paramFloat1 -= 360.0F;
    } else {
      return this.g;
    } 
    this.g = paramFloat1;
    return this.g;
  }
  
  public float c() {
    return this.g;
  }
  
  public boolean d(MotionEvent paramMotionEvent) {
    a a1;
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 5) {
            if (i != 6)
              return true; 
            this.f = -1;
            return true;
          } 
          this.a = paramMotionEvent.getX();
          this.b = paramMotionEvent.getY();
          this.f = paramMotionEvent.findPointerIndex(paramMotionEvent.getPointerId(paramMotionEvent.getActionIndex()));
        } else {
          if (this.e != -1 && this.f != -1 && paramMotionEvent.getPointerCount() > this.f) {
            float f1 = paramMotionEvent.getX(this.e);
            float f2 = paramMotionEvent.getY(this.e);
            float f3 = paramMotionEvent.getX(this.f);
            float f4 = paramMotionEvent.getY(this.f);
            if (this.h) {
              this.g = 0.0F;
              this.h = false;
            } else {
              a(this.a, this.b, this.c, this.d, f3, f4, f1, f2);
            } 
            a1 = this.i;
            if (a1 != null)
              a1.a(this); 
            this.a = f3;
            this.b = f4;
            this.c = f1;
            this.d = f2;
            return true;
          } 
          return true;
        } 
      } else {
        this.e = -1;
        return true;
      } 
    } else {
      this.c = a1.getX();
      this.d = a1.getY();
      this.e = a1.findPointerIndex(a1.getPointerId(0));
    } 
    this.g = 0.0F;
    this.h = true;
    return true;
  }
  
  public static interface a {
    boolean a(h param1h);
  }
  
  public static class b implements a {}
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a9\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */