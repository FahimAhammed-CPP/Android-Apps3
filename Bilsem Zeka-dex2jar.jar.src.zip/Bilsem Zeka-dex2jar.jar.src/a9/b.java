package a9;

public final class b {
  public static float a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat1 /= paramFloat4 / 2.0F;
    paramFloat3 /= 2.0F;
    if (paramFloat1 < 1.0F) {
      paramFloat1 = paramFloat3 * paramFloat1 * paramFloat1 * paramFloat1;
    } else {
      paramFloat1 -= 2.0F;
      paramFloat1 = paramFloat3 * (paramFloat1 * paramFloat1 * paramFloat1 + 2.0F);
    } 
    return paramFloat1 + paramFloat2;
  }
  
  public static float b(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat1 = paramFloat1 / paramFloat4 - 1.0F;
    return paramFloat3 * (paramFloat1 * paramFloat1 * paramFloat1 + 1.0F) + paramFloat2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a9\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */