package a9;

import android.annotation.TargetApi;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.util.Log;

public class c {
  @TargetApi(17)
  private static int a() {
    EGLDisplay eGLDisplay = EGL14.eglGetDisplay(0);
    int[] arrayOfInt1 = new int[2];
    EGL14.eglInitialize(eGLDisplay, arrayOfInt1, 0, arrayOfInt1, 1);
    EGLConfig[] arrayOfEGLConfig = new EGLConfig[1];
    int[] arrayOfInt2 = new int[1];
    EGL14.eglChooseConfig(eGLDisplay, new int[] { 12351, 12430, 12329, 0, 12352, 4, 12339, 1, 12344 }, 0, arrayOfEGLConfig, 0, 1, arrayOfInt2, 0);
    if (arrayOfInt2[0] == 0)
      return 0; 
    EGLConfig eGLConfig = arrayOfEGLConfig[0];
    EGLSurface eGLSurface1 = EGL14.eglCreatePbufferSurface(eGLDisplay, eGLConfig, new int[] { 12375, 64, 12374, 64, 12344 }, 0);
    EGLContext eGLContext = EGL14.eglCreateContext(eGLDisplay, eGLConfig, EGL14.EGL_NO_CONTEXT, new int[] { 12440, 2, 12344 }, 0);
    EGL14.eglMakeCurrent(eGLDisplay, eGLSurface1, eGLSurface1, eGLContext);
    int[] arrayOfInt3 = new int[1];
    GLES20.glGetIntegerv(3379, arrayOfInt3, 0);
    EGLSurface eGLSurface2 = EGL14.EGL_NO_SURFACE;
    EGL14.eglMakeCurrent(eGLDisplay, eGLSurface2, eGLSurface2, EGL14.EGL_NO_CONTEXT);
    EGL14.eglDestroySurface(eGLDisplay, eGLSurface1);
    EGL14.eglDestroyContext(eGLDisplay, eGLContext);
    EGL14.eglTerminate(eGLDisplay);
    return arrayOfInt3[0];
  }
  
  public static int b() {
    try {
      return a();
    } catch (Exception exception) {
      Log.d("EglUtils", "getMaxTextureSize: ", exception);
      return 0;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a9\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */