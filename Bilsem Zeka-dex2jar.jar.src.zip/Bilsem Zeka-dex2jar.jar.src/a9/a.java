package a9;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.view.WindowManager;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import x8.b;
import z8.b;

public class a {
  public static int a(BitmapFactory.Options paramOptions, int paramInt1, int paramInt2) {
    int k = paramOptions.outHeight;
    int m = paramOptions.outWidth;
    int j = 1;
    byte b = 1;
    int i = b;
    if (k <= paramInt2)
      if (m > paramInt1) {
        i = b;
      } else {
        return j;
      }  
    while (true) {
      if (k / i <= paramInt2) {
        j = i;
        if (m / i > paramInt1)
          continue; 
        return j;
      } 
      continue;
      i *= 2;
    } 
  }
  
  public static int b(Context paramContext) {
    WindowManager windowManager = (WindowManager)paramContext.getSystemService("window");
    Point point = new Point();
    if (windowManager != null)
      windowManager.getDefaultDisplay().getSize(point); 
    int i = point.x;
    int j = point.y;
    j = (int)Math.sqrt(Math.pow(i, 2.0D) + Math.pow(j, 2.0D));
    Canvas canvas = new Canvas();
    int k = Math.min(canvas.getMaximumBitmapWidth(), canvas.getMaximumBitmapHeight());
    i = j;
    if (k > 0)
      i = Math.min(j, k); 
    k = c.b();
    j = i;
    if (k > 0)
      j = Math.min(i, k); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("maxBitmapSize: ");
    stringBuilder.append(j);
    Log.d("BitmapLoadUtils", stringBuilder.toString());
    return j;
  }
  
  public static void c(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
        return;
      } catch (IOException iOException) {
        return;
      }  
  }
  
  public static void d(Context paramContext, Uri paramUri1, Uri paramUri2, int paramInt1, int paramInt2, b paramb) {
    (new b(paramContext, paramUri1, paramUri2, paramInt1, paramInt2, paramb)).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
  }
  
  public static int e(int paramInt) {
    switch (paramInt) {
      default:
        return 0;
      case 7:
      case 8:
        return 270;
      case 5:
      case 6:
        return 90;
      case 3:
      case 4:
        break;
    } 
    return 180;
  }
  
  public static int f(int paramInt) {
    return (paramInt != 2 && paramInt != 7 && paramInt != 4 && paramInt != 5) ? 1 : -1;
  }
  
  public static int g(Context paramContext, Uri paramUri) {
    int j = 0;
    int i = j;
    try {
      InputStream inputStream = paramContext.getContentResolver().openInputStream(paramUri);
      if (inputStream == null)
        return 0; 
      i = j;
      j = (new f(inputStream)).g();
      i = j;
      c(inputStream);
      return j;
    } catch (IOException iOException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getExifOrientation: ");
      stringBuilder.append(paramUri.toString());
      Log.e("BitmapLoadUtils", stringBuilder.toString(), iOException);
      return i;
    } 
  }
  
  public static boolean h(Uri paramUri) {
    return (paramUri != null && "content".equals(paramUri.getScheme()));
  }
  
  public static Bitmap i(Bitmap paramBitmap, Matrix paramMatrix) {
    try {
      Bitmap bitmap = Bitmap.createBitmap(paramBitmap, 0, 0, paramBitmap.getWidth(), paramBitmap.getHeight(), paramMatrix, true);
      boolean bool = paramBitmap.sameAs(bitmap);
      if (!bool)
        return bitmap; 
    } catch (OutOfMemoryError outOfMemoryError) {
      Log.e("BitmapLoadUtils", "transformBitmap: ", outOfMemoryError);
    } 
    return paramBitmap;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a9\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */