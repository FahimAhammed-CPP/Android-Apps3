package a9;

import android.graphics.RectF;

public class g {
  public static float[] a(RectF paramRectF) {
    return new float[] { paramRectF.centerX(), paramRectF.centerY() };
  }
  
  public static float[] b(RectF paramRectF) {
    float f1 = paramRectF.left;
    float f2 = paramRectF.top;
    float f3 = paramRectF.right;
    float f4 = paramRectF.bottom;
    return new float[] { f1, f2, f3, f2, f3, f4, f1, f4 };
  }
  
  public static float[] c(float[] paramArrayOffloat) {
    return new float[] { (float)Math.sqrt(Math.pow((paramArrayOffloat[0] - paramArrayOffloat[2]), 2.0D) + Math.pow((paramArrayOffloat[1] - paramArrayOffloat[3]), 2.0D)), (float)Math.sqrt(Math.pow((paramArrayOffloat[2] - paramArrayOffloat[4]), 2.0D) + Math.pow((paramArrayOffloat[3] - paramArrayOffloat[5]), 2.0D)) };
  }
  
  public static RectF d(float[] paramArrayOffloat) {
    RectF rectF = new RectF(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY);
    int i;
    for (i = 1; i < paramArrayOffloat.length; i += 2) {
      float f2 = Math.round(paramArrayOffloat[i - 1] * 10.0F) / 10.0F;
      float f1 = Math.round(paramArrayOffloat[i] * 10.0F) / 10.0F;
      float f4 = rectF.left;
      float f3 = f4;
      if (f2 < f4)
        f3 = f2; 
      rectF.left = f3;
      f4 = rectF.top;
      f3 = f4;
      if (f1 < f4)
        f3 = f1; 
      rectF.top = f3;
      f3 = rectF.right;
      if (f2 <= f3)
        f2 = f3; 
      rectF.right = f2;
      f2 = rectF.bottom;
      if (f1 <= f2)
        f1 = f2; 
      rectF.bottom = f1;
    } 
    rectF.sort();
    return rectF;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a9\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */