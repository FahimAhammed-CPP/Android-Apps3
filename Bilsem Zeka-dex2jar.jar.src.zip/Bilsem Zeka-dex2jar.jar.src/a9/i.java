package a9;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;

public class i extends StateListDrawable {
  private int a;
  
  public i(Drawable paramDrawable, int paramInt) {
    this.a = paramInt;
    addState(new int[] { 16842913 }, paramDrawable);
    addState(new int[0], paramDrawable);
  }
  
  public boolean isStateful() {
    return true;
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    int k = paramArrayOfint.length;
    int j = 0;
    boolean bool = false;
    while (j < k) {
      if (paramArrayOfint[j] == 16842913)
        bool = true; 
      j++;
    } 
    if (bool) {
      setColorFilter(this.a, PorterDuff.Mode.SRC_ATOP);
    } else {
      clearColorFilter();
    } 
    return super.onStateChange(paramArrayOfint);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a9\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */