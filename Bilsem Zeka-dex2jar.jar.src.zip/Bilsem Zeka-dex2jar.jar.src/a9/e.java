package a9;

import android.content.Context;
import android.net.Uri;
import java.io.InputStream;
import java.nio.channels.FileChannel;

public class e {
  public static void a(Context paramContext, Uri paramUri1, Uri paramUri2) {
    FileChannel fileChannel1;
    if (paramUri1.equals(paramUri2))
      return; 
    FileChannel fileChannel2 = null;
    Uri uri = null;
    try {
      InputStream inputStream = paramContext.getContentResolver().openInputStream(paramUri1);
    } finally {
      paramUri2 = null;
      paramUri1 = null;
    } 
    if (fileChannel1 != null)
      fileChannel1.close(); 
    if (paramUri1 != null)
      paramUri1.close(); 
    throw paramUri2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a9\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */