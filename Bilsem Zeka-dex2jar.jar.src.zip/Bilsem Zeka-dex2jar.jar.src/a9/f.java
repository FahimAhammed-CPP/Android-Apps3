package a9;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;

public class f {
  private static final byte[] b = "Exif\000\000".getBytes(Charset.forName("UTF-8"));
  
  private static final int[] c = new int[] { 
      0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 
      8, 4, 8 };
  
  private final b a;
  
  public f(InputStream paramInputStream) {
    this.a = new c(paramInputStream);
  }
  
  private static int a(int paramInt1, int paramInt2) {
    return paramInt1 + 2 + paramInt2 * 12;
  }
  
  public static void b(Context paramContext, int paramInt1, int paramInt2, Uri paramUri1, Uri paramUri2) {
    androidx.exifinterface.media.a a1;
    ParcelFileDescriptor parcelFileDescriptor1;
    if (paramContext == null) {
      Log.d("ImageHeaderParser", "context is null");
      return;
    } 
    ParcelFileDescriptor parcelFileDescriptor3 = null;
    ParcelFileDescriptor parcelFileDescriptor2 = null;
    androidx.exifinterface.media.a a2 = null;
    Uri uri = null;
    try {
      InputStream inputStream = paramContext.getContentResolver().openInputStream(paramUri1);
      paramUri1 = uri;
    } catch (IOException iOException1) {
    
    } finally {
      paramUri1 = null;
      paramUri2 = null;
    } 
    try {
      Log.d("ImageHeaderParser", paramUri2.getMessage(), (Throwable)paramUri2);
      return;
    } finally {
      parcelFileDescriptor2 = null;
      paramUri2 = paramUri1;
    } 
    if (iOException != null)
      try {
        iOException.close();
      } catch (IOException iOException1) {
        Log.d("ImageHeaderParser", iOException1.getMessage(), iOException1);
      }  
    if (paramUri2 != null)
      try {
        paramUri2.close();
      } catch (IOException iOException1) {
        Log.d("ImageHeaderParser", iOException1.getMessage(), iOException1);
      }  
    throw parcelFileDescriptor1;
  }
  
  public static void c(Context paramContext, int paramInt1, int paramInt2, Uri paramUri, String paramString) {
    if (paramContext == null) {
      Log.d("ImageHeaderParser", "context is null");
      return;
    } 
    InputStream inputStream2 = null;
    InputStream inputStream1 = null;
    try {
      InputStream inputStream = paramContext.getContentResolver().openInputStream(paramUri);
      inputStream1 = inputStream;
      inputStream2 = inputStream;
      f(new androidx.exifinterface.media.a(inputStream), new androidx.exifinterface.media.a(paramString), paramInt1, paramInt2);
      if (inputStream != null)
        try {
          inputStream.close();
          return;
        } catch (IOException iOException) {
          Log.d("ImageHeaderParser", iOException.getMessage(), iOException);
        }  
    } catch (IOException iOException) {
      inputStream1 = inputStream2;
      Log.d("ImageHeaderParser", iOException.getMessage(), iOException);
      if (inputStream2 != null) {
        inputStream2.close();
        return;
      } 
    } finally {}
  }
  
  public static void d(Context paramContext, androidx.exifinterface.media.a parama, int paramInt1, int paramInt2, Uri paramUri) {
    if (paramContext == null) {
      Log.d("ImageHeaderParser", "context is null");
      return;
    } 
    ParcelFileDescriptor parcelFileDescriptor2 = null;
    ParcelFileDescriptor parcelFileDescriptor1 = null;
    try {
      ParcelFileDescriptor parcelFileDescriptor = paramContext.getContentResolver().openFileDescriptor(paramUri, "rw");
      parcelFileDescriptor1 = parcelFileDescriptor;
      parcelFileDescriptor2 = parcelFileDescriptor;
      f(parama, new androidx.exifinterface.media.a(parcelFileDescriptor.getFileDescriptor()), paramInt1, paramInt2);
      try {
        parcelFileDescriptor.close();
        return;
      } catch (IOException iOException) {
        Log.d("ImageHeaderParser", iOException.getMessage(), iOException);
      } 
    } catch (IOException iOException) {
      parcelFileDescriptor1 = parcelFileDescriptor2;
      Log.d("ImageHeaderParser", iOException.getMessage());
      if (parcelFileDescriptor2 != null) {
        parcelFileDescriptor2.close();
        return;
      } 
    } finally {}
  }
  
  public static void e(androidx.exifinterface.media.a parama, int paramInt1, int paramInt2, String paramString) {
    try {
      f(parama, new androidx.exifinterface.media.a(paramString), paramInt1, paramInt2);
      return;
    } catch (IOException iOException) {
      Log.d("ImageHeaderParser", iOException.getMessage());
      return;
    } 
  }
  
  private static void f(androidx.exifinterface.media.a parama1, androidx.exifinterface.media.a parama2, int paramInt1, int paramInt2) {
    int i;
    for (i = 0; i < 22; i++) {
      (new String[22])[0] = "FNumber";
      (new String[22])[1] = "DateTime";
      (new String[22])[2] = "DateTimeDigitized";
      (new String[22])[3] = "ExposureTime";
      (new String[22])[4] = "Flash";
      (new String[22])[5] = "FocalLength";
      (new String[22])[6] = "GPSAltitude";
      (new String[22])[7] = "GPSAltitudeRef";
      (new String[22])[8] = "GPSDateStamp";
      (new String[22])[9] = "GPSLatitude";
      (new String[22])[10] = "GPSLatitudeRef";
      (new String[22])[11] = "GPSLongitude";
      (new String[22])[12] = "GPSLongitudeRef";
      (new String[22])[13] = "GPSProcessingMethod";
      (new String[22])[14] = "GPSTimeStamp";
      (new String[22])[15] = "PhotographicSensitivity";
      (new String[22])[16] = "Make";
      (new String[22])[17] = "Model";
      (new String[22])[18] = "SubSecTime";
      (new String[22])[19] = "SubSecTimeDigitized";
      (new String[22])[20] = "SubSecTimeOriginal";
      (new String[22])[21] = "WhiteBalance";
      String str1 = (new String[22])[i];
      String str2 = parama1.d(str1);
      if (!TextUtils.isEmpty(str2))
        parama2.U(str1, str2); 
    } 
    parama2.U("ImageWidth", String.valueOf(paramInt1));
    parama2.U("ImageLength", String.valueOf(paramInt2));
    parama2.U("Orientation", "0");
    parama2.Q();
  }
  
  private static boolean h(int paramInt) {
    return ((paramInt & 0xFFD8) == 65496 || paramInt == 19789 || paramInt == 18761);
  }
  
  private boolean i(byte[] paramArrayOfbyte, int paramInt) {
    boolean bool;
    if (paramArrayOfbyte != null && paramInt > b.length) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      paramInt = 0;
      while (true) {
        byte[] arrayOfByte = b;
        if (paramInt < arrayOfByte.length) {
          if (paramArrayOfbyte[paramInt] != arrayOfByte[paramInt])
            return false; 
          paramInt++;
          continue;
        } 
        break;
      } 
    } 
    return bool;
  }
  
  private int j() {
    while (true) {
      short s = this.a.c();
      if (s != 255) {
        if (Log.isLoggable("ImageHeaderParser", 3)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown segmentId=");
          stringBuilder.append(s);
          Log.d("ImageHeaderParser", stringBuilder.toString());
        } 
        return -1;
      } 
      s = this.a.c();
      if (s == 218)
        return -1; 
      if (s == 217) {
        if (Log.isLoggable("ImageHeaderParser", 3))
          Log.d("ImageHeaderParser", "Found MARKER_EOI in exif segment"); 
        return -1;
      } 
      int i = this.a.a() - 2;
      if (s != 225) {
        b b1 = this.a;
        long l1 = i;
        long l2 = b1.skip(l1);
        if (l2 != l1) {
          if (Log.isLoggable("ImageHeaderParser", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to skip enough data, type: ");
            stringBuilder.append(s);
            stringBuilder.append(", wanted to skip: ");
            stringBuilder.append(i);
            stringBuilder.append(", but actually skipped: ");
            stringBuilder.append(l2);
            Log.d("ImageHeaderParser", stringBuilder.toString());
          } 
          return -1;
        } 
        continue;
      } 
      return i;
    } 
  }
  
  private static int k(a parama) {
    short s = parama.a(6);
    if (s != 19789) {
      int i;
      ByteOrder byteOrder1;
      if (s == 18761) {
        byteOrder1 = ByteOrder.LITTLE_ENDIAN;
      } else {
        if (Log.isLoggable("ImageHeaderParser", 3)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown endianness = ");
          stringBuilder.append(s);
          Log.d("ImageHeaderParser", stringBuilder.toString());
        } 
        byteOrder1 = ByteOrder.BIG_ENDIAN;
      } 
      parama.d(byteOrder1);
      int j = parama.b(10) + 6;
      short s1 = parama.a(j);
      s = 0;
      while (true) {
        short s2;
        String str1;
        String str2;
        if (i < s1) {
          int k = a(j, i);
          short s3 = parama.a(k);
          if (s3 != 274)
            continue; 
          s2 = parama.a(k + 2);
          if (s2 < 1 || s2 > 12) {
            if (Log.isLoggable("ImageHeaderParser", 3)) {
              StringBuilder stringBuilder = new StringBuilder();
              str2 = "Got invalid format code = ";
            } else {
              continue;
            } 
          } else {
            int m = parama.b(k + 4);
            if (m < 0) {
              if (Log.isLoggable("ImageHeaderParser", 3)) {
                str1 = "Negative tiff component count";
              } else {
                continue;
              } 
            } else {
              if (Log.isLoggable("ImageHeaderParser", 3)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Got tagIndex=");
                stringBuilder.append(i);
                stringBuilder.append(" tagType=");
                stringBuilder.append(s3);
                stringBuilder.append(" formatCode=");
                stringBuilder.append(s2);
                stringBuilder.append(" componentCount=");
                stringBuilder.append(m);
                Log.d("ImageHeaderParser", stringBuilder.toString());
              } 
              m += c[s2];
              if (m > 4) {
                if (Log.isLoggable("ImageHeaderParser", 3)) {
                  StringBuilder stringBuilder = new StringBuilder();
                  str2 = "Got byte count > 4, not orientation, continuing, formatCode=";
                } else {
                  continue;
                } 
              } else {
                k += 8;
                if (k < 0 || k > parama.c()) {
                  if (Log.isLoggable("ImageHeaderParser", 3)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Illegal tagValueOffset=");
                    stringBuilder.append(k);
                    stringBuilder.append(" tagType=");
                    stringBuilder.append(s3);
                    str1 = stringBuilder.toString();
                  } else {
                    continue;
                  } 
                } else {
                  StringBuilder stringBuilder;
                  if (m < 0 || m + k > parama.c()) {
                    if (Log.isLoggable("ImageHeaderParser", 3)) {
                      stringBuilder = new StringBuilder();
                      stringBuilder.append("Illegal number of bytes for TI tag data tagType=");
                      stringBuilder.append(s3);
                    } else {
                      continue;
                    } 
                  } else {
                    return parama.a(k);
                  } 
                  str1 = stringBuilder.toString();
                } 
                Log.d("ImageHeaderParser", str1);
              } 
              str1.append(str2);
              str1.append(s2);
            } 
            Log.d("ImageHeaderParser", str1);
          } 
        } else {
          break;
        } 
        str1.append(str2);
        str1.append(s2);
        i = s + 1;
      } 
      return -1;
    } 
    ByteOrder byteOrder = ByteOrder.BIG_ENDIAN;
  }
  
  private int l(byte[] paramArrayOfbyte, int paramInt) {
    StringBuilder stringBuilder;
    int i = this.a.b(paramArrayOfbyte, paramInt);
    if (i != paramInt) {
      if (Log.isLoggable("ImageHeaderParser", 3)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to read exif segment data, length: ");
        stringBuilder.append(paramInt);
        stringBuilder.append(", actually read: ");
        stringBuilder.append(i);
        Log.d("ImageHeaderParser", stringBuilder.toString());
      } 
      return -1;
    } 
    if (i((byte[])stringBuilder, paramInt))
      return k(new a((byte[])stringBuilder, paramInt)); 
    if (Log.isLoggable("ImageHeaderParser", 3))
      Log.d("ImageHeaderParser", "Missing jpeg exif preamble"); 
    return -1;
  }
  
  public int g() {
    int i = this.a.a();
    if (!h(i)) {
      if (Log.isLoggable("ImageHeaderParser", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Parser doesn't handle magic number: ");
        stringBuilder.append(i);
        Log.d("ImageHeaderParser", stringBuilder.toString());
      } 
      return -1;
    } 
    i = j();
    if (i == -1) {
      if (Log.isLoggable("ImageHeaderParser", 3))
        Log.d("ImageHeaderParser", "Failed to parse exif segment length, or exif segment not found"); 
      return -1;
    } 
    return l(new byte[i], i);
  }
  
  private static class a {
    private final ByteBuffer a;
    
    public a(byte[] param1ArrayOfbyte, int param1Int) {
      this.a = (ByteBuffer)ByteBuffer.wrap(param1ArrayOfbyte).order(ByteOrder.BIG_ENDIAN).limit(param1Int);
    }
    
    public short a(int param1Int) {
      return this.a.getShort(param1Int);
    }
    
    public int b(int param1Int) {
      return this.a.getInt(param1Int);
    }
    
    public int c() {
      return this.a.remaining();
    }
    
    public void d(ByteOrder param1ByteOrder) {
      this.a.order(param1ByteOrder);
    }
  }
  
  private static interface b {
    int a();
    
    int b(byte[] param1ArrayOfbyte, int param1Int);
    
    short c();
    
    long skip(long param1Long);
  }
  
  private static class c implements b {
    private final InputStream a;
    
    public c(InputStream param1InputStream) {
      this.a = param1InputStream;
    }
    
    public int a() {
      return this.a.read() << 8 & 0xFF00 | this.a.read() & 0xFF;
    }
    
    public int b(byte[] param1ArrayOfbyte, int param1Int) {
      int i = param1Int;
      while (i > 0) {
        int j = this.a.read(param1ArrayOfbyte, param1Int - i, i);
        if (j != -1)
          i -= j; 
      } 
      return param1Int - i;
    }
    
    public short c() {
      return (short)(this.a.read() & 0xFF);
    }
    
    public long skip(long param1Long) {
      if (param1Long < 0L)
        return 0L; 
      long l;
      for (l = param1Long; l > 0L; l -= l1) {
        long l1 = this.a.skip(l);
        if (l1 <= 0L) {
          if (this.a.read() == -1)
            break; 
          l1 = 1L;
        } 
      } 
      return param1Long - l;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a9\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */