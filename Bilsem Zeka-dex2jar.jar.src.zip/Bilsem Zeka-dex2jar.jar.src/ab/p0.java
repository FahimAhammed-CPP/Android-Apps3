package ab;

import ga.o;
import ja.d;

public final class p0 {
  public static final String a(Object paramObject) {
    return paramObject.getClass().getSimpleName();
  }
  
  public static final String b(Object paramObject) {
    return Integer.toHexString(System.identityHashCode(paramObject));
  }
  
  public static final String c(d<?> paramd) {
    Object object;
    if (paramd instanceof kotlinx.coroutines.internal.f)
      return paramd.toString(); 
    try {
      o.a a = o.a;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramd);
      stringBuilder.append('@');
      stringBuilder.append(b(paramd));
      object = o.a(stringBuilder.toString());
    } finally {
      Exception exception = null;
      o.a a = o.a;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\p0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */