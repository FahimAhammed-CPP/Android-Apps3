package ab;

public interface v<T> extends s0<T> {
  boolean F(Throwable paramThrowable);
  
  boolean H(T paramT);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */