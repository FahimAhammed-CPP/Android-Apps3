package ab;

import ja.d;
import ja.e;
import ja.g;
import ja.h;
import kotlin.coroutines.jvm.internal.e;
import kotlin.jvm.internal.m;
import kotlin.jvm.internal.v;
import qa.p;

public final class g0 {
  private static final g a(g paramg1, g paramg2, boolean paramBoolean) {
    boolean bool1 = c(paramg1);
    boolean bool2 = c(paramg2);
    if (!bool1 && !bool2)
      return paramg1.q(paramg2); 
    v<g> v = new v();
    v.a = paramg2;
    h h = h.a;
    paramg1 = (g)paramg1.h(h, new b(v, paramBoolean));
    if (bool2)
      v.a = ((g)v.a).h(h, a.a); 
    return paramg1.q((g)v.a);
  }
  
  public static final String b(g paramg) {
    return null;
  }
  
  private static final boolean c(g paramg) {
    return ((Boolean)paramg.h(Boolean.FALSE, c.a)).booleanValue();
  }
  
  public static final g d(l0 paraml0, g paramg) {
    paramg = a(paraml0.k(), paramg, true);
    g g1 = paramg;
    if (paramg != z0.a()) {
      g1 = paramg;
      if (paramg.b((g.c)e.U) == null)
        g1 = paramg.q((g)z0.a()); 
    } 
    return g1;
  }
  
  public static final g e(g paramg1, g paramg2) {
    return !c(paramg2) ? paramg1.q(paramg2) : a(paramg1, paramg2, false);
  }
  
  public static final q2<?> f(e parame) {
    while (true) {
      if (parame instanceof v0)
        return null; 
      e e1 = parame.getCallerFrame();
      if (e1 == null)
        return null; 
      parame = e1;
      if (e1 instanceof q2)
        return (q2)e1; 
    } 
  }
  
  public static final q2<?> g(d<?> paramd, g paramg, Object paramObject) {
    boolean bool;
    if (!(paramd instanceof e))
      return null; 
    if (paramg.b(r2.a) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool)
      return null; 
    q2<?> q2 = f((e)paramd);
    if (q2 != null)
      q2.O0(paramg, paramObject); 
    return q2;
  }
  
  static final class a extends m implements p<g, g.b, g> {
    public static final a a = new a();
    
    a() {
      super(2);
    }
    
    public final g a(g param1g, g.b param1b) {
      return (param1b instanceof f0) ? param1g.q((g)((f0)param1b).C()) : param1g.q((g)param1b);
    }
  }
  
  static final class b extends m implements p<g, g.b, g> {
    b(v<g> param1v, boolean param1Boolean) {
      super(2);
    }
    
    public final g a(g param1g, g.b param1b) {
      if (!(param1b instanceof f0))
        return param1g.q((g)param1b); 
      g.b b1 = ((g)this.a.a).b(param1b.getKey());
      if (b1 == null) {
        boolean bool = this.b;
        b1 = param1b;
        param1b = b1;
        if (bool)
          param1b = b1.C(); 
        return param1g.q((g)param1b);
      } 
      v<g> v1 = this.a;
      v1.a = ((g)v1.a).J(param1b.getKey());
      return param1g.q(((f0)param1b).z(b1));
    }
  }
  
  static final class c extends m implements p<Boolean, g.b, Boolean> {
    public static final c a = new c();
    
    c() {
      super(2);
    }
    
    public final Boolean a(boolean param1Boolean, g.b param1b) {
      if (param1Boolean || param1b instanceof f0) {
        param1Boolean = true;
        return Boolean.valueOf(param1Boolean);
      } 
      param1Boolean = false;
      return Boolean.valueOf(param1Boolean);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\g0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */