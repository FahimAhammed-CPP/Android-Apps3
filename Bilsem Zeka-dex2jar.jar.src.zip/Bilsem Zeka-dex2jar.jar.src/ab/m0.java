package ab;

import ja.g;
import java.util.concurrent.CancellationException;
import kotlinx.coroutines.internal.e;

public final class m0 {
  public static final l0 a(g paramg) {
    if (paramg.b(t1.K) == null)
      paramg = paramg.q((g)x1.b(null, 1, null)); 
    return (l0)new e(paramg);
  }
  
  public static final void b(l0 paraml0, CancellationException paramCancellationException) {
    t1 t1 = (t1)paraml0.k().b(t1.K);
    if (t1 != null) {
      t1.Q(paramCancellationException);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Scope cannot be cancelled because it does not have a job: ");
    stringBuilder.append(paraml0);
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public static final void d(l0 paraml0) {
    x1.e(paraml0.k());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\m0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */