package ab;

import ja.g;
import qa.p;

final class r2 implements g.b, g.c<r2> {
  public static final r2 a = new r2();
  
  public g J(g.c<?> paramc) {
    return g.b.a.c(this, paramc);
  }
  
  public <E extends g.b> E b(g.c<E> paramc) {
    return (E)g.b.a.b(this, paramc);
  }
  
  public g.c<?> getKey() {
    return this;
  }
  
  public <R> R h(R paramR, p<? super R, ? super g.b, ? extends R> paramp) {
    return (R)g.b.a.a(this, paramR, paramp);
  }
  
  public g q(g paramg) {
    return g.b.a.d(this, paramg);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\r2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */