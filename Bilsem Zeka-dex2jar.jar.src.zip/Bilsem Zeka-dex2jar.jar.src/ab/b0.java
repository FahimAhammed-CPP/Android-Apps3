package ab;

import ga.u;
import kotlin.jvm.internal.l;
import qa.l;

public final class b0 {
  public final Object a;
  
  public final l<Throwable, u> b;
  
  public b0(Object paramObject, l<? super Throwable, u> paraml) {
    this.a = paramObject;
    this.b = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof b0))
      return false; 
    paramObject = paramObject;
    return !l.b(this.a, ((b0)paramObject).a) ? false : (!!l.b(this.b, ((b0)paramObject).b));
  }
  
  public int hashCode() {
    int i;
    Object object = this.a;
    if (object == null) {
      i = 0;
    } else {
      i = object.hashCode();
    } 
    return i * 31 + this.b.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CompletedWithCancellation(result=");
    stringBuilder.append(this.a);
    stringBuilder.append(", onCancellation=");
    stringBuilder.append(this.b);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */