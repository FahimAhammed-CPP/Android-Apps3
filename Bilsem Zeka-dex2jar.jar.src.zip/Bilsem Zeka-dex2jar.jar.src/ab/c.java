package ab;

public final class c {
  static {
  
  }
  
  public static final b a() {
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */