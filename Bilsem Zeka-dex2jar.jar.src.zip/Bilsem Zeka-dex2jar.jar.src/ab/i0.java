package ab;

import ja.g;

public interface i0 extends g.b {
  public static final a J = a.a;
  
  void f(g paramg, Throwable paramThrowable);
  
  public static final class a implements g.c<i0> {}
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */