package ab;

import ga.o;
import ga.p;
import ga.u;

final class j2<T> extends z1 {
  private final n<T> e;
  
  public j2(n<? super T> paramn) {
    this.e = (n)paramn;
  }
  
  public void B(Throwable paramThrowable) {
    n<T> n1;
    Object object = C().d0();
    if (object instanceof a0) {
      n1 = this.e;
      o.a a = o.a;
      object = p.a(((a0)object).a);
    } else {
      n1 = this.e;
      o.a a = o.a;
      object = b2.h(object);
    } 
    n1.resumeWith(o.a(object));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\j2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */