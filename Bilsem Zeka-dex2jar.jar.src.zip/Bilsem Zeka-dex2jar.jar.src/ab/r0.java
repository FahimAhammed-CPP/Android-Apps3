package ab;

import kotlinx.coroutines.internal.c0;
import kotlinx.coroutines.internal.t;

public final class r0 {
  private static final boolean a = c0.e("kotlinx.coroutines.main.delay", false);
  
  private static final t0 b = b();
  
  public static final t0 a() {
    return b;
  }
  
  private static final t0 b() {
    if (!a)
      return q0.h; 
    d2 d2 = z0.c();
    return (t.c(d2) || !(d2 instanceof t0)) ? q0.h : (t0)d2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\r0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */