package ab;

import ja.g;
import java.util.concurrent.CancellationException;

public final class x1 {
  public static final y a(t1 paramt1) {
    return y1.a(paramt1);
  }
  
  public static final void c(g paramg, CancellationException paramCancellationException) {
    y1.c(paramg, paramCancellationException);
  }
  
  public static final void d(t1 paramt1) {
    y1.d(paramt1);
  }
  
  public static final void e(g paramg) {
    y1.e(paramg);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\x1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */