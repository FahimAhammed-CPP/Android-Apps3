package ab;

public interface a1 {
  void f();
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\a1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */