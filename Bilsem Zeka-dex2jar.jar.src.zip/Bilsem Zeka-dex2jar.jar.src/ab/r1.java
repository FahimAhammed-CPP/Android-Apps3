package ab;

import ga.u;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import qa.l;

final class r1 extends v1 {
  private final l<Throwable, u> e;
  
  public r1(l<? super Throwable, u> paraml) {
    this.e = (l)paraml;
    this._invoked = 0;
  }
  
  public void B(Throwable paramThrowable) {
    if (f.compareAndSet(this, 0, 1))
      this.e.invoke(paramThrowable); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\r1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */