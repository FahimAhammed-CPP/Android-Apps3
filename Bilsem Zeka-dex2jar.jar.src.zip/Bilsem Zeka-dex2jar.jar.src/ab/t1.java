package ab;

import ga.u;
import ja.g;
import java.util.concurrent.CancellationException;
import qa.l;
import qa.p;

public interface t1 extends g.b {
  public static final b K = b.a;
  
  a1 D(l<? super Throwable, u> paraml);
  
  a1 P(boolean paramBoolean1, boolean paramBoolean2, l<? super Throwable, u> paraml);
  
  void Q(CancellationException paramCancellationException);
  
  boolean a();
  
  CancellationException m();
  
  s n(u paramu);
  
  boolean start();
  
  public static final class a {
    public static <R> R b(t1 param1t1, R param1R, p<? super R, ? super g.b, ? extends R> param1p) {
      return (R)g.b.a.a(param1t1, param1R, param1p);
    }
    
    public static <E extends g.b> E c(t1 param1t1, g.c<E> param1c) {
      return (E)g.b.a.b(param1t1, param1c);
    }
    
    public static g e(t1 param1t1, g.c<?> param1c) {
      return g.b.a.c(param1t1, param1c);
    }
    
    public static g f(t1 param1t1, g param1g) {
      return g.b.a.d(param1t1, param1g);
    }
  }
  
  public static final class b implements g.c<t1> {}
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\t1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */