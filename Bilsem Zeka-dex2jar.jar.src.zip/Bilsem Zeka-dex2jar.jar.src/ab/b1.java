package ab;

import ga.u;

final class b1 extends k {
  private final a1 a;
  
  public b1(a1 parama1) {
    this.a = parama1;
  }
  
  public void a(Throwable paramThrowable) {
    this.a.f();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DisposeOnCancel[");
    stringBuilder.append(this.a);
    stringBuilder.append(']');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\b1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */