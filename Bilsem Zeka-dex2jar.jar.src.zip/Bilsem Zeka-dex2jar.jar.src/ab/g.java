package ab;

public final class g extends e1 {
  private final Thread h;
  
  public g(Thread paramThread) {
    this.h = paramThread;
  }
  
  protected Thread l0() {
    return this.h;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */