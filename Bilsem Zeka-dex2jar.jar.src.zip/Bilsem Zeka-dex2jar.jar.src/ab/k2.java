package ab;

import ga.u;
import ja.g;

class k2 extends a<u> {
  public k2(g paramg, boolean paramBoolean) {
    super(paramg, true, paramBoolean);
  }
  
  protected boolean e0(Throwable paramThrowable) {
    k0.a(getContext(), paramThrowable);
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\k2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */