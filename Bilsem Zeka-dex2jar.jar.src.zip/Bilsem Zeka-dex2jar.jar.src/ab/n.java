package ab;

import androidx.concurrent.futures.b;
import ga.e;
import ga.u;
import ja.d;
import ja.g;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import ka.b;
import kotlin.coroutines.jvm.internal.e;
import kotlinx.coroutines.internal.b0;
import kotlinx.coroutines.internal.f;
import qa.l;

public class n<T> extends w0<T> implements m<T>, e {
  private final d<T> d;
  
  private final g e;
  
  private a1 f;
  
  public n(d<? super T> paramd, int paramInt) {
    super(paramInt);
    this.d = (d)paramd;
    this.e = paramd.getContext();
    this._decision = 0;
    this._state = d.a;
  }
  
  private final a1 A() {
    t1 t1 = (t1)getContext().b(t1.K);
    if (t1 == null)
      return null; 
    a1 a11 = t1.a.d(t1, true, false, new r(this), 2, null);
    this.f = a11;
    return a11;
  }
  
  private final boolean C() {
    return (x0.c(this.c) && ((f)this.d).p());
  }
  
  private final k D(l<? super Throwable, u> paraml) {
    return (paraml instanceof k) ? (k)paraml : new q1(paraml);
  }
  
  private final void E(l<? super Throwable, u> paraml, Object paramObject) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("It's prohibited to register multiple handlers, tried to register ");
    stringBuilder.append(paraml);
    stringBuilder.append(", already has ");
    stringBuilder.append(paramObject);
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  private final void H() {
    d<T> d1 = this.d;
    if (d1 instanceof f) {
      f f = (f)d1;
    } else {
      d1 = null;
    } 
    if (d1 != null) {
      Throwable throwable = d1.t(this);
      if (throwable == null)
        return; 
      s();
      l(throwable);
    } 
  }
  
  private final void J(Object paramObject, int paramInt, l<? super Throwable, u> paraml) {
    while (true) {
      Object object = this._state;
      if (object instanceof g2) {
        Object object1 = L((g2)object, paramObject, paramInt, paraml, null);
        if (b.a(h, this, object, object1)) {
          t();
          u(paramInt);
          return;
        } 
        continue;
      } 
      if (object instanceof q) {
        object = object;
        if (object.c()) {
          if (paraml != null)
            p(paraml, ((a0)object).a); 
          return;
        } 
      } 
      k(paramObject);
      throw new e();
    } 
  }
  
  private final Object L(g2 paramg2, Object paramObject1, int paramInt, l<? super Throwable, u> paraml, Object paramObject2) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof ab/a0
    //   4: ifeq -> 9
    //   7: aload_2
    //   8: areturn
    //   9: iload_3
    //   10: invokestatic b : (I)Z
    //   13: ifne -> 23
    //   16: aload #5
    //   18: ifnonnull -> 23
    //   21: aload_2
    //   22: areturn
    //   23: aload #4
    //   25: ifnonnull -> 50
    //   28: aload_1
    //   29: instanceof ab/k
    //   32: ifeq -> 42
    //   35: aload_1
    //   36: instanceof ab/e
    //   39: ifeq -> 50
    //   42: aload_2
    //   43: astore #6
    //   45: aload #5
    //   47: ifnull -> 86
    //   50: aload_1
    //   51: instanceof ab/k
    //   54: ifeq -> 65
    //   57: aload_1
    //   58: checkcast ab/k
    //   61: astore_1
    //   62: goto -> 67
    //   65: aconst_null
    //   66: astore_1
    //   67: new ab/z
    //   70: dup
    //   71: aload_2
    //   72: aload_1
    //   73: aload #4
    //   75: aload #5
    //   77: aconst_null
    //   78: bipush #16
    //   80: aconst_null
    //   81: invokespecial <init> : (Ljava/lang/Object;Lab/k;Lqa/l;Ljava/lang/Object;Ljava/lang/Throwable;ILkotlin/jvm/internal/g;)V
    //   84: astore #6
    //   86: aload #6
    //   88: areturn
  }
  
  private final boolean M() {
    while (true) {
      int i = this._decision;
      if (i != 0) {
        if (i == 1)
          return false; 
        throw new IllegalStateException("Already resumed".toString());
      } 
      if (g.compareAndSet(this, 0, 2))
        return true; 
    } 
  }
  
  private final b0 N(Object<? super Throwable, u> paramObject1, Object paramObject2, l<? super Throwable, u> paraml) {
    while (true) {
      b0 b0;
      Object object = this._state;
      if (object instanceof g2) {
        Object object1 = L((g2)object, paramObject1, this.c, paraml, paramObject2);
        if (b.a(h, this, object, object1)) {
          t();
          return o.a;
        } 
        continue;
      } 
      boolean bool = object instanceof z;
      paraml = null;
      paramObject1 = (Object<? super Throwable, u>)paraml;
      if (bool) {
        l<? super Throwable, u> l1 = paraml;
        if (paramObject2 != null) {
          l1 = paraml;
          if (((z)object).d == paramObject2)
            b0 = o.a; 
        } 
      } 
      return b0;
    } 
  }
  
  private final boolean O() {
    while (true) {
      int i = this._decision;
      if (i != 0) {
        if (i == 2)
          return false; 
        throw new IllegalStateException("Already suspended".toString());
      } 
      if (g.compareAndSet(this, 0, 1))
        return true; 
    } 
  }
  
  private final Void k(Object paramObject) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Already resumed, but proposed with update ");
    stringBuilder.append(paramObject);
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  private final void n(l<? super Throwable, u> paraml, Throwable paramThrowable) {
    try {
      return;
    } finally {
      paraml = null;
      g g1 = getContext();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception in invokeOnCancellation handler for ");
      stringBuilder.append(this);
      k0.a(g1, new d0(stringBuilder.toString(), (Throwable)paraml));
    } 
  }
  
  private final boolean q(Throwable paramThrowable) {
    return !C() ? false : ((f)this.d).q(paramThrowable);
  }
  
  private final void t() {
    if (!C())
      s(); 
  }
  
  private final void u(int paramInt) {
    if (M())
      return; 
    x0.a(this, paramInt);
  }
  
  private final String y() {
    Object object = x();
    return (object instanceof g2) ? "Active" : ((object instanceof q) ? "Cancelled" : "Completed");
  }
  
  public boolean B() {
    return x() instanceof g2 ^ true;
  }
  
  protected String F() {
    return "CancellableContinuation";
  }
  
  public final void G(Throwable paramThrowable) {
    if (q(paramThrowable))
      return; 
    l(paramThrowable);
    t();
  }
  
  public final boolean I() {
    Object object = this._state;
    if (object instanceof z && ((z)object).d != null) {
      s();
      return false;
    } 
    this._decision = 0;
    this._state = d.a;
    return true;
  }
  
  public void a(Object paramObject, Throwable paramThrowable) {
    while (true) {
      paramObject = this._state;
      if (!(paramObject instanceof g2)) {
        if (paramObject instanceof a0)
          return; 
        if (paramObject instanceof z) {
          z z = (z)paramObject;
          if ((z.c() ^ true) != 0) {
            z z1 = z.b(z, null, null, null, null, paramThrowable, 15, null);
            if (b.a(h, this, paramObject, z1)) {
              z.d(this, paramThrowable);
              return;
            } 
            continue;
          } 
          throw new IllegalStateException("Must be called at most once".toString());
        } 
        if (b.a(h, this, paramObject, new z(paramObject, null, null, null, paramThrowable, 14, null)))
          return; 
        continue;
      } 
      throw new IllegalStateException("Not completed".toString());
    } 
  }
  
  public final d<T> b() {
    return this.d;
  }
  
  public Object c(T paramT, Object paramObject) {
    return N(paramT, paramObject, null);
  }
  
  public Throwable d(Object paramObject) {
    paramObject = super.d(paramObject);
    return (Throwable)((paramObject != null) ? paramObject : null);
  }
  
  public void e(l<? super Throwable, u> paraml) {
    k k = D(paraml);
    while (true) {
      a0 a0;
      Object object = this._state;
      if (object instanceof d) {
        if (b.a(h, this, object, k))
          return; 
        continue;
      } 
      if (object instanceof k) {
        E(paraml, object);
        continue;
      } 
      boolean bool = object instanceof a0;
      if (bool) {
        a0 = (a0)object;
        if (!a0.b())
          E(paraml, object); 
        if (object instanceof q) {
          object = null;
          if (!bool)
            a0 = null; 
          if (a0 != null)
            object = a0.a; 
          n(paraml, (Throwable)object);
        } 
        return;
      } 
      if (object instanceof z) {
        z z1 = (z)object;
        if (z1.b != null)
          E(paraml, object); 
        if (a0 instanceof e)
          return; 
        if (z1.c()) {
          n(paraml, z1.e);
          return;
        } 
        z1 = z.b(z1, null, (k)a0, null, null, null, 29, null);
        if (b.a(h, this, object, z1))
          return; 
        continue;
      } 
      if (a0 instanceof e)
        return; 
      z z = new z(object, (k)a0, null, null, null, 28, null);
      if (b.a(h, this, object, z))
        break; 
    } 
  }
  
  public <T> T f(Object paramObject) {
    Object object = paramObject;
    if (paramObject instanceof z)
      object = ((z)paramObject).a; 
    return (T)object;
  }
  
  public void g(T paramT, l<? super Throwable, u> paraml) {
    J(paramT, this.c, paraml);
  }
  
  public e getCallerFrame() {
    d<T> d1 = this.d;
    return (d1 instanceof e) ? (e)d1 : null;
  }
  
  public g getContext() {
    return this.e;
  }
  
  public Object i() {
    return x();
  }
  
  public Object j(Throwable paramThrowable) {
    return N(new a0(paramThrowable, false, 2, null), null, null);
  }
  
  public boolean l(Throwable paramThrowable) {
    while (true) {
      Object object = this._state;
      if (!(object instanceof g2))
        return false; 
      boolean bool = object instanceof k;
      q q = new q(this, paramThrowable, bool);
      if (b.a(h, this, object, q)) {
        if (bool) {
          object = object;
        } else {
          object = null;
        } 
        if (object != null)
          m((k)object, paramThrowable); 
        t();
        u(this.c);
        return true;
      } 
    } 
  }
  
  public final void m(k paramk, Throwable paramThrowable) {
    try {
      return;
    } finally {
      paramk = null;
      g g1 = getContext();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception in invokeOnCancellation handler for ");
      stringBuilder.append(this);
      k0.a(g1, new d0(stringBuilder.toString(), (Throwable)paramk));
    } 
  }
  
  public Object o(T paramT, Object paramObject, l<? super Throwable, u> paraml) {
    return N(paramT, paramObject, paraml);
  }
  
  public final void p(l<? super Throwable, u> paraml, Throwable paramThrowable) {
    try {
      return;
    } finally {
      paraml = null;
      g g1 = getContext();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Exception in resume onCancellation handler for ");
      stringBuilder.append(this);
      k0.a(g1, new d0(stringBuilder.toString(), (Throwable)paraml));
    } 
  }
  
  public void r(Object paramObject) {
    u(this.c);
  }
  
  public void resumeWith(Object paramObject) {
    K(this, e0.b(paramObject, this), this.c, null, 4, null);
  }
  
  public final void s() {
    a1 a11 = this.f;
    if (a11 == null)
      return; 
    a11.f();
    this.f = f2.a;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(F());
    stringBuilder.append('(');
    stringBuilder.append(p0.c(this.d));
    stringBuilder.append("){");
    stringBuilder.append(y());
    stringBuilder.append("}@");
    stringBuilder.append(p0.b(this));
    return stringBuilder.toString();
  }
  
  public Throwable v(t1 paramt1) {
    return paramt1.m();
  }
  
  public final Object w() {
    boolean bool = C();
    if (O()) {
      if (this.f == null)
        A(); 
      if (bool)
        H(); 
      return b.c();
    } 
    if (bool)
      H(); 
    Object object = x();
    if (!(object instanceof a0)) {
      if (x0.b(this.c)) {
        t1 t1 = (t1)getContext().b(t1.K);
        if (t1 != null && !t1.a()) {
          CancellationException cancellationException = t1.m();
          a(object, cancellationException);
          throw cancellationException;
        } 
      } 
      return f(object);
    } 
    throw ((a0)object).a;
  }
  
  public final Object x() {
    return this._state;
  }
  
  public void z() {
    a1 a11 = A();
    if (a11 == null)
      return; 
    if (B()) {
      a11.f();
      this.f = f2.a;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */