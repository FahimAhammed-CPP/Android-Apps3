package ab;

import eb.b;
import ga.l;
import ja.d;
import ja.f;
import qa.p;

public enum n0 {
  a, b, c, d;
  
  public final <R, T> void f(p<? super R, ? super d<? super T>, ? extends Object> paramp, R paramR, d<? super T> paramd) {
    int i = a.a[ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i == 4)
            return; 
          throw new l();
        } 
        b.a(paramp, paramR, paramd);
        return;
      } 
      f.a(paramp, paramR, paramd);
      return;
    } 
    eb.a.d(paramp, paramR, paramd, null, 4, null);
  }
  
  public final boolean i() {
    return (this == b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */