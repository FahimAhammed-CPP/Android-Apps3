package ab;

import java.util.concurrent.CancellationException;
import kotlin.jvm.internal.l;

public final class u1 extends CancellationException {
  public final transient t1 a;
  
  public u1(String paramString, Throwable paramThrowable, t1 paramt1) {
    super(paramString);
    this.a = paramt1;
    if (paramThrowable != null)
      initCause(paramThrowable); 
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (paramObject instanceof u1) {
        paramObject = paramObject;
        if (l.b(paramObject.getMessage(), getMessage()) && l.b(((u1)paramObject).a, this.a) && l.b(paramObject.getCause(), getCause()))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  public Throwable fillInStackTrace() {
    setStackTrace(new StackTraceElement[0]);
    return this;
  }
  
  public int hashCode() {
    byte b;
    String str = getMessage();
    l.c(str);
    int i = str.hashCode();
    int j = this.a.hashCode();
    Throwable throwable = getCause();
    if (throwable != null) {
      b = throwable.hashCode();
    } else {
      b = 0;
    } 
    return (i * 31 + j) * 31 + b;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    stringBuilder.append("; job=");
    stringBuilder.append(this.a);
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a\\u1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */