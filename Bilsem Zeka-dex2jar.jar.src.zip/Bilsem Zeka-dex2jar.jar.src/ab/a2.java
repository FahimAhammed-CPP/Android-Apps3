package ab;

import ga.u;
import ja.g;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.coroutines.jvm.internal.h;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.v;
import kotlinx.coroutines.internal.b0;
import kotlinx.coroutines.internal.n;
import kotlinx.coroutines.internal.o;
import kotlinx.coroutines.internal.w;
import qa.l;
import qa.p;

public class a2 implements t1, u, h2 {
  public a2(boolean paramBoolean) {
    c1 c1;
    if (paramBoolean) {
      c1 = b2.c();
    } else {
      c1 = b2.d();
    } 
    this._state = c1;
    this._parentHandle = null;
  }
  
  private final Object A(ja.d<Object> paramd) {
    a<?> a = new a(ka.b.b(paramd), this);
    a.z();
    p.a(a, D(new j2(a)));
    Object object = a.w();
    if (object == ka.b.c())
      h.c(paramd); 
    return object;
  }
  
  private final boolean D0(o1 paramo1, Object paramObject) {
    if (!androidx.concurrent.futures.b.a(a, this, paramo1, b2.g(paramObject)))
      return false; 
    r0(null);
    s0(paramObject);
    S(paramo1, paramObject);
    return true;
  }
  
  private final boolean E0(o1 paramo1, Throwable paramThrowable) {
    e2 e2 = b0(paramo1);
    if (e2 == null)
      return false; 
    c c = new c(e2, false, paramThrowable);
    if (!androidx.concurrent.futures.b.a(a, this, paramo1, c))
      return false; 
    p0(e2, paramThrowable);
    return true;
  }
  
  private final Object F0(Object paramObject1, Object paramObject2) {
    return !(paramObject1 instanceof o1) ? b2.a() : (((paramObject1 instanceof c1 || paramObject1 instanceof z1) && !(paramObject1 instanceof t) && !(paramObject2 instanceof a0)) ? (D0((o1)paramObject1, paramObject2) ? paramObject2 : b2.b()) : G0((o1)paramObject1, paramObject2));
  }
  
  private final Object G0(o1 paramo1, Object paramObject) {
    c c1;
    e2 e2 = b0(paramo1);
    if (e2 == null)
      return b2.b(); 
    boolean bool = paramo1 instanceof c;
    c c3 = null;
    if (bool) {
      c1 = (c)paramo1;
    } else {
      c1 = null;
    } 
    bool = false;
    c c2 = c1;
    if (c1 == null)
      c2 = new c(e2, false, null); 
    synchronized (new v()) {
      b0 b0;
      Throwable throwable1;
      if (c2.h()) {
        b0 = b2.a();
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=InnerObjectType{ObjectType{ab/a2}.Lab/a2$c;}, name=null} */
        return b0;
      } 
      c2.k(true);
      if (c2 != b0 && !androidx.concurrent.futures.b.a(a, this, b0, c2)) {
        b0 = b2.b();
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=InnerObjectType{ObjectType{ab/a2}.Lab/a2$c;}, name=null} */
        return b0;
      } 
      boolean bool1 = c2.g();
      if (paramObject instanceof a0) {
        a0 a0 = (a0)paramObject;
      } else {
        c1 = null;
      } 
      if (c1 != null)
        c2.b(((a0)c1).a); 
      Throwable throwable2 = c2.f();
      if (!bool1)
        bool = true; 
      c1 = c3;
      if (Boolean.valueOf(bool).booleanValue())
        throwable1 = throwable2; 
      null.a = throwable1;
      u u1 = u.a;
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=InnerObjectType{ObjectType{ab/a2}.Lab/a2$c;}, name=null} */
      if (throwable1 != null)
        p0(e2, throwable1); 
      t t = W((o1)b0);
      return (t != null && H0(c2, t, paramObject)) ? b2.b : V(c2, paramObject);
    } 
  }
  
  private final boolean H0(c paramc, t paramt, Object paramObject) {
    while (true) {
      if (t1.a.d(paramt.e, false, false, new b(this, paramc, paramt, paramObject), 1, null) != f2.a)
        return true; 
      t t2 = o0(paramt);
      paramt = t2;
      if (t2 == null)
        return false; 
    } 
  }
  
  private final Object L(Object paramObject) {
    while (true) {
      Object object = d0();
      if (!(object instanceof o1) || (object instanceof c && ((c)object).h()))
        break; 
      object = F0(object, new a0(U(paramObject), false, 2, null));
      if (object != b2.b())
        return object; 
    } 
    return b2.a();
  }
  
  private final boolean N(Throwable paramThrowable) {
    boolean bool1 = i0();
    boolean bool = true;
    if (bool1)
      return true; 
    bool1 = paramThrowable instanceof CancellationException;
    s s = c0();
    if (s != null) {
      if (s == f2.a)
        return bool1; 
      if (!s.i(paramThrowable)) {
        if (bool1)
          return true; 
        bool = false;
      } 
      return bool;
    } 
    return bool1;
  }
  
  private final void S(o1 paramo1, Object paramObject) {
    Throwable throwable;
    StringBuilder stringBuilder;
    s s = c0();
    if (s != null) {
      s.f();
      x0(f2.a);
    } 
    boolean bool = paramObject instanceof a0;
    s = null;
    if (bool) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    if (paramObject != null)
      throwable = ((a0)paramObject).a; 
    if (paramo1 instanceof z1)
      try {
        return;
      } finally {
        paramObject = null;
        stringBuilder = new StringBuilder();
        stringBuilder.append("Exception in completion handler ");
        stringBuilder.append(paramo1);
        stringBuilder.append(" for ");
        stringBuilder.append(this);
        f0(new d0(stringBuilder.toString(), (Throwable)paramObject));
      }  
    paramo1 = paramo1.d();
    if (paramo1 != null)
      q0((e2)paramo1, (Throwable)stringBuilder); 
  }
  
  private final void T(c paramc, t paramt, Object paramObject) {
    paramt = o0(paramt);
    if (paramt != null && H0(paramc, paramt, paramObject))
      return; 
    w(V(paramc, paramObject));
  }
  
  private final Throwable U(Object paramObject) {
    boolean bool;
    if (paramObject == null) {
      bool = true;
    } else {
      bool = paramObject instanceof Throwable;
    } 
    if (bool) {
      Throwable throwable = (Throwable)paramObject;
      paramObject = throwable;
      if (throwable == null)
        return new u1(s(this), null, this); 
    } else {
      if (paramObject != null)
        return ((h2)paramObject).K(); 
      throw new NullPointerException("null cannot be cast to non-null type kotlinx.coroutines.ParentJob");
    } 
    return (Throwable)paramObject;
  }
  
  private final Object V(c paramc, Object paramObject) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof ab/a0
    //   4: ifeq -> 16
    //   7: aload_2
    //   8: checkcast ab/a0
    //   11: astore #5
    //   13: goto -> 19
    //   16: aconst_null
    //   17: astore #5
    //   19: aload #5
    //   21: ifnull -> 34
    //   24: aload #5
    //   26: getfield a : Ljava/lang/Throwable;
    //   29: astore #5
    //   31: goto -> 37
    //   34: aconst_null
    //   35: astore #5
    //   37: aload_1
    //   38: monitorenter
    //   39: aload_1
    //   40: invokevirtual g : ()Z
    //   43: istore #4
    //   45: aload_1
    //   46: aload #5
    //   48: invokevirtual j : (Ljava/lang/Throwable;)Ljava/util/List;
    //   51: astore #7
    //   53: aload_0
    //   54: aload_1
    //   55: aload #7
    //   57: invokespecial Y : (Lab/a2$c;Ljava/util/List;)Ljava/lang/Throwable;
    //   60: astore #6
    //   62: aload #6
    //   64: ifnull -> 75
    //   67: aload_0
    //   68: aload #6
    //   70: aload #7
    //   72: invokespecial v : (Ljava/lang/Throwable;Ljava/util/List;)V
    //   75: aload_1
    //   76: monitorexit
    //   77: iconst_0
    //   78: istore_3
    //   79: aload #6
    //   81: ifnonnull -> 87
    //   84: goto -> 110
    //   87: aload #6
    //   89: aload #5
    //   91: if_acmpne -> 97
    //   94: goto -> 110
    //   97: new ab/a0
    //   100: dup
    //   101: aload #6
    //   103: iconst_0
    //   104: iconst_2
    //   105: aconst_null
    //   106: invokespecial <init> : (Ljava/lang/Throwable;ZILkotlin/jvm/internal/g;)V
    //   109: astore_2
    //   110: aload #6
    //   112: ifnull -> 165
    //   115: aload_0
    //   116: aload #6
    //   118: invokespecial N : (Ljava/lang/Throwable;)Z
    //   121: ifne -> 133
    //   124: aload_0
    //   125: aload #6
    //   127: invokevirtual e0 : (Ljava/lang/Throwable;)Z
    //   130: ifeq -> 135
    //   133: iconst_1
    //   134: istore_3
    //   135: iload_3
    //   136: ifeq -> 165
    //   139: aload_2
    //   140: ifnull -> 154
    //   143: aload_2
    //   144: checkcast ab/a0
    //   147: invokevirtual b : ()Z
    //   150: pop
    //   151: goto -> 165
    //   154: new java/lang/NullPointerException
    //   157: dup
    //   158: ldc_w 'null cannot be cast to non-null type kotlinx.coroutines.CompletedExceptionally'
    //   161: invokespecial <init> : (Ljava/lang/String;)V
    //   164: athrow
    //   165: iload #4
    //   167: ifne -> 176
    //   170: aload_0
    //   171: aload #6
    //   173: invokevirtual r0 : (Ljava/lang/Throwable;)V
    //   176: aload_0
    //   177: aload_2
    //   178: invokevirtual s0 : (Ljava/lang/Object;)V
    //   181: getstatic ab/a2.a : Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;
    //   184: aload_0
    //   185: aload_1
    //   186: aload_2
    //   187: invokestatic g : (Ljava/lang/Object;)Ljava/lang/Object;
    //   190: invokestatic a : (Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
    //   193: pop
    //   194: aload_0
    //   195: aload_1
    //   196: aload_2
    //   197: invokespecial S : (Lab/o1;Ljava/lang/Object;)V
    //   200: aload_2
    //   201: areturn
    //   202: astore_2
    //   203: aload_1
    //   204: monitorexit
    //   205: aload_2
    //   206: athrow
    // Exception table:
    //   from	to	target	type
    //   39	62	202	finally
    //   67	75	202	finally
  }
  
  private final t W(o1 paramo1) {
    e2 e2;
    boolean bool = paramo1 instanceof t;
    o1 o11 = null;
    if (bool) {
      e2 = (e2)paramo1;
    } else {
      e2 = null;
    } 
    if (e2 == null) {
      e2 = paramo1.d();
      paramo1 = o11;
      if (e2 != null)
        return o0((o)e2); 
    } else {
      paramo1 = e2;
    } 
    return (t)paramo1;
  }
  
  private final Throwable X(Object paramObject) {
    boolean bool = paramObject instanceof a0;
    Throwable throwable = null;
    if (bool) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    if (paramObject != null)
      throwable = ((a0)paramObject).a; 
    return throwable;
  }
  
  private final Throwable Y(c paramc, List<? extends Throwable> paramList) {
    boolean bool = paramList.isEmpty();
    c c1 = null;
    if (bool)
      return paramc.g() ? new u1(s(this), null, this) : null; 
    Iterator<? extends Throwable> iterator = paramList.iterator();
    while (true) {
      paramc = c1;
      if (iterator.hasNext()) {
        paramc = (c)iterator.next();
        if (((Throwable)paramc instanceof CancellationException ^ true) != 0)
          break; 
        continue;
      } 
      break;
    } 
    Throwable throwable = (Throwable)paramc;
    return (throwable != null) ? throwable : paramList.get(0);
  }
  
  private final e2 b0(o1 paramo1) {
    StringBuilder stringBuilder;
    e2 e2 = paramo1.d();
    if (e2 == null) {
      if (paramo1 instanceof c1)
        return new e2(); 
      if (paramo1 instanceof z1) {
        v0((z1)paramo1);
        return null;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("State should have list: ");
      stringBuilder.append(paramo1);
      throw new IllegalStateException(stringBuilder.toString().toString());
    } 
    return (e2)stringBuilder;
  }
  
  private final Object j0(Object paramObject) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #5
    //   3: aconst_null
    //   4: astore_3
    //   5: aload_0
    //   6: invokevirtual d0 : ()Ljava/lang/Object;
    //   9: astore #6
    //   11: aload #6
    //   13: instanceof ab/a2$c
    //   16: ifeq -> 133
    //   19: aload #6
    //   21: monitorenter
    //   22: aload #6
    //   24: checkcast ab/a2$c
    //   27: invokevirtual i : ()Z
    //   30: ifeq -> 42
    //   33: invokestatic f : ()Lkotlinx/coroutines/internal/b0;
    //   36: astore_1
    //   37: aload #6
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: aload #6
    //   44: checkcast ab/a2$c
    //   47: invokevirtual g : ()Z
    //   50: istore_2
    //   51: aload_1
    //   52: ifnonnull -> 59
    //   55: iload_2
    //   56: ifne -> 83
    //   59: aload_3
    //   60: astore #4
    //   62: aload_3
    //   63: ifnonnull -> 73
    //   66: aload_0
    //   67: aload_1
    //   68: invokespecial U : (Ljava/lang/Object;)Ljava/lang/Throwable;
    //   71: astore #4
    //   73: aload #6
    //   75: checkcast ab/a2$c
    //   78: aload #4
    //   80: invokevirtual b : (Ljava/lang/Throwable;)V
    //   83: aload #6
    //   85: checkcast ab/a2$c
    //   88: invokevirtual f : ()Ljava/lang/Throwable;
    //   91: astore_3
    //   92: aload #5
    //   94: astore_1
    //   95: iload_2
    //   96: iconst_1
    //   97: ixor
    //   98: ifeq -> 103
    //   101: aload_3
    //   102: astore_1
    //   103: aload #6
    //   105: monitorexit
    //   106: aload_1
    //   107: ifnull -> 123
    //   110: aload_0
    //   111: aload #6
    //   113: checkcast ab/a2$c
    //   116: invokevirtual d : ()Lab/e2;
    //   119: aload_1
    //   120: invokespecial p0 : (Lab/e2;Ljava/lang/Throwable;)V
    //   123: invokestatic a : ()Lkotlinx/coroutines/internal/b0;
    //   126: areturn
    //   127: astore_1
    //   128: aload #6
    //   130: monitorexit
    //   131: aload_1
    //   132: athrow
    //   133: aload #6
    //   135: instanceof ab/o1
    //   138: ifeq -> 270
    //   141: aload_3
    //   142: astore #4
    //   144: aload_3
    //   145: ifnonnull -> 155
    //   148: aload_0
    //   149: aload_1
    //   150: invokespecial U : (Ljava/lang/Object;)Ljava/lang/Throwable;
    //   153: astore #4
    //   155: aload #6
    //   157: checkcast ab/o1
    //   160: astore #7
    //   162: aload #7
    //   164: invokeinterface a : ()Z
    //   169: ifeq -> 190
    //   172: aload #4
    //   174: astore_3
    //   175: aload_0
    //   176: aload #7
    //   178: aload #4
    //   180: invokespecial E0 : (Lab/o1;Ljava/lang/Throwable;)Z
    //   183: ifeq -> 5
    //   186: invokestatic a : ()Lkotlinx/coroutines/internal/b0;
    //   189: areturn
    //   190: aload_0
    //   191: aload #6
    //   193: new ab/a0
    //   196: dup
    //   197: aload #4
    //   199: iconst_0
    //   200: iconst_2
    //   201: aconst_null
    //   202: invokespecial <init> : (Ljava/lang/Throwable;ZILkotlin/jvm/internal/g;)V
    //   205: invokespecial F0 : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   208: astore #7
    //   210: aload #7
    //   212: invokestatic a : ()Lkotlinx/coroutines/internal/b0;
    //   215: if_acmpeq -> 232
    //   218: aload #4
    //   220: astore_3
    //   221: aload #7
    //   223: invokestatic b : ()Lkotlinx/coroutines/internal/b0;
    //   226: if_acmpeq -> 5
    //   229: aload #7
    //   231: areturn
    //   232: new java/lang/StringBuilder
    //   235: dup
    //   236: invokespecial <init> : ()V
    //   239: astore_1
    //   240: aload_1
    //   241: ldc_w 'Cannot happen in '
    //   244: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   247: pop
    //   248: aload_1
    //   249: aload #6
    //   251: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   254: pop
    //   255: new java/lang/IllegalStateException
    //   258: dup
    //   259: aload_1
    //   260: invokevirtual toString : ()Ljava/lang/String;
    //   263: invokevirtual toString : ()Ljava/lang/String;
    //   266: invokespecial <init> : (Ljava/lang/String;)V
    //   269: athrow
    //   270: invokestatic f : ()Lkotlinx/coroutines/internal/b0;
    //   273: areturn
    // Exception table:
    //   from	to	target	type
    //   22	37	127	finally
    //   42	51	127	finally
    //   66	73	127	finally
    //   73	83	127	finally
    //   83	92	127	finally
  }
  
  private final z1 m0(l<? super Throwable, u> paraml, boolean paramBoolean) {
    z1 z1 = null;
    v1 v1 = null;
    if (paramBoolean) {
      if (paraml instanceof v1)
        v1 = (v1)paraml; 
      z1 = v1;
      if (v1 == null)
        z1 = new r1(paraml); 
    } else {
      if (paraml instanceof z1)
        z1 = (z1)paraml; 
      if (z1 == null)
        z1 = new s1(paraml); 
    } 
    z1.D(this);
    return z1;
  }
  
  private final t o0(o paramo) {
    o o1;
    while (true) {
      o1 = paramo;
      if (paramo.v()) {
        paramo = paramo.s();
        continue;
      } 
      break;
    } 
    while (true) {
      paramo = o1.r();
      o1 = paramo;
      if (!paramo.v()) {
        if (paramo instanceof t)
          return (t)paramo; 
        o1 = paramo;
        if (paramo instanceof e2)
          return null; 
      } 
    } 
  }
  
  private final void p0(e2 parame2, Throwable paramThrowable) {
    d0 d0;
    r0(paramThrowable);
    o o = (o)parame2.q();
    z1 z1 = null;
    while (!l.b(o, parame2)) {
      d0 d01;
      z1 z11 = z1;
      if (o instanceof v1) {
        z11 = (z1)o;
        try {
          z11.B(paramThrowable);
        } finally {
          Exception exception = null;
        } 
      } 
      o = o.r();
      d0 = d01;
    } 
    if (d0 != null)
      f0(d0); 
    N(paramThrowable);
  }
  
  private final void q0(e2 parame2, Throwable paramThrowable) {
    d0 d0;
    o o = (o)parame2.q();
    z1 z1 = null;
    while (!l.b(o, parame2)) {
      d0 d01;
      z1 z11 = z1;
      if (o instanceof z1) {
        z11 = (z1)o;
        try {
          z11.B(paramThrowable);
        } finally {
          Exception exception = null;
        } 
      } 
      o = o.r();
      d0 = d01;
    } 
    if (d0 != null)
      f0(d0); 
  }
  
  private final boolean u(Object paramObject, e2 parame2, z1 paramz1) {
    boolean bool;
    paramObject = new d(paramz1, this, paramObject);
    while (true) {
      int i = parame2.s().A(paramz1, (o)parame2, (o.a)paramObject);
      bool = true;
      if (i != 1) {
        if (i != 2)
          continue; 
        bool = false;
      } 
      break;
    } 
    return bool;
  }
  
  private final void u0(c1 paramc1) {
    n1 n1;
    e2 e2 = new e2();
    if (!paramc1.a())
      n1 = new n1(e2); 
    androidx.concurrent.futures.b.a(a, this, paramc1, n1);
  }
  
  private final void v(Throwable paramThrowable, List<? extends Throwable> paramList) {
    if (paramList.size() <= 1)
      return; 
    Set<?> set = Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>(paramList.size()));
    for (Throwable throwable : paramList) {
      if (throwable != paramThrowable && throwable != paramThrowable && !(throwable instanceof CancellationException) && set.add(throwable))
        ga.a.a(paramThrowable, throwable); 
    } 
  }
  
  private final void v0(z1 paramz1) {
    paramz1.m((o)new e2());
    o o = paramz1.r();
    androidx.concurrent.futures.b.a(a, this, paramz1, o);
  }
  
  private final int y0(Object paramObject) {
    if (paramObject instanceof c1) {
      if (((c1)paramObject).a())
        return 0; 
      if (!androidx.concurrent.futures.b.a(a, this, paramObject, b2.c()))
        return -1; 
      t0();
      return 1;
    } 
    if (paramObject instanceof n1) {
      if (!androidx.concurrent.futures.b.a(a, this, paramObject, ((n1)paramObject).d()))
        return -1; 
      t0();
      return 1;
    } 
    return 0;
  }
  
  private final String z0(Object paramObject) {
    boolean bool = paramObject instanceof c;
    String str = "Active";
    if (bool) {
      c c = (c)paramObject;
      if (c.g())
        return "Cancelling"; 
      paramObject = str;
      if (c.h())
        return "Completing"; 
    } else {
      if (paramObject instanceof o1)
        return ((o1)paramObject).a() ? "Active" : "New"; 
      if (paramObject instanceof a0)
        return "Cancelled"; 
      paramObject = "Completed";
    } 
    return (String)paramObject;
  }
  
  protected final CancellationException A0(Throwable paramThrowable, String paramString) {
    String str1;
    u1 u1;
    if (paramThrowable instanceof CancellationException) {
      str1 = (String)paramThrowable;
    } else {
      str1 = null;
    } 
    String str2 = str1;
    if (str1 == null) {
      str1 = paramString;
      if (paramString == null)
        str1 = s(this); 
      u1 = new u1(str1, paramThrowable, this);
    } 
    return u1;
  }
  
  public final void B(h2 paramh2) {
    G(paramh2);
  }
  
  public final String C0() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(n0());
    stringBuilder.append('{');
    stringBuilder.append(z0(d0()));
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public final a1 D(l<? super Throwable, u> paraml) {
    return P(false, true, paraml);
  }
  
  public final boolean E(Throwable paramThrowable) {
    return G(paramThrowable);
  }
  
  public final boolean G(Object paramObject) {
    Object object1 = b2.a();
    if (a0()) {
      Object object = L(paramObject);
      object1 = object;
      if (object == b2.b)
        return true; 
    } 
    Object object2 = object1;
    if (object1 == b2.a())
      object2 = j0(paramObject); 
    if (object2 == b2.a())
      return true; 
    if (object2 == b2.b)
      return true; 
    if (object2 == b2.f())
      return false; 
    w(object2);
    return true;
  }
  
  public void I(Throwable paramThrowable) {
    G(paramThrowable);
  }
  
  public g J(g.c<?> paramc) {
    return t1.a.e(this, paramc);
  }
  
  public CancellationException K() {
    StringBuilder stringBuilder;
    Object object = d0();
    boolean bool = object instanceof c;
    CancellationException cancellationException1 = null;
    if (bool) {
      Throwable throwable = ((c)object).f();
    } else if (object instanceof a0) {
      Throwable throwable = ((a0)object).a;
    } else if (!(object instanceof o1)) {
      stringBuilder = null;
    } else {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot be cancelling child in this state: ");
      stringBuilder.append(object);
      throw new IllegalStateException(stringBuilder.toString().toString());
    } 
    if (stringBuilder instanceof CancellationException)
      cancellationException1 = (CancellationException)stringBuilder; 
    CancellationException cancellationException2 = cancellationException1;
    if (cancellationException1 == null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Parent job is ");
      stringBuilder1.append(z0(object));
      cancellationException2 = new u1(stringBuilder1.toString(), (Throwable)stringBuilder, this);
    } 
    return cancellationException2;
  }
  
  protected String O() {
    return "Job was cancelled";
  }
  
  public final a1 P(boolean paramBoolean1, boolean paramBoolean2, l<? super Throwable, u> paraml) {
    z1 z1 = m0(paraml, paramBoolean1);
    while (true) {
      Object object;
      while (true) {
        object = d0();
        break;
      } 
      if (u(object, (e2)SYNTHETIC_LOCAL_VARIABLE_11, z1))
        return z1; 
    } 
  }
  
  public void Q(CancellationException paramCancellationException) {
    CancellationException cancellationException = paramCancellationException;
    if (paramCancellationException == null)
      cancellationException = new u1(s(this), null, this); 
    I(cancellationException);
  }
  
  public boolean R(Throwable paramThrowable) {
    return (paramThrowable instanceof CancellationException) ? true : ((G(paramThrowable) && Z()));
  }
  
  public boolean Z() {
    return true;
  }
  
  public boolean a() {
    Object object = d0();
    return (object instanceof o1 && ((o1)object).a());
  }
  
  public boolean a0() {
    return false;
  }
  
  public <E extends g.b> E b(g.c<E> paramc) {
    return t1.a.c(this, paramc);
  }
  
  public final s c0() {
    return (s)this._parentHandle;
  }
  
  public final Object d0() {
    while (true) {
      Object object = this._state;
      if (!(object instanceof w))
        return object; 
      ((w)object).c(this);
    } 
  }
  
  protected boolean e0(Throwable paramThrowable) {
    return false;
  }
  
  public void f0(Throwable paramThrowable) {
    throw paramThrowable;
  }
  
  protected final void g0(t1 paramt1) {
    if (paramt1 == null) {
      x0(f2.a);
      return;
    } 
    paramt1.start();
    s s = paramt1.n(this);
    x0(s);
    if (h0()) {
      s.f();
      x0(f2.a);
    } 
  }
  
  public final g.c<?> getKey() {
    return t1.K;
  }
  
  public <R> R h(R paramR, p<? super R, ? super g.b, ? extends R> paramp) {
    return t1.a.b(this, paramR, paramp);
  }
  
  public final boolean h0() {
    return d0() instanceof o1 ^ true;
  }
  
  protected boolean i0() {
    return false;
  }
  
  public final boolean k0(Object paramObject) {
    while (true) {
      Object object = F0(d0(), paramObject);
      if (object == b2.a())
        return false; 
      if (object == b2.b)
        return true; 
      if (object != b2.b()) {
        w(object);
        return true;
      } 
    } 
  }
  
  public final Object l0(Object paramObject) {
    while (true) {
      Object object = F0(d0(), paramObject);
      if (object != b2.a()) {
        if (object != b2.b())
          return object; 
        continue;
      } 
      object = new StringBuilder();
      object.append("Job ");
      object.append(this);
      object.append(" is already complete or completing, but is being completed with ");
      object.append(paramObject);
      throw new IllegalStateException(object.toString(), X(paramObject));
    } 
  }
  
  public final CancellationException m() {
    Object object = d0();
    if (object instanceof c) {
      object = ((c)object).f();
      if (object != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(p0.a(this));
        stringBuilder.append(" is cancelling");
        object = A0((Throwable)object, stringBuilder.toString());
        if (object != null)
          return (CancellationException)object; 
      } 
      object = new StringBuilder();
      object.append("Job is still new or active: ");
      object.append(this);
      throw new IllegalStateException(object.toString().toString());
    } 
    if (!(object instanceof o1)) {
      if (object instanceof a0)
        return B0(this, ((a0)object).a, null, 1, null); 
      object = new StringBuilder();
      object.append(p0.a(this));
      object.append(" has completed normally");
      return new u1(object.toString(), null, this);
    } 
    object = new StringBuilder();
    object.append("Job is still new or active: ");
    object.append(this);
    throw new IllegalStateException(object.toString().toString());
  }
  
  public final s n(u paramu) {
    return (s)t1.a.d(this, true, false, new t(paramu), 2, null);
  }
  
  public String n0() {
    return p0.a(this);
  }
  
  public g q(g paramg) {
    return t1.a.f(this, paramg);
  }
  
  protected void r0(Throwable paramThrowable) {}
  
  protected void s0(Object paramObject) {}
  
  public final boolean start() {
    while (true) {
      int i = y0(d0());
      if (i != 0) {
        if (i != 1)
          continue; 
        return true;
      } 
      return false;
    } 
  }
  
  protected void t0() {}
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(C0());
    stringBuilder.append('@');
    stringBuilder.append(p0.b(this));
    return stringBuilder.toString();
  }
  
  protected void w(Object paramObject) {}
  
  public final void w0(z1 paramz1) {
    while (true) {
      Object object = d0();
      if (object instanceof z1) {
        if (object != paramz1)
          return; 
        if (androidx.concurrent.futures.b.a(a, this, object, b2.c()))
          return; 
        continue;
      } 
      if (object instanceof o1 && ((o1)object).d() != null)
        paramz1.w(); 
      return;
    } 
  }
  
  public final void x0(s params) {
    this._parentHandle = params;
  }
  
  public final Object y(ja.d<Object> paramd) {
    while (true) {
      Object object = d0();
      if (!(object instanceof o1)) {
        if (!(object instanceof a0))
          return b2.h(object); 
        throw ((a0)object).a;
      } 
      if (y0(object) >= 0)
        return A(paramd); 
    } 
  }
  
  private static final class a<T> extends n<T> {
    private final a2 i;
    
    public a(ja.d<? super T> param1d, a2 param1a2) {
      super(param1d, 1);
      this.i = param1a2;
    }
    
    protected String F() {
      return "AwaitContinuation";
    }
    
    public Throwable v(t1 param1t1) {
      Object object = this.i.d0();
      if (object instanceof a2.c) {
        Throwable throwable = ((a2.c)object).f();
        if (throwable != null)
          return throwable; 
      } 
      return (object instanceof a0) ? ((a0)object).a : param1t1.m();
    }
  }
  
  private static final class b extends z1 {
    private final a2 e;
    
    private final a2.c f;
    
    private final t g;
    
    private final Object h;
    
    public b(a2 param1a2, a2.c param1c, t param1t, Object param1Object) {
      this.e = param1a2;
      this.f = param1c;
      this.g = param1t;
      this.h = param1Object;
    }
    
    public void B(Throwable param1Throwable) {
      a2.t(this.e, this.f, this.g, this.h);
    }
  }
  
  private static final class c implements o1 {
    private final e2 a;
    
    public c(e2 param1e2, boolean param1Boolean, Throwable param1Throwable) {}
    
    private final ArrayList<Throwable> c() {
      return new ArrayList<Throwable>(4);
    }
    
    private final Object e() {
      return this._exceptionsHolder;
    }
    
    private final void l(Object param1Object) {
      this._exceptionsHolder = param1Object;
    }
    
    public boolean a() {
      return (f() == null);
    }
    
    public final void b(Throwable param1Throwable) {
      Throwable throwable = f();
      if (throwable == null) {
        m(param1Throwable);
        return;
      } 
      if (param1Throwable == throwable)
        return; 
      Object object = e();
      if (object == null) {
        l(param1Throwable);
        return;
      } 
      if (object instanceof Throwable) {
        if (param1Throwable == object)
          return; 
        ArrayList<Throwable> arrayList = c();
        arrayList.add(object);
        arrayList.add(param1Throwable);
        l(arrayList);
        return;
      } 
      if (object instanceof ArrayList) {
        ((ArrayList<Throwable>)object).add(param1Throwable);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("State is ");
      stringBuilder.append(object);
      throw new IllegalStateException(stringBuilder.toString().toString());
    }
    
    public e2 d() {
      return this.a;
    }
    
    public final Throwable f() {
      return (Throwable)this._rootCause;
    }
    
    public final boolean g() {
      return (f() != null);
    }
    
    public final boolean h() {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge Z and I\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public final boolean i() {
      return (e() == b2.e());
    }
    
    public final List<Throwable> j(Throwable param1Throwable) {
      StringBuilder stringBuilder;
      ArrayList<Object> arrayList;
      Object object = e();
      if (object == null) {
        arrayList = (ArrayList)c();
      } else if (object instanceof Throwable) {
        arrayList = (ArrayList)c();
        arrayList.add(object);
      } else if (object instanceof ArrayList) {
        arrayList = (ArrayList)object;
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("State is ");
        stringBuilder.append(object);
        throw new IllegalStateException(stringBuilder.toString().toString());
      } 
      object = f();
      if (object != null)
        arrayList.add(0, object); 
      if (stringBuilder != null && !l.b(stringBuilder, object))
        arrayList.add(stringBuilder); 
      l(b2.e());
      return arrayList;
    }
    
    public final void k(boolean param1Boolean) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public final void m(Throwable param1Throwable) {
      this._rootCause = param1Throwable;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Finishing[cancelling=");
      stringBuilder.append(g());
      stringBuilder.append(", completing=");
      stringBuilder.append(h());
      stringBuilder.append(", rootCause=");
      stringBuilder.append(f());
      stringBuilder.append(", exceptions=");
      stringBuilder.append(e());
      stringBuilder.append(", list=");
      stringBuilder.append(d());
      stringBuilder.append(']');
      return stringBuilder.toString();
    }
  }
  
  public static final class d extends o.a {
    public d(o param1o, a2 param1a2, Object param1Object) {
      super(param1o);
    }
    
    public Object i(o param1o) {
      boolean bool;
      if (this.d.d0() == this.e) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool ? null : n.a();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\a2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */