package ab;

public final class o0 extends Error {
  public o0(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */