package ab;

import ga.n;
import ga.r;
import ga.u;
import ja.d;
import ja.e;
import ja.g;
import kotlinx.coroutines.internal.f0;
import kotlinx.coroutines.internal.z;

public final class q2<T> extends z<T> {
  private ThreadLocal<n<g, Object>> d;
  
  public q2(g paramg, d<? super T> paramd) {
    super(g1, paramd);
    g g1;
    this.d = new ThreadLocal<n<g, Object>>();
    if (!(paramd.getContext().b((g.c)e.U) instanceof h0)) {
      Object object = f0.c(paramg, null);
      f0.a(paramg, object);
      O0(paramg, object);
    } 
  }
  
  protected void I0(Object<?> paramObject) {
    n n = this.d.get();
    null = null;
    if (n != null) {
      f0.a((g)n.a(), n.b());
      this.d.set(null);
    } 
    Object object2 = e0.a(paramObject, this.c);
    d<?> d = this.c;
    g g = d.getContext();
    Object object1 = f0.c(g, null);
    paramObject = null;
    if (object1 != f0.a)
      paramObject = (Object<?>)g0.g(d, g, object1); 
    try {
      this.c.resumeWith(object2);
      u u = u.a;
      return;
    } finally {
      if (paramObject == null || paramObject.N0())
        f0.a(g, object1); 
    } 
  }
  
  public final boolean N0() {
    if (this.d.get() == null)
      return false; 
    this.d.set(null);
    return true;
  }
  
  public final void O0(g paramg, Object paramObject) {
    this.d.set(r.a(paramg, paramObject));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\q2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */