package ab;

import ja.g;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.jvm.internal.l;
import kotlinx.coroutines.internal.g0;
import kotlinx.coroutines.internal.h0;
import kotlinx.coroutines.internal.q;
import va.j;

public abstract class e1 extends f1 implements t0 {
  private final boolean A0(a parama) {
    b b = (b)this._delayed;
    if (b != null) {
      a a1 = (a)b.e();
    } else {
      b = null;
    } 
    return (b == parama);
  }
  
  private final void p0() {
    while (true) {
      Object object = this._queue;
      if (object == null) {
        if (androidx.concurrent.futures.b.a(f, this, null, h1.a()))
          return; 
        continue;
      } 
      if (object instanceof q) {
        ((q)object).d();
        return;
      } 
      if (object == h1.a())
        return; 
      q q = new q(8, true);
      q.a(object);
      if (androidx.concurrent.futures.b.a(f, this, object, q))
        break; 
    } 
  }
  
  private final Runnable q0() {
    while (true) {
      Object object = this._queue;
      if (object == null)
        return null; 
      if (object instanceof q) {
        q q = (q)object;
        Object object1 = q.j();
        if (object1 != q.h)
          return (Runnable)object1; 
        androidx.concurrent.futures.b.a(f, this, object, q.i());
        continue;
      } 
      if (object == h1.a())
        return null; 
      if (androidx.concurrent.futures.b.a(f, this, object, null))
        return (Runnable)object; 
    } 
  }
  
  private final boolean s0(Runnable paramRunnable) {
    while (true) {
      Object object = this._queue;
      if (t0())
        return false; 
      if (object == null) {
        if (androidx.concurrent.futures.b.a(f, this, null, paramRunnable))
          return true; 
        continue;
      } 
      if (object instanceof q) {
        q q1 = (q)object;
        int i = q1.a(paramRunnable);
        if (i != 0) {
          if (i != 1) {
            if (i != 2)
              continue; 
            return false;
          } 
          androidx.concurrent.futures.b.a(f, this, object, q1.i());
          continue;
        } 
        return true;
      } 
      if (object == h1.a())
        return false; 
      q q = new q(8, true);
      q.a(object);
      q.a(paramRunnable);
      if (androidx.concurrent.futures.b.a(f, this, object, q))
        return true; 
    } 
  }
  
  private final boolean t0() {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge Z and I\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  private final void v0() {
    c.a();
    long l = System.nanoTime();
    while (true) {
      b b = (b)this._delayed;
      if (b != null) {
        a a = (a)b.i();
        if (a == null)
          return; 
        m0(l, a);
        continue;
      } 
      break;
    } 
  }
  
  private final int y0(long paramLong, a parama) {
    if (t0())
      return 1; 
    b b = (b)this._delayed;
    Object object = b;
    if (b == null) {
      androidx.concurrent.futures.b.a(g, this, null, new b(paramLong));
      object = this._delayed;
      l.c(object);
      object = object;
    } 
    return parama.p(paramLong, (b)object, this);
  }
  
  private final void z0(boolean paramBoolean) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public final void W(g paramg, Runnable paramRunnable) {
    r0(paramRunnable);
  }
  
  protected long d0() {
    if (super.d0() == 0L)
      return 0L; 
    Object object = this._queue;
    if (object != null)
      if (object instanceof q) {
        if (!((q)object).g())
          return 0L; 
      } else {
        return (object == h1.a()) ? Long.MAX_VALUE : 0L;
      }  
    object = this._delayed;
    if (object != null) {
      object = object.e();
      if (object == null)
        return Long.MAX_VALUE; 
      long l = ((a)object).a;
      c.a();
      return j.b(l - System.nanoTime(), 0L);
    } 
    return Long.MAX_VALUE;
  }
  
  public long i0() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual j0 : ()Z
    //   4: ifeq -> 9
    //   7: lconst_0
    //   8: lreturn
    //   9: aload_0
    //   10: getfield _delayed : Ljava/lang/Object;
    //   13: checkcast ab/e1$b
    //   16: astore #5
    //   18: aload #5
    //   20: ifnull -> 123
    //   23: aload #5
    //   25: invokevirtual d : ()Z
    //   28: ifne -> 123
    //   31: invokestatic a : ()Lab/b;
    //   34: pop
    //   35: invokestatic nanoTime : ()J
    //   38: lstore_1
    //   39: aload #5
    //   41: monitorenter
    //   42: aload #5
    //   44: invokevirtual b : ()Lkotlinx/coroutines/internal/h0;
    //   47: astore #6
    //   49: aconst_null
    //   50: astore #4
    //   52: aload #6
    //   54: ifnonnull -> 63
    //   57: aload #5
    //   59: monitorexit
    //   60: goto -> 104
    //   63: aload #6
    //   65: checkcast ab/e1$a
    //   68: astore #6
    //   70: aload #6
    //   72: lload_1
    //   73: invokevirtual q : (J)Z
    //   76: ifeq -> 148
    //   79: aload_0
    //   80: aload #6
    //   82: invokespecial s0 : (Ljava/lang/Runnable;)Z
    //   85: istore_3
    //   86: goto -> 89
    //   89: iload_3
    //   90: ifeq -> 57
    //   93: aload #5
    //   95: iconst_0
    //   96: invokevirtual h : (I)Lkotlinx/coroutines/internal/h0;
    //   99: astore #4
    //   101: goto -> 57
    //   104: aload #4
    //   106: checkcast ab/e1$a
    //   109: ifnonnull -> 39
    //   112: goto -> 123
    //   115: astore #4
    //   117: aload #5
    //   119: monitorexit
    //   120: aload #4
    //   122: athrow
    //   123: aload_0
    //   124: invokespecial q0 : ()Ljava/lang/Runnable;
    //   127: astore #4
    //   129: aload #4
    //   131: ifnull -> 143
    //   134: aload #4
    //   136: invokeinterface run : ()V
    //   141: lconst_0
    //   142: lreturn
    //   143: aload_0
    //   144: invokevirtual d0 : ()J
    //   147: lreturn
    //   148: iconst_0
    //   149: istore_3
    //   150: goto -> 89
    // Exception table:
    //   from	to	target	type
    //   42	49	115	finally
    //   63	86	115	finally
    //   93	101	115	finally
  }
  
  public void r0(Runnable paramRunnable) {
    if (s0(paramRunnable)) {
      n0();
      return;
    } 
    q0.h.r0(paramRunnable);
  }
  
  public void shutdown() {
    o2.a.c();
    z0(true);
    p0();
    do {
    
    } while (i0() <= 0L);
    v0();
  }
  
  protected boolean u0() {
    if (!h0())
      return false; 
    b b = (b)this._delayed;
    if (b != null && !b.d())
      return false; 
    Object object = this._queue;
    if (object != null) {
      if (object instanceof q)
        return ((q)object).g(); 
      if (object != h1.a())
        return false; 
    } 
    return true;
  }
  
  protected final void w0() {
    this._queue = null;
    this._delayed = null;
  }
  
  public final void x0(long paramLong, a parama) {
    int i = y0(paramLong, parama);
    if (i != 0) {
      if (i != 1) {
        if (i == 2)
          return; 
        throw new IllegalStateException("unexpected result".toString());
      } 
      m0(paramLong, parama);
      return;
    } 
    if (A0(parama))
      n0(); 
  }
  
  public static abstract class a implements Runnable, Comparable<a>, a1, h0 {
    private volatile Object _heap;
    
    public long a;
    
    private int b;
    
    public void a(g0<?> param1g0) {
      boolean bool;
      if (this._heap != h1.b()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        this._heap = param1g0;
        return;
      } 
      throw new IllegalArgumentException("Failed requirement.".toString());
    }
    
    public final void f() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield _heap : Ljava/lang/Object;
      //   6: astore_1
      //   7: invokestatic b : ()Lkotlinx/coroutines/internal/b0;
      //   10: astore_2
      //   11: aload_1
      //   12: aload_2
      //   13: if_acmpne -> 19
      //   16: aload_0
      //   17: monitorexit
      //   18: return
      //   19: aload_1
      //   20: instanceof ab/e1$b
      //   23: ifeq -> 59
      //   26: aload_1
      //   27: checkcast ab/e1$b
      //   30: astore_1
      //   31: goto -> 34
      //   34: aload_1
      //   35: ifnull -> 44
      //   38: aload_1
      //   39: aload_0
      //   40: invokevirtual g : (Lkotlinx/coroutines/internal/h0;)Z
      //   43: pop
      //   44: aload_0
      //   45: invokestatic b : ()Lkotlinx/coroutines/internal/b0;
      //   48: putfield _heap : Ljava/lang/Object;
      //   51: aload_0
      //   52: monitorexit
      //   53: return
      //   54: astore_1
      //   55: aload_0
      //   56: monitorexit
      //   57: aload_1
      //   58: athrow
      //   59: aconst_null
      //   60: astore_1
      //   61: goto -> 34
      // Exception table:
      //   from	to	target	type
      //   2	11	54	finally
      //   19	31	54	finally
      //   38	44	54	finally
      //   44	51	54	finally
    }
    
    public int getIndex() {
      return this.b;
    }
    
    public g0<?> l() {
      Object object = this._heap;
      return (object instanceof g0) ? (g0)object : null;
    }
    
    public int o(a param1a) {
      int i = this.a - param1a.a cmp 0L;
      return (i > 0) ? 1 : ((i < 0) ? -1 : 0);
    }
    
    public final int p(long param1Long, e1.b param1b, e1 param1e1) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield _heap : Ljava/lang/Object;
      //   6: astore #8
      //   8: invokestatic b : ()Lkotlinx/coroutines/internal/b0;
      //   11: astore #9
      //   13: aload #8
      //   15: aload #9
      //   17: if_acmpne -> 24
      //   20: aload_0
      //   21: monitorexit
      //   22: iconst_2
      //   23: ireturn
      //   24: aload_3
      //   25: monitorenter
      //   26: aload_3
      //   27: invokevirtual b : ()Lkotlinx/coroutines/internal/h0;
      //   30: checkcast ab/e1$a
      //   33: astore #8
      //   35: aload #4
      //   37: invokestatic o0 : (Lab/e1;)Z
      //   40: istore #7
      //   42: iload #7
      //   44: ifeq -> 53
      //   47: aload_3
      //   48: monitorexit
      //   49: aload_0
      //   50: monitorexit
      //   51: iconst_1
      //   52: ireturn
      //   53: aload #8
      //   55: ifnonnull -> 66
      //   58: aload_3
      //   59: lload_1
      //   60: putfield b : J
      //   63: goto -> 99
      //   66: aload #8
      //   68: getfield a : J
      //   71: lstore #5
      //   73: lload #5
      //   75: lload_1
      //   76: lsub
      //   77: lconst_0
      //   78: lcmp
      //   79: iflt -> 148
      //   82: goto -> 85
      //   85: lload_1
      //   86: aload_3
      //   87: getfield b : J
      //   90: lsub
      //   91: lconst_0
      //   92: lcmp
      //   93: ifle -> 99
      //   96: goto -> 58
      //   99: aload_0
      //   100: getfield a : J
      //   103: lstore_1
      //   104: aload_3
      //   105: getfield b : J
      //   108: lstore #5
      //   110: lload_1
      //   111: lload #5
      //   113: lsub
      //   114: lconst_0
      //   115: lcmp
      //   116: ifge -> 125
      //   119: aload_0
      //   120: lload #5
      //   122: putfield a : J
      //   125: aload_3
      //   126: aload_0
      //   127: invokevirtual a : (Lkotlinx/coroutines/internal/h0;)V
      //   130: aload_3
      //   131: monitorexit
      //   132: aload_0
      //   133: monitorexit
      //   134: iconst_0
      //   135: ireturn
      //   136: astore #4
      //   138: aload_3
      //   139: monitorexit
      //   140: aload #4
      //   142: athrow
      //   143: astore_3
      //   144: aload_0
      //   145: monitorexit
      //   146: aload_3
      //   147: athrow
      //   148: lload #5
      //   150: lstore_1
      //   151: goto -> 85
      // Exception table:
      //   from	to	target	type
      //   2	13	143	finally
      //   24	26	143	finally
      //   26	42	136	finally
      //   47	49	143	finally
      //   58	63	136	finally
      //   66	73	136	finally
      //   85	96	136	finally
      //   99	110	136	finally
      //   119	125	136	finally
      //   125	130	136	finally
      //   130	132	143	finally
      //   138	143	143	finally
    }
    
    public final boolean q(long param1Long) {
      return (param1Long - this.a >= 0L);
    }
    
    public void setIndex(int param1Int) {
      this.b = param1Int;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Delayed[nanos=");
      stringBuilder.append(this.a);
      stringBuilder.append(']');
      return stringBuilder.toString();
    }
  }
  
  public static final class b extends g0<a> {
    public long b;
    
    public b(long param1Long) {
      this.b = param1Long;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\e1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */