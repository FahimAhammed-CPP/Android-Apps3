package ab;

import eb.a;
import ga.u;
import ja.d;
import ja.g;
import ka.b;
import qa.p;

final class c2 extends k2 {
  private final d<u> c;
  
  public c2(g paramg, p<? super l0, ? super d<? super u>, ? extends Object> paramp) {
    super(paramg, false);
    this.c = b.a(paramp, this, this);
  }
  
  protected void t0() {
    a.b(this.c, this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\c2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */