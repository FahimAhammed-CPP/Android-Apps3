package ab;

import ja.g;
import ja.h;
import java.util.concurrent.Executor;

final class y0 implements Executor {
  public final h0 a;
  
  public void execute(Runnable paramRunnable) {
    this.a.W((g)h.a, paramRunnable);
  }
  
  public String toString() {
    return this.a.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */