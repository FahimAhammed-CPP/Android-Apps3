package ab;

import ga.u;
import qa.l;

final class q1 extends k {
  private final l<Throwable, u> a;
  
  public q1(l<? super Throwable, u> paraml) {
    this.a = (l)paraml;
  }
  
  public void a(Throwable paramThrowable) {
    this.a.invoke(paramThrowable);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("InvokeOnCancel[");
    stringBuilder.append(p0.a(this.a));
    stringBuilder.append('@');
    stringBuilder.append(p0.b(this));
    stringBuilder.append(']');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\q1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */