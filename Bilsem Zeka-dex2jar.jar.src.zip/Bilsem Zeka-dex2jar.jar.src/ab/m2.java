package ab;

public final class m2 {
  public static final y a(t1 paramt1) {
    return new l2(paramt1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\m2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */