package ab;

import java.util.concurrent.locks.LockSupport;

public abstract class f1 extends d1 {
  protected abstract Thread l0();
  
  protected void m0(long paramLong, e1.a parama) {
    q0.h.x0(paramLong, parama);
  }
  
  protected final void n0() {
    Thread thread = l0();
    if (Thread.currentThread() != thread) {
      c.a();
      LockSupport.unpark(thread);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\f1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */