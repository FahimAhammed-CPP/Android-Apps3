package ab;

import kotlinx.coroutines.internal.b0;

public final class h1 {
  private static final b0 a = new b0("REMOVED_TASK");
  
  private static final b0 b = new b0("CLOSED_EMPTY");
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\h1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */