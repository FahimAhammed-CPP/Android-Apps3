package ab;

import ga.u;

public final class r extends v1 {
  public final n<?> e;
  
  public r(n<?> paramn) {
    this.e = paramn;
  }
  
  public void B(Throwable paramThrowable) {
    n<?> n1 = this.e;
    n1.G(n1.v(C()));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */