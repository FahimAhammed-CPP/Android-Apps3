package ab;

import ga.u;
import kotlinx.coroutines.internal.o;
import qa.l;

public abstract class c0 extends o implements l<Throwable, u> {
  public abstract void B(Throwable paramThrowable);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */