package ab;

import ja.g;
import java.util.concurrent.locks.LockSupport;
import kotlin.jvm.internal.l;

final class f<T> extends a<T> {
  private final Thread c;
  
  private final d1 d;
  
  public f(g paramg, Thread paramThread, d1 paramd1) {
    super(paramg, true, true);
    this.c = paramThread;
    this.d = paramd1;
  }
  
  public final T M0() {
    c.a();
    try {
      d1 d11 = this.d;
      a0 a0 = null;
      if (d11 != null)
        d1.f0(d11, false, 1, null); 
      while (true) {
        try {
          if (!Thread.interrupted()) {
            long l;
            d11 = this.d;
            if (d11 != null) {
              l = d11.i0();
            } else {
              l = Long.MAX_VALUE;
            } 
            if (!h0()) {
              c.a();
              LockSupport.parkNanos(this, l);
              continue;
            } 
            d11 = this.d;
            if (d11 != null)
              d1.a0(d11, false, 1, null); 
            c.a();
            Object object = b2.h(d0());
            if (object instanceof a0)
              a0 = (a0)object; 
            if (a0 == null)
              return (T)object; 
            throw a0.a;
          } 
        } finally {}
        InterruptedException interruptedException = new InterruptedException();
        E(interruptedException);
        throw interruptedException;
      } 
    } finally {
      c.a();
    } 
  }
  
  protected boolean i0() {
    return true;
  }
  
  protected void w(Object paramObject) {
    if (!l.b(Thread.currentThread(), this.c)) {
      paramObject = this.c;
      c.a();
      LockSupport.unpark((Thread)paramObject);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */