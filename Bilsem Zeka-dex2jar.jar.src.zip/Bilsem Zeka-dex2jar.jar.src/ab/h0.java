package ab;

import ja.a;
import ja.b;
import ja.d;
import ja.e;
import ja.g;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import kotlinx.coroutines.internal.f;
import kotlinx.coroutines.internal.k;
import kotlinx.coroutines.internal.l;
import qa.l;

public abstract class h0 extends a implements e {
  public static final a b = new a(null);
  
  public h0() {
    super((g.c)e.U);
  }
  
  public g J(g.c<?> paramc) {
    return e.a.b(this, paramc);
  }
  
  public abstract void W(g paramg, Runnable paramRunnable);
  
  public boolean X(g paramg) {
    return true;
  }
  
  public h0 Y(int paramInt) {
    l.a(paramInt);
    return (h0)new k(this, paramInt);
  }
  
  public <E extends g.b> E b(g.c<E> paramc) {
    return (E)e.a.a(this, paramc);
  }
  
  public final <T> d<T> i(d<? super T> paramd) {
    return (d<T>)new f(this, paramd);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(p0.a(this));
    stringBuilder.append('@');
    stringBuilder.append(p0.b(this));
    return stringBuilder.toString();
  }
  
  public final void x(d<?> paramd) {
    ((f)paramd).s();
  }
  
  public static final class a extends b<e, h0> {
    private a() {
      super((g.c)e.U, a.a);
    }
    
    static final class a extends m implements l<g.b, h0> {
      public static final a a = new a();
      
      a() {
        super(1);
      }
      
      public final h0 a(g.b param2b) {
        return (param2b instanceof h0) ? (h0)param2b : null;
      }
    }
  }
  
  static final class a extends m implements l<g.b, h0> {
    public static final a a = new a();
    
    a() {
      super(1);
    }
    
    public final h0 a(g.b param1b) {
      return (param1b instanceof h0) ? (h0)param1b : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\h0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */