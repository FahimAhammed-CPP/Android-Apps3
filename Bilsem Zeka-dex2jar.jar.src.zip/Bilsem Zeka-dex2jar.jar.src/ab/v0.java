package ab;

import ja.d;
import ja.g;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import ka.b;
import kotlinx.coroutines.internal.g;
import kotlinx.coroutines.internal.z;

public final class v0<T> extends z<T> {
  public v0(g paramg, d<? super T> paramd) {
    super(paramg, paramd);
  }
  
  private final boolean O0() {
    while (true) {
      int i = this._decision;
      if (i != 0) {
        if (i == 1)
          return false; 
        throw new IllegalStateException("Already resumed".toString());
      } 
      if (d.compareAndSet(this, 0, 2))
        return true; 
    } 
  }
  
  private final boolean P0() {
    while (true) {
      int i = this._decision;
      if (i != 0) {
        if (i == 2)
          return false; 
        throw new IllegalStateException("Already suspended".toString());
      } 
      if (d.compareAndSet(this, 0, 1))
        return true; 
    } 
  }
  
  protected void I0(Object paramObject) {
    if (O0())
      return; 
    g.c(b.b(this.c), e0.a(paramObject, this.c), null, 2, null);
  }
  
  public final Object N0() {
    if (P0())
      return b.c(); 
    Object object = b2.h(d0());
    if (!(object instanceof a0))
      return object; 
    throw ((a0)object).a;
  }
  
  protected void w(Object paramObject) {
    I0(paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\v0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */