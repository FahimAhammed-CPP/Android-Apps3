package ab;

import ga.u;

public final class t extends v1 implements s {
  public final u e;
  
  public t(u paramu) {
    this.e = paramu;
  }
  
  public void B(Throwable paramThrowable) {
    this.e.B(C());
  }
  
  public t1 getParent() {
    return C();
  }
  
  public boolean i(Throwable paramThrowable) {
    return C().R(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */