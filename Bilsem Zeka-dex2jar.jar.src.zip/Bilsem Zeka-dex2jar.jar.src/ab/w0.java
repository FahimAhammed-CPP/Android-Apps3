package ab;

import ga.a;
import ja.d;
import ja.g;
import kotlin.jvm.internal.l;
import kotlinx.coroutines.internal.f;
import kotlinx.coroutines.internal.f0;
import kotlinx.coroutines.scheduling.h;
import kotlinx.coroutines.scheduling.i;

public abstract class w0<T> extends h {
  public int c;
  
  public w0(int paramInt) {
    this.c = paramInt;
  }
  
  public void a(Object paramObject, Throwable paramThrowable) {}
  
  public abstract d<T> b();
  
  public Throwable d(Object paramObject) {
    boolean bool = paramObject instanceof a0;
    Throwable throwable = null;
    if (bool) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    if (paramObject != null)
      throwable = ((a0)paramObject).a; 
    return throwable;
  }
  
  public <T> T f(Object paramObject) {
    return (T)paramObject;
  }
  
  public final void h(Throwable paramThrowable1, Throwable paramThrowable2) {
    if (paramThrowable1 == null && paramThrowable2 == null)
      return; 
    if (paramThrowable1 != null && paramThrowable2 != null)
      a.a(paramThrowable1, paramThrowable2); 
    Throwable throwable = paramThrowable1;
    if (paramThrowable1 == null)
      throwable = paramThrowable2; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fatal exception in coroutines machinery for ");
    stringBuilder.append(this);
    stringBuilder.append(". Please read KDoc to 'handleFatalException' method and report this incident to maintainers");
    String str = stringBuilder.toString();
    l.c(throwable);
    o0 o0 = new o0(str, throwable);
    k0.a(b().getContext(), o0);
  }
  
  public abstract Object i();
  
  public final void run() {
    i i = this.b;
    try {
      q2 q2;
      f f = (f)b();
      d<?> d = f.e;
      null = f.g;
      g g = d.getContext();
      Object object = f0.c(g, null);
      if (object != f0.a) {
        q2 = g0.g(d, g, object);
      } else {
        q2 = null;
      } 
    } finally {
      Object object;
      Exception exception = null;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\w0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */