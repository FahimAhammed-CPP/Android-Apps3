package ab;

import ga.u;
import kotlinx.coroutines.internal.o;

final class i2 extends e {
  private final o a;
  
  public i2(o paramo) {
    this.a = paramo;
  }
  
  public void a(Throwable paramThrowable) {
    this.a.w();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RemoveOnCancel[");
    stringBuilder.append(this.a);
    stringBuilder.append(']');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\i2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */