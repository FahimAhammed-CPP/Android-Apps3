package ab;

final class p1 {
  public final o1 a;
  
  public p1(o1 paramo1) {
    this.a = paramo1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\p1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */