package ab;

import ga.o;
import ga.p;
import ga.u;
import ja.d;
import qa.l;

public final class e0 {
  public static final <T> Object a(Object paramObject, d<? super T> paramd) {
    Object object = paramObject;
    if (paramObject instanceof a0) {
      object = o.a;
      object = p.a(((a0)paramObject).a);
    } 
    return o.a(object);
  }
  
  public static final <T> Object b(Object paramObject, m<?> paramm) {
    Throwable throwable = o.b(paramObject);
    return (throwable == null) ? paramObject : new a0(throwable, false, 2, null);
  }
  
  public static final <T> Object c(Object paramObject, l<? super Throwable, u> paraml) {
    Object object = o.b(paramObject);
    if (object == null) {
      object = paramObject;
      if (paraml != null)
        return new b0(paramObject, paraml); 
    } else {
      object = new a0((Throwable)object, false, 2, null);
    } 
    return object;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */