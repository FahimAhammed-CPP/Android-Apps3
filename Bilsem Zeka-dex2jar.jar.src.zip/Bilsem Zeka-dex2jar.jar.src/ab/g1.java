package ab;

public final class g1 {
  public static final d1 a() {
    return new g(Thread.currentThread());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\g1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */