package ab;

import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;
import va.j;

public final class q0 extends e1 implements Runnable {
  private static volatile Thread _thread;
  
  private static volatile int debugStatus;
  
  public static final q0 h;
  
  private static final long i;
  
  static {
    Long long_;
    q0 q01 = new q0();
    h = q01;
    d1.f0(q01, false, 1, null);
    TimeUnit timeUnit = TimeUnit.MILLISECONDS;
    try {
      long_ = Long.getLong("kotlinx.coroutines.DefaultExecutor.keepAlive", 1000L);
    } catch (SecurityException securityException) {
      long_ = Long.valueOf(1000L);
    } 
    i = timeUnit.toNanos(long_.longValue());
  }
  
  private final void B0() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial E0 : ()Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifne -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: iconst_3
    //   15: putstatic ab/q0.debugStatus : I
    //   18: aload_0
    //   19: invokevirtual w0 : ()V
    //   22: aload_0
    //   23: invokevirtual notifyAll : ()V
    //   26: aload_0
    //   27: monitorexit
    //   28: return
    //   29: astore_2
    //   30: aload_0
    //   31: monitorexit
    //   32: aload_2
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	29	finally
    //   14	26	29	finally
  }
  
  private final Thread C0() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic ab/q0._thread : Ljava/lang/Thread;
    //   5: astore_2
    //   6: aload_2
    //   7: astore_1
    //   8: aload_2
    //   9: ifnonnull -> 36
    //   12: new java/lang/Thread
    //   15: dup
    //   16: aload_0
    //   17: ldc 'kotlinx.coroutines.DefaultExecutor'
    //   19: invokespecial <init> : (Ljava/lang/Runnable;Ljava/lang/String;)V
    //   22: astore_1
    //   23: aload_1
    //   24: putstatic ab/q0._thread : Ljava/lang/Thread;
    //   27: aload_1
    //   28: iconst_1
    //   29: invokevirtual setDaemon : (Z)V
    //   32: aload_1
    //   33: invokevirtual start : ()V
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: areturn
    //   40: astore_1
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_1
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	6	40	finally
    //   12	36	40	finally
  }
  
  private final boolean D0() {
    return (debugStatus == 4);
  }
  
  private final boolean E0() {
    int i = debugStatus;
    return (i == 2 || i == 3);
  }
  
  private final boolean F0() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial E0 : ()Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq -> 15
    //   11: aload_0
    //   12: monitorexit
    //   13: iconst_0
    //   14: ireturn
    //   15: iconst_1
    //   16: putstatic ab/q0.debugStatus : I
    //   19: aload_0
    //   20: invokevirtual notifyAll : ()V
    //   23: aload_0
    //   24: monitorexit
    //   25: iconst_1
    //   26: ireturn
    //   27: astore_2
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_2
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	27	finally
    //   15	23	27	finally
  }
  
  private final void G0() {
    throw new RejectedExecutionException("DefaultExecutor was shut down. This error indicates that Dispatchers.shutdown() was invoked prior to completion of exiting coroutines, leaving coroutines in incomplete state. Please refer to Dispatchers.shutdown documentation for more details");
  }
  
  protected Thread l0() {
    Thread thread2 = _thread;
    Thread thread1 = thread2;
    if (thread2 == null)
      thread1 = C0(); 
    return thread1;
  }
  
  protected void m0(long paramLong, e1.a parama) {
    G0();
  }
  
  public void r0(Runnable paramRunnable) {
    if (D0())
      G0(); 
    super.r0(paramRunnable);
  }
  
  public void run() {
    o2.a.d(this);
    c.a();
    try {
      boolean bool = F0();
      if (!bool)
        return; 
      long l = Long.MAX_VALUE;
      while (true) {
        long l1;
        Thread.interrupted();
        long l2 = i0();
        if (l2 == Long.MAX_VALUE) {
          c.a();
          long l3 = System.nanoTime();
          l1 = l;
          if (l == Long.MAX_VALUE) {
            l = i;
            l1 = l + l3;
          } 
          l = l1 - l3;
          if (l <= 0L)
            return; 
          l2 = j.d(l2, l);
        } else {
          l1 = Long.MAX_VALUE;
        } 
        l = l1;
        if (l2 > 0L) {
          bool = E0();
          if (bool)
            return; 
          c.a();
          LockSupport.parkNanos(this, l2);
          l = l1;
        } 
      } 
    } finally {
      _thread = null;
      B0();
      c.a();
      if (!u0())
        l0(); 
    } 
  }
  
  public void shutdown() {
    debugStatus = 4;
    super.shutdown();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\q0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */