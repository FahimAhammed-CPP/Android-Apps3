package ab;

final class c1 implements o1 {
  private final boolean a;
  
  public c1(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public boolean a() {
    return this.a;
  }
  
  public e2 d() {
    return null;
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Empty{");
    if (a()) {
      str = "Active";
    } else {
      str = "New";
    } 
    stringBuilder.append(str);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\c1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */