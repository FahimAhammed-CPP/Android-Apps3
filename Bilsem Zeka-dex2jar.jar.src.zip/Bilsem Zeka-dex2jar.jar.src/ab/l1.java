package ab;

import java.util.concurrent.Executor;

public final class l1 {
  public static final h0 a(Executor paramExecutor) {
    if (paramExecutor instanceof y0) {
      null = (h0)paramExecutor;
    } else {
      null = null;
    } 
    if (null != null) {
      h0 h0 = ((y0)null).a;
      null = h0;
      return (h0 == null) ? new k1(paramExecutor) : null;
    } 
    return new k1(paramExecutor);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\l1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */