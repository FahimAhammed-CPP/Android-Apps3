package ab;

public final class f2 implements a1, s {
  public static final f2 a = new f2();
  
  public void f() {}
  
  public t1 getParent() {
    return null;
  }
  
  public boolean i(Throwable paramThrowable) {
    return false;
  }
  
  public String toString() {
    return "NonDisposableHandle";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\f2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */