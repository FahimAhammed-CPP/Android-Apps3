package ab;

import ja.d;
import ja.g;
import qa.p;

public abstract class a<T> extends a2 implements d<T>, l0 {
  private final g b;
  
  public a(g paramg, boolean paramBoolean1, boolean paramBoolean2) {
    super(paramBoolean2);
    if (paramBoolean1)
      g0((t1)paramg.b(t1.K)); 
    this.b = paramg.q((g)this);
  }
  
  protected void I0(Object paramObject) {
    w(paramObject);
  }
  
  protected void J0(Throwable paramThrowable, boolean paramBoolean) {}
  
  protected void K0(T paramT) {}
  
  public final <R> void L0(n0 paramn0, R paramR, p<? super R, ? super d<? super T>, ? extends Object> paramp) {
    paramn0.f(paramp, paramR, this);
  }
  
  protected String O() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(p0.a(this));
    stringBuilder.append(" was cancelled");
    return stringBuilder.toString();
  }
  
  public boolean a() {
    return super.a();
  }
  
  public final void f0(Throwable paramThrowable) {
    k0.a(this.b, paramThrowable);
  }
  
  public final g getContext() {
    return this.b;
  }
  
  public g k() {
    return this.b;
  }
  
  public String n0() {
    String str = g0.b(this.b);
    if (str == null)
      return super.n0(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append('"');
    stringBuilder.append(str);
    stringBuilder.append("\":");
    stringBuilder.append(super.n0());
    return stringBuilder.toString();
  }
  
  public final void resumeWith(Object paramObject) {
    paramObject = l0(e0.d(paramObject, null, 1, null));
    if (paramObject == b2.b)
      return; 
    I0(paramObject);
  }
  
  protected final void s0(Object paramObject) {
    if (paramObject instanceof a0) {
      paramObject = paramObject;
      J0(((a0)paramObject).a, paramObject.a());
      return;
    } 
    K0((T)paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */