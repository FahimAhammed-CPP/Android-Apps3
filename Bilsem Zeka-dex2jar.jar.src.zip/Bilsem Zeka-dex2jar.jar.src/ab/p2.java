package ab;

import ja.g;

public final class p2 extends h0 {
  public static final p2 c = new p2();
  
  public void W(g paramg, Runnable paramRunnable) {
    s2 s2 = (s2)paramg.b(s2.c);
    if (s2 != null) {
      s2.b = true;
      return;
    } 
    throw new UnsupportedOperationException("Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls.");
  }
  
  public boolean X(g paramg) {
    return false;
  }
  
  public String toString() {
    return "Dispatchers.Unconfined";
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\p2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */