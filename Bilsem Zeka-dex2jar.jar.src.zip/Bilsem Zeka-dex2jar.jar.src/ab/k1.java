package ab;

import ja.g;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import kotlinx.coroutines.internal.d;

public final class k1 extends j1 implements t0 {
  private final Executor d;
  
  public k1(Executor paramExecutor) {
    this.d = paramExecutor;
    d.a(a0());
  }
  
  private final void Z(g paramg, RejectedExecutionException paramRejectedExecutionException) {
    x1.c(paramg, i1.a("The task was rejected", paramRejectedExecutionException));
  }
  
  public void W(g paramg, Runnable paramRunnable) {
    try {
      Executor executor = a0();
      c.a();
      executor.execute(paramRunnable);
      return;
    } catch (RejectedExecutionException rejectedExecutionException) {
      c.a();
      Z(paramg, rejectedExecutionException);
      z0.b().W(paramg, paramRunnable);
      return;
    } 
  }
  
  public Executor a0() {
    return this.d;
  }
  
  public void close() {
    Executor executor = a0();
    if (executor instanceof java.util.concurrent.ExecutorService) {
      executor = executor;
    } else {
      executor = null;
    } 
    if (executor != null)
      executor.shutdown(); 
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof k1 && ((k1)paramObject).a0() == a0());
  }
  
  public int hashCode() {
    return System.identityHashCode(a0());
  }
  
  public String toString() {
    return a0().toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\k1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */