package ab;

public interface o1 {
  boolean a();
  
  e2 d();
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\o1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */