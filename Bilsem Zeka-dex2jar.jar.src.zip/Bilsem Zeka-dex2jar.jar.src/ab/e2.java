package ab;

import kotlinx.coroutines.internal.m;

public final class e2 extends m implements o1 {
  public boolean a() {
    return true;
  }
  
  public e2 d() {
    return this;
  }
  
  public String toString() {
    return super.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\e2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */