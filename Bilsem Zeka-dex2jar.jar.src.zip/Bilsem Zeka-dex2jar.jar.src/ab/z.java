package ab;

import ga.u;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import qa.l;

final class z {
  public final Object a;
  
  public final k b;
  
  public final l<Throwable, u> c;
  
  public final Object d;
  
  public final Throwable e;
  
  public z(Object paramObject1, k paramk, l<? super Throwable, u> paraml, Object paramObject2, Throwable paramThrowable) {
    this.a = paramObject1;
    this.b = paramk;
    this.c = (l)paraml;
    this.d = paramObject2;
    this.e = paramThrowable;
  }
  
  public final z a(Object paramObject1, k paramk, l<? super Throwable, u> paraml, Object paramObject2, Throwable paramThrowable) {
    return new z(paramObject1, paramk, paraml, paramObject2, paramThrowable);
  }
  
  public final boolean c() {
    return (this.e != null);
  }
  
  public final void d(n<?> paramn, Throwable paramThrowable) {
    k k1 = this.b;
    if (k1 != null)
      paramn.m(k1, paramThrowable); 
    l<Throwable, u> l1 = this.c;
    if (l1 != null)
      paramn.p(l1, paramThrowable); 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof z))
      return false; 
    paramObject = paramObject;
    return !l.b(this.a, ((z)paramObject).a) ? false : (!l.b(this.b, ((z)paramObject).b) ? false : (!l.b(this.c, ((z)paramObject).c) ? false : (!l.b(this.d, ((z)paramObject).d) ? false : (!!l.b(this.e, ((z)paramObject).e)))));
  }
  
  public int hashCode() {
    int i;
    int j;
    int m;
    int n;
    Object<Throwable, u> object = (Object<Throwable, u>)this.a;
    int i1 = 0;
    if (object == null) {
      i = 0;
    } else {
      i = object.hashCode();
    } 
    object = (Object<Throwable, u>)this.b;
    if (object == null) {
      j = 0;
    } else {
      j = object.hashCode();
    } 
    object = (Object<Throwable, u>)this.c;
    if (object == null) {
      m = 0;
    } else {
      m = object.hashCode();
    } 
    object = (Object<Throwable, u>)this.d;
    if (object == null) {
      n = 0;
    } else {
      n = object.hashCode();
    } 
    object = (Object<Throwable, u>)this.e;
    if (object != null)
      i1 = object.hashCode(); 
    return (((i * 31 + j) * 31 + m) * 31 + n) * 31 + i1;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CompletedContinuation(result=");
    stringBuilder.append(this.a);
    stringBuilder.append(", cancelHandler=");
    stringBuilder.append(this.b);
    stringBuilder.append(", onCancellation=");
    stringBuilder.append(this.c);
    stringBuilder.append(", idempotentResume=");
    stringBuilder.append(this.d);
    stringBuilder.append(", cancelCause=");
    stringBuilder.append(this.e);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */