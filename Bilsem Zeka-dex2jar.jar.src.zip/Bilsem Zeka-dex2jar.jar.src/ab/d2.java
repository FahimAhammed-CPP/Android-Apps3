package ab;

public abstract class d2 extends h0 {
  public abstract d2 Z();
  
  protected final String a0() {
    d2 d21 = z0.c();
    if (this == d21)
      return "Dispatchers.Main"; 
    try {
      d21 = d21.Z();
    } catch (UnsupportedOperationException unsupportedOperationException) {
      unsupportedOperationException = null;
    } 
    return (this == unsupportedOperationException) ? "Dispatchers.Main.immediate" : null;
  }
  
  public String toString() {
    String str2 = a0();
    String str1 = str2;
    if (str2 == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(p0.a(this));
      stringBuilder.append('@');
      stringBuilder.append(p0.b(this));
      str1 = stringBuilder.toString();
    } 
    return str1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\d2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */