package ab;

import ga.u;
import qa.l;

final class s1 extends z1 {
  private final l<Throwable, u> e;
  
  public s1(l<? super Throwable, u> paraml) {
    this.e = (l)paraml;
  }
  
  public void B(Throwable paramThrowable) {
    this.e.invoke(paramThrowable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\s1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */