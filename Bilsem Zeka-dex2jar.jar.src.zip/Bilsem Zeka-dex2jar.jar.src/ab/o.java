package ab;

import kotlinx.coroutines.internal.b0;

public final class o {
  public static final b0 a = new b0("RESUME_TOKEN");
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */