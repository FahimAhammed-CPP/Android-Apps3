package ab;

import ja.d;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public final class q extends a0 {
  public q(d<?> paramd, Throwable paramThrowable, boolean paramBoolean) {
    super(throwable, paramBoolean);
  }
  
  public final boolean c() {
    return c.compareAndSet(this, 0, 1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */