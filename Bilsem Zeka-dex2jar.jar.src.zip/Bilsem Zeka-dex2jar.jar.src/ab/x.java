package ab;

import ga.o;

public final class x {
  public static final <T> v<T> a(t1 paramt1) {
    return new w<T>(paramt1);
  }
  
  public static final <T> boolean c(v<T> paramv, Object paramObject) {
    Throwable throwable = o.b(paramObject);
    return (throwable == null) ? paramv.H((T)paramObject) : paramv.F(throwable);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */