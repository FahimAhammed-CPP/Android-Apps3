package ab;

public final class n1 implements o1 {
  private final e2 a;
  
  public n1(e2 parame2) {
    this.a = parame2;
  }
  
  public boolean a() {
    return false;
  }
  
  public e2 d() {
    return this.a;
  }
  
  public String toString() {
    return super.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\n1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */