package ab;

public abstract class v1 extends z1 {}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\v1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */