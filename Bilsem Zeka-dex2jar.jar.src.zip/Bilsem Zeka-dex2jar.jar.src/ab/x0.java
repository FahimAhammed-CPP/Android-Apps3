package ab;

import ga.o;
import ga.p;
import ga.u;
import ja.d;
import ja.g;
import kotlinx.coroutines.internal.f;
import kotlinx.coroutines.internal.f0;

public final class x0 {
  public static final <T> void a(w0<? super T> paramw0, int paramInt) {
    boolean bool;
    g g;
    d<? super T> d = paramw0.b();
    if (paramInt == 4) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && d instanceof f && b(paramInt) == b(paramw0.c)) {
      h0 h0 = ((f)d).d;
      g = d.getContext();
      if (h0.X(g)) {
        h0.W(g, (Runnable)paramw0);
        return;
      } 
      e(paramw0);
      return;
    } 
    d(paramw0, (d<? super T>)g, bool);
  }
  
  public static final boolean b(int paramInt) {
    boolean bool = true;
    if (paramInt != 1) {
      if (paramInt == 2)
        return true; 
      bool = false;
    } 
    return bool;
  }
  
  public static final boolean c(int paramInt) {
    return (paramInt == 2);
  }
  
  public static final <T> void d(w0<? super T> paramw0, d<? super T> paramd, boolean paramBoolean) {
    Object<?> object;
    g g;
    Object object1 = paramw0.i();
    Throwable throwable = paramw0.d(object1);
    if (throwable != null) {
      o.a a = o.a;
      object = (Object<?>)p.a(throwable);
    } else {
      o.a a = o.a;
      object = object.f(object1);
    } 
    object1 = o.a(object);
    if (paramBoolean) {
      f f = (f)paramd;
      object = (Object<?>)f.e;
      Object object2 = f.g;
      g = object.getContext();
      object2 = f0.c(g, object2);
      if (object2 != f0.a) {
        object = (Object<?>)g0.g((d<?>)object, g, object2);
      } else {
        object = null;
      } 
      try {
        f.e.resumeWith(object1);
        object1 = u.a;
      } finally {
        if (object == null || object.N0())
          f0.a(g, object2); 
      } 
    } else {
      g.resumeWith(object1);
    } 
  }
  
  private static final void e(w0<?> paramw0) {
    d1 d1 = o2.a.b();
    if (d1.g0()) {
      d1.c0(paramw0);
      return;
    } 
    d1.e0(true);
    try {
      d(paramw0, paramw0.b(), true);
    } finally {
      Exception exception = null;
    } 
    d1.Z(true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\x0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */