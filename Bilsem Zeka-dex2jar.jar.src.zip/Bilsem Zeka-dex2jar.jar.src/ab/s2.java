package ab;

import ja.a;
import ja.g;
import kotlin.jvm.internal.g;

public final class s2 extends a {
  public static final a c = new a(null);
  
  public boolean b;
  
  public s2() {
    super(c);
  }
  
  public static final class a implements g.c<s2> {
    private a() {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\s2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */