package ab;

import ja.b;
import ja.g;
import java.io.Closeable;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import qa.l;

public abstract class j1 extends h0 implements Closeable {
  public static final a c = new a(null);
  
  public static final class a extends b<h0, j1> {
    private a() {
      super((g.c)h0.b, a.a);
    }
    
    static final class a extends m implements l<g.b, j1> {
      public static final a a = new a();
      
      a() {
        super(1);
      }
      
      public final j1 a(g.b param2b) {
        return (param2b instanceof j1) ? (j1)param2b : null;
      }
    }
  }
  
  static final class a extends m implements l<g.b, j1> {
    public static final a a = new a();
    
    a() {
      super(1);
    }
    
    public final j1 a(g.b param1b) {
      return (param1b instanceof j1) ? (j1)param1b : null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\j1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */