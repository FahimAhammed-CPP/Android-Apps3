package ab;

import ga.a;
import ja.g;

public final class k0 {
  public static final void a(g paramg, Throwable paramThrowable) {
    try {
      i0 i0 = (i0)paramg.b(i0.J);
      return;
    } finally {
      Exception exception = null;
      j0.a(paramg, b(paramThrowable, exception));
    } 
  }
  
  public static final Throwable b(Throwable paramThrowable1, Throwable paramThrowable2) {
    if (paramThrowable1 == paramThrowable2)
      return paramThrowable1; 
    paramThrowable2 = new RuntimeException("Exception while trying to handle coroutine exception", paramThrowable2);
    a.a(paramThrowable2, paramThrowable1);
    return paramThrowable2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\k0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */