package ab;

import ja.d;

public interface s0<T> extends t1 {
  Object M(d<? super T> paramd);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */