package ab;

public class w1 extends a2 implements y {
  private final boolean b;
  
  public w1(t1 paramt1) {
    super(true);
    g0(paramt1);
    this.b = I0();
  }
  
  private final boolean I0() {
    s s = c0();
    if (s instanceof t) {
      s = s;
    } else {
      s = null;
    } 
    if (s != null) {
      a2 a22 = s.C();
      a2 a21 = a22;
      if (a22 == null)
        return false; 
      while (true) {
        if (a21.Z())
          return true; 
        s s1 = a21.c0();
        if (s1 instanceof t) {
          s1 = s1;
        } else {
          s1 = null;
        } 
        if (s1 != null) {
          a22 = s1.C();
          a2 a23 = a22;
          if (a22 == null)
            break; 
          continue;
        } 
        break;
      } 
    } 
    return false;
  }
  
  public boolean Z() {
    return this.b;
  }
  
  public boolean a0() {
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\w1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */