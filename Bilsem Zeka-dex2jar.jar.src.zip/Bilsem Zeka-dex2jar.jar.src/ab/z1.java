package ab;

import kotlin.jvm.internal.l;

public abstract class z1 extends c0 implements a1, o1 {
  public a2 d;
  
  public final a2 C() {
    a2 a21 = this.d;
    if (a21 != null)
      return a21; 
    l.t("job");
    return null;
  }
  
  public final void D(a2 parama2) {
    this.d = parama2;
  }
  
  public boolean a() {
    return true;
  }
  
  public e2 d() {
    return null;
  }
  
  public void f() {
    C().w0(this);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(p0.a(this));
    stringBuilder.append('@');
    stringBuilder.append(p0.b(this));
    stringBuilder.append("[job@");
    stringBuilder.append(p0.b(C()));
    stringBuilder.append(']');
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\z1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */