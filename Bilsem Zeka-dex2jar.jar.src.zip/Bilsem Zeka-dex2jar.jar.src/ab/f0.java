package ab;

import ja.g;

public interface f0<S> extends n2<S> {
  f0<S> C();
  
  g z(g.b paramb);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */