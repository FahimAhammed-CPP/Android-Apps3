package ab;

public final class o2 {
  public static final o2 a = new o2();
  
  private static final ThreadLocal<d1> b = new ThreadLocal<d1>();
  
  public final d1 a() {
    return b.get();
  }
  
  public final d1 b() {
    ThreadLocal<d1> threadLocal = b;
    d1 d12 = threadLocal.get();
    d1 d11 = d12;
    if (d12 == null) {
      d11 = g1.a();
      threadLocal.set(d11);
    } 
    return d11;
  }
  
  public final void c() {
    b.set(null);
  }
  
  public final void d(d1 paramd1) {
    b.set(paramd1);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\o2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */