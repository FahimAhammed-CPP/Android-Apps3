package ab;

import ja.g;
import ja.h;

public final class m1 implements l0 {
  public static final m1 a = new m1();
  
  public g k() {
    return (g)h.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\m1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */