package ab;

import kotlinx.coroutines.internal.b0;

public final class b2 {
  private static final b0 a = new b0("COMPLETING_ALREADY");
  
  public static final b0 b = new b0("COMPLETING_WAITING_CHILDREN");
  
  private static final b0 c = new b0("COMPLETING_RETRY");
  
  private static final b0 d = new b0("TOO_LATE_TO_CANCEL");
  
  private static final b0 e = new b0("SEALED");
  
  private static final c1 f = new c1(false);
  
  private static final c1 g = new c1(true);
  
  public static final Object g(Object paramObject) {
    Object object = paramObject;
    if (paramObject instanceof o1)
      object = new p1((o1)paramObject); 
    return object;
  }
  
  public static final Object h(Object paramObject) {
    Object object;
    if (paramObject instanceof p1) {
      object = paramObject;
    } else {
      object = null;
    } 
    Object object1 = paramObject;
    if (object != null) {
      object1 = ((p1)object).a;
      if (object1 == null)
        return paramObject; 
    } 
    return object1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\b2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */