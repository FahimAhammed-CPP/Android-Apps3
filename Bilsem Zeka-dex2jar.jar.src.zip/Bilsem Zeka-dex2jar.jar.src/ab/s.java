package ab;

public interface s extends a1 {
  t1 getParent();
  
  boolean i(Throwable paramThrowable);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */