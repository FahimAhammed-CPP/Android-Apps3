package ab;

import ga.a;
import ga.o;
import ga.u;
import ja.g;
import java.util.List;
import java.util.ServiceLoader;
import xa.c;

public final class j0 {
  private static final List<i0> a = c.f(c.a(ServiceLoader.<i0>load(i0.class, i0.class.getClassLoader()).iterator()));
  
  public static final void a(g paramg, Throwable paramThrowable) {
    for (i0 i0 : a) {
      try {
        i0.f(paramg, paramThrowable);
      } finally {
        i0 = null;
        Thread thread1 = Thread.currentThread();
      } 
    } 
    Thread thread = Thread.currentThread();
    try {
      o.a a = o.a;
      a.a(paramThrowable, new u0(paramg));
      o.a(u.a);
    } finally {
      paramg = null;
      o.a a = o.a;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */