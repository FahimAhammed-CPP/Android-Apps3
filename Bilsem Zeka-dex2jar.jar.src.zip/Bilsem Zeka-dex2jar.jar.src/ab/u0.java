package ab;

import ja.g;

final class u0 extends RuntimeException {
  private final g a;
  
  public u0(g paramg) {
    this.a = paramg;
  }
  
  public Throwable fillInStackTrace() {
    setStackTrace(new StackTraceElement[0]);
    return this;
  }
  
  public String getLocalizedMessage() {
    return this.a.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a\\u0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */