package ab;

import ja.d;
import kotlinx.coroutines.internal.f;
import kotlinx.coroutines.internal.o;

public final class p {
  public static final void a(m<?> paramm, a1 parama1) {
    paramm.e(new b1(parama1));
  }
  
  public static final <T> n<T> b(d<? super T> paramd) {
    if (!(paramd instanceof f))
      return new n<T>(paramd, 1); 
    n<T> n = ((f)paramd).m();
    if (n != null) {
      if (!n.I())
        n = null; 
      if (n != null)
        return n; 
    } 
    return new n<T>(paramd, 2);
  }
  
  public static final void c(m<?> paramm, o paramo) {
    paramm.e(new i2(paramo));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */