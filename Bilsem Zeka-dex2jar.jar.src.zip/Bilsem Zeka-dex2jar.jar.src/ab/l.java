package ab;

import ga.u;
import qa.l;

public abstract class l implements l<Throwable, u> {
  public abstract void a(Throwable paramThrowable);
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */