package ab;

import kotlinx.coroutines.internal.a;

public abstract class d1 extends h0 {
  private long c;
  
  private boolean d;
  
  private a<w0<?>> e;
  
  private final long b0(boolean paramBoolean) {
    return paramBoolean ? 4294967296L : 1L;
  }
  
  public final void Z(boolean paramBoolean) {
    long l = this.c - b0(paramBoolean);
    this.c = l;
    if (l > 0L)
      return; 
    if (this.d)
      shutdown(); 
  }
  
  public final void c0(w0<?> paramw0) {
    a<w0<?>> a2 = this.e;
    a<w0<?>> a1 = a2;
    if (a2 == null) {
      a1 = new a();
      this.e = a1;
    } 
    a1.a(paramw0);
  }
  
  protected long d0() {
    a<w0<?>> a1 = this.e;
    return (a1 == null) ? Long.MAX_VALUE : (a1.c() ? Long.MAX_VALUE : 0L);
  }
  
  public final void e0(boolean paramBoolean) {
    this.c += b0(paramBoolean);
    if (!paramBoolean)
      this.d = true; 
  }
  
  public final boolean g0() {
    return (this.c >= b0(true));
  }
  
  public final boolean h0() {
    a<w0<?>> a1 = this.e;
    return (a1 != null) ? a1.c() : true;
  }
  
  public long i0() {
    return !j0() ? Long.MAX_VALUE : 0L;
  }
  
  public final boolean j0() {
    a<w0<?>> a1 = this.e;
    if (a1 == null)
      return false; 
    w0 w0 = (w0)a1.d();
    if (w0 == null)
      return false; 
    w0.run();
    return true;
  }
  
  public boolean k0() {
    return false;
  }
  
  public void shutdown() {}
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\ab\d1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */