package a7;

import c7.i;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.atomic.AtomicInteger;
import s6.f;
import v6.n;
import v6.w;
import x6.b0;
import x6.c0;
import y6.h;

public class e {
  private static final Charset e = Charset.forName("UTF-8");
  
  private static final int f = 15;
  
  private static final h g = new h();
  
  private static final Comparator<? super File> h = new c();
  
  private static final FilenameFilter i = new d();
  
  private final AtomicInteger a = new AtomicInteger(0);
  
  private final f b;
  
  private final i c;
  
  private final n d;
  
  public e(f paramf, i parami, n paramn) {
    this.b = paramf;
    this.c = parami;
    this.d = paramn;
  }
  
  private static String A(File paramFile) {
    null = new byte[8192];
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    FileInputStream fileInputStream = new FileInputStream(paramFile);
    try {
      while (true) {
        int j = fileInputStream.read(null);
        if (j > 0) {
          byteArrayOutputStream.write(null, 0, j);
          continue;
        } 
        return new String(byteArrayOutputStream.toByteArray(), e);
      } 
    } finally {
      try {
        fileInputStream.close();
      } finally {
        fileInputStream = null;
      } 
    } 
  }
  
  private void B(File paramFile, b0.d paramd, String paramString, b0.a parama) {
    String str = this.d.d(paramString);
    try {
      h h1 = g;
      b0 b0 = h1.F(A(paramFile)).s(paramd).p(parama).o(str);
      F(this.b.g(paramString), h1.G(b0));
      return;
    } catch (IOException iOException) {
      f f1 = f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not synthesize final native report file for ");
      stringBuilder.append(paramFile);
      f1.l(stringBuilder.toString(), iOException);
      return;
    } 
  }
  
  private void C(String paramString, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : La7/f;
    //   4: aload_1
    //   5: getstatic a7/e.i : Ljava/io/FilenameFilter;
    //   8: invokevirtual p : (Ljava/lang/String;Ljava/io/FilenameFilter;)Ljava/util/List;
    //   11: astore #7
    //   13: aload #7
    //   15: invokeinterface isEmpty : ()Z
    //   20: ifeq -> 71
    //   23: invokestatic f : ()Ls6/f;
    //   26: astore #6
    //   28: new java/lang/StringBuilder
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: astore #7
    //   37: aload #7
    //   39: ldc 'Session '
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: pop
    //   45: aload #7
    //   47: aload_1
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: pop
    //   52: aload #7
    //   54: ldc ' has no events.'
    //   56: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   59: pop
    //   60: aload #6
    //   62: aload #7
    //   64: invokevirtual toString : ()Ljava/lang/String;
    //   67: invokevirtual i : (Ljava/lang/String;)V
    //   70: return
    //   71: aload #7
    //   73: invokestatic sort : (Ljava/util/List;)V
    //   76: new java/util/ArrayList
    //   79: dup
    //   80: invokespecial <init> : ()V
    //   83: astore #6
    //   85: aload #7
    //   87: invokeinterface iterator : ()Ljava/util/Iterator;
    //   92: astore #7
    //   94: iconst_0
    //   95: istore #4
    //   97: aload #7
    //   99: invokeinterface hasNext : ()Z
    //   104: ifeq -> 211
    //   107: aload #7
    //   109: invokeinterface next : ()Ljava/lang/Object;
    //   114: checkcast java/io/File
    //   117: astore #8
    //   119: aload #6
    //   121: getstatic a7/e.g : Ly6/h;
    //   124: aload #8
    //   126: invokestatic A : (Ljava/io/File;)Ljava/lang/String;
    //   129: invokevirtual h : (Ljava/lang/String;)Lx6/b0$e$d;
    //   132: invokeinterface add : (Ljava/lang/Object;)Z
    //   137: pop
    //   138: iload #4
    //   140: ifne -> 158
    //   143: aload #8
    //   145: invokevirtual getName : ()Ljava/lang/String;
    //   148: invokestatic s : (Ljava/lang/String;)Z
    //   151: istore #5
    //   153: iload #5
    //   155: ifeq -> 94
    //   158: iconst_1
    //   159: istore #4
    //   161: goto -> 97
    //   164: astore #9
    //   166: invokestatic f : ()Ls6/f;
    //   169: astore #10
    //   171: new java/lang/StringBuilder
    //   174: dup
    //   175: invokespecial <init> : ()V
    //   178: astore #11
    //   180: aload #11
    //   182: ldc 'Could not add event to report for '
    //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: pop
    //   188: aload #11
    //   190: aload #8
    //   192: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   195: pop
    //   196: aload #10
    //   198: aload #11
    //   200: invokevirtual toString : ()Ljava/lang/String;
    //   203: aload #9
    //   205: invokevirtual l : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   208: goto -> 97
    //   211: aload #6
    //   213: invokeinterface isEmpty : ()Z
    //   218: ifeq -> 261
    //   221: invokestatic f : ()Ls6/f;
    //   224: astore #6
    //   226: new java/lang/StringBuilder
    //   229: dup
    //   230: invokespecial <init> : ()V
    //   233: astore #7
    //   235: aload #7
    //   237: ldc 'Could not parse event files for session '
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: aload #7
    //   245: aload_1
    //   246: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   249: pop
    //   250: aload #6
    //   252: aload #7
    //   254: invokevirtual toString : ()Ljava/lang/String;
    //   257: invokevirtual k : (Ljava/lang/String;)V
    //   260: return
    //   261: aload_1
    //   262: aload_0
    //   263: getfield b : La7/f;
    //   266: invokestatic j : (Ljava/lang/String;La7/f;)Ljava/lang/String;
    //   269: astore #7
    //   271: aload_0
    //   272: getfield d : Lv6/n;
    //   275: aload_1
    //   276: invokevirtual d : (Ljava/lang/String;)Ljava/lang/String;
    //   279: astore #8
    //   281: aload_0
    //   282: aload_0
    //   283: getfield b : La7/f;
    //   286: aload_1
    //   287: ldc 'report'
    //   289: invokevirtual o : (Ljava/lang/String;Ljava/lang/String;)Ljava/io/File;
    //   292: aload #6
    //   294: lload_2
    //   295: iload #4
    //   297: aload #7
    //   299: aload #8
    //   301: invokespecial D : (Ljava/io/File;Ljava/util/List;JZLjava/lang/String;Ljava/lang/String;)V
    //   304: return
    // Exception table:
    //   from	to	target	type
    //   119	138	164	java/io/IOException
    //   143	153	164	java/io/IOException
  }
  
  private void D(File paramFile, List<b0.e.d> paramList, long paramLong, boolean paramBoolean, String paramString1, String paramString2) {
    try {
      File file;
      h h1 = g;
      b0 b0 = h1.F(A(paramFile)).t(paramLong, paramBoolean, paramString1).o(paramString2).q(c0.l(paramList));
      b0.e e1 = b0.m();
      if (e1 == null)
        return; 
      f f1 = f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("appQualitySessionId: ");
      stringBuilder.append(paramString2);
      f1.b(stringBuilder.toString());
      if (paramBoolean) {
        file = this.b.j(e1.i());
      } else {
        file = this.b.l(file.i());
      } 
      F(file, h1.G(b0));
      return;
    } catch (IOException iOException) {
      f f1 = f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not synthesize final report file for ");
      stringBuilder.append(paramFile);
      f1.l(stringBuilder.toString(), iOException);
      return;
    } 
  }
  
  private int E(String paramString, int paramInt) {
    List<File> list = this.b.p(paramString, new a());
    Collections.sort(list, new b());
    return f(list, paramInt);
  }
  
  private static void F(File paramFile, String paramString) {
    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(paramFile), e);
    try {
      outputStreamWriter.write(paramString);
      return;
    } finally {
      try {
        outputStreamWriter.close();
      } finally {
        outputStreamWriter = null;
      } 
    } 
  }
  
  private static void G(File paramFile, String paramString, long paramLong) {
    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(paramFile), e);
    try {
      outputStreamWriter.write(paramString);
      paramFile.setLastModified(h(paramLong));
      return;
    } finally {
      try {
        outputStreamWriter.close();
      } finally {
        paramString = null;
      } 
    } 
  }
  
  private SortedSet<String> e(String paramString) {
    this.b.b();
    SortedSet<String> sortedSet = p();
    if (paramString != null)
      sortedSet.remove(paramString); 
    if (sortedSet.size() <= 8)
      return sortedSet; 
    while (sortedSet.size() > 8) {
      paramString = sortedSet.last();
      f f1 = f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removing session over cap: ");
      stringBuilder.append(paramString);
      f1.b(stringBuilder.toString());
      this.b.c(paramString);
      sortedSet.remove(paramString);
    } 
    return sortedSet;
  }
  
  private static int f(List<File> paramList, int paramInt) {
    int j = paramList.size();
    for (File file : paramList) {
      if (j <= paramInt)
        return j; 
      f.s(file);
      j--;
    } 
    return j;
  }
  
  private void g() {
    int j = (this.c.b()).a.b;
    List<File> list = n();
    int k = list.size();
    if (k <= j)
      return; 
    Iterator<File> iterator = list.subList(j, k).iterator();
    while (iterator.hasNext())
      ((File)iterator.next()).delete(); 
  }
  
  private static long h(long paramLong) {
    return paramLong * 1000L;
  }
  
  private void j(List<File> paramList) {
    Iterator<File> iterator = paramList.iterator();
    while (iterator.hasNext())
      ((File)iterator.next()).delete(); 
  }
  
  private static String m(int paramInt, boolean paramBoolean) {
    String str1;
    String str2 = String.format(Locale.US, "%010d", new Object[] { Integer.valueOf(paramInt) });
    if (paramBoolean) {
      str1 = "_";
    } else {
      str1 = "";
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("event");
    stringBuilder.append(str2);
    stringBuilder.append(str1);
    return stringBuilder.toString();
  }
  
  private List<File> n() {
    ArrayList<File> arrayList = new ArrayList();
    arrayList.addAll(this.b.k());
    arrayList.addAll(this.b.h());
    Comparator<? super File> comparator = h;
    Collections.sort(arrayList, comparator);
    List<File> list = this.b.m();
    Collections.sort(list, comparator);
    arrayList.addAll(list);
    return arrayList;
  }
  
  private static String o(String paramString) {
    return paramString.substring(0, f);
  }
  
  private static boolean s(String paramString) {
    return (paramString.startsWith("event") && paramString.endsWith("_"));
  }
  
  private static boolean t(File paramFile, String paramString) {
    return (paramString.startsWith("event") && !paramString.endsWith("_"));
  }
  
  private static int x(File paramFile1, File paramFile2) {
    return o(paramFile1.getName()).compareTo(o(paramFile2.getName()));
  }
  
  public void i() {
    j(this.b.m());
    j(this.b.k());
    j(this.b.h());
  }
  
  public void k(String paramString, long paramLong) {
    for (String str : e(paramString)) {
      f f1 = f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Finalizing report for session ");
      stringBuilder.append(str);
      f1.i(stringBuilder.toString());
      C(str, paramLong);
      this.b.c(str);
    } 
    g();
  }
  
  public void l(String paramString, b0.d paramd, b0.a parama) {
    File file = this.b.o(paramString, "report");
    f f1 = f.f();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Writing native session report for ");
    stringBuilder.append(paramString);
    stringBuilder.append(" to file: ");
    stringBuilder.append(file);
    f1.b(stringBuilder.toString());
    B(file, paramd, paramString, parama);
  }
  
  public SortedSet<String> p() {
    return (new TreeSet<String>(this.b.d())).descendingSet();
  }
  
  public long q(String paramString) {
    return this.b.o(paramString, "start-time").lastModified();
  }
  
  public boolean r() {
    return (!this.b.m().isEmpty() || !this.b.k().isEmpty() || !this.b.h().isEmpty());
  }
  
  public List<w> w() {
    List<File> list = n();
    ArrayList<w> arrayList = new ArrayList();
    for (File file : list) {
      try {
        arrayList.add(w.a(g.F(A(file)), file.getName(), file));
      } catch (IOException iOException) {
        f f1 = f.f();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not load report file ");
        stringBuilder.append(file);
        stringBuilder.append("; deleting");
        f1.l(stringBuilder.toString(), iOException);
        file.delete();
      } 
    } 
    return arrayList;
  }
  
  public void y(b0.e.d paramd, String paramString, boolean paramBoolean) {
    int j = (this.c.b()).a.a;
    String str1 = g.i(paramd);
    String str2 = m(this.a.getAndIncrement(), paramBoolean);
    try {
      F(this.b.o(paramString, str2), str1);
    } catch (IOException iOException) {
      f f1 = f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not persist event for session ");
      stringBuilder.append(paramString);
      f1.l(stringBuilder.toString(), iOException);
    } 
    E(paramString, j);
  }
  
  public void z(b0 paramb0) {
    b0.e e1 = paramb0.m();
    if (e1 == null) {
      f.f().b("Could not get session for report");
      return;
    } 
    String str = e1.i();
    try {
      String str1 = g.G(paramb0);
      F(this.b.o(str, "report"), str1);
      G(this.b.o(str, "start-time"), "", e1.l());
      return;
    } catch (IOException iOException) {
      f f1 = f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not persist report for session ");
      stringBuilder.append(str);
      f1.c(stringBuilder.toString(), iOException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a7\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */