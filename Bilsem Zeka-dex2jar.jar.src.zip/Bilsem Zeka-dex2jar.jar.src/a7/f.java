package a7;

import a5.l;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class f {
  private final File a;
  
  private final File b;
  
  private final File c;
  
  private final File d;
  
  private final File e;
  
  private final File f;
  
  public f(Context paramContext) {
    String str;
    File file2 = paramContext.getFilesDir();
    this.a = file2;
    if (v()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(".com.google.firebase.crashlytics.files.v2");
      stringBuilder.append(File.pathSeparator);
      stringBuilder.append(u(l.a()));
      str = stringBuilder.toString();
    } else {
      str = ".com.google.firebase.crashlytics.files.v1";
    } 
    File file1 = q(new File(file2, str));
    this.b = file1;
    this.c = q(new File(file1, "open-sessions"));
    this.d = q(new File(file1, "reports"));
    this.e = q(new File(file1, "priority-reports"));
    this.f = q(new File(file1, "native-reports"));
  }
  
  private void a(File paramFile) {
    if (paramFile.exists() && s(paramFile)) {
      s6.f f1 = s6.f.f();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Deleted previous Crashlytics file system: ");
      stringBuilder.append(paramFile.getPath());
      f1.b(stringBuilder.toString());
    } 
  }
  
  private File n(String paramString) {
    return r(new File(this.c, paramString));
  }
  
  private static File q(File paramFile) {
    // Byte code:
    //   0: ldc a7/f
    //   2: monitorenter
    //   3: aload_0
    //   4: invokevirtual exists : ()Z
    //   7: ifeq -> 69
    //   10: aload_0
    //   11: invokevirtual isDirectory : ()Z
    //   14: istore_1
    //   15: iload_1
    //   16: ifeq -> 24
    //   19: ldc a7/f
    //   21: monitorexit
    //   22: aload_0
    //   23: areturn
    //   24: invokestatic f : ()Ls6/f;
    //   27: astore_2
    //   28: new java/lang/StringBuilder
    //   31: dup
    //   32: invokespecial <init> : ()V
    //   35: astore_3
    //   36: aload_3
    //   37: ldc 'Unexpected non-directory file: '
    //   39: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: pop
    //   43: aload_3
    //   44: aload_0
    //   45: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   48: pop
    //   49: aload_3
    //   50: ldc '; deleting file and creating new directory.'
    //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: pop
    //   56: aload_2
    //   57: aload_3
    //   58: invokevirtual toString : ()Ljava/lang/String;
    //   61: invokevirtual b : (Ljava/lang/String;)V
    //   64: aload_0
    //   65: invokevirtual delete : ()Z
    //   68: pop
    //   69: aload_0
    //   70: invokevirtual mkdirs : ()Z
    //   73: ifne -> 109
    //   76: invokestatic f : ()Ls6/f;
    //   79: astore_2
    //   80: new java/lang/StringBuilder
    //   83: dup
    //   84: invokespecial <init> : ()V
    //   87: astore_3
    //   88: aload_3
    //   89: ldc 'Could not create Crashlytics-specific directory: '
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: pop
    //   95: aload_3
    //   96: aload_0
    //   97: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: aload_2
    //   102: aload_3
    //   103: invokevirtual toString : ()Ljava/lang/String;
    //   106: invokevirtual d : (Ljava/lang/String;)V
    //   109: ldc a7/f
    //   111: monitorexit
    //   112: aload_0
    //   113: areturn
    //   114: astore_0
    //   115: ldc a7/f
    //   117: monitorexit
    //   118: aload_0
    //   119: athrow
    // Exception table:
    //   from	to	target	type
    //   3	15	114	finally
    //   24	69	114	finally
    //   69	109	114	finally
  }
  
  private static File r(File paramFile) {
    paramFile.mkdirs();
    return paramFile;
  }
  
  static boolean s(File paramFile) {
    File[] arrayOfFile = paramFile.listFiles();
    if (arrayOfFile != null) {
      int j = arrayOfFile.length;
      for (int i = 0; i < j; i++)
        s(arrayOfFile[i]); 
    } 
    return paramFile.delete();
  }
  
  private static <T> List<T> t(T[] paramArrayOfT) {
    return (paramArrayOfT == null) ? Collections.emptyList() : Arrays.asList(paramArrayOfT);
  }
  
  static String u(String paramString) {
    return paramString.replaceAll("[^a-zA-Z0-9.]", "_");
  }
  
  @SuppressLint({"AnnotateVersionCheck"})
  private static boolean v() {
    return (Build.VERSION.SDK_INT >= 28);
  }
  
  public void b() {
    a(new File(this.a, ".com.google.firebase.crashlytics"));
    a(new File(this.a, ".com.google.firebase.crashlytics-ndk"));
    if (v())
      a(new File(this.a, ".com.google.firebase.crashlytics.files.v1")); 
  }
  
  public boolean c(String paramString) {
    return s(new File(this.c, paramString));
  }
  
  public List<String> d() {
    return t(this.c.list());
  }
  
  public File e(String paramString) {
    return new File(this.b, paramString);
  }
  
  public List<File> f(FilenameFilter paramFilenameFilter) {
    return t(this.b.listFiles(paramFilenameFilter));
  }
  
  public File g(String paramString) {
    return new File(this.f, paramString);
  }
  
  public List<File> h() {
    return t(this.f.listFiles());
  }
  
  public File i(String paramString) {
    return r(new File(n(paramString), "native"));
  }
  
  public File j(String paramString) {
    return new File(this.e, paramString);
  }
  
  public List<File> k() {
    return t(this.e.listFiles());
  }
  
  public File l(String paramString) {
    return new File(this.d, paramString);
  }
  
  public List<File> m() {
    return t(this.d.listFiles());
  }
  
  public File o(String paramString1, String paramString2) {
    return new File(n(paramString1), paramString2);
  }
  
  public List<File> p(String paramString, FilenameFilter paramFilenameFilter) {
    return t(n(paramString).listFiles(paramFilenameFilter));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\a7\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */