package aa;

import android.util.Log;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import t9.s;

public class h {
  private static Map<String, Object> b(Throwable paramThrowable) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    hashMap.put("message", paramThrowable.toString());
    hashMap.put("code", paramThrowable.getClass().getSimpleName());
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cause: ");
    stringBuilder.append(paramThrowable.getCause());
    stringBuilder.append(", Stacktrace: ");
    stringBuilder.append(Log.getStackTraceString(paramThrowable));
    hashMap.put("details", stringBuilder.toString());
    return (Map)hashMap;
  }
  
  public static interface a {
    List<String> a();
    
    List<String> b(h.c param1c);
    
    String c();
    
    String d();
    
    String e();
    
    String f();
  }
  
  private static class b extends s {
    public static final b d = new b();
  }
  
  public enum c {
    b(0),
    c(1),
    d(2),
    e(3),
    f(4),
    g(5),
    h(6),
    i(7),
    j(8),
    k(9),
    l(10);
    
    private int a;
    
    c(int param1Int1) {
      this.a = param1Int1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\aa\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */