package aa;

import android.content.Context;
import android.util.Log;
import ea.b;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import k9.a;
import t9.c;

public class i implements a, h.a {
  private Context b;
  
  private String g() {
    return b.d(this.b);
  }
  
  private String h() {
    return b.c(this.b);
  }
  
  private List<String> i() {
    ArrayList<String> arrayList = new ArrayList();
    for (File file : this.b.getExternalCacheDirs()) {
      if (file != null)
        arrayList.add(file.getAbsolutePath()); 
    } 
    return arrayList;
  }
  
  private List<String> j(h.c paramc) {
    ArrayList<String> arrayList = new ArrayList();
    for (File file : this.b.getExternalFilesDirs(m(paramc))) {
      if (file != null)
        arrayList.add(file.getAbsolutePath()); 
    } 
    return arrayList;
  }
  
  private String k() {
    File file = this.b.getExternalFilesDir(null);
    return (file == null) ? null : file.getAbsolutePath();
  }
  
  private String l() {
    return this.b.getCacheDir().getPath();
  }
  
  private String m(h.c paramc) {
    StringBuilder stringBuilder;
    switch (a.a[paramc.ordinal()]) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unrecognized directory: ");
        stringBuilder.append(paramc);
        throw new RuntimeException(stringBuilder.toString());
      case 11:
        return "documents";
      case 10:
        return "dcim";
      case 9:
        return "downloads";
      case 8:
        return "movies";
      case 7:
        return "pictures";
      case 6:
        return "notifications";
      case 5:
        return "alarms";
      case 4:
        return "ringtones";
      case 3:
        return "podcasts";
      case 2:
        return "music";
      case 1:
        break;
    } 
    return null;
  }
  
  private void n(c paramc, Context paramContext) {
    paramc.b();
    try {
      g.h(paramc, this);
    } catch (Exception exception) {
      Log.e("PathProviderPlugin", "Received exception while setting up PathProviderPlugin", exception);
    } 
    this.b = paramContext;
  }
  
  public List<String> a() {
    return i();
  }
  
  public List<String> b(h.c paramc) {
    return j(paramc);
  }
  
  public String c() {
    return k();
  }
  
  public String d() {
    return l();
  }
  
  public String e() {
    return h();
  }
  
  public String f() {
    return g();
  }
  
  public void onAttachedToEngine(a.b paramb) {
    n(paramb.b(), paramb.a());
  }
  
  public void onDetachedFromEngine(a.b paramb) {
    g.h(paramb.b(), null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Bilsem Zeka-dex2jar.jar!\aa\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */