package com.google.analytics.tracking.android;

import android.content.Context;
import android.text.TextUtils;

class ParameterLoaderImpl implements ParameterLoader {
  private final Context mContext;
  
  public ParameterLoaderImpl(Context paramContext) {
    if (paramContext == null)
      throw new NullPointerException("Context cannot be null"); 
    this.mContext = paramContext.getApplicationContext();
  }
  
  private int getResourceIdForType(String paramString1, String paramString2) {
    return (this.mContext == null) ? 0 : this.mContext.getResources().getIdentifier(paramString1, paramString2, this.mContext.getPackageName());
  }
  
  public boolean getBoolean(String paramString) {
    int i = getResourceIdForType(paramString, "bool");
    return (i == 0) ? false : "true".equalsIgnoreCase(this.mContext.getString(i));
  }
  
  public Double getDoubleFromString(String paramString) {
    paramString = getString(paramString);
    if (TextUtils.isEmpty(paramString))
      return null; 
    try {
      double d = Double.parseDouble(paramString);
      return Double.valueOf(d);
    } catch (NumberFormatException numberFormatException) {
      Log.w("NumberFormatException parsing " + paramString);
      return null;
    } 
  }
  
  public int getInt(String paramString, int paramInt) {
    int i = getResourceIdForType(paramString, "integer");
    if (i == 0)
      return paramInt; 
    try {
      return Integer.parseInt(this.mContext.getString(i));
    } catch (NumberFormatException numberFormatException) {
      Log.w("NumberFormatException parsing " + this.mContext.getString(i));
      return paramInt;
    } 
  }
  
  public String getString(String paramString) {
    int i = getResourceIdForType(paramString, "string");
    return (i == 0) ? null : this.mContext.getString(i);
  }
  
  public boolean isBooleanKeyPresent(String paramString) {
    return (getResourceIdForType(paramString, "bool") != 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\ParameterLoaderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */