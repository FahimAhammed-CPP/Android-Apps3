package com.google.analytics.tracking.android;

public class ExceptionReporter implements Thread.UncaughtExceptionHandler {
  private ExceptionParser mExceptionParser;
  
  private final Thread.UncaughtExceptionHandler mOriginalHandler;
  
  private final ServiceManager mServiceManager;
  
  private final Tracker mTracker;
  
  public ExceptionReporter(Tracker paramTracker, ServiceManager paramServiceManager, Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler) {
    String str;
    if (paramTracker == null)
      throw new NullPointerException("tracker cannot be null"); 
    if (paramServiceManager == null)
      throw new NullPointerException("serviceManager cannot be null"); 
    this.mOriginalHandler = paramUncaughtExceptionHandler;
    this.mTracker = paramTracker;
    this.mServiceManager = paramServiceManager;
    StringBuilder stringBuilder = (new StringBuilder()).append("ExceptionReporter created, original handler is ");
    if (paramUncaughtExceptionHandler == null) {
      str = "null";
    } else {
      str = paramUncaughtExceptionHandler.getClass().getName();
    } 
    Log.iDebug(stringBuilder.append(str).toString());
  }
  
  public ExceptionParser getExceptionParser() {
    return this.mExceptionParser;
  }
  
  public void setExceptionParser(ExceptionParser paramExceptionParser) {
    this.mExceptionParser = paramExceptionParser;
  }
  
  public void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    String str;
    if (this.mExceptionParser == null) {
      str = paramThrowable.getMessage();
    } else {
      if (paramThread != null) {
        str = paramThread.getName();
      } else {
        str = null;
      } 
      str = this.mExceptionParser.getDescription(str, paramThrowable);
    } 
    Log.iDebug("Tracking Exception: " + str);
    this.mTracker.sendException(str, true);
    this.mServiceManager.dispatch();
    if (this.mOriginalHandler != null) {
      Log.iDebug("Passing exception to original handler.");
      this.mOriginalHandler.uncaughtException(paramThread, paramThrowable);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\ExceptionReporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */