package com.google.analytics.tracking.android;

import android.app.IntentService;
import android.content.Intent;
import java.io.FileOutputStream;
import java.io.IOException;

public final class CampaignTrackingService extends IntentService {
  public CampaignTrackingService() {
    super("CampaignIntentService");
  }
  
  public CampaignTrackingService(String paramString) {
    super(paramString);
  }
  
  protected void onHandleIntent(Intent paramIntent) {
    String str = paramIntent.getStringExtra("referrer");
    try {
      FileOutputStream fileOutputStream = openFileOutput("gaInstallData", 0);
      fileOutputStream.write(str.getBytes());
      fileOutputStream.close();
      return;
    } catch (IOException iOException) {
      Log.e("Error storing install campaign.");
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\CampaignTrackingService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */