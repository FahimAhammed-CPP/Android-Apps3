package com.google.analytics.tracking.android;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.common.util.VisibleForTesting;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class EasyTracker {
  static final int NUM_MILLISECONDS_TO_WAIT_FOR_OPEN_ACTIVITY = 1000;
  
  private static EasyTracker sInstance;
  
  private int mActivitiesActive = 0;
  
  private final Map<String, String> mActivityNameMap = new HashMap<String, String>();
  
  private GoogleAnalytics mAnalyticsInstance;
  
  private String mAppName;
  
  private String mAppVersion;
  
  private Clock mClock = new Clock() {
      public long currentTimeMillis() {
        return System.currentTimeMillis();
      }
    };
  
  private Context mContext;
  
  private boolean mDebug;
  
  private int mDispatchPeriod = 1800;
  
  private Thread.UncaughtExceptionHandler mExceptionHandler;
  
  private boolean mIsAnonymizeIpEnabled;
  
  private boolean mIsAutoActivityTracking = false;
  
  private boolean mIsEnabled = false;
  
  private boolean mIsInForeground = false;
  
  private boolean mIsReportUncaughtExceptionsEnabled;
  
  private long mLastOnStopTime;
  
  private ParameterLoader mParameterFetcher;
  
  private Double mSampleRate;
  
  private ServiceManager mServiceManager;
  
  private long mSessionTimeout;
  
  private Timer mTimer;
  
  private TimerTask mTimerTask;
  
  private Tracker mTracker = null;
  
  private String mTrackingId;
  
  private void clearExistingTimer() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mTimer : Ljava/util/Timer;
    //   6: ifnull -> 21
    //   9: aload_0
    //   10: getfield mTimer : Ljava/util/Timer;
    //   13: invokevirtual cancel : ()V
    //   16: aload_0
    //   17: aconst_null
    //   18: putfield mTimer : Ljava/util/Timer;
    //   21: aload_0
    //   22: monitorexit
    //   23: return
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	24	finally
  }
  
  @VisibleForTesting
  static void clearTracker() {
    sInstance = null;
  }
  
  private String getActivityName(Activity paramActivity) {
    String str2 = paramActivity.getClass().getCanonicalName();
    if (this.mActivityNameMap.containsKey(str2))
      return this.mActivityNameMap.get(str2); 
    String str3 = this.mParameterFetcher.getString(str2);
    String str1 = str3;
    if (str3 == null)
      str1 = str2; 
    this.mActivityNameMap.put(str2, str1);
    return str1;
  }
  
  public static EasyTracker getInstance() {
    if (sInstance == null)
      sInstance = new EasyTracker(); 
    return sInstance;
  }
  
  public static Tracker getTracker() {
    if ((getInstance()).mContext == null)
      throw new IllegalStateException("You must call EasyTracker.getInstance().setContext(context) or startActivity(activity) before calling getTracker()"); 
    return (getInstance()).mTracker;
  }
  
  private void loadParameters() {
    boolean bool2 = true;
    this.mTrackingId = this.mParameterFetcher.getString("ga_trackingId");
    if (TextUtils.isEmpty(this.mTrackingId)) {
      this.mTrackingId = this.mParameterFetcher.getString("ga_api_key");
      if (TextUtils.isEmpty(this.mTrackingId)) {
        Log.e("EasyTracker requested, but missing required ga_trackingId");
        this.mTracker = new NoopTracker();
        return;
      } 
    } 
    this.mIsEnabled = true;
    this.mAppName = this.mParameterFetcher.getString("ga_appName");
    this.mAppVersion = this.mParameterFetcher.getString("ga_appVersion");
    this.mDebug = this.mParameterFetcher.getBoolean("ga_debug");
    this.mSampleRate = this.mParameterFetcher.getDoubleFromString("ga_sampleFrequency");
    if (this.mSampleRate == null)
      this.mSampleRate = new Double(this.mParameterFetcher.getInt("ga_sampleRate", 100)); 
    this.mDispatchPeriod = this.mParameterFetcher.getInt("ga_dispatchPeriod", 1800);
    this.mSessionTimeout = (this.mParameterFetcher.getInt("ga_sessionTimeout", 30) * 1000);
    boolean bool1 = bool2;
    if (!this.mParameterFetcher.getBoolean("ga_autoActivityTracking"))
      if (this.mParameterFetcher.getBoolean("ga_auto_activity_tracking")) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    this.mIsAutoActivityTracking = bool1;
    this.mIsAnonymizeIpEnabled = this.mParameterFetcher.getBoolean("ga_anonymizeIp");
    this.mIsReportUncaughtExceptionsEnabled = this.mParameterFetcher.getBoolean("ga_reportUncaughtExceptions");
    this.mTracker = this.mAnalyticsInstance.getTracker(this.mTrackingId);
    if (!TextUtils.isEmpty(this.mAppName)) {
      Log.i("setting appName to " + this.mAppName);
      this.mTracker.setAppName(this.mAppName);
    } 
    if (this.mAppVersion != null)
      this.mTracker.setAppVersion(this.mAppVersion); 
    this.mTracker.setAnonymizeIp(this.mIsAnonymizeIpEnabled);
    this.mTracker.setSampleRate(this.mSampleRate.doubleValue());
    this.mAnalyticsInstance.setDebug(this.mDebug);
    this.mServiceManager.setDispatchPeriod(this.mDispatchPeriod);
    if (this.mIsReportUncaughtExceptionsEnabled) {
      Thread.UncaughtExceptionHandler uncaughtExceptionHandler2 = this.mExceptionHandler;
      Thread.UncaughtExceptionHandler uncaughtExceptionHandler1 = uncaughtExceptionHandler2;
      if (uncaughtExceptionHandler2 == null)
        uncaughtExceptionHandler1 = new ExceptionReporter(this.mTracker, this.mServiceManager, Thread.getDefaultUncaughtExceptionHandler()); 
      Thread.setDefaultUncaughtExceptionHandler(uncaughtExceptionHandler1);
      return;
    } 
  }
  
  public void activityStart(Activity paramActivity) {
    setContext((Context)paramActivity);
    if (this.mIsEnabled) {
      clearExistingTimer();
      if (!this.mIsInForeground && this.mActivitiesActive == 0 && checkForNewSession()) {
        this.mTracker.setStartSession(true);
        if (!this.mIsAutoActivityTracking);
      } 
      this.mIsInForeground = true;
      this.mActivitiesActive++;
      if (this.mIsAutoActivityTracking) {
        this.mTracker.sendView(getActivityName(paramActivity));
        return;
      } 
    } 
  }
  
  public void activityStop(Activity paramActivity) {
    setContext((Context)paramActivity);
    if (this.mIsEnabled) {
      this.mActivitiesActive--;
      this.mActivitiesActive = Math.max(0, this.mActivitiesActive);
      this.mLastOnStopTime = this.mClock.currentTimeMillis();
      if (this.mActivitiesActive == 0) {
        clearExistingTimer();
        this.mTimerTask = new NotInForegroundTimerTask();
        this.mTimer = new Timer("waitForActivityStart");
        this.mTimer.schedule(this.mTimerTask, 1000L);
        return;
      } 
    } 
  }
  
  boolean checkForNewSession() {
    return (this.mSessionTimeout == 0L || (this.mSessionTimeout > 0L && this.mClock.currentTimeMillis() > this.mLastOnStopTime + this.mSessionTimeout));
  }
  
  public void dispatch() {
    if (this.mIsEnabled)
      this.mServiceManager.dispatch(); 
  }
  
  @VisibleForTesting
  int getActivitiesActive() {
    return this.mActivitiesActive;
  }
  
  @VisibleForTesting
  void setClock(Clock paramClock) {
    this.mClock = paramClock;
  }
  
  public void setContext(Context paramContext) {
    if (paramContext == null) {
      Log.e("Context cannot be null");
      return;
    } 
    GAServiceManager gAServiceManager = GAServiceManager.getInstance();
    setContext(paramContext, new ParameterLoaderImpl(paramContext.getApplicationContext()), GoogleAnalytics.getInstance(paramContext.getApplicationContext()), gAServiceManager);
  }
  
  @VisibleForTesting
  void setContext(Context paramContext, ParameterLoader paramParameterLoader, GoogleAnalytics paramGoogleAnalytics, ServiceManager paramServiceManager) {
    if (paramContext == null)
      Log.e("Context cannot be null"); 
    if (this.mContext == null) {
      this.mContext = paramContext.getApplicationContext();
      this.mAnalyticsInstance = paramGoogleAnalytics;
      this.mServiceManager = paramServiceManager;
      this.mParameterFetcher = paramParameterLoader;
      loadParameters();
    } 
  }
  
  @VisibleForTesting
  void setUncaughtExceptionHandler(Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler) {
    this.mExceptionHandler = paramUncaughtExceptionHandler;
  }
  
  class NoopTracker extends Tracker {
    private String mAppId;
    
    private String mAppInstallerId;
    
    private ExceptionParser mExceptionParser;
    
    private boolean mIsAnonymizeIp;
    
    private boolean mIsUseSecure;
    
    private double mSampleRate = 100.0D;
    
    public void close() {}
    
    public Map<String, String> constructEvent(String param1String1, String param1String2, String param1String3, Long param1Long) {
      return new HashMap<String, String>();
    }
    
    public Map<String, String> constructException(String param1String, boolean param1Boolean) {
      return new HashMap<String, String>();
    }
    
    public Map<String, String> constructRawException(String param1String, Throwable param1Throwable, boolean param1Boolean) {
      return new HashMap<String, String>();
    }
    
    public Map<String, String> constructSocial(String param1String1, String param1String2, String param1String3) {
      return new HashMap<String, String>();
    }
    
    public Map<String, String> constructTiming(String param1String1, long param1Long, String param1String2, String param1String3) {
      return new HashMap<String, String>();
    }
    
    public Map<String, String> constructTransaction(Transaction param1Transaction) {
      return new HashMap<String, String>();
    }
    
    public String get(String param1String) {
      return "";
    }
    
    public String getAppId() {
      return this.mAppId;
    }
    
    public String getAppInstallerId() {
      return this.mAppInstallerId;
    }
    
    public ExceptionParser getExceptionParser() {
      return this.mExceptionParser;
    }
    
    public double getSampleRate() {
      return this.mSampleRate;
    }
    
    public String getTrackingId() {
      return "";
    }
    
    public boolean isAnonymizeIpEnabled() {
      return this.mIsAnonymizeIp;
    }
    
    public boolean isUseSecure() {
      return this.mIsUseSecure;
    }
    
    public void send(String param1String, Map<String, String> param1Map) {}
    
    public void sendEvent(String param1String1, String param1String2, String param1String3, Long param1Long) {}
    
    public void sendException(String param1String, Throwable param1Throwable, boolean param1Boolean) {}
    
    public void sendException(String param1String, boolean param1Boolean) {}
    
    public void sendSocial(String param1String1, String param1String2, String param1String3) {}
    
    public void sendTiming(String param1String1, long param1Long, String param1String2, String param1String3) {}
    
    public void sendTransaction(Transaction param1Transaction) {}
    
    public void sendView() {}
    
    public void sendView(String param1String) {}
    
    public void set(String param1String1, String param1String2) {}
    
    public void setAnonymizeIp(boolean param1Boolean) {
      this.mIsAnonymizeIp = param1Boolean;
    }
    
    public void setAppId(String param1String) {
      this.mAppId = param1String;
    }
    
    public void setAppInstallerId(String param1String) {
      this.mAppInstallerId = param1String;
    }
    
    public void setAppName(String param1String) {}
    
    public void setAppScreen(String param1String) {}
    
    public void setAppVersion(String param1String) {}
    
    public void setCampaign(String param1String) {}
    
    public void setCustomDimension(int param1Int, String param1String) {}
    
    public void setCustomDimensionsAndMetrics(Map<Integer, String> param1Map, Map<Integer, Long> param1Map1) {}
    
    public void setCustomMetric(int param1Int, Long param1Long) {}
    
    public void setExceptionParser(ExceptionParser param1ExceptionParser) {
      this.mExceptionParser = param1ExceptionParser;
    }
    
    public void setReferrer(String param1String) {}
    
    public void setSampleRate(double param1Double) {
      this.mSampleRate = param1Double;
    }
    
    public void setStartSession(boolean param1Boolean) {}
    
    public void setUseSecure(boolean param1Boolean) {
      this.mIsUseSecure = param1Boolean;
    }
  }
  
  private class NotInForegroundTimerTask extends TimerTask {
    private NotInForegroundTimerTask() {}
    
    public void run() {
      EasyTracker.access$102(EasyTracker.this, false);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\EasyTracker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */