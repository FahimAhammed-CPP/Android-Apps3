package com.google.analytics.tracking.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

class GANetworkReceiver extends BroadcastReceiver {
  private final ServiceManager mManager;
  
  GANetworkReceiver(ServiceManager paramServiceManager) {
    this.mManager = paramServiceManager;
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if ("android.net.conn.CONNECTIVITY_CHANGE".equals(paramIntent.getAction())) {
      boolean bool1;
      Bundle bundle = paramIntent.getExtras();
      Boolean bool = Boolean.FALSE;
      if (bundle != null)
        bool = Boolean.valueOf(paramIntent.getExtras().getBoolean("noConnectivity")); 
      ServiceManager serviceManager = this.mManager;
      if (!bool.booleanValue()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      serviceManager.updateConnectivityStatus(bool1);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\GANetworkReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */