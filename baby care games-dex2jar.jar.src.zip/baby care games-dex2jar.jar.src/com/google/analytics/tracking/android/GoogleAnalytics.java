package com.google.analytics.tracking.android;

import android.content.Context;
import com.google.android.gms.common.util.VisibleForTesting;
import java.util.HashMap;
import java.util.Map;

public class GoogleAnalytics implements TrackerHandler {
  private static GoogleAnalytics sInstance;
  
  private AdHitIdGenerator mAdHitIdGenerator;
  
  private volatile Boolean mAppOptOut;
  
  private volatile String mClientId;
  
  private Context mContext;
  
  private boolean mDebug;
  
  private Tracker mDefaultTracker;
  
  private String mLastTrackingId;
  
  private AnalyticsThread mThread;
  
  private final Map<String, Tracker> mTrackers = new HashMap<String, Tracker>();
  
  @VisibleForTesting
  GoogleAnalytics() {}
  
  private GoogleAnalytics(Context paramContext) {
    this(paramContext, GAThread.getInstance(paramContext));
  }
  
  private GoogleAnalytics(Context paramContext, AnalyticsThread paramAnalyticsThread) {
    if (paramContext == null)
      throw new IllegalArgumentException("context cannot be null"); 
    this.mContext = paramContext.getApplicationContext();
    this.mThread = paramAnalyticsThread;
    this.mAdHitIdGenerator = new AdHitIdGenerator();
    this.mThread.requestAppOptOut(new AppOptOutCallback() {
          public void reportAppOptOut(boolean param1Boolean) {
            GoogleAnalytics.access$002(GoogleAnalytics.this, Boolean.valueOf(param1Boolean));
          }
        });
    this.mThread.requestClientId(new AnalyticsThread.ClientIdCallback() {
          public void reportClientId(String param1String) {
            GoogleAnalytics.access$102(GoogleAnalytics.this, param1String);
          }
        });
  }
  
  @VisibleForTesting
  static void clearInstance() {
    // Byte code:
    //   0: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   2: monitorenter
    //   3: aconst_null
    //   4: putstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   7: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	10	11	finally
    //   12	15	11	finally
  }
  
  static GoogleAnalytics getInstance() {
    // Byte code:
    //   0: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   2: monitorenter
    //   3: getstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   6: astore_0
    //   7: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	10	12	finally
    //   13	16	12	finally
  }
  
  public static GoogleAnalytics getInstance(Context paramContext) {
    // Byte code:
    //   0: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   2: monitorenter
    //   3: getstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   6: ifnonnull -> 20
    //   9: new com/google/analytics/tracking/android/GoogleAnalytics
    //   12: dup
    //   13: aload_0
    //   14: invokespecial <init> : (Landroid/content/Context;)V
    //   17: putstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   20: getstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   23: astore_0
    //   24: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   26: monitorexit
    //   27: aload_0
    //   28: areturn
    //   29: astore_0
    //   30: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   32: monitorexit
    //   33: aload_0
    //   34: athrow
    // Exception table:
    //   from	to	target	type
    //   3	20	29	finally
    //   20	27	29	finally
    //   30	33	29	finally
  }
  
  @VisibleForTesting
  static GoogleAnalytics getNewInstance(Context paramContext, AnalyticsThread paramAnalyticsThread) {
    // Byte code:
    //   0: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   2: monitorenter
    //   3: getstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   6: ifnull -> 15
    //   9: getstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   12: invokevirtual close : ()V
    //   15: new com/google/analytics/tracking/android/GoogleAnalytics
    //   18: dup
    //   19: aload_0
    //   20: aload_1
    //   21: invokespecial <init> : (Landroid/content/Context;Lcom/google/analytics/tracking/android/AnalyticsThread;)V
    //   24: putstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   27: getstatic com/google/analytics/tracking/android/GoogleAnalytics.sInstance : Lcom/google/analytics/tracking/android/GoogleAnalytics;
    //   30: astore_0
    //   31: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   33: monitorexit
    //   34: aload_0
    //   35: areturn
    //   36: astore_0
    //   37: ldc com/google/analytics/tracking/android/GoogleAnalytics
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   3	15	36	finally
    //   15	34	36	finally
    //   37	40	36	finally
  }
  
  @VisibleForTesting
  void close() {}
  
  public void closeTracker(Tracker paramTracker) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mTrackers : Ljava/util/Map;
    //   6: invokeinterface values : ()Ljava/util/Collection;
    //   11: aload_1
    //   12: invokeinterface remove : (Ljava/lang/Object;)Z
    //   17: pop
    //   18: aload_1
    //   19: aload_0
    //   20: getfield mDefaultTracker : Lcom/google/analytics/tracking/android/Tracker;
    //   23: if_acmpne -> 31
    //   26: aload_0
    //   27: aconst_null
    //   28: putfield mDefaultTracker : Lcom/google/analytics/tracking/android/Tracker;
    //   31: aload_0
    //   32: monitorexit
    //   33: return
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: athrow
    // Exception table:
    //   from	to	target	type
    //   2	31	34	finally
    //   31	33	34	finally
    //   35	37	34	finally
  }
  
  @VisibleForTesting
  Boolean getAppOptOut() {
    return this.mAppOptOut;
  }
  
  String getClientIdForAds() {
    return (this.mClientId == null) ? null : this.mClientId.toString();
  }
  
  public Tracker getDefaultTracker() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic getInstance : ()Lcom/google/analytics/tracking/android/GAUsage;
    //   5: getstatic com/google/analytics/tracking/android/GAUsage$Field.GET_DEFAULT_TRACKER : Lcom/google/analytics/tracking/android/GAUsage$Field;
    //   8: invokevirtual setUsage : (Lcom/google/analytics/tracking/android/GAUsage$Field;)V
    //   11: aload_0
    //   12: getfield mDefaultTracker : Lcom/google/analytics/tracking/android/Tracker;
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: areturn
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	20	finally
    //   21	23	20	finally
  }
  
  public Tracker getTracker(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 21
    //   6: new java/lang/IllegalArgumentException
    //   9: dup
    //   10: ldc 'trackingId cannot be null'
    //   12: invokespecial <init> : (Ljava/lang/String;)V
    //   15: athrow
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    //   21: aload_0
    //   22: getfield mTrackers : Ljava/util/Map;
    //   25: aload_1
    //   26: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   31: checkcast com/google/analytics/tracking/android/Tracker
    //   34: astore_3
    //   35: aload_3
    //   36: astore_2
    //   37: aload_3
    //   38: ifnonnull -> 79
    //   41: new com/google/analytics/tracking/android/Tracker
    //   44: dup
    //   45: aload_1
    //   46: aload_0
    //   47: invokespecial <init> : (Ljava/lang/String;Lcom/google/analytics/tracking/android/TrackerHandler;)V
    //   50: astore_3
    //   51: aload_0
    //   52: getfield mTrackers : Ljava/util/Map;
    //   55: aload_1
    //   56: aload_3
    //   57: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   62: pop
    //   63: aload_3
    //   64: astore_2
    //   65: aload_0
    //   66: getfield mDefaultTracker : Lcom/google/analytics/tracking/android/Tracker;
    //   69: ifnonnull -> 79
    //   72: aload_0
    //   73: aload_3
    //   74: putfield mDefaultTracker : Lcom/google/analytics/tracking/android/Tracker;
    //   77: aload_3
    //   78: astore_2
    //   79: invokestatic getInstance : ()Lcom/google/analytics/tracking/android/GAUsage;
    //   82: getstatic com/google/analytics/tracking/android/GAUsage$Field.GET_TRACKER : Lcom/google/analytics/tracking/android/GAUsage$Field;
    //   85: invokevirtual setUsage : (Lcom/google/analytics/tracking/android/GAUsage$Field;)V
    //   88: aload_0
    //   89: monitorexit
    //   90: aload_2
    //   91: areturn
    // Exception table:
    //   from	to	target	type
    //   6	16	16	finally
    //   17	19	16	finally
    //   21	35	16	finally
    //   41	63	16	finally
    //   65	77	16	finally
    //   79	90	16	finally
  }
  
  String getTrackingIdForAds() {
    return this.mLastTrackingId;
  }
  
  public boolean isDebugEnabled() {
    GAUsage.getInstance().setUsage(GAUsage.Field.GET_DEBUG);
    return this.mDebug;
  }
  
  public void requestAppOptOut(AppOptOutCallback paramAppOptOutCallback) {
    GAUsage.getInstance().setUsage(GAUsage.Field.REQUEST_APP_OPT_OUT);
    if (this.mAppOptOut != null) {
      paramAppOptOutCallback.reportAppOptOut(this.mAppOptOut.booleanValue());
      return;
    } 
    this.mThread.requestAppOptOut(paramAppOptOutCallback);
  }
  
  public void sendHit(Map<String, String> paramMap) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 21
    //   6: new java/lang/IllegalArgumentException
    //   9: dup
    //   10: ldc 'hit cannot be null'
    //   12: invokespecial <init> : (Ljava/lang/String;)V
    //   15: athrow
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    //   21: aload_1
    //   22: ldc 'language'
    //   24: invokestatic getDefault : ()Ljava/util/Locale;
    //   27: invokestatic getLanguage : (Ljava/util/Locale;)Ljava/lang/String;
    //   30: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   35: pop
    //   36: aload_1
    //   37: ldc 'adSenseAdMobHitId'
    //   39: aload_0
    //   40: getfield mAdHitIdGenerator : Lcom/google/analytics/tracking/android/AdHitIdGenerator;
    //   43: invokevirtual getAdHitId : ()I
    //   46: invokestatic toString : (I)Ljava/lang/String;
    //   49: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   54: pop
    //   55: aload_1
    //   56: ldc 'screenResolution'
    //   58: new java/lang/StringBuilder
    //   61: dup
    //   62: invokespecial <init> : ()V
    //   65: aload_0
    //   66: getfield mContext : Landroid/content/Context;
    //   69: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   72: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   75: getfield widthPixels : I
    //   78: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   81: ldc 'x'
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: aload_0
    //   87: getfield mContext : Landroid/content/Context;
    //   90: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   93: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   96: getfield heightPixels : I
    //   99: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   102: invokevirtual toString : ()Ljava/lang/String;
    //   105: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   110: pop
    //   111: aload_1
    //   112: ldc_w 'usage'
    //   115: invokestatic getInstance : ()Lcom/google/analytics/tracking/android/GAUsage;
    //   118: invokevirtual getAndClearSequence : ()Ljava/lang/String;
    //   121: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   126: pop
    //   127: invokestatic getInstance : ()Lcom/google/analytics/tracking/android/GAUsage;
    //   130: invokevirtual getAndClearUsage : ()Ljava/lang/String;
    //   133: pop
    //   134: aload_0
    //   135: getfield mThread : Lcom/google/analytics/tracking/android/AnalyticsThread;
    //   138: aload_1
    //   139: invokeinterface sendHit : (Ljava/util/Map;)V
    //   144: aload_0
    //   145: aload_1
    //   146: ldc_w 'trackingId'
    //   149: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   154: checkcast java/lang/String
    //   157: putfield mLastTrackingId : Ljava/lang/String;
    //   160: aload_0
    //   161: monitorexit
    //   162: return
    // Exception table:
    //   from	to	target	type
    //   6	16	16	finally
    //   17	19	16	finally
    //   21	162	16	finally
  }
  
  public void setAppOptOut(boolean paramBoolean) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_APP_OPT_OUT);
    this.mAppOptOut = Boolean.valueOf(paramBoolean);
    this.mThread.setAppOptOut(paramBoolean);
  }
  
  public void setDebug(boolean paramBoolean) {
    GAUsage.getInstance().setUsage(GAUsage.Field.SET_DEBUG);
    this.mDebug = paramBoolean;
    Log.setDebug(paramBoolean);
  }
  
  public void setDefaultTracker(Tracker paramTracker) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic getInstance : ()Lcom/google/analytics/tracking/android/GAUsage;
    //   5: getstatic com/google/analytics/tracking/android/GAUsage$Field.SET_DEFAULT_TRACKER : Lcom/google/analytics/tracking/android/GAUsage$Field;
    //   8: invokevirtual setUsage : (Lcom/google/analytics/tracking/android/GAUsage$Field;)V
    //   11: aload_0
    //   12: aload_1
    //   13: putfield mDefaultTracker : Lcom/google/analytics/tracking/android/Tracker;
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	19	finally
    //   20	22	19	finally
  }
  
  public static interface AppOptOutCallback {
    void reportAppOptOut(boolean param1Boolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\GoogleAnalytics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */