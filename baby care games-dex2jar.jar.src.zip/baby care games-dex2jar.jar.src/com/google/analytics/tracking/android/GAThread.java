package com.google.analytics.tracking.android;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import com.google.android.gms.analytics.internal.Command;
import com.google.android.gms.common.util.VisibleForTesting;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;

class GAThread extends Thread implements AnalyticsThread {
  static final String API_VERSION = "1";
  
  private static final String CLIENT_VERSION = "ma1b4";
  
  private static final int MAX_SAMPLE_RATE = 100;
  
  private static final int SAMPLE_RATE_MODULO = 10000;
  
  private static final int SAMPLE_RATE_MULTIPLIER = 100;
  
  private static GAThread sInstance;
  
  private volatile boolean mAppOptOut;
  
  private volatile String mClientId;
  
  private volatile boolean mClosed = false;
  
  private volatile List<Command> mCommands;
  
  private final Context mContext;
  
  private volatile boolean mDisabled = false;
  
  private volatile String mInstallCampaign;
  
  private volatile MetaModel mMetaModel;
  
  private volatile ServiceProxy mServiceProxy;
  
  private final LinkedBlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();
  
  private GAThread(Context paramContext) {
    super("GAThread");
    if (paramContext != null) {
      this.mContext = paramContext.getApplicationContext();
    } else {
      this.mContext = paramContext;
    } 
    start();
  }
  
  @VisibleForTesting
  GAThread(Context paramContext, ServiceProxy paramServiceProxy) {
    super("GAThread");
    if (paramContext != null) {
      this.mContext = paramContext.getApplicationContext();
    } else {
      this.mContext = paramContext;
    } 
    this.mServiceProxy = paramServiceProxy;
    start();
  }
  
  private void fillAppParameters(Map<String, String> paramMap) {
    String str3;
    PackageManager packageManager = this.mContext.getPackageManager();
    String str4 = this.mContext.getPackageName();
    String str6 = packageManager.getInstallerPackageName(str4);
    String str2 = str4;
    String str5 = null;
    String str1 = str2;
    try {
      PackageInfo packageInfo = packageManager.getPackageInfo(this.mContext.getPackageName(), 0);
      str1 = str2;
      str3 = str5;
      if (packageInfo != null) {
        str1 = str2;
        str2 = packageManager.getApplicationLabel(packageInfo.applicationInfo).toString();
        str1 = str2;
        str3 = packageInfo.versionName;
        str1 = str2;
      } 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("Error retrieving package info: appName set to " + str1);
      str3 = str5;
    } 
    putIfAbsent(paramMap, "appName", str1);
    putIfAbsent(paramMap, "appVersion", str3);
    putIfAbsent(paramMap, "appId", str4);
    putIfAbsent(paramMap, "appInstallerId", str6);
    paramMap.put("apiVersion", "1");
  }
  
  private void fillCampaignParameters(Map<String, String> paramMap) {
    String str = Utils.filterCampaign(paramMap.get("campaign"));
    if (TextUtils.isEmpty(str))
      return; 
    Map<String, String> map = Utils.parseURLParameters(str);
    paramMap.put("campaignContent", map.get("utm_content"));
    paramMap.put("campaignMedium", map.get("utm_medium"));
    paramMap.put("campaignName", map.get("utm_campaign"));
    paramMap.put("campaignSource", map.get("utm_source"));
    paramMap.put("campaignKeyword", map.get("utm_term"));
    paramMap.put("campaignId", map.get("utm_id"));
    paramMap.put("gclid", map.get("gclid"));
    paramMap.put("dclid", map.get("dclid"));
    paramMap.put("gmob_t", map.get("gmob_t"));
  }
  
  private void fillExceptionParameters(Map<String, String> paramMap) {
    String str = paramMap.get("rawException");
    if (str != null) {
      paramMap.remove("rawException");
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(Utils.hexDecode(str));
      try {
        ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
        Object object = objectInputStream.readObject();
        objectInputStream.close();
        if (object instanceof Throwable) {
          Throwable throwable = (Throwable)object;
          object = new ArrayList();
          paramMap.put("exDescription", (new StandardExceptionParser(this.mContext, (Collection<String>)object)).getDescription(paramMap.get("exceptionThreadName"), throwable));
          return;
        } 
        return;
      } catch (IOException iOException) {
        Log.w("IOException reading exception");
        return;
      } catch (ClassNotFoundException classNotFoundException) {
        Log.w("ClassNotFoundException reading exception");
        return;
      } 
    } 
  }
  
  private String generateClientId() {
    String str2 = UUID.randomUUID().toString().toLowerCase();
    String str1 = str2;
    if (!storeClientId(str2))
      str1 = "0"; 
    return str1;
  }
  
  @VisibleForTesting
  static String getAndClearCampaign(Context paramContext) {
    try {
      FileInputStream fileInputStream = paramContext.openFileInput("gaInstallData");
      byte[] arrayOfByte = new byte[8192];
      int i = fileInputStream.read(arrayOfByte, 0, 8192);
      if (fileInputStream.available() > 0) {
        Log.e("Too much campaign data, ignoring it.");
        fileInputStream.close();
        paramContext.deleteFile("gaInstallData");
        return null;
      } 
      fileInputStream.close();
      paramContext.deleteFile("gaInstallData");
      if (i <= 0) {
        Log.w("Campaign file is empty.");
        return null;
      } 
      String str = new String(arrayOfByte, 0, i);
      Log.i("Campaign found: " + str);
      return str;
    } catch (FileNotFoundException fileNotFoundException) {
      Log.i("No campaign data found.");
      return null;
    } catch (IOException iOException) {
      Log.e("Error reading campaign data.");
      fileNotFoundException.deleteFile("gaInstallData");
      return null;
    } 
  }
  
  private String getHostUrl(Map<String, String> paramMap) {
    String str2 = paramMap.get("internalHitUrl");
    String str1 = str2;
    if (str2 == null) {
      if (paramMap.containsKey("useSecure"))
        return Utils.safeParseBoolean(paramMap.get("useSecure")) ? "https://ssl.google-analytics.com/collect" : "http://www.google-analytics.com/collect"; 
    } else {
      return str1;
    } 
    return "https://ssl.google-analytics.com/collect";
  }
  
  static GAThread getInstance(Context paramContext) {
    if (sInstance == null)
      sInstance = new GAThread(paramContext); 
    return sInstance;
  }
  
  private void init() {
    this.mServiceProxy.createService();
    this.mCommands = new ArrayList<Command>();
    this.mCommands.add(new Command("appendVersion", "_v", "ma1b4"));
    this.mCommands.add(new Command("appendQueueTime", "qt", null));
    this.mCommands.add(new Command("appendCacheBuster", "z", null));
    this.mMetaModel = new MetaModel();
    MetaModelInitializer.set(this.mMetaModel);
  }
  
  private boolean isSampledOut(Map<String, String> paramMap) {
    if (paramMap.get("sampleRate") != null) {
      double d = Utils.safeParseDouble(paramMap.get("sampleRate"));
      if (d <= 0.0D)
        return true; 
      if (d < 100.0D) {
        String str = paramMap.get("clientId");
        if (str != null && (Math.abs(str.hashCode()) % 10000) >= 100.0D * d)
          return true; 
      } 
    } 
    return false;
  }
  
  private boolean loadAppOptOut() {
    return this.mContext.getFileStreamPath("gaOptOut").exists();
  }
  
  private String printStackTrace(Throwable paramThrowable) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(byteArrayOutputStream);
    paramThrowable.printStackTrace(printStream);
    printStream.flush();
    return new String(byteArrayOutputStream.toByteArray());
  }
  
  private void putIfAbsent(Map<String, String> paramMap, String paramString1, String paramString2) {
    if (!paramMap.containsKey(paramString1))
      paramMap.put(paramString1, paramString2); 
  }
  
  private void queueToThread(Runnable paramRunnable) {
    this.queue.add(paramRunnable);
  }
  
  private boolean storeClientId(String paramString) {
    try {
      FileOutputStream fileOutputStream = this.mContext.openFileOutput("gaClientId", 0);
      fileOutputStream.write(paramString.getBytes());
      fileOutputStream.close();
      return true;
    } catch (FileNotFoundException fileNotFoundException) {
      Log.e("Error creating clientId file.");
      return false;
    } catch (IOException iOException) {
      Log.e("Error writing to clientId file.");
      return false;
    } 
  }
  
  @VisibleForTesting
  void close() {
    this.mClosed = true;
    interrupt();
  }
  
  public void dispatch() {
    queueToThread(new Runnable() {
          public void run() {
            GAThread.this.mServiceProxy.dispatch();
          }
        });
  }
  
  public LinkedBlockingQueue<Runnable> getQueue() {
    return this.queue;
  }
  
  public Thread getThread() {
    return this;
  }
  
  @VisibleForTesting
  String initializeClientId() {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore #5
    //   6: aconst_null
    //   7: astore_3
    //   8: aload_0
    //   9: getfield mContext : Landroid/content/Context;
    //   12: ldc_w 'gaClientId'
    //   15: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   18: astore #6
    //   20: sipush #128
    //   23: newarray byte
    //   25: astore_2
    //   26: aload #6
    //   28: aload_2
    //   29: iconst_0
    //   30: sipush #128
    //   33: invokevirtual read : ([BII)I
    //   36: istore_1
    //   37: aload #6
    //   39: invokevirtual available : ()I
    //   42: ifle -> 68
    //   45: ldc_w 'clientId file seems corrupted, deleting it.'
    //   48: invokestatic e : (Ljava/lang/String;)I
    //   51: pop
    //   52: aload #6
    //   54: invokevirtual close : ()V
    //   57: aload_0
    //   58: getfield mContext : Landroid/content/Context;
    //   61: ldc_w 'gaInstallData'
    //   64: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   67: pop
    //   68: iload_1
    //   69: ifgt -> 110
    //   72: ldc_w 'clientId file seems empty, deleting it.'
    //   75: invokestatic e : (Ljava/lang/String;)I
    //   78: pop
    //   79: aload #6
    //   81: invokevirtual close : ()V
    //   84: aload_0
    //   85: getfield mContext : Landroid/content/Context;
    //   88: ldc_w 'gaInstallData'
    //   91: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   94: pop
    //   95: aload_3
    //   96: astore_2
    //   97: aload_2
    //   98: astore_3
    //   99: aload_2
    //   100: ifnonnull -> 108
    //   103: aload_0
    //   104: invokespecial generateClientId : ()Ljava/lang/String;
    //   107: astore_3
    //   108: aload_3
    //   109: areturn
    //   110: new java/lang/String
    //   113: dup
    //   114: aload_2
    //   115: iconst_0
    //   116: iload_1
    //   117: invokespecial <init> : ([BII)V
    //   120: astore_2
    //   121: aload #6
    //   123: invokevirtual close : ()V
    //   126: goto -> 97
    //   129: astore_2
    //   130: aload #4
    //   132: astore_2
    //   133: ldc_w 'Error reading clientId file, deleting it.'
    //   136: invokestatic e : (Ljava/lang/String;)I
    //   139: pop
    //   140: aload_0
    //   141: getfield mContext : Landroid/content/Context;
    //   144: ldc_w 'gaInstallData'
    //   147: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   150: pop
    //   151: goto -> 97
    //   154: astore_2
    //   155: aload #5
    //   157: astore_2
    //   158: ldc_w 'cliendId file doesn't have long value, deleting it.'
    //   161: invokestatic e : (Ljava/lang/String;)I
    //   164: pop
    //   165: aload_0
    //   166: getfield mContext : Landroid/content/Context;
    //   169: ldc_w 'gaInstallData'
    //   172: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   175: pop
    //   176: goto -> 97
    //   179: astore_3
    //   180: goto -> 158
    //   183: astore_3
    //   184: goto -> 133
    //   187: astore_2
    //   188: aload_3
    //   189: astore_2
    //   190: goto -> 97
    //   193: astore_3
    //   194: goto -> 97
    // Exception table:
    //   from	to	target	type
    //   8	68	187	java/io/FileNotFoundException
    //   8	68	129	java/io/IOException
    //   8	68	154	java/lang/NumberFormatException
    //   72	95	187	java/io/FileNotFoundException
    //   72	95	129	java/io/IOException
    //   72	95	154	java/lang/NumberFormatException
    //   110	121	187	java/io/FileNotFoundException
    //   110	121	129	java/io/IOException
    //   110	121	154	java/lang/NumberFormatException
    //   121	126	193	java/io/FileNotFoundException
    //   121	126	183	java/io/IOException
    //   121	126	179	java/lang/NumberFormatException
  }
  
  @VisibleForTesting
  boolean isDisabled() {
    return this.mDisabled;
  }
  
  public void requestAppOptOut(final GoogleAnalytics.AppOptOutCallback callback) {
    queueToThread(new Runnable() {
          public void run() {
            callback.reportAppOptOut(GAThread.this.mAppOptOut);
          }
        });
  }
  
  public void requestClientId(final AnalyticsThread.ClientIdCallback callback) {
    queueToThread(new Runnable() {
          public void run() {
            callback.reportClientId(GAThread.this.mClientId);
          }
        });
  }
  
  public void run() {
    // Byte code:
    //   0: ldc2_w 5000
    //   3: invokestatic sleep : (J)V
    //   6: aload_0
    //   7: getfield mServiceProxy : Lcom/google/analytics/tracking/android/ServiceProxy;
    //   10: ifnonnull -> 29
    //   13: aload_0
    //   14: new com/google/analytics/tracking/android/GAServiceProxy
    //   17: dup
    //   18: aload_0
    //   19: getfield mContext : Landroid/content/Context;
    //   22: aload_0
    //   23: invokespecial <init> : (Landroid/content/Context;Lcom/google/analytics/tracking/android/AnalyticsThread;)V
    //   26: putfield mServiceProxy : Lcom/google/analytics/tracking/android/ServiceProxy;
    //   29: aload_0
    //   30: invokespecial init : ()V
    //   33: aload_0
    //   34: aload_0
    //   35: invokespecial loadAppOptOut : ()Z
    //   38: putfield mAppOptOut : Z
    //   41: aload_0
    //   42: aload_0
    //   43: invokevirtual initializeClientId : ()Ljava/lang/String;
    //   46: putfield mClientId : Ljava/lang/String;
    //   49: aload_0
    //   50: aload_0
    //   51: getfield mContext : Landroid/content/Context;
    //   54: invokestatic getAndClearCampaign : (Landroid/content/Context;)Ljava/lang/String;
    //   57: putfield mInstallCampaign : Ljava/lang/String;
    //   60: aload_0
    //   61: getfield mClosed : Z
    //   64: ifne -> 205
    //   67: aload_0
    //   68: getfield queue : Ljava/util/concurrent/LinkedBlockingQueue;
    //   71: invokevirtual take : ()Ljava/lang/Object;
    //   74: checkcast java/lang/Runnable
    //   77: astore_1
    //   78: aload_0
    //   79: getfield mDisabled : Z
    //   82: ifne -> 60
    //   85: aload_1
    //   86: invokeinterface run : ()V
    //   91: goto -> 60
    //   94: astore_1
    //   95: aload_1
    //   96: invokevirtual toString : ()Ljava/lang/String;
    //   99: invokestatic i : (Ljava/lang/String;)I
    //   102: pop
    //   103: goto -> 60
    //   106: astore_1
    //   107: new java/lang/StringBuilder
    //   110: dup
    //   111: invokespecial <init> : ()V
    //   114: ldc_w 'Error on GAThread: '
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: aload_0
    //   121: aload_1
    //   122: invokespecial printStackTrace : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: invokevirtual toString : ()Ljava/lang/String;
    //   131: invokestatic e : (Ljava/lang/String;)I
    //   134: pop
    //   135: ldc_w 'Google Analytics is shutting down.'
    //   138: invokestatic e : (Ljava/lang/String;)I
    //   141: pop
    //   142: aload_0
    //   143: iconst_1
    //   144: putfield mDisabled : Z
    //   147: goto -> 60
    //   150: astore_1
    //   151: ldc_w 'sleep interrupted in GAThread initialize'
    //   154: invokestatic w : (Ljava/lang/String;)I
    //   157: pop
    //   158: goto -> 6
    //   161: astore_1
    //   162: new java/lang/StringBuilder
    //   165: dup
    //   166: invokespecial <init> : ()V
    //   169: ldc_w 'Error initializing the GAThread: '
    //   172: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial printStackTrace : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: invokevirtual toString : ()Ljava/lang/String;
    //   186: invokestatic e : (Ljava/lang/String;)I
    //   189: pop
    //   190: ldc_w 'Google Analytics will not start up.'
    //   193: invokestatic e : (Ljava/lang/String;)I
    //   196: pop
    //   197: aload_0
    //   198: iconst_1
    //   199: putfield mDisabled : Z
    //   202: goto -> 60
    //   205: return
    // Exception table:
    //   from	to	target	type
    //   0	6	150	java/lang/InterruptedException
    //   33	60	161	java/lang/Throwable
    //   67	91	94	java/lang/InterruptedException
    //   67	91	106	java/lang/Throwable
    //   95	103	106	java/lang/Throwable
  }
  
  public void sendHit(final Map<String, String> hitCopy) {
    hitCopy = new HashMap<String, String>(hitCopy);
    final long hitTime = System.currentTimeMillis();
    hitCopy.put("hitTime", Long.toString(l));
    queueToThread(new Runnable() {
          public void run() {
            hitCopy.put("clientId", GAThread.this.mClientId);
            if (GAThread.this.mAppOptOut || GAThread.this.isSampledOut(hitCopy))
              return; 
            if (!TextUtils.isEmpty(GAThread.this.mInstallCampaign)) {
              hitCopy.put("campaign", GAThread.this.mInstallCampaign);
              GAThread.access$302(GAThread.this, (String)null);
            } 
            GAThread.this.fillAppParameters(hitCopy);
            GAThread.this.fillCampaignParameters(hitCopy);
            GAThread.this.fillExceptionParameters(hitCopy);
            Map<String, String> map = HitBuilder.generateHitParams(GAThread.this.mMetaModel, hitCopy);
            GAThread.this.mServiceProxy.putHit(map, hitTime, GAThread.this.getHostUrl(hitCopy), GAThread.this.mCommands);
          }
        });
  }
  
  public void setAppOptOut(final boolean appOptOut) {
    queueToThread(new Runnable() {
          public void run() {
            if (GAThread.this.mAppOptOut == appOptOut)
              return; 
            if (appOptOut) {
              File file = GAThread.this.mContext.getFileStreamPath("gaOptOut");
              try {
                file.createNewFile();
              } catch (IOException iOException) {
                Log.w("Error creating optOut file.");
              } 
              GAThread.this.mServiceProxy.clearHits();
            } else {
              GAThread.this.mContext.deleteFile("gaOptOut");
            } 
            GAThread.access$102(GAThread.this, appOptOut);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\GAThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */