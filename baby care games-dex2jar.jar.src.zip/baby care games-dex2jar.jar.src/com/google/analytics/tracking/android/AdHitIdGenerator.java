package com.google.analytics.tracking.android;

import com.google.android.gms.common.util.VisibleForTesting;

class AdHitIdGenerator {
  private boolean mAdMobSdkInstalled;
  
  AdHitIdGenerator() {
    try {
      boolean bool;
      if (Class.forName("com.google.ads.AdRequest") != null) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mAdMobSdkInstalled = bool;
      return;
    } catch (ClassNotFoundException classNotFoundException) {
      this.mAdMobSdkInstalled = false;
      return;
    } 
  }
  
  @VisibleForTesting
  AdHitIdGenerator(boolean paramBoolean) {
    this.mAdMobSdkInstalled = paramBoolean;
  }
  
  int getAdHitId() {
    return !this.mAdMobSdkInstalled ? 0 : AdMobInfo.getInstance().generateAdHitId();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\AdHitIdGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */