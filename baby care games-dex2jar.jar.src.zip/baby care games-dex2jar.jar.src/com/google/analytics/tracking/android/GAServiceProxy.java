package com.google.analytics.tracking.android;

import android.content.Context;
import android.content.Intent;
import com.google.android.gms.analytics.internal.Command;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;

class GAServiceProxy implements ServiceProxy, AnalyticsGmsCoreClient.OnConnectedListener, AnalyticsGmsCoreClient.OnConnectionFailedListener {
  private static final long FAILED_CONNECT_WAIT_TIME = 3000L;
  
  private static final int MAX_TRIES = 2;
  
  private static final long RECONNECT_WAIT_TIME = 5000L;
  
  private static final long SERVICE_CONNECTION_TIMEOUT = 300000L;
  
  private volatile AnalyticsClient client;
  
  private Clock clock;
  
  private volatile int connectTries;
  
  private final Context ctx;
  
  private volatile Timer disconnectCheckTimer;
  
  private volatile Timer failedConnectTimer;
  
  private long idleTimeout = 300000L;
  
  private volatile long lastRequestTime;
  
  private boolean pendingClearHits;
  
  private boolean pendingDispatch;
  
  private final Queue<HitParams> queue = new ConcurrentLinkedQueue<HitParams>();
  
  private volatile Timer reConnectTimer;
  
  private volatile ConnectState state;
  
  private AnalyticsStore store;
  
  private AnalyticsStore testStore;
  
  private final AnalyticsThread thread;
  
  GAServiceProxy(Context paramContext, AnalyticsThread paramAnalyticsThread) {
    this(paramContext, paramAnalyticsThread, null);
  }
  
  GAServiceProxy(Context paramContext, AnalyticsThread paramAnalyticsThread, AnalyticsStore paramAnalyticsStore) {
    this.testStore = paramAnalyticsStore;
    this.ctx = paramContext;
    this.thread = paramAnalyticsThread;
    this.clock = new Clock() {
        public long currentTimeMillis() {
          return System.currentTimeMillis();
        }
      };
    this.connectTries = 0;
    this.state = ConnectState.DISCONNECTED;
  }
  
  private Timer cancelTimer(Timer paramTimer) {
    if (paramTimer != null)
      paramTimer.cancel(); 
    return null;
  }
  
  private void clearAllTimers() {
    this.reConnectTimer = cancelTimer(this.reConnectTimer);
    this.failedConnectTimer = cancelTimer(this.failedConnectTimer);
    this.disconnectCheckTimer = cancelTimer(this.disconnectCheckTimer);
  }
  
  private void connectToService() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield client : Lcom/google/analytics/tracking/android/AnalyticsClient;
    //   6: ifnull -> 118
    //   9: aload_0
    //   10: getfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   13: astore_1
    //   14: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.CONNECTED_LOCAL : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   17: astore_2
    //   18: aload_1
    //   19: aload_2
    //   20: if_acmpeq -> 118
    //   23: aload_0
    //   24: aload_0
    //   25: getfield connectTries : I
    //   28: iconst_1
    //   29: iadd
    //   30: putfield connectTries : I
    //   33: aload_0
    //   34: aload_0
    //   35: getfield failedConnectTimer : Ljava/util/Timer;
    //   38: invokespecial cancelTimer : (Ljava/util/Timer;)Ljava/util/Timer;
    //   41: pop
    //   42: aload_0
    //   43: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.CONNECTING : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   46: putfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   49: aload_0
    //   50: new java/util/Timer
    //   53: dup
    //   54: ldc 'Failed Connect'
    //   56: invokespecial <init> : (Ljava/lang/String;)V
    //   59: putfield failedConnectTimer : Ljava/util/Timer;
    //   62: aload_0
    //   63: getfield failedConnectTimer : Ljava/util/Timer;
    //   66: new com/google/analytics/tracking/android/GAServiceProxy$FailedConnectTask
    //   69: dup
    //   70: aload_0
    //   71: aconst_null
    //   72: invokespecial <init> : (Lcom/google/analytics/tracking/android/GAServiceProxy;Lcom/google/analytics/tracking/android/GAServiceProxy$1;)V
    //   75: ldc2_w 3000
    //   78: invokevirtual schedule : (Ljava/util/TimerTask;J)V
    //   81: ldc 'connecting to Analytics service'
    //   83: invokestatic iDebug : (Ljava/lang/String;)I
    //   86: pop
    //   87: aload_0
    //   88: getfield client : Lcom/google/analytics/tracking/android/AnalyticsClient;
    //   91: invokeinterface connect : ()V
    //   96: aload_0
    //   97: monitorexit
    //   98: return
    //   99: astore_1
    //   100: ldc 'security exception on connectToService'
    //   102: invokestatic w : (Ljava/lang/String;)I
    //   105: pop
    //   106: aload_0
    //   107: invokespecial useStore : ()V
    //   110: goto -> 96
    //   113: astore_1
    //   114: aload_0
    //   115: monitorexit
    //   116: aload_1
    //   117: athrow
    //   118: ldc 'client not initialized.'
    //   120: invokestatic w : (Ljava/lang/String;)I
    //   123: pop
    //   124: aload_0
    //   125: invokespecial useStore : ()V
    //   128: goto -> 96
    // Exception table:
    //   from	to	target	type
    //   2	18	113	finally
    //   23	96	99	java/lang/SecurityException
    //   23	96	113	finally
    //   100	110	113	finally
    //   118	128	113	finally
  }
  
  private void disconnectFromService() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield client : Lcom/google/analytics/tracking/android/AnalyticsClient;
    //   6: ifnull -> 35
    //   9: aload_0
    //   10: getfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   13: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.CONNECTED_SERVICE : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   16: if_acmpne -> 35
    //   19: aload_0
    //   20: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.PENDING_DISCONNECT : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   23: putfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   26: aload_0
    //   27: getfield client : Lcom/google/analytics/tracking/android/AnalyticsClient;
    //   30: invokeinterface disconnect : ()V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	35	38	finally
  }
  
  private void dispatchToStore() {
    this.store.dispatch();
    this.pendingDispatch = false;
  }
  
  private void fireReconnectAttempt() {
    this.reConnectTimer = cancelTimer(this.reConnectTimer);
    this.reConnectTimer = new Timer("Service Reconnect");
    this.reConnectTimer.schedule(new ReconnectTask(), 5000L);
  }
  
  private void sendQueue() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic currentThread : ()Ljava/lang/Thread;
    //   5: aload_0
    //   6: getfield thread : Lcom/google/analytics/tracking/android/AnalyticsThread;
    //   9: invokeinterface getThread : ()Ljava/lang/Thread;
    //   14: invokevirtual equals : (Ljava/lang/Object;)Z
    //   17: ifne -> 44
    //   20: aload_0
    //   21: getfield thread : Lcom/google/analytics/tracking/android/AnalyticsThread;
    //   24: invokeinterface getQueue : ()Ljava/util/concurrent/LinkedBlockingQueue;
    //   29: new com/google/analytics/tracking/android/GAServiceProxy$2
    //   32: dup
    //   33: aload_0
    //   34: invokespecial <init> : (Lcom/google/analytics/tracking/android/GAServiceProxy;)V
    //   37: invokevirtual add : (Ljava/lang/Object;)Z
    //   40: pop
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: aload_0
    //   45: getfield pendingClearHits : Z
    //   48: ifeq -> 55
    //   51: aload_0
    //   52: invokevirtual clearHits : ()V
    //   55: getstatic com/google/analytics/tracking/android/GAServiceProxy$3.$SwitchMap$com$google$analytics$tracking$android$GAServiceProxy$ConnectState : [I
    //   58: aload_0
    //   59: getfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   62: invokevirtual ordinal : ()I
    //   65: iaload
    //   66: tableswitch default -> 283, 1 -> 92, 2 -> 171, 3 -> 257
    //   92: aload_0
    //   93: getfield queue : Ljava/util/Queue;
    //   96: invokeinterface isEmpty : ()Z
    //   101: ifne -> 157
    //   104: aload_0
    //   105: getfield queue : Ljava/util/Queue;
    //   108: invokeinterface poll : ()Ljava/lang/Object;
    //   113: checkcast com/google/analytics/tracking/android/GAServiceProxy$HitParams
    //   116: astore_1
    //   117: ldc_w 'Sending hit to store'
    //   120: invokestatic iDebug : (Ljava/lang/String;)I
    //   123: pop
    //   124: aload_0
    //   125: getfield store : Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   128: aload_1
    //   129: invokevirtual getWireFormatParams : ()Ljava/util/Map;
    //   132: aload_1
    //   133: invokevirtual getHitTimeInMilliseconds : ()J
    //   136: aload_1
    //   137: invokevirtual getPath : ()Ljava/lang/String;
    //   140: aload_1
    //   141: invokevirtual getCommands : ()Ljava/util/List;
    //   144: invokeinterface putHit : (Ljava/util/Map;JLjava/lang/String;Ljava/util/Collection;)V
    //   149: goto -> 92
    //   152: astore_1
    //   153: aload_0
    //   154: monitorexit
    //   155: aload_1
    //   156: athrow
    //   157: aload_0
    //   158: getfield pendingDispatch : Z
    //   161: ifeq -> 41
    //   164: aload_0
    //   165: invokespecial dispatchToStore : ()V
    //   168: goto -> 41
    //   171: aload_0
    //   172: getfield queue : Ljava/util/Queue;
    //   175: invokeinterface isEmpty : ()Z
    //   180: ifne -> 241
    //   183: aload_0
    //   184: getfield queue : Ljava/util/Queue;
    //   187: invokeinterface peek : ()Ljava/lang/Object;
    //   192: checkcast com/google/analytics/tracking/android/GAServiceProxy$HitParams
    //   195: astore_1
    //   196: ldc_w 'Sending hit to service'
    //   199: invokestatic iDebug : (Ljava/lang/String;)I
    //   202: pop
    //   203: aload_0
    //   204: getfield client : Lcom/google/analytics/tracking/android/AnalyticsClient;
    //   207: aload_1
    //   208: invokevirtual getWireFormatParams : ()Ljava/util/Map;
    //   211: aload_1
    //   212: invokevirtual getHitTimeInMilliseconds : ()J
    //   215: aload_1
    //   216: invokevirtual getPath : ()Ljava/lang/String;
    //   219: aload_1
    //   220: invokevirtual getCommands : ()Ljava/util/List;
    //   223: invokeinterface sendHit : (Ljava/util/Map;JLjava/lang/String;Ljava/util/List;)V
    //   228: aload_0
    //   229: getfield queue : Ljava/util/Queue;
    //   232: invokeinterface poll : ()Ljava/lang/Object;
    //   237: pop
    //   238: goto -> 171
    //   241: aload_0
    //   242: aload_0
    //   243: getfield clock : Lcom/google/analytics/tracking/android/Clock;
    //   246: invokeinterface currentTimeMillis : ()J
    //   251: putfield lastRequestTime : J
    //   254: goto -> 41
    //   257: ldc_w 'Need to reconnect'
    //   260: invokestatic iDebug : (Ljava/lang/String;)I
    //   263: pop
    //   264: aload_0
    //   265: getfield queue : Ljava/util/Queue;
    //   268: invokeinterface isEmpty : ()Z
    //   273: ifne -> 41
    //   276: aload_0
    //   277: invokespecial connectToService : ()V
    //   280: goto -> 41
    //   283: goto -> 41
    // Exception table:
    //   from	to	target	type
    //   2	41	152	finally
    //   44	55	152	finally
    //   55	92	152	finally
    //   92	149	152	finally
    //   157	168	152	finally
    //   171	238	152	finally
    //   241	254	152	finally
    //   257	280	152	finally
  }
  
  private void useStore() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   6: astore_1
    //   7: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.CONNECTED_LOCAL : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   10: astore_2
    //   11: aload_1
    //   12: aload_2
    //   13: if_acmpne -> 19
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: aload_0
    //   20: invokespecial clearAllTimers : ()V
    //   23: ldc_w 'falling back to local store'
    //   26: invokestatic iDebug : (Ljava/lang/String;)I
    //   29: pop
    //   30: aload_0
    //   31: getfield testStore : Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   34: ifnull -> 64
    //   37: aload_0
    //   38: aload_0
    //   39: getfield testStore : Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   42: putfield store : Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   45: aload_0
    //   46: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.CONNECTED_LOCAL : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   49: putfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   52: aload_0
    //   53: invokespecial sendQueue : ()V
    //   56: goto -> 16
    //   59: astore_1
    //   60: aload_0
    //   61: monitorexit
    //   62: aload_1
    //   63: athrow
    //   64: invokestatic getInstance : ()Lcom/google/analytics/tracking/android/GAServiceManager;
    //   67: astore_1
    //   68: aload_1
    //   69: aload_0
    //   70: getfield ctx : Landroid/content/Context;
    //   73: aload_0
    //   74: getfield thread : Lcom/google/analytics/tracking/android/AnalyticsThread;
    //   77: invokevirtual initialize : (Landroid/content/Context;Lcom/google/analytics/tracking/android/AnalyticsThread;)V
    //   80: aload_0
    //   81: aload_1
    //   82: invokevirtual getStore : ()Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   85: putfield store : Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   88: goto -> 45
    // Exception table:
    //   from	to	target	type
    //   2	11	59	finally
    //   19	45	59	finally
    //   45	56	59	finally
    //   64	88	59	finally
  }
  
  public void clearHits() {
    Log.iDebug("clearHits called");
    this.queue.clear();
    switch (this.state) {
      default:
        this.pendingClearHits = true;
        return;
      case CONNECTED_LOCAL:
        this.store.clearHits(0L);
        this.pendingClearHits = false;
        return;
      case CONNECTED_SERVICE:
        break;
    } 
    this.client.clearHits();
    this.pendingClearHits = false;
  }
  
  public void createService() {
    if (this.client != null)
      return; 
    this.client = new AnalyticsGmsCoreClient(this.ctx, this, this);
    connectToService();
  }
  
  void createService(AnalyticsClient paramAnalyticsClient) {
    if (this.client != null)
      return; 
    this.client = paramAnalyticsClient;
    connectToService();
  }
  
  public void dispatch() {
    switch (this.state) {
      default:
        this.pendingDispatch = true;
      case CONNECTED_SERVICE:
        return;
      case CONNECTED_LOCAL:
        break;
    } 
    dispatchToStore();
  }
  
  public void onConnected() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: aload_0
    //   5: getfield failedConnectTimer : Ljava/util/Timer;
    //   8: invokespecial cancelTimer : (Ljava/util/Timer;)Ljava/util/Timer;
    //   11: putfield failedConnectTimer : Ljava/util/Timer;
    //   14: aload_0
    //   15: iconst_0
    //   16: putfield connectTries : I
    //   19: ldc_w 'Connected to service'
    //   22: invokestatic iDebug : (Ljava/lang/String;)I
    //   25: pop
    //   26: aload_0
    //   27: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.CONNECTED_SERVICE : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   30: putfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   33: aload_0
    //   34: invokespecial sendQueue : ()V
    //   37: aload_0
    //   38: aload_0
    //   39: aload_0
    //   40: getfield disconnectCheckTimer : Ljava/util/Timer;
    //   43: invokespecial cancelTimer : (Ljava/util/Timer;)Ljava/util/Timer;
    //   46: putfield disconnectCheckTimer : Ljava/util/Timer;
    //   49: aload_0
    //   50: new java/util/Timer
    //   53: dup
    //   54: ldc_w 'disconnect check'
    //   57: invokespecial <init> : (Ljava/lang/String;)V
    //   60: putfield disconnectCheckTimer : Ljava/util/Timer;
    //   63: aload_0
    //   64: getfield disconnectCheckTimer : Ljava/util/Timer;
    //   67: new com/google/analytics/tracking/android/GAServiceProxy$DisconnectCheckTask
    //   70: dup
    //   71: aload_0
    //   72: aconst_null
    //   73: invokespecial <init> : (Lcom/google/analytics/tracking/android/GAServiceProxy;Lcom/google/analytics/tracking/android/GAServiceProxy$1;)V
    //   76: aload_0
    //   77: getfield idleTimeout : J
    //   80: invokevirtual schedule : (Ljava/util/TimerTask;J)V
    //   83: aload_0
    //   84: monitorexit
    //   85: return
    //   86: astore_1
    //   87: aload_0
    //   88: monitorexit
    //   89: aload_1
    //   90: athrow
    // Exception table:
    //   from	to	target	type
    //   2	83	86	finally
  }
  
  public void onConnectionFailed(int paramInt, Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.PENDING_CONNECTION : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   6: putfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   9: aload_0
    //   10: getfield connectTries : I
    //   13: iconst_2
    //   14: if_icmpge -> 54
    //   17: new java/lang/StringBuilder
    //   20: dup
    //   21: invokespecial <init> : ()V
    //   24: ldc_w 'Service unavailable (code='
    //   27: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: iload_1
    //   31: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   34: ldc_w '), will retry.'
    //   37: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: invokevirtual toString : ()Ljava/lang/String;
    //   43: invokestatic w : (Ljava/lang/String;)I
    //   46: pop
    //   47: aload_0
    //   48: invokespecial fireReconnectAttempt : ()V
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: new java/lang/StringBuilder
    //   57: dup
    //   58: invokespecial <init> : ()V
    //   61: ldc_w 'Service unavailable (code='
    //   64: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   67: iload_1
    //   68: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   71: ldc_w '), using local store.'
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: invokevirtual toString : ()Ljava/lang/String;
    //   80: invokestatic w : (Ljava/lang/String;)I
    //   83: pop
    //   84: aload_0
    //   85: invokespecial useStore : ()V
    //   88: goto -> 51
    //   91: astore_2
    //   92: aload_0
    //   93: monitorexit
    //   94: aload_2
    //   95: athrow
    // Exception table:
    //   from	to	target	type
    //   2	51	91	finally
    //   54	88	91	finally
  }
  
  public void onDisconnected() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   6: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.PENDING_DISCONNECT : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   9: if_acmpne -> 33
    //   12: ldc_w 'Disconnected from service'
    //   15: invokestatic iDebug : (Ljava/lang/String;)I
    //   18: pop
    //   19: aload_0
    //   20: invokespecial clearAllTimers : ()V
    //   23: aload_0
    //   24: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.DISCONNECTED : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   27: putfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   30: aload_0
    //   31: monitorexit
    //   32: return
    //   33: ldc_w 'Unexpected disconnect.'
    //   36: invokestatic iDebug : (Ljava/lang/String;)I
    //   39: pop
    //   40: aload_0
    //   41: getstatic com/google/analytics/tracking/android/GAServiceProxy$ConnectState.PENDING_CONNECTION : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   44: putfield state : Lcom/google/analytics/tracking/android/GAServiceProxy$ConnectState;
    //   47: aload_0
    //   48: getfield connectTries : I
    //   51: iconst_2
    //   52: if_icmpge -> 67
    //   55: aload_0
    //   56: invokespecial fireReconnectAttempt : ()V
    //   59: goto -> 30
    //   62: astore_1
    //   63: aload_0
    //   64: monitorexit
    //   65: aload_1
    //   66: athrow
    //   67: aload_0
    //   68: invokespecial useStore : ()V
    //   71: goto -> 30
    // Exception table:
    //   from	to	target	type
    //   2	30	62	finally
    //   33	59	62	finally
    //   67	71	62	finally
  }
  
  public void putHit(Map<String, String> paramMap, long paramLong, String paramString, List<Command> paramList) {
    Log.iDebug("putHit called");
    this.queue.add(new HitParams(paramMap, paramLong, paramString, paramList));
    sendQueue();
  }
  
  void setClock(Clock paramClock) {
    this.clock = paramClock;
  }
  
  public void setIdleTimeout(long paramLong) {
    this.idleTimeout = paramLong;
  }
  
  private enum ConnectState {
    BLOCKED, CONNECTED_LOCAL, CONNECTED_SERVICE, CONNECTING, DISCONNECTED, PENDING_CONNECTION, PENDING_DISCONNECT;
    
    static {
      CONNECTED_LOCAL = new ConnectState("CONNECTED_LOCAL", 2);
      BLOCKED = new ConnectState("BLOCKED", 3);
      PENDING_CONNECTION = new ConnectState("PENDING_CONNECTION", 4);
      PENDING_DISCONNECT = new ConnectState("PENDING_DISCONNECT", 5);
      DISCONNECTED = new ConnectState("DISCONNECTED", 6);
      $VALUES = new ConnectState[] { CONNECTING, CONNECTED_SERVICE, CONNECTED_LOCAL, BLOCKED, PENDING_CONNECTION, PENDING_DISCONNECT, DISCONNECTED };
    }
  }
  
  private class DisconnectCheckTask extends TimerTask {
    private DisconnectCheckTask() {}
    
    public void run() {
      if (GAServiceProxy.this.state == GAServiceProxy.ConnectState.CONNECTED_SERVICE && GAServiceProxy.this.queue.isEmpty() && GAServiceProxy.this.lastRequestTime + GAServiceProxy.this.idleTimeout < GAServiceProxy.this.clock.currentTimeMillis()) {
        Log.iDebug("Disconnecting due to inactivity");
        GAServiceProxy.this.disconnectFromService();
        return;
      } 
      GAServiceProxy.this.disconnectCheckTimer.schedule(new DisconnectCheckTask(), GAServiceProxy.this.idleTimeout);
    }
  }
  
  private class FailedConnectTask extends TimerTask {
    private FailedConnectTask() {}
    
    public void run() {
      if (GAServiceProxy.this.state == GAServiceProxy.ConnectState.CONNECTING)
        GAServiceProxy.this.useStore(); 
    }
  }
  
  private static class HitParams {
    private final List<Command> commands;
    
    private final long hitTimeInMilliseconds;
    
    private final String path;
    
    private final Map<String, String> wireFormatParams;
    
    public HitParams(Map<String, String> param1Map, long param1Long, String param1String, List<Command> param1List) {
      this.wireFormatParams = param1Map;
      this.hitTimeInMilliseconds = param1Long;
      this.path = param1String;
      this.commands = param1List;
    }
    
    public List<Command> getCommands() {
      return this.commands;
    }
    
    public long getHitTimeInMilliseconds() {
      return this.hitTimeInMilliseconds;
    }
    
    public String getPath() {
      return this.path;
    }
    
    public Map<String, String> getWireFormatParams() {
      return this.wireFormatParams;
    }
  }
  
  private class ReconnectTask extends TimerTask {
    private ReconnectTask() {}
    
    public void run() {
      GAServiceProxy.this.connectToService();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\GAServiceProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */