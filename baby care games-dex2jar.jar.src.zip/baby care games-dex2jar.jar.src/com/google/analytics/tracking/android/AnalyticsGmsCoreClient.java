package com.google.analytics.tracking.android;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.analytics.internal.Command;
import com.google.android.gms.analytics.internal.IAnalyticsService;
import java.util.List;
import java.util.Map;

class AnalyticsGmsCoreClient implements AnalyticsClient {
  private static final int BIND_ADJUST_WITH_ACTIVITY = 128;
  
  public static final int BIND_FAILED = 1;
  
  public static final String KEY_APP_PACKAGE_NAME = "app_package_name";
  
  public static final int REMOTE_EXECUTION_FAILED = 2;
  
  static final String SERVICE_ACTION = "com.google.android.gms.analytics.service.START";
  
  private static final String SERVICE_DESCRIPTOR = "com.google.android.gms.analytics.internal.IAnalyticsService";
  
  private ServiceConnection mConnection;
  
  private Context mContext;
  
  private OnConnectedListener mOnConnectedListener;
  
  private OnConnectionFailedListener mOnConnectionFailedListener;
  
  private IAnalyticsService mService;
  
  public AnalyticsGmsCoreClient(Context paramContext, OnConnectedListener paramOnConnectedListener, OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.mContext = paramContext;
    if (paramOnConnectedListener == null)
      throw new IllegalArgumentException("onConnectedListener cannot be null"); 
    this.mOnConnectedListener = paramOnConnectedListener;
    if (paramOnConnectionFailedListener == null)
      throw new IllegalArgumentException("onConnectionFailedListener cannot be null"); 
    this.mOnConnectionFailedListener = paramOnConnectionFailedListener;
  }
  
  private IAnalyticsService getService() {
    checkConnected();
    return this.mService;
  }
  
  private void onConnectionSuccess() {
    this.mOnConnectedListener.onConnected();
  }
  
  private void onServiceBound() {
    onConnectionSuccess();
  }
  
  protected void checkConnected() {
    if (!isConnected())
      throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called."); 
  }
  
  public void clearHits() {
    try {
      getService().clearHits();
      return;
    } catch (RemoteException remoteException) {
      Log.e("clear hits failed: " + remoteException);
      return;
    } 
  }
  
  public void connect() {
    Intent intent = new Intent("com.google.android.gms.analytics.service.START");
    intent.putExtra("app_package_name", this.mContext.getPackageName());
    if (this.mConnection != null) {
      Log.e("Calling connect() while still connected, missing disconnect().");
      return;
    } 
    this.mConnection = new AnalyticsServiceConnection();
    boolean bool = this.mContext.bindService(intent, this.mConnection, 129);
    Log.iDebug("connect: bindService returned " + bool + " for " + intent);
    if (!bool) {
      this.mConnection = null;
      this.mOnConnectionFailedListener.onConnectionFailed(1, null);
      return;
    } 
  }
  
  public void disconnect() {
    this.mService = null;
    if (this.mConnection != null) {
      try {
        this.mContext.unbindService(this.mConnection);
      } catch (IllegalStateException illegalStateException) {
      
      } catch (IllegalArgumentException illegalArgumentException) {}
      this.mConnection = null;
      this.mOnConnectedListener.onDisconnected();
    } 
  }
  
  public boolean isConnected() {
    return (this.mService != null);
  }
  
  public void sendHit(Map<String, String> paramMap, long paramLong, String paramString, List<Command> paramList) {
    try {
      getService().sendHit(paramMap, paramLong, paramString, paramList);
      return;
    } catch (RemoteException remoteException) {
      Log.e("sendHit failed: " + remoteException);
      return;
    } 
  }
  
  final class AnalyticsServiceConnection implements ServiceConnection {
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      Log.dDebug("service connected, binder: " + param1IBinder);
      try {
        if ("com.google.android.gms.analytics.internal.IAnalyticsService".equals(param1IBinder.getInterfaceDescriptor())) {
          Log.dDebug("bound to service");
          AnalyticsGmsCoreClient.access$002(AnalyticsGmsCoreClient.this, IAnalyticsService.Stub.asInterface(param1IBinder));
          AnalyticsGmsCoreClient.this.onServiceBound();
          return;
        } 
      } catch (RemoteException remoteException) {}
      AnalyticsGmsCoreClient.this.mContext.unbindService(this);
      AnalyticsGmsCoreClient.access$302(AnalyticsGmsCoreClient.this, null);
      AnalyticsGmsCoreClient.this.mOnConnectionFailedListener.onConnectionFailed(2, null);
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      Log.dDebug("service disconnected: " + param1ComponentName);
      AnalyticsGmsCoreClient.access$302(AnalyticsGmsCoreClient.this, null);
      AnalyticsGmsCoreClient.this.mOnConnectedListener.onDisconnected();
    }
  }
  
  public static interface OnConnectedListener {
    void onConnected();
    
    void onDisconnected();
  }
  
  public static interface OnConnectionFailedListener {
    void onConnectionFailed(int param1Int, Intent param1Intent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\AnalyticsGmsCoreClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */