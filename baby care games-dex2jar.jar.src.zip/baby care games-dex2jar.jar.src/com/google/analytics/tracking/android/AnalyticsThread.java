package com.google.analytics.tracking.android;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

interface AnalyticsThread {
  void dispatch();
  
  LinkedBlockingQueue<Runnable> getQueue();
  
  Thread getThread();
  
  void requestAppOptOut(GoogleAnalytics.AppOptOutCallback paramAppOptOutCallback);
  
  void requestClientId(ClientIdCallback paramClientIdCallback);
  
  void sendHit(Map<String, String> paramMap);
  
  void setAppOptOut(boolean paramBoolean);
  
  public static interface ClientIdCallback {
    void reportClientId(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\AnalyticsThread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */