package com.google.analytics.tracking.android;

class Hit {
  private final long mHitId;
  
  private String mHitString;
  
  private final long mHitTime;
  
  private String mHitUrl;
  
  Hit(String paramString, long paramLong1, long paramLong2) {
    this.mHitString = paramString;
    this.mHitId = paramLong1;
    this.mHitTime = paramLong2;
  }
  
  long getHitId() {
    return this.mHitId;
  }
  
  String getHitParams() {
    return this.mHitString;
  }
  
  long getHitTime() {
    return this.mHitTime;
  }
  
  String getHitUrl() {
    return this.mHitUrl;
  }
  
  void setHitString(String paramString) {
    this.mHitString = paramString;
  }
  
  void setHitUrl(String paramString) {
    this.mHitUrl = paramString;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\Hit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */