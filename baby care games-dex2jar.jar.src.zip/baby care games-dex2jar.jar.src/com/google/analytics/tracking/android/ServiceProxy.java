package com.google.analytics.tracking.android;

import com.google.android.gms.analytics.internal.Command;
import java.util.List;
import java.util.Map;

interface ServiceProxy {
  void clearHits();
  
  void createService();
  
  void dispatch();
  
  void putHit(Map<String, String> paramMap, long paramLong, String paramString, List<Command> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\ServiceProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */