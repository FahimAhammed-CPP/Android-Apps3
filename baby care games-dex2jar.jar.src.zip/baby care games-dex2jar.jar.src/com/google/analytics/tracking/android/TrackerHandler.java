package com.google.analytics.tracking.android;

import java.util.Map;

interface TrackerHandler {
  void closeTracker(Tracker paramTracker);
  
  void sendHit(Map<String, String> paramMap);
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\TrackerHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */