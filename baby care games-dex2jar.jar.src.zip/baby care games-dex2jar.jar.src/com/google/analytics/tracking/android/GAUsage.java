package com.google.analytics.tracking.android;

import com.google.android.gms.common.util.VisibleForTesting;
import java.util.SortedSet;
import java.util.TreeSet;

class GAUsage {
  private static final String BASE_64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  
  private static final GAUsage INSTANCE = new GAUsage();
  
  private boolean mDisableUsage = false;
  
  private StringBuilder mSequence = new StringBuilder();
  
  private SortedSet<Field> mUsedFields = new TreeSet<Field>();
  
  public static GAUsage getInstance() {
    return INSTANCE;
  }
  
  @VisibleForTesting
  static GAUsage getPrivateInstance() {
    return new GAUsage();
  }
  
  public String getAndClearSequence() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mSequence : Ljava/lang/StringBuilder;
    //   6: invokevirtual length : ()I
    //   9: ifle -> 23
    //   12: aload_0
    //   13: getfield mSequence : Ljava/lang/StringBuilder;
    //   16: iconst_0
    //   17: ldc '.'
    //   19: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   22: pop
    //   23: aload_0
    //   24: getfield mSequence : Ljava/lang/StringBuilder;
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore_1
    //   31: aload_0
    //   32: new java/lang/StringBuilder
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: putfield mSequence : Ljava/lang/StringBuilder;
    //   42: aload_0
    //   43: monitorexit
    //   44: aload_1
    //   45: areturn
    //   46: astore_1
    //   47: aload_0
    //   48: monitorexit
    //   49: aload_1
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	46	finally
    //   23	42	46	finally
  }
  
  public String getAndClearUsage() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/lang/StringBuilder
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: astore #4
    //   11: iconst_0
    //   12: istore_1
    //   13: bipush #6
    //   15: istore_2
    //   16: aload_0
    //   17: getfield mUsedFields : Ljava/util/SortedSet;
    //   20: invokeinterface size : ()I
    //   25: ifle -> 103
    //   28: aload_0
    //   29: getfield mUsedFields : Ljava/util/SortedSet;
    //   32: invokeinterface first : ()Ljava/lang/Object;
    //   37: checkcast com/google/analytics/tracking/android/GAUsage$Field
    //   40: astore #5
    //   42: aload_0
    //   43: getfield mUsedFields : Ljava/util/SortedSet;
    //   46: aload #5
    //   48: invokeinterface remove : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload #5
    //   56: invokevirtual ordinal : ()I
    //   59: istore_3
    //   60: iload_3
    //   61: iload_2
    //   62: if_icmplt -> 87
    //   65: aload #4
    //   67: ldc 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
    //   69: iload_1
    //   70: invokevirtual charAt : (I)C
    //   73: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   76: pop
    //   77: iconst_0
    //   78: istore_1
    //   79: iload_2
    //   80: bipush #6
    //   82: iadd
    //   83: istore_2
    //   84: goto -> 60
    //   87: iload_1
    //   88: iconst_1
    //   89: aload #5
    //   91: invokevirtual ordinal : ()I
    //   94: bipush #6
    //   96: irem
    //   97: ishl
    //   98: iadd
    //   99: istore_1
    //   100: goto -> 16
    //   103: iload_1
    //   104: ifgt -> 115
    //   107: aload #4
    //   109: invokevirtual length : ()I
    //   112: ifne -> 127
    //   115: aload #4
    //   117: ldc 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
    //   119: iload_1
    //   120: invokevirtual charAt : (I)C
    //   123: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   126: pop
    //   127: aload_0
    //   128: getfield mUsedFields : Ljava/util/SortedSet;
    //   131: invokeinterface clear : ()V
    //   136: aload #4
    //   138: invokevirtual toString : ()Ljava/lang/String;
    //   141: astore #4
    //   143: aload_0
    //   144: monitorexit
    //   145: aload #4
    //   147: areturn
    //   148: astore #4
    //   150: aload_0
    //   151: monitorexit
    //   152: aload #4
    //   154: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	148	finally
    //   16	60	148	finally
    //   65	77	148	finally
    //   87	100	148	finally
    //   107	115	148	finally
    //   115	127	148	finally
    //   127	143	148	finally
  }
  
  public void setDisableUsage(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iload_1
    //   4: putfield mDisableUsage : Z
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_2
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_2
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public void setUsage(Field paramField) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mDisableUsage : Z
    //   6: ifne -> 37
    //   9: aload_0
    //   10: getfield mUsedFields : Ljava/util/SortedSet;
    //   13: aload_1
    //   14: invokeinterface add : (Ljava/lang/Object;)Z
    //   19: pop
    //   20: aload_0
    //   21: getfield mSequence : Ljava/lang/StringBuilder;
    //   24: ldc 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
    //   26: aload_1
    //   27: invokevirtual ordinal : ()I
    //   30: invokevirtual charAt : (I)C
    //   33: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   36: pop
    //   37: aload_0
    //   38: monitorexit
    //   39: return
    //   40: astore_1
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_1
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	37	40	finally
  }
  
  public enum Field {
    BLANK_06, BLANK_13, BLANK_15, BLANK_17, BLANK_48, CONSTRUCT_EVENT, CONSTRUCT_EXCEPTION, CONSTRUCT_ITEM, CONSTRUCT_RAW_EXCEPTION, CONSTRUCT_SOCIAL, CONSTRUCT_TIMING, CONSTRUCT_TRANSACTION, DISPATCH, GET, GET_ANONYMIZE_IP, GET_APP_ID, GET_APP_INSTALLER_ID, GET_DEBUG, GET_DEFAULT_TRACKER, GET_EXCEPTION_PARSER, GET_SAMPLE_RATE, GET_TRACKER, GET_TRACKING_ID, GET_USE_SECURE, REPORT_UNCAUGHT_EXCEPTIONS, REQUEST_APP_OPT_OUT, SEND, SET, SET_ANONYMIZE_IP, SET_APP_ID, SET_APP_INSTALLER_ID, SET_APP_NAME, SET_APP_OPT_OUT, SET_APP_SCREEN, SET_APP_VERSION, SET_AUTO_ACTIVITY_TRACKING, SET_CAMPAIGN, SET_DEBUG, SET_DEFAULT_TRACKER, SET_DISPATCH_PERIOD, SET_EXCEPTION_PARSER, SET_REFERRER, SET_SAMPLE_RATE, SET_SESSION_TIMEOUT, SET_START_SESSION, SET_USE_SECURE, TRACK_EVENT, TRACK_EXCEPTION_WITH_DESCRIPTION, TRACK_EXCEPTION_WITH_THROWABLE, TRACK_SOCIAL, TRACK_TIMING, TRACK_TRANSACTION, TRACK_VIEW, TRACK_VIEW_WITH_APPSCREEN;
    
    static {
      TRACK_EXCEPTION_WITH_DESCRIPTION = new Field("TRACK_EXCEPTION_WITH_DESCRIPTION", 4);
      TRACK_EXCEPTION_WITH_THROWABLE = new Field("TRACK_EXCEPTION_WITH_THROWABLE", 5);
      BLANK_06 = new Field("BLANK_06", 6);
      TRACK_TIMING = new Field("TRACK_TIMING", 7);
      TRACK_SOCIAL = new Field("TRACK_SOCIAL", 8);
      GET = new Field("GET", 9);
      SET = new Field("SET", 10);
      SEND = new Field("SEND", 11);
      SET_START_SESSION = new Field("SET_START_SESSION", 12);
      BLANK_13 = new Field("BLANK_13", 13);
      SET_APP_NAME = new Field("SET_APP_NAME", 14);
      BLANK_15 = new Field("BLANK_15", 15);
      SET_APP_VERSION = new Field("SET_APP_VERSION", 16);
      BLANK_17 = new Field("BLANK_17", 17);
      SET_APP_SCREEN = new Field("SET_APP_SCREEN", 18);
      GET_TRACKING_ID = new Field("GET_TRACKING_ID", 19);
      SET_ANONYMIZE_IP = new Field("SET_ANONYMIZE_IP", 20);
      GET_ANONYMIZE_IP = new Field("GET_ANONYMIZE_IP", 21);
      SET_SAMPLE_RATE = new Field("SET_SAMPLE_RATE", 22);
      GET_SAMPLE_RATE = new Field("GET_SAMPLE_RATE", 23);
      SET_USE_SECURE = new Field("SET_USE_SECURE", 24);
      GET_USE_SECURE = new Field("GET_USE_SECURE", 25);
      SET_REFERRER = new Field("SET_REFERRER", 26);
      SET_CAMPAIGN = new Field("SET_CAMPAIGN", 27);
      SET_APP_ID = new Field("SET_APP_ID", 28);
      GET_APP_ID = new Field("GET_APP_ID", 29);
      SET_EXCEPTION_PARSER = new Field("SET_EXCEPTION_PARSER", 30);
      GET_EXCEPTION_PARSER = new Field("GET_EXCEPTION_PARSER", 31);
      CONSTRUCT_TRANSACTION = new Field("CONSTRUCT_TRANSACTION", 32);
      CONSTRUCT_EXCEPTION = new Field("CONSTRUCT_EXCEPTION", 33);
      CONSTRUCT_RAW_EXCEPTION = new Field("CONSTRUCT_RAW_EXCEPTION", 34);
      CONSTRUCT_TIMING = new Field("CONSTRUCT_TIMING", 35);
      CONSTRUCT_SOCIAL = new Field("CONSTRUCT_SOCIAL", 36);
      SET_DEBUG = new Field("SET_DEBUG", 37);
      GET_DEBUG = new Field("GET_DEBUG", 38);
      GET_TRACKER = new Field("GET_TRACKER", 39);
      GET_DEFAULT_TRACKER = new Field("GET_DEFAULT_TRACKER", 40);
      SET_DEFAULT_TRACKER = new Field("SET_DEFAULT_TRACKER", 41);
      SET_APP_OPT_OUT = new Field("SET_APP_OPT_OUT", 42);
      REQUEST_APP_OPT_OUT = new Field("REQUEST_APP_OPT_OUT", 43);
      DISPATCH = new Field("DISPATCH", 44);
      SET_DISPATCH_PERIOD = new Field("SET_DISPATCH_PERIOD", 45);
      BLANK_48 = new Field("BLANK_48", 46);
      REPORT_UNCAUGHT_EXCEPTIONS = new Field("REPORT_UNCAUGHT_EXCEPTIONS", 47);
      SET_AUTO_ACTIVITY_TRACKING = new Field("SET_AUTO_ACTIVITY_TRACKING", 48);
      SET_SESSION_TIMEOUT = new Field("SET_SESSION_TIMEOUT", 49);
      CONSTRUCT_EVENT = new Field("CONSTRUCT_EVENT", 50);
      CONSTRUCT_ITEM = new Field("CONSTRUCT_ITEM", 51);
      SET_APP_INSTALLER_ID = new Field("SET_APP_INSTALLER_ID", 52);
      GET_APP_INSTALLER_ID = new Field("GET_APP_INSTALLER_ID", 53);
      $VALUES = new Field[] { 
          TRACK_VIEW, TRACK_VIEW_WITH_APPSCREEN, TRACK_EVENT, TRACK_TRANSACTION, TRACK_EXCEPTION_WITH_DESCRIPTION, TRACK_EXCEPTION_WITH_THROWABLE, BLANK_06, TRACK_TIMING, TRACK_SOCIAL, GET, 
          SET, SEND, SET_START_SESSION, BLANK_13, SET_APP_NAME, BLANK_15, SET_APP_VERSION, BLANK_17, SET_APP_SCREEN, GET_TRACKING_ID, 
          SET_ANONYMIZE_IP, GET_ANONYMIZE_IP, SET_SAMPLE_RATE, GET_SAMPLE_RATE, SET_USE_SECURE, GET_USE_SECURE, SET_REFERRER, SET_CAMPAIGN, SET_APP_ID, GET_APP_ID, 
          SET_EXCEPTION_PARSER, GET_EXCEPTION_PARSER, CONSTRUCT_TRANSACTION, CONSTRUCT_EXCEPTION, CONSTRUCT_RAW_EXCEPTION, CONSTRUCT_TIMING, CONSTRUCT_SOCIAL, SET_DEBUG, GET_DEBUG, GET_TRACKER, 
          GET_DEFAULT_TRACKER, SET_DEFAULT_TRACKER, SET_APP_OPT_OUT, REQUEST_APP_OPT_OUT, DISPATCH, SET_DISPATCH_PERIOD, BLANK_48, REPORT_UNCAUGHT_EXCEPTIONS, SET_AUTO_ACTIVITY_TRACKING, SET_SESSION_TIMEOUT, 
          CONSTRUCT_EVENT, CONSTRUCT_ITEM, SET_APP_INSTALLER_ID, GET_APP_INSTALLER_ID };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\GAUsage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */