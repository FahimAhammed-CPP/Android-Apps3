package com.google.analytics.tracking.android;

interface ParameterLoader {
  boolean getBoolean(String paramString);
  
  Double getDoubleFromString(String paramString);
  
  int getInt(String paramString, int paramInt);
  
  String getString(String paramString);
  
  boolean isBooleanKeyPresent(String paramString);
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\ParameterLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */