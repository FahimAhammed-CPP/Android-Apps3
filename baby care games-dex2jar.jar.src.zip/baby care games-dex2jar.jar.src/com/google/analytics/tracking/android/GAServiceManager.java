package com.google.analytics.tracking.android;

import android.content.Context;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import com.google.android.gms.common.util.VisibleForTesting;

public class GAServiceManager implements ServiceManager {
  private static final int MSG_KEY = 1;
  
  private static final Object MSG_OBJECT = new Object();
  
  private static GAServiceManager instance;
  
  private boolean connected = true;
  
  private Context ctx;
  
  private int dispatchPeriodInSeconds = 1800;
  
  private Handler handler;
  
  private boolean listenForNetwork = true;
  
  private AnalyticsStoreStateListener listener = new AnalyticsStoreStateListener() {
      public void reportStoreIsEmpty(boolean param1Boolean) {
        GAServiceManager.this.updatePowerSaveMode(param1Boolean, GAServiceManager.this.connected);
      }
    };
  
  private GANetworkReceiver networkReceiver;
  
  private boolean pendingDispatch = true;
  
  private AnalyticsStore store;
  
  private boolean storeIsEmpty = false;
  
  private volatile AnalyticsThread thread;
  
  private GAServiceManager() {}
  
  @VisibleForTesting
  GAServiceManager(Context paramContext, AnalyticsThread paramAnalyticsThread, AnalyticsStore paramAnalyticsStore, boolean paramBoolean) {
    this.store = paramAnalyticsStore;
    this.thread = paramAnalyticsThread;
    this.listenForNetwork = paramBoolean;
    initialize(paramContext, paramAnalyticsThread);
  }
  
  public static GAServiceManager getInstance() {
    if (instance == null)
      instance = new GAServiceManager(); 
    return instance;
  }
  
  private void initializeHandler() {
    this.handler = new Handler(this.ctx.getMainLooper(), new Handler.Callback() {
          public boolean handleMessage(Message param1Message) {
            if (1 == param1Message.what && GAServiceManager.MSG_OBJECT.equals(param1Message.obj)) {
              GAUsage.getInstance().setDisableUsage(true);
              GAServiceManager.this.dispatch();
              GAUsage.getInstance().setDisableUsage(false);
              if (GAServiceManager.this.dispatchPeriodInSeconds > 0 && !GAServiceManager.this.storeIsEmpty)
                GAServiceManager.this.handler.sendMessageDelayed(GAServiceManager.this.handler.obtainMessage(1, GAServiceManager.MSG_OBJECT), (GAServiceManager.this.dispatchPeriodInSeconds * 1000)); 
            } 
            return true;
          }
        });
    if (this.dispatchPeriodInSeconds > 0)
      this.handler.sendMessageDelayed(this.handler.obtainMessage(1, MSG_OBJECT), (this.dispatchPeriodInSeconds * 1000)); 
  }
  
  private void initializeNetworkReceiver() {
    this.networkReceiver = new GANetworkReceiver(this);
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
    this.ctx.registerReceiver(this.networkReceiver, intentFilter);
  }
  
  public void dispatch() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield thread : Lcom/google/analytics/tracking/android/AnalyticsThread;
    //   6: ifnonnull -> 23
    //   9: ldc 'dispatch call queued.  Need to call GAServiceManager.getInstance().initialize().'
    //   11: invokestatic w : (Ljava/lang/String;)I
    //   14: pop
    //   15: aload_0
    //   16: iconst_1
    //   17: putfield pendingDispatch : Z
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: invokestatic getInstance : ()Lcom/google/analytics/tracking/android/GAUsage;
    //   26: getstatic com/google/analytics/tracking/android/GAUsage$Field.DISPATCH : Lcom/google/analytics/tracking/android/GAUsage$Field;
    //   29: invokevirtual setUsage : (Lcom/google/analytics/tracking/android/GAUsage$Field;)V
    //   32: aload_0
    //   33: getfield thread : Lcom/google/analytics/tracking/android/AnalyticsThread;
    //   36: invokeinterface dispatch : ()V
    //   41: goto -> 20
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	44	finally
    //   23	41	44	finally
  }
  
  @VisibleForTesting
  AnalyticsStoreStateListener getListener() {
    return this.listener;
  }
  
  AnalyticsStore getStore() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield store : Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   6: ifnonnull -> 50
    //   9: aload_0
    //   10: getfield ctx : Landroid/content/Context;
    //   13: ifnonnull -> 31
    //   16: new java/lang/IllegalStateException
    //   19: dup
    //   20: ldc 'Cant get a store unless we have a context'
    //   22: invokespecial <init> : (Ljava/lang/String;)V
    //   25: athrow
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    //   31: aload_0
    //   32: new com/google/analytics/tracking/android/PersistentAnalyticsStore
    //   35: dup
    //   36: aload_0
    //   37: getfield listener : Lcom/google/analytics/tracking/android/AnalyticsStoreStateListener;
    //   40: aload_0
    //   41: getfield ctx : Landroid/content/Context;
    //   44: invokespecial <init> : (Lcom/google/analytics/tracking/android/AnalyticsStoreStateListener;Landroid/content/Context;)V
    //   47: putfield store : Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   50: aload_0
    //   51: getfield handler : Landroid/os/Handler;
    //   54: ifnonnull -> 61
    //   57: aload_0
    //   58: invokespecial initializeHandler : ()V
    //   61: aload_0
    //   62: getfield networkReceiver : Lcom/google/analytics/tracking/android/GANetworkReceiver;
    //   65: ifnonnull -> 79
    //   68: aload_0
    //   69: getfield listenForNetwork : Z
    //   72: ifeq -> 79
    //   75: aload_0
    //   76: invokespecial initializeNetworkReceiver : ()V
    //   79: aload_0
    //   80: getfield store : Lcom/google/analytics/tracking/android/AnalyticsStore;
    //   83: astore_1
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_1
    //   87: areturn
    // Exception table:
    //   from	to	target	type
    //   2	26	26	finally
    //   31	50	26	finally
    //   50	61	26	finally
    //   61	79	26	finally
    //   79	84	26	finally
  }
  
  void initialize(Context paramContext, AnalyticsThread paramAnalyticsThread) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield ctx : Landroid/content/Context;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: aload_1
    //   16: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   19: putfield ctx : Landroid/content/Context;
    //   22: aload_0
    //   23: getfield thread : Lcom/google/analytics/tracking/android/AnalyticsThread;
    //   26: ifnonnull -> 11
    //   29: aload_0
    //   30: aload_2
    //   31: putfield thread : Lcom/google/analytics/tracking/android/AnalyticsThread;
    //   34: aload_0
    //   35: getfield pendingDispatch : Z
    //   38: ifeq -> 11
    //   41: aload_2
    //   42: invokeinterface dispatch : ()V
    //   47: goto -> 11
    //   50: astore_1
    //   51: aload_0
    //   52: monitorexit
    //   53: aload_1
    //   54: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	50	finally
    //   14	47	50	finally
  }
  
  public void setDispatchPeriod(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield handler : Landroid/os/Handler;
    //   6: ifnonnull -> 23
    //   9: ldc 'Need to call initialize() and be in fallback mode to start dispatch.'
    //   11: invokestatic w : (Ljava/lang/String;)I
    //   14: pop
    //   15: aload_0
    //   16: iload_1
    //   17: putfield dispatchPeriodInSeconds : I
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: invokestatic getInstance : ()Lcom/google/analytics/tracking/android/GAUsage;
    //   26: getstatic com/google/analytics/tracking/android/GAUsage$Field.SET_DISPATCH_PERIOD : Lcom/google/analytics/tracking/android/GAUsage$Field;
    //   29: invokevirtual setUsage : (Lcom/google/analytics/tracking/android/GAUsage$Field;)V
    //   32: aload_0
    //   33: getfield storeIsEmpty : Z
    //   36: ifne -> 64
    //   39: aload_0
    //   40: getfield connected : Z
    //   43: ifeq -> 64
    //   46: aload_0
    //   47: getfield dispatchPeriodInSeconds : I
    //   50: ifle -> 64
    //   53: aload_0
    //   54: getfield handler : Landroid/os/Handler;
    //   57: iconst_1
    //   58: getstatic com/google/analytics/tracking/android/GAServiceManager.MSG_OBJECT : Ljava/lang/Object;
    //   61: invokevirtual removeMessages : (ILjava/lang/Object;)V
    //   64: aload_0
    //   65: iload_1
    //   66: putfield dispatchPeriodInSeconds : I
    //   69: iload_1
    //   70: ifle -> 20
    //   73: aload_0
    //   74: getfield storeIsEmpty : Z
    //   77: ifne -> 20
    //   80: aload_0
    //   81: getfield connected : Z
    //   84: ifeq -> 20
    //   87: aload_0
    //   88: getfield handler : Landroid/os/Handler;
    //   91: aload_0
    //   92: getfield handler : Landroid/os/Handler;
    //   95: iconst_1
    //   96: getstatic com/google/analytics/tracking/android/GAServiceManager.MSG_OBJECT : Ljava/lang/Object;
    //   99: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   102: iload_1
    //   103: sipush #1000
    //   106: imul
    //   107: i2l
    //   108: invokevirtual sendMessageDelayed : (Landroid/os/Message;J)Z
    //   111: pop
    //   112: goto -> 20
    //   115: astore_2
    //   116: aload_0
    //   117: monitorexit
    //   118: aload_2
    //   119: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	115	finally
    //   23	64	115	finally
    //   64	69	115	finally
    //   73	112	115	finally
  }
  
  public void updateConnectivityStatus(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield storeIsEmpty : Z
    //   7: iload_1
    //   8: invokevirtual updatePowerSaveMode : (ZZ)V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  @VisibleForTesting
  void updatePowerSaveMode(boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield storeIsEmpty : Z
    //   6: iload_1
    //   7: if_icmpne -> 23
    //   10: aload_0
    //   11: getfield connected : Z
    //   14: istore_3
    //   15: iload_3
    //   16: iload_2
    //   17: if_icmpne -> 23
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: iload_1
    //   24: ifne -> 31
    //   27: iload_2
    //   28: ifne -> 49
    //   31: aload_0
    //   32: getfield dispatchPeriodInSeconds : I
    //   35: ifle -> 49
    //   38: aload_0
    //   39: getfield handler : Landroid/os/Handler;
    //   42: iconst_1
    //   43: getstatic com/google/analytics/tracking/android/GAServiceManager.MSG_OBJECT : Ljava/lang/Object;
    //   46: invokevirtual removeMessages : (ILjava/lang/Object;)V
    //   49: iload_1
    //   50: ifne -> 92
    //   53: iload_2
    //   54: ifeq -> 92
    //   57: aload_0
    //   58: getfield dispatchPeriodInSeconds : I
    //   61: ifle -> 92
    //   64: aload_0
    //   65: getfield handler : Landroid/os/Handler;
    //   68: aload_0
    //   69: getfield handler : Landroid/os/Handler;
    //   72: iconst_1
    //   73: getstatic com/google/analytics/tracking/android/GAServiceManager.MSG_OBJECT : Ljava/lang/Object;
    //   76: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
    //   79: aload_0
    //   80: getfield dispatchPeriodInSeconds : I
    //   83: sipush #1000
    //   86: imul
    //   87: i2l
    //   88: invokevirtual sendMessageDelayed : (Landroid/os/Message;J)Z
    //   91: pop
    //   92: new java/lang/StringBuilder
    //   95: dup
    //   96: invokespecial <init> : ()V
    //   99: ldc 'PowerSaveMode '
    //   101: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: astore #5
    //   106: iload_1
    //   107: ifne -> 158
    //   110: iload_2
    //   111: ifne -> 151
    //   114: goto -> 158
    //   117: aload #5
    //   119: aload #4
    //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: invokevirtual toString : ()Ljava/lang/String;
    //   127: invokestatic iDebug : (Ljava/lang/String;)I
    //   130: pop
    //   131: aload_0
    //   132: iload_1
    //   133: putfield storeIsEmpty : Z
    //   136: aload_0
    //   137: iload_2
    //   138: putfield connected : Z
    //   141: goto -> 20
    //   144: astore #4
    //   146: aload_0
    //   147: monitorexit
    //   148: aload #4
    //   150: athrow
    //   151: ldc 'terminated.'
    //   153: astore #4
    //   155: goto -> 117
    //   158: ldc 'initiated.'
    //   160: astore #4
    //   162: goto -> 117
    // Exception table:
    //   from	to	target	type
    //   2	15	144	finally
    //   31	49	144	finally
    //   57	92	144	finally
    //   92	106	144	finally
    //   117	141	144	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\analytics\tracking\android\GAServiceManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */