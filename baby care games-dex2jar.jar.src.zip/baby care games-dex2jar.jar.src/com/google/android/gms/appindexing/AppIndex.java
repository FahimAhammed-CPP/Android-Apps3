package com.google.android.gms.appindexing;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.internal.hc;
import com.google.android.gms.internal.hz;

public final class AppIndex {
  public static final Api<Api.ApiOptions.NoOptions> API = hc.CI;
  
  public static final Api<Api.ApiOptions.NoOptions> APP_INDEX_API = hc.CI;
  
  public static final AppIndexApi AppIndexApi = (AppIndexApi)new hz();
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\appindexing\AppIndex.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */