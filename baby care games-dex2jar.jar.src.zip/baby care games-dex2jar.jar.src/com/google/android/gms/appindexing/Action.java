package com.google.android.gms.appindexing;

import android.net.Uri;
import android.os.Bundle;
import com.google.android.gms.internal.jx;

public final class Action extends Thing {
  public static final String TYPE_ADD = "http://schema.org/AddAction";
  
  public static final String TYPE_BOOKMARK = "http://schema.org/BookmarkAction";
  
  public static final String TYPE_LIKE = "http://schema.org/LikeAction";
  
  public static final String TYPE_LISTEN = "http://schema.org/ListenAction";
  
  public static final String TYPE_VIEW = "http://schema.org/ViewAction";
  
  public static final String TYPE_WANT = "http://schema.org/WantAction";
  
  public static final String TYPE_WATCH = "http://schema.org/WatchAction";
  
  private Action(Bundle paramBundle) {
    super(paramBundle);
  }
  
  public static Action newAction(String paramString1, String paramString2, Uri paramUri) {
    return newAction(paramString1, paramString2, null, paramUri);
  }
  
  public static Action newAction(String paramString1, String paramString2, Uri paramUri1, Uri paramUri2) {
    Builder builder1 = new Builder(paramString1);
    Thing.Builder builder = (new Thing.Builder()).setName(paramString2);
    if (paramUri1 == null) {
      paramString1 = null;
      return builder1.setObject(builder.setId(paramString1).setUrl(paramUri2).build()).build();
    } 
    paramString1 = paramUri1.toString();
    return builder1.setObject(builder.setId(paramString1).setUrl(paramUri2).build()).build();
  }
  
  public static final class Builder extends Thing.Builder {
    public Builder(String param1String) {
      jx.i(param1String);
      super.put("type", param1String);
    }
    
    public Action build() {
      jx.b(this.DJ.get("object"), "setObject is required before calling build().");
      jx.b(this.DJ.get("type"), "setType is required before calling build().");
      Bundle bundle = (Bundle)this.DJ.getParcelable("object");
      jx.b(bundle.get("name"), "Must call setObject() with a valid name. Example: setObject(new Thing.Builder().setName(name).setUrl(url))");
      jx.b(bundle.get("url"), "Must call setObject() with a valid app url. Example: setObject(new Thing.Builder().setName(name).setUrl(url))");
      return new Action(this.DJ);
    }
    
    public Builder put(String param1String, Thing param1Thing) {
      return (Builder)super.put(param1String, param1Thing);
    }
    
    public Builder put(String param1String1, String param1String2) {
      return (Builder)super.put(param1String1, param1String2);
    }
    
    public Builder setName(String param1String) {
      return (Builder)super.put("name", param1String);
    }
    
    public Builder setObject(Thing param1Thing) {
      jx.i(param1Thing);
      return (Builder)super.put("object", param1Thing);
    }
    
    public Builder setUrl(Uri param1Uri) {
      if (param1Uri != null)
        super.put("url", param1Uri.toString()); 
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\appindexing\Action.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */