package com.google.android.gms.appindexing;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import com.google.android.gms.internal.jx;

public class Thing {
  final Bundle DI;
  
  Thing(Bundle paramBundle) {
    this.DI = paramBundle;
  }
  
  public Bundle fI() {
    return this.DI;
  }
  
  public static class Builder {
    final Bundle DJ = new Bundle();
    
    public Thing build() {
      return new Thing(this.DJ);
    }
    
    public Builder put(String param1String, Thing param1Thing) {
      jx.i(param1String);
      if (param1Thing != null)
        this.DJ.putParcelable(param1String, (Parcelable)param1Thing.DI); 
      return this;
    }
    
    public Builder put(String param1String1, String param1String2) {
      jx.i(param1String1);
      if (param1String2 != null)
        this.DJ.putString(param1String1, param1String2); 
      return this;
    }
    
    public Builder setDescription(String param1String) {
      put("description", param1String);
      return this;
    }
    
    public Builder setId(String param1String) {
      if (param1String != null)
        put("id", param1String); 
      return this;
    }
    
    public Builder setName(String param1String) {
      jx.i(param1String);
      put("name", param1String);
      return this;
    }
    
    public Builder setType(String param1String) {
      put("type", param1String);
      return this;
    }
    
    public Builder setUrl(Uri param1Uri) {
      jx.i(param1Uri);
      put("url", param1Uri.toString());
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\appindexing\Thing.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */