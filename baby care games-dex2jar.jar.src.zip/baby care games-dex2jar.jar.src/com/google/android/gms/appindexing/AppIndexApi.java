package com.google.android.gms.appindexing;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import java.util.List;

public interface AppIndexApi {
  ActionResult action(GoogleApiClient paramGoogleApiClient, Action paramAction);
  
  @Deprecated
  PendingResult<Status> view(GoogleApiClient paramGoogleApiClient, Activity paramActivity, Intent paramIntent, String paramString, Uri paramUri, List<AppIndexingLink> paramList);
  
  PendingResult<Status> view(GoogleApiClient paramGoogleApiClient, Activity paramActivity, Uri paramUri1, String paramString, Uri paramUri2, List<AppIndexingLink> paramList);
  
  @Deprecated
  PendingResult<Status> viewEnd(GoogleApiClient paramGoogleApiClient, Activity paramActivity, Intent paramIntent);
  
  PendingResult<Status> viewEnd(GoogleApiClient paramGoogleApiClient, Activity paramActivity, Uri paramUri);
  
  public static interface ActionResult {
    PendingResult<Status> end(GoogleApiClient param1GoogleApiClient);
    
    PendingResult<Status> getPendingResult();
  }
  
  public static final class AppIndexingLink {
    public final Uri appIndexingUrl;
    
    public final int viewId;
    
    public final Uri webUrl;
    
    public AppIndexingLink(Uri param1Uri1, Uri param1Uri2, View param1View) {
      this.appIndexingUrl = param1Uri1;
      this.webUrl = param1Uri2;
      this.viewId = param1View.getId();
    }
    
    public AppIndexingLink(Uri param1Uri, View param1View) {
      this(param1Uri, null, param1View);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\appindexing\AppIndexApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */