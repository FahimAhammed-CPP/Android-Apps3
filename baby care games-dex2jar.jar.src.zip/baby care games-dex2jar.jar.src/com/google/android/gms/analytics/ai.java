package com.google.android.gms.analytics;

import android.content.Context;
import android.util.DisplayMetrics;

class ai implements q {
  private static ai Cc;
  
  private static Object xO = new Object();
  
  private final Context mContext;
  
  protected ai(Context paramContext) {
    this.mContext = paramContext;
  }
  
  public static ai fl() {
    synchronized (xO) {
      return Cc;
    } 
  }
  
  public static void y(Context paramContext) {
    synchronized (xO) {
      if (Cc == null)
        Cc = new ai(paramContext); 
      return;
    } 
  }
  
  public boolean ac(String paramString) {
    return "&sr".equals(paramString);
  }
  
  protected String fm() {
    DisplayMetrics displayMetrics = this.mContext.getResources().getDisplayMetrics();
    return displayMetrics.widthPixels + "x" + displayMetrics.heightPixels;
  }
  
  public String getValue(String paramString) {
    return (paramString != null && paramString.equals("&sr")) ? fm() : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */