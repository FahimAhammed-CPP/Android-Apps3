package com.google.android.gms.analytics;

import android.os.Build;
import java.io.File;

public class t {
  public static boolean ag(String paramString) {
    if (version() < 9)
      return false; 
    File file = new File(paramString);
    file.setReadable(false, false);
    file.setWritable(false, false);
    file.setReadable(true, true);
    file.setWritable(true, true);
    return true;
  }
  
  public static int version() {
    try {
      return Integer.parseInt(Build.VERSION.SDK);
    } catch (NumberFormatException numberFormatException) {
      ae.T("Invalid version number: " + Build.VERSION.SDK);
      return 0;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */