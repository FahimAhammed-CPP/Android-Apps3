package com.google.android.gms.analytics;

public interface Logger {
  void error(Exception paramException);
  
  void error(String paramString);
  
  int getLogLevel();
  
  void info(String paramString);
  
  void setLogLevel(int paramInt);
  
  void verbose(String paramString);
  
  void warn(String paramString);
  
  public static class LogLevel {
    public static final int ERROR = 3;
    
    public static final int INFO = 1;
    
    public static final int VERBOSE = 0;
    
    public static final int WARNING = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\Logger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */