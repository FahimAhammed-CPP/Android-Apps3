package com.google.android.gms.analytics;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import java.io.FileOutputStream;
import java.io.IOException;

public class CampaignTrackingService extends IntentService {
  public CampaignTrackingService() {
    super("CampaignIntentService");
  }
  
  public CampaignTrackingService(String paramString) {
    super(paramString);
  }
  
  public void onHandleIntent(Intent paramIntent) {
    processIntent((Context)this, paramIntent);
  }
  
  public void processIntent(Context paramContext, Intent paramIntent) {
    String str = paramIntent.getStringExtra("referrer");
    try {
      FileOutputStream fileOutputStream = paramContext.openFileOutput("gaInstallData", 0);
      fileOutputStream.write(str.getBytes());
      fileOutputStream.close();
      ae.V("Stored campaign information.");
      return;
    } catch (IOException iOException) {
      ae.T("Error storing install campaign.");
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\CampaignTrackingService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */