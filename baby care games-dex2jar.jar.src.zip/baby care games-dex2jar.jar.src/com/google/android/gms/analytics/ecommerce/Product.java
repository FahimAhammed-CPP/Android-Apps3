package com.google.android.gms.analytics.ecommerce;

import com.google.android.gms.analytics.s;
import com.google.android.gms.internal.jx;
import java.util.HashMap;
import java.util.Map;

public class Product {
  Map<String, String> CD = new HashMap<String, String>();
  
  public Map<String, String> aq(String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (Map.Entry<String, String> entry : this.CD.entrySet())
      hashMap.put(paramString + (String)entry.getKey(), entry.getValue()); 
    return (Map)hashMap;
  }
  
  void put(String paramString1, String paramString2) {
    jx.b(paramString1, "Name should be non-null");
    this.CD.put(paramString1, paramString2);
  }
  
  public Product setBrand(String paramString) {
    put("br", paramString);
    return this;
  }
  
  public Product setCategory(String paramString) {
    put("ca", paramString);
    return this;
  }
  
  public Product setCouponCode(String paramString) {
    put("cc", paramString);
    return this;
  }
  
  public Product setCustomDimension(int paramInt, String paramString) {
    put(s.E(paramInt), paramString);
    return this;
  }
  
  public Product setCustomMetric(int paramInt1, int paramInt2) {
    put(s.F(paramInt1), Integer.toString(paramInt2));
    return this;
  }
  
  public Product setId(String paramString) {
    put("id", paramString);
    return this;
  }
  
  public Product setName(String paramString) {
    put("nm", paramString);
    return this;
  }
  
  public Product setPosition(int paramInt) {
    put("ps", Integer.toString(paramInt));
    return this;
  }
  
  public Product setPrice(double paramDouble) {
    put("pr", Double.toString(paramDouble));
    return this;
  }
  
  public Product setQuantity(int paramInt) {
    put("qt", Integer.toString(paramInt));
    return this;
  }
  
  public Product setVariant(String paramString) {
    put("va", paramString);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\ecommerce\Product.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */