package com.google.android.gms.analytics;

import android.content.Context;
import android.content.Intent;
import com.google.android.gms.internal.ha;
import com.google.android.gms.internal.ld;
import com.google.android.gms.internal.lf;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;

class w implements ak, c.b, c.c {
  private final Context mContext;
  
  private ld wb;
  
  private d yU;
  
  private final f yV;
  
  private boolean yX;
  
  private volatile long zh;
  
  private volatile a zi;
  
  private volatile b zj;
  
  private d zk;
  
  private final GoogleAnalytics zl;
  
  private final Queue<d> zm = new ConcurrentLinkedQueue<d>();
  
  private volatile int zn;
  
  private volatile Timer zo;
  
  private volatile Timer zp;
  
  private volatile Timer zq;
  
  private boolean zr;
  
  private boolean zs;
  
  private boolean zt;
  
  private long zu = 300000L;
  
  w(Context paramContext, f paramf) {
    this(paramContext, paramf, null, GoogleAnalytics.getInstance(paramContext));
  }
  
  w(Context paramContext, f paramf, d paramd, GoogleAnalytics paramGoogleAnalytics) {
    this.zk = paramd;
    this.mContext = paramContext;
    this.yV = paramf;
    this.zl = paramGoogleAnalytics;
    this.wb = lf.if();
    this.zn = 0;
    this.zi = a.zD;
  }
  
  private Timer a(Timer paramTimer) {
    if (paramTimer != null)
      paramTimer.cancel(); 
    return null;
  }
  
  private void cJ() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zj : Lcom/google/android/gms/analytics/b;
    //   6: ifnull -> 35
    //   9: aload_0
    //   10: getfield zi : Lcom/google/android/gms/analytics/w$a;
    //   13: getstatic com/google/android/gms/analytics/w$a.zy : Lcom/google/android/gms/analytics/w$a;
    //   16: if_acmpne -> 35
    //   19: aload_0
    //   20: getstatic com/google/android/gms/analytics/w$a.zC : Lcom/google/android/gms/analytics/w$a;
    //   23: putfield zi : Lcom/google/android/gms/analytics/w$a;
    //   26: aload_0
    //   27: getfield zj : Lcom/google/android/gms/analytics/b;
    //   30: invokeinterface disconnect : ()V
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	35	38	finally
  }
  
  private void eA() {
    this.zo = a(this.zo);
    this.zp = a(this.zp);
    this.zq = a(this.zq);
  }
  
  private void eC() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic currentThread : ()Ljava/lang/Thread;
    //   5: aload_0
    //   6: getfield yV : Lcom/google/android/gms/analytics/f;
    //   9: invokeinterface getThread : ()Ljava/lang/Thread;
    //   14: invokevirtual equals : (Ljava/lang/Object;)Z
    //   17: ifne -> 44
    //   20: aload_0
    //   21: getfield yV : Lcom/google/android/gms/analytics/f;
    //   24: invokeinterface dX : ()Ljava/util/concurrent/LinkedBlockingQueue;
    //   29: new com/google/android/gms/analytics/w$1
    //   32: dup
    //   33: aload_0
    //   34: invokespecial <init> : (Lcom/google/android/gms/analytics/w;)V
    //   37: invokevirtual add : (Ljava/lang/Object;)Z
    //   40: pop
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: aload_0
    //   45: getfield zr : Z
    //   48: ifeq -> 55
    //   51: aload_0
    //   52: invokevirtual dQ : ()V
    //   55: getstatic com/google/android/gms/analytics/w$2.zw : [I
    //   58: aload_0
    //   59: getfield zi : Lcom/google/android/gms/analytics/w$a;
    //   62: invokevirtual ordinal : ()I
    //   65: iaload
    //   66: tableswitch default -> 365, 1 -> 108, 2 -> 219, 3 -> 365, 4 -> 365, 5 -> 365, 6 -> 340, 7 -> 188
    //   108: aload_0
    //   109: getfield zm : Ljava/util/Queue;
    //   112: invokeinterface isEmpty : ()Z
    //   117: ifne -> 205
    //   120: aload_0
    //   121: getfield zm : Ljava/util/Queue;
    //   124: invokeinterface poll : ()Ljava/lang/Object;
    //   129: checkcast com/google/android/gms/analytics/w$d
    //   132: astore_1
    //   133: new java/lang/StringBuilder
    //   136: dup
    //   137: invokespecial <init> : ()V
    //   140: ldc 'Sending hit to store  '
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: aload_1
    //   146: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   149: invokevirtual toString : ()Ljava/lang/String;
    //   152: invokestatic V : (Ljava/lang/String;)V
    //   155: aload_0
    //   156: getfield yU : Lcom/google/android/gms/analytics/d;
    //   159: aload_1
    //   160: invokevirtual eH : ()Ljava/util/Map;
    //   163: aload_1
    //   164: invokevirtual eI : ()J
    //   167: aload_1
    //   168: invokevirtual getPath : ()Ljava/lang/String;
    //   171: aload_1
    //   172: invokevirtual eJ : ()Ljava/util/List;
    //   175: invokeinterface a : (Ljava/util/Map;JLjava/lang/String;Ljava/util/Collection;)V
    //   180: goto -> 108
    //   183: astore_1
    //   184: aload_0
    //   185: monitorexit
    //   186: aload_1
    //   187: athrow
    //   188: ldc 'Blocked. Dropping hits.'
    //   190: invokestatic V : (Ljava/lang/String;)V
    //   193: aload_0
    //   194: getfield zm : Ljava/util/Queue;
    //   197: invokeinterface clear : ()V
    //   202: goto -> 41
    //   205: aload_0
    //   206: getfield yX : Z
    //   209: ifeq -> 41
    //   212: aload_0
    //   213: invokespecial eD : ()V
    //   216: goto -> 41
    //   219: aload_0
    //   220: getfield zm : Ljava/util/Queue;
    //   223: invokeinterface isEmpty : ()Z
    //   228: ifne -> 324
    //   231: aload_0
    //   232: getfield zm : Ljava/util/Queue;
    //   235: invokeinterface peek : ()Ljava/lang/Object;
    //   240: checkcast com/google/android/gms/analytics/w$d
    //   243: astore_1
    //   244: new java/lang/StringBuilder
    //   247: dup
    //   248: invokespecial <init> : ()V
    //   251: ldc_w 'Sending hit to service   '
    //   254: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   257: aload_1
    //   258: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   261: invokevirtual toString : ()Ljava/lang/String;
    //   264: invokestatic V : (Ljava/lang/String;)V
    //   267: aload_0
    //   268: getfield zl : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   271: invokevirtual isDryRunEnabled : ()Z
    //   274: ifne -> 315
    //   277: aload_0
    //   278: getfield zj : Lcom/google/android/gms/analytics/b;
    //   281: aload_1
    //   282: invokevirtual eH : ()Ljava/util/Map;
    //   285: aload_1
    //   286: invokevirtual eI : ()J
    //   289: aload_1
    //   290: invokevirtual getPath : ()Ljava/lang/String;
    //   293: aload_1
    //   294: invokevirtual eJ : ()Ljava/util/List;
    //   297: invokeinterface a : (Ljava/util/Map;JLjava/lang/String;Ljava/util/List;)V
    //   302: aload_0
    //   303: getfield zm : Ljava/util/Queue;
    //   306: invokeinterface poll : ()Ljava/lang/Object;
    //   311: pop
    //   312: goto -> 219
    //   315: ldc_w 'Dry run enabled. Hit not actually sent to service.'
    //   318: invokestatic V : (Ljava/lang/String;)V
    //   321: goto -> 302
    //   324: aload_0
    //   325: aload_0
    //   326: getfield wb : Lcom/google/android/gms/internal/ld;
    //   329: invokeinterface elapsedRealtime : ()J
    //   334: putfield zh : J
    //   337: goto -> 41
    //   340: ldc_w 'Need to reconnect'
    //   343: invokestatic V : (Ljava/lang/String;)V
    //   346: aload_0
    //   347: getfield zm : Ljava/util/Queue;
    //   350: invokeinterface isEmpty : ()Z
    //   355: ifne -> 41
    //   358: aload_0
    //   359: invokespecial eF : ()V
    //   362: goto -> 41
    //   365: goto -> 41
    // Exception table:
    //   from	to	target	type
    //   2	41	183	finally
    //   44	55	183	finally
    //   55	108	183	finally
    //   108	180	183	finally
    //   188	202	183	finally
    //   205	216	183	finally
    //   219	302	183	finally
    //   302	312	183	finally
    //   315	321	183	finally
    //   324	337	183	finally
    //   340	362	183	finally
  }
  
  private void eD() {
    this.yU.dispatch();
    this.yX = false;
  }
  
  private void eE() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zi : Lcom/google/android/gms/analytics/w$a;
    //   6: astore_1
    //   7: getstatic com/google/android/gms/analytics/w$a.zz : Lcom/google/android/gms/analytics/w$a;
    //   10: astore_2
    //   11: aload_1
    //   12: aload_2
    //   13: if_acmpne -> 19
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: aload_0
    //   20: getfield mContext : Landroid/content/Context;
    //   23: ifnull -> 72
    //   26: ldc_w 'com.google.android.gms'
    //   29: aload_0
    //   30: getfield mContext : Landroid/content/Context;
    //   33: invokevirtual getPackageName : ()Ljava/lang/String;
    //   36: invokevirtual equals : (Ljava/lang/Object;)Z
    //   39: ifeq -> 72
    //   42: aload_0
    //   43: getstatic com/google/android/gms/analytics/w$a.zA : Lcom/google/android/gms/analytics/w$a;
    //   46: putfield zi : Lcom/google/android/gms/analytics/w$a;
    //   49: aload_0
    //   50: getfield zj : Lcom/google/android/gms/analytics/b;
    //   53: invokeinterface disconnect : ()V
    //   58: ldc_w 'Attempted to fall back to local store from service.'
    //   61: invokestatic W : (Ljava/lang/String;)V
    //   64: goto -> 16
    //   67: astore_1
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_1
    //   71: athrow
    //   72: aload_0
    //   73: invokespecial eA : ()V
    //   76: ldc_w 'falling back to local store'
    //   79: invokestatic V : (Ljava/lang/String;)V
    //   82: aload_0
    //   83: getfield zk : Lcom/google/android/gms/analytics/d;
    //   86: ifnull -> 111
    //   89: aload_0
    //   90: aload_0
    //   91: getfield zk : Lcom/google/android/gms/analytics/d;
    //   94: putfield yU : Lcom/google/android/gms/analytics/d;
    //   97: aload_0
    //   98: getstatic com/google/android/gms/analytics/w$a.zz : Lcom/google/android/gms/analytics/w$a;
    //   101: putfield zi : Lcom/google/android/gms/analytics/w$a;
    //   104: aload_0
    //   105: invokespecial eC : ()V
    //   108: goto -> 16
    //   111: invokestatic eu : ()Lcom/google/android/gms/analytics/v;
    //   114: astore_1
    //   115: aload_1
    //   116: aload_0
    //   117: getfield mContext : Landroid/content/Context;
    //   120: aload_0
    //   121: getfield yV : Lcom/google/android/gms/analytics/f;
    //   124: invokevirtual a : (Landroid/content/Context;Lcom/google/android/gms/analytics/f;)V
    //   127: aload_0
    //   128: aload_1
    //   129: invokevirtual ex : ()Lcom/google/android/gms/analytics/d;
    //   132: putfield yU : Lcom/google/android/gms/analytics/d;
    //   135: goto -> 97
    // Exception table:
    //   from	to	target	type
    //   2	11	67	finally
    //   19	64	67	finally
    //   72	97	67	finally
    //   97	108	67	finally
    //   111	135	67	finally
  }
  
  private void eF() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zt : Z
    //   6: ifne -> 126
    //   9: aload_0
    //   10: getfield zj : Lcom/google/android/gms/analytics/b;
    //   13: ifnull -> 126
    //   16: aload_0
    //   17: getfield zi : Lcom/google/android/gms/analytics/w$a;
    //   20: astore_1
    //   21: getstatic com/google/android/gms/analytics/w$a.zz : Lcom/google/android/gms/analytics/w$a;
    //   24: astore_2
    //   25: aload_1
    //   26: aload_2
    //   27: if_acmpeq -> 126
    //   30: aload_0
    //   31: aload_0
    //   32: getfield zn : I
    //   35: iconst_1
    //   36: iadd
    //   37: putfield zn : I
    //   40: aload_0
    //   41: aload_0
    //   42: getfield zp : Ljava/util/Timer;
    //   45: invokespecial a : (Ljava/util/Timer;)Ljava/util/Timer;
    //   48: pop
    //   49: aload_0
    //   50: getstatic com/google/android/gms/analytics/w$a.zx : Lcom/google/android/gms/analytics/w$a;
    //   53: putfield zi : Lcom/google/android/gms/analytics/w$a;
    //   56: aload_0
    //   57: new java/util/Timer
    //   60: dup
    //   61: ldc_w 'Failed Connect'
    //   64: invokespecial <init> : (Ljava/lang/String;)V
    //   67: putfield zp : Ljava/util/Timer;
    //   70: aload_0
    //   71: getfield zp : Ljava/util/Timer;
    //   74: new com/google/android/gms/analytics/w$c
    //   77: dup
    //   78: aload_0
    //   79: aconst_null
    //   80: invokespecial <init> : (Lcom/google/android/gms/analytics/w;Lcom/google/android/gms/analytics/w$1;)V
    //   83: ldc2_w 3000
    //   86: invokevirtual schedule : (Ljava/util/TimerTask;J)V
    //   89: ldc_w 'connecting to Analytics service'
    //   92: invokestatic V : (Ljava/lang/String;)V
    //   95: aload_0
    //   96: getfield zj : Lcom/google/android/gms/analytics/b;
    //   99: invokeinterface connect : ()V
    //   104: aload_0
    //   105: monitorexit
    //   106: return
    //   107: astore_1
    //   108: ldc_w 'security exception on connectToService'
    //   111: invokestatic W : (Ljava/lang/String;)V
    //   114: aload_0
    //   115: invokespecial eE : ()V
    //   118: goto -> 104
    //   121: astore_1
    //   122: aload_0
    //   123: monitorexit
    //   124: aload_1
    //   125: athrow
    //   126: ldc_w 'client not initialized.'
    //   129: invokestatic W : (Ljava/lang/String;)V
    //   132: aload_0
    //   133: invokespecial eE : ()V
    //   136: goto -> 104
    // Exception table:
    //   from	to	target	type
    //   2	25	121	finally
    //   30	104	107	java/lang/SecurityException
    //   30	104	121	finally
    //   108	118	121	finally
    //   126	136	121	finally
  }
  
  private void eG() {
    this.zo = a(this.zo);
    this.zo = new Timer("Service Reconnect");
    this.zo.schedule(new e(), 5000L);
  }
  
  public void a(int paramInt, Intent paramIntent) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getstatic com/google/android/gms/analytics/w$a.zB : Lcom/google/android/gms/analytics/w$a;
    //   6: putfield zi : Lcom/google/android/gms/analytics/w$a;
    //   9: aload_0
    //   10: getfield zn : I
    //   13: iconst_2
    //   14: if_icmpge -> 53
    //   17: new java/lang/StringBuilder
    //   20: dup
    //   21: invokespecial <init> : ()V
    //   24: ldc_w 'Service unavailable (code='
    //   27: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: iload_1
    //   31: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   34: ldc_w '), will retry.'
    //   37: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: invokevirtual toString : ()Ljava/lang/String;
    //   43: invokestatic W : (Ljava/lang/String;)V
    //   46: aload_0
    //   47: invokespecial eG : ()V
    //   50: aload_0
    //   51: monitorexit
    //   52: return
    //   53: new java/lang/StringBuilder
    //   56: dup
    //   57: invokespecial <init> : ()V
    //   60: ldc_w 'Service unavailable (code='
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: iload_1
    //   67: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   70: ldc_w '), using local store.'
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: invokevirtual toString : ()Ljava/lang/String;
    //   79: invokestatic W : (Ljava/lang/String;)V
    //   82: aload_0
    //   83: invokespecial eE : ()V
    //   86: goto -> 50
    //   89: astore_2
    //   90: aload_0
    //   91: monitorexit
    //   92: aload_2
    //   93: athrow
    // Exception table:
    //   from	to	target	type
    //   2	50	89	finally
    //   53	86	89	finally
  }
  
  public void b(Map<String, String> paramMap, long paramLong, String paramString, List<ha> paramList) {
    ae.V("putHit called");
    this.zm.add(new d(paramMap, paramLong, paramString, paramList));
    eC();
  }
  
  public void dQ() {
    ae.V("clearHits called");
    this.zm.clear();
    switch (null.zw[this.zi.ordinal()]) {
      default:
        this.zr = true;
        return;
      case 1:
        this.yU.l(0L);
        this.zr = false;
        return;
      case 2:
        break;
    } 
    this.zj.dQ();
    this.zr = false;
  }
  
  public void dW() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zt : Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: ldc_w 'setForceLocalDispatch called.'
    //   17: invokestatic V : (Ljava/lang/String;)V
    //   20: aload_0
    //   21: iconst_1
    //   22: putfield zt : Z
    //   25: getstatic com/google/android/gms/analytics/w$2.zw : [I
    //   28: aload_0
    //   29: getfield zi : Lcom/google/android/gms/analytics/w$a;
    //   32: invokevirtual ordinal : ()I
    //   35: iaload
    //   36: tableswitch default -> 96, 1 -> 11, 2 -> 76, 3 -> 88, 4 -> 11, 5 -> 11, 6 -> 11
    //   76: aload_0
    //   77: invokespecial cJ : ()V
    //   80: goto -> 11
    //   83: astore_2
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_2
    //   87: athrow
    //   88: aload_0
    //   89: iconst_1
    //   90: putfield zs : Z
    //   93: goto -> 11
    //   96: goto -> 11
    // Exception table:
    //   from	to	target	type
    //   2	7	83	finally
    //   14	76	83	finally
    //   76	80	83	finally
    //   88	93	83	finally
  }
  
  public void dispatch() {
    switch (null.zw[this.zi.ordinal()]) {
      default:
        this.yX = true;
      case 2:
        return;
      case 1:
        break;
    } 
    eD();
  }
  
  public void eB() {
    if (this.zj != null)
      return; 
    this.zj = new c(this.mContext, this, this);
    eF();
  }
  
  public void onConnected() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: aload_0
    //   5: getfield zp : Ljava/util/Timer;
    //   8: invokespecial a : (Ljava/util/Timer;)Ljava/util/Timer;
    //   11: putfield zp : Ljava/util/Timer;
    //   14: aload_0
    //   15: iconst_0
    //   16: putfield zn : I
    //   19: ldc_w 'Connected to service'
    //   22: invokestatic V : (Ljava/lang/String;)V
    //   25: aload_0
    //   26: getstatic com/google/android/gms/analytics/w$a.zy : Lcom/google/android/gms/analytics/w$a;
    //   29: putfield zi : Lcom/google/android/gms/analytics/w$a;
    //   32: aload_0
    //   33: getfield zs : Z
    //   36: ifeq -> 51
    //   39: aload_0
    //   40: invokespecial cJ : ()V
    //   43: aload_0
    //   44: iconst_0
    //   45: putfield zs : Z
    //   48: aload_0
    //   49: monitorexit
    //   50: return
    //   51: aload_0
    //   52: invokespecial eC : ()V
    //   55: aload_0
    //   56: aload_0
    //   57: aload_0
    //   58: getfield zq : Ljava/util/Timer;
    //   61: invokespecial a : (Ljava/util/Timer;)Ljava/util/Timer;
    //   64: putfield zq : Ljava/util/Timer;
    //   67: aload_0
    //   68: new java/util/Timer
    //   71: dup
    //   72: ldc_w 'disconnect check'
    //   75: invokespecial <init> : (Ljava/lang/String;)V
    //   78: putfield zq : Ljava/util/Timer;
    //   81: aload_0
    //   82: getfield zq : Ljava/util/Timer;
    //   85: new com/google/android/gms/analytics/w$b
    //   88: dup
    //   89: aload_0
    //   90: aconst_null
    //   91: invokespecial <init> : (Lcom/google/android/gms/analytics/w;Lcom/google/android/gms/analytics/w$1;)V
    //   94: aload_0
    //   95: getfield zu : J
    //   98: invokevirtual schedule : (Ljava/util/TimerTask;J)V
    //   101: goto -> 48
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   2	48	104	finally
    //   51	101	104	finally
  }
  
  public void onDisconnected() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield zi : Lcom/google/android/gms/analytics/w$a;
    //   6: getstatic com/google/android/gms/analytics/w$a.zA : Lcom/google/android/gms/analytics/w$a;
    //   9: if_acmpne -> 25
    //   12: ldc_w 'Service blocked.'
    //   15: invokestatic V : (Ljava/lang/String;)V
    //   18: aload_0
    //   19: invokespecial eA : ()V
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: aload_0
    //   26: getfield zi : Lcom/google/android/gms/analytics/w$a;
    //   29: getstatic com/google/android/gms/analytics/w$a.zC : Lcom/google/android/gms/analytics/w$a;
    //   32: if_acmpne -> 60
    //   35: ldc_w 'Disconnected from service'
    //   38: invokestatic V : (Ljava/lang/String;)V
    //   41: aload_0
    //   42: invokespecial eA : ()V
    //   45: aload_0
    //   46: getstatic com/google/android/gms/analytics/w$a.zD : Lcom/google/android/gms/analytics/w$a;
    //   49: putfield zi : Lcom/google/android/gms/analytics/w$a;
    //   52: goto -> 22
    //   55: astore_1
    //   56: aload_0
    //   57: monitorexit
    //   58: aload_1
    //   59: athrow
    //   60: ldc_w 'Unexpected disconnect.'
    //   63: invokestatic V : (Ljava/lang/String;)V
    //   66: aload_0
    //   67: getstatic com/google/android/gms/analytics/w$a.zB : Lcom/google/android/gms/analytics/w$a;
    //   70: putfield zi : Lcom/google/android/gms/analytics/w$a;
    //   73: aload_0
    //   74: getfield zn : I
    //   77: iconst_2
    //   78: if_icmpge -> 88
    //   81: aload_0
    //   82: invokespecial eG : ()V
    //   85: goto -> 22
    //   88: aload_0
    //   89: invokespecial eE : ()V
    //   92: goto -> 22
    // Exception table:
    //   from	to	target	type
    //   2	22	55	finally
    //   25	52	55	finally
    //   60	85	55	finally
    //   88	92	55	finally
  }
  
  private enum a {
    zA, zB, zC, zD, zx, zy, zz;
    
    static {
    
    }
  }
  
  private class b extends TimerTask {
    private b(w this$0) {}
    
    public void run() {
      if (w.b(this.zv) == w.a.zy && w.e(this.zv).isEmpty() && w.f(this.zv) + w.g(this.zv) < w.h(this.zv).elapsedRealtime()) {
        ae.V("Disconnecting due to inactivity");
        w.i(this.zv);
        return;
      } 
      w.j(this.zv).schedule(new b(), w.g(this.zv));
    }
  }
  
  private class c extends TimerTask {
    private c(w this$0) {}
    
    public void run() {
      if (w.b(this.zv) == w.a.zx)
        w.c(this.zv); 
    }
  }
  
  private static class d {
    private final Map<String, String> zF;
    
    private final long zG;
    
    private final String zH;
    
    private final List<ha> zI;
    
    public d(Map<String, String> param1Map, long param1Long, String param1String, List<ha> param1List) {
      this.zF = param1Map;
      this.zG = param1Long;
      this.zH = param1String;
      this.zI = param1List;
    }
    
    public Map<String, String> eH() {
      return this.zF;
    }
    
    public long eI() {
      return this.zG;
    }
    
    public List<ha> eJ() {
      return this.zI;
    }
    
    public String getPath() {
      return this.zH;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("PATH: ");
      stringBuilder.append(this.zH);
      if (this.zF != null) {
        stringBuilder.append("  PARAMS: ");
        for (Map.Entry<String, String> entry : this.zF.entrySet()) {
          stringBuilder.append((String)entry.getKey());
          stringBuilder.append("=");
          stringBuilder.append((String)entry.getValue());
          stringBuilder.append(",  ");
        } 
      } 
      return stringBuilder.toString();
    }
  }
  
  private class e extends TimerTask {
    private e(w this$0) {}
    
    public void run() {
      w.d(this.zv);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */