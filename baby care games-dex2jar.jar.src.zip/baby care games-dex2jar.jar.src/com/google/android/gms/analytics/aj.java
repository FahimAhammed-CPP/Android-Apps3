package com.google.android.gms.analytics;

abstract class aj {
  abstract void C(boolean paramBoolean);
  
  abstract void dispatchLocalHits();
  
  abstract void ey();
  
  abstract void setLocalDispatchPeriod(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */