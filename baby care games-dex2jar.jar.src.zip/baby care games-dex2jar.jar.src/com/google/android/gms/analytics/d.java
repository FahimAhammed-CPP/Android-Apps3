package com.google.android.gms.analytics;

import com.google.android.gms.internal.ha;
import java.util.Collection;
import java.util.Map;

interface d {
  void a(Map<String, String> paramMap, long paramLong, String paramString, Collection<ha> paramCollection);
  
  r dV();
  
  void dispatch();
  
  void l(long paramLong);
  
  void setDryRun(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */