package com.google.android.gms.analytics;

public class ae {
  private static GoogleAnalytics BL;
  
  private static volatile boolean BM = false;
  
  private static Logger BN;
  
  public static void T(String paramString) {
    Logger logger = getLogger();
    if (logger != null)
      logger.error(paramString); 
  }
  
  public static void U(String paramString) {
    Logger logger = getLogger();
    if (logger != null)
      logger.info(paramString); 
  }
  
  public static void V(String paramString) {
    Logger logger = getLogger();
    if (logger != null)
      logger.verbose(paramString); 
  }
  
  public static void W(String paramString) {
    Logger logger = getLogger();
    if (logger != null)
      logger.warn(paramString); 
  }
  
  public static boolean ff() {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (getLogger() != null) {
      bool1 = bool2;
      if (getLogger().getLogLevel() == 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  static Logger getLogger() {
    // Byte code:
    //   0: ldc com/google/android/gms/analytics/ae
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/analytics/ae.BM : Z
    //   6: ifeq -> 34
    //   9: getstatic com/google/android/gms/analytics/ae.BN : Lcom/google/android/gms/analytics/Logger;
    //   12: ifnonnull -> 25
    //   15: new com/google/android/gms/analytics/p
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: putstatic com/google/android/gms/analytics/ae.BN : Lcom/google/android/gms/analytics/Logger;
    //   25: getstatic com/google/android/gms/analytics/ae.BN : Lcom/google/android/gms/analytics/Logger;
    //   28: astore_0
    //   29: ldc com/google/android/gms/analytics/ae
    //   31: monitorexit
    //   32: aload_0
    //   33: areturn
    //   34: getstatic com/google/android/gms/analytics/ae.BL : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   37: ifnonnull -> 46
    //   40: invokestatic eY : ()Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   43: putstatic com/google/android/gms/analytics/ae.BL : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   46: getstatic com/google/android/gms/analytics/ae.BL : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   49: ifnull -> 70
    //   52: getstatic com/google/android/gms/analytics/ae.BL : Lcom/google/android/gms/analytics/GoogleAnalytics;
    //   55: invokevirtual getLogger : ()Lcom/google/android/gms/analytics/Logger;
    //   58: astore_0
    //   59: ldc com/google/android/gms/analytics/ae
    //   61: monitorexit
    //   62: aload_0
    //   63: areturn
    //   64: astore_0
    //   65: ldc com/google/android/gms/analytics/ae
    //   67: monitorexit
    //   68: aload_0
    //   69: athrow
    //   70: ldc com/google/android/gms/analytics/ae
    //   72: monitorexit
    //   73: aconst_null
    //   74: areturn
    // Exception table:
    //   from	to	target	type
    //   3	25	64	finally
    //   25	32	64	finally
    //   34	46	64	finally
    //   46	62	64	finally
    //   65	68	64	finally
    //   70	73	64	finally
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */