package com.google.android.gms.analytics;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.text.TextUtils;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.apache.http.Header;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.message.BasicHttpEntityEnclosingRequest;

public class h implements r {
  private final Context mContext;
  
  private final String wl;
  
  private final HttpClient yf;
  
  private URL yg;
  
  private int yh;
  
  private int yi;
  
  private int yj;
  
  private String yk;
  
  private String yl;
  
  private i ym;
  
  private l yn;
  
  private Set<Integer> yo = new HashSet<Integer>();
  
  private boolean yp = false;
  
  private long yq;
  
  private long yr;
  
  private o ys;
  
  private volatile boolean yt = false;
  
  h(HttpClient paramHttpClient, Context paramContext, o paramo) {
    this.mContext = paramContext.getApplicationContext();
    this.ys = paramo;
    this.wl = a("GoogleAnalytics", "4.0", Build.VERSION.RELEASE, an.a(Locale.getDefault()), Build.MODEL, Build.ID);
    this.yf = paramHttpClient;
  }
  
  private String a(ab paramab, List<String> paramList, i parami) {
    String str2;
    if (parami == i.yw) {
      if (paramab.fa() == null || paramab.fa().length() == 0) {
        str2 = "";
      } else {
        str2 = paramab.fa();
      } 
      long l1 = System.currentTimeMillis();
      return TextUtils.isEmpty(str2) ? "" : ac.a(paramab, l1);
    } 
    String str1 = "";
    for (String str : str2) {
      if (str.length() != 0) {
        str2 = str1;
        if (str1.length() != 0)
          str2 = str1 + "\n"; 
        str1 = str2 + str;
      } 
    } 
    return str1;
  }
  
  private URL a(ab paramab) {
    if (this.yg != null)
      return this.yg; 
    String str = paramab.fd();
    try {
      if ("http:".equals(str)) {
        str = "http://www.google-analytics.com/collect";
        return new URL(str);
      } 
    } catch (MalformedURLException malformedURLException) {
      ae.T("Error trying to parse the hardcoded host url. This really shouldn't happen.");
      return null;
    } 
    str = "https://ssl.google-analytics.com/collect";
    return new URL(str);
  }
  
  private void a(af paramaf, HttpHost paramHttpHost, i parami, l paraml) {
    HttpHost httpHost;
    paramaf.g("_bs", parami.toString());
    paramaf.g("_cs", paraml.toString());
    String str = paramaf.fg();
    if (TextUtils.isEmpty(str))
      return; 
    if (paramHttpHost == null)
      try {
        URL uRL = new URL("https://ssl.google-analytics.com");
        httpHost = new HttpHost(uRL.getHost(), uRL.getPort(), uRL.getProtocol());
        a(str, httpHost, 1, paramaf, l.yI);
        return;
      } catch (MalformedURLException malformedURLException) {
        return;
      }  
    a(str, httpHost, 1, (af)malformedURLException, l.yI);
  }
  
  private void a(HttpEntityEnclosingRequest paramHttpEntityEnclosingRequest) {
    StringBuffer stringBuffer = new StringBuffer();
    Header[] arrayOfHeader = paramHttpEntityEnclosingRequest.getAllHeaders();
    int k = arrayOfHeader.length;
    int j;
    for (j = 0; j < k; j++)
      stringBuffer.append(arrayOfHeader[j].toString()).append("\n"); 
    stringBuffer.append(paramHttpEntityEnclosingRequest.getRequestLine().toString()).append("\n");
    if (paramHttpEntityEnclosingRequest.getEntity() != null)
      try {
        InputStream inputStream = paramHttpEntityEnclosingRequest.getEntity().getContent();
        if (inputStream != null) {
          j = inputStream.available();
          if (j > 0) {
            byte[] arrayOfByte = new byte[j];
            inputStream.read(arrayOfByte);
            stringBuffer.append("POST:\n");
            stringBuffer.append(new String(arrayOfByte)).append("\n");
          } 
        } 
      } catch (IOException iOException) {
        ae.W("Error Writing hit to log...");
      }  
    ae.U(stringBuffer.toString());
  }
  
  private boolean a(String paramString, HttpHost paramHttpHost, int paramInt, af paramaf, l paraml) {
    // Byte code:
    //   0: iload_3
    //   1: iconst_1
    //   2: if_icmple -> 73
    //   5: iconst_1
    //   6: istore #7
    //   8: aload_1
    //   9: invokevirtual getBytes : ()[B
    //   12: arraylength
    //   13: aload_0
    //   14: getfield yj : I
    //   17: if_icmpgt -> 32
    //   20: aload_1
    //   21: invokevirtual getBytes : ()[B
    //   24: arraylength
    //   25: aload_0
    //   26: getfield yi : I
    //   29: if_icmple -> 79
    //   32: new java/lang/StringBuilder
    //   35: dup
    //   36: invokespecial <init> : ()V
    //   39: ldc_w 'Request too long (> '
    //   42: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: aload_0
    //   46: getfield yi : I
    //   49: aload_0
    //   50: getfield yj : I
    //   53: invokestatic min : (II)I
    //   56: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   59: ldc_w ' bytes)--not sent'
    //   62: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: invokevirtual toString : ()Ljava/lang/String;
    //   68: invokestatic W : (Ljava/lang/String;)V
    //   71: iconst_1
    //   72: ireturn
    //   73: iconst_0
    //   74: istore #7
    //   76: goto -> 8
    //   79: aload_0
    //   80: getfield yt : Z
    //   83: ifeq -> 94
    //   86: ldc_w 'Dry run enabled. Hit not actually sent.'
    //   89: invokestatic U : (Ljava/lang/String;)V
    //   92: iconst_1
    //   93: ireturn
    //   94: aload_0
    //   95: aload_1
    //   96: iload #7
    //   98: invokespecial d : (Ljava/lang/String;Z)Lorg/apache/http/HttpEntityEnclosingRequest;
    //   101: astore #8
    //   103: aload #8
    //   105: ifnull -> 71
    //   108: aload #8
    //   110: invokeinterface getRequestLine : ()Lorg/apache/http/RequestLine;
    //   115: invokeinterface getMethod : ()Ljava/lang/String;
    //   120: ldc_w 'GET'
    //   123: invokevirtual equals : (Ljava/lang/Object;)Z
    //   126: ifeq -> 277
    //   129: aload_1
    //   130: invokevirtual getBytes : ()[B
    //   133: arraylength
    //   134: istore #6
    //   136: aload_1
    //   137: invokevirtual getBytes : ()[B
    //   140: arraylength
    //   141: istore_3
    //   142: aload #8
    //   144: ldc_w 'Host'
    //   147: aload_2
    //   148: invokevirtual toHostString : ()Ljava/lang/String;
    //   151: invokeinterface addHeader : (Ljava/lang/String;Ljava/lang/String;)V
    //   156: invokestatic ff : ()Z
    //   159: ifeq -> 168
    //   162: aload_0
    //   163: aload #8
    //   165: invokespecial a : (Lorg/apache/http/HttpEntityEnclosingRequest;)V
    //   168: aload_0
    //   169: getfield yf : Lorg/apache/http/client/HttpClient;
    //   172: aload_2
    //   173: aload #8
    //   175: invokeinterface execute : (Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;)Lorg/apache/http/HttpResponse;
    //   180: astore_1
    //   181: aload #4
    //   183: ldc_w '_td'
    //   186: iload #6
    //   188: invokevirtual e : (Ljava/lang/String;I)V
    //   191: aload #4
    //   193: ldc_w '_cd'
    //   196: iload_3
    //   197: invokevirtual e : (Ljava/lang/String;I)V
    //   200: aload_1
    //   201: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   206: invokeinterface getStatusCode : ()I
    //   211: istore_3
    //   212: aload_1
    //   213: invokeinterface getEntity : ()Lorg/apache/http/HttpEntity;
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 229
    //   223: aload_2
    //   224: invokeinterface consumeContent : ()V
    //   229: iload_3
    //   230: sipush #200
    //   233: if_icmpeq -> 71
    //   236: iload #7
    //   238: ifeq -> 458
    //   241: aload_0
    //   242: getfield yo : Ljava/util/Set;
    //   245: iload_3
    //   246: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   249: invokeinterface contains : (Ljava/lang/Object;)Z
    //   254: ifeq -> 458
    //   257: ldc_w 'Falling back to single hit per request mode.'
    //   260: invokestatic U : (Ljava/lang/String;)V
    //   263: aload_0
    //   264: iconst_1
    //   265: putfield yp : Z
    //   268: aload_0
    //   269: invokestatic currentTimeMillis : ()J
    //   272: putfield yq : J
    //   275: iconst_0
    //   276: ireturn
    //   277: getstatic com/google/android/gms/analytics/h$1.yu : [I
    //   280: aload #5
    //   282: invokevirtual ordinal : ()I
    //   285: iaload
    //   286: tableswitch default -> 541, 1 -> 335
    //   304: aload_1
    //   305: invokevirtual getBytes : ()[B
    //   308: arraylength
    //   309: istore_3
    //   310: aload #8
    //   312: new org/apache/http/entity/StringEntity
    //   315: dup
    //   316: aload_1
    //   317: invokespecial <init> : (Ljava/lang/String;)V
    //   320: invokeinterface setEntity : (Lorg/apache/http/HttpEntity;)V
    //   325: aload_1
    //   326: invokevirtual getBytes : ()[B
    //   329: arraylength
    //   330: istore #6
    //   332: goto -> 142
    //   335: new java/io/ByteArrayOutputStream
    //   338: dup
    //   339: invokespecial <init> : ()V
    //   342: astore #5
    //   344: new java/util/zip/GZIPOutputStream
    //   347: dup
    //   348: aload #5
    //   350: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   353: astore #9
    //   355: aload #9
    //   357: aload_1
    //   358: invokevirtual getBytes : ()[B
    //   361: invokevirtual write : ([B)V
    //   364: aload #9
    //   366: invokevirtual close : ()V
    //   369: aload #5
    //   371: invokevirtual toByteArray : ()[B
    //   374: astore #5
    //   376: aload #5
    //   378: arraylength
    //   379: iconst_0
    //   380: iadd
    //   381: istore_3
    //   382: aload #8
    //   384: new org/apache/http/entity/ByteArrayEntity
    //   387: dup
    //   388: aload #5
    //   390: invokespecial <init> : ([B)V
    //   393: invokeinterface setEntity : (Lorg/apache/http/HttpEntity;)V
    //   398: aload #8
    //   400: ldc_w 'Content-Encoding'
    //   403: ldc_w 'gzip'
    //   406: invokeinterface addHeader : (Ljava/lang/String;Ljava/lang/String;)V
    //   411: goto -> 325
    //   414: astore_1
    //   415: ldc_w 'Encoding error, hit will be discarded'
    //   418: invokestatic T : (Ljava/lang/String;)V
    //   421: iconst_1
    //   422: ireturn
    //   423: astore_1
    //   424: new java/lang/StringBuilder
    //   427: dup
    //   428: invokespecial <init> : ()V
    //   431: ldc_w 'Unexpected IOException: '
    //   434: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   437: aload_1
    //   438: invokevirtual getMessage : ()Ljava/lang/String;
    //   441: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: invokevirtual toString : ()Ljava/lang/String;
    //   447: invokestatic T : (Ljava/lang/String;)V
    //   450: ldc_w 'Request will be discarded'
    //   453: invokestatic T : (Ljava/lang/String;)V
    //   456: iconst_1
    //   457: ireturn
    //   458: new java/lang/StringBuilder
    //   461: dup
    //   462: invokespecial <init> : ()V
    //   465: ldc_w 'Bad response: '
    //   468: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   471: aload_1
    //   472: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   477: invokeinterface getStatusCode : ()I
    //   482: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   485: invokevirtual toString : ()Ljava/lang/String;
    //   488: invokestatic W : (Ljava/lang/String;)V
    //   491: iconst_1
    //   492: ireturn
    //   493: astore_1
    //   494: ldc_w 'ClientProtocolException sending hit; discarding hit...'
    //   497: invokestatic W : (Ljava/lang/String;)V
    //   500: iconst_1
    //   501: ireturn
    //   502: astore_1
    //   503: new java/lang/StringBuilder
    //   506: dup
    //   507: invokespecial <init> : ()V
    //   510: ldc_w 'Exception sending hit: '
    //   513: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   516: aload_1
    //   517: invokevirtual getClass : ()Ljava/lang/Class;
    //   520: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   523: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   526: invokevirtual toString : ()Ljava/lang/String;
    //   529: invokestatic W : (Ljava/lang/String;)V
    //   532: aload_1
    //   533: invokevirtual getMessage : ()Ljava/lang/String;
    //   536: invokestatic W : (Ljava/lang/String;)V
    //   539: iconst_0
    //   540: ireturn
    //   541: goto -> 304
    // Exception table:
    //   from	to	target	type
    //   168	219	493	org/apache/http/client/ClientProtocolException
    //   168	219	502	java/io/IOException
    //   223	229	493	org/apache/http/client/ClientProtocolException
    //   223	229	502	java/io/IOException
    //   241	275	493	org/apache/http/client/ClientProtocolException
    //   241	275	502	java/io/IOException
    //   277	304	414	java/io/UnsupportedEncodingException
    //   277	304	423	java/io/IOException
    //   304	325	414	java/io/UnsupportedEncodingException
    //   304	325	423	java/io/IOException
    //   325	332	414	java/io/UnsupportedEncodingException
    //   325	332	423	java/io/IOException
    //   335	411	414	java/io/UnsupportedEncodingException
    //   335	411	423	java/io/IOException
    //   458	491	493	org/apache/http/client/ClientProtocolException
    //   458	491	502	java/io/IOException
  }
  
  private HttpEntityEnclosingRequest d(String paramString, boolean paramBoolean) {
    if (TextUtils.isEmpty(paramString)) {
      System.out.println("Empty hit, discarding.");
      return null;
    } 
    paramString = this.yk + "?" + paramString;
    if (paramString.length() < this.yh && !paramBoolean) {
      BasicHttpEntityEnclosingRequest basicHttpEntityEnclosingRequest1 = new BasicHttpEntityEnclosingRequest("GET", paramString);
      basicHttpEntityEnclosingRequest1.addHeader("User-Agent", this.wl);
      return (HttpEntityEnclosingRequest)basicHttpEntityEnclosingRequest1;
    } 
    if (paramBoolean) {
      BasicHttpEntityEnclosingRequest basicHttpEntityEnclosingRequest1 = new BasicHttpEntityEnclosingRequest("POST", this.yl);
      basicHttpEntityEnclosingRequest1.addHeader("User-Agent", this.wl);
      return (HttpEntityEnclosingRequest)basicHttpEntityEnclosingRequest1;
    } 
    BasicHttpEntityEnclosingRequest basicHttpEntityEnclosingRequest = new BasicHttpEntityEnclosingRequest("POST", this.yk);
    basicHttpEntityEnclosingRequest.addHeader("User-Agent", this.wl);
    return (HttpEntityEnclosingRequest)basicHttpEntityEnclosingRequest;
  }
  
  int a(List<ab> paramList, int paramInt) {
    if (paramList.isEmpty())
      return 0; 
    int j = paramInt;
    if (paramInt > paramList.size())
      j = paramList.size(); 
    int k = j - 1;
    long l1 = 0L;
    paramInt = j;
    j = k;
    while (true) {
      k = paramInt;
      if (j > 0) {
        ab ab1 = paramList.get(j - 1);
        ab ab2 = paramList.get(j);
        long l2 = ab1.fc();
        long l3 = ab2.fc();
        if (l2 != 0L && l3 != 0L && l3 - l2 > l1) {
          l1 = l3 - l2;
          paramInt = j;
        } 
        j--;
        continue;
      } 
      return k;
    } 
  }
  
  public int a(List<ab> paramList, af paramaf, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield ys : Lcom/google/android/gms/analytics/o;
    //   5: invokeinterface eb : ()I
    //   10: putfield yh : I
    //   13: aload_0
    //   14: aload_0
    //   15: getfield ys : Lcom/google/android/gms/analytics/o;
    //   18: invokeinterface ec : ()I
    //   23: putfield yi : I
    //   26: aload_0
    //   27: aload_0
    //   28: getfield ys : Lcom/google/android/gms/analytics/o;
    //   31: invokeinterface ed : ()I
    //   36: putfield yj : I
    //   39: aload_0
    //   40: getfield ys : Lcom/google/android/gms/analytics/o;
    //   43: invokeinterface ee : ()I
    //   48: istore #4
    //   50: aload_0
    //   51: aload_0
    //   52: getfield ys : Lcom/google/android/gms/analytics/o;
    //   55: invokeinterface eg : ()Ljava/lang/String;
    //   60: putfield yk : Ljava/lang/String;
    //   63: aload_0
    //   64: aload_0
    //   65: getfield ys : Lcom/google/android/gms/analytics/o;
    //   68: invokeinterface eh : ()Ljava/lang/String;
    //   73: putfield yl : Ljava/lang/String;
    //   76: aload_0
    //   77: aload_0
    //   78: getfield ys : Lcom/google/android/gms/analytics/o;
    //   81: invokeinterface ei : ()Lcom/google/android/gms/analytics/i;
    //   86: putfield ym : Lcom/google/android/gms/analytics/i;
    //   89: aload_0
    //   90: aload_0
    //   91: getfield ys : Lcom/google/android/gms/analytics/o;
    //   94: invokeinterface ej : ()Lcom/google/android/gms/analytics/l;
    //   99: putfield yn : Lcom/google/android/gms/analytics/l;
    //   102: aload_0
    //   103: getfield yo : Ljava/util/Set;
    //   106: invokeinterface clear : ()V
    //   111: aload_0
    //   112: getfield yo : Ljava/util/Set;
    //   115: aload_0
    //   116: getfield ys : Lcom/google/android/gms/analytics/o;
    //   119: invokeinterface ek : ()Ljava/util/Set;
    //   124: invokeinterface addAll : (Ljava/util/Collection;)Z
    //   129: pop
    //   130: aload_0
    //   131: aload_0
    //   132: getfield ys : Lcom/google/android/gms/analytics/o;
    //   135: invokeinterface ef : ()J
    //   140: putfield yr : J
    //   143: aload_0
    //   144: getfield yp : Z
    //   147: ifne -> 174
    //   150: aload_0
    //   151: getfield yo : Ljava/util/Set;
    //   154: invokeinterface isEmpty : ()Z
    //   159: ifeq -> 174
    //   162: aload_0
    //   163: iconst_1
    //   164: putfield yp : Z
    //   167: aload_0
    //   168: invokestatic currentTimeMillis : ()J
    //   171: putfield yq : J
    //   174: aload_0
    //   175: getfield yp : Z
    //   178: ifeq -> 206
    //   181: invokestatic currentTimeMillis : ()J
    //   184: aload_0
    //   185: getfield yq : J
    //   188: lsub
    //   189: ldc2_w 1000
    //   192: aload_0
    //   193: getfield yr : J
    //   196: lmul
    //   197: lcmp
    //   198: ifle -> 206
    //   201: aload_0
    //   202: iconst_0
    //   203: putfield yp : Z
    //   206: aload_0
    //   207: getfield yp : Z
    //   210: ifeq -> 493
    //   213: getstatic com/google/android/gms/analytics/i.yw : Lcom/google/android/gms/analytics/i;
    //   216: astore #17
    //   218: getstatic com/google/android/gms/analytics/l.yI : Lcom/google/android/gms/analytics/l;
    //   221: astore #16
    //   223: iconst_0
    //   224: istore #8
    //   226: aload_1
    //   227: invokeinterface size : ()I
    //   232: iload #4
    //   234: invokestatic min : (II)I
    //   237: istore #6
    //   239: aload_2
    //   240: ldc_w '_hr'
    //   243: aload_1
    //   244: invokeinterface size : ()I
    //   249: invokevirtual e : (Ljava/lang/String;I)V
    //   252: invokestatic currentTimeMillis : ()J
    //   255: lstore #13
    //   257: new java/util/ArrayList
    //   260: dup
    //   261: invokespecial <init> : ()V
    //   264: astore #19
    //   266: new java/util/ArrayList
    //   269: dup
    //   270: invokespecial <init> : ()V
    //   273: astore #20
    //   275: lconst_0
    //   276: lstore #9
    //   278: aload #17
    //   280: getstatic com/google/android/gms/analytics/i.yw : Lcom/google/android/gms/analytics/i;
    //   283: if_acmpeq -> 1085
    //   286: aload_1
    //   287: invokeinterface iterator : ()Ljava/util/Iterator;
    //   292: astore #21
    //   294: iconst_0
    //   295: istore #5
    //   297: aload #21
    //   299: invokeinterface hasNext : ()Z
    //   304: ifeq -> 1079
    //   307: aload #21
    //   309: invokeinterface next : ()Ljava/lang/Object;
    //   314: checkcast com/google/android/gms/analytics/ab
    //   317: astore #15
    //   319: aload #15
    //   321: invokevirtual fa : ()Ljava/lang/String;
    //   324: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   327: ifeq -> 508
    //   330: ldc ''
    //   332: astore #15
    //   334: aload #15
    //   336: astore #18
    //   338: aload #15
    //   340: invokevirtual getBytes : ()[B
    //   343: arraylength
    //   344: aload_0
    //   345: getfield yi : I
    //   348: if_icmple -> 355
    //   351: ldc ''
    //   353: astore #18
    //   355: aload #19
    //   357: aload #18
    //   359: invokeinterface add : (Ljava/lang/Object;)Z
    //   364: pop
    //   365: lload #9
    //   367: lstore #11
    //   369: aload #18
    //   371: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   374: ifne -> 404
    //   377: aload #18
    //   379: invokevirtual getBytes : ()[B
    //   382: arraylength
    //   383: istore #7
    //   385: iload #5
    //   387: ifne -> 520
    //   390: iconst_0
    //   391: istore #4
    //   393: lload #9
    //   395: iload #4
    //   397: iload #7
    //   399: iadd
    //   400: i2l
    //   401: ladd
    //   402: lstore #11
    //   404: aload #20
    //   406: lload #11
    //   408: invokestatic valueOf : (J)Ljava/lang/Long;
    //   411: invokeinterface add : (Ljava/lang/Object;)Z
    //   416: pop
    //   417: lload #11
    //   419: aload_0
    //   420: getfield yj : I
    //   423: i2l
    //   424: lcmp
    //   425: ifgt -> 1072
    //   428: iload #5
    //   430: iconst_1
    //   431: iadd
    //   432: istore #4
    //   434: iload #4
    //   436: iload #6
    //   438: if_icmpne -> 526
    //   441: iconst_1
    //   442: istore #6
    //   444: lload #11
    //   446: lstore #9
    //   448: iload #4
    //   450: istore #5
    //   452: iload #5
    //   454: iconst_1
    //   455: if_icmple -> 537
    //   458: aload #20
    //   460: iload #5
    //   462: iconst_1
    //   463: isub
    //   464: invokeinterface get : (I)Ljava/lang/Object;
    //   469: checkcast java/lang/Long
    //   472: invokevirtual longValue : ()J
    //   475: aload_0
    //   476: getfield yj : I
    //   479: i2l
    //   480: lcmp
    //   481: ifle -> 537
    //   484: iload #5
    //   486: iconst_1
    //   487: isub
    //   488: istore #5
    //   490: goto -> 452
    //   493: aload_0
    //   494: getfield ym : Lcom/google/android/gms/analytics/i;
    //   497: astore #17
    //   499: aload_0
    //   500: getfield yn : Lcom/google/android/gms/analytics/l;
    //   503: astore #16
    //   505: goto -> 223
    //   508: aload #15
    //   510: lload #13
    //   512: invokestatic a : (Lcom/google/android/gms/analytics/ab;J)Ljava/lang/String;
    //   515: astore #15
    //   517: goto -> 334
    //   520: iconst_1
    //   521: istore #4
    //   523: goto -> 393
    //   526: iload #4
    //   528: istore #5
    //   530: lload #11
    //   532: lstore #9
    //   534: goto -> 297
    //   537: lload #9
    //   539: aload_0
    //   540: getfield yj : I
    //   543: i2l
    //   544: lcmp
    //   545: ifle -> 1065
    //   548: getstatic com/google/android/gms/analytics/h$1.yv : [I
    //   551: aload #17
    //   553: invokevirtual ordinal : ()I
    //   556: iaload
    //   557: tableswitch default -> 592, 1 -> 743, 2 -> 772, 3 -> 784, 4 -> 796, 5 -> 869
    //   592: ldc_w 'Unexpected batching strategy encountered; sending a single hit.'
    //   595: invokestatic W : (Ljava/lang/String;)V
    //   598: aload #19
    //   600: iconst_0
    //   601: invokeinterface get : (I)Ljava/lang/Object;
    //   606: checkcast java/lang/String
    //   609: astore #15
    //   611: aload #19
    //   613: invokeinterface clear : ()V
    //   618: aload #19
    //   620: aload #15
    //   622: invokeinterface add : (Ljava/lang/Object;)Z
    //   627: pop
    //   628: iconst_1
    //   629: istore #4
    //   631: iload #4
    //   633: aload #19
    //   635: invokeinterface size : ()I
    //   640: if_icmpge -> 1065
    //   643: aload #19
    //   645: iconst_0
    //   646: iload #4
    //   648: invokeinterface subList : (II)Ljava/util/List;
    //   653: astore #15
    //   655: iconst_0
    //   656: istore #4
    //   658: aconst_null
    //   659: astore #18
    //   661: iconst_0
    //   662: istore #7
    //   664: iload #8
    //   666: istore #5
    //   668: iload #7
    //   670: iload #6
    //   672: if_icmpge -> 1026
    //   675: aload_1
    //   676: iload #7
    //   678: invokeinterface get : (I)Ljava/lang/Object;
    //   683: checkcast com/google/android/gms/analytics/ab
    //   686: astore #19
    //   688: aload_0
    //   689: aload #19
    //   691: invokespecial a : (Lcom/google/android/gms/analytics/ab;)Ljava/net/URL;
    //   694: astore #20
    //   696: iconst_1
    //   697: aload #15
    //   699: invokeinterface size : ()I
    //   704: invokestatic max : (II)I
    //   707: istore #8
    //   709: aload #20
    //   711: ifnonnull -> 876
    //   714: ldc_w 'No destination: discarding hit.'
    //   717: invokestatic W : (Ljava/lang/String;)V
    //   720: iload #4
    //   722: iload #8
    //   724: iadd
    //   725: istore #4
    //   727: iload #5
    //   729: iload #8
    //   731: iadd
    //   732: istore #5
    //   734: iload #7
    //   736: iconst_1
    //   737: iadd
    //   738: istore #7
    //   740: goto -> 668
    //   743: aload #19
    //   745: invokeinterface size : ()I
    //   750: iconst_2
    //   751: idiv
    //   752: istore #7
    //   754: iload #7
    //   756: istore #4
    //   758: iload #5
    //   760: iload #7
    //   762: if_icmpgt -> 631
    //   765: iload #5
    //   767: istore #4
    //   769: goto -> 631
    //   772: aload_0
    //   773: aload_1
    //   774: iload #5
    //   776: invokevirtual a : (Ljava/util/List;I)I
    //   779: istore #4
    //   781: goto -> 631
    //   784: aload_0
    //   785: aload_1
    //   786: iload #5
    //   788: invokevirtual b : (Ljava/util/List;I)I
    //   791: istore #4
    //   793: goto -> 631
    //   796: lload #9
    //   798: aload_0
    //   799: getfield yj : I
    //   802: iconst_2
    //   803: imul
    //   804: i2l
    //   805: lcmp
    //   806: ifge -> 862
    //   809: aload #20
    //   811: invokeinterface size : ()I
    //   816: iconst_1
    //   817: isub
    //   818: istore #4
    //   820: iload #4
    //   822: ifle -> 859
    //   825: aload #20
    //   827: iload #4
    //   829: invokeinterface get : (I)Ljava/lang/Object;
    //   834: checkcast java/lang/Long
    //   837: invokevirtual longValue : ()J
    //   840: lload #9
    //   842: ldc2_w 2
    //   845: ldiv
    //   846: lcmp
    //   847: ifle -> 859
    //   850: iload #4
    //   852: iconst_1
    //   853: isub
    //   854: istore #4
    //   856: goto -> 820
    //   859: goto -> 631
    //   862: iload #5
    //   864: istore #4
    //   866: goto -> 631
    //   869: iload #5
    //   871: istore #4
    //   873: goto -> 631
    //   876: new org/apache/http/HttpHost
    //   879: dup
    //   880: aload #20
    //   882: invokevirtual getHost : ()Ljava/lang/String;
    //   885: aload #20
    //   887: invokevirtual getPort : ()I
    //   890: aload #20
    //   892: invokevirtual getProtocol : ()Ljava/lang/String;
    //   895: invokespecial <init> : (Ljava/lang/String;ILjava/lang/String;)V
    //   898: astore #18
    //   900: aload_0
    //   901: aload_0
    //   902: aload #19
    //   904: aload #15
    //   906: aload #17
    //   908: invokespecial a : (Lcom/google/android/gms/analytics/ab;Ljava/util/List;Lcom/google/android/gms/analytics/i;)Ljava/lang/String;
    //   911: aload #18
    //   913: iload #8
    //   915: aload_2
    //   916: aload #16
    //   918: invokespecial a : (Ljava/lang/String;Lorg/apache/http/HttpHost;ILcom/google/android/gms/analytics/af;Lcom/google/android/gms/analytics/l;)Z
    //   921: ifne -> 964
    //   924: aload_2
    //   925: ldc_w '_de'
    //   928: iconst_1
    //   929: invokevirtual e : (Ljava/lang/String;I)V
    //   932: aload_2
    //   933: ldc_w '_hd'
    //   936: iload #4
    //   938: invokevirtual e : (Ljava/lang/String;I)V
    //   941: aload_2
    //   942: ldc_w '_hs'
    //   945: iload #5
    //   947: invokevirtual e : (Ljava/lang/String;I)V
    //   950: aload_0
    //   951: aload_2
    //   952: aload #18
    //   954: aload #17
    //   956: aload #16
    //   958: invokespecial a : (Lcom/google/android/gms/analytics/af;Lorg/apache/http/HttpHost;Lcom/google/android/gms/analytics/i;Lcom/google/android/gms/analytics/l;)V
    //   961: iload #5
    //   963: ireturn
    //   964: aload #15
    //   966: invokeinterface iterator : ()Ljava/util/Iterator;
    //   971: astore #19
    //   973: aload #19
    //   975: invokeinterface hasNext : ()Z
    //   980: ifeq -> 1008
    //   983: aload #19
    //   985: invokeinterface next : ()Ljava/lang/Object;
    //   990: checkcast java/lang/String
    //   993: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   996: ifeq -> 1062
    //   999: iload #4
    //   1001: iconst_1
    //   1002: iadd
    //   1003: istore #4
    //   1005: goto -> 973
    //   1008: aload_2
    //   1009: ldc_w '_rs'
    //   1012: iconst_1
    //   1013: invokevirtual e : (Ljava/lang/String;I)V
    //   1016: iload #5
    //   1018: iload #8
    //   1020: iadd
    //   1021: istore #5
    //   1023: goto -> 734
    //   1026: aload_2
    //   1027: ldc_w '_hd'
    //   1030: iload #4
    //   1032: invokevirtual e : (Ljava/lang/String;I)V
    //   1035: aload_2
    //   1036: ldc_w '_hs'
    //   1039: iload #5
    //   1041: invokevirtual e : (Ljava/lang/String;I)V
    //   1044: iload_3
    //   1045: ifeq -> 1059
    //   1048: aload_0
    //   1049: aload_2
    //   1050: aload #18
    //   1052: aload #17
    //   1054: aload #16
    //   1056: invokespecial a : (Lcom/google/android/gms/analytics/af;Lorg/apache/http/HttpHost;Lcom/google/android/gms/analytics/i;Lcom/google/android/gms/analytics/l;)V
    //   1059: iload #5
    //   1061: ireturn
    //   1062: goto -> 1005
    //   1065: aload #19
    //   1067: astore #15
    //   1069: goto -> 655
    //   1072: iload #5
    //   1074: istore #4
    //   1076: goto -> 434
    //   1079: iconst_1
    //   1080: istore #6
    //   1082: goto -> 452
    //   1085: iconst_0
    //   1086: istore #5
    //   1088: goto -> 452
  }
  
  String a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6) {
    return String.format("%s/%s (Linux; U; Android %s; %s; %s Build/%s)", new Object[] { paramString1, paramString2, paramString3, paramString4, paramString5, paramString6 });
  }
  
  public void ad(String paramString) {
    try {
      this.yg = new URL(paramString);
      return;
    } catch (MalformedURLException malformedURLException) {
      this.yg = null;
      return;
    } 
  }
  
  int b(List<ab> paramList, int paramInt) {
    if (paramList.isEmpty())
      return 0; 
    int j = paramInt - 1;
    while (true) {
      int k = paramInt;
      if (j > 0) {
        String str = ((ab)paramList.get(j)).fa();
        if (!TextUtils.isEmpty(str)) {
          if (str.contains("sc=start"))
            return j; 
          if (str.contains("sc=end"))
            return j + 1; 
        } 
        j--;
        continue;
      } 
      return k;
    } 
  }
  
  public boolean ea() {
    NetworkInfo networkInfo = ((ConnectivityManager)this.mContext.getSystemService("connectivity")).getActiveNetworkInfo();
    if (networkInfo == null || !networkInfo.isConnected()) {
      ae.V("...no network connectivity");
      return false;
    } 
    return true;
  }
  
  public void setDryRun(boolean paramBoolean) {
    this.yt = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */