package com.google.android.gms.analytics;

class ad implements ah {
  private final long BF;
  
  private final int BG;
  
  private double BH;
  
  private long BI;
  
  private final Object BJ = new Object();
  
  private final String BK;
  
  public ad(int paramInt, long paramLong, String paramString) {
    this.BG = paramInt;
    this.BH = this.BG;
    this.BF = paramLong;
    this.BK = paramString;
  }
  
  public ad(String paramString) {
    this(60, 2000L, paramString);
  }
  
  public boolean fe() {
    synchronized (this.BJ) {
      long l = System.currentTimeMillis();
      if (this.BH < this.BG) {
        double d = (l - this.BI) / this.BF;
        if (d > 0.0D)
          this.BH = Math.min(this.BG, d + this.BH); 
      } 
      this.BI = l;
      if (this.BH >= 1.0D) {
        this.BH--;
        return true;
      } 
      ae.W("Excessive " + this.BK + " detected; call ignored.");
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */