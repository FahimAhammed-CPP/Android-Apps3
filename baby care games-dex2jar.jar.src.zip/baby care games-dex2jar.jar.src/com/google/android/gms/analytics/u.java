package com.google.android.gms.analytics;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

class u extends BroadcastReceiver {
  static final String yR = u.class.getName();
  
  private final aj yS;
  
  u(aj paramaj) {
    this.yS = paramaj;
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    aj aj1;
    boolean bool = false;
    String str = paramIntent.getAction();
    if ("android.net.conn.CONNECTIVITY_CHANGE".equals(str)) {
      boolean bool1 = paramIntent.getBooleanExtra("noConnectivity", false);
      aj1 = this.yS;
      if (!bool1)
        bool = true; 
      aj1.C(bool);
      return;
    } 
    if ("com.google.analytics.RADIO_POWERED".equals(aj1) && !paramIntent.hasExtra(yR)) {
      this.yS.ey();
      return;
    } 
  }
  
  public void z(Context paramContext) {
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
    paramContext.registerReceiver(this, intentFilter);
    intentFilter = new IntentFilter();
    intentFilter.addAction("com.google.analytics.RADIO_POWERED");
    intentFilter.addCategory(paramContext.getPackageName());
    paramContext.registerReceiver(this, intentFilter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytic\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */