package com.google.android.gms.analytics;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Locale;

class a implements q {
  private static Object xO = new Object();
  
  private static a xP;
  
  private Context mContext;
  
  private AdvertisingIdClient.Info xQ;
  
  private long xR;
  
  private String xS;
  
  private boolean xT = false;
  
  private Object xU = new Object();
  
  a(Context paramContext) {
    this.mContext = paramContext.getApplicationContext();
  }
  
  private boolean a(AdvertisingIdClient.Info paramInfo1, AdvertisingIdClient.Info paramInfo2) {
    String str2;
    AdvertisingIdClient.Info info = null;
    if (paramInfo2 == null) {
      paramInfo2 = null;
    } else {
      str2 = paramInfo2.getId();
    } 
    if (TextUtils.isEmpty(str2))
      return true; 
    k.y(this.mContext);
    k k = k.el();
    String str3 = k.getValue("&cid");
    synchronized (this.xU) {
      if (!this.xT) {
        this.xS = x(this.mContext);
        this.xT = true;
      } else if (TextUtils.isEmpty(this.xS)) {
        String str4;
        if (paramInfo1 == null) {
          paramInfo1 = info;
        } else {
          str4 = paramInfo1.getId();
        } 
        if (str4 == null)
          return ab(str2 + str3); 
        this.xS = aa(str4 + str3);
      } 
      String str = aa(str2 + str3);
      if (TextUtils.isEmpty(str))
        return false; 
    } 
    if (paramInfo1.equals(this.xS)) {
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_6} */
      return true;
    } 
    if (!TextUtils.isEmpty(this.xS)) {
      ae.V("Resetting the client id because Advertising Id changed.");
      String str = k.em();
      ae.V("New client Id: " + str);
      boolean bool1 = ab(str2 + str);
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_6} */
      return bool1;
    } 
    String str1 = str3;
    boolean bool = ab(str2 + str1);
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_6} */
    return bool;
  }
  
  static String aa(String paramString) {
    MessageDigest messageDigest = an.ap("MD5");
    return (messageDigest == null) ? null : String.format(Locale.US, "%032X", new Object[] { new BigInteger(1, messageDigest.digest(paramString.getBytes())) });
  }
  
  private boolean ab(String paramString) {
    try {
      paramString = aa(paramString);
      ae.V("Storing hashed adid.");
      FileOutputStream fileOutputStream = this.mContext.openFileOutput("gaClientIdData", 0);
      fileOutputStream.write(paramString.getBytes());
      fileOutputStream.close();
      this.xS = paramString;
      return true;
    } catch (FileNotFoundException fileNotFoundException) {
      ae.T("Error creating hash file.");
      return false;
    } catch (IOException iOException) {
      ae.T("Error writing to hash file.");
      return false;
    } 
  }
  
  public static q w(Context paramContext) {
    if (xP == null)
      synchronized (xO) {
        if (xP == null)
          xP = new a(paramContext); 
        return xP;
      }  
    return xP;
  }
  
  static String x(Context paramContext) {
    String str = null;
    try {
      FileInputStream fileInputStream = paramContext.openFileInput("gaClientIdData");
      byte[] arrayOfByte = new byte[128];
      int i = fileInputStream.read(arrayOfByte, 0, 128);
      if (fileInputStream.available() > 0) {
        ae.W("Hash file seems corrupted, deleting it.");
        fileInputStream.close();
        paramContext.deleteFile("gaClientIdData");
        return null;
      } 
      if (i <= 0) {
        ae.U("Hash file is empty.");
        fileInputStream.close();
        return null;
      } 
      String str1 = new String(arrayOfByte, 0, i);
      try {
        fileInputStream.close();
        return str1;
      } catch (FileNotFoundException null) {
        return str1;
      } catch (IOException iOException) {
        str = str1;
        ae.W("Error reading Hash file, deleting it.");
        fileNotFoundException.deleteFile("gaClientIdData");
        return str;
      } 
    } catch (FileNotFoundException fileNotFoundException) {
      return null;
    } catch (IOException iOException) {
      ae.W("Error reading Hash file, deleting it.");
      fileNotFoundException.deleteFile("gaClientIdData");
      return str;
    } 
  }
  
  AdvertisingIdClient.Info dP() {
    try {
      return AdvertisingIdClient.getAdvertisingIdInfo(this.mContext);
    } catch (IllegalStateException illegalStateException) {
      ae.W("IllegalStateException getting Ad Id Info. If you would like to see Audience reports, please ensure that you have added '<meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />' to your application manifest file. See http://goo.gl/naFqQk for details.");
      return null;
    } catch (GooglePlayServicesRepairableException googlePlayServicesRepairableException) {
      ae.W("GooglePlayServicesRepairableException getting Ad Id Info");
      return null;
    } catch (IOException iOException) {
      ae.W("IOException getting Ad Id Info");
      return null;
    } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
      ae.W("GooglePlayServicesNotAvailableException getting Ad Id Info");
      return null;
    } catch (Throwable throwable) {
      ae.W("Unknown exception. Could not get the ad Id.");
      return null;
    } 
  }
  
  public String getValue(String paramString) {
    long l = System.currentTimeMillis();
    if (l - this.xR > 1000L) {
      AdvertisingIdClient.Info info = dP();
      if (a(this.xQ, info)) {
        this.xQ = info;
      } else {
        this.xQ = new AdvertisingIdClient.Info("", false);
      } 
      this.xR = l;
    } 
    if (this.xQ != null) {
      if ("&adid".equals(paramString))
        return this.xQ.getId(); 
      if ("&ate".equals(paramString))
        return this.xQ.isLimitAdTrackingEnabled() ? "0" : "1"; 
    } 
    return null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */