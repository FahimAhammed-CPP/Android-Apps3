package com.google.android.gms.analytics;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class StandardExceptionParser implements ExceptionParser {
  private final TreeSet<String> Cd = new TreeSet<String>();
  
  public StandardExceptionParser(Context paramContext, Collection<String> paramCollection) {
    setIncludedPackages(paramContext, paramCollection);
  }
  
  protected StackTraceElement getBestStackTraceElement(Throwable paramThrowable) {
    StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
    if (arrayOfStackTraceElement == null || arrayOfStackTraceElement.length == 0)
      return null; 
    int j = arrayOfStackTraceElement.length;
    for (int i = 0; i < j; i++) {
      StackTraceElement stackTraceElement = arrayOfStackTraceElement[i];
      String str = stackTraceElement.getClassName();
      Iterator<String> iterator = this.Cd.iterator();
      while (iterator.hasNext()) {
        if (str.startsWith(iterator.next()))
          return stackTraceElement; 
      } 
    } 
    return arrayOfStackTraceElement[0];
  }
  
  protected Throwable getCause(Throwable paramThrowable) {
    while (paramThrowable.getCause() != null)
      paramThrowable = paramThrowable.getCause(); 
    return paramThrowable;
  }
  
  public String getDescription(String paramString, Throwable paramThrowable) {
    return getDescription(getCause(paramThrowable), getBestStackTraceElement(getCause(paramThrowable)), paramString);
  }
  
  protected String getDescription(Throwable paramThrowable, StackTraceElement paramStackTraceElement, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramThrowable.getClass().getSimpleName());
    if (paramStackTraceElement != null) {
      String[] arrayOfString = paramStackTraceElement.getClassName().split("\\.");
      String str2 = "unknown";
      String str1 = str2;
      if (arrayOfString != null) {
        str1 = str2;
        if (arrayOfString.length > 0)
          str1 = arrayOfString[arrayOfString.length - 1]; 
      } 
      stringBuilder.append(String.format(" (@%s:%s:%s)", new Object[] { str1, paramStackTraceElement.getMethodName(), Integer.valueOf(paramStackTraceElement.getLineNumber()) }));
    } 
    if (paramString != null)
      stringBuilder.append(String.format(" {%s}", new Object[] { paramString })); 
    return stringBuilder.toString();
  }
  
  public void setIncludedPackages(Context paramContext, Collection<String> paramCollection) {
    this.Cd.clear();
    HashSet<String> hashSet = new HashSet();
    if (paramCollection != null)
      hashSet.addAll(paramCollection); 
    if (paramContext != null)
      try {
        String str = paramContext.getApplicationContext().getPackageName();
        this.Cd.add(str);
        ActivityInfo[] arrayOfActivityInfo = (paramContext.getApplicationContext().getPackageManager().getPackageInfo(str, 15)).activities;
        if (arrayOfActivityInfo != null) {
          int j = arrayOfActivityInfo.length;
          for (int i = 0; i < j; i++)
            hashSet.add((arrayOfActivityInfo[i]).packageName); 
        } 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        ae.U("No package found");
      }  
    label31: for (String str : hashSet) {
      Iterator<String> iterator = this.Cd.iterator();
      boolean bool = true;
      while (true) {
        if (iterator.hasNext()) {
          String str1 = iterator.next();
          if (!str.startsWith(str1)) {
            if (str1.startsWith(str))
              this.Cd.remove(str1); 
          } else {
            bool = false;
            continue;
          } 
        } 
        if (bool) {
          this.Cd.add(str);
          continue label31;
        } 
        continue label31;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\StandardExceptionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */