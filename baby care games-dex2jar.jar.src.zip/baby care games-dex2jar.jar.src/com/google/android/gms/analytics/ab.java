package com.google.android.gms.analytics;

import android.text.TextUtils;

public class ab {
  private String Bu;
  
  private final long Bv;
  
  private final long Bw;
  
  private final String Bx;
  
  private String By;
  
  private String Bz = "https:";
  
  public ab(String paramString1, long paramLong1, long paramLong2, String paramString2) {
    this.Bu = paramString1;
    this.Bv = paramLong1;
    this.Bw = paramLong2;
    this.Bx = paramString2;
  }
  
  public void aj(String paramString) {
    this.Bu = paramString;
  }
  
  public void ak(String paramString) {
    if (paramString != null && !TextUtils.isEmpty(paramString.trim())) {
      this.By = paramString;
      if (paramString.toLowerCase().startsWith("http:")) {
        this.Bz = "http:";
        return;
      } 
    } 
  }
  
  public String fa() {
    return this.Bu;
  }
  
  public long fb() {
    return this.Bv;
  }
  
  public long fc() {
    return this.Bw;
  }
  
  public String fd() {
    return this.Bz;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */