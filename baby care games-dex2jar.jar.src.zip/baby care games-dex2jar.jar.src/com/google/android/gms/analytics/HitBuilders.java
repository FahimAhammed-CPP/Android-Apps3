package com.google.android.gms.analytics;

import android.text.TextUtils;
import com.google.android.gms.analytics.ecommerce.Product;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.analytics.ecommerce.Promotion;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class HitBuilders {
  @Deprecated
  public static class AppViewBuilder extends HitBuilder<AppViewBuilder> {
    public AppViewBuilder() {
      y.eK().a(y.a.Bg);
      set("&t", "screenview");
    }
  }
  
  public static class EventBuilder extends HitBuilder<EventBuilder> {
    public EventBuilder() {
      y.eK().a(y.a.AU);
      set("&t", "event");
    }
    
    public EventBuilder(String param1String1, String param1String2) {
      this();
      setCategory(param1String1);
      setAction(param1String2);
    }
    
    public EventBuilder setAction(String param1String) {
      set("&ea", param1String);
      return this;
    }
    
    public EventBuilder setCategory(String param1String) {
      set("&ec", param1String);
      return this;
    }
    
    public EventBuilder setLabel(String param1String) {
      set("&el", param1String);
      return this;
    }
    
    public EventBuilder setValue(long param1Long) {
      set("&ev", Long.toString(param1Long));
      return this;
    }
  }
  
  public static class ExceptionBuilder extends HitBuilder<ExceptionBuilder> {
    public ExceptionBuilder() {
      y.eK().a(y.a.AD);
      set("&t", "exception");
    }
    
    public ExceptionBuilder setDescription(String param1String) {
      set("&exd", param1String);
      return this;
    }
    
    public ExceptionBuilder setFatal(boolean param1Boolean) {
      set("&exf", an.E(param1Boolean));
      return this;
    }
  }
  
  protected static class HitBuilder<T extends HitBuilder> {
    private Map<String, String> BA = new HashMap<String, String>();
    
    ProductAction BB;
    
    Map<String, List<Product>> BC = new HashMap<String, List<Product>>();
    
    List<Promotion> BD = new ArrayList<Promotion>();
    
    List<Product> BE = new ArrayList<Product>();
    
    public T addImpression(Product param1Product, String param1String) {
      if (param1Product == null) {
        ae.W("product should be non-null");
        return (T)this;
      } 
      String str = param1String;
      if (param1String == null)
        str = ""; 
      if (!this.BC.containsKey(str))
        this.BC.put(str, new ArrayList<Product>()); 
      ((List<Product>)this.BC.get(str)).add(param1Product);
      return (T)this;
    }
    
    public T addProduct(Product param1Product) {
      if (param1Product == null) {
        ae.W("product should be non-null");
        return (T)this;
      } 
      this.BE.add(param1Product);
      return (T)this;
    }
    
    public T addPromotion(Promotion param1Promotion) {
      if (param1Promotion == null) {
        ae.W("promotion should be non-null");
        return (T)this;
      } 
      this.BD.add(param1Promotion);
      return (T)this;
    }
    
    public Map<String, String> build() {
      HashMap<String, String> hashMap = new HashMap<String, String>(this.BA);
      if (this.BB != null)
        hashMap.putAll(this.BB.build()); 
      Iterator<Promotion> iterator = this.BD.iterator();
      int i;
      for (i = 1; iterator.hasNext(); i++)
        hashMap.putAll(((Promotion)iterator.next()).aq(s.B(i))); 
      iterator = (Iterator)this.BE.iterator();
      for (i = 1; iterator.hasNext(); i++)
        hashMap.putAll(((Product)iterator.next()).aq(s.A(i))); 
      iterator = this.BC.entrySet().iterator();
      for (i = 1; iterator.hasNext(); i++) {
        Map.Entry entry = (Map.Entry)iterator.next();
        List list = (List)entry.getValue();
        String str = s.D(i);
        Iterator<Product> iterator1 = list.iterator();
        for (int j = 1; iterator1.hasNext(); j++)
          hashMap.putAll(((Product)iterator1.next()).aq(str + s.C(j))); 
        if (!TextUtils.isEmpty((CharSequence)entry.getKey()))
          hashMap.put(str + "nm", (String)entry.getKey()); 
      } 
      return hashMap;
    }
    
    protected String get(String param1String) {
      return this.BA.get(param1String);
    }
    
    public final T set(String param1String1, String param1String2) {
      y.eK().a(y.a.zW);
      if (param1String1 != null) {
        this.BA.put(param1String1, param1String2);
        return (T)this;
      } 
      ae.W(" HitBuilder.set() called with a null paramName.");
      return (T)this;
    }
    
    public final T setAll(Map<String, String> param1Map) {
      y.eK().a(y.a.zX);
      if (param1Map == null)
        return (T)this; 
      this.BA.putAll(new HashMap<String, String>(param1Map));
      return (T)this;
    }
    
    public T setCampaignParamsFromUrl(String param1String) {
      y.eK().a(y.a.zZ);
      param1String = an.ao(param1String);
      if (TextUtils.isEmpty(param1String))
        return (T)this; 
      Map<String, String> map = an.an(param1String);
      set("&cc", map.get("utm_content"));
      set("&cm", map.get("utm_medium"));
      set("&cn", map.get("utm_campaign"));
      set("&cs", map.get("utm_source"));
      set("&ck", map.get("utm_term"));
      set("&ci", map.get("utm_id"));
      set("&gclid", map.get("gclid"));
      set("&dclid", map.get("dclid"));
      set("&gmob_t", map.get("gmob_t"));
      return (T)this;
    }
    
    public T setCustomDimension(int param1Int, String param1String) {
      set(s.y(param1Int), param1String);
      return (T)this;
    }
    
    public T setCustomMetric(int param1Int, float param1Float) {
      set(s.z(param1Int), Float.toString(param1Float));
      return (T)this;
    }
    
    protected T setHitType(String param1String) {
      set("&t", param1String);
      return (T)this;
    }
    
    public T setNewSession() {
      set("&sc", "start");
      return (T)this;
    }
    
    public T setNonInteraction(boolean param1Boolean) {
      set("&ni", an.E(param1Boolean));
      return (T)this;
    }
    
    public T setProductAction(ProductAction param1ProductAction) {
      this.BB = param1ProductAction;
      return (T)this;
    }
    
    public T setPromotionAction(String param1String) {
      this.BA.put("&promoa", param1String);
      return (T)this;
    }
  }
  
  @Deprecated
  public static class ItemBuilder extends HitBuilder<ItemBuilder> {
    public ItemBuilder() {
      y.eK().a(y.a.AV);
      set("&t", "item");
    }
    
    public ItemBuilder setCategory(String param1String) {
      set("&iv", param1String);
      return this;
    }
    
    public ItemBuilder setCurrencyCode(String param1String) {
      set("&cu", param1String);
      return this;
    }
    
    public ItemBuilder setName(String param1String) {
      set("&in", param1String);
      return this;
    }
    
    public ItemBuilder setPrice(double param1Double) {
      set("&ip", Double.toString(param1Double));
      return this;
    }
    
    public ItemBuilder setQuantity(long param1Long) {
      set("&iq", Long.toString(param1Long));
      return this;
    }
    
    public ItemBuilder setSku(String param1String) {
      set("&ic", param1String);
      return this;
    }
    
    public ItemBuilder setTransactionId(String param1String) {
      set("&ti", param1String);
      return this;
    }
  }
  
  public static class ScreenViewBuilder extends HitBuilder<ScreenViewBuilder> {
    public ScreenViewBuilder() {
      y.eK().a(y.a.Bg);
      set("&t", "screenview");
    }
  }
  
  public static class SocialBuilder extends HitBuilder<SocialBuilder> {
    public SocialBuilder() {
      y.eK().a(y.a.AG);
      set("&t", "social");
    }
    
    public SocialBuilder setAction(String param1String) {
      set("&sa", param1String);
      return this;
    }
    
    public SocialBuilder setNetwork(String param1String) {
      set("&sn", param1String);
      return this;
    }
    
    public SocialBuilder setTarget(String param1String) {
      set("&st", param1String);
      return this;
    }
  }
  
  public static class TimingBuilder extends HitBuilder<TimingBuilder> {
    public TimingBuilder() {
      y.eK().a(y.a.AF);
      set("&t", "timing");
    }
    
    public TimingBuilder(String param1String1, String param1String2, long param1Long) {
      this();
      setVariable(param1String2);
      setValue(param1Long);
      setCategory(param1String1);
    }
    
    public TimingBuilder setCategory(String param1String) {
      set("&utc", param1String);
      return this;
    }
    
    public TimingBuilder setLabel(String param1String) {
      set("&utl", param1String);
      return this;
    }
    
    public TimingBuilder setValue(long param1Long) {
      set("&utt", Long.toString(param1Long));
      return this;
    }
    
    public TimingBuilder setVariable(String param1String) {
      set("&utv", param1String);
      return this;
    }
  }
  
  @Deprecated
  public static class TransactionBuilder extends HitBuilder<TransactionBuilder> {
    public TransactionBuilder() {
      y.eK().a(y.a.AC);
      set("&t", "transaction");
    }
    
    public TransactionBuilder setAffiliation(String param1String) {
      set("&ta", param1String);
      return this;
    }
    
    public TransactionBuilder setCurrencyCode(String param1String) {
      set("&cu", param1String);
      return this;
    }
    
    public TransactionBuilder setRevenue(double param1Double) {
      set("&tr", Double.toString(param1Double));
      return this;
    }
    
    public TransactionBuilder setShipping(double param1Double) {
      set("&ts", Double.toString(param1Double));
      return this;
    }
    
    public TransactionBuilder setTax(double param1Double) {
      set("&tt", Double.toString(param1Double));
      return this;
    }
    
    public TransactionBuilder setTransactionId(String param1String) {
      set("&ti", param1String);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\HitBuilders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */