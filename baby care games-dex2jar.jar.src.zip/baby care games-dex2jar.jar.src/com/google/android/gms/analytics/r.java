package com.google.android.gms.analytics;

import java.util.List;

public interface r {
  int a(List<ab> paramList, af paramaf, boolean paramBoolean);
  
  void ad(String paramString);
  
  boolean ea();
  
  void setDryRun(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\analytics\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */