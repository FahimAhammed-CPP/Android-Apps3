package com.google.android.gms.deviceconnection.features;

import com.google.android.gms.common.data.DataBuffer;

public class DeviceFeatureBuffer extends DataBuffer<DeviceFeature> {
  public DeviceFeature get(int paramInt) {
    return new a(this.JG, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\deviceconnection\features\DeviceFeatureBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */