package com.google.android.gms.common.data;

import android.os.Bundle;
import com.google.android.gms.common.api.Releasable;
import java.util.Iterator;

public abstract class DataBuffer<T> implements Releasable, Iterable<T> {
  protected final DataHolder JG;
  
  protected DataBuffer(DataHolder paramDataHolder) {
    this.JG = paramDataHolder;
    if (this.JG != null)
      this.JG.e(this); 
  }
  
  @Deprecated
  public final void close() {
    release();
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Bundle gV() {
    return this.JG.gV();
  }
  
  public abstract T get(int paramInt);
  
  public int getCount() {
    return (this.JG == null) ? 0 : this.JG.getCount();
  }
  
  @Deprecated
  public boolean isClosed() {
    return (this.JG == null) ? true : this.JG.isClosed();
  }
  
  public Iterator<T> iterator() {
    return new c<T>(this);
  }
  
  public void release() {
    if (this.JG != null)
      this.JG.close(); 
  }
  
  public Iterator<T> singleRefIterator() {
    return new h<T>(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\data\DataBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */