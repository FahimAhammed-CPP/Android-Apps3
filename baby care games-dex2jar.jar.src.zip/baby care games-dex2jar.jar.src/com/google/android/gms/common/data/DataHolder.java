package com.google.android.gms.common.data;

import android.database.CharArrayBuffer;
import android.database.CursorIndexOutOfBoundsException;
import android.database.CursorWindow;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.jx;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class DataHolder implements SafeParcelable {
  public static final f CREATOR = new f();
  
  private static final a Ll = new a(new String[0], null) {
    
    };
  
  private final int CK;
  
  private final int Iv;
  
  private final String[] Ld;
  
  Bundle Le;
  
  private final CursorWindow[] Lf;
  
  private final Bundle Lg;
  
  int[] Lh;
  
  int Li;
  
  private Object Lj;
  
  private boolean Lk = true;
  
  boolean mClosed = false;
  
  DataHolder(int paramInt1, String[] paramArrayOfString, CursorWindow[] paramArrayOfCursorWindow, int paramInt2, Bundle paramBundle) {
    this.CK = paramInt1;
    this.Ld = paramArrayOfString;
    this.Lf = paramArrayOfCursorWindow;
    this.Iv = paramInt2;
    this.Lg = paramBundle;
  }
  
  private DataHolder(a parama, int paramInt, Bundle paramBundle) {
    this(a.a(parama), a(parama, -1), paramInt, paramBundle);
  }
  
  public DataHolder(String[] paramArrayOfString, CursorWindow[] paramArrayOfCursorWindow, int paramInt, Bundle paramBundle) {
    this.CK = 1;
    this.Ld = (String[])jx.i(paramArrayOfString);
    this.Lf = (CursorWindow[])jx.i(paramArrayOfCursorWindow);
    this.Iv = paramInt;
    this.Lg = paramBundle;
    gX();
  }
  
  public static DataHolder a(int paramInt, Bundle paramBundle) {
    return new DataHolder(Ll, paramInt, paramBundle);
  }
  
  private static CursorWindow[] a(a parama, int paramInt) {
    List<Map> list;
    boolean bool = false;
    if ((a.a(parama)).length == 0)
      return new CursorWindow[0]; 
    if (paramInt < 0 || paramInt >= a.b(parama).size()) {
      list = a.b(parama);
    } else {
      list = a.b(parama).subList(0, paramInt);
    } 
    int j = list.size();
    CursorWindow cursorWindow = new CursorWindow(false);
    ArrayList<CursorWindow> arrayList = new ArrayList();
    arrayList.add(cursorWindow);
    cursorWindow.setNumColumns((a.a(parama)).length);
    paramInt = 0;
    int i = 0;
    label69: while (true) {
      if (paramInt < j) {
        CursorWindow cursorWindow1 = cursorWindow;
        try {
          if (!cursorWindow.allocRow()) {
            Log.d("DataHolder", "Allocating additional cursor window for large data set (row " + paramInt + ")");
            cursorWindow = new CursorWindow(false);
            cursorWindow.setStartPosition(paramInt);
            cursorWindow.setNumColumns((a.a(parama)).length);
            arrayList.add(cursorWindow);
            cursorWindow1 = cursorWindow;
            if (!cursorWindow.allocRow()) {
              Log.e("DataHolder", "Unable to allocate row to hold data.");
              arrayList.remove(cursorWindow);
              return arrayList.<CursorWindow>toArray(new CursorWindow[arrayList.size()]);
            } 
          } 
          Map map = list.get(paramInt);
          int k = 0;
          boolean bool1 = true;
          while (true) {
            if (k < (a.a(parama)).length && bool1) {
              String str = a.a(parama)[k];
              Object object = map.get(str);
              if (object == null) {
                bool1 = cursorWindow1.putNull(paramInt, k);
              } else if (object instanceof String) {
                bool1 = cursorWindow1.putString((String)object, paramInt, k);
              } else if (object instanceof Long) {
                bool1 = cursorWindow1.putLong(((Long)object).longValue(), paramInt, k);
              } else if (object instanceof Integer) {
                bool1 = cursorWindow1.putLong(((Integer)object).intValue(), paramInt, k);
              } else if (object instanceof Boolean) {
                long l;
                if (((Boolean)object).booleanValue()) {
                  l = 1L;
                } else {
                  l = 0L;
                } 
                bool1 = cursorWindow1.putLong(l, paramInt, k);
              } else if (object instanceof byte[]) {
                bool1 = cursorWindow1.putBlob((byte[])object, paramInt, k);
              } else if (object instanceof Double) {
                bool1 = cursorWindow1.putDouble(((Double)object).doubleValue(), paramInt, k);
              } else if (object instanceof Float) {
                bool1 = cursorWindow1.putDouble(((Float)object).floatValue(), paramInt, k);
              } else {
                throw new IllegalArgumentException("Unsupported object for column " + str + ": " + object);
              } 
            } else {
              if (!bool1) {
                if (i)
                  throw new b("Could not add the value to a new CursorWindow. The size of value may be larger than what a CursorWindow can handle."); 
                Log.d("DataHolder", "Couldn't populate window data for row " + paramInt + " - allocating new window.");
                cursorWindow1.freeLastRow();
                cursorWindow1 = new CursorWindow(false);
                cursorWindow1.setStartPosition(paramInt);
                cursorWindow1.setNumColumns((a.a(parama)).length);
                arrayList.add(cursorWindow1);
                i = paramInt - 1;
                paramInt = 1;
              } else {
                k = 0;
                i = paramInt;
                paramInt = k;
              } 
              k = paramInt;
              paramInt = i + 1;
              CursorWindow cursorWindow2 = cursorWindow1;
              i = k;
              continue label69;
            } 
            k++;
          } 
        } catch (RuntimeException runtimeException) {
          i = arrayList.size();
          for (paramInt = bool; paramInt < i; paramInt++)
            ((CursorWindow)arrayList.get(paramInt)).close(); 
          throw runtimeException;
        } 
        break;
      } 
      return arrayList.<CursorWindow>toArray(new CursorWindow[arrayList.size()]);
    } 
  }
  
  public static DataHolder av(int paramInt) {
    return a(paramInt, (Bundle)null);
  }
  
  private void g(String paramString, int paramInt) {
    if (this.Le == null || !this.Le.containsKey(paramString))
      throw new IllegalArgumentException("No such column: " + paramString); 
    if (isClosed())
      throw new IllegalArgumentException("Buffer is closed."); 
    if (paramInt < 0 || paramInt >= this.Li)
      throw new CursorIndexOutOfBoundsException(paramInt, this.Li); 
  }
  
  public long a(String paramString, int paramInt1, int paramInt2) {
    g(paramString, paramInt1);
    return this.Lf[paramInt2].getLong(paramInt1, this.Le.getInt(paramString));
  }
  
  public void a(String paramString, int paramInt1, int paramInt2, CharArrayBuffer paramCharArrayBuffer) {
    g(paramString, paramInt1);
    this.Lf[paramInt2].copyStringToBuffer(paramInt1, this.Le.getInt(paramString), paramCharArrayBuffer);
  }
  
  public boolean aQ(String paramString) {
    return this.Le.containsKey(paramString);
  }
  
  public int au(int paramInt) {
    boolean bool;
    int i = 0;
    if (paramInt >= 0 && paramInt < this.Li) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.K(bool);
    while (true) {
      int j = i;
      if (i < this.Lh.length)
        if (paramInt < this.Lh[i]) {
          j = i - 1;
        } else {
          i++;
          continue;
        }  
      paramInt = j;
      if (j == this.Lh.length)
        paramInt = j - 1; 
      return paramInt;
    } 
  }
  
  public int b(String paramString, int paramInt1, int paramInt2) {
    g(paramString, paramInt1);
    return this.Lf[paramInt2].getInt(paramInt1, this.Le.getInt(paramString));
  }
  
  public String c(String paramString, int paramInt1, int paramInt2) {
    g(paramString, paramInt1);
    return this.Lf[paramInt2].getString(paramInt1, this.Le.getInt(paramString));
  }
  
  public void close() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mClosed : Z
    //   6: ifne -> 41
    //   9: aload_0
    //   10: iconst_1
    //   11: putfield mClosed : Z
    //   14: iconst_0
    //   15: istore_1
    //   16: iload_1
    //   17: aload_0
    //   18: getfield Lf : [Landroid/database/CursorWindow;
    //   21: arraylength
    //   22: if_icmpge -> 41
    //   25: aload_0
    //   26: getfield Lf : [Landroid/database/CursorWindow;
    //   29: iload_1
    //   30: aaload
    //   31: invokevirtual close : ()V
    //   34: iload_1
    //   35: iconst_1
    //   36: iadd
    //   37: istore_1
    //   38: goto -> 16
    //   41: aload_0
    //   42: monitorexit
    //   43: return
    //   44: astore_2
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_2
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	44	finally
    //   16	34	44	finally
    //   41	43	44	finally
    //   45	47	44	finally
  }
  
  public boolean d(String paramString, int paramInt1, int paramInt2) {
    g(paramString, paramInt1);
    return (Long.valueOf(this.Lf[paramInt2].getLong(paramInt1, this.Le.getInt(paramString))).longValue() == 1L);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public float e(String paramString, int paramInt1, int paramInt2) {
    g(paramString, paramInt1);
    return this.Lf[paramInt2].getFloat(paramInt1, this.Le.getInt(paramString));
  }
  
  public void e(Object paramObject) {
    this.Lj = paramObject;
  }
  
  public byte[] f(String paramString, int paramInt1, int paramInt2) {
    g(paramString, paramInt1);
    return this.Lf[paramInt2].getBlob(paramInt1, this.Le.getInt(paramString));
  }
  
  protected void finalize() throws Throwable {
    try {
      if (this.Lk && this.Lf.length > 0 && !isClosed()) {
        String str;
        if (this.Lj == null) {
          str = "internal object: " + toString();
        } else {
          str = this.Lj.toString();
        } 
        Log.e("DataBuffer", "Internal data leak within a DataBuffer object detected!  Be sure to explicitly call release() on all DataBuffer extending objects when you are done with them. (" + str + ")");
        close();
      } 
      return;
    } finally {
      super.finalize();
    } 
  }
  
  public Uri g(String paramString, int paramInt1, int paramInt2) {
    paramString = c(paramString, paramInt1, paramInt2);
    return (paramString == null) ? null : Uri.parse(paramString);
  }
  
  public Bundle gV() {
    return this.Lg;
  }
  
  public void gX() {
    int j = 0;
    this.Le = new Bundle();
    int i;
    for (i = 0; i < this.Ld.length; i++)
      this.Le.putInt(this.Ld[i], i); 
    this.Lh = new int[this.Lf.length];
    int k = 0;
    i = j;
    j = k;
    while (i < this.Lf.length) {
      this.Lh[i] = j;
      k = this.Lf[i].getStartPosition();
      j += this.Lf[i].getNumRows() - j - k;
      i++;
    } 
    this.Li = j;
  }
  
  String[] gY() {
    return this.Ld;
  }
  
  CursorWindow[] gZ() {
    return this.Lf;
  }
  
  public int getCount() {
    return this.Li;
  }
  
  public int getStatusCode() {
    return this.Iv;
  }
  
  int getVersionCode() {
    return this.CK;
  }
  
  public boolean h(String paramString, int paramInt1, int paramInt2) {
    g(paramString, paramInt1);
    return this.Lf[paramInt2].isNull(paramInt1, this.Le.getInt(paramString));
  }
  
  public boolean isClosed() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mClosed : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	11	finally
    //   12	14	11	finally
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    f.a(this, paramParcel, paramInt);
  }
  
  public static class a {
    private final String[] Ld;
    
    private final ArrayList<HashMap<String, Object>> Lm;
    
    private final String Ln;
    
    private final HashMap<Object, Integer> Lo;
    
    private boolean Lp;
    
    private String Lq;
    
    private a(String[] param1ArrayOfString, String param1String) {
      this.Ld = (String[])jx.i(param1ArrayOfString);
      this.Lm = new ArrayList<HashMap<String, Object>>();
      this.Ln = param1String;
      this.Lo = new HashMap<Object, Integer>();
      this.Lp = false;
      this.Lq = null;
    }
  }
  
  public static class b extends RuntimeException {
    public b(String param1String) {
      super(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\data\DataHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */