package com.google.android.gms.common.data;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;

public class b implements Parcelable.Creator<a> {
  static void a(a parama, Parcel paramParcel, int paramInt) {
    int i = com.google.android.gms.common.internal.safeparcel.b.H(paramParcel);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 1, parama.CK);
    com.google.android.gms.common.internal.safeparcel.b.a(paramParcel, 2, (Parcelable)parama.KS, paramInt, false);
    com.google.android.gms.common.internal.safeparcel.b.c(paramParcel, 3, parama.Gt);
    com.google.android.gms.common.internal.safeparcel.b.H(paramParcel, i);
  }
  
  public a A(Parcel paramParcel) {
    int i = 0;
    int k = a.G(paramParcel);
    ParcelFileDescriptor parcelFileDescriptor = null;
    int j = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.F(paramParcel);
      switch (a.aH(m)) {
        case 1:
          j = a.g(paramParcel, m);
          break;
        case 2:
          parcelFileDescriptor = (ParcelFileDescriptor)a.a(paramParcel, m, ParcelFileDescriptor.CREATOR);
          break;
        case 3:
          i = a.g(paramParcel, m);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new a(j, parcelFileDescriptor, i);
  }
  
  public a[] ar(int paramInt) {
    return new a[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\data\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */