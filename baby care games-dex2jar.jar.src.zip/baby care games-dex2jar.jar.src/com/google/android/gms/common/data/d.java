package com.google.android.gms.common.data;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.internal.jv;
import com.google.android.gms.internal.jx;

public abstract class d {
  protected final DataHolder JG;
  
  protected int KZ;
  
  private int La;
  
  public d(DataHolder paramDataHolder, int paramInt) {
    this.JG = (DataHolder)jx.i(paramDataHolder);
    as(paramInt);
  }
  
  protected void a(String paramString, CharArrayBuffer paramCharArrayBuffer) {
    this.JG.a(paramString, this.KZ, this.La, paramCharArrayBuffer);
  }
  
  public boolean aQ(String paramString) {
    return this.JG.aQ(paramString);
  }
  
  protected Uri aR(String paramString) {
    return this.JG.g(paramString, this.KZ, this.La);
  }
  
  protected boolean aS(String paramString) {
    return this.JG.h(paramString, this.KZ, this.La);
  }
  
  protected void as(int paramInt) {
    boolean bool;
    if (paramInt >= 0 && paramInt < this.JG.getCount()) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.K(bool);
    this.KZ = paramInt;
    this.La = this.JG.au(this.KZ);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (paramObject instanceof d) {
      paramObject = paramObject;
      bool1 = bool2;
      if (jv.equal(Integer.valueOf(((d)paramObject).KZ), Integer.valueOf(this.KZ))) {
        bool1 = bool2;
        if (jv.equal(Integer.valueOf(((d)paramObject).La), Integer.valueOf(this.La))) {
          bool1 = bool2;
          if (((d)paramObject).JG == this.JG)
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  protected int gW() {
    return this.KZ;
  }
  
  protected boolean getBoolean(String paramString) {
    return this.JG.d(paramString, this.KZ, this.La);
  }
  
  protected byte[] getByteArray(String paramString) {
    return this.JG.f(paramString, this.KZ, this.La);
  }
  
  protected float getFloat(String paramString) {
    return this.JG.e(paramString, this.KZ, this.La);
  }
  
  protected int getInteger(String paramString) {
    return this.JG.b(paramString, this.KZ, this.La);
  }
  
  protected long getLong(String paramString) {
    return this.JG.a(paramString, this.KZ, this.La);
  }
  
  protected String getString(String paramString) {
    return this.JG.c(paramString, this.KZ, this.La);
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { Integer.valueOf(this.KZ), Integer.valueOf(this.La), this.JG });
  }
  
  public boolean isDataValid() {
    return !this.JG.isClosed();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\data\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */