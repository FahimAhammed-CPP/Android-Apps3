package com.google.android.gms.common.data;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public class a implements SafeParcelable {
  public static final Parcelable.Creator<a> CREATOR = new b();
  
  final int CK;
  
  final int Gt;
  
  ParcelFileDescriptor KS;
  
  private Bitmap KT;
  
  private boolean KU;
  
  private File KV;
  
  a(int paramInt1, ParcelFileDescriptor paramParcelFileDescriptor, int paramInt2) {
    this.CK = paramInt1;
    this.KS = paramParcelFileDescriptor;
    this.Gt = paramInt2;
    this.KT = null;
    this.KU = false;
  }
  
  public a(Bitmap paramBitmap) {
    this.CK = 1;
    this.KS = null;
    this.Gt = 0;
    this.KT = paramBitmap;
    this.KU = true;
  }
  
  private void a(Closeable paramCloseable) {
    try {
      paramCloseable.close();
      return;
    } catch (IOException iOException) {
      Log.w("BitmapTeleporter", "Could not close stream", iOException);
      return;
    } 
  }
  
  private FileOutputStream gU() {
    if (this.KV == null)
      throw new IllegalStateException("setTempDir() must be called before writing this object to a parcel"); 
    try {
      File file = File.createTempFile("teleporter", ".tmp", this.KV);
      try {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        this.KS = ParcelFileDescriptor.open(file, 268435456);
        file.delete();
        return fileOutputStream;
      } catch (FileNotFoundException fileNotFoundException) {
        throw new IllegalStateException("Temporary file is somehow already deleted");
      } 
    } catch (IOException iOException) {
      throw new IllegalStateException("Could not create temporary file", iOException);
    } 
  }
  
  public void a(File paramFile) {
    if (paramFile == null)
      throw new NullPointerException("Cannot set null temp directory"); 
    this.KV = paramFile;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Bitmap gT() {
    if (!this.KU) {
      ByteBuffer byteBuffer;
      DataInputStream dataInputStream = new DataInputStream((InputStream)new ParcelFileDescriptor.AutoCloseInputStream(this.KS));
      try {
        byte[] arrayOfByte = new byte[dataInputStream.readInt()];
        int i = dataInputStream.readInt();
        int j = dataInputStream.readInt();
        Bitmap.Config config = Bitmap.Config.valueOf(dataInputStream.readUTF());
        dataInputStream.read(arrayOfByte);
        a(dataInputStream);
        byteBuffer = ByteBuffer.wrap(arrayOfByte);
        Bitmap bitmap = Bitmap.createBitmap(i, j, config);
        bitmap.copyPixelsFromBuffer(byteBuffer);
        this.KT = bitmap;
        return this.KT;
      } catch (IOException iOException) {
        throw new IllegalStateException("Could not read from parcel file descriptor", iOException);
      } finally {
        a((Closeable)byteBuffer);
      } 
    } 
    return this.KT;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    if (this.KS == null) {
      Bitmap bitmap = this.KT;
      ByteBuffer byteBuffer = ByteBuffer.allocate(bitmap.getRowBytes() * bitmap.getHeight());
      bitmap.copyPixelsToBuffer(byteBuffer);
      byte[] arrayOfByte = byteBuffer.array();
      DataOutputStream dataOutputStream = new DataOutputStream(gU());
      try {
        dataOutputStream.writeInt(arrayOfByte.length);
        dataOutputStream.writeInt(bitmap.getWidth());
        dataOutputStream.writeInt(bitmap.getHeight());
        dataOutputStream.writeUTF(bitmap.getConfig().toString());
        dataOutputStream.write(arrayOfByte);
        a(dataOutputStream);
        return;
      } catch (IOException iOException) {
        throw new IllegalStateException("Could not write into unlinked file", iOException);
      } finally {
        a(dataOutputStream);
      } 
    } 
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\data\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */