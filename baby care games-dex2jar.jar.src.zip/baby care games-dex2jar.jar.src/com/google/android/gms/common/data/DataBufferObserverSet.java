package com.google.android.gms.common.data;

import java.util.HashSet;
import java.util.Iterator;

public final class DataBufferObserverSet implements DataBufferObserver, DataBufferObserver.Observable {
  private HashSet<DataBufferObserver> KY = new HashSet<DataBufferObserver>();
  
  public void addObserver(DataBufferObserver paramDataBufferObserver) {
    this.KY.add(paramDataBufferObserver);
  }
  
  public void clear() {
    this.KY.clear();
  }
  
  public boolean hasObservers() {
    return !this.KY.isEmpty();
  }
  
  public void onDataChanged() {
    Iterator<DataBufferObserver> iterator = this.KY.iterator();
    while (iterator.hasNext())
      ((DataBufferObserver)iterator.next()).onDataChanged(); 
  }
  
  public void onDataRangeChanged(int paramInt1, int paramInt2) {
    Iterator<DataBufferObserver> iterator = this.KY.iterator();
    while (iterator.hasNext())
      ((DataBufferObserver)iterator.next()).onDataRangeChanged(paramInt1, paramInt2); 
  }
  
  public void onDataRangeInserted(int paramInt1, int paramInt2) {
    Iterator<DataBufferObserver> iterator = this.KY.iterator();
    while (iterator.hasNext())
      ((DataBufferObserver)iterator.next()).onDataRangeInserted(paramInt1, paramInt2); 
  }
  
  public void onDataRangeMoved(int paramInt1, int paramInt2, int paramInt3) {
    Iterator<DataBufferObserver> iterator = this.KY.iterator();
    while (iterator.hasNext())
      ((DataBufferObserver)iterator.next()).onDataRangeMoved(paramInt1, paramInt2, paramInt3); 
  }
  
  public void onDataRangeRemoved(int paramInt1, int paramInt2) {
    Iterator<DataBufferObserver> iterator = this.KY.iterator();
    while (iterator.hasNext())
      ((DataBufferObserver)iterator.next()).onDataRangeRemoved(paramInt1, paramInt2); 
  }
  
  public void removeObserver(DataBufferObserver paramDataBufferObserver) {
    this.KY.remove(paramDataBufferObserver);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\data\DataBufferObserverSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */