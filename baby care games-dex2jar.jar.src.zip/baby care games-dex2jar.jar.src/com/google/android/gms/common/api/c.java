package com.google.android.gms.common.api;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.jg;
import com.google.android.gms.internal.jm;
import com.google.android.gms.internal.jx;
import com.google.android.gms.internal.kc;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

final class c implements GoogleApiClient {
  private final Looper JF;
  
  private final Condition JR = this.zO.newCondition();
  
  private final jm JS;
  
  private final int JT;
  
  final Queue<d<?>> JU = new LinkedList<d<?>>();
  
  private ConnectionResult JV;
  
  private int JW;
  
  private volatile int JX = 4;
  
  private volatile boolean JY;
  
  private boolean JZ = false;
  
  private final b Jy = new b(this) {
      public void b(c.d<?> param1d) {
        this.Kn.Kk.remove(param1d);
      }
    };
  
  private int Ka;
  
  private long Kb = 120000L;
  
  private long Kc = 5000L;
  
  final Handler Kd;
  
  BroadcastReceiver Ke;
  
  private final Bundle Kf = new Bundle();
  
  private final Map<Api.c<?>, Api.a> Kg = new HashMap<Api.c<?>, Api.a>();
  
  private final List<String> Kh;
  
  private boolean Ki;
  
  private final Set<d<?>> Kj = Collections.newSetFromMap(new WeakHashMap<d<?>, Boolean>());
  
  final Set<d<?>> Kk = Collections.newSetFromMap(new ConcurrentHashMap<d<?>, Boolean>());
  
  private final GoogleApiClient.ConnectionCallbacks Kl = new GoogleApiClient.ConnectionCallbacks(this) {
      public void onConnected(Bundle param1Bundle) {
        c.a(this.Kn).lock();
        try {
          if (c.b(this.Kn) == 1) {
            if (param1Bundle != null)
              c.c(this.Kn).putAll(param1Bundle); 
            c.d(this.Kn);
          } 
          return;
        } finally {
          c.a(this.Kn).unlock();
        } 
      }
      
      public void onConnectionSuspended(int param1Int) {
        c.a(this.Kn).lock();
        switch (param1Int) {
          default:
            c.a(this.Kn).unlock();
            return;
          case 2:
            try {
              c.a(this.Kn, param1Int);
              this.Kn.connect();
            } finally {
              c.a(this.Kn).unlock();
            } 
          case 1:
            break;
        } 
        boolean bool = this.Kn.gL();
        if (bool) {
          c.a(this.Kn).unlock();
          return;
        } 
        c.a(this.Kn, true);
        this.Kn.Ke = new c.a(this.Kn);
        IntentFilter intentFilter = new IntentFilter("android.intent.action.PACKAGE_ADDED");
        intentFilter.addDataScheme("package");
        c.e(this.Kn).registerReceiver(this.Kn.Ke, intentFilter);
        this.Kn.Kd.sendMessageDelayed(this.Kn.Kd.obtainMessage(1), c.f(this.Kn));
        this.Kn.Kd.sendMessageDelayed(this.Kn.Kd.obtainMessage(2), c.g(this.Kn));
        c.a(this.Kn, param1Int);
      }
    };
  
  private final jm.b Km = new jm.b(this) {
      public Bundle fX() {
        return null;
      }
      
      public boolean gN() {
        return c.h(this.Kn);
      }
      
      public boolean isConnected() {
        return this.Kn.isConnected();
      }
    };
  
  private final Context mContext;
  
  private final Lock zO = new ReentrantLock();
  
  public c(Context paramContext, Looper paramLooper, jg paramjg, Map<Api<?>, Api.ApiOptions> paramMap, Set<GoogleApiClient.ConnectionCallbacks> paramSet, Set<GoogleApiClient.OnConnectionFailedListener> paramSet1, int paramInt) {
    this.mContext = paramContext;
    this.JS = new jm(paramContext, paramLooper, this.Km);
    this.JF = paramLooper;
    this.Kd = new c(this, paramLooper);
    this.JT = paramInt;
    for (GoogleApiClient.ConnectionCallbacks connectionCallbacks : paramSet)
      this.JS.registerConnectionCallbacks(connectionCallbacks); 
    for (GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener : paramSet1)
      this.JS.registerConnectionFailedListener(onConnectionFailedListener); 
    for (Api<?> api : paramMap.keySet()) {
      Api.b<Api.a, ?> b1 = api.gx();
      Object object = paramMap.get(api);
      this.Kg.put(api.gz(), a(b1, object, paramContext, paramLooper, paramjg, this.Kl, new GoogleApiClient.OnConnectionFailedListener(this, b1) {
              public void onConnectionFailed(ConnectionResult param1ConnectionResult) {
                c.a(this.Kn).lock();
                try {
                  if (c.k(this.Kn) == null || this.Ko.getPriority() < c.l(this.Kn)) {
                    c.a(this.Kn, param1ConnectionResult);
                    c.b(this.Kn, this.Ko.getPriority());
                  } 
                  c.d(this.Kn);
                  return;
                } finally {
                  c.a(this.Kn).unlock();
                } 
              }
            }));
    } 
    this.Kh = Collections.unmodifiableList(paramjg.ho());
  }
  
  private static <C extends Api.a, O> C a(Api.b<C, O> paramb, Object paramObject, Context paramContext, Looper paramLooper, jg paramjg, GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    return paramb.a(paramContext, paramLooper, paramjg, (O)paramObject, paramConnectionCallbacks, paramOnConnectionFailedListener);
  }
  
  private void a(GoogleApiClient paramGoogleApiClient, f paramf, boolean paramBoolean) {
    kc.Nu.c(paramGoogleApiClient).setResultCallback(new ResultCallback<Status>(this, paramf, paramBoolean, paramGoogleApiClient) {
          public void j(Status param1Status) {
            if (param1Status.isSuccess() && this.Kn.isConnected())
              this.Kn.reconnect(); 
            this.Kq.b(param1Status);
            if (this.Kr)
              this.GB.disconnect(); 
          }
        });
  }
  
  private <A extends Api.a> void a(d<A> paramd) throws DeadObjectException {
    this.zO.lock();
    try {
      boolean bool;
      if (paramd.gz() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      jx.b(bool, "This task can not be executed or enqueued (it's probably a Batch or malformed)");
      this.Kk.add(paramd);
      paramd.a(this.Jy);
      if (gL()) {
        paramd.l(new Status(8));
        return;
      } 
      paramd.b(a(paramd.gz()));
      return;
    } finally {
      this.zO.unlock();
    } 
  }
  
  private void al(int paramInt) {
    this.zO.lock();
    try {
      if (this.JX != 3) {
        if (paramInt == -1) {
          if (isConnecting()) {
            Iterator<d<?>> iterator1 = this.JU.iterator();
            while (iterator1.hasNext()) {
              d d = iterator1.next();
              if (d.gF() != 1) {
                d.cancel();
                iterator1.remove();
              } 
            } 
          } else {
            this.JU.clear();
          } 
          Iterator<d<?>> iterator = this.Kk.iterator();
          while (iterator.hasNext())
            ((d)iterator.next()).cancel(); 
          this.Kk.clear();
          iterator = (Iterator)this.Kj.iterator();
          while (iterator.hasNext())
            ((d)iterator.next()).clear(); 
          this.Kj.clear();
          if (this.JV == null && !this.JU.isEmpty()) {
            this.JZ = true;
            return;
          } 
        } 
        boolean bool1 = isConnecting();
        boolean bool2 = isConnected();
        this.JX = 3;
        if (bool1) {
          if (paramInt == -1)
            this.JV = null; 
          this.JR.signalAll();
        } 
        this.Ki = false;
        for (Api.a a : this.Kg.values()) {
          if (a.isConnected())
            a.disconnect(); 
        } 
        this.Ki = true;
        this.JX = 4;
        if (bool2) {
          if (paramInt != -1)
            this.JS.aE(paramInt); 
          this.Ki = false;
        } 
      } 
    } finally {
      this.zO.unlock();
    } 
  }
  
  private void gJ() {
    Bundle bundle;
    this.Ka--;
    if (this.Ka == 0) {
      if (this.JV != null) {
        this.JZ = false;
        al(3);
        if (!gL() || !GooglePlayServicesUtil.e(this.mContext, this.JV.getErrorCode())) {
          gM();
          this.JS.b(this.JV);
        } 
        this.Ki = false;
        return;
      } 
    } else {
      return;
    } 
    this.JX = 2;
    gM();
    this.JR.signalAll();
    gK();
    if (this.JZ) {
      this.JZ = false;
      al(-1);
      return;
    } 
    if (this.Kf.isEmpty()) {
      bundle = null;
    } else {
      bundle = this.Kf;
    } 
    this.JS.f(bundle);
  }
  
  private void gK() {
    this.zO.lock();
  }
  
  private void gM() {
    this.zO.lock();
    try {
      boolean bool = this.JY;
      if (!bool)
        return; 
      this.JY = false;
      this.Kd.removeMessages(2);
      this.Kd.removeMessages(1);
      this.mContext.unregisterReceiver(this.Ke);
      return;
    } finally {
      this.zO.unlock();
    } 
  }
  
  private void resume() {
    this.zO.lock();
    try {
      if (gL())
        connect(); 
      return;
    } finally {
      this.zO.unlock();
    } 
  }
  
  public <C extends Api.a> C a(Api.c<C> paramc) {
    Api.a a = this.Kg.get(paramc);
    jx.b(a, "Appropriate Api was not requested.");
    return (C)a;
  }
  
  public <A extends Api.a, R extends Result, T extends BaseImplementation.a<R, A>> T a(T paramT) {
    this.zO.lock();
    try {
      if (isConnected()) {
        b((BaseImplementation.a)paramT);
        return paramT;
      } 
      this.JU.add((d<?>)paramT);
      return paramT;
    } finally {
      this.zO.unlock();
    } 
  }
  
  public boolean a(Scope paramScope) {
    return this.Kh.contains(paramScope.gO());
  }
  
  public <A extends Api.a, T extends BaseImplementation.a<? extends Result, A>> T b(T paramT) {
    boolean bool;
    if (isConnected() || gL()) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.a(bool, "GoogleApiClient is not connected yet.");
    gK();
    try {
      a((d<Api.a>)paramT);
      return paramT;
    } catch (DeadObjectException deadObjectException) {
      al(1);
      return paramT;
    } 
  }
  
  public ConnectionResult blockingConnect() {
    boolean bool;
    if (Looper.myLooper() != Looper.getMainLooper()) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.a(bool, "blockingConnect must not be called on the UI thread");
    this.zO.lock();
    try {
      connect();
      while (true) {
        bool = isConnecting();
        if (bool) {
          try {
            this.JR.await();
          } catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
            return new ConnectionResult(15, null);
          } 
          continue;
        } 
        if (isConnected())
          return ConnectionResult.Iu; 
        if (this.JV != null)
          return this.JV; 
        return new ConnectionResult(13, null);
      } 
    } finally {
      this.zO.unlock();
    } 
  }
  
  public ConnectionResult blockingConnect(long paramLong, TimeUnit paramTimeUnit) {
    boolean bool;
    if (Looper.myLooper() != Looper.getMainLooper()) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.a(bool, "blockingConnect must not be called on the UI thread");
    this.zO.lock();
    try {
      connect();
      paramLong = paramTimeUnit.toNanos(paramLong);
      while (true) {
        bool = isConnecting();
        if (bool) {
          try {
            long l = this.JR.awaitNanos(paramLong);
            paramLong = l;
            if (l <= 0L)
              return new ConnectionResult(14, null); 
          } catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
            return new ConnectionResult(15, null);
          } 
          continue;
        } 
        if (isConnected())
          return ConnectionResult.Iu; 
        if (this.JV != null)
          return this.JV; 
        return new ConnectionResult(13, null);
      } 
    } finally {
      this.zO.unlock();
    } 
  }
  
  public PendingResult<Status> clearDefaultAccountAndReconnect() {
    jx.a(isConnected(), "GoogleApiClient is not connected yet.");
    f f = new f(this.JF);
    if (this.Kg.containsKey(kc.DQ)) {
      a(this, f, false);
      return f;
    } 
    AtomicReference<GoogleApiClient> atomicReference = new AtomicReference();
    GoogleApiClient.ConnectionCallbacks connectionCallbacks = new GoogleApiClient.ConnectionCallbacks(this, atomicReference, f) {
        public void onConnected(Bundle param1Bundle) {
          c.a(this.Kn, this.Kp.get(), this.Kq, true);
        }
        
        public void onConnectionSuspended(int param1Int) {}
      };
    GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener = new GoogleApiClient.OnConnectionFailedListener(this, f) {
        public void onConnectionFailed(ConnectionResult param1ConnectionResult) {
          this.Kq.b(new Status(8));
        }
      };
    GoogleApiClient googleApiClient = (new GoogleApiClient.Builder(this.mContext)).addApi(kc.API).addConnectionCallbacks(connectionCallbacks).addOnConnectionFailedListener(onConnectionFailedListener).setHandler(this.Kd).build();
    atomicReference.set(googleApiClient);
    googleApiClient.connect();
    return f;
  }
  
  public void connect() {
    this.zO.lock();
    try {
      this.JZ = false;
      if (!isConnected()) {
        boolean bool = isConnecting();
        if (!bool) {
          this.Ki = true;
          this.JV = null;
          this.JX = 1;
          this.Kf.clear();
          this.Ka = this.Kg.size();
          Iterator<Api.a> iterator = this.Kg.values().iterator();
          while (iterator.hasNext())
            ((Api.a)iterator.next()).connect(); 
          return;
        } 
      } 
      return;
    } finally {
      this.zO.unlock();
    } 
  }
  
  public <L> d<L> d(L paramL) {
    jx.b(paramL, "Listener must not be null");
    this.zO.lock();
    try {
      d<L> d = new d<L>(this.JF, paramL);
      this.Kj.add(d);
      return d;
    } finally {
      this.zO.unlock();
    } 
  }
  
  public void disconnect() {
    gM();
    al(-1);
  }
  
  boolean gL() {
    return this.JY;
  }
  
  public Looper getLooper() {
    return this.JF;
  }
  
  public boolean isConnected() {
    return (this.JX == 2);
  }
  
  public boolean isConnecting() {
    return (this.JX == 1);
  }
  
  public boolean isConnectionCallbacksRegistered(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks) {
    return this.JS.isConnectionCallbacksRegistered(paramConnectionCallbacks);
  }
  
  public boolean isConnectionFailedListenerRegistered(GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    return this.JS.isConnectionFailedListenerRegistered(paramOnConnectionFailedListener);
  }
  
  public void reconnect() {
    disconnect();
    connect();
  }
  
  public void registerConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks) {
    this.JS.registerConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void registerConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.JS.registerConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  public void stopAutoManage(FragmentActivity paramFragmentActivity) {
    boolean bool;
    if (this.JT >= 0) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.a(bool, "Called stopAutoManage but automatic lifecycle management is not enabled.");
    g.a(paramFragmentActivity).ao(this.JT);
  }
  
  public void unregisterConnectionCallbacks(GoogleApiClient.ConnectionCallbacks paramConnectionCallbacks) {
    this.JS.unregisterConnectionCallbacks(paramConnectionCallbacks);
  }
  
  public void unregisterConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    this.JS.unregisterConnectionFailedListener(paramOnConnectionFailedListener);
  }
  
  private static class a extends BroadcastReceiver {
    private WeakReference<c> Ks;
    
    a(c param1c) {
      this.Ks = new WeakReference<c>(param1c);
    }
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      String str;
      Uri uri = param1Intent.getData();
      param1Context = null;
      if (uri != null)
        str = uri.getSchemeSpecificPart(); 
      if (str != null && str.equals("com.google.android.gms")) {
        c c = this.Ks.get();
        if (c != null && !c.isConnected() && !c.isConnecting() && c.gL()) {
          c.connect();
          return;
        } 
      } 
    }
  }
  
  static interface b {
    void b(c.d<?> param1d);
  }
  
  private class c extends Handler {
    c(c this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      switch (param1Message.what) {
        default:
          Log.w("GoogleApiClientImpl", "Unknown message id: " + param1Message.what);
          return;
        case 1:
          c.i(this.Kn);
          return;
        case 2:
          break;
      } 
      c.j(this.Kn);
    }
  }
  
  static interface d<A extends Api.a> {
    void a(c.b param1b);
    
    void b(A param1A) throws DeadObjectException;
    
    void cancel();
    
    int gF();
    
    Api.c<A> gz();
    
    void l(Status param1Status);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */