package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.util.Log;
import android.util.SparseArray;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.jx;

public class g extends Fragment implements DialogInterface.OnCancelListener, LoaderManager.LoaderCallbacks<ConnectionResult> {
  private boolean KC;
  
  private int KD = -1;
  
  private ConnectionResult KE;
  
  private final Handler KF = new Handler(Looper.getMainLooper());
  
  private final SparseArray<b> KG = new SparseArray();
  
  public static g a(FragmentActivity paramFragmentActivity) {
    jx.aU("Must be called from main thread of process");
    FragmentManager fragmentManager = paramFragmentActivity.getSupportFragmentManager();
    try {
      g g2 = (g)fragmentManager.findFragmentByTag("GmsSupportLifecycleFragment");
      if (g2 != null) {
        g g3 = g2;
        if (g2.isRemoving()) {
          g3 = new g();
          fragmentManager.beginTransaction().add(g3, "GmsSupportLifecycleFragment").commit();
          fragmentManager.executePendingTransactions();
          return g3;
        } 
        return g3;
      } 
      g g1 = new g();
      fragmentManager.beginTransaction().add(g1, "GmsSupportLifecycleFragment").commit();
      fragmentManager.executePendingTransactions();
      return g1;
    } catch (ClassCastException classCastException) {
      throw new IllegalStateException("Fragment with tag GmsSupportLifecycleFragment is not a SupportLifecycleFragment", classCastException);
    } 
  }
  
  private void a(int paramInt, ConnectionResult paramConnectionResult) {
    if (!this.KC) {
      this.KC = true;
      this.KD = paramInt;
      this.KE = paramConnectionResult;
      this.KF.post(new c(this, paramInt, paramConnectionResult));
    } 
  }
  
  private void aq(int paramInt) {
    if (paramInt == this.KD)
      gR(); 
  }
  
  private void b(int paramInt, ConnectionResult paramConnectionResult) {
    Log.w("GmsSupportLifecycleFragment", "Unresolved error while connecting client. Stopping auto-manage.");
    b b = (b)this.KG.get(paramInt);
    if (b != null) {
      ao(paramInt);
      GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener = b.KK;
      if (onConnectionFailedListener != null)
        onConnectionFailedListener.onConnectionFailed(paramConnectionResult); 
    } 
    gR();
  }
  
  private void gR() {
    int i = 0;
    this.KC = false;
    this.KD = -1;
    this.KE = null;
    LoaderManager loaderManager = getLoaderManager();
    while (i < this.KG.size()) {
      int j = this.KG.keyAt(i);
      a a = ap(j);
      if (a != null)
        a.gS(); 
      loaderManager.initLoader(j, null, this);
      i++;
    } 
  }
  
  public void a(int paramInt, GoogleApiClient paramGoogleApiClient, GoogleApiClient.OnConnectionFailedListener paramOnConnectionFailedListener) {
    boolean bool;
    jx.b(paramGoogleApiClient, "GoogleApiClient instance cannot be null");
    if (this.KG.indexOfKey(paramInt) < 0) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.a(bool, "Already managing a GoogleApiClient with id " + paramInt);
    b b = new b(paramGoogleApiClient, paramOnConnectionFailedListener);
    this.KG.put(paramInt, b);
    if (getActivity() != null)
      getLoaderManager().initLoader(paramInt, null, this); 
  }
  
  public void a(Loader<ConnectionResult> paramLoader, ConnectionResult paramConnectionResult) {
    if (paramConnectionResult.isSuccess()) {
      aq(paramLoader.getId());
      return;
    } 
    a(paramLoader.getId(), paramConnectionResult);
  }
  
  public GoogleApiClient an(int paramInt) {
    if (getActivity() != null) {
      a a = ap(paramInt);
      if (a != null)
        return a.KH; 
    } 
    return null;
  }
  
  public void ao(int paramInt) {
    getLoaderManager().destroyLoader(paramInt);
    this.KG.remove(paramInt);
  }
  
  a ap(int paramInt) {
    try {
      return (a)getLoaderManager().getLoader(paramInt);
    } catch (ClassCastException classCastException) {
      throw new IllegalStateException("Unknown loader in SupportLifecycleFragment", classCastException);
    } 
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #4
    //   3: iload_1
    //   4: tableswitch default -> 28, 1 -> 55, 2 -> 39
    //   28: iconst_0
    //   29: istore_1
    //   30: iload_1
    //   31: ifeq -> 66
    //   34: aload_0
    //   35: invokespecial gR : ()V
    //   38: return
    //   39: aload_0
    //   40: invokevirtual getActivity : ()Landroid/support/v4/app/FragmentActivity;
    //   43: invokestatic isGooglePlayServicesAvailable : (Landroid/content/Context;)I
    //   46: ifne -> 28
    //   49: iload #4
    //   51: istore_1
    //   52: goto -> 30
    //   55: iload_2
    //   56: iconst_m1
    //   57: if_icmpne -> 28
    //   60: iload #4
    //   62: istore_1
    //   63: goto -> 30
    //   66: aload_0
    //   67: aload_0
    //   68: getfield KD : I
    //   71: aload_0
    //   72: getfield KE : Lcom/google/android/gms/common/ConnectionResult;
    //   75: invokespecial b : (ILcom/google/android/gms/common/ConnectionResult;)V
    //   78: return
  }
  
  public void onAttach(Activity paramActivity) {
    super.onAttach(paramActivity);
    for (int i = 0; i < this.KG.size(); i++) {
      int j = this.KG.keyAt(i);
      a a = ap(j);
      if (a != null && ((b)this.KG.valueAt(i)).KH != a.KH) {
        getLoaderManager().restartLoader(j, null, this);
      } else {
        getLoaderManager().initLoader(j, null, this);
      } 
    } 
  }
  
  public void onCancel(DialogInterface paramDialogInterface) {
    b(this.KD, this.KE);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (paramBundle != null) {
      this.KC = paramBundle.getBoolean("resolving_error", false);
      this.KD = paramBundle.getInt("failed_client_id", -1);
      if (this.KD >= 0)
        this.KE = new ConnectionResult(paramBundle.getInt("failed_status"), (PendingIntent)paramBundle.getParcelable("failed_resolution")); 
    } 
  }
  
  public Loader<ConnectionResult> onCreateLoader(int paramInt, Bundle paramBundle) {
    return new a((Context)getActivity(), ((b)this.KG.get(paramInt)).KH);
  }
  
  public void onLoaderReset(Loader<ConnectionResult> paramLoader) {
    if (paramLoader.getId() == this.KD)
      gR(); 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putBoolean("resolving_error", this.KC);
    if (this.KD >= 0) {
      paramBundle.putInt("failed_client_id", this.KD);
      paramBundle.putInt("failed_status", this.KE.getErrorCode());
      paramBundle.putParcelable("failed_resolution", (Parcelable)this.KE.getResolution());
    } 
  }
  
  public void onStart() {
    super.onStart();
    if (!this.KC)
      for (int i = 0; i < this.KG.size(); i++)
        getLoaderManager().initLoader(this.KG.keyAt(i), null, this);  
  }
  
  static class a extends Loader<ConnectionResult> implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    public final GoogleApiClient KH;
    
    private boolean KI;
    
    private ConnectionResult KJ;
    
    public a(Context param1Context, GoogleApiClient param1GoogleApiClient) {
      super(param1Context);
      this.KH = param1GoogleApiClient;
    }
    
    private void a(ConnectionResult param1ConnectionResult) {
      this.KJ = param1ConnectionResult;
      if (isStarted() && !isAbandoned())
        deliverResult(param1ConnectionResult); 
    }
    
    public void gS() {
      if (this.KI) {
        this.KI = false;
        if (isStarted() && !isAbandoned())
          this.KH.connect(); 
      } 
    }
    
    public void onConnected(Bundle param1Bundle) {
      this.KI = false;
      a(ConnectionResult.Iu);
    }
    
    public void onConnectionFailed(ConnectionResult param1ConnectionResult) {
      this.KI = true;
      a(param1ConnectionResult);
    }
    
    public void onConnectionSuspended(int param1Int) {}
    
    protected void onReset() {
      this.KJ = null;
      this.KI = false;
      this.KH.unregisterConnectionCallbacks(this);
      this.KH.unregisterConnectionFailedListener(this);
      this.KH.disconnect();
    }
    
    protected void onStartLoading() {
      super.onStartLoading();
      this.KH.registerConnectionCallbacks(this);
      this.KH.registerConnectionFailedListener(this);
      if (this.KJ != null)
        deliverResult(this.KJ); 
      if (!this.KH.isConnected() && !this.KH.isConnecting() && !this.KI)
        this.KH.connect(); 
    }
    
    protected void onStopLoading() {
      this.KH.disconnect();
    }
  }
  
  private static class b {
    public final GoogleApiClient KH;
    
    public final GoogleApiClient.OnConnectionFailedListener KK;
    
    private b(GoogleApiClient param1GoogleApiClient, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      this.KH = param1GoogleApiClient;
      this.KK = param1OnConnectionFailedListener;
    }
  }
  
  private class c implements Runnable {
    private final int KL;
    
    private final ConnectionResult KM;
    
    public c(g this$0, int param1Int, ConnectionResult param1ConnectionResult) {
      this.KL = param1Int;
      this.KM = param1ConnectionResult;
    }
    
    public void run() {
      if (this.KM.hasResolution())
        try {
          int i = this.KN.getActivity().getSupportFragmentManager().getFragments().indexOf(this.KN);
          this.KM.startResolutionForResult((Activity)this.KN.getActivity(), (i + 1 << 16) + 1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          g.a(this.KN);
          return;
        }  
      if (GooglePlayServicesUtil.isUserRecoverableError(this.KM.getErrorCode())) {
        GooglePlayServicesUtil.showErrorDialogFragment(this.KM.getErrorCode(), (Activity)this.KN.getActivity(), this.KN, 2, this.KN);
        return;
      } 
      g.a(this.KN, this.KL, this.KM);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */