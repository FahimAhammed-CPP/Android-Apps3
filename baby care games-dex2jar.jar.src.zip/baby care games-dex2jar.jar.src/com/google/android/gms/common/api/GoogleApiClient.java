package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.internal.jg;
import com.google.android.gms.internal.jx;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public interface GoogleApiClient {
  <C extends Api.a> C a(Api.c<C> paramc);
  
  <A extends Api.a, R extends Result, T extends BaseImplementation.a<R, A>> T a(T paramT);
  
  boolean a(Scope paramScope);
  
  <A extends Api.a, T extends BaseImplementation.a<? extends Result, A>> T b(T paramT);
  
  ConnectionResult blockingConnect();
  
  ConnectionResult blockingConnect(long paramLong, TimeUnit paramTimeUnit);
  
  PendingResult<Status> clearDefaultAccountAndReconnect();
  
  void connect();
  
  <L> d<L> d(L paramL);
  
  void disconnect();
  
  Looper getLooper();
  
  boolean isConnected();
  
  boolean isConnecting();
  
  boolean isConnectionCallbacksRegistered(ConnectionCallbacks paramConnectionCallbacks);
  
  boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener paramOnConnectionFailedListener);
  
  void reconnect();
  
  void registerConnectionCallbacks(ConnectionCallbacks paramConnectionCallbacks);
  
  void registerConnectionFailedListener(OnConnectionFailedListener paramOnConnectionFailedListener);
  
  void stopAutoManage(FragmentActivity paramFragmentActivity);
  
  void unregisterConnectionCallbacks(ConnectionCallbacks paramConnectionCallbacks);
  
  void unregisterConnectionFailedListener(OnConnectionFailedListener paramOnConnectionFailedListener);
  
  public static final class Builder {
    private String DZ;
    
    private Looper JF;
    
    private final Set<String> JH = new HashSet<String>();
    
    private int JI;
    
    private View JJ;
    
    private String JK;
    
    private final Map<Api<?>, Api.ApiOptions> JL = new HashMap<Api<?>, Api.ApiOptions>();
    
    private FragmentActivity JM;
    
    private int JN = -1;
    
    private GoogleApiClient.OnConnectionFailedListener JO;
    
    private final Set<GoogleApiClient.ConnectionCallbacks> JP = new HashSet<GoogleApiClient.ConnectionCallbacks>();
    
    private final Set<GoogleApiClient.OnConnectionFailedListener> JQ = new HashSet<GoogleApiClient.OnConnectionFailedListener>();
    
    private final Context mContext;
    
    public Builder(Context param1Context) {
      this.mContext = param1Context;
      this.JF = param1Context.getMainLooper();
      this.JK = param1Context.getPackageName();
    }
    
    public Builder(Context param1Context, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      this(param1Context);
      jx.b(param1ConnectionCallbacks, "Must provide a connected listener");
      this.JP.add(param1ConnectionCallbacks);
      jx.b(param1OnConnectionFailedListener, "Must provide a connection failed listener");
      this.JQ.add(param1OnConnectionFailedListener);
    }
    
    private GoogleApiClient gI() {
      g g = g.a(this.JM);
      GoogleApiClient googleApiClient2 = g.an(this.JN);
      GoogleApiClient googleApiClient1 = googleApiClient2;
      if (googleApiClient2 == null)
        googleApiClient1 = new c(this.mContext.getApplicationContext(), this.JF, gH(), this.JL, this.JP, this.JQ, this.JN); 
      g.a(this.JN, googleApiClient1, this.JO);
      return googleApiClient1;
    }
    
    public Builder addApi(Api<? extends Api.ApiOptions.NotRequiredOptions> param1Api) {
      this.JL.put(param1Api, null);
      List<Scope> list = param1Api.gy();
      int j = list.size();
      for (int i = 0; i < j; i++)
        this.JH.add(((Scope)list.get(i)).gO()); 
      return this;
    }
    
    public <O extends Api.ApiOptions.HasOptions> Builder addApi(Api<O> param1Api, O param1O) {
      jx.b(param1O, "Null options are not permitted for this Api");
      this.JL.put(param1Api, (Api.ApiOptions)param1O);
      List<Scope> list = param1Api.gy();
      int j = list.size();
      for (int i = 0; i < j; i++)
        this.JH.add(((Scope)list.get(i)).gO()); 
      return this;
    }
    
    public Builder addConnectionCallbacks(GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks) {
      this.JP.add(param1ConnectionCallbacks);
      return this;
    }
    
    public Builder addOnConnectionFailedListener(GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      this.JQ.add(param1OnConnectionFailedListener);
      return this;
    }
    
    public Builder addScope(Scope param1Scope) {
      this.JH.add(param1Scope.gO());
      return this;
    }
    
    public GoogleApiClient build() {
      boolean bool;
      if (!this.JL.isEmpty()) {
        bool = true;
      } else {
        bool = false;
      } 
      jx.b(bool, "must call addApi() to add at least one API");
      return (this.JN >= 0) ? gI() : new c(this.mContext, this.JF, gH(), this.JL, this.JP, this.JQ, -1);
    }
    
    public Builder enableAutoManage(FragmentActivity param1FragmentActivity, int param1Int, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      if (param1Int >= 0) {
        boolean bool1 = true;
        jx.b(bool1, "clientId must be non-negative");
        this.JN = param1Int;
        this.JM = (FragmentActivity)jx.b(param1FragmentActivity, "Null activity is not permitted.");
        this.JO = param1OnConnectionFailedListener;
        return this;
      } 
      boolean bool = false;
      jx.b(bool, "clientId must be non-negative");
      this.JN = param1Int;
      this.JM = (FragmentActivity)jx.b(param1FragmentActivity, "Null activity is not permitted.");
      this.JO = param1OnConnectionFailedListener;
      return this;
    }
    
    public jg gH() {
      return new jg(this.DZ, this.JH, this.JI, this.JJ, this.JK);
    }
    
    public Builder setAccountName(String param1String) {
      this.DZ = param1String;
      return this;
    }
    
    public Builder setGravityForPopups(int param1Int) {
      this.JI = param1Int;
      return this;
    }
    
    public Builder setHandler(Handler param1Handler) {
      jx.b(param1Handler, "Handler must not be null");
      this.JF = param1Handler.getLooper();
      return this;
    }
    
    public Builder setViewForPopups(View param1View) {
      this.JJ = param1View;
      return this;
    }
    
    public Builder useDefaultAccount() {
      return setAccountName("<<default account>>");
    }
  }
  
  public static interface ConnectionCallbacks {
    public static final int CAUSE_NETWORK_LOST = 2;
    
    public static final int CAUSE_SERVICE_DISCONNECTED = 1;
    
    void onConnected(Bundle param1Bundle);
    
    void onConnectionSuspended(int param1Int);
  }
  
  public static interface OnConnectionFailedListener extends GooglePlayServicesClient.OnConnectionFailedListener {
    void onConnectionFailed(ConnectionResult param1ConnectionResult);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\GoogleApiClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */