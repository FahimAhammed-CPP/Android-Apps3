package com.google.android.gms.common.api;

import com.google.android.gms.internal.jx;
import java.util.concurrent.TimeUnit;

public final class BatchResult implements Result {
  private final Status Eb;
  
  private final PendingResult<?>[] JC;
  
  BatchResult(Status paramStatus, PendingResult<?>[] paramArrayOfPendingResult) {
    this.Eb = paramStatus;
    this.JC = paramArrayOfPendingResult;
  }
  
  public Status getStatus() {
    return this.Eb;
  }
  
  public <R extends Result> R take(BatchResultToken<R> paramBatchResultToken) {
    if (paramBatchResultToken.mId < this.JC.length) {
      boolean bool1 = true;
      jx.b(bool1, "The result token does not belong to this batch");
      return (R)this.JC[paramBatchResultToken.mId].await(0L, TimeUnit.MILLISECONDS);
    } 
    boolean bool = false;
    jx.b(bool, "The result token does not belong to this batch");
    return (R)this.JC[paramBatchResultToken.mId].await(0L, TimeUnit.MILLISECONDS);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\BatchResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */