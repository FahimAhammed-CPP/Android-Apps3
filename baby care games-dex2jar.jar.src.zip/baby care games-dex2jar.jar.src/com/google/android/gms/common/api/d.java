package com.google.android.gms.common.api;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.internal.jx;

public final class d<L> {
  private final a Kt;
  
  private volatile L mListener;
  
  d(Looper paramLooper, L paramL) {
    this.Kt = new a(this, paramLooper);
    this.mListener = (L)jx.b(paramL, "Listener must not be null");
  }
  
  public void a(b<? super L> paramb) {
    jx.b(paramb, "Notifier must not be null");
    Message message = this.Kt.obtainMessage(1, paramb);
    this.Kt.sendMessage(message);
  }
  
  void b(b<? super L> paramb) {
    L l = this.mListener;
    if (l == null) {
      paramb.gG();
      return;
    } 
    try {
      paramb.c(l);
      return;
    } catch (Exception exception) {
      Log.w("ListenerHolder", "Notifying listener failed", exception);
      paramb.gG();
      return;
    } 
  }
  
  public void clear() {
    this.mListener = null;
  }
  
  private final class a extends Handler {
    public a(d this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      boolean bool = true;
      if (param1Message.what != 1)
        bool = false; 
      jx.L(bool);
      this.Ku.b((d.b)param1Message.obj);
    }
  }
  
  public static interface b<L> {
    void c(L param1L);
    
    void gG();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */