package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class StatusCreator implements Parcelable.Creator<Status> {
  public static final int CONTENT_DESCRIPTION = 0;
  
  static void a(Status paramStatus, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramStatus.getStatusCode());
    b.c(paramParcel, 1000, paramStatus.getVersionCode());
    b.a(paramParcel, 2, paramStatus.getStatusMessage(), false);
    b.a(paramParcel, 3, (Parcelable)paramStatus.gP(), paramInt, false);
    b.H(paramParcel, i);
  }
  
  public Status createFromParcel(Parcel paramParcel) {
    PendingIntent pendingIntent = null;
    int j = 0;
    int k = a.G(paramParcel);
    String str = null;
    int i = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.F(paramParcel);
      switch (a.aH(m)) {
        default:
          a.b(paramParcel, m);
          continue;
        case 1:
          j = a.g(paramParcel, m);
          continue;
        case 1000:
          i = a.g(paramParcel, m);
          continue;
        case 2:
          str = a.o(paramParcel, m);
          continue;
        case 3:
          break;
      } 
      pendingIntent = (PendingIntent)a.a(paramParcel, m, PendingIntent.CREATOR);
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new Status(i, j, str, pendingIntent);
  }
  
  public Status[] newArray(int paramInt) {
    return new Status[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\StatusCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */