package com.google.android.gms.common.api;

import java.util.concurrent.TimeUnit;

public interface PendingResult<R extends Result> {
  void a(a parama);
  
  R await();
  
  R await(long paramLong, TimeUnit paramTimeUnit);
  
  void cancel();
  
  boolean isCanceled();
  
  void setResultCallback(ResultCallback<R> paramResultCallback);
  
  void setResultCallback(ResultCallback<R> paramResultCallback, long paramLong, TimeUnit paramTimeUnit);
  
  public static interface a {
    void m(Status param1Status);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\PendingResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */