package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.internal.jg;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class Api<O extends Api.ApiOptions> {
  private final b<?, O> Jm;
  
  private final c<?> Jn;
  
  private final ArrayList<Scope> Jo;
  
  public <C extends a> Api(b<C, O> paramb, c<C> paramc, Scope... paramVarArgs) {
    this.Jm = paramb;
    this.Jn = paramc;
    this.Jo = new ArrayList<Scope>(Arrays.asList(paramVarArgs));
  }
  
  public b<?, O> gx() {
    return this.Jm;
  }
  
  public List<Scope> gy() {
    return this.Jo;
  }
  
  public c<?> gz() {
    return this.Jn;
  }
  
  public static interface ApiOptions {
    public static interface HasOptions extends ApiOptions {}
    
    public static final class NoOptions implements NotRequiredOptions {}
    
    public static interface NotRequiredOptions extends ApiOptions {}
    
    public static interface Optional extends HasOptions, NotRequiredOptions {}
  }
  
  public static interface HasOptions extends ApiOptions {}
  
  public static final class NoOptions implements ApiOptions.NotRequiredOptions {}
  
  public static interface NotRequiredOptions extends ApiOptions {}
  
  public static interface Optional extends ApiOptions.HasOptions, ApiOptions.NotRequiredOptions {}
  
  public static interface a {
    void connect();
    
    void disconnect();
    
    boolean isConnected();
  }
  
  public static interface b<T extends a, O> {
    T a(Context param1Context, Looper param1Looper, jg param1jg, O param1O, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener);
    
    int getPriority();
  }
  
  public static final class c<C extends a> {}
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\Api.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */