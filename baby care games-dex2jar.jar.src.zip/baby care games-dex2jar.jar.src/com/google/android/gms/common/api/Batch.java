package com.google.android.gms.common.api;

import android.os.Looper;
import java.util.ArrayList;
import java.util.List;

public final class Batch extends BaseImplementation.AbstractPendingResult<BatchResult> {
  private boolean JA;
  
  private boolean JB;
  
  private final PendingResult<?>[] JC;
  
  private int Jz;
  
  private final Object mH = new Object();
  
  private Batch(List<PendingResult<?>> paramList, Looper paramLooper) {
    super(new BaseImplementation.CallbackHandler<BatchResult>(paramLooper));
    this.Jz = paramList.size();
    this.JC = (PendingResult<?>[])new PendingResult[this.Jz];
    for (int i = 0; i < paramList.size(); i++) {
      PendingResult<?> pendingResult = paramList.get(i);
      this.JC[i] = pendingResult;
      pendingResult.a(new PendingResult.a(this) {
            public void m(Status param1Status) {
              synchronized (Batch.a(this.JD)) {
                if (this.JD.isCanceled())
                  return; 
                if (param1Status.isCanceled()) {
                  Batch.a(this.JD, true);
                } else if (!param1Status.isSuccess()) {
                  Batch.b(this.JD, true);
                } 
                Batch.b(this.JD);
                if (Batch.c(this.JD) == 0)
                  if (Batch.d(this.JD)) {
                    Batch.e(this.JD);
                  } else {
                    if (Batch.f(this.JD)) {
                      param1Status = new Status(13);
                    } else {
                      param1Status = Status.Kw;
                    } 
                    this.JD.b(new BatchResult(param1Status, (PendingResult<?>[])Batch.g(this.JD)));
                  }  
                return;
              } 
            }
          });
    } 
  }
  
  public void cancel() {
    super.cancel();
    PendingResult<?>[] arrayOfPendingResult = this.JC;
    int j = arrayOfPendingResult.length;
    for (int i = 0; i < j; i++)
      arrayOfPendingResult[i].cancel(); 
  }
  
  public BatchResult createFailedResult(Status paramStatus) {
    return new BatchResult(paramStatus, this.JC);
  }
  
  public static final class Builder {
    private List<PendingResult<?>> JE = new ArrayList<PendingResult<?>>();
    
    private Looper JF;
    
    public Builder(GoogleApiClient param1GoogleApiClient) {
      this.JF = param1GoogleApiClient.getLooper();
    }
    
    public <R extends Result> BatchResultToken<R> add(PendingResult<R> param1PendingResult) {
      BatchResultToken<Result> batchResultToken = new BatchResultToken<Result>(this.JE.size());
      this.JE.add(param1PendingResult);
      return (BatchResultToken)batchResultToken;
    }
    
    public Batch build() {
      return new Batch(this.JE, this.JF);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\api\Batch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */