package com.google.android.gms.common.images;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.jv;
import org.json.JSONException;
import org.json.JSONObject;

public final class WebImage implements SafeParcelable {
  public static final Parcelable.Creator<WebImage> CREATOR = new b();
  
  private final int CK;
  
  private final Uri LU;
  
  private final int li;
  
  private final int lj;
  
  WebImage(int paramInt1, Uri paramUri, int paramInt2, int paramInt3) {
    this.CK = paramInt1;
    this.LU = paramUri;
    this.li = paramInt2;
    this.lj = paramInt3;
  }
  
  public WebImage(Uri paramUri) throws IllegalArgumentException {
    this(paramUri, 0, 0);
  }
  
  public WebImage(Uri paramUri, int paramInt1, int paramInt2) throws IllegalArgumentException {
    this(1, paramUri, paramInt1, paramInt2);
    if (paramUri == null)
      throw new IllegalArgumentException("url cannot be null"); 
    if (paramInt1 < 0 || paramInt2 < 0)
      throw new IllegalArgumentException("width and height must not be negative"); 
  }
  
  public WebImage(JSONObject paramJSONObject) throws IllegalArgumentException {
    this(d(paramJSONObject), paramJSONObject.optInt("width", 0), paramJSONObject.optInt("height", 0));
  }
  
  private static Uri d(JSONObject paramJSONObject) {
    Uri uri = null;
    if (paramJSONObject.has("url"))
      try {
        return Uri.parse(paramJSONObject.getString("url"));
      } catch (JSONException jSONException) {
        return null;
      }  
    return uri;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject == null || !(paramObject instanceof WebImage))
        return false; 
      paramObject = paramObject;
      if (!jv.equal(this.LU, ((WebImage)paramObject).LU) || this.li != ((WebImage)paramObject).li || this.lj != ((WebImage)paramObject).lj)
        return false; 
    } 
    return true;
  }
  
  public int getHeight() {
    return this.lj;
  }
  
  public Uri getUrl() {
    return this.LU;
  }
  
  int getVersionCode() {
    return this.CK;
  }
  
  public int getWidth() {
    return this.li;
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { this.LU, Integer.valueOf(this.li), Integer.valueOf(this.lj) });
  }
  
  public JSONObject toJson() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("url", this.LU.toString());
      jSONObject.put("width", this.li);
      jSONObject.put("height", this.lj);
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
  
  public String toString() {
    return String.format("Image %dx%d %s", new Object[] { Integer.valueOf(this.li), Integer.valueOf(this.lj), this.LU.toString() });
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    b.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\images\WebImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */