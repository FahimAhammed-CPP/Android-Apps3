package com.google.android.gms.common;

import android.os.Bundle;

@Deprecated
public interface GooglePlayServicesClient {
  void connect();
  
  void disconnect();
  
  boolean isConnected();
  
  boolean isConnecting();
  
  boolean isConnectionCallbacksRegistered(ConnectionCallbacks paramConnectionCallbacks);
  
  boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener paramOnConnectionFailedListener);
  
  void registerConnectionCallbacks(ConnectionCallbacks paramConnectionCallbacks);
  
  void registerConnectionFailedListener(OnConnectionFailedListener paramOnConnectionFailedListener);
  
  void unregisterConnectionCallbacks(ConnectionCallbacks paramConnectionCallbacks);
  
  void unregisterConnectionFailedListener(OnConnectionFailedListener paramOnConnectionFailedListener);
  
  @Deprecated
  public static interface ConnectionCallbacks {
    void onConnected(Bundle param1Bundle);
    
    void onDisconnected();
  }
  
  @Deprecated
  public static interface OnConnectionFailedListener {
    void onConnectionFailed(ConnectionResult param1ConnectionResult);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\common\GooglePlayServicesClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */