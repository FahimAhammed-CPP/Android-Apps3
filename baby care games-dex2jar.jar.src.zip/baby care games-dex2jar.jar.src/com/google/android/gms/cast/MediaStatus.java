package com.google.android.gms.cast;

import org.json.JSONException;
import org.json.JSONObject;

public final class MediaStatus {
  public static final long COMMAND_PAUSE = 1L;
  
  public static final long COMMAND_SEEK = 2L;
  
  public static final long COMMAND_SET_VOLUME = 4L;
  
  public static final long COMMAND_SKIP_BACKWARD = 32L;
  
  public static final long COMMAND_SKIP_FORWARD = 16L;
  
  public static final long COMMAND_TOGGLE_MUTE = 8L;
  
  private static final long[] Gs = new long[0];
  
  public static final int IDLE_REASON_CANCELED = 2;
  
  public static final int IDLE_REASON_ERROR = 4;
  
  public static final int IDLE_REASON_FINISHED = 1;
  
  public static final int IDLE_REASON_INTERRUPTED = 3;
  
  public static final int IDLE_REASON_NONE = 0;
  
  public static final int PLAYER_STATE_BUFFERING = 4;
  
  public static final int PLAYER_STATE_IDLE = 1;
  
  public static final int PLAYER_STATE_PAUSED = 3;
  
  public static final int PLAYER_STATE_PLAYING = 2;
  
  public static final int PLAYER_STATE_UNKNOWN = 0;
  
  private JSONObject Ga;
  
  private MediaInfo Gb;
  
  private long Gj;
  
  private double Gk;
  
  private int Gl;
  
  private int Gm;
  
  private long Gn;
  
  private long Go;
  
  private double Gp;
  
  private boolean Gq;
  
  private long[] Gr;
  
  public MediaStatus(JSONObject paramJSONObject) throws JSONException {
    a(paramJSONObject, 0);
  }
  
  public int a(JSONObject paramJSONObject, int paramInt) throws JSONException {
    // Byte code:
    //   0: iconst_2
    //   1: istore #11
    //   3: iconst_0
    //   4: istore #10
    //   6: iconst_1
    //   7: istore #9
    //   9: aload_1
    //   10: ldc 'mediaSessionId'
    //   12: invokevirtual getLong : (Ljava/lang/String;)J
    //   15: lstore #12
    //   17: lload #12
    //   19: aload_0
    //   20: getfield Gj : J
    //   23: lcmp
    //   24: ifeq -> 779
    //   27: aload_0
    //   28: lload #12
    //   30: putfield Gj : J
    //   33: iconst_1
    //   34: istore #6
    //   36: iload #6
    //   38: istore #7
    //   40: aload_1
    //   41: ldc 'playerState'
    //   43: invokevirtual has : (Ljava/lang/String;)Z
    //   46: ifeq -> 165
    //   49: aload_1
    //   50: ldc 'playerState'
    //   52: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   55: astore #15
    //   57: aload #15
    //   59: ldc 'IDLE'
    //   61: invokevirtual equals : (Ljava/lang/Object;)Z
    //   64: ifeq -> 464
    //   67: iconst_1
    //   68: istore #5
    //   70: iload #6
    //   72: istore #8
    //   74: iload #5
    //   76: aload_0
    //   77: getfield Gl : I
    //   80: if_icmpeq -> 95
    //   83: aload_0
    //   84: iload #5
    //   86: putfield Gl : I
    //   89: iload #6
    //   91: iconst_2
    //   92: ior
    //   93: istore #8
    //   95: iload #8
    //   97: istore #7
    //   99: iload #5
    //   101: iconst_1
    //   102: if_icmpne -> 165
    //   105: iload #8
    //   107: istore #7
    //   109: aload_1
    //   110: ldc 'idleReason'
    //   112: invokevirtual has : (Ljava/lang/String;)Z
    //   115: ifeq -> 165
    //   118: aload_1
    //   119: ldc 'idleReason'
    //   121: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   124: astore #15
    //   126: aload #15
    //   128: ldc 'CANCELLED'
    //   130: invokevirtual equals : (Ljava/lang/Object;)Z
    //   133: ifeq -> 512
    //   136: iload #11
    //   138: istore #5
    //   140: iload #8
    //   142: istore #7
    //   144: iload #5
    //   146: aload_0
    //   147: getfield Gm : I
    //   150: if_icmpeq -> 165
    //   153: aload_0
    //   154: iload #5
    //   156: putfield Gm : I
    //   159: iload #8
    //   161: iconst_2
    //   162: ior
    //   163: istore #7
    //   165: iload #7
    //   167: istore #5
    //   169: aload_1
    //   170: ldc 'playbackRate'
    //   172: invokevirtual has : (Ljava/lang/String;)Z
    //   175: ifeq -> 209
    //   178: aload_1
    //   179: ldc 'playbackRate'
    //   181: invokevirtual getDouble : (Ljava/lang/String;)D
    //   184: dstore_3
    //   185: iload #7
    //   187: istore #5
    //   189: aload_0
    //   190: getfield Gk : D
    //   193: dload_3
    //   194: dcmpl
    //   195: ifeq -> 209
    //   198: aload_0
    //   199: dload_3
    //   200: putfield Gk : D
    //   203: iload #7
    //   205: iconst_2
    //   206: ior
    //   207: istore #5
    //   209: iload #5
    //   211: istore #7
    //   213: aload_1
    //   214: ldc 'currentTime'
    //   216: invokevirtual has : (Ljava/lang/String;)Z
    //   219: ifeq -> 269
    //   222: iload #5
    //   224: istore #7
    //   226: iload_2
    //   227: iconst_2
    //   228: iand
    //   229: ifne -> 269
    //   232: aload_1
    //   233: ldc 'currentTime'
    //   235: invokevirtual getDouble : (Ljava/lang/String;)D
    //   238: invokestatic b : (D)J
    //   241: lstore #12
    //   243: iload #5
    //   245: istore #7
    //   247: lload #12
    //   249: aload_0
    //   250: getfield Gn : J
    //   253: lcmp
    //   254: ifeq -> 269
    //   257: aload_0
    //   258: lload #12
    //   260: putfield Gn : J
    //   263: iload #5
    //   265: iconst_2
    //   266: ior
    //   267: istore #7
    //   269: iload #7
    //   271: istore #6
    //   273: aload_1
    //   274: ldc 'supportedMediaCommands'
    //   276: invokevirtual has : (Ljava/lang/String;)Z
    //   279: ifeq -> 316
    //   282: aload_1
    //   283: ldc 'supportedMediaCommands'
    //   285: invokevirtual getLong : (Ljava/lang/String;)J
    //   288: lstore #12
    //   290: iload #7
    //   292: istore #6
    //   294: lload #12
    //   296: aload_0
    //   297: getfield Go : J
    //   300: lcmp
    //   301: ifeq -> 316
    //   304: aload_0
    //   305: lload #12
    //   307: putfield Go : J
    //   310: iload #7
    //   312: iconst_2
    //   313: ior
    //   314: istore #6
    //   316: iload #6
    //   318: istore #5
    //   320: aload_1
    //   321: ldc 'volume'
    //   323: invokevirtual has : (Ljava/lang/String;)Z
    //   326: ifeq -> 409
    //   329: iload #6
    //   331: istore #5
    //   333: iload_2
    //   334: iconst_1
    //   335: iand
    //   336: ifne -> 409
    //   339: aload_1
    //   340: ldc 'volume'
    //   342: invokevirtual getJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   345: astore #15
    //   347: aload #15
    //   349: ldc 'level'
    //   351: invokevirtual getDouble : (Ljava/lang/String;)D
    //   354: dstore_3
    //   355: iload #6
    //   357: istore_2
    //   358: dload_3
    //   359: aload_0
    //   360: getfield Gp : D
    //   363: dcmpl
    //   364: ifeq -> 377
    //   367: aload_0
    //   368: dload_3
    //   369: putfield Gp : D
    //   372: iload #6
    //   374: iconst_2
    //   375: ior
    //   376: istore_2
    //   377: aload #15
    //   379: ldc 'muted'
    //   381: invokevirtual getBoolean : (Ljava/lang/String;)Z
    //   384: istore #14
    //   386: iload_2
    //   387: istore #5
    //   389: iload #14
    //   391: aload_0
    //   392: getfield Gq : Z
    //   395: if_icmpeq -> 409
    //   398: aload_0
    //   399: iload #14
    //   401: putfield Gq : Z
    //   404: iload_2
    //   405: iconst_2
    //   406: ior
    //   407: istore #5
    //   409: aload_1
    //   410: ldc 'activeTrackIds'
    //   412: invokevirtual has : (Ljava/lang/String;)Z
    //   415: ifeq -> 736
    //   418: aload_1
    //   419: ldc 'activeTrackIds'
    //   421: invokevirtual getJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   424: astore #16
    //   426: aload #16
    //   428: invokevirtual length : ()I
    //   431: istore #7
    //   433: iload #7
    //   435: newarray long
    //   437: astore #15
    //   439: iconst_0
    //   440: istore_2
    //   441: iload_2
    //   442: iload #7
    //   444: if_icmpge -> 560
    //   447: aload #15
    //   449: iload_2
    //   450: aload #16
    //   452: iload_2
    //   453: invokevirtual getLong : (I)J
    //   456: lastore
    //   457: iload_2
    //   458: iconst_1
    //   459: iadd
    //   460: istore_2
    //   461: goto -> 441
    //   464: aload #15
    //   466: ldc 'PLAYING'
    //   468: invokevirtual equals : (Ljava/lang/Object;)Z
    //   471: ifeq -> 480
    //   474: iconst_2
    //   475: istore #5
    //   477: goto -> 70
    //   480: aload #15
    //   482: ldc 'PAUSED'
    //   484: invokevirtual equals : (Ljava/lang/Object;)Z
    //   487: ifeq -> 496
    //   490: iconst_3
    //   491: istore #5
    //   493: goto -> 70
    //   496: aload #15
    //   498: ldc 'BUFFERING'
    //   500: invokevirtual equals : (Ljava/lang/Object;)Z
    //   503: ifeq -> 773
    //   506: iconst_4
    //   507: istore #5
    //   509: goto -> 70
    //   512: aload #15
    //   514: ldc 'INTERRUPTED'
    //   516: invokevirtual equals : (Ljava/lang/Object;)Z
    //   519: ifeq -> 528
    //   522: iconst_3
    //   523: istore #5
    //   525: goto -> 140
    //   528: aload #15
    //   530: ldc 'FINISHED'
    //   532: invokevirtual equals : (Ljava/lang/Object;)Z
    //   535: ifeq -> 544
    //   538: iconst_1
    //   539: istore #5
    //   541: goto -> 140
    //   544: aload #15
    //   546: ldc 'ERROR'
    //   548: invokevirtual equals : (Ljava/lang/Object;)Z
    //   551: ifeq -> 767
    //   554: iconst_4
    //   555: istore #5
    //   557: goto -> 140
    //   560: aload_0
    //   561: getfield Gr : [J
    //   564: ifnonnull -> 685
    //   567: iload #9
    //   569: istore_2
    //   570: iload_2
    //   571: ifeq -> 580
    //   574: aload_0
    //   575: aload #15
    //   577: putfield Gr : [J
    //   580: iload_2
    //   581: istore #6
    //   583: iload #5
    //   585: istore_2
    //   586: iload #6
    //   588: ifeq -> 602
    //   591: aload_0
    //   592: aload #15
    //   594: putfield Gr : [J
    //   597: iload #5
    //   599: iconst_2
    //   600: ior
    //   601: istore_2
    //   602: iload_2
    //   603: istore #5
    //   605: aload_1
    //   606: ldc 'customData'
    //   608: invokevirtual has : (Ljava/lang/String;)Z
    //   611: ifeq -> 629
    //   614: aload_0
    //   615: aload_1
    //   616: ldc 'customData'
    //   618: invokevirtual getJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   621: putfield Ga : Lorg/json/JSONObject;
    //   624: iload_2
    //   625: iconst_2
    //   626: ior
    //   627: istore #5
    //   629: iload #5
    //   631: istore_2
    //   632: aload_1
    //   633: ldc 'media'
    //   635: invokevirtual has : (Ljava/lang/String;)Z
    //   638: ifeq -> 683
    //   641: aload_1
    //   642: ldc 'media'
    //   644: invokevirtual getJSONObject : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   647: astore_1
    //   648: aload_0
    //   649: new com/google/android/gms/cast/MediaInfo
    //   652: dup
    //   653: aload_1
    //   654: invokespecial <init> : (Lorg/json/JSONObject;)V
    //   657: putfield Gb : Lcom/google/android/gms/cast/MediaInfo;
    //   660: iload #5
    //   662: iconst_2
    //   663: ior
    //   664: istore #5
    //   666: iload #5
    //   668: istore_2
    //   669: aload_1
    //   670: ldc 'metadata'
    //   672: invokevirtual has : (Ljava/lang/String;)Z
    //   675: ifeq -> 683
    //   678: iload #5
    //   680: iconst_4
    //   681: ior
    //   682: istore_2
    //   683: iload_2
    //   684: ireturn
    //   685: iload #9
    //   687: istore_2
    //   688: aload_0
    //   689: getfield Gr : [J
    //   692: arraylength
    //   693: iload #7
    //   695: if_icmpne -> 570
    //   698: iconst_0
    //   699: istore #6
    //   701: iload #6
    //   703: iload #7
    //   705: if_icmpge -> 762
    //   708: iload #9
    //   710: istore_2
    //   711: aload_0
    //   712: getfield Gr : [J
    //   715: iload #6
    //   717: laload
    //   718: aload #15
    //   720: iload #6
    //   722: laload
    //   723: lcmp
    //   724: ifne -> 570
    //   727: iload #6
    //   729: iconst_1
    //   730: iadd
    //   731: istore #6
    //   733: goto -> 701
    //   736: aload_0
    //   737: getfield Gr : [J
    //   740: ifnull -> 752
    //   743: iconst_1
    //   744: istore #6
    //   746: aconst_null
    //   747: astore #15
    //   749: goto -> 583
    //   752: aconst_null
    //   753: astore #15
    //   755: iload #10
    //   757: istore #6
    //   759: goto -> 583
    //   762: iconst_0
    //   763: istore_2
    //   764: goto -> 570
    //   767: iconst_0
    //   768: istore #5
    //   770: goto -> 140
    //   773: iconst_0
    //   774: istore #5
    //   776: goto -> 70
    //   779: iconst_0
    //   780: istore #6
    //   782: goto -> 36
  }
  
  public long fR() {
    return this.Gj;
  }
  
  public long[] getActiveTrackIds() {
    return (this.Gr != null) ? this.Gr : Gs;
  }
  
  public JSONObject getCustomData() {
    return this.Ga;
  }
  
  public int getIdleReason() {
    return this.Gm;
  }
  
  public MediaInfo getMediaInfo() {
    return this.Gb;
  }
  
  public double getPlaybackRate() {
    return this.Gk;
  }
  
  public int getPlayerState() {
    return this.Gl;
  }
  
  public long getStreamPosition() {
    return this.Gn;
  }
  
  public double getStreamVolume() {
    return this.Gp;
  }
  
  public boolean isMediaCommandSupported(long paramLong) {
    return ((this.Go & paramLong) != 0L);
  }
  
  public boolean isMute() {
    return this.Gq;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\cast\MediaStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */