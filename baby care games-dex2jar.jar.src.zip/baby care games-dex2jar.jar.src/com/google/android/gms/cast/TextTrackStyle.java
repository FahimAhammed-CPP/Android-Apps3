package com.google.android.gms.cast;

import android.content.Context;
import android.graphics.Color;
import com.google.android.gms.internal.jv;
import org.json.JSONException;
import org.json.JSONObject;

public final class TextTrackStyle {
  public static final int COLOR_UNSPECIFIED = 0;
  
  public static final float DEFAULT_FONT_SCALE = 1.0F;
  
  public static final int EDGE_TYPE_DEPRESSED = 4;
  
  public static final int EDGE_TYPE_DROP_SHADOW = 2;
  
  public static final int EDGE_TYPE_NONE = 0;
  
  public static final int EDGE_TYPE_OUTLINE = 1;
  
  public static final int EDGE_TYPE_RAISED = 3;
  
  public static final int EDGE_TYPE_UNSPECIFIED = -1;
  
  public static final int FONT_FAMILY_CASUAL = 4;
  
  public static final int FONT_FAMILY_CURSIVE = 5;
  
  public static final int FONT_FAMILY_MONOSPACED_SANS_SERIF = 1;
  
  public static final int FONT_FAMILY_MONOSPACED_SERIF = 3;
  
  public static final int FONT_FAMILY_SANS_SERIF = 0;
  
  public static final int FONT_FAMILY_SERIF = 2;
  
  public static final int FONT_FAMILY_SMALL_CAPITALS = 6;
  
  public static final int FONT_FAMILY_UNSPECIFIED = -1;
  
  public static final int FONT_STYLE_BOLD = 1;
  
  public static final int FONT_STYLE_BOLD_ITALIC = 3;
  
  public static final int FONT_STYLE_ITALIC = 2;
  
  public static final int FONT_STYLE_NORMAL = 0;
  
  public static final int FONT_STYLE_UNSPECIFIED = -1;
  
  public static final int WINDOW_TYPE_NONE = 0;
  
  public static final int WINDOW_TYPE_NORMAL = 1;
  
  public static final int WINDOW_TYPE_ROUNDED = 2;
  
  public static final int WINDOW_TYPE_UNSPECIFIED = -1;
  
  private float GT;
  
  private int GU;
  
  private int GV;
  
  private int GW;
  
  private int GX;
  
  private int GY;
  
  private int GZ;
  
  private JSONObject Ga;
  
  private String Ha;
  
  private int Hb;
  
  private int Hc;
  
  private int xB;
  
  public TextTrackStyle() {
    clear();
  }
  
  private int aC(String paramString) {
    int j = 0;
    int i = j;
    if (paramString != null) {
      i = j;
      if (paramString.length() == 9) {
        i = j;
        if (paramString.charAt(0) == '#')
          try {
            i = Integer.parseInt(paramString.substring(1, 3), 16);
            j = Integer.parseInt(paramString.substring(3, 5), 16);
            int k = Integer.parseInt(paramString.substring(5, 7), 16);
            return Color.argb(Integer.parseInt(paramString.substring(7, 9), 16), i, j, k);
          } catch (NumberFormatException numberFormatException) {
            return 0;
          }  
      } 
    } 
    return i;
  }
  
  private void clear() {
    this.GT = 1.0F;
    this.GU = 0;
    this.xB = 0;
    this.GV = -1;
    this.GW = 0;
    this.GX = -1;
    this.GY = 0;
    this.GZ = 0;
    this.Ha = null;
    this.Hb = -1;
    this.Hc = -1;
    this.Ga = null;
  }
  
  public static TextTrackStyle fromSystemSettings(Context paramContext) {
    // Byte code:
    //   0: new com/google/android/gms/cast/TextTrackStyle
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_3
    //   8: invokestatic im : ()Z
    //   11: ifne -> 16
    //   14: aload_3
    //   15: areturn
    //   16: aload_0
    //   17: ldc 'captioning'
    //   19: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   22: checkcast android/view/accessibility/CaptioningManager
    //   25: astore_0
    //   26: aload_3
    //   27: aload_0
    //   28: invokevirtual getFontScale : ()F
    //   31: invokevirtual setFontScale : (F)V
    //   34: aload_0
    //   35: invokevirtual getUserStyle : ()Landroid/view/accessibility/CaptioningManager$CaptionStyle;
    //   38: astore_0
    //   39: aload_3
    //   40: aload_0
    //   41: getfield backgroundColor : I
    //   44: invokevirtual setBackgroundColor : (I)V
    //   47: aload_3
    //   48: aload_0
    //   49: getfield foregroundColor : I
    //   52: invokevirtual setForegroundColor : (I)V
    //   55: aload_0
    //   56: getfield edgeType : I
    //   59: tableswitch default -> 80, 1 -> 142, 2 -> 150
    //   80: aload_3
    //   81: iconst_0
    //   82: invokevirtual setEdgeType : (I)V
    //   85: aload_3
    //   86: aload_0
    //   87: getfield edgeColor : I
    //   90: invokevirtual setEdgeColor : (I)V
    //   93: aload_0
    //   94: invokevirtual getTypeface : ()Landroid/graphics/Typeface;
    //   97: astore_0
    //   98: aload_0
    //   99: ifnull -> 140
    //   102: getstatic android/graphics/Typeface.MONOSPACE : Landroid/graphics/Typeface;
    //   105: aload_0
    //   106: invokevirtual equals : (Ljava/lang/Object;)Z
    //   109: ifeq -> 158
    //   112: aload_3
    //   113: iconst_1
    //   114: invokevirtual setFontGenericFamily : (I)V
    //   117: aload_0
    //   118: invokevirtual isBold : ()Z
    //   121: istore_1
    //   122: aload_0
    //   123: invokevirtual isItalic : ()Z
    //   126: istore_2
    //   127: iload_1
    //   128: ifeq -> 202
    //   131: iload_2
    //   132: ifeq -> 202
    //   135: aload_3
    //   136: iconst_3
    //   137: invokevirtual setFontStyle : (I)V
    //   140: aload_3
    //   141: areturn
    //   142: aload_3
    //   143: iconst_1
    //   144: invokevirtual setEdgeType : (I)V
    //   147: goto -> 85
    //   150: aload_3
    //   151: iconst_2
    //   152: invokevirtual setEdgeType : (I)V
    //   155: goto -> 85
    //   158: getstatic android/graphics/Typeface.SANS_SERIF : Landroid/graphics/Typeface;
    //   161: aload_0
    //   162: invokevirtual equals : (Ljava/lang/Object;)Z
    //   165: ifeq -> 176
    //   168: aload_3
    //   169: iconst_0
    //   170: invokevirtual setFontGenericFamily : (I)V
    //   173: goto -> 117
    //   176: getstatic android/graphics/Typeface.SERIF : Landroid/graphics/Typeface;
    //   179: aload_0
    //   180: invokevirtual equals : (Ljava/lang/Object;)Z
    //   183: ifeq -> 194
    //   186: aload_3
    //   187: iconst_2
    //   188: invokevirtual setFontGenericFamily : (I)V
    //   191: goto -> 117
    //   194: aload_3
    //   195: iconst_0
    //   196: invokevirtual setFontGenericFamily : (I)V
    //   199: goto -> 117
    //   202: iload_1
    //   203: ifeq -> 214
    //   206: aload_3
    //   207: iconst_1
    //   208: invokevirtual setFontStyle : (I)V
    //   211: goto -> 140
    //   214: iload_2
    //   215: ifeq -> 226
    //   218: aload_3
    //   219: iconst_2
    //   220: invokevirtual setFontStyle : (I)V
    //   223: goto -> 140
    //   226: aload_3
    //   227: iconst_0
    //   228: invokevirtual setFontStyle : (I)V
    //   231: goto -> 140
  }
  
  private String u(int paramInt) {
    return String.format("#%02X%02X%02X%02X", new Object[] { Integer.valueOf(Color.red(paramInt)), Integer.valueOf(Color.green(paramInt)), Integer.valueOf(Color.blue(paramInt)), Integer.valueOf(Color.alpha(paramInt)) });
  }
  
  public void c(JSONObject paramJSONObject) throws JSONException {
    clear();
    this.GT = (float)paramJSONObject.optDouble("fontScale", 1.0D);
    this.GU = aC(paramJSONObject.optString("foregroundColor"));
    this.xB = aC(paramJSONObject.optString("backgroundColor"));
    if (paramJSONObject.has("edgeType")) {
      String str = paramJSONObject.getString("edgeType");
      if ("NONE".equals(str)) {
        this.GV = 0;
      } else if ("OUTLINE".equals(str)) {
        this.GV = 1;
      } else if ("DROP_SHADOW".equals(str)) {
        this.GV = 2;
      } else if ("RAISED".equals(str)) {
        this.GV = 3;
      } else if ("DEPRESSED".equals(str)) {
        this.GV = 4;
      } 
    } 
    this.GW = aC(paramJSONObject.optString("edgeColor"));
    if (paramJSONObject.has("windowType")) {
      String str = paramJSONObject.getString("windowType");
      if ("NONE".equals(str)) {
        this.GX = 0;
      } else if ("NORMAL".equals(str)) {
        this.GX = 1;
      } else if ("ROUNDED_CORNERS".equals(str)) {
        this.GX = 2;
      } 
    } 
    this.GY = aC(paramJSONObject.optString("windowColor"));
    if (this.GX == 2)
      this.GZ = paramJSONObject.optInt("windowRoundedCornerRadius", 0); 
    this.Ha = paramJSONObject.optString("fontFamily", null);
    if (paramJSONObject.has("fontGenericFamily")) {
      String str = paramJSONObject.getString("fontGenericFamily");
      if ("SANS_SERIF".equals(str)) {
        this.Hb = 0;
      } else if ("MONOSPACED_SANS_SERIF".equals(str)) {
        this.Hb = 1;
      } else if ("SERIF".equals(str)) {
        this.Hb = 2;
      } else if ("MONOSPACED_SERIF".equals(str)) {
        this.Hb = 3;
      } else if ("CASUAL".equals(str)) {
        this.Hb = 4;
      } else if ("CURSIVE".equals(str)) {
        this.Hb = 5;
      } else if ("SMALL_CAPITALS".equals(str)) {
        this.Hb = 6;
      } 
    } 
    if (paramJSONObject.has("fontStyle")) {
      String str = paramJSONObject.getString("fontStyle");
      if ("NORMAL".equals(str)) {
        this.Hc = 0;
      } else if ("BOLD".equals(str)) {
        this.Hc = 1;
      } else if ("ITALIC".equals(str)) {
        this.Hc = 2;
      } else if ("BOLD_ITALIC".equals(str)) {
        this.Hc = 3;
      } 
    } 
    this.Ga = paramJSONObject.optJSONObject("customData");
  }
  
  public boolean equals(Object paramObject) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #5
    //   3: iconst_0
    //   4: istore #6
    //   6: aload_0
    //   7: aload_1
    //   8: if_acmpne -> 17
    //   11: iconst_1
    //   12: istore #4
    //   14: iload #4
    //   16: ireturn
    //   17: iload #6
    //   19: istore #4
    //   21: aload_1
    //   22: instanceof com/google/android/gms/cast/TextTrackStyle
    //   25: ifeq -> 14
    //   28: aload_1
    //   29: checkcast com/google/android/gms/cast/TextTrackStyle
    //   32: astore_1
    //   33: aload_0
    //   34: getfield Ga : Lorg/json/JSONObject;
    //   37: ifnonnull -> 213
    //   40: iconst_1
    //   41: istore_2
    //   42: aload_1
    //   43: getfield Ga : Lorg/json/JSONObject;
    //   46: ifnonnull -> 218
    //   49: iconst_1
    //   50: istore_3
    //   51: iload #6
    //   53: istore #4
    //   55: iload_2
    //   56: iload_3
    //   57: if_icmpne -> 14
    //   60: aload_0
    //   61: getfield Ga : Lorg/json/JSONObject;
    //   64: ifnull -> 92
    //   67: aload_1
    //   68: getfield Ga : Lorg/json/JSONObject;
    //   71: ifnull -> 92
    //   74: iload #6
    //   76: istore #4
    //   78: aload_0
    //   79: getfield Ga : Lorg/json/JSONObject;
    //   82: aload_1
    //   83: getfield Ga : Lorg/json/JSONObject;
    //   86: invokestatic d : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   89: ifeq -> 14
    //   92: aload_0
    //   93: getfield GT : F
    //   96: aload_1
    //   97: getfield GT : F
    //   100: fcmpl
    //   101: ifne -> 223
    //   104: aload_0
    //   105: getfield GU : I
    //   108: aload_1
    //   109: getfield GU : I
    //   112: if_icmpne -> 223
    //   115: aload_0
    //   116: getfield xB : I
    //   119: aload_1
    //   120: getfield xB : I
    //   123: if_icmpne -> 223
    //   126: aload_0
    //   127: getfield GV : I
    //   130: aload_1
    //   131: getfield GV : I
    //   134: if_icmpne -> 223
    //   137: aload_0
    //   138: getfield GW : I
    //   141: aload_1
    //   142: getfield GW : I
    //   145: if_icmpne -> 223
    //   148: aload_0
    //   149: getfield GX : I
    //   152: aload_1
    //   153: getfield GX : I
    //   156: if_icmpne -> 223
    //   159: aload_0
    //   160: getfield GZ : I
    //   163: aload_1
    //   164: getfield GZ : I
    //   167: if_icmpne -> 223
    //   170: aload_0
    //   171: getfield Ha : Ljava/lang/String;
    //   174: aload_1
    //   175: getfield Ha : Ljava/lang/String;
    //   178: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   181: ifeq -> 223
    //   184: aload_0
    //   185: getfield Hb : I
    //   188: aload_1
    //   189: getfield Hb : I
    //   192: if_icmpne -> 223
    //   195: aload_0
    //   196: getfield Hc : I
    //   199: aload_1
    //   200: getfield Hc : I
    //   203: if_icmpne -> 223
    //   206: iload #5
    //   208: istore #4
    //   210: iload #4
    //   212: ireturn
    //   213: iconst_0
    //   214: istore_2
    //   215: goto -> 42
    //   218: iconst_0
    //   219: istore_3
    //   220: goto -> 51
    //   223: iconst_0
    //   224: istore #4
    //   226: goto -> 210
  }
  
  public int getBackgroundColor() {
    return this.xB;
  }
  
  public JSONObject getCustomData() {
    return this.Ga;
  }
  
  public int getEdgeColor() {
    return this.GW;
  }
  
  public int getEdgeType() {
    return this.GV;
  }
  
  public String getFontFamily() {
    return this.Ha;
  }
  
  public int getFontGenericFamily() {
    return this.Hb;
  }
  
  public float getFontScale() {
    return this.GT;
  }
  
  public int getFontStyle() {
    return this.Hc;
  }
  
  public int getForegroundColor() {
    return this.GU;
  }
  
  public int getWindowColor() {
    return this.GY;
  }
  
  public int getWindowCornerRadius() {
    return this.GZ;
  }
  
  public int getWindowType() {
    return this.GX;
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { 
          Float.valueOf(this.GT), Integer.valueOf(this.GU), Integer.valueOf(this.xB), Integer.valueOf(this.GV), Integer.valueOf(this.GW), Integer.valueOf(this.GX), Integer.valueOf(this.GY), Integer.valueOf(this.GZ), this.Ha, Integer.valueOf(this.Hb), 
          Integer.valueOf(this.Hc), this.Ga });
  }
  
  public void setBackgroundColor(int paramInt) {
    this.xB = paramInt;
  }
  
  public void setCustomData(JSONObject paramJSONObject) {
    this.Ga = paramJSONObject;
  }
  
  public void setEdgeColor(int paramInt) {
    this.GW = paramInt;
  }
  
  public void setEdgeType(int paramInt) {
    if (paramInt < 0 || paramInt > 4)
      throw new IllegalArgumentException("invalid edgeType"); 
    this.GV = paramInt;
  }
  
  public void setFontFamily(String paramString) {
    this.Ha = paramString;
  }
  
  public void setFontGenericFamily(int paramInt) {
    if (paramInt < 0 || paramInt > 6)
      throw new IllegalArgumentException("invalid fontGenericFamily"); 
    this.Hb = paramInt;
  }
  
  public void setFontScale(float paramFloat) {
    this.GT = paramFloat;
  }
  
  public void setFontStyle(int paramInt) {
    if (paramInt < 0 || paramInt > 3)
      throw new IllegalArgumentException("invalid fontStyle"); 
    this.Hc = paramInt;
  }
  
  public void setForegroundColor(int paramInt) {
    this.GU = paramInt;
  }
  
  public void setWindowColor(int paramInt) {
    this.GY = paramInt;
  }
  
  public void setWindowCornerRadius(int paramInt) {
    if (paramInt < 0)
      throw new IllegalArgumentException("invalid windowCornerRadius"); 
    this.GZ = paramInt;
  }
  
  public void setWindowType(int paramInt) {
    if (paramInt < 0 || paramInt > 2)
      throw new IllegalArgumentException("invalid windowType"); 
    this.GX = paramInt;
  }
  
  public JSONObject toJson() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("fontScale", this.GT);
      if (this.GU != 0)
        jSONObject.put("foregroundColor", u(this.GU)); 
      if (this.xB != 0)
        jSONObject.put("backgroundColor", u(this.xB)); 
      switch (this.GV) {
        case 0:
          jSONObject.put("edgeType", "NONE");
          break;
        case 1:
          jSONObject.put("edgeType", "OUTLINE");
          break;
        case 2:
          jSONObject.put("edgeType", "DROP_SHADOW");
          break;
        case 3:
          jSONObject.put("edgeType", "RAISED");
          break;
        case 4:
          jSONObject.put("edgeType", "DEPRESSED");
          break;
      } 
      if (this.GW != 0)
        jSONObject.put("edgeColor", u(this.GW)); 
      switch (this.GX) {
        case 0:
          jSONObject.put("windowType", "NONE");
          break;
        case 1:
          jSONObject.put("windowType", "NORMAL");
          break;
        case 2:
          jSONObject.put("windowType", "ROUNDED_CORNERS");
          break;
      } 
      if (this.GY != 0)
        jSONObject.put("windowColor", u(this.GY)); 
      if (this.GX == 2)
        jSONObject.put("windowRoundedCornerRadius", this.GZ); 
      if (this.Ha != null)
        jSONObject.put("fontFamily", this.Ha); 
      switch (this.Hb) {
        case 0:
          jSONObject.put("fontGenericFamily", "SANS_SERIF");
          break;
        case 1:
          jSONObject.put("fontGenericFamily", "MONOSPACED_SANS_SERIF");
          break;
        case 2:
          jSONObject.put("fontGenericFamily", "SERIF");
          break;
        case 3:
          jSONObject.put("fontGenericFamily", "MONOSPACED_SERIF");
          break;
        case 4:
          jSONObject.put("fontGenericFamily", "CASUAL");
          break;
        case 5:
          jSONObject.put("fontGenericFamily", "CURSIVE");
          break;
        case 6:
          jSONObject.put("fontGenericFamily", "SMALL_CAPITALS");
          break;
      } 
      switch (this.Hc) {
        case 0:
          jSONObject.put("fontStyle", "NORMAL");
          break;
        case 1:
          jSONObject.put("fontStyle", "BOLD");
          break;
        case 2:
          jSONObject.put("fontStyle", "ITALIC");
          break;
        case 3:
          jSONObject.put("fontStyle", "BOLD_ITALIC");
          break;
      } 
      if (this.Ga != null) {
        jSONObject.put("customData", this.Ga);
        return jSONObject;
      } 
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\cast\TextTrackStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */