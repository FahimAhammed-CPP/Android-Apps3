package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class c implements Parcelable.Creator<LaunchOptions> {
  static void a(LaunchOptions paramLaunchOptions, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramLaunchOptions.getVersionCode());
    b.a(paramParcel, 2, paramLaunchOptions.getRelaunchIfRunning());
    b.a(paramParcel, 3, paramLaunchOptions.getLanguage(), false);
    b.H(paramParcel, paramInt);
  }
  
  public LaunchOptions[] aa(int paramInt) {
    return new LaunchOptions[paramInt];
  }
  
  public LaunchOptions w(Parcel paramParcel) {
    boolean bool = false;
    int j = a.G(paramParcel);
    String str = null;
    int i = 0;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          bool = a.c(paramParcel, k);
          break;
        case 3:
          str = a.o(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new LaunchOptions(i, bool, str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\cast\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */