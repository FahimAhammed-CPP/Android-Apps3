package com.google.android.gms.cast;

import android.text.TextUtils;
import com.google.android.gms.internal.in;
import com.google.android.gms.internal.jv;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public final class MediaTrack {
  public static final int SUBTYPE_CAPTIONS = 2;
  
  public static final int SUBTYPE_CHAPTERS = 4;
  
  public static final int SUBTYPE_DESCRIPTIONS = 3;
  
  public static final int SUBTYPE_METADATA = 5;
  
  public static final int SUBTYPE_NONE = 0;
  
  public static final int SUBTYPE_SUBTITLES = 1;
  
  public static final int SUBTYPE_UNKNOWN = -1;
  
  public static final int TYPE_AUDIO = 2;
  
  public static final int TYPE_TEXT = 1;
  
  public static final int TYPE_UNKNOWN = 0;
  
  public static final int TYPE_VIDEO = 3;
  
  private long Eg;
  
  private String FR;
  
  private String FT;
  
  private String FV;
  
  private JSONObject Ga;
  
  private int Gt;
  
  private int Gu;
  
  private String mName;
  
  MediaTrack(long paramLong, int paramInt) throws IllegalArgumentException {
    clear();
    this.Eg = paramLong;
    if (paramInt <= 0 || paramInt > 3)
      throw new IllegalArgumentException("invalid type " + paramInt); 
    this.Gt = paramInt;
  }
  
  MediaTrack(JSONObject paramJSONObject) throws JSONException {
    c(paramJSONObject);
  }
  
  private void c(JSONObject paramJSONObject) throws JSONException {
    clear();
    this.Eg = paramJSONObject.getLong("trackId");
    String str = paramJSONObject.getString("type");
    if ("TEXT".equals(str)) {
      this.Gt = 1;
    } else if ("AUDIO".equals(str)) {
      this.Gt = 2;
    } else if ("VIDEO".equals(str)) {
      this.Gt = 3;
    } else {
      throw new JSONException("invalid type: " + str);
    } 
    this.FT = paramJSONObject.optString("trackContentId", null);
    this.FV = paramJSONObject.optString("trackContentType", null);
    this.mName = paramJSONObject.optString("name", null);
    this.FR = paramJSONObject.optString("language", null);
    if (paramJSONObject.has("subtype")) {
      str = paramJSONObject.getString("subtype");
      if ("SUBTITLES".equals(str)) {
        this.Gu = 1;
      } else if ("CAPTIONS".equals(str)) {
        this.Gu = 2;
      } else if ("DESCRIPTIONS".equals(str)) {
        this.Gu = 3;
      } else if ("CHAPTERS".equals(str)) {
        this.Gu = 4;
      } else if ("METADATA".equals(str)) {
        this.Gu = 5;
      } else {
        throw new JSONException("invalid subtype: " + str);
      } 
    } else {
      this.Gu = 0;
    } 
    this.Ga = paramJSONObject.optJSONObject("customData");
  }
  
  private void clear() {
    this.Eg = 0L;
    this.Gt = 0;
    this.FT = null;
    this.mName = null;
    this.FR = null;
    this.Gu = -1;
    this.Ga = null;
  }
  
  void ab(int paramInt) throws IllegalArgumentException {
    if (paramInt <= -1 || paramInt > 5)
      throw new IllegalArgumentException("invalid subtype " + paramInt); 
    if (paramInt != 0 && this.Gt != 1)
      throw new IllegalArgumentException("subtypes are only valid for text tracks"); 
    this.Gu = paramInt;
  }
  
  public boolean equals(Object paramObject) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #5
    //   3: iconst_0
    //   4: istore #6
    //   6: aload_0
    //   7: aload_1
    //   8: if_acmpne -> 17
    //   11: iconst_1
    //   12: istore #4
    //   14: iload #4
    //   16: ireturn
    //   17: iload #6
    //   19: istore #4
    //   21: aload_1
    //   22: instanceof com/google/android/gms/cast/MediaTrack
    //   25: ifeq -> 14
    //   28: aload_1
    //   29: checkcast com/google/android/gms/cast/MediaTrack
    //   32: astore_1
    //   33: aload_0
    //   34: getfield Ga : Lorg/json/JSONObject;
    //   37: ifnonnull -> 189
    //   40: iconst_1
    //   41: istore_2
    //   42: aload_1
    //   43: getfield Ga : Lorg/json/JSONObject;
    //   46: ifnonnull -> 194
    //   49: iconst_1
    //   50: istore_3
    //   51: iload #6
    //   53: istore #4
    //   55: iload_2
    //   56: iload_3
    //   57: if_icmpne -> 14
    //   60: aload_0
    //   61: getfield Ga : Lorg/json/JSONObject;
    //   64: ifnull -> 92
    //   67: aload_1
    //   68: getfield Ga : Lorg/json/JSONObject;
    //   71: ifnull -> 92
    //   74: iload #6
    //   76: istore #4
    //   78: aload_0
    //   79: getfield Ga : Lorg/json/JSONObject;
    //   82: aload_1
    //   83: getfield Ga : Lorg/json/JSONObject;
    //   86: invokestatic d : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   89: ifeq -> 14
    //   92: aload_0
    //   93: getfield Eg : J
    //   96: aload_1
    //   97: getfield Eg : J
    //   100: lcmp
    //   101: ifne -> 199
    //   104: aload_0
    //   105: getfield Gt : I
    //   108: aload_1
    //   109: getfield Gt : I
    //   112: if_icmpne -> 199
    //   115: aload_0
    //   116: getfield FT : Ljava/lang/String;
    //   119: aload_1
    //   120: getfield FT : Ljava/lang/String;
    //   123: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   126: ifeq -> 199
    //   129: aload_0
    //   130: getfield FV : Ljava/lang/String;
    //   133: aload_1
    //   134: getfield FV : Ljava/lang/String;
    //   137: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   140: ifeq -> 199
    //   143: aload_0
    //   144: getfield mName : Ljava/lang/String;
    //   147: aload_1
    //   148: getfield mName : Ljava/lang/String;
    //   151: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   154: ifeq -> 199
    //   157: aload_0
    //   158: getfield FR : Ljava/lang/String;
    //   161: aload_1
    //   162: getfield FR : Ljava/lang/String;
    //   165: invokestatic a : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   168: ifeq -> 199
    //   171: aload_0
    //   172: getfield Gu : I
    //   175: aload_1
    //   176: getfield Gu : I
    //   179: if_icmpne -> 199
    //   182: iload #5
    //   184: istore #4
    //   186: iload #4
    //   188: ireturn
    //   189: iconst_0
    //   190: istore_2
    //   191: goto -> 42
    //   194: iconst_0
    //   195: istore_3
    //   196: goto -> 51
    //   199: iconst_0
    //   200: istore #4
    //   202: goto -> 186
  }
  
  public String getContentId() {
    return this.FT;
  }
  
  public String getContentType() {
    return this.FV;
  }
  
  public JSONObject getCustomData() {
    return this.Ga;
  }
  
  public long getId() {
    return this.Eg;
  }
  
  public String getLanguage() {
    return this.FR;
  }
  
  public String getName() {
    return this.mName;
  }
  
  public int getSubtype() {
    return this.Gu;
  }
  
  public int getType() {
    return this.Gt;
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { Long.valueOf(this.Eg), Integer.valueOf(this.Gt), this.FT, this.FV, this.mName, this.FR, Integer.valueOf(this.Gu), this.Ga });
  }
  
  public void setContentId(String paramString) {
    this.FT = paramString;
  }
  
  public void setContentType(String paramString) {
    this.FV = paramString;
  }
  
  void setCustomData(JSONObject paramJSONObject) {
    this.Ga = paramJSONObject;
  }
  
  void setLanguage(String paramString) {
    this.FR = paramString;
  }
  
  void setName(String paramString) {
    this.mName = paramString;
  }
  
  public JSONObject toJson() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("trackId", this.Eg);
      switch (this.Gt) {
        case 1:
          jSONObject.put("type", "TEXT");
          break;
        case 2:
          jSONObject.put("type", "AUDIO");
          break;
        case 3:
          jSONObject.put("type", "VIDEO");
          break;
      } 
      if (this.FT != null)
        jSONObject.put("trackContentId", this.FT); 
      if (this.FV != null)
        jSONObject.put("trackContentType", this.FV); 
      if (this.mName != null)
        jSONObject.put("name", this.mName); 
      if (!TextUtils.isEmpty(this.FR))
        jSONObject.put("language", this.FR); 
      switch (this.Gu) {
        case 1:
          jSONObject.put("subtype", "SUBTITLES");
          break;
        case 2:
          jSONObject.put("subtype", "CAPTIONS");
          break;
        case 3:
          jSONObject.put("subtype", "DESCRIPTIONS");
          break;
        case 4:
          jSONObject.put("subtype", "CHAPTERS");
          break;
        case 5:
          jSONObject.put("subtype", "METADATA");
          break;
      } 
      if (this.Ga != null) {
        jSONObject.put("customData", this.Ga);
        return jSONObject;
      } 
      return jSONObject;
    } catch (JSONException jSONException) {
      return jSONObject;
    } 
  }
  
  public static class Builder {
    private final MediaTrack Gv;
    
    public Builder(long param1Long, int param1Int) throws IllegalArgumentException {
      this.Gv = new MediaTrack(param1Long, param1Int);
    }
    
    public MediaTrack build() {
      return this.Gv;
    }
    
    public Builder setContentId(String param1String) {
      this.Gv.setContentId(param1String);
      return this;
    }
    
    public Builder setContentType(String param1String) {
      this.Gv.setContentType(param1String);
      return this;
    }
    
    public Builder setCustomData(JSONObject param1JSONObject) {
      this.Gv.setCustomData(param1JSONObject);
      return this;
    }
    
    public Builder setLanguage(String param1String) {
      this.Gv.setLanguage(param1String);
      return this;
    }
    
    public Builder setLanguage(Locale param1Locale) {
      this.Gv.setLanguage(in.b(param1Locale));
      return this;
    }
    
    public Builder setName(String param1String) {
      this.Gv.setName(param1String);
      return this;
    }
    
    public Builder setSubtype(int param1Int) throws IllegalArgumentException {
      this.Gv.ab(param1Int);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\cast\MediaTrack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */