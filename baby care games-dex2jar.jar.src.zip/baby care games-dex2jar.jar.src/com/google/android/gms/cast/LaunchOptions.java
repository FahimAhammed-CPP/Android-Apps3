package com.google.android.gms.cast;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.in;
import com.google.android.gms.internal.jv;
import java.util.Locale;

public class LaunchOptions implements SafeParcelable {
  public static final Parcelable.Creator<LaunchOptions> CREATOR = new c();
  
  private final int CK;
  
  private boolean FQ;
  
  private String FR;
  
  public LaunchOptions() {
    this(1, false, in.b(Locale.getDefault()));
  }
  
  LaunchOptions(int paramInt, boolean paramBoolean, String paramString) {
    this.CK = paramInt;
    this.FQ = paramBoolean;
    this.FR = paramString;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (!(paramObject instanceof LaunchOptions))
        return false; 
      paramObject = paramObject;
      if (this.FQ != ((LaunchOptions)paramObject).FQ || !in.a(this.FR, ((LaunchOptions)paramObject).FR))
        return false; 
    } 
    return true;
  }
  
  public String getLanguage() {
    return this.FR;
  }
  
  public boolean getRelaunchIfRunning() {
    return this.FQ;
  }
  
  int getVersionCode() {
    return this.CK;
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { Boolean.valueOf(this.FQ), this.FR });
  }
  
  public void setLanguage(String paramString) {
    this.FR = paramString;
  }
  
  public void setRelaunchIfRunning(boolean paramBoolean) {
    this.FQ = paramBoolean;
  }
  
  public String toString() {
    return String.format("LaunchOptions(relaunchIfRunning=%b, language=%s)", new Object[] { Boolean.valueOf(this.FQ), this.FR });
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    c.a(this, paramParcel, paramInt);
  }
  
  public static final class Builder {
    private LaunchOptions FS = new LaunchOptions();
    
    public LaunchOptions build() {
      return this.FS;
    }
    
    public Builder setLocale(Locale param1Locale) {
      this.FS.setLanguage(in.b(param1Locale));
      return this;
    }
    
    public Builder setRelaunchIfRunning(boolean param1Boolean) {
      this.FS.setRelaunchIfRunning(param1Boolean);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\cast\LaunchOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */