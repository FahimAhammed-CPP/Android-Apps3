package com.google.android.gms.cast;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.im;
import com.google.android.gms.internal.it;
import com.google.android.gms.internal.iu;
import com.google.android.gms.internal.iv;
import java.io.IOException;
import org.json.JSONObject;

public class RemoteMediaPlayer implements Cast.MessageReceivedCallback {
  public static final int RESUME_STATE_PAUSE = 2;
  
  public static final int RESUME_STATE_PLAY = 1;
  
  public static final int RESUME_STATE_UNCHANGED = 0;
  
  public static final int STATUS_CANCELED = 2101;
  
  public static final int STATUS_FAILED = 2100;
  
  public static final int STATUS_REPLACED = 2103;
  
  public static final int STATUS_SUCCEEDED = 0;
  
  public static final int STATUS_TIMED_OUT = 2102;
  
  private final it Gw = new it(this) {
      protected void onMetadataUpdated() {
        RemoteMediaPlayer.b(this.GA);
      }
      
      protected void onStatusUpdated() {
        RemoteMediaPlayer.a(this.GA);
      }
    };
  
  private final a Gx = new a(this);
  
  private OnMetadataUpdatedListener Gy;
  
  private OnStatusUpdatedListener Gz;
  
  private final Object mH = new Object();
  
  public RemoteMediaPlayer() {
    this.Gw.a(this.Gx);
  }
  
  private void onMetadataUpdated() {
    if (this.Gy != null)
      this.Gy.onMetadataUpdated(); 
  }
  
  private void onStatusUpdated() {
    if (this.Gz != null)
      this.Gz.onStatusUpdated(); 
  }
  
  public long getApproximateStreamPosition() {
    synchronized (this.mH) {
      return this.Gw.getApproximateStreamPosition();
    } 
  }
  
  public MediaInfo getMediaInfo() {
    synchronized (this.mH) {
      return this.Gw.getMediaInfo();
    } 
  }
  
  public MediaStatus getMediaStatus() {
    synchronized (this.mH) {
      return this.Gw.getMediaStatus();
    } 
  }
  
  public String getNamespace() {
    return this.Gw.getNamespace();
  }
  
  public long getStreamDuration() {
    synchronized (this.mH) {
      return this.Gw.getStreamDuration();
    } 
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo) {
    return load(paramGoogleApiClient, paramMediaInfo, true, 0L, null, null);
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo, boolean paramBoolean) {
    return load(paramGoogleApiClient, paramMediaInfo, paramBoolean, 0L, null, null);
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo, boolean paramBoolean, long paramLong) {
    return load(paramGoogleApiClient, paramMediaInfo, paramBoolean, paramLong, null, null);
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo, boolean paramBoolean, long paramLong, JSONObject paramJSONObject) {
    return load(paramGoogleApiClient, paramMediaInfo, paramBoolean, paramLong, null, paramJSONObject);
  }
  
  public PendingResult<MediaChannelResult> load(GoogleApiClient paramGoogleApiClient, MediaInfo paramMediaInfo, boolean paramBoolean, long paramLong, long[] paramArrayOflong, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramMediaInfo, paramBoolean, paramLong, paramArrayOflong, paramJSONObject) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).a(this.GR, this.GE, this.GF, this.GG, this.GH, this.GI);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public void onMessageReceived(CastDevice paramCastDevice, String paramString1, String paramString2) {
    this.Gw.aD(paramString2);
  }
  
  public PendingResult<MediaChannelResult> pause(GoogleApiClient paramGoogleApiClient) {
    return pause(paramGoogleApiClient, null);
  }
  
  public PendingResult<MediaChannelResult> pause(GoogleApiClient paramGoogleApiClient, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramJSONObject) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).a(this.GR, this.GI);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> play(GoogleApiClient paramGoogleApiClient) {
    return play(paramGoogleApiClient, null);
  }
  
  public PendingResult<MediaChannelResult> play(GoogleApiClient paramGoogleApiClient, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramJSONObject) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).c(this.GR, this.GI);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> requestStatus(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).a(this.GR);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> seek(GoogleApiClient paramGoogleApiClient, long paramLong) {
    return seek(paramGoogleApiClient, paramLong, 0, null);
  }
  
  public PendingResult<MediaChannelResult> seek(GoogleApiClient paramGoogleApiClient, long paramLong, int paramInt) {
    return seek(paramGoogleApiClient, paramLong, paramInt, null);
  }
  
  public PendingResult<MediaChannelResult> seek(GoogleApiClient paramGoogleApiClient, long paramLong, int paramInt, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramLong, paramInt, paramJSONObject) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).a(this.GR, this.GJ, this.GK, this.GI);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> setActiveMediaTracks(GoogleApiClient paramGoogleApiClient, long[] paramArrayOflong) {
    if (paramArrayOflong == null || paramArrayOflong.length == 0)
      throw new IllegalArgumentException("trackIds cannot be null or empty"); 
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramArrayOflong) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).a(this.GR, this.GC);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public void setOnMetadataUpdatedListener(OnMetadataUpdatedListener paramOnMetadataUpdatedListener) {
    this.Gy = paramOnMetadataUpdatedListener;
  }
  
  public void setOnStatusUpdatedListener(OnStatusUpdatedListener paramOnStatusUpdatedListener) {
    this.Gz = paramOnStatusUpdatedListener;
  }
  
  public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient paramGoogleApiClient, boolean paramBoolean) {
    return setStreamMute(paramGoogleApiClient, paramBoolean, null);
  }
  
  public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient paramGoogleApiClient, boolean paramBoolean, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramBoolean, paramJSONObject) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).a(this.GR, this.GM, this.GI);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IllegalStateException illegalStateException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient paramGoogleApiClient, double paramDouble) throws IllegalArgumentException {
    return setStreamVolume(paramGoogleApiClient, paramDouble, null);
  }
  
  public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient paramGoogleApiClient, double paramDouble, JSONObject paramJSONObject) throws IllegalArgumentException {
    if (Double.isInfinite(paramDouble) || Double.isNaN(paramDouble))
      throw new IllegalArgumentException("Volume cannot be " + paramDouble); 
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramDouble, paramJSONObject) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).a(this.GR, this.GL, this.GI);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IllegalStateException illegalStateException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IllegalArgumentException illegalArgumentException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> setTextTrackStyle(GoogleApiClient paramGoogleApiClient, TextTrackStyle paramTextTrackStyle) {
    if (paramTextTrackStyle == null)
      throw new IllegalArgumentException("trackStyle cannot be null"); 
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramTextTrackStyle) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).a(this.GR, this.GD);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public PendingResult<MediaChannelResult> stop(GoogleApiClient paramGoogleApiClient) {
    return stop(paramGoogleApiClient, null);
  }
  
  public PendingResult<MediaChannelResult> stop(GoogleApiClient paramGoogleApiClient, JSONObject paramJSONObject) {
    return (PendingResult<MediaChannelResult>)paramGoogleApiClient.b(new b(this, paramGoogleApiClient, paramGoogleApiClient, paramJSONObject) {
          protected void a(im param1im) {
            synchronized (RemoteMediaPlayer.c(this.GA)) {
              RemoteMediaPlayer.d(this.GA).b(this.GB);
              try {
                RemoteMediaPlayer.e(this.GA).b(this.GR, this.GI);
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } catch (IOException iOException) {
                b(k(new Status(2100)));
                RemoteMediaPlayer.d(this.GA).b(null);
                return;
              } finally {
                Exception exception;
              } 
            } 
            RemoteMediaPlayer.d(this.GA).b(null);
            throw SYNTHETIC_LOCAL_VARIABLE_2;
          }
        });
  }
  
  public static interface MediaChannelResult extends Result {
    JSONObject getCustomData();
  }
  
  public static interface OnMetadataUpdatedListener {
    void onMetadataUpdated();
  }
  
  public static interface OnStatusUpdatedListener {
    void onStatusUpdated();
  }
  
  private class a implements iu {
    private GoogleApiClient GN;
    
    private long GO = 0L;
    
    public a(RemoteMediaPlayer this$0) {}
    
    public void a(String param1String1, String param1String2, long param1Long, String param1String3) throws IOException {
      if (this.GN == null)
        throw new IOException("No GoogleApiClient available"); 
      Cast.CastApi.sendMessage(this.GN, param1String1, param1String2).setResultCallback(new a(this, param1Long));
    }
    
    public void b(GoogleApiClient param1GoogleApiClient) {
      this.GN = param1GoogleApiClient;
    }
    
    public long fS() {
      long l = this.GO + 1L;
      this.GO = l;
      return l;
    }
    
    private final class a implements ResultCallback<Status> {
      private final long GP;
      
      a(RemoteMediaPlayer.a this$0, long param2Long) {
        this.GP = param2Long;
      }
      
      public void j(Status param2Status) {
        if (!param2Status.isSuccess())
          RemoteMediaPlayer.e(this.GQ.GA).b(this.GP, param2Status.getStatusCode()); 
      }
    }
  }
  
  private final class a implements ResultCallback<Status> {
    private final long GP;
    
    a(RemoteMediaPlayer this$0, long param1Long) {
      this.GP = param1Long;
    }
    
    public void j(Status param1Status) {
      if (!param1Status.isSuccess())
        RemoteMediaPlayer.e(this.GQ.GA).b(this.GP, param1Status.getStatusCode()); 
    }
  }
  
  private static abstract class b extends Cast.a<MediaChannelResult> {
    iv GR = new iv(this) {
        public void a(long param2Long, int param2Int, JSONObject param2JSONObject) {
          this.GS.b(new RemoteMediaPlayer.c(new Status(param2Int), param2JSONObject));
        }
        
        public void n(long param2Long) {
          this.GS.b(this.GS.k(new Status(2103)));
        }
      };
    
    b(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public RemoteMediaPlayer.MediaChannelResult k(Status param1Status) {
      return new RemoteMediaPlayer.MediaChannelResult(this, param1Status) {
          public JSONObject getCustomData() {
            return null;
          }
          
          public Status getStatus() {
            return this.DS;
          }
        };
    }
  }
  
  class null implements iv {
    null(RemoteMediaPlayer this$0) {}
    
    public void a(long param1Long, int param1Int, JSONObject param1JSONObject) {
      this.GS.b(new RemoteMediaPlayer.c(new Status(param1Int), param1JSONObject));
    }
    
    public void n(long param1Long) {
      this.GS.b(this.GS.k(new Status(2103)));
    }
  }
  
  class null implements MediaChannelResult {
    null(RemoteMediaPlayer this$0, Status param1Status) {}
    
    public JSONObject getCustomData() {
      return null;
    }
    
    public Status getStatus() {
      return this.DS;
    }
  }
  
  private static final class c implements MediaChannelResult {
    private final Status Eb;
    
    private final JSONObject Ga;
    
    c(Status param1Status, JSONObject param1JSONObject) {
      this.Eb = param1Status;
      this.Ga = param1JSONObject;
    }
    
    public JSONObject getCustomData() {
      return this.Ga;
    }
    
    public Status getStatus() {
      return this.Eb;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\cast\RemoteMediaPlayer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */