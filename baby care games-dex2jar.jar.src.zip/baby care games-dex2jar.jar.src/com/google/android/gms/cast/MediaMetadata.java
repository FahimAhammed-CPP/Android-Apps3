package com.google.android.gms.cast;

import android.os.Bundle;
import android.text.TextUtils;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.internal.ix;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class MediaMetadata {
  private static final String[] Gc = new String[] { null, "String", "int", "double", "ISO-8601 date String" };
  
  private static final a Gd = (new a()).a("com.google.android.gms.cast.metadata.CREATION_DATE", "creationDateTime", 4).a("com.google.android.gms.cast.metadata.RELEASE_DATE", "releaseDate", 4).a("com.google.android.gms.cast.metadata.BROADCAST_DATE", "originalAirdate", 4).a("com.google.android.gms.cast.metadata.TITLE", "title", 1).a("com.google.android.gms.cast.metadata.SUBTITLE", "subtitle", 1).a("com.google.android.gms.cast.metadata.ARTIST", "artist", 1).a("com.google.android.gms.cast.metadata.ALBUM_ARTIST", "albumArtist", 1).a("com.google.android.gms.cast.metadata.ALBUM_TITLE", "albumName", 1).a("com.google.android.gms.cast.metadata.COMPOSER", "composer", 1).a("com.google.android.gms.cast.metadata.DISC_NUMBER", "discNumber", 2).a("com.google.android.gms.cast.metadata.TRACK_NUMBER", "trackNumber", 2).a("com.google.android.gms.cast.metadata.SEASON_NUMBER", "season", 2).a("com.google.android.gms.cast.metadata.EPISODE_NUMBER", "episode", 2).a("com.google.android.gms.cast.metadata.SERIES_TITLE", "seriesTitle", 1).a("com.google.android.gms.cast.metadata.STUDIO", "studio", 1).a("com.google.android.gms.cast.metadata.WIDTH", "width", 2).a("com.google.android.gms.cast.metadata.HEIGHT", "height", 2).a("com.google.android.gms.cast.metadata.LOCATION_NAME", "location", 1).a("com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "latitude", 3).a("com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "longitude", 3);
  
  public static final String KEY_ALBUM_ARTIST = "com.google.android.gms.cast.metadata.ALBUM_ARTIST";
  
  public static final String KEY_ALBUM_TITLE = "com.google.android.gms.cast.metadata.ALBUM_TITLE";
  
  public static final String KEY_ARTIST = "com.google.android.gms.cast.metadata.ARTIST";
  
  public static final String KEY_BROADCAST_DATE = "com.google.android.gms.cast.metadata.BROADCAST_DATE";
  
  public static final String KEY_COMPOSER = "com.google.android.gms.cast.metadata.COMPOSER";
  
  public static final String KEY_CREATION_DATE = "com.google.android.gms.cast.metadata.CREATION_DATE";
  
  public static final String KEY_DISC_NUMBER = "com.google.android.gms.cast.metadata.DISC_NUMBER";
  
  public static final String KEY_EPISODE_NUMBER = "com.google.android.gms.cast.metadata.EPISODE_NUMBER";
  
  public static final String KEY_HEIGHT = "com.google.android.gms.cast.metadata.HEIGHT";
  
  public static final String KEY_LOCATION_LATITUDE = "com.google.android.gms.cast.metadata.LOCATION_LATITUDE";
  
  public static final String KEY_LOCATION_LONGITUDE = "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE";
  
  public static final String KEY_LOCATION_NAME = "com.google.android.gms.cast.metadata.LOCATION_NAME";
  
  public static final String KEY_RELEASE_DATE = "com.google.android.gms.cast.metadata.RELEASE_DATE";
  
  public static final String KEY_SEASON_NUMBER = "com.google.android.gms.cast.metadata.SEASON_NUMBER";
  
  public static final String KEY_SERIES_TITLE = "com.google.android.gms.cast.metadata.SERIES_TITLE";
  
  public static final String KEY_STUDIO = "com.google.android.gms.cast.metadata.STUDIO";
  
  public static final String KEY_SUBTITLE = "com.google.android.gms.cast.metadata.SUBTITLE";
  
  public static final String KEY_TITLE = "com.google.android.gms.cast.metadata.TITLE";
  
  public static final String KEY_TRACK_NUMBER = "com.google.android.gms.cast.metadata.TRACK_NUMBER";
  
  public static final String KEY_WIDTH = "com.google.android.gms.cast.metadata.WIDTH";
  
  public static final int MEDIA_TYPE_GENERIC = 0;
  
  public static final int MEDIA_TYPE_MOVIE = 1;
  
  public static final int MEDIA_TYPE_MUSIC_TRACK = 3;
  
  public static final int MEDIA_TYPE_PHOTO = 4;
  
  public static final int MEDIA_TYPE_TV_SHOW = 2;
  
  public static final int MEDIA_TYPE_USER = 100;
  
  private final List<WebImage> Fp = new ArrayList<WebImage>();
  
  private final Bundle Ge = new Bundle();
  
  private int Gf;
  
  public MediaMetadata() {
    this(0);
  }
  
  public MediaMetadata(int paramInt) {
    this.Gf = paramInt;
  }
  
  private void a(JSONObject paramJSONObject, String... paramVarArgs) {
    try {
      int j = paramVarArgs.length;
      for (int i = 0;; i++) {
        if (i < j) {
          String str = paramVarArgs[i];
          if (this.Ge.containsKey(str))
            switch (Gd.aB(str)) {
              case 1:
              case 4:
                paramJSONObject.put(Gd.az(str), this.Ge.getString(str));
                break;
              case 2:
                paramJSONObject.put(Gd.az(str), this.Ge.getInt(str));
                break;
              case 3:
                paramJSONObject.put(Gd.az(str), this.Ge.getDouble(str));
                break;
            }  
        } else {
          for (String str : this.Ge.keySet()) {
            if (!str.startsWith("com.google.")) {
              Object object = this.Ge.get(str);
              if (object instanceof String) {
                paramJSONObject.put(str, object);
                continue;
              } 
              if (object instanceof Integer) {
                paramJSONObject.put(str, object);
                continue;
              } 
              if (object instanceof Double)
                paramJSONObject.put(str, object); 
            } 
          } 
          break;
        } 
      } 
    } catch (JSONException jSONException) {}
  }
  
  private boolean a(Bundle paramBundle1, Bundle paramBundle2) {
    if (paramBundle1.size() != paramBundle2.size())
      return false; 
    for (String str : paramBundle1.keySet()) {
      Object object1 = paramBundle1.get(str);
      Object object2 = paramBundle2.get(str);
      if (object1 instanceof Bundle && object2 instanceof Bundle && !a((Bundle)object1, (Bundle)object2))
        return false; 
      if (object1 == null) {
        if (object2 != null || !paramBundle2.containsKey(str))
          return false; 
        continue;
      } 
      if (!object1.equals(object2))
        return false; 
    } 
    return true;
  }
  
  private void b(JSONObject paramJSONObject, String... paramVarArgs) {
    HashSet hashSet = new HashSet(Arrays.asList((Object[])paramVarArgs));
    try {
      Iterator<String> iterator = paramJSONObject.keys();
      while (iterator.hasNext()) {
        String str = iterator.next();
        if (!"metadataType".equals(str)) {
          String str1 = Gd.aA(str);
          if (str1 != null) {
            boolean bool = hashSet.contains(str1);
            if (bool)
              try {
                object1 = paramJSONObject.get(str);
                if (object1 != null)
                  switch (Gd.aB(str1)) {
                    case 1:
                      if (object1 instanceof String)
                        this.Ge.putString(str1, (String)object1); 
                      continue;
                    case 4:
                      if (object1 instanceof String && ix.aL((String)object1) != null)
                        this.Ge.putString(str1, (String)object1); 
                      continue;
                    case 2:
                      if (object1 instanceof Integer)
                        this.Ge.putInt(str1, ((Integer)object1).intValue()); 
                      continue;
                    case 3:
                      if (object1 instanceof Double)
                        this.Ge.putDouble(str1, ((Double)object1).doubleValue()); 
                      continue;
                  }  
              } catch (JSONException object1) {} 
            continue;
          } 
          Object object2 = paramJSONObject.get((String)object1);
          if (object2 instanceof String) {
            this.Ge.putString((String)object1, (String)object2);
            continue;
          } 
          if (object2 instanceof Integer) {
            this.Ge.putInt((String)object1, ((Integer)object2).intValue());
            continue;
          } 
          if (object2 instanceof Double)
            this.Ge.putDouble((String)object1, ((Double)object2).doubleValue()); 
        } 
      } 
    } catch (JSONException jSONException) {}
  }
  
  private void f(String paramString, int paramInt) throws IllegalArgumentException {
    if (TextUtils.isEmpty(paramString))
      throw new IllegalArgumentException("null and empty keys are not allowed"); 
    int i = Gd.aB(paramString);
    if (i != paramInt && i != 0)
      throw new IllegalArgumentException("Value for " + paramString + " must be a " + Gc[paramInt]); 
  }
  
  public void addImage(WebImage paramWebImage) {
    this.Fp.add(paramWebImage);
  }
  
  public void c(JSONObject paramJSONObject) {
    clear();
    this.Gf = 0;
    try {
      this.Gf = paramJSONObject.getInt("metadataType");
    } catch (JSONException jSONException) {}
    ix.a(this.Fp, paramJSONObject);
    switch (this.Gf) {
      default:
        b(paramJSONObject, new String[0]);
        return;
      case 0:
        b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return;
      case 1:
        b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return;
      case 2:
        b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE" });
        return;
      case 3:
        b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return;
      case 4:
        break;
    } 
    b(paramJSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE" });
  }
  
  public void clear() {
    this.Ge.clear();
    this.Fp.clear();
  }
  
  public void clearImages() {
    this.Fp.clear();
  }
  
  public boolean containsKey(String paramString) {
    return this.Ge.containsKey(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (!(paramObject instanceof MediaMetadata))
        return false; 
      paramObject = paramObject;
      if (!a(this.Ge, ((MediaMetadata)paramObject).Ge) || !this.Fp.equals(((MediaMetadata)paramObject).Fp))
        return false; 
    } 
    return true;
  }
  
  public Calendar getDate(String paramString) {
    f(paramString, 4);
    paramString = this.Ge.getString(paramString);
    return (paramString != null) ? ix.aL(paramString) : null;
  }
  
  public String getDateAsString(String paramString) {
    f(paramString, 4);
    return this.Ge.getString(paramString);
  }
  
  public double getDouble(String paramString) {
    f(paramString, 3);
    return this.Ge.getDouble(paramString);
  }
  
  public List<WebImage> getImages() {
    return this.Fp;
  }
  
  public int getInt(String paramString) {
    f(paramString, 2);
    return this.Ge.getInt(paramString);
  }
  
  public int getMediaType() {
    return this.Gf;
  }
  
  public String getString(String paramString) {
    f(paramString, 1);
    return this.Ge.getString(paramString);
  }
  
  public boolean hasImages() {
    return (this.Fp != null && !this.Fp.isEmpty());
  }
  
  public int hashCode() {
    Iterator<String> iterator = this.Ge.keySet().iterator();
    int i;
    for (i = 17; iterator.hasNext(); i = this.Ge.get(str).hashCode() + i * 31)
      String str = iterator.next(); 
    return i * 31 + this.Fp.hashCode();
  }
  
  public Set<String> keySet() {
    return this.Ge.keySet();
  }
  
  public void putDate(String paramString, Calendar paramCalendar) {
    f(paramString, 4);
    this.Ge.putString(paramString, ix.a(paramCalendar));
  }
  
  public void putDouble(String paramString, double paramDouble) {
    f(paramString, 3);
    this.Ge.putDouble(paramString, paramDouble);
  }
  
  public void putInt(String paramString, int paramInt) {
    f(paramString, 2);
    this.Ge.putInt(paramString, paramInt);
  }
  
  public void putString(String paramString1, String paramString2) {
    f(paramString1, 1);
    this.Ge.putString(paramString1, paramString2);
  }
  
  public JSONObject toJson() {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("metadataType", this.Gf);
    } catch (JSONException jSONException) {}
    ix.a(jSONObject, this.Fp);
    switch (this.Gf) {
      default:
        a(jSONObject, new String[0]);
        return jSONObject;
      case 0:
        a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return jSONObject;
      case 1:
        a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.STUDIO", "com.google.android.gms.cast.metadata.SUBTITLE", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return jSONObject;
      case 2:
        a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.SERIES_TITLE", "com.google.android.gms.cast.metadata.SEASON_NUMBER", "com.google.android.gms.cast.metadata.EPISODE_NUMBER", "com.google.android.gms.cast.metadata.BROADCAST_DATE" });
        return jSONObject;
      case 3:
        a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.ALBUM_TITLE", "com.google.android.gms.cast.metadata.ALBUM_ARTIST", "com.google.android.gms.cast.metadata.COMPOSER", "com.google.android.gms.cast.metadata.TRACK_NUMBER", "com.google.android.gms.cast.metadata.DISC_NUMBER", "com.google.android.gms.cast.metadata.RELEASE_DATE" });
        return jSONObject;
      case 4:
        break;
    } 
    a(jSONObject, new String[] { "com.google.android.gms.cast.metadata.TITLE", "com.google.android.gms.cast.metadata.ARTIST", "com.google.android.gms.cast.metadata.LOCATION_NAME", "com.google.android.gms.cast.metadata.LOCATION_LATITUDE", "com.google.android.gms.cast.metadata.LOCATION_LONGITUDE", "com.google.android.gms.cast.metadata.WIDTH", "com.google.android.gms.cast.metadata.HEIGHT", "com.google.android.gms.cast.metadata.CREATION_DATE" });
    return jSONObject;
  }
  
  private static class a {
    private final Map<String, String> Gg = new HashMap<String, String>();
    
    private final Map<String, String> Gh = new HashMap<String, String>();
    
    private final Map<String, Integer> Gi = new HashMap<String, Integer>();
    
    public a a(String param1String1, String param1String2, int param1Int) {
      this.Gg.put(param1String1, param1String2);
      this.Gh.put(param1String2, param1String1);
      this.Gi.put(param1String1, Integer.valueOf(param1Int));
      return this;
    }
    
    public String aA(String param1String) {
      return this.Gh.get(param1String);
    }
    
    public int aB(String param1String) {
      Integer integer = this.Gi.get(param1String);
      return (integer != null) ? integer.intValue() : 0;
    }
    
    public String az(String param1String) {
      return this.Gg.get(param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\cast\MediaMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */