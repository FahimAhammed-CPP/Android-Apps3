package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.in;
import com.google.android.gms.internal.jv;
import java.util.ArrayList;
import java.util.List;

public final class ApplicationMetadata implements SafeParcelable {
  public static final Parcelable.Creator<ApplicationMetadata> CREATOR = new a();
  
  private final int CK = 1;
  
  String Fo;
  
  List<WebImage> Fp;
  
  List<String> Fq;
  
  String Fr;
  
  Uri Fs;
  
  String mName;
  
  private ApplicationMetadata() {
    this.Fp = new ArrayList<WebImage>();
    this.Fq = new ArrayList<String>();
  }
  
  ApplicationMetadata(int paramInt, String paramString1, String paramString2, List<WebImage> paramList, List<String> paramList1, String paramString3, Uri paramUri) {
    this.Fo = paramString1;
    this.mName = paramString2;
    this.Fp = paramList;
    this.Fq = paramList1;
    this.Fr = paramString3;
    this.Fs = paramUri;
  }
  
  public boolean areNamespacesSupported(List<String> paramList) {
    return (this.Fq != null && this.Fq.containsAll(paramList));
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (!(paramObject instanceof ApplicationMetadata))
        return false; 
      paramObject = paramObject;
      if (!in.a(this.Fo, ((ApplicationMetadata)paramObject).Fo) || !in.a(this.Fp, ((ApplicationMetadata)paramObject).Fp) || !in.a(this.mName, ((ApplicationMetadata)paramObject).mName) || !in.a(this.Fq, ((ApplicationMetadata)paramObject).Fq) || !in.a(this.Fr, ((ApplicationMetadata)paramObject).Fr) || !in.a(this.Fs, ((ApplicationMetadata)paramObject).Fs))
        return false; 
    } 
    return true;
  }
  
  public Uri fP() {
    return this.Fs;
  }
  
  public String getApplicationId() {
    return this.Fo;
  }
  
  public List<WebImage> getImages() {
    return this.Fp;
  }
  
  public String getName() {
    return this.mName;
  }
  
  public String getSenderAppIdentifier() {
    return this.Fr;
  }
  
  int getVersionCode() {
    return this.CK;
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { Integer.valueOf(this.CK), this.Fo, this.mName, this.Fp, this.Fq, this.Fr, this.Fs });
  }
  
  public boolean isNamespaceSupported(String paramString) {
    return (this.Fq != null && this.Fq.contains(paramString));
  }
  
  public String toString() {
    return this.mName;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    a.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\cast\ApplicationMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */