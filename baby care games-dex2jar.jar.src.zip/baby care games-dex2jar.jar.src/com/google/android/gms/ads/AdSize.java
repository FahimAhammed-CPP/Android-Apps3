package com.google.android.gms.ads;

import android.content.Context;
import com.google.android.gms.internal.ay;
import com.google.android.gms.internal.gq;

public final class AdSize {
  public static final int AUTO_HEIGHT = -2;
  
  public static final AdSize BANNER = new AdSize(320, 50, "320x50_mb");
  
  public static final AdSize FULL_BANNER = new AdSize(468, 60, "468x60_as");
  
  public static final int FULL_WIDTH = -1;
  
  public static final AdSize LARGE_BANNER = new AdSize(320, 100, "320x100_as");
  
  public static final AdSize LEADERBOARD = new AdSize(728, 90, "728x90_as");
  
  public static final AdSize MEDIUM_RECTANGLE = new AdSize(300, 250, "300x250_as");
  
  public static final AdSize SMART_BANNER;
  
  public static final AdSize WIDE_SKYSCRAPER = new AdSize(160, 600, "160x600_as");
  
  private final int li;
  
  private final int lj;
  
  private final String lk;
  
  static {
    SMART_BANNER = new AdSize(-1, -2, "smart_banner");
  }
  
  public AdSize(int paramInt1, int paramInt2) {
    this(paramInt1, paramInt2, stringBuilder.append(str).append("_as").toString());
  }
  
  AdSize(int paramInt1, int paramInt2, String paramString) {
    if (paramInt1 < 0 && paramInt1 != -1)
      throw new IllegalArgumentException("Invalid width for AdSize: " + paramInt1); 
    if (paramInt2 < 0 && paramInt2 != -2)
      throw new IllegalArgumentException("Invalid height for AdSize: " + paramInt2); 
    this.li = paramInt1;
    this.lj = paramInt2;
    this.lk = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject != this) {
      if (!(paramObject instanceof AdSize))
        return false; 
      paramObject = paramObject;
      if (this.li != ((AdSize)paramObject).li || this.lj != ((AdSize)paramObject).lj || !this.lk.equals(((AdSize)paramObject).lk))
        return false; 
    } 
    return true;
  }
  
  public int getHeight() {
    return this.lj;
  }
  
  public int getHeightInPixels(Context paramContext) {
    return (this.lj == -2) ? ay.b(paramContext.getResources().getDisplayMetrics()) : gq.a(paramContext, this.lj);
  }
  
  public int getWidth() {
    return this.li;
  }
  
  public int getWidthInPixels(Context paramContext) {
    return (this.li == -1) ? ay.a(paramContext.getResources().getDisplayMetrics()) : gq.a(paramContext, this.li);
  }
  
  public int hashCode() {
    return this.lk.hashCode();
  }
  
  public boolean isAutoHeight() {
    return (this.lj == -2);
  }
  
  public boolean isFullWidth() {
    return (this.li == -1);
  }
  
  public String toString() {
    return this.lk;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\ads\AdSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */