package com.google.android.gms.ads.search;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.internal.bh;

public final class SearchAdView extends ViewGroup {
  private final bh ll = new bh(this);
  
  public SearchAdView(Context paramContext) {
    super(paramContext);
  }
  
  public SearchAdView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public SearchAdView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public void destroy() {
    this.ll.destroy();
  }
  
  public AdListener getAdListener() {
    return this.ll.getAdListener();
  }
  
  public AdSize getAdSize() {
    return this.ll.getAdSize();
  }
  
  public String getAdUnitId() {
    return this.ll.getAdUnitId();
  }
  
  public void loadAd(SearchAdRequest paramSearchAdRequest) {
    this.ll.a(paramSearchAdRequest.Y());
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null && view.getVisibility() != 8) {
      int i = view.getMeasuredWidth();
      int j = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1 - i) / 2;
      paramInt2 = (paramInt4 - paramInt2 - j) / 2;
      view.layout(paramInt1, paramInt2, i + paramInt1, j + paramInt2);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = 0;
    View view = getChildAt(0);
    AdSize adSize = getAdSize();
    if (view != null && view.getVisibility() != 8) {
      measureChild(view, paramInt1, paramInt2);
      j = view.getMeasuredWidth();
      i = view.getMeasuredHeight();
    } else if (adSize != null) {
      Context context = getContext();
      j = adSize.getWidthInPixels(context);
      i = adSize.getHeightInPixels(context);
    } else {
      j = 0;
    } 
    int j = Math.max(j, getSuggestedMinimumWidth());
    i = Math.max(i, getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSize(j, paramInt1), View.resolveSize(i, paramInt2));
  }
  
  public void pause() {
    this.ll.pause();
  }
  
  public void resume() {
    this.ll.resume();
  }
  
  public void setAdListener(AdListener paramAdListener) {
    this.ll.setAdListener(paramAdListener);
  }
  
  public void setAdSize(AdSize paramAdSize) {
    this.ll.setAdSizes(new AdSize[] { paramAdSize });
  }
  
  public void setAdUnitId(String paramString) {
    this.ll.setAdUnitId(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\ads\search\SearchAdView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */