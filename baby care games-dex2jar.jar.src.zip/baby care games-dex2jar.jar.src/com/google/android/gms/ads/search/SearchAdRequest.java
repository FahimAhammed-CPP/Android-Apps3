package com.google.android.gms.ads.search;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;
import com.google.android.gms.internal.bg;

public final class SearchAdRequest {
  public static final int BORDER_TYPE_DASHED = 1;
  
  public static final int BORDER_TYPE_DOTTED = 2;
  
  public static final int BORDER_TYPE_NONE = 0;
  
  public static final int BORDER_TYPE_SOLID = 3;
  
  public static final int CALL_BUTTON_COLOR_DARK = 2;
  
  public static final int CALL_BUTTON_COLOR_LIGHT = 0;
  
  public static final int CALL_BUTTON_COLOR_MEDIUM = 1;
  
  public static final String DEVICE_ID_EMULATOR = bg.DEVICE_ID_EMULATOR;
  
  public static final int ERROR_CODE_INTERNAL_ERROR = 0;
  
  public static final int ERROR_CODE_INVALID_REQUEST = 1;
  
  public static final int ERROR_CODE_NETWORK_ERROR = 2;
  
  public static final int ERROR_CODE_NO_FILL = 3;
  
  private final bg lg;
  
  private final int xA;
  
  private final int xB;
  
  private final int xC;
  
  private final int xD;
  
  private final int xE;
  
  private final int xF;
  
  private final int xG;
  
  private final int xH;
  
  private final String xI;
  
  private final int xJ;
  
  private final String xK;
  
  private final int xL;
  
  private final int xM;
  
  private final String xN;
  
  private SearchAdRequest(Builder paramBuilder) {
    this.xA = Builder.a(paramBuilder);
    this.xB = Builder.b(paramBuilder);
    this.xC = Builder.c(paramBuilder);
    this.xD = Builder.d(paramBuilder);
    this.xE = Builder.e(paramBuilder);
    this.xF = Builder.f(paramBuilder);
    this.xG = Builder.g(paramBuilder);
    this.xH = Builder.h(paramBuilder);
    this.xI = Builder.i(paramBuilder);
    this.xJ = Builder.j(paramBuilder);
    this.xK = Builder.k(paramBuilder);
    this.xL = Builder.l(paramBuilder);
    this.xM = Builder.m(paramBuilder);
    this.xN = Builder.n(paramBuilder);
    this.lg = new bg(Builder.o(paramBuilder), this);
  }
  
  bg Y() {
    return this.lg;
  }
  
  public int getAnchorTextColor() {
    return this.xA;
  }
  
  public int getBackgroundColor() {
    return this.xB;
  }
  
  public int getBackgroundGradientBottom() {
    return this.xC;
  }
  
  public int getBackgroundGradientTop() {
    return this.xD;
  }
  
  public int getBorderColor() {
    return this.xE;
  }
  
  public int getBorderThickness() {
    return this.xF;
  }
  
  public int getBorderType() {
    return this.xG;
  }
  
  public int getCallButtonColor() {
    return this.xH;
  }
  
  public String getCustomChannels() {
    return this.xI;
  }
  
  public <T extends CustomEvent> Bundle getCustomEventExtrasBundle(Class<T> paramClass) {
    return this.lg.getCustomEventExtrasBundle(paramClass);
  }
  
  public int getDescriptionTextColor() {
    return this.xJ;
  }
  
  public String getFontFace() {
    return this.xK;
  }
  
  public int getHeaderTextColor() {
    return this.xL;
  }
  
  public int getHeaderTextSize() {
    return this.xM;
  }
  
  public Location getLocation() {
    return this.lg.getLocation();
  }
  
  @Deprecated
  public <T extends NetworkExtras> T getNetworkExtras(Class<T> paramClass) {
    return (T)this.lg.getNetworkExtras(paramClass);
  }
  
  public <T extends MediationAdapter> Bundle getNetworkExtrasBundle(Class<T> paramClass) {
    return this.lg.getNetworkExtrasBundle(paramClass);
  }
  
  public String getQuery() {
    return this.xN;
  }
  
  public boolean isTestDevice(Context paramContext) {
    return this.lg.isTestDevice(paramContext);
  }
  
  public static final class Builder {
    private final bg.a lh = new bg.a();
    
    private int xA;
    
    private int xB;
    
    private int xC;
    
    private int xD;
    
    private int xE;
    
    private int xF;
    
    private int xG = 0;
    
    private int xH;
    
    private String xI;
    
    private int xJ;
    
    private String xK;
    
    private int xL;
    
    private int xM;
    
    private String xN;
    
    public Builder addCustomEventExtrasBundle(Class<? extends CustomEvent> param1Class, Bundle param1Bundle) {
      this.lh.b(param1Class, param1Bundle);
      return this;
    }
    
    public Builder addNetworkExtras(NetworkExtras param1NetworkExtras) {
      this.lh.a(param1NetworkExtras);
      return this;
    }
    
    public Builder addNetworkExtrasBundle(Class<? extends MediationAdapter> param1Class, Bundle param1Bundle) {
      this.lh.a(param1Class, param1Bundle);
      return this;
    }
    
    public Builder addTestDevice(String param1String) {
      this.lh.s(param1String);
      return this;
    }
    
    public SearchAdRequest build() {
      return new SearchAdRequest(this);
    }
    
    public Builder setAnchorTextColor(int param1Int) {
      this.xA = param1Int;
      return this;
    }
    
    public Builder setBackgroundColor(int param1Int) {
      this.xB = param1Int;
      this.xC = Color.argb(0, 0, 0, 0);
      this.xD = Color.argb(0, 0, 0, 0);
      return this;
    }
    
    public Builder setBackgroundGradient(int param1Int1, int param1Int2) {
      this.xB = Color.argb(0, 0, 0, 0);
      this.xC = param1Int2;
      this.xD = param1Int1;
      return this;
    }
    
    public Builder setBorderColor(int param1Int) {
      this.xE = param1Int;
      return this;
    }
    
    public Builder setBorderThickness(int param1Int) {
      this.xF = param1Int;
      return this;
    }
    
    public Builder setBorderType(int param1Int) {
      this.xG = param1Int;
      return this;
    }
    
    public Builder setCallButtonColor(int param1Int) {
      this.xH = param1Int;
      return this;
    }
    
    public Builder setCustomChannels(String param1String) {
      this.xI = param1String;
      return this;
    }
    
    public Builder setDescriptionTextColor(int param1Int) {
      this.xJ = param1Int;
      return this;
    }
    
    public Builder setFontFace(String param1String) {
      this.xK = param1String;
      return this;
    }
    
    public Builder setHeaderTextColor(int param1Int) {
      this.xL = param1Int;
      return this;
    }
    
    public Builder setHeaderTextSize(int param1Int) {
      this.xM = param1Int;
      return this;
    }
    
    public Builder setLocation(Location param1Location) {
      this.lh.a(param1Location);
      return this;
    }
    
    public Builder setQuery(String param1String) {
      this.xN = param1String;
      return this;
    }
    
    public Builder tagForChildDirectedTreatment(boolean param1Boolean) {
      this.lh.j(param1Boolean);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\ads\search\SearchAdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */