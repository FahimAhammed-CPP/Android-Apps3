package com.google.android.gms.ads;

import android.app.Activity;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.internal.dw;
import com.google.android.gms.internal.dx;
import com.google.android.gms.internal.gr;

public final class AdActivity extends Activity {
  public static final String CLASS_NAME = "com.google.android.gms.ads.AdActivity";
  
  public static final String SIMPLE_CLASS_NAME = "AdActivity";
  
  private dx lf;
  
  private void X() {
    if (this.lf != null)
      try {
        this.lf.X();
        return;
      } catch (RemoteException remoteException) {
        gr.d("Could not forward setContentViewSet to ad overlay:", (Throwable)remoteException);
        return;
      }  
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.lf = dw.b(this);
    if (this.lf == null) {
      gr.W("Could not create ad overlay.");
      finish();
      return;
    } 
    try {
      this.lf.onCreate(paramBundle);
      return;
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onCreate to ad overlay:", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  protected void onDestroy() {
    try {
      if (this.lf != null)
        this.lf.onDestroy(); 
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onDestroy to ad overlay:", (Throwable)remoteException);
    } 
    super.onDestroy();
  }
  
  protected void onPause() {
    try {
      if (this.lf != null)
        this.lf.onPause(); 
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onPause to ad overlay:", (Throwable)remoteException);
      finish();
    } 
    super.onPause();
  }
  
  protected void onRestart() {
    super.onRestart();
    try {
      if (this.lf != null)
        this.lf.onRestart(); 
      return;
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onRestart to ad overlay:", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  protected void onResume() {
    super.onResume();
    try {
      if (this.lf != null)
        this.lf.onResume(); 
      return;
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onResume to ad overlay:", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    try {
      if (this.lf != null)
        this.lf.onSaveInstanceState(paramBundle); 
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onSaveInstanceState to ad overlay:", (Throwable)remoteException);
      finish();
    } 
    super.onSaveInstanceState(paramBundle);
  }
  
  protected void onStart() {
    super.onStart();
    try {
      if (this.lf != null)
        this.lf.onStart(); 
      return;
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onStart to ad overlay:", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  protected void onStop() {
    try {
      if (this.lf != null)
        this.lf.onStop(); 
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onStop to ad overlay:", (Throwable)remoteException);
      finish();
    } 
    super.onStop();
  }
  
  public void setContentView(int paramInt) {
    super.setContentView(paramInt);
    X();
  }
  
  public void setContentView(View paramView) {
    super.setContentView(paramView);
    X();
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    super.setContentView(paramView, paramLayoutParams);
    X();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\ads\AdActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */