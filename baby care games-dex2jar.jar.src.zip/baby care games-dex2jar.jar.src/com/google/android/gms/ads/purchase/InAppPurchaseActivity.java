package com.google.android.gms.ads.purchase;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.internal.eo;
import com.google.android.gms.internal.et;
import com.google.android.gms.internal.gr;

public final class InAppPurchaseActivity extends Activity {
  public static final String CLASS_NAME = "com.google.android.gms.ads.purchase.InAppPurchaseActivity";
  
  public static final String SIMPLE_CLASS_NAME = "InAppPurchaseActivity";
  
  private eo xz;
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    try {
      if (this.xz != null)
        this.xz.onActivityResult(paramInt1, paramInt2, paramIntent); 
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onActivityResult to in-app purchase manager:", (Throwable)remoteException);
    } 
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.xz = et.e(this);
    if (this.xz == null) {
      gr.W("Could not create in-app purchase manager.");
      finish();
      return;
    } 
    try {
      this.xz.onCreate();
      return;
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onCreate to in-app purchase manager:", (Throwable)remoteException);
      finish();
      return;
    } 
  }
  
  protected void onDestroy() {
    try {
      if (this.xz != null)
        this.xz.onDestroy(); 
    } catch (RemoteException remoteException) {
      gr.d("Could not forward onDestroy to in-app purchase manager:", (Throwable)remoteException);
    } 
    super.onDestroy();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\ads\purchase\InAppPurchaseActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */