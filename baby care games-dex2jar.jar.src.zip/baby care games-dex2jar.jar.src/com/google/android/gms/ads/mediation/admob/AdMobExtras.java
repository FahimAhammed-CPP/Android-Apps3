package com.google.android.gms.ads.mediation.admob;

import android.os.Bundle;
import com.google.ads.mediation.NetworkExtras;

@Deprecated
public final class AdMobExtras implements NetworkExtras {
  private final Bundle mExtras;
  
  public AdMobExtras(Bundle paramBundle) {
    if (paramBundle != null) {
      paramBundle = new Bundle(paramBundle);
    } else {
      paramBundle = null;
    } 
    this.mExtras = paramBundle;
  }
  
  public Bundle getExtras() {
    return this.mExtras;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\ads\mediation\admob\AdMobExtras.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */