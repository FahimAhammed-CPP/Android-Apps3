package com.google.android.gms.ads.doubleclick;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.customevent.CustomEvent;
import com.google.android.gms.internal.bg;
import com.google.android.gms.internal.jx;
import java.util.Date;
import java.util.Set;

public final class PublisherAdRequest {
  public static final String DEVICE_ID_EMULATOR = bg.DEVICE_ID_EMULATOR;
  
  public static final int ERROR_CODE_INTERNAL_ERROR = 0;
  
  public static final int ERROR_CODE_INVALID_REQUEST = 1;
  
  public static final int ERROR_CODE_NETWORK_ERROR = 2;
  
  public static final int ERROR_CODE_NO_FILL = 3;
  
  public static final int GENDER_FEMALE = 2;
  
  public static final int GENDER_MALE = 1;
  
  public static final int GENDER_UNKNOWN = 0;
  
  private final bg lg;
  
  private PublisherAdRequest(Builder paramBuilder) {
    this.lg = new bg(Builder.a(paramBuilder));
  }
  
  public bg Y() {
    return this.lg;
  }
  
  public Date getBirthday() {
    return this.lg.getBirthday();
  }
  
  public String getContentUrl() {
    return this.lg.getContentUrl();
  }
  
  public <T extends CustomEvent> Bundle getCustomEventExtrasBundle(Class<T> paramClass) {
    return this.lg.getCustomEventExtrasBundle(paramClass);
  }
  
  public int getGender() {
    return this.lg.getGender();
  }
  
  public Set<String> getKeywords() {
    return this.lg.getKeywords();
  }
  
  public Location getLocation() {
    return this.lg.getLocation();
  }
  
  public boolean getManualImpressionsEnabled() {
    return this.lg.getManualImpressionsEnabled();
  }
  
  @Deprecated
  public <T extends NetworkExtras> T getNetworkExtras(Class<T> paramClass) {
    return (T)this.lg.getNetworkExtras(paramClass);
  }
  
  public <T extends MediationAdapter> Bundle getNetworkExtrasBundle(Class<T> paramClass) {
    return this.lg.getNetworkExtrasBundle(paramClass);
  }
  
  public String getPublisherProvidedId() {
    return this.lg.getPublisherProvidedId();
  }
  
  public boolean isTestDevice(Context paramContext) {
    return this.lg.isTestDevice(paramContext);
  }
  
  public static final class Builder {
    private final bg.a lh = new bg.a();
    
    public Builder addCustomEventExtrasBundle(Class<? extends CustomEvent> param1Class, Bundle param1Bundle) {
      this.lh.b(param1Class, param1Bundle);
      return this;
    }
    
    public Builder addKeyword(String param1String) {
      this.lh.r(param1String);
      return this;
    }
    
    public Builder addNetworkExtras(NetworkExtras param1NetworkExtras) {
      this.lh.a(param1NetworkExtras);
      return this;
    }
    
    public Builder addNetworkExtrasBundle(Class<? extends MediationAdapter> param1Class, Bundle param1Bundle) {
      this.lh.a(param1Class, param1Bundle);
      return this;
    }
    
    public Builder addTestDevice(String param1String) {
      this.lh.s(param1String);
      return this;
    }
    
    public PublisherAdRequest build() {
      return new PublisherAdRequest(this);
    }
    
    public Builder setBirthday(Date param1Date) {
      this.lh.a(param1Date);
      return this;
    }
    
    public Builder setContentUrl(String param1String) {
      jx.b(param1String, "Content URL must be non-null.");
      jx.b(param1String, "Content URL must be non-empty.");
      if (param1String.length() <= 512) {
        boolean bool1 = true;
        jx.b(bool1, "Content URL must not exceed %d in length.  Provided length was %d.", new Object[] { Integer.valueOf(512), Integer.valueOf(param1String.length()) });
        this.lh.t(param1String);
        return this;
      } 
      boolean bool = false;
      jx.b(bool, "Content URL must not exceed %d in length.  Provided length was %d.", new Object[] { Integer.valueOf(512), Integer.valueOf(param1String.length()) });
      this.lh.t(param1String);
      return this;
    }
    
    public Builder setGender(int param1Int) {
      this.lh.h(param1Int);
      return this;
    }
    
    public Builder setLocation(Location param1Location) {
      this.lh.a(param1Location);
      return this;
    }
    
    public Builder setManualImpressionsEnabled(boolean param1Boolean) {
      this.lh.i(param1Boolean);
      return this;
    }
    
    public Builder setPublisherProvidedId(String param1String) {
      this.lh.u(param1String);
      return this;
    }
    
    public Builder tagForChildDirectedTreatment(boolean param1Boolean) {
      this.lh.j(param1Boolean);
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\ads\doubleclick\PublisherAdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */