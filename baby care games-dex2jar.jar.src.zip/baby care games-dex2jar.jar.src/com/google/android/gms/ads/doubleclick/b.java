package com.google.android.gms.ads.doubleclick;

public interface b {
  void a(a parama);
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\ads\doubleclick\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */