package com.google.android.gms.appstate;

import com.google.android.gms.internal.jv;

public final class a implements AppState {
  private final int DK;
  
  private final String DL;
  
  private final byte[] DM;
  
  private final boolean DN;
  
  private final String DO;
  
  private final byte[] DP;
  
  public a(AppState paramAppState) {
    this.DK = paramAppState.getKey();
    this.DL = paramAppState.getLocalVersion();
    this.DM = paramAppState.getLocalData();
    this.DN = paramAppState.hasConflict();
    this.DO = paramAppState.getConflictVersion();
    this.DP = paramAppState.getConflictData();
  }
  
  static int a(AppState paramAppState) {
    return jv.hashCode(new Object[] { Integer.valueOf(paramAppState.getKey()), paramAppState.getLocalVersion(), paramAppState.getLocalData(), Boolean.valueOf(paramAppState.hasConflict()), paramAppState.getConflictVersion(), paramAppState.getConflictData() });
  }
  
  static boolean a(AppState paramAppState, Object paramObject) {
    boolean bool2 = true;
    if (!(paramObject instanceof AppState))
      return false; 
    boolean bool1 = bool2;
    if (paramAppState != paramObject) {
      paramObject = paramObject;
      if (jv.equal(Integer.valueOf(paramObject.getKey()), Integer.valueOf(paramAppState.getKey())) && jv.equal(paramObject.getLocalVersion(), paramAppState.getLocalVersion()) && jv.equal(paramObject.getLocalData(), paramAppState.getLocalData()) && jv.equal(Boolean.valueOf(paramObject.hasConflict()), Boolean.valueOf(paramAppState.hasConflict())) && jv.equal(paramObject.getConflictVersion(), paramAppState.getConflictVersion())) {
        bool1 = bool2;
        return !jv.equal(paramObject.getConflictData(), paramAppState.getConflictData()) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  static String b(AppState paramAppState) {
    return jv.h(paramAppState).a("Key", Integer.valueOf(paramAppState.getKey())).a("LocalVersion", paramAppState.getLocalVersion()).a("LocalData", paramAppState.getLocalData()).a("HasConflict", Boolean.valueOf(paramAppState.hasConflict())).a("ConflictVersion", paramAppState.getConflictVersion()).a("ConflictData", paramAppState.getConflictData()).toString();
  }
  
  public boolean equals(Object paramObject) {
    return a(this, paramObject);
  }
  
  public AppState fJ() {
    return this;
  }
  
  public byte[] getConflictData() {
    return this.DP;
  }
  
  public String getConflictVersion() {
    return this.DO;
  }
  
  public int getKey() {
    return this.DK;
  }
  
  public byte[] getLocalData() {
    return this.DM;
  }
  
  public String getLocalVersion() {
    return this.DL;
  }
  
  public boolean hasConflict() {
    return this.DN;
  }
  
  public int hashCode() {
    return a(this);
  }
  
  public boolean isDataValid() {
    return true;
  }
  
  public String toString() {
    return b(this);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\appstate\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */