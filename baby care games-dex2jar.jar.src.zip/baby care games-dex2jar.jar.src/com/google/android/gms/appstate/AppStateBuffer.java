package com.google.android.gms.appstate;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.DataHolder;

public final class AppStateBuffer extends DataBuffer<AppState> {
  public AppStateBuffer(DataHolder paramDataHolder) {
    super(paramDataHolder);
  }
  
  public AppState get(int paramInt) {
    return new b(this.JG, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\appstate\AppStateBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */