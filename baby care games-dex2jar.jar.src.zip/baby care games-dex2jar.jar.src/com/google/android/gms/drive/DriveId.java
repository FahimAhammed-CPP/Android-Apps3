package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.internal.ak;
import com.google.android.gms.drive.internal.w;
import com.google.android.gms.internal.jx;
import com.google.android.gms.internal.qv;
import com.google.android.gms.internal.qw;

public class DriveId implements SafeParcelable {
  public static final Parcelable.Creator<DriveId> CREATOR = new c();
  
  final int CK;
  
  final String Ot;
  
  final long Ou;
  
  final long Ov;
  
  private volatile String Ow;
  
  DriveId(int paramInt, String paramString, long paramLong1, long paramLong2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #8
    //   3: aload_0
    //   4: invokespecial <init> : ()V
    //   7: aload_0
    //   8: aconst_null
    //   9: putfield Ow : Ljava/lang/String;
    //   12: aload_0
    //   13: iload_1
    //   14: putfield CK : I
    //   17: aload_0
    //   18: aload_2
    //   19: putfield Ot : Ljava/lang/String;
    //   22: ldc ''
    //   24: aload_2
    //   25: invokevirtual equals : (Ljava/lang/Object;)Z
    //   28: ifne -> 75
    //   31: iconst_1
    //   32: istore #7
    //   34: iload #7
    //   36: invokestatic L : (Z)V
    //   39: aload_2
    //   40: ifnonnull -> 55
    //   43: iload #8
    //   45: istore #7
    //   47: lload_3
    //   48: ldc2_w -1
    //   51: lcmp
    //   52: ifeq -> 58
    //   55: iconst_1
    //   56: istore #7
    //   58: iload #7
    //   60: invokestatic L : (Z)V
    //   63: aload_0
    //   64: lload_3
    //   65: putfield Ou : J
    //   68: aload_0
    //   69: lload #5
    //   71: putfield Ov : J
    //   74: return
    //   75: iconst_0
    //   76: istore #7
    //   78: goto -> 34
  }
  
  public DriveId(String paramString, long paramLong1, long paramLong2) {
    this(1, paramString, paramLong1, paramLong2);
  }
  
  public static DriveId bi(String paramString) {
    jx.i(paramString);
    return new DriveId(paramString, -1L, -1L);
  }
  
  public static DriveId decodeFromString(String paramString) {
    jx.b(paramString.startsWith("DriveId:"), "Invalid DriveId: " + paramString);
    return f(Base64.decode(paramString.substring("DriveId:".length()), 10));
  }
  
  static DriveId f(byte[] paramArrayOfbyte) {
    ak ak;
    try {
      ak = ak.g(paramArrayOfbyte);
      if ("".equals(ak.QG)) {
        paramArrayOfbyte = null;
        return new DriveId(ak.versionCode, (String)paramArrayOfbyte, ak.QH, ak.QI);
      } 
    } catch (qv qv) {
      throw new IllegalArgumentException();
    } 
    String str = ak.QG;
    return new DriveId(ak.versionCode, str, ak.QH, ak.QI);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public final String encodeToString() {
    if (this.Ow == null) {
      String str = Base64.encodeToString(iu(), 10);
      this.Ow = "DriveId:" + str;
    } 
    return this.Ow;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof DriveId) {
      paramObject = paramObject;
      if (((DriveId)paramObject).Ov != this.Ov) {
        w.o("DriveId", "Attempt to compare invalid DriveId detected. Has local storage been cleared?");
        return false;
      } 
      if (((DriveId)paramObject).Ou == -1L && this.Ou == -1L)
        return ((DriveId)paramObject).Ot.equals(this.Ot); 
      if (((DriveId)paramObject).Ou == this.Ou)
        return true; 
    } 
    return false;
  }
  
  public String getResourceId() {
    return this.Ot;
  }
  
  public int hashCode() {
    return (this.Ou == -1L) ? this.Ot.hashCode() : (String.valueOf(this.Ov) + String.valueOf(this.Ou)).hashCode();
  }
  
  final byte[] iu() {
    ak ak = new ak();
    ak.versionCode = this.CK;
    if (this.Ot == null) {
      String str1 = "";
      ak.QG = str1;
      ak.QH = this.Ou;
      ak.QI = this.Ov;
      return qw.f((qw)ak);
    } 
    String str = this.Ot;
    ak.QG = str;
    ak.QH = this.Ou;
    ak.QI = this.Ov;
    return qw.f((qw)ak);
  }
  
  public String toString() {
    return encodeToString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    c.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\DriveId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */