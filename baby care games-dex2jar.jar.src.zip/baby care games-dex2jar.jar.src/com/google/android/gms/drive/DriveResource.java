package com.google.android.gms.drive;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.events.ChangeListener;
import java.util.Set;

public interface DriveResource {
  PendingResult<Status> addChangeListener(GoogleApiClient paramGoogleApiClient, ChangeListener paramChangeListener);
  
  PendingResult<Status> addChangeSubscription(GoogleApiClient paramGoogleApiClient);
  
  DriveId getDriveId();
  
  PendingResult<MetadataResult> getMetadata(GoogleApiClient paramGoogleApiClient);
  
  PendingResult<DriveApi.MetadataBufferResult> listParents(GoogleApiClient paramGoogleApiClient);
  
  PendingResult<Status> removeChangeListener(GoogleApiClient paramGoogleApiClient, ChangeListener paramChangeListener);
  
  PendingResult<Status> removeChangeSubscription(GoogleApiClient paramGoogleApiClient);
  
  PendingResult<Status> setParents(GoogleApiClient paramGoogleApiClient, Set<DriveId> paramSet);
  
  PendingResult<MetadataResult> updateMetadata(GoogleApiClient paramGoogleApiClient, MetadataChangeSet paramMetadataChangeSet);
  
  public static interface MetadataResult extends Result {
    Metadata getMetadata();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\DriveResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */