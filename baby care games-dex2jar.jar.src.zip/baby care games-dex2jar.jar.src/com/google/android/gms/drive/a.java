package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.b;

public class a implements Parcelable.Creator<Contents> {
  static void a(Contents paramContents, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramContents.CK);
    b.a(paramParcel, 2, (Parcelable)paramContents.LG, paramInt, false);
    b.c(paramParcel, 3, paramContents.ve);
    b.c(paramParcel, 4, paramContents.Oi);
    b.a(paramParcel, 5, (Parcelable)paramContents.Oj, paramInt, false);
    b.a(paramParcel, 7, paramContents.Ok);
    b.H(paramParcel, i);
  }
  
  public Contents R(Parcel paramParcel) {
    DriveId driveId = null;
    boolean bool = false;
    int m = com.google.android.gms.common.internal.safeparcel.a.G(paramParcel);
    int i = 0;
    int j = 0;
    ParcelFileDescriptor parcelFileDescriptor = null;
    int k = 0;
    while (paramParcel.dataPosition() < m) {
      int n = com.google.android.gms.common.internal.safeparcel.a.F(paramParcel);
      switch (com.google.android.gms.common.internal.safeparcel.a.aH(n)) {
        case 1:
          k = com.google.android.gms.common.internal.safeparcel.a.g(paramParcel, n);
          break;
        case 2:
          parcelFileDescriptor = (ParcelFileDescriptor)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, n, ParcelFileDescriptor.CREATOR);
          break;
        case 3:
          j = com.google.android.gms.common.internal.safeparcel.a.g(paramParcel, n);
          break;
        case 4:
          i = com.google.android.gms.common.internal.safeparcel.a.g(paramParcel, n);
          break;
        case 5:
          driveId = (DriveId)com.google.android.gms.common.internal.safeparcel.a.a(paramParcel, n, DriveId.CREATOR);
          break;
        case 7:
          bool = com.google.android.gms.common.internal.safeparcel.a.c(paramParcel, n);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != m)
      throw new com.google.android.gms.common.internal.safeparcel.a.a("Overread allowed size end=" + m, paramParcel); 
    return new Contents(k, parcelFileDescriptor, j, i, driveId, bool);
  }
  
  public Contents[] aX(int paramInt) {
    return new Contents[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */