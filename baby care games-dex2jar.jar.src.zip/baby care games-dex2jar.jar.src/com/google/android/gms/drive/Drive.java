package com.google.android.gms.drive;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.drive.internal.p;
import com.google.android.gms.drive.internal.r;
import com.google.android.gms.drive.internal.u;
import com.google.android.gms.drive.internal.x;
import com.google.android.gms.drive.internal.z;
import com.google.android.gms.internal.jg;
import java.util.List;

public final class Drive {
  public static final Api<Api.ApiOptions.NoOptions> API;
  
  public static final Api.c<r> DQ = new Api.c();
  
  public static final DriveApi DriveApi;
  
  public static final DrivePreferencesApi DrivePreferencesApi;
  
  public static final Scope Oo;
  
  public static final Scope Op;
  
  public static final Api<b> Oq;
  
  public static final b Or;
  
  public static final e Os;
  
  public static final Scope SCOPE_APPFOLDER;
  
  public static final Scope SCOPE_FILE = new Scope("https://www.googleapis.com/auth/drive.file");
  
  static {
    SCOPE_APPFOLDER = new Scope("https://www.googleapis.com/auth/drive.appdata");
    Oo = new Scope("https://www.googleapis.com/auth/drive");
    Op = new Scope("https://www.googleapis.com/auth/drive.apps");
    API = new Api(new a<Api.ApiOptions.NoOptions>() {
          protected Bundle a(Api.ApiOptions.NoOptions param1NoOptions) {
            return new Bundle();
          }
        },  DQ, new Scope[0]);
    Oq = new Api(new a<b>() {
          protected Bundle a(Drive.b param1b) {
            return (param1b == null) ? new Bundle() : param1b.iq();
          }
        },  DQ, new Scope[0]);
    DriveApi = (DriveApi)new p();
    Or = (b)new u();
    Os = (e)new z();
    DrivePreferencesApi = (DrivePreferencesApi)new x();
  }
  
  public static abstract class a<O extends Api.ApiOptions> implements Api.b<r, O> {
    protected abstract Bundle a(O param1O);
    
    public r a(Context param1Context, Looper param1Looper, jg param1jg, O param1O, GoogleApiClient.ConnectionCallbacks param1ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener param1OnConnectionFailedListener) {
      List list = param1jg.ho();
      return new r(param1Context, param1Looper, param1jg, param1ConnectionCallbacks, param1OnConnectionFailedListener, (String[])list.toArray((Object[])new String[list.size()]), a(param1O));
    }
    
    public int getPriority() {
      return Integer.MAX_VALUE;
    }
  }
  
  public static class b implements Api.ApiOptions.Optional {
    private final Bundle DJ;
    
    private b() {
      this(new Bundle());
    }
    
    private b(Bundle param1Bundle) {
      this.DJ = param1Bundle;
    }
    
    public Bundle iq() {
      return this.DJ;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\Drive.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */