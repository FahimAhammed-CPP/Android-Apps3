package com.google.android.gms.drive;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.query.Query;
import java.util.List;

public interface DriveApi {
  PendingResult<Status> cancelPendingActions(GoogleApiClient paramGoogleApiClient, List<String> paramList);
  
  PendingResult<DriveIdResult> fetchDriveId(GoogleApiClient paramGoogleApiClient, String paramString);
  
  DriveFolder getAppFolder(GoogleApiClient paramGoogleApiClient);
  
  DriveFile getFile(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId);
  
  DriveFolder getFolder(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId);
  
  DriveFolder getRootFolder(GoogleApiClient paramGoogleApiClient);
  
  CreateFileActivityBuilder newCreateFileActivityBuilder();
  
  PendingResult<DriveContentsResult> newDriveContents(GoogleApiClient paramGoogleApiClient);
  
  OpenFileActivityBuilder newOpenFileActivityBuilder();
  
  PendingResult<MetadataBufferResult> query(GoogleApiClient paramGoogleApiClient, Query paramQuery);
  
  PendingResult<Status> requestSync(GoogleApiClient paramGoogleApiClient);
  
  public static interface DriveContentsResult extends Result {
    DriveContents getDriveContents();
  }
  
  public static interface DriveIdResult extends Result {
    DriveId getDriveId();
  }
  
  public static interface MetadataBufferResult extends Result {
    MetadataBuffer getMetadataBuffer();
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\DriveApi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */