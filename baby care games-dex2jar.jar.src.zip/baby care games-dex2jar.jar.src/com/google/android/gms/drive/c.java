package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class c implements Parcelable.Creator<DriveId> {
  static void a(DriveId paramDriveId, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramDriveId.CK);
    b.a(paramParcel, 2, paramDriveId.Ot, false);
    b.a(paramParcel, 3, paramDriveId.Ou);
    b.a(paramParcel, 4, paramDriveId.Ov);
    b.H(paramParcel, paramInt);
  }
  
  public DriveId S(Parcel paramParcel) {
    long l1 = 0L;
    int j = a.G(paramParcel);
    int i = 0;
    String str = null;
    long l2 = 0L;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          str = a.o(paramParcel, k);
          break;
        case 3:
          l2 = a.i(paramParcel, k);
          break;
        case 4:
          l1 = a.i(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new DriveId(i, str, l2, l1);
  }
  
  public DriveId[] aY(int paramInt) {
    return new DriveId[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */