package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class DrivePreferences implements SafeParcelable {
  public static final Parcelable.Creator<DrivePreferences> CREATOR = new d();
  
  final int CK;
  
  final boolean Ox;
  
  DrivePreferences(int paramInt, boolean paramBoolean) {
    this.CK = paramInt;
    this.Ox = paramBoolean;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    d.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\DrivePreferences.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */