package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;

public class ay implements Parcelable.Creator<OpenContentsRequest> {
  static void a(OpenContentsRequest paramOpenContentsRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramOpenContentsRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramOpenContentsRequest.Pp, paramInt, false);
    b.c(paramParcel, 3, paramOpenContentsRequest.Oi);
    b.c(paramParcel, 4, paramOpenContentsRequest.QT);
    b.H(paramParcel, i);
  }
  
  public OpenContentsRequest aD(Parcel paramParcel) {
    int i = 0;
    int m = a.G(paramParcel);
    DriveId driveId = null;
    int j = 0;
    int k = 0;
    while (paramParcel.dataPosition() < m) {
      int n = a.F(paramParcel);
      switch (a.aH(n)) {
        case 1:
          k = a.g(paramParcel, n);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, n, DriveId.CREATOR);
          break;
        case 3:
          j = a.g(paramParcel, n);
          break;
        case 4:
          i = a.g(paramParcel, n);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != m)
      throw new a.a("Overread allowed size end=" + m, paramParcel); 
    return new OpenContentsRequest(k, driveId, j, i);
  }
  
  public OpenContentsRequest[] bS(int paramInt) {
    return new OpenContentsRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\ay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */