package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveFile;

class az extends c {
  private final BaseImplementation.b<DriveApi.DriveContentsResult> Ea;
  
  private final DriveFile.DownloadProgressListener QU;
  
  az(BaseImplementation.b<DriveApi.DriveContentsResult> paramb, DriveFile.DownloadProgressListener paramDownloadProgressListener) {
    this.Ea = paramb;
    this.QU = paramDownloadProgressListener;
  }
  
  public void a(OnContentsResponse paramOnContentsResponse) throws RemoteException {
    Status status;
    if (paramOnContentsResponse.iM()) {
      status = new Status(-1);
    } else {
      status = Status.Kw;
    } 
    this.Ea.b(new p.a(status, new s(paramOnContentsResponse.iL())));
  }
  
  public void a(OnDownloadProgressResponse paramOnDownloadProgressResponse) throws RemoteException {
    if (this.QU != null)
      this.QU.onProgress(paramOnDownloadProgressResponse.iO(), paramOnDownloadProgressResponse.iP()); 
  }
  
  public void n(Status paramStatus) throws RemoteException {
    this.Ea.b(new p.a(paramStatus, null));
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\az.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */