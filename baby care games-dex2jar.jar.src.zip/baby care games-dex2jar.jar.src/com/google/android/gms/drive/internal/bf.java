package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DriveId;
import java.util.ArrayList;

public class bf implements Parcelable.Creator<SetResourceParentsRequest> {
  static void a(SetResourceParentsRequest paramSetResourceParentsRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramSetResourceParentsRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramSetResourceParentsRequest.QW, paramInt, false);
    b.c(paramParcel, 3, paramSetResourceParentsRequest.QX, false);
    b.H(paramParcel, i);
  }
  
  public SetResourceParentsRequest aJ(Parcel paramParcel) {
    ArrayList<DriveId> arrayList = null;
    int j = a.G(paramParcel);
    int i = 0;
    DriveId driveId = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, k, DriveId.CREATOR);
          break;
        case 3:
          arrayList = a.c(paramParcel, k, DriveId.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new SetResourceParentsRequest(i, driveId, arrayList);
  }
  
  public SetResourceParentsRequest[] bY(int paramInt) {
    return new SetResourceParentsRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\bf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */