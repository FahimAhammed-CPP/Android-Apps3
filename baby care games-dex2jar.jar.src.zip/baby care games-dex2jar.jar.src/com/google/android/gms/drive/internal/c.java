package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.realtime.internal.m;

public class c extends af.a {
  public void a(OnContentsResponse paramOnContentsResponse) throws RemoteException {}
  
  public void a(OnDeviceUsagePreferenceResponse paramOnDeviceUsagePreferenceResponse) throws RemoteException {}
  
  public void a(OnDownloadProgressResponse paramOnDownloadProgressResponse) throws RemoteException {}
  
  public void a(OnDriveIdResponse paramOnDriveIdResponse) throws RemoteException {}
  
  public void a(OnDrivePreferencesResponse paramOnDrivePreferencesResponse) throws RemoteException {}
  
  public void a(OnListEntriesResponse paramOnListEntriesResponse) throws RemoteException {}
  
  public void a(OnListParentsResponse paramOnListParentsResponse) throws RemoteException {}
  
  public void a(OnLoadRealtimeResponse paramOnLoadRealtimeResponse, m paramm) throws RemoteException {}
  
  public void a(OnMetadataResponse paramOnMetadataResponse) throws RemoteException {}
  
  public void a(OnResourceIdSetResponse paramOnResourceIdSetResponse) throws RemoteException {}
  
  public void a(OnStorageStatsResponse paramOnStorageStatsResponse) throws RemoteException {}
  
  public void a(OnSyncMoreResponse paramOnSyncMoreResponse) throws RemoteException {}
  
  public void n(Status paramStatus) throws RemoteException {}
  
  public void onSuccess() throws RemoteException {}
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */