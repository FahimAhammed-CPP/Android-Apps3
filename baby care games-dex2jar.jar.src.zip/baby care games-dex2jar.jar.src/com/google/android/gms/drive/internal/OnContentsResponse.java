package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.Contents;

public class OnContentsResponse implements SafeParcelable {
  public static final Parcelable.Creator<OnContentsResponse> CREATOR = new al();
  
  final int CK;
  
  final Contents PW;
  
  final boolean QJ;
  
  OnContentsResponse(int paramInt, Contents paramContents, boolean paramBoolean) {
    this.CK = paramInt;
    this.PW = paramContents;
    this.QJ = paramBoolean;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Contents iL() {
    return this.PW;
  }
  
  public boolean iM() {
    return this.QJ;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    al.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\OnContentsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */