package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.CompletionEvent;

public class aq implements Parcelable.Creator<OnEventResponse> {
  static void a(OnEventResponse paramOnEventResponse, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramOnEventResponse.CK);
    b.c(paramParcel, 2, paramOnEventResponse.Pm);
    b.a(paramParcel, 3, (Parcelable)paramOnEventResponse.QO, paramInt, false);
    b.a(paramParcel, 5, (Parcelable)paramOnEventResponse.QP, paramInt, false);
    b.H(paramParcel, i);
  }
  
  public OnEventResponse av(Parcel paramParcel) {
    CompletionEvent completionEvent = null;
    int j = 0;
    int k = a.G(paramParcel);
    ChangeEvent changeEvent = null;
    int i = 0;
    while (paramParcel.dataPosition() < k) {
      int m = a.F(paramParcel);
      switch (a.aH(m)) {
        case 1:
          m = a.g(paramParcel, m);
          i = j;
          j = m;
          m = j;
          j = i;
          i = m;
          break;
        case 2:
          m = a.g(paramParcel, m);
          j = i;
          i = m;
          m = j;
          j = i;
          i = m;
          break;
        case 3:
          changeEvent = (ChangeEvent)a.a(paramParcel, m, ChangeEvent.CREATOR);
          m = i;
          i = j;
          j = m;
          m = j;
          j = i;
          i = m;
          break;
        case 5:
          completionEvent = (CompletionEvent)a.a(paramParcel, m, CompletionEvent.CREATOR);
          m = i;
          i = j;
          j = m;
          m = j;
          j = i;
          i = m;
          break;
      } 
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new OnEventResponse(i, j, changeEvent, completionEvent);
  }
  
  public OnEventResponse[] bK(int paramInt) {
    return new OnEventResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\aq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */