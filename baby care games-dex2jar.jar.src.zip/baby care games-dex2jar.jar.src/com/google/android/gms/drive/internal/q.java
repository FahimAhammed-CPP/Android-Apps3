package com.google.android.gms.drive.internal;

import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Drive;

abstract class q<R extends Result> extends BaseImplementation.a<R, r> {
  public q(GoogleApiClient paramGoogleApiClient) {
    super(Drive.DQ, paramGoogleApiClient);
  }
  
  static abstract class a extends q<Status> {
    a(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    protected Status b(Status param1Status) {
      return param1Status;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */