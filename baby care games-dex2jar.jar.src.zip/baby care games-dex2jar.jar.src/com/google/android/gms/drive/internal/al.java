package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.Contents;

public class al implements Parcelable.Creator<OnContentsResponse> {
  static void a(OnContentsResponse paramOnContentsResponse, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramOnContentsResponse.CK);
    b.a(paramParcel, 2, (Parcelable)paramOnContentsResponse.PW, paramInt, false);
    b.a(paramParcel, 3, paramOnContentsResponse.QJ);
    b.H(paramParcel, i);
  }
  
  public OnContentsResponse aq(Parcel paramParcel) {
    boolean bool = false;
    int j = a.G(paramParcel);
    Contents contents = null;
    int i = 0;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          contents = (Contents)a.a(paramParcel, k, Contents.CREATOR);
          break;
        case 3:
          bool = a.c(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OnContentsResponse(i, contents, bool);
  }
  
  public OnContentsResponse[] bF(int paramInt) {
    return new OnContentsResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */