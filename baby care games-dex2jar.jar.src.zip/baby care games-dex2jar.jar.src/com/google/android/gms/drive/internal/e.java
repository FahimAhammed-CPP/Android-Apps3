package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class e implements Parcelable.Creator<CheckResourceIdsExistRequest> {
  static void a(CheckResourceIdsExistRequest paramCheckResourceIdsExistRequest, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramCheckResourceIdsExistRequest.getVersionCode());
    b.b(paramParcel, 2, paramCheckResourceIdsExistRequest.iF(), false);
    b.H(paramParcel, paramInt);
  }
  
  public CheckResourceIdsExistRequest ac(Parcel paramParcel) {
    int j = a.G(paramParcel);
    int i = 0;
    ArrayList<String> arrayList = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          arrayList = a.C(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new CheckResourceIdsExistRequest(i, arrayList);
  }
  
  public CheckResourceIdsExistRequest[] bm(int paramInt) {
    return new CheckResourceIdsExistRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */