package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.DrivePreferences;

public class ap implements Parcelable.Creator<OnDrivePreferencesResponse> {
  static void a(OnDrivePreferencesResponse paramOnDrivePreferencesResponse, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramOnDrivePreferencesResponse.CK);
    b.a(paramParcel, 2, (Parcelable)paramOnDrivePreferencesResponse.QN, paramInt, false);
    b.H(paramParcel, i);
  }
  
  public OnDrivePreferencesResponse au(Parcel paramParcel) {
    int j = a.G(paramParcel);
    int i = 0;
    DrivePreferences drivePreferences = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          drivePreferences = (DrivePreferences)a.a(paramParcel, k, DrivePreferences.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OnDrivePreferencesResponse(i, drivePreferences);
  }
  
  public OnDrivePreferencesResponse[] bJ(int paramInt) {
    return new OnDrivePreferencesResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\ap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */