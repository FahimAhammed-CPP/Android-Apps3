package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class h implements Parcelable.Creator<CreateContentsRequest> {
  static void a(CreateContentsRequest paramCreateContentsRequest, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramCreateContentsRequest.CK);
    b.c(paramParcel, 2, paramCreateContentsRequest.Oi);
    b.H(paramParcel, paramInt);
  }
  
  public CreateContentsRequest af(Parcel paramParcel) {
    int k = a.G(paramParcel);
    int i = 0;
    int j = 536870912;
    while (paramParcel.dataPosition() < k) {
      int m = a.F(paramParcel);
      switch (a.aH(m)) {
        case 1:
          i = a.g(paramParcel, m);
          break;
        case 2:
          j = a.g(paramParcel, m);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != k)
      throw new a.a("Overread allowed size end=" + k, paramParcel); 
    return new CreateContentsRequest(i, j);
  }
  
  public CreateContentsRequest[] bp(int paramInt) {
    return new CreateContentsRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */