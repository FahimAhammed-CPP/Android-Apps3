package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class OnMetadataResponse implements SafeParcelable {
  public static final Parcelable.Creator<OnMetadataResponse> CREATOR = new at();
  
  final int CK;
  
  final MetadataBundle Px;
  
  OnMetadataResponse(int paramInt, MetadataBundle paramMetadataBundle) {
    this.CK = paramInt;
    this.Px = paramMetadataBundle;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public MetadataBundle iU() {
    return this.Px;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    at.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\OnMetadataResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */