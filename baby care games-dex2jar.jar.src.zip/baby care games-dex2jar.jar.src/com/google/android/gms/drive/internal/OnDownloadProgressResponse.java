package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnDownloadProgressResponse implements SafeParcelable {
  public static final Parcelable.Creator<OnDownloadProgressResponse> CREATOR = new an();
  
  final int CK;
  
  final long QL;
  
  final long QM;
  
  OnDownloadProgressResponse(int paramInt, long paramLong1, long paramLong2) {
    this.CK = paramInt;
    this.QL = paramLong1;
    this.QM = paramLong2;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public long iO() {
    return this.QL;
  }
  
  public long iP() {
    return this.QM;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    an.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\OnDownloadProgressResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */