package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.CreateFileActivityBuilder;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.OpenFileActivityBuilder;
import com.google.android.gms.drive.query.Query;
import java.util.List;

public class p implements DriveApi {
  public PendingResult<DriveApi.DriveContentsResult> a(GoogleApiClient paramGoogleApiClient, int paramInt) {
    return (PendingResult<DriveApi.DriveContentsResult>)paramGoogleApiClient.a(new b(this, paramGoogleApiClient, paramInt) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new CreateContentsRequest(this.PG), new p.h((BaseImplementation.b<DriveApi.DriveContentsResult>)this));
          }
        });
  }
  
  public PendingResult<Status> cancelPendingActions(GoogleApiClient paramGoogleApiClient, List<String> paramList) {
    return ((r)paramGoogleApiClient.a(Drive.DQ)).cancelPendingActions(paramGoogleApiClient, paramList);
  }
  
  public PendingResult<DriveApi.DriveIdResult> fetchDriveId(GoogleApiClient paramGoogleApiClient, String paramString) {
    return (PendingResult<DriveApi.DriveIdResult>)paramGoogleApiClient.a(new e(this, paramGoogleApiClient, paramString) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new GetMetadataRequest(DriveId.bi(this.PH)), new p.c((BaseImplementation.b<DriveApi.DriveIdResult>)this));
          }
        });
  }
  
  public DriveFolder getAppFolder(GoogleApiClient paramGoogleApiClient) {
    if (!paramGoogleApiClient.isConnected())
      throw new IllegalStateException("Client must be connected"); 
    DriveId driveId = ((r)paramGoogleApiClient.a(Drive.DQ)).iI();
    return (driveId != null) ? new v(driveId) : null;
  }
  
  public DriveFile getFile(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId) {
    if (paramDriveId == null)
      throw new IllegalArgumentException("Id must be provided."); 
    if (!paramGoogleApiClient.isConnected())
      throw new IllegalStateException("Client must be connected"); 
    return new t(paramDriveId);
  }
  
  public DriveFolder getFolder(GoogleApiClient paramGoogleApiClient, DriveId paramDriveId) {
    if (paramDriveId == null)
      throw new IllegalArgumentException("Id must be provided."); 
    if (!paramGoogleApiClient.isConnected())
      throw new IllegalStateException("Client must be connected"); 
    return new v(paramDriveId);
  }
  
  public DriveFolder getRootFolder(GoogleApiClient paramGoogleApiClient) {
    if (!paramGoogleApiClient.isConnected())
      throw new IllegalStateException("Client must be connected"); 
    return new v(((r)paramGoogleApiClient.a(Drive.DQ)).iH());
  }
  
  public CreateFileActivityBuilder newCreateFileActivityBuilder() {
    return new CreateFileActivityBuilder();
  }
  
  public PendingResult<DriveApi.DriveContentsResult> newDriveContents(GoogleApiClient paramGoogleApiClient) {
    return a(paramGoogleApiClient, 536870912);
  }
  
  public OpenFileActivityBuilder newOpenFileActivityBuilder() {
    return new OpenFileActivityBuilder();
  }
  
  public PendingResult<DriveApi.MetadataBufferResult> query(GoogleApiClient paramGoogleApiClient, Query paramQuery) {
    if (paramQuery == null)
      throw new IllegalArgumentException("Query must be provided."); 
    return (PendingResult<DriveApi.MetadataBufferResult>)paramGoogleApiClient.a(new g(this, paramGoogleApiClient, paramQuery) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new QueryRequest(this.PE), new p.i((BaseImplementation.b<DriveApi.MetadataBufferResult>)this));
          }
        });
  }
  
  public PendingResult<Status> requestSync(GoogleApiClient paramGoogleApiClient) {
    return (PendingResult<Status>)paramGoogleApiClient.b(new q.a(this, paramGoogleApiClient) {
          protected void a(r param1r) throws RemoteException {
            param1r.iG().a(new bg((BaseImplementation.b<Status>)this));
          }
        });
  }
  
  static class a implements DriveApi.DriveContentsResult {
    private final Status Eb;
    
    private final DriveContents Om;
    
    public a(Status param1Status, DriveContents param1DriveContents) {
      this.Eb = param1Status;
      this.Om = param1DriveContents;
    }
    
    public DriveContents getDriveContents() {
      return this.Om;
    }
    
    public Status getStatus() {
      return this.Eb;
    }
  }
  
  static abstract class b extends q<DriveApi.DriveContentsResult> {
    b(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public DriveApi.DriveContentsResult o(Status param1Status) {
      return new p.a(param1Status, null);
    }
  }
  
  static class c extends c {
    private final BaseImplementation.b<DriveApi.DriveIdResult> Ea;
    
    public c(BaseImplementation.b<DriveApi.DriveIdResult> param1b) {
      this.Ea = param1b;
    }
    
    public void a(OnDriveIdResponse param1OnDriveIdResponse) throws RemoteException {
      this.Ea.b(new p.d(Status.Kw, param1OnDriveIdResponse.getDriveId()));
    }
    
    public void a(OnMetadataResponse param1OnMetadataResponse) throws RemoteException {
      this.Ea.b(new p.d(Status.Kw, (new m(param1OnMetadataResponse.iU())).getDriveId()));
    }
    
    public void n(Status param1Status) throws RemoteException {
      this.Ea.b(new p.d(param1Status, null));
    }
  }
  
  private static class d implements DriveApi.DriveIdResult {
    private final Status Eb;
    
    private final DriveId Oj;
    
    public d(Status param1Status, DriveId param1DriveId) {
      this.Eb = param1Status;
      this.Oj = param1DriveId;
    }
    
    public DriveId getDriveId() {
      return this.Oj;
    }
    
    public Status getStatus() {
      return this.Eb;
    }
  }
  
  static abstract class e extends q<DriveApi.DriveIdResult> {
    e(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public DriveApi.DriveIdResult p(Status param1Status) {
      return new p.d(param1Status, null);
    }
  }
  
  static class f implements DriveApi.MetadataBufferResult {
    private final Status Eb;
    
    private final MetadataBuffer PI;
    
    private final boolean PJ;
    
    public f(Status param1Status, MetadataBuffer param1MetadataBuffer, boolean param1Boolean) {
      this.Eb = param1Status;
      this.PI = param1MetadataBuffer;
      this.PJ = param1Boolean;
    }
    
    public MetadataBuffer getMetadataBuffer() {
      return this.PI;
    }
    
    public Status getStatus() {
      return this.Eb;
    }
  }
  
  static abstract class g extends q<DriveApi.MetadataBufferResult> {
    g(GoogleApiClient param1GoogleApiClient) {
      super(param1GoogleApiClient);
    }
    
    public DriveApi.MetadataBufferResult q(Status param1Status) {
      return new p.f(param1Status, null, false);
    }
  }
  
  private static class h extends c {
    private final BaseImplementation.b<DriveApi.DriveContentsResult> Ea;
    
    public h(BaseImplementation.b<DriveApi.DriveContentsResult> param1b) {
      this.Ea = param1b;
    }
    
    public void a(OnContentsResponse param1OnContentsResponse) throws RemoteException {
      this.Ea.b(new p.a(Status.Kw, new s(param1OnContentsResponse.iL())));
    }
    
    public void n(Status param1Status) throws RemoteException {
      this.Ea.b(new p.a(param1Status, null));
    }
  }
  
  private static class i extends c {
    private final BaseImplementation.b<DriveApi.MetadataBufferResult> Ea;
    
    public i(BaseImplementation.b<DriveApi.MetadataBufferResult> param1b) {
      this.Ea = param1b;
    }
    
    public void a(OnListEntriesResponse param1OnListEntriesResponse) throws RemoteException {
      MetadataBuffer metadataBuffer = new MetadataBuffer(param1OnListEntriesResponse.iR(), null);
      this.Ea.b(new p.f(Status.Kw, metadataBuffer, param1OnListEntriesResponse.iS()));
    }
    
    public void n(Status param1Status) throws RemoteException {
      this.Ea.b(new p.f(param1Status, null, false));
    }
  }
  
  static class j extends q.a {
    j(GoogleApiClient param1GoogleApiClient, Status param1Status) {
      super(param1GoogleApiClient);
      b((Result)param1Status);
    }
    
    protected void a(r param1r) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */