package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.jx;

public class CreateContentsRequest implements SafeParcelable {
  public static final Parcelable.Creator<CreateContentsRequest> CREATOR = new h();
  
  final int CK;
  
  final int Oi;
  
  public CreateContentsRequest(int paramInt) {
    this(1, paramInt);
  }
  
  CreateContentsRequest(int paramInt1, int paramInt2) {
    boolean bool;
    this.CK = paramInt1;
    if (paramInt2 == 536870912 || paramInt2 == 805306368) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.b(bool, "Cannot create a new read-only contents!");
    this.Oi = paramInt2;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    h.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\CreateContentsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */