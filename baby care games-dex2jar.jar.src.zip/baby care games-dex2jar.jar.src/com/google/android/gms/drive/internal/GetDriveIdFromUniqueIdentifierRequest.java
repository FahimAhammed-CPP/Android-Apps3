package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class GetDriveIdFromUniqueIdentifierRequest implements SafeParcelable {
  public static final Parcelable.Creator<GetDriveIdFromUniqueIdentifierRequest> CREATOR = new ac();
  
  final int CK;
  
  final String QC;
  
  final boolean QD;
  
  GetDriveIdFromUniqueIdentifierRequest(int paramInt, String paramString, boolean paramBoolean) {
    this.CK = paramInt;
    this.QC = paramString;
    this.QD = paramBoolean;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ac.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\GetDriveIdFromUniqueIdentifierRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */