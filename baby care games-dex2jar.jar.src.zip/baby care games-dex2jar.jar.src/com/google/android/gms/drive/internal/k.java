package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class k implements Parcelable.Creator<CreateFileRequest> {
  static void a(CreateFileRequest paramCreateFileRequest, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramCreateFileRequest.CK);
    b.a(paramParcel, 2, (Parcelable)paramCreateFileRequest.Pz, paramInt, false);
    b.a(paramParcel, 3, (Parcelable)paramCreateFileRequest.Px, paramInt, false);
    b.a(paramParcel, 4, (Parcelable)paramCreateFileRequest.Pr, paramInt, false);
    b.a(paramParcel, 5, paramCreateFileRequest.Py, false);
    b.a(paramParcel, 6, paramCreateFileRequest.PA);
    b.a(paramParcel, 7, paramCreateFileRequest.Oy, false);
    b.c(paramParcel, 8, paramCreateFileRequest.PB);
    b.c(paramParcel, 9, paramCreateFileRequest.PC);
    b.H(paramParcel, i);
  }
  
  public CreateFileRequest ah(Parcel paramParcel) {
    int i = 0;
    String str = null;
    int n = a.G(paramParcel);
    int j = 0;
    boolean bool = false;
    Integer integer = null;
    Contents contents = null;
    MetadataBundle metadataBundle = null;
    DriveId driveId = null;
    int m = 0;
    while (paramParcel.dataPosition() < n) {
      int i1 = a.F(paramParcel);
      switch (a.aH(i1)) {
        case 1:
          m = a.g(paramParcel, i1);
          break;
        case 2:
          driveId = (DriveId)a.a(paramParcel, i1, DriveId.CREATOR);
          break;
        case 3:
          metadataBundle = (MetadataBundle)a.a(paramParcel, i1, MetadataBundle.CREATOR);
          break;
        case 4:
          contents = (Contents)a.a(paramParcel, i1, Contents.CREATOR);
          break;
        case 5:
          integer = a.h(paramParcel, i1);
          break;
        case 6:
          bool = a.c(paramParcel, i1);
          break;
        case 7:
          str = a.o(paramParcel, i1);
          break;
        case 8:
          j = a.g(paramParcel, i1);
          break;
        case 9:
          i = a.g(paramParcel, i1);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != n)
      throw new a.a("Overread allowed size end=" + n, paramParcel); 
    return new CreateFileRequest(m, driveId, metadataBundle, contents, integer, bool, str, j, i);
  }
  
  public CreateFileRequest[] bs(int paramInt) {
    return new CreateFileRequest[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */