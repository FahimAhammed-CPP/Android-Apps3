package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class OnSyncMoreResponse implements SafeParcelable {
  public static final Parcelable.Creator<OnSyncMoreResponse> CREATOR = new ax();
  
  final int CK;
  
  final boolean PJ;
  
  OnSyncMoreResponse(int paramInt, boolean paramBoolean) {
    this.CK = paramInt;
    this.PJ = paramBoolean;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    ax.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\OnSyncMoreResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */