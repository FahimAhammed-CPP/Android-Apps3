package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;

public class at implements Parcelable.Creator<OnMetadataResponse> {
  static void a(OnMetadataResponse paramOnMetadataResponse, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramOnMetadataResponse.CK);
    b.a(paramParcel, 2, (Parcelable)paramOnMetadataResponse.Px, paramInt, false);
    b.H(paramParcel, i);
  }
  
  public OnMetadataResponse ay(Parcel paramParcel) {
    int j = a.G(paramParcel);
    int i = 0;
    MetadataBundle metadataBundle = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          metadataBundle = (MetadataBundle)a.a(paramParcel, k, MetadataBundle.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OnMetadataResponse(i, metadataBundle);
  }
  
  public OnMetadataResponse[] bN(int paramInt) {
    return new OnMetadataResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\at.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */