package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.i;

public class OnListParentsResponse extends i implements SafeParcelable {
  public static final Parcelable.Creator<OnListParentsResponse> CREATOR = new as();
  
  final int CK;
  
  final DataHolder QR;
  
  OnListParentsResponse(int paramInt, DataHolder paramDataHolder) {
    this.CK = paramInt;
    this.QR = paramDataHolder;
  }
  
  protected void I(Parcel paramParcel, int paramInt) {
    as.a(this, paramParcel, paramInt);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public DataHolder iT() {
    return this.QR;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\OnListParentsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */