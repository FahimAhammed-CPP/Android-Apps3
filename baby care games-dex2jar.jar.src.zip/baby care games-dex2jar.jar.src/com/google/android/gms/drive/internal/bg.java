package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.Status;

public class bg extends c {
  private final BaseImplementation.b<Status> Ea;
  
  public bg(BaseImplementation.b<Status> paramb) {
    this.Ea = paramb;
  }
  
  public void n(Status paramStatus) throws RemoteException {
    this.Ea.b(paramStatus);
  }
  
  public void onSuccess() throws RemoteException {
    this.Ea.b(Status.Kw);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\bg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */