package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class an implements Parcelable.Creator<OnDownloadProgressResponse> {
  static void a(OnDownloadProgressResponse paramOnDownloadProgressResponse, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramOnDownloadProgressResponse.CK);
    b.a(paramParcel, 2, paramOnDownloadProgressResponse.QL);
    b.a(paramParcel, 3, paramOnDownloadProgressResponse.QM);
    b.H(paramParcel, paramInt);
  }
  
  public OnDownloadProgressResponse as(Parcel paramParcel) {
    long l1 = 0L;
    int j = a.G(paramParcel);
    int i = 0;
    long l2 = 0L;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          l2 = a.i(paramParcel, k);
          break;
        case 3:
          l1 = a.i(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OnDownloadProgressResponse(i, l2, l1);
  }
  
  public OnDownloadProgressResponse[] bH(int paramInt) {
    return new OnDownloadProgressResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */