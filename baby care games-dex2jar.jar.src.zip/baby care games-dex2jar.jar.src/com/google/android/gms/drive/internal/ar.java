package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class ar implements Parcelable.Creator<OnListEntriesResponse> {
  static void a(OnListEntriesResponse paramOnListEntriesResponse, Parcel paramParcel, int paramInt) {
    int i = b.H(paramParcel);
    b.c(paramParcel, 1, paramOnListEntriesResponse.CK);
    b.a(paramParcel, 2, (Parcelable)paramOnListEntriesResponse.QQ, paramInt, false);
    b.a(paramParcel, 3, paramOnListEntriesResponse.PJ);
    b.H(paramParcel, i);
  }
  
  public OnListEntriesResponse aw(Parcel paramParcel) {
    boolean bool = false;
    int j = a.G(paramParcel);
    DataHolder dataHolder = null;
    int i = 0;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          dataHolder = (DataHolder)a.a(paramParcel, k, (Parcelable.Creator)DataHolder.CREATOR);
          break;
        case 3:
          bool = a.c(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new OnListEntriesResponse(i, dataHolder, bool);
  }
  
  public OnListEntriesResponse[] bL(int paramInt) {
    return new OnListEntriesResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */