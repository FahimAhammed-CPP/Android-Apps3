package com.google.android.gms.drive.internal;

import android.content.IntentSender;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.drive.RealtimeDocumentSyncRequest;

public interface ae extends IInterface {
  IntentSender a(CreateFileIntentSenderRequest paramCreateFileIntentSenderRequest) throws RemoteException;
  
  IntentSender a(OpenFileIntentSenderRequest paramOpenFileIntentSenderRequest) throws RemoteException;
  
  void a(RealtimeDocumentSyncRequest paramRealtimeDocumentSyncRequest, af paramaf) throws RemoteException;
  
  void a(AddEventListenerRequest paramAddEventListenerRequest, ag paramag, String paramString, af paramaf) throws RemoteException;
  
  void a(AuthorizeAccessRequest paramAuthorizeAccessRequest, af paramaf) throws RemoteException;
  
  void a(CancelPendingActionsRequest paramCancelPendingActionsRequest, af paramaf) throws RemoteException;
  
  void a(CheckResourceIdsExistRequest paramCheckResourceIdsExistRequest, af paramaf) throws RemoteException;
  
  void a(CloseContentsAndUpdateMetadataRequest paramCloseContentsAndUpdateMetadataRequest, af paramaf) throws RemoteException;
  
  void a(CloseContentsRequest paramCloseContentsRequest, af paramaf) throws RemoteException;
  
  void a(CreateContentsRequest paramCreateContentsRequest, af paramaf) throws RemoteException;
  
  void a(CreateFileRequest paramCreateFileRequest, af paramaf) throws RemoteException;
  
  void a(CreateFolderRequest paramCreateFolderRequest, af paramaf) throws RemoteException;
  
  void a(DeleteResourceRequest paramDeleteResourceRequest, af paramaf) throws RemoteException;
  
  void a(DisconnectRequest paramDisconnectRequest) throws RemoteException;
  
  void a(GetDriveIdFromUniqueIdentifierRequest paramGetDriveIdFromUniqueIdentifierRequest, af paramaf) throws RemoteException;
  
  void a(GetMetadataRequest paramGetMetadataRequest, af paramaf) throws RemoteException;
  
  void a(ListParentsRequest paramListParentsRequest, af paramaf) throws RemoteException;
  
  void a(LoadRealtimeRequest paramLoadRealtimeRequest, af paramaf) throws RemoteException;
  
  void a(OpenContentsRequest paramOpenContentsRequest, af paramaf) throws RemoteException;
  
  void a(QueryRequest paramQueryRequest, af paramaf) throws RemoteException;
  
  void a(RemoveEventListenerRequest paramRemoveEventListenerRequest, ag paramag, String paramString, af paramaf) throws RemoteException;
  
  void a(SetDrivePreferencesRequest paramSetDrivePreferencesRequest, af paramaf) throws RemoteException;
  
  void a(SetFileUploadPreferencesRequest paramSetFileUploadPreferencesRequest, af paramaf) throws RemoteException;
  
  void a(SetResourceParentsRequest paramSetResourceParentsRequest, af paramaf) throws RemoteException;
  
  void a(TrashResourceRequest paramTrashResourceRequest, af paramaf) throws RemoteException;
  
  void a(UpdateMetadataRequest paramUpdateMetadataRequest, af paramaf) throws RemoteException;
  
  void a(af paramaf) throws RemoteException;
  
  void b(QueryRequest paramQueryRequest, af paramaf) throws RemoteException;
  
  void b(af paramaf) throws RemoteException;
  
  void c(af paramaf) throws RemoteException;
  
  void d(af paramaf) throws RemoteException;
  
  void e(af paramaf) throws RemoteException;
  
  void f(af paramaf) throws RemoteException;
  
  void g(af paramaf) throws RemoteException;
  
  void h(af paramaf) throws RemoteException;
  
  public static abstract class a extends Binder implements ae {
    public static ae X(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.google.android.gms.drive.internal.IDriveService");
      return (iInterface != null && iInterface instanceof ae) ? (ae)iInterface : new a(param1IBinder);
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      IntentSender intentSender;
      QueryRequest queryRequest2;
      UpdateMetadataRequest updateMetadataRequest1;
      CreateContentsRequest createContentsRequest1;
      CreateFileRequest createFileRequest1;
      CreateFolderRequest createFolderRequest1;
      OpenContentsRequest openContentsRequest1;
      CloseContentsRequest closeContentsRequest1;
      OpenFileIntentSenderRequest openFileIntentSenderRequest1;
      CreateFileIntentSenderRequest createFileIntentSenderRequest1;
      AuthorizeAccessRequest authorizeAccessRequest1;
      ListParentsRequest listParentsRequest1;
      AddEventListenerRequest addEventListenerRequest1;
      RemoveEventListenerRequest removeEventListenerRequest1;
      DisconnectRequest disconnectRequest1;
      TrashResourceRequest trashResourceRequest1;
      CloseContentsAndUpdateMetadataRequest closeContentsAndUpdateMetadataRequest1;
      QueryRequest queryRequest1;
      DeleteResourceRequest deleteResourceRequest1;
      LoadRealtimeRequest loadRealtimeRequest1;
      SetResourceParentsRequest setResourceParentsRequest1;
      GetDriveIdFromUniqueIdentifierRequest getDriveIdFromUniqueIdentifierRequest1;
      CheckResourceIdsExistRequest checkResourceIdsExistRequest1;
      SetDrivePreferencesRequest setDrivePreferencesRequest1;
      RealtimeDocumentSyncRequest realtimeDocumentSyncRequest1;
      CancelPendingActionsRequest cancelPendingActionsRequest;
      GetMetadataRequest getMetadataRequest2 = null;
      QueryRequest queryRequest3 = null;
      UpdateMetadataRequest updateMetadataRequest2 = null;
      CreateContentsRequest createContentsRequest2 = null;
      CreateFileRequest createFileRequest2 = null;
      CreateFolderRequest createFolderRequest2 = null;
      OpenContentsRequest openContentsRequest2 = null;
      CloseContentsRequest closeContentsRequest2 = null;
      OpenFileIntentSenderRequest openFileIntentSenderRequest2 = null;
      CreateFileIntentSenderRequest createFileIntentSenderRequest2 = null;
      AuthorizeAccessRequest authorizeAccessRequest2 = null;
      ListParentsRequest listParentsRequest2 = null;
      AddEventListenerRequest addEventListenerRequest2 = null;
      RemoveEventListenerRequest removeEventListenerRequest2 = null;
      DisconnectRequest disconnectRequest2 = null;
      TrashResourceRequest trashResourceRequest2 = null;
      CloseContentsAndUpdateMetadataRequest closeContentsAndUpdateMetadataRequest2 = null;
      QueryRequest queryRequest4 = null;
      DeleteResourceRequest deleteResourceRequest2 = null;
      LoadRealtimeRequest loadRealtimeRequest2 = null;
      SetResourceParentsRequest setResourceParentsRequest2 = null;
      GetDriveIdFromUniqueIdentifierRequest getDriveIdFromUniqueIdentifierRequest2 = null;
      CheckResourceIdsExistRequest checkResourceIdsExistRequest2 = null;
      SetDrivePreferencesRequest setDrivePreferencesRequest2 = null;
      RealtimeDocumentSyncRequest realtimeDocumentSyncRequest2 = null;
      SetFileUploadPreferencesRequest setFileUploadPreferencesRequest2 = null;
      GetMetadataRequest getMetadataRequest1 = null;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.google.android.gms.drive.internal.IDriveService");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          if (param1Parcel1.readInt() != 0)
            getMetadataRequest1 = (GetMetadataRequest)GetMetadataRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(getMetadataRequest1, af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 2:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          getMetadataRequest1 = getMetadataRequest2;
          if (param1Parcel1.readInt() != 0)
            queryRequest2 = (QueryRequest)QueryRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(queryRequest2, af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 3:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          queryRequest2 = queryRequest3;
          if (param1Parcel1.readInt() != 0)
            updateMetadataRequest1 = (UpdateMetadataRequest)UpdateMetadataRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(updateMetadataRequest1, af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 4:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          updateMetadataRequest1 = updateMetadataRequest2;
          if (param1Parcel1.readInt() != 0)
            createContentsRequest1 = (CreateContentsRequest)CreateContentsRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(createContentsRequest1, af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 5:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          createContentsRequest1 = createContentsRequest2;
          if (param1Parcel1.readInt() != 0)
            createFileRequest1 = (CreateFileRequest)CreateFileRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(createFileRequest1, af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 6:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          createFileRequest1 = createFileRequest2;
          if (param1Parcel1.readInt() != 0)
            createFolderRequest1 = (CreateFolderRequest)CreateFolderRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(createFolderRequest1, af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 7:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          createFolderRequest1 = createFolderRequest2;
          if (param1Parcel1.readInt() != 0)
            openContentsRequest1 = (OpenContentsRequest)OpenContentsRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(openContentsRequest1, af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 8:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          openContentsRequest1 = openContentsRequest2;
          if (param1Parcel1.readInt() != 0)
            closeContentsRequest1 = (CloseContentsRequest)CloseContentsRequest.CREATOR.createFromParcel(param1Parcel1); 
          a(closeContentsRequest1, af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 9:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          a(af.a.Y(param1Parcel1.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 10:
          param1Parcel1.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          closeContentsRequest1 = closeContentsRequest2;
          if (param1Parcel1.readInt() != 0)
            openFileIntentSenderRequest1 = (OpenFileIntentSenderRequest)OpenFileIntentSenderRequest.CREATOR.createFromParcel(param1Parcel1); 
          intentSender = a(openFileIntentSenderRequest1);
          param1Parcel2.writeNoException();
          if (intentSender != null) {
            param1Parcel2.writeInt(1);
            intentSender.writeToParcel(param1Parcel2, 1);
            return true;
          } 
          param1Parcel2.writeInt(0);
          return true;
        case 11:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          openFileIntentSenderRequest1 = openFileIntentSenderRequest2;
          if (intentSender.readInt() != 0)
            createFileIntentSenderRequest1 = (CreateFileIntentSenderRequest)CreateFileIntentSenderRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          intentSender = a(createFileIntentSenderRequest1);
          param1Parcel2.writeNoException();
          if (intentSender != null) {
            param1Parcel2.writeInt(1);
            intentSender.writeToParcel(param1Parcel2, 1);
            return true;
          } 
          param1Parcel2.writeInt(0);
          return true;
        case 12:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          createFileIntentSenderRequest1 = createFileIntentSenderRequest2;
          if (intentSender.readInt() != 0)
            authorizeAccessRequest1 = (AuthorizeAccessRequest)AuthorizeAccessRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(authorizeAccessRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 13:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          authorizeAccessRequest1 = authorizeAccessRequest2;
          if (intentSender.readInt() != 0)
            listParentsRequest1 = (ListParentsRequest)ListParentsRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(listParentsRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 14:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          listParentsRequest1 = listParentsRequest2;
          if (intentSender.readInt() != 0)
            addEventListenerRequest1 = (AddEventListenerRequest)AddEventListenerRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(addEventListenerRequest1, ag.a.Z(intentSender.readStrongBinder()), intentSender.readString(), af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 15:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          addEventListenerRequest1 = addEventListenerRequest2;
          if (intentSender.readInt() != 0)
            removeEventListenerRequest1 = (RemoveEventListenerRequest)RemoveEventListenerRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(removeEventListenerRequest1, ag.a.Z(intentSender.readStrongBinder()), intentSender.readString(), af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 16:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          removeEventListenerRequest1 = removeEventListenerRequest2;
          if (intentSender.readInt() != 0)
            disconnectRequest1 = (DisconnectRequest)DisconnectRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(disconnectRequest1);
          param1Parcel2.writeNoException();
          return true;
        case 17:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          disconnectRequest1 = disconnectRequest2;
          if (intentSender.readInt() != 0)
            trashResourceRequest1 = (TrashResourceRequest)TrashResourceRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(trashResourceRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 18:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          trashResourceRequest1 = trashResourceRequest2;
          if (intentSender.readInt() != 0)
            closeContentsAndUpdateMetadataRequest1 = (CloseContentsAndUpdateMetadataRequest)CloseContentsAndUpdateMetadataRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(closeContentsAndUpdateMetadataRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 19:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          closeContentsAndUpdateMetadataRequest1 = closeContentsAndUpdateMetadataRequest2;
          if (intentSender.readInt() != 0)
            queryRequest1 = (QueryRequest)QueryRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          b(queryRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 20:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          b(af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 21:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          c(af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 22:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          d(af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 23:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          e(af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 24:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          queryRequest1 = queryRequest4;
          if (intentSender.readInt() != 0)
            deleteResourceRequest1 = (DeleteResourceRequest)DeleteResourceRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(deleteResourceRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 27:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          deleteResourceRequest1 = deleteResourceRequest2;
          if (intentSender.readInt() != 0)
            loadRealtimeRequest1 = (LoadRealtimeRequest)LoadRealtimeRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(loadRealtimeRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 28:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          loadRealtimeRequest1 = loadRealtimeRequest2;
          if (intentSender.readInt() != 0)
            setResourceParentsRequest1 = (SetResourceParentsRequest)SetResourceParentsRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(setResourceParentsRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 29:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          setResourceParentsRequest1 = setResourceParentsRequest2;
          if (intentSender.readInt() != 0)
            getDriveIdFromUniqueIdentifierRequest1 = (GetDriveIdFromUniqueIdentifierRequest)GetDriveIdFromUniqueIdentifierRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(getDriveIdFromUniqueIdentifierRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 30:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          getDriveIdFromUniqueIdentifierRequest1 = getDriveIdFromUniqueIdentifierRequest2;
          if (intentSender.readInt() != 0)
            checkResourceIdsExistRequest1 = (CheckResourceIdsExistRequest)CheckResourceIdsExistRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(checkResourceIdsExistRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 31:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          f(af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 32:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          g(af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 33:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          checkResourceIdsExistRequest1 = checkResourceIdsExistRequest2;
          if (intentSender.readInt() != 0)
            setDrivePreferencesRequest1 = (SetDrivePreferencesRequest)SetDrivePreferencesRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(setDrivePreferencesRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 34:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          setDrivePreferencesRequest1 = setDrivePreferencesRequest2;
          if (intentSender.readInt() != 0)
            realtimeDocumentSyncRequest1 = (RealtimeDocumentSyncRequest)RealtimeDocumentSyncRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(realtimeDocumentSyncRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 35:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          h(af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 36:
          intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
          realtimeDocumentSyncRequest1 = realtimeDocumentSyncRequest2;
          if (intentSender.readInt() != 0)
            setFileUploadPreferencesRequest1 = (SetFileUploadPreferencesRequest)SetFileUploadPreferencesRequest.CREATOR.createFromParcel((Parcel)intentSender); 
          a(setFileUploadPreferencesRequest1, af.a.Y(intentSender.readStrongBinder()));
          param1Parcel2.writeNoException();
          return true;
        case 37:
          break;
      } 
      intentSender.enforceInterface("com.google.android.gms.drive.internal.IDriveService");
      SetFileUploadPreferencesRequest setFileUploadPreferencesRequest1 = setFileUploadPreferencesRequest2;
      if (intentSender.readInt() != 0)
        cancelPendingActionsRequest = (CancelPendingActionsRequest)CancelPendingActionsRequest.CREATOR.createFromParcel((Parcel)intentSender); 
      a(cancelPendingActionsRequest, af.a.Y(intentSender.readStrongBinder()));
      param1Parcel2.writeNoException();
      return true;
    }
    
    private static class a implements ae {
      private IBinder le;
      
      a(IBinder param2IBinder) {
        this.le = param2IBinder;
      }
      
      public IntentSender a(CreateFileIntentSenderRequest param2CreateFileIntentSenderRequest) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CreateFileIntentSenderRequest != null) {
            parcel1.writeInt(1);
            param2CreateFileIntentSenderRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(11, parcel1, parcel2, 0);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        param2CreateFileIntentSenderRequest = null;
        parcel2.recycle();
        parcel1.recycle();
        return (IntentSender)param2CreateFileIntentSenderRequest;
      }
      
      public IntentSender a(OpenFileIntentSenderRequest param2OpenFileIntentSenderRequest) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2OpenFileIntentSenderRequest != null) {
            parcel1.writeInt(1);
            param2OpenFileIntentSenderRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(10, parcel1, parcel2, 0);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
        param2OpenFileIntentSenderRequest = null;
        parcel2.recycle();
        parcel1.recycle();
        return (IntentSender)param2OpenFileIntentSenderRequest;
      }
      
      public void a(RealtimeDocumentSyncRequest param2RealtimeDocumentSyncRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2RealtimeDocumentSyncRequest != null) {
            parcel1.writeInt(1);
            param2RealtimeDocumentSyncRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2RealtimeDocumentSyncRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2RealtimeDocumentSyncRequest);
          this.le.transact(34, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(AddEventListenerRequest param2AddEventListenerRequest, ag param2ag, String param2String, af param2af) throws RemoteException {
        AddEventListenerRequest addEventListenerRequest = null;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2AddEventListenerRequest != null) {
            parcel1.writeInt(1);
            param2AddEventListenerRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2ag != null) {
            iBinder = param2ag.asBinder();
          } else {
            param2AddEventListenerRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2AddEventListenerRequest);
          parcel1.writeString(param2String);
          param2AddEventListenerRequest = addEventListenerRequest;
          if (param2af != null)
            iBinder = param2af.asBinder(); 
          parcel1.writeStrongBinder(iBinder);
          this.le.transact(14, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(AuthorizeAccessRequest param2AuthorizeAccessRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2AuthorizeAccessRequest != null) {
            parcel1.writeInt(1);
            param2AuthorizeAccessRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2AuthorizeAccessRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2AuthorizeAccessRequest);
          this.le.transact(12, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CancelPendingActionsRequest param2CancelPendingActionsRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CancelPendingActionsRequest != null) {
            parcel1.writeInt(1);
            param2CancelPendingActionsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2CancelPendingActionsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CancelPendingActionsRequest);
          this.le.transact(37, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CheckResourceIdsExistRequest param2CheckResourceIdsExistRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CheckResourceIdsExistRequest != null) {
            parcel1.writeInt(1);
            param2CheckResourceIdsExistRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2CheckResourceIdsExistRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CheckResourceIdsExistRequest);
          this.le.transact(30, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CloseContentsAndUpdateMetadataRequest param2CloseContentsAndUpdateMetadataRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CloseContentsAndUpdateMetadataRequest != null) {
            parcel1.writeInt(1);
            param2CloseContentsAndUpdateMetadataRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2CloseContentsAndUpdateMetadataRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CloseContentsAndUpdateMetadataRequest);
          this.le.transact(18, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CloseContentsRequest param2CloseContentsRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CloseContentsRequest != null) {
            parcel1.writeInt(1);
            param2CloseContentsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2CloseContentsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CloseContentsRequest);
          this.le.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CreateContentsRequest param2CreateContentsRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CreateContentsRequest != null) {
            parcel1.writeInt(1);
            param2CreateContentsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2CreateContentsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CreateContentsRequest);
          this.le.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CreateFileRequest param2CreateFileRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CreateFileRequest != null) {
            parcel1.writeInt(1);
            param2CreateFileRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2CreateFileRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CreateFileRequest);
          this.le.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(CreateFolderRequest param2CreateFolderRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2CreateFolderRequest != null) {
            parcel1.writeInt(1);
            param2CreateFolderRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2CreateFolderRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2CreateFolderRequest);
          this.le.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(DeleteResourceRequest param2DeleteResourceRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2DeleteResourceRequest != null) {
            parcel1.writeInt(1);
            param2DeleteResourceRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2DeleteResourceRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2DeleteResourceRequest);
          this.le.transact(24, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(DisconnectRequest param2DisconnectRequest) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2DisconnectRequest != null) {
            parcel1.writeInt(1);
            param2DisconnectRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.le.transact(16, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(GetDriveIdFromUniqueIdentifierRequest param2GetDriveIdFromUniqueIdentifierRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2GetDriveIdFromUniqueIdentifierRequest != null) {
            parcel1.writeInt(1);
            param2GetDriveIdFromUniqueIdentifierRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2GetDriveIdFromUniqueIdentifierRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2GetDriveIdFromUniqueIdentifierRequest);
          this.le.transact(29, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(GetMetadataRequest param2GetMetadataRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2GetMetadataRequest != null) {
            parcel1.writeInt(1);
            param2GetMetadataRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2GetMetadataRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2GetMetadataRequest);
          this.le.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(ListParentsRequest param2ListParentsRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2ListParentsRequest != null) {
            parcel1.writeInt(1);
            param2ListParentsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2ListParentsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2ListParentsRequest);
          this.le.transact(13, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(LoadRealtimeRequest param2LoadRealtimeRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2LoadRealtimeRequest != null) {
            parcel1.writeInt(1);
            param2LoadRealtimeRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2LoadRealtimeRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2LoadRealtimeRequest);
          this.le.transact(27, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(OpenContentsRequest param2OpenContentsRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2OpenContentsRequest != null) {
            parcel1.writeInt(1);
            param2OpenContentsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2OpenContentsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2OpenContentsRequest);
          this.le.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(QueryRequest param2QueryRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2QueryRequest != null) {
            parcel1.writeInt(1);
            param2QueryRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2QueryRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2QueryRequest);
          this.le.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(RemoveEventListenerRequest param2RemoveEventListenerRequest, ag param2ag, String param2String, af param2af) throws RemoteException {
        RemoveEventListenerRequest removeEventListenerRequest = null;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          IBinder iBinder;
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2RemoveEventListenerRequest != null) {
            parcel1.writeInt(1);
            param2RemoveEventListenerRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2ag != null) {
            iBinder = param2ag.asBinder();
          } else {
            param2RemoveEventListenerRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2RemoveEventListenerRequest);
          parcel1.writeString(param2String);
          param2RemoveEventListenerRequest = removeEventListenerRequest;
          if (param2af != null)
            iBinder = param2af.asBinder(); 
          parcel1.writeStrongBinder(iBinder);
          this.le.transact(15, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(SetDrivePreferencesRequest param2SetDrivePreferencesRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2SetDrivePreferencesRequest != null) {
            parcel1.writeInt(1);
            param2SetDrivePreferencesRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2SetDrivePreferencesRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2SetDrivePreferencesRequest);
          this.le.transact(33, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(SetFileUploadPreferencesRequest param2SetFileUploadPreferencesRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2SetFileUploadPreferencesRequest != null) {
            parcel1.writeInt(1);
            param2SetFileUploadPreferencesRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2SetFileUploadPreferencesRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2SetFileUploadPreferencesRequest);
          this.le.transact(36, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(SetResourceParentsRequest param2SetResourceParentsRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2SetResourceParentsRequest != null) {
            parcel1.writeInt(1);
            param2SetResourceParentsRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2SetResourceParentsRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2SetResourceParentsRequest);
          this.le.transact(28, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(TrashResourceRequest param2TrashResourceRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2TrashResourceRequest != null) {
            parcel1.writeInt(1);
            param2TrashResourceRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2TrashResourceRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2TrashResourceRequest);
          this.le.transact(17, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(UpdateMetadataRequest param2UpdateMetadataRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2UpdateMetadataRequest != null) {
            parcel1.writeInt(1);
            param2UpdateMetadataRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2UpdateMetadataRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2UpdateMetadataRequest);
          this.le.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void a(af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2af = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2af);
          this.le.transact(9, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.le;
      }
      
      public void b(QueryRequest param2QueryRequest, af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2QueryRequest != null) {
            parcel1.writeInt(1);
            param2QueryRequest.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2QueryRequest = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2QueryRequest);
          this.le.transact(19, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void b(af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2af = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2af);
          this.le.transact(20, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void c(af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2af = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2af);
          this.le.transact(21, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void d(af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2af = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2af);
          this.le.transact(22, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void e(af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2af = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2af);
          this.le.transact(23, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void f(af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2af = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2af);
          this.le.transact(31, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void g(af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2af = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2af);
          this.le.transact(32, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void h(af param2af) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
          if (param2af != null) {
            IBinder iBinder = param2af.asBinder();
          } else {
            param2af = null;
          } 
          parcel1.writeStrongBinder((IBinder)param2af);
          this.le.transact(35, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class a implements ae {
    private IBinder le;
    
    a(IBinder param1IBinder) {
      this.le = param1IBinder;
    }
    
    public IntentSender a(CreateFileIntentSenderRequest param1CreateFileIntentSenderRequest) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CreateFileIntentSenderRequest != null) {
          parcel1.writeInt(1);
          param1CreateFileIntentSenderRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(11, parcel1, parcel2, 0);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      param1CreateFileIntentSenderRequest = null;
      parcel2.recycle();
      parcel1.recycle();
      return (IntentSender)param1CreateFileIntentSenderRequest;
    }
    
    public IntentSender a(OpenFileIntentSenderRequest param1OpenFileIntentSenderRequest) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1OpenFileIntentSenderRequest != null) {
          parcel1.writeInt(1);
          param1OpenFileIntentSenderRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(10, parcel1, parcel2, 0);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
      param1OpenFileIntentSenderRequest = null;
      parcel2.recycle();
      parcel1.recycle();
      return (IntentSender)param1OpenFileIntentSenderRequest;
    }
    
    public void a(RealtimeDocumentSyncRequest param1RealtimeDocumentSyncRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1RealtimeDocumentSyncRequest != null) {
          parcel1.writeInt(1);
          param1RealtimeDocumentSyncRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1RealtimeDocumentSyncRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1RealtimeDocumentSyncRequest);
        this.le.transact(34, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(AddEventListenerRequest param1AddEventListenerRequest, ag param1ag, String param1String, af param1af) throws RemoteException {
      AddEventListenerRequest addEventListenerRequest = null;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1AddEventListenerRequest != null) {
          parcel1.writeInt(1);
          param1AddEventListenerRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1ag != null) {
          iBinder = param1ag.asBinder();
        } else {
          param1AddEventListenerRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1AddEventListenerRequest);
        parcel1.writeString(param1String);
        param1AddEventListenerRequest = addEventListenerRequest;
        if (param1af != null)
          iBinder = param1af.asBinder(); 
        parcel1.writeStrongBinder(iBinder);
        this.le.transact(14, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(AuthorizeAccessRequest param1AuthorizeAccessRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1AuthorizeAccessRequest != null) {
          parcel1.writeInt(1);
          param1AuthorizeAccessRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1AuthorizeAccessRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1AuthorizeAccessRequest);
        this.le.transact(12, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CancelPendingActionsRequest param1CancelPendingActionsRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CancelPendingActionsRequest != null) {
          parcel1.writeInt(1);
          param1CancelPendingActionsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1CancelPendingActionsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CancelPendingActionsRequest);
        this.le.transact(37, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CheckResourceIdsExistRequest param1CheckResourceIdsExistRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CheckResourceIdsExistRequest != null) {
          parcel1.writeInt(1);
          param1CheckResourceIdsExistRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1CheckResourceIdsExistRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CheckResourceIdsExistRequest);
        this.le.transact(30, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CloseContentsAndUpdateMetadataRequest param1CloseContentsAndUpdateMetadataRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CloseContentsAndUpdateMetadataRequest != null) {
          parcel1.writeInt(1);
          param1CloseContentsAndUpdateMetadataRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1CloseContentsAndUpdateMetadataRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CloseContentsAndUpdateMetadataRequest);
        this.le.transact(18, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CloseContentsRequest param1CloseContentsRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CloseContentsRequest != null) {
          parcel1.writeInt(1);
          param1CloseContentsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1CloseContentsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CloseContentsRequest);
        this.le.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CreateContentsRequest param1CreateContentsRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CreateContentsRequest != null) {
          parcel1.writeInt(1);
          param1CreateContentsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1CreateContentsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CreateContentsRequest);
        this.le.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CreateFileRequest param1CreateFileRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CreateFileRequest != null) {
          parcel1.writeInt(1);
          param1CreateFileRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1CreateFileRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CreateFileRequest);
        this.le.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(CreateFolderRequest param1CreateFolderRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1CreateFolderRequest != null) {
          parcel1.writeInt(1);
          param1CreateFolderRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1CreateFolderRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1CreateFolderRequest);
        this.le.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(DeleteResourceRequest param1DeleteResourceRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1DeleteResourceRequest != null) {
          parcel1.writeInt(1);
          param1DeleteResourceRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1DeleteResourceRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1DeleteResourceRequest);
        this.le.transact(24, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(DisconnectRequest param1DisconnectRequest) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1DisconnectRequest != null) {
          parcel1.writeInt(1);
          param1DisconnectRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.le.transact(16, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(GetDriveIdFromUniqueIdentifierRequest param1GetDriveIdFromUniqueIdentifierRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1GetDriveIdFromUniqueIdentifierRequest != null) {
          parcel1.writeInt(1);
          param1GetDriveIdFromUniqueIdentifierRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1GetDriveIdFromUniqueIdentifierRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1GetDriveIdFromUniqueIdentifierRequest);
        this.le.transact(29, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(GetMetadataRequest param1GetMetadataRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1GetMetadataRequest != null) {
          parcel1.writeInt(1);
          param1GetMetadataRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1GetMetadataRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1GetMetadataRequest);
        this.le.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(ListParentsRequest param1ListParentsRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1ListParentsRequest != null) {
          parcel1.writeInt(1);
          param1ListParentsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1ListParentsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1ListParentsRequest);
        this.le.transact(13, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(LoadRealtimeRequest param1LoadRealtimeRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1LoadRealtimeRequest != null) {
          parcel1.writeInt(1);
          param1LoadRealtimeRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1LoadRealtimeRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1LoadRealtimeRequest);
        this.le.transact(27, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(OpenContentsRequest param1OpenContentsRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1OpenContentsRequest != null) {
          parcel1.writeInt(1);
          param1OpenContentsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1OpenContentsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1OpenContentsRequest);
        this.le.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(QueryRequest param1QueryRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1QueryRequest != null) {
          parcel1.writeInt(1);
          param1QueryRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1QueryRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1QueryRequest);
        this.le.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(RemoveEventListenerRequest param1RemoveEventListenerRequest, ag param1ag, String param1String, af param1af) throws RemoteException {
      RemoveEventListenerRequest removeEventListenerRequest = null;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        IBinder iBinder;
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1RemoveEventListenerRequest != null) {
          parcel1.writeInt(1);
          param1RemoveEventListenerRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1ag != null) {
          iBinder = param1ag.asBinder();
        } else {
          param1RemoveEventListenerRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1RemoveEventListenerRequest);
        parcel1.writeString(param1String);
        param1RemoveEventListenerRequest = removeEventListenerRequest;
        if (param1af != null)
          iBinder = param1af.asBinder(); 
        parcel1.writeStrongBinder(iBinder);
        this.le.transact(15, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(SetDrivePreferencesRequest param1SetDrivePreferencesRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1SetDrivePreferencesRequest != null) {
          parcel1.writeInt(1);
          param1SetDrivePreferencesRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1SetDrivePreferencesRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1SetDrivePreferencesRequest);
        this.le.transact(33, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(SetFileUploadPreferencesRequest param1SetFileUploadPreferencesRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1SetFileUploadPreferencesRequest != null) {
          parcel1.writeInt(1);
          param1SetFileUploadPreferencesRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1SetFileUploadPreferencesRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1SetFileUploadPreferencesRequest);
        this.le.transact(36, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(SetResourceParentsRequest param1SetResourceParentsRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1SetResourceParentsRequest != null) {
          parcel1.writeInt(1);
          param1SetResourceParentsRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1SetResourceParentsRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1SetResourceParentsRequest);
        this.le.transact(28, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(TrashResourceRequest param1TrashResourceRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1TrashResourceRequest != null) {
          parcel1.writeInt(1);
          param1TrashResourceRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1TrashResourceRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1TrashResourceRequest);
        this.le.transact(17, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(UpdateMetadataRequest param1UpdateMetadataRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1UpdateMetadataRequest != null) {
          parcel1.writeInt(1);
          param1UpdateMetadataRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1UpdateMetadataRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1UpdateMetadataRequest);
        this.le.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void a(af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1af = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1af);
        this.le.transact(9, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.le;
    }
    
    public void b(QueryRequest param1QueryRequest, af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1QueryRequest != null) {
          parcel1.writeInt(1);
          param1QueryRequest.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1QueryRequest = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1QueryRequest);
        this.le.transact(19, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void b(af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1af = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1af);
        this.le.transact(20, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void c(af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1af = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1af);
        this.le.transact(21, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void d(af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1af = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1af);
        this.le.transact(22, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void e(af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1af = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1af);
        this.le.transact(23, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void f(af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1af = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1af);
        this.le.transact(31, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void g(af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1af = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1af);
        this.le.transact(32, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void h(af param1af) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.google.android.gms.drive.internal.IDriveService");
        if (param1af != null) {
          IBinder iBinder = param1af.asBinder();
        } else {
          param1af = null;
        } 
        parcel1.writeStrongBinder((IBinder)param1af);
        this.le.transact(35, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */