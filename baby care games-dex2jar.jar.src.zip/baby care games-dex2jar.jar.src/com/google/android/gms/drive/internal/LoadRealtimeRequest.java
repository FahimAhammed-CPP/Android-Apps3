package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.drive.DriveId;

public class LoadRealtimeRequest implements SafeParcelable {
  public static final Parcelable.Creator<LoadRealtimeRequest> CREATOR = new aj();
  
  final int CK;
  
  final DriveId Oj;
  
  final boolean QF;
  
  LoadRealtimeRequest(int paramInt, DriveId paramDriveId, boolean paramBoolean) {
    this.CK = paramInt;
    this.Oj = paramDriveId;
    this.QF = paramBoolean;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    aj.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\internal\LoadRealtimeRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */