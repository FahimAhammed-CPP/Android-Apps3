package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.jx;

public abstract class i implements Parcelable {
  private volatile transient boolean OW = false;
  
  protected abstract void I(Parcel paramParcel, int paramInt);
  
  public final boolean iB() {
    return this.OW;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    boolean bool;
    if (!iB()) {
      bool = true;
    } else {
      bool = false;
    } 
    jx.K(bool);
    this.OW = true;
    I(paramParcel, paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */