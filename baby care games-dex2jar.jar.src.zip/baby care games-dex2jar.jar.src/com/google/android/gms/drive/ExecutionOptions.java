package com.google.android.gms.drive;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.internal.r;
import com.google.android.gms.internal.jv;

public final class ExecutionOptions {
  public static final int CONFLICT_STRATEGY_KEEP_REMOTE = 1;
  
  public static final int CONFLICT_STRATEGY_OVERWRITE_REMOTE = 0;
  
  public static final int MAX_TRACKING_TAG_STRING_LENGTH = 65536;
  
  private final int OA;
  
  private final String Oy;
  
  private final boolean Oz;
  
  public ExecutionOptions(String paramString, boolean paramBoolean, int paramInt) {
    this.Oy = paramString;
    this.Oz = paramBoolean;
    this.OA = paramInt;
  }
  
  public static void a(GoogleApiClient paramGoogleApiClient, ExecutionOptions paramExecutionOptions) {
    r r = (r)paramGoogleApiClient.a(Drive.DQ);
    if (paramExecutionOptions.iw() && !r.iJ())
      throw new IllegalStateException("Application must define an exported DriveEventService subclass in AndroidManifest.xml to be notified on completion"); 
  }
  
  public static boolean ba(int paramInt) {
    switch (paramInt) {
      default:
        return false;
      case 1:
        break;
    } 
    return true;
  }
  
  public static boolean bb(int paramInt) {
    switch (paramInt) {
      default:
        return false;
      case 0:
      case 1:
        break;
    } 
    return true;
  }
  
  public static boolean bj(String paramString) {
    return (paramString != null && !paramString.isEmpty() && paramString.length() <= 65536);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool2 = true;
    if (paramObject == null || paramObject.getClass() != getClass())
      return false; 
    boolean bool1 = bool2;
    if (paramObject != this) {
      paramObject = paramObject;
      if (jv.equal(this.Oy, ((ExecutionOptions)paramObject).Oy) && this.OA == ((ExecutionOptions)paramObject).OA) {
        bool1 = bool2;
        return (this.Oz != ((ExecutionOptions)paramObject).Oz) ? false : bool1;
      } 
      return false;
    } 
    return bool1;
  }
  
  public int hashCode() {
    return jv.hashCode(new Object[] { this.Oy, Integer.valueOf(this.OA), Boolean.valueOf(this.Oz) });
  }
  
  public String iv() {
    return this.Oy;
  }
  
  public boolean iw() {
    return this.Oz;
  }
  
  public int ix() {
    return this.OA;
  }
  
  public static final class Builder {
    private int OA = 0;
    
    private String Oy;
    
    private boolean Oz;
    
    public ExecutionOptions build() {
      if (this.OA == 1 && !this.Oz)
        throw new IllegalStateException("Cannot use CONFLICT_STRATEGY_KEEP_REMOTE without requesting completion notifications"); 
      return new ExecutionOptions(this.Oy, this.Oz, this.OA);
    }
    
    public Builder setConflictStrategy(int param1Int) {
      if (!ExecutionOptions.bb(param1Int))
        throw new IllegalArgumentException("Unrecognized value for conflict strategy: " + param1Int); 
      this.OA = param1Int;
      return this;
    }
    
    public Builder setNotifyOnCompletion(boolean param1Boolean) {
      this.Oz = param1Boolean;
      return this;
    }
    
    public Builder setTrackingTag(String param1String) {
      if (!ExecutionOptions.bj(param1String))
        throw new IllegalArgumentException(String.format("trackingTag must not be null nor empty, and the length must be <= the maximum length (%s)", new Object[] { Integer.valueOf(65536) })); 
      this.Oy = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\ExecutionOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */