package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class h implements Parcelable.Creator<UserMetadata> {
  static void a(UserMetadata paramUserMetadata, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramUserMetadata.CK);
    b.a(paramParcel, 2, paramUserMetadata.OR, false);
    b.a(paramParcel, 3, paramUserMetadata.OS, false);
    b.a(paramParcel, 4, paramUserMetadata.OT, false);
    b.a(paramParcel, 5, paramUserMetadata.OU);
    b.a(paramParcel, 6, paramUserMetadata.OV, false);
    b.H(paramParcel, paramInt);
  }
  
  public UserMetadata W(Parcel paramParcel) {
    boolean bool = false;
    String str1 = null;
    int j = a.G(paramParcel);
    String str2 = null;
    String str3 = null;
    String str4 = null;
    int i = 0;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          str4 = a.o(paramParcel, k);
          break;
        case 3:
          str3 = a.o(paramParcel, k);
          break;
        case 4:
          str2 = a.o(paramParcel, k);
          break;
        case 5:
          bool = a.c(paramParcel, k);
          break;
        case 6:
          str1 = a.o(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new UserMetadata(i, str4, str3, str2, bool, str1);
  }
  
  public UserMetadata[] be(int paramInt) {
    return new UserMetadata[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */