package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class d implements Parcelable.Creator<DrivePreferences> {
  static void a(DrivePreferences paramDrivePreferences, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramDrivePreferences.CK);
    b.a(paramParcel, 2, paramDrivePreferences.Ox);
    b.H(paramParcel, paramInt);
  }
  
  public DrivePreferences T(Parcel paramParcel) {
    boolean bool = false;
    int j = a.G(paramParcel);
    int i = 0;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          bool = a.c(paramParcel, k);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new DrivePreferences(i, bool);
  }
  
  public DrivePreferences[] aZ(int paramInt) {
    return new DrivePreferences[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\drive\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */