package com.google.android.gms.auth;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import java.util.ArrayList;

public class AccountChangeEventsResponseCreator implements Parcelable.Creator<AccountChangeEventsResponse> {
  public static final int CONTENT_DESCRIPTION = 0;
  
  static void a(AccountChangeEventsResponse paramAccountChangeEventsResponse, Parcel paramParcel, int paramInt) {
    paramInt = b.H(paramParcel);
    b.c(paramParcel, 1, paramAccountChangeEventsResponse.Ef);
    b.c(paramParcel, 2, paramAccountChangeEventsResponse.mp, false);
    b.H(paramParcel, paramInt);
  }
  
  public AccountChangeEventsResponse createFromParcel(Parcel paramParcel) {
    int j = a.G(paramParcel);
    int i = 0;
    ArrayList<AccountChangeEvent> arrayList = null;
    while (paramParcel.dataPosition() < j) {
      int k = a.F(paramParcel);
      switch (a.aH(k)) {
        case 1:
          i = a.g(paramParcel, k);
          break;
        case 2:
          arrayList = a.c(paramParcel, k, AccountChangeEvent.CREATOR);
          break;
      } 
    } 
    if (paramParcel.dataPosition() != j)
      throw new a.a("Overread allowed size end=" + j, paramParcel); 
    return new AccountChangeEventsResponse(i, arrayList);
  }
  
  public AccountChangeEventsResponse[] newArray(int paramInt) {
    return new AccountChangeEventsResponse[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\auth\AccountChangeEventsResponseCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */