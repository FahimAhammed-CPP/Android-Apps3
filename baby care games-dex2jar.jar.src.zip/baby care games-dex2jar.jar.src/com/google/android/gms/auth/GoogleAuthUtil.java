package com.google.android.gms.auth;

import android.accounts.AccountManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.a;
import com.google.android.gms.internal.ii;
import com.google.android.gms.internal.jx;
import com.google.android.gms.internal.r;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

public final class GoogleAuthUtil {
  public static final int CHANGE_TYPE_ACCOUNT_ADDED = 1;
  
  public static final int CHANGE_TYPE_ACCOUNT_REMOVED = 2;
  
  public static final int CHANGE_TYPE_ACCOUNT_RENAMED_FROM = 3;
  
  public static final int CHANGE_TYPE_ACCOUNT_RENAMED_TO = 4;
  
  private static final ComponentName Ek;
  
  private static final ComponentName El;
  
  private static final Intent Em;
  
  private static final Intent En;
  
  public static final String GOOGLE_ACCOUNT_TYPE = "com.google";
  
  public static final String KEY_ANDROID_PACKAGE_NAME;
  
  public static final String KEY_CALLER_UID = "callerUid";
  
  public static final String KEY_REQUEST_ACTIONS = "request_visible_actions";
  
  @Deprecated
  public static final String KEY_REQUEST_VISIBLE_ACTIVITIES = "request_visible_actions";
  
  public static final String KEY_SUPPRESS_PROGRESS_SCREEN = "suppressProgressScreen";
  
  static {
    if (Build.VERSION.SDK_INT >= 14);
    KEY_ANDROID_PACKAGE_NAME = "androidPackageName";
    Ek = new ComponentName("com.google.android.gms", "com.google.android.gms.auth.GetToken");
    El = new ComponentName("com.google.android.gms", "com.google.android.gms.recovery.RecoveryService");
    Em = (new Intent()).setPackage("com.google.android.gms").setComponent(Ek);
    En = (new Intent()).setPackage("com.google.android.gms").setComponent(El);
  }
  
  private static void C(Context paramContext) throws GoogleAuthException {
    try {
      GooglePlayServicesUtil.C(paramContext);
      return;
    } catch (GooglePlayServicesRepairableException googlePlayServicesRepairableException) {
      throw new GooglePlayServicesAvailabilityException(googlePlayServicesRepairableException.getConnectionStatusCode(), googlePlayServicesRepairableException.getMessage(), googlePlayServicesRepairableException.getIntent());
    } catch (GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException) {
      throw new GoogleAuthException(googlePlayServicesNotAvailableException.getMessage());
    } 
  }
  
  private static String a(Context paramContext, String paramString1, String paramString2, Bundle paramBundle) throws IOException, GoogleAuthException {
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    try {
      return getToken(paramContext, paramString1, paramString2, bundle);
    } catch (GooglePlayServicesAvailabilityException googlePlayServicesAvailabilityException) {
      GooglePlayServicesUtil.showErrorNotification(googlePlayServicesAvailabilityException.getConnectionStatusCode(), paramContext);
      throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
    } catch (UserRecoverableAuthException userRecoverableAuthException) {
      throw new UserRecoverableNotifiedException("User intervention required. Notification has been pushed.");
    } 
  }
  
  private static boolean ax(String paramString) {
    return ("NetworkError".equals(paramString) || "ServiceUnavailable".equals(paramString) || "Timeout".equals(paramString));
  }
  
  private static boolean ay(String paramString) {
    return ("BadAuthentication".equals(paramString) || "CaptchaRequired".equals(paramString) || "DeviceManagementRequiredOrSyncDisabled".equals(paramString) || "NeedPermission".equals(paramString) || "NeedsBrowser".equals(paramString) || "UserCancel".equals(paramString) || "AppDownloadRequired".equals(paramString) || ii.EI.fO().equals(paramString) || ii.EJ.fO().equals(paramString) || ii.EK.fO().equals(paramString) || ii.EL.fO().equals(paramString) || ii.EM.fO().equals(paramString) || ii.EN.fO().equals(paramString));
  }
  
  public static void clearToken(Context paramContext, String paramString) throws GooglePlayServicesAvailabilityException, GoogleAuthException, IOException {
    Context context = paramContext.getApplicationContext();
    jx.aV("Calling this from your main thread can lead to deadlock");
    C(context);
    Bundle bundle = new Bundle();
    String str = (paramContext.getApplicationInfo()).packageName;
    bundle.putString("clientPackageName", str);
    if (!bundle.containsKey(KEY_ANDROID_PACKAGE_NAME))
      bundle.putString(KEY_ANDROID_PACKAGE_NAME, str); 
    a a = new a();
    if (context.bindService(Em, (ServiceConnection)a, 1))
      try {
        Bundle bundle1 = r.a.a(a.gs()).a(paramString, bundle);
        String str1 = bundle1.getString(ii.Fk);
        if (!bundle1.getBoolean("booleanResult"))
          throw new GoogleAuthException(str1); 
        return;
      } catch (RemoteException remoteException) {
        Log.i("GoogleAuthUtil", "GMS remote exception ", (Throwable)remoteException);
        throw new IOException("remote exception");
      } catch (InterruptedException interruptedException) {
        throw new GoogleAuthException("Interrupted");
      } finally {
        context.unbindService((ServiceConnection)a);
      }  
    throw new IOException("Could not bind to service with the given context.");
  }
  
  public static List<AccountChangeEvent> getAccountChangeEvents(Context paramContext, int paramInt, String paramString) throws GoogleAuthException, IOException {
    jx.b(paramString, "accountName must be provided");
    jx.aV("Calling this from your main thread can lead to deadlock");
    paramContext = paramContext.getApplicationContext();
    C(paramContext);
    a a = new a();
    if (paramContext.bindService(Em, (ServiceConnection)a, 1))
      try {
        return r.a.a(a.gs()).a((new AccountChangeEventsRequest()).setAccountName(paramString).setEventIndex(paramInt)).getEvents();
      } catch (RemoteException remoteException) {
        Log.i("GoogleAuthUtil", "GMS remote exception ", (Throwable)remoteException);
        throw new IOException("remote exception");
      } catch (InterruptedException interruptedException) {
        throw new GoogleAuthException("Interrupted");
      } finally {
        paramContext.unbindService((ServiceConnection)a);
      }  
    throw new IOException("Could not bind to service with the given context.");
  }
  
  public static String getAccountId(Context paramContext, String paramString) throws GoogleAuthException, IOException {
    jx.b(paramString, "accountName must be provided");
    jx.aV("Calling this from your main thread can lead to deadlock");
    C(paramContext.getApplicationContext());
    return getToken(paramContext, paramString, "^^_account_id_^^", new Bundle());
  }
  
  public static String getAppCert(Context paramContext, String paramString) {
    return "spatula";
  }
  
  public static String getToken(Context paramContext, String paramString1, String paramString2) throws IOException, UserRecoverableAuthException, GoogleAuthException {
    return getToken(paramContext, paramString1, paramString2, new Bundle());
  }
  
  public static String getToken(Context paramContext, String paramString1, String paramString2, Bundle paramBundle) throws IOException, UserRecoverableAuthException, GoogleAuthException {
    Context context = paramContext.getApplicationContext();
    jx.aV("Calling this from your main thread can lead to deadlock");
    C(context);
    if (paramBundle == null) {
      paramBundle = new Bundle();
    } else {
      paramBundle = new Bundle(paramBundle);
    } 
    String str = (paramContext.getApplicationInfo()).packageName;
    paramBundle.putString("clientPackageName", str);
    if (!paramBundle.containsKey(KEY_ANDROID_PACKAGE_NAME))
      paramBundle.putString(KEY_ANDROID_PACKAGE_NAME, str); 
    a a = new a();
    if (context.bindService(Em, (ServiceConnection)a, 1)) {
      try {
        Bundle bundle = r.a.a(a.gs()).a(paramString1, paramString2, paramBundle);
        if (bundle == null) {
          Log.w("GoogleAuthUtil", "Binder call returned null.");
          throw new GoogleAuthException("ServiceUnavailable");
        } 
        paramString2 = bundle.getString("authtoken");
        boolean bool = TextUtils.isEmpty(paramString2);
        if (!bool)
          return paramString2; 
        paramString2 = bundle.getString("Error");
        Intent intent = (Intent)bundle.getParcelable("userRecoveryIntent");
      } catch (RemoteException remoteException) {
        Log.i("GoogleAuthUtil", "GMS remote exception ", (Throwable)remoteException);
        throw new IOException("remote exception");
      } catch (InterruptedException interruptedException) {
        throw new GoogleAuthException("Interrupted");
      } finally {
        context.unbindService((ServiceConnection)a);
      } 
      if (ax(paramString2))
        throw new IOException(paramString2); 
      throw new GoogleAuthException(paramString2);
    } 
    throw new IOException("Could not bind to service with the given context.");
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle) throws IOException, UserRecoverableNotifiedException, GoogleAuthException {
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    bundle.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, bundle);
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle, Intent paramIntent) throws IOException, UserRecoverableNotifiedException, GoogleAuthException {
    h(paramIntent);
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    bundle.putParcelable("callback_intent", (Parcelable)paramIntent);
    bundle.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, bundle);
  }
  
  public static String getTokenWithNotification(Context paramContext, String paramString1, String paramString2, Bundle paramBundle1, String paramString3, Bundle paramBundle2) throws IOException, UserRecoverableNotifiedException, GoogleAuthException {
    if (TextUtils.isEmpty(paramString3))
      throw new IllegalArgumentException("Authority cannot be empty or null."); 
    Bundle bundle = paramBundle1;
    if (paramBundle1 == null)
      bundle = new Bundle(); 
    paramBundle1 = paramBundle2;
    if (paramBundle2 == null)
      paramBundle1 = new Bundle(); 
    ContentResolver.validateSyncExtrasBundle(paramBundle1);
    bundle.putString("authority", paramString3);
    bundle.putBundle("sync_extras", paramBundle1);
    bundle.putBoolean("handle_notification", true);
    return a(paramContext, paramString1, paramString2, bundle);
  }
  
  private static void h(Intent paramIntent) {
    if (paramIntent == null)
      throw new IllegalArgumentException("Callback cannot be null."); 
    String str = paramIntent.toUri(1);
    try {
      Intent.parseUri(str, 1);
      return;
    } catch (URISyntaxException uRISyntaxException) {
      throw new IllegalArgumentException("Parameter callback contains invalid data. It must be serializable using toUri() and parseUri().");
    } 
  }
  
  @Deprecated
  public static void invalidateToken(Context paramContext, String paramString) {
    AccountManager.get(paramContext).invalidateAuthToken("com.google", paramString);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 11);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\android\gms\auth\GoogleAuthUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */