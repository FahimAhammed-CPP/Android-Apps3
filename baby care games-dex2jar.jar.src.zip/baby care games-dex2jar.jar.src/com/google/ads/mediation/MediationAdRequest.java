package com.google.ads.mediation;

import android.location.Location;
import com.google.ads.AdRequest;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

@Deprecated
public final class MediationAdRequest {
  private final Date d;
  
  private final AdRequest.Gender e;
  
  private final Set<String> f;
  
  private final boolean g;
  
  private final Location h;
  
  public MediationAdRequest(Date paramDate, AdRequest.Gender paramGender, Set<String> paramSet, boolean paramBoolean, Location paramLocation) {
    this.d = paramDate;
    this.e = paramGender;
    this.f = paramSet;
    this.g = paramBoolean;
    this.h = paramLocation;
  }
  
  public Integer getAgeInYears() {
    Integer integer;
    if (this.d != null) {
      Calendar calendar1 = Calendar.getInstance();
      Calendar calendar2 = Calendar.getInstance();
      calendar1.setTime(this.d);
      integer = Integer.valueOf(calendar2.get(1) - calendar1.get(1));
      if (calendar2.get(2) >= calendar1.get(2)) {
        Integer integer1 = integer;
        if (calendar2.get(2) == calendar1.get(2)) {
          integer1 = integer;
          if (calendar2.get(5) < calendar1.get(5))
            return Integer.valueOf(integer.intValue() - 1); 
        } 
        return integer1;
      } 
    } else {
      return null;
    } 
    return Integer.valueOf(integer.intValue() - 1);
  }
  
  public Date getBirthday() {
    return this.d;
  }
  
  public AdRequest.Gender getGender() {
    return this.e;
  }
  
  public Set<String> getKeywords() {
    return this.f;
  }
  
  public Location getLocation() {
    return this.h;
  }
  
  public boolean isTesting() {
    return this.g;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\ads\mediation\MediationAdRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */