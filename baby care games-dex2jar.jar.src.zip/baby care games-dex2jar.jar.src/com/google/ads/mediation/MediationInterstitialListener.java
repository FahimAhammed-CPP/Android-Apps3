package com.google.ads.mediation;

import com.google.ads.AdRequest;

@Deprecated
public interface MediationInterstitialListener {
  void onDismissScreen(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter);
  
  void onFailedToReceiveAd(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter, AdRequest.ErrorCode paramErrorCode);
  
  void onLeaveApplication(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter);
  
  void onPresentScreen(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter);
  
  void onReceivedAd(MediationInterstitialAdapter<?, ?> paramMediationInterstitialAdapter);
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\ads\mediation\MediationInterstitialListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */