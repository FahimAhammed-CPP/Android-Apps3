package com.google.ads.mediation.admob;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.internal.gq;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

public final class AdMobAdapter implements MediationBannerAdapter, MediationInterstitialAdapter {
  private AdView i;
  
  private InterstitialAd j;
  
  static AdRequest a(Context paramContext, MediationAdRequest paramMediationAdRequest, Bundle paramBundle1, Bundle paramBundle2) {
    AdRequest.Builder builder = new AdRequest.Builder();
    Date date = paramMediationAdRequest.getBirthday();
    if (date != null)
      builder.setBirthday(date); 
    int i = paramMediationAdRequest.getGender();
    if (i != 0)
      builder.setGender(i); 
    Set set = paramMediationAdRequest.getKeywords();
    if (set != null) {
      Iterator<String> iterator = set.iterator();
      while (iterator.hasNext())
        builder.addKeyword(iterator.next()); 
    } 
    Location location = paramMediationAdRequest.getLocation();
    if (location != null)
      builder.setLocation(location); 
    if (paramMediationAdRequest.isTesting())
      builder.addTestDevice(gq.v(paramContext)); 
    if (paramBundle2.getInt("tagForChildDirectedTreatment") != -1) {
      boolean bool;
      if (paramBundle2.getInt("tagForChildDirectedTreatment") == 1) {
        bool = true;
      } else {
        bool = false;
      } 
      builder.tagForChildDirectedTreatment(bool);
    } 
    if (paramBundle1 == null)
      paramBundle1 = new Bundle(); 
    paramBundle1.putInt("gw", 1);
    paramBundle1.putString("mad_hac", paramBundle2.getString("mad_hac"));
    if (!TextUtils.isEmpty(paramBundle2.getString("adJson")))
      paramBundle1.putString("_ad", paramBundle2.getString("adJson")); 
    paramBundle1.putBoolean("_noRefresh", true);
    builder.addNetworkExtrasBundle(AdMobAdapter.class, paramBundle1);
    return builder.build();
  }
  
  public View getBannerView() {
    return (View)this.i;
  }
  
  public void onDestroy() {
    if (this.i != null) {
      this.i.destroy();
      this.i = null;
    } 
    if (this.j != null)
      this.j = null; 
  }
  
  public void onPause() {
    if (this.i != null)
      this.i.pause(); 
  }
  
  public void onResume() {
    if (this.i != null)
      this.i.resume(); 
  }
  
  public void requestBannerAd(Context paramContext, MediationBannerListener paramMediationBannerListener, Bundle paramBundle1, AdSize paramAdSize, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    this.i = new AdView(paramContext);
    this.i.setAdSize(new AdSize(paramAdSize.getWidth(), paramAdSize.getHeight()));
    this.i.setAdUnitId(paramBundle1.getString("pubid"));
    this.i.setAdListener(new a(this, paramMediationBannerListener));
    this.i.loadAd(a(paramContext, paramMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void requestInterstitialAd(Context paramContext, MediationInterstitialListener paramMediationInterstitialListener, Bundle paramBundle1, MediationAdRequest paramMediationAdRequest, Bundle paramBundle2) {
    this.j = new InterstitialAd(paramContext);
    this.j.setAdUnitId(paramBundle1.getString("pubid"));
    this.j.setAdListener(new b(this, paramMediationInterstitialListener));
    this.j.loadAd(a(paramContext, paramMediationAdRequest, paramBundle2, paramBundle1));
  }
  
  public void showInterstitial() {
    this.j.show();
  }
  
  private static final class a extends AdListener {
    private final AdMobAdapter k;
    
    private final MediationBannerListener l;
    
    public a(AdMobAdapter param1AdMobAdapter, MediationBannerListener param1MediationBannerListener) {
      this.k = param1AdMobAdapter;
      this.l = param1MediationBannerListener;
    }
    
    public void onAdClosed() {
      this.l.onAdClosed(this.k);
    }
    
    public void onAdFailedToLoad(int param1Int) {
      this.l.onAdFailedToLoad(this.k, param1Int);
    }
    
    public void onAdLeftApplication() {
      this.l.onAdLeftApplication(this.k);
    }
    
    public void onAdLoaded() {
      this.l.onAdLoaded(this.k);
    }
    
    public void onAdOpened() {
      this.l.onAdClicked(this.k);
      this.l.onAdOpened(this.k);
    }
  }
  
  private static final class b extends AdListener {
    private final AdMobAdapter k;
    
    private final MediationInterstitialListener m;
    
    public b(AdMobAdapter param1AdMobAdapter, MediationInterstitialListener param1MediationInterstitialListener) {
      this.k = param1AdMobAdapter;
      this.m = param1MediationInterstitialListener;
    }
    
    public void onAdClosed() {
      this.m.onAdClosed(this.k);
    }
    
    public void onAdFailedToLoad(int param1Int) {
      this.m.onAdFailedToLoad(this.k, param1Int);
    }
    
    public void onAdLeftApplication() {
      this.m.onAdLeftApplication(this.k);
    }
    
    public void onAdLoaded() {
      this.m.onAdLoaded(this.k);
    }
    
    public void onAdOpened() {
      this.m.onAdOpened(this.k);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\ads\mediation\admob\AdMobAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */