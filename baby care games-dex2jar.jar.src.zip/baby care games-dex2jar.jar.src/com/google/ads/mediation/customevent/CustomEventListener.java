package com.google.ads.mediation.customevent;

@Deprecated
public interface CustomEventListener {
  void onDismissScreen();
  
  void onFailedToReceiveAd();
  
  void onLeaveApplication();
  
  void onPresentScreen();
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\google\ads\mediation\customevent\CustomEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */