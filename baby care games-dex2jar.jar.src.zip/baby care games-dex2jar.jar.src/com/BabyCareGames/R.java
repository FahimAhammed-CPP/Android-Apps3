package com.BabyCareGames;

public final class R {
  public static final class attr {
    public static final int adSize = 2130771968;
    
    public static final int adSizes = 2130771969;
    
    public static final int adUnitId = 2130771970;
    
    public static final int appTheme = 2130771990;
    
    public static final int buyButtonAppearance = 2130771997;
    
    public static final int buyButtonHeight = 2130771994;
    
    public static final int buyButtonText = 2130771996;
    
    public static final int buyButtonWidth = 2130771995;
    
    public static final int cameraBearing = 2130771975;
    
    public static final int cameraTargetLat = 2130771976;
    
    public static final int cameraTargetLng = 2130771977;
    
    public static final int cameraTilt = 2130771978;
    
    public static final int cameraZoom = 2130771979;
    
    public static final int circleCrop = 2130771973;
    
    public static final int environment = 2130771991;
    
    public static final int fragmentMode = 2130771993;
    
    public static final int fragmentStyle = 2130771992;
    
    public static final int imageAspectRatio = 2130771972;
    
    public static final int imageAspectRatioAdjust = 2130771971;
    
    public static final int liteMode = 2130771980;
    
    public static final int mapType = 2130771974;
    
    public static final int maskedWalletDetailsBackground = 2130772000;
    
    public static final int maskedWalletDetailsButtonBackground = 2130772002;
    
    public static final int maskedWalletDetailsButtonTextAppearance = 2130772001;
    
    public static final int maskedWalletDetailsHeaderTextAppearance = 2130771999;
    
    public static final int maskedWalletDetailsLogoImageType = 2130772004;
    
    public static final int maskedWalletDetailsLogoTextColor = 2130772003;
    
    public static final int maskedWalletDetailsTextAppearance = 2130771998;
    
    public static final int uiCompass = 2130771981;
    
    public static final int uiMapToolbar = 2130771989;
    
    public static final int uiRotateGestures = 2130771982;
    
    public static final int uiScrollGestures = 2130771983;
    
    public static final int uiTiltGestures = 2130771984;
    
    public static final int uiZoomControls = 2130771985;
    
    public static final int uiZoomGestures = 2130771986;
    
    public static final int useViewLifecycle = 2130771987;
    
    public static final int zOrderOnTop = 2130771988;
  }
  
  public static final class bool {
    public static final int ga_autoActivityTracking = 2131296256;
    
    public static final int ga_reportUncaughtExceptions = 2131296257;
  }
  
  public static final class color {
    public static final int common_action_bar_splitter = 2131165193;
    
    public static final int common_signin_btn_dark_text_default = 2131165184;
    
    public static final int common_signin_btn_dark_text_disabled = 2131165186;
    
    public static final int common_signin_btn_dark_text_focused = 2131165187;
    
    public static final int common_signin_btn_dark_text_pressed = 2131165185;
    
    public static final int common_signin_btn_default_background = 2131165192;
    
    public static final int common_signin_btn_light_text_default = 2131165188;
    
    public static final int common_signin_btn_light_text_disabled = 2131165190;
    
    public static final int common_signin_btn_light_text_focused = 2131165191;
    
    public static final int common_signin_btn_light_text_pressed = 2131165189;
    
    public static final int common_signin_btn_text_dark = 2131165207;
    
    public static final int common_signin_btn_text_light = 2131165208;
    
    public static final int wallet_bright_foreground_disabled_holo_light = 2131165199;
    
    public static final int wallet_bright_foreground_holo_dark = 2131165194;
    
    public static final int wallet_bright_foreground_holo_light = 2131165200;
    
    public static final int wallet_dim_foreground_disabled_holo_dark = 2131165196;
    
    public static final int wallet_dim_foreground_holo_dark = 2131165195;
    
    public static final int wallet_dim_foreground_inverse_disabled_holo_dark = 2131165198;
    
    public static final int wallet_dim_foreground_inverse_holo_dark = 2131165197;
    
    public static final int wallet_highlighted_text_holo_dark = 2131165204;
    
    public static final int wallet_highlighted_text_holo_light = 2131165203;
    
    public static final int wallet_hint_foreground_holo_dark = 2131165202;
    
    public static final int wallet_hint_foreground_holo_light = 2131165201;
    
    public static final int wallet_holo_blue_light = 2131165205;
    
    public static final int wallet_link_text_light = 2131165206;
    
    public static final int wallet_primary_text_holo_light = 2131165209;
    
    public static final int wallet_secondary_text_holo_dark = 2131165210;
  }
  
  public static final class drawable {
    public static final int addimage = 2130837504;
    
    public static final int camera = 2130837505;
    
    public static final int common_full_open_on_phone = 2130837506;
    
    public static final int common_ic_googleplayservices = 2130837507;
    
    public static final int common_signin_btn_icon_dark = 2130837508;
    
    public static final int common_signin_btn_icon_disabled_dark = 2130837509;
    
    public static final int common_signin_btn_icon_disabled_focus_dark = 2130837510;
    
    public static final int common_signin_btn_icon_disabled_focus_light = 2130837511;
    
    public static final int common_signin_btn_icon_disabled_light = 2130837512;
    
    public static final int common_signin_btn_icon_focus_dark = 2130837513;
    
    public static final int common_signin_btn_icon_focus_light = 2130837514;
    
    public static final int common_signin_btn_icon_light = 2130837515;
    
    public static final int common_signin_btn_icon_normal_dark = 2130837516;
    
    public static final int common_signin_btn_icon_normal_light = 2130837517;
    
    public static final int common_signin_btn_icon_pressed_dark = 2130837518;
    
    public static final int common_signin_btn_icon_pressed_light = 2130837519;
    
    public static final int common_signin_btn_text_dark = 2130837520;
    
    public static final int common_signin_btn_text_disabled_dark = 2130837521;
    
    public static final int common_signin_btn_text_disabled_focus_dark = 2130837522;
    
    public static final int common_signin_btn_text_disabled_focus_light = 2130837523;
    
    public static final int common_signin_btn_text_disabled_light = 2130837524;
    
    public static final int common_signin_btn_text_focus_dark = 2130837525;
    
    public static final int common_signin_btn_text_focus_light = 2130837526;
    
    public static final int common_signin_btn_text_light = 2130837527;
    
    public static final int common_signin_btn_text_normal_dark = 2130837528;
    
    public static final int common_signin_btn_text_normal_light = 2130837529;
    
    public static final int common_signin_btn_text_pressed_dark = 2130837530;
    
    public static final int common_signin_btn_text_pressed_light = 2130837531;
    
    public static final int face = 2130837532;
    
    public static final int ic_launcher = 2130837533;
    
    public static final int ic_plusone_medium_off_client = 2130837534;
    
    public static final int ic_plusone_small_off_client = 2130837535;
    
    public static final int ic_plusone_standard_off_client = 2130837536;
    
    public static final int ic_plusone_tall_off_client = 2130837537;
    
    public static final int mirrorx = 2130837538;
    
    public static final int mirrory = 2130837539;
    
    public static final int powered_by_google_dark = 2130837540;
    
    public static final int powered_by_google_light = 2130837541;
    
    public static final int save = 2130837542;
  }
  
  public static final class id {
    public static final int GetImage = 2131427354;
    
    public static final int SaveImage = 2131427355;
    
    public static final int adjust_height = 2131427328;
    
    public static final int adjust_width = 2131427329;
    
    public static final int book_now = 2131427344;
    
    public static final int buyButton = 2131427340;
    
    public static final int buy_now = 2131427345;
    
    public static final int buy_with_google = 2131427346;
    
    public static final int classic = 2131427348;
    
    public static final int donate_with_google = 2131427347;
    
    public static final int grayscale = 2131427349;
    
    public static final int holo_dark = 2131427335;
    
    public static final int holo_light = 2131427336;
    
    public static final int hybrid = 2131427331;
    
    public static final int linearLayout3 = 2131427353;
    
    public static final int linearLayout4 = 2131427352;
    
    public static final int linearLayoutAdMob = 2131427356;
    
    public static final int linearLayoutAdMobText = 2131427357;
    
    public static final int match_parent = 2131427342;
    
    public static final int menu_settings = 2131427360;
    
    public static final int monochrome = 2131427350;
    
    public static final int none = 2131427330;
    
    public static final int normal = 2131427332;
    
    public static final int production = 2131427337;
    
    public static final int sandbox = 2131427338;
    
    public static final int satellite = 2131427333;
    
    public static final int selectionDetails = 2131427341;
    
    public static final int strict_sandbox = 2131427339;
    
    public static final int terrain = 2131427334;
    
    public static final int textView1 = 2131427358;
    
    public static final int textView2 = 2131427359;
    
    public static final int webview = 2131427351;
    
    public static final int wrap_content = 2131427343;
  }
  
  public static final class integer {
    public static final int google_play_services_version = 2131230720;
  }
  
  public static final class layout {
    public static final int activity_main = 2130903040;
  }
  
  public static final class menu {
    public static final int activity_main = 2131361792;
  }
  
  public static final class raw {
    public static final int gtm_analytics = 2130968576;
  }
  
  public static final class string {
    public static final int accept = 2131099650;
    
    public static final int achievement_1 = 2131099685;
    
    public static final int achievement_2 = 2131099686;
    
    public static final int achievement_3 = 2131099687;
    
    public static final int achievement_4 = 2131099688;
    
    public static final int achievement_5 = 2131099689;
    
    public static final int app_id = 2131099684;
    
    public static final int app_name = 2131099691;
    
    public static final int common_android_wear_notification_needs_update_text = 2131099657;
    
    public static final int common_android_wear_update_text = 2131099670;
    
    public static final int common_android_wear_update_title = 2131099668;
    
    public static final int common_google_play_services_enable_button = 2131099666;
    
    public static final int common_google_play_services_enable_text = 2131099665;
    
    public static final int common_google_play_services_enable_title = 2131099664;
    
    public static final int common_google_play_services_error_notification_requested_by_msg = 2131099659;
    
    public static final int common_google_play_services_install_button = 2131099663;
    
    public static final int common_google_play_services_install_text_phone = 2131099661;
    
    public static final int common_google_play_services_install_text_tablet = 2131099662;
    
    public static final int common_google_play_services_install_title = 2131099660;
    
    public static final int common_google_play_services_invalid_account_text = 2131099674;
    
    public static final int common_google_play_services_invalid_account_title = 2131099673;
    
    public static final int common_google_play_services_needs_enabling_title = 2131099658;
    
    public static final int common_google_play_services_network_error_text = 2131099672;
    
    public static final int common_google_play_services_network_error_title = 2131099671;
    
    public static final int common_google_play_services_notification_needs_installation_title = 2131099655;
    
    public static final int common_google_play_services_notification_needs_update_title = 2131099656;
    
    public static final int common_google_play_services_notification_ticker = 2131099654;
    
    public static final int common_google_play_services_unknown_issue = 2131099675;
    
    public static final int common_google_play_services_unsupported_text = 2131099677;
    
    public static final int common_google_play_services_unsupported_title = 2131099676;
    
    public static final int common_google_play_services_update_button = 2131099678;
    
    public static final int common_google_play_services_update_text = 2131099669;
    
    public static final int common_google_play_services_update_title = 2131099667;
    
    public static final int common_open_on_phone = 2131099681;
    
    public static final int common_signin_button_text = 2131099679;
    
    public static final int common_signin_button_text_long = 2131099680;
    
    public static final int create_calendar_message = 2131099653;
    
    public static final int create_calendar_title = 2131099652;
    
    public static final int decline = 2131099651;
    
    public static final int ga_trackingId = 2131099683;
    
    public static final int hello_world = 2131099692;
    
    public static final int leaderboard_id = 2131099690;
    
    public static final int menu_settings = 2131099693;
    
    public static final int store_picture_message = 2131099649;
    
    public static final int store_picture_title = 2131099648;
    
    public static final int wallet_buy_button_place_holder = 2131099682;
  }
  
  public static final class style {
    public static final int AppBaseTheme = 2131034117;
    
    public static final int AppTheme = 2131034118;
    
    public static final int Theme_IAPTheme = 2131034112;
    
    public static final int WalletFragmentDefaultButtonTextAppearance = 2131034115;
    
    public static final int WalletFragmentDefaultDetailsHeaderTextAppearance = 2131034114;
    
    public static final int WalletFragmentDefaultDetailsTextAppearance = 2131034113;
    
    public static final int WalletFragmentDefaultStyle = 2131034116;
  }
  
  public static final class styleable {
    public static final int[] AdsAttrs = new int[] { 2130771968, 2130771969, 2130771970 };
    
    public static final int AdsAttrs_adSize = 0;
    
    public static final int AdsAttrs_adSizes = 1;
    
    public static final int AdsAttrs_adUnitId = 2;
    
    public static final int[] LoadingImageView = new int[] { 2130771971, 2130771972, 2130771973 };
    
    public static final int LoadingImageView_circleCrop = 2;
    
    public static final int LoadingImageView_imageAspectRatio = 1;
    
    public static final int LoadingImageView_imageAspectRatioAdjust = 0;
    
    public static final int[] MapAttrs = new int[] { 
        2130771974, 2130771975, 2130771976, 2130771977, 2130771978, 2130771979, 2130771980, 2130771981, 2130771982, 2130771983, 
        2130771984, 2130771985, 2130771986, 2130771987, 2130771988, 2130771989 };
    
    public static final int MapAttrs_cameraBearing = 1;
    
    public static final int MapAttrs_cameraTargetLat = 2;
    
    public static final int MapAttrs_cameraTargetLng = 3;
    
    public static final int MapAttrs_cameraTilt = 4;
    
    public static final int MapAttrs_cameraZoom = 5;
    
    public static final int MapAttrs_liteMode = 6;
    
    public static final int MapAttrs_mapType = 0;
    
    public static final int MapAttrs_uiCompass = 7;
    
    public static final int MapAttrs_uiMapToolbar = 15;
    
    public static final int MapAttrs_uiRotateGestures = 8;
    
    public static final int MapAttrs_uiScrollGestures = 9;
    
    public static final int MapAttrs_uiTiltGestures = 10;
    
    public static final int MapAttrs_uiZoomControls = 11;
    
    public static final int MapAttrs_uiZoomGestures = 12;
    
    public static final int MapAttrs_useViewLifecycle = 13;
    
    public static final int MapAttrs_zOrderOnTop = 14;
    
    public static final int[] WalletFragmentOptions = new int[] { 2130771990, 2130771991, 2130771992, 2130771993 };
    
    public static final int WalletFragmentOptions_appTheme = 0;
    
    public static final int WalletFragmentOptions_environment = 1;
    
    public static final int WalletFragmentOptions_fragmentMode = 3;
    
    public static final int WalletFragmentOptions_fragmentStyle = 2;
    
    public static final int[] WalletFragmentStyle = new int[] { 
        2130771994, 2130771995, 2130771996, 2130771997, 2130771998, 2130771999, 2130772000, 2130772001, 2130772002, 2130772003, 
        2130772004 };
    
    public static final int WalletFragmentStyle_buyButtonAppearance = 3;
    
    public static final int WalletFragmentStyle_buyButtonHeight = 0;
    
    public static final int WalletFragmentStyle_buyButtonText = 2;
    
    public static final int WalletFragmentStyle_buyButtonWidth = 1;
    
    public static final int WalletFragmentStyle_maskedWalletDetailsBackground = 6;
    
    public static final int WalletFragmentStyle_maskedWalletDetailsButtonBackground = 8;
    
    public static final int WalletFragmentStyle_maskedWalletDetailsButtonTextAppearance = 7;
    
    public static final int WalletFragmentStyle_maskedWalletDetailsHeaderTextAppearance = 5;
    
    public static final int WalletFragmentStyle_maskedWalletDetailsLogoImageType = 10;
    
    public static final int WalletFragmentStyle_maskedWalletDetailsLogoTextColor = 9;
    
    public static final int WalletFragmentStyle_maskedWalletDetailsTextAppearance = 4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\BabyCareGames\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */