package com.BabyCareGames;

import android.content.Context;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class InterstitialAdmob {
  public static String intID = "ca-app-pub-7257110515906635/4344333309";
  
  public static InterstitialAd mInterstitialAd;
  
  public static void LoadInt(Context paramContext) {
    mInterstitialAd = new InterstitialAd(paramContext);
    mInterstitialAd.setAdUnitId(intID);
    requestNewInterstitial();
    mInterstitialAd.setAdListener(new AdListener() {
          public void onAdClosed() {
            InterstitialAdmob.requestNewInterstitial();
          }
        });
  }
  
  public static void ShowInt() {
    if (mInterstitialAd.isLoaded())
      mInterstitialAd.show(); 
  }
  
  private static void requestNewInterstitial() {
    AdRequest adRequest = (new AdRequest.Builder()).build();
    mInterstitialAd.loadAd(adRequest);
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\BabyCareGames\InterstitialAdmob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */