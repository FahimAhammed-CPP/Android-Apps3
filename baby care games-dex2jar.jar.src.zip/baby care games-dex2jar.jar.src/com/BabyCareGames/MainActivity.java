package com.BabyCareGames;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Process;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.startapp.android.publish.StartAppAd;
import java.io.File;

public class MainActivity extends myTrackedActivity {
  static Bitmap workImage = null;
  
  static Bitmap workImageToSave = null;
  
  private AdView adView;
  
  public boolean closeApp = false;
  
  public Activity curActivity = this;
  
  private String curUrl = "file:///android_asset/index.html";
  
  private boolean isBanner = false;
  
  private StartAppAd startAppAd = new StartAppAd((Context)this);
  
  private WebView webView;
  
  private void AddAdMob() {
    this.adView = new AdView((Context)this);
    this.adView.setAdUnitId("ca-app-pub-7257110515906635/9236244907");
    if ((getResources().getConfiguration()).orientation == 1) {
      this.adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
    } else {
      this.adView.setAdSize(AdSize.LARGE_BANNER);
    } 
    ((LinearLayout)findViewById(2131427356)).addView((View)this.adView);
    AdRequest adRequest = (new AdRequest.Builder()).build();
    this.adView.loadAd(adRequest);
  }
  
  private void changeAdmobToBanner() {
    if (this.isBanner)
      return; 
    this.isBanner = true;
    this.adView = new AdView((Context)this);
    this.adView.setAdUnitId("ca-app-pub-7257110515906635/9236244907");
    this.adView.setAdSize(AdSize.LARGE_BANNER);
    LinearLayout linearLayout = (LinearLayout)findViewById(2131427356);
    linearLayout.removeAllViews();
    linearLayout.addView((View)this.adView);
    AdRequest adRequest = (new AdRequest.Builder()).build();
    this.adView.loadAd(adRequest);
  }
  
  private boolean isNetworkAvailable() {
    return (((ConnectivityManager)getSystemService("connectivity")).getActiveNetworkInfo() != null);
  }
  
  private void setButtons() {
    ImageView imageView = (ImageView)findViewById(2131427354);
    imageView.setVisibility(4);
    imageView.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            MainActivity.this.webView.loadUrl("javascript:setImages();");
          }
        });
    imageView = (ImageView)findViewById(2131427355);
    imageView.setVisibility(4);
    imageView.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            Picture picture = MainActivity.this.webView.capturePicture();
            Bitmap bitmap = Bitmap.createBitmap(picture.getWidth(), picture.getHeight(), Bitmap.Config.ARGB_8888);
            picture.draw(new Canvas(bitmap));
            String str = ImageUtil.SaveImage(bitmap, MainActivity.this.curActivity);
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.setDataAndType(Uri.fromFile(new File(str)), "image/*");
            MainActivity.this.startActivity(intent);
          }
        });
  }
  
  private void takePic() {
    startActivityForResult(new Intent("android.media.action.IMAGE_CAPTURE"), 80);
  }
  
  private void threadChangeAd(String paramString) {
    if (paramString.contains("index.html"))
      return; 
    (new Thread() {
        public void run() {
          try {
            Thread.sleep(200L);
          } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
          } 
          MainActivity.this.runOnUiThread(new Thread() {
                public void run() {
                  MainActivity.null.access$0(MainActivity.null.this).changeAdmobToBanner();
                }
              });
        }
      }).start();
  }
  
  public void hideGalleryBtn() {
    runOnUiThread(new Runnable() {
          public void run() {
            ((ImageView)MainActivity.this.findViewById(2131427354)).setVisibility(4);
          }
        });
  }
  
  public void hideSaveBtn() {
    runOnUiThread(new Runnable() {
          public void run() {
            ((ImageView)MainActivity.this.findViewById(2131427355)).setVisibility(4);
          }
        });
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    try {
      Bitmap bitmap;
      super.onActivityResult(paramInt1, paramInt2, paramIntent);
      if (isGoogleGamesApi(paramInt1, paramInt2))
        return; 
      if (paramInt1 == 80) {
        bitmap = (Bitmap)paramIntent.getExtras().get("data");
      } else {
        File file = GetImageFromDevice.getTempFile();
        Bitmap bitmap1 = BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() + "/" + "temporary_holder.jpg");
        bitmap = bitmap1;
        if (file.exists()) {
          file.delete();
          bitmap = bitmap1;
        } 
      } 
      workImage = bitmap;
      Toast.makeText((Context)this, "Proccesing...", 1).show();
      runOnUiThread(new Runnable() {
            public void run() {
              (new Thread(new Runnable() {
                    public void run() {
                      float f = MainActivity.workImage.getHeight() / MainActivity.workImage.getWidth();
                      Display display = MainActivity.null.access$0(MainActivity.null.this).getWindowManager().getDefaultDisplay();
                      int j = display.getWidth();
                      int i = (int)(display.getWidth() * f);
                      if (display.getWidth() > display.getHeight()) {
                        j = (int)(display.getHeight() / f);
                        i = display.getHeight();
                      } 
                      MainActivity.workImage = Bitmap.createScaledBitmap(MainActivity.workImage, j, i, false);
                      MainActivity.workImage = GetImageFromDevice.toGrayscale(MainActivity.workImage);
                      MainActivity.workImage = GetImageFromDevice.fastsmooth(MainActivity.workImage);
                      MainActivity.workImage = GetImageFromDevice.changeColor(MainActivity.workImage);
                      String str = ImageUtil.encodeToString(MainActivity.workImage);
                      (MainActivity.null.access$0(MainActivity.null.this)).webView.loadUrl("javascript:SetImage(\"" + str.replace("\n", "") + "\")");
                    }
                  })).start();
            }
          });
      return;
    } catch (Exception exception) {
      Log.d("fd", exception.getMessage());
      return;
    } 
  }
  
  public void onBackPressed() {
    if (!this.webView.canGoBack()) {
      this.startAppAd.onBackPressed();
      super.onBackPressed();
      return;
    } 
    if (this.webView.getUrl().contains("Gameindex.html")) {
      InterstitialAdmob.ShowInt();
      this.webView.goBack();
      return;
    } 
    this.webView.goBack();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    StartAppAd.init((Context)this, "105571702", "205355864");
    setContentView(2130903040);
    getWindow().setFlags(128, 128);
    CookieManager.getInstance().setAcceptCookie(true);
    AddAdMob();
    InterstitialAdmob.LoadInt((Context)this);
    this.webView = (WebView)findViewById(2131427351);
    this.webView.getSettings().setDomStorageEnabled(true);
    this.webView.getSettings().setDatabaseEnabled(true);
    this.webView.getSettings().setDatabasePath("/data/data/" + getPackageName() + "/databases/");
    JsInterface jsInterface = new JsInterface(this);
    this.webView.addJavascriptInterface(jsInterface, "JsInterface");
    this.webView.getSettings().setJavaScriptEnabled(true);
    this.webView.setWebChromeClient(new WebChromeClient() {
        
        });
    this.webView.setWebViewClient(new WebViewClient() {
          public void onPageStarted(WebView param1WebView, String param1String, Bitmap param1Bitmap) {
            LinearLayout linearLayout = (LinearLayout)MainActivity.this.findViewById(2131427356);
            if (param1String.contains(MainActivity.this.curUrl)) {
              linearLayout.setVisibility(8);
            } else {
              linearLayout.setVisibility(0);
            } 
            MainActivity.this.threadChangeAd(param1String);
          }
          
          public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
            MainActivity.this.threadChangeAd(param1String);
            if (!MainActivity.this.isNetworkAvailable()) {
              param1WebView.loadUrl(param1String);
              return true;
            } 
            param1WebView.loadUrl(param1String);
            return true;
          }
        });
    if (!isNetworkAvailable()) {
      this.webView.loadUrl(this.curUrl);
    } else {
      this.webView.loadUrl(this.curUrl);
    } 
    setButtons();
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131361792, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    if (paramMenuItem.getTitle().toString().equals("Close")) {
      this.closeApp = true;
      Process.killProcess(Process.myPid());
    } 
    return true;
  }
  
  protected void onPause() {
    super.onPause();
  }
  
  protected void onResume() {
    super.onResume();
    this.startAppAd.onResume();
  }
  
  public void saveToGallery() {
    Picture picture = this.webView.capturePicture();
    Bitmap bitmap = Bitmap.createBitmap(picture.getWidth(), picture.getHeight(), Bitmap.Config.ARGB_8888);
    picture.draw(new Canvas(bitmap));
    String str = ImageUtil.SaveImage(bitmap, this.curActivity);
    Intent intent = new Intent();
    intent.setAction("android.intent.action.VIEW");
    intent.setDataAndType(Uri.fromFile(new File(str)), "image/*");
    startActivity(intent);
  }
  
  public void showGalleryBtn() {
    runOnUiThread(new Runnable() {
          public void run() {
            ((ImageView)MainActivity.this.findViewById(2131427354)).setVisibility(0);
          }
        });
  }
  
  public void showSaveBtn() {
    runOnUiThread(new Runnable() {
          public void run() {
            ((ImageView)MainActivity.this.findViewById(2131427355)).setVisibility(0);
          }
        });
  }
}


/* Location:              C:\soft\dex2jar-2.0\baby care games-dex2jar.jar!\com\BabyCareGames\MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */