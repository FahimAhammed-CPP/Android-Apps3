package CoronaProvider.ads.admob;

import android.content.Context;
import android.graphics.Point;
import android.util.Log;
import android.widget.AbsoluteLayout;
import com.ansca.corona.CoronaEnvironment;
import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeListener;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.naef.jnlua.JavaFunction;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.LuaType;
import com.naef.jnlua.NamedJavaFunction;

public class LuaLoader implements JavaFunction, CoronaRuntimeListener {
  private static String ADSSHOWN = "adsShown";
  
  private static final String PROVIDER_NAME = "AdMobProvider";
  
  protected static CoronaRuntimeTaskDispatcher fDispatcher;
  
  private static int fListener;
  
  private AbsoluteLayout fAbsoluteLayout;
  
  private double fAdHeightRatio;
  
  private AdMobAd fAdMobAd;
  
  private String fApplicationId;
  
  public LuaLoader() {
    if (CoronaEnvironment.getCoronaActivity() == null)
      throw new IllegalArgumentException("Activity cannot be null."); 
    fDispatcher = null;
    this.fApplicationId = "";
    this.fAdHeightRatio = 0.0D;
    fListener = -1;
  }
  
  protected static void dispatchEvent(final boolean isError, final String finalResponse, final String finalType, final String finalPhase) {
    CoronaRuntimeTaskDispatcher coronaRuntimeTaskDispatcher = fDispatcher;
    final int listener = fListener;
    if (coronaRuntimeTaskDispatcher != null && i != -1)
      coronaRuntimeTaskDispatcher.send(new CoronaRuntimeTask() {
            public void executeUsing(CoronaRuntime param1CoronaRuntime) {
              try {
                String str;
                LuaState luaState = param1CoronaRuntime.getLuaState();
                CoronaLua.newEvent(luaState, "adsRequest");
                luaState.pushString("AdMobProvider");
                luaState.setField(-2, "provider");
                luaState.pushBoolean(isError);
                luaState.setField(-2, "isError");
                if (finalResponse == null) {
                  str = "";
                } else {
                  str = finalResponse;
                } 
                luaState.pushString(str);
                luaState.setField(-2, "response");
                if (finalType == null) {
                  str = "";
                } else {
                  str = finalType;
                } 
                luaState.pushString(str);
                luaState.setField(-2, "type");
                if (finalPhase == null) {
                  str = "";
                } else {
                  str = finalPhase;
                } 
                luaState.pushString(str);
                luaState.setField(-2, "phase");
                CoronaLua.dispatchEvent(luaState, listener, 0);
                return;
              } catch (Exception exception) {
                exception.printStackTrace();
                return;
              } 
            }
          }); 
  }
  
  public int getHeight(LuaState paramLuaState) {
    double d4 = 0.0D;
    double d5 = 0.0D;
    double d1 = 0.0D;
    int i = paramLuaState.getTop();
    paramLuaState.getGlobal("require");
    paramLuaState.pushString("config");
    paramLuaState.call(1, -1);
    paramLuaState.getGlobal("application");
    double d3 = d4;
    double d2 = d5;
    if (paramLuaState.isTable(-1)) {
      paramLuaState.getField(-1, "content");
      d3 = d4;
      d2 = d5;
      if (paramLuaState.isTable(-1)) {
        paramLuaState.getField(-1, "height");
        d3 = paramLuaState.toNumber(-1);
        paramLuaState.pop(1);
        paramLuaState.getField(-1, "width");
        d2 = paramLuaState.toNumber(-1);
        paramLuaState.pop(1);
      } 
    } 
    paramLuaState.getGlobal("system");
    paramLuaState.getField(-1, "orientation");
    if (paramLuaState.isString(-1)) {
      String str = paramLuaState.toString(-1);
      if (str.equals("landscapeLeft") || str.equals("landscapeRight")) {
        d1 = this.fAdHeightRatio * d2;
        paramLuaState.setTop(i);
        paramLuaState.pushNumber(d1);
        return 1;
      } 
    } else {
      paramLuaState.setTop(i);
      paramLuaState.pushNumber(d1);
      return 1;
    } 
    d1 = this.fAdHeightRatio * d3;
    paramLuaState.setTop(i);
    paramLuaState.pushNumber(d1);
    return 1;
  }
  
  public int init(LuaState paramLuaState) {
    boolean bool = false;
    Context context = CoronaEnvironment.getApplicationContext();
    if (context != null) {
      context.enforceCallingOrSelfPermission("android.permission.INTERNET", null);
      context.enforceCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE", null);
    } 
    if ("" == this.fApplicationId) {
      if (CoronaLua.isListener(paramLuaState, -1, "adsRequest"))
        fListener = CoronaLua.newRef(paramLuaState, -1); 
      int i = -1 - 1;
      if (paramLuaState.isString(i)) {
        this.fApplicationId = paramLuaState.toString(i);
        bool = true;
      } 
      this.fAdMobAd = new AdMobAd(this.fApplicationId);
      paramLuaState.pushBoolean(bool);
      return 1;
    } 
    Log.v("Corona", "WARNING: ads.init() should only be called once. The application id has already been set to :" + this.fApplicationId + ".");
    this.fAdMobAd = new AdMobAd(this.fApplicationId);
    paramLuaState.pushBoolean(bool);
    return 1;
  }
  
  public int invoke(LuaState paramLuaState) {
    InitWrapper initWrapper = new InitWrapper();
    ShowWrapper showWrapper = new ShowWrapper();
    HideWrapper hideWrapper = new HideWrapper();
    HeightWrapper heightWrapper = new HeightWrapper();
    LoadWrapper loadWrapper = new LoadWrapper();
    IsLoadedWrapper isLoadedWrapper = new IsLoadedWrapper();
    paramLuaState.register(paramLuaState.toString(1), new NamedJavaFunction[] { initWrapper, showWrapper, hideWrapper, heightWrapper, loadWrapper, isLoadedWrapper });
    fDispatcher = new CoronaRuntimeTaskDispatcher(paramLuaState);
    return 1;
  }
  
  public void onExiting(CoronaRuntime paramCoronaRuntime) {
    this.fAdMobAd.destroy();
    CoronaLua.deleteRef(paramCoronaRuntime.getLuaState(), fListener);
    fListener = -1;
    this.fApplicationId = "";
  }
  
  public void onLoaded(CoronaRuntime paramCoronaRuntime) {}
  
  public void onResumed(CoronaRuntime paramCoronaRuntime) {
    this.fAdMobAd.resume();
  }
  
  public void onStarted(CoronaRuntime paramCoronaRuntime) {}
  
  public void onSuspended(CoronaRuntime paramCoronaRuntime) {
    this.fAdMobAd.pause();
  }
  
  public int show(LuaState paramLuaState) {
    int k = 1 + 1;
    String str3 = paramLuaState.checkString(1);
    int j = 0;
    byte b2 = 0;
    int i = 0;
    byte b1 = 0;
    boolean bool1 = false;
    boolean bool2 = false;
    String str1 = null;
    String str2 = null;
    if (paramLuaState.isTable(k)) {
      paramLuaState.getField(k, "x");
      j = b2;
      if (paramLuaState.isNumber(-1))
        j = (int)Math.round(paramLuaState.toNumber(-1)); 
      paramLuaState.pop(1);
      paramLuaState.getField(k, "y");
      i = b1;
      if (paramLuaState.isNumber(-1))
        i = (int)Math.round(paramLuaState.toNumber(-1)); 
      paramLuaState.pop(1);
      paramLuaState.getField(k, "testMode");
      bool1 = bool2;
      if (paramLuaState.isBoolean(-1))
        bool1 = paramLuaState.toBoolean(-1); 
      paramLuaState.pop(1);
      paramLuaState.getField(k, "appId");
      str1 = str2;
      if (paramLuaState.type(-1) == LuaType.STRING)
        str1 = paramLuaState.toString(-1); 
      paramLuaState.pop(1);
    } 
    Point point = CoronaEnvironment.getCoronaActivity().convertCoronaPointToAndroidPoint(j, i);
    if (point != null) {
      j = point.x;
      i = point.y;
    } 
    showAd(str3, j, i, bool1, str1);
    return 0;
  }
  
  public void showAd(String paramString1, int paramInt1, int paramInt2, boolean paramBoolean, String paramString2) {
    if (this.fAdMobAd != null) {
      if (paramString2 != null)
        this.fAdMobAd.setAppId(paramString2); 
      if (paramString1.equals("banner")) {
        double d = this.fAdMobAd.show(paramInt1, paramInt2, paramBoolean);
        if (d > 0.0D) {
          this.fAdHeightRatio = d;
          return;
        } 
        return;
      } 
      if (paramString1.equals("interstitial")) {
        this.fAdMobAd.showInterstitialAd(paramBoolean);
        return;
      } 
      Log.w("Corona", "ads.show() Could not recognize banner type(" + paramString1 + ")");
      return;
    } 
  }
  
  private class HeightWrapper implements NamedJavaFunction {
    private HeightWrapper() {}
    
    public String getName() {
      return "height";
    }
    
    public int invoke(LuaState param1LuaState) {
      return LuaLoader.this.getHeight(param1LuaState);
    }
  }
  
  private class HideWrapper implements NamedJavaFunction {
    private HideWrapper() {}
    
    public String getName() {
      return "hide";
    }
    
    public int invoke(LuaState param1LuaState) {
      LuaLoader.this.fAdMobAd.hide();
      return 0;
    }
  }
  
  private class InitWrapper implements NamedJavaFunction {
    private InitWrapper() {}
    
    public String getName() {
      return "init";
    }
    
    public int invoke(LuaState param1LuaState) {
      return LuaLoader.this.init(param1LuaState);
    }
  }
  
  private class IsLoadedWrapper implements NamedJavaFunction {
    private IsLoadedWrapper() {}
    
    public String getName() {
      return "isLoaded";
    }
    
    public int invoke(LuaState param1LuaState) {
      if (param1LuaState.type(-1) == LuaType.STRING) {
        String str = param1LuaState.toString(-1);
        param1LuaState.pushBoolean(LuaLoader.this.fAdMobAd.isLoaded(str));
        return 1;
      } 
      param1LuaState.pushBoolean(false);
      return 1;
    }
  }
  
  private class LoadWrapper implements NamedJavaFunction {
    private LoadWrapper() {}
    
    public String getName() {
      return "load";
    }
    
    public int invoke(LuaState param1LuaState) {
      boolean bool1 = false;
      boolean bool2 = false;
      String str = param1LuaState.toString(1);
      int i = 1 + 1;
      if (param1LuaState.isTable(i)) {
        param1LuaState.getField(i, "appId");
        if (param1LuaState.type(-1) == LuaType.STRING) {
          String str1 = param1LuaState.toString(-1);
          LuaLoader.this.fAdMobAd.setAppId(str1);
        } 
        param1LuaState.pop(1);
        param1LuaState.getField(i, "testMode");
        bool1 = bool2;
        if (param1LuaState.isBoolean(-1))
          bool1 = param1LuaState.toBoolean(-1); 
        param1LuaState.pop(1);
      } 
      LuaLoader.this.fAdMobAd.load(str, bool1);
      return 0;
    }
  }
  
  private class ShowWrapper implements NamedJavaFunction {
    private ShowWrapper() {}
    
    public String getName() {
      return "show";
    }
    
    public int invoke(LuaState param1LuaState) {
      return LuaLoader.this.show(param1LuaState);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\ads\admob\LuaLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */