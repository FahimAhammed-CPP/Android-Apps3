package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.leaderboard.Leaderboard;
import com.google.android.gms.games.leaderboard.LeaderboardScoreBuffer;
import com.google.android.gms.games.leaderboard.OnLeaderboardScoresLoadedListener;
import com.naef.jnlua.LuaState;

public class LoadTopScoresListener extends Listener implements OnLeaderboardScoresLoadedListener {
  private String fCategory;
  
  public LoadTopScoresListener(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, String paramString) {
    super(paramCoronaRuntimeTaskDispatcher, paramInt);
    this.fCategory = paramString;
  }
  
  public void onLeaderboardScoresLoaded(int paramInt, Leaderboard paramLeaderboard, final LeaderboardScoreBuffer scores) {
    if (this.fListener < 0)
      return; 
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, "loadScores");
          luaState.pushString("loadScores");
          luaState.setField(-2, "type");
          luaState.newTable(scores.getCount(), 0);
          for (int i = 0; i < scores.getCount(); i++) {
            Listener.pushLeaderboardScoreToLua(luaState, scores.get(i), LoadTopScoresListener.this.fCategory);
            luaState.rawSet(-2, i + 1);
          } 
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, LoadTopScoresListener.this.fListener, 0);
            CoronaLua.deleteRef(luaState, LoadTopScoresListener.this.fListener);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    this.fDispatcher.send(coronaRuntimeTask);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\LoadTopScoresListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */