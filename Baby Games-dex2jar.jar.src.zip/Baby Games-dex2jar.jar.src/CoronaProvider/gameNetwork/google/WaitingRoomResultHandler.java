package CoronaProvider.gameNetwork.google;

import android.content.Intent;
import com.ansca.corona.CoronaActivity;
import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.naef.jnlua.LuaState;
import java.util.ArrayList;

public class WaitingRoomResultHandler extends Listener implements CoronaActivity.OnActivityResultHandler {
  private GameHelper fGameHelper;
  
  public WaitingRoomResultHandler(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GameHelper paramGameHelper) {
    super(paramCoronaRuntimeTaskDispatcher, paramInt);
    this.fGameHelper = paramGameHelper;
  }
  
  public void onHandleActivityResult(CoronaActivity paramCoronaActivity, int paramInt1, int paramInt2, Intent paramIntent) {
    paramCoronaActivity.unregisterActivityResultHandler(this);
    paramCoronaActivity.getRuntimeTaskDispatcher();
    Room room = (Room)paramIntent.getExtras().get("room");
    if (-1 == paramInt2) {
      pushIntentResult(false, "start", room);
      return;
    } 
    if (paramInt2 == 0 || 10005 == paramInt2) {
      pushIntentResult(true, "cancel", room);
      if (this.fGameHelper != null && this.fGameHelper.getGamesClient() != null) {
        this.fGameHelper.getGamesClient().leaveRoom(RoomManager.getRoomManager(this.fDispatcher, this.fListener, this.fGameHelper.getGamesClient()), room.getRoomId());
        return;
      } 
      return;
    } 
    if (10001 == paramInt2 && this.fGameHelper != null && this.fGameHelper.getGamesClient() != null) {
      this.fGameHelper.signOut();
      return;
    } 
  }
  
  public void pushIntentResult(final boolean isError, final String phase, final Room room) {
    if (this.fListener < 0)
      return; 
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, "waitingRoom");
          luaState.pushString("waitingRoom");
          luaState.setField(-2, "type");
          luaState.newTable();
          luaState.pushBoolean(isError);
          luaState.setField(-2, "isError");
          luaState.pushString(phase);
          luaState.setField(-2, "phase");
          luaState.pushString(room.getRoomId());
          luaState.setField(-2, "roomID");
          int j = 1;
          ArrayList<String> arrayList = room.getParticipantIds();
          int i = 0;
          while (i < arrayList.size()) {
            int k = j;
            if (arrayList.get(i) != room.getParticipantId(finalGamesClient.getCurrentPlayerId())) {
              luaState.pushString(arrayList.get(i));
              luaState.rawSet(-2, j);
              k = j + 1;
            } 
            i++;
            j = k;
          } 
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, WaitingRoomResultHandler.this.fListener, 0);
            CoronaLua.deleteRef(luaState, WaitingRoomResultHandler.this.fListener);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    this.fDispatcher.send(coronaRuntimeTask);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\WaitingRoomResultHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */