package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.OnPlayersLoadedListener;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerBuffer;
import com.naef.jnlua.LuaState;
import java.util.HashMap;
import java.util.Iterator;

public class LoadInvitablePlayersManager {
  private CoronaRuntimeTaskDispatcher fDispatcher;
  
  private GamesClient fGamesClient;
  
  private int fListener;
  
  public LoadInvitablePlayersManager(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GamesClient paramGamesClient) {
    this.fDispatcher = paramCoronaRuntimeTaskDispatcher;
    this.fListener = paramInt;
    this.fGamesClient = paramGamesClient;
  }
  
  public void load() {
    if (this.fDispatcher != null && this.fListener > 0 && this.fGamesClient != null)
      this.fGamesClient.loadMoreInvitablePlayers(new LoadPlayerListener(), 25); 
  }
  
  public class LoadPlayerListener implements OnPlayersLoadedListener {
    private HashMap<String, Player> fPlayers = new HashMap<String, Player>();
    
    private void callback() {
      if (LoadInvitablePlayersManager.this.fListener < 0)
        return; 
      CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
          public void executeUsing(CoronaRuntime param2CoronaRuntime) {
            Iterator<Player> iterator = LoadInvitablePlayersManager.LoadPlayerListener.this.fPlayers.values().iterator();
            LuaState luaState = param2CoronaRuntime.getLuaState();
            CoronaLua.newEvent(luaState, "loadFriends");
            luaState.pushString("loadFriends");
            luaState.setField(-2, "type");
            luaState.newTable();
            for (int i = 1; iterator.hasNext(); i++) {
              Listener.pushPlayerToLua(luaState, iterator.next());
              luaState.rawSet(-2, i);
            } 
            luaState.setField(-2, "data");
            try {
              CoronaLua.dispatchEvent(luaState, LoadInvitablePlayersManager.this.fListener, 0);
              CoronaLua.deleteRef(luaState, LoadInvitablePlayersManager.this.fListener);
              return;
            } catch (Exception exception) {
              exception.printStackTrace();
              return;
            } 
          }
        };
      LoadInvitablePlayersManager.this.fDispatcher.send(coronaRuntimeTask);
    }
    
    public void onPlayersLoaded(int param1Int, PlayerBuffer param1PlayerBuffer) {
      if (param1PlayerBuffer.getCount() > 1) {
        for (param1Int = 0; param1Int < param1PlayerBuffer.getCount(); param1Int++) {
          String str = param1PlayerBuffer.get(param1Int).getPlayerId();
          if (this.fPlayers.containsKey(str)) {
            callback();
            return;
          } 
          this.fPlayers.put(str, param1PlayerBuffer.get(param1Int));
        } 
        LoadInvitablePlayersManager.this.fGamesClient.loadMoreInvitablePlayers(this, 25);
        return;
      } 
      callback();
    }
  }
  
  class null implements CoronaRuntimeTask {
    public void executeUsing(CoronaRuntime param1CoronaRuntime) {
      Iterator<Player> iterator = this.this$1.fPlayers.values().iterator();
      LuaState luaState = param1CoronaRuntime.getLuaState();
      CoronaLua.newEvent(luaState, "loadFriends");
      luaState.pushString("loadFriends");
      luaState.setField(-2, "type");
      luaState.newTable();
      for (int i = 1; iterator.hasNext(); i++) {
        Listener.pushPlayerToLua(luaState, iterator.next());
        luaState.rawSet(-2, i);
      } 
      luaState.setField(-2, "data");
      try {
        CoronaLua.dispatchEvent(luaState, LoadInvitablePlayersManager.this.fListener, 0);
        CoronaLua.deleteRef(luaState, LoadInvitablePlayersManager.this.fListener);
        return;
      } catch (Exception exception) {
        exception.printStackTrace();
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\LoadInvitablePlayersManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */