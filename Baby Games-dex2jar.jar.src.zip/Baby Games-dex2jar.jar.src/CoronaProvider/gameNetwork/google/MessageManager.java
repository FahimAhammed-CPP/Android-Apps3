package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessage;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessageReceivedListener;
import com.google.android.gms.games.multiplayer.realtime.RealTimeReliableMessageSentListener;
import com.naef.jnlua.LuaState;
import java.util.ArrayList;

public class MessageManager implements RealTimeMessageReceivedListener {
  static CoronaRuntimeTaskDispatcher fDispatcher;
  
  static GamesClient fGamesClient;
  
  static int fMessageListener;
  
  static MessageManager fMessageManager;
  
  private MessageManager(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GamesClient paramGamesClient) {
    fGamesClient = paramGamesClient;
  }
  
  public static MessageManager getMessageManager(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GamesClient paramGamesClient) {
    if (fMessageManager == null)
      fMessageManager = new MessageManager(paramCoronaRuntimeTaskDispatcher, paramInt, paramGamesClient); 
    setDispatcher(paramCoronaRuntimeTaskDispatcher);
    if (paramInt > 0)
      setMessageListener(paramInt); 
    return fMessageManager;
  }
  
  private static void setDispatcher(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher) {
    fDispatcher = paramCoronaRuntimeTaskDispatcher;
  }
  
  public static void setMessageListener(int paramInt) {
    fMessageListener = paramInt;
  }
  
  public void onRealTimeMessageReceived(final RealTimeMessage finalMessage) {
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, "messageReceived");
          luaState.pushString("messageReceived");
          luaState.setField(-2, "type");
          luaState.newTable();
          luaState.pushString(new String(finalMessage.getMessageData()));
          luaState.setField(-2, "message");
          luaState.pushString(finalMessage.getSenderParticipantId());
          luaState.setField(-2, "participantId");
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, MessageManager.fMessageListener, 0);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    fDispatcher.send(coronaRuntimeTask);
  }
  
  public void sendMessage(ArrayList<String> paramArrayList, String paramString1, String paramString2, boolean paramBoolean) {
    if (paramBoolean) {
      for (String str : paramArrayList) {
        fGamesClient.sendReliableRealTimeMessage(new RealTimeReliableMessageSentListener() {
              public void onRealTimeMessageSent(int param1Int1, int param1Int2, String param1String) {}
            },  paramString1.getBytes(), paramString2, str);
      } 
    } else {
      fGamesClient.sendUnreliableRealTimeMessage(paramString1.getBytes(), paramString2, paramArrayList);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\MessageManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */