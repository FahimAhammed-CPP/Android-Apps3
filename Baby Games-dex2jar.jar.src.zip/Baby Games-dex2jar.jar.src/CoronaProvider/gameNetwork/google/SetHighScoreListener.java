package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.leaderboard.OnScoreSubmittedListener;
import com.google.android.gms.games.leaderboard.SubmitScoreResult;
import com.naef.jnlua.LuaState;

public class SetHighScoreListener extends Listener implements OnScoreSubmittedListener {
  public SetHighScoreListener(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt) {
    super(paramCoronaRuntimeTaskDispatcher, paramInt);
  }
  
  public void onScoreSubmitted(int paramInt, final SubmitScoreResult finalScoreResult) {
    if (this.fListener < 0)
      return; 
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, "setHighScore");
          luaState.pushString("setHighScore");
          luaState.setField(-2, "type");
          Listener.pushSubmitScoreResultToLua(luaState, finalScoreResult);
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, SetHighScoreListener.this.fListener, 0);
            CoronaLua.deleteRef(luaState, SetHighScoreListener.this.fListener);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    this.fDispatcher.send(coronaRuntimeTask);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\SetHighScoreListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */