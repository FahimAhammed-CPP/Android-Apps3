package CoronaProvider.gameNetwork.google;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.ansca.corona.CoronaActivity;
import com.ansca.corona.CoronaEnvironment;
import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.naef.jnlua.JavaFunction;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.NamedJavaFunction;
import java.util.ArrayList;
import java.util.HashSet;

public class LuaLoader implements JavaFunction {
  private static final String EVENT_NAME = "gameNetwork";
  
  private CoronaRuntimeTaskDispatcher fDispatcher;
  
  private int fListener;
  
  private GameHelper helper;
  
  public LuaLoader() {
    if (CoronaEnvironment.getCoronaActivity() == null)
      throw new IllegalArgumentException("Activity cannot be null."); 
    this.fListener = -1;
  }
  
  private boolean isConnected() {
    return (this.helper != null && this.helper.getGamesClient() != null && this.helper.getGamesClient().isConnected());
  }
  
  public int init(LuaState paramLuaState) {
    final int finalListener = -1;
    int j = paramLuaState.getTop();
    if (CoronaLua.isListener(paramLuaState, -1, ""))
      i = CoronaLua.newRef(paramLuaState, -1); 
    paramLuaState.setTop(j);
    if (i > 0) {
      CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
          public void executeUsing(CoronaRuntime param1CoronaRuntime) {
            boolean bool = true;
            try {
              int i = GooglePlayServicesUtil.isGooglePlayServicesAvailable((Context)CoronaEnvironment.getCoronaActivity());
              boolean bool1 = false;
              String str = "";
              if (i == 1) {
                bool1 = true;
                str = "Service Missing";
              } else if (i == 2) {
                bool1 = true;
                str = "Service Version Update Required";
              } else if (i == 3) {
                bool1 = true;
                str = "Service Disabled";
              } else if (i == 9) {
                bool1 = true;
                str = "Service Invalid";
              } 
              LuaState luaState = param1CoronaRuntime.getLuaState();
              CoronaLua.newEvent(luaState, "init");
              luaState.pushString("init");
              luaState.setField(-2, "type");
              if (bool1)
                bool = false; 
              luaState.pushBoolean(bool);
              luaState.setField(-2, "data");
              if (bool1) {
                luaState.pushBoolean(bool1);
                luaState.setField(-2, "isError");
                luaState.pushString(str);
                luaState.setField(-2, "errorMessage");
                luaState.pushNumber(i);
                luaState.setField(-2, "errorCode");
              } 
              if (finalListener > 0) {
                CoronaLua.dispatchEvent(luaState, finalListener, 0);
                return;
              } 
            } catch (Exception exception) {
              exception.printStackTrace();
            } 
          }
        };
      this.fDispatcher.send(coronaRuntimeTask);
    } 
    return 0;
  }
  
  public int invoke(LuaState paramLuaState) {
    this.fDispatcher = new CoronaRuntimeTaskDispatcher(paramLuaState);
    InitWrapper initWrapper = new InitWrapper();
    ShowWrapper showWrapper = new ShowWrapper();
    RequestWrapper requestWrapper = new RequestWrapper();
    paramLuaState.register(paramLuaState.toString(1), new NamedJavaFunction[] { initWrapper, showWrapper, requestWrapper });
    return 1;
  }
  
  public int login(int paramInt, boolean paramBoolean) {
    CoronaActivity coronaActivity = CoronaEnvironment.getCoronaActivity();
    SignInListener signInListener = new SignInListener(this.fDispatcher, paramInt);
    if (isConnected() && coronaActivity != null) {
      signInListener.onSignInSucceeded();
      return 0;
    } 
    this.helper = new GameHelper((Activity)coronaActivity);
    this.helper.setup(signInListener, 1);
    if (!paramBoolean) {
      this.helper.getGamesClient().connect();
      return 0;
    } 
    paramInt = coronaActivity.registerActivityResultHandler(new CoronaActivity.OnActivityResultHandler() {
          public void onHandleActivityResult(CoronaActivity param1CoronaActivity, int param1Int1, int param1Int2, Intent param1Intent) {
            LuaLoader.this.helper.onActivityResult(param1Int1, param1Int2, param1Intent);
          }
        });
    this.helper.setRequestCode(paramInt);
    if (!this.helper.getGamesClient().isConnected()) {
      coronaActivity.runOnUiThread(new Runnable() {
            public void run() {
              finalHelper.beginUserInitiatedSignIn();
            }
          });
      return 0;
    } 
    return 0;
  }
  
  public int logout() {
    if (isConnected()) {
      try {
        this.helper.signOut();
      } catch (SecurityException securityException) {}
      this.helper = null;
    } 
    return 0;
  }
  
  public int request(LuaState paramLuaState) {
    HashSet<String> hashSet1;
    RoomManager roomManager;
    HashSet<String> hashSet2;
    String str2;
    ArrayList<String> arrayList;
    String str1;
    int j = -1;
    int i = -1;
    int k = i;
    if (paramLuaState.isTable(-1)) {
      paramLuaState.getField(-1, "listener");
      if (CoronaLua.isListener(paramLuaState, -1, ""))
        i = CoronaLua.newRef(paramLuaState, -1); 
      paramLuaState.pop(1);
      j = -1 - 1;
      k = i;
    } 
    String str3 = paramLuaState.toString(j);
    if (str3.equals("unlockAchievement")) {
      String str = "";
      i = paramLuaState.getTop();
      str3 = str;
      if (paramLuaState.isTable(-1)) {
        paramLuaState.getField(-1, "achievement");
        str3 = str;
        if (paramLuaState.isTable(-1)) {
          paramLuaState.getField(-1, "identifier");
          str3 = str;
          if (paramLuaState.isString(-1))
            str3 = paramLuaState.toString(-1); 
        } 
      } 
      paramLuaState.setTop(i);
      if (isConnected() && !str3.equals(""))
        this.helper.getGamesClient().unlockAchievementImmediate(new UnlockAchievementListener(this.fDispatcher, k), str3); 
      return 0;
    } 
    if (str3.equals("setHighScore")) {
      long l2 = 0L;
      i = paramLuaState.getTop();
      str3 = "";
      String str = str3;
      long l1 = l2;
      if (paramLuaState.isTable(-1)) {
        paramLuaState.getField(-1, "localPlayerScore");
        str = str3;
        l1 = l2;
        if (paramLuaState.isTable(-1)) {
          paramLuaState.getField(-1, "category");
          if (paramLuaState.isString(-1))
            str3 = paramLuaState.toString(-1); 
          paramLuaState.getField(-2, "value");
          str = str3;
          l1 = l2;
          if (paramLuaState.isNumber(-1)) {
            l1 = (long)paramLuaState.toNumber(-1);
            str = str3;
          } 
        } 
      } 
      paramLuaState.setTop(i);
      if (isConnected() && !str.equals("")) {
        this.helper.getGamesClient().submitScoreImmediate(new SetHighScoreListener(this.fDispatcher, k), str, l1);
        return 0;
      } 
      return 0;
    } 
    if (str3.equals("isConnected")) {
      paramLuaState.pushBoolean(isConnected());
      return 0 + 1;
    } 
    if (str3.equals("login")) {
      boolean bool2 = true;
      boolean bool1 = bool2;
      if (paramLuaState.isTable(-1)) {
        paramLuaState.getField(-1, "userInitiated");
        bool1 = bool2;
        if (paramLuaState.isBoolean(-1))
          bool1 = paramLuaState.toBoolean(-1); 
      } 
      login(k, bool1);
      return 0;
    } 
    if (str3.equals("logout")) {
      logout();
      return 0;
    } 
    if (str3.equals("loadPlayers")) {
      hashSet2 = new HashSet();
      j = paramLuaState.getTop();
      if (paramLuaState.isTable(-1)) {
        paramLuaState.getField(-1, "playerIDs");
        if (paramLuaState.isTable(-1)) {
          int m = paramLuaState.length(-1);
          if (m > 0)
            for (i = 1; i <= m; i++) {
              paramLuaState.rawGet(-1, i);
              hashSet2.add(paramLuaState.toString(-1));
              paramLuaState.pop(1);
            }  
        } 
      } 
      paramLuaState.setTop(j);
      if (isConnected()) {
        (new PlayerLoaderManager(this.fDispatcher, k, this.helper.getGamesClient(), "loadPlayers")).loadPlayers(hashSet2, false);
        return 0;
      } 
      return 0;
    } 
    if (hashSet2.equals("loadLocalPlayer")) {
      if (isConnected()) {
        hashSet1 = new HashSet();
        hashSet1.add(this.helper.getGamesClient().getCurrentPlayerId());
        (new PlayerLoaderManager(this.fDispatcher, k, this.helper.getGamesClient(), "loadPlayers")).loadPlayers(hashSet1, true);
        return 0;
      } 
      return 0;
    } 
    if (hashSet2.equals("loadScores")) {
      boolean bool;
      String str6;
      str2 = "";
      String str4 = "Global";
      String str5 = "AllTime";
      j = 25;
      boolean bool2 = false;
      boolean bool1 = false;
      int m = hashSet1.getTop();
      if (hashSet1.isTable(-1)) {
        hashSet1.getField(-1, "leaderboard");
        str6 = str2;
        i = j;
        String str7 = str4;
        String str8 = str5;
        if (hashSet1.isTable(-1)) {
          hashSet1.getField(-1, "category");
          if (hashSet1.isString(-1))
            str2 = hashSet1.toString(-1); 
          hashSet1.pop(1);
          hashSet1.getField(-1, "playerScope");
          if (hashSet1.isString(-1))
            str4 = hashSet1.toString(-1); 
          hashSet1.pop(1);
          hashSet1.getField(-1, "timeScope");
          if (hashSet1.isString(-1))
            str5 = hashSet1.toString(-1); 
          hashSet1.pop(1);
          hashSet1.getField(-1, "playerCentered");
          if (hashSet1.isBoolean(-1))
            bool1 = hashSet1.toBoolean(-1); 
          hashSet1.pop(1);
          hashSet1.getField(-1, "range");
          str6 = str2;
          i = j;
          bool2 = bool1;
          str7 = str4;
          str8 = str5;
          if (hashSet1.isTable(-1)) {
            hashSet1.rawGet(-1, 2);
            str6 = str2;
            i = j;
            bool2 = bool1;
            str7 = str4;
            str8 = str5;
            if (hashSet1.isNumber(-1)) {
              j = Double.valueOf(hashSet1.toNumber(-1)).intValue();
              str6 = str2;
              i = j;
              bool2 = bool1;
              str7 = str4;
              str8 = str5;
              if (j > 25) {
                i = 25;
                str8 = str5;
                str7 = str4;
                bool2 = bool1;
                str6 = str2;
              } 
            } 
          } 
        } 
        if (!str6.equals("")) {
          if (str8.equals("Week")) {
            j = 1;
          } else if (str8.equals("Today")) {
            j = 0;
          } else {
            j = 2;
          } 
          if (str7.equals("FriendsOnly")) {
            bool = true;
          } else {
            bool = false;
          } 
          if (isConnected()) {
            if (bool2) {
              this.helper.getGamesClient().loadPlayerCenteredScores(new LoadTopScoresListener(this.fDispatcher, k, str6), str6, j, bool, i, true);
              hashSet1.setTop(m);
              return 0;
            } 
          } else {
            hashSet1.setTop(m);
            return 0;
          } 
        } else {
          hashSet1.setTop(m);
          return 0;
        } 
      } else {
        hashSet1.setTop(m);
        return 0;
      } 
      this.helper.getGamesClient().loadTopScores(new LoadTopScoresListener(this.fDispatcher, k, str6), str6, j, bool, i, true);
      hashSet1.setTop(m);
      return 0;
    } 
    if (str2.equals("loadAchievements") || str2.equals("loadAchievementDescriptions")) {
      if (isConnected()) {
        this.helper.getGamesClient().loadAchievements(new LoadAchievementsListener(this.fDispatcher, k), true);
        return 0;
      } 
      return 0;
    } 
    if (str2.equals("loadLeaderboardCategories")) {
      if (isConnected()) {
        this.helper.getGamesClient().loadLeaderboardMetadata(new LoadLeaderboardCategoriesListener(this.fDispatcher, k), true);
        return 0;
      } 
      return 0;
    } 
    if (str2.equals("createRoom")) {
      if (isConnected()) {
        arrayList = new ArrayList();
        i = 0;
        j = 0;
        int m = hashSet1.getTop();
        if (hashSet1.isTable(-1)) {
          hashSet1.getField(-1, "playerIDs");
          if (hashSet1.isTable(-1)) {
            j = hashSet1.length(-1);
            if (j > 0)
              for (i = 1; i <= j; i++) {
                hashSet1.rawGet(-1, i);
                arrayList.add(hashSet1.toString(-1));
                hashSet1.pop(1);
              }  
          } 
          hashSet1.pop(1);
          hashSet1.getField(-1, "maxAutoMatchPlayers");
          i = (int)hashSet1.toNumber(-1);
          hashSet1.pop(1);
          hashSet1.getField(-1, "minAutoMatchPlayers");
          j = (int)hashSet1.toNumber(-1);
        } 
        hashSet1.setTop(m);
        roomManager = RoomManager.getRoomManager(this.fDispatcher, k, this.helper.getGamesClient());
        MessageManager messageManager = MessageManager.getMessageManager(this.fDispatcher, k, this.helper.getGamesClient());
        RoomConfig.Builder builder = RoomConfig.builder(roomManager);
        if (arrayList.size() > 0)
          builder.addPlayersToInvite(arrayList); 
        if (j > 0 || i > 0)
          builder.setAutoMatchCriteria(RoomConfig.createAutoMatchCriteria(j, i, 0L)); 
        builder.setMessageReceivedListener(messageManager);
        builder.setRoomStatusUpdateListener(roomManager);
        builder.setSocketCommunicationEnabled(false);
        this.helper.getGamesClient().createRoom(builder.build());
        return 0;
      } 
      return 0;
    } 
    if (arrayList.equals("joinRoom")) {
      if (isConnected()) {
        ArrayList<String> arrayList1 = null;
        i = roomManager.getTop();
        arrayList = arrayList1;
        if (roomManager.isTable(-1)) {
          roomManager.getField(-1, "roomID");
          arrayList = arrayList1;
          if (roomManager.isString(-1))
            str1 = roomManager.toString(-1); 
        } 
        roomManager.setTop(i);
        if (str1 != null) {
          roomManager = RoomManager.getRoomManager(this.fDispatcher, k, this.helper.getGamesClient());
          MessageManager messageManager = MessageManager.getMessageManager(this.fDispatcher, k, this.helper.getGamesClient());
          RoomConfig.Builder builder = RoomConfig.builder(roomManager);
          builder.setInvitationIdToAccept(str1);
          builder.setSocketCommunicationEnabled(false);
          builder.setMessageReceivedListener(messageManager);
          builder.setRoomStatusUpdateListener(roomManager);
          this.helper.getGamesClient().joinRoom(builder.build());
          return 0;
        } 
      } 
      return 0;
    } 
    if (str1.equals("sendMessage")) {
      if (isConnected()) {
        ArrayList<String> arrayList1 = new ArrayList();
        String str4 = null;
        String str5 = null;
        str1 = null;
        String str6 = null;
        boolean bool1 = true;
        boolean bool2 = true;
        j = roomManager.getTop();
        if (roomManager.isTable(-1)) {
          roomManager.getField(-1, "playerIDs");
          if (roomManager.isTable(-1)) {
            int m = roomManager.length(-1);
            if (m > 0)
              for (i = 1; i <= m; i++) {
                roomManager.rawGet(-1, i);
                arrayList1.add(roomManager.toString(-1));
                roomManager.pop(1);
              }  
          } 
          roomManager.pop(1);
          roomManager.getField(-1, "roomID");
          str1 = str6;
          if (roomManager.isString(-1))
            str1 = roomManager.toString(-1); 
          roomManager.pop(1);
          roomManager.getField(-1, "message");
          str4 = str5;
          if (roomManager.isString(-1))
            str4 = roomManager.toString(-1); 
          roomManager.pop(1);
          roomManager.getField(-1, "reliable");
          bool1 = bool2;
          if (roomManager.isBoolean(-1))
            bool1 = roomManager.toBoolean(-1); 
          roomManager.pop(1);
        } 
        roomManager.setTop(j);
        if (arrayList1 != null && str4 != null && str1 != null) {
          MessageManager.getMessageManager(this.fDispatcher, k, this.helper.getGamesClient()).sendMessage(arrayList1, str4, str1, bool1);
          return 0;
        } 
      } 
      return 0;
    } 
    if (str1.equals("leaveRoom")) {
      if (isConnected()) {
        String str = null;
        i = roomManager.getTop();
        str1 = str;
        if (roomManager.isTable(-1)) {
          roomManager.getField(-1, "roomID");
          str1 = str;
          if (roomManager.isString(-1))
            str1 = roomManager.toString(-1); 
        } 
        roomManager.setTop(i);
        if (str1 != null) {
          roomManager = RoomManager.getRoomManager(this.fDispatcher, k, this.helper.getGamesClient());
          this.helper.getGamesClient().leaveRoom(roomManager, str1);
          return 0;
        } 
      } 
      return 0;
    } 
    if (str1.equals("setMessageReceivedListener")) {
      MessageManager.setMessageListener(k);
      return 0;
    } 
    if (str1.equals("setRoomListener")) {
      RoomManager.setRoomListener(k);
      return 0;
    } 
    if (str1.equals("setInvitationReceivedListener")) {
      if (isConnected()) {
        this.helper.getGamesClient().registerInvitationListener(new InvitationReceivedListener(this.fDispatcher, k));
        return 0;
      } 
      return 0;
    } 
    if (str1.equals("loadFriends")) {
      (new LoadInvitablePlayersManager(this.fDispatcher, k, this.helper.getGamesClient())).load();
      return 0;
    } 
    return 0;
  }
  
  public int show(LuaState paramLuaState) {
    final GameHelper finalHelper;
    final int finalMinToStart = -1;
    final int finalMin = -1;
    final int finalMax = paramLuaState.getTop();
    final int finalRequestCode = i;
    if (paramLuaState.isTable(-1)) {
      paramLuaState.getField(-1, "listener");
      if (CoronaLua.isListener(paramLuaState, -1, "googlePlayGames"))
        i = CoronaLua.newRef(paramLuaState, -1); 
      k = -1 - 1;
      j = i;
    } 
    paramLuaState.setTop(m);
    String str = paramLuaState.toString(k);
    CoronaActivity coronaActivity = CoronaEnvironment.getCoronaActivity();
    if (isConnected() && coronaActivity != null) {
      gameHelper = this.helper;
      if (str.equals("achievements")) {
        coronaActivity.runOnUiThread(new Runnable() {
              public void run() {
                if (CoronaEnvironment.getCoronaActivity() != null)
                  CoronaEnvironment.getCoronaActivity().startActivityForResult(finalHelper.getGamesClient().getAchievementsIntent(), requestCode); 
              }
            });
        return 0;
      } 
    } else {
      return 0;
    } 
    if (str.equals("leaderboards")) {
      coronaActivity.runOnUiThread(new Runnable() {
            public void run() {
              if (CoronaEnvironment.getCoronaActivity() != null)
                CoronaEnvironment.getCoronaActivity().startActivityForResult(finalHelper.getGamesClient().getAllLeaderboardsIntent(), requestCode); 
            }
          });
      return 0;
    } 
    if (str.equals("selectPlayers")) {
      i = -1;
      byte b = -1;
      m = b;
      k = i;
      if (paramLuaState.isTable(-1)) {
        paramLuaState.getField(-1, "minPlayers");
        if (paramLuaState.isNumber(-1)) {
          i = (int)paramLuaState.toNumber(-1);
          paramLuaState.pop(1);
        } 
        paramLuaState.getField(-1, "maxPlayers");
        m = b;
        k = i;
        if (paramLuaState.isNumber(-1)) {
          m = (int)paramLuaState.toNumber(-1);
          paramLuaState.pop(1);
          k = i;
        } 
      } 
      if (k > -1 && m > -1)
        coronaActivity.runOnUiThread(new Runnable() {
              public void run() {
                if (CoronaEnvironment.getCoronaActivity() != null)
                  CoronaEnvironment.getCoronaActivity().startActivityForResult(finalHelper.getGamesClient().getRealTimeSelectOpponentsIntent(finalMin, finalMax), finalRequestCode); 
              }
            }); 
      return 0;
    } 
    if (str.equals("waitingRoom")) {
      str = null;
      k = 0;
      i = k;
      if (paramLuaState.isTable(-1)) {
        paramLuaState.getField(-1, "roomID");
        String str1 = paramLuaState.toString(-1);
        paramLuaState.pop(1);
        paramLuaState.getField(-1, "minPlayers");
        i = k;
        str = str1;
        if (paramLuaState.isNumber(-1)) {
          i = (int)paramLuaState.toNumber(-1);
          str = str1;
        } 
      } 
      if (str != null) {
        j = coronaActivity.registerActivityResultHandler(new WaitingRoomResultHandler(this.fDispatcher, j, gameHelper));
        coronaActivity.runOnUiThread(new Runnable() {
              public void run() {
                if (CoronaEnvironment.getCoronaActivity() != null && room != null)
                  CoronaEnvironment.getCoronaActivity().startActivityForResult(finalHelper.getGamesClient().getRealTimeWaitingRoomIntent(room, finalMinToStart), finalRequestCode); 
              }
            });
      } 
      return 0;
    } 
    if (str.equals("invitations"))
      coronaActivity.runOnUiThread(new Runnable() {
            public void run() {
              if (CoronaEnvironment.getCoronaActivity() != null)
                CoronaEnvironment.getCoronaActivity().startActivityForResult(finalHelper.getGamesClient().getInvitationInboxIntent(), finalRequestCode); 
            }
          }); 
    return 0;
  }
  
  private class InitWrapper implements NamedJavaFunction {
    private InitWrapper() {}
    
    public String getName() {
      return "init";
    }
    
    public int invoke(LuaState param1LuaState) {
      return LuaLoader.this.init(param1LuaState);
    }
  }
  
  private class RequestWrapper implements NamedJavaFunction {
    private RequestWrapper() {}
    
    public String getName() {
      return "request";
    }
    
    public int invoke(LuaState param1LuaState) {
      return LuaLoader.this.request(param1LuaState);
    }
  }
  
  private class ShowWrapper implements NamedJavaFunction {
    private ShowWrapper() {}
    
    public String getName() {
      return "show";
    }
    
    public int invoke(LuaState param1LuaState) {
      return LuaLoader.this.show(param1LuaState);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\LuaLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */