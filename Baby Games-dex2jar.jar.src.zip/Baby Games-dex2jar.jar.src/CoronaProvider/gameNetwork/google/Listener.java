package CoronaProvider.gameNetwork.google;

import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.achievement.Achievement;
import com.google.android.gms.games.leaderboard.Leaderboard;
import com.google.android.gms.games.leaderboard.LeaderboardScore;
import com.google.android.gms.games.leaderboard.SubmitScoreResult;
import com.google.android.gms.games.multiplayer.Invitation;
import com.naef.jnlua.LuaState;
import java.util.Date;

public abstract class Listener {
  public static final String ALIAS = "alias";
  
  public static final String DATA = "data";
  
  public static final String PLAYER_ID = "playerID";
  
  public static final String TYPE = "type";
  
  protected CoronaRuntimeTaskDispatcher fDispatcher;
  
  protected int fListener;
  
  public Listener(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt) {
    this.fListener = paramInt;
    this.fDispatcher = paramCoronaRuntimeTaskDispatcher;
  }
  
  protected static void pushAchievementToLua(LuaState paramLuaState, Achievement paramAchievement) {
    boolean bool1;
    boolean bool2 = true;
    paramLuaState.newTable(0, 6);
    paramLuaState.pushString(paramAchievement.getAchievementId());
    paramLuaState.setField(-2, "identifier");
    paramLuaState.pushString(paramAchievement.getName());
    paramLuaState.setField(-2, "title");
    paramLuaState.pushString(paramAchievement.getDescription());
    paramLuaState.setField(-2, "description");
    if (paramAchievement.getState() == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    paramLuaState.pushBoolean(bool1);
    paramLuaState.setField(-2, "isCompleted");
    if (paramAchievement.getState() == 2) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    paramLuaState.pushBoolean(bool1);
    paramLuaState.setField(-2, "isHidden");
    paramLuaState.pushNumber(paramAchievement.getLastUpdatedTimestamp());
    paramLuaState.setField(-2, "lastReportedDate");
  }
  
  protected static void pushInvitationToLua(LuaState paramLuaState, Invitation paramInvitation) {
    paramLuaState.newTable(0, 3);
    paramLuaState.pushString(paramInvitation.getInvitationId());
    paramLuaState.setField(-2, "roomID");
    paramLuaState.pushString(paramInvitation.getInviter().getDisplayName());
    paramLuaState.setField(-2, "alias");
    paramLuaState.pushString(paramInvitation.getInviter().getPlayer().getPlayerId());
    paramLuaState.setField(-2, "playerID");
  }
  
  protected static void pushLeaderboardScoreToLua(LuaState paramLuaState, LeaderboardScore paramLeaderboardScore, String paramString) {
    Player player = paramLeaderboardScore.getScoreHolder();
    paramLuaState.newTable(0, 7);
    paramLuaState.pushString(player.getPlayerId());
    paramLuaState.setField(-2, "playerID");
    paramLuaState.pushString(paramString);
    paramLuaState.setField(-2, "category");
    paramLuaState.pushNumber(paramLeaderboardScore.getRawScore());
    paramLuaState.setField(-2, "value");
    paramLuaState.pushString((new Date(paramLeaderboardScore.getTimestampMillis())).toString());
    paramLuaState.setField(-2, "date");
    paramLuaState.pushString(paramLeaderboardScore.getDisplayScore());
    paramLuaState.setField(-2, "formattedValue");
    paramLuaState.pushNumber(paramLeaderboardScore.getRank());
    paramLuaState.setField(-2, "rank");
    paramLuaState.pushNumber(paramLeaderboardScore.getTimestampMillis());
    paramLuaState.setField(-2, "unixTime");
  }
  
  protected static void pushLeaderboardToLua(LuaState paramLuaState, Leaderboard paramLeaderboard) {
    paramLuaState.newTable(0, 2);
    paramLuaState.pushString(paramLeaderboard.getLeaderboardId());
    paramLuaState.setField(-2, "category");
    paramLuaState.pushString(paramLeaderboard.getDisplayName());
    paramLuaState.setField(-2, "title");
  }
  
  protected static void pushPlayerToLua(LuaState paramLuaState, Player paramPlayer) {
    paramLuaState.newTable(0, 2);
    paramLuaState.pushString(paramPlayer.getPlayerId());
    paramLuaState.setField(-2, "playerID");
    paramLuaState.pushString(paramPlayer.getDisplayName());
    paramLuaState.setField(-2, "alias");
  }
  
  protected static void pushSubmitScoreResultToLua(LuaState paramLuaState, SubmitScoreResult paramSubmitScoreResult) {
    paramLuaState.newTable(4, 0);
    paramLuaState.pushString(paramSubmitScoreResult.getLeaderboardId());
    paramLuaState.setField(-2, "category");
    SubmitScoreResult.Result result = paramSubmitScoreResult.getScoreResult(2);
    if (result != null) {
      paramLuaState.pushNumber(result.rawScore);
      paramLuaState.setField(-2, "value");
      paramLuaState.pushString(result.formattedScore);
      paramLuaState.setField(-2, "formattedValue");
    } 
    paramLuaState.pushString(paramSubmitScoreResult.getPlayerId());
    paramLuaState.setField(-2, "playerID");
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\Listener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */