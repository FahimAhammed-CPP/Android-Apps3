package CoronaProvider.gameNetwork.google;

import android.content.Intent;
import com.ansca.corona.CoronaActivity;
import com.ansca.corona.CoronaLua;
import com.ansca.corona.CoronaRuntime;
import com.ansca.corona.CoronaRuntimeTask;
import com.ansca.corona.CoronaRuntimeTaskDispatcher;
import com.naef.jnlua.LuaState;
import java.util.ArrayList;
import java.util.Iterator;

public class SelectPlayersResultHandler extends Listener implements CoronaActivity.OnActivityResultHandler {
  private GameHelper fGameHelper;
  
  public SelectPlayersResultHandler(CoronaRuntimeTaskDispatcher paramCoronaRuntimeTaskDispatcher, int paramInt, GameHelper paramGameHelper) {
    super(paramCoronaRuntimeTaskDispatcher, paramInt);
    this.fGameHelper = paramGameHelper;
  }
  
  private void pushSelectedPlayersToLua(final ArrayList<String> invitees, final int minAutoMatch, final int maxAutoMatch, final String phase) {
    CoronaRuntimeTask coronaRuntimeTask = new CoronaRuntimeTask() {
        public void executeUsing(CoronaRuntime param1CoronaRuntime) {
          LuaState luaState = param1CoronaRuntime.getLuaState();
          CoronaLua.newEvent(luaState, "selectPlayers");
          luaState.pushString("selectPlayers");
          luaState.setField(-2, "type");
          luaState.newTable();
          int i = 1;
          Iterator<String> iterator = invitees.iterator();
          while (iterator.hasNext()) {
            luaState.pushString(iterator.next());
            luaState.rawSet(-2, i);
            i++;
          } 
          luaState.pushNumber(minAutoMatch);
          luaState.setField(-2, "minAutoMatchPlayers");
          luaState.pushNumber(maxAutoMatch);
          luaState.setField(-2, "maxAutoMatchPlayers");
          luaState.pushString(phase);
          luaState.setField(-2, "phase");
          luaState.setField(-2, "data");
          try {
            CoronaLua.dispatchEvent(luaState, SelectPlayersResultHandler.this.fListener, 0);
            CoronaLua.deleteRef(luaState, SelectPlayersResultHandler.this.fListener);
            return;
          } catch (Exception exception) {
            exception.printStackTrace();
            return;
          } 
        }
      };
    this.fDispatcher.send(coronaRuntimeTask);
  }
  
  public void onHandleActivityResult(CoronaActivity paramCoronaActivity, int paramInt1, int paramInt2, Intent paramIntent) {
    ArrayList<String> arrayList;
    String str;
    paramCoronaActivity.unregisterActivityResultHandler(this);
    paramCoronaActivity.getRuntimeTaskDispatcher();
    CoronaActivity coronaActivity = null;
    boolean bool1 = false;
    boolean bool2 = false;
    if (-1 == paramInt2) {
      arrayList = paramIntent.getStringArrayListExtra("players");
      paramInt1 = paramIntent.getIntExtra("min_automatch_players", 0);
      paramInt2 = paramIntent.getIntExtra("max_automatch_players", 0);
      str = "selected";
    } else if (10001 == paramInt2) {
      String str1 = "logout";
      paramCoronaActivity = coronaActivity;
      paramInt2 = bool2;
      paramInt1 = bool1;
      str = str1;
      if (this.fGameHelper != null) {
        paramCoronaActivity = coronaActivity;
        paramInt2 = bool2;
        paramInt1 = bool1;
        str = str1;
        if (this.fGameHelper.getGamesClient() != null) {
          this.fGameHelper.signOut();
          paramCoronaActivity = coronaActivity;
          paramInt2 = bool2;
          paramInt1 = bool1;
          str = str1;
        } 
      } 
    } else {
      arrayList = new ArrayList();
      str = "cancelled";
      paramInt2 = bool2;
      paramInt1 = bool1;
    } 
    pushSelectedPlayersToLua(arrayList, paramInt1, paramInt2, str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\CoronaProvider\gameNetwork\google\SelectPlayersResultHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */