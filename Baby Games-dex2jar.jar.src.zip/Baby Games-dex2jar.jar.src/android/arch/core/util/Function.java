package android.arch.core.util;

public interface Function<I, O> {
  O apply(I paramI);
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\android\arch\cor\\util\Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */