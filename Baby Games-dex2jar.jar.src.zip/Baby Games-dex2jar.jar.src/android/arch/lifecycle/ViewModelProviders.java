package android.arch.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.support.annotation.MainThread;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

public class ViewModelProviders {
  private static Activity checkActivity(Fragment paramFragment) {
    FragmentActivity fragmentActivity = paramFragment.getActivity();
    if (fragmentActivity == null)
      throw new IllegalStateException("Can't create ViewModelProvider for detached fragment"); 
    return (Activity)fragmentActivity;
  }
  
  private static Application checkApplication(Activity paramActivity) {
    Application application = paramActivity.getApplication();
    if (application == null)
      throw new IllegalStateException("Your activity/fragment is not yet attached to Application. You can't request ViewModel before onCreate call."); 
    return application;
  }
  
  @MainThread
  @NonNull
  public static ViewModelProvider of(@NonNull Fragment paramFragment) {
    return of(paramFragment, (ViewModelProvider.Factory)null);
  }
  
  @MainThread
  @NonNull
  public static ViewModelProvider of(@NonNull Fragment paramFragment, @Nullable ViewModelProvider.Factory paramFactory) {
    Application application = checkApplication(checkActivity(paramFragment));
    ViewModelProvider.Factory factory = paramFactory;
    if (paramFactory == null)
      factory = ViewModelProvider.AndroidViewModelFactory.getInstance(application); 
    return new ViewModelProvider(ViewModelStores.of(paramFragment), factory);
  }
  
  @MainThread
  @NonNull
  public static ViewModelProvider of(@NonNull FragmentActivity paramFragmentActivity) {
    return of(paramFragmentActivity, (ViewModelProvider.Factory)null);
  }
  
  @MainThread
  @NonNull
  public static ViewModelProvider of(@NonNull FragmentActivity paramFragmentActivity, @Nullable ViewModelProvider.Factory paramFactory) {
    Application application = checkApplication((Activity)paramFragmentActivity);
    ViewModelProvider.Factory factory = paramFactory;
    if (paramFactory == null)
      factory = ViewModelProvider.AndroidViewModelFactory.getInstance(application); 
    return new ViewModelProvider(ViewModelStores.of(paramFragmentActivity), factory);
  }
  
  @Deprecated
  public static class DefaultFactory extends ViewModelProvider.AndroidViewModelFactory {
    @Deprecated
    public DefaultFactory(@NonNull Application param1Application) {
      super(param1Application);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\android\arch\lifecycle\ViewModelProviders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */