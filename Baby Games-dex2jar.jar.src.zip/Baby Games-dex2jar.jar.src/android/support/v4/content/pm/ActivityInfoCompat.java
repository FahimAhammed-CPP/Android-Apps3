package android.support.v4.content.pm;

@Deprecated
public final class ActivityInfoCompat {
  @Deprecated
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\android\support\v4\content\pm\ActivityInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */