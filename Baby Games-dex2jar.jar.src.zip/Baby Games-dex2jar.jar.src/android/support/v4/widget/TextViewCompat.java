package android.support.v4.widget;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.annotation.StyleRes;
import android.support.v4.os.BuildCompat;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class TextViewCompat {
  public static final int AUTO_SIZE_TEXT_TYPE_NONE = 0;
  
  public static final int AUTO_SIZE_TEXT_TYPE_UNIFORM = 1;
  
  static final TextViewCompatBaseImpl IMPL = new TextViewCompatBaseImpl();
  
  public static int getAutoSizeMaxTextSize(@NonNull TextView paramTextView) {
    return IMPL.getAutoSizeMaxTextSize(paramTextView);
  }
  
  public static int getAutoSizeMinTextSize(@NonNull TextView paramTextView) {
    return IMPL.getAutoSizeMinTextSize(paramTextView);
  }
  
  public static int getAutoSizeStepGranularity(@NonNull TextView paramTextView) {
    return IMPL.getAutoSizeStepGranularity(paramTextView);
  }
  
  @NonNull
  public static int[] getAutoSizeTextAvailableSizes(@NonNull TextView paramTextView) {
    return IMPL.getAutoSizeTextAvailableSizes(paramTextView);
  }
  
  public static int getAutoSizeTextType(@NonNull TextView paramTextView) {
    return IMPL.getAutoSizeTextType(paramTextView);
  }
  
  @NonNull
  public static Drawable[] getCompoundDrawablesRelative(@NonNull TextView paramTextView) {
    return IMPL.getCompoundDrawablesRelative(paramTextView);
  }
  
  public static int getMaxLines(@NonNull TextView paramTextView) {
    return IMPL.getMaxLines(paramTextView);
  }
  
  public static int getMinLines(@NonNull TextView paramTextView) {
    return IMPL.getMinLines(paramTextView);
  }
  
  public static void setAutoSizeTextTypeUniformWithConfiguration(@NonNull TextView paramTextView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    IMPL.setAutoSizeTextTypeUniformWithConfiguration(paramTextView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull TextView paramTextView, @NonNull int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    IMPL.setAutoSizeTextTypeUniformWithPresetSizes(paramTextView, paramArrayOfint, paramInt);
  }
  
  public static void setAutoSizeTextTypeWithDefaults(@NonNull TextView paramTextView, int paramInt) {
    IMPL.setAutoSizeTextTypeWithDefaults(paramTextView, paramInt);
  }
  
  public static void setCompoundDrawablesRelative(@NonNull TextView paramTextView, @Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4) {
    IMPL.setCompoundDrawablesRelative(paramTextView, paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
  }
  
  public static void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView paramTextView, @DrawableRes int paramInt1, @DrawableRes int paramInt2, @DrawableRes int paramInt3, @DrawableRes int paramInt4) {
    IMPL.setCompoundDrawablesRelativeWithIntrinsicBounds(paramTextView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView paramTextView, @Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4) {
    IMPL.setCompoundDrawablesRelativeWithIntrinsicBounds(paramTextView, paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
  }
  
  public static void setCustomSelectionActionModeCallback(@NonNull TextView paramTextView, @NonNull ActionMode.Callback paramCallback) {
    IMPL.setCustomSelectionActionModeCallback(paramTextView, paramCallback);
  }
  
  public static void setTextAppearance(@NonNull TextView paramTextView, @StyleRes int paramInt) {
    IMPL.setTextAppearance(paramTextView, paramInt);
  }
  
  static {
    if (BuildCompat.isAtLeastOMR1()) {
      IMPL = new TextViewCompatApi27Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26) {
      IMPL = new TextViewCompatApi26Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      IMPL = new TextViewCompatApi23Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 18) {
      IMPL = new TextViewCompatApi18Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 17) {
      IMPL = new TextViewCompatApi17Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      IMPL = new TextViewCompatApi16Impl();
      return;
    } 
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface AutoSizeTextType {}
  
  @RequiresApi(16)
  static class TextViewCompatApi16Impl extends TextViewCompatBaseImpl {
    public int getMaxLines(TextView param1TextView) {
      return param1TextView.getMaxLines();
    }
    
    public int getMinLines(TextView param1TextView) {
      return param1TextView.getMinLines();
    }
  }
  
  @RequiresApi(17)
  static class TextViewCompatApi17Impl extends TextViewCompatApi16Impl {
    public Drawable[] getCompoundDrawablesRelative(@NonNull TextView param1TextView) {
      boolean bool = true;
      if (param1TextView.getLayoutDirection() != 1)
        bool = false; 
      Drawable[] arrayOfDrawable = param1TextView.getCompoundDrawables();
      if (bool) {
        Drawable drawable1 = arrayOfDrawable[2];
        Drawable drawable2 = arrayOfDrawable[0];
        arrayOfDrawable[0] = drawable1;
        arrayOfDrawable[2] = drawable2;
      } 
      return arrayOfDrawable;
    }
    
    public void setCompoundDrawablesRelative(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      Drawable drawable;
      boolean bool = true;
      if (param1TextView.getLayoutDirection() != 1)
        bool = false; 
      if (bool) {
        drawable = param1Drawable3;
      } else {
        drawable = param1Drawable1;
      } 
      if (!bool)
        param1Drawable1 = param1Drawable3; 
      param1TextView.setCompoundDrawables(drawable, param1Drawable2, param1Drawable1, param1Drawable4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @DrawableRes int param1Int1, @DrawableRes int param1Int2, @DrawableRes int param1Int3, @DrawableRes int param1Int4) {
      int i;
      boolean bool = true;
      if (param1TextView.getLayoutDirection() != 1)
        bool = false; 
      if (bool) {
        i = param1Int3;
      } else {
        i = param1Int1;
      } 
      if (!bool)
        param1Int1 = param1Int3; 
      param1TextView.setCompoundDrawablesWithIntrinsicBounds(i, param1Int2, param1Int1, param1Int4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      Drawable drawable;
      boolean bool = true;
      if (param1TextView.getLayoutDirection() != 1)
        bool = false; 
      if (bool) {
        drawable = param1Drawable3;
      } else {
        drawable = param1Drawable1;
      } 
      if (!bool)
        param1Drawable1 = param1Drawable3; 
      param1TextView.setCompoundDrawablesWithIntrinsicBounds(drawable, param1Drawable2, param1Drawable1, param1Drawable4);
    }
  }
  
  @RequiresApi(18)
  static class TextViewCompatApi18Impl extends TextViewCompatApi17Impl {
    public Drawable[] getCompoundDrawablesRelative(@NonNull TextView param1TextView) {
      return param1TextView.getCompoundDrawablesRelative();
    }
    
    public void setCompoundDrawablesRelative(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesRelative(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @DrawableRes int param1Int1, @DrawableRes int param1Int2, @DrawableRes int param1Int3, @DrawableRes int param1Int4) {
      param1TextView.setCompoundDrawablesRelativeWithIntrinsicBounds(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesRelativeWithIntrinsicBounds(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
  }
  
  @RequiresApi(23)
  static class TextViewCompatApi23Impl extends TextViewCompatApi18Impl {
    public void setTextAppearance(@NonNull TextView param1TextView, @StyleRes int param1Int) {
      param1TextView.setTextAppearance(param1Int);
    }
  }
  
  @RequiresApi(26)
  static class TextViewCompatApi26Impl extends TextViewCompatApi23Impl {
    public void setCustomSelectionActionModeCallback(final TextView textView, final ActionMode.Callback callback) {
      if (Build.VERSION.SDK_INT != 26 && Build.VERSION.SDK_INT != 27) {
        super.setCustomSelectionActionModeCallback(textView, callback);
        return;
      } 
      textView.setCustomSelectionActionModeCallback(new ActionMode.Callback() {
            private static final int MENU_ITEM_ORDER_PROCESS_TEXT_INTENT_ACTIONS_START = 100;
            
            private boolean mCanUseMenuBuilderReferences;
            
            private boolean mInitializedMenuBuilderReferences = false;
            
            private Class mMenuBuilderClass;
            
            private Method mMenuBuilderRemoveItemAtMethod;
            
            private Intent createProcessTextIntent() {
              return (new Intent()).setAction("android.intent.action.PROCESS_TEXT").setType("text/plain");
            }
            
            private Intent createProcessTextIntentForResolveInfo(ResolveInfo param2ResolveInfo, TextView param2TextView) {
              Intent intent = createProcessTextIntent();
              if (!isEditable(param2TextView)) {
                boolean bool1 = true;
                return intent.putExtra("android.intent.extra.PROCESS_TEXT_READONLY", bool1).setClassName(param2ResolveInfo.activityInfo.packageName, param2ResolveInfo.activityInfo.name);
              } 
              boolean bool = false;
              return intent.putExtra("android.intent.extra.PROCESS_TEXT_READONLY", bool).setClassName(param2ResolveInfo.activityInfo.packageName, param2ResolveInfo.activityInfo.name);
            }
            
            private List<ResolveInfo> getSupportedActivities(Context param2Context, PackageManager param2PackageManager) {
              ArrayList<ResolveInfo> arrayList = new ArrayList();
              if (param2Context instanceof android.app.Activity) {
                Iterator<ResolveInfo> iterator = param2PackageManager.queryIntentActivities(createProcessTextIntent(), 0).iterator();
                while (true) {
                  if (iterator.hasNext()) {
                    ResolveInfo resolveInfo = iterator.next();
                    if (isSupportedActivity(resolveInfo, param2Context))
                      arrayList.add(resolveInfo); 
                    continue;
                  } 
                  return arrayList;
                } 
              } 
              return arrayList;
            }
            
            private boolean isEditable(TextView param2TextView) {
              return (param2TextView instanceof android.text.Editable && param2TextView.onCheckIsTextEditor() && param2TextView.isEnabled());
            }
            
            private boolean isSupportedActivity(ResolveInfo param2ResolveInfo, Context param2Context) {
              boolean bool2 = false;
              if (param2Context.getPackageName().equals(param2ResolveInfo.activityInfo.packageName))
                return true; 
              boolean bool1 = bool2;
              if (param2ResolveInfo.activityInfo.exported) {
                if (param2ResolveInfo.activityInfo.permission != null) {
                  bool1 = bool2;
                  return (param2Context.checkSelfPermission(param2ResolveInfo.activityInfo.permission) == 0) ? true : bool1;
                } 
                return true;
              } 
              return bool1;
            }
            
            private void recomputeProcessTextMenuItems(Menu param2Menu) {
              // Byte code:
              //   0: aload_0
              //   1: getfield val$textView : Landroid/widget/TextView;
              //   4: invokevirtual getContext : ()Landroid/content/Context;
              //   7: astore #5
              //   9: aload #5
              //   11: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
              //   14: astore #4
              //   16: aload_0
              //   17: getfield mInitializedMenuBuilderReferences : Z
              //   20: ifne -> 65
              //   23: aload_0
              //   24: iconst_1
              //   25: putfield mInitializedMenuBuilderReferences : Z
              //   28: aload_0
              //   29: ldc 'com.android.internal.view.menu.MenuBuilder'
              //   31: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
              //   34: putfield mMenuBuilderClass : Ljava/lang/Class;
              //   37: aload_0
              //   38: aload_0
              //   39: getfield mMenuBuilderClass : Ljava/lang/Class;
              //   42: ldc 'removeItemAt'
              //   44: iconst_1
              //   45: anewarray java/lang/Class
              //   48: dup
              //   49: iconst_0
              //   50: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
              //   53: aastore
              //   54: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
              //   57: putfield mMenuBuilderRemoveItemAtMethod : Ljava/lang/reflect/Method;
              //   60: aload_0
              //   61: iconst_1
              //   62: putfield mCanUseMenuBuilderReferences : Z
              //   65: aload_0
              //   66: getfield mCanUseMenuBuilderReferences : Z
              //   69: ifeq -> 181
              //   72: aload_0
              //   73: getfield mMenuBuilderClass : Ljava/lang/Class;
              //   76: aload_1
              //   77: invokevirtual isInstance : (Ljava/lang/Object;)Z
              //   80: ifeq -> 181
              //   83: aload_0
              //   84: getfield mMenuBuilderRemoveItemAtMethod : Ljava/lang/reflect/Method;
              //   87: astore_3
              //   88: aload_1
              //   89: invokeinterface size : ()I
              //   94: iconst_1
              //   95: isub
              //   96: istore_2
              //   97: iload_2
              //   98: iflt -> 206
              //   101: aload_1
              //   102: iload_2
              //   103: invokeinterface getItem : (I)Landroid/view/MenuItem;
              //   108: astore #6
              //   110: aload #6
              //   112: invokeinterface getIntent : ()Landroid/content/Intent;
              //   117: ifnull -> 155
              //   120: ldc 'android.intent.action.PROCESS_TEXT'
              //   122: aload #6
              //   124: invokeinterface getIntent : ()Landroid/content/Intent;
              //   129: invokevirtual getAction : ()Ljava/lang/String;
              //   132: invokevirtual equals : (Ljava/lang/Object;)Z
              //   135: ifeq -> 155
              //   138: aload_3
              //   139: aload_1
              //   140: iconst_1
              //   141: anewarray java/lang/Object
              //   144: dup
              //   145: iconst_0
              //   146: iload_2
              //   147: invokestatic valueOf : (I)Ljava/lang/Integer;
              //   150: aastore
              //   151: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
              //   154: pop
              //   155: iload_2
              //   156: iconst_1
              //   157: isub
              //   158: istore_2
              //   159: goto -> 97
              //   162: astore_3
              //   163: aload_0
              //   164: aconst_null
              //   165: putfield mMenuBuilderClass : Ljava/lang/Class;
              //   168: aload_0
              //   169: aconst_null
              //   170: putfield mMenuBuilderRemoveItemAtMethod : Ljava/lang/reflect/Method;
              //   173: aload_0
              //   174: iconst_0
              //   175: putfield mCanUseMenuBuilderReferences : Z
              //   178: goto -> 65
              //   181: aload_1
              //   182: invokevirtual getClass : ()Ljava/lang/Class;
              //   185: ldc 'removeItemAt'
              //   187: iconst_1
              //   188: anewarray java/lang/Class
              //   191: dup
              //   192: iconst_0
              //   193: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
              //   196: aastore
              //   197: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
              //   200: astore_3
              //   201: goto -> 88
              //   204: astore_1
              //   205: return
              //   206: aload_0
              //   207: aload #5
              //   209: aload #4
              //   211: invokespecial getSupportedActivities : (Landroid/content/Context;Landroid/content/pm/PackageManager;)Ljava/util/List;
              //   214: astore_3
              //   215: iconst_0
              //   216: istore_2
              //   217: iload_2
              //   218: aload_3
              //   219: invokeinterface size : ()I
              //   224: if_icmpge -> 205
              //   227: aload_3
              //   228: iload_2
              //   229: invokeinterface get : (I)Ljava/lang/Object;
              //   234: checkcast android/content/pm/ResolveInfo
              //   237: astore #5
              //   239: aload_1
              //   240: iconst_0
              //   241: iconst_0
              //   242: iload_2
              //   243: bipush #100
              //   245: iadd
              //   246: aload #5
              //   248: aload #4
              //   250: invokevirtual loadLabel : (Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
              //   253: invokeinterface add : (IIILjava/lang/CharSequence;)Landroid/view/MenuItem;
              //   258: aload_0
              //   259: aload #5
              //   261: aload_0
              //   262: getfield val$textView : Landroid/widget/TextView;
              //   265: invokespecial createProcessTextIntentForResolveInfo : (Landroid/content/pm/ResolveInfo;Landroid/widget/TextView;)Landroid/content/Intent;
              //   268: invokeinterface setIntent : (Landroid/content/Intent;)Landroid/view/MenuItem;
              //   273: iconst_1
              //   274: invokeinterface setShowAsAction : (I)V
              //   279: iload_2
              //   280: iconst_1
              //   281: iadd
              //   282: istore_2
              //   283: goto -> 217
              //   286: astore_1
              //   287: return
              //   288: astore_1
              //   289: return
              //   290: astore_3
              //   291: goto -> 163
              // Exception table:
              //   from	to	target	type
              //   28	65	290	java/lang/ClassNotFoundException
              //   28	65	162	java/lang/NoSuchMethodException
              //   65	88	204	java/lang/NoSuchMethodException
              //   65	88	286	java/lang/IllegalAccessException
              //   65	88	288	java/lang/reflect/InvocationTargetException
              //   88	97	204	java/lang/NoSuchMethodException
              //   88	97	286	java/lang/IllegalAccessException
              //   88	97	288	java/lang/reflect/InvocationTargetException
              //   101	155	204	java/lang/NoSuchMethodException
              //   101	155	286	java/lang/IllegalAccessException
              //   101	155	288	java/lang/reflect/InvocationTargetException
              //   181	201	204	java/lang/NoSuchMethodException
              //   181	201	286	java/lang/IllegalAccessException
              //   181	201	288	java/lang/reflect/InvocationTargetException
            }
            
            public boolean onActionItemClicked(ActionMode param2ActionMode, MenuItem param2MenuItem) {
              return callback.onActionItemClicked(param2ActionMode, param2MenuItem);
            }
            
            public boolean onCreateActionMode(ActionMode param2ActionMode, Menu param2Menu) {
              return callback.onCreateActionMode(param2ActionMode, param2Menu);
            }
            
            public void onDestroyActionMode(ActionMode param2ActionMode) {
              callback.onDestroyActionMode(param2ActionMode);
            }
            
            public boolean onPrepareActionMode(ActionMode param2ActionMode, Menu param2Menu) {
              recomputeProcessTextMenuItems(param2Menu);
              return callback.onPrepareActionMode(param2ActionMode, param2Menu);
            }
          });
    }
  }
  
  class null implements ActionMode.Callback {
    private static final int MENU_ITEM_ORDER_PROCESS_TEXT_INTENT_ACTIONS_START = 100;
    
    private boolean mCanUseMenuBuilderReferences;
    
    private boolean mInitializedMenuBuilderReferences = false;
    
    private Class mMenuBuilderClass;
    
    private Method mMenuBuilderRemoveItemAtMethod;
    
    private Intent createProcessTextIntent() {
      return (new Intent()).setAction("android.intent.action.PROCESS_TEXT").setType("text/plain");
    }
    
    private Intent createProcessTextIntentForResolveInfo(ResolveInfo param1ResolveInfo, TextView param1TextView) {
      Intent intent = createProcessTextIntent();
      if (!isEditable(param1TextView)) {
        boolean bool1 = true;
        return intent.putExtra("android.intent.extra.PROCESS_TEXT_READONLY", bool1).setClassName(param1ResolveInfo.activityInfo.packageName, param1ResolveInfo.activityInfo.name);
      } 
      boolean bool = false;
      return intent.putExtra("android.intent.extra.PROCESS_TEXT_READONLY", bool).setClassName(param1ResolveInfo.activityInfo.packageName, param1ResolveInfo.activityInfo.name);
    }
    
    private List<ResolveInfo> getSupportedActivities(Context param1Context, PackageManager param1PackageManager) {
      ArrayList<ResolveInfo> arrayList = new ArrayList();
      if (param1Context instanceof android.app.Activity) {
        Iterator<ResolveInfo> iterator = param1PackageManager.queryIntentActivities(createProcessTextIntent(), 0).iterator();
        while (true) {
          if (iterator.hasNext()) {
            ResolveInfo resolveInfo = iterator.next();
            if (isSupportedActivity(resolveInfo, param1Context))
              arrayList.add(resolveInfo); 
            continue;
          } 
          return arrayList;
        } 
      } 
      return arrayList;
    }
    
    private boolean isEditable(TextView param1TextView) {
      return (param1TextView instanceof android.text.Editable && param1TextView.onCheckIsTextEditor() && param1TextView.isEnabled());
    }
    
    private boolean isSupportedActivity(ResolveInfo param1ResolveInfo, Context param1Context) {
      boolean bool2 = false;
      if (param1Context.getPackageName().equals(param1ResolveInfo.activityInfo.packageName))
        return true; 
      boolean bool1 = bool2;
      if (param1ResolveInfo.activityInfo.exported) {
        if (param1ResolveInfo.activityInfo.permission != null) {
          bool1 = bool2;
          return (param1Context.checkSelfPermission(param1ResolveInfo.activityInfo.permission) == 0) ? true : bool1;
        } 
        return true;
      } 
      return bool1;
    }
    
    private void recomputeProcessTextMenuItems(Menu param1Menu) {
      // Byte code:
      //   0: aload_0
      //   1: getfield val$textView : Landroid/widget/TextView;
      //   4: invokevirtual getContext : ()Landroid/content/Context;
      //   7: astore #5
      //   9: aload #5
      //   11: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
      //   14: astore #4
      //   16: aload_0
      //   17: getfield mInitializedMenuBuilderReferences : Z
      //   20: ifne -> 65
      //   23: aload_0
      //   24: iconst_1
      //   25: putfield mInitializedMenuBuilderReferences : Z
      //   28: aload_0
      //   29: ldc 'com.android.internal.view.menu.MenuBuilder'
      //   31: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
      //   34: putfield mMenuBuilderClass : Ljava/lang/Class;
      //   37: aload_0
      //   38: aload_0
      //   39: getfield mMenuBuilderClass : Ljava/lang/Class;
      //   42: ldc 'removeItemAt'
      //   44: iconst_1
      //   45: anewarray java/lang/Class
      //   48: dup
      //   49: iconst_0
      //   50: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   53: aastore
      //   54: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   57: putfield mMenuBuilderRemoveItemAtMethod : Ljava/lang/reflect/Method;
      //   60: aload_0
      //   61: iconst_1
      //   62: putfield mCanUseMenuBuilderReferences : Z
      //   65: aload_0
      //   66: getfield mCanUseMenuBuilderReferences : Z
      //   69: ifeq -> 181
      //   72: aload_0
      //   73: getfield mMenuBuilderClass : Ljava/lang/Class;
      //   76: aload_1
      //   77: invokevirtual isInstance : (Ljava/lang/Object;)Z
      //   80: ifeq -> 181
      //   83: aload_0
      //   84: getfield mMenuBuilderRemoveItemAtMethod : Ljava/lang/reflect/Method;
      //   87: astore_3
      //   88: aload_1
      //   89: invokeinterface size : ()I
      //   94: iconst_1
      //   95: isub
      //   96: istore_2
      //   97: iload_2
      //   98: iflt -> 206
      //   101: aload_1
      //   102: iload_2
      //   103: invokeinterface getItem : (I)Landroid/view/MenuItem;
      //   108: astore #6
      //   110: aload #6
      //   112: invokeinterface getIntent : ()Landroid/content/Intent;
      //   117: ifnull -> 155
      //   120: ldc 'android.intent.action.PROCESS_TEXT'
      //   122: aload #6
      //   124: invokeinterface getIntent : ()Landroid/content/Intent;
      //   129: invokevirtual getAction : ()Ljava/lang/String;
      //   132: invokevirtual equals : (Ljava/lang/Object;)Z
      //   135: ifeq -> 155
      //   138: aload_3
      //   139: aload_1
      //   140: iconst_1
      //   141: anewarray java/lang/Object
      //   144: dup
      //   145: iconst_0
      //   146: iload_2
      //   147: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   150: aastore
      //   151: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   154: pop
      //   155: iload_2
      //   156: iconst_1
      //   157: isub
      //   158: istore_2
      //   159: goto -> 97
      //   162: astore_3
      //   163: aload_0
      //   164: aconst_null
      //   165: putfield mMenuBuilderClass : Ljava/lang/Class;
      //   168: aload_0
      //   169: aconst_null
      //   170: putfield mMenuBuilderRemoveItemAtMethod : Ljava/lang/reflect/Method;
      //   173: aload_0
      //   174: iconst_0
      //   175: putfield mCanUseMenuBuilderReferences : Z
      //   178: goto -> 65
      //   181: aload_1
      //   182: invokevirtual getClass : ()Ljava/lang/Class;
      //   185: ldc 'removeItemAt'
      //   187: iconst_1
      //   188: anewarray java/lang/Class
      //   191: dup
      //   192: iconst_0
      //   193: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   196: aastore
      //   197: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   200: astore_3
      //   201: goto -> 88
      //   204: astore_1
      //   205: return
      //   206: aload_0
      //   207: aload #5
      //   209: aload #4
      //   211: invokespecial getSupportedActivities : (Landroid/content/Context;Landroid/content/pm/PackageManager;)Ljava/util/List;
      //   214: astore_3
      //   215: iconst_0
      //   216: istore_2
      //   217: iload_2
      //   218: aload_3
      //   219: invokeinterface size : ()I
      //   224: if_icmpge -> 205
      //   227: aload_3
      //   228: iload_2
      //   229: invokeinterface get : (I)Ljava/lang/Object;
      //   234: checkcast android/content/pm/ResolveInfo
      //   237: astore #5
      //   239: aload_1
      //   240: iconst_0
      //   241: iconst_0
      //   242: iload_2
      //   243: bipush #100
      //   245: iadd
      //   246: aload #5
      //   248: aload #4
      //   250: invokevirtual loadLabel : (Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
      //   253: invokeinterface add : (IIILjava/lang/CharSequence;)Landroid/view/MenuItem;
      //   258: aload_0
      //   259: aload #5
      //   261: aload_0
      //   262: getfield val$textView : Landroid/widget/TextView;
      //   265: invokespecial createProcessTextIntentForResolveInfo : (Landroid/content/pm/ResolveInfo;Landroid/widget/TextView;)Landroid/content/Intent;
      //   268: invokeinterface setIntent : (Landroid/content/Intent;)Landroid/view/MenuItem;
      //   273: iconst_1
      //   274: invokeinterface setShowAsAction : (I)V
      //   279: iload_2
      //   280: iconst_1
      //   281: iadd
      //   282: istore_2
      //   283: goto -> 217
      //   286: astore_1
      //   287: return
      //   288: astore_1
      //   289: return
      //   290: astore_3
      //   291: goto -> 163
      // Exception table:
      //   from	to	target	type
      //   28	65	290	java/lang/ClassNotFoundException
      //   28	65	162	java/lang/NoSuchMethodException
      //   65	88	204	java/lang/NoSuchMethodException
      //   65	88	286	java/lang/IllegalAccessException
      //   65	88	288	java/lang/reflect/InvocationTargetException
      //   88	97	204	java/lang/NoSuchMethodException
      //   88	97	286	java/lang/IllegalAccessException
      //   88	97	288	java/lang/reflect/InvocationTargetException
      //   101	155	204	java/lang/NoSuchMethodException
      //   101	155	286	java/lang/IllegalAccessException
      //   101	155	288	java/lang/reflect/InvocationTargetException
      //   181	201	204	java/lang/NoSuchMethodException
      //   181	201	286	java/lang/IllegalAccessException
      //   181	201	288	java/lang/reflect/InvocationTargetException
    }
    
    public boolean onActionItemClicked(ActionMode param1ActionMode, MenuItem param1MenuItem) {
      return callback.onActionItemClicked(param1ActionMode, param1MenuItem);
    }
    
    public boolean onCreateActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      return callback.onCreateActionMode(param1ActionMode, param1Menu);
    }
    
    public void onDestroyActionMode(ActionMode param1ActionMode) {
      callback.onDestroyActionMode(param1ActionMode);
    }
    
    public boolean onPrepareActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      recomputeProcessTextMenuItems(param1Menu);
      return callback.onPrepareActionMode(param1ActionMode, param1Menu);
    }
  }
  
  @RequiresApi(27)
  static class TextViewCompatApi27Impl extends TextViewCompatApi26Impl {
    public int getAutoSizeMaxTextSize(TextView param1TextView) {
      return param1TextView.getAutoSizeMaxTextSize();
    }
    
    public int getAutoSizeMinTextSize(TextView param1TextView) {
      return param1TextView.getAutoSizeMinTextSize();
    }
    
    public int getAutoSizeStepGranularity(TextView param1TextView) {
      return param1TextView.getAutoSizeStepGranularity();
    }
    
    public int[] getAutoSizeTextAvailableSizes(TextView param1TextView) {
      return param1TextView.getAutoSizeTextAvailableSizes();
    }
    
    public int getAutoSizeTextType(TextView param1TextView) {
      return param1TextView.getAutoSizeTextType();
    }
    
    public void setAutoSizeTextTypeUniformWithConfiguration(TextView param1TextView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) throws IllegalArgumentException {
      param1TextView.setAutoSizeTextTypeUniformWithConfiguration(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void setAutoSizeTextTypeUniformWithPresetSizes(TextView param1TextView, @NonNull int[] param1ArrayOfint, int param1Int) throws IllegalArgumentException {
      param1TextView.setAutoSizeTextTypeUniformWithPresetSizes(param1ArrayOfint, param1Int);
    }
    
    public void setAutoSizeTextTypeWithDefaults(TextView param1TextView, int param1Int) {
      param1TextView.setAutoSizeTextTypeWithDefaults(param1Int);
    }
  }
  
  static class TextViewCompatBaseImpl {
    private static final int LINES = 1;
    
    private static final String LOG_TAG = "TextViewCompatBase";
    
    private static Field sMaxModeField;
    
    private static boolean sMaxModeFieldFetched;
    
    private static Field sMaximumField;
    
    private static boolean sMaximumFieldFetched;
    
    private static Field sMinModeField;
    
    private static boolean sMinModeFieldFetched;
    
    private static Field sMinimumField;
    
    private static boolean sMinimumFieldFetched;
    
    private static Field retrieveField(String param1String) {
      Field field = null;
      try {
        Field field1 = TextView.class.getDeclaredField(param1String);
        field = field1;
        field1.setAccessible(true);
        return field1;
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("TextViewCompatBase", "Could not retrieve " + param1String + " field.");
        return field;
      } 
    }
    
    private static int retrieveIntFromField(Field param1Field, TextView param1TextView) {
      try {
        return param1Field.getInt(param1TextView);
      } catch (IllegalAccessException illegalAccessException) {
        Log.d("TextViewCompatBase", "Could not retrieve value of " + param1Field.getName() + " field.");
        return -1;
      } 
    }
    
    public int getAutoSizeMaxTextSize(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeMaxTextSize() : -1;
    }
    
    public int getAutoSizeMinTextSize(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeMinTextSize() : -1;
    }
    
    public int getAutoSizeStepGranularity(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeStepGranularity() : -1;
    }
    
    public int[] getAutoSizeTextAvailableSizes(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeTextAvailableSizes() : new int[0];
    }
    
    public int getAutoSizeTextType(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeTextType() : 0;
    }
    
    public Drawable[] getCompoundDrawablesRelative(@NonNull TextView param1TextView) {
      return param1TextView.getCompoundDrawables();
    }
    
    public int getMaxLines(TextView param1TextView) {
      if (!sMaxModeFieldFetched) {
        sMaxModeField = retrieveField("mMaxMode");
        sMaxModeFieldFetched = true;
      } 
      if (sMaxModeField != null && retrieveIntFromField(sMaxModeField, param1TextView) == 1) {
        if (!sMaximumFieldFetched) {
          sMaximumField = retrieveField("mMaximum");
          sMaximumFieldFetched = true;
        } 
        if (sMaximumField != null)
          return retrieveIntFromField(sMaximumField, param1TextView); 
      } 
      return -1;
    }
    
    public int getMinLines(TextView param1TextView) {
      if (!sMinModeFieldFetched) {
        sMinModeField = retrieveField("mMinMode");
        sMinModeFieldFetched = true;
      } 
      if (sMinModeField != null && retrieveIntFromField(sMinModeField, param1TextView) == 1) {
        if (!sMinimumFieldFetched) {
          sMinimumField = retrieveField("mMinimum");
          sMinimumFieldFetched = true;
        } 
        if (sMinimumField != null)
          return retrieveIntFromField(sMinimumField, param1TextView); 
      } 
      return -1;
    }
    
    public void setAutoSizeTextTypeUniformWithConfiguration(TextView param1TextView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) throws IllegalArgumentException {
      if (param1TextView instanceof AutoSizeableTextView)
        ((AutoSizeableTextView)param1TextView).setAutoSizeTextTypeUniformWithConfiguration(param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public void setAutoSizeTextTypeUniformWithPresetSizes(TextView param1TextView, @NonNull int[] param1ArrayOfint, int param1Int) throws IllegalArgumentException {
      if (param1TextView instanceof AutoSizeableTextView)
        ((AutoSizeableTextView)param1TextView).setAutoSizeTextTypeUniformWithPresetSizes(param1ArrayOfint, param1Int); 
    }
    
    public void setAutoSizeTextTypeWithDefaults(TextView param1TextView, int param1Int) {
      if (param1TextView instanceof AutoSizeableTextView)
        ((AutoSizeableTextView)param1TextView).setAutoSizeTextTypeWithDefaults(param1Int); 
    }
    
    public void setCompoundDrawablesRelative(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      param1TextView.setCompoundDrawables(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @DrawableRes int param1Int1, @DrawableRes int param1Int2, @DrawableRes int param1Int3, @DrawableRes int param1Int4) {
      param1TextView.setCompoundDrawablesWithIntrinsicBounds(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesWithIntrinsicBounds(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    public void setCustomSelectionActionModeCallback(TextView param1TextView, ActionMode.Callback param1Callback) {
      param1TextView.setCustomSelectionActionModeCallback(param1Callback);
    }
    
    public void setTextAppearance(TextView param1TextView, @StyleRes int param1Int) {
      param1TextView.setTextAppearance(param1TextView.getContext(), param1Int);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\android\support\v4\widget\TextViewCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */