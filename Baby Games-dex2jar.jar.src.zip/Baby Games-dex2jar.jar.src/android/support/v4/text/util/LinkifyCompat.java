package android.support.v4.text.util;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.v4.util.PatternsCompat;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.webkit.WebView;
import android.widget.TextView;
import java.io.UnsupportedEncodingException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LinkifyCompat {
  private static final Comparator<LinkSpec> COMPARATOR;
  
  private static final String[] EMPTY_STRING = new String[0];
  
  static {
    COMPARATOR = new Comparator<LinkSpec>() {
        public int compare(LinkifyCompat.LinkSpec param1LinkSpec1, LinkifyCompat.LinkSpec param1LinkSpec2) {
          if (param1LinkSpec1.start >= param1LinkSpec2.start) {
            if (param1LinkSpec1.start > param1LinkSpec2.start)
              return 1; 
            if (param1LinkSpec1.end < param1LinkSpec2.end)
              return 1; 
            if (param1LinkSpec1.end <= param1LinkSpec2.end)
              return 0; 
          } 
          return -1;
        }
      };
  }
  
  private static void addLinkMovementMethod(@NonNull TextView paramTextView) {
    MovementMethod movementMethod = paramTextView.getMovementMethod();
    if ((movementMethod == null || !(movementMethod instanceof LinkMovementMethod)) && paramTextView.getLinksClickable())
      paramTextView.setMovementMethod(LinkMovementMethod.getInstance()); 
  }
  
  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString) {
    if (Build.VERSION.SDK_INT >= 26) {
      Linkify.addLinks(paramTextView, paramPattern, paramString);
      return;
    } 
    addLinks(paramTextView, paramPattern, paramString, (String[])null, (Linkify.MatchFilter)null, (Linkify.TransformFilter)null);
  }
  
  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter) {
    if (Build.VERSION.SDK_INT >= 26) {
      Linkify.addLinks(paramTextView, paramPattern, paramString, paramMatchFilter, paramTransformFilter);
      return;
    } 
    addLinks(paramTextView, paramPattern, paramString, (String[])null, paramMatchFilter, paramTransformFilter);
  }
  
  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable String[] paramArrayOfString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter) {
    if (Build.VERSION.SDK_INT >= 26) {
      Linkify.addLinks(paramTextView, paramPattern, paramString, paramArrayOfString, paramMatchFilter, paramTransformFilter);
      return;
    } 
    SpannableString spannableString = SpannableString.valueOf(paramTextView.getText());
    if (addLinks((Spannable)spannableString, paramPattern, paramString, paramArrayOfString, paramMatchFilter, paramTransformFilter)) {
      paramTextView.setText((CharSequence)spannableString);
      addLinkMovementMethod(paramTextView);
      return;
    } 
  }
  
  public static boolean addLinks(@NonNull Spannable paramSpannable, int paramInt) {
    if (Build.VERSION.SDK_INT >= 27)
      return Linkify.addLinks(paramSpannable, paramInt); 
    if (paramInt == 0)
      return false; 
    URLSpan[] arrayOfURLSpan = (URLSpan[])paramSpannable.getSpans(0, paramSpannable.length(), URLSpan.class);
    for (int i = arrayOfURLSpan.length - 1; i >= 0; i--)
      paramSpannable.removeSpan(arrayOfURLSpan[i]); 
    if ((paramInt & 0x4) != 0)
      Linkify.addLinks(paramSpannable, 4); 
    ArrayList<LinkSpec> arrayList = new ArrayList();
    if ((paramInt & 0x1) != 0) {
      Pattern pattern = PatternsCompat.AUTOLINK_WEB_URL;
      Linkify.MatchFilter matchFilter = Linkify.sUrlMatchFilter;
      gatherLinks(arrayList, paramSpannable, pattern, new String[] { "http://", "https://", "rtsp://" }, matchFilter, null);
    } 
    if ((paramInt & 0x2) != 0)
      gatherLinks(arrayList, paramSpannable, PatternsCompat.AUTOLINK_EMAIL_ADDRESS, new String[] { "mailto:" }, null, null); 
    if ((paramInt & 0x8) != 0)
      gatherMapLinks(arrayList, paramSpannable); 
    pruneOverlaps(arrayList, paramSpannable);
    if (arrayList.size() == 0)
      return false; 
    for (LinkSpec linkSpec : arrayList) {
      if (linkSpec.frameworkAddedSpan == null)
        applyLink(linkSpec.url, linkSpec.start, linkSpec.end, paramSpannable); 
    } 
    return true;
  }
  
  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString) {
    return (Build.VERSION.SDK_INT >= 26) ? Linkify.addLinks(paramSpannable, paramPattern, paramString) : addLinks(paramSpannable, paramPattern, paramString, (String[])null, (Linkify.MatchFilter)null, (Linkify.TransformFilter)null);
  }
  
  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter) {
    return (Build.VERSION.SDK_INT >= 26) ? Linkify.addLinks(paramSpannable, paramPattern, paramString, paramMatchFilter, paramTransformFilter) : addLinks(paramSpannable, paramPattern, paramString, (String[])null, paramMatchFilter, paramTransformFilter);
  }
  
  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable String[] paramArrayOfString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: bipush #26
    //   5: if_icmplt -> 24
    //   8: aload_0
    //   9: aload_1
    //   10: aload_2
    //   11: aload_3
    //   12: aload #4
    //   14: aload #5
    //   16: invokestatic addLinks : (Landroid/text/Spannable;Ljava/util/regex/Pattern;Ljava/lang/String;[Ljava/lang/String;Landroid/text/util/Linkify$MatchFilter;Landroid/text/util/Linkify$TransformFilter;)Z
    //   19: istore #9
    //   21: iload #9
    //   23: ireturn
    //   24: aload_2
    //   25: astore #10
    //   27: aload_2
    //   28: ifnonnull -> 35
    //   31: ldc ''
    //   33: astore #10
    //   35: aload_3
    //   36: ifnull -> 47
    //   39: aload_3
    //   40: astore_2
    //   41: aload_3
    //   42: arraylength
    //   43: iconst_1
    //   44: if_icmpge -> 51
    //   47: getstatic android/support/v4/text/util/LinkifyCompat.EMPTY_STRING : [Ljava/lang/String;
    //   50: astore_2
    //   51: aload_2
    //   52: arraylength
    //   53: iconst_1
    //   54: iadd
    //   55: anewarray java/lang/String
    //   58: astore #11
    //   60: aload #11
    //   62: iconst_0
    //   63: aload #10
    //   65: getstatic java/util/Locale.ROOT : Ljava/util/Locale;
    //   68: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   71: aastore
    //   72: iconst_0
    //   73: istore #6
    //   75: iload #6
    //   77: aload_2
    //   78: arraylength
    //   79: if_icmpge -> 122
    //   82: aload_2
    //   83: iload #6
    //   85: aaload
    //   86: astore_3
    //   87: aload_3
    //   88: ifnonnull -> 111
    //   91: ldc ''
    //   93: astore_3
    //   94: aload #11
    //   96: iload #6
    //   98: iconst_1
    //   99: iadd
    //   100: aload_3
    //   101: aastore
    //   102: iload #6
    //   104: iconst_1
    //   105: iadd
    //   106: istore #6
    //   108: goto -> 75
    //   111: aload_3
    //   112: getstatic java/util/Locale.ROOT : Ljava/util/Locale;
    //   115: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   118: astore_3
    //   119: goto -> 94
    //   122: iconst_0
    //   123: istore #8
    //   125: aload_1
    //   126: aload_0
    //   127: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   130: astore_1
    //   131: iload #8
    //   133: istore #9
    //   135: aload_1
    //   136: invokevirtual find : ()Z
    //   139: ifeq -> 21
    //   142: aload_1
    //   143: invokevirtual start : ()I
    //   146: istore #6
    //   148: aload_1
    //   149: invokevirtual end : ()I
    //   152: istore #7
    //   154: iconst_1
    //   155: istore #9
    //   157: aload #4
    //   159: ifnull -> 176
    //   162: aload #4
    //   164: aload_0
    //   165: iload #6
    //   167: iload #7
    //   169: invokeinterface acceptMatch : (Ljava/lang/CharSequence;II)Z
    //   174: istore #9
    //   176: iload #9
    //   178: ifeq -> 131
    //   181: aload_1
    //   182: iconst_0
    //   183: invokevirtual group : (I)Ljava/lang/String;
    //   186: aload #11
    //   188: aload_1
    //   189: aload #5
    //   191: invokestatic makeUrl : (Ljava/lang/String;[Ljava/lang/String;Ljava/util/regex/Matcher;Landroid/text/util/Linkify$TransformFilter;)Ljava/lang/String;
    //   194: iload #6
    //   196: iload #7
    //   198: aload_0
    //   199: invokestatic applyLink : (Ljava/lang/String;IILandroid/text/Spannable;)V
    //   202: iconst_1
    //   203: istore #8
    //   205: goto -> 131
  }
  
  public static boolean addLinks(@NonNull TextView paramTextView, int paramInt) {
    boolean bool2 = false;
    if (Build.VERSION.SDK_INT >= 26)
      return Linkify.addLinks(paramTextView, paramInt); 
    boolean bool1 = bool2;
    if (paramInt != 0) {
      CharSequence charSequence = paramTextView.getText();
      if (charSequence instanceof Spannable) {
        bool1 = bool2;
        if (addLinks((Spannable)charSequence, paramInt)) {
          addLinkMovementMethod(paramTextView);
          return true;
        } 
        return bool1;
      } 
      SpannableString spannableString = SpannableString.valueOf(charSequence);
      bool1 = bool2;
      if (addLinks((Spannable)spannableString, paramInt)) {
        addLinkMovementMethod(paramTextView);
        paramTextView.setText((CharSequence)spannableString);
        return true;
      } 
    } 
    return bool1;
  }
  
  private static void applyLink(String paramString, int paramInt1, int paramInt2, Spannable paramSpannable) {
    paramSpannable.setSpan(new URLSpan(paramString), paramInt1, paramInt2, 33);
  }
  
  private static void gatherLinks(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable, Pattern paramPattern, String[] paramArrayOfString, Linkify.MatchFilter paramMatchFilter, Linkify.TransformFilter paramTransformFilter) {
    Matcher matcher = paramPattern.matcher((CharSequence)paramSpannable);
    while (matcher.find()) {
      int i = matcher.start();
      int j = matcher.end();
      if (paramMatchFilter == null || paramMatchFilter.acceptMatch((CharSequence)paramSpannable, i, j)) {
        LinkSpec linkSpec = new LinkSpec();
        linkSpec.url = makeUrl(matcher.group(0), paramArrayOfString, matcher, paramTransformFilter);
        linkSpec.start = i;
        linkSpec.end = j;
        paramArrayList.add(linkSpec);
      } 
    } 
  }
  
  private static void gatherMapLinks(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable) {
    String str = paramSpannable.toString();
    int i = 0;
    while (true) {
      try {
        String str1 = WebView.findAddress(str);
        if (str1 != null) {
          int j = str.indexOf(str1);
          if (j < 0)
            return; 
          LinkSpec linkSpec = new LinkSpec();
          int k = j + str1.length();
          linkSpec.start = i + j;
          linkSpec.end = i + k;
          str = str.substring(k);
          i += k;
          try {
            str1 = URLEncoder.encode(str1, "UTF-8");
            linkSpec.url = "geo:0,0?q=" + str1;
            paramArrayList.add(linkSpec);
          } catch (UnsupportedEncodingException unsupportedEncodingException) {}
          continue;
        } 
      } catch (UnsupportedOperationException unsupportedOperationException) {
        return;
      } 
      break;
    } 
  }
  
  private static String makeUrl(@NonNull String paramString, @NonNull String[] paramArrayOfString, Matcher paramMatcher, @Nullable Linkify.TransformFilter paramTransformFilter) {
    String str = paramString;
    if (paramTransformFilter != null)
      str = paramTransformFilter.transformUrl(paramMatcher, paramString); 
    boolean bool = false;
    int i = 0;
    while (true) {
      boolean bool1 = bool;
      paramString = str;
      if (i < paramArrayOfString.length)
        if (str.regionMatches(true, 0, paramArrayOfString[i], 0, paramArrayOfString[i].length())) {
          bool = true;
          bool1 = bool;
          paramString = str;
          if (!str.regionMatches(false, 0, paramArrayOfString[i], 0, paramArrayOfString[i].length())) {
            paramString = paramArrayOfString[i] + str.substring(paramArrayOfString[i].length());
            bool1 = bool;
          } 
        } else {
          i++;
          continue;
        }  
      String str1 = paramString;
      if (!bool1) {
        str1 = paramString;
        if (paramArrayOfString.length > 0)
          str1 = paramArrayOfString[0] + paramString; 
      } 
      return str1;
    } 
  }
  
  private static void pruneOverlaps(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable) {
    URLSpan[] arrayOfURLSpan = (URLSpan[])paramSpannable.getSpans(0, paramSpannable.length(), URLSpan.class);
    int i;
    for (i = 0; i < arrayOfURLSpan.length; i++) {
      LinkSpec linkSpec = new LinkSpec();
      linkSpec.frameworkAddedSpan = arrayOfURLSpan[i];
      linkSpec.start = paramSpannable.getSpanStart(arrayOfURLSpan[i]);
      linkSpec.end = paramSpannable.getSpanEnd(arrayOfURLSpan[i]);
      paramArrayList.add(linkSpec);
    } 
    Collections.sort(paramArrayList, COMPARATOR);
    int k = paramArrayList.size();
    for (int j = 0; j < k - 1; j++) {
      LinkSpec linkSpec1 = paramArrayList.get(j);
      LinkSpec linkSpec2 = paramArrayList.get(j + 1);
      i = -1;
      if (linkSpec1.start <= linkSpec2.start && linkSpec1.end > linkSpec2.start) {
        if (linkSpec2.end <= linkSpec1.end) {
          i = j + 1;
        } else if (linkSpec1.end - linkSpec1.start > linkSpec2.end - linkSpec2.start) {
          i = j + 1;
        } else if (linkSpec1.end - linkSpec1.start < linkSpec2.end - linkSpec2.start) {
          i = j;
        } 
        if (i != -1) {
          URLSpan uRLSpan = ((LinkSpec)paramArrayList.get(i)).frameworkAddedSpan;
          if (uRLSpan != null)
            paramSpannable.removeSpan(uRLSpan); 
          paramArrayList.remove(i);
          k--;
          continue;
        } 
      } 
    } 
  }
  
  private static class LinkSpec {
    int end;
    
    URLSpan frameworkAddedSpan;
    
    int start;
    
    String url;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface LinkifyMask {}
}


/* Location:              C:\soft\dex2jar-2.0\Baby Games-dex2jar.jar!\android\support\v4\tex\\util\LinkifyCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */