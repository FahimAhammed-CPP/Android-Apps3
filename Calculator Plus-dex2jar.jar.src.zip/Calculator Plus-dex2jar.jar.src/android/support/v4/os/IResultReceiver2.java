package android.support.v4.os;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public interface IResultReceiver2 extends IInterface {
  public static final String DESCRIPTOR = "android$support$v4$os$IResultReceiver2".replace('$', '.');
  
  void send(int paramInt, Bundle paramBundle) throws RemoteException;
  
  public static class Default implements IResultReceiver2 {
    public IBinder asBinder() {
      return null;
    }
    
    public void send(int param1Int, Bundle param1Bundle) throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements IResultReceiver2 {
    static final int TRANSACTION_send = 1;
    
    public Stub() {
      attachInterface(this, DESCRIPTOR);
    }
    
    public static IResultReceiver2 asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface(DESCRIPTOR);
      return (iInterface != null && iInterface instanceof IResultReceiver2) ? (IResultReceiver2)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      String str = DESCRIPTOR;
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface(str); 
      if (param1Int1 != 1598968902) {
        if (param1Int1 != 1)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        send(param1Parcel1.readInt(), (Bundle)IResultReceiver2._Parcel.readTypedObject(param1Parcel1, Bundle.CREATOR));
        return true;
      } 
      param1Parcel2.writeString(str);
      return true;
    }
    
    private static class Proxy implements IResultReceiver2 {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor() {
        return DESCRIPTOR;
      }
      
      public void send(int param2Int, Bundle param2Bundle) throws RemoteException {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken(DESCRIPTOR);
          parcel.writeInt(param2Int);
          IResultReceiver2._Parcel.writeTypedObject(parcel, (T)param2Bundle, 0);
          this.mRemote.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IResultReceiver2 {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getInterfaceDescriptor() {
      return DESCRIPTOR;
    }
    
    public void send(int param1Int, Bundle param1Bundle) throws RemoteException {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken(DESCRIPTOR);
        parcel.writeInt(param1Int);
        IResultReceiver2._Parcel.writeTypedObject(parcel, (T)param1Bundle, 0);
        this.mRemote.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
  }
  
  public static class _Parcel {
    private static <T> T readTypedObject(Parcel param1Parcel, Parcelable.Creator<T> param1Creator) {
      return (T)((param1Parcel.readInt() != 0) ? param1Creator.createFromParcel(param1Parcel) : null);
    }
    
    private static <T extends Parcelable> void writeTypedObject(Parcel param1Parcel, T param1T, int param1Int) {
      if (param1T != null) {
        param1Parcel.writeInt(1);
        param1T.writeToParcel(param1Parcel, param1Int);
        return;
      } 
      param1Parcel.writeInt(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\android\support\v4\os\IResultReceiver2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */