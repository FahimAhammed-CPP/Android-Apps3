package android.support.customtabs.trusted;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public interface ITrustedWebActivityCallback extends IInterface {
  public static final String DESCRIPTOR = "android.support.customtabs.trusted.ITrustedWebActivityCallback";
  
  void onExtraCallback(String paramString, Bundle paramBundle) throws RemoteException;
  
  public static class Default implements ITrustedWebActivityCallback {
    public IBinder asBinder() {
      return null;
    }
    
    public void onExtraCallback(String param1String, Bundle param1Bundle) throws RemoteException {}
  }
  
  public static abstract class Stub extends Binder implements ITrustedWebActivityCallback {
    static final int TRANSACTION_onExtraCallback = 2;
    
    public Stub() {
      attachInterface(this, "android.support.customtabs.trusted.ITrustedWebActivityCallback");
    }
    
    public static ITrustedWebActivityCallback asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("android.support.customtabs.trusted.ITrustedWebActivityCallback");
      return (iInterface != null && iInterface instanceof ITrustedWebActivityCallback) ? (ITrustedWebActivityCallback)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      if (param1Int1 >= 1 && param1Int1 <= 16777215)
        param1Parcel1.enforceInterface("android.support.customtabs.trusted.ITrustedWebActivityCallback"); 
      if (param1Int1 != 1598968902) {
        if (param1Int1 != 2)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        onExtraCallback(param1Parcel1.readString(), (Bundle)ITrustedWebActivityCallback._Parcel.readTypedObject(param1Parcel1, Bundle.CREATOR));
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel2.writeString("android.support.customtabs.trusted.ITrustedWebActivityCallback");
      return true;
    }
    
    private static class Proxy implements ITrustedWebActivityCallback {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getInterfaceDescriptor() {
        return "android.support.customtabs.trusted.ITrustedWebActivityCallback";
      }
      
      public void onExtraCallback(String param2String, Bundle param2Bundle) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityCallback");
          parcel1.writeString(param2String);
          ITrustedWebActivityCallback._Parcel.writeTypedObject(parcel1, (T)param2Bundle, 0);
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements ITrustedWebActivityCallback {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getInterfaceDescriptor() {
      return "android.support.customtabs.trusted.ITrustedWebActivityCallback";
    }
    
    public void onExtraCallback(String param1String, Bundle param1Bundle) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("android.support.customtabs.trusted.ITrustedWebActivityCallback");
        parcel1.writeString(param1String);
        ITrustedWebActivityCallback._Parcel.writeTypedObject(parcel1, (T)param1Bundle, 0);
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
  
  public static class _Parcel {
    private static <T> T readTypedObject(Parcel param1Parcel, Parcelable.Creator<T> param1Creator) {
      return (T)((param1Parcel.readInt() != 0) ? param1Creator.createFromParcel(param1Parcel) : null);
    }
    
    private static <T extends Parcelable> void writeTypedObject(Parcel param1Parcel, T param1T, int param1Int) {
      if (param1T != null) {
        param1Parcel.writeInt(1);
        param1T.writeToParcel(param1Parcel, param1Int);
        return;
      } 
      param1Parcel.writeInt(0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\android\support\customtabs\trusted\ITrustedWebActivityCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */