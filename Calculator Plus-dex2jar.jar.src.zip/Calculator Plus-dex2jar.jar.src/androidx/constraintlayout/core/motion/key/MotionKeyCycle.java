package androidx.constraintlayout.core.motion.key;

import androidx.constraintlayout.core.motion.CustomVariable;
import androidx.constraintlayout.core.motion.utils.KeyCycleOscillator;
import androidx.constraintlayout.core.motion.utils.SplineSet;
import androidx.constraintlayout.core.motion.utils.TypedValues;
import androidx.constraintlayout.core.motion.utils.Utils;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.HashSet;

public class MotionKeyCycle extends MotionKey {
  public static final int KEY_TYPE = 4;
  
  static final String NAME = "KeyCycle";
  
  public static final int SHAPE_BOUNCE = 6;
  
  public static final int SHAPE_COS_WAVE = 5;
  
  public static final int SHAPE_REVERSE_SAW_WAVE = 4;
  
  public static final int SHAPE_SAW_WAVE = 3;
  
  public static final int SHAPE_SIN_WAVE = 0;
  
  public static final int SHAPE_SQUARE_WAVE = 1;
  
  public static final int SHAPE_TRIANGLE_WAVE = 2;
  
  private static final String TAG = "KeyCycle";
  
  public static final String WAVE_OFFSET = "waveOffset";
  
  public static final String WAVE_PERIOD = "wavePeriod";
  
  public static final String WAVE_PHASE = "wavePhase";
  
  public static final String WAVE_SHAPE = "waveShape";
  
  private float mAlpha = Float.NaN;
  
  private int mCurveFit = 0;
  
  private String mCustomWaveShape = null;
  
  private float mElevation = Float.NaN;
  
  private float mProgress = Float.NaN;
  
  private float mRotation = Float.NaN;
  
  private float mRotationX = Float.NaN;
  
  private float mRotationY = Float.NaN;
  
  private float mScaleX = Float.NaN;
  
  private float mScaleY = Float.NaN;
  
  private String mTransitionEasing = null;
  
  private float mTransitionPathRotate = Float.NaN;
  
  private float mTranslationX = Float.NaN;
  
  private float mTranslationY = Float.NaN;
  
  private float mTranslationZ = Float.NaN;
  
  private float mWaveOffset = 0.0F;
  
  private float mWavePeriod = Float.NaN;
  
  private float mWavePhase = 0.0F;
  
  private int mWaveShape = -1;
  
  public void addCycleValues(HashMap<String, KeyCycleOscillator> paramHashMap) {
    for (String str : paramHashMap.keySet()) {
      if (str.startsWith("CUSTOM")) {
        String str1 = str.substring(7);
        CustomVariable customVariable = this.mCustom.get(str1);
        if (customVariable == null || customVariable.getType() != 901)
          continue; 
        keyCycleOscillator = paramHashMap.get(str);
        if (keyCycleOscillator == null)
          continue; 
        keyCycleOscillator.setPoint(this.mFramePosition, this.mWaveShape, this.mCustomWaveShape, -1, this.mWavePeriod, this.mWaveOffset, this.mWavePhase, customVariable.getValueToInterpolate(), customVariable);
        continue;
      } 
      float f = getValue((String)keyCycleOscillator);
      if (Float.isNaN(f))
        continue; 
      KeyCycleOscillator keyCycleOscillator = paramHashMap.get(keyCycleOscillator);
      if (keyCycleOscillator == null)
        continue; 
      keyCycleOscillator.setPoint(this.mFramePosition, this.mWaveShape, this.mCustomWaveShape, -1, this.mWavePeriod, this.mWaveOffset, this.mWavePhase, f);
    } 
  }
  
  public void addValues(HashMap<String, SplineSet> paramHashMap) {}
  
  public MotionKey clone() {
    return null;
  }
  
  public void dump() {
    PrintStream printStream = System.out;
    StringBuilder stringBuilder = new StringBuilder("MotionKeyCycle{mWaveShape=");
    stringBuilder.append(this.mWaveShape);
    stringBuilder.append(", mWavePeriod=");
    stringBuilder.append(this.mWavePeriod);
    stringBuilder.append(", mWaveOffset=");
    stringBuilder.append(this.mWaveOffset);
    stringBuilder.append(", mWavePhase=");
    stringBuilder.append(this.mWavePhase);
    stringBuilder.append(", mRotation=");
    stringBuilder.append(this.mRotation);
    stringBuilder.append('}');
    printStream.println(stringBuilder.toString());
  }
  
  public void getAttributeNames(HashSet<String> paramHashSet) {
    if (!Float.isNaN(this.mAlpha))
      paramHashSet.add("alpha"); 
    if (!Float.isNaN(this.mElevation))
      paramHashSet.add("elevation"); 
    if (!Float.isNaN(this.mRotation))
      paramHashSet.add("rotationZ"); 
    if (!Float.isNaN(this.mRotationX))
      paramHashSet.add("rotationX"); 
    if (!Float.isNaN(this.mRotationY))
      paramHashSet.add("rotationY"); 
    if (!Float.isNaN(this.mScaleX))
      paramHashSet.add("scaleX"); 
    if (!Float.isNaN(this.mScaleY))
      paramHashSet.add("scaleY"); 
    if (!Float.isNaN(this.mTransitionPathRotate))
      paramHashSet.add("pathRotate"); 
    if (!Float.isNaN(this.mTranslationX))
      paramHashSet.add("translationX"); 
    if (!Float.isNaN(this.mTranslationY))
      paramHashSet.add("translationY"); 
    if (!Float.isNaN(this.mTranslationZ))
      paramHashSet.add("translationZ"); 
    if (this.mCustom.size() > 0)
      for (String str : this.mCustom.keySet()) {
        StringBuilder stringBuilder = new StringBuilder("CUSTOM,");
        stringBuilder.append(str);
        paramHashSet.add(stringBuilder.toString());
      }  
  }
  
  public int getId(String paramString) {
    byte b;
    paramString.hashCode();
    switch (paramString.hashCode()) {
      default:
        b = -1;
        break;
      case 1941332754:
        if (paramString.equals("visibility")) {
          b = 20;
          break;
        } 
      case 1532805160:
        if (paramString.equals("waveShape")) {
          b = 19;
          break;
        } 
      case 803192288:
        if (paramString.equals("pathRotate")) {
          b = 18;
          break;
        } 
      case 579057826:
        if (paramString.equals("curveFit")) {
          b = 17;
          break;
        } 
      case 106629499:
        if (paramString.equals("phase")) {
          b = 16;
          break;
        } 
      case 92909918:
        if (paramString.equals("alpha")) {
          b = 15;
          break;
        } 
      case -908189617:
        if (paramString.equals("scaleY")) {
          b = 14;
          break;
        } 
      case -908189618:
        if (paramString.equals("scaleX")) {
          b = 13;
          break;
        } 
      case -987906985:
        if (paramString.equals("pivotY")) {
          b = 12;
          break;
        } 
      case -987906986:
        if (paramString.equals("pivotX")) {
          b = 11;
          break;
        } 
      case -991726143:
        if (paramString.equals("period")) {
          b = 10;
          break;
        } 
      case -1001078227:
        if (paramString.equals("progress")) {
          b = 9;
          break;
        } 
      case -1019779949:
        if (paramString.equals("offset")) {
          b = 8;
          break;
        } 
      case -1225497655:
        if (paramString.equals("translationZ")) {
          b = 7;
          break;
        } 
      case -1225497656:
        if (paramString.equals("translationY")) {
          b = 6;
          break;
        } 
      case -1225497657:
        if (paramString.equals("translationX")) {
          b = 5;
          break;
        } 
      case -1249320804:
        if (paramString.equals("rotationZ")) {
          b = 4;
          break;
        } 
      case -1249320805:
        if (paramString.equals("rotationY")) {
          b = 3;
          break;
        } 
      case -1249320806:
        if (paramString.equals("rotationX")) {
          b = 2;
          break;
        } 
      case -1310311125:
        if (paramString.equals("easing")) {
          b = 1;
          break;
        } 
      case -1581616630:
        if (paramString.equals("customWave")) {
          b = 0;
          break;
        } 
    } 
    switch (b) {
      default:
        return -1;
      case 20:
        return 402;
      case 19:
        return 421;
      case 18:
        return 416;
      case 17:
        return 401;
      case 16:
        return 425;
      case 15:
        return 403;
      case 14:
        return 312;
      case 13:
        return 311;
      case 12:
        return 314;
      case 11:
        return 313;
      case 10:
        return 423;
      case 9:
        return 315;
      case 8:
        return 424;
      case 7:
        return 306;
      case 6:
        return 305;
      case 5:
        return 304;
      case 4:
        return 310;
      case 3:
        return 309;
      case 2:
        return 308;
      case 1:
        return 420;
      case 0:
        break;
    } 
    return 422;
  }
  
  public float getValue(String paramString) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      case 803192288:
        if (!paramString.equals("pathRotate"))
          break; 
        b = 13;
        break;
      case 106629499:
        if (!paramString.equals("phase"))
          break; 
        b = 12;
        break;
      case 92909918:
        if (!paramString.equals("alpha"))
          break; 
        b = 11;
        break;
      case -4379043:
        if (!paramString.equals("elevation"))
          break; 
        b = 10;
        break;
      case -908189617:
        if (!paramString.equals("scaleY"))
          break; 
        b = 9;
        break;
      case -908189618:
        if (!paramString.equals("scaleX"))
          break; 
        b = 8;
        break;
      case -1001078227:
        if (!paramString.equals("progress"))
          break; 
        b = 7;
        break;
      case -1019779949:
        if (!paramString.equals("offset"))
          break; 
        b = 6;
        break;
      case -1225497655:
        if (!paramString.equals("translationZ"))
          break; 
        b = 5;
        break;
      case -1225497656:
        if (!paramString.equals("translationY"))
          break; 
        b = 4;
        break;
      case -1225497657:
        if (!paramString.equals("translationX"))
          break; 
        b = 3;
        break;
      case -1249320804:
        if (!paramString.equals("rotationZ"))
          break; 
        b = 2;
        break;
      case -1249320805:
        if (!paramString.equals("rotationY"))
          break; 
        b = 1;
        break;
      case -1249320806:
        if (!paramString.equals("rotationX"))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        return Float.NaN;
      case 13:
        return this.mTransitionPathRotate;
      case 12:
        return this.mWavePhase;
      case 11:
        return this.mAlpha;
      case 10:
        return this.mElevation;
      case 9:
        return this.mScaleY;
      case 8:
        return this.mScaleX;
      case 7:
        return this.mProgress;
      case 6:
        return this.mWaveOffset;
      case 5:
        return this.mTranslationZ;
      case 4:
        return this.mTranslationY;
      case 3:
        return this.mTranslationX;
      case 2:
        return this.mRotation;
      case 1:
        return this.mRotationY;
      case 0:
        break;
    } 
    return this.mRotationX;
  }
  
  public void printAttributes() {
    HashSet<String> hashSet = new HashSet();
    getAttributeNames(hashSet);
    StringBuilder stringBuilder = new StringBuilder(" ------------- ");
    stringBuilder.append(this.mFramePosition);
    stringBuilder.append(" -------------");
    Utils.log(stringBuilder.toString());
    stringBuilder = new StringBuilder("MotionKeyCycle{Shape=");
    stringBuilder.append(this.mWaveShape);
    stringBuilder.append(", Period=");
    stringBuilder.append(this.mWavePeriod);
    stringBuilder.append(", Offset=");
    stringBuilder.append(this.mWaveOffset);
    stringBuilder.append(", Phase=");
    stringBuilder.append(this.mWavePhase);
    stringBuilder.append('}');
    Utils.log(stringBuilder.toString());
    int i = 0;
    String[] arrayOfString = hashSet.<String>toArray(new String[0]);
    while (i < arrayOfString.length) {
      TypedValues.AttributesType.-CC.getId(arrayOfString[i]);
      stringBuilder = new StringBuilder();
      stringBuilder.append(arrayOfString[i]);
      stringBuilder.append(":");
      stringBuilder.append(getValue(arrayOfString[i]));
      Utils.log(stringBuilder.toString());
      i++;
    } 
  }
  
  public boolean setValue(int paramInt, float paramFloat) {
    if (paramInt != 315) {
      if (paramInt != 403) {
        if (paramInt != 416) {
          switch (paramInt) {
            default:
              switch (paramInt) {
                default:
                  return super.setValue(paramInt, paramFloat);
                case 425:
                  this.mWavePhase = paramFloat;
                  return true;
                case 424:
                  this.mWaveOffset = paramFloat;
                  return true;
                case 423:
                  break;
              } 
              this.mWavePeriod = paramFloat;
              return true;
            case 312:
              this.mScaleY = paramFloat;
              return true;
            case 311:
              this.mScaleX = paramFloat;
              return true;
            case 310:
              this.mRotation = paramFloat;
              return true;
            case 309:
              this.mRotationY = paramFloat;
              return true;
            case 308:
              this.mRotationX = paramFloat;
              return true;
            case 307:
              this.mElevation = paramFloat;
              return true;
            case 306:
              this.mTranslationZ = paramFloat;
              return true;
            case 305:
              this.mTranslationY = paramFloat;
              return true;
            case 304:
              break;
          } 
          this.mTranslationX = paramFloat;
        } else {
          this.mTransitionPathRotate = paramFloat;
        } 
      } else {
        this.mAlpha = paramFloat;
      } 
    } else {
      this.mProgress = paramFloat;
    } 
    return true;
  }
  
  public boolean setValue(int paramInt1, int paramInt2) {
    if (paramInt1 != 401) {
      if (paramInt1 != 421)
        return setValue(paramInt1, paramInt2) ? true : super.setValue(paramInt1, paramInt2); 
      this.mWaveShape = paramInt2;
      return true;
    } 
    this.mCurveFit = paramInt2;
    return true;
  }
  
  public boolean setValue(int paramInt, String paramString) {
    if (paramInt != 420) {
      if (paramInt != 422)
        return super.setValue(paramInt, paramString); 
      this.mCustomWaveShape = paramString;
      return true;
    } 
    this.mTransitionEasing = paramString;
    return true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\motion\key\MotionKeyCycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */