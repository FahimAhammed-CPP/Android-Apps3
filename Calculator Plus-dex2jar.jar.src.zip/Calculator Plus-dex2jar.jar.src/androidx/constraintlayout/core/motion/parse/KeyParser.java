package androidx.constraintlayout.core.motion.parse;

import androidx.constraintlayout.core.motion.utils.TypedBundle;
import androidx.constraintlayout.core.parser.CLElement;
import androidx.constraintlayout.core.parser.CLKey;
import androidx.constraintlayout.core.parser.CLObject;
import androidx.constraintlayout.core.parser.CLParser;
import androidx.constraintlayout.core.parser.CLParsingException;
import java.io.PrintStream;

public class KeyParser {
  public static void main(String[] paramArrayOfString) {
    parseAttributes("{frame:22,\ntarget:'widget1',\neasing:'easeIn',\ncurveFit:'spline',\nprogress:0.3,\nalpha:0.2,\nelevation:0.7,\nrotationZ:23,\nrotationX:25.0,\nrotationY:27.0,\npivotX:15,\npivotY:17,\npivotTarget:'32',\npathRotate:23,\nscaleX:0.5,\nscaleY:0.7,\ntranslationX:5,\ntranslationY:7,\ntranslationZ:11,\n}");
  }
  
  private static TypedBundle parse(String paramString, Ids paramIds, DataType paramDataType) {
    TypedBundle typedBundle = new TypedBundle();
    try {
      CLObject cLObject = CLParser.parse(paramString);
      int j = cLObject.size();
      for (int i = 0; i < j; i++) {
        PrintStream printStream;
        CLKey cLKey = (CLKey)cLObject.get(i);
        String str = cLKey.content();
        CLElement cLElement = cLKey.getValue();
        int k = paramIds.get(str);
        if (k == -1) {
          printStream = System.err;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("unknown type ");
          stringBuilder.append(str);
          printStream.println(stringBuilder.toString());
        } else {
          int m = paramDataType.get(k);
          if (m != 1) {
            if (m != 2) {
              if (m != 4) {
                if (m == 8) {
                  typedBundle.add(k, printStream.content());
                  PrintStream printStream1 = System.out;
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("parse ");
                  stringBuilder.append(str);
                  stringBuilder.append(" STRING_MASK > ");
                  stringBuilder.append(printStream.content());
                  printStream1.println(stringBuilder.toString());
                } 
              } else {
                typedBundle.add(k, printStream.getFloat());
                PrintStream printStream1 = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("parse ");
                stringBuilder.append(str);
                stringBuilder.append(" FLOAT_MASK > ");
                stringBuilder.append(printStream.getFloat());
                printStream1.println(stringBuilder.toString());
              } 
            } else {
              typedBundle.add(k, printStream.getInt());
              PrintStream printStream1 = System.out;
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("parse ");
              stringBuilder.append(str);
              stringBuilder.append(" INT_MASK > ");
              stringBuilder.append(printStream.getInt());
              printStream1.println(stringBuilder.toString());
            } 
          } else {
            typedBundle.add(k, cLObject.getBoolean(i));
          } 
        } 
      } 
    } catch (CLParsingException cLParsingException) {
      cLParsingException.printStackTrace();
    } 
    return typedBundle;
  }
  
  public static TypedBundle parseAttributes(String paramString) {
    return parse(paramString, new KeyParser$$ExternalSyntheticLambda0(), new KeyParser$$ExternalSyntheticLambda1());
  }
  
  private static interface DataType {
    int get(int param1Int);
  }
  
  private static interface Ids {
    int get(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\motion\parse\KeyParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */