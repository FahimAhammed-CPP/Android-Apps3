package androidx.constraintlayout.core.motion.utils;

public interface DifferentialInterpolator {
  float getInterpolation(float paramFloat);
  
  float getVelocity();
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\DifferentialInterpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */