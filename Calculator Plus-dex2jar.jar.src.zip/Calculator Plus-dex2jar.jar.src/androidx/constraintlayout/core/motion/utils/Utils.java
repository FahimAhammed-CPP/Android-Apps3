package androidx.constraintlayout.core.motion.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;

public class Utils {
  static DebugHandle ourHandle;
  
  private static int clamp(int paramInt) {
    paramInt = (paramInt & paramInt >> 31) - 255;
    return (paramInt & paramInt >> 31) + 255;
  }
  
  public static void log(String paramString) {
    StackTraceElement stackTraceElement = (new Throwable()).getStackTrace()[1];
    String str2 = stackTraceElement.getMethodName();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str2);
    stringBuilder2.append("                  ");
    str2 = stringBuilder2.toString().substring(0, 17);
    String str3 = "    ".substring(Integer.toString(stackTraceElement.getLineNumber()).length());
    StringBuilder stringBuilder3 = new StringBuilder(".(");
    stringBuilder3.append(stackTraceElement.getFileName());
    stringBuilder3.append(":");
    stringBuilder3.append(stackTraceElement.getLineNumber());
    stringBuilder3.append(")");
    stringBuilder3.append(str3);
    stringBuilder3.append(str2);
    String str1 = stringBuilder3.toString();
    PrintStream printStream = System.out;
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(str1);
    stringBuilder1.append(" ");
    stringBuilder1.append(paramString);
    printStream.println(stringBuilder1.toString());
    DebugHandle debugHandle = ourHandle;
    if (debugHandle != null) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str1);
      stringBuilder1.append(" ");
      stringBuilder1.append(paramString);
      debugHandle.message(stringBuilder1.toString());
    } 
  }
  
  public static void log(String paramString1, String paramString2) {
    PrintStream printStream = System.out;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    stringBuilder.append(" : ");
    stringBuilder.append(paramString2);
    printStream.println(stringBuilder.toString());
  }
  
  public static void logStack(String paramString, int paramInt) {
    StackTraceElement[] arrayOfStackTraceElement = (new Throwable()).getStackTrace();
    int i = arrayOfStackTraceElement.length;
    boolean bool = true;
    i = Math.min(paramInt, i - 1);
    String str = " ";
    for (paramInt = bool; paramInt <= i; paramInt++) {
      StackTraceElement stackTraceElement = arrayOfStackTraceElement[paramInt];
      StringBuilder stringBuilder1 = new StringBuilder(".(");
      stringBuilder1.append(arrayOfStackTraceElement[paramInt].getFileName());
      stringBuilder1.append(":");
      stringBuilder1.append(arrayOfStackTraceElement[paramInt].getLineNumber());
      stringBuilder1.append(") ");
      stringBuilder1.append(arrayOfStackTraceElement[paramInt].getMethodName());
      String str1 = stringBuilder1.toString();
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(" ");
      str = stringBuilder2.toString();
      PrintStream printStream = System.out;
      StringBuilder stringBuilder3 = new StringBuilder();
      stringBuilder3.append(paramString);
      stringBuilder3.append(str);
      stringBuilder3.append(str1);
      stringBuilder3.append(str);
      printStream.println(stringBuilder3.toString());
    } 
  }
  
  public static void loge(String paramString1, String paramString2) {
    PrintStream printStream = System.err;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString1);
    stringBuilder.append(" : ");
    stringBuilder.append(paramString2);
    printStream.println(stringBuilder.toString());
  }
  
  public static int rgbaTocColor(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    int i = clamp((int)(paramFloat1 * 255.0F));
    int j = clamp((int)(paramFloat2 * 255.0F));
    int k = clamp((int)(paramFloat3 * 255.0F));
    return i << 16 | clamp((int)(paramFloat4 * 255.0F)) << 24 | j << 8 | k;
  }
  
  public static void setDebugHandle(DebugHandle paramDebugHandle) {
    ourHandle = paramDebugHandle;
  }
  
  public static void socketSend(String paramString) {
    try {
      OutputStream outputStream = (new Socket("127.0.0.1", 5327)).getOutputStream();
      outputStream.write(paramString.getBytes());
      outputStream.close();
      return;
    } catch (IOException iOException) {
      iOException.printStackTrace();
      return;
    } 
  }
  
  public int getInterpolatedColor(float[] paramArrayOffloat) {
    int i = clamp((int)((float)Math.pow(paramArrayOffloat[0], 0.45454545454545453D) * 255.0F));
    int j = clamp((int)((float)Math.pow(paramArrayOffloat[1], 0.45454545454545453D) * 255.0F));
    int k = clamp((int)((float)Math.pow(paramArrayOffloat[2], 0.45454545454545453D) * 255.0F));
    return clamp((int)(paramArrayOffloat[3] * 255.0F)) << 24 | i << 16 | j << 8 | k;
  }
  
  public static interface DebugHandle {
    void message(String param1String);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */