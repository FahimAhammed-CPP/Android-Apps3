package androidx.constraintlayout.core.motion.utils;

import java.lang.reflect.Array;

public class HyperSpline {
  double[][] mCtl;
  
  Cubic[][] mCurve;
  
  double[] mCurveLength;
  
  int mDimensionality;
  
  int mPoints;
  
  double mTotalLength;
  
  public HyperSpline() {}
  
  public HyperSpline(double[][] paramArrayOfdouble) {
    setup(paramArrayOfdouble);
  }
  
  static Cubic[] calcNaturalCubic(int paramInt, double[] paramArrayOfdouble) {
    double[] arrayOfDouble2 = new double[paramInt];
    double[] arrayOfDouble3 = new double[paramInt];
    double[] arrayOfDouble1 = new double[paramInt];
    int m = paramInt - 1;
    int i = 0;
    arrayOfDouble2[0] = 0.5D;
    int k = 1;
    for (paramInt = 1; paramInt < m; paramInt++)
      arrayOfDouble2[paramInt] = 1.0D / (4.0D - arrayOfDouble2[paramInt - 1]); 
    int j = m - 1;
    arrayOfDouble2[m] = 1.0D / (2.0D - arrayOfDouble2[j]);
    arrayOfDouble3[0] = (paramArrayOfdouble[1] - paramArrayOfdouble[0]) * 3.0D * arrayOfDouble2[0];
    for (paramInt = k; paramInt < m; paramInt = k) {
      k = paramInt + 1;
      double d1 = paramArrayOfdouble[k];
      int n = paramInt - 1;
      arrayOfDouble3[paramInt] = ((d1 - paramArrayOfdouble[n]) * 3.0D - arrayOfDouble3[n]) * arrayOfDouble2[paramInt];
    } 
    double d = ((paramArrayOfdouble[m] - paramArrayOfdouble[j]) * 3.0D - arrayOfDouble3[j]) * arrayOfDouble2[m];
    arrayOfDouble3[m] = d;
    arrayOfDouble1[m] = d;
    for (paramInt = j; paramInt >= 0; paramInt--)
      arrayOfDouble1[paramInt] = arrayOfDouble3[paramInt] - arrayOfDouble2[paramInt] * arrayOfDouble1[paramInt + 1]; 
    Cubic[] arrayOfCubic = new Cubic[m];
    for (paramInt = i; paramInt < m; paramInt = i) {
      d = paramArrayOfdouble[paramInt];
      double d1 = (float)d;
      double d2 = arrayOfDouble1[paramInt];
      i = paramInt + 1;
      double d3 = paramArrayOfdouble[i];
      double d4 = arrayOfDouble1[i];
      arrayOfCubic[paramInt] = new Cubic(d1, d2, (d3 - d) * 3.0D - d2 * 2.0D - d4, (d - d3) * 2.0D + d2 + d4);
    } 
    return arrayOfCubic;
  }
  
  public double approxLength(Cubic[] paramArrayOfCubic) {
    double d3;
    int i = paramArrayOfCubic.length;
    double[] arrayOfDouble = new double[paramArrayOfCubic.length];
    double d4 = 0.0D;
    double d2 = 0.0D;
    double d1 = d2;
    while (true) {
      i = 0;
      boolean bool = false;
      d3 = d4;
      if (d2 < 1.0D) {
        d3 = 0.0D;
        for (i = bool; i < paramArrayOfCubic.length; i++) {
          double d5 = arrayOfDouble[i];
          double d6 = paramArrayOfCubic[i].eval(d2);
          arrayOfDouble[i] = d6;
          d5 -= d6;
          d3 += d5 * d5;
        } 
        double d = d1;
        if (d2 > 0.0D)
          d = d1 + Math.sqrt(d3); 
        d2 += 0.1D;
        d1 = d;
        continue;
      } 
      break;
    } 
    while (i < paramArrayOfCubic.length) {
      d2 = arrayOfDouble[i];
      double d = paramArrayOfCubic[i].eval(1.0D);
      arrayOfDouble[i] = d;
      d2 -= d;
      d3 += d2 * d2;
      i++;
    } 
    return d1 + Math.sqrt(d3);
  }
  
  public double getPos(double paramDouble, int paramInt) {
    double[] arrayOfDouble;
    paramDouble *= this.mTotalLength;
    int i = 0;
    while (true) {
      arrayOfDouble = this.mCurveLength;
      if (i < arrayOfDouble.length - 1) {
        double d = arrayOfDouble[i];
        if (d < paramDouble) {
          paramDouble -= d;
          i++;
          continue;
        } 
      } 
      break;
    } 
    return this.mCurve[paramInt][i].eval(paramDouble / arrayOfDouble[i]);
  }
  
  public void getPos(double paramDouble, double[] paramArrayOfdouble) {
    int j;
    paramDouble *= this.mTotalLength;
    byte b = 0;
    int i = 0;
    while (true) {
      double[] arrayOfDouble = this.mCurveLength;
      j = b;
      if (i < arrayOfDouble.length - 1) {
        double d = arrayOfDouble[i];
        j = b;
        if (d < paramDouble) {
          paramDouble -= d;
          i++;
          continue;
        } 
      } 
      break;
    } 
    while (j < paramArrayOfdouble.length) {
      paramArrayOfdouble[j] = this.mCurve[j][i].eval(paramDouble / this.mCurveLength[i]);
      j++;
    } 
  }
  
  public void getPos(double paramDouble, float[] paramArrayOffloat) {
    int j;
    paramDouble *= this.mTotalLength;
    byte b = 0;
    int i = 0;
    while (true) {
      double[] arrayOfDouble = this.mCurveLength;
      j = b;
      if (i < arrayOfDouble.length - 1) {
        double d = arrayOfDouble[i];
        j = b;
        if (d < paramDouble) {
          paramDouble -= d;
          i++;
          continue;
        } 
      } 
      break;
    } 
    while (j < paramArrayOffloat.length) {
      paramArrayOffloat[j] = (float)this.mCurve[j][i].eval(paramDouble / this.mCurveLength[i]);
      j++;
    } 
  }
  
  public void getVelocity(double paramDouble, double[] paramArrayOfdouble) {
    int j;
    paramDouble *= this.mTotalLength;
    byte b = 0;
    int i = 0;
    while (true) {
      double[] arrayOfDouble = this.mCurveLength;
      j = b;
      if (i < arrayOfDouble.length - 1) {
        double d = arrayOfDouble[i];
        j = b;
        if (d < paramDouble) {
          paramDouble -= d;
          i++;
          continue;
        } 
      } 
      break;
    } 
    while (j < paramArrayOfdouble.length) {
      paramArrayOfdouble[j] = this.mCurve[j][i].vel(paramDouble / this.mCurveLength[i]);
      j++;
    } 
  }
  
  public void setup(double[][] paramArrayOfdouble) {
    int i = (paramArrayOfdouble[0]).length;
    this.mDimensionality = i;
    int j = paramArrayOfdouble.length;
    this.mPoints = j;
    this.mCtl = (double[][])Array.newInstance(double.class, new int[] { i, j });
    this.mCurve = new Cubic[this.mDimensionality][];
    for (i = 0; i < this.mDimensionality; i++) {
      for (j = 0; j < this.mPoints; j++)
        this.mCtl[i][j] = paramArrayOfdouble[j][i]; 
    } 
    i = 0;
    while (true) {
      j = this.mDimensionality;
      if (i < j) {
        Cubic[][] arrayOfCubic1 = this.mCurve;
        double[] arrayOfDouble = this.mCtl[i];
        arrayOfCubic1[i] = calcNaturalCubic(arrayOfDouble.length, arrayOfDouble);
        i++;
        continue;
      } 
      this.mCurveLength = new double[this.mPoints - 1];
      this.mTotalLength = 0.0D;
      Cubic[] arrayOfCubic = new Cubic[j];
      for (i = 0; i < this.mCurveLength.length; i++) {
        for (j = 0; j < this.mDimensionality; j++)
          arrayOfCubic[j] = this.mCurve[j][i]; 
        double d1 = this.mTotalLength;
        double[] arrayOfDouble = this.mCurveLength;
        double d2 = approxLength(arrayOfCubic);
        arrayOfDouble[i] = d2;
        this.mTotalLength = d1 + d2;
      } 
      return;
    } 
  }
  
  public static class Cubic {
    double mA;
    
    double mB;
    
    double mC;
    
    double mD;
    
    public Cubic(double param1Double1, double param1Double2, double param1Double3, double param1Double4) {
      this.mA = param1Double1;
      this.mB = param1Double2;
      this.mC = param1Double3;
      this.mD = param1Double4;
    }
    
    public double eval(double param1Double) {
      return ((this.mD * param1Double + this.mC) * param1Double + this.mB) * param1Double + this.mA;
    }
    
    public double vel(double param1Double) {
      return (this.mD * 3.0D * param1Double + this.mC * 2.0D) * param1Double + this.mB;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\motio\\utils\HyperSpline.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */