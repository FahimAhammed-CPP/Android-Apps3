package androidx.constraintlayout.core.parser;

import java.io.PrintStream;

public class CLParser {
  static boolean DEBUG = false;
  
  private boolean hasComment = false;
  
  private int lineNumber;
  
  private String mContent;
  
  public CLParser(String paramString) {
    this.mContent = paramString;
  }
  
  private CLElement createElement(CLElement paramCLElement, int paramInt, TYPE paramTYPE, boolean paramBoolean, char[] paramArrayOfchar) {
    CLElement cLElement;
    if (DEBUG) {
      PrintStream printStream = System.out;
      StringBuilder stringBuilder = new StringBuilder("CREATE ");
      stringBuilder.append(paramTYPE);
      stringBuilder.append(" at ");
      stringBuilder.append(paramArrayOfchar[paramInt]);
      printStream.println(stringBuilder.toString());
    } 
    switch (paramTYPE) {
      default:
        paramTYPE = null;
        break;
      case null:
        cLElement = CLToken.allocate(paramArrayOfchar);
        break;
      case null:
        cLElement = CLKey.allocate(paramArrayOfchar);
        break;
      case null:
        cLElement = CLNumber.allocate(paramArrayOfchar);
        break;
      case null:
        cLElement = CLString.allocate(paramArrayOfchar);
        break;
      case null:
        cLElement = CLArray.allocate(paramArrayOfchar);
        paramInt++;
        break;
      case null:
        cLElement = CLObject.allocate(paramArrayOfchar);
        paramInt++;
        break;
    } 
    if (cLElement == null)
      return null; 
    cLElement.setLine(this.lineNumber);
    if (paramBoolean)
      cLElement.setStart(paramInt); 
    if (paramCLElement instanceof CLContainer)
      cLElement.setContainer((CLContainer)paramCLElement); 
    return cLElement;
  }
  
  private CLElement getNextJsonElement(int paramInt, char paramChar, CLElement paramCLElement, char[] paramArrayOfchar) throws CLParsingException {
    CLElement cLElement = paramCLElement;
    if (paramChar != '\t') {
      cLElement = paramCLElement;
      if (paramChar != '\n') {
        cLElement = paramCLElement;
        if (paramChar != '\r') {
          cLElement = paramCLElement;
          if (paramChar != ' ') {
            StringBuilder stringBuilder;
            if (paramChar != '"' && paramChar != '\'') {
              if (paramChar != '[') {
                if (paramChar != ']') {
                  if (paramChar != '{') {
                    if (paramChar != '}') {
                      cLElement = paramCLElement;
                      switch (paramChar) {
                        default:
                          if (paramCLElement instanceof CLContainer && !(paramCLElement instanceof CLObject)) {
                            CLElement cLElement1 = createElement(paramCLElement, paramInt, TYPE.TOKEN, true, paramArrayOfchar);
                            paramCLElement = cLElement1;
                            if (paramCLElement.validate(paramChar, paramInt))
                              return cLElement1; 
                            stringBuilder = new StringBuilder("incorrect token <");
                            stringBuilder.append(paramChar);
                            stringBuilder.append("> at line ");
                            stringBuilder.append(this.lineNumber);
                            throw new CLParsingException(stringBuilder.toString(), paramCLElement);
                          } 
                          return createElement(paramCLElement, paramInt, TYPE.KEY, true, (char[])stringBuilder);
                        case '/':
                          paramInt++;
                          cLElement = paramCLElement;
                          if (paramInt < stringBuilder.length) {
                            cLElement = paramCLElement;
                            if (stringBuilder[paramInt] == 47) {
                              this.hasComment = true;
                              return paramCLElement;
                            } 
                          } 
                          break;
                        case '+':
                        case '-':
                        case '.':
                        case '0':
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                        case '5':
                        case '6':
                        case '7':
                        case '8':
                        case '9':
                          return createElement(paramCLElement, paramInt, TYPE.NUMBER, true, (char[])stringBuilder);
                        case ',':
                        case ':':
                          break;
                      } 
                    } else {
                      paramCLElement.setEnd((paramInt - 1));
                      paramCLElement = paramCLElement.getContainer();
                      paramCLElement.setEnd(paramInt);
                      return paramCLElement;
                    } 
                  } else {
                    return createElement(paramCLElement, paramInt, TYPE.OBJECT, true, (char[])stringBuilder);
                  } 
                } else {
                  paramCLElement.setEnd((paramInt - 1));
                  paramCLElement = paramCLElement.getContainer();
                  paramCLElement.setEnd(paramInt);
                  return paramCLElement;
                } 
              } else {
                return createElement(paramCLElement, paramInt, TYPE.ARRAY, true, (char[])stringBuilder);
              } 
            } else {
              if (paramCLElement instanceof CLObject)
                return createElement(paramCLElement, paramInt, TYPE.KEY, true, (char[])stringBuilder); 
              cLElement = createElement(paramCLElement, paramInt, TYPE.STRING, true, (char[])stringBuilder);
            } 
          } 
        } 
      } 
    } 
    return cLElement;
  }
  
  public static CLObject parse(String paramString) throws CLParsingException {
    return (new CLParser(paramString)).parse();
  }
  
  public CLObject parse() throws CLParsingException {
    // Byte code:
    //   0: aload_0
    //   1: getfield mContent : Ljava/lang/String;
    //   4: invokevirtual toCharArray : ()[C
    //   7: astore #12
    //   9: aload #12
    //   11: arraylength
    //   12: istore_3
    //   13: aload_0
    //   14: iconst_1
    //   15: putfield lineNumber : I
    //   18: iconst_0
    //   19: istore_2
    //   20: iload_2
    //   21: iload_3
    //   22: if_icmpge -> 65
    //   25: aload #12
    //   27: iload_2
    //   28: caload
    //   29: istore #4
    //   31: iload #4
    //   33: bipush #123
    //   35: if_icmpne -> 41
    //   38: goto -> 67
    //   41: iload #4
    //   43: bipush #10
    //   45: if_icmpne -> 58
    //   48: aload_0
    //   49: aload_0
    //   50: getfield lineNumber : I
    //   53: iconst_1
    //   54: iadd
    //   55: putfield lineNumber : I
    //   58: iload_2
    //   59: iconst_1
    //   60: iadd
    //   61: istore_2
    //   62: goto -> 20
    //   65: iconst_m1
    //   66: istore_2
    //   67: iload_2
    //   68: iconst_m1
    //   69: if_icmpeq -> 778
    //   72: aload #12
    //   74: invokestatic allocate : ([C)Landroidx/constraintlayout/core/parser/CLObject;
    //   77: astore #11
    //   79: aload #11
    //   81: aload_0
    //   82: getfield lineNumber : I
    //   85: invokevirtual setLine : (I)V
    //   88: aload #11
    //   90: iload_2
    //   91: i2l
    //   92: invokevirtual setStart : (J)V
    //   95: iload_2
    //   96: iconst_1
    //   97: iadd
    //   98: istore_2
    //   99: aload #11
    //   101: astore #9
    //   103: aload #9
    //   105: astore #8
    //   107: iload_2
    //   108: iload_3
    //   109: if_icmpge -> 675
    //   112: aload #12
    //   114: iload_2
    //   115: caload
    //   116: istore_1
    //   117: iload_1
    //   118: bipush #10
    //   120: if_icmpne -> 133
    //   123: aload_0
    //   124: aload_0
    //   125: getfield lineNumber : I
    //   128: iconst_1
    //   129: iadd
    //   130: putfield lineNumber : I
    //   133: aload_0
    //   134: getfield hasComment : Z
    //   137: ifeq -> 155
    //   140: aload #9
    //   142: astore #10
    //   144: iload_1
    //   145: bipush #10
    //   147: if_icmpne -> 664
    //   150: aload_0
    //   151: iconst_0
    //   152: putfield hasComment : Z
    //   155: aload #9
    //   157: ifnonnull -> 167
    //   160: aload #9
    //   162: astore #8
    //   164: goto -> 675
    //   167: aload #9
    //   169: invokevirtual isDone : ()Z
    //   172: ifeq -> 190
    //   175: aload_0
    //   176: iload_2
    //   177: iload_1
    //   178: aload #9
    //   180: aload #12
    //   182: invokespecial getNextJsonElement : (ICLandroidx/constraintlayout/core/parser/CLElement;[C)Landroidx/constraintlayout/core/parser/CLElement;
    //   185: astore #8
    //   187: goto -> 619
    //   190: aload #9
    //   192: instanceof androidx/constraintlayout/core/parser/CLObject
    //   195: ifeq -> 235
    //   198: iload_1
    //   199: bipush #125
    //   201: if_icmpne -> 220
    //   204: aload #9
    //   206: iload_2
    //   207: iconst_1
    //   208: isub
    //   209: i2l
    //   210: invokevirtual setEnd : (J)V
    //   213: aload #9
    //   215: astore #8
    //   217: goto -> 619
    //   220: aload_0
    //   221: iload_2
    //   222: iload_1
    //   223: aload #9
    //   225: aload #12
    //   227: invokespecial getNextJsonElement : (ICLandroidx/constraintlayout/core/parser/CLElement;[C)Landroidx/constraintlayout/core/parser/CLElement;
    //   230: astore #8
    //   232: goto -> 619
    //   235: aload #9
    //   237: instanceof androidx/constraintlayout/core/parser/CLArray
    //   240: ifeq -> 280
    //   243: iload_1
    //   244: bipush #93
    //   246: if_icmpne -> 265
    //   249: aload #9
    //   251: iload_2
    //   252: iconst_1
    //   253: isub
    //   254: i2l
    //   255: invokevirtual setEnd : (J)V
    //   258: aload #9
    //   260: astore #8
    //   262: goto -> 619
    //   265: aload_0
    //   266: iload_2
    //   267: iload_1
    //   268: aload #9
    //   270: aload #12
    //   272: invokespecial getNextJsonElement : (ICLandroidx/constraintlayout/core/parser/CLElement;[C)Landroidx/constraintlayout/core/parser/CLElement;
    //   275: astore #8
    //   277: goto -> 619
    //   280: aload #9
    //   282: instanceof androidx/constraintlayout/core/parser/CLString
    //   285: istore #5
    //   287: iload #5
    //   289: ifeq -> 337
    //   292: aload #9
    //   294: astore #8
    //   296: aload #12
    //   298: aload #9
    //   300: getfield start : J
    //   303: l2i
    //   304: caload
    //   305: iload_1
    //   306: if_icmpne -> 619
    //   309: aload #9
    //   311: aload #9
    //   313: getfield start : J
    //   316: lconst_1
    //   317: ladd
    //   318: invokevirtual setStart : (J)V
    //   321: aload #9
    //   323: iload_2
    //   324: iconst_1
    //   325: isub
    //   326: i2l
    //   327: invokevirtual setEnd : (J)V
    //   330: aload #9
    //   332: astore #8
    //   334: goto -> 619
    //   337: aload #9
    //   339: instanceof androidx/constraintlayout/core/parser/CLToken
    //   342: ifeq -> 421
    //   345: aload #9
    //   347: checkcast androidx/constraintlayout/core/parser/CLToken
    //   350: astore #8
    //   352: aload #8
    //   354: iload_1
    //   355: iload_2
    //   356: i2l
    //   357: invokevirtual validate : (CJ)Z
    //   360: ifeq -> 366
    //   363: goto -> 421
    //   366: new java/lang/StringBuilder
    //   369: dup
    //   370: ldc 'parsing incorrect token '
    //   372: invokespecial <init> : (Ljava/lang/String;)V
    //   375: astore #9
    //   377: aload #9
    //   379: aload #8
    //   381: invokevirtual content : ()Ljava/lang/String;
    //   384: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   387: pop
    //   388: aload #9
    //   390: ldc ' at line '
    //   392: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   395: pop
    //   396: aload #9
    //   398: aload_0
    //   399: getfield lineNumber : I
    //   402: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   405: pop
    //   406: new androidx/constraintlayout/core/parser/CLParsingException
    //   409: dup
    //   410: aload #9
    //   412: invokevirtual toString : ()Ljava/lang/String;
    //   415: aload #8
    //   417: invokespecial <init> : (Ljava/lang/String;Landroidx/constraintlayout/core/parser/CLElement;)V
    //   420: athrow
    //   421: aload #9
    //   423: instanceof androidx/constraintlayout/core/parser/CLKey
    //   426: ifne -> 434
    //   429: iload #5
    //   431: ifeq -> 486
    //   434: aload #12
    //   436: aload #9
    //   438: getfield start : J
    //   441: l2i
    //   442: caload
    //   443: istore #4
    //   445: iload #4
    //   447: bipush #39
    //   449: if_icmpeq -> 459
    //   452: iload #4
    //   454: bipush #34
    //   456: if_icmpne -> 486
    //   459: iload #4
    //   461: iload_1
    //   462: if_icmpne -> 486
    //   465: aload #9
    //   467: aload #9
    //   469: getfield start : J
    //   472: lconst_1
    //   473: ladd
    //   474: invokevirtual setStart : (J)V
    //   477: aload #9
    //   479: iload_2
    //   480: iconst_1
    //   481: isub
    //   482: i2l
    //   483: invokevirtual setEnd : (J)V
    //   486: aload #9
    //   488: astore #8
    //   490: aload #9
    //   492: invokevirtual isDone : ()Z
    //   495: ifne -> 619
    //   498: iload_1
    //   499: bipush #125
    //   501: if_icmpeq -> 550
    //   504: iload_1
    //   505: bipush #93
    //   507: if_icmpeq -> 550
    //   510: iload_1
    //   511: bipush #44
    //   513: if_icmpeq -> 550
    //   516: iload_1
    //   517: bipush #32
    //   519: if_icmpeq -> 550
    //   522: iload_1
    //   523: bipush #9
    //   525: if_icmpeq -> 550
    //   528: iload_1
    //   529: bipush #13
    //   531: if_icmpeq -> 550
    //   534: iload_1
    //   535: bipush #10
    //   537: if_icmpeq -> 550
    //   540: aload #9
    //   542: astore #8
    //   544: iload_1
    //   545: bipush #58
    //   547: if_icmpne -> 619
    //   550: iload_2
    //   551: iconst_1
    //   552: isub
    //   553: i2l
    //   554: lstore #6
    //   556: aload #9
    //   558: lload #6
    //   560: invokevirtual setEnd : (J)V
    //   563: iload_1
    //   564: bipush #125
    //   566: if_icmpeq -> 579
    //   569: aload #9
    //   571: astore #8
    //   573: iload_1
    //   574: bipush #93
    //   576: if_icmpne -> 619
    //   579: aload #9
    //   581: invokevirtual getContainer : ()Landroidx/constraintlayout/core/parser/CLElement;
    //   584: astore #9
    //   586: aload #9
    //   588: lload #6
    //   590: invokevirtual setEnd : (J)V
    //   593: aload #9
    //   595: astore #8
    //   597: aload #9
    //   599: instanceof androidx/constraintlayout/core/parser/CLKey
    //   602: ifeq -> 619
    //   605: aload #9
    //   607: invokevirtual getContainer : ()Landroidx/constraintlayout/core/parser/CLElement;
    //   610: astore #8
    //   612: aload #8
    //   614: lload #6
    //   616: invokevirtual setEnd : (J)V
    //   619: aload #8
    //   621: astore #10
    //   623: aload #8
    //   625: invokevirtual isDone : ()Z
    //   628: ifeq -> 664
    //   631: aload #8
    //   633: instanceof androidx/constraintlayout/core/parser/CLKey
    //   636: ifeq -> 657
    //   639: aload #8
    //   641: astore #10
    //   643: aload #8
    //   645: checkcast androidx/constraintlayout/core/parser/CLKey
    //   648: getfield mElements : Ljava/util/ArrayList;
    //   651: invokevirtual size : ()I
    //   654: ifle -> 664
    //   657: aload #8
    //   659: invokevirtual getContainer : ()Landroidx/constraintlayout/core/parser/CLElement;
    //   662: astore #10
    //   664: iload_2
    //   665: iconst_1
    //   666: iadd
    //   667: istore_2
    //   668: aload #10
    //   670: astore #9
    //   672: goto -> 103
    //   675: aload #8
    //   677: ifnull -> 732
    //   680: aload #8
    //   682: invokevirtual isDone : ()Z
    //   685: ifne -> 732
    //   688: aload #8
    //   690: instanceof androidx/constraintlayout/core/parser/CLString
    //   693: ifeq -> 713
    //   696: aload #8
    //   698: aload #8
    //   700: getfield start : J
    //   703: l2i
    //   704: iconst_1
    //   705: iadd
    //   706: i2l
    //   707: invokevirtual setStart : (J)V
    //   710: goto -> 713
    //   713: aload #8
    //   715: iload_3
    //   716: iconst_1
    //   717: isub
    //   718: i2l
    //   719: invokevirtual setEnd : (J)V
    //   722: aload #8
    //   724: invokevirtual getContainer : ()Landroidx/constraintlayout/core/parser/CLElement;
    //   727: astore #8
    //   729: goto -> 675
    //   732: getstatic androidx/constraintlayout/core/parser/CLParser.DEBUG : Z
    //   735: ifeq -> 775
    //   738: getstatic java/lang/System.out : Ljava/io/PrintStream;
    //   741: astore #8
    //   743: new java/lang/StringBuilder
    //   746: dup
    //   747: ldc 'Root: '
    //   749: invokespecial <init> : (Ljava/lang/String;)V
    //   752: astore #9
    //   754: aload #9
    //   756: aload #11
    //   758: invokevirtual toJSON : ()Ljava/lang/String;
    //   761: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   764: pop
    //   765: aload #8
    //   767: aload #9
    //   769: invokevirtual toString : ()Ljava/lang/String;
    //   772: invokevirtual println : (Ljava/lang/String;)V
    //   775: aload #11
    //   777: areturn
    //   778: new androidx/constraintlayout/core/parser/CLParsingException
    //   781: dup
    //   782: ldc 'invalid json content'
    //   784: aconst_null
    //   785: invokespecial <init> : (Ljava/lang/String;Landroidx/constraintlayout/core/parser/CLElement;)V
    //   788: athrow
  }
  
  enum TYPE {
    ARRAY, KEY, NUMBER, OBJECT, STRING, TOKEN, UNKNOWN;
    
    static {
      TYPE tYPE1 = new TYPE("UNKNOWN", 0);
      UNKNOWN = tYPE1;
      TYPE tYPE2 = new TYPE("OBJECT", 1);
      OBJECT = tYPE2;
      TYPE tYPE3 = new TYPE("ARRAY", 2);
      ARRAY = tYPE3;
      TYPE tYPE4 = new TYPE("NUMBER", 3);
      NUMBER = tYPE4;
      TYPE tYPE5 = new TYPE("STRING", 4);
      STRING = tYPE5;
      TYPE tYPE6 = new TYPE("KEY", 5);
      KEY = tYPE6;
      TYPE tYPE7 = new TYPE("TOKEN", 6);
      TOKEN = tYPE7;
      $VALUES = new TYPE[] { tYPE1, tYPE2, tYPE3, tYPE4, tYPE5, tYPE6, tYPE7 };
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\parser\CLParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */