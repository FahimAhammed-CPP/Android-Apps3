package androidx.constraintlayout.core.state;

public interface Interpolator {
  float getInterpolation(float paramFloat);
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\state\Interpolator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */