package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.HashMap;

public class Barrier extends HelperWidget {
  public static final int BOTTOM = 3;
  
  public static final int LEFT = 0;
  
  public static final int RIGHT = 1;
  
  public static final int TOP = 2;
  
  private static final boolean USE_RELAX_GONE = false;
  
  private static final boolean USE_RESOLUTION = true;
  
  private boolean mAllowsGoneWidget = true;
  
  private int mBarrierType = 0;
  
  private int mMargin = 0;
  
  boolean resolved = false;
  
  public Barrier() {}
  
  public Barrier(String paramString) {
    setDebugName(paramString);
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   4: iconst_0
    //   5: aload_0
    //   6: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   9: aastore
    //   10: aload_0
    //   11: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   14: iconst_2
    //   15: aload_0
    //   16: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   19: aastore
    //   20: aload_0
    //   21: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   24: iconst_1
    //   25: aload_0
    //   26: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   29: aastore
    //   30: aload_0
    //   31: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   34: iconst_3
    //   35: aload_0
    //   36: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   39: aastore
    //   40: iconst_0
    //   41: istore_3
    //   42: iload_3
    //   43: aload_0
    //   44: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   47: arraylength
    //   48: if_icmpge -> 77
    //   51: aload_0
    //   52: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   55: iload_3
    //   56: aaload
    //   57: aload_1
    //   58: aload_0
    //   59: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   62: iload_3
    //   63: aaload
    //   64: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   67: putfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   70: iload_3
    //   71: iconst_1
    //   72: iadd
    //   73: istore_3
    //   74: goto -> 42
    //   77: aload_0
    //   78: getfield mBarrierType : I
    //   81: istore_3
    //   82: iload_3
    //   83: iflt -> 1026
    //   86: iload_3
    //   87: iconst_4
    //   88: if_icmpge -> 1026
    //   91: aload_0
    //   92: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   95: aload_0
    //   96: getfield mBarrierType : I
    //   99: aaload
    //   100: astore #7
    //   102: aload_0
    //   103: getfield resolved : Z
    //   106: ifne -> 114
    //   109: aload_0
    //   110: invokevirtual allSolved : ()Z
    //   113: pop
    //   114: aload_0
    //   115: getfield resolved : Z
    //   118: ifeq -> 215
    //   121: aload_0
    //   122: iconst_0
    //   123: putfield resolved : Z
    //   126: aload_0
    //   127: getfield mBarrierType : I
    //   130: istore_3
    //   131: iload_3
    //   132: ifeq -> 184
    //   135: iload_3
    //   136: iconst_1
    //   137: if_icmpne -> 143
    //   140: goto -> 184
    //   143: iload_3
    //   144: iconst_2
    //   145: if_icmpeq -> 153
    //   148: iload_3
    //   149: iconst_3
    //   150: if_icmpne -> 214
    //   153: aload_1
    //   154: aload_0
    //   155: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   158: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   161: aload_0
    //   162: getfield mY : I
    //   165: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   168: aload_1
    //   169: aload_0
    //   170: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   173: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   176: aload_0
    //   177: getfield mY : I
    //   180: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   183: return
    //   184: aload_1
    //   185: aload_0
    //   186: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   189: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   192: aload_0
    //   193: getfield mX : I
    //   196: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   199: aload_1
    //   200: aload_0
    //   201: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   204: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   207: aload_0
    //   208: getfield mX : I
    //   211: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;I)V
    //   214: return
    //   215: iconst_0
    //   216: istore_3
    //   217: iload_3
    //   218: aload_0
    //   219: getfield mWidgetsCount : I
    //   222: if_icmpge -> 367
    //   225: aload_0
    //   226: getfield mWidgets : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   229: iload_3
    //   230: aaload
    //   231: astore #8
    //   233: aload_0
    //   234: getfield mAllowsGoneWidget : Z
    //   237: ifne -> 251
    //   240: aload #8
    //   242: invokevirtual allowedInBarrier : ()Z
    //   245: ifne -> 251
    //   248: goto -> 360
    //   251: aload_0
    //   252: getfield mBarrierType : I
    //   255: istore #4
    //   257: iload #4
    //   259: ifeq -> 268
    //   262: iload #4
    //   264: iconst_1
    //   265: if_icmpne -> 306
    //   268: aload #8
    //   270: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   273: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   276: if_acmpne -> 306
    //   279: aload #8
    //   281: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   284: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   287: ifnull -> 306
    //   290: aload #8
    //   292: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   295: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   298: ifnull -> 306
    //   301: iconst_1
    //   302: istore_2
    //   303: goto -> 369
    //   306: aload_0
    //   307: getfield mBarrierType : I
    //   310: istore #4
    //   312: iload #4
    //   314: iconst_2
    //   315: if_icmpeq -> 324
    //   318: iload #4
    //   320: iconst_3
    //   321: if_icmpne -> 360
    //   324: aload #8
    //   326: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   329: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   332: if_acmpne -> 360
    //   335: aload #8
    //   337: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   340: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   343: ifnull -> 360
    //   346: aload #8
    //   348: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   351: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   354: ifnull -> 360
    //   357: goto -> 301
    //   360: iload_3
    //   361: iconst_1
    //   362: iadd
    //   363: istore_3
    //   364: goto -> 217
    //   367: iconst_0
    //   368: istore_2
    //   369: aload_0
    //   370: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   373: invokevirtual hasCenteredDependents : ()Z
    //   376: ifne -> 397
    //   379: aload_0
    //   380: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   383: invokevirtual hasCenteredDependents : ()Z
    //   386: ifeq -> 392
    //   389: goto -> 397
    //   392: iconst_0
    //   393: istore_3
    //   394: goto -> 399
    //   397: iconst_1
    //   398: istore_3
    //   399: aload_0
    //   400: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   403: invokevirtual hasCenteredDependents : ()Z
    //   406: ifne -> 428
    //   409: aload_0
    //   410: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   413: invokevirtual hasCenteredDependents : ()Z
    //   416: ifeq -> 422
    //   419: goto -> 428
    //   422: iconst_0
    //   423: istore #4
    //   425: goto -> 431
    //   428: iconst_1
    //   429: istore #4
    //   431: iload_2
    //   432: ifne -> 487
    //   435: aload_0
    //   436: getfield mBarrierType : I
    //   439: istore #5
    //   441: iload #5
    //   443: ifne -> 450
    //   446: iload_3
    //   447: ifne -> 482
    //   450: iload #5
    //   452: iconst_2
    //   453: if_icmpne -> 461
    //   456: iload #4
    //   458: ifne -> 482
    //   461: iload #5
    //   463: iconst_1
    //   464: if_icmpne -> 471
    //   467: iload_3
    //   468: ifne -> 482
    //   471: iload #5
    //   473: iconst_3
    //   474: if_icmpne -> 487
    //   477: iload #4
    //   479: ifeq -> 487
    //   482: iconst_1
    //   483: istore_3
    //   484: goto -> 489
    //   487: iconst_0
    //   488: istore_3
    //   489: iload_3
    //   490: ifne -> 498
    //   493: iconst_4
    //   494: istore_3
    //   495: goto -> 500
    //   498: iconst_5
    //   499: istore_3
    //   500: iconst_0
    //   501: istore #4
    //   503: iload #4
    //   505: aload_0
    //   506: getfield mWidgetsCount : I
    //   509: if_icmpge -> 719
    //   512: aload_0
    //   513: getfield mWidgets : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   516: iload #4
    //   518: aaload
    //   519: astore #8
    //   521: aload_0
    //   522: getfield mAllowsGoneWidget : Z
    //   525: ifne -> 539
    //   528: aload #8
    //   530: invokevirtual allowedInBarrier : ()Z
    //   533: ifne -> 539
    //   536: goto -> 710
    //   539: aload_1
    //   540: aload #8
    //   542: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   545: aload_0
    //   546: getfield mBarrierType : I
    //   549: aaload
    //   550: invokevirtual createObjectVariable : (Ljava/lang/Object;)Landroidx/constraintlayout/core/SolverVariable;
    //   553: astore #9
    //   555: aload #8
    //   557: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   560: aload_0
    //   561: getfield mBarrierType : I
    //   564: aaload
    //   565: aload #9
    //   567: putfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   570: aload #8
    //   572: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   575: aload_0
    //   576: getfield mBarrierType : I
    //   579: aaload
    //   580: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   583: ifnull -> 626
    //   586: aload #8
    //   588: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   591: aload_0
    //   592: getfield mBarrierType : I
    //   595: aaload
    //   596: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   599: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   602: aload_0
    //   603: if_acmpne -> 626
    //   606: aload #8
    //   608: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   611: aload_0
    //   612: getfield mBarrierType : I
    //   615: aaload
    //   616: getfield mMargin : I
    //   619: iconst_0
    //   620: iadd
    //   621: istore #5
    //   623: goto -> 629
    //   626: iconst_0
    //   627: istore #5
    //   629: aload_0
    //   630: getfield mBarrierType : I
    //   633: istore #6
    //   635: iload #6
    //   637: ifeq -> 671
    //   640: iload #6
    //   642: iconst_2
    //   643: if_icmpne -> 649
    //   646: goto -> 671
    //   649: aload_1
    //   650: aload #7
    //   652: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   655: aload #9
    //   657: aload_0
    //   658: getfield mMargin : I
    //   661: iload #5
    //   663: iadd
    //   664: iload_2
    //   665: invokevirtual addGreaterBarrier : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IZ)V
    //   668: goto -> 690
    //   671: aload_1
    //   672: aload #7
    //   674: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   677: aload #9
    //   679: aload_0
    //   680: getfield mMargin : I
    //   683: iload #5
    //   685: isub
    //   686: iload_2
    //   687: invokevirtual addLowerBarrier : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;IZ)V
    //   690: aload_1
    //   691: aload #7
    //   693: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   696: aload #9
    //   698: aload_0
    //   699: getfield mMargin : I
    //   702: iload #5
    //   704: iadd
    //   705: iload_3
    //   706: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   709: pop
    //   710: iload #4
    //   712: iconst_1
    //   713: iadd
    //   714: istore #4
    //   716: goto -> 503
    //   719: aload_0
    //   720: getfield mBarrierType : I
    //   723: istore_3
    //   724: iload_3
    //   725: ifne -> 799
    //   728: aload_1
    //   729: aload_0
    //   730: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   733: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   736: aload_0
    //   737: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   740: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   743: iconst_0
    //   744: bipush #8
    //   746: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   749: pop
    //   750: aload_1
    //   751: aload_0
    //   752: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   755: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   758: aload_0
    //   759: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   762: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   765: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   768: iconst_0
    //   769: iconst_4
    //   770: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   773: pop
    //   774: aload_1
    //   775: aload_0
    //   776: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   779: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   782: aload_0
    //   783: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   786: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   789: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   792: iconst_0
    //   793: iconst_0
    //   794: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   797: pop
    //   798: return
    //   799: iload_3
    //   800: iconst_1
    //   801: if_icmpne -> 875
    //   804: aload_1
    //   805: aload_0
    //   806: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   809: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   812: aload_0
    //   813: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   816: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   819: iconst_0
    //   820: bipush #8
    //   822: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   825: pop
    //   826: aload_1
    //   827: aload_0
    //   828: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   831: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   834: aload_0
    //   835: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   838: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   841: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   844: iconst_0
    //   845: iconst_4
    //   846: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   849: pop
    //   850: aload_1
    //   851: aload_0
    //   852: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   855: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   858: aload_0
    //   859: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   862: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   865: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   868: iconst_0
    //   869: iconst_0
    //   870: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   873: pop
    //   874: return
    //   875: iload_3
    //   876: iconst_2
    //   877: if_icmpne -> 951
    //   880: aload_1
    //   881: aload_0
    //   882: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   885: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   888: aload_0
    //   889: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   892: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   895: iconst_0
    //   896: bipush #8
    //   898: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   901: pop
    //   902: aload_1
    //   903: aload_0
    //   904: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   907: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   910: aload_0
    //   911: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   914: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   917: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   920: iconst_0
    //   921: iconst_4
    //   922: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   925: pop
    //   926: aload_1
    //   927: aload_0
    //   928: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   931: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   934: aload_0
    //   935: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   938: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   941: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   944: iconst_0
    //   945: iconst_0
    //   946: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   949: pop
    //   950: return
    //   951: iload_3
    //   952: iconst_3
    //   953: if_icmpne -> 1026
    //   956: aload_1
    //   957: aload_0
    //   958: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   961: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   964: aload_0
    //   965: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   968: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   971: iconst_0
    //   972: bipush #8
    //   974: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   977: pop
    //   978: aload_1
    //   979: aload_0
    //   980: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   983: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   986: aload_0
    //   987: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   990: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   993: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   996: iconst_0
    //   997: iconst_4
    //   998: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1001: pop
    //   1002: aload_1
    //   1003: aload_0
    //   1004: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1007: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1010: aload_0
    //   1011: getfield mParent : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1014: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1017: getfield mSolverVariable : Landroidx/constraintlayout/core/SolverVariable;
    //   1020: iconst_0
    //   1021: iconst_0
    //   1022: invokevirtual addEquality : (Landroidx/constraintlayout/core/SolverVariable;Landroidx/constraintlayout/core/SolverVariable;II)Landroidx/constraintlayout/core/ArrayRow;
    //   1025: pop
    //   1026: return
  }
  
  public boolean allSolved() {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore_1
    //   5: iconst_1
    //   6: istore_2
    //   7: iload_1
    //   8: aload_0
    //   9: getfield mWidgetsCount : I
    //   12: if_icmpge -> 112
    //   15: aload_0
    //   16: getfield mWidgets : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   19: iload_1
    //   20: aaload
    //   21: astore #7
    //   23: aload_0
    //   24: getfield mAllowsGoneWidget : Z
    //   27: ifne -> 43
    //   30: aload #7
    //   32: invokevirtual allowedInBarrier : ()Z
    //   35: ifne -> 43
    //   38: iload_2
    //   39: istore_3
    //   40: goto -> 103
    //   43: aload_0
    //   44: getfield mBarrierType : I
    //   47: istore_3
    //   48: iload_3
    //   49: ifeq -> 57
    //   52: iload_3
    //   53: iconst_1
    //   54: if_icmpne -> 70
    //   57: aload #7
    //   59: invokevirtual isResolvedHorizontally : ()Z
    //   62: ifne -> 70
    //   65: iconst_0
    //   66: istore_3
    //   67: goto -> 103
    //   70: aload_0
    //   71: getfield mBarrierType : I
    //   74: istore #4
    //   76: iload #4
    //   78: iconst_2
    //   79: if_icmpeq -> 90
    //   82: iload_2
    //   83: istore_3
    //   84: iload #4
    //   86: iconst_3
    //   87: if_icmpne -> 103
    //   90: iload_2
    //   91: istore_3
    //   92: aload #7
    //   94: invokevirtual isResolvedVertically : ()Z
    //   97: ifne -> 103
    //   100: goto -> 65
    //   103: iload_1
    //   104: iconst_1
    //   105: iadd
    //   106: istore_1
    //   107: iload_3
    //   108: istore_2
    //   109: goto -> 7
    //   112: iload_2
    //   113: ifeq -> 432
    //   116: aload_0
    //   117: getfield mWidgetsCount : I
    //   120: ifle -> 432
    //   123: iconst_0
    //   124: istore_1
    //   125: iconst_0
    //   126: istore_3
    //   127: iload #5
    //   129: aload_0
    //   130: getfield mWidgetsCount : I
    //   133: if_icmpge -> 386
    //   136: aload_0
    //   137: getfield mWidgets : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   140: iload #5
    //   142: aaload
    //   143: astore #7
    //   145: aload_0
    //   146: getfield mAllowsGoneWidget : Z
    //   149: ifne -> 163
    //   152: aload #7
    //   154: invokevirtual allowedInBarrier : ()Z
    //   157: ifne -> 163
    //   160: goto -> 377
    //   163: iload_1
    //   164: istore #4
    //   166: iload_3
    //   167: istore_2
    //   168: iload_3
    //   169: ifne -> 258
    //   172: aload_0
    //   173: getfield mBarrierType : I
    //   176: istore_2
    //   177: iload_2
    //   178: ifne -> 196
    //   181: aload #7
    //   183: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   186: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   189: invokevirtual getFinalValue : ()I
    //   192: istore_1
    //   193: goto -> 253
    //   196: iload_2
    //   197: iconst_1
    //   198: if_icmpne -> 216
    //   201: aload #7
    //   203: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   206: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   209: invokevirtual getFinalValue : ()I
    //   212: istore_1
    //   213: goto -> 253
    //   216: iload_2
    //   217: iconst_2
    //   218: if_icmpne -> 236
    //   221: aload #7
    //   223: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   226: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   229: invokevirtual getFinalValue : ()I
    //   232: istore_1
    //   233: goto -> 253
    //   236: iload_2
    //   237: iconst_3
    //   238: if_icmpne -> 253
    //   241: aload #7
    //   243: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   246: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   249: invokevirtual getFinalValue : ()I
    //   252: istore_1
    //   253: iconst_1
    //   254: istore_2
    //   255: iload_1
    //   256: istore #4
    //   258: aload_0
    //   259: getfield mBarrierType : I
    //   262: istore #6
    //   264: iload #6
    //   266: ifne -> 291
    //   269: iload #4
    //   271: aload #7
    //   273: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.LEFT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   276: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   279: invokevirtual getFinalValue : ()I
    //   282: invokestatic min : (II)I
    //   285: istore_1
    //   286: iload_2
    //   287: istore_3
    //   288: goto -> 377
    //   291: iload #6
    //   293: iconst_1
    //   294: if_icmpne -> 319
    //   297: iload #4
    //   299: aload #7
    //   301: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.RIGHT : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   304: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   307: invokevirtual getFinalValue : ()I
    //   310: invokestatic max : (II)I
    //   313: istore_1
    //   314: iload_2
    //   315: istore_3
    //   316: goto -> 377
    //   319: iload #6
    //   321: iconst_2
    //   322: if_icmpne -> 347
    //   325: iload #4
    //   327: aload #7
    //   329: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.TOP : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   332: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   335: invokevirtual getFinalValue : ()I
    //   338: invokestatic min : (II)I
    //   341: istore_1
    //   342: iload_2
    //   343: istore_3
    //   344: goto -> 377
    //   347: iload #4
    //   349: istore_1
    //   350: iload_2
    //   351: istore_3
    //   352: iload #6
    //   354: iconst_3
    //   355: if_icmpne -> 377
    //   358: iload #4
    //   360: aload #7
    //   362: getstatic androidx/constraintlayout/core/widgets/ConstraintAnchor$Type.BOTTOM : Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;
    //   365: invokevirtual getAnchor : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor$Type;)Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   368: invokevirtual getFinalValue : ()I
    //   371: invokestatic max : (II)I
    //   374: istore_1
    //   375: iload_2
    //   376: istore_3
    //   377: iload #5
    //   379: iconst_1
    //   380: iadd
    //   381: istore #5
    //   383: goto -> 127
    //   386: iload_1
    //   387: aload_0
    //   388: getfield mMargin : I
    //   391: iadd
    //   392: istore_1
    //   393: aload_0
    //   394: getfield mBarrierType : I
    //   397: istore_2
    //   398: iload_2
    //   399: ifeq -> 419
    //   402: iload_2
    //   403: iconst_1
    //   404: if_icmpne -> 410
    //   407: goto -> 419
    //   410: aload_0
    //   411: iload_1
    //   412: iload_1
    //   413: invokevirtual setFinalVertical : (II)V
    //   416: goto -> 425
    //   419: aload_0
    //   420: iload_1
    //   421: iload_1
    //   422: invokevirtual setFinalHorizontal : (II)V
    //   425: aload_0
    //   426: iconst_1
    //   427: putfield resolved : Z
    //   430: iconst_1
    //   431: ireturn
    //   432: iconst_0
    //   433: ireturn
  }
  
  public boolean allowedInBarrier() {
    return true;
  }
  
  @Deprecated
  public boolean allowsGoneWidget() {
    return this.mAllowsGoneWidget;
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mBarrierType = ((Barrier)paramConstraintWidget).mBarrierType;
    this.mAllowsGoneWidget = ((Barrier)paramConstraintWidget).mAllowsGoneWidget;
    this.mMargin = ((Barrier)paramConstraintWidget).mMargin;
  }
  
  public boolean getAllowsGoneWidget() {
    return this.mAllowsGoneWidget;
  }
  
  public int getBarrierType() {
    return this.mBarrierType;
  }
  
  public int getMargin() {
    return this.mMargin;
  }
  
  public int getOrientation() {
    int i = this.mBarrierType;
    return (i != 0 && i != 1) ? ((i != 2 && i != 3) ? -1 : 1) : 0;
  }
  
  public boolean isResolvedHorizontally() {
    return this.resolved;
  }
  
  public boolean isResolvedVertically() {
    return this.resolved;
  }
  
  protected void markWidgets() {
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      if (this.mAllowsGoneWidget || constraintWidget.allowedInBarrier()) {
        int j = this.mBarrierType;
        if (j == 0 || j == 1) {
          constraintWidget.setInBarrier(0, true);
        } else if (j == 2 || j == 3) {
          constraintWidget.setInBarrier(1, true);
        } 
      } 
    } 
  }
  
  public void setAllowsGoneWidget(boolean paramBoolean) {
    this.mAllowsGoneWidget = paramBoolean;
  }
  
  public void setBarrierType(int paramInt) {
    this.mBarrierType = paramInt;
  }
  
  public void setMargin(int paramInt) {
    this.mMargin = paramInt;
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder("[Barrier] ");
    stringBuilder1.append(getDebugName());
    stringBuilder1.append(" {");
    String str = stringBuilder1.toString();
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      String str1 = str;
      if (i > 0) {
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(str);
        stringBuilder3.append(", ");
        str1 = stringBuilder3.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append(constraintWidget.getDebugName());
      str = stringBuilder.toString();
    } 
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(str);
    stringBuilder2.append("}");
    return stringBuilder2.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\widgets\Barrier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */