package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;

public class HorizontalWidgetRun extends WidgetRun {
  private static int[] tempDimensions = new int[2];
  
  public HorizontalWidgetRun(ConstraintWidget paramConstraintWidget) {
    super(paramConstraintWidget);
    this.start.type = DependencyNode.Type.LEFT;
    this.end.type = DependencyNode.Type.RIGHT;
    this.orientation = 0;
  }
  
  private void computeInsetRatio(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
    paramInt1 = paramInt2 - paramInt1;
    paramInt2 = paramInt4 - paramInt3;
    if (paramInt5 != -1) {
      if (paramInt5 != 0) {
        if (paramInt5 != 1)
          return; 
        paramInt2 = (int)(paramInt1 * paramFloat + 0.5F);
        paramArrayOfint[0] = paramInt1;
        paramArrayOfint[1] = paramInt2;
        return;
      } 
      paramArrayOfint[0] = (int)(paramInt2 * paramFloat + 0.5F);
      paramArrayOfint[1] = paramInt2;
      return;
    } 
    paramInt3 = (int)(paramInt2 * paramFloat + 0.5F);
    paramInt4 = (int)(paramInt1 / paramFloat + 0.5F);
    if (paramInt3 <= paramInt1) {
      paramArrayOfint[0] = paramInt3;
      paramArrayOfint[1] = paramInt2;
      return;
    } 
    if (paramInt4 <= paramInt2) {
      paramArrayOfint[0] = paramInt1;
      paramArrayOfint[1] = paramInt4;
    } 
  }
  
  void apply() {
    if (this.widget.measured)
      this.dimension.resolve(this.widget.getWidth()); 
    if (!this.dimension.resolved) {
      this.dimensionBehavior = this.widget.getHorizontalDimensionBehaviour();
      if (this.dimensionBehavior != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
        if (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
          ConstraintWidget constraintWidget = this.widget.getParent();
          if (constraintWidget != null && (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.FIXED || constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_PARENT)) {
            int i = constraintWidget.getWidth();
            int j = this.widget.mLeft.getMargin();
            int k = this.widget.mRight.getMargin();
            addTarget(this.start, constraintWidget.horizontalRun.start, this.widget.mLeft.getMargin());
            addTarget(this.end, constraintWidget.horizontalRun.end, -this.widget.mRight.getMargin());
            this.dimension.resolve(i - j - k);
            return;
          } 
        } 
        if (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.FIXED)
          this.dimension.resolve(this.widget.getWidth()); 
      } 
    } else if (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
      ConstraintWidget constraintWidget = this.widget.getParent();
      if (constraintWidget != null && (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.FIXED || constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_PARENT)) {
        addTarget(this.start, constraintWidget.horizontalRun.start, this.widget.mLeft.getMargin());
        addTarget(this.end, constraintWidget.horizontalRun.end, -this.widget.mRight.getMargin());
        return;
      } 
    } 
    if (this.dimension.resolved && this.widget.measured) {
      if ((this.widget.mListAnchors[0]).mTarget != null && (this.widget.mListAnchors[1]).mTarget != null) {
        if (this.widget.isInHorizontalChain()) {
          this.start.margin = this.widget.mListAnchors[0].getMargin();
          this.end.margin = -this.widget.mListAnchors[1].getMargin();
          return;
        } 
        DependencyNode dependencyNode = getTarget(this.widget.mListAnchors[0]);
        if (dependencyNode != null)
          addTarget(this.start, dependencyNode, this.widget.mListAnchors[0].getMargin()); 
        dependencyNode = getTarget(this.widget.mListAnchors[1]);
        if (dependencyNode != null)
          addTarget(this.end, dependencyNode, -this.widget.mListAnchors[1].getMargin()); 
        this.start.delegateToWidgetRun = true;
        this.end.delegateToWidgetRun = true;
        return;
      } 
      if ((this.widget.mListAnchors[0]).mTarget != null) {
        DependencyNode dependencyNode = getTarget(this.widget.mListAnchors[0]);
        if (dependencyNode != null) {
          addTarget(this.start, dependencyNode, this.widget.mListAnchors[0].getMargin());
          addTarget(this.end, this.start, this.dimension.value);
          return;
        } 
      } else if ((this.widget.mListAnchors[1]).mTarget != null) {
        DependencyNode dependencyNode = getTarget(this.widget.mListAnchors[1]);
        if (dependencyNode != null) {
          addTarget(this.end, dependencyNode, -this.widget.mListAnchors[1].getMargin());
          addTarget(this.start, this.end, -this.dimension.value);
          return;
        } 
      } else if (!(this.widget instanceof androidx.constraintlayout.core.widgets.Helper) && this.widget.getParent() != null && (this.widget.getAnchor(ConstraintAnchor.Type.CENTER)).mTarget == null) {
        DependencyNode dependencyNode = (this.widget.getParent()).horizontalRun.start;
        addTarget(this.start, dependencyNode, this.widget.getX());
        addTarget(this.end, this.start, this.dimension.value);
        return;
      } 
    } else {
      if (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
        int i = this.widget.mMatchConstraintDefaultWidth;
        if (i != 2) {
          if (i == 3)
            if (this.widget.mMatchConstraintDefaultHeight == 3) {
              this.start.updateDelegate = this;
              this.end.updateDelegate = this;
              this.widget.verticalRun.start.updateDelegate = this;
              this.widget.verticalRun.end.updateDelegate = this;
              this.dimension.updateDelegate = this;
              if (this.widget.isInVerticalChain()) {
                this.dimension.targets.add(this.widget.verticalRun.dimension);
                this.widget.verticalRun.dimension.dependencies.add(this.dimension);
                this.widget.verticalRun.dimension.updateDelegate = this;
                this.dimension.targets.add(this.widget.verticalRun.start);
                this.dimension.targets.add(this.widget.verticalRun.end);
                this.widget.verticalRun.start.dependencies.add(this.dimension);
                this.widget.verticalRun.end.dependencies.add(this.dimension);
              } else if (this.widget.isInHorizontalChain()) {
                this.widget.verticalRun.dimension.targets.add(this.dimension);
                this.dimension.dependencies.add(this.widget.verticalRun.dimension);
              } else {
                this.widget.verticalRun.dimension.targets.add(this.dimension);
              } 
            } else {
              DimensionDependency dimensionDependency = this.widget.verticalRun.dimension;
              this.dimension.targets.add(dimensionDependency);
              dimensionDependency.dependencies.add(this.dimension);
              this.widget.verticalRun.start.dependencies.add(this.dimension);
              this.widget.verticalRun.end.dependencies.add(this.dimension);
              this.dimension.delegateToWidgetRun = true;
              this.dimension.dependencies.add(this.start);
              this.dimension.dependencies.add(this.end);
              this.start.targets.add(this.dimension);
              this.end.targets.add(this.dimension);
            }  
        } else {
          ConstraintWidget constraintWidget = this.widget.getParent();
          if (constraintWidget != null) {
            DimensionDependency dimensionDependency = constraintWidget.verticalRun.dimension;
            this.dimension.targets.add(dimensionDependency);
            dimensionDependency.dependencies.add(this.dimension);
            this.dimension.delegateToWidgetRun = true;
            this.dimension.dependencies.add(this.start);
            this.dimension.dependencies.add(this.end);
          } 
        } 
      } 
      if ((this.widget.mListAnchors[0]).mTarget != null && (this.widget.mListAnchors[1]).mTarget != null) {
        if (this.widget.isInHorizontalChain()) {
          this.start.margin = this.widget.mListAnchors[0].getMargin();
          this.end.margin = -this.widget.mListAnchors[1].getMargin();
          return;
        } 
        DependencyNode dependencyNode1 = getTarget(this.widget.mListAnchors[0]);
        DependencyNode dependencyNode2 = getTarget(this.widget.mListAnchors[1]);
        if (dependencyNode1 != null)
          dependencyNode1.addDependency(this); 
        if (dependencyNode2 != null)
          dependencyNode2.addDependency(this); 
        this.mRunType = WidgetRun.RunType.CENTER;
        return;
      } 
      if ((this.widget.mListAnchors[0]).mTarget != null) {
        DependencyNode dependencyNode = getTarget(this.widget.mListAnchors[0]);
        if (dependencyNode != null) {
          addTarget(this.start, dependencyNode, this.widget.mListAnchors[0].getMargin());
          addTarget(this.end, this.start, 1, this.dimension);
          return;
        } 
      } else if ((this.widget.mListAnchors[1]).mTarget != null) {
        DependencyNode dependencyNode = getTarget(this.widget.mListAnchors[1]);
        if (dependencyNode != null) {
          addTarget(this.end, dependencyNode, -this.widget.mListAnchors[1].getMargin());
          addTarget(this.start, this.end, -1, this.dimension);
          return;
        } 
      } else if (!(this.widget instanceof androidx.constraintlayout.core.widgets.Helper) && this.widget.getParent() != null) {
        DependencyNode dependencyNode = (this.widget.getParent()).horizontalRun.start;
        addTarget(this.start, dependencyNode, this.widget.getX());
        addTarget(this.end, this.start, 1, this.dimension);
      } 
    } 
  }
  
  public void applyToWidget() {
    if (this.start.resolved)
      this.widget.setX(this.start.value); 
  }
  
  void clear() {
    this.runGroup = null;
    this.start.clear();
    this.end.clear();
    this.dimension.clear();
    this.resolved = false;
  }
  
  void reset() {
    this.resolved = false;
    this.start.clear();
    this.start.resolved = false;
    this.end.clear();
    this.end.resolved = false;
    this.dimension.resolved = false;
  }
  
  boolean supportsWrapComputation() {
    return (this.dimensionBehavior == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) ? ((this.widget.mMatchConstraintDefaultWidth == 0)) : true;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("HorizontalRun ");
    stringBuilder.append(this.widget.getDebugName());
    return stringBuilder.toString();
  }
  
  public void update(Dependency paramDependency) {
    // Byte code:
    //   0: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun$1.$SwitchMap$androidx$constraintlayout$core$widgets$analyzer$WidgetRun$RunType : [I
    //   3: aload_0
    //   4: getfield mRunType : Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun$RunType;
    //   7: invokevirtual ordinal : ()I
    //   10: iaload
    //   11: istore #4
    //   13: iload #4
    //   15: iconst_1
    //   16: if_icmpeq -> 63
    //   19: iload #4
    //   21: iconst_2
    //   22: if_icmpeq -> 55
    //   25: iload #4
    //   27: iconst_3
    //   28: if_icmpeq -> 34
    //   31: goto -> 68
    //   34: aload_0
    //   35: aload_1
    //   36: aload_0
    //   37: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   40: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   43: aload_0
    //   44: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   47: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   50: iconst_0
    //   51: invokevirtual updateRunCenter : (Landroidx/constraintlayout/core/widgets/analyzer/Dependency;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
    //   54: return
    //   55: aload_0
    //   56: aload_1
    //   57: invokevirtual updateRunEnd : (Landroidx/constraintlayout/core/widgets/analyzer/Dependency;)V
    //   60: goto -> 68
    //   63: aload_0
    //   64: aload_1
    //   65: invokevirtual updateRunStart : (Landroidx/constraintlayout/core/widgets/analyzer/Dependency;)V
    //   68: aload_0
    //   69: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   72: getfield resolved : Z
    //   75: ifne -> 1583
    //   78: aload_0
    //   79: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   82: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   85: if_acmpne -> 1583
    //   88: aload_0
    //   89: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   92: getfield mMatchConstraintDefaultWidth : I
    //   95: istore #4
    //   97: iload #4
    //   99: iconst_2
    //   100: if_icmpeq -> 1522
    //   103: iload #4
    //   105: iconst_3
    //   106: if_icmpeq -> 112
    //   109: goto -> 1583
    //   112: aload_0
    //   113: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   116: getfield mMatchConstraintDefaultHeight : I
    //   119: ifeq -> 266
    //   122: aload_0
    //   123: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   126: getfield mMatchConstraintDefaultHeight : I
    //   129: iconst_3
    //   130: if_icmpne -> 136
    //   133: goto -> 266
    //   136: aload_0
    //   137: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   140: invokevirtual getDimensionRatioSide : ()I
    //   143: istore #4
    //   145: iload #4
    //   147: iconst_m1
    //   148: if_icmpeq -> 220
    //   151: iload #4
    //   153: ifeq -> 194
    //   156: iload #4
    //   158: iconst_1
    //   159: if_icmpeq -> 168
    //   162: iconst_0
    //   163: istore #4
    //   165: goto -> 254
    //   168: aload_0
    //   169: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   172: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   175: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   178: getfield value : I
    //   181: i2f
    //   182: fstore_2
    //   183: aload_0
    //   184: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   187: invokevirtual getDimensionRatio : ()F
    //   190: fstore_3
    //   191: goto -> 243
    //   194: aload_0
    //   195: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   198: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   201: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   204: getfield value : I
    //   207: i2f
    //   208: aload_0
    //   209: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   212: invokevirtual getDimensionRatio : ()F
    //   215: fdiv
    //   216: fstore_2
    //   217: goto -> 247
    //   220: aload_0
    //   221: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   224: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   227: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   230: getfield value : I
    //   233: i2f
    //   234: fstore_2
    //   235: aload_0
    //   236: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   239: invokevirtual getDimensionRatio : ()F
    //   242: fstore_3
    //   243: fload_2
    //   244: fload_3
    //   245: fmul
    //   246: fstore_2
    //   247: fload_2
    //   248: ldc 0.5
    //   250: fadd
    //   251: f2i
    //   252: istore #4
    //   254: aload_0
    //   255: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   258: iload #4
    //   260: invokevirtual resolve : (I)V
    //   263: goto -> 1583
    //   266: aload_0
    //   267: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   270: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   273: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   276: astore_1
    //   277: aload_0
    //   278: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   281: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   284: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   287: astore #13
    //   289: aload_0
    //   290: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   293: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   296: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   299: ifnull -> 308
    //   302: iconst_1
    //   303: istore #4
    //   305: goto -> 311
    //   308: iconst_0
    //   309: istore #4
    //   311: aload_0
    //   312: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   315: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   318: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   321: ifnull -> 330
    //   324: iconst_1
    //   325: istore #5
    //   327: goto -> 333
    //   330: iconst_0
    //   331: istore #5
    //   333: aload_0
    //   334: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   337: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   340: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   343: ifnull -> 352
    //   346: iconst_1
    //   347: istore #6
    //   349: goto -> 355
    //   352: iconst_0
    //   353: istore #6
    //   355: aload_0
    //   356: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   359: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   362: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   365: ifnull -> 374
    //   368: iconst_1
    //   369: istore #7
    //   371: goto -> 377
    //   374: iconst_0
    //   375: istore #7
    //   377: aload_0
    //   378: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   381: invokevirtual getDimensionRatioSide : ()I
    //   384: istore #8
    //   386: iload #4
    //   388: ifeq -> 993
    //   391: iload #5
    //   393: ifeq -> 993
    //   396: iload #6
    //   398: ifeq -> 993
    //   401: iload #7
    //   403: ifeq -> 993
    //   406: aload_0
    //   407: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   410: invokevirtual getDimensionRatio : ()F
    //   413: fstore_2
    //   414: aload_1
    //   415: getfield resolved : Z
    //   418: ifeq -> 597
    //   421: aload #13
    //   423: getfield resolved : Z
    //   426: ifeq -> 597
    //   429: aload_0
    //   430: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   433: getfield readyToSolve : Z
    //   436: ifeq -> 596
    //   439: aload_0
    //   440: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   443: getfield readyToSolve : Z
    //   446: ifne -> 450
    //   449: return
    //   450: aload_0
    //   451: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   454: getfield targets : Ljava/util/List;
    //   457: iconst_0
    //   458: invokeinterface get : (I)Ljava/lang/Object;
    //   463: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   466: getfield value : I
    //   469: istore #4
    //   471: aload_0
    //   472: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   475: getfield margin : I
    //   478: istore #5
    //   480: aload_0
    //   481: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   484: getfield targets : Ljava/util/List;
    //   487: iconst_0
    //   488: invokeinterface get : (I)Ljava/lang/Object;
    //   493: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   496: getfield value : I
    //   499: istore #6
    //   501: aload_0
    //   502: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   505: getfield margin : I
    //   508: istore #7
    //   510: aload_1
    //   511: getfield value : I
    //   514: istore #9
    //   516: aload_1
    //   517: getfield margin : I
    //   520: istore #10
    //   522: aload #13
    //   524: getfield value : I
    //   527: istore #11
    //   529: aload #13
    //   531: getfield margin : I
    //   534: istore #12
    //   536: aload_0
    //   537: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   540: iload #4
    //   542: iload #5
    //   544: iadd
    //   545: iload #6
    //   547: iload #7
    //   549: isub
    //   550: iload #9
    //   552: iload #10
    //   554: iadd
    //   555: iload #11
    //   557: iload #12
    //   559: isub
    //   560: fload_2
    //   561: iload #8
    //   563: invokespecial computeInsetRatio : ([IIIIIFI)V
    //   566: aload_0
    //   567: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   570: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   573: iconst_0
    //   574: iaload
    //   575: invokevirtual resolve : (I)V
    //   578: aload_0
    //   579: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   582: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   585: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   588: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   591: iconst_1
    //   592: iaload
    //   593: invokevirtual resolve : (I)V
    //   596: return
    //   597: aload_0
    //   598: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   601: getfield resolved : Z
    //   604: ifeq -> 783
    //   607: aload_0
    //   608: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   611: getfield resolved : Z
    //   614: ifeq -> 783
    //   617: aload_1
    //   618: getfield readyToSolve : Z
    //   621: ifeq -> 782
    //   624: aload #13
    //   626: getfield readyToSolve : Z
    //   629: ifne -> 633
    //   632: return
    //   633: aload_0
    //   634: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   637: getfield value : I
    //   640: istore #4
    //   642: aload_0
    //   643: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   646: getfield margin : I
    //   649: istore #5
    //   651: aload_0
    //   652: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   655: getfield value : I
    //   658: istore #6
    //   660: aload_0
    //   661: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   664: getfield margin : I
    //   667: istore #7
    //   669: aload_1
    //   670: getfield targets : Ljava/util/List;
    //   673: iconst_0
    //   674: invokeinterface get : (I)Ljava/lang/Object;
    //   679: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   682: getfield value : I
    //   685: istore #9
    //   687: aload_1
    //   688: getfield margin : I
    //   691: istore #10
    //   693: aload #13
    //   695: getfield targets : Ljava/util/List;
    //   698: iconst_0
    //   699: invokeinterface get : (I)Ljava/lang/Object;
    //   704: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   707: getfield value : I
    //   710: istore #11
    //   712: aload #13
    //   714: getfield margin : I
    //   717: istore #12
    //   719: aload_0
    //   720: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   723: iload #4
    //   725: iload #5
    //   727: iadd
    //   728: iload #6
    //   730: iload #7
    //   732: isub
    //   733: iload #9
    //   735: iload #10
    //   737: iadd
    //   738: iload #11
    //   740: iload #12
    //   742: isub
    //   743: fload_2
    //   744: iload #8
    //   746: invokespecial computeInsetRatio : ([IIIIIFI)V
    //   749: aload_0
    //   750: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   753: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   756: iconst_0
    //   757: iaload
    //   758: invokevirtual resolve : (I)V
    //   761: aload_0
    //   762: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   765: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   768: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   771: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   774: iconst_1
    //   775: iaload
    //   776: invokevirtual resolve : (I)V
    //   779: goto -> 783
    //   782: return
    //   783: aload_0
    //   784: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   787: getfield readyToSolve : Z
    //   790: ifeq -> 992
    //   793: aload_0
    //   794: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   797: getfield readyToSolve : Z
    //   800: ifeq -> 992
    //   803: aload_1
    //   804: getfield readyToSolve : Z
    //   807: ifeq -> 992
    //   810: aload #13
    //   812: getfield readyToSolve : Z
    //   815: ifne -> 819
    //   818: return
    //   819: aload_0
    //   820: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   823: getfield targets : Ljava/util/List;
    //   826: iconst_0
    //   827: invokeinterface get : (I)Ljava/lang/Object;
    //   832: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   835: getfield value : I
    //   838: istore #4
    //   840: aload_0
    //   841: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   844: getfield margin : I
    //   847: istore #5
    //   849: aload_0
    //   850: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   853: getfield targets : Ljava/util/List;
    //   856: iconst_0
    //   857: invokeinterface get : (I)Ljava/lang/Object;
    //   862: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   865: getfield value : I
    //   868: istore #6
    //   870: aload_0
    //   871: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   874: getfield margin : I
    //   877: istore #7
    //   879: aload_1
    //   880: getfield targets : Ljava/util/List;
    //   883: iconst_0
    //   884: invokeinterface get : (I)Ljava/lang/Object;
    //   889: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   892: getfield value : I
    //   895: istore #9
    //   897: aload_1
    //   898: getfield margin : I
    //   901: istore #10
    //   903: aload #13
    //   905: getfield targets : Ljava/util/List;
    //   908: iconst_0
    //   909: invokeinterface get : (I)Ljava/lang/Object;
    //   914: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   917: getfield value : I
    //   920: istore #11
    //   922: aload #13
    //   924: getfield margin : I
    //   927: istore #12
    //   929: aload_0
    //   930: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   933: iload #4
    //   935: iload #5
    //   937: iadd
    //   938: iload #6
    //   940: iload #7
    //   942: isub
    //   943: iload #9
    //   945: iload #10
    //   947: iadd
    //   948: iload #11
    //   950: iload #12
    //   952: isub
    //   953: fload_2
    //   954: iload #8
    //   956: invokespecial computeInsetRatio : ([IIIIIFI)V
    //   959: aload_0
    //   960: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   963: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   966: iconst_0
    //   967: iaload
    //   968: invokevirtual resolve : (I)V
    //   971: aload_0
    //   972: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   975: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   978: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   981: getstatic androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun.tempDimensions : [I
    //   984: iconst_1
    //   985: iaload
    //   986: invokevirtual resolve : (I)V
    //   989: goto -> 1583
    //   992: return
    //   993: iload #4
    //   995: ifeq -> 1265
    //   998: iload #6
    //   1000: ifeq -> 1265
    //   1003: aload_0
    //   1004: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1007: getfield readyToSolve : Z
    //   1010: ifeq -> 1264
    //   1013: aload_0
    //   1014: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1017: getfield readyToSolve : Z
    //   1020: ifne -> 1024
    //   1023: return
    //   1024: aload_0
    //   1025: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1028: invokevirtual getDimensionRatio : ()F
    //   1031: fstore_2
    //   1032: aload_0
    //   1033: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1036: getfield targets : Ljava/util/List;
    //   1039: iconst_0
    //   1040: invokeinterface get : (I)Ljava/lang/Object;
    //   1045: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1048: getfield value : I
    //   1051: aload_0
    //   1052: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1055: getfield margin : I
    //   1058: iadd
    //   1059: istore #4
    //   1061: aload_0
    //   1062: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1065: getfield targets : Ljava/util/List;
    //   1068: iconst_0
    //   1069: invokeinterface get : (I)Ljava/lang/Object;
    //   1074: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1077: getfield value : I
    //   1080: aload_0
    //   1081: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1084: getfield margin : I
    //   1087: isub
    //   1088: istore #5
    //   1090: iload #8
    //   1092: iconst_m1
    //   1093: if_icmpeq -> 1187
    //   1096: iload #8
    //   1098: ifeq -> 1187
    //   1101: iload #8
    //   1103: iconst_1
    //   1104: if_icmpeq -> 1110
    //   1107: goto -> 1583
    //   1110: aload_0
    //   1111: iload #5
    //   1113: iload #4
    //   1115: isub
    //   1116: iconst_0
    //   1117: invokevirtual getLimitedDimension : (II)I
    //   1120: istore #4
    //   1122: iload #4
    //   1124: i2f
    //   1125: fload_2
    //   1126: fdiv
    //   1127: ldc 0.5
    //   1129: fadd
    //   1130: f2i
    //   1131: istore #6
    //   1133: aload_0
    //   1134: iload #6
    //   1136: iconst_1
    //   1137: invokevirtual getLimitedDimension : (II)I
    //   1140: istore #5
    //   1142: iload #6
    //   1144: iload #5
    //   1146: if_icmpeq -> 1160
    //   1149: iload #5
    //   1151: i2f
    //   1152: fload_2
    //   1153: fmul
    //   1154: ldc 0.5
    //   1156: fadd
    //   1157: f2i
    //   1158: istore #4
    //   1160: aload_0
    //   1161: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1164: iload #4
    //   1166: invokevirtual resolve : (I)V
    //   1169: aload_0
    //   1170: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1173: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1176: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1179: iload #5
    //   1181: invokevirtual resolve : (I)V
    //   1184: goto -> 1583
    //   1187: aload_0
    //   1188: iload #5
    //   1190: iload #4
    //   1192: isub
    //   1193: iconst_0
    //   1194: invokevirtual getLimitedDimension : (II)I
    //   1197: istore #4
    //   1199: iload #4
    //   1201: i2f
    //   1202: fload_2
    //   1203: fmul
    //   1204: ldc 0.5
    //   1206: fadd
    //   1207: f2i
    //   1208: istore #6
    //   1210: aload_0
    //   1211: iload #6
    //   1213: iconst_1
    //   1214: invokevirtual getLimitedDimension : (II)I
    //   1217: istore #5
    //   1219: iload #6
    //   1221: iload #5
    //   1223: if_icmpeq -> 1237
    //   1226: iload #5
    //   1228: i2f
    //   1229: fload_2
    //   1230: fdiv
    //   1231: ldc 0.5
    //   1233: fadd
    //   1234: f2i
    //   1235: istore #4
    //   1237: aload_0
    //   1238: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1241: iload #4
    //   1243: invokevirtual resolve : (I)V
    //   1246: aload_0
    //   1247: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1250: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1253: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1256: iload #5
    //   1258: invokevirtual resolve : (I)V
    //   1261: goto -> 1583
    //   1264: return
    //   1265: iload #5
    //   1267: ifeq -> 1583
    //   1270: iload #7
    //   1272: ifeq -> 1583
    //   1275: aload_1
    //   1276: getfield readyToSolve : Z
    //   1279: ifeq -> 1521
    //   1282: aload #13
    //   1284: getfield readyToSolve : Z
    //   1287: ifne -> 1291
    //   1290: return
    //   1291: aload_0
    //   1292: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1295: invokevirtual getDimensionRatio : ()F
    //   1298: fstore_2
    //   1299: aload_1
    //   1300: getfield targets : Ljava/util/List;
    //   1303: iconst_0
    //   1304: invokeinterface get : (I)Ljava/lang/Object;
    //   1309: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1312: getfield value : I
    //   1315: aload_1
    //   1316: getfield margin : I
    //   1319: iadd
    //   1320: istore #4
    //   1322: aload #13
    //   1324: getfield targets : Ljava/util/List;
    //   1327: iconst_0
    //   1328: invokeinterface get : (I)Ljava/lang/Object;
    //   1333: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1336: getfield value : I
    //   1339: aload #13
    //   1341: getfield margin : I
    //   1344: isub
    //   1345: istore #5
    //   1347: iload #8
    //   1349: iconst_m1
    //   1350: if_icmpeq -> 1444
    //   1353: iload #8
    //   1355: ifeq -> 1367
    //   1358: iload #8
    //   1360: iconst_1
    //   1361: if_icmpeq -> 1444
    //   1364: goto -> 1583
    //   1367: aload_0
    //   1368: iload #5
    //   1370: iload #4
    //   1372: isub
    //   1373: iconst_1
    //   1374: invokevirtual getLimitedDimension : (II)I
    //   1377: istore #4
    //   1379: iload #4
    //   1381: i2f
    //   1382: fload_2
    //   1383: fmul
    //   1384: ldc 0.5
    //   1386: fadd
    //   1387: f2i
    //   1388: istore #6
    //   1390: aload_0
    //   1391: iload #6
    //   1393: iconst_0
    //   1394: invokevirtual getLimitedDimension : (II)I
    //   1397: istore #5
    //   1399: iload #6
    //   1401: iload #5
    //   1403: if_icmpeq -> 1417
    //   1406: iload #5
    //   1408: i2f
    //   1409: fload_2
    //   1410: fdiv
    //   1411: ldc 0.5
    //   1413: fadd
    //   1414: f2i
    //   1415: istore #4
    //   1417: aload_0
    //   1418: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1421: iload #5
    //   1423: invokevirtual resolve : (I)V
    //   1426: aload_0
    //   1427: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1430: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1433: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1436: iload #4
    //   1438: invokevirtual resolve : (I)V
    //   1441: goto -> 1583
    //   1444: aload_0
    //   1445: iload #5
    //   1447: iload #4
    //   1449: isub
    //   1450: iconst_1
    //   1451: invokevirtual getLimitedDimension : (II)I
    //   1454: istore #4
    //   1456: iload #4
    //   1458: i2f
    //   1459: fload_2
    //   1460: fdiv
    //   1461: ldc 0.5
    //   1463: fadd
    //   1464: f2i
    //   1465: istore #6
    //   1467: aload_0
    //   1468: iload #6
    //   1470: iconst_0
    //   1471: invokevirtual getLimitedDimension : (II)I
    //   1474: istore #5
    //   1476: iload #6
    //   1478: iload #5
    //   1480: if_icmpeq -> 1494
    //   1483: iload #5
    //   1485: i2f
    //   1486: fload_2
    //   1487: fmul
    //   1488: ldc 0.5
    //   1490: fadd
    //   1491: f2i
    //   1492: istore #4
    //   1494: aload_0
    //   1495: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1498: iload #5
    //   1500: invokevirtual resolve : (I)V
    //   1503: aload_0
    //   1504: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1507: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1510: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1513: iload #4
    //   1515: invokevirtual resolve : (I)V
    //   1518: goto -> 1583
    //   1521: return
    //   1522: aload_0
    //   1523: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1526: invokevirtual getParent : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1529: astore_1
    //   1530: aload_1
    //   1531: ifnull -> 1583
    //   1534: aload_1
    //   1535: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1538: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1541: getfield resolved : Z
    //   1544: ifeq -> 1583
    //   1547: aload_0
    //   1548: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1551: getfield mMatchConstraintPercentWidth : F
    //   1554: fstore_2
    //   1555: aload_1
    //   1556: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1559: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1562: getfield value : I
    //   1565: i2f
    //   1566: fload_2
    //   1567: fmul
    //   1568: ldc 0.5
    //   1570: fadd
    //   1571: f2i
    //   1572: istore #4
    //   1574: aload_0
    //   1575: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1578: iload #4
    //   1580: invokevirtual resolve : (I)V
    //   1583: aload_0
    //   1584: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1587: getfield readyToSolve : Z
    //   1590: ifeq -> 2121
    //   1593: aload_0
    //   1594: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1597: getfield readyToSolve : Z
    //   1600: ifne -> 1604
    //   1603: return
    //   1604: aload_0
    //   1605: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1608: getfield resolved : Z
    //   1611: ifeq -> 1635
    //   1614: aload_0
    //   1615: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1618: getfield resolved : Z
    //   1621: ifeq -> 1635
    //   1624: aload_0
    //   1625: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1628: getfield resolved : Z
    //   1631: ifeq -> 1635
    //   1634: return
    //   1635: aload_0
    //   1636: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1639: getfield resolved : Z
    //   1642: ifne -> 1770
    //   1645: aload_0
    //   1646: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1649: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1652: if_acmpne -> 1770
    //   1655: aload_0
    //   1656: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1659: getfield mMatchConstraintDefaultWidth : I
    //   1662: ifne -> 1770
    //   1665: aload_0
    //   1666: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1669: invokevirtual isInHorizontalChain : ()Z
    //   1672: ifne -> 1770
    //   1675: aload_0
    //   1676: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1679: getfield targets : Ljava/util/List;
    //   1682: iconst_0
    //   1683: invokeinterface get : (I)Ljava/lang/Object;
    //   1688: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1691: astore_1
    //   1692: aload_0
    //   1693: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1696: getfield targets : Ljava/util/List;
    //   1699: iconst_0
    //   1700: invokeinterface get : (I)Ljava/lang/Object;
    //   1705: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1708: astore #13
    //   1710: aload_1
    //   1711: getfield value : I
    //   1714: aload_0
    //   1715: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1718: getfield margin : I
    //   1721: iadd
    //   1722: istore #4
    //   1724: aload #13
    //   1726: getfield value : I
    //   1729: aload_0
    //   1730: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1733: getfield margin : I
    //   1736: iadd
    //   1737: istore #5
    //   1739: aload_0
    //   1740: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1743: iload #4
    //   1745: invokevirtual resolve : (I)V
    //   1748: aload_0
    //   1749: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1752: iload #5
    //   1754: invokevirtual resolve : (I)V
    //   1757: aload_0
    //   1758: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1761: iload #5
    //   1763: iload #4
    //   1765: isub
    //   1766: invokevirtual resolve : (I)V
    //   1769: return
    //   1770: aload_0
    //   1771: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1774: getfield resolved : Z
    //   1777: ifne -> 1959
    //   1780: aload_0
    //   1781: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1784: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1787: if_acmpne -> 1959
    //   1790: aload_0
    //   1791: getfield matchConstraintsType : I
    //   1794: iconst_1
    //   1795: if_icmpne -> 1959
    //   1798: aload_0
    //   1799: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1802: getfield targets : Ljava/util/List;
    //   1805: invokeinterface size : ()I
    //   1810: ifle -> 1959
    //   1813: aload_0
    //   1814: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1817: getfield targets : Ljava/util/List;
    //   1820: invokeinterface size : ()I
    //   1825: ifle -> 1959
    //   1828: aload_0
    //   1829: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1832: getfield targets : Ljava/util/List;
    //   1835: iconst_0
    //   1836: invokeinterface get : (I)Ljava/lang/Object;
    //   1841: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1844: astore_1
    //   1845: aload_0
    //   1846: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1849: getfield targets : Ljava/util/List;
    //   1852: iconst_0
    //   1853: invokeinterface get : (I)Ljava/lang/Object;
    //   1858: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1861: astore #13
    //   1863: aload_1
    //   1864: getfield value : I
    //   1867: istore #4
    //   1869: aload_0
    //   1870: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1873: getfield margin : I
    //   1876: istore #5
    //   1878: aload #13
    //   1880: getfield value : I
    //   1883: aload_0
    //   1884: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1887: getfield margin : I
    //   1890: iadd
    //   1891: iload #4
    //   1893: iload #5
    //   1895: iadd
    //   1896: isub
    //   1897: aload_0
    //   1898: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1901: getfield wrapValue : I
    //   1904: invokestatic min : (II)I
    //   1907: istore #4
    //   1909: aload_0
    //   1910: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1913: getfield mMatchConstraintMaxWidth : I
    //   1916: istore #6
    //   1918: aload_0
    //   1919: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1922: getfield mMatchConstraintMinWidth : I
    //   1925: iload #4
    //   1927: invokestatic max : (II)I
    //   1930: istore #5
    //   1932: iload #5
    //   1934: istore #4
    //   1936: iload #6
    //   1938: ifle -> 1950
    //   1941: iload #6
    //   1943: iload #5
    //   1945: invokestatic min : (II)I
    //   1948: istore #4
    //   1950: aload_0
    //   1951: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1954: iload #4
    //   1956: invokevirtual resolve : (I)V
    //   1959: aload_0
    //   1960: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1963: getfield resolved : Z
    //   1966: ifne -> 1970
    //   1969: return
    //   1970: aload_0
    //   1971: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1974: getfield targets : Ljava/util/List;
    //   1977: iconst_0
    //   1978: invokeinterface get : (I)Ljava/lang/Object;
    //   1983: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   1986: astore_1
    //   1987: aload_0
    //   1988: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1991: getfield targets : Ljava/util/List;
    //   1994: iconst_0
    //   1995: invokeinterface get : (I)Ljava/lang/Object;
    //   2000: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   2003: astore #13
    //   2005: aload_1
    //   2006: getfield value : I
    //   2009: aload_0
    //   2010: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2013: getfield margin : I
    //   2016: iadd
    //   2017: istore #4
    //   2019: aload #13
    //   2021: getfield value : I
    //   2024: aload_0
    //   2025: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2028: getfield margin : I
    //   2031: iadd
    //   2032: istore #5
    //   2034: aload_0
    //   2035: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2038: invokevirtual getHorizontalBiasPercent : ()F
    //   2041: fstore_2
    //   2042: aload_1
    //   2043: aload #13
    //   2045: if_acmpne -> 2064
    //   2048: aload_1
    //   2049: getfield value : I
    //   2052: istore #4
    //   2054: aload #13
    //   2056: getfield value : I
    //   2059: istore #5
    //   2061: ldc 0.5
    //   2063: fstore_2
    //   2064: aload_0
    //   2065: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   2068: getfield value : I
    //   2071: istore #6
    //   2073: aload_0
    //   2074: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2077: iload #4
    //   2079: i2f
    //   2080: ldc 0.5
    //   2082: fadd
    //   2083: iload #5
    //   2085: iload #4
    //   2087: isub
    //   2088: iload #6
    //   2090: isub
    //   2091: i2f
    //   2092: fload_2
    //   2093: fmul
    //   2094: fadd
    //   2095: f2i
    //   2096: invokevirtual resolve : (I)V
    //   2099: aload_0
    //   2100: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2103: aload_0
    //   2104: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2107: getfield value : I
    //   2110: aload_0
    //   2111: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   2114: getfield value : I
    //   2117: iadd
    //   2118: invokevirtual resolve : (I)V
    //   2121: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\HorizontalWidgetRun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */