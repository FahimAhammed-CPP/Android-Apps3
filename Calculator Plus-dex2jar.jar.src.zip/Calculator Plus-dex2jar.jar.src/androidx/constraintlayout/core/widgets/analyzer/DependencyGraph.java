package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class DependencyGraph {
  private static final boolean USE_GROUPS = true;
  
  private ConstraintWidgetContainer container;
  
  private ConstraintWidgetContainer mContainer;
  
  ArrayList<RunGroup> mGroups = new ArrayList<RunGroup>();
  
  private BasicMeasure.Measure mMeasure = new BasicMeasure.Measure();
  
  private BasicMeasure.Measurer mMeasurer = null;
  
  private boolean mNeedBuildGraph = true;
  
  private boolean mNeedRedoMeasures = true;
  
  private ArrayList<WidgetRun> mRuns = new ArrayList<WidgetRun>();
  
  private ArrayList<RunGroup> runGroups = new ArrayList<RunGroup>();
  
  public DependencyGraph(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    this.container = paramConstraintWidgetContainer;
    this.mContainer = paramConstraintWidgetContainer;
  }
  
  private void applyGroup(DependencyNode paramDependencyNode1, int paramInt1, int paramInt2, DependencyNode paramDependencyNode2, ArrayList<RunGroup> paramArrayList, RunGroup paramRunGroup) {
    WidgetRun widgetRun = paramDependencyNode1.run;
    if (widgetRun.runGroup == null && widgetRun != this.container.horizontalRun) {
      if (widgetRun == this.container.verticalRun)
        return; 
      RunGroup runGroup = paramRunGroup;
      if (paramRunGroup == null) {
        runGroup = new RunGroup(widgetRun, paramInt2);
        paramArrayList.add(runGroup);
      } 
      widgetRun.runGroup = runGroup;
      runGroup.add(widgetRun);
      for (Dependency dependency : widgetRun.start.dependencies) {
        if (dependency instanceof DependencyNode)
          applyGroup((DependencyNode)dependency, paramInt1, 0, paramDependencyNode2, paramArrayList, runGroup); 
      } 
      for (Dependency dependency : widgetRun.end.dependencies) {
        if (dependency instanceof DependencyNode)
          applyGroup((DependencyNode)dependency, paramInt1, 1, paramDependencyNode2, paramArrayList, runGroup); 
      } 
      if (paramInt1 == 1 && widgetRun instanceof VerticalWidgetRun)
        for (Dependency dependency : ((VerticalWidgetRun)widgetRun).baseline.dependencies) {
          if (dependency instanceof DependencyNode)
            applyGroup((DependencyNode)dependency, paramInt1, 2, paramDependencyNode2, paramArrayList, runGroup); 
        }  
      for (DependencyNode dependencyNode : widgetRun.start.targets) {
        if (dependencyNode == paramDependencyNode2)
          runGroup.dual = true; 
        applyGroup(dependencyNode, paramInt1, 0, paramDependencyNode2, paramArrayList, runGroup);
      } 
      for (DependencyNode dependencyNode : widgetRun.end.targets) {
        if (dependencyNode == paramDependencyNode2)
          runGroup.dual = true; 
        applyGroup(dependencyNode, paramInt1, 1, paramDependencyNode2, paramArrayList, runGroup);
      } 
      if (paramInt1 == 1 && widgetRun instanceof VerticalWidgetRun) {
        Iterator<DependencyNode> iterator = ((VerticalWidgetRun)widgetRun).baseline.targets.iterator();
        while (true) {
          if (iterator.hasNext()) {
            DependencyNode dependencyNode = iterator.next();
            try {
              applyGroup(dependencyNode, paramInt1, 2, paramDependencyNode2, paramArrayList, runGroup);
            } finally {}
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  private boolean basicMeasureWidgets(ConstraintWidgetContainer paramConstraintWidgetContainer) {
    // Byte code:
    //   0: aload_1
    //   1: getfield mChildren : Ljava/util/ArrayList;
    //   4: invokevirtual iterator : ()Ljava/util/Iterator;
    //   7: astore #11
    //   9: aload #11
    //   11: invokeinterface hasNext : ()Z
    //   16: ifeq -> 1595
    //   19: aload #11
    //   21: invokeinterface next : ()Ljava/lang/Object;
    //   26: checkcast androidx/constraintlayout/core/widgets/ConstraintWidget
    //   29: astore #12
    //   31: aload #12
    //   33: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   36: iconst_0
    //   37: aaload
    //   38: astore #9
    //   40: aload #12
    //   42: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   45: iconst_1
    //   46: aaload
    //   47: astore #10
    //   49: aload #12
    //   51: invokevirtual getVisibility : ()I
    //   54: bipush #8
    //   56: if_icmpne -> 68
    //   59: aload #12
    //   61: iconst_1
    //   62: putfield measured : Z
    //   65: goto -> 9
    //   68: aload #12
    //   70: getfield mMatchConstraintPercentWidth : F
    //   73: fconst_1
    //   74: fcmpg
    //   75: ifge -> 92
    //   78: aload #9
    //   80: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   83: if_acmpne -> 92
    //   86: aload #12
    //   88: iconst_2
    //   89: putfield mMatchConstraintDefaultWidth : I
    //   92: aload #12
    //   94: getfield mMatchConstraintPercentHeight : F
    //   97: fconst_1
    //   98: fcmpg
    //   99: ifge -> 116
    //   102: aload #10
    //   104: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   107: if_acmpne -> 116
    //   110: aload #12
    //   112: iconst_2
    //   113: putfield mMatchConstraintDefaultHeight : I
    //   116: aload #12
    //   118: invokevirtual getDimensionRatio : ()F
    //   121: fconst_0
    //   122: fcmpl
    //   123: ifle -> 236
    //   126: aload #9
    //   128: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   131: if_acmpne -> 159
    //   134: aload #10
    //   136: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   139: if_acmpeq -> 150
    //   142: aload #10
    //   144: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   147: if_acmpne -> 159
    //   150: aload #12
    //   152: iconst_3
    //   153: putfield mMatchConstraintDefaultWidth : I
    //   156: goto -> 236
    //   159: aload #10
    //   161: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   164: if_acmpne -> 192
    //   167: aload #9
    //   169: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   172: if_acmpeq -> 183
    //   175: aload #9
    //   177: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   180: if_acmpne -> 192
    //   183: aload #12
    //   185: iconst_3
    //   186: putfield mMatchConstraintDefaultHeight : I
    //   189: goto -> 236
    //   192: aload #9
    //   194: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   197: if_acmpne -> 236
    //   200: aload #10
    //   202: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   205: if_acmpne -> 236
    //   208: aload #12
    //   210: getfield mMatchConstraintDefaultWidth : I
    //   213: ifne -> 222
    //   216: aload #12
    //   218: iconst_3
    //   219: putfield mMatchConstraintDefaultWidth : I
    //   222: aload #12
    //   224: getfield mMatchConstraintDefaultHeight : I
    //   227: ifne -> 236
    //   230: aload #12
    //   232: iconst_3
    //   233: putfield mMatchConstraintDefaultHeight : I
    //   236: aload #9
    //   238: astore #8
    //   240: aload #9
    //   242: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   245: if_acmpne -> 292
    //   248: aload #9
    //   250: astore #8
    //   252: aload #12
    //   254: getfield mMatchConstraintDefaultWidth : I
    //   257: iconst_1
    //   258: if_icmpne -> 292
    //   261: aload #12
    //   263: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   266: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   269: ifnull -> 287
    //   272: aload #9
    //   274: astore #8
    //   276: aload #12
    //   278: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   281: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   284: ifnonnull -> 292
    //   287: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   290: astore #8
    //   292: aload #8
    //   294: astore #9
    //   296: aload #10
    //   298: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   301: if_acmpne -> 343
    //   304: aload #12
    //   306: getfield mMatchConstraintDefaultHeight : I
    //   309: iconst_1
    //   310: if_icmpne -> 343
    //   313: aload #12
    //   315: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   318: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   321: ifnull -> 335
    //   324: aload #12
    //   326: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   329: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   332: ifnonnull -> 343
    //   335: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   338: astore #8
    //   340: goto -> 347
    //   343: aload #10
    //   345: astore #8
    //   347: aload #12
    //   349: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   352: aload #9
    //   354: putfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   357: aload #12
    //   359: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   362: aload #12
    //   364: getfield mMatchConstraintDefaultWidth : I
    //   367: putfield matchConstraintsType : I
    //   370: aload #12
    //   372: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   375: aload #8
    //   377: putfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   380: aload #12
    //   382: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   385: aload #12
    //   387: getfield mMatchConstraintDefaultHeight : I
    //   390: putfield matchConstraintsType : I
    //   393: aload #9
    //   395: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   398: if_acmpeq -> 417
    //   401: aload #9
    //   403: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   406: if_acmpeq -> 417
    //   409: aload #9
    //   411: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   414: if_acmpne -> 444
    //   417: aload #8
    //   419: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   422: if_acmpeq -> 1422
    //   425: aload #8
    //   427: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   430: if_acmpeq -> 1422
    //   433: aload #8
    //   435: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   438: if_acmpne -> 444
    //   441: goto -> 1422
    //   444: aload #9
    //   446: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   449: if_acmpne -> 812
    //   452: aload #8
    //   454: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   457: if_acmpeq -> 468
    //   460: aload #8
    //   462: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   465: if_acmpne -> 812
    //   468: aload #12
    //   470: getfield mMatchConstraintDefaultWidth : I
    //   473: iconst_3
    //   474: if_icmpne -> 578
    //   477: aload #8
    //   479: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   482: if_acmpne -> 499
    //   485: aload_0
    //   486: aload #12
    //   488: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   491: iconst_0
    //   492: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   495: iconst_0
    //   496: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   499: aload #12
    //   501: invokevirtual getHeight : ()I
    //   504: istore #4
    //   506: iload #4
    //   508: i2f
    //   509: aload #12
    //   511: getfield mDimensionRatio : F
    //   514: fmul
    //   515: ldc 0.5
    //   517: fadd
    //   518: f2i
    //   519: istore #5
    //   521: aload_0
    //   522: aload #12
    //   524: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   527: iload #5
    //   529: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   532: iload #4
    //   534: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   537: aload #12
    //   539: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   542: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   545: aload #12
    //   547: invokevirtual getWidth : ()I
    //   550: invokevirtual resolve : (I)V
    //   553: aload #12
    //   555: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   558: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   561: aload #12
    //   563: invokevirtual getHeight : ()I
    //   566: invokevirtual resolve : (I)V
    //   569: aload #12
    //   571: iconst_1
    //   572: putfield measured : Z
    //   575: goto -> 9
    //   578: aload #12
    //   580: getfield mMatchConstraintDefaultWidth : I
    //   583: iconst_1
    //   584: if_icmpne -> 619
    //   587: aload_0
    //   588: aload #12
    //   590: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   593: iconst_0
    //   594: aload #8
    //   596: iconst_0
    //   597: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   600: aload #12
    //   602: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   605: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   608: aload #12
    //   610: invokevirtual getWidth : ()I
    //   613: putfield wrapValue : I
    //   616: goto -> 9
    //   619: aload #12
    //   621: getfield mMatchConstraintDefaultWidth : I
    //   624: iconst_2
    //   625: if_icmpne -> 732
    //   628: aload_1
    //   629: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   632: iconst_0
    //   633: aaload
    //   634: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   637: if_acmpeq -> 652
    //   640: aload_1
    //   641: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   644: iconst_0
    //   645: aaload
    //   646: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   649: if_acmpne -> 812
    //   652: aload #12
    //   654: getfield mMatchConstraintPercentWidth : F
    //   657: aload_1
    //   658: invokevirtual getWidth : ()I
    //   661: i2f
    //   662: fmul
    //   663: ldc 0.5
    //   665: fadd
    //   666: f2i
    //   667: istore #4
    //   669: aload #12
    //   671: invokevirtual getHeight : ()I
    //   674: istore #5
    //   676: aload_0
    //   677: aload #12
    //   679: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   682: iload #4
    //   684: aload #8
    //   686: iload #5
    //   688: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   691: aload #12
    //   693: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   696: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   699: aload #12
    //   701: invokevirtual getWidth : ()I
    //   704: invokevirtual resolve : (I)V
    //   707: aload #12
    //   709: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   712: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   715: aload #12
    //   717: invokevirtual getHeight : ()I
    //   720: invokevirtual resolve : (I)V
    //   723: aload #12
    //   725: iconst_1
    //   726: putfield measured : Z
    //   729: goto -> 9
    //   732: aload #12
    //   734: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   737: iconst_0
    //   738: aaload
    //   739: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   742: ifnull -> 758
    //   745: aload #12
    //   747: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   750: iconst_1
    //   751: aaload
    //   752: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   755: ifnonnull -> 812
    //   758: aload_0
    //   759: aload #12
    //   761: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   764: iconst_0
    //   765: aload #8
    //   767: iconst_0
    //   768: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   771: aload #12
    //   773: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   776: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   779: aload #12
    //   781: invokevirtual getWidth : ()I
    //   784: invokevirtual resolve : (I)V
    //   787: aload #12
    //   789: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   792: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   795: aload #12
    //   797: invokevirtual getHeight : ()I
    //   800: invokevirtual resolve : (I)V
    //   803: aload #12
    //   805: iconst_1
    //   806: putfield measured : Z
    //   809: goto -> 9
    //   812: aload #8
    //   814: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   817: if_acmpne -> 1199
    //   820: aload #9
    //   822: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   825: if_acmpeq -> 836
    //   828: aload #9
    //   830: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   833: if_acmpne -> 1199
    //   836: aload #12
    //   838: getfield mMatchConstraintDefaultHeight : I
    //   841: iconst_3
    //   842: if_icmpne -> 963
    //   845: aload #9
    //   847: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   850: if_acmpne -> 867
    //   853: aload_0
    //   854: aload #12
    //   856: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   859: iconst_0
    //   860: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   863: iconst_0
    //   864: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   867: aload #12
    //   869: invokevirtual getWidth : ()I
    //   872: istore #4
    //   874: aload #12
    //   876: getfield mDimensionRatio : F
    //   879: fstore_3
    //   880: fload_3
    //   881: fstore_2
    //   882: aload #12
    //   884: invokevirtual getDimensionRatioSide : ()I
    //   887: iconst_m1
    //   888: if_icmpne -> 895
    //   891: fconst_1
    //   892: fload_3
    //   893: fdiv
    //   894: fstore_2
    //   895: iload #4
    //   897: i2f
    //   898: fload_2
    //   899: fmul
    //   900: ldc 0.5
    //   902: fadd
    //   903: f2i
    //   904: istore #5
    //   906: aload_0
    //   907: aload #12
    //   909: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   912: iload #4
    //   914: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   917: iload #5
    //   919: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   922: aload #12
    //   924: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   927: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   930: aload #12
    //   932: invokevirtual getWidth : ()I
    //   935: invokevirtual resolve : (I)V
    //   938: aload #12
    //   940: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   943: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   946: aload #12
    //   948: invokevirtual getHeight : ()I
    //   951: invokevirtual resolve : (I)V
    //   954: aload #12
    //   956: iconst_1
    //   957: putfield measured : Z
    //   960: goto -> 9
    //   963: aload #12
    //   965: getfield mMatchConstraintDefaultHeight : I
    //   968: iconst_1
    //   969: if_icmpne -> 1004
    //   972: aload_0
    //   973: aload #12
    //   975: aload #9
    //   977: iconst_0
    //   978: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   981: iconst_0
    //   982: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   985: aload #12
    //   987: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   990: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   993: aload #12
    //   995: invokevirtual getHeight : ()I
    //   998: putfield wrapValue : I
    //   1001: goto -> 9
    //   1004: aload #12
    //   1006: getfield mMatchConstraintDefaultHeight : I
    //   1009: iconst_2
    //   1010: if_icmpne -> 1119
    //   1013: aload_1
    //   1014: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1017: iconst_1
    //   1018: aaload
    //   1019: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1022: if_acmpeq -> 1037
    //   1025: aload_1
    //   1026: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1029: iconst_1
    //   1030: aaload
    //   1031: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1034: if_acmpne -> 1199
    //   1037: aload #12
    //   1039: getfield mMatchConstraintPercentHeight : F
    //   1042: fstore_2
    //   1043: aload #12
    //   1045: invokevirtual getWidth : ()I
    //   1048: istore #4
    //   1050: fload_2
    //   1051: aload_1
    //   1052: invokevirtual getHeight : ()I
    //   1055: i2f
    //   1056: fmul
    //   1057: ldc 0.5
    //   1059: fadd
    //   1060: f2i
    //   1061: istore #5
    //   1063: aload_0
    //   1064: aload #12
    //   1066: aload #9
    //   1068: iload #4
    //   1070: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1073: iload #5
    //   1075: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1078: aload #12
    //   1080: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1083: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1086: aload #12
    //   1088: invokevirtual getWidth : ()I
    //   1091: invokevirtual resolve : (I)V
    //   1094: aload #12
    //   1096: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1099: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1102: aload #12
    //   1104: invokevirtual getHeight : ()I
    //   1107: invokevirtual resolve : (I)V
    //   1110: aload #12
    //   1112: iconst_1
    //   1113: putfield measured : Z
    //   1116: goto -> 9
    //   1119: aload #12
    //   1121: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1124: iconst_2
    //   1125: aaload
    //   1126: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1129: ifnull -> 1145
    //   1132: aload #12
    //   1134: getfield mListAnchors : [Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1137: iconst_3
    //   1138: aaload
    //   1139: getfield mTarget : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1142: ifnonnull -> 1199
    //   1145: aload_0
    //   1146: aload #12
    //   1148: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1151: iconst_0
    //   1152: aload #8
    //   1154: iconst_0
    //   1155: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1158: aload #12
    //   1160: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1163: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1166: aload #12
    //   1168: invokevirtual getWidth : ()I
    //   1171: invokevirtual resolve : (I)V
    //   1174: aload #12
    //   1176: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1179: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1182: aload #12
    //   1184: invokevirtual getHeight : ()I
    //   1187: invokevirtual resolve : (I)V
    //   1190: aload #12
    //   1192: iconst_1
    //   1193: putfield measured : Z
    //   1196: goto -> 9
    //   1199: aload #9
    //   1201: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1204: if_acmpne -> 9
    //   1207: aload #8
    //   1209: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1212: if_acmpne -> 9
    //   1215: aload #12
    //   1217: getfield mMatchConstraintDefaultWidth : I
    //   1220: iconst_1
    //   1221: if_icmpeq -> 1373
    //   1224: aload #12
    //   1226: getfield mMatchConstraintDefaultHeight : I
    //   1229: iconst_1
    //   1230: if_icmpne -> 1236
    //   1233: goto -> 1373
    //   1236: aload #12
    //   1238: getfield mMatchConstraintDefaultHeight : I
    //   1241: iconst_2
    //   1242: if_icmpne -> 9
    //   1245: aload #12
    //   1247: getfield mMatchConstraintDefaultWidth : I
    //   1250: iconst_2
    //   1251: if_icmpne -> 9
    //   1254: aload_1
    //   1255: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1258: iconst_0
    //   1259: aaload
    //   1260: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1263: if_acmpne -> 9
    //   1266: aload_1
    //   1267: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1270: iconst_1
    //   1271: aaload
    //   1272: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1275: if_acmpne -> 9
    //   1278: aload #12
    //   1280: getfield mMatchConstraintPercentWidth : F
    //   1283: fstore_2
    //   1284: aload #12
    //   1286: getfield mMatchConstraintPercentHeight : F
    //   1289: fstore_3
    //   1290: fload_2
    //   1291: aload_1
    //   1292: invokevirtual getWidth : ()I
    //   1295: i2f
    //   1296: fmul
    //   1297: ldc 0.5
    //   1299: fadd
    //   1300: f2i
    //   1301: istore #4
    //   1303: fload_3
    //   1304: aload_1
    //   1305: invokevirtual getHeight : ()I
    //   1308: i2f
    //   1309: fmul
    //   1310: ldc 0.5
    //   1312: fadd
    //   1313: f2i
    //   1314: istore #5
    //   1316: aload_0
    //   1317: aload #12
    //   1319: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1322: iload #4
    //   1324: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1327: iload #5
    //   1329: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1332: aload #12
    //   1334: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1337: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1340: aload #12
    //   1342: invokevirtual getWidth : ()I
    //   1345: invokevirtual resolve : (I)V
    //   1348: aload #12
    //   1350: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1353: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1356: aload #12
    //   1358: invokevirtual getHeight : ()I
    //   1361: invokevirtual resolve : (I)V
    //   1364: aload #12
    //   1366: iconst_1
    //   1367: putfield measured : Z
    //   1370: goto -> 9
    //   1373: aload_0
    //   1374: aload #12
    //   1376: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1379: iconst_0
    //   1380: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1383: iconst_0
    //   1384: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1387: aload #12
    //   1389: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1392: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1395: aload #12
    //   1397: invokevirtual getWidth : ()I
    //   1400: putfield wrapValue : I
    //   1403: aload #12
    //   1405: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1408: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1411: aload #12
    //   1413: invokevirtual getHeight : ()I
    //   1416: putfield wrapValue : I
    //   1419: goto -> 9
    //   1422: aload #12
    //   1424: invokevirtual getWidth : ()I
    //   1427: istore #4
    //   1429: aload #9
    //   1431: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1434: if_acmpne -> 1481
    //   1437: aload_1
    //   1438: invokevirtual getWidth : ()I
    //   1441: istore #4
    //   1443: aload #12
    //   1445: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1448: getfield mMargin : I
    //   1451: istore #5
    //   1453: aload #12
    //   1455: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1458: getfield mMargin : I
    //   1461: istore #6
    //   1463: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1466: astore #9
    //   1468: iload #4
    //   1470: iload #5
    //   1472: isub
    //   1473: iload #6
    //   1475: isub
    //   1476: istore #4
    //   1478: goto -> 1481
    //   1481: aload #12
    //   1483: invokevirtual getHeight : ()I
    //   1486: istore #5
    //   1488: aload #8
    //   1490: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1493: if_acmpne -> 1540
    //   1496: aload_1
    //   1497: invokevirtual getHeight : ()I
    //   1500: istore #5
    //   1502: aload #12
    //   1504: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1507: getfield mMargin : I
    //   1510: istore #6
    //   1512: aload #12
    //   1514: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
    //   1517: getfield mMargin : I
    //   1520: istore #7
    //   1522: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1525: astore #8
    //   1527: iload #5
    //   1529: iload #6
    //   1531: isub
    //   1532: iload #7
    //   1534: isub
    //   1535: istore #5
    //   1537: goto -> 1540
    //   1540: aload_0
    //   1541: aload #12
    //   1543: aload #9
    //   1545: iload #4
    //   1547: aload #8
    //   1549: iload #5
    //   1551: invokespecial measure : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;ILandroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;I)V
    //   1554: aload #12
    //   1556: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   1559: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1562: aload #12
    //   1564: invokevirtual getWidth : ()I
    //   1567: invokevirtual resolve : (I)V
    //   1570: aload #12
    //   1572: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   1575: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1578: aload #12
    //   1580: invokevirtual getHeight : ()I
    //   1583: invokevirtual resolve : (I)V
    //   1586: aload #12
    //   1588: iconst_1
    //   1589: putfield measured : Z
    //   1592: goto -> 9
    //   1595: iconst_0
    //   1596: ireturn
  }
  
  private int computeWrap(ConstraintWidgetContainer paramConstraintWidgetContainer, int paramInt) {
    int j = this.mGroups.size();
    long l = 0L;
    for (int i = 0; i < j; i++)
      l = Math.max(l, ((RunGroup)this.mGroups.get(i)).computeWrapSize(paramConstraintWidgetContainer, paramInt)); 
    return (int)l;
  }
  
  private void displayGraph() {
    Iterator<WidgetRun> iterator = this.mRuns.iterator();
    String str;
    for (str = "digraph {\n"; iterator.hasNext(); str = generateDisplayGraph(iterator.next(), str));
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(str);
    stringBuilder1.append("\n}\n");
    str = stringBuilder1.toString();
    PrintStream printStream = System.out;
    StringBuilder stringBuilder2 = new StringBuilder("content:<<\n");
    stringBuilder2.append(str);
    stringBuilder2.append("\n>>");
    printStream.println(stringBuilder2.toString());
  }
  
  private void findGroup(WidgetRun paramWidgetRun, int paramInt, ArrayList<RunGroup> paramArrayList) {
    for (Dependency dependency : paramWidgetRun.start.dependencies) {
      if (dependency instanceof DependencyNode) {
        applyGroup((DependencyNode)dependency, paramInt, 0, paramWidgetRun.end, paramArrayList, null);
        continue;
      } 
      if (dependency instanceof WidgetRun)
        applyGroup(((WidgetRun)dependency).start, paramInt, 0, paramWidgetRun.end, paramArrayList, null); 
    } 
    for (Dependency dependency : paramWidgetRun.end.dependencies) {
      if (dependency instanceof DependencyNode) {
        applyGroup((DependencyNode)dependency, paramInt, 1, paramWidgetRun.start, paramArrayList, null);
        continue;
      } 
      if (dependency instanceof WidgetRun)
        applyGroup(((WidgetRun)dependency).end, paramInt, 1, paramWidgetRun.start, paramArrayList, null); 
    } 
    if (paramInt == 1)
      for (Dependency dependency : ((VerticalWidgetRun)paramWidgetRun).baseline.dependencies) {
        if (dependency instanceof DependencyNode)
          applyGroup((DependencyNode)dependency, paramInt, 2, null, paramArrayList, null); 
      }  
  }
  
  private String generateChainDisplayGraph(ChainRun paramChainRun, String paramString) {
    int i = paramChainRun.orientation;
    StringBuilder stringBuilder1 = new StringBuilder("subgraph cluster_");
    stringBuilder1.append(paramChainRun.widget.getDebugName());
    if (i == 0) {
      stringBuilder1.append("_h");
    } else {
      stringBuilder1.append("_v");
    } 
    stringBuilder1.append(" {\n");
    Iterator<WidgetRun> iterator = paramChainRun.widgets.iterator();
    String str;
    for (str = ""; iterator.hasNext(); str = generateDisplayGraph(widgetRun, str)) {
      WidgetRun widgetRun = iterator.next();
      stringBuilder1.append(widgetRun.widget.getDebugName());
      if (i == 0) {
        stringBuilder1.append("_HORIZONTAL");
      } else {
        stringBuilder1.append("_VERTICAL");
      } 
      stringBuilder1.append(";\n");
    } 
    stringBuilder1.append("}\n");
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append(str);
    stringBuilder2.append(stringBuilder1);
    return stringBuilder2.toString();
  }
  
  private String generateDisplayGraph(WidgetRun paramWidgetRun, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   4: astore #6
    //   6: aload_1
    //   7: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   10: astore #7
    //   12: new java/lang/StringBuilder
    //   15: dup
    //   16: aload_2
    //   17: invokespecial <init> : (Ljava/lang/String;)V
    //   20: astore #8
    //   22: aload_1
    //   23: instanceof androidx/constraintlayout/core/widgets/analyzer/HelperReferences
    //   26: ifne -> 81
    //   29: aload #6
    //   31: getfield dependencies : Ljava/util/List;
    //   34: invokeinterface isEmpty : ()Z
    //   39: ifeq -> 81
    //   42: aload #7
    //   44: getfield dependencies : Ljava/util/List;
    //   47: invokeinterface isEmpty : ()Z
    //   52: aload #6
    //   54: getfield targets : Ljava/util/List;
    //   57: invokeinterface isEmpty : ()Z
    //   62: iand
    //   63: ifeq -> 81
    //   66: aload #7
    //   68: getfield targets : Ljava/util/List;
    //   71: invokeinterface isEmpty : ()Z
    //   76: ifeq -> 81
    //   79: aload_2
    //   80: areturn
    //   81: aload #8
    //   83: aload_0
    //   84: aload_1
    //   85: invokespecial nodeDefinition : (Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;)Ljava/lang/String;
    //   88: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: pop
    //   92: aload_0
    //   93: aload #6
    //   95: aload #7
    //   97: invokespecial isCenteredConnection : (Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;)Z
    //   100: istore #4
    //   102: aload_0
    //   103: aload #7
    //   105: iload #4
    //   107: aload_0
    //   108: aload #6
    //   110: iload #4
    //   112: aload_2
    //   113: invokespecial generateDisplayNode : (Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;ZLjava/lang/String;)Ljava/lang/String;
    //   116: invokespecial generateDisplayNode : (Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;ZLjava/lang/String;)Ljava/lang/String;
    //   119: astore #5
    //   121: aload_1
    //   122: instanceof androidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun
    //   125: istore_3
    //   126: aload #5
    //   128: astore_2
    //   129: iload_3
    //   130: ifeq -> 149
    //   133: aload_0
    //   134: aload_1
    //   135: checkcast androidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun
    //   138: getfield baseline : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   141: iload #4
    //   143: aload #5
    //   145: invokespecial generateDisplayNode : (Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;ZLjava/lang/String;)Ljava/lang/String;
    //   148: astore_2
    //   149: aload_1
    //   150: instanceof androidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun
    //   153: ifne -> 460
    //   156: aload_1
    //   157: instanceof androidx/constraintlayout/core/widgets/analyzer/ChainRun
    //   160: istore #4
    //   162: iload #4
    //   164: ifeq -> 180
    //   167: aload_1
    //   168: checkcast androidx/constraintlayout/core/widgets/analyzer/ChainRun
    //   171: getfield orientation : I
    //   174: ifne -> 180
    //   177: goto -> 460
    //   180: iload_3
    //   181: ifne -> 200
    //   184: iload #4
    //   186: ifeq -> 717
    //   189: aload_1
    //   190: checkcast androidx/constraintlayout/core/widgets/analyzer/ChainRun
    //   193: getfield orientation : I
    //   196: iconst_1
    //   197: if_icmpne -> 717
    //   200: aload_1
    //   201: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   204: invokevirtual getVerticalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   207: astore #5
    //   209: aload #5
    //   211: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   214: if_acmpeq -> 304
    //   217: aload #5
    //   219: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   222: if_acmpne -> 228
    //   225: goto -> 304
    //   228: aload #5
    //   230: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   233: if_acmpne -> 717
    //   236: aload_1
    //   237: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   240: invokevirtual getDimensionRatio : ()F
    //   243: fconst_0
    //   244: fcmpl
    //   245: ifle -> 717
    //   248: aload #8
    //   250: ldc_w '\\n'
    //   253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   256: pop
    //   257: aload #8
    //   259: aload_1
    //   260: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   263: invokevirtual getDebugName : ()Ljava/lang/String;
    //   266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   269: pop
    //   270: aload #8
    //   272: ldc_w '_VERTICAL -> '
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: pop
    //   279: aload #8
    //   281: aload_1
    //   282: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   285: invokevirtual getDebugName : ()Ljava/lang/String;
    //   288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   291: pop
    //   292: aload #8
    //   294: ldc_w '_HORIZONTAL;\\n'
    //   297: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: pop
    //   301: goto -> 717
    //   304: aload #6
    //   306: getfield targets : Ljava/util/List;
    //   309: invokeinterface isEmpty : ()Z
    //   314: ifne -> 382
    //   317: aload #7
    //   319: getfield targets : Ljava/util/List;
    //   322: invokeinterface isEmpty : ()Z
    //   327: ifeq -> 382
    //   330: aload #8
    //   332: ldc_w '\\n'
    //   335: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   338: pop
    //   339: aload #8
    //   341: aload #7
    //   343: invokevirtual name : ()Ljava/lang/String;
    //   346: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   349: pop
    //   350: aload #8
    //   352: ldc_w ' -> '
    //   355: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   358: pop
    //   359: aload #8
    //   361: aload #6
    //   363: invokevirtual name : ()Ljava/lang/String;
    //   366: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   369: pop
    //   370: aload #8
    //   372: ldc_w '\\n'
    //   375: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   378: pop
    //   379: goto -> 717
    //   382: aload #6
    //   384: getfield targets : Ljava/util/List;
    //   387: invokeinterface isEmpty : ()Z
    //   392: ifeq -> 717
    //   395: aload #7
    //   397: getfield targets : Ljava/util/List;
    //   400: invokeinterface isEmpty : ()Z
    //   405: ifne -> 717
    //   408: aload #8
    //   410: ldc_w '\\n'
    //   413: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   416: pop
    //   417: aload #8
    //   419: aload #6
    //   421: invokevirtual name : ()Ljava/lang/String;
    //   424: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   427: pop
    //   428: aload #8
    //   430: ldc_w ' -> '
    //   433: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   436: pop
    //   437: aload #8
    //   439: aload #7
    //   441: invokevirtual name : ()Ljava/lang/String;
    //   444: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   447: pop
    //   448: aload #8
    //   450: ldc_w '\\n'
    //   453: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   456: pop
    //   457: goto -> 717
    //   460: aload_1
    //   461: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   464: invokevirtual getHorizontalDimensionBehaviour : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   467: astore #5
    //   469: aload #5
    //   471: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   474: if_acmpeq -> 564
    //   477: aload #5
    //   479: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   482: if_acmpne -> 488
    //   485: goto -> 564
    //   488: aload #5
    //   490: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   493: if_acmpne -> 717
    //   496: aload_1
    //   497: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   500: invokevirtual getDimensionRatio : ()F
    //   503: fconst_0
    //   504: fcmpl
    //   505: ifle -> 717
    //   508: aload #8
    //   510: ldc_w '\\n'
    //   513: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   516: pop
    //   517: aload #8
    //   519: aload_1
    //   520: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   523: invokevirtual getDebugName : ()Ljava/lang/String;
    //   526: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   529: pop
    //   530: aload #8
    //   532: ldc_w '_HORIZONTAL -> '
    //   535: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   538: pop
    //   539: aload #8
    //   541: aload_1
    //   542: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   545: invokevirtual getDebugName : ()Ljava/lang/String;
    //   548: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   551: pop
    //   552: aload #8
    //   554: ldc_w '_VERTICAL;\\n'
    //   557: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   560: pop
    //   561: goto -> 717
    //   564: aload #6
    //   566: getfield targets : Ljava/util/List;
    //   569: invokeinterface isEmpty : ()Z
    //   574: ifne -> 642
    //   577: aload #7
    //   579: getfield targets : Ljava/util/List;
    //   582: invokeinterface isEmpty : ()Z
    //   587: ifeq -> 642
    //   590: aload #8
    //   592: ldc_w '\\n'
    //   595: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   598: pop
    //   599: aload #8
    //   601: aload #7
    //   603: invokevirtual name : ()Ljava/lang/String;
    //   606: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   609: pop
    //   610: aload #8
    //   612: ldc_w ' -> '
    //   615: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   618: pop
    //   619: aload #8
    //   621: aload #6
    //   623: invokevirtual name : ()Ljava/lang/String;
    //   626: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   629: pop
    //   630: aload #8
    //   632: ldc_w '\\n'
    //   635: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   638: pop
    //   639: goto -> 717
    //   642: aload #6
    //   644: getfield targets : Ljava/util/List;
    //   647: invokeinterface isEmpty : ()Z
    //   652: ifeq -> 717
    //   655: aload #7
    //   657: getfield targets : Ljava/util/List;
    //   660: invokeinterface isEmpty : ()Z
    //   665: ifne -> 717
    //   668: aload #8
    //   670: ldc_w '\\n'
    //   673: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   676: pop
    //   677: aload #8
    //   679: aload #6
    //   681: invokevirtual name : ()Ljava/lang/String;
    //   684: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   687: pop
    //   688: aload #8
    //   690: ldc_w ' -> '
    //   693: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   696: pop
    //   697: aload #8
    //   699: aload #7
    //   701: invokevirtual name : ()Ljava/lang/String;
    //   704: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   707: pop
    //   708: aload #8
    //   710: ldc_w '\\n'
    //   713: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   716: pop
    //   717: aload_1
    //   718: instanceof androidx/constraintlayout/core/widgets/analyzer/ChainRun
    //   721: ifeq -> 734
    //   724: aload_0
    //   725: aload_1
    //   726: checkcast androidx/constraintlayout/core/widgets/analyzer/ChainRun
    //   729: aload_2
    //   730: invokespecial generateChainDisplayGraph : (Landroidx/constraintlayout/core/widgets/analyzer/ChainRun;Ljava/lang/String;)Ljava/lang/String;
    //   733: areturn
    //   734: aload #8
    //   736: invokevirtual toString : ()Ljava/lang/String;
    //   739: areturn
  }
  
  private String generateDisplayNode(DependencyNode paramDependencyNode, boolean paramBoolean, String paramString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: aload_3
    //   5: invokespecial <init> : (Ljava/lang/String;)V
    //   8: astore #5
    //   10: aload_1
    //   11: getfield targets : Ljava/util/List;
    //   14: invokeinterface iterator : ()Ljava/util/Iterator;
    //   19: astore #6
    //   21: aload #6
    //   23: invokeinterface hasNext : ()Z
    //   28: ifeq -> 408
    //   31: aload #6
    //   33: invokeinterface next : ()Ljava/lang/Object;
    //   38: checkcast androidx/constraintlayout/core/widgets/analyzer/DependencyNode
    //   41: astore_3
    //   42: new java/lang/StringBuilder
    //   45: dup
    //   46: ldc_w '\\n'
    //   49: invokespecial <init> : (Ljava/lang/String;)V
    //   52: astore #4
    //   54: aload #4
    //   56: aload_1
    //   57: invokevirtual name : ()Ljava/lang/String;
    //   60: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: pop
    //   64: aload #4
    //   66: invokevirtual toString : ()Ljava/lang/String;
    //   69: astore #4
    //   71: new java/lang/StringBuilder
    //   74: dup
    //   75: invokespecial <init> : ()V
    //   78: astore #7
    //   80: aload #7
    //   82: aload #4
    //   84: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   87: pop
    //   88: aload #7
    //   90: ldc_w ' -> '
    //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: pop
    //   97: aload #7
    //   99: aload_3
    //   100: invokevirtual name : ()Ljava/lang/String;
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: pop
    //   107: aload #7
    //   109: invokevirtual toString : ()Ljava/lang/String;
    //   112: astore #4
    //   114: aload_1
    //   115: getfield margin : I
    //   118: ifgt -> 138
    //   121: iload_2
    //   122: ifne -> 138
    //   125: aload #4
    //   127: astore_3
    //   128: aload_1
    //   129: getfield run : Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;
    //   132: instanceof androidx/constraintlayout/core/widgets/analyzer/HelperReferences
    //   135: ifeq -> 369
    //   138: new java/lang/StringBuilder
    //   141: dup
    //   142: invokespecial <init> : ()V
    //   145: astore_3
    //   146: aload_3
    //   147: aload #4
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: pop
    //   153: aload_3
    //   154: ldc_w '['
    //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: pop
    //   161: aload_3
    //   162: invokevirtual toString : ()Ljava/lang/String;
    //   165: astore #4
    //   167: aload #4
    //   169: astore_3
    //   170: aload_1
    //   171: getfield margin : I
    //   174: ifle -> 258
    //   177: new java/lang/StringBuilder
    //   180: dup
    //   181: invokespecial <init> : ()V
    //   184: astore_3
    //   185: aload_3
    //   186: aload #4
    //   188: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: pop
    //   192: aload_3
    //   193: ldc_w 'label="'
    //   196: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   199: pop
    //   200: aload_3
    //   201: aload_1
    //   202: getfield margin : I
    //   205: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   208: pop
    //   209: aload_3
    //   210: ldc_w '"'
    //   213: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   216: pop
    //   217: aload_3
    //   218: invokevirtual toString : ()Ljava/lang/String;
    //   221: astore #4
    //   223: aload #4
    //   225: astore_3
    //   226: iload_2
    //   227: ifeq -> 258
    //   230: new java/lang/StringBuilder
    //   233: dup
    //   234: invokespecial <init> : ()V
    //   237: astore_3
    //   238: aload_3
    //   239: aload #4
    //   241: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   244: pop
    //   245: aload_3
    //   246: ldc_w ','
    //   249: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: pop
    //   253: aload_3
    //   254: invokevirtual toString : ()Ljava/lang/String;
    //   257: astore_3
    //   258: aload_3
    //   259: astore #4
    //   261: iload_2
    //   262: ifeq -> 297
    //   265: new java/lang/StringBuilder
    //   268: dup
    //   269: invokespecial <init> : ()V
    //   272: astore #4
    //   274: aload #4
    //   276: aload_3
    //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: pop
    //   281: aload #4
    //   283: ldc_w ' style=dashed '
    //   286: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   289: pop
    //   290: aload #4
    //   292: invokevirtual toString : ()Ljava/lang/String;
    //   295: astore #4
    //   297: aload #4
    //   299: astore_3
    //   300: aload_1
    //   301: getfield run : Landroidx/constraintlayout/core/widgets/analyzer/WidgetRun;
    //   304: instanceof androidx/constraintlayout/core/widgets/analyzer/HelperReferences
    //   307: ifeq -> 338
    //   310: new java/lang/StringBuilder
    //   313: dup
    //   314: invokespecial <init> : ()V
    //   317: astore_3
    //   318: aload_3
    //   319: aload #4
    //   321: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   324: pop
    //   325: aload_3
    //   326: ldc_w ' style=bold,color=gray '
    //   329: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   332: pop
    //   333: aload_3
    //   334: invokevirtual toString : ()Ljava/lang/String;
    //   337: astore_3
    //   338: new java/lang/StringBuilder
    //   341: dup
    //   342: invokespecial <init> : ()V
    //   345: astore #4
    //   347: aload #4
    //   349: aload_3
    //   350: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   353: pop
    //   354: aload #4
    //   356: ldc_w ']'
    //   359: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: pop
    //   363: aload #4
    //   365: invokevirtual toString : ()Ljava/lang/String;
    //   368: astore_3
    //   369: new java/lang/StringBuilder
    //   372: dup
    //   373: invokespecial <init> : ()V
    //   376: astore #4
    //   378: aload #4
    //   380: aload_3
    //   381: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: aload #4
    //   387: ldc_w '\\n'
    //   390: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   393: pop
    //   394: aload #5
    //   396: aload #4
    //   398: invokevirtual toString : ()Ljava/lang/String;
    //   401: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   404: pop
    //   405: goto -> 21
    //   408: aload #5
    //   410: invokevirtual toString : ()Ljava/lang/String;
    //   413: areturn
  }
  
  private boolean isCenteredConnection(DependencyNode paramDependencyNode1, DependencyNode paramDependencyNode2) {
    Iterator<DependencyNode> iterator2 = paramDependencyNode1.targets.iterator();
    boolean bool2 = false;
    int i = 0;
    while (iterator2.hasNext()) {
      if ((DependencyNode)iterator2.next() != paramDependencyNode2)
        i++; 
    } 
    Iterator<DependencyNode> iterator1 = paramDependencyNode2.targets.iterator();
    int j = 0;
    while (iterator1.hasNext()) {
      if ((DependencyNode)iterator1.next() != paramDependencyNode1)
        j++; 
    } 
    boolean bool1 = bool2;
    if (i > 0) {
      bool1 = bool2;
      if (j > 0)
        bool1 = true; 
    } 
    return bool1;
  }
  
  private void measure(ConstraintWidget paramConstraintWidget, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour1, int paramInt1, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour2, int paramInt2) {
    this.mMeasure.horizontalBehavior = paramDimensionBehaviour1;
    this.mMeasure.verticalBehavior = paramDimensionBehaviour2;
    this.mMeasure.horizontalDimension = paramInt1;
    this.mMeasure.verticalDimension = paramInt2;
    this.mMeasurer.measure(paramConstraintWidget, this.mMeasure);
    paramConstraintWidget.setWidth(this.mMeasure.measuredWidth);
    paramConstraintWidget.setHeight(this.mMeasure.measuredHeight);
    paramConstraintWidget.setHasBaseline(this.mMeasure.measuredHasBaseline);
    paramConstraintWidget.setBaselineDistance(this.mMeasure.measuredBaseline);
  }
  
  private String nodeDefinition(WidgetRun paramWidgetRun) {
    ConstraintWidget.DimensionBehaviour dimensionBehaviour;
    boolean bool = paramWidgetRun instanceof VerticalWidgetRun;
    String str = paramWidgetRun.widget.getDebugName();
    StringBuilder stringBuilder = new StringBuilder(str);
    ConstraintWidget constraintWidget = paramWidgetRun.widget;
    if (!bool) {
      dimensionBehaviour = constraintWidget.getHorizontalDimensionBehaviour();
    } else {
      dimensionBehaviour = dimensionBehaviour.getVerticalDimensionBehaviour();
    } 
    RunGroup runGroup = paramWidgetRun.runGroup;
    if (!bool) {
      stringBuilder.append("_HORIZONTAL");
    } else {
      stringBuilder.append("_VERTICAL");
    } 
    stringBuilder.append(" [shape=none, label=<<TABLE BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"2\">  <TR>");
    if (!bool) {
      stringBuilder.append("    <TD ");
      if (paramWidgetRun.start.resolved)
        stringBuilder.append(" BGCOLOR=\"green\""); 
      stringBuilder.append(" PORT=\"LEFT\" BORDER=\"1\">L</TD>");
    } else {
      stringBuilder.append("    <TD ");
      if (paramWidgetRun.start.resolved)
        stringBuilder.append(" BGCOLOR=\"green\""); 
      stringBuilder.append(" PORT=\"TOP\" BORDER=\"1\">T</TD>");
    } 
    stringBuilder.append("    <TD BORDER=\"1\" ");
    if (paramWidgetRun.dimension.resolved && !paramWidgetRun.widget.measured) {
      stringBuilder.append(" BGCOLOR=\"green\" ");
    } else if (paramWidgetRun.dimension.resolved) {
      stringBuilder.append(" BGCOLOR=\"lightgray\" ");
    } else if (paramWidgetRun.widget.measured) {
      stringBuilder.append(" BGCOLOR=\"yellow\" ");
    } 
    if (dimensionBehaviour == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
      stringBuilder.append("style=\"dashed\""); 
    stringBuilder.append(">");
    stringBuilder.append(str);
    if (runGroup != null) {
      stringBuilder.append(" [");
      stringBuilder.append(runGroup.groupIndex + 1);
      stringBuilder.append("/");
      stringBuilder.append(RunGroup.index);
      stringBuilder.append("]");
    } 
    stringBuilder.append(" </TD>");
    if (!bool) {
      stringBuilder.append("    <TD ");
      if (paramWidgetRun.end.resolved)
        stringBuilder.append(" BGCOLOR=\"green\""); 
      stringBuilder.append(" PORT=\"RIGHT\" BORDER=\"1\">R</TD>");
    } else {
      stringBuilder.append("    <TD ");
      if (((VerticalWidgetRun)paramWidgetRun).baseline.resolved)
        stringBuilder.append(" BGCOLOR=\"green\""); 
      stringBuilder.append(" PORT=\"BASELINE\" BORDER=\"1\">b</TD>    <TD ");
      if (paramWidgetRun.end.resolved)
        stringBuilder.append(" BGCOLOR=\"green\""); 
      stringBuilder.append(" PORT=\"BOTTOM\" BORDER=\"1\">B</TD>");
    } 
    stringBuilder.append("  </TR></TABLE>>];\n");
    return stringBuilder.toString();
  }
  
  public void buildGraph() {
    buildGraph(this.mRuns);
    this.mGroups.clear();
    RunGroup.index = 0;
    findGroup(this.container.horizontalRun, 0, this.mGroups);
    findGroup(this.container.verticalRun, 1, this.mGroups);
    this.mNeedBuildGraph = false;
  }
  
  public void buildGraph(ArrayList<WidgetRun> paramArrayList) {
    paramArrayList.clear();
    this.mContainer.horizontalRun.clear();
    this.mContainer.verticalRun.clear();
    paramArrayList.add(this.mContainer.horizontalRun);
    paramArrayList.add(this.mContainer.verticalRun);
    Iterator<ConstraintWidget> iterator1 = this.mContainer.mChildren.iterator();
    HashSet<ChainRun> hashSet = null;
    while (iterator1.hasNext()) {
      HashSet<ChainRun> hashSet1;
      ConstraintWidget constraintWidget = iterator1.next();
      if (constraintWidget instanceof androidx.constraintlayout.core.widgets.Guideline) {
        paramArrayList.add(new GuidelineReference(constraintWidget));
        continue;
      } 
      if (constraintWidget.isInHorizontalChain()) {
        if (constraintWidget.horizontalChainRun == null)
          constraintWidget.horizontalChainRun = new ChainRun(constraintWidget, 0); 
        hashSet1 = hashSet;
        if (hashSet == null)
          hashSet1 = new HashSet(); 
        hashSet1.add(constraintWidget.horizontalChainRun);
        hashSet = hashSet1;
      } else {
        paramArrayList.add(constraintWidget.horizontalRun);
      } 
      if (constraintWidget.isInVerticalChain()) {
        if (constraintWidget.verticalChainRun == null)
          constraintWidget.verticalChainRun = new ChainRun(constraintWidget, 1); 
        hashSet1 = hashSet;
        if (hashSet == null)
          hashSet1 = new HashSet<ChainRun>(); 
        hashSet1.add(constraintWidget.verticalChainRun);
      } else {
        paramArrayList.add(constraintWidget.verticalRun);
        hashSet1 = hashSet;
      } 
      hashSet = hashSet1;
      if (constraintWidget instanceof androidx.constraintlayout.core.widgets.HelperWidget) {
        paramArrayList.add(new HelperReferences(constraintWidget));
        hashSet = hashSet1;
      } 
    } 
    if (hashSet != null)
      paramArrayList.addAll((Collection)hashSet); 
    Iterator<WidgetRun> iterator = paramArrayList.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).clear(); 
    for (WidgetRun widgetRun : paramArrayList) {
      if (widgetRun.widget == this.mContainer)
        continue; 
      widgetRun.apply();
    } 
  }
  
  public void defineTerminalWidgets(ConstraintWidget.DimensionBehaviour paramDimensionBehaviour1, ConstraintWidget.DimensionBehaviour paramDimensionBehaviour2) {
    if (this.mNeedBuildGraph) {
      buildGraph();
      Iterator<ConstraintWidget> iterator = this.container.mChildren.iterator();
      boolean bool = false;
      while (iterator.hasNext()) {
        ConstraintWidget constraintWidget = iterator.next();
        constraintWidget.isTerminalWidget[0] = true;
        constraintWidget.isTerminalWidget[1] = true;
        if (constraintWidget instanceof androidx.constraintlayout.core.widgets.Barrier)
          bool = true; 
      } 
      if (!bool)
        for (RunGroup runGroup : this.mGroups) {
          boolean bool1;
          boolean bool2;
          if (paramDimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (paramDimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
            bool2 = true;
          } else {
            bool2 = false;
          } 
          runGroup.defineTerminalWidgets(bool1, bool2);
        }  
    } 
  }
  
  public boolean directMeasure(boolean paramBoolean) {
    boolean bool1;
    boolean bool2 = true;
    int i = paramBoolean & true;
    if (this.mNeedBuildGraph || this.mNeedRedoMeasures) {
      for (ConstraintWidget constraintWidget : this.container.mChildren) {
        constraintWidget.ensureWidgetRuns();
        constraintWidget.measured = false;
        constraintWidget.horizontalRun.reset();
        constraintWidget.verticalRun.reset();
      } 
      this.container.ensureWidgetRuns();
      this.container.measured = false;
      this.container.horizontalRun.reset();
      this.container.verticalRun.reset();
      this.mNeedRedoMeasures = false;
    } 
    if (basicMeasureWidgets(this.mContainer))
      return false; 
    this.container.setX(0);
    this.container.setY(0);
    ConstraintWidget.DimensionBehaviour dimensionBehaviour1 = this.container.getDimensionBehaviour(0);
    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = this.container.getDimensionBehaviour(1);
    if (this.mNeedBuildGraph)
      buildGraph(); 
    int k = this.container.getX();
    int j = this.container.getY();
    this.container.horizontalRun.start.resolve(k);
    this.container.verticalRun.start.resolve(j);
    measureWidgets();
    if (dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
      bool1 = i;
      if (i != 0) {
        Iterator<WidgetRun> iterator1 = this.mRuns.iterator();
        while (true) {
          bool1 = i;
          if (iterator1.hasNext()) {
            if (!((WidgetRun)iterator1.next()).supportsWrapComputation()) {
              bool1 = false;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      if (bool1 != 0 && dimensionBehaviour1 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        this.container.setHorizontalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        ConstraintWidgetContainer constraintWidgetContainer = this.container;
        constraintWidgetContainer.setWidth(computeWrap(constraintWidgetContainer, 0));
        this.container.horizontalRun.dimension.resolve(this.container.getWidth());
      } 
      if (bool1 != 0 && dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
        this.container.setVerticalDimensionBehaviour(ConstraintWidget.DimensionBehaviour.FIXED);
        ConstraintWidgetContainer constraintWidgetContainer = this.container;
        constraintWidgetContainer.setHeight(computeWrap(constraintWidgetContainer, 1));
        this.container.verticalRun.dimension.resolve(this.container.getHeight());
      } 
    } 
    if (this.container.mListDimensionBehaviors[0] == ConstraintWidget.DimensionBehaviour.FIXED || this.container.mListDimensionBehaviors[0] == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
      bool1 = this.container.getWidth() + k;
      this.container.horizontalRun.end.resolve(bool1);
      this.container.horizontalRun.dimension.resolve(bool1 - k);
      measureWidgets();
      if (this.container.mListDimensionBehaviors[1] == ConstraintWidget.DimensionBehaviour.FIXED || this.container.mListDimensionBehaviors[1] == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
        bool1 = this.container.getHeight() + j;
        this.container.verticalRun.end.resolve(bool1);
        this.container.verticalRun.dimension.resolve(bool1 - j);
      } 
      measureWidgets();
      bool1 = true;
    } else {
      bool1 = false;
    } 
    for (WidgetRun widgetRun : this.mRuns) {
      if (widgetRun.widget == this.container && !widgetRun.resolved)
        continue; 
      widgetRun.applyToWidget();
    } 
    Iterator<WidgetRun> iterator = this.mRuns.iterator();
    while (true) {
      paramBoolean = bool2;
      if (iterator.hasNext()) {
        WidgetRun widgetRun = iterator.next();
        if ((bool1 || widgetRun.widget != this.container) && (!widgetRun.start.resolved || (!widgetRun.end.resolved && !(widgetRun instanceof GuidelineReference)) || (!widgetRun.dimension.resolved && !(widgetRun instanceof ChainRun) && !(widgetRun instanceof GuidelineReference)))) {
          paramBoolean = false;
          break;
        } 
        continue;
      } 
      break;
    } 
    this.container.setHorizontalDimensionBehaviour(dimensionBehaviour1);
    this.container.setVerticalDimensionBehaviour(dimensionBehaviour2);
    return paramBoolean;
  }
  
  public boolean directMeasureSetup(boolean paramBoolean) {
    if (this.mNeedBuildGraph) {
      for (ConstraintWidget constraintWidget : this.container.mChildren) {
        constraintWidget.ensureWidgetRuns();
        constraintWidget.measured = false;
        constraintWidget.horizontalRun.dimension.resolved = false;
        constraintWidget.horizontalRun.resolved = false;
        constraintWidget.horizontalRun.reset();
        constraintWidget.verticalRun.dimension.resolved = false;
        constraintWidget.verticalRun.resolved = false;
        constraintWidget.verticalRun.reset();
      } 
      this.container.ensureWidgetRuns();
      this.container.measured = false;
      this.container.horizontalRun.dimension.resolved = false;
      this.container.horizontalRun.resolved = false;
      this.container.horizontalRun.reset();
      this.container.verticalRun.dimension.resolved = false;
      this.container.verticalRun.resolved = false;
      this.container.verticalRun.reset();
      buildGraph();
    } 
    if (basicMeasureWidgets(this.mContainer))
      return false; 
    this.container.setX(0);
    this.container.setY(0);
    this.container.horizontalRun.start.resolve(0);
    this.container.verticalRun.start.resolve(0);
    return true;
  }
  
  public boolean directMeasureWithOrientation(boolean paramBoolean, int paramInt) {
    // Byte code:
    //   0: iconst_1
    //   1: istore #7
    //   3: iload_1
    //   4: iconst_1
    //   5: iand
    //   6: istore #4
    //   8: aload_0
    //   9: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   12: iconst_0
    //   13: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   16: astore #8
    //   18: aload_0
    //   19: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   22: iconst_1
    //   23: invokevirtual getDimensionBehaviour : (I)Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   26: astore #9
    //   28: aload_0
    //   29: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   32: invokevirtual getX : ()I
    //   35: istore #5
    //   37: aload_0
    //   38: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   41: invokevirtual getY : ()I
    //   44: istore #6
    //   46: iload #4
    //   48: ifeq -> 247
    //   51: aload #8
    //   53: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   56: if_acmpeq -> 67
    //   59: aload #9
    //   61: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   64: if_acmpne -> 247
    //   67: aload_0
    //   68: getfield mRuns : Ljava/util/ArrayList;
    //   71: invokevirtual iterator : ()Ljava/util/Iterator;
    //   74: astore #10
    //   76: iload #4
    //   78: istore_3
    //   79: aload #10
    //   81: invokeinterface hasNext : ()Z
    //   86: ifeq -> 120
    //   89: aload #10
    //   91: invokeinterface next : ()Ljava/lang/Object;
    //   96: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   99: astore #11
    //   101: aload #11
    //   103: getfield orientation : I
    //   106: iload_2
    //   107: if_icmpne -> 76
    //   110: aload #11
    //   112: invokevirtual supportsWrapComputation : ()Z
    //   115: ifne -> 76
    //   118: iconst_0
    //   119: istore_3
    //   120: iload_2
    //   121: ifne -> 187
    //   124: iload_3
    //   125: ifeq -> 247
    //   128: aload #8
    //   130: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   133: if_acmpne -> 247
    //   136: aload_0
    //   137: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   140: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   143: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   146: aload_0
    //   147: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   150: astore #10
    //   152: aload #10
    //   154: aload_0
    //   155: aload #10
    //   157: iconst_0
    //   158: invokespecial computeWrap : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;I)I
    //   161: invokevirtual setWidth : (I)V
    //   164: aload_0
    //   165: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   168: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   171: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   174: aload_0
    //   175: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   178: invokevirtual getWidth : ()I
    //   181: invokevirtual resolve : (I)V
    //   184: goto -> 247
    //   187: iload_3
    //   188: ifeq -> 247
    //   191: aload #9
    //   193: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   196: if_acmpne -> 247
    //   199: aload_0
    //   200: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   203: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   206: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   209: aload_0
    //   210: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   213: astore #10
    //   215: aload #10
    //   217: aload_0
    //   218: aload #10
    //   220: iconst_1
    //   221: invokespecial computeWrap : (Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;I)I
    //   224: invokevirtual setHeight : (I)V
    //   227: aload_0
    //   228: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   231: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   234: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   237: aload_0
    //   238: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   241: invokevirtual getHeight : ()I
    //   244: invokevirtual resolve : (I)V
    //   247: iload_2
    //   248: ifne -> 326
    //   251: aload_0
    //   252: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   255: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   258: iconst_0
    //   259: aaload
    //   260: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   263: if_acmpeq -> 281
    //   266: aload_0
    //   267: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   270: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   273: iconst_0
    //   274: aaload
    //   275: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   278: if_acmpne -> 359
    //   281: aload_0
    //   282: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   285: invokevirtual getWidth : ()I
    //   288: iload #5
    //   290: iadd
    //   291: istore_3
    //   292: aload_0
    //   293: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   296: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   299: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   302: iload_3
    //   303: invokevirtual resolve : (I)V
    //   306: aload_0
    //   307: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   310: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   313: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   316: iload_3
    //   317: iload #5
    //   319: isub
    //   320: invokevirtual resolve : (I)V
    //   323: goto -> 406
    //   326: aload_0
    //   327: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   330: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   333: iconst_1
    //   334: aaload
    //   335: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.FIXED : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   338: if_acmpeq -> 364
    //   341: aload_0
    //   342: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   345: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   348: iconst_1
    //   349: aaload
    //   350: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_PARENT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   353: if_acmpne -> 359
    //   356: goto -> 364
    //   359: iconst_0
    //   360: istore_3
    //   361: goto -> 408
    //   364: aload_0
    //   365: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   368: invokevirtual getHeight : ()I
    //   371: iload #6
    //   373: iadd
    //   374: istore_3
    //   375: aload_0
    //   376: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   379: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   382: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   385: iload_3
    //   386: invokevirtual resolve : (I)V
    //   389: aload_0
    //   390: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   393: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   396: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   399: iload_3
    //   400: iload #6
    //   402: isub
    //   403: invokevirtual resolve : (I)V
    //   406: iconst_1
    //   407: istore_3
    //   408: aload_0
    //   409: invokevirtual measureWidgets : ()V
    //   412: aload_0
    //   413: getfield mRuns : Ljava/util/ArrayList;
    //   416: invokevirtual iterator : ()Ljava/util/Iterator;
    //   419: astore #10
    //   421: aload #10
    //   423: invokeinterface hasNext : ()Z
    //   428: ifeq -> 486
    //   431: aload #10
    //   433: invokeinterface next : ()Ljava/lang/Object;
    //   438: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   441: astore #11
    //   443: aload #11
    //   445: getfield orientation : I
    //   448: iload_2
    //   449: if_icmpeq -> 455
    //   452: goto -> 421
    //   455: aload #11
    //   457: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   460: aload_0
    //   461: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   464: if_acmpne -> 478
    //   467: aload #11
    //   469: getfield resolved : Z
    //   472: ifne -> 478
    //   475: goto -> 421
    //   478: aload #11
    //   480: invokevirtual applyToWidget : ()V
    //   483: goto -> 421
    //   486: aload_0
    //   487: getfield mRuns : Ljava/util/ArrayList;
    //   490: invokevirtual iterator : ()Ljava/util/Iterator;
    //   493: astore #10
    //   495: iload #7
    //   497: istore_1
    //   498: aload #10
    //   500: invokeinterface hasNext : ()Z
    //   505: ifeq -> 603
    //   508: aload #10
    //   510: invokeinterface next : ()Ljava/lang/Object;
    //   515: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   518: astore #11
    //   520: aload #11
    //   522: getfield orientation : I
    //   525: iload_2
    //   526: if_icmpeq -> 532
    //   529: goto -> 495
    //   532: iload_3
    //   533: ifne -> 551
    //   536: aload #11
    //   538: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   541: aload_0
    //   542: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   545: if_acmpne -> 551
    //   548: goto -> 495
    //   551: aload #11
    //   553: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   556: getfield resolved : Z
    //   559: ifne -> 567
    //   562: iconst_0
    //   563: istore_1
    //   564: goto -> 603
    //   567: aload #11
    //   569: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   572: getfield resolved : Z
    //   575: ifne -> 581
    //   578: goto -> 562
    //   581: aload #11
    //   583: instanceof androidx/constraintlayout/core/widgets/analyzer/ChainRun
    //   586: ifne -> 495
    //   589: aload #11
    //   591: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   594: getfield resolved : Z
    //   597: ifne -> 495
    //   600: goto -> 562
    //   603: aload_0
    //   604: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   607: aload #8
    //   609: invokevirtual setHorizontalDimensionBehaviour : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   612: aload_0
    //   613: getfield container : Landroidx/constraintlayout/core/widgets/ConstraintWidgetContainer;
    //   616: aload #9
    //   618: invokevirtual setVerticalDimensionBehaviour : (Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;)V
    //   621: iload_1
    //   622: ireturn
  }
  
  public void invalidateGraph() {
    this.mNeedBuildGraph = true;
  }
  
  public void invalidateMeasures() {
    this.mNeedRedoMeasures = true;
  }
  
  public void measureWidgets() {
    Iterator iterator = this.container.mChildren.iterator();
    while (true) {
      while (true)
        break; 
      if (((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_8).measured && ((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_8).verticalRun.baselineDimension != null)
        ((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_8).verticalRun.baselineDimension.resolve(SYNTHETIC_LOCAL_VARIABLE_8.getBaselineDistance()); 
    } 
  }
  
  public void setMeasurer(BasicMeasure.Measurer paramMeasurer) {
    this.mMeasurer = paramMeasurer;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\DependencyGraph.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */