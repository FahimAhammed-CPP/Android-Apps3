package androidx.constraintlayout.core.widgets.analyzer;

import androidx.constraintlayout.core.widgets.ConstraintAnchor;
import androidx.constraintlayout.core.widgets.ConstraintWidget;
import androidx.constraintlayout.core.widgets.ConstraintWidgetContainer;
import java.util.ArrayList;
import java.util.Iterator;

public class ChainRun extends WidgetRun {
  private int chainStyle;
  
  ArrayList<WidgetRun> widgets = new ArrayList<WidgetRun>();
  
  public ChainRun(ConstraintWidget paramConstraintWidget, int paramInt) {
    super(paramConstraintWidget);
    this.orientation = paramInt;
    build();
  }
  
  private void build() {
    int i;
    ConstraintWidget constraintWidget2 = this.widget;
    ConstraintWidget constraintWidget1;
    for (constraintWidget1 = constraintWidget2.getPreviousChainMember(this.orientation); constraintWidget1 != null; constraintWidget1 = constraintWidget) {
      ConstraintWidget constraintWidget = constraintWidget1.getPreviousChainMember(this.orientation);
      constraintWidget2 = constraintWidget1;
    } 
    this.widget = constraintWidget2;
    this.widgets.add(constraintWidget2.getRun(this.orientation));
    for (constraintWidget1 = constraintWidget2.getNextChainMember(this.orientation); constraintWidget1 != null; constraintWidget1 = constraintWidget1.getNextChainMember(this.orientation))
      this.widgets.add(constraintWidget1.getRun(this.orientation)); 
    for (WidgetRun widgetRun : this.widgets) {
      if (this.orientation == 0) {
        widgetRun.widget.horizontalChainRun = this;
        continue;
      } 
      if (this.orientation == 1)
        widgetRun.widget.verticalChainRun = this; 
    } 
    if (this.orientation == 0 && ((ConstraintWidgetContainer)this.widget.getParent()).isRtl()) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i && this.widgets.size() > 1) {
      ArrayList<WidgetRun> arrayList = this.widgets;
      this.widget = ((WidgetRun)arrayList.get(arrayList.size() - 1)).widget;
    } 
    if (this.orientation == 0) {
      i = this.widget.getHorizontalChainStyle();
    } else {
      i = this.widget.getVerticalChainStyle();
    } 
    this.chainStyle = i;
  }
  
  private ConstraintWidget getFirstVisibleWidget() {
    for (int i = 0; i < this.widgets.size(); i++) {
      WidgetRun widgetRun = this.widgets.get(i);
      if (widgetRun.widget.getVisibility() != 8)
        return widgetRun.widget; 
    } 
    return null;
  }
  
  private ConstraintWidget getLastVisibleWidget() {
    for (int i = this.widgets.size() - 1; i >= 0; i--) {
      WidgetRun widgetRun = this.widgets.get(i);
      if (widgetRun.widget.getVisibility() != 8)
        return widgetRun.widget; 
    } 
    return null;
  }
  
  void apply() {
    DependencyNode dependencyNode;
    Iterator<WidgetRun> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).apply(); 
    int i = this.widgets.size();
    if (i < 1)
      return; 
    ConstraintWidget constraintWidget2 = ((WidgetRun)this.widgets.get(0)).widget;
    ConstraintWidget constraintWidget1 = ((WidgetRun)this.widgets.get(i - 1)).widget;
    if (this.orientation == 0) {
      ConstraintAnchor constraintAnchor2 = constraintWidget2.mLeft;
      ConstraintAnchor constraintAnchor1 = constraintWidget1.mRight;
      DependencyNode dependencyNode1 = getTarget(constraintAnchor2, 0);
      i = constraintAnchor2.getMargin();
      ConstraintWidget constraintWidget = getFirstVisibleWidget();
      if (constraintWidget != null)
        i = constraintWidget.mLeft.getMargin(); 
      if (dependencyNode1 != null)
        addTarget(this.start, dependencyNode1, i); 
      dependencyNode = getTarget(constraintAnchor1, 0);
      i = constraintAnchor1.getMargin();
      constraintWidget1 = getLastVisibleWidget();
      if (constraintWidget1 != null)
        i = constraintWidget1.mRight.getMargin(); 
      if (dependencyNode != null)
        addTarget(this.end, dependencyNode, -i); 
    } else {
      ConstraintAnchor constraintAnchor2 = ((ConstraintWidget)dependencyNode).mTop;
      ConstraintAnchor constraintAnchor1 = constraintWidget1.mBottom;
      DependencyNode dependencyNode2 = getTarget(constraintAnchor2, 1);
      i = constraintAnchor2.getMargin();
      ConstraintWidget constraintWidget4 = getFirstVisibleWidget();
      if (constraintWidget4 != null)
        i = constraintWidget4.mTop.getMargin(); 
      if (dependencyNode2 != null)
        addTarget(this.start, dependencyNode2, i); 
      DependencyNode dependencyNode1 = getTarget(constraintAnchor1, 1);
      i = constraintAnchor1.getMargin();
      ConstraintWidget constraintWidget3 = getLastVisibleWidget();
      if (constraintWidget3 != null)
        i = constraintWidget3.mBottom.getMargin(); 
      if (dependencyNode1 != null)
        addTarget(this.end, dependencyNode1, -i); 
    } 
    this.start.updateDelegate = this;
    this.end.updateDelegate = this;
  }
  
  public void applyToWidget() {
    for (int i = 0; i < this.widgets.size(); i++)
      ((WidgetRun)this.widgets.get(i)).applyToWidget(); 
  }
  
  void clear() {
    this.runGroup = null;
    Iterator<WidgetRun> iterator = this.widgets.iterator();
    while (iterator.hasNext())
      ((WidgetRun)iterator.next()).clear(); 
  }
  
  public long getWrapDimension() {
    int j = this.widgets.size();
    long l = 0L;
    for (int i = 0; i < j; i++) {
      WidgetRun widgetRun = this.widgets.get(i);
      l = l + widgetRun.start.margin + widgetRun.getWrapDimension() + widgetRun.end.margin;
    } 
    return l;
  }
  
  void reset() {
    this.start.resolved = false;
    this.end.resolved = false;
  }
  
  boolean supportsWrapComputation() {
    int j = this.widgets.size();
    for (int i = 0; i < j; i++) {
      if (!((WidgetRun)this.widgets.get(i)).supportsWrapComputation())
        return false; 
    } 
    return true;
  }
  
  public String toString() {
    String str;
    StringBuilder stringBuilder = new StringBuilder("ChainRun ");
    if (this.orientation == 0) {
      str = "horizontal : ";
    } else {
      str = "vertical : ";
    } 
    stringBuilder.append(str);
    for (WidgetRun widgetRun : this.widgets) {
      stringBuilder.append("<");
      stringBuilder.append(widgetRun);
      stringBuilder.append("> ");
    } 
    return stringBuilder.toString();
  }
  
  public void update(Dependency paramDependency) {
    // Byte code:
    //   0: aload_0
    //   1: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   4: getfield resolved : Z
    //   7: ifeq -> 2443
    //   10: aload_0
    //   11: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   14: getfield resolved : Z
    //   17: ifne -> 21
    //   20: return
    //   21: aload_0
    //   22: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   25: invokevirtual getParent : ()Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   28: astore_1
    //   29: aload_1
    //   30: instanceof androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   33: ifeq -> 48
    //   36: aload_1
    //   37: checkcast androidx/constraintlayout/core/widgets/ConstraintWidgetContainer
    //   40: invokevirtual isRtl : ()Z
    //   43: istore #21
    //   45: goto -> 51
    //   48: iconst_0
    //   49: istore #21
    //   51: aload_0
    //   52: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   55: getfield value : I
    //   58: aload_0
    //   59: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   62: getfield value : I
    //   65: isub
    //   66: istore #20
    //   68: aload_0
    //   69: getfield widgets : Ljava/util/ArrayList;
    //   72: invokevirtual size : ()I
    //   75: istore #19
    //   77: iconst_0
    //   78: istore #5
    //   80: iconst_m1
    //   81: istore #6
    //   83: iload #5
    //   85: iload #19
    //   87: if_icmpge -> 126
    //   90: iload #5
    //   92: istore #13
    //   94: aload_0
    //   95: getfield widgets : Ljava/util/ArrayList;
    //   98: iload #5
    //   100: invokevirtual get : (I)Ljava/lang/Object;
    //   103: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   106: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   109: invokevirtual getVisibility : ()I
    //   112: bipush #8
    //   114: if_icmpne -> 129
    //   117: iload #5
    //   119: iconst_1
    //   120: iadd
    //   121: istore #5
    //   123: goto -> 80
    //   126: iconst_m1
    //   127: istore #13
    //   129: iload #19
    //   131: iconst_1
    //   132: isub
    //   133: istore #18
    //   135: iload #18
    //   137: istore #5
    //   139: iload #6
    //   141: istore #14
    //   143: iload #5
    //   145: iflt -> 184
    //   148: aload_0
    //   149: getfield widgets : Ljava/util/ArrayList;
    //   152: iload #5
    //   154: invokevirtual get : (I)Ljava/lang/Object;
    //   157: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   160: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   163: invokevirtual getVisibility : ()I
    //   166: bipush #8
    //   168: if_icmpne -> 180
    //   171: iload #5
    //   173: iconst_1
    //   174: isub
    //   175: istore #5
    //   177: goto -> 139
    //   180: iload #5
    //   182: istore #14
    //   184: iconst_0
    //   185: istore #9
    //   187: iload #9
    //   189: iconst_2
    //   190: if_icmpge -> 654
    //   193: iconst_0
    //   194: istore #10
    //   196: iconst_0
    //   197: istore #7
    //   199: iconst_0
    //   200: istore #5
    //   202: iconst_0
    //   203: istore #8
    //   205: fconst_0
    //   206: fstore_2
    //   207: iload #10
    //   209: iload #19
    //   211: if_icmpge -> 619
    //   214: aload_0
    //   215: getfield widgets : Ljava/util/ArrayList;
    //   218: iload #10
    //   220: invokevirtual get : (I)Ljava/lang/Object;
    //   223: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   226: astore_1
    //   227: aload_1
    //   228: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   231: invokevirtual getVisibility : ()I
    //   234: bipush #8
    //   236: if_icmpne -> 250
    //   239: iload #7
    //   241: istore #6
    //   243: iload #5
    //   245: istore #11
    //   247: goto -> 602
    //   250: iload #8
    //   252: iconst_1
    //   253: iadd
    //   254: istore #16
    //   256: iload #7
    //   258: istore #6
    //   260: iload #10
    //   262: ifle -> 288
    //   265: iload #7
    //   267: istore #6
    //   269: iload #10
    //   271: iload #13
    //   273: if_icmplt -> 288
    //   276: iload #7
    //   278: aload_1
    //   279: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   282: getfield margin : I
    //   285: iadd
    //   286: istore #6
    //   288: aload_1
    //   289: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   292: getfield value : I
    //   295: istore #11
    //   297: aload_1
    //   298: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   301: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   304: if_acmpeq -> 313
    //   307: iconst_1
    //   308: istore #8
    //   310: goto -> 316
    //   313: iconst_0
    //   314: istore #8
    //   316: iload #8
    //   318: ifeq -> 394
    //   321: aload_0
    //   322: getfield orientation : I
    //   325: ifne -> 345
    //   328: aload_1
    //   329: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   332: getfield horizontalRun : Landroidx/constraintlayout/core/widgets/analyzer/HorizontalWidgetRun;
    //   335: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   338: getfield resolved : Z
    //   341: ifne -> 345
    //   344: return
    //   345: iload #8
    //   347: istore #15
    //   349: iload #11
    //   351: istore #12
    //   353: iload #5
    //   355: istore #7
    //   357: aload_0
    //   358: getfield orientation : I
    //   361: iconst_1
    //   362: if_icmpne -> 470
    //   365: iload #8
    //   367: istore #15
    //   369: iload #11
    //   371: istore #12
    //   373: iload #5
    //   375: istore #7
    //   377: aload_1
    //   378: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   381: getfield verticalRun : Landroidx/constraintlayout/core/widgets/analyzer/VerticalWidgetRun;
    //   384: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   387: getfield resolved : Z
    //   390: ifne -> 470
    //   393: return
    //   394: aload_1
    //   395: getfield matchConstraintsType : I
    //   398: iconst_1
    //   399: if_icmpne -> 433
    //   402: iload #9
    //   404: ifne -> 433
    //   407: aload_1
    //   408: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   411: getfield wrapValue : I
    //   414: istore #7
    //   416: iload #5
    //   418: iconst_1
    //   419: iadd
    //   420: istore #8
    //   422: iload #7
    //   424: istore #5
    //   426: iload #8
    //   428: istore #7
    //   430: goto -> 463
    //   433: iload #8
    //   435: istore #15
    //   437: iload #11
    //   439: istore #12
    //   441: iload #5
    //   443: istore #7
    //   445: aload_1
    //   446: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   449: getfield resolved : Z
    //   452: ifeq -> 470
    //   455: iload #5
    //   457: istore #7
    //   459: iload #11
    //   461: istore #5
    //   463: iconst_1
    //   464: istore #15
    //   466: iload #5
    //   468: istore #12
    //   470: iload #15
    //   472: ifne -> 528
    //   475: iload #7
    //   477: iconst_1
    //   478: iadd
    //   479: istore #8
    //   481: aload_1
    //   482: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   485: getfield mWeight : [F
    //   488: aload_0
    //   489: getfield orientation : I
    //   492: faload
    //   493: fstore #4
    //   495: iload #6
    //   497: istore #5
    //   499: iload #8
    //   501: istore #7
    //   503: fload_2
    //   504: fstore_3
    //   505: fload #4
    //   507: fconst_0
    //   508: fcmpl
    //   509: iflt -> 537
    //   512: fload_2
    //   513: fload #4
    //   515: fadd
    //   516: fstore_3
    //   517: iload #6
    //   519: istore #5
    //   521: iload #8
    //   523: istore #7
    //   525: goto -> 537
    //   528: iload #6
    //   530: iload #12
    //   532: iadd
    //   533: istore #5
    //   535: fload_2
    //   536: fstore_3
    //   537: iload #5
    //   539: istore #6
    //   541: iload #7
    //   543: istore #11
    //   545: iload #16
    //   547: istore #8
    //   549: fload_3
    //   550: fstore_2
    //   551: iload #10
    //   553: iload #18
    //   555: if_icmpge -> 602
    //   558: iload #5
    //   560: istore #6
    //   562: iload #7
    //   564: istore #11
    //   566: iload #16
    //   568: istore #8
    //   570: fload_3
    //   571: fstore_2
    //   572: iload #10
    //   574: iload #14
    //   576: if_icmpge -> 602
    //   579: iload #5
    //   581: aload_1
    //   582: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   585: getfield margin : I
    //   588: ineg
    //   589: iadd
    //   590: istore #6
    //   592: fload_3
    //   593: fstore_2
    //   594: iload #16
    //   596: istore #8
    //   598: iload #7
    //   600: istore #11
    //   602: iload #10
    //   604: iconst_1
    //   605: iadd
    //   606: istore #10
    //   608: iload #6
    //   610: istore #7
    //   612: iload #11
    //   614: istore #5
    //   616: goto -> 207
    //   619: iload #7
    //   621: iload #20
    //   623: if_icmplt -> 643
    //   626: iload #5
    //   628: ifne -> 634
    //   631: goto -> 643
    //   634: iload #9
    //   636: iconst_1
    //   637: iadd
    //   638: istore #9
    //   640: goto -> 187
    //   643: iload #8
    //   645: istore #15
    //   647: iload #5
    //   649: istore #6
    //   651: goto -> 665
    //   654: iconst_0
    //   655: istore #15
    //   657: iconst_0
    //   658: istore #7
    //   660: iconst_0
    //   661: istore #6
    //   663: fconst_0
    //   664: fstore_2
    //   665: aload_0
    //   666: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   669: getfield value : I
    //   672: istore #8
    //   674: iload #21
    //   676: ifeq -> 688
    //   679: aload_0
    //   680: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   683: getfield value : I
    //   686: istore #8
    //   688: iload #8
    //   690: istore #5
    //   692: iload #7
    //   694: iload #20
    //   696: if_icmple -> 741
    //   699: iload #21
    //   701: ifeq -> 724
    //   704: iload #8
    //   706: iload #7
    //   708: iload #20
    //   710: isub
    //   711: i2f
    //   712: fconst_2
    //   713: fdiv
    //   714: ldc 0.5
    //   716: fadd
    //   717: f2i
    //   718: iadd
    //   719: istore #5
    //   721: goto -> 741
    //   724: iload #8
    //   726: iload #7
    //   728: iload #20
    //   730: isub
    //   731: i2f
    //   732: fconst_2
    //   733: fdiv
    //   734: ldc 0.5
    //   736: fadd
    //   737: f2i
    //   738: isub
    //   739: istore #5
    //   741: iload #6
    //   743: ifle -> 1216
    //   746: iload #20
    //   748: iload #7
    //   750: isub
    //   751: i2f
    //   752: fstore_3
    //   753: fload_3
    //   754: iload #6
    //   756: i2f
    //   757: fdiv
    //   758: ldc 0.5
    //   760: fadd
    //   761: f2i
    //   762: istore #10
    //   764: iconst_0
    //   765: istore #16
    //   767: iconst_0
    //   768: istore #8
    //   770: iload #5
    //   772: istore #9
    //   774: iload #16
    //   776: iload #19
    //   778: if_icmpge -> 1016
    //   781: aload_0
    //   782: getfield widgets : Ljava/util/ArrayList;
    //   785: iload #16
    //   787: invokevirtual get : (I)Ljava/lang/Object;
    //   790: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   793: astore_1
    //   794: aload_1
    //   795: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   798: invokevirtual getVisibility : ()I
    //   801: bipush #8
    //   803: if_icmpne -> 809
    //   806: goto -> 1007
    //   809: aload_1
    //   810: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   813: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   816: if_acmpne -> 1007
    //   819: aload_1
    //   820: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   823: getfield resolved : Z
    //   826: ifne -> 1007
    //   829: fload_2
    //   830: fconst_0
    //   831: fcmpl
    //   832: ifle -> 860
    //   835: aload_1
    //   836: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   839: getfield mWeight : [F
    //   842: aload_0
    //   843: getfield orientation : I
    //   846: faload
    //   847: fload_3
    //   848: fmul
    //   849: fload_2
    //   850: fdiv
    //   851: ldc 0.5
    //   853: fadd
    //   854: f2i
    //   855: istore #5
    //   857: goto -> 864
    //   860: iload #10
    //   862: istore #5
    //   864: aload_0
    //   865: getfield orientation : I
    //   868: ifne -> 892
    //   871: aload_1
    //   872: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   875: getfield mMatchConstraintMaxWidth : I
    //   878: istore #12
    //   880: aload_1
    //   881: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   884: getfield mMatchConstraintMinWidth : I
    //   887: istore #11
    //   889: goto -> 910
    //   892: aload_1
    //   893: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   896: getfield mMatchConstraintMaxHeight : I
    //   899: istore #12
    //   901: aload_1
    //   902: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   905: getfield mMatchConstraintMinHeight : I
    //   908: istore #11
    //   910: aload_1
    //   911: getfield matchConstraintsType : I
    //   914: iconst_1
    //   915: if_icmpne -> 935
    //   918: iload #5
    //   920: aload_1
    //   921: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   924: getfield wrapValue : I
    //   927: invokestatic min : (II)I
    //   930: istore #17
    //   932: goto -> 939
    //   935: iload #5
    //   937: istore #17
    //   939: iload #11
    //   941: iload #17
    //   943: invokestatic max : (II)I
    //   946: istore #17
    //   948: iload #17
    //   950: istore #11
    //   952: iload #12
    //   954: ifle -> 966
    //   957: iload #12
    //   959: iload #17
    //   961: invokestatic min : (II)I
    //   964: istore #11
    //   966: iload #5
    //   968: istore #17
    //   970: iload #8
    //   972: istore #12
    //   974: iload #11
    //   976: iload #5
    //   978: if_icmpeq -> 991
    //   981: iload #8
    //   983: iconst_1
    //   984: iadd
    //   985: istore #12
    //   987: iload #11
    //   989: istore #17
    //   991: aload_1
    //   992: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   995: iload #17
    //   997: invokevirtual resolve : (I)V
    //   1000: iload #12
    //   1002: istore #8
    //   1004: goto -> 1007
    //   1007: iload #16
    //   1009: iconst_1
    //   1010: iadd
    //   1011: istore #16
    //   1013: goto -> 774
    //   1016: iload #8
    //   1018: ifle -> 1164
    //   1021: iload #6
    //   1023: iload #8
    //   1025: isub
    //   1026: istore #10
    //   1028: iconst_0
    //   1029: istore #6
    //   1031: iconst_0
    //   1032: istore #5
    //   1034: iload #6
    //   1036: iload #19
    //   1038: if_icmpge -> 1157
    //   1041: aload_0
    //   1042: getfield widgets : Ljava/util/ArrayList;
    //   1045: iload #6
    //   1047: invokevirtual get : (I)Ljava/lang/Object;
    //   1050: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   1053: astore_1
    //   1054: aload_1
    //   1055: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1058: invokevirtual getVisibility : ()I
    //   1061: bipush #8
    //   1063: if_icmpne -> 1069
    //   1066: goto -> 1148
    //   1069: iload #5
    //   1071: istore #7
    //   1073: iload #6
    //   1075: ifle -> 1101
    //   1078: iload #5
    //   1080: istore #7
    //   1082: iload #6
    //   1084: iload #13
    //   1086: if_icmplt -> 1101
    //   1089: iload #5
    //   1091: aload_1
    //   1092: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1095: getfield margin : I
    //   1098: iadd
    //   1099: istore #7
    //   1101: iload #7
    //   1103: aload_1
    //   1104: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1107: getfield value : I
    //   1110: iadd
    //   1111: istore #7
    //   1113: iload #7
    //   1115: istore #5
    //   1117: iload #6
    //   1119: iload #18
    //   1121: if_icmpge -> 1148
    //   1124: iload #7
    //   1126: istore #5
    //   1128: iload #6
    //   1130: iload #14
    //   1132: if_icmpge -> 1148
    //   1135: iload #7
    //   1137: aload_1
    //   1138: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1141: getfield margin : I
    //   1144: ineg
    //   1145: iadd
    //   1146: istore #5
    //   1148: iload #6
    //   1150: iconst_1
    //   1151: iadd
    //   1152: istore #6
    //   1154: goto -> 1034
    //   1157: iload #10
    //   1159: istore #6
    //   1161: goto -> 1168
    //   1164: iload #7
    //   1166: istore #5
    //   1168: aload_0
    //   1169: getfield chainStyle : I
    //   1172: iconst_2
    //   1173: if_icmpne -> 1201
    //   1176: iload #8
    //   1178: ifne -> 1201
    //   1181: aload_0
    //   1182: iconst_0
    //   1183: putfield chainStyle : I
    //   1186: iload #5
    //   1188: istore #7
    //   1190: iload #6
    //   1192: istore #10
    //   1194: iload #9
    //   1196: istore #5
    //   1198: goto -> 1220
    //   1201: iload #5
    //   1203: istore #7
    //   1205: iload #6
    //   1207: istore #10
    //   1209: iload #9
    //   1211: istore #5
    //   1213: goto -> 1220
    //   1216: iload #6
    //   1218: istore #10
    //   1220: iload #7
    //   1222: iload #20
    //   1224: if_icmple -> 1232
    //   1227: aload_0
    //   1228: iconst_2
    //   1229: putfield chainStyle : I
    //   1232: iload #15
    //   1234: ifle -> 1254
    //   1237: iload #10
    //   1239: ifne -> 1254
    //   1242: iload #13
    //   1244: iload #14
    //   1246: if_icmpne -> 1254
    //   1249: aload_0
    //   1250: iconst_2
    //   1251: putfield chainStyle : I
    //   1254: aload_0
    //   1255: getfield chainStyle : I
    //   1258: istore #6
    //   1260: iload #6
    //   1262: iconst_1
    //   1263: if_icmpne -> 1680
    //   1266: iload #15
    //   1268: iconst_1
    //   1269: if_icmple -> 1287
    //   1272: iload #20
    //   1274: iload #7
    //   1276: isub
    //   1277: iload #15
    //   1279: iconst_1
    //   1280: isub
    //   1281: idiv
    //   1282: istore #6
    //   1284: goto -> 1308
    //   1287: iload #15
    //   1289: iconst_1
    //   1290: if_icmpne -> 1305
    //   1293: iload #20
    //   1295: iload #7
    //   1297: isub
    //   1298: iconst_2
    //   1299: idiv
    //   1300: istore #6
    //   1302: goto -> 1308
    //   1305: iconst_0
    //   1306: istore #6
    //   1308: iload #6
    //   1310: istore #8
    //   1312: iload #10
    //   1314: ifle -> 1320
    //   1317: iconst_0
    //   1318: istore #8
    //   1320: iconst_0
    //   1321: istore #6
    //   1323: iload #5
    //   1325: istore #7
    //   1327: iload #6
    //   1329: iload #19
    //   1331: if_icmpge -> 2443
    //   1334: iload #21
    //   1336: ifeq -> 1351
    //   1339: iload #19
    //   1341: iload #6
    //   1343: iconst_1
    //   1344: iadd
    //   1345: isub
    //   1346: istore #5
    //   1348: goto -> 1355
    //   1351: iload #6
    //   1353: istore #5
    //   1355: aload_0
    //   1356: getfield widgets : Ljava/util/ArrayList;
    //   1359: iload #5
    //   1361: invokevirtual get : (I)Ljava/lang/Object;
    //   1364: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   1367: astore_1
    //   1368: aload_1
    //   1369: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1372: invokevirtual getVisibility : ()I
    //   1375: bipush #8
    //   1377: if_icmpne -> 1405
    //   1380: aload_1
    //   1381: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1384: iload #7
    //   1386: invokevirtual resolve : (I)V
    //   1389: aload_1
    //   1390: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1393: iload #7
    //   1395: invokevirtual resolve : (I)V
    //   1398: iload #7
    //   1400: istore #5
    //   1402: goto -> 1667
    //   1405: iload #7
    //   1407: istore #5
    //   1409: iload #6
    //   1411: ifle -> 1436
    //   1414: iload #21
    //   1416: ifeq -> 1429
    //   1419: iload #7
    //   1421: iload #8
    //   1423: isub
    //   1424: istore #5
    //   1426: goto -> 1436
    //   1429: iload #7
    //   1431: iload #8
    //   1433: iadd
    //   1434: istore #5
    //   1436: iload #5
    //   1438: istore #7
    //   1440: iload #6
    //   1442: ifle -> 1488
    //   1445: iload #5
    //   1447: istore #7
    //   1449: iload #6
    //   1451: iload #13
    //   1453: if_icmplt -> 1488
    //   1456: iload #21
    //   1458: ifeq -> 1476
    //   1461: iload #5
    //   1463: aload_1
    //   1464: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1467: getfield margin : I
    //   1470: isub
    //   1471: istore #7
    //   1473: goto -> 1488
    //   1476: iload #5
    //   1478: aload_1
    //   1479: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1482: getfield margin : I
    //   1485: iadd
    //   1486: istore #7
    //   1488: iload #21
    //   1490: ifeq -> 1505
    //   1493: aload_1
    //   1494: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1497: iload #7
    //   1499: invokevirtual resolve : (I)V
    //   1502: goto -> 1514
    //   1505: aload_1
    //   1506: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1509: iload #7
    //   1511: invokevirtual resolve : (I)V
    //   1514: aload_1
    //   1515: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1518: getfield value : I
    //   1521: istore #9
    //   1523: iload #9
    //   1525: istore #5
    //   1527: aload_1
    //   1528: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1531: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1534: if_acmpne -> 1558
    //   1537: iload #9
    //   1539: istore #5
    //   1541: aload_1
    //   1542: getfield matchConstraintsType : I
    //   1545: iconst_1
    //   1546: if_icmpne -> 1558
    //   1549: aload_1
    //   1550: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1553: getfield wrapValue : I
    //   1556: istore #5
    //   1558: iload #21
    //   1560: ifeq -> 1573
    //   1563: iload #7
    //   1565: iload #5
    //   1567: isub
    //   1568: istore #7
    //   1570: goto -> 1580
    //   1573: iload #7
    //   1575: iload #5
    //   1577: iadd
    //   1578: istore #7
    //   1580: iload #21
    //   1582: ifeq -> 1597
    //   1585: aload_1
    //   1586: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1589: iload #7
    //   1591: invokevirtual resolve : (I)V
    //   1594: goto -> 1606
    //   1597: aload_1
    //   1598: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1601: iload #7
    //   1603: invokevirtual resolve : (I)V
    //   1606: aload_1
    //   1607: iconst_1
    //   1608: putfield resolved : Z
    //   1611: iload #7
    //   1613: istore #5
    //   1615: iload #6
    //   1617: iload #18
    //   1619: if_icmpge -> 1667
    //   1622: iload #7
    //   1624: istore #5
    //   1626: iload #6
    //   1628: iload #14
    //   1630: if_icmpge -> 1667
    //   1633: iload #21
    //   1635: ifeq -> 1654
    //   1638: iload #7
    //   1640: aload_1
    //   1641: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1644: getfield margin : I
    //   1647: ineg
    //   1648: isub
    //   1649: istore #5
    //   1651: goto -> 1667
    //   1654: iload #7
    //   1656: aload_1
    //   1657: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1660: getfield margin : I
    //   1663: ineg
    //   1664: iadd
    //   1665: istore #5
    //   1667: iload #6
    //   1669: iconst_1
    //   1670: iadd
    //   1671: istore #6
    //   1673: iload #5
    //   1675: istore #7
    //   1677: goto -> 1327
    //   1680: iload #6
    //   1682: ifne -> 2044
    //   1685: iload #20
    //   1687: iload #7
    //   1689: isub
    //   1690: iload #15
    //   1692: iconst_1
    //   1693: iadd
    //   1694: idiv
    //   1695: istore #8
    //   1697: iload #10
    //   1699: ifle -> 1705
    //   1702: iconst_0
    //   1703: istore #8
    //   1705: iconst_0
    //   1706: istore #6
    //   1708: iload #6
    //   1710: iload #19
    //   1712: if_icmpge -> 2443
    //   1715: iload #21
    //   1717: ifeq -> 1732
    //   1720: iload #19
    //   1722: iload #6
    //   1724: iconst_1
    //   1725: iadd
    //   1726: isub
    //   1727: istore #7
    //   1729: goto -> 1736
    //   1732: iload #6
    //   1734: istore #7
    //   1736: aload_0
    //   1737: getfield widgets : Ljava/util/ArrayList;
    //   1740: iload #7
    //   1742: invokevirtual get : (I)Ljava/lang/Object;
    //   1745: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   1748: astore_1
    //   1749: aload_1
    //   1750: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   1753: invokevirtual getVisibility : ()I
    //   1756: bipush #8
    //   1758: if_icmpne -> 1782
    //   1761: aload_1
    //   1762: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1765: iload #5
    //   1767: invokevirtual resolve : (I)V
    //   1770: aload_1
    //   1771: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1774: iload #5
    //   1776: invokevirtual resolve : (I)V
    //   1779: goto -> 2035
    //   1782: iload #21
    //   1784: ifeq -> 1797
    //   1787: iload #5
    //   1789: iload #8
    //   1791: isub
    //   1792: istore #7
    //   1794: goto -> 1804
    //   1797: iload #5
    //   1799: iload #8
    //   1801: iadd
    //   1802: istore #7
    //   1804: iload #7
    //   1806: istore #5
    //   1808: iload #6
    //   1810: ifle -> 1856
    //   1813: iload #7
    //   1815: istore #5
    //   1817: iload #6
    //   1819: iload #13
    //   1821: if_icmplt -> 1856
    //   1824: iload #21
    //   1826: ifeq -> 1844
    //   1829: iload #7
    //   1831: aload_1
    //   1832: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1835: getfield margin : I
    //   1838: isub
    //   1839: istore #5
    //   1841: goto -> 1856
    //   1844: iload #7
    //   1846: aload_1
    //   1847: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1850: getfield margin : I
    //   1853: iadd
    //   1854: istore #5
    //   1856: iload #21
    //   1858: ifeq -> 1873
    //   1861: aload_1
    //   1862: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1865: iload #5
    //   1867: invokevirtual resolve : (I)V
    //   1870: goto -> 1882
    //   1873: aload_1
    //   1874: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1877: iload #5
    //   1879: invokevirtual resolve : (I)V
    //   1882: aload_1
    //   1883: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1886: getfield value : I
    //   1889: istore #9
    //   1891: iload #9
    //   1893: istore #7
    //   1895: aload_1
    //   1896: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1899: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   1902: if_acmpne -> 1931
    //   1905: iload #9
    //   1907: istore #7
    //   1909: aload_1
    //   1910: getfield matchConstraintsType : I
    //   1913: iconst_1
    //   1914: if_icmpne -> 1931
    //   1917: iload #9
    //   1919: aload_1
    //   1920: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   1923: getfield wrapValue : I
    //   1926: invokestatic min : (II)I
    //   1929: istore #7
    //   1931: iload #21
    //   1933: ifeq -> 1946
    //   1936: iload #5
    //   1938: iload #7
    //   1940: isub
    //   1941: istore #7
    //   1943: goto -> 1953
    //   1946: iload #5
    //   1948: iload #7
    //   1950: iadd
    //   1951: istore #7
    //   1953: iload #21
    //   1955: ifeq -> 1970
    //   1958: aload_1
    //   1959: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1962: iload #7
    //   1964: invokevirtual resolve : (I)V
    //   1967: goto -> 1979
    //   1970: aload_1
    //   1971: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   1974: iload #7
    //   1976: invokevirtual resolve : (I)V
    //   1979: iload #7
    //   1981: istore #5
    //   1983: iload #6
    //   1985: iload #18
    //   1987: if_icmpge -> 2035
    //   1990: iload #7
    //   1992: istore #5
    //   1994: iload #6
    //   1996: iload #14
    //   1998: if_icmpge -> 2035
    //   2001: iload #21
    //   2003: ifeq -> 2022
    //   2006: iload #7
    //   2008: aload_1
    //   2009: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2012: getfield margin : I
    //   2015: ineg
    //   2016: isub
    //   2017: istore #5
    //   2019: goto -> 2035
    //   2022: iload #7
    //   2024: aload_1
    //   2025: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2028: getfield margin : I
    //   2031: ineg
    //   2032: iadd
    //   2033: istore #5
    //   2035: iload #6
    //   2037: iconst_1
    //   2038: iadd
    //   2039: istore #6
    //   2041: goto -> 1708
    //   2044: iload #6
    //   2046: iconst_2
    //   2047: if_icmpne -> 2443
    //   2050: aload_0
    //   2051: getfield orientation : I
    //   2054: ifne -> 2068
    //   2057: aload_0
    //   2058: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2061: invokevirtual getHorizontalBiasPercent : ()F
    //   2064: fstore_2
    //   2065: goto -> 2076
    //   2068: aload_0
    //   2069: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2072: invokevirtual getVerticalBiasPercent : ()F
    //   2075: fstore_2
    //   2076: fload_2
    //   2077: fstore_3
    //   2078: iload #21
    //   2080: ifeq -> 2087
    //   2083: fconst_1
    //   2084: fload_2
    //   2085: fsub
    //   2086: fstore_3
    //   2087: iload #20
    //   2089: iload #7
    //   2091: isub
    //   2092: i2f
    //   2093: fload_3
    //   2094: fmul
    //   2095: ldc 0.5
    //   2097: fadd
    //   2098: f2i
    //   2099: istore #6
    //   2101: iload #6
    //   2103: iflt -> 2111
    //   2106: iload #10
    //   2108: ifle -> 2114
    //   2111: iconst_0
    //   2112: istore #6
    //   2114: iload #21
    //   2116: ifeq -> 2129
    //   2119: iload #5
    //   2121: iload #6
    //   2123: isub
    //   2124: istore #5
    //   2126: goto -> 2136
    //   2129: iload #5
    //   2131: iload #6
    //   2133: iadd
    //   2134: istore #5
    //   2136: iconst_0
    //   2137: istore #6
    //   2139: iload #6
    //   2141: iload #19
    //   2143: if_icmpge -> 2443
    //   2146: iload #21
    //   2148: ifeq -> 2163
    //   2151: iload #19
    //   2153: iload #6
    //   2155: iconst_1
    //   2156: iadd
    //   2157: isub
    //   2158: istore #7
    //   2160: goto -> 2167
    //   2163: iload #6
    //   2165: istore #7
    //   2167: aload_0
    //   2168: getfield widgets : Ljava/util/ArrayList;
    //   2171: iload #7
    //   2173: invokevirtual get : (I)Ljava/lang/Object;
    //   2176: checkcast androidx/constraintlayout/core/widgets/analyzer/WidgetRun
    //   2179: astore_1
    //   2180: aload_1
    //   2181: getfield widget : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   2184: invokevirtual getVisibility : ()I
    //   2187: bipush #8
    //   2189: if_icmpne -> 2213
    //   2192: aload_1
    //   2193: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2196: iload #5
    //   2198: invokevirtual resolve : (I)V
    //   2201: aload_1
    //   2202: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2205: iload #5
    //   2207: invokevirtual resolve : (I)V
    //   2210: goto -> 2434
    //   2213: iload #5
    //   2215: istore #7
    //   2217: iload #6
    //   2219: ifle -> 2265
    //   2222: iload #5
    //   2224: istore #7
    //   2226: iload #6
    //   2228: iload #13
    //   2230: if_icmplt -> 2265
    //   2233: iload #21
    //   2235: ifeq -> 2253
    //   2238: iload #5
    //   2240: aload_1
    //   2241: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2244: getfield margin : I
    //   2247: isub
    //   2248: istore #7
    //   2250: goto -> 2265
    //   2253: iload #5
    //   2255: aload_1
    //   2256: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2259: getfield margin : I
    //   2262: iadd
    //   2263: istore #7
    //   2265: iload #21
    //   2267: ifeq -> 2282
    //   2270: aload_1
    //   2271: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2274: iload #7
    //   2276: invokevirtual resolve : (I)V
    //   2279: goto -> 2291
    //   2282: aload_1
    //   2283: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2286: iload #7
    //   2288: invokevirtual resolve : (I)V
    //   2291: aload_1
    //   2292: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   2295: getfield value : I
    //   2298: istore #5
    //   2300: aload_1
    //   2301: getfield dimensionBehavior : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2304: getstatic androidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/core/widgets/ConstraintWidget$DimensionBehaviour;
    //   2307: if_acmpne -> 2330
    //   2310: aload_1
    //   2311: getfield matchConstraintsType : I
    //   2314: iconst_1
    //   2315: if_icmpne -> 2330
    //   2318: aload_1
    //   2319: getfield dimension : Landroidx/constraintlayout/core/widgets/analyzer/DimensionDependency;
    //   2322: getfield wrapValue : I
    //   2325: istore #5
    //   2327: goto -> 2330
    //   2330: iload #21
    //   2332: ifeq -> 2345
    //   2335: iload #7
    //   2337: iload #5
    //   2339: isub
    //   2340: istore #7
    //   2342: goto -> 2352
    //   2345: iload #7
    //   2347: iload #5
    //   2349: iadd
    //   2350: istore #7
    //   2352: iload #21
    //   2354: ifeq -> 2369
    //   2357: aload_1
    //   2358: getfield start : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2361: iload #7
    //   2363: invokevirtual resolve : (I)V
    //   2366: goto -> 2378
    //   2369: aload_1
    //   2370: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2373: iload #7
    //   2375: invokevirtual resolve : (I)V
    //   2378: iload #7
    //   2380: istore #5
    //   2382: iload #6
    //   2384: iload #18
    //   2386: if_icmpge -> 2434
    //   2389: iload #7
    //   2391: istore #5
    //   2393: iload #6
    //   2395: iload #14
    //   2397: if_icmpge -> 2434
    //   2400: iload #21
    //   2402: ifeq -> 2421
    //   2405: iload #7
    //   2407: aload_1
    //   2408: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2411: getfield margin : I
    //   2414: ineg
    //   2415: isub
    //   2416: istore #5
    //   2418: goto -> 2434
    //   2421: iload #7
    //   2423: aload_1
    //   2424: getfield end : Landroidx/constraintlayout/core/widgets/analyzer/DependencyNode;
    //   2427: getfield margin : I
    //   2430: ineg
    //   2431: iadd
    //   2432: istore #5
    //   2434: iload #6
    //   2436: iconst_1
    //   2437: iadd
    //   2438: istore #6
    //   2440: goto -> 2139
    //   2443: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\widgets\analyzer\ChainRun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */