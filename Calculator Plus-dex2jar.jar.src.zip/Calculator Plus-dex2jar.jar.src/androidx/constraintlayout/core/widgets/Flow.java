package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.LinearSystem;
import java.util.ArrayList;
import java.util.HashMap;

public class Flow extends VirtualLayout {
  public static final int HORIZONTAL_ALIGN_CENTER = 2;
  
  public static final int HORIZONTAL_ALIGN_END = 1;
  
  public static final int HORIZONTAL_ALIGN_START = 0;
  
  public static final int VERTICAL_ALIGN_BASELINE = 3;
  
  public static final int VERTICAL_ALIGN_BOTTOM = 1;
  
  public static final int VERTICAL_ALIGN_CENTER = 2;
  
  public static final int VERTICAL_ALIGN_TOP = 0;
  
  public static final int WRAP_ALIGNED = 2;
  
  public static final int WRAP_CHAIN = 1;
  
  public static final int WRAP_CHAIN_NEW = 3;
  
  public static final int WRAP_NONE = 0;
  
  private ConstraintWidget[] mAlignedBiggestElementsInCols = null;
  
  private ConstraintWidget[] mAlignedBiggestElementsInRows = null;
  
  private int[] mAlignedDimensions = null;
  
  private ArrayList<WidgetsList> mChainList = new ArrayList<WidgetsList>();
  
  private ConstraintWidget[] mDisplayedWidgets;
  
  private int mDisplayedWidgetsCount = 0;
  
  private float mFirstHorizontalBias = 0.5F;
  
  private int mFirstHorizontalStyle = -1;
  
  private float mFirstVerticalBias = 0.5F;
  
  private int mFirstVerticalStyle = -1;
  
  private int mHorizontalAlign = 2;
  
  private float mHorizontalBias = 0.5F;
  
  private int mHorizontalGap = 0;
  
  private int mHorizontalStyle = -1;
  
  private float mLastHorizontalBias = 0.5F;
  
  private int mLastHorizontalStyle = -1;
  
  private float mLastVerticalBias = 0.5F;
  
  private int mLastVerticalStyle = -1;
  
  private int mMaxElementsWrap = -1;
  
  private int mOrientation = 0;
  
  private int mVerticalAlign = 2;
  
  private float mVerticalBias = 0.5F;
  
  private int mVerticalGap = 0;
  
  private int mVerticalStyle = -1;
  
  private int mWrapMode = 0;
  
  private void createAlignedConstraints(boolean paramBoolean) {
    if (this.mAlignedDimensions != null && this.mAlignedBiggestElementsInCols != null) {
      ConstraintWidget constraintWidget;
      if (this.mAlignedBiggestElementsInRows == null)
        return; 
      int i;
      for (i = 0; i < this.mDisplayedWidgetsCount; i++)
        this.mDisplayedWidgets[i].resetAnchors(); 
      int[] arrayOfInt = this.mAlignedDimensions;
      int j = arrayOfInt[0];
      int k = arrayOfInt[1];
      float f = this.mHorizontalBias;
      arrayOfInt = null;
      i = 0;
      while (i < j) {
        int m;
        ConstraintWidget constraintWidget1;
        if (paramBoolean) {
          m = j - i - 1;
          f = 1.0F - this.mHorizontalBias;
        } else {
          m = i;
        } 
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[m];
        int[] arrayOfInt1 = arrayOfInt;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            arrayOfInt1 = arrayOfInt;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mLeft, this.mLeft, getPaddingLeft());
              constraintWidget2.setHorizontalChainStyle(this.mHorizontalStyle);
              constraintWidget2.setHorizontalBiasPercent(f);
            } 
            if (i == j - 1)
              constraintWidget2.connect(constraintWidget2.mRight, this.mRight, getPaddingRight()); 
            if (i > 0 && arrayOfInt != null) {
              constraintWidget2.connect(constraintWidget2.mLeft, ((ConstraintWidget)arrayOfInt).mRight, this.mHorizontalGap);
              arrayOfInt.connect(((ConstraintWidget)arrayOfInt).mRight, constraintWidget2.mLeft, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      i = 0;
      while (i < k) {
        ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInRows[i];
        ConstraintWidget constraintWidget1 = constraintWidget;
        if (constraintWidget2 != null)
          if (constraintWidget2.getVisibility() == 8) {
            constraintWidget1 = constraintWidget;
          } else {
            if (i == 0) {
              constraintWidget2.connect(constraintWidget2.mTop, this.mTop, getPaddingTop());
              constraintWidget2.setVerticalChainStyle(this.mVerticalStyle);
              constraintWidget2.setVerticalBiasPercent(this.mVerticalBias);
            } 
            if (i == k - 1)
              constraintWidget2.connect(constraintWidget2.mBottom, this.mBottom, getPaddingBottom()); 
            if (i > 0 && constraintWidget != null) {
              constraintWidget2.connect(constraintWidget2.mTop, constraintWidget.mBottom, this.mVerticalGap);
              constraintWidget.connect(constraintWidget.mBottom, constraintWidget2.mTop, 0);
            } 
            constraintWidget1 = constraintWidget2;
          }  
        i++;
        constraintWidget = constraintWidget1;
      } 
      for (i = 0; i < j; i++) {
        int m;
        for (m = 0; m < k; m++) {
          int n = m * j + i;
          if (this.mOrientation == 1)
            n = i * k + m; 
          ConstraintWidget[] arrayOfConstraintWidget = this.mDisplayedWidgets;
          if (n < arrayOfConstraintWidget.length) {
            ConstraintWidget constraintWidget1 = arrayOfConstraintWidget[n];
            if (constraintWidget1 != null && constraintWidget1.getVisibility() != 8) {
              ConstraintWidget constraintWidget2 = this.mAlignedBiggestElementsInCols[i];
              ConstraintWidget constraintWidget3 = this.mAlignedBiggestElementsInRows[m];
              if (constraintWidget1 != constraintWidget2) {
                constraintWidget1.connect(constraintWidget1.mLeft, constraintWidget2.mLeft, 0);
                constraintWidget1.connect(constraintWidget1.mRight, constraintWidget2.mRight, 0);
              } 
              if (constraintWidget1 != constraintWidget3) {
                constraintWidget1.connect(constraintWidget1.mTop, constraintWidget3.mTop, 0);
                constraintWidget1.connect(constraintWidget1.mBottom, constraintWidget3.mBottom, 0);
              } 
            } 
          } 
        } 
      } 
    } 
  }
  
  private final int getWidgetHeight(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 0)
        return 0; 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentHeight * paramInt);
        if (paramInt != paramConstraintWidget.getHeight()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, paramConstraintWidget.getHorizontalDimensionBehaviour(), paramConstraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, paramInt);
        } 
        return paramInt;
      } 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 1)
        return paramConstraintWidget.getHeight(); 
      if (paramConstraintWidget.mMatchConstraintDefaultHeight == 3)
        return (int)(paramConstraintWidget.getWidth() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getHeight();
  }
  
  private final int getWidgetWidth(ConstraintWidget paramConstraintWidget, int paramInt) {
    if (paramConstraintWidget == null)
      return 0; 
    if (paramConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 0)
        return 0; 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 2) {
        paramInt = (int)(paramConstraintWidget.mMatchConstraintPercentWidth * paramInt);
        if (paramInt != paramConstraintWidget.getWidth()) {
          paramConstraintWidget.setMeasureRequested(true);
          measure(paramConstraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, paramInt, paramConstraintWidget.getVerticalDimensionBehaviour(), paramConstraintWidget.getHeight());
        } 
        return paramInt;
      } 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 1)
        return paramConstraintWidget.getWidth(); 
      if (paramConstraintWidget.mMatchConstraintDefaultWidth == 3)
        return (int)(paramConstraintWidget.getHeight() * paramConstraintWidget.mDimensionRatio + 0.5F); 
    } 
    return paramConstraintWidget.getWidth();
  }
  
  private void measureAligned(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    // Byte code:
    //   0: iload_3
    //   1: ifne -> 126
    //   4: aload_0
    //   5: getfield mMaxElementsWrap : I
    //   8: istore #6
    //   10: iload #6
    //   12: istore #8
    //   14: iload #6
    //   16: ifgt -> 116
    //   19: iconst_0
    //   20: istore #6
    //   22: iconst_0
    //   23: istore #9
    //   25: iconst_0
    //   26: istore #7
    //   28: iload #6
    //   30: istore #8
    //   32: iload #9
    //   34: iload_2
    //   35: if_icmpge -> 116
    //   38: iload #7
    //   40: istore #8
    //   42: iload #9
    //   44: ifle -> 56
    //   47: iload #7
    //   49: aload_0
    //   50: getfield mHorizontalGap : I
    //   53: iadd
    //   54: istore #8
    //   56: aload_1
    //   57: iload #9
    //   59: aaload
    //   60: astore #13
    //   62: aload #13
    //   64: ifnonnull -> 74
    //   67: iload #8
    //   69: istore #7
    //   71: goto -> 107
    //   74: iload #8
    //   76: aload_0
    //   77: aload #13
    //   79: iload #4
    //   81: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   84: iadd
    //   85: istore #7
    //   87: iload #7
    //   89: iload #4
    //   91: if_icmple -> 101
    //   94: iload #6
    //   96: istore #8
    //   98: goto -> 116
    //   101: iload #6
    //   103: iconst_1
    //   104: iadd
    //   105: istore #6
    //   107: iload #9
    //   109: iconst_1
    //   110: iadd
    //   111: istore #9
    //   113: goto -> 28
    //   116: iload #8
    //   118: istore #7
    //   120: iconst_0
    //   121: istore #6
    //   123: goto -> 245
    //   126: aload_0
    //   127: getfield mMaxElementsWrap : I
    //   130: istore #6
    //   132: iload #6
    //   134: istore #8
    //   136: iload #6
    //   138: ifgt -> 238
    //   141: iconst_0
    //   142: istore #6
    //   144: iconst_0
    //   145: istore #9
    //   147: iconst_0
    //   148: istore #7
    //   150: iload #6
    //   152: istore #8
    //   154: iload #9
    //   156: iload_2
    //   157: if_icmpge -> 238
    //   160: iload #7
    //   162: istore #8
    //   164: iload #9
    //   166: ifle -> 178
    //   169: iload #7
    //   171: aload_0
    //   172: getfield mVerticalGap : I
    //   175: iadd
    //   176: istore #8
    //   178: aload_1
    //   179: iload #9
    //   181: aaload
    //   182: astore #13
    //   184: aload #13
    //   186: ifnonnull -> 196
    //   189: iload #8
    //   191: istore #7
    //   193: goto -> 229
    //   196: iload #8
    //   198: aload_0
    //   199: aload #13
    //   201: iload #4
    //   203: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   206: iadd
    //   207: istore #7
    //   209: iload #7
    //   211: iload #4
    //   213: if_icmple -> 223
    //   216: iload #6
    //   218: istore #8
    //   220: goto -> 238
    //   223: iload #6
    //   225: iconst_1
    //   226: iadd
    //   227: istore #6
    //   229: iload #9
    //   231: iconst_1
    //   232: iadd
    //   233: istore #9
    //   235: goto -> 150
    //   238: iconst_0
    //   239: istore #7
    //   241: iload #8
    //   243: istore #6
    //   245: aload_0
    //   246: getfield mAlignedDimensions : [I
    //   249: ifnonnull -> 259
    //   252: aload_0
    //   253: iconst_2
    //   254: newarray int
    //   256: putfield mAlignedDimensions : [I
    //   259: iload #6
    //   261: ifne -> 277
    //   264: iload #6
    //   266: istore #11
    //   268: iload #7
    //   270: istore #9
    //   272: iload_3
    //   273: iconst_1
    //   274: if_icmpeq -> 294
    //   277: iload #7
    //   279: ifne -> 308
    //   282: iload_3
    //   283: ifne -> 308
    //   286: iload #7
    //   288: istore #9
    //   290: iload #6
    //   292: istore #11
    //   294: iconst_1
    //   295: istore #12
    //   297: iload #11
    //   299: istore #6
    //   301: iload #9
    //   303: istore #7
    //   305: goto -> 311
    //   308: iconst_0
    //   309: istore #12
    //   311: iload #12
    //   313: ifne -> 844
    //   316: iload_3
    //   317: ifne -> 336
    //   320: iload_2
    //   321: i2f
    //   322: iload #7
    //   324: i2f
    //   325: fdiv
    //   326: f2d
    //   327: invokestatic ceil : (D)D
    //   330: d2i
    //   331: istore #6
    //   333: goto -> 349
    //   336: iload_2
    //   337: i2f
    //   338: iload #6
    //   340: i2f
    //   341: fdiv
    //   342: f2d
    //   343: invokestatic ceil : (D)D
    //   346: d2i
    //   347: istore #7
    //   349: aload_0
    //   350: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   353: astore #13
    //   355: aload #13
    //   357: ifnull -> 380
    //   360: aload #13
    //   362: arraylength
    //   363: iload #7
    //   365: if_icmpge -> 371
    //   368: goto -> 380
    //   371: aload #13
    //   373: aconst_null
    //   374: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   377: goto -> 389
    //   380: aload_0
    //   381: iload #7
    //   383: anewarray androidx/constraintlayout/core/widgets/ConstraintWidget
    //   386: putfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   389: aload_0
    //   390: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   393: astore #13
    //   395: aload #13
    //   397: ifnull -> 420
    //   400: aload #13
    //   402: arraylength
    //   403: iload #6
    //   405: if_icmpge -> 411
    //   408: goto -> 420
    //   411: aload #13
    //   413: aconst_null
    //   414: invokestatic fill : ([Ljava/lang/Object;Ljava/lang/Object;)V
    //   417: goto -> 429
    //   420: aload_0
    //   421: iload #6
    //   423: anewarray androidx/constraintlayout/core/widgets/ConstraintWidget
    //   426: putfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   429: iconst_0
    //   430: istore #8
    //   432: iload #8
    //   434: iload #7
    //   436: if_icmpge -> 602
    //   439: iconst_0
    //   440: istore #9
    //   442: iload #9
    //   444: iload #6
    //   446: if_icmpge -> 593
    //   449: iload #9
    //   451: iload #7
    //   453: imul
    //   454: iload #8
    //   456: iadd
    //   457: istore #10
    //   459: iload_3
    //   460: iconst_1
    //   461: if_icmpne -> 474
    //   464: iload #8
    //   466: iload #6
    //   468: imul
    //   469: iload #9
    //   471: iadd
    //   472: istore #10
    //   474: iload #10
    //   476: aload_1
    //   477: arraylength
    //   478: if_icmplt -> 484
    //   481: goto -> 584
    //   484: aload_1
    //   485: iload #10
    //   487: aaload
    //   488: astore #13
    //   490: aload #13
    //   492: ifnonnull -> 498
    //   495: goto -> 584
    //   498: aload_0
    //   499: aload #13
    //   501: iload #4
    //   503: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   506: istore #10
    //   508: aload_0
    //   509: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   512: iload #8
    //   514: aaload
    //   515: astore #14
    //   517: aload #14
    //   519: ifnull -> 532
    //   522: aload #14
    //   524: invokevirtual getWidth : ()I
    //   527: iload #10
    //   529: if_icmpge -> 541
    //   532: aload_0
    //   533: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   536: iload #8
    //   538: aload #13
    //   540: aastore
    //   541: aload_0
    //   542: aload #13
    //   544: iload #4
    //   546: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   549: istore #10
    //   551: aload_0
    //   552: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   555: iload #9
    //   557: aaload
    //   558: astore #14
    //   560: aload #14
    //   562: ifnull -> 575
    //   565: aload #14
    //   567: invokevirtual getHeight : ()I
    //   570: iload #10
    //   572: if_icmpge -> 584
    //   575: aload_0
    //   576: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   579: iload #9
    //   581: aload #13
    //   583: aastore
    //   584: iload #9
    //   586: iconst_1
    //   587: iadd
    //   588: istore #9
    //   590: goto -> 442
    //   593: iload #8
    //   595: iconst_1
    //   596: iadd
    //   597: istore #8
    //   599: goto -> 432
    //   602: iconst_0
    //   603: istore #9
    //   605: iconst_0
    //   606: istore #8
    //   608: iload #9
    //   610: iload #7
    //   612: if_icmpge -> 677
    //   615: aload_0
    //   616: getfield mAlignedBiggestElementsInCols : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   619: iload #9
    //   621: aaload
    //   622: astore #13
    //   624: iload #8
    //   626: istore #10
    //   628: aload #13
    //   630: ifnull -> 664
    //   633: iload #8
    //   635: istore #10
    //   637: iload #9
    //   639: ifle -> 651
    //   642: iload #8
    //   644: aload_0
    //   645: getfield mHorizontalGap : I
    //   648: iadd
    //   649: istore #10
    //   651: iload #10
    //   653: aload_0
    //   654: aload #13
    //   656: iload #4
    //   658: invokespecial getWidgetWidth : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   661: iadd
    //   662: istore #10
    //   664: iload #9
    //   666: iconst_1
    //   667: iadd
    //   668: istore #9
    //   670: iload #10
    //   672: istore #8
    //   674: goto -> 608
    //   677: iconst_0
    //   678: istore #9
    //   680: iconst_0
    //   681: istore #10
    //   683: iload #9
    //   685: iload #6
    //   687: if_icmpge -> 752
    //   690: aload_0
    //   691: getfield mAlignedBiggestElementsInRows : [Landroidx/constraintlayout/core/widgets/ConstraintWidget;
    //   694: iload #9
    //   696: aaload
    //   697: astore #13
    //   699: iload #10
    //   701: istore #11
    //   703: aload #13
    //   705: ifnull -> 739
    //   708: iload #10
    //   710: istore #11
    //   712: iload #9
    //   714: ifle -> 726
    //   717: iload #10
    //   719: aload_0
    //   720: getfield mVerticalGap : I
    //   723: iadd
    //   724: istore #11
    //   726: iload #11
    //   728: aload_0
    //   729: aload #13
    //   731: iload #4
    //   733: invokespecial getWidgetHeight : (Landroidx/constraintlayout/core/widgets/ConstraintWidget;I)I
    //   736: iadd
    //   737: istore #11
    //   739: iload #9
    //   741: iconst_1
    //   742: iadd
    //   743: istore #9
    //   745: iload #11
    //   747: istore #10
    //   749: goto -> 683
    //   752: aload #5
    //   754: iconst_0
    //   755: iload #8
    //   757: iastore
    //   758: aload #5
    //   760: iconst_1
    //   761: iload #10
    //   763: iastore
    //   764: iload_3
    //   765: ifne -> 806
    //   768: iload #6
    //   770: istore #11
    //   772: iload #7
    //   774: istore #9
    //   776: iload #8
    //   778: iload #4
    //   780: if_icmple -> 294
    //   783: iload #6
    //   785: istore #11
    //   787: iload #7
    //   789: istore #9
    //   791: iload #7
    //   793: iconst_1
    //   794: if_icmple -> 294
    //   797: iload #7
    //   799: iconst_1
    //   800: isub
    //   801: istore #7
    //   803: goto -> 311
    //   806: iload #6
    //   808: istore #11
    //   810: iload #7
    //   812: istore #9
    //   814: iload #10
    //   816: iload #4
    //   818: if_icmple -> 294
    //   821: iload #6
    //   823: istore #11
    //   825: iload #7
    //   827: istore #9
    //   829: iload #6
    //   831: iconst_1
    //   832: if_icmple -> 294
    //   835: iload #6
    //   837: iconst_1
    //   838: isub
    //   839: istore #6
    //   841: goto -> 311
    //   844: aload_0
    //   845: getfield mAlignedDimensions : [I
    //   848: astore_1
    //   849: aload_1
    //   850: iconst_0
    //   851: iload #7
    //   853: iastore
    //   854: aload_1
    //   855: iconst_1
    //   856: iload #6
    //   858: iastore
    //   859: return
  }
  
  private void measureChainWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    ConstraintWidget constraintWidget;
    if (paramInt1 == 0)
      return; 
    this.mChainList.clear();
    WidgetsList widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
    this.mChainList.add(widgetsList);
    if (paramInt2 == 0) {
      Object object;
      boolean bool = false;
      int i3 = 0;
      int i4 = 0;
      while (true) {
        Object object1 = object;
        if (i4 < paramInt1) {
          boolean bool1;
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i4];
          int i5 = getWidgetWidth(constraintWidget, paramInt3);
          object1 = object;
          if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = object + 1; 
          if ((i3 == paramInt3 || this.mHorizontalGap + i3 + i5 > paramInt3) && widgetsList.biggest != null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          boolean bool2 = bool1;
          if (!bool1) {
            bool2 = bool1;
            if (i4 > 0) {
              int i6 = this.mMaxElementsWrap;
              bool2 = bool1;
              if (i6 > 0) {
                bool2 = bool1;
                if (i4 % i6 == 0)
                  bool2 = true; 
              } 
            } 
          } 
          if (bool2) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i4);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i4 > 0) {
              i3 += this.mHorizontalGap + i5;
              continue;
            } 
          } 
          i3 = i5;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_16);
        i4++;
        object = SYNTHETIC_LOCAL_VARIABLE_7;
      } 
    } else {
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      while (true) {
        i = i3;
        if (i5 < paramInt1) {
          WidgetsList widgetsList1;
          constraintWidget = paramArrayOfConstraintWidget[i5];
          int i7 = getWidgetHeight(constraintWidget, paramInt3);
          i = i3;
          if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = i3 + 1; 
          if ((i4 == paramInt3 || this.mVerticalGap + i4 + i7 > paramInt3) && widgetsList.biggest != null) {
            i3 = 1;
          } else {
            i3 = 0;
          } 
          int i6 = i3;
          if (i3 == 0) {
            i6 = i3;
            if (i5 > 0) {
              int i8 = this.mMaxElementsWrap;
              i6 = i3;
              if (i8 > 0) {
                i6 = i3;
                if (i5 % i8 == 0)
                  i6 = 1; 
              } 
            } 
          } 
          if (i6 != 0) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i5);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i5 > 0) {
              i4 += this.mVerticalGap + i7;
              continue;
            } 
          } 
          i4 = i7;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add(constraintWidget);
        i5++;
        i3 = i;
      } 
    } 
    int i2 = this.mChainList.size();
    ConstraintAnchor constraintAnchor1 = this.mLeft;
    ConstraintAnchor constraintAnchor4 = this.mTop;
    ConstraintAnchor constraintAnchor2 = this.mRight;
    ConstraintAnchor constraintAnchor3 = this.mBottom;
    int j = getPaddingLeft();
    int k = getPaddingTop();
    int n = getPaddingRight();
    int m = getPaddingBottom();
    if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (i > 0 && paramInt1 != 0)
      for (paramInt1 = 0; paramInt1 < i2; paramInt1++) {
        WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
        if (paramInt2 == 0) {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getWidth());
        } else {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getHeight());
        } 
      }  
    int i = 0;
    int i1 = 0;
    paramInt1 = 0;
    while (paramInt1 < i2) {
      int i3;
      WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
      if (paramInt2 == 0) {
        if (paramInt1 < i2 - 1) {
          constraintAnchor3 = ((WidgetsList)this.mChainList.get(paramInt1 + 1)).biggest.mTop;
          i3 = 0;
        } else {
          constraintAnchor3 = this.mBottom;
          i3 = getPaddingBottom();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mBottom;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, n, i3, paramInt3);
        k = Math.max(i1, widgetsList1.getWidth());
        m = i + widgetsList1.getHeight();
        i = m;
        if (paramInt1 > 0)
          i = m + this.mVerticalGap; 
        constraintAnchor4 = constraintAnchor;
        i1 = 0;
        m = i3;
        i3 = k;
        k = i1;
      } else {
        n = paramInt1;
        if (n < i2 - 1) {
          constraintAnchor2 = ((WidgetsList)this.mChainList.get(n + 1)).biggest.mLeft;
          i3 = 0;
        } else {
          constraintAnchor2 = this.mRight;
          i3 = getPaddingRight();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mRight;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, i3, m, paramInt3);
        j = i1 + widgetsList1.getWidth();
        i1 = Math.max(i, widgetsList1.getHeight());
        i = j;
        if (n > 0)
          i = j + this.mHorizontalGap; 
        j = i1;
        n = i3;
        constraintAnchor1 = constraintAnchor;
        i1 = 0;
        i3 = i;
        i = j;
        j = i1;
      } 
      paramInt1++;
      i1 = i3;
    } 
    paramArrayOfint[0] = i1;
    paramArrayOfint[1] = i;
  }
  
  private void measureChainWrap_new(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    if (paramInt1 == 0)
      return; 
    this.mChainList.clear();
    WidgetsList widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
    this.mChainList.add(widgetsList);
    if (paramInt2 == 0) {
      int i6 = 0;
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      while (true) {
        i = i3;
        if (i5 < paramInt1) {
          int i8 = i6 + 1;
          ConstraintWidget constraintWidget = paramArrayOfConstraintWidget[i5];
          i6 = getWidgetWidth(constraintWidget, paramInt3);
          i = i3;
          if (constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = i3 + 1; 
          if ((i4 == paramInt3 || this.mHorizontalGap + i4 + i6 > paramInt3) && widgetsList.biggest != null) {
            i3 = 1;
          } else {
            i3 = 0;
          } 
          int i7 = i3;
          if (i3 == 0) {
            i7 = i3;
            if (i5 > 0) {
              int i9 = this.mMaxElementsWrap;
              i7 = i3;
              if (i9 > 0) {
                i7 = i3;
                if (i8 > i9)
                  i7 = 1; 
              } 
            } 
          } 
          if (i7 != 0) {
            widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList.setStartIndex(i5);
            this.mChainList.add(widgetsList);
            i3 = i8;
            i4 = i6;
          } else {
            if (i5 > 0) {
              i4 += this.mHorizontalGap + i6;
            } else {
              i4 = i6;
            } 
            i3 = 0;
          } 
          widgetsList.add(constraintWidget);
          i5++;
          i6 = i3;
          i3 = i;
          continue;
        } 
        break;
      } 
    } else {
      int i5 = 0;
      int i3 = 0;
      int i4 = 0;
      while (true) {
        i = i3;
        if (i4 < paramInt1) {
          WidgetsList widgetsList1;
          ConstraintWidget constraintWidget = paramArrayOfConstraintWidget[i4];
          int i7 = getWidgetHeight(constraintWidget, paramInt3);
          i = i3;
          if (constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT)
            i = i3 + 1; 
          if ((i5 == paramInt3 || this.mVerticalGap + i5 + i7 > paramInt3) && widgetsList.biggest != null) {
            i3 = 1;
          } else {
            i3 = 0;
          } 
          int i6 = i3;
          if (i3 == 0) {
            i6 = i3;
            if (i4 > 0) {
              int i8 = this.mMaxElementsWrap;
              i6 = i3;
              if (i8 > 0) {
                i6 = i3;
                if (i8 < 0)
                  i6 = 1; 
              } 
            } 
          } 
          if (i6 != 0) {
            widgetsList1 = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
            widgetsList1.setStartIndex(i4);
            this.mChainList.add(widgetsList1);
          } else {
            widgetsList1 = widgetsList;
            if (i4 > 0) {
              i3 = i5 + this.mVerticalGap + i7;
              continue;
            } 
          } 
          i3 = i7;
          widgetsList = widgetsList1;
          continue;
        } 
        break;
        widgetsList.add((ConstraintWidget)SYNTHETIC_LOCAL_VARIABLE_16);
        i4++;
        i5 = i3;
        i3 = i;
      } 
    } 
    int i2 = this.mChainList.size();
    ConstraintAnchor constraintAnchor1 = this.mLeft;
    ConstraintAnchor constraintAnchor4 = this.mTop;
    ConstraintAnchor constraintAnchor2 = this.mRight;
    ConstraintAnchor constraintAnchor3 = this.mBottom;
    int j = getPaddingLeft();
    int k = getPaddingTop();
    int n = getPaddingRight();
    int m = getPaddingBottom();
    if (getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (i > 0 && paramInt1 != 0)
      for (paramInt1 = 0; paramInt1 < i2; paramInt1++) {
        WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
        if (paramInt2 == 0) {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getWidth());
        } else {
          widgetsList1.measureMatchConstraints(paramInt3 - widgetsList1.getHeight());
        } 
      }  
    int i = 0;
    int i1 = 0;
    paramInt1 = 0;
    while (paramInt1 < i2) {
      int i3;
      WidgetsList widgetsList1 = this.mChainList.get(paramInt1);
      if (paramInt2 == 0) {
        if (paramInt1 < i2 - 1) {
          constraintAnchor3 = ((WidgetsList)this.mChainList.get(paramInt1 + 1)).biggest.mTop;
          i3 = 0;
        } else {
          constraintAnchor3 = this.mBottom;
          i3 = getPaddingBottom();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mBottom;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, n, i3, paramInt3);
        k = Math.max(i1, widgetsList1.getWidth());
        m = i + widgetsList1.getHeight();
        i = m;
        if (paramInt1 > 0)
          i = m + this.mVerticalGap; 
        constraintAnchor4 = constraintAnchor;
        i1 = 0;
        m = i3;
        i3 = k;
        k = i1;
      } else {
        n = paramInt1;
        if (n < i2 - 1) {
          constraintAnchor2 = ((WidgetsList)this.mChainList.get(n + 1)).biggest.mLeft;
          i3 = 0;
        } else {
          constraintAnchor2 = this.mRight;
          i3 = getPaddingRight();
        } 
        ConstraintAnchor constraintAnchor = widgetsList1.biggest.mRight;
        widgetsList1.setup(paramInt2, constraintAnchor1, constraintAnchor4, constraintAnchor2, constraintAnchor3, j, k, i3, m, paramInt3);
        j = i1 + widgetsList1.getWidth();
        i1 = Math.max(i, widgetsList1.getHeight());
        i = j;
        if (n > 0)
          i = j + this.mHorizontalGap; 
        j = i1;
        n = i3;
        constraintAnchor1 = constraintAnchor;
        i1 = 0;
        i3 = i;
        i = j;
        j = i1;
      } 
      paramInt1++;
      i1 = i3;
    } 
    paramArrayOfint[0] = i1;
    paramArrayOfint[1] = i;
  }
  
  private void measureNoWrap(ConstraintWidget[] paramArrayOfConstraintWidget, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfint) {
    WidgetsList widgetsList;
    if (paramInt1 == 0)
      return; 
    if (this.mChainList.size() == 0) {
      widgetsList = new WidgetsList(paramInt2, this.mLeft, this.mTop, this.mRight, this.mBottom, paramInt3);
      this.mChainList.add(widgetsList);
    } else {
      widgetsList = this.mChainList.get(0);
      widgetsList.clear();
      ConstraintAnchor constraintAnchor1 = this.mLeft;
      ConstraintAnchor constraintAnchor2 = this.mTop;
      ConstraintAnchor constraintAnchor3 = this.mRight;
      ConstraintAnchor constraintAnchor4 = this.mBottom;
      int i = getPaddingLeft();
      int j = getPaddingTop();
      int k = getPaddingRight();
      int m = getPaddingBottom();
      widgetsList.setup(paramInt2, constraintAnchor1, constraintAnchor2, constraintAnchor3, constraintAnchor4, i, j, k, m, paramInt3);
    } 
    for (paramInt2 = 0; paramInt2 < paramInt1; paramInt2++)
      widgetsList.add(paramArrayOfConstraintWidget[paramInt2]); 
    paramArrayOfint[0] = widgetsList.getWidth();
    paramArrayOfint[1] = widgetsList.getHeight();
  }
  
  public void addToSolver(LinearSystem paramLinearSystem, boolean paramBoolean) {
    super.addToSolver(paramLinearSystem, paramBoolean);
    if (getParent() != null && ((ConstraintWidgetContainer)getParent()).isRtl()) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    int i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i == 3) {
            int j = this.mChainList.size();
            for (i = 0; i < j; i++) {
              boolean bool;
              WidgetsList widgetsList = this.mChainList.get(i);
              if (i == j - 1) {
                bool = true;
              } else {
                bool = false;
              } 
              widgetsList.createConstraints(paramBoolean, i, bool);
            } 
          } 
        } else {
          createAlignedConstraints(paramBoolean);
        } 
      } else {
        int j = this.mChainList.size();
        for (i = 0; i < j; i++) {
          boolean bool;
          WidgetsList widgetsList = this.mChainList.get(i);
          if (i == j - 1) {
            bool = true;
          } else {
            bool = false;
          } 
          widgetsList.createConstraints(paramBoolean, i, bool);
        } 
      } 
    } else if (this.mChainList.size() > 0) {
      ((WidgetsList)this.mChainList.get(0)).createConstraints(paramBoolean, 0, true);
    } 
    needsCallbackFromSolver(false);
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    this.mHorizontalStyle = ((Flow)paramConstraintWidget).mHorizontalStyle;
    this.mVerticalStyle = ((Flow)paramConstraintWidget).mVerticalStyle;
    this.mFirstHorizontalStyle = ((Flow)paramConstraintWidget).mFirstHorizontalStyle;
    this.mFirstVerticalStyle = ((Flow)paramConstraintWidget).mFirstVerticalStyle;
    this.mLastHorizontalStyle = ((Flow)paramConstraintWidget).mLastHorizontalStyle;
    this.mLastVerticalStyle = ((Flow)paramConstraintWidget).mLastVerticalStyle;
    this.mHorizontalBias = ((Flow)paramConstraintWidget).mHorizontalBias;
    this.mVerticalBias = ((Flow)paramConstraintWidget).mVerticalBias;
    this.mFirstHorizontalBias = ((Flow)paramConstraintWidget).mFirstHorizontalBias;
    this.mFirstVerticalBias = ((Flow)paramConstraintWidget).mFirstVerticalBias;
    this.mLastHorizontalBias = ((Flow)paramConstraintWidget).mLastHorizontalBias;
    this.mLastVerticalBias = ((Flow)paramConstraintWidget).mLastVerticalBias;
    this.mHorizontalGap = ((Flow)paramConstraintWidget).mHorizontalGap;
    this.mVerticalGap = ((Flow)paramConstraintWidget).mVerticalGap;
    this.mHorizontalAlign = ((Flow)paramConstraintWidget).mHorizontalAlign;
    this.mVerticalAlign = ((Flow)paramConstraintWidget).mVerticalAlign;
    this.mWrapMode = ((Flow)paramConstraintWidget).mWrapMode;
    this.mMaxElementsWrap = ((Flow)paramConstraintWidget).mMaxElementsWrap;
    this.mOrientation = ((Flow)paramConstraintWidget).mOrientation;
  }
  
  public float getMaxElementsWrap() {
    return this.mMaxElementsWrap;
  }
  
  public void measure(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mWidgetsCount > 0 && !measureChildren()) {
      setMeasure(0, 0);
      needsCallbackFromSolver(false);
      return;
    } 
    int i1 = getPaddingLeft();
    int i2 = getPaddingRight();
    int m = getPaddingTop();
    int n = getPaddingBottom();
    int[] arrayOfInt = new int[2];
    int j = paramInt2 - i1 - i2;
    int i = this.mOrientation;
    if (i == 1)
      j = paramInt4 - m - n; 
    if (i == 0) {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } else {
      if (this.mHorizontalStyle == -1)
        this.mHorizontalStyle = 0; 
      if (this.mVerticalStyle == -1)
        this.mVerticalStyle = 0; 
    } 
    ConstraintWidget[] arrayOfConstraintWidget = this.mWidgets;
    int k = 0;
    for (i = 0; k < this.mWidgetsCount; i = i3) {
      int i3 = i;
      if (this.mWidgets[k].getVisibility() == 8)
        i3 = i + 1; 
      k++;
    } 
    k = this.mWidgetsCount;
    if (i > 0) {
      arrayOfConstraintWidget = new ConstraintWidget[this.mWidgetsCount - i];
      k = 0;
      for (i = 0; k < this.mWidgetsCount; i = i3) {
        ConstraintWidget constraintWidget = this.mWidgets[k];
        int i3 = i;
        if (constraintWidget.getVisibility() != 8) {
          arrayOfConstraintWidget[i] = constraintWidget;
          i3 = i + 1;
        } 
        k++;
      } 
      k = i;
    } 
    this.mDisplayedWidgets = arrayOfConstraintWidget;
    this.mDisplayedWidgetsCount = k;
    i = this.mWrapMode;
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i == 3)
            measureChainWrap_new(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt); 
        } else {
          measureAligned(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
        } 
      } else {
        measureChainWrap(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
      } 
    } else {
      measureNoWrap(arrayOfConstraintWidget, k, this.mOrientation, j, arrayOfInt);
    } 
    boolean bool = true;
    j = arrayOfInt[0] + i1 + i2;
    i = arrayOfInt[1] + m + n;
    if (paramInt1 == 1073741824) {
      paramInt1 = paramInt2;
    } else if (paramInt1 == Integer.MIN_VALUE) {
      paramInt1 = Math.min(j, paramInt2);
    } else if (paramInt1 == 0) {
      paramInt1 = j;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt3 == 1073741824) {
      paramInt2 = paramInt4;
    } else if (paramInt3 == Integer.MIN_VALUE) {
      paramInt2 = Math.min(i, paramInt4);
    } else if (paramInt3 == 0) {
      paramInt2 = i;
    } else {
      paramInt2 = 0;
    } 
    setMeasure(paramInt1, paramInt2);
    setWidth(paramInt1);
    setHeight(paramInt2);
    if (this.mWidgetsCount <= 0)
      bool = false; 
    needsCallbackFromSolver(bool);
  }
  
  public void setFirstHorizontalBias(float paramFloat) {
    this.mFirstHorizontalBias = paramFloat;
  }
  
  public void setFirstHorizontalStyle(int paramInt) {
    this.mFirstHorizontalStyle = paramInt;
  }
  
  public void setFirstVerticalBias(float paramFloat) {
    this.mFirstVerticalBias = paramFloat;
  }
  
  public void setFirstVerticalStyle(int paramInt) {
    this.mFirstVerticalStyle = paramInt;
  }
  
  public void setHorizontalAlign(int paramInt) {
    this.mHorizontalAlign = paramInt;
  }
  
  public void setHorizontalBias(float paramFloat) {
    this.mHorizontalBias = paramFloat;
  }
  
  public void setHorizontalGap(int paramInt) {
    this.mHorizontalGap = paramInt;
  }
  
  public void setHorizontalStyle(int paramInt) {
    this.mHorizontalStyle = paramInt;
  }
  
  public void setLastHorizontalBias(float paramFloat) {
    this.mLastHorizontalBias = paramFloat;
  }
  
  public void setLastHorizontalStyle(int paramInt) {
    this.mLastHorizontalStyle = paramInt;
  }
  
  public void setLastVerticalBias(float paramFloat) {
    this.mLastVerticalBias = paramFloat;
  }
  
  public void setLastVerticalStyle(int paramInt) {
    this.mLastVerticalStyle = paramInt;
  }
  
  public void setMaxElementsWrap(int paramInt) {
    this.mMaxElementsWrap = paramInt;
  }
  
  public void setOrientation(int paramInt) {
    this.mOrientation = paramInt;
  }
  
  public void setVerticalAlign(int paramInt) {
    this.mVerticalAlign = paramInt;
  }
  
  public void setVerticalBias(float paramFloat) {
    this.mVerticalBias = paramFloat;
  }
  
  public void setVerticalGap(int paramInt) {
    this.mVerticalGap = paramInt;
  }
  
  public void setVerticalStyle(int paramInt) {
    this.mVerticalStyle = paramInt;
  }
  
  public void setWrapMode(int paramInt) {
    this.mWrapMode = paramInt;
  }
  
  private class WidgetsList {
    private ConstraintWidget biggest = null;
    
    int biggestDimension = 0;
    
    private ConstraintAnchor mBottom;
    
    private int mCount = 0;
    
    private int mHeight = 0;
    
    private ConstraintAnchor mLeft;
    
    private int mMax = 0;
    
    private int mNbMatchConstraintsWidgets = 0;
    
    private int mOrientation;
    
    private int mPaddingBottom = 0;
    
    private int mPaddingLeft = 0;
    
    private int mPaddingRight = 0;
    
    private int mPaddingTop = 0;
    
    private ConstraintAnchor mRight;
    
    private int mStartIndex = 0;
    
    private ConstraintAnchor mTop;
    
    private int mWidth = 0;
    
    public WidgetsList(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = Flow.this.getPaddingLeft();
      this.mPaddingTop = Flow.this.getPaddingTop();
      this.mPaddingRight = Flow.this.getPaddingRight();
      this.mPaddingBottom = Flow.this.getPaddingBottom();
      this.mMax = param1Int2;
    }
    
    private void recomputeDimensions() {
      this.mWidth = 0;
      this.mHeight = 0;
      this.biggest = null;
      this.biggestDimension = 0;
      int j = this.mCount;
      for (int i = 0; i < j; i++) {
        if (this.mStartIndex + i >= Flow.this.mDisplayedWidgetsCount)
          return; 
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + i];
        if (this.mOrientation == 0) {
          int m = constraintWidget.getWidth();
          int k = Flow.this.mHorizontalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mWidth += m + k;
          k = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          if (this.biggest == null || this.biggestDimension < k) {
            this.biggest = constraintWidget;
            this.biggestDimension = k;
            this.mHeight = k;
          } 
        } else {
          int m = Flow.this.getWidgetWidth(constraintWidget, this.mMax);
          int n = Flow.this.getWidgetHeight(constraintWidget, this.mMax);
          int k = Flow.this.mVerticalGap;
          if (constraintWidget.getVisibility() == 8)
            k = 0; 
          this.mHeight += n + k;
          if (this.biggest == null || this.biggestDimension < m) {
            this.biggest = constraintWidget;
            this.biggestDimension = m;
            this.mWidth = m;
          } 
        } 
      } 
    }
    
    public void add(ConstraintWidget param1ConstraintWidget) {
      int i = this.mOrientation;
      int j = 0;
      int k = 0;
      if (i == 0) {
        i = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        j = Flow.this.mHorizontalGap;
        if (param1ConstraintWidget.getVisibility() == 8)
          j = k; 
        this.mWidth += i + j;
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (this.biggest == null || this.biggestDimension < i) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = i;
          this.mHeight = i;
        } 
      } else {
        int m = Flow.this.getWidgetWidth(param1ConstraintWidget, this.mMax);
        i = Flow.this.getWidgetHeight(param1ConstraintWidget, this.mMax);
        if (param1ConstraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
          this.mNbMatchConstraintsWidgets++;
          i = 0;
        } 
        k = Flow.this.mVerticalGap;
        if (param1ConstraintWidget.getVisibility() != 8)
          j = k; 
        this.mHeight += i + j;
        if (this.biggest == null || this.biggestDimension < m) {
          this.biggest = param1ConstraintWidget;
          this.biggestDimension = m;
          this.mWidth = m;
        } 
      } 
      this.mCount++;
    }
    
    public void clear() {
      this.biggestDimension = 0;
      this.biggest = null;
      this.mWidth = 0;
      this.mHeight = 0;
      this.mStartIndex = 0;
      this.mCount = 0;
      this.mNbMatchConstraintsWidgets = 0;
    }
    
    public void createConstraints(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mCount : I
      //   4: istore #12
      //   6: iconst_0
      //   7: istore #6
      //   9: iload #6
      //   11: iload #12
      //   13: if_icmpge -> 72
      //   16: aload_0
      //   17: getfield mStartIndex : I
      //   20: iload #6
      //   22: iadd
      //   23: aload_0
      //   24: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   27: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   30: if_icmplt -> 36
      //   33: goto -> 72
      //   36: aload_0
      //   37: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   40: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   43: aload_0
      //   44: getfield mStartIndex : I
      //   47: iload #6
      //   49: iadd
      //   50: aaload
      //   51: astore #13
      //   53: aload #13
      //   55: ifnull -> 63
      //   58: aload #13
      //   60: invokevirtual resetAnchors : ()V
      //   63: iload #6
      //   65: iconst_1
      //   66: iadd
      //   67: istore #6
      //   69: goto -> 9
      //   72: iload #12
      //   74: ifeq -> 1791
      //   77: aload_0
      //   78: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   81: ifnonnull -> 85
      //   84: return
      //   85: iload_3
      //   86: ifeq -> 99
      //   89: iload_2
      //   90: ifne -> 99
      //   93: iconst_1
      //   94: istore #9
      //   96: goto -> 102
      //   99: iconst_0
      //   100: istore #9
      //   102: iconst_0
      //   103: istore #6
      //   105: iconst_m1
      //   106: istore #7
      //   108: iconst_m1
      //   109: istore #8
      //   111: iload #6
      //   113: iload #12
      //   115: if_icmpge -> 243
      //   118: iload_1
      //   119: ifeq -> 134
      //   122: iload #12
      //   124: iconst_1
      //   125: isub
      //   126: iload #6
      //   128: isub
      //   129: istore #10
      //   131: goto -> 138
      //   134: iload #6
      //   136: istore #10
      //   138: aload_0
      //   139: getfield mStartIndex : I
      //   142: iload #10
      //   144: iadd
      //   145: aload_0
      //   146: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   149: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   152: if_icmplt -> 158
      //   155: goto -> 243
      //   158: aload_0
      //   159: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   162: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   165: aload_0
      //   166: getfield mStartIndex : I
      //   169: iload #10
      //   171: iadd
      //   172: aaload
      //   173: astore #13
      //   175: iload #7
      //   177: istore #11
      //   179: iload #8
      //   181: istore #10
      //   183: aload #13
      //   185: ifnull -> 226
      //   188: iload #7
      //   190: istore #11
      //   192: iload #8
      //   194: istore #10
      //   196: aload #13
      //   198: invokevirtual getVisibility : ()I
      //   201: ifne -> 226
      //   204: iload #7
      //   206: istore #8
      //   208: iload #7
      //   210: iconst_m1
      //   211: if_icmpne -> 218
      //   214: iload #6
      //   216: istore #8
      //   218: iload #6
      //   220: istore #10
      //   222: iload #8
      //   224: istore #11
      //   226: iload #6
      //   228: iconst_1
      //   229: iadd
      //   230: istore #6
      //   232: iload #11
      //   234: istore #7
      //   236: iload #10
      //   238: istore #8
      //   240: goto -> 111
      //   243: aload_0
      //   244: getfield mOrientation : I
      //   247: istore #6
      //   249: aconst_null
      //   250: astore #14
      //   252: aconst_null
      //   253: astore #13
      //   255: iload #6
      //   257: ifne -> 1063
      //   260: aload_0
      //   261: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   264: astore #16
      //   266: aload #16
      //   268: aload_0
      //   269: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   272: invokestatic access$600 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   275: invokevirtual setVerticalChainStyle : (I)V
      //   278: aload_0
      //   279: getfield mPaddingTop : I
      //   282: istore #10
      //   284: iload #10
      //   286: istore #6
      //   288: iload_2
      //   289: ifle -> 304
      //   292: iload #10
      //   294: aload_0
      //   295: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   298: invokestatic access$100 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   301: iadd
      //   302: istore #6
      //   304: aload #16
      //   306: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   309: aload_0
      //   310: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   313: iload #6
      //   315: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   318: pop
      //   319: iload_3
      //   320: ifeq -> 340
      //   323: aload #16
      //   325: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   328: aload_0
      //   329: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   332: aload_0
      //   333: getfield mPaddingBottom : I
      //   336: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   339: pop
      //   340: iload_2
      //   341: ifle -> 364
      //   344: aload_0
      //   345: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   348: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   351: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   354: aload #16
      //   356: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   359: iconst_0
      //   360: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   363: pop
      //   364: aload_0
      //   365: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   368: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   371: iconst_3
      //   372: if_icmpne -> 464
      //   375: aload #16
      //   377: invokevirtual hasBaseline : ()Z
      //   380: ifne -> 464
      //   383: iconst_0
      //   384: istore_2
      //   385: iload_2
      //   386: iload #12
      //   388: if_icmpge -> 464
      //   391: iload_1
      //   392: ifeq -> 406
      //   395: iload #12
      //   397: iconst_1
      //   398: isub
      //   399: iload_2
      //   400: isub
      //   401: istore #6
      //   403: goto -> 409
      //   406: iload_2
      //   407: istore #6
      //   409: aload_0
      //   410: getfield mStartIndex : I
      //   413: iload #6
      //   415: iadd
      //   416: aload_0
      //   417: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   420: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   423: if_icmplt -> 429
      //   426: goto -> 464
      //   429: aload_0
      //   430: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   433: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   436: aload_0
      //   437: getfield mStartIndex : I
      //   440: iload #6
      //   442: iadd
      //   443: aaload
      //   444: astore #14
      //   446: aload #14
      //   448: invokevirtual hasBaseline : ()Z
      //   451: ifeq -> 457
      //   454: goto -> 468
      //   457: iload_2
      //   458: iconst_1
      //   459: iadd
      //   460: istore_2
      //   461: goto -> 385
      //   464: aload #16
      //   466: astore #14
      //   468: iconst_0
      //   469: istore #6
      //   471: iload #6
      //   473: iload #12
      //   475: if_icmpge -> 1791
      //   478: iload_1
      //   479: ifeq -> 493
      //   482: iload #12
      //   484: iconst_1
      //   485: isub
      //   486: iload #6
      //   488: isub
      //   489: istore_2
      //   490: goto -> 496
      //   493: iload #6
      //   495: istore_2
      //   496: aload_0
      //   497: getfield mStartIndex : I
      //   500: iload_2
      //   501: iadd
      //   502: aload_0
      //   503: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   506: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   509: if_icmplt -> 513
      //   512: return
      //   513: aload_0
      //   514: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   517: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   520: aload_0
      //   521: getfield mStartIndex : I
      //   524: iload_2
      //   525: iadd
      //   526: aaload
      //   527: astore #15
      //   529: aload #15
      //   531: ifnonnull -> 537
      //   534: goto -> 1054
      //   537: iload #6
      //   539: ifne -> 560
      //   542: aload #15
      //   544: aload #15
      //   546: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   549: aload_0
      //   550: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   553: aload_0
      //   554: getfield mPaddingLeft : I
      //   557: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   560: iload_2
      //   561: ifne -> 738
      //   564: aload_0
      //   565: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   568: invokestatic access$800 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   571: istore #10
      //   573: aload_0
      //   574: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   577: invokestatic access$900 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   580: fstore #5
      //   582: fload #5
      //   584: fstore #4
      //   586: iload_1
      //   587: ifeq -> 596
      //   590: fconst_1
      //   591: fload #5
      //   593: fsub
      //   594: fstore #4
      //   596: aload_0
      //   597: getfield mStartIndex : I
      //   600: ifne -> 660
      //   603: aload_0
      //   604: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   607: invokestatic access$1000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   610: iconst_m1
      //   611: if_icmpeq -> 660
      //   614: aload_0
      //   615: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   618: invokestatic access$1000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   621: istore_2
      //   622: iload_1
      //   623: ifeq -> 644
      //   626: aload_0
      //   627: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   630: invokestatic access$1100 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   633: fstore #4
      //   635: fconst_1
      //   636: fload #4
      //   638: fsub
      //   639: fstore #4
      //   641: goto -> 653
      //   644: aload_0
      //   645: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   648: invokestatic access$1100 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   651: fstore #4
      //   653: fload #4
      //   655: fstore #5
      //   657: goto -> 725
      //   660: iload #10
      //   662: istore_2
      //   663: fload #4
      //   665: fstore #5
      //   667: iload_3
      //   668: ifeq -> 725
      //   671: iload #10
      //   673: istore_2
      //   674: fload #4
      //   676: fstore #5
      //   678: aload_0
      //   679: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   682: invokestatic access$1200 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   685: iconst_m1
      //   686: if_icmpeq -> 725
      //   689: aload_0
      //   690: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   693: invokestatic access$1200 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   696: istore_2
      //   697: iload_1
      //   698: ifeq -> 713
      //   701: aload_0
      //   702: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   705: invokestatic access$1300 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   708: fstore #4
      //   710: goto -> 635
      //   713: aload_0
      //   714: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   717: invokestatic access$1300 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   720: fstore #4
      //   722: goto -> 653
      //   725: aload #15
      //   727: iload_2
      //   728: invokevirtual setHorizontalChainStyle : (I)V
      //   731: aload #15
      //   733: fload #5
      //   735: invokevirtual setHorizontalBiasPercent : (F)V
      //   738: iload #6
      //   740: iload #12
      //   742: iconst_1
      //   743: isub
      //   744: if_icmpne -> 765
      //   747: aload #15
      //   749: aload #15
      //   751: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   754: aload_0
      //   755: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   758: aload_0
      //   759: getfield mPaddingRight : I
      //   762: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   765: aload #13
      //   767: ifnull -> 846
      //   770: aload #15
      //   772: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   775: aload #13
      //   777: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   780: aload_0
      //   781: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   784: invokestatic access$000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   787: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   790: pop
      //   791: iload #6
      //   793: iload #7
      //   795: if_icmpne -> 810
      //   798: aload #15
      //   800: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   803: aload_0
      //   804: getfield mPaddingLeft : I
      //   807: invokevirtual setGoneMargin : (I)V
      //   810: aload #13
      //   812: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   815: aload #15
      //   817: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   820: iconst_0
      //   821: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   824: pop
      //   825: iload #6
      //   827: iload #8
      //   829: iconst_1
      //   830: iadd
      //   831: if_icmpne -> 846
      //   834: aload #13
      //   836: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   839: aload_0
      //   840: getfield mPaddingRight : I
      //   843: invokevirtual setGoneMargin : (I)V
      //   846: aload #15
      //   848: astore #13
      //   850: aload #15
      //   852: aload #16
      //   854: if_acmpeq -> 534
      //   857: aload_0
      //   858: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   861: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   864: iconst_3
      //   865: if_icmpne -> 913
      //   868: aload #14
      //   870: invokevirtual hasBaseline : ()Z
      //   873: ifeq -> 913
      //   876: aload #15
      //   878: aload #14
      //   880: if_acmpeq -> 913
      //   883: aload #15
      //   885: invokevirtual hasBaseline : ()Z
      //   888: ifeq -> 913
      //   891: aload #15
      //   893: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   896: aload #14
      //   898: getfield mBaseline : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   901: iconst_0
      //   902: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   905: pop
      //   906: aload #15
      //   908: astore #13
      //   910: goto -> 1054
      //   913: aload_0
      //   914: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   917: invokestatic access$700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   920: istore_2
      //   921: iload_2
      //   922: ifeq -> 1035
      //   925: iload_2
      //   926: iconst_1
      //   927: if_icmpeq -> 1013
      //   930: iload #9
      //   932: ifeq -> 976
      //   935: aload #15
      //   937: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   940: aload_0
      //   941: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   944: aload_0
      //   945: getfield mPaddingTop : I
      //   948: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   951: pop
      //   952: aload #15
      //   954: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   957: aload_0
      //   958: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   961: aload_0
      //   962: getfield mPaddingBottom : I
      //   965: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   968: pop
      //   969: aload #15
      //   971: astore #13
      //   973: goto -> 1054
      //   976: aload #15
      //   978: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   981: aload #16
      //   983: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   986: iconst_0
      //   987: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   990: pop
      //   991: aload #15
      //   993: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   996: aload #16
      //   998: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1001: iconst_0
      //   1002: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1005: pop
      //   1006: aload #15
      //   1008: astore #13
      //   1010: goto -> 1054
      //   1013: aload #15
      //   1015: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1018: aload #16
      //   1020: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1023: iconst_0
      //   1024: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1027: pop
      //   1028: aload #15
      //   1030: astore #13
      //   1032: goto -> 1054
      //   1035: aload #15
      //   1037: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1040: aload #16
      //   1042: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1045: iconst_0
      //   1046: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1049: pop
      //   1050: aload #15
      //   1052: astore #13
      //   1054: iload #6
      //   1056: iconst_1
      //   1057: iadd
      //   1058: istore #6
      //   1060: goto -> 471
      //   1063: aload_0
      //   1064: getfield biggest : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1067: astore #15
      //   1069: aload #15
      //   1071: aload_0
      //   1072: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1075: invokestatic access$800 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1078: invokevirtual setHorizontalChainStyle : (I)V
      //   1081: aload_0
      //   1082: getfield mPaddingLeft : I
      //   1085: istore #10
      //   1087: iload #10
      //   1089: istore #6
      //   1091: iload_2
      //   1092: ifle -> 1107
      //   1095: iload #10
      //   1097: aload_0
      //   1098: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1101: invokestatic access$000 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1104: iadd
      //   1105: istore #6
      //   1107: iload_1
      //   1108: ifeq -> 1174
      //   1111: aload #15
      //   1113: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1116: aload_0
      //   1117: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1120: iload #6
      //   1122: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1125: pop
      //   1126: iload_3
      //   1127: ifeq -> 1147
      //   1130: aload #15
      //   1132: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1135: aload_0
      //   1136: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1139: aload_0
      //   1140: getfield mPaddingRight : I
      //   1143: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1146: pop
      //   1147: iload_2
      //   1148: ifle -> 1234
      //   1151: aload_0
      //   1152: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1155: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1158: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1161: aload #15
      //   1163: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1166: iconst_0
      //   1167: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1170: pop
      //   1171: goto -> 1234
      //   1174: aload #15
      //   1176: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1179: aload_0
      //   1180: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1183: iload #6
      //   1185: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1188: pop
      //   1189: iload_3
      //   1190: ifeq -> 1210
      //   1193: aload #15
      //   1195: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1198: aload_0
      //   1199: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1202: aload_0
      //   1203: getfield mPaddingRight : I
      //   1206: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1209: pop
      //   1210: iload_2
      //   1211: ifle -> 1234
      //   1214: aload_0
      //   1215: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1218: getfield mOwner : Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1221: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1224: aload #15
      //   1226: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1229: iconst_0
      //   1230: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1233: pop
      //   1234: iconst_0
      //   1235: istore #6
      //   1237: aload #14
      //   1239: astore #13
      //   1241: iload #6
      //   1243: iload #12
      //   1245: if_icmpge -> 1791
      //   1248: aload_0
      //   1249: getfield mStartIndex : I
      //   1252: iload #6
      //   1254: iadd
      //   1255: aload_0
      //   1256: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1259: invokestatic access$400 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1262: if_icmplt -> 1266
      //   1265: return
      //   1266: aload_0
      //   1267: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1270: invokestatic access$500 : (Landroidx/constraintlayout/core/widgets/Flow;)[Landroidx/constraintlayout/core/widgets/ConstraintWidget;
      //   1273: aload_0
      //   1274: getfield mStartIndex : I
      //   1277: iload #6
      //   1279: iadd
      //   1280: aaload
      //   1281: astore #14
      //   1283: aload #14
      //   1285: ifnonnull -> 1291
      //   1288: goto -> 1782
      //   1291: iload #6
      //   1293: ifne -> 1429
      //   1296: aload #14
      //   1298: aload #14
      //   1300: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1303: aload_0
      //   1304: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1307: aload_0
      //   1308: getfield mPaddingTop : I
      //   1311: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   1314: aload_0
      //   1315: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1318: invokestatic access$600 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1321: istore #10
      //   1323: aload_0
      //   1324: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1327: invokestatic access$1400 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1330: fstore #5
      //   1332: aload_0
      //   1333: getfield mStartIndex : I
      //   1336: ifne -> 1370
      //   1339: aload_0
      //   1340: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1343: invokestatic access$1500 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1346: iconst_m1
      //   1347: if_icmpeq -> 1370
      //   1350: aload_0
      //   1351: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1354: invokestatic access$1500 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1357: istore_2
      //   1358: aload_0
      //   1359: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1362: invokestatic access$1600 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1365: fstore #4
      //   1367: goto -> 1416
      //   1370: iload #10
      //   1372: istore_2
      //   1373: fload #5
      //   1375: fstore #4
      //   1377: iload_3
      //   1378: ifeq -> 1416
      //   1381: iload #10
      //   1383: istore_2
      //   1384: fload #5
      //   1386: fstore #4
      //   1388: aload_0
      //   1389: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1392: invokestatic access$1700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1395: iconst_m1
      //   1396: if_icmpeq -> 1416
      //   1399: aload_0
      //   1400: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1403: invokestatic access$1700 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1406: istore_2
      //   1407: aload_0
      //   1408: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1411: invokestatic access$1800 : (Landroidx/constraintlayout/core/widgets/Flow;)F
      //   1414: fstore #4
      //   1416: aload #14
      //   1418: iload_2
      //   1419: invokevirtual setVerticalChainStyle : (I)V
      //   1422: aload #14
      //   1424: fload #4
      //   1426: invokevirtual setVerticalBiasPercent : (F)V
      //   1429: iload #6
      //   1431: iload #12
      //   1433: iconst_1
      //   1434: isub
      //   1435: if_icmpne -> 1456
      //   1438: aload #14
      //   1440: aload #14
      //   1442: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1445: aload_0
      //   1446: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1449: aload_0
      //   1450: getfield mPaddingBottom : I
      //   1453: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)V
      //   1456: aload #13
      //   1458: ifnull -> 1537
      //   1461: aload #14
      //   1463: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1466: aload #13
      //   1468: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1471: aload_0
      //   1472: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1475: invokestatic access$100 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1478: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1481: pop
      //   1482: iload #6
      //   1484: iload #7
      //   1486: if_icmpne -> 1501
      //   1489: aload #14
      //   1491: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1494: aload_0
      //   1495: getfield mPaddingTop : I
      //   1498: invokevirtual setGoneMargin : (I)V
      //   1501: aload #13
      //   1503: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1506: aload #14
      //   1508: getfield mTop : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1511: iconst_0
      //   1512: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1515: pop
      //   1516: iload #6
      //   1518: iload #8
      //   1520: iconst_1
      //   1521: iadd
      //   1522: if_icmpne -> 1537
      //   1525: aload #13
      //   1527: getfield mBottom : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1530: aload_0
      //   1531: getfield mPaddingBottom : I
      //   1534: invokevirtual setGoneMargin : (I)V
      //   1537: aload #14
      //   1539: aload #15
      //   1541: if_acmpeq -> 1778
      //   1544: iload_1
      //   1545: ifeq -> 1642
      //   1548: aload_0
      //   1549: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1552: invokestatic access$1900 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1555: istore_2
      //   1556: iload_2
      //   1557: ifeq -> 1624
      //   1560: iload_2
      //   1561: iconst_1
      //   1562: if_icmpeq -> 1606
      //   1565: iload_2
      //   1566: iconst_2
      //   1567: if_icmpeq -> 1573
      //   1570: goto -> 1778
      //   1573: aload #14
      //   1575: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1578: aload #15
      //   1580: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1583: iconst_0
      //   1584: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1587: pop
      //   1588: aload #14
      //   1590: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1593: aload #15
      //   1595: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1598: iconst_0
      //   1599: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1602: pop
      //   1603: goto -> 1778
      //   1606: aload #14
      //   1608: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1611: aload #15
      //   1613: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1616: iconst_0
      //   1617: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1620: pop
      //   1621: goto -> 1778
      //   1624: aload #14
      //   1626: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1629: aload #15
      //   1631: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1634: iconst_0
      //   1635: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1638: pop
      //   1639: goto -> 1778
      //   1642: aload_0
      //   1643: getfield this$0 : Landroidx/constraintlayout/core/widgets/Flow;
      //   1646: invokestatic access$1900 : (Landroidx/constraintlayout/core/widgets/Flow;)I
      //   1649: istore_2
      //   1650: iload_2
      //   1651: ifeq -> 1760
      //   1654: iload_2
      //   1655: iconst_1
      //   1656: if_icmpeq -> 1742
      //   1659: iload_2
      //   1660: iconst_2
      //   1661: if_icmpeq -> 1667
      //   1664: goto -> 1778
      //   1667: iload #9
      //   1669: ifeq -> 1709
      //   1672: aload #14
      //   1674: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1677: aload_0
      //   1678: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1681: aload_0
      //   1682: getfield mPaddingLeft : I
      //   1685: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1688: pop
      //   1689: aload #14
      //   1691: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1694: aload_0
      //   1695: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1698: aload_0
      //   1699: getfield mPaddingRight : I
      //   1702: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1705: pop
      //   1706: goto -> 1778
      //   1709: aload #14
      //   1711: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1714: aload #15
      //   1716: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1719: iconst_0
      //   1720: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1723: pop
      //   1724: aload #14
      //   1726: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1729: aload #15
      //   1731: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1734: iconst_0
      //   1735: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1738: pop
      //   1739: goto -> 1778
      //   1742: aload #14
      //   1744: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1747: aload #15
      //   1749: getfield mRight : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1752: iconst_0
      //   1753: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1756: pop
      //   1757: goto -> 1778
      //   1760: aload #14
      //   1762: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1765: aload #15
      //   1767: getfield mLeft : Landroidx/constraintlayout/core/widgets/ConstraintAnchor;
      //   1770: iconst_0
      //   1771: invokevirtual connect : (Landroidx/constraintlayout/core/widgets/ConstraintAnchor;I)Z
      //   1774: pop
      //   1775: goto -> 1778
      //   1778: aload #14
      //   1780: astore #13
      //   1782: iload #6
      //   1784: iconst_1
      //   1785: iadd
      //   1786: istore #6
      //   1788: goto -> 1241
      //   1791: return
    }
    
    public int getHeight() {
      return (this.mOrientation == 1) ? (this.mHeight - Flow.this.mVerticalGap) : this.mHeight;
    }
    
    public int getWidth() {
      return (this.mOrientation == 0) ? (this.mWidth - Flow.this.mHorizontalGap) : this.mWidth;
    }
    
    public void measureMatchConstraints(int param1Int) {
      int j = this.mNbMatchConstraintsWidgets;
      if (j == 0)
        return; 
      int i = this.mCount;
      j = param1Int / j;
      for (param1Int = 0; param1Int < i && this.mStartIndex + param1Int < Flow.this.mDisplayedWidgetsCount; param1Int++) {
        ConstraintWidget constraintWidget = Flow.this.mDisplayedWidgets[this.mStartIndex + param1Int];
        if (this.mOrientation == 0) {
          if (constraintWidget != null && constraintWidget.getHorizontalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultWidth == 0)
            Flow.this.measure(constraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, j, constraintWidget.getVerticalDimensionBehaviour(), constraintWidget.getHeight()); 
        } else if (constraintWidget != null && constraintWidget.getVerticalDimensionBehaviour() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.mMatchConstraintDefaultHeight == 0) {
          Flow.this.measure(constraintWidget, constraintWidget.getHorizontalDimensionBehaviour(), constraintWidget.getWidth(), ConstraintWidget.DimensionBehaviour.FIXED, j);
        } 
      } 
      recomputeDimensions();
    }
    
    public void setStartIndex(int param1Int) {
      this.mStartIndex = param1Int;
    }
    
    public void setup(int param1Int1, ConstraintAnchor param1ConstraintAnchor1, ConstraintAnchor param1ConstraintAnchor2, ConstraintAnchor param1ConstraintAnchor3, ConstraintAnchor param1ConstraintAnchor4, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.mOrientation = param1Int1;
      this.mLeft = param1ConstraintAnchor1;
      this.mTop = param1ConstraintAnchor2;
      this.mRight = param1ConstraintAnchor3;
      this.mBottom = param1ConstraintAnchor4;
      this.mPaddingLeft = param1Int2;
      this.mPaddingTop = param1Int3;
      this.mPaddingRight = param1Int4;
      this.mPaddingBottom = param1Int5;
      this.mMax = param1Int6;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\widgets\Flow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */