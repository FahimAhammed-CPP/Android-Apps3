package androidx.constraintlayout.core.widgets;

import androidx.constraintlayout.core.widgets.analyzer.Grouping;
import androidx.constraintlayout.core.widgets.analyzer.WidgetGroup;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class HelperWidget extends ConstraintWidget implements Helper {
  public ConstraintWidget[] mWidgets = new ConstraintWidget[4];
  
  public int mWidgetsCount = 0;
  
  public void add(ConstraintWidget paramConstraintWidget) {
    if (paramConstraintWidget != this) {
      if (paramConstraintWidget == null)
        return; 
      int i = this.mWidgetsCount;
      ConstraintWidget[] arrayOfConstraintWidget = this.mWidgets;
      if (i + 1 > arrayOfConstraintWidget.length)
        this.mWidgets = Arrays.<ConstraintWidget>copyOf(arrayOfConstraintWidget, arrayOfConstraintWidget.length * 2); 
      arrayOfConstraintWidget = this.mWidgets;
      i = this.mWidgetsCount;
      arrayOfConstraintWidget[i] = paramConstraintWidget;
      this.mWidgetsCount = i + 1;
    } 
  }
  
  public void addDependents(ArrayList<WidgetGroup> paramArrayList, int paramInt, WidgetGroup paramWidgetGroup) {
    int j;
    byte b = 0;
    int i = 0;
    while (true) {
      j = b;
      if (i < this.mWidgetsCount) {
        paramWidgetGroup.add(this.mWidgets[i]);
        i++;
        continue;
      } 
      break;
    } 
    while (j < this.mWidgetsCount) {
      Grouping.findDependents(this.mWidgets[j], paramInt, paramArrayList, paramWidgetGroup);
      j++;
    } 
  }
  
  public void copy(ConstraintWidget paramConstraintWidget, HashMap<ConstraintWidget, ConstraintWidget> paramHashMap) {
    super.copy(paramConstraintWidget, paramHashMap);
    paramConstraintWidget = paramConstraintWidget;
    int i = 0;
    this.mWidgetsCount = 0;
    int j = ((HelperWidget)paramConstraintWidget).mWidgetsCount;
    while (i < j) {
      add(paramHashMap.get(((HelperWidget)paramConstraintWidget).mWidgets[i]));
      i++;
    } 
  }
  
  public int findGroupInDependents(int paramInt) {
    for (int i = 0; i < this.mWidgetsCount; i++) {
      ConstraintWidget constraintWidget = this.mWidgets[i];
      if (paramInt == 0 && constraintWidget.horizontalGroup != -1)
        return constraintWidget.horizontalGroup; 
      if (paramInt == 1 && constraintWidget.verticalGroup != -1)
        return constraintWidget.verticalGroup; 
    } 
    return -1;
  }
  
  public void removeAllIds() {
    this.mWidgetsCount = 0;
    Arrays.fill((Object[])this.mWidgets, (Object)null);
  }
  
  public void updateConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer) {}
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\core\widgets\HelperWidget.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */