package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.constraintlayout.motion.widget.Debug;
import androidx.constraintlayout.motion.widget.Key;
import androidx.constraintlayout.motion.widget.KeyAttributes;
import androidx.constraintlayout.motion.widget.KeyPosition;
import androidx.constraintlayout.motion.widget.MotionController;
import androidx.constraintlayout.motion.widget.MotionHelper;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.R;
import java.util.HashMap;

public class MotionEffect extends MotionHelper {
  public static final int AUTO = -1;
  
  public static final int EAST = 2;
  
  public static final int NORTH = 0;
  
  public static final int SOUTH = 1;
  
  public static final String TAG = "FadeMove";
  
  private static final int UNSET = -1;
  
  public static final int WEST = 3;
  
  private int fadeMove = -1;
  
  private float motionEffectAlpha = 0.1F;
  
  private int motionEffectEnd = 50;
  
  private int motionEffectStart = 49;
  
  private boolean motionEffectStrictMove = true;
  
  private int motionEffectTranslationX = 0;
  
  private int motionEffectTranslationY = 0;
  
  private int viewTransitionId = -1;
  
  public MotionEffect(Context paramContext) {
    super(paramContext);
  }
  
  public MotionEffect(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramContext, paramAttributeSet);
  }
  
  public MotionEffect(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramContext, paramAttributeSet);
  }
  
  private void init(Context paramContext, AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.MotionEffect);
      int j = typedArray.getIndexCount();
      int i;
      for (i = 0; i < j; i++) {
        int k = typedArray.getIndex(i);
        if (k == R.styleable.MotionEffect_motionEffect_start) {
          k = typedArray.getInt(k, this.motionEffectStart);
          this.motionEffectStart = k;
          this.motionEffectStart = Math.max(Math.min(k, 99), 0);
        } else if (k == R.styleable.MotionEffect_motionEffect_end) {
          k = typedArray.getInt(k, this.motionEffectEnd);
          this.motionEffectEnd = k;
          this.motionEffectEnd = Math.max(Math.min(k, 99), 0);
        } else if (k == R.styleable.MotionEffect_motionEffect_translationX) {
          this.motionEffectTranslationX = typedArray.getDimensionPixelOffset(k, this.motionEffectTranslationX);
        } else if (k == R.styleable.MotionEffect_motionEffect_translationY) {
          this.motionEffectTranslationY = typedArray.getDimensionPixelOffset(k, this.motionEffectTranslationY);
        } else if (k == R.styleable.MotionEffect_motionEffect_alpha) {
          this.motionEffectAlpha = typedArray.getFloat(k, this.motionEffectAlpha);
        } else if (k == R.styleable.MotionEffect_motionEffect_move) {
          this.fadeMove = typedArray.getInt(k, this.fadeMove);
        } else if (k == R.styleable.MotionEffect_motionEffect_strict) {
          this.motionEffectStrictMove = typedArray.getBoolean(k, this.motionEffectStrictMove);
        } else if (k == R.styleable.MotionEffect_motionEffect_viewTransition) {
          this.viewTransitionId = typedArray.getResourceId(k, this.viewTransitionId);
        } 
      } 
      i = this.motionEffectStart;
      j = this.motionEffectEnd;
      if (i == j)
        if (i > 0) {
          this.motionEffectStart = i - 1;
        } else {
          this.motionEffectEnd = j + 1;
        }  
      typedArray.recycle();
    } 
  }
  
  public boolean isDecorator() {
    return true;
  }
  
  public void onPreSetup(MotionLayout paramMotionLayout, HashMap<View, MotionController> paramHashMap) {
    StringBuilder stringBuilder;
    Key key1;
    Key key2;
    Key key3;
    View[] arrayOfView = getViews((ConstraintLayout)getParent());
    if (arrayOfView == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append(Debug.getLoc());
      stringBuilder.append(" views = null");
      Log.v("FadeMove", stringBuilder.toString());
      return;
    } 
    KeyAttributes keyAttributes2 = new KeyAttributes();
    KeyAttributes keyAttributes3 = new KeyAttributes();
    keyAttributes2.setValue("alpha", Float.valueOf(this.motionEffectAlpha));
    keyAttributes3.setValue("alpha", Float.valueOf(this.motionEffectAlpha));
    keyAttributes2.setFramePosition(this.motionEffectStart);
    keyAttributes3.setFramePosition(this.motionEffectEnd);
    KeyPosition keyPosition1 = new KeyPosition();
    keyPosition1.setFramePosition(this.motionEffectStart);
    keyPosition1.setType(0);
    keyPosition1.setValue("percentX", Integer.valueOf(0));
    keyPosition1.setValue("percentY", Integer.valueOf(0));
    KeyPosition keyPosition2 = new KeyPosition();
    keyPosition2.setFramePosition(this.motionEffectEnd);
    keyPosition2.setType(0);
    keyPosition2.setValue("percentX", Integer.valueOf(1));
    keyPosition2.setValue("percentY", Integer.valueOf(1));
    int i = this.motionEffectTranslationX;
    KeyAttributes keyAttributes1 = null;
    if (i > 0) {
      key1 = (Key)new KeyAttributes();
      KeyAttributes keyAttributes = new KeyAttributes();
      key1.setValue("translationX", Integer.valueOf(this.motionEffectTranslationX));
      key1.setFramePosition(this.motionEffectEnd);
      keyAttributes.setValue("translationX", Integer.valueOf(0));
      keyAttributes.setFramePosition(this.motionEffectEnd - 1);
    } else {
      key1 = null;
      key2 = key1;
    } 
    if (this.motionEffectTranslationY > 0) {
      keyAttributes1 = new KeyAttributes();
      key3 = (Key)new KeyAttributes();
      keyAttributes1.setValue("translationY", Integer.valueOf(this.motionEffectTranslationY));
      keyAttributes1.setFramePosition(this.motionEffectEnd);
      key3.setValue("translationY", Integer.valueOf(0));
      key3.setFramePosition(this.motionEffectEnd - 1);
    } else {
      key3 = null;
    } 
    i = this.fadeMove;
    int j = i;
    if (i == -1) {
      int[] arrayOfInt = new int[4];
      for (i = 0; i < arrayOfView.length; i++) {
        MotionController motionController = paramHashMap.get(arrayOfView[i]);
        if (motionController != null) {
          float f1 = motionController.getFinalX() - motionController.getStartX();
          float f2 = motionController.getFinalY() - motionController.getStartY();
          if (f2 < 0.0F)
            arrayOfInt[1] = arrayOfInt[1] + 1; 
          if (f2 > 0.0F)
            arrayOfInt[0] = arrayOfInt[0] + 1; 
          if (f1 > 0.0F)
            arrayOfInt[3] = arrayOfInt[3] + 1; 
          if (f1 < 0.0F)
            arrayOfInt[2] = arrayOfInt[2] + 1; 
        } 
      } 
      int m = arrayOfInt[0];
      i = 1;
      int k = 0;
      while (true) {
        j = k;
        if (i < 4) {
          int n = arrayOfInt[i];
          j = m;
          if (m < n) {
            k = i;
            j = n;
          } 
          i++;
          m = j;
          continue;
        } 
        break;
      } 
    } 
    for (i = 0; i < arrayOfView.length; i++) {
      MotionController motionController = paramHashMap.get(arrayOfView[i]);
      if (motionController != null) {
        int k;
        float f1 = motionController.getFinalX() - motionController.getStartX();
        float f2 = motionController.getFinalY() - motionController.getStartY();
        if ((j == 0) ? (f2 > 0.0F && (!this.motionEffectStrictMove || f1 == 0.0F)) : ((j == 1) ? (f2 < 0.0F && (!this.motionEffectStrictMove || f1 == 0.0F)) : ((j == 2) ? (f1 < 0.0F && (!this.motionEffectStrictMove || f2 == 0.0F)) : (j == 3 && f1 > 0.0F && (!this.motionEffectStrictMove || f2 == 0.0F))))) {
          k = 0;
        } else {
          k = 1;
        } 
        if (k) {
          k = this.viewTransitionId;
          if (k == -1) {
            motionController.addKey((Key)keyAttributes2);
            motionController.addKey((Key)keyAttributes3);
            motionController.addKey((Key)keyPosition1);
            motionController.addKey((Key)keyPosition2);
            if (this.motionEffectTranslationX > 0) {
              motionController.addKey(key1);
              motionController.addKey(key2);
            } 
            if (this.motionEffectTranslationY > 0) {
              motionController.addKey((Key)keyAttributes1);
              motionController.addKey(key3);
            } 
          } else {
            stringBuilder.applyViewTransition(k, motionController);
          } 
        } 
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\constraintlayout\helper\widget\MotionEffect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */