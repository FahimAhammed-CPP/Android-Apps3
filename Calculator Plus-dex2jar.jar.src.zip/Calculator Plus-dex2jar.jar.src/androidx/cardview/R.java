package androidx.cardview;

public final class R {
  public static final class attr {
    public static final int cardBackgroundColor = 2130968731;
    
    public static final int cardCornerRadius = 2130968732;
    
    public static final int cardElevation = 2130968733;
    
    public static final int cardMaxElevation = 2130968735;
    
    public static final int cardPreventCornerOverlap = 2130968736;
    
    public static final int cardUseCompatPadding = 2130968737;
    
    public static final int cardViewStyle = 2130968738;
    
    public static final int contentPadding = 2130968898;
    
    public static final int contentPaddingBottom = 2130968899;
    
    public static final int contentPaddingLeft = 2130968901;
    
    public static final int contentPaddingRight = 2130968902;
    
    public static final int contentPaddingTop = 2130968904;
  }
  
  public static final class color {
    public static final int cardview_dark_background = 2131099699;
    
    public static final int cardview_light_background = 2131099700;
    
    public static final int cardview_shadow_end_color = 2131099701;
    
    public static final int cardview_shadow_start_color = 2131099702;
  }
  
  public static final class dimen {
    public static final int cardview_compat_inset_shadow = 2131165269;
    
    public static final int cardview_default_elevation = 2131165270;
    
    public static final int cardview_default_radius = 2131165271;
  }
  
  public static final class style {
    public static final int Base_CardView = 2132082702;
    
    public static final int CardView = 2132082970;
    
    public static final int CardView_Dark = 2132082971;
    
    public static final int CardView_Light = 2132082972;
  }
  
  public static final class styleable {
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130968731, 2130968732, 2130968733, 2130968735, 2130968736, 2130968737, 2130968898, 2130968899, 
        2130968901, 2130968902, 2130968904 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\cardview\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */