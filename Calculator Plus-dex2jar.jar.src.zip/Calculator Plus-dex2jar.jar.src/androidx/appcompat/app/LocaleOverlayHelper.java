package androidx.appcompat.app;

import android.os.LocaleList;
import androidx.core.os.LocaleListCompat;
import java.util.LinkedHashSet;
import java.util.Locale;

final class LocaleOverlayHelper {
  private static LocaleListCompat combineLocales(LocaleListCompat paramLocaleListCompat1, LocaleListCompat paramLocaleListCompat2) {
    LinkedHashSet<Locale> linkedHashSet = new LinkedHashSet();
    for (int i = 0; i < paramLocaleListCompat1.size() + paramLocaleListCompat2.size(); i++) {
      Locale locale;
      if (i < paramLocaleListCompat1.size()) {
        locale = paramLocaleListCompat1.get(i);
      } else {
        locale = paramLocaleListCompat2.get(i - paramLocaleListCompat1.size());
      } 
      if (locale != null)
        linkedHashSet.add(locale); 
    } 
    return LocaleListCompat.create(linkedHashSet.<Locale>toArray(new Locale[linkedHashSet.size()]));
  }
  
  static LocaleListCompat combineLocalesIfOverlayExists(LocaleList paramLocaleList1, LocaleList paramLocaleList2) {
    return (paramLocaleList1 == null || paramLocaleList1.isEmpty()) ? LocaleListCompat.getEmptyLocaleList() : combineLocales(LocaleListCompat.wrap(paramLocaleList1), LocaleListCompat.wrap(paramLocaleList2));
  }
  
  static LocaleListCompat combineLocalesIfOverlayExists(LocaleListCompat paramLocaleListCompat1, LocaleListCompat paramLocaleListCompat2) {
    return (paramLocaleListCompat1 == null || paramLocaleListCompat1.isEmpty()) ? LocaleListCompat.getEmptyLocaleList() : combineLocales(paramLocaleListCompat1, paramLocaleListCompat2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\appcompat\app\LocaleOverlayHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */