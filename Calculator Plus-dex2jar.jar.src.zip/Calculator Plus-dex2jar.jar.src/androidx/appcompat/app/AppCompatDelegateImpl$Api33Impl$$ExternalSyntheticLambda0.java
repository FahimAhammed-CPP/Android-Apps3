package androidx.appcompat.app;

import android.window.OnBackInvokedCallback;



/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\appcompat\app\AppCompatDelegateImpl$Api33Impl$$ExternalSyntheticLambda0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */