package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.widget.CompoundButtonCompat;

class AppCompatCompoundButtonHelper {
  private ColorStateList mButtonTintList = null;
  
  private PorterDuff.Mode mButtonTintMode = null;
  
  private boolean mHasButtonTint = false;
  
  private boolean mHasButtonTintMode = false;
  
  private boolean mSkipNextApply;
  
  private final CompoundButton mView;
  
  AppCompatCompoundButtonHelper(CompoundButton paramCompoundButton) {
    this.mView = paramCompoundButton;
  }
  
  void applyButtonTint() {
    Drawable drawable = CompoundButtonCompat.getButtonDrawable(this.mView);
    if (drawable != null && (this.mHasButtonTint || this.mHasButtonTintMode)) {
      drawable = DrawableCompat.wrap(drawable).mutate();
      if (this.mHasButtonTint)
        DrawableCompat.setTintList(drawable, this.mButtonTintList); 
      if (this.mHasButtonTintMode)
        DrawableCompat.setTintMode(drawable, this.mButtonTintMode); 
      if (drawable.isStateful())
        drawable.setState(this.mView.getDrawableState()); 
      this.mView.setButtonDrawable(drawable);
    } 
  }
  
  int getCompoundPaddingLeft(int paramInt) {
    return paramInt;
  }
  
  ColorStateList getSupportButtonTintList() {
    return this.mButtonTintList;
  }
  
  PorterDuff.Mode getSupportButtonTintMode() {
    return this.mButtonTintMode;
  }
  
  void loadFromAttributes(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mView : Landroid/widget/CompoundButton;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: aload_1
    //   8: getstatic androidx/appcompat/R$styleable.CompoundButton : [I
    //   11: iload_2
    //   12: iconst_0
    //   13: invokestatic obtainStyledAttributes : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/TintTypedArray;
    //   16: astore_3
    //   17: aload_0
    //   18: getfield mView : Landroid/widget/CompoundButton;
    //   21: astore #4
    //   23: aload #4
    //   25: aload #4
    //   27: invokevirtual getContext : ()Landroid/content/Context;
    //   30: getstatic androidx/appcompat/R$styleable.CompoundButton : [I
    //   33: aload_1
    //   34: aload_3
    //   35: invokevirtual getWrappedTypeArray : ()Landroid/content/res/TypedArray;
    //   38: iload_2
    //   39: iconst_0
    //   40: invokestatic saveAttributeDataForStyleable : (Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    //   43: aload_3
    //   44: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonCompat : I
    //   47: invokevirtual hasValue : (I)Z
    //   50: ifeq -> 88
    //   53: aload_3
    //   54: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonCompat : I
    //   57: iconst_0
    //   58: invokevirtual getResourceId : (II)I
    //   61: istore_2
    //   62: iload_2
    //   63: ifeq -> 88
    //   66: aload_0
    //   67: getfield mView : Landroid/widget/CompoundButton;
    //   70: astore_1
    //   71: aload_1
    //   72: aload_1
    //   73: invokevirtual getContext : ()Landroid/content/Context;
    //   76: iload_2
    //   77: invokestatic getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   80: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   83: iconst_1
    //   84: istore_2
    //   85: goto -> 90
    //   88: iconst_0
    //   89: istore_2
    //   90: iload_2
    //   91: ifne -> 134
    //   94: aload_3
    //   95: getstatic androidx/appcompat/R$styleable.CompoundButton_android_button : I
    //   98: invokevirtual hasValue : (I)Z
    //   101: ifeq -> 134
    //   104: aload_3
    //   105: getstatic androidx/appcompat/R$styleable.CompoundButton_android_button : I
    //   108: iconst_0
    //   109: invokevirtual getResourceId : (II)I
    //   112: istore_2
    //   113: iload_2
    //   114: ifeq -> 134
    //   117: aload_0
    //   118: getfield mView : Landroid/widget/CompoundButton;
    //   121: astore_1
    //   122: aload_1
    //   123: aload_1
    //   124: invokevirtual getContext : ()Landroid/content/Context;
    //   127: iload_2
    //   128: invokestatic getDrawable : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   131: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   134: aload_3
    //   135: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonTint : I
    //   138: invokevirtual hasValue : (I)Z
    //   141: ifeq -> 158
    //   144: aload_0
    //   145: getfield mView : Landroid/widget/CompoundButton;
    //   148: aload_3
    //   149: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonTint : I
    //   152: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   155: invokestatic setButtonTintList : (Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V
    //   158: aload_3
    //   159: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonTintMode : I
    //   162: invokevirtual hasValue : (I)Z
    //   165: ifeq -> 187
    //   168: aload_0
    //   169: getfield mView : Landroid/widget/CompoundButton;
    //   172: aload_3
    //   173: getstatic androidx/appcompat/R$styleable.CompoundButton_buttonTintMode : I
    //   176: iconst_m1
    //   177: invokevirtual getInt : (II)I
    //   180: aconst_null
    //   181: invokestatic parseTintMode : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   184: invokestatic setButtonTintMode : (Landroid/widget/CompoundButton;Landroid/graphics/PorterDuff$Mode;)V
    //   187: aload_3
    //   188: invokevirtual recycle : ()V
    //   191: return
    //   192: astore_1
    //   193: aload_3
    //   194: invokevirtual recycle : ()V
    //   197: aload_1
    //   198: athrow
    //   199: astore_1
    //   200: goto -> 88
    // Exception table:
    //   from	to	target	type
    //   43	62	192	finally
    //   66	83	199	android/content/res/Resources$NotFoundException
    //   66	83	192	finally
    //   94	113	192	finally
    //   117	134	192	finally
    //   134	158	192	finally
    //   158	187	192	finally
  }
  
  void onSetButtonDrawable() {
    if (this.mSkipNextApply) {
      this.mSkipNextApply = false;
      return;
    } 
    this.mSkipNextApply = true;
    applyButtonTint();
  }
  
  void setSupportButtonTintList(ColorStateList paramColorStateList) {
    this.mButtonTintList = paramColorStateList;
    this.mHasButtonTint = true;
    applyButtonTint();
  }
  
  void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    this.mButtonTintMode = paramMode;
    this.mHasButtonTintMode = true;
    applyButtonTint();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\appcompat\widget\AppCompatCompoundButtonHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */