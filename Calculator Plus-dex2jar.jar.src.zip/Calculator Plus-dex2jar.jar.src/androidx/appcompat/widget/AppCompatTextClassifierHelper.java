package androidx.appcompat.widget;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.util.Preconditions;

final class AppCompatTextClassifierHelper {
  private TextClassifier mTextClassifier;
  
  private TextView mTextView;
  
  AppCompatTextClassifierHelper(TextView paramTextView) {
    this.mTextView = (TextView)Preconditions.checkNotNull(paramTextView);
  }
  
  public TextClassifier getTextClassifier() {
    TextClassifier textClassifier2 = this.mTextClassifier;
    TextClassifier textClassifier1 = textClassifier2;
    if (textClassifier2 == null)
      textClassifier1 = Api26Impl.getTextClassifier(this.mTextView); 
    return textClassifier1;
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    this.mTextClassifier = paramTextClassifier;
  }
  
  private static final class Api26Impl {
    static TextClassifier getTextClassifier(TextView param1TextView) {
      TextClassificationManager textClassificationManager = (TextClassificationManager)param1TextView.getContext().getSystemService(TextClassificationManager.class);
      return (textClassificationManager != null) ? textClassificationManager.getTextClassifier() : TextClassifier.NO_OP;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextClassifierHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */