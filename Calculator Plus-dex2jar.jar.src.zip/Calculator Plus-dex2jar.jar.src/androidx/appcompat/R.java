package androidx.appcompat;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
    
    public static final int btn_checkbox_to_checked_box_inner_merged_animation = 2130771980;
    
    public static final int btn_checkbox_to_checked_box_outer_merged_animation = 2130771981;
    
    public static final int btn_checkbox_to_checked_icon_null_animation = 2130771982;
    
    public static final int btn_checkbox_to_unchecked_box_inner_merged_animation = 2130771983;
    
    public static final int btn_checkbox_to_unchecked_check_path_merged_animation = 2130771984;
    
    public static final int btn_checkbox_to_unchecked_icon_null_animation = 2130771985;
    
    public static final int btn_radio_to_off_mtrl_dot_group_animation = 2130771986;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_animation = 2130771987;
    
    public static final int btn_radio_to_off_mtrl_ring_outer_path_animation = 2130771988;
    
    public static final int btn_radio_to_on_mtrl_dot_group_animation = 2130771989;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_animation = 2130771990;
    
    public static final int btn_radio_to_on_mtrl_ring_outer_path_animation = 2130771991;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130968579;
    
    public static final int actionBarItemBackground = 2130968580;
    
    public static final int actionBarPopupTheme = 2130968581;
    
    public static final int actionBarSize = 2130968582;
    
    public static final int actionBarSplitStyle = 2130968583;
    
    public static final int actionBarStyle = 2130968584;
    
    public static final int actionBarTabBarStyle = 2130968585;
    
    public static final int actionBarTabStyle = 2130968586;
    
    public static final int actionBarTabTextStyle = 2130968587;
    
    public static final int actionBarTheme = 2130968588;
    
    public static final int actionBarWidgetTheme = 2130968589;
    
    public static final int actionButtonStyle = 2130968590;
    
    public static final int actionDropDownStyle = 2130968591;
    
    public static final int actionLayout = 2130968592;
    
    public static final int actionMenuTextAppearance = 2130968593;
    
    public static final int actionMenuTextColor = 2130968594;
    
    public static final int actionModeBackground = 2130968595;
    
    public static final int actionModeCloseButtonStyle = 2130968596;
    
    public static final int actionModeCloseContentDescription = 2130968597;
    
    public static final int actionModeCloseDrawable = 2130968598;
    
    public static final int actionModeCopyDrawable = 2130968599;
    
    public static final int actionModeCutDrawable = 2130968600;
    
    public static final int actionModeFindDrawable = 2130968601;
    
    public static final int actionModePasteDrawable = 2130968602;
    
    public static final int actionModePopupWindowStyle = 2130968603;
    
    public static final int actionModeSelectAllDrawable = 2130968604;
    
    public static final int actionModeShareDrawable = 2130968605;
    
    public static final int actionModeSplitBackground = 2130968606;
    
    public static final int actionModeStyle = 2130968607;
    
    public static final int actionModeTheme = 2130968608;
    
    public static final int actionModeWebSearchDrawable = 2130968609;
    
    public static final int actionOverflowButtonStyle = 2130968610;
    
    public static final int actionOverflowMenuStyle = 2130968611;
    
    public static final int actionProviderClass = 2130968612;
    
    public static final int actionViewClass = 2130968614;
    
    public static final int activityChooserViewStyle = 2130968616;
    
    public static final int alertDialogButtonGroupStyle = 2130968619;
    
    public static final int alertDialogCenterButtons = 2130968620;
    
    public static final int alertDialogStyle = 2130968621;
    
    public static final int alertDialogTheme = 2130968622;
    
    public static final int allowStacking = 2130968623;
    
    public static final int alphabeticModifiers = 2130968625;
    
    public static final int arrowHeadLength = 2130968637;
    
    public static final int arrowShaftLength = 2130968638;
    
    public static final int autoCompleteTextViewStyle = 2130968641;
    
    public static final int autoSizeMaxTextSize = 2130968643;
    
    public static final int autoSizeMinTextSize = 2130968644;
    
    public static final int autoSizePresetSizes = 2130968645;
    
    public static final int autoSizeStepGranularity = 2130968646;
    
    public static final int autoSizeTextType = 2130968647;
    
    public static final int background = 2130968649;
    
    public static final int backgroundSplit = 2130968656;
    
    public static final int backgroundStacked = 2130968657;
    
    public static final int backgroundTint = 2130968658;
    
    public static final int backgroundTintMode = 2130968659;
    
    public static final int barLength = 2130968675;
    
    public static final int borderlessButtonStyle = 2130968696;
    
    public static final int buttonBarButtonStyle = 2130968715;
    
    public static final int buttonBarNegativeButtonStyle = 2130968716;
    
    public static final int buttonBarNeutralButtonStyle = 2130968717;
    
    public static final int buttonBarPositiveButtonStyle = 2130968718;
    
    public static final int buttonBarStyle = 2130968719;
    
    public static final int buttonCompat = 2130968720;
    
    public static final int buttonGravity = 2130968721;
    
    public static final int buttonIconDimen = 2130968723;
    
    public static final int buttonPanelSideLayout = 2130968726;
    
    public static final int buttonStyle = 2130968727;
    
    public static final int buttonStyleSmall = 2130968728;
    
    public static final int buttonTint = 2130968729;
    
    public static final int buttonTintMode = 2130968730;
    
    public static final int checkMarkCompat = 2130968751;
    
    public static final int checkMarkTint = 2130968752;
    
    public static final int checkMarkTintMode = 2130968753;
    
    public static final int checkboxStyle = 2130968754;
    
    public static final int checkedTextViewStyle = 2130968765;
    
    public static final int closeIcon = 2130968801;
    
    public static final int closeItemLayout = 2130968808;
    
    public static final int collapseContentDescription = 2130968809;
    
    public static final int collapseIcon = 2130968810;
    
    public static final int color = 2130968820;
    
    public static final int colorAccent = 2130968821;
    
    public static final int colorBackgroundFloating = 2130968822;
    
    public static final int colorButtonNormal = 2130968823;
    
    public static final int colorControlActivated = 2130968825;
    
    public static final int colorControlHighlight = 2130968826;
    
    public static final int colorControlNormal = 2130968827;
    
    public static final int colorError = 2130968828;
    
    public static final int colorPrimary = 2130968853;
    
    public static final int colorPrimaryDark = 2130968855;
    
    public static final int colorSwitchThumbNormal = 2130968876;
    
    public static final int commitIcon = 2130968881;
    
    public static final int contentDescription = 2130968891;
    
    public static final int contentInsetEnd = 2130968892;
    
    public static final int contentInsetEndWithActions = 2130968893;
    
    public static final int contentInsetLeft = 2130968894;
    
    public static final int contentInsetRight = 2130968895;
    
    public static final int contentInsetStart = 2130968896;
    
    public static final int contentInsetStartWithNavigation = 2130968897;
    
    public static final int controlBackground = 2130968907;
    
    public static final int customNavigationLayout = 2130968936;
    
    public static final int defaultQueryHint = 2130968949;
    
    public static final int dialogCornerRadius = 2130968956;
    
    public static final int dialogPreferredPadding = 2130968957;
    
    public static final int dialogTheme = 2130968958;
    
    public static final int displayOptions = 2130968959;
    
    public static final int divider = 2130968960;
    
    public static final int dividerHorizontal = 2130968962;
    
    public static final int dividerPadding = 2130968965;
    
    public static final int dividerVertical = 2130968967;
    
    public static final int drawableBottomCompat = 2130968972;
    
    public static final int drawableEndCompat = 2130968973;
    
    public static final int drawableLeftCompat = 2130968974;
    
    public static final int drawableRightCompat = 2130968975;
    
    public static final int drawableSize = 2130968976;
    
    public static final int drawableStartCompat = 2130968977;
    
    public static final int drawableTint = 2130968978;
    
    public static final int drawableTintMode = 2130968979;
    
    public static final int drawableTopCompat = 2130968980;
    
    public static final int drawerArrowStyle = 2130968981;
    
    public static final int dropDownListViewStyle = 2130968984;
    
    public static final int dropdownListPreferredItemHeight = 2130968985;
    
    public static final int editTextBackground = 2130968988;
    
    public static final int editTextColor = 2130968989;
    
    public static final int editTextStyle = 2130968990;
    
    public static final int elevation = 2130968991;
    
    public static final int emojiCompatEnabled = 2130968995;
    
    public static final int expandActivityOverflowButtonDrawable = 2130969020;
    
    public static final int firstBaselineToTopHeight = 2130969055;
    
    public static final int fontFamily = 2130969091;
    
    public static final int fontVariationSettings = 2130969100;
    
    public static final int gapBetweenBars = 2130969106;
    
    public static final int goIcon = 2130969108;
    
    public static final int height = 2130969114;
    
    public static final int hideOnContentScroll = 2130969122;
    
    public static final int homeAsUpIndicator = 2130969128;
    
    public static final int homeLayout = 2130969129;
    
    public static final int icon = 2130969133;
    
    public static final int iconTint = 2130969139;
    
    public static final int iconTintMode = 2130969140;
    
    public static final int iconifiedByDefault = 2130969141;
    
    public static final int imageButtonStyle = 2130969144;
    
    public static final int indeterminateProgressStyle = 2130969150;
    
    public static final int initialActivityCount = 2130969156;
    
    public static final int isLightTheme = 2130969158;
    
    public static final int itemPadding = 2130969172;
    
    public static final int lastBaselineToBottomHeight = 2130969198;
    
    public static final int layout = 2130969201;
    
    public static final int lineHeight = 2130969278;
    
    public static final int listChoiceBackgroundIndicator = 2130969281;
    
    public static final int listChoiceIndicatorMultipleAnimated = 2130969282;
    
    public static final int listChoiceIndicatorSingleAnimated = 2130969283;
    
    public static final int listDividerAlertDialog = 2130969284;
    
    public static final int listItemLayout = 2130969285;
    
    public static final int listLayout = 2130969286;
    
    public static final int listMenuViewStyle = 2130969287;
    
    public static final int listPopupWindowStyle = 2130969288;
    
    public static final int listPreferredItemHeight = 2130969289;
    
    public static final int listPreferredItemHeightLarge = 2130969290;
    
    public static final int listPreferredItemHeightSmall = 2130969291;
    
    public static final int listPreferredItemPaddingEnd = 2130969292;
    
    public static final int listPreferredItemPaddingLeft = 2130969293;
    
    public static final int listPreferredItemPaddingRight = 2130969294;
    
    public static final int listPreferredItemPaddingStart = 2130969295;
    
    public static final int logo = 2130969296;
    
    public static final int logoDescription = 2130969298;
    
    public static final int maxButtonHeight = 2130969351;
    
    public static final int measureWithLargestChild = 2130969359;
    
    public static final int menu = 2130969360;
    
    public static final int multiChoiceItemLayout = 2130969423;
    
    public static final int navigationContentDescription = 2130969425;
    
    public static final int navigationIcon = 2130969426;
    
    public static final int navigationMode = 2130969428;
    
    public static final int numericModifiers = 2130969437;
    
    public static final int overlapAnchor = 2130969447;
    
    public static final int paddingBottomNoButtons = 2130969449;
    
    public static final int paddingEnd = 2130969451;
    
    public static final int paddingStart = 2130969454;
    
    public static final int paddingTopNoTitle = 2130969455;
    
    public static final int panelBackground = 2130969457;
    
    public static final int panelMenuListTheme = 2130969458;
    
    public static final int panelMenuListWidth = 2130969459;
    
    public static final int popupMenuStyle = 2130969485;
    
    public static final int popupTheme = 2130969486;
    
    public static final int popupWindowStyle = 2130969487;
    
    public static final int preserveIconSpacing = 2130969491;
    
    public static final int progressBarPadding = 2130969494;
    
    public static final int progressBarStyle = 2130969495;
    
    public static final int queryBackground = 2130969499;
    
    public static final int queryHint = 2130969500;
    
    public static final int radioButtonStyle = 2130969502;
    
    public static final int ratingBarStyle = 2130969504;
    
    public static final int ratingBarStyleIndicator = 2130969505;
    
    public static final int ratingBarStyleSmall = 2130969506;
    
    public static final int searchHintIcon = 2130969529;
    
    public static final int searchIcon = 2130969530;
    
    public static final int searchViewStyle = 2130969532;
    
    public static final int seekBarStyle = 2130969535;
    
    public static final int selectableItemBackground = 2130969536;
    
    public static final int selectableItemBackgroundBorderless = 2130969537;
    
    public static final int showAsAction = 2130969555;
    
    public static final int showDividers = 2130969557;
    
    public static final int showText = 2130969560;
    
    public static final int showTitle = 2130969561;
    
    public static final int singleChoiceItemLayout = 2130969569;
    
    public static final int spinBars = 2130969578;
    
    public static final int spinnerDropDownItemStyle = 2130969579;
    
    public static final int spinnerStyle = 2130969580;
    
    public static final int splitTrack = 2130969585;
    
    public static final int srcCompat = 2130969591;
    
    public static final int state_above_anchor = 2130969602;
    
    public static final int subMenuArrow = 2130969617;
    
    public static final int submitBackground = 2130969622;
    
    public static final int subtitle = 2130969623;
    
    public static final int subtitleTextAppearance = 2130969625;
    
    public static final int subtitleTextColor = 2130969626;
    
    public static final int subtitleTextStyle = 2130969627;
    
    public static final int suggestionRowLayout = 2130969631;
    
    public static final int switchMinWidth = 2130969632;
    
    public static final int switchPadding = 2130969633;
    
    public static final int switchStyle = 2130969634;
    
    public static final int switchTextAppearance = 2130969635;
    
    public static final int textAllCaps = 2130969671;
    
    public static final int textAppearanceLargePopupMenu = 2130969694;
    
    public static final int textAppearanceListItem = 2130969696;
    
    public static final int textAppearanceListItemSecondary = 2130969697;
    
    public static final int textAppearanceListItemSmall = 2130969698;
    
    public static final int textAppearancePopupMenuHeader = 2130969700;
    
    public static final int textAppearanceSearchResultSubtitle = 2130969701;
    
    public static final int textAppearanceSearchResultTitle = 2130969702;
    
    public static final int textAppearanceSmallPopupMenu = 2130969703;
    
    public static final int textColorAlertDialogListItem = 2130969714;
    
    public static final int textColorSearchUrl = 2130969715;
    
    public static final int textLocale = 2130969727;
    
    public static final int theme = 2130969739;
    
    public static final int thickness = 2130969740;
    
    public static final int thumbTextPadding = 2130969749;
    
    public static final int thumbTint = 2130969750;
    
    public static final int thumbTintMode = 2130969751;
    
    public static final int tickMark = 2130969755;
    
    public static final int tickMarkTint = 2130969756;
    
    public static final int tickMarkTintMode = 2130969757;
    
    public static final int tint = 2130969761;
    
    public static final int tintMode = 2130969762;
    
    public static final int title = 2130969764;
    
    public static final int titleMargin = 2130969768;
    
    public static final int titleMarginBottom = 2130969769;
    
    public static final int titleMarginEnd = 2130969770;
    
    public static final int titleMarginStart = 2130969771;
    
    public static final int titleMarginTop = 2130969772;
    
    public static final int titleMargins = 2130969773;
    
    public static final int titleTextAppearance = 2130969775;
    
    public static final int titleTextColor = 2130969776;
    
    public static final int titleTextStyle = 2130969778;
    
    public static final int toolbarNavigationButtonStyle = 2130969781;
    
    public static final int toolbarStyle = 2130969782;
    
    public static final int tooltipForegroundColor = 2130969784;
    
    public static final int tooltipFrameBackground = 2130969785;
    
    public static final int tooltipText = 2130969787;
    
    public static final int track = 2130969792;
    
    public static final int trackTint = 2130969802;
    
    public static final int trackTintMode = 2130969803;
    
    public static final int viewInflaterClass = 2130969822;
    
    public static final int voiceIcon = 2130969828;
    
    public static final int windowActionBar = 2130969836;
    
    public static final int windowActionBarOverlay = 2130969837;
    
    public static final int windowActionModeOverlay = 2130969838;
    
    public static final int windowFixedHeightMajor = 2130969839;
    
    public static final int windowFixedHeightMinor = 2130969840;
    
    public static final int windowFixedWidthMajor = 2130969841;
    
    public static final int windowFixedWidthMinor = 2130969842;
    
    public static final int windowMinWidthMajor = 2130969843;
    
    public static final int windowMinWidthMinor = 2130969844;
    
    public static final int windowNoTitle = 2130969845;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2131034112;
    
    public static final int abc_config_actionMenuItemAllCaps = 2131034113;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131099648;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131099649;
    
    public static final int abc_btn_colored_borderless_text_material = 2131099650;
    
    public static final int abc_btn_colored_text_material = 2131099651;
    
    public static final int abc_color_highlight_material = 2131099652;
    
    public static final int abc_decor_view_status_guard = 2131099653;
    
    public static final int abc_decor_view_status_guard_light = 2131099654;
    
    public static final int abc_hint_foreground_material_dark = 2131099655;
    
    public static final int abc_hint_foreground_material_light = 2131099656;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131099657;
    
    public static final int abc_primary_text_disable_only_material_light = 2131099658;
    
    public static final int abc_primary_text_material_dark = 2131099659;
    
    public static final int abc_primary_text_material_light = 2131099660;
    
    public static final int abc_search_url_text = 2131099661;
    
    public static final int abc_search_url_text_normal = 2131099662;
    
    public static final int abc_search_url_text_pressed = 2131099663;
    
    public static final int abc_search_url_text_selected = 2131099664;
    
    public static final int abc_secondary_text_material_dark = 2131099665;
    
    public static final int abc_secondary_text_material_light = 2131099666;
    
    public static final int abc_tint_btn_checkable = 2131099667;
    
    public static final int abc_tint_default = 2131099668;
    
    public static final int abc_tint_edittext = 2131099669;
    
    public static final int abc_tint_seek_thumb = 2131099670;
    
    public static final int abc_tint_spinner = 2131099671;
    
    public static final int abc_tint_switch_track = 2131099672;
    
    public static final int accent_material_dark = 2131099673;
    
    public static final int accent_material_light = 2131099674;
    
    public static final int background_floating_material_dark = 2131099678;
    
    public static final int background_floating_material_light = 2131099679;
    
    public static final int background_material_dark = 2131099680;
    
    public static final int background_material_light = 2131099681;
    
    public static final int bright_foreground_disabled_material_dark = 2131099683;
    
    public static final int bright_foreground_disabled_material_light = 2131099684;
    
    public static final int bright_foreground_inverse_material_dark = 2131099685;
    
    public static final int bright_foreground_inverse_material_light = 2131099686;
    
    public static final int bright_foreground_material_dark = 2131099687;
    
    public static final int bright_foreground_material_light = 2131099688;
    
    public static final int button_material_dark = 2131099693;
    
    public static final int button_material_light = 2131099694;
    
    public static final int dim_foreground_disabled_material_dark = 2131099742;
    
    public static final int dim_foreground_disabled_material_light = 2131099743;
    
    public static final int dim_foreground_material_dark = 2131099744;
    
    public static final int dim_foreground_material_light = 2131099745;
    
    public static final int error_color_material_dark = 2131099747;
    
    public static final int error_color_material_light = 2131099748;
    
    public static final int foreground_material_dark = 2131099749;
    
    public static final int foreground_material_light = 2131099750;
    
    public static final int highlighted_text_material_dark = 2131099751;
    
    public static final int highlighted_text_material_light = 2131099752;
    
    public static final int material_blue_grey_800 = 2131100166;
    
    public static final int material_blue_grey_900 = 2131100167;
    
    public static final int material_blue_grey_950 = 2131100168;
    
    public static final int material_deep_teal_200 = 2131100170;
    
    public static final int material_deep_teal_500 = 2131100171;
    
    public static final int material_grey_100 = 2131100238;
    
    public static final int material_grey_300 = 2131100239;
    
    public static final int material_grey_50 = 2131100240;
    
    public static final int material_grey_600 = 2131100241;
    
    public static final int material_grey_800 = 2131100242;
    
    public static final int material_grey_850 = 2131100243;
    
    public static final int material_grey_900 = 2131100244;
    
    public static final int primary_dark_material_dark = 2131100398;
    
    public static final int primary_dark_material_light = 2131100399;
    
    public static final int primary_material_dark = 2131100400;
    
    public static final int primary_material_light = 2131100401;
    
    public static final int primary_text_default_material_dark = 2131100402;
    
    public static final int primary_text_default_material_light = 2131100403;
    
    public static final int primary_text_disabled_material_dark = 2131100404;
    
    public static final int primary_text_disabled_material_light = 2131100405;
    
    public static final int ripple_material_dark = 2131100406;
    
    public static final int ripple_material_light = 2131100407;
    
    public static final int secondary_text_default_material_dark = 2131100408;
    
    public static final int secondary_text_default_material_light = 2131100409;
    
    public static final int secondary_text_disabled_material_dark = 2131100410;
    
    public static final int secondary_text_disabled_material_light = 2131100411;
    
    public static final int switch_thumb_disabled_material_dark = 2131100413;
    
    public static final int switch_thumb_disabled_material_light = 2131100414;
    
    public static final int switch_thumb_material_dark = 2131100415;
    
    public static final int switch_thumb_material_light = 2131100416;
    
    public static final int switch_thumb_normal_material_dark = 2131100417;
    
    public static final int switch_thumb_normal_material_light = 2131100418;
    
    public static final int tooltip_background_dark = 2131100423;
    
    public static final int tooltip_background_light = 2131100424;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131165184;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131165185;
    
    public static final int abc_action_bar_default_height_material = 2131165186;
    
    public static final int abc_action_bar_default_padding_end_material = 2131165187;
    
    public static final int abc_action_bar_default_padding_start_material = 2131165188;
    
    public static final int abc_action_bar_elevation_material = 2131165189;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131165190;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131165191;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131165192;
    
    public static final int abc_action_bar_stacked_max_height = 2131165193;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131165194;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131165195;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131165196;
    
    public static final int abc_action_button_min_height_material = 2131165197;
    
    public static final int abc_action_button_min_width_material = 2131165198;
    
    public static final int abc_action_button_min_width_overflow_material = 2131165199;
    
    public static final int abc_alert_dialog_button_bar_height = 2131165200;
    
    public static final int abc_alert_dialog_button_dimen = 2131165201;
    
    public static final int abc_button_inset_horizontal_material = 2131165202;
    
    public static final int abc_button_inset_vertical_material = 2131165203;
    
    public static final int abc_button_padding_horizontal_material = 2131165204;
    
    public static final int abc_button_padding_vertical_material = 2131165205;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131165206;
    
    public static final int abc_config_prefDialogWidth = 2131165207;
    
    public static final int abc_control_corner_material = 2131165208;
    
    public static final int abc_control_inset_material = 2131165209;
    
    public static final int abc_control_padding_material = 2131165210;
    
    public static final int abc_dialog_corner_radius_material = 2131165211;
    
    public static final int abc_dialog_fixed_height_major = 2131165212;
    
    public static final int abc_dialog_fixed_height_minor = 2131165213;
    
    public static final int abc_dialog_fixed_width_major = 2131165214;
    
    public static final int abc_dialog_fixed_width_minor = 2131165215;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131165216;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131165217;
    
    public static final int abc_dialog_min_width_major = 2131165218;
    
    public static final int abc_dialog_min_width_minor = 2131165219;
    
    public static final int abc_dialog_padding_material = 2131165220;
    
    public static final int abc_dialog_padding_top_material = 2131165221;
    
    public static final int abc_dialog_title_divider_material = 2131165222;
    
    public static final int abc_disabled_alpha_material_dark = 2131165223;
    
    public static final int abc_disabled_alpha_material_light = 2131165224;
    
    public static final int abc_dropdownitem_icon_width = 2131165225;
    
    public static final int abc_dropdownitem_text_padding_left = 2131165226;
    
    public static final int abc_dropdownitem_text_padding_right = 2131165227;
    
    public static final int abc_edit_text_inset_bottom_material = 2131165228;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131165229;
    
    public static final int abc_edit_text_inset_top_material = 2131165230;
    
    public static final int abc_floating_window_z = 2131165231;
    
    public static final int abc_list_item_height_large_material = 2131165232;
    
    public static final int abc_list_item_height_material = 2131165233;
    
    public static final int abc_list_item_height_small_material = 2131165234;
    
    public static final int abc_list_item_padding_horizontal_material = 2131165235;
    
    public static final int abc_panel_menu_list_width = 2131165236;
    
    public static final int abc_progress_bar_height_material = 2131165237;
    
    public static final int abc_search_view_preferred_height = 2131165238;
    
    public static final int abc_search_view_preferred_width = 2131165239;
    
    public static final int abc_seekbar_track_background_height_material = 2131165240;
    
    public static final int abc_seekbar_track_progress_height_material = 2131165241;
    
    public static final int abc_select_dialog_padding_start_material = 2131165242;
    
    public static final int abc_star_big = 2131165243;
    
    public static final int abc_star_medium = 2131165244;
    
    public static final int abc_star_small = 2131165245;
    
    public static final int abc_switch_padding = 2131165246;
    
    public static final int abc_text_size_body_1_material = 2131165247;
    
    public static final int abc_text_size_body_2_material = 2131165248;
    
    public static final int abc_text_size_button_material = 2131165249;
    
    public static final int abc_text_size_caption_material = 2131165250;
    
    public static final int abc_text_size_display_1_material = 2131165251;
    
    public static final int abc_text_size_display_2_material = 2131165252;
    
    public static final int abc_text_size_display_3_material = 2131165253;
    
    public static final int abc_text_size_display_4_material = 2131165254;
    
    public static final int abc_text_size_headline_material = 2131165255;
    
    public static final int abc_text_size_large_material = 2131165256;
    
    public static final int abc_text_size_medium_material = 2131165257;
    
    public static final int abc_text_size_menu_header_material = 2131165258;
    
    public static final int abc_text_size_menu_material = 2131165259;
    
    public static final int abc_text_size_small_material = 2131165260;
    
    public static final int abc_text_size_subhead_material = 2131165261;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131165262;
    
    public static final int abc_text_size_title_material = 2131165263;
    
    public static final int abc_text_size_title_material_toolbar = 2131165264;
    
    public static final int disabled_alpha_material_dark = 2131165329;
    
    public static final int disabled_alpha_material_light = 2131165330;
    
    public static final int highlight_alpha_material_colored = 2131165334;
    
    public static final int highlight_alpha_material_dark = 2131165335;
    
    public static final int highlight_alpha_material_light = 2131165336;
    
    public static final int hint_alpha_material_dark = 2131165337;
    
    public static final int hint_alpha_material_light = 2131165338;
    
    public static final int hint_pressed_alpha_material_dark = 2131165339;
    
    public static final int hint_pressed_alpha_material_light = 2131165340;
    
    public static final int tooltip_corner_radius = 2131165963;
    
    public static final int tooltip_horizontal_padding = 2131165964;
    
    public static final int tooltip_margin = 2131165965;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131165966;
    
    public static final int tooltip_precise_anchor_threshold = 2131165967;
    
    public static final int tooltip_vertical_padding = 2131165968;
    
    public static final int tooltip_y_offset_non_touch = 2131165969;
    
    public static final int tooltip_y_offset_touch = 2131165970;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131230760;
    
    public static final int abc_action_bar_item_background_material = 2131230761;
    
    public static final int abc_btn_borderless_material = 2131230762;
    
    public static final int abc_btn_check_material = 2131230763;
    
    public static final int abc_btn_check_material_anim = 2131230764;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131230765;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131230766;
    
    public static final int abc_btn_colored_material = 2131230767;
    
    public static final int abc_btn_default_mtrl_shape = 2131230768;
    
    public static final int abc_btn_radio_material = 2131230769;
    
    public static final int abc_btn_radio_material_anim = 2131230770;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131230771;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131230772;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131230773;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131230774;
    
    public static final int abc_cab_background_internal_bg = 2131230775;
    
    public static final int abc_cab_background_top_material = 2131230776;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131230777;
    
    public static final int abc_control_background_material = 2131230778;
    
    public static final int abc_dialog_material_background = 2131230779;
    
    public static final int abc_edit_text_material = 2131230780;
    
    public static final int abc_ic_ab_back_material = 2131230781;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131230782;
    
    public static final int abc_ic_clear_material = 2131230783;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131230784;
    
    public static final int abc_ic_go_search_api_material = 2131230785;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131230786;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131230787;
    
    public static final int abc_ic_menu_overflow_material = 2131230788;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131230789;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131230790;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131230791;
    
    public static final int abc_ic_search_api_material = 2131230792;
    
    public static final int abc_ic_voice_search_api_material = 2131230793;
    
    public static final int abc_item_background_holo_dark = 2131230794;
    
    public static final int abc_item_background_holo_light = 2131230795;
    
    public static final int abc_list_divider_material = 2131230796;
    
    public static final int abc_list_divider_mtrl_alpha = 2131230797;
    
    public static final int abc_list_focused_holo = 2131230798;
    
    public static final int abc_list_longpressed_holo = 2131230799;
    
    public static final int abc_list_pressed_holo_dark = 2131230800;
    
    public static final int abc_list_pressed_holo_light = 2131230801;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131230802;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131230803;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131230804;
    
    public static final int abc_list_selector_disabled_holo_light = 2131230805;
    
    public static final int abc_list_selector_holo_dark = 2131230806;
    
    public static final int abc_list_selector_holo_light = 2131230807;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131230808;
    
    public static final int abc_popup_background_mtrl_mult = 2131230809;
    
    public static final int abc_ratingbar_indicator_material = 2131230810;
    
    public static final int abc_ratingbar_material = 2131230811;
    
    public static final int abc_ratingbar_small_material = 2131230812;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131230813;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131230814;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131230815;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131230816;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131230817;
    
    public static final int abc_seekbar_thumb_material = 2131230818;
    
    public static final int abc_seekbar_tick_mark_material = 2131230819;
    
    public static final int abc_seekbar_track_material = 2131230820;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131230821;
    
    public static final int abc_spinner_textfield_background_material = 2131230822;
    
    public static final int abc_star_black_48dp = 2131230823;
    
    public static final int abc_star_half_black_48dp = 2131230824;
    
    public static final int abc_switch_thumb_material = 2131230825;
    
    public static final int abc_switch_track_mtrl_alpha = 2131230826;
    
    public static final int abc_tab_indicator_material = 2131230827;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131230828;
    
    public static final int abc_text_cursor_material = 2131230829;
    
    public static final int abc_text_select_handle_left_mtrl = 2131230830;
    
    public static final int abc_text_select_handle_middle_mtrl = 2131230831;
    
    public static final int abc_text_select_handle_right_mtrl = 2131230832;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131230833;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131230834;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131230835;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131230836;
    
    public static final int abc_textfield_search_material = 2131230837;
    
    public static final int btn_checkbox_checked_mtrl = 2131230845;
    
    public static final int btn_checkbox_checked_to_unchecked_mtrl_animation = 2131230846;
    
    public static final int btn_checkbox_unchecked_mtrl = 2131230847;
    
    public static final int btn_checkbox_unchecked_to_checked_mtrl_animation = 2131230848;
    
    public static final int btn_radio_off_mtrl = 2131230849;
    
    public static final int btn_radio_off_to_on_mtrl_animation = 2131230850;
    
    public static final int btn_radio_on_mtrl = 2131230851;
    
    public static final int btn_radio_on_to_off_mtrl_animation = 2131230852;
    
    public static final int test_level_drawable = 2131230959;
    
    public static final int tooltip_frame_dark = 2131230960;
    
    public static final int tooltip_frame_light = 2131230961;
  }
  
  public static final class id {
    public static final int action_bar = 2131361853;
    
    public static final int action_bar_activity_content = 2131361854;
    
    public static final int action_bar_container = 2131361855;
    
    public static final int action_bar_root = 2131361856;
    
    public static final int action_bar_spinner = 2131361857;
    
    public static final int action_bar_subtitle = 2131361858;
    
    public static final int action_bar_title = 2131361859;
    
    public static final int action_context_bar = 2131361861;
    
    public static final int action_menu_divider = 2131361864;
    
    public static final int action_menu_presenter = 2131361865;
    
    public static final int action_mode_bar = 2131361866;
    
    public static final int action_mode_bar_stub = 2131361867;
    
    public static final int action_mode_close_button = 2131361868;
    
    public static final int activity_chooser_view_content = 2131361871;
    
    public static final int add = 2131361872;
    
    public static final int alertTitle = 2131361873;
    
    public static final int buttonPanel = 2131361919;
    
    public static final int checkbox = 2131361934;
    
    public static final int checked = 2131361935;
    
    public static final int content = 2131361964;
    
    public static final int contentPanel = 2131361965;
    
    public static final int custom = 2131361974;
    
    public static final int customPanel = 2131361975;
    
    public static final int decor_content_parent = 2131361982;
    
    public static final int default_activity_button = 2131361983;
    
    public static final int edit_query = 2131362019;
    
    public static final int expand_activities_button = 2131362029;
    
    public static final int expanded_menu = 2131362030;
    
    public static final int group_divider = 2131362067;
    
    public static final int home = 2131362077;
    
    public static final int icon = 2131362081;
    
    public static final int image = 2131362086;
    
    public static final int listMode = 2131362114;
    
    public static final int list_item = 2131362115;
    
    public static final int message = 2131362149;
    
    public static final int multiply = 2131362183;
    
    public static final int none = 2131362201;
    
    public static final int normal = 2131362202;
    
    public static final int off = 2131362211;
    
    public static final int on = 2131362212;
    
    public static final int parentPanel = 2131362225;
    
    public static final int progress_circular = 2131362248;
    
    public static final int progress_horizontal = 2131362249;
    
    public static final int radio = 2131362251;
    
    public static final int screen = 2131362276;
    
    public static final int scrollIndicatorDown = 2131362278;
    
    public static final int scrollIndicatorUp = 2131362279;
    
    public static final int scrollView = 2131362280;
    
    public static final int search_badge = 2131362282;
    
    public static final int search_bar = 2131362283;
    
    public static final int search_button = 2131362285;
    
    public static final int search_close_btn = 2131362286;
    
    public static final int search_edit_frame = 2131362287;
    
    public static final int search_go_btn = 2131362288;
    
    public static final int search_mag_icon = 2131362289;
    
    public static final int search_plate = 2131362290;
    
    public static final int search_src_text = 2131362291;
    
    public static final int search_voice_btn = 2131362305;
    
    public static final int select_dialog_listview = 2131362307;
    
    public static final int shortcut = 2131362318;
    
    public static final int spacer = 2131362338;
    
    public static final int split_action_bar = 2131362341;
    
    public static final int src_atop = 2131362347;
    
    public static final int src_in = 2131362348;
    
    public static final int src_over = 2131362349;
    
    public static final int submenuarrow = 2131362359;
    
    public static final int submit_area = 2131362360;
    
    public static final int tabMode = 2131362362;
    
    public static final int textSpacerNoButtons = 2131362382;
    
    public static final int textSpacerNoTitle = 2131362383;
    
    public static final int title = 2131362403;
    
    public static final int titleDividerNoCustom = 2131362404;
    
    public static final int title_template = 2131362405;
    
    public static final int topPanel = 2131362409;
    
    public static final int unchecked = 2131362421;
    
    public static final int uniform = 2131362422;
    
    public static final int up = 2131362424;
    
    public static final int wrap_content = 2131362443;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131427328;
    
    public static final int abc_config_activityShortDur = 2131427329;
    
    public static final int cancel_button_image_alpha = 2131427332;
    
    public static final int config_tooltipAnimTime = 2131427334;
  }
  
  public static final class interpolator {
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_0 = 2131492864;
    
    public static final int btn_checkbox_checked_mtrl_animation_interpolator_1 = 2131492865;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 2131492866;
    
    public static final int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 2131492867;
    
    public static final int btn_radio_to_off_mtrl_animation_interpolator_0 = 2131492868;
    
    public static final int btn_radio_to_on_mtrl_animation_interpolator_0 = 2131492869;
    
    public static final int fast_out_slow_in = 2131492870;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131558400;
    
    public static final int abc_action_bar_up_container = 2131558401;
    
    public static final int abc_action_menu_item_layout = 2131558402;
    
    public static final int abc_action_menu_layout = 2131558403;
    
    public static final int abc_action_mode_bar = 2131558404;
    
    public static final int abc_action_mode_close_item_material = 2131558405;
    
    public static final int abc_activity_chooser_view = 2131558406;
    
    public static final int abc_activity_chooser_view_list_item = 2131558407;
    
    public static final int abc_alert_dialog_button_bar_material = 2131558408;
    
    public static final int abc_alert_dialog_material = 2131558409;
    
    public static final int abc_alert_dialog_title_material = 2131558410;
    
    public static final int abc_cascading_menu_item_layout = 2131558411;
    
    public static final int abc_dialog_title_material = 2131558412;
    
    public static final int abc_expanded_menu_layout = 2131558413;
    
    public static final int abc_list_menu_item_checkbox = 2131558414;
    
    public static final int abc_list_menu_item_icon = 2131558415;
    
    public static final int abc_list_menu_item_layout = 2131558416;
    
    public static final int abc_list_menu_item_radio = 2131558417;
    
    public static final int abc_popup_menu_header_item_layout = 2131558418;
    
    public static final int abc_popup_menu_item_layout = 2131558419;
    
    public static final int abc_screen_content_include = 2131558420;
    
    public static final int abc_screen_simple = 2131558421;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131558422;
    
    public static final int abc_screen_toolbar = 2131558423;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131558424;
    
    public static final int abc_search_view = 2131558425;
    
    public static final int abc_select_dialog_material = 2131558426;
    
    public static final int abc_tooltip = 2131558427;
    
    public static final int select_dialog_item_material = 2131558517;
    
    public static final int select_dialog_multichoice_material = 2131558518;
    
    public static final int select_dialog_singlechoice_material = 2131558519;
    
    public static final int support_simple_spinner_dropdown_item = 2131558520;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2132017152;
    
    public static final int abc_action_bar_up_description = 2132017153;
    
    public static final int abc_action_menu_overflow_description = 2132017154;
    
    public static final int abc_action_mode_done = 2132017155;
    
    public static final int abc_activity_chooser_view_see_all = 2132017156;
    
    public static final int abc_activitychooserview_choose_application = 2132017157;
    
    public static final int abc_capital_off = 2132017158;
    
    public static final int abc_capital_on = 2132017159;
    
    public static final int abc_menu_alt_shortcut_label = 2132017160;
    
    public static final int abc_menu_ctrl_shortcut_label = 2132017161;
    
    public static final int abc_menu_delete_shortcut_label = 2132017162;
    
    public static final int abc_menu_enter_shortcut_label = 2132017163;
    
    public static final int abc_menu_function_shortcut_label = 2132017164;
    
    public static final int abc_menu_meta_shortcut_label = 2132017165;
    
    public static final int abc_menu_shift_shortcut_label = 2132017166;
    
    public static final int abc_menu_space_shortcut_label = 2132017167;
    
    public static final int abc_menu_sym_shortcut_label = 2132017168;
    
    public static final int abc_prepend_shortcut_label = 2132017169;
    
    public static final int abc_search_hint = 2132017170;
    
    public static final int abc_searchview_description_clear = 2132017171;
    
    public static final int abc_searchview_description_query = 2132017172;
    
    public static final int abc_searchview_description_search = 2132017173;
    
    public static final int abc_searchview_description_submit = 2132017174;
    
    public static final int abc_searchview_description_voice = 2132017175;
    
    public static final int abc_shareactionprovider_share_with = 2132017176;
    
    public static final int abc_shareactionprovider_share_with_application = 2132017177;
    
    public static final int abc_toolbar_collapse_description = 2132017178;
    
    public static final int search_menu_title = 2132017372;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2132082688;
    
    public static final int AlertDialog_AppCompat_Light = 2132082689;
    
    public static final int Animation_AppCompat_Dialog = 2132082690;
    
    public static final int Animation_AppCompat_DropDownUp = 2132082691;
    
    public static final int Animation_AppCompat_Tooltip = 2132082692;
    
    public static final int Base_AlertDialog_AppCompat = 2132082697;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2132082698;
    
    public static final int Base_Animation_AppCompat_Dialog = 2132082699;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2132082700;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2132082701;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2132082704;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2132082703;
    
    public static final int Base_TextAppearance_AppCompat = 2132082708;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2132082709;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2132082710;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2132082711;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2132082712;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2132082713;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2132082714;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2132082715;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2132082716;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2132082717;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2132082718;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2132082719;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2132082720;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2132082721;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2132082722;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2132082723;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2132082724;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2132082725;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2132082726;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2132082727;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2132082728;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2132082729;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2132082730;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2132082731;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2132082732;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2132082733;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2132082734;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2132082735;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2132082736;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2132082737;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2132082738;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2132082739;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2132082740;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2132082741;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2132082742;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2132082743;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2132082744;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2132082745;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2132082746;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2132082747;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2132082748;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2132082749;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2132082750;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2132082751;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2132082752;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2132082758;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2132082759;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2132082760;
    
    public static final int Base_ThemeOverlay_AppCompat = 2132082802;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2132082803;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2132082804;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2132082805;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2132082806;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2132082807;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2132082808;
    
    public static final int Base_Theme_AppCompat = 2132082761;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2132082762;
    
    public static final int Base_Theme_AppCompat_Dialog = 2132082763;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2132082767;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2132082764;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2132082765;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2132082766;
    
    public static final int Base_Theme_AppCompat_Light = 2132082768;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2132082769;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2132082770;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2132082774;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2132082771;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2132082772;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2132082773;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2132082851;
    
    public static final int Base_V21_Theme_AppCompat = 2132082843;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2132082844;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2132082845;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2132082846;
    
    public static final int Base_V22_Theme_AppCompat = 2132082855;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2132082856;
    
    public static final int Base_V23_Theme_AppCompat = 2132082857;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2132082858;
    
    public static final int Base_V26_Theme_AppCompat = 2132082863;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2132082864;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2132082865;
    
    public static final int Base_V28_Theme_AppCompat = 2132082866;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2132082867;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2132082872;
    
    public static final int Base_V7_Theme_AppCompat = 2132082868;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2132082869;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2132082870;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2132082871;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2132082873;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2132082874;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2132082875;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2132082876;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2132082877;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2132082878;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2132082879;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2132082880;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2132082881;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2132082882;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2132082883;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2132082884;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2132082885;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2132082886;
    
    public static final int Base_Widget_AppCompat_Button = 2132082887;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2132082893;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2132082894;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2132082888;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2132082889;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2132082890;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2132082891;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2132082892;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2132082895;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2132082896;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2132082897;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2132082898;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2132082899;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2132082900;
    
    public static final int Base_Widget_AppCompat_EditText = 2132082901;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2132082902;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2132082903;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2132082904;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2132082905;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2132082906;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2132082907;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2132082908;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2132082909;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2132082910;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2132082911;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2132082912;
    
    public static final int Base_Widget_AppCompat_ListView = 2132082913;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2132082914;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2132082915;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2132082916;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2132082917;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2132082918;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2132082919;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2132082920;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2132082921;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2132082922;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2132082923;
    
    public static final int Base_Widget_AppCompat_SearchView = 2132082924;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2132082925;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2132082926;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2132082927;
    
    public static final int Base_Widget_AppCompat_Spinner = 2132082928;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2132082929;
    
    public static final int Base_Widget_AppCompat_TextView = 2132082930;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2132082931;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2132082932;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2132082933;
    
    public static final int Platform_AppCompat = 2132082998;
    
    public static final int Platform_AppCompat_Light = 2132082999;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2132083004;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2132083005;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2132083006;
    
    public static final int Platform_V21_AppCompat = 2132083007;
    
    public static final int Platform_V21_AppCompat_Light = 2132083008;
    
    public static final int Platform_V25_AppCompat = 2132083009;
    
    public static final int Platform_V25_AppCompat_Light = 2132083010;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2132083011;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2132083012;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2132083013;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2132083014;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2132083015;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2132083016;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2132083017;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2132083018;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2132083019;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2132083020;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2132083026;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2132083021;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2132083022;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2132083023;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2132083024;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2132083025;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2132083027;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2132083028;
    
    public static final int TextAppearance_AppCompat = 2132083088;
    
    public static final int TextAppearance_AppCompat_Body1 = 2132083089;
    
    public static final int TextAppearance_AppCompat_Body2 = 2132083090;
    
    public static final int TextAppearance_AppCompat_Button = 2132083091;
    
    public static final int TextAppearance_AppCompat_Caption = 2132083092;
    
    public static final int TextAppearance_AppCompat_Display1 = 2132083093;
    
    public static final int TextAppearance_AppCompat_Display2 = 2132083094;
    
    public static final int TextAppearance_AppCompat_Display3 = 2132083095;
    
    public static final int TextAppearance_AppCompat_Display4 = 2132083096;
    
    public static final int TextAppearance_AppCompat_Headline = 2132083097;
    
    public static final int TextAppearance_AppCompat_Inverse = 2132083098;
    
    public static final int TextAppearance_AppCompat_Large = 2132083099;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2132083100;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2132083101;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2132083102;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2132083103;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2132083104;
    
    public static final int TextAppearance_AppCompat_Medium = 2132083105;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2132083106;
    
    public static final int TextAppearance_AppCompat_Menu = 2132083107;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2132083108;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2132083109;
    
    public static final int TextAppearance_AppCompat_Small = 2132083110;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2132083111;
    
    public static final int TextAppearance_AppCompat_Subhead = 2132083112;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2132083113;
    
    public static final int TextAppearance_AppCompat_Title = 2132083114;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2132083115;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2132083116;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2132083117;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2132083118;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2132083119;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2132083120;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2132083121;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2132083122;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2132083123;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2132083124;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2132083125;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2132083126;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2132083127;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2132083128;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2132083129;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2132083130;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2132083131;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2132083132;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2132083133;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2132083134;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2132083135;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2132083217;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2132083218;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2132083219;
    
    public static final int ThemeOverlay_AppCompat = 2132083323;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2132083324;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2132083325;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2132083326;
    
    public static final int ThemeOverlay_AppCompat_DayNight = 2132083327;
    
    public static final int ThemeOverlay_AppCompat_DayNight_ActionBar = 2132083328;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2132083329;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2132083330;
    
    public static final int ThemeOverlay_AppCompat_Light = 2132083331;
    
    public static final int Theme_AppCompat = 2132083220;
    
    public static final int Theme_AppCompat_CompactMenu = 2132083221;
    
    public static final int Theme_AppCompat_DayNight = 2132083222;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2132083223;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2132083224;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2132083227;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2132083225;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2132083226;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2132083228;
    
    public static final int Theme_AppCompat_Dialog = 2132083229;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2132083232;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2132083230;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2132083231;
    
    public static final int Theme_AppCompat_Empty = 2132083233;
    
    public static final int Theme_AppCompat_Light = 2132083234;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2132083235;
    
    public static final int Theme_AppCompat_Light_Dialog = 2132083236;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2132083239;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2132083237;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2132083238;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2132083240;
    
    public static final int Theme_AppCompat_NoActionBar = 2132083241;
    
    public static final int Widget_AppCompat_ActionBar = 2132083436;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2132083437;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2132083438;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2132083439;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2132083440;
    
    public static final int Widget_AppCompat_ActionButton = 2132083441;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2132083442;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2132083443;
    
    public static final int Widget_AppCompat_ActionMode = 2132083444;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2132083445;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2132083446;
    
    public static final int Widget_AppCompat_Button = 2132083447;
    
    public static final int Widget_AppCompat_ButtonBar = 2132083453;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2132083454;
    
    public static final int Widget_AppCompat_Button_Borderless = 2132083448;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2132083449;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2132083450;
    
    public static final int Widget_AppCompat_Button_Colored = 2132083451;
    
    public static final int Widget_AppCompat_Button_Small = 2132083452;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2132083455;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2132083456;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2132083457;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2132083458;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2132083459;
    
    public static final int Widget_AppCompat_EditText = 2132083460;
    
    public static final int Widget_AppCompat_ImageButton = 2132083461;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2132083462;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2132083463;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2132083464;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2132083465;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2132083466;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2132083467;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2132083468;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2132083469;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2132083470;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2132083471;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2132083472;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2132083473;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2132083474;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2132083475;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2132083476;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2132083477;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2132083478;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2132083479;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2132083480;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2132083481;
    
    public static final int Widget_AppCompat_Light_SearchView = 2132083482;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2132083483;
    
    public static final int Widget_AppCompat_ListMenuView = 2132083484;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2132083485;
    
    public static final int Widget_AppCompat_ListView = 2132083486;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2132083487;
    
    public static final int Widget_AppCompat_ListView_Menu = 2132083488;
    
    public static final int Widget_AppCompat_PopupMenu = 2132083489;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2132083490;
    
    public static final int Widget_AppCompat_PopupWindow = 2132083491;
    
    public static final int Widget_AppCompat_ProgressBar = 2132083492;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2132083493;
    
    public static final int Widget_AppCompat_RatingBar = 2132083494;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2132083495;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2132083496;
    
    public static final int Widget_AppCompat_SearchView = 2132083497;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2132083498;
    
    public static final int Widget_AppCompat_SeekBar = 2132083499;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2132083500;
    
    public static final int Widget_AppCompat_Spinner = 2132083501;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2132083502;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2132083503;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2132083504;
    
    public static final int Widget_AppCompat_TextView = 2132083505;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2132083506;
    
    public static final int Widget_AppCompat_Toolbar = 2132083507;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2132083508;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130968649, 2130968656, 2130968657, 2130968892, 2130968893, 2130968894, 2130968895, 2130968896, 2130968897, 2130968936, 
        2130968959, 2130968960, 2130968991, 2130969114, 2130969122, 2130969128, 2130969129, 2130969133, 2130969150, 2130969172, 
        2130969296, 2130969428, 2130969486, 2130969494, 2130969495, 2130969623, 2130969627, 2130969764, 2130969778 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130968649, 2130968656, 2130968808, 2130969114, 2130969627, 2130969778 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130969020, 2130969156 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130968723, 2130968726, 2130969285, 2130969286, 2130969423, 2130969561, 2130969569 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AppCompatEmojiHelper = new int[0];
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130969591, 2130969761, 2130969762 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130969755, 2130969756, 2130969757 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130968643, 2130968644, 2130968645, 2130968646, 2130968647, 2130968972, 2130968973, 2130968974, 2130968975, 
        2130968977, 2130968978, 2130968979, 2130968980, 2130968995, 2130969055, 2130969091, 2130969100, 2130969198, 2130969278, 
        2130969671, 2130969727 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_drawableBottomCompat = 6;
    
    public static final int AppCompatTextView_drawableEndCompat = 7;
    
    public static final int AppCompatTextView_drawableLeftCompat = 8;
    
    public static final int AppCompatTextView_drawableRightCompat = 9;
    
    public static final int AppCompatTextView_drawableStartCompat = 10;
    
    public static final int AppCompatTextView_drawableTint = 11;
    
    public static final int AppCompatTextView_drawableTintMode = 12;
    
    public static final int AppCompatTextView_drawableTopCompat = 13;
    
    public static final int AppCompatTextView_emojiCompatEnabled = 14;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 15;
    
    public static final int AppCompatTextView_fontFamily = 16;
    
    public static final int AppCompatTextView_fontVariationSettings = 17;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 18;
    
    public static final int AppCompatTextView_lineHeight = 19;
    
    public static final int AppCompatTextView_textAllCaps = 20;
    
    public static final int AppCompatTextView_textLocale = 21;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130968579, 2130968580, 2130968581, 2130968582, 2130968583, 2130968584, 2130968585, 2130968586, 
        2130968587, 2130968588, 2130968589, 2130968590, 2130968591, 2130968593, 2130968594, 2130968595, 2130968596, 2130968597, 
        2130968598, 2130968599, 2130968600, 2130968601, 2130968602, 2130968603, 2130968604, 2130968605, 2130968606, 2130968607, 
        2130968608, 2130968609, 2130968610, 2130968611, 2130968616, 2130968619, 2130968620, 2130968621, 2130968622, 2130968641, 
        2130968696, 2130968715, 2130968716, 2130968717, 2130968718, 2130968719, 2130968727, 2130968728, 2130968754, 2130968765, 
        2130968821, 2130968822, 2130968823, 2130968825, 2130968826, 2130968827, 2130968828, 2130968853, 2130968855, 2130968876, 
        2130968907, 2130968956, 2130968957, 2130968958, 2130968962, 2130968967, 2130968984, 2130968985, 2130968988, 2130968989, 
        2130968990, 2130969128, 2130969144, 2130969281, 2130969282, 2130969283, 2130969284, 2130969287, 2130969288, 2130969289, 
        2130969290, 2130969291, 2130969292, 2130969293, 2130969294, 2130969295, 2130969457, 2130969458, 2130969459, 2130969485, 
        2130969487, 2130969502, 2130969504, 2130969505, 2130969506, 2130969532, 2130969535, 2130969536, 2130969537, 2130969579, 
        2130969580, 2130969634, 2130969694, 2130969696, 2130969697, 2130969698, 2130969700, 2130969701, 2130969702, 2130969703, 
        2130969714, 2130969715, 2130969781, 2130969782, 2130969784, 2130969785, 2130969822, 2130969836, 2130969837, 2130969838, 
        2130969839, 2130969840, 2130969841, 2130969842, 2130969843, 2130969844, 2130969845 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseContentDescription = 19;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 21;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 22;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 23;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 24;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 25;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 26;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 27;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 28;
    
    public static final int AppCompatTheme_actionModeStyle = 29;
    
    public static final int AppCompatTheme_actionModeTheme = 30;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 31;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 32;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 33;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 34;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 35;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 36;
    
    public static final int AppCompatTheme_alertDialogStyle = 37;
    
    public static final int AppCompatTheme_alertDialogTheme = 38;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 39;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 43;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 44;
    
    public static final int AppCompatTheme_buttonBarStyle = 45;
    
    public static final int AppCompatTheme_buttonStyle = 46;
    
    public static final int AppCompatTheme_buttonStyleSmall = 47;
    
    public static final int AppCompatTheme_checkboxStyle = 48;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 49;
    
    public static final int AppCompatTheme_colorAccent = 50;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 51;
    
    public static final int AppCompatTheme_colorButtonNormal = 52;
    
    public static final int AppCompatTheme_colorControlActivated = 53;
    
    public static final int AppCompatTheme_colorControlHighlight = 54;
    
    public static final int AppCompatTheme_colorControlNormal = 55;
    
    public static final int AppCompatTheme_colorError = 56;
    
    public static final int AppCompatTheme_colorPrimary = 57;
    
    public static final int AppCompatTheme_colorPrimaryDark = 58;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 59;
    
    public static final int AppCompatTheme_controlBackground = 60;
    
    public static final int AppCompatTheme_dialogCornerRadius = 61;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 62;
    
    public static final int AppCompatTheme_dialogTheme = 63;
    
    public static final int AppCompatTheme_dividerHorizontal = 64;
    
    public static final int AppCompatTheme_dividerVertical = 65;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 66;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 67;
    
    public static final int AppCompatTheme_editTextBackground = 68;
    
    public static final int AppCompatTheme_editTextColor = 69;
    
    public static final int AppCompatTheme_editTextStyle = 70;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 71;
    
    public static final int AppCompatTheme_imageButtonStyle = 72;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 73;
    
    public static final int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 74;
    
    public static final int AppCompatTheme_listChoiceIndicatorSingleAnimated = 75;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 76;
    
    public static final int AppCompatTheme_listMenuViewStyle = 77;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 78;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 79;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 80;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 81;
    
    public static final int AppCompatTheme_listPreferredItemPaddingEnd = 82;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 83;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 84;
    
    public static final int AppCompatTheme_listPreferredItemPaddingStart = 85;
    
    public static final int AppCompatTheme_panelBackground = 86;
    
    public static final int AppCompatTheme_panelMenuListTheme = 87;
    
    public static final int AppCompatTheme_panelMenuListWidth = 88;
    
    public static final int AppCompatTheme_popupMenuStyle = 89;
    
    public static final int AppCompatTheme_popupWindowStyle = 90;
    
    public static final int AppCompatTheme_radioButtonStyle = 91;
    
    public static final int AppCompatTheme_ratingBarStyle = 92;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 93;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 94;
    
    public static final int AppCompatTheme_searchViewStyle = 95;
    
    public static final int AppCompatTheme_seekBarStyle = 96;
    
    public static final int AppCompatTheme_selectableItemBackground = 97;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 98;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 99;
    
    public static final int AppCompatTheme_spinnerStyle = 100;
    
    public static final int AppCompatTheme_switchStyle = 101;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 102;
    
    public static final int AppCompatTheme_textAppearanceListItem = 103;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 104;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 105;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 106;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 107;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 108;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 109;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 110;
    
    public static final int AppCompatTheme_textColorSearchUrl = 111;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 112;
    
    public static final int AppCompatTheme_toolbarStyle = 113;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 114;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 115;
    
    public static final int AppCompatTheme_viewInflaterClass = 116;
    
    public static final int AppCompatTheme_windowActionBar = 117;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 118;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 119;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 120;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 121;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 122;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 123;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 124;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 125;
    
    public static final int AppCompatTheme_windowNoTitle = 126;
    
    public static final int[] ButtonBarLayout = new int[] { 2130968623 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] CheckedTextView = new int[] { 16843016, 2130968751, 2130968752, 2130968753 };
    
    public static final int CheckedTextView_android_checkMark = 0;
    
    public static final int CheckedTextView_checkMarkCompat = 1;
    
    public static final int CheckedTextView_checkMarkTint = 2;
    
    public static final int CheckedTextView_checkMarkTintMode = 3;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130968720, 2130968729, 2130968730 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonCompat = 1;
    
    public static final int CompoundButton_buttonTint = 2;
    
    public static final int CompoundButton_buttonTintMode = 3;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130968637, 2130968638, 2130968675, 2130968820, 2130968976, 2130969106, 2130969578, 2130969740 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130968960, 2130968965, 2130969359, 2130969557 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130968592, 2130968612, 2130968614, 2130968625, 2130968891, 2130969139, 2130969140, 
        2130969437, 2130969555, 2130969787 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130969491, 2130969617 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130969447 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130969602 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] RecycleListView = new int[] { 2130969449, 2130969455 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842804, 16842970, 16843039, 16843087, 16843088, 16843296, 16843364, 2130968629, 2130968630, 2130968642, 
        2130968801, 2130968881, 2130968949, 2130969108, 2130969113, 2130969121, 2130969141, 2130969201, 2130969499, 2130969500, 
        2130969529, 2130969530, 2130969531, 2130969622, 2130969631, 2130969817, 2130969828 };
    
    public static final int SearchView_android_focusable = 1;
    
    public static final int SearchView_android_hint = 4;
    
    public static final int SearchView_android_imeOptions = 6;
    
    public static final int SearchView_android_inputType = 5;
    
    public static final int SearchView_android_maxWidth = 2;
    
    public static final int SearchView_android_text = 3;
    
    public static final int SearchView_android_textAppearance = 0;
    
    public static final int SearchView_animateMenuItems = 7;
    
    public static final int SearchView_animateNavigationIcon = 8;
    
    public static final int SearchView_autoShowKeyboard = 9;
    
    public static final int SearchView_closeIcon = 10;
    
    public static final int SearchView_commitIcon = 11;
    
    public static final int SearchView_defaultQueryHint = 12;
    
    public static final int SearchView_goIcon = 13;
    
    public static final int SearchView_headerLayout = 14;
    
    public static final int SearchView_hideNavigationIcon = 15;
    
    public static final int SearchView_iconifiedByDefault = 16;
    
    public static final int SearchView_layout = 17;
    
    public static final int SearchView_queryBackground = 18;
    
    public static final int SearchView_queryHint = 19;
    
    public static final int SearchView_searchHintIcon = 20;
    
    public static final int SearchView_searchIcon = 21;
    
    public static final int SearchView_searchPrefixText = 22;
    
    public static final int SearchView_submitBackground = 23;
    
    public static final int SearchView_suggestionRowLayout = 24;
    
    public static final int SearchView_useDrawerArrowDrawable = 25;
    
    public static final int SearchView_voiceIcon = 26;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130969486 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130969560, 2130969585, 2130969632, 2130969633, 2130969635, 2130969749, 2130969750, 
        2130969751, 2130969792, 2130969802, 2130969803 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130969091, 2130969100, 2130969671, 2130969727 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textFontWeight = 11;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 12;
    
    public static final int TextAppearance_fontVariationSettings = 13;
    
    public static final int TextAppearance_textAllCaps = 14;
    
    public static final int TextAppearance_textLocale = 15;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130968721, 2130968809, 2130968810, 2130968892, 2130968893, 2130968894, 2130968895, 2130968896, 
        2130968897, 2130969296, 2130969298, 2130969351, 2130969360, 2130969425, 2130969426, 2130969486, 2130969623, 2130969625, 
        2130969626, 2130969764, 2130969768, 2130969769, 2130969770, 2130969771, 2130969772, 2130969773, 2130969775, 2130969776 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_menu = 14;
    
    public static final int Toolbar_navigationContentDescription = 15;
    
    public static final int Toolbar_navigationIcon = 16;
    
    public static final int Toolbar_popupTheme = 17;
    
    public static final int Toolbar_subtitle = 18;
    
    public static final int Toolbar_subtitleTextAppearance = 19;
    
    public static final int Toolbar_subtitleTextColor = 20;
    
    public static final int Toolbar_title = 21;
    
    public static final int Toolbar_titleMargin = 22;
    
    public static final int Toolbar_titleMarginBottom = 23;
    
    public static final int Toolbar_titleMarginEnd = 24;
    
    public static final int Toolbar_titleMarginStart = 25;
    
    public static final int Toolbar_titleMarginTop = 26;
    
    public static final int Toolbar_titleMargins = 27;
    
    public static final int Toolbar_titleTextAppearance = 28;
    
    public static final int Toolbar_titleTextColor = 29;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130969451, 2130969454, 2130969739 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130968658, 2130968659 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\appcompat\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */