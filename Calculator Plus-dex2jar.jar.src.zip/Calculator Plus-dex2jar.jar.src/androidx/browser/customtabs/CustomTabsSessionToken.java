package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.customtabs.ICustomTabsCallback;
import android.util.Log;
import androidx.core.app.BundleCompat;

public class CustomTabsSessionToken {
  private static final String TAG = "CustomTabsSessionToken";
  
  private final CustomTabsCallback mCallback;
  
  final ICustomTabsCallback mCallbackBinder;
  
  private final PendingIntent mSessionId;
  
  CustomTabsSessionToken(ICustomTabsCallback paramICustomTabsCallback, PendingIntent paramPendingIntent) {
    if (paramICustomTabsCallback != null || paramPendingIntent != null) {
      CustomTabsCallback customTabsCallback;
      this.mCallbackBinder = paramICustomTabsCallback;
      this.mSessionId = paramPendingIntent;
      if (paramICustomTabsCallback == null) {
        paramICustomTabsCallback = null;
      } else {
        customTabsCallback = new CustomTabsCallback() {
            public void extraCallback(String param1String, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.extraCallback(param1String, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
                return;
              } 
            }
            
            public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) {
              try {
                return CustomTabsSessionToken.this.mCallbackBinder.extraCallbackWithResult(param1String, param1Bundle);
              } catch (RemoteException remoteException) {
                Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
                return null;
              } 
            }
            
            public void onActivityResized(int param1Int1, int param1Int2, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onActivityResized(param1Int1, param1Int2, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
                return;
              } 
            }
            
            public void onMessageChannelReady(Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onMessageChannelReady(param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
                return;
              } 
            }
            
            public void onNavigationEvent(int param1Int, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onNavigationEvent(param1Int, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
                return;
              } 
            }
            
            public void onPostMessage(String param1String, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onPostMessage(param1String, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
                return;
              } 
            }
            
            public void onRelationshipValidationResult(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {
              try {
                CustomTabsSessionToken.this.mCallbackBinder.onRelationshipValidationResult(param1Int, param1Uri, param1Boolean, param1Bundle);
                return;
              } catch (RemoteException remoteException) {
                Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
                return;
              } 
            }
          };
      } 
      this.mCallback = customTabsCallback;
      return;
    } 
    throw new IllegalStateException("CustomTabsSessionToken must have either a session id or a callback (or both).");
  }
  
  public static CustomTabsSessionToken createMockSessionTokenForTesting() {
    return new CustomTabsSessionToken((ICustomTabsCallback)new MockCallback(), null);
  }
  
  private IBinder getCallbackBinderAssertNotNull() {
    ICustomTabsCallback iCustomTabsCallback = this.mCallbackBinder;
    if (iCustomTabsCallback != null)
      return iCustomTabsCallback.asBinder(); 
    throw new IllegalStateException("CustomTabSessionToken must have valid binder or pending session");
  }
  
  public static CustomTabsSessionToken getSessionTokenFromIntent(Intent paramIntent) {
    ICustomTabsCallback iCustomTabsCallback;
    Bundle bundle = paramIntent.getExtras();
    Intent intent = null;
    if (bundle == null)
      return null; 
    IBinder iBinder = BundleCompat.getBinder(bundle, "android.support.customtabs.extra.SESSION");
    PendingIntent pendingIntent = (PendingIntent)paramIntent.getParcelableExtra("android.support.customtabs.extra.SESSION_ID");
    if (iBinder == null && pendingIntent == null)
      return null; 
    if (iBinder == null) {
      paramIntent = intent;
    } else {
      iCustomTabsCallback = ICustomTabsCallback.Stub.asInterface(iBinder);
    } 
    return new CustomTabsSessionToken(iCustomTabsCallback, pendingIntent);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool1;
    if (!(paramObject instanceof CustomTabsSessionToken))
      return false; 
    paramObject = paramObject;
    PendingIntent pendingIntent1 = paramObject.getId();
    PendingIntent pendingIntent2 = this.mSessionId;
    boolean bool2 = true;
    if (pendingIntent2 == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (pendingIntent1 != null)
      bool2 = false; 
    return (bool1 != bool2) ? false : ((pendingIntent2 != null) ? pendingIntent2.equals(pendingIntent1) : getCallbackBinderAssertNotNull().equals(paramObject.getCallbackBinderAssertNotNull()));
  }
  
  public CustomTabsCallback getCallback() {
    return this.mCallback;
  }
  
  IBinder getCallbackBinder() {
    ICustomTabsCallback iCustomTabsCallback = this.mCallbackBinder;
    return (iCustomTabsCallback == null) ? null : iCustomTabsCallback.asBinder();
  }
  
  PendingIntent getId() {
    return this.mSessionId;
  }
  
  public boolean hasCallback() {
    return (this.mCallbackBinder != null);
  }
  
  public boolean hasId() {
    return (this.mSessionId != null);
  }
  
  public int hashCode() {
    PendingIntent pendingIntent = this.mSessionId;
    return (pendingIntent != null) ? pendingIntent.hashCode() : getCallbackBinderAssertNotNull().hashCode();
  }
  
  public boolean isAssociatedWith(CustomTabsSession paramCustomTabsSession) {
    return paramCustomTabsSession.getBinder().equals(this.mCallbackBinder);
  }
  
  static class MockCallback extends ICustomTabsCallback.Stub {
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public void extraCallback(String param1String, Bundle param1Bundle) {}
    
    public Bundle extraCallbackWithResult(String param1String, Bundle param1Bundle) {
      return null;
    }
    
    public void onActivityResized(int param1Int1, int param1Int2, Bundle param1Bundle) {}
    
    public void onMessageChannelReady(Bundle param1Bundle) {}
    
    public void onNavigationEvent(int param1Int, Bundle param1Bundle) {}
    
    public void onPostMessage(String param1String, Bundle param1Bundle) {}
    
    public void onRelationshipValidationResult(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\browser\customtabs\CustomTabsSessionToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */