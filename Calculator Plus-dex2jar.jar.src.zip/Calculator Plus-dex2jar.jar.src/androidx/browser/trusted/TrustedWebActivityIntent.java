package androidx.browser.trusted;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.core.content.ContextCompat;
import java.util.List;

public final class TrustedWebActivityIntent {
  private final Intent mIntent;
  
  private final List<Uri> mSharedFileUris;
  
  TrustedWebActivityIntent(Intent paramIntent, List<Uri> paramList) {
    this.mIntent = paramIntent;
    this.mSharedFileUris = paramList;
  }
  
  private void grantUriPermissionToProvider(Context paramContext) {
    for (Uri uri : this.mSharedFileUris)
      paramContext.grantUriPermission(this.mIntent.getPackage(), uri, 1); 
  }
  
  public Intent getIntent() {
    return this.mIntent;
  }
  
  public void launchTrustedWebActivity(Context paramContext) {
    grantUriPermissionToProvider(paramContext);
    ContextCompat.startActivity(paramContext, this.mIntent, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\browser\trusted\TrustedWebActivityIntent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */