package androidx.activity;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.graphics.Rect;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\0020\0042\006\020\005\032\0020\0062\006\020\007\032\0020\b¨\006\t"}, d2 = {"Landroidx/activity/Api26Impl;", "", "()V", "setPipParamsSourceRectHint", "", "activity", "Landroid/app/Activity;", "hint", "Landroid/graphics/Rect;", "activity-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class Api26Impl {
  public static final Api26Impl INSTANCE = new Api26Impl();
  
  public final void setPipParamsSourceRectHint(Activity paramActivity, Rect paramRect) {
    Intrinsics.checkNotNullParameter(paramActivity, "activity");
    Intrinsics.checkNotNullParameter(paramRect, "hint");
    paramActivity.setPictureInPictureParams((new PictureInPictureParams.Builder()).setSourceRectHint(paramRect).build());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\Api26Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */