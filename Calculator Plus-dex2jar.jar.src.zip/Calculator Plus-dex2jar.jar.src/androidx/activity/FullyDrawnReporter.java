package androidx.activity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\b\002\n\002\020\013\n\002\b\003\n\002\020!\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\b\030\0002\0020\001B\033\022\006\020\002\032\0020\003\022\f\020\004\032\b\022\004\022\0020\0060\005¢\006\002\020\007J\024\020\024\032\0020\0062\f\020\025\032\b\022\004\022\0020\0060\005J\006\020\026\032\0020\006J\b\020\027\032\0020\006H\007J\b\020\030\032\0020\006H\002J\024\020\031\032\0020\0062\f\020\025\032\b\022\004\022\0020\0060\005J\006\020\032\032\0020\006R\016\020\002\032\0020\003X\004¢\006\002\n\000R\021\020\b\032\0020\t8F¢\006\006\032\004\b\b\020\nR\016\020\013\032\0020\001X\004¢\006\002\n\000R\034\020\f\032\016\022\n\022\b\022\004\022\0020\0060\0050\r8\002X\004¢\006\002\n\000R\024\020\004\032\b\022\004\022\0020\0060\005X\004¢\006\002\n\000R\022\020\016\032\0020\t8\002@\002X\016¢\006\002\n\000R\016\020\017\032\0020\020X\004¢\006\002\n\000R\022\020\021\032\0020\t8\002@\002X\016¢\006\002\n\000R\022\020\022\032\0020\0238\002@\002X\016¢\006\002\n\000¨\006\033"}, d2 = {"Landroidx/activity/FullyDrawnReporter;", "", "executor", "Ljava/util/concurrent/Executor;", "reportFullyDrawn", "Lkotlin/Function0;", "", "(Ljava/util/concurrent/Executor;Lkotlin/jvm/functions/Function0;)V", "isFullyDrawnReported", "", "()Z", "lock", "onReportCallbacks", "", "reportPosted", "reportRunnable", "Ljava/lang/Runnable;", "reportedFullyDrawn", "reporterCount", "", "addOnReportDrawnListener", "callback", "addReporter", "fullyDrawnReported", "postWhenReportersAreDone", "removeOnReportDrawnListener", "removeReporter", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class FullyDrawnReporter {
  private final Executor executor;
  
  private final Object lock;
  
  private final List<Function0<Unit>> onReportCallbacks;
  
  private final Function0<Unit> reportFullyDrawn;
  
  private boolean reportPosted;
  
  private final Runnable reportRunnable;
  
  private boolean reportedFullyDrawn;
  
  private int reporterCount;
  
  public FullyDrawnReporter(Executor paramExecutor, Function0<Unit> paramFunction0) {
    this.executor = paramExecutor;
    this.reportFullyDrawn = paramFunction0;
    this.lock = new Object();
    this.onReportCallbacks = new ArrayList<Function0<Unit>>();
    this.reportRunnable = new FullyDrawnReporter$$ExternalSyntheticLambda0(this);
  }
  
  private final void postWhenReportersAreDone() {
    if (!this.reportPosted && this.reporterCount == 0) {
      this.reportPosted = true;
      this.executor.execute(this.reportRunnable);
    } 
  }
  
  private static final void reportRunnable$lambda$2(FullyDrawnReporter paramFullyDrawnReporter) {
    Intrinsics.checkNotNullParameter(paramFullyDrawnReporter, "this$0");
    synchronized (paramFullyDrawnReporter.lock) {
      paramFullyDrawnReporter.reportPosted = false;
      if (paramFullyDrawnReporter.reporterCount == 0 && !paramFullyDrawnReporter.reportedFullyDrawn) {
        paramFullyDrawnReporter.reportFullyDrawn.invoke();
        paramFullyDrawnReporter.fullyDrawnReported();
      } 
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  public final void addOnReportDrawnListener(Function0<Unit> paramFunction0) {
    Intrinsics.checkNotNullParameter(paramFunction0, "callback");
    synchronized (this.lock) {
      boolean bool;
      if (this.reportedFullyDrawn) {
        bool = true;
      } else {
        this.onReportCallbacks.add(paramFunction0);
        bool = false;
      } 
      if (bool)
        paramFunction0.invoke(); 
      return;
    } 
  }
  
  public final void addReporter() {
    synchronized (this.lock) {
      if (!this.reportedFullyDrawn)
        this.reporterCount++; 
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  public final void fullyDrawnReported() {
    synchronized (this.lock) {
      this.reportedFullyDrawn = true;
      Iterator<Function0<Unit>> iterator = this.onReportCallbacks.iterator();
      while (iterator.hasNext())
        ((Function0)iterator.next()).invoke(); 
      this.onReportCallbacks.clear();
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  public final boolean isFullyDrawnReported() {
    synchronized (this.lock) {
      return this.reportedFullyDrawn;
    } 
  }
  
  public final void removeOnReportDrawnListener(Function0<Unit> paramFunction0) {
    Intrinsics.checkNotNullParameter(paramFunction0, "callback");
    synchronized (this.lock) {
      this.onReportCallbacks.remove(paramFunction0);
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
  
  public final void removeReporter() {
    synchronized (this.lock) {
      if (!this.reportedFullyDrawn) {
        boolean bool;
        int i = this.reporterCount;
        if (i > 0) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool) {
          this.reporterCount = i - 1;
          postWhenReportersAreDone();
        } else {
          throw new IllegalStateException("removeReporter() called when all reporters have already been removed.".toString());
        } 
      } 
      Unit unit = Unit.INSTANCE;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\FullyDrawnReporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */