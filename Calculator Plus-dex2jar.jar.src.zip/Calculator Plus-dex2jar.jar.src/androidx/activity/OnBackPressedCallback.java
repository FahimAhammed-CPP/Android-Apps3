package androidx.activity;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000(\n\002\030\002\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\b\016\b&\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\020\020\023\032\0020\n2\006\020\024\032\0020\007H\001J\b\020\025\032\0020\nH'J\b\020\026\032\0020\nH\007J\020\020\027\032\0020\n2\006\020\024\032\0020\007H\001R\024\020\005\032\b\022\004\022\0020\0070\006X\004¢\006\002\n\000R\"\020\b\032\n\022\004\022\0020\n\030\0010\tX\016¢\006\016\n\000\032\004\b\013\020\f\"\004\b\r\020\016R&\020\020\032\0020\0032\006\020\017\032\0020\0038G@GX\016¢\006\016\n\000\032\004\b\020\020\021\"\004\b\022\020\004¨\006\030"}, d2 = {"Landroidx/activity/OnBackPressedCallback;", "", "enabled", "", "(Z)V", "cancellables", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Landroidx/activity/Cancellable;", "enabledChangedCallback", "Lkotlin/Function0;", "", "getEnabledChangedCallback$activity_release", "()Lkotlin/jvm/functions/Function0;", "setEnabledChangedCallback$activity_release", "(Lkotlin/jvm/functions/Function0;)V", "value", "isEnabled", "()Z", "setEnabled", "addCancellable", "cancellable", "handleOnBackPressed", "remove", "removeCancellable", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class OnBackPressedCallback {
  private final CopyOnWriteArrayList<Cancellable> cancellables;
  
  private Function0<Unit> enabledChangedCallback;
  
  private boolean isEnabled;
  
  public OnBackPressedCallback(boolean paramBoolean) {
    this.isEnabled = paramBoolean;
    this.cancellables = new CopyOnWriteArrayList<Cancellable>();
  }
  
  public final void addCancellable(Cancellable paramCancellable) {
    Intrinsics.checkNotNullParameter(paramCancellable, "cancellable");
    this.cancellables.add(paramCancellable);
  }
  
  public final Function0<Unit> getEnabledChangedCallback$activity_release() {
    return this.enabledChangedCallback;
  }
  
  public abstract void handleOnBackPressed();
  
  public final boolean isEnabled() {
    return this.isEnabled;
  }
  
  public final void remove() {
    Iterator<Cancellable> iterator = this.cancellables.iterator();
    while (iterator.hasNext())
      ((Cancellable)iterator.next()).cancel(); 
  }
  
  public final void removeCancellable(Cancellable paramCancellable) {
    Intrinsics.checkNotNullParameter(paramCancellable, "cancellable");
    this.cancellables.remove(paramCancellable);
  }
  
  public final void setEnabled(boolean paramBoolean) {
    this.isEnabled = paramBoolean;
    Function0<Unit> function0 = this.enabledChangedCallback;
    if (function0 != null)
      function0.invoke(); 
  }
  
  public final void setEnabledChangedCallback$activity_release(Function0<Unit> paramFunction0) {
    this.enabledChangedCallback = paramFunction0;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\OnBackPressedCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */