package androidx.activity;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelLazy;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.viewmodel.CreationExtras;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Lazy;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Reflection;

@Metadata(d1 = {"\000\"\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\0324\020\000\032\b\022\004\022\002H\0020\001\"\n\b\000\020\002\030\001*\0020\003*\0020\0042\020\b\n\020\005\032\n\022\004\022\0020\007\030\0010\006H\bø\001\000\032F\020\000\032\b\022\004\022\002H\0020\001\"\n\b\000\020\002\030\001*\0020\003*\0020\0042\020\b\n\020\b\032\n\022\004\022\0020\t\030\0010\0062\020\b\n\020\005\032\n\022\004\022\0020\007\030\0010\006H\bø\001\000\002\007\n\005\b20\001¨\006\n"}, d2 = {"viewModels", "Lkotlin/Lazy;", "VM", "Landroidx/lifecycle/ViewModel;", "Landroidx/activity/ComponentActivity;", "factoryProducer", "Lkotlin/Function0;", "Landroidx/lifecycle/ViewModelProvider$Factory;", "extrasProducer", "Landroidx/lifecycle/viewmodel/CreationExtras;", "activity-ktx_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ActivityViewModelLazyKt {
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/ViewModelStore;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 176)
  public static final class ActivityViewModelLazyKt$viewModels$1 extends Lambda implements Function0<ViewModelStore> {
    public ActivityViewModelLazyKt$viewModels$1(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final ViewModelStore invoke() {
      ViewModelStore viewModelStore = this.$this_viewModels.getViewModelStore();
      Intrinsics.checkNotNullExpressionValue(viewModelStore, "viewModelStore");
      return viewModelStore;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/viewmodel/CreationExtras;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 176)
  public static final class ActivityViewModelLazyKt$viewModels$2 extends Lambda implements Function0<CreationExtras> {
    public ActivityViewModelLazyKt$viewModels$2(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final CreationExtras invoke() {
      CreationExtras creationExtras = this.$this_viewModels.getDefaultViewModelCreationExtras();
      Intrinsics.checkNotNullExpressionValue(creationExtras, "this.defaultViewModelCreationExtras");
      return creationExtras;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/ViewModelStore;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 176)
  public static final class ActivityViewModelLazyKt$viewModels$3 extends Lambda implements Function0<ViewModelStore> {
    public ActivityViewModelLazyKt$viewModels$3(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final ViewModelStore invoke() {
      ViewModelStore viewModelStore = this.$this_viewModels.getViewModelStore();
      Intrinsics.checkNotNullExpressionValue(viewModelStore, "viewModelStore");
      return viewModelStore;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/viewmodel/CreationExtras;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 176)
  public static final class ActivityViewModelLazyKt$viewModels$4 extends Lambda implements Function0<CreationExtras> {
    public ActivityViewModelLazyKt$viewModels$4(Function0<? extends CreationExtras> param1Function0, ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final CreationExtras invoke() {
      Function0<CreationExtras> function0 = this.$extrasProducer;
      if (function0 != null) {
        CreationExtras creationExtras2 = (CreationExtras)function0.invoke();
        CreationExtras creationExtras1 = creationExtras2;
        if (creationExtras2 == null) {
          creationExtras1 = this.$this_viewModels.getDefaultViewModelCreationExtras();
          Intrinsics.checkNotNullExpressionValue(creationExtras1, "this.defaultViewModelCreationExtras");
          return creationExtras1;
        } 
        return creationExtras1;
      } 
      CreationExtras creationExtras = this.$this_viewModels.getDefaultViewModelCreationExtras();
      Intrinsics.checkNotNullExpressionValue(creationExtras, "this.defaultViewModelCreationExtras");
      return creationExtras;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/ViewModelProvider$Factory;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 176)
  public static final class ActivityViewModelLazyKt$viewModels$factoryPromise$1 extends Lambda implements Function0<ViewModelProvider.Factory> {
    public ActivityViewModelLazyKt$viewModels$factoryPromise$1(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final ViewModelProvider.Factory invoke() {
      ViewModelProvider.Factory factory = this.$this_viewModels.getDefaultViewModelProviderFactory();
      Intrinsics.checkNotNullExpressionValue(factory, "defaultViewModelProviderFactory");
      return factory;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\020\000\032\0020\001\"\n\b\000\020\002\030\001*\0020\003H\n¢\006\002\b\004"}, d2 = {"<anonymous>", "Landroidx/lifecycle/ViewModelProvider$Factory;", "VM", "Landroidx/lifecycle/ViewModel;", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 176)
  public static final class ActivityViewModelLazyKt$viewModels$factoryPromise$2 extends Lambda implements Function0<ViewModelProvider.Factory> {
    public ActivityViewModelLazyKt$viewModels$factoryPromise$2(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final ViewModelProvider.Factory invoke() {
      ViewModelProvider.Factory factory = this.$this_viewModels.getDefaultViewModelProviderFactory();
      Intrinsics.checkNotNullExpressionValue(factory, "defaultViewModelProviderFactory");
      return factory;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\ActivityViewModelLazyKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */