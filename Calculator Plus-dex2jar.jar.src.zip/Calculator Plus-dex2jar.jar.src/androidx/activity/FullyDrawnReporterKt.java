package androidx.activity;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;

@Metadata(d1 = {"\000\034\n\000\n\002\020\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\002\0323\020\000\032\0020\001*\0020\0022\034\020\003\032\030\b\001\022\n\022\b\022\004\022\0020\0010\005\022\006\022\004\030\0010\0060\004HHø\001\000¢\006\002\020\007\002\004\n\002\b\031¨\006\b"}, d2 = {"reportWhenComplete", "", "Landroidx/activity/FullyDrawnReporter;", "reporter", "Lkotlin/Function1;", "Lkotlin/coroutines/Continuation;", "", "(Landroidx/activity/FullyDrawnReporter;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "activity_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class FullyDrawnReporterKt {
  public static final Object reportWhenComplete(FullyDrawnReporter paramFullyDrawnReporter, Function1<? super Continuation<? super Unit>, ? extends Object> paramFunction1, Continuation<? super Unit> paramContinuation) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof androidx/activity/FullyDrawnReporterKt$reportWhenComplete$1
    //   4: ifeq -> 40
    //   7: aload_2
    //   8: checkcast androidx/activity/FullyDrawnReporterKt$reportWhenComplete$1
    //   11: astore #4
    //   13: aload #4
    //   15: getfield label : I
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 40
    //   24: aload #4
    //   26: aload #4
    //   28: getfield label : I
    //   31: ldc -2147483648
    //   33: iadd
    //   34: putfield label : I
    //   37: goto -> 50
    //   40: new androidx/activity/FullyDrawnReporterKt$reportWhenComplete$1
    //   43: dup
    //   44: aload_2
    //   45: invokespecial <init> : (Lkotlin/coroutines/Continuation;)V
    //   48: astore #4
    //   50: aload #4
    //   52: getfield result : Ljava/lang/Object;
    //   55: astore #6
    //   57: invokestatic getCOROUTINE_SUSPENDED : ()Ljava/lang/Object;
    //   60: astore #5
    //   62: aload #4
    //   64: getfield label : I
    //   67: istore_3
    //   68: iload_3
    //   69: ifeq -> 106
    //   72: iload_3
    //   73: iconst_1
    //   74: if_icmpne -> 96
    //   77: aload #4
    //   79: getfield L$0 : Ljava/lang/Object;
    //   82: checkcast androidx/activity/FullyDrawnReporter
    //   85: astore_0
    //   86: aload_0
    //   87: astore_2
    //   88: aload #6
    //   90: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   93: goto -> 162
    //   96: new java/lang/IllegalStateException
    //   99: dup
    //   100: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   102: invokespecial <init> : (Ljava/lang/String;)V
    //   105: athrow
    //   106: aload #6
    //   108: invokestatic throwOnFailure : (Ljava/lang/Object;)V
    //   111: aload_0
    //   112: invokevirtual addReporter : ()V
    //   115: aload_0
    //   116: invokevirtual isFullyDrawnReported : ()Z
    //   119: ifeq -> 126
    //   122: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   125: areturn
    //   126: aload_0
    //   127: astore_2
    //   128: aload #4
    //   130: aload_0
    //   131: putfield L$0 : Ljava/lang/Object;
    //   134: aload_0
    //   135: astore_2
    //   136: aload #4
    //   138: iconst_1
    //   139: putfield label : I
    //   142: aload_0
    //   143: astore_2
    //   144: aload_1
    //   145: aload #4
    //   147: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   152: astore_1
    //   153: aload_1
    //   154: aload #5
    //   156: if_acmpne -> 162
    //   159: aload #5
    //   161: areturn
    //   162: iconst_1
    //   163: invokestatic finallyStart : (I)V
    //   166: aload_0
    //   167: invokevirtual removeReporter : ()V
    //   170: iconst_1
    //   171: invokestatic finallyEnd : (I)V
    //   174: getstatic kotlin/Unit.INSTANCE : Lkotlin/Unit;
    //   177: areturn
    //   178: astore_0
    //   179: iconst_1
    //   180: invokestatic finallyStart : (I)V
    //   183: aload_2
    //   184: invokevirtual removeReporter : ()V
    //   187: iconst_1
    //   188: invokestatic finallyEnd : (I)V
    //   191: aload_0
    //   192: athrow
    // Exception table:
    //   from	to	target	type
    //   88	93	178	finally
    //   128	134	178	finally
    //   136	142	178	finally
    //   144	153	178	finally
  }
  
  private static final Object reportWhenComplete$$forInline(FullyDrawnReporter paramFullyDrawnReporter, Function1<? super Continuation<? super Unit>, ? extends Object> paramFunction1, Continuation<? super Unit> paramContinuation) {
    paramFullyDrawnReporter.addReporter();
    if (paramFullyDrawnReporter.isFullyDrawnReported())
      return Unit.INSTANCE; 
    try {
      paramFunction1.invoke(paramContinuation);
      return Unit.INSTANCE;
    } finally {
      InlineMarker.finallyStart(1);
      paramFullyDrawnReporter.removeReporter();
      InlineMarker.finallyEnd(1);
    } 
  }
  
  @Metadata(k = 3, mv = {1, 8, 0}, xi = 176)
  @DebugMetadata(c = "androidx.activity.FullyDrawnReporterKt", f = "FullyDrawnReporter.kt", i = {0}, l = {188}, m = "reportWhenComplete", n = {"$this$reportWhenComplete"}, s = {"L$0"})
  static final class FullyDrawnReporterKt$reportWhenComplete$1 extends ContinuationImpl {
    Object L$0;
    
    int label;
    
    FullyDrawnReporterKt$reportWhenComplete$1(Continuation<? super FullyDrawnReporterKt$reportWhenComplete$1> param1Continuation) {
      super(param1Continuation);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.result = param1Object;
      this.label |= Integer.MIN_VALUE;
      return FullyDrawnReporterKt.reportWhenComplete(null, null, (Continuation<? super Unit>)this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\FullyDrawnReporterKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */