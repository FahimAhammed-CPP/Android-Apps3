package androidx.activity.result;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import kotlin.Metadata;
import kotlin.annotation.AnnotationRetention;
import kotlin.annotation.Retention;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\013\n\002\020\002\n\002\b\005\b\007\030\000 \0322\0020\001:\002\031\032B\017\b\020\022\006\020\002\032\0020\003¢\006\002\020\004B/\b\000\022\006\020\005\032\0020\006\022\n\b\002\020\007\032\004\030\0010\b\022\b\b\002\020\t\032\0020\n\022\b\b\002\020\013\032\0020\n¢\006\002\020\fJ\b\020\024\032\0020\nH\026J\030\020\025\032\0020\0262\006\020\027\032\0020\0032\006\020\030\032\0020\nH\026R\023\020\007\032\004\030\0010\b¢\006\b\n\000\032\004\b\r\020\016R\021\020\t\032\0020\n¢\006\b\n\000\032\004\b\017\020\020R\021\020\013\032\0020\n¢\006\b\n\000\032\004\b\021\020\020R\021\020\005\032\0020\006¢\006\b\n\000\032\004\b\022\020\023¨\006\033"}, d2 = {"Landroidx/activity/result/IntentSenderRequest;", "Landroid/os/Parcelable;", "parcel", "Landroid/os/Parcel;", "(Landroid/os/Parcel;)V", "intentSender", "Landroid/content/IntentSender;", "fillInIntent", "Landroid/content/Intent;", "flagsMask", "", "flagsValues", "(Landroid/content/IntentSender;Landroid/content/Intent;II)V", "getFillInIntent", "()Landroid/content/Intent;", "getFlagsMask", "()I", "getFlagsValues", "getIntentSender", "()Landroid/content/IntentSender;", "describeContents", "writeToParcel", "", "dest", "flags", "Builder", "Companion", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class IntentSenderRequest implements Parcelable {
  public static final Parcelable.Creator<IntentSenderRequest> CREATOR;
  
  public static final Companion Companion = new Companion(null);
  
  private final Intent fillInIntent;
  
  private final int flagsMask;
  
  private final int flagsValues;
  
  private final IntentSender intentSender;
  
  static {
    CREATOR = new IntentSenderRequest$Companion$CREATOR$1();
  }
  
  public IntentSenderRequest(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.intentSender = paramIntentSender;
    this.fillInIntent = paramIntent;
    this.flagsMask = paramInt1;
    this.flagsValues = paramInt2;
  }
  
  public IntentSenderRequest(Parcel paramParcel) {
    this((IntentSender)parcelable, (Intent)paramParcel.readParcelable(Intent.class.getClassLoader()), paramParcel.readInt(), paramParcel.readInt());
  }
  
  public int describeContents() {
    return 0;
  }
  
  public final Intent getFillInIntent() {
    return this.fillInIntent;
  }
  
  public final int getFlagsMask() {
    return this.flagsMask;
  }
  
  public final int getFlagsValues() {
    return this.flagsValues;
  }
  
  public final IntentSender getIntentSender() {
    return this.intentSender;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    Intrinsics.checkNotNullParameter(paramParcel, "dest");
    paramParcel.writeParcelable((Parcelable)this.intentSender, paramInt);
    paramParcel.writeParcelable((Parcelable)this.fillInIntent, paramInt);
    paramParcel.writeInt(this.flagsMask);
    paramParcel.writeInt(this.flagsValues);
  }
  
  @Metadata(d1 = {"\0000\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\006\030\0002\0020\001:\001\023B\017\b\026\022\006\020\002\032\0020\003¢\006\002\020\004B\r\022\006\020\005\032\0020\006¢\006\002\020\007J\006\020\r\032\0020\016J\020\020\017\032\0020\0002\b\020\b\032\004\030\0010\tJ\026\020\020\032\0020\0002\006\020\021\032\0020\0132\006\020\022\032\0020\013R\020\020\b\032\004\030\0010\tX\016¢\006\002\n\000R\016\020\n\032\0020\013X\016¢\006\002\n\000R\016\020\f\032\0020\013X\016¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000¨\006\024"}, d2 = {"Landroidx/activity/result/IntentSenderRequest$Builder;", "", "pendingIntent", "Landroid/app/PendingIntent;", "(Landroid/app/PendingIntent;)V", "intentSender", "Landroid/content/IntentSender;", "(Landroid/content/IntentSender;)V", "fillInIntent", "Landroid/content/Intent;", "flagsMask", "", "flagsValues", "build", "Landroidx/activity/result/IntentSenderRequest;", "setFillInIntent", "setFlags", "values", "mask", "Flag", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Builder {
    private Intent fillInIntent;
    
    private int flagsMask;
    
    private int flagsValues;
    
    private final IntentSender intentSender;
    
    public Builder(PendingIntent param1PendingIntent) {
      this(intentSender);
    }
    
    public Builder(IntentSender param1IntentSender) {
      this.intentSender = param1IntentSender;
    }
    
    public final IntentSenderRequest build() {
      return new IntentSenderRequest(this.intentSender, this.fillInIntent, this.flagsMask, this.flagsValues);
    }
    
    public final Builder setFillInIntent(Intent param1Intent) {
      this.fillInIntent = param1Intent;
      return this;
    }
    
    public final Builder setFlags(int param1Int1, int param1Int2) {
      this.flagsValues = param1Int1;
      this.flagsMask = param1Int2;
      return this;
    }
    
    @Retention(RetentionPolicy.SOURCE)
    @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\033\n\000\b\002\030\0002\0020\001B\000¨\006\002"}, d2 = {"Landroidx/activity/result/IntentSenderRequest$Builder$Flag;", "", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    @Retention(AnnotationRetention.SOURCE)
    private static @interface Flag {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @Metadata(d1 = {"\000\n\n\002\030\002\n\002\020\033\n\000\b\002\030\0002\0020\001B\000¨\006\002"}, d2 = {"Landroidx/activity/result/IntentSenderRequest$Builder$Flag;", "", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  @Retention(AnnotationRetention.SOURCE)
  private static @interface Flag {}
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002R\034\020\003\032\b\022\004\022\0020\0050\0048\006X\004¢\006\b\n\000\022\004\b\006\020\002¨\006\007"}, d2 = {"Landroidx/activity/result/IntentSenderRequest$Companion;", "", "()V", "CREATOR", "Landroid/os/Parcelable$Creator;", "Landroidx/activity/result/IntentSenderRequest;", "getCREATOR$annotations", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Companion {
    private Companion() {}
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\021\n\000\n\002\020\b\n\002\b\002*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\020\020\003\032\0020\0022\006\020\004\032\0020\005H\026J\035\020\006\032\n\022\006\022\004\030\0010\0020\0072\006\020\b\032\0020\tH\026¢\006\002\020\n¨\006\013"}, d2 = {"androidx/activity/result/IntentSenderRequest$Companion$CREATOR$1", "Landroid/os/Parcelable$Creator;", "Landroidx/activity/result/IntentSenderRequest;", "createFromParcel", "inParcel", "Landroid/os/Parcel;", "newArray", "", "size", "", "(I)[Landroidx/activity/result/IntentSenderRequest;", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class IntentSenderRequest$Companion$CREATOR$1 implements Parcelable.Creator<IntentSenderRequest> {
    public IntentSenderRequest createFromParcel(Parcel param1Parcel) {
      Intrinsics.checkNotNullParameter(param1Parcel, "inParcel");
      return new IntentSenderRequest(param1Parcel);
    }
    
    public IntentSenderRequest[] newArray(int param1Int) {
      return new IntentSenderRequest[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\result\IntentSenderRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */