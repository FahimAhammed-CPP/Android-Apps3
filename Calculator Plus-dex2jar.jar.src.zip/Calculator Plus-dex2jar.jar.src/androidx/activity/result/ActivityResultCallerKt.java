package androidx.activity.result;

import androidx.activity.result.contract.ActivityResultContract;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000,\n\000\n\002\030\002\n\002\020\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\032Q\020\000\032\b\022\004\022\0020\0020\001\"\004\b\000\020\003\"\004\b\001\020\004*\0020\0052\022\020\006\032\016\022\004\022\002H\003\022\004\022\002H\0040\0072\006\020\b\032\002H\0032\022\020\t\032\016\022\004\022\002H\004\022\004\022\0020\0020\n¢\006\002\020\013\032Y\020\000\032\b\022\004\022\0020\0020\001\"\004\b\000\020\003\"\004\b\001\020\004*\0020\0052\022\020\006\032\016\022\004\022\002H\003\022\004\022\002H\0040\0072\006\020\b\032\002H\0032\006\020\f\032\0020\r2\022\020\t\032\016\022\004\022\002H\004\022\004\022\0020\0020\n¢\006\002\020\016¨\006\017"}, d2 = {"registerForActivityResult", "Landroidx/activity/result/ActivityResultLauncher;", "", "I", "O", "Landroidx/activity/result/ActivityResultCaller;", "contract", "Landroidx/activity/result/contract/ActivityResultContract;", "input", "callback", "Lkotlin/Function1;", "(Landroidx/activity/result/ActivityResultCaller;Landroidx/activity/result/contract/ActivityResultContract;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Landroidx/activity/result/ActivityResultLauncher;", "registry", "Landroidx/activity/result/ActivityResultRegistry;", "(Landroidx/activity/result/ActivityResultCaller;Landroidx/activity/result/contract/ActivityResultContract;Ljava/lang/Object;Landroidx/activity/result/ActivityResultRegistry;Lkotlin/jvm/functions/Function1;)Landroidx/activity/result/ActivityResultLauncher;", "activity-ktx_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ActivityResultCallerKt {
  public static final <I, O> ActivityResultLauncher<Unit> registerForActivityResult(ActivityResultCaller paramActivityResultCaller, ActivityResultContract<I, O> paramActivityResultContract, I paramI, ActivityResultRegistry paramActivityResultRegistry, Function1<? super O, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramActivityResultCaller, "<this>");
    Intrinsics.checkNotNullParameter(paramActivityResultContract, "contract");
    Intrinsics.checkNotNullParameter(paramActivityResultRegistry, "registry");
    Intrinsics.checkNotNullParameter(paramFunction1, "callback");
    ActivityResultLauncher<I> activityResultLauncher = paramActivityResultCaller.registerForActivityResult(paramActivityResultContract, paramActivityResultRegistry, new ActivityResultCallerKt$$ExternalSyntheticLambda1(paramFunction1));
    Intrinsics.checkNotNullExpressionValue(activityResultLauncher, "registerForActivityResul…egistry) { callback(it) }");
    return new ActivityResultCallerLauncher<I, O>(activityResultLauncher, paramActivityResultContract, paramI);
  }
  
  public static final <I, O> ActivityResultLauncher<Unit> registerForActivityResult(ActivityResultCaller paramActivityResultCaller, ActivityResultContract<I, O> paramActivityResultContract, I paramI, Function1<? super O, Unit> paramFunction1) {
    Intrinsics.checkNotNullParameter(paramActivityResultCaller, "<this>");
    Intrinsics.checkNotNullParameter(paramActivityResultContract, "contract");
    Intrinsics.checkNotNullParameter(paramFunction1, "callback");
    ActivityResultLauncher<I> activityResultLauncher = paramActivityResultCaller.registerForActivityResult(paramActivityResultContract, new ActivityResultCallerKt$$ExternalSyntheticLambda0(paramFunction1));
    Intrinsics.checkNotNullExpressionValue(activityResultLauncher, "registerForActivityResul…ontract) { callback(it) }");
    return new ActivityResultCallerLauncher<I, O>(activityResultLauncher, paramActivityResultContract, paramI);
  }
  
  private static final void registerForActivityResult$lambda$0(Function1 paramFunction1, Object paramObject) {
    Intrinsics.checkNotNullParameter(paramFunction1, "$callback");
    paramFunction1.invoke(paramObject);
  }
  
  private static final void registerForActivityResult$lambda$1(Function1 paramFunction1, Object paramObject) {
    Intrinsics.checkNotNullParameter(paramFunction1, "$callback");
    paramFunction1.invoke(paramObject);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\result\ActivityResultCallerKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */