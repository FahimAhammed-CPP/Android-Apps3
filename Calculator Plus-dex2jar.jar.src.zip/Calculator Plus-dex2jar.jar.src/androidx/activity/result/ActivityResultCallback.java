package androidx.activity.result;

import kotlin.Metadata;

@Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\020\000\n\000\n\002\020\002\n\002\b\003\bæ\001\030\000*\004\b\000\020\0012\0020\002J\025\020\003\032\0020\0042\006\020\005\032\0028\000H&¢\006\002\020\006ø\001\000\002\006\n\004\b!0\001¨\006\007À\006\001"}, d2 = {"Landroidx/activity/result/ActivityResultCallback;", "O", "", "onActivityResult", "", "result", "(Ljava/lang/Object;)V", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface ActivityResultCallback<O> {
  void onActivityResult(O paramO);
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\result\ActivityResultCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */