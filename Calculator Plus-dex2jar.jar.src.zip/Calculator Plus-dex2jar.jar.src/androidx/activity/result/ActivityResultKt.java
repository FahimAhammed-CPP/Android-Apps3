package androidx.activity.result;

import android.content.Intent;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\022\n\000\n\002\020\b\n\002\030\002\n\000\n\002\030\002\n\000\032\r\020\000\032\0020\001*\0020\002H\002\032\017\020\003\032\004\030\0010\004*\0020\002H\002¨\006\005"}, d2 = {"component1", "", "Landroidx/activity/result/ActivityResult;", "component2", "Landroid/content/Intent;", "activity-ktx_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ActivityResultKt {
  public static final int component1(ActivityResult paramActivityResult) {
    Intrinsics.checkNotNullParameter(paramActivityResult, "<this>");
    return paramActivityResult.getResultCode();
  }
  
  public static final Intent component2(ActivityResult paramActivityResult) {
    Intrinsics.checkNotNullParameter(paramActivityResult, "<this>");
    return paramActivityResult.getData();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\result\ActivityResultKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */