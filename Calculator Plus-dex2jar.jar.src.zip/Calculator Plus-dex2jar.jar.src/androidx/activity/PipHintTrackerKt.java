package androidx.activity;

import android.app.Activity;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewTreeObserver;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.channels.ProduceKt;
import kotlinx.coroutines.channels.ProducerScope;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;

@Metadata(d1 = {"\000\024\n\000\n\002\020\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\032\035\020\000\032\0020\001*\0020\0022\006\020\003\032\0020\004H@ø\001\000¢\006\002\020\005\002\004\n\002\b\031¨\006\006"}, d2 = {"trackPipAnimationHintView", "", "Landroid/app/Activity;", "view", "Landroid/view/View;", "(Landroid/app/Activity;Landroid/view/View;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "activity-ktx_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class PipHintTrackerKt {
  public static final Object trackPipAnimationHintView(Activity paramActivity, View paramView, Continuation<? super Unit> paramContinuation) {
    Object object = FlowKt.callbackFlow(new PipHintTrackerKt$trackPipAnimationHintView$flow$1(paramView, null)).collect(new PipHintTrackerKt$trackPipAnimationHintView$2(paramActivity), paramContinuation);
    return (object == IntrinsicsKt.getCOROUTINE_SUSPENDED()) ? object : Unit.INSTANCE;
  }
  
  private static final Rect trackPipAnimationHintView$positionInWindow(View paramView) {
    Rect rect = new Rect();
    paramView.getGlobalVisibleRect(rect);
    return rect;
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002\020\000\032\0020\0012\006\020\002\032\0020\003H@¢\006\004\b\004\020\005"}, d2 = {"<anonymous>", "", "hint", "Landroid/graphics/Rect;", "emit", "(Landroid/graphics/Rect;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class PipHintTrackerKt$trackPipAnimationHintView$2<T> implements FlowCollector {
    PipHintTrackerKt$trackPipAnimationHintView$2(Activity param1Activity) {}
    
    public final Object emit(Rect param1Rect, Continuation<? super Unit> param1Continuation) {
      Api26Impl.INSTANCE.setPipParamsSourceRectHint(this.$this_trackPipAnimationHintView, param1Rect);
      return Unit.INSTANCE;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\000\n\002\020\002\n\002\030\002\n\002\030\002\020\000\032\0020\001*\b\022\004\022\0020\0030\002H@"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/channels/ProducerScope;", "Landroid/graphics/Rect;"}, k = 3, mv = {1, 8, 0}, xi = 48)
  @DebugMetadata(c = "androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1", f = "PipHintTracker.kt", i = {}, l = {87}, m = "invokeSuspend", n = {}, s = {})
  static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1 extends SuspendLambda implements Function2<ProducerScope<? super Rect>, Continuation<? super Unit>, Object> {
    int label;
    
    PipHintTrackerKt$trackPipAnimationHintView$flow$1(View param1View, Continuation<? super PipHintTrackerKt$trackPipAnimationHintView$flow$1> param1Continuation) {
      super(2, param1Continuation);
    }
    
    private static final void invokeSuspend$lambda$0(ProducerScope param1ProducerScope, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
      if (param1Int1 != param1Int5 || param1Int3 != param1Int7 || param1Int2 != param1Int6 || param1Int4 != param1Int8) {
        Intrinsics.checkNotNullExpressionValue(param1View, "v");
        param1ProducerScope.trySend-JP2dKIU(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(param1View));
      } 
    }
    
    private static final void invokeSuspend$lambda$1(ProducerScope param1ProducerScope, View param1View) {
      param1ProducerScope.trySend-JP2dKIU(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(param1View));
    }
    
    public final Continuation<Unit> create(Object param1Object, Continuation<?> param1Continuation) {
      PipHintTrackerKt$trackPipAnimationHintView$flow$1 pipHintTrackerKt$trackPipAnimationHintView$flow$1 = new PipHintTrackerKt$trackPipAnimationHintView$flow$1(this.$view, (Continuation)param1Continuation);
      pipHintTrackerKt$trackPipAnimationHintView$flow$1.L$0 = param1Object;
      return (Continuation<Unit>)pipHintTrackerKt$trackPipAnimationHintView$flow$1;
    }
    
    public final Object invoke(ProducerScope<? super Rect> param1ProducerScope, Continuation<? super Unit> param1Continuation) {
      return ((PipHintTrackerKt$trackPipAnimationHintView$flow$1)create(param1ProducerScope, param1Continuation)).invokeSuspend(Unit.INSTANCE);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = IntrinsicsKt.getCOROUTINE_SUSPENDED();
      int i = this.label;
      if (i != 0) {
        if (i == 1) {
          ResultKt.throwOnFailure(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        ResultKt.throwOnFailure(param1Object);
        param1Object = this.L$0;
        PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda0 pipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda0 = new PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda0((ProducerScope)param1Object);
        PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda1 pipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda1 = new PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda1((ProducerScope)param1Object, this.$view);
        PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 pipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 = new PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1((ProducerScope<? super Rect>)param1Object, this.$view, pipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda1, pipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda0);
        if (Api19Impl.INSTANCE.isAttachedToWindow(this.$view)) {
          param1Object.trySend-JP2dKIU(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(this.$view));
          this.$view.getViewTreeObserver().addOnScrollChangedListener(pipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda1);
          this.$view.addOnLayoutChangeListener(pipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda0);
        } 
        this.$view.addOnAttachStateChangeListener(pipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1);
        Function0<Unit> function0 = new Function0<Unit>(this.$view, pipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda1, pipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda0, pipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1) {
            public final void invoke() {
              this.$view.getViewTreeObserver().removeOnScrollChangedListener(this.$scrollChangeListener);
              this.$view.removeOnLayoutChangeListener(this.$layoutChangeListener);
              this.$view.removeOnAttachStateChangeListener(this.$attachStateChangeListener);
            }
          };
        Continuation continuation = (Continuation)this;
        this.label = 1;
        if (ProduceKt.awaitClose((ProducerScope)param1Object, function0, continuation) == object)
          return object; 
      } 
      return Unit.INSTANCE;
    }
    
    @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007"}, d2 = {"androidx/activity/PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1", "Landroid/view/View$OnAttachStateChangeListener;", "onViewAttachedToWindow", "", "v", "Landroid/view/View;", "onViewDetachedFromWindow", "activity-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 implements View.OnAttachStateChangeListener {
      PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1(ProducerScope<? super Rect> param1ProducerScope, View param1View, ViewTreeObserver.OnScrollChangedListener param1OnScrollChangedListener, View.OnLayoutChangeListener param1OnLayoutChangeListener) {}
      
      public void onViewAttachedToWindow(View param1View) {
        Intrinsics.checkNotNullParameter(param1View, "v");
        this.$$this$callbackFlow.trySend-JP2dKIU(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(this.$view));
        this.$view.getViewTreeObserver().addOnScrollChangedListener(this.$scrollChangeListener);
        this.$view.addOnLayoutChangeListener(this.$layoutChangeListener);
      }
      
      public void onViewDetachedFromWindow(View param1View) {
        Intrinsics.checkNotNullParameter(param1View, "v");
        param1View.getViewTreeObserver().removeOnScrollChangedListener(this.$scrollChangeListener);
        param1View.removeOnLayoutChangeListener(this.$layoutChangeListener);
      }
    }
  }
  
  @Metadata(d1 = {"\000\b\n\000\n\002\020\002\n\000\020\000\032\0020\001H\n¢\006\002\b\002"}, d2 = {"<anonymous>", "", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 48)
  static final class null extends Lambda implements Function0<Unit> {
    null(View param1View, ViewTreeObserver.OnScrollChangedListener param1OnScrollChangedListener, View.OnLayoutChangeListener param1OnLayoutChangeListener, PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 param1PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1) {
      super(0);
    }
    
    public final void invoke() {
      this.$view.getViewTreeObserver().removeOnScrollChangedListener(this.$scrollChangeListener);
      this.$view.removeOnLayoutChangeListener(this.$layoutChangeListener);
      this.$view.removeOnAttachStateChangeListener(this.$attachStateChangeListener);
    }
  }
  
  @Metadata(d1 = {"\000\031\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\002\b\002*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026J\020\020\006\032\0020\0032\006\020\004\032\0020\005H\026¨\006\007"}, d2 = {"androidx/activity/PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1", "Landroid/view/View$OnAttachStateChangeListener;", "onViewAttachedToWindow", "", "v", "Landroid/view/View;", "onViewDetachedFromWindow", "activity-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 implements View.OnAttachStateChangeListener {
    PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1(ProducerScope<? super Rect> param1ProducerScope, View param1View, ViewTreeObserver.OnScrollChangedListener param1OnScrollChangedListener, View.OnLayoutChangeListener param1OnLayoutChangeListener) {}
    
    public void onViewAttachedToWindow(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "v");
      this.$$this$callbackFlow.trySend-JP2dKIU(PipHintTrackerKt.trackPipAnimationHintView$positionInWindow(this.$view));
      this.$view.getViewTreeObserver().addOnScrollChangedListener(this.$scrollChangeListener);
      this.$view.addOnLayoutChangeListener(this.$layoutChangeListener);
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      Intrinsics.checkNotNullParameter(param1View, "v");
      param1View.getViewTreeObserver().removeOnScrollChangedListener(this.$scrollChangeListener);
      param1View.removeOnLayoutChangeListener(this.$layoutChangeListener);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\PipHintTrackerKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */