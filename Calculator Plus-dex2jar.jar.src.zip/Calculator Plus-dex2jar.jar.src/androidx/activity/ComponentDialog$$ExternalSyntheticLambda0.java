package androidx.activity;


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\ComponentDialog$$ExternalSyntheticLambda0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */