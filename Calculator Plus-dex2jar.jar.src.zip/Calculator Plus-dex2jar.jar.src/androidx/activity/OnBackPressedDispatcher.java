package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import java.util.Collection;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArrayDeque;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

@Metadata(d1 = {"\000H\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\013\030\0002\0020\001:\003\036\037 B\023\b\007\022\n\b\002\020\002\032\004\030\0010\003¢\006\002\020\004J\020\020\021\032\0020\t2\006\020\022\032\0020\020H\007J\030\020\021\032\0020\t2\006\020\023\032\0020\0242\006\020\022\032\0020\020H\007J\025\020\025\032\0020\0262\006\020\022\032\0020\020H\001¢\006\002\b\027J\b\020\030\032\0020\006H\007J\b\020\031\032\0020\tH\007J\020\020\032\032\0020\t2\006\020\033\032\0020\013H\007J\r\020\034\032\0020\tH\001¢\006\002\b\035R\016\020\005\032\0020\006X\016¢\006\002\n\000R\026\020\007\032\n\022\004\022\0020\t\030\0010\bX\016¢\006\002\n\000R\020\020\002\032\004\030\0010\003X\004¢\006\002\n\000R\020\020\n\032\004\030\0010\013X\016¢\006\002\n\000R\020\020\f\032\004\030\0010\rX\016¢\006\002\n\000R\024\020\016\032\b\022\004\022\0020\0200\017X\004¢\006\002\n\000¨\006!"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher;", "", "fallbackOnBackPressed", "Ljava/lang/Runnable;", "(Ljava/lang/Runnable;)V", "backInvokedCallbackRegistered", "", "enabledChangedCallback", "Lkotlin/Function0;", "", "invokedDispatcher", "Landroid/window/OnBackInvokedDispatcher;", "onBackInvokedCallback", "Landroid/window/OnBackInvokedCallback;", "onBackPressedCallbacks", "Lkotlin/collections/ArrayDeque;", "Landroidx/activity/OnBackPressedCallback;", "addCallback", "onBackPressedCallback", "owner", "Landroidx/lifecycle/LifecycleOwner;", "addCancellableCallback", "Landroidx/activity/Cancellable;", "addCancellableCallback$activity_release", "hasEnabledCallbacks", "onBackPressed", "setOnBackInvokedDispatcher", "invoker", "updateBackInvokedCallbackState", "updateBackInvokedCallbackState$activity_release", "Api33Impl", "LifecycleOnBackPressedCancellable", "OnBackPressedCancellable", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class OnBackPressedDispatcher {
  private boolean backInvokedCallbackRegistered;
  
  private Function0<Unit> enabledChangedCallback;
  
  private final Runnable fallbackOnBackPressed;
  
  private OnBackInvokedDispatcher invokedDispatcher;
  
  private OnBackInvokedCallback onBackInvokedCallback;
  
  private final ArrayDeque<OnBackPressedCallback> onBackPressedCallbacks;
  
  public OnBackPressedDispatcher() {
    this(null, 1, null);
  }
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.fallbackOnBackPressed = paramRunnable;
    this.onBackPressedCallbacks = new ArrayDeque();
    if (Build.VERSION.SDK_INT >= 33) {
      this.enabledChangedCallback = new Function0<Unit>() {
          public final void invoke() {
            OnBackPressedDispatcher.this.updateBackInvokedCallbackState$activity_release();
          }
        };
      this.onBackInvokedCallback = Api33Impl.INSTANCE.createOnBackInvokedCallback(new Function0<Unit>() {
            public final void invoke() {
              OnBackPressedDispatcher.this.onBackPressed();
            }
          });
    } 
  }
  
  public final void addCallback(OnBackPressedCallback paramOnBackPressedCallback) {
    Intrinsics.checkNotNullParameter(paramOnBackPressedCallback, "onBackPressedCallback");
    addCancellableCallback$activity_release(paramOnBackPressedCallback);
  }
  
  public final void addCallback(LifecycleOwner paramLifecycleOwner, OnBackPressedCallback paramOnBackPressedCallback) {
    Intrinsics.checkNotNullParameter(paramLifecycleOwner, "owner");
    Intrinsics.checkNotNullParameter(paramOnBackPressedCallback, "onBackPressedCallback");
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    if (lifecycle.getCurrentState() == Lifecycle.State.DESTROYED)
      return; 
    paramOnBackPressedCallback.addCancellable(new LifecycleOnBackPressedCancellable(lifecycle, paramOnBackPressedCallback));
    if (Build.VERSION.SDK_INT >= 33) {
      updateBackInvokedCallbackState$activity_release();
      paramOnBackPressedCallback.setEnabledChangedCallback$activity_release(this.enabledChangedCallback);
    } 
  }
  
  public final Cancellable addCancellableCallback$activity_release(OnBackPressedCallback paramOnBackPressedCallback) {
    Intrinsics.checkNotNullParameter(paramOnBackPressedCallback, "onBackPressedCallback");
    this.onBackPressedCallbacks.add(paramOnBackPressedCallback);
    OnBackPressedCancellable onBackPressedCancellable = new OnBackPressedCancellable(paramOnBackPressedCallback);
    paramOnBackPressedCallback.addCancellable(onBackPressedCancellable);
    if (Build.VERSION.SDK_INT >= 33) {
      updateBackInvokedCallbackState$activity_release();
      paramOnBackPressedCallback.setEnabledChangedCallback$activity_release(this.enabledChangedCallback);
    } 
    return onBackPressedCancellable;
  }
  
  public final boolean hasEnabledCallbacks() {
    Iterable iterable = (Iterable)this.onBackPressedCallbacks;
    boolean bool = iterable instanceof Collection;
    boolean bool1 = false;
    if (bool && ((Collection)iterable).isEmpty())
      return false; 
    Iterator<OnBackPressedCallback> iterator = iterable.iterator();
    while (true) {
      bool = bool1;
      if (iterator.hasNext()) {
        if (((OnBackPressedCallback)iterator.next()).isEnabled()) {
          bool = true;
          break;
        } 
        continue;
      } 
      break;
    } 
    return bool;
  }
  
  public final void onBackPressed() {
    // Byte code:
    //   0: aload_0
    //   1: getfield onBackPressedCallbacks : Lkotlin/collections/ArrayDeque;
    //   4: checkcast java/util/List
    //   7: astore_1
    //   8: aload_1
    //   9: aload_1
    //   10: invokeinterface size : ()I
    //   15: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   20: astore_2
    //   21: aload_2
    //   22: invokeinterface hasPrevious : ()Z
    //   27: ifeq -> 50
    //   30: aload_2
    //   31: invokeinterface previous : ()Ljava/lang/Object;
    //   36: astore_1
    //   37: aload_1
    //   38: checkcast androidx/activity/OnBackPressedCallback
    //   41: invokevirtual isEnabled : ()Z
    //   44: ifeq -> 21
    //   47: goto -> 52
    //   50: aconst_null
    //   51: astore_1
    //   52: aload_1
    //   53: checkcast androidx/activity/OnBackPressedCallback
    //   56: astore_1
    //   57: aload_1
    //   58: ifnull -> 66
    //   61: aload_1
    //   62: invokevirtual handleOnBackPressed : ()V
    //   65: return
    //   66: aload_0
    //   67: getfield fallbackOnBackPressed : Ljava/lang/Runnable;
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 81
    //   75: aload_1
    //   76: invokeinterface run : ()V
    //   81: return
  }
  
  public final void setOnBackInvokedDispatcher(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    Intrinsics.checkNotNullParameter(paramOnBackInvokedDispatcher, "invoker");
    this.invokedDispatcher = paramOnBackInvokedDispatcher;
    updateBackInvokedCallbackState$activity_release();
  }
  
  public final void updateBackInvokedCallbackState$activity_release() {
    boolean bool = hasEnabledCallbacks();
    OnBackInvokedDispatcher onBackInvokedDispatcher = this.invokedDispatcher;
    OnBackInvokedCallback onBackInvokedCallback = this.onBackInvokedCallback;
    if (onBackInvokedDispatcher != null && onBackInvokedCallback != null) {
      if (bool && !this.backInvokedCallbackRegistered) {
        Api33Impl.INSTANCE.registerOnBackInvokedCallback(onBackInvokedDispatcher, 0, onBackInvokedCallback);
        this.backInvokedCallbackRegistered = true;
        return;
      } 
      if (!bool && this.backInvokedCallbackRegistered) {
        Api33Impl.INSTANCE.unregisterOnBackInvokedCallback(onBackInvokedDispatcher, onBackInvokedCallback);
        this.backInvokedCallbackRegistered = false;
      } 
    } 
  }
  
  @Metadata(d1 = {"\000&\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\020\002\n\002\b\003\n\002\020\b\n\002\b\003\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\026\020\003\032\0020\0042\f\020\005\032\b\022\004\022\0020\0070\006H\007J \020\b\032\0020\0072\006\020\t\032\0020\0012\006\020\n\032\0020\0132\006\020\f\032\0020\001H\007J\030\020\r\032\0020\0072\006\020\t\032\0020\0012\006\020\f\032\0020\001H\007¨\006\016"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher$Api33Impl;", "", "()V", "createOnBackInvokedCallback", "Landroid/window/OnBackInvokedCallback;", "onBackInvoked", "Lkotlin/Function0;", "", "registerOnBackInvokedCallback", "dispatcher", "priority", "", "callback", "unregisterOnBackInvokedCallback", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class Api33Impl {
    public static final Api33Impl INSTANCE = new Api33Impl();
    
    private static final void createOnBackInvokedCallback$lambda$0(Function0 param1Function0) {
      Intrinsics.checkNotNullParameter(param1Function0, "$onBackInvoked");
      param1Function0.invoke();
    }
    
    public final OnBackInvokedCallback createOnBackInvokedCallback(Function0<Unit> param1Function0) {
      Intrinsics.checkNotNullParameter(param1Function0, "onBackInvoked");
      return new OnBackPressedDispatcher$Api33Impl$$ExternalSyntheticLambda0(param1Function0);
    }
    
    public final void registerOnBackInvokedCallback(Object param1Object1, int param1Int, Object param1Object2) {
      Intrinsics.checkNotNullParameter(param1Object1, "dispatcher");
      Intrinsics.checkNotNullParameter(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(param1Int, (OnBackInvokedCallback)param1Object2);
    }
    
    public final void unregisterOnBackInvokedCallback(Object param1Object1, Object param1Object2) {
      Intrinsics.checkNotNullParameter(param1Object1, "dispatcher");
      Intrinsics.checkNotNullParameter(param1Object2, "callback");
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  @Metadata(d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\b\004\030\0002\0020\0012\0020\002B\025\022\006\020\003\032\0020\004\022\006\020\005\032\0020\006¢\006\002\020\007J\b\020\t\032\0020\nH\026J\030\020\013\032\0020\n2\006\020\f\032\0020\r2\006\020\016\032\0020\017H\026R\020\020\b\032\004\030\0010\002X\016¢\006\002\n\000R\016\020\003\032\0020\004X\004¢\006\002\n\000R\016\020\005\032\0020\006X\004¢\006\002\n\000¨\006\020"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;", "Landroidx/lifecycle/LifecycleEventObserver;", "Landroidx/activity/Cancellable;", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "onBackPressedCallback", "Landroidx/activity/OnBackPressedCallback;", "(Landroidx/activity/OnBackPressedDispatcher;Landroidx/lifecycle/Lifecycle;Landroidx/activity/OnBackPressedCallback;)V", "currentCancellable", "cancel", "", "onStateChanged", "source", "Landroidx/lifecycle/LifecycleOwner;", "event", "Landroidx/lifecycle/Lifecycle$Event;", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  private final class LifecycleOnBackPressedCancellable implements LifecycleEventObserver, Cancellable {
    private Cancellable currentCancellable;
    
    private final Lifecycle lifecycle;
    
    private final OnBackPressedCallback onBackPressedCallback;
    
    public LifecycleOnBackPressedCancellable(Lifecycle param1Lifecycle, OnBackPressedCallback param1OnBackPressedCallback) {
      this.lifecycle = param1Lifecycle;
      this.onBackPressedCallback = param1OnBackPressedCallback;
      param1Lifecycle.addObserver((LifecycleObserver)this);
    }
    
    public void cancel() {
      this.lifecycle.removeObserver((LifecycleObserver)this);
      this.onBackPressedCallback.removeCancellable(this);
      Cancellable cancellable = this.currentCancellable;
      if (cancellable != null)
        cancellable.cancel(); 
      this.currentCancellable = null;
    }
    
    public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
      Intrinsics.checkNotNullParameter(param1LifecycleOwner, "source");
      Intrinsics.checkNotNullParameter(param1Event, "event");
      if (param1Event == Lifecycle.Event.ON_START) {
        this.currentCancellable = OnBackPressedDispatcher.this.addCancellableCallback$activity_release(this.onBackPressedCallback);
        return;
      } 
      if (param1Event == Lifecycle.Event.ON_STOP) {
        Cancellable cancellable = this.currentCancellable;
        if (cancellable != null) {
          cancellable.cancel();
          return;
        } 
      } else if (param1Event == Lifecycle.Event.ON_DESTROY) {
        cancel();
      } 
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\002\n\000\b\004\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004J\b\020\005\032\0020\006H\026R\016\020\002\032\0020\003X\004¢\006\002\n\000¨\006\007"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher$OnBackPressedCancellable;", "Landroidx/activity/Cancellable;", "onBackPressedCallback", "Landroidx/activity/OnBackPressedCallback;", "(Landroidx/activity/OnBackPressedDispatcher;Landroidx/activity/OnBackPressedCallback;)V", "cancel", "", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  private final class OnBackPressedCancellable implements Cancellable {
    private final OnBackPressedCallback onBackPressedCallback;
    
    public OnBackPressedCancellable(OnBackPressedCallback param1OnBackPressedCallback) {
      this.onBackPressedCallback = param1OnBackPressedCallback;
    }
    
    public void cancel() {
      OnBackPressedDispatcher.this.onBackPressedCallbacks.remove(this.onBackPressedCallback);
      this.onBackPressedCallback.removeCancellable(this);
      if (Build.VERSION.SDK_INT >= 33) {
        this.onBackPressedCallback.setEnabledChangedCallback$activity_release(null);
        OnBackPressedDispatcher.this.updateBackInvokedCallbackState$activity_release();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */