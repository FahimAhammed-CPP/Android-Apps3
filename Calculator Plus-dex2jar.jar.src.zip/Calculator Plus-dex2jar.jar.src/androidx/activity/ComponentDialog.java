package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.ViewTreeLifecycleOwner;
import androidx.savedstate.SavedStateRegistry;
import androidx.savedstate.SavedStateRegistryController;
import androidx.savedstate.SavedStateRegistryOwner;
import androidx.savedstate.ViewTreeSavedStateRegistryOwner;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000d\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\006\b\026\030\0002\0020\0012\0020\0022\0020\0032\0020\004B\031\b\007\022\006\020\005\032\0020\006\022\b\b\003\020\007\032\0020\b¢\006\002\020\tJ\032\020\037\032\0020 2\006\020!\032\0020\"2\b\020#\032\004\030\0010$H\026J\b\020%\032\0020 H\002J\b\020&\032\0020 H\027J\022\020'\032\0020 2\b\020(\032\004\030\0010)H\025J\b\020*\032\0020)H\026J\b\020+\032\0020 H\025J\b\020,\032\0020 H\025J\020\020-\032\0020 2\006\020!\032\0020\"H\026J\032\020-\032\0020 2\006\020!\032\0020\"2\b\020#\032\004\030\0010$H\026J\020\020-\032\0020 2\006\020.\032\0020\bH\026R\020\020\n\032\004\030\0010\013X\016¢\006\002\n\000R\024\020\f\032\0020\r8VX\004¢\006\006\032\004\b\016\020\017R\024\020\020\032\0020\0138BX\004¢\006\006\032\004\b\021\020\022R\027\020\023\032\0020\024¢\006\016\n\000\022\004\b\025\020\026\032\004\b\027\020\030R\024\020\031\032\0020\0328VX\004¢\006\006\032\004\b\033\020\034R\016\020\035\032\0020\036X\004¢\006\002\n\000¨\006/"}, d2 = {"Landroidx/activity/ComponentDialog;", "Landroid/app/Dialog;", "Landroidx/lifecycle/LifecycleOwner;", "Landroidx/activity/OnBackPressedDispatcherOwner;", "Landroidx/savedstate/SavedStateRegistryOwner;", "context", "Landroid/content/Context;", "themeResId", "", "(Landroid/content/Context;I)V", "_lifecycleRegistry", "Landroidx/lifecycle/LifecycleRegistry;", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "getLifecycle", "()Landroidx/lifecycle/Lifecycle;", "lifecycleRegistry", "getLifecycleRegistry", "()Landroidx/lifecycle/LifecycleRegistry;", "onBackPressedDispatcher", "Landroidx/activity/OnBackPressedDispatcher;", "getOnBackPressedDispatcher$annotations", "()V", "getOnBackPressedDispatcher", "()Landroidx/activity/OnBackPressedDispatcher;", "savedStateRegistry", "Landroidx/savedstate/SavedStateRegistry;", "getSavedStateRegistry", "()Landroidx/savedstate/SavedStateRegistry;", "savedStateRegistryController", "Landroidx/savedstate/SavedStateRegistryController;", "addContentView", "", "view", "Landroid/view/View;", "params", "Landroid/view/ViewGroup$LayoutParams;", "initViewTreeOwners", "onBackPressed", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onSaveInstanceState", "onStart", "onStop", "setContentView", "layoutResID", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class ComponentDialog extends Dialog implements LifecycleOwner, OnBackPressedDispatcherOwner, SavedStateRegistryOwner {
  private LifecycleRegistry _lifecycleRegistry;
  
  private final OnBackPressedDispatcher onBackPressedDispatcher = new OnBackPressedDispatcher(new ComponentDialog$$ExternalSyntheticLambda0(this));
  
  private final SavedStateRegistryController savedStateRegistryController = SavedStateRegistryController.Companion.create(this);
  
  public ComponentDialog(Context paramContext) {
    this(paramContext, 0, 2, (DefaultConstructorMarker)null);
  }
  
  public ComponentDialog(Context paramContext, int paramInt) {
    super(paramContext, paramInt);
  }
  
  private final LifecycleRegistry getLifecycleRegistry() {
    LifecycleRegistry lifecycleRegistry2 = this._lifecycleRegistry;
    LifecycleRegistry lifecycleRegistry1 = lifecycleRegistry2;
    if (lifecycleRegistry2 == null) {
      lifecycleRegistry1 = new LifecycleRegistry(this);
      this._lifecycleRegistry = lifecycleRegistry1;
    } 
    return lifecycleRegistry1;
  }
  
  private final void initViewTreeOwners() {
    Window window3 = getWindow();
    Intrinsics.checkNotNull(window3);
    View view3 = window3.getDecorView();
    Intrinsics.checkNotNullExpressionValue(view3, "window!!.decorView");
    ViewTreeLifecycleOwner.set(view3, this);
    Window window2 = getWindow();
    Intrinsics.checkNotNull(window2);
    View view2 = window2.getDecorView();
    Intrinsics.checkNotNullExpressionValue(view2, "window!!.decorView");
    ViewTreeOnBackPressedDispatcherOwner.set(view2, this);
    Window window1 = getWindow();
    Intrinsics.checkNotNull(window1);
    View view1 = window1.getDecorView();
    Intrinsics.checkNotNullExpressionValue(view1, "window!!.decorView");
    ViewTreeSavedStateRegistryOwner.set(view1, this);
  }
  
  private static final void onBackPressedDispatcher$lambda$1(ComponentDialog paramComponentDialog) {
    Intrinsics.checkNotNullParameter(paramComponentDialog, "this$0");
    paramComponentDialog.onBackPressed();
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    Intrinsics.checkNotNullParameter(paramView, "view");
    initViewTreeOwners();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public Lifecycle getLifecycle() {
    return (Lifecycle)getLifecycleRegistry();
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.onBackPressedDispatcher;
  }
  
  public SavedStateRegistry getSavedStateRegistry() {
    return this.savedStateRegistryController.getSavedStateRegistry();
  }
  
  public void onBackPressed() {
    this.onBackPressedDispatcher.onBackPressed();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (Build.VERSION.SDK_INT >= 33) {
      OnBackPressedDispatcher onBackPressedDispatcher = this.onBackPressedDispatcher;
      OnBackInvokedDispatcher onBackInvokedDispatcher = getOnBackInvokedDispatcher();
      Intrinsics.checkNotNullExpressionValue(onBackInvokedDispatcher, "onBackInvokedDispatcher");
      onBackPressedDispatcher.setOnBackInvokedDispatcher(onBackInvokedDispatcher);
    } 
    this.savedStateRegistryController.performRestore(paramBundle);
    getLifecycleRegistry().handleLifecycleEvent(Lifecycle.Event.ON_CREATE);
  }
  
  public Bundle onSaveInstanceState() {
    Bundle bundle = super.onSaveInstanceState();
    Intrinsics.checkNotNullExpressionValue(bundle, "super.onSaveInstanceState()");
    this.savedStateRegistryController.performSave(bundle);
    return bundle;
  }
  
  protected void onStart() {
    super.onStart();
    getLifecycleRegistry().handleLifecycleEvent(Lifecycle.Event.ON_RESUME);
  }
  
  protected void onStop() {
    getLifecycleRegistry().handleLifecycleEvent(Lifecycle.Event.ON_DESTROY);
    this._lifecycleRegistry = null;
    super.onStop();
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "view");
    initViewTreeOwners();
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    Intrinsics.checkNotNullParameter(paramView, "view");
    initViewTreeOwners();
    super.setContentView(paramView, paramLayoutParams);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\ComponentDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */