package androidx.activity.contextaware;

import android.content.Context;
import kotlin.Metadata;

@Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\000\n\002\020\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\bf\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H&J\n\020\006\032\004\030\0010\007H&J\020\020\b\032\0020\0032\006\020\004\032\0020\005H&ø\001\000\002\006\n\004\b!0\001¨\006\tÀ\006\001"}, d2 = {"Landroidx/activity/contextaware/ContextAware;", "", "addOnContextAvailableListener", "", "listener", "Landroidx/activity/contextaware/OnContextAvailableListener;", "peekAvailableContext", "Landroid/content/Context;", "removeOnContextAvailableListener", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface ContextAware {
  void addOnContextAvailableListener(OnContextAvailableListener paramOnContextAvailableListener);
  
  Context peekAvailableContext();
  
  void removeOnContextAvailableListener(OnContextAvailableListener paramOnContextAvailableListener);
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\contextaware\ContextAware.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */