package androidx.activity.contextaware;

import android.content.Context;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlinx.coroutines.CancellableContinuation;
import kotlinx.coroutines.CancellableContinuationImpl;

@Metadata(d1 = {"\000\032\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\002\032@\020\000\032\007H\001¢\006\002\b\002\"\004\b\000\020\001*\0020\0032\036\b\004\020\004\032\030\022\t\022\0070\006¢\006\002\b\002\022\t\022\007H\001¢\006\002\b\0020\005HHø\001\000¢\006\002\020\007\002\004\n\002\b\031¨\006\b"}, d2 = {"withContextAvailable", "R", "Lkotlin/jvm/JvmSuppressWildcards;", "Landroidx/activity/contextaware/ContextAware;", "onContextAvailable", "Lkotlin/Function1;", "Landroid/content/Context;", "(Landroidx/activity/contextaware/ContextAware;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "activity_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class ContextAwareKt {
  public static final <R> Object withContextAvailable(ContextAware paramContextAware, Function1<Context, R> paramFunction1, Continuation<R> paramContinuation) {
    Context context = paramContextAware.peekAvailableContext();
    if (context != null)
      return paramFunction1.invoke(context); 
    CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted(paramContinuation), 1);
    cancellableContinuationImpl.initCancellability();
    CancellableContinuation<R> cancellableContinuation = (CancellableContinuation)cancellableContinuationImpl;
    ContextAwareKt$withContextAvailable$2$listener$1 contextAwareKt$withContextAvailable$2$listener$1 = new ContextAwareKt$withContextAvailable$2$listener$1(cancellableContinuation, paramFunction1);
    paramContextAware.addOnContextAvailableListener(contextAwareKt$withContextAvailable$2$listener$1);
    cancellableContinuation.invokeOnCancellation(new ContextAwareKt$withContextAvailable$2$1(paramContextAware, contextAwareKt$withContextAvailable$2$listener$1));
    Object object = cancellableContinuationImpl.getResult();
    if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED())
      DebugProbesKt.probeCoroutineSuspended(paramContinuation); 
    return object;
  }
  
  private static final <R> Object withContextAvailable$$forInline(ContextAware paramContextAware, Function1<Context, R> paramFunction1, Continuation<R> paramContinuation) {
    Context context = paramContextAware.peekAvailableContext();
    if (context != null)
      return paramFunction1.invoke(context); 
    InlineMarker.mark(0);
    CancellableContinuationImpl cancellableContinuationImpl = new CancellableContinuationImpl(IntrinsicsKt.intercepted(paramContinuation), 1);
    cancellableContinuationImpl.initCancellability();
    CancellableContinuation<R> cancellableContinuation = (CancellableContinuation)cancellableContinuationImpl;
    ContextAwareKt$withContextAvailable$2$listener$1 contextAwareKt$withContextAvailable$2$listener$1 = new ContextAwareKt$withContextAvailable$2$listener$1(cancellableContinuation, paramFunction1);
    paramContextAware.addOnContextAvailableListener(contextAwareKt$withContextAvailable$2$listener$1);
    cancellableContinuation.invokeOnCancellation(new ContextAwareKt$withContextAvailable$2$1(paramContextAware, contextAwareKt$withContextAvailable$2$listener$1));
    Unit unit = Unit.INSTANCE;
    Object object = cancellableContinuationImpl.getResult();
    if (object == IntrinsicsKt.getCOROUTINE_SUSPENDED())
      DebugProbesKt.probeCoroutineSuspended(paramContinuation); 
    InlineMarker.mark(1);
    return object;
  }
  
  @Metadata(d1 = {"\000\020\n\000\n\002\020\002\n\002\b\002\n\002\020\003\n\000\020\000\032\0020\001\"\004\b\000\020\0022\b\020\003\032\004\030\0010\004H\n¢\006\002\b\005"}, d2 = {"<anonymous>", "", "R", "it", "", "invoke"}, k = 3, mv = {1, 8, 0}, xi = 176)
  public static final class ContextAwareKt$withContextAvailable$2$1 extends Lambda implements Function1<Throwable, Unit> {
    public ContextAwareKt$withContextAvailable$2$1(ContextAware param1ContextAware, ContextAwareKt$withContextAvailable$2$listener$1 param1ContextAwareKt$withContextAvailable$2$listener$1) {
      super(1);
    }
    
    public final void invoke(Throwable param1Throwable) {
      this.$this_withContextAvailable.removeOnContextAvailableListener(this.$listener);
    }
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\000\n\002\020\002\n\000\n\002\030\002\n\000*\001\000\b\n\030\0002\0020\001J\020\020\002\032\0020\0032\006\020\004\032\0020\005H\026¨\006\006"}, d2 = {"androidx/activity/contextaware/ContextAwareKt$withContextAvailable$2$listener$1", "Landroidx/activity/contextaware/OnContextAvailableListener;", "onContextAvailable", "", "context", "Landroid/content/Context;", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 176)
  public static final class ContextAwareKt$withContextAvailable$2$listener$1 implements OnContextAvailableListener {
    public ContextAwareKt$withContextAvailable$2$listener$1(CancellableContinuation<R> param1CancellableContinuation, Function1<Context, R> param1Function1) {}
    
    public void onContextAvailable(Context param1Context) {
      Object object;
      Intrinsics.checkNotNullParameter(param1Context, "context");
      CancellableContinuation<R> cancellableContinuation = this.$co;
      Function1<Context, R> function1 = this.$onContextAvailable;
      try {
        Result.Companion companion = Result.Companion;
        ContextAwareKt$withContextAvailable$2$listener$1 contextAwareKt$withContextAvailable$2$listener$1 = this;
        object = Result.constructor-impl(function1.invoke(param1Context));
      } finally {
        param1Context = null;
        Result.Companion companion = Result.Companion;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\contextaware\ContextAwareKt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */