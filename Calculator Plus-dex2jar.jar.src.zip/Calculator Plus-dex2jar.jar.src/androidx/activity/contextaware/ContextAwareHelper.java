package androidx.activity.contextaware;

import android.content.Context;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020#\n\002\030\002\n\000\n\002\020\002\n\002\b\006\030\0002\0020\001B\005¢\006\002\020\002J\016\020\b\032\0020\t2\006\020\n\032\0020\007J\006\020\013\032\0020\tJ\016\020\f\032\0020\t2\006\020\003\032\0020\004J\b\020\r\032\004\030\0010\004J\016\020\016\032\0020\t2\006\020\n\032\0020\007R\020\020\003\032\004\030\0010\004X\016¢\006\002\n\000R\024\020\005\032\b\022\004\022\0020\0070\006X\004¢\006\002\n\000¨\006\017"}, d2 = {"Landroidx/activity/contextaware/ContextAwareHelper;", "", "()V", "context", "Landroid/content/Context;", "listeners", "", "Landroidx/activity/contextaware/OnContextAvailableListener;", "addOnContextAvailableListener", "", "listener", "clearAvailableContext", "dispatchOnContextAvailable", "peekAvailableContext", "removeOnContextAvailableListener", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ContextAwareHelper {
  private volatile Context context;
  
  private final Set<OnContextAvailableListener> listeners = new CopyOnWriteArraySet<OnContextAvailableListener>();
  
  public final void addOnContextAvailableListener(OnContextAvailableListener paramOnContextAvailableListener) {
    Intrinsics.checkNotNullParameter(paramOnContextAvailableListener, "listener");
    Context context = this.context;
    if (context != null)
      paramOnContextAvailableListener.onContextAvailable(context); 
    this.listeners.add(paramOnContextAvailableListener);
  }
  
  public final void clearAvailableContext() {
    this.context = null;
  }
  
  public final void dispatchOnContextAvailable(Context paramContext) {
    Intrinsics.checkNotNullParameter(paramContext, "context");
    this.context = paramContext;
    Iterator<OnContextAvailableListener> iterator = this.listeners.iterator();
    while (iterator.hasNext())
      ((OnContextAvailableListener)iterator.next()).onContextAvailable(paramContext); 
  }
  
  public final Context peekAvailableContext() {
    return this.context;
  }
  
  public final void removeOnContextAvailableListener(OnContextAvailableListener paramOnContextAvailableListener) {
    Intrinsics.checkNotNullParameter(paramOnContextAvailableListener, "listener");
    this.listeners.remove(paramOnContextAvailableListener);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\contextaware\ContextAwareHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */