package androidx.activity;

import android.view.View;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\000\bÁ\002\030\0002\0020\001B\007\b\002¢\006\002\020\002J\016\020\003\032\0020\0042\006\020\005\032\0020\006¨\006\007"}, d2 = {"Landroidx/activity/Api19Impl;", "", "()V", "isAttachedToWindow", "", "view", "Landroid/view/View;", "activity-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class Api19Impl {
  public static final Api19Impl INSTANCE = new Api19Impl();
  
  public final boolean isAttachedToWindow(View paramView) {
    Intrinsics.checkNotNullParameter(paramView, "view");
    return paramView.isAttachedToWindow();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Calculator Plus-dex2jar.jar!\androidx\activity\Api19Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */