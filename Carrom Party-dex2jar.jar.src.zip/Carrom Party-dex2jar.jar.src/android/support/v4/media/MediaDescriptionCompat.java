package android.support.v4.media;

import a.a.b.a.d;
import a.a.b.a.e;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

public final class MediaDescriptionCompat implements Parcelable {
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  public final String a;
  
  public final CharSequence b;
  
  public final CharSequence c;
  
  public final CharSequence d;
  
  public final Bitmap e;
  
  public final Uri f;
  
  public final Bundle g;
  
  public final Uri h;
  
  public Object i;
  
  public MediaDescriptionCompat(Parcel paramParcel) {
    this.a = paramParcel.readString();
    this.b = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.c = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.d = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    ClassLoader classLoader = MediaDescriptionCompat.class.getClassLoader();
    this.e = (Bitmap)paramParcel.readParcelable(classLoader);
    this.f = (Uri)paramParcel.readParcelable(classLoader);
    this.g = paramParcel.readBundle(classLoader);
    this.h = (Uri)paramParcel.readParcelable(classLoader);
  }
  
  public MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.a = paramString;
    this.b = paramCharSequence1;
    this.c = paramCharSequence2;
    this.d = paramCharSequence3;
    this.e = paramBitmap;
    this.f = paramUri1;
    this.g = paramBundle;
    this.h = paramUri2;
  }
  
  public static MediaDescriptionCompat c(Object paramObject) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #4
    //   3: aconst_null
    //   4: astore_3
    //   5: aload #4
    //   7: astore_2
    //   8: aload_0
    //   9: ifnull -> 217
    //   12: getstatic android/os/Build$VERSION.SDK_INT : I
    //   15: istore_1
    //   16: aload #4
    //   18: astore_2
    //   19: iload_1
    //   20: bipush #21
    //   22: if_icmplt -> 217
    //   25: new android/support/v4/media/MediaDescriptionCompat$b
    //   28: dup
    //   29: invokespecial <init> : ()V
    //   32: astore #5
    //   34: aload #5
    //   36: aload_0
    //   37: invokestatic f : (Ljava/lang/Object;)Ljava/lang/String;
    //   40: invokevirtual f : (Ljava/lang/String;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   43: pop
    //   44: aload #5
    //   46: aload_0
    //   47: invokestatic h : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   50: invokevirtual i : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   53: pop
    //   54: aload #5
    //   56: aload_0
    //   57: invokestatic g : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   60: invokevirtual h : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   63: pop
    //   64: aload #5
    //   66: aload_0
    //   67: invokestatic b : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   70: invokevirtual b : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   73: pop
    //   74: aload #5
    //   76: aload_0
    //   77: invokestatic d : (Ljava/lang/Object;)Landroid/graphics/Bitmap;
    //   80: invokevirtual d : (Landroid/graphics/Bitmap;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   83: pop
    //   84: aload #5
    //   86: aload_0
    //   87: invokestatic e : (Ljava/lang/Object;)Landroid/net/Uri;
    //   90: invokevirtual e : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   93: pop
    //   94: aload_0
    //   95: invokestatic c : (Ljava/lang/Object;)Landroid/os/Bundle;
    //   98: astore #4
    //   100: aload #4
    //   102: ifnull -> 124
    //   105: aload #4
    //   107: invokestatic a : (Landroid/os/Bundle;)V
    //   110: aload #4
    //   112: ldc 'android.support.v4.media.description.MEDIA_URI'
    //   114: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   117: checkcast android/net/Uri
    //   120: astore_2
    //   121: goto -> 126
    //   124: aconst_null
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 166
    //   130: aload #4
    //   132: ldc 'android.support.v4.media.description.NULL_BUNDLE_FLAG'
    //   134: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   137: ifeq -> 152
    //   140: aload #4
    //   142: invokevirtual size : ()I
    //   145: iconst_2
    //   146: if_icmpne -> 152
    //   149: goto -> 169
    //   152: aload #4
    //   154: ldc 'android.support.v4.media.description.MEDIA_URI'
    //   156: invokevirtual remove : (Ljava/lang/String;)V
    //   159: aload #4
    //   161: ldc 'android.support.v4.media.description.NULL_BUNDLE_FLAG'
    //   163: invokevirtual remove : (Ljava/lang/String;)V
    //   166: aload #4
    //   168: astore_3
    //   169: aload #5
    //   171: aload_3
    //   172: invokevirtual c : (Landroid/os/Bundle;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   175: pop
    //   176: aload_2
    //   177: ifnull -> 190
    //   180: aload #5
    //   182: aload_2
    //   183: invokevirtual g : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   186: pop
    //   187: goto -> 206
    //   190: iload_1
    //   191: bipush #23
    //   193: if_icmplt -> 206
    //   196: aload #5
    //   198: aload_0
    //   199: invokestatic a : (Ljava/lang/Object;)Landroid/net/Uri;
    //   202: invokevirtual g : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   205: pop
    //   206: aload #5
    //   208: invokevirtual a : ()Landroid/support/v4/media/MediaDescriptionCompat;
    //   211: astore_2
    //   212: aload_2
    //   213: aload_0
    //   214: putfield i : Ljava/lang/Object;
    //   217: aload_2
    //   218: areturn
  }
  
  public Object d() {
    Object object2 = this.i;
    Object object1 = object2;
    if (object2 == null) {
      int i = Build.VERSION.SDK_INT;
      if (i < 21)
        return object2; 
      Object object = d.a.b();
      d.a.g(object, this.a);
      d.a.i(object, this.b);
      d.a.h(object, this.c);
      d.a.c(object, this.d);
      d.a.e(object, this.e);
      d.a.f(object, this.f);
      object2 = this.g;
      object1 = object2;
      if (i < 23) {
        object1 = object2;
        if (this.h != null) {
          object1 = object2;
          if (object2 == null) {
            object1 = new Bundle();
            object1.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
          } 
          object1.putParcelable("android.support.v4.media.description.MEDIA_URI", (Parcelable)this.h);
        } 
      } 
      d.a.d(object, (Bundle)object1);
      if (i >= 23)
        e.a.a(object, this.h); 
      object1 = d.a.a(object);
      this.i = object1;
    } 
    return object1;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.b);
    stringBuilder.append(", ");
    stringBuilder.append(this.c);
    stringBuilder.append(", ");
    stringBuilder.append(this.d);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    if (Build.VERSION.SDK_INT < 21) {
      paramParcel.writeString(this.a);
      TextUtils.writeToParcel(this.b, paramParcel, paramInt);
      TextUtils.writeToParcel(this.c, paramParcel, paramInt);
      TextUtils.writeToParcel(this.d, paramParcel, paramInt);
      paramParcel.writeParcelable((Parcelable)this.e, paramInt);
      paramParcel.writeParcelable((Parcelable)this.f, paramInt);
      paramParcel.writeBundle(this.g);
      paramParcel.writeParcelable((Parcelable)this.h, paramInt);
      return;
    } 
    d.i(d(), paramParcel, paramInt);
  }
  
  public static final class a implements Parcelable.Creator<MediaDescriptionCompat> {
    public MediaDescriptionCompat a(Parcel param1Parcel) {
      return (Build.VERSION.SDK_INT < 21) ? new MediaDescriptionCompat(param1Parcel) : MediaDescriptionCompat.c(d.a(param1Parcel));
    }
    
    public MediaDescriptionCompat[] b(int param1Int) {
      return new MediaDescriptionCompat[param1Int];
    }
  }
  
  public static final class b {
    public String a;
    
    public CharSequence b;
    
    public CharSequence c;
    
    public CharSequence d;
    
    public Bitmap e;
    
    public Uri f;
    
    public Bundle g;
    
    public Uri h;
    
    public MediaDescriptionCompat a() {
      return new MediaDescriptionCompat(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }
    
    public b b(CharSequence param1CharSequence) {
      this.d = param1CharSequence;
      return this;
    }
    
    public b c(Bundle param1Bundle) {
      this.g = param1Bundle;
      return this;
    }
    
    public b d(Bitmap param1Bitmap) {
      this.e = param1Bitmap;
      return this;
    }
    
    public b e(Uri param1Uri) {
      this.f = param1Uri;
      return this;
    }
    
    public b f(String param1String) {
      this.a = param1String;
      return this;
    }
    
    public b g(Uri param1Uri) {
      this.h = param1Uri;
      return this;
    }
    
    public b h(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
      return this;
    }
    
    public b i(CharSequence param1CharSequence) {
      this.b = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */