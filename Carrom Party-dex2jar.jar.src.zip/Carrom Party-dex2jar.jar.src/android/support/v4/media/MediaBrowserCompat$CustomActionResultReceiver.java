package android.support.v4.media;

import a.a.b.a.a;
import android.os.Bundle;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.os.ResultReceiver;
import android.util.Log;

public class MediaBrowserCompat$CustomActionResultReceiver extends ResultReceiver {
  public final String c;
  
  public final Bundle d;
  
  public final a e;
  
  public void c(int paramInt, Bundle paramBundle) {
    if (this.e == null)
      return; 
    MediaSessionCompat.a(paramBundle);
    if (paramInt != -1) {
      if (paramInt != 0) {
        if (paramInt != 1) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown result code: ");
          stringBuilder.append(paramInt);
          stringBuilder.append(" (extras=");
          stringBuilder.append(this.d);
          stringBuilder.append(", resultData=");
          stringBuilder.append(paramBundle);
          stringBuilder.append(")");
          Log.w("MediaBrowserCompat", stringBuilder.toString());
          return;
        } 
        this.e.b(this.c, this.d, paramBundle);
        return;
      } 
      this.e.c(this.c, this.d, paramBundle);
      return;
    } 
    this.e.a(this.c, this.d, paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\android\support\v4\media\MediaBrowserCompat$CustomActionResultReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */