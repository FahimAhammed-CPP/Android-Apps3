package android.support.v4.media.session;

import a.a.b.a.g.b;
import a.a.b.a.g.c;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaMetadataCompat;
import android.util.Log;
import b.h.e.e;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class MediaControllerCompat$MediaControllerImplApi21 {
  public final Object a;
  
  public final List<c> b;
  
  public HashMap<c, a> c;
  
  public final MediaSessionCompat.Token d;
  
  public void a() {
    if (this.d.c() == null)
      return; 
    Iterator<c> iterator = this.b.iterator();
    while (iterator.hasNext()) {
      c c = iterator.next();
      a a = new a(c);
      this.c.put(c, a);
      c.c = (a.a.b.a.g.a)a;
      try {
        this.d.c().G0((a.a.b.a.g.a)a);
        c.i(13, null, null);
      } catch (RemoteException remoteException) {
        Log.e("MediaControllerCompat", "Dead object in registerCallback.", (Throwable)remoteException);
        break;
      } 
    } 
    this.b.clear();
  }
  
  public static class ExtraBinderRequestResultReceiver extends ResultReceiver {
    public WeakReference<MediaControllerCompat$MediaControllerImplApi21> a;
    
    public void onReceiveResult(int param1Int, Bundle param1Bundle) {
      MediaControllerCompat$MediaControllerImplApi21 mediaControllerCompat$MediaControllerImplApi21 = this.a.get();
      if (mediaControllerCompat$MediaControllerImplApi21 != null) {
        if (param1Bundle == null)
          return; 
        synchronized (mediaControllerCompat$MediaControllerImplApi21.a) {
          mediaControllerCompat$MediaControllerImplApi21.d.d(b.a.a0(e.a(param1Bundle, "android.support.v4.media.session.EXTRA_BINDER")));
          mediaControllerCompat$MediaControllerImplApi21.d.f(param1Bundle.getBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE"));
          mediaControllerCompat$MediaControllerImplApi21.a();
          return;
        } 
      } 
    }
  }
  
  public static class a extends c.c {
    public a(c param1c) {
      super(param1c);
    }
    
    public void E(Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void G(List<MediaSessionCompat.QueueItem> param1List) {
      throw new AssertionError();
    }
    
    public void M6(ParcelableVolumeInfo param1ParcelableVolumeInfo) {
      throw new AssertionError();
    }
    
    public void U(CharSequence param1CharSequence) {
      throw new AssertionError();
    }
    
    public void V() {
      throw new AssertionError();
    }
    
    public void j4(MediaMetadataCompat param1MediaMetadataCompat) {
      throw new AssertionError();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\android\support\v4\media\session\MediaControllerCompat$MediaControllerImplApi21.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */