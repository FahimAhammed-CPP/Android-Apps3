package b.e.f;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import b.e.b;
import b.e.c;

public class g extends Drawable {
  public static final double q = Math.cos(Math.toRadians(45.0D));
  
  public static a r;
  
  public final int a;
  
  public Paint b;
  
  public Paint c;
  
  public Paint d;
  
  public final RectF e;
  
  public float f;
  
  public Path g;
  
  public float h;
  
  public float i;
  
  public float j;
  
  public ColorStateList k;
  
  public boolean l = true;
  
  public final int m;
  
  public final int n;
  
  public boolean o = true;
  
  public boolean p = false;
  
  public g(Resources paramResources, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3) {
    this.m = paramResources.getColor(b.d);
    this.n = paramResources.getColor(b.c);
    this.a = paramResources.getDimensionPixelSize(c.a);
    this.b = new Paint(5);
    n(paramColorStateList);
    Paint paint = new Paint(5);
    this.c = paint;
    paint.setStyle(Paint.Style.FILL);
    this.f = (int)(paramFloat1 + 0.5F);
    this.e = new RectF();
    paint = new Paint(this.c);
    this.d = paint;
    paint.setAntiAlias(false);
    s(paramFloat2, paramFloat3);
  }
  
  public static float c(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    float f = paramFloat1;
    if (paramBoolean) {
      double d1 = paramFloat1;
      double d2 = q;
      double d3 = paramFloat2;
      Double.isNaN(d3);
      Double.isNaN(d1);
      f = (float)(d1 + (1.0D - d2) * d3);
    } 
    return f;
  }
  
  public static float d(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (paramBoolean) {
      double d1 = (paramFloat1 * 1.5F);
      double d2 = q;
      double d3 = paramFloat2;
      Double.isNaN(d3);
      Double.isNaN(d1);
      return (float)(d1 + (1.0D - d2) * d3);
    } 
    return paramFloat1 * 1.5F;
  }
  
  public final void a(Rect paramRect) {
    float f1 = this.h;
    float f2 = 1.5F * f1;
    this.e.set(paramRect.left + f1, paramRect.top + f2, paramRect.right - f1, paramRect.bottom - f2);
    b();
  }
  
  public final void b() {
    float f1 = this.f;
    RectF rectF1 = new RectF(-f1, -f1, f1, f1);
    RectF rectF2 = new RectF(rectF1);
    f1 = this.i;
    rectF2.inset(-f1, -f1);
    Path path = this.g;
    if (path == null) {
      this.g = new Path();
    } else {
      path.reset();
    } 
    this.g.setFillType(Path.FillType.EVEN_ODD);
    this.g.moveTo(-this.f, 0.0F);
    this.g.rLineTo(-this.i, 0.0F);
    this.g.arcTo(rectF2, 180.0F, 90.0F, false);
    this.g.arcTo(rectF1, 270.0F, -90.0F, false);
    this.g.close();
    f1 = this.f;
    f1 /= this.i + f1;
    Paint paint = this.c;
    float f2 = this.f;
    float f3 = this.i;
    int i = this.m;
    int j = this.n;
    Shader.TileMode tileMode = Shader.TileMode.CLAMP;
    paint.setShader((Shader)new RadialGradient(0.0F, 0.0F, f2 + f3, new int[] { i, i, j }, new float[] { 0.0F, f1, 1.0F }, tileMode));
    paint = this.d;
    f3 = this.f;
    f1 = -f3;
    f2 = this.i;
    f3 = -f3;
    i = this.m;
    j = this.n;
    tileMode = Shader.TileMode.CLAMP;
    paint.setShader((Shader)new LinearGradient(0.0F, f1 + f2, 0.0F, f3 - f2, new int[] { i, i, j }, new float[] { 0.0F, 0.5F, 1.0F }, tileMode));
    this.d.setAntiAlias(false);
  }
  
  public void draw(Canvas paramCanvas) {
    if (this.l) {
      a(getBounds());
      this.l = false;
    } 
    paramCanvas.translate(0.0F, this.j / 2.0F);
    e(paramCanvas);
    paramCanvas.translate(0.0F, -this.j / 2.0F);
    r.a(paramCanvas, this.e, this.f, this.b);
  }
  
  public final void e(Canvas paramCanvas) {
    boolean bool;
    float f2 = this.f;
    float f1 = -f2 - this.i;
    f2 = f2 + this.a + this.j / 2.0F;
    float f3 = this.e.width();
    float f4 = f2 * 2.0F;
    if (f3 - f4 > 0.0F) {
      i = 1;
    } else {
      i = 0;
    } 
    if (this.e.height() - f4 > 0.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    int j = paramCanvas.save();
    RectF rectF = this.e;
    paramCanvas.translate(rectF.left + f2, rectF.top + f2);
    paramCanvas.drawPath(this.g, this.c);
    if (i)
      paramCanvas.drawRect(0.0F, f1, this.e.width() - f4, -this.f, this.d); 
    paramCanvas.restoreToCount(j);
    j = paramCanvas.save();
    rectF = this.e;
    paramCanvas.translate(rectF.right - f2, rectF.bottom - f2);
    paramCanvas.rotate(180.0F);
    paramCanvas.drawPath(this.g, this.c);
    if (i)
      paramCanvas.drawRect(0.0F, f1, this.e.width() - f4, -this.f + this.i, this.d); 
    paramCanvas.restoreToCount(j);
    int i = paramCanvas.save();
    rectF = this.e;
    paramCanvas.translate(rectF.left + f2, rectF.bottom - f2);
    paramCanvas.rotate(270.0F);
    paramCanvas.drawPath(this.g, this.c);
    if (bool)
      paramCanvas.drawRect(0.0F, f1, this.e.height() - f4, -this.f, this.d); 
    paramCanvas.restoreToCount(i);
    i = paramCanvas.save();
    rectF = this.e;
    paramCanvas.translate(rectF.right - f2, rectF.top + f2);
    paramCanvas.rotate(90.0F);
    paramCanvas.drawPath(this.g, this.c);
    if (bool)
      paramCanvas.drawRect(0.0F, f1, this.e.height() - f4, -this.f, this.d); 
    paramCanvas.restoreToCount(i);
  }
  
  public ColorStateList f() {
    return this.k;
  }
  
  public float g() {
    return this.f;
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public boolean getPadding(Rect paramRect) {
    int i = (int)Math.ceil(d(this.h, this.f, this.o));
    int j = (int)Math.ceil(c(this.h, this.f, this.o));
    paramRect.set(j, i, j, i);
    return true;
  }
  
  public void h(Rect paramRect) {
    getPadding(paramRect);
  }
  
  public float i() {
    return this.h;
  }
  
  public boolean isStateful() {
    ColorStateList colorStateList = this.k;
    return ((colorStateList != null && colorStateList.isStateful()) || super.isStateful());
  }
  
  public float j() {
    float f = this.h;
    return Math.max(f, this.f + this.a + f * 1.5F / 2.0F) * 2.0F + (this.h * 1.5F + this.a) * 2.0F;
  }
  
  public float k() {
    float f = this.h;
    return Math.max(f, this.f + this.a + f / 2.0F) * 2.0F + (this.h + this.a) * 2.0F;
  }
  
  public float l() {
    return this.j;
  }
  
  public void m(boolean paramBoolean) {
    this.o = paramBoolean;
    invalidateSelf();
  }
  
  public final void n(ColorStateList paramColorStateList) {
    ColorStateList colorStateList = paramColorStateList;
    if (paramColorStateList == null)
      colorStateList = ColorStateList.valueOf(0); 
    this.k = colorStateList;
    this.b.setColor(colorStateList.getColorForState(getState(), this.k.getDefaultColor()));
  }
  
  public void o(ColorStateList paramColorStateList) {
    n(paramColorStateList);
    invalidateSelf();
  }
  
  public void onBoundsChange(Rect paramRect) {
    super.onBoundsChange(paramRect);
    this.l = true;
  }
  
  public boolean onStateChange(int[] paramArrayOfint) {
    ColorStateList colorStateList = this.k;
    int i = colorStateList.getColorForState(paramArrayOfint, colorStateList.getDefaultColor());
    if (this.b.getColor() == i)
      return false; 
    this.b.setColor(i);
    this.l = true;
    invalidateSelf();
    return true;
  }
  
  public void p(float paramFloat) {
    if (paramFloat >= 0.0F) {
      paramFloat = (int)(paramFloat + 0.5F);
      if (this.f == paramFloat)
        return; 
      this.f = paramFloat;
      this.l = true;
      invalidateSelf();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid radius ");
    stringBuilder.append(paramFloat);
    stringBuilder.append(". Must be >= 0");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void q(float paramFloat) {
    s(this.j, paramFloat);
  }
  
  public void r(float paramFloat) {
    s(paramFloat, this.h);
  }
  
  public final void s(float paramFloat1, float paramFloat2) {
    if (paramFloat1 >= 0.0F) {
      if (paramFloat2 >= 0.0F) {
        float f = t(paramFloat1);
        paramFloat2 = t(paramFloat2);
        paramFloat1 = f;
        if (f > paramFloat2) {
          if (!this.p)
            this.p = true; 
          paramFloat1 = paramFloat2;
        } 
        if (this.j == paramFloat1 && this.h == paramFloat2)
          return; 
        this.j = paramFloat1;
        this.h = paramFloat2;
        this.i = (int)(paramFloat1 * 1.5F + this.a + 0.5F);
        this.l = true;
        invalidateSelf();
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid max shadow size ");
      stringBuilder1.append(paramFloat2);
      stringBuilder1.append(". Must be >= 0");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid shadow size ");
    stringBuilder.append(paramFloat1);
    stringBuilder.append(". Must be >= 0");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setAlpha(int paramInt) {
    this.b.setAlpha(paramInt);
    this.c.setAlpha(paramInt);
    this.d.setAlpha(paramInt);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.b.setColorFilter(paramColorFilter);
  }
  
  public final int t(float paramFloat) {
    int j = (int)(paramFloat + 0.5F);
    int i = j;
    if (j % 2 == 1)
      i = j - 1; 
    return i;
  }
  
  public static interface a {
    void a(Canvas param1Canvas, RectF param1RectF, float param1Float, Paint param1Paint);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\e\f\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */