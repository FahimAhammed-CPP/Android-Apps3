package b.e.f;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;

public class b implements e {
  public void a(d paramd, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3) {
    paramd.b(new f(paramColorStateList, paramFloat1));
    View view = paramd.f();
    view.setClipToOutline(true);
    view.setElevation(paramFloat2);
    n(paramd, paramFloat3);
  }
  
  public void b(d paramd, float paramFloat) {
    o(paramd).h(paramFloat);
  }
  
  public float c(d paramd) {
    return paramd.f().getElevation();
  }
  
  public float d(d paramd) {
    return o(paramd).d();
  }
  
  public void e(d paramd) {
    n(paramd, g(paramd));
  }
  
  public void f(d paramd, float paramFloat) {
    paramd.f().setElevation(paramFloat);
  }
  
  public float g(d paramd) {
    return o(paramd).c();
  }
  
  public ColorStateList h(d paramd) {
    return o(paramd).b();
  }
  
  public void i() {}
  
  public float j(d paramd) {
    return d(paramd) * 2.0F;
  }
  
  public float k(d paramd) {
    return d(paramd) * 2.0F;
  }
  
  public void l(d paramd) {
    n(paramd, g(paramd));
  }
  
  public void m(d paramd, ColorStateList paramColorStateList) {
    o(paramd).f(paramColorStateList);
  }
  
  public void n(d paramd, float paramFloat) {
    o(paramd).g(paramFloat, paramd.d(), paramd.c());
    p(paramd);
  }
  
  public final f o(d paramd) {
    return (f)paramd.e();
  }
  
  public void p(d paramd) {
    if (!paramd.d()) {
      paramd.g(0, 0, 0, 0);
      return;
    } 
    float f1 = g(paramd);
    float f2 = d(paramd);
    int i = (int)Math.ceil(g.c(f1, f2, paramd.c()));
    int j = (int)Math.ceil(g.d(f1, f2, paramd.c()));
    paramd.g(i, j, i, j);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\e\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */