package b.e.f;

import android.graphics.drawable.Drawable;
import android.view.View;

public interface d {
  void a(int paramInt1, int paramInt2);
  
  void b(Drawable paramDrawable);
  
  boolean c();
  
  boolean d();
  
  Drawable e();
  
  View f();
  
  void g(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\e\f\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */