package b.e.f;

import android.content.Context;
import android.content.res.ColorStateList;

public interface e {
  void a(d paramd, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3);
  
  void b(d paramd, float paramFloat);
  
  float c(d paramd);
  
  float d(d paramd);
  
  void e(d paramd);
  
  void f(d paramd, float paramFloat);
  
  float g(d paramd);
  
  ColorStateList h(d paramd);
  
  void i();
  
  float j(d paramd);
  
  float k(d paramd);
  
  void l(d paramd);
  
  void m(d paramd, ColorStateList paramColorStateList);
  
  void n(d paramd, float paramFloat);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\e\f\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */