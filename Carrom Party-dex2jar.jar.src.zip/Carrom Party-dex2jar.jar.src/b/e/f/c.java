package b.e.f;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

public class c implements e {
  public final RectF a = new RectF();
  
  public void a(d paramd, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3) {
    g g = o(paramContext, paramColorStateList, paramFloat1, paramFloat2, paramFloat3);
    g.m(paramd.c());
    paramd.b(g);
    q(paramd);
  }
  
  public void b(d paramd, float paramFloat) {
    p(paramd).p(paramFloat);
    q(paramd);
  }
  
  public float c(d paramd) {
    return p(paramd).l();
  }
  
  public float d(d paramd) {
    return p(paramd).g();
  }
  
  public void e(d paramd) {}
  
  public void f(d paramd, float paramFloat) {
    p(paramd).r(paramFloat);
  }
  
  public float g(d paramd) {
    return p(paramd).i();
  }
  
  public ColorStateList h(d paramd) {
    return p(paramd).f();
  }
  
  public void i() {
    g.r = new a(this);
  }
  
  public float j(d paramd) {
    return p(paramd).j();
  }
  
  public float k(d paramd) {
    return p(paramd).k();
  }
  
  public void l(d paramd) {
    p(paramd).m(paramd.c());
    q(paramd);
  }
  
  public void m(d paramd, ColorStateList paramColorStateList) {
    p(paramd).o(paramColorStateList);
  }
  
  public void n(d paramd, float paramFloat) {
    p(paramd).q(paramFloat);
    q(paramd);
  }
  
  public final g o(Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3) {
    return new g(paramContext.getResources(), paramColorStateList, paramFloat1, paramFloat2, paramFloat3);
  }
  
  public final g p(d paramd) {
    return (g)paramd.e();
  }
  
  public void q(d paramd) {
    Rect rect = new Rect();
    p(paramd).h(rect);
    paramd.a((int)Math.ceil(k(paramd)), (int)Math.ceil(j(paramd)));
    paramd.g(rect.left, rect.top, rect.right, rect.bottom);
  }
  
  public class a implements g.a {
    public a(c this$0) {}
    
    public void a(Canvas param1Canvas, RectF param1RectF, float param1Float, Paint param1Paint) {
      float f1 = 2.0F * param1Float;
      float f2 = param1RectF.width() - f1 - 1.0F;
      float f3 = param1RectF.height();
      if (param1Float >= 1.0F) {
        float f4 = param1Float + 0.5F;
        RectF rectF = this.a.a;
        float f5 = -f4;
        rectF.set(f5, f5, f4, f4);
        int i = param1Canvas.save();
        param1Canvas.translate(param1RectF.left + f4, param1RectF.top + f4);
        param1Canvas.drawArc(this.a.a, 180.0F, 90.0F, true, param1Paint);
        param1Canvas.translate(f2, 0.0F);
        param1Canvas.rotate(90.0F);
        param1Canvas.drawArc(this.a.a, 180.0F, 90.0F, true, param1Paint);
        param1Canvas.translate(f3 - f1 - 1.0F, 0.0F);
        param1Canvas.rotate(90.0F);
        param1Canvas.drawArc(this.a.a, 180.0F, 90.0F, true, param1Paint);
        param1Canvas.translate(f2, 0.0F);
        param1Canvas.rotate(90.0F);
        param1Canvas.drawArc(this.a.a, 180.0F, 90.0F, true, param1Paint);
        param1Canvas.restoreToCount(i);
        f1 = param1RectF.left;
        f2 = param1RectF.top;
        param1Canvas.drawRect(f1 + f4 - 1.0F, f2, param1RectF.right - f4 + 1.0F, f2 + f4, param1Paint);
        f1 = param1RectF.left;
        f2 = param1RectF.bottom;
        param1Canvas.drawRect(f1 + f4 - 1.0F, f2 - f4, param1RectF.right - f4 + 1.0F, f2, param1Paint);
      } 
      param1Canvas.drawRect(param1RectF.left, param1RectF.top + param1Float, param1RectF.right, param1RectF.bottom - param1Float, param1Paint);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\e\f\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */