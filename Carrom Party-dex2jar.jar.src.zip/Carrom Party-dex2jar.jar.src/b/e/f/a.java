package b.e.f;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

public class a extends c {
  public void i() {
    g.r = new a(this);
  }
  
  public class a implements g.a {
    public a(a this$0) {}
    
    public void a(Canvas param1Canvas, RectF param1RectF, float param1Float, Paint param1Paint) {
      param1Canvas.drawRoundRect(param1RectF, param1Float, param1Float, param1Paint);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\e\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */