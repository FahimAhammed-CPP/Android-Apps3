package b.e;

public final class c {
  public static final int a = 2131099728;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */