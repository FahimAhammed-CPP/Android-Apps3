package b.e;

public final class b {
  public static final int a = 2131034156;
  
  public static final int b = 2131034157;
  
  public static final int c = 2131034158;
  
  public static final int d = 2131034159;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\e\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */