package b.o.a;

import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import b.f.h;
import b.n.g;
import b.n.m;
import b.n.n;
import b.n.s;
import b.n.t;
import b.n.u;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

public class b extends a {
  public static boolean c = false;
  
  public final g a;
  
  public final c b;
  
  public b(g paramg, u paramu) {
    this.a = paramg;
    this.b = c.g(paramu);
  }
  
  @Deprecated
  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    this.b.e(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public <D> b.o.b.b<D> c(int paramInt, Bundle paramBundle, a.a<D> parama) {
    if (!this.b.i()) {
      if (Looper.getMainLooper() == Looper.myLooper()) {
        a<?> a1 = this.b.h(paramInt);
        if (c) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("initLoader in ");
          stringBuilder.append(this);
          stringBuilder.append(": args=");
          stringBuilder.append(paramBundle);
          Log.v("LoaderManager", stringBuilder.toString());
        } 
        if (a1 == null)
          return e(paramInt, paramBundle, parama, null); 
        if (c) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("  Re-using existing loader ");
          stringBuilder.append(a1);
          Log.v("LoaderManager", stringBuilder.toString());
        } 
        return (b.o.b.b)a1.s(this.a, parama);
      } 
      throw new IllegalStateException("initLoader must be called on the main thread");
    } 
    throw new IllegalStateException("Called while creating a loader");
  }
  
  public void d() {
    this.b.j();
  }
  
  public final <D> b.o.b.b<D> e(int paramInt, Bundle paramBundle, a.a<D> parama, b.o.b.b<D> paramb) {
    try {
      this.b.l();
      b.o.b.b<D> b1 = parama.b(paramInt, paramBundle);
      if (b1 != null) {
        if (!b1.getClass().isMemberClass() || Modifier.isStatic(b1.getClass().getModifiers())) {
          a<D> a1 = new a<D>(paramInt, paramBundle, b1, paramb);
          if (c) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("  Created new loader ");
            stringBuilder1.append(a1);
            Log.v("LoaderManager", stringBuilder1.toString());
          } 
          this.b.k(paramInt, a1);
          return a1.s(this.a, parama);
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Object returned from onCreateLoader must not be a non-static inner member class: ");
        stringBuilder.append(b1);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      throw new IllegalArgumentException("Object returned from onCreateLoader must not be null");
    } finally {
      this.b.f();
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("LoaderManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    b.h.m.b.a(this.a, stringBuilder);
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public static class a<D> extends m<D> implements b.o.b.b.b<D> {
    public final int l;
    
    public final Bundle m;
    
    public final b.o.b.b<D> n;
    
    public g o;
    
    public b.b<D> p;
    
    public b.o.b.b<D> q;
    
    public a(int param1Int, Bundle param1Bundle, b.o.b.b<D> param1b1, b.o.b.b<D> param1b2) {
      this.l = param1Int;
      this.m = param1Bundle;
      this.n = param1b1;
      this.q = param1b2;
      param1b1.r(param1Int, this);
    }
    
    public void a(b.o.b.b<D> param1b, D param1D) {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onLoadComplete: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      if (Looper.myLooper() == Looper.getMainLooper()) {
        n(param1D);
        return;
      } 
      if (b.c)
        Log.w("LoaderManager", "onLoadComplete was incorrectly called on a background thread"); 
      l(param1D);
    }
    
    public void j() {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Starting: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      this.n.u();
    }
    
    public void k() {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Stopping: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      this.n.v();
    }
    
    public void m(n<? super D> param1n) {
      super.m(param1n);
      this.o = null;
      this.p = null;
    }
    
    public void n(D param1D) {
      super.n(param1D);
      b.o.b.b<D> b1 = this.q;
      if (b1 != null) {
        b1.s();
        this.q = null;
      } 
    }
    
    public b.o.b.b<D> o(boolean param1Boolean) {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  Destroying: ");
        stringBuilder.append(this);
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      this.n.c();
      this.n.b();
      b.b<D> b1 = this.p;
      if (b1 != null) {
        m(b1);
        if (param1Boolean)
          b1.d(); 
      } 
      this.n.w(this);
      if ((b1 != null && !b1.c()) || param1Boolean) {
        this.n.s();
        return this.q;
      } 
      return this.n;
    }
    
    public void p(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mId=");
      param1PrintWriter.print(this.l);
      param1PrintWriter.print(" mArgs=");
      param1PrintWriter.println(this.m);
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mLoader=");
      param1PrintWriter.println(this.n);
      b.o.b.b<D> b1 = this.n;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append("  ");
      b1.h(stringBuilder.toString(), param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
      if (this.p != null) {
        param1PrintWriter.print(param1String);
        param1PrintWriter.print("mCallbacks=");
        param1PrintWriter.println(this.p);
        b.b<D> b2 = this.p;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(param1String);
        stringBuilder1.append("  ");
        b2.b(stringBuilder1.toString(), param1PrintWriter);
      } 
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mData=");
      param1PrintWriter.println(q().e(f()));
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mStarted=");
      param1PrintWriter.println(g());
    }
    
    public b.o.b.b<D> q() {
      return this.n;
    }
    
    public void r() {
      g g1 = this.o;
      b.b<D> b1 = this.p;
      if (g1 != null && b1 != null) {
        super.m(b1);
        h(g1, b1);
      } 
    }
    
    public b.o.b.b<D> s(g param1g, a.a<D> param1a) {
      b.b<D> b1 = new b.b<D>(this.n, param1a);
      h(param1g, b1);
      b.b<D> b2 = this.p;
      if (b2 != null)
        m(b2); 
      this.o = param1g;
      this.p = b1;
      return this.n;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(64);
      stringBuilder.append("LoaderInfo{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" #");
      stringBuilder.append(this.l);
      stringBuilder.append(" : ");
      b.h.m.b.a(this.n, stringBuilder);
      stringBuilder.append("}}");
      return stringBuilder.toString();
    }
  }
  
  public static class b<D> implements n<D> {
    public final b.o.b.b<D> a;
    
    public final a.a<D> b;
    
    public boolean c = false;
    
    public b(b.o.b.b<D> param1b, a.a<D> param1a) {
      this.a = param1b;
      this.b = param1a;
    }
    
    public void a(D param1D) {
      if (b.c) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  onLoadFinished in ");
        stringBuilder.append(this.a);
        stringBuilder.append(": ");
        stringBuilder.append(this.a.e(param1D));
        Log.v("LoaderManager", stringBuilder.toString());
      } 
      this.b.a(this.a, param1D);
      this.c = true;
    }
    
    public void b(String param1String, PrintWriter param1PrintWriter) {
      param1PrintWriter.print(param1String);
      param1PrintWriter.print("mDeliveredData=");
      param1PrintWriter.println(this.c);
    }
    
    public boolean c() {
      return this.c;
    }
    
    public void d() {
      if (this.c) {
        if (b.c) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("  Resetting: ");
          stringBuilder.append(this.a);
          Log.v("LoaderManager", stringBuilder.toString());
        } 
        this.b.c(this.a);
      } 
    }
    
    public String toString() {
      return this.b.toString();
    }
  }
  
  public static class c extends s {
    public static final t.a d = new a();
    
    public h<b.a> b = new h();
    
    public boolean c = false;
    
    public static c g(u param1u) {
      return (c)(new t(param1u, d)).a(c.class);
    }
    
    public void d() {
      super.d();
      int j = this.b.t();
      for (int i = 0; i < j; i++)
        ((b.a)this.b.u(i)).o(true); 
      this.b.e();
    }
    
    public void e(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      if (this.b.t() > 0) {
        param1PrintWriter.print(param1String);
        param1PrintWriter.println("Loaders:");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1String);
        stringBuilder.append("    ");
        String str = stringBuilder.toString();
        int i;
        for (i = 0; i < this.b.t(); i++) {
          b.a a1 = (b.a)this.b.u(i);
          param1PrintWriter.print(param1String);
          param1PrintWriter.print("  #");
          param1PrintWriter.print(this.b.r(i));
          param1PrintWriter.print(": ");
          param1PrintWriter.println(a1.toString());
          a1.p(str, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
        } 
      } 
    }
    
    public void f() {
      this.c = false;
    }
    
    public <D> b.a<D> h(int param1Int) {
      return (b.a<D>)this.b.o(param1Int);
    }
    
    public boolean i() {
      return this.c;
    }
    
    public void j() {
      int j = this.b.t();
      for (int i = 0; i < j; i++)
        ((b.a)this.b.u(i)).r(); 
    }
    
    public void k(int param1Int, b.a param1a) {
      this.b.s(param1Int, param1a);
    }
    
    public void l() {
      this.c = true;
    }
    
    public static final class a implements t.a {
      public <T extends s> T a(Class<T> param2Class) {
        return (T)new b.c();
      }
    }
  }
  
  public static final class a implements t.a {
    public <T extends s> T a(Class<T> param1Class) {
      return (T)new b.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\o\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */