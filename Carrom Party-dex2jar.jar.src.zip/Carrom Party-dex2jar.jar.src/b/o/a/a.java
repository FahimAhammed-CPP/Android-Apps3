package b.o.a;

import android.os.Bundle;
import b.n.g;
import b.n.v;
import b.o.b.b;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class a {
  public static <T extends g & v> a b(T paramT) {
    return new b((g)paramT, ((v)paramT).h());
  }
  
  @Deprecated
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract <D> b<D> c(int paramInt, Bundle paramBundle, a<D> parama);
  
  public abstract void d();
  
  public static interface a<D> {
    void a(b<D> param1b, D param1D);
    
    b<D> b(int param1Int, Bundle param1Bundle);
    
    void c(b<D> param1b);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\o\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */