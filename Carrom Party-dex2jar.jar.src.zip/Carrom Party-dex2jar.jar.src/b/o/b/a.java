package b.o.b;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import b.h.j.i;
import b.h.m.i;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

public abstract class a<D> extends b<D> {
  public final Executor i;
  
  public volatile a j;
  
  public volatile a k;
  
  public long l;
  
  public long m = -10000L;
  
  public Handler n;
  
  public a(Context paramContext) {
    this(paramContext, c.h);
  }
  
  public a(Context paramContext, Executor paramExecutor) {
    super(paramContext);
    this.i = paramExecutor;
  }
  
  public void A() {
    if (this.k == null && this.j != null) {
      if (this.j.k) {
        this.j.k = false;
        this.n.removeCallbacks(this.j);
      } 
      if (this.l > 0L && SystemClock.uptimeMillis() < this.m + this.l) {
        this.j.k = true;
        this.n.postAtTime(this.j, this.m + this.l);
        return;
      } 
      this.j.c(this.i, null);
    } 
  }
  
  public abstract D B();
  
  public void C(D paramD) {}
  
  public D D() {
    return B();
  }
  
  @Deprecated
  public void h(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.h(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    if (this.j != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTask=");
      paramPrintWriter.print(this.j);
      paramPrintWriter.print(" waiting=");
      paramPrintWriter.println(this.j.k);
    } 
    if (this.k != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mCancellingTask=");
      paramPrintWriter.print(this.k);
      paramPrintWriter.print(" waiting=");
      paramPrintWriter.println(this.k.k);
    } 
    if (this.l != 0L) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mUpdateThrottle=");
      i.c(this.l, paramPrintWriter);
      paramPrintWriter.print(" mLastLoadCompleteTime=");
      i.b(this.m, SystemClock.uptimeMillis(), paramPrintWriter);
      paramPrintWriter.println();
    } 
  }
  
  public boolean l() {
    if (this.j != null) {
      if (!this.d)
        this.g = true; 
      if (this.k != null) {
        if (this.j.k) {
          this.j.k = false;
          this.n.removeCallbacks(this.j);
        } 
        this.j = null;
        return false;
      } 
      if (this.j.k) {
        this.j.k = false;
        this.n.removeCallbacks(this.j);
        this.j = null;
        return false;
      } 
      boolean bool = this.j.a(false);
      if (bool) {
        this.k = this.j;
        x();
      } 
      this.j = null;
      return bool;
    } 
    return false;
  }
  
  public void n() {
    super.n();
    c();
    this.j = new a(this);
    A();
  }
  
  public void x() {}
  
  public void y(a parama, D paramD) {
    C(paramD);
    if (this.k == parama) {
      t();
      this.m = SystemClock.uptimeMillis();
      this.k = null;
      f();
      A();
    } 
  }
  
  public void z(a parama, D paramD) {
    if (this.j != parama) {
      y(parama, paramD);
      return;
    } 
    if (j()) {
      C(paramD);
      return;
    } 
    d();
    this.m = SystemClock.uptimeMillis();
    this.j = null;
    g(paramD);
  }
  
  public final class a extends c<Void, Void, D> implements Runnable {
    public final CountDownLatch j = new CountDownLatch(1);
    
    public boolean k;
    
    public a(a this$0) {}
    
    public void h(D param1D) {
      try {
        this.l.y(this, param1D);
        return;
      } finally {
        this.j.countDown();
      } 
    }
    
    public void i(D param1D) {
      try {
        this.l.z(this, param1D);
        return;
      } finally {
        this.j.countDown();
      } 
    }
    
    public D n(Void... param1VarArgs) {
      try {
        return (D)this.l.D();
      } catch (i i) {
        if (f())
          return null; 
        throw i;
      } 
    }
    
    public void run() {
      this.k = false;
      this.l.A();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\o\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */