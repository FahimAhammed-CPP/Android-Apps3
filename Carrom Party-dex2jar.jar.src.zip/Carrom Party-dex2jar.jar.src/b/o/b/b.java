package b.o.b;

import android.content.Context;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class b<D> {
  public int a;
  
  public b<D> b;
  
  public a<D> c;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public boolean f = true;
  
  public boolean g = false;
  
  public boolean h = false;
  
  public b(Context paramContext) {
    paramContext.getApplicationContext();
  }
  
  public void b() {
    this.e = true;
    k();
  }
  
  public boolean c() {
    return l();
  }
  
  public void d() {
    this.h = false;
  }
  
  public String e(D paramD) {
    StringBuilder stringBuilder = new StringBuilder(64);
    b.h.m.b.a(paramD, stringBuilder);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void f() {
    a<D> a1 = this.c;
    if (a1 != null)
      a1.a(this); 
  }
  
  public void g(D paramD) {
    b<D> b1 = this.b;
    if (b1 != null)
      b1.a(this, paramD); 
  }
  
  @Deprecated
  public void h(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mId=");
    paramPrintWriter.print(this.a);
    paramPrintWriter.print(" mListener=");
    paramPrintWriter.println(this.b);
    if (this.d || this.g || this.h) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStarted=");
      paramPrintWriter.print(this.d);
      paramPrintWriter.print(" mContentChanged=");
      paramPrintWriter.print(this.g);
      paramPrintWriter.print(" mProcessingChange=");
      paramPrintWriter.println(this.h);
    } 
    if (this.e || this.f) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAbandoned=");
      paramPrintWriter.print(this.e);
      paramPrintWriter.print(" mReset=");
      paramPrintWriter.println(this.f);
    } 
  }
  
  public void i() {
    n();
  }
  
  public boolean j() {
    return this.e;
  }
  
  public void k() {}
  
  public boolean l() {
    throw null;
  }
  
  public void m() {
    if (this.d) {
      i();
      return;
    } 
    this.g = true;
  }
  
  public void n() {}
  
  public void o() {}
  
  public void p() {
    throw null;
  }
  
  public void q() {}
  
  public void r(int paramInt, b<D> paramb) {
    if (this.b == null) {
      this.b = paramb;
      this.a = paramInt;
      return;
    } 
    throw new IllegalStateException("There is already a listener registered");
  }
  
  public void s() {
    o();
    this.f = true;
    this.d = false;
    this.e = false;
    this.g = false;
    this.h = false;
  }
  
  public void t() {
    if (this.h)
      m(); 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(64);
    b.h.m.b.a(this, stringBuilder);
    stringBuilder.append(" id=");
    stringBuilder.append(this.a);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public final void u() {
    this.d = true;
    this.f = false;
    this.e = false;
    p();
  }
  
  public void v() {
    this.d = false;
    q();
  }
  
  public void w(b<D> paramb) {
    b<D> b1 = this.b;
    if (b1 != null) {
      if (b1 == paramb) {
        this.b = null;
        return;
      } 
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    } 
    throw new IllegalStateException("No listener register");
  }
  
  public static interface a<D> {
    void a(b<D> param1b);
  }
  
  public static interface b<D> {
    void a(b<D> param1b, D param1D);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\o\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */