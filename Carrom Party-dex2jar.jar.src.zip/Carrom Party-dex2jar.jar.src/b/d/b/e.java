package b.d.b;

import a.a.a.a;
import a.a.a.b;
import android.content.ComponentName;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import java.util.List;

public final class e {
  public final b a;
  
  public final a b;
  
  public final ComponentName c;
  
  public e(b paramb, a parama, ComponentName paramComponentName) {
    this.a = paramb;
    this.b = parama;
    this.c = paramComponentName;
  }
  
  public IBinder a() {
    return this.b.asBinder();
  }
  
  public ComponentName b() {
    return this.c;
  }
  
  public boolean c(Uri paramUri, Bundle paramBundle, List<Bundle> paramList) {
    try {
      return this.a.c1(this.b, paramUri, paramBundle, paramList);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\d\b\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */