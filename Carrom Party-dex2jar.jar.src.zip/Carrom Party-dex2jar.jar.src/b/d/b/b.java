package b.d.b;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;

public class b {
  public final a.a.a.b a;
  
  public final ComponentName b;
  
  public b(a.a.a.b paramb, ComponentName paramComponentName) {
    this.a = paramb;
    this.b = paramComponentName;
  }
  
  public static boolean a(Context paramContext, String paramString, d paramd) {
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, paramd, 33);
  }
  
  public static boolean b(Context paramContext, String paramString) {
    if (paramString == null)
      return false; 
    paramContext = paramContext.getApplicationContext();
    a a = new a(paramContext);
    try {
      return a(paramContext, paramString, a);
    } catch (SecurityException securityException) {
      return false;
    } 
  }
  
  public e c(a parama) {
    b b1 = new b(this, parama);
    try {
      boolean bool = this.a.v4((a.a.a.a)b1);
      return !bool ? null : new e(this.a, (a.a.a.a)b1, this.b);
    } catch (RemoteException remoteException) {
      return null;
    } 
  }
  
  public boolean d(long paramLong) {
    try {
      return this.a.q3(paramLong);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
  
  public static final class a extends d {
    public a(Context param1Context) {}
    
    public final void a(ComponentName param1ComponentName, b param1b) {
      param1b.d(0L);
      this.a.unbindService(this);
    }
    
    public final void onServiceDisconnected(ComponentName param1ComponentName) {}
  }
  
  public class b extends a.a.a.a.a {
    public Handler a = new Handler(Looper.getMainLooper());
    
    public b(b this$0, a param1a) {}
    
    public void L4(String param1String, Bundle param1Bundle) {
      if (this.b == null)
        return; 
      this.a.post(new b(this, param1String, param1Bundle));
    }
    
    public void c6(String param1String, Bundle param1Bundle) {
      if (this.b == null)
        return; 
      this.a.post(new d(this, param1String, param1Bundle));
    }
    
    public void j6(Bundle param1Bundle) {
      if (this.b == null)
        return; 
      this.a.post(new c(this, param1Bundle));
    }
    
    public void n6(int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {
      if (this.b == null)
        return; 
      this.a.post(new e(this, param1Int, param1Uri, param1Boolean, param1Bundle));
    }
    
    public void q5(int param1Int, Bundle param1Bundle) {
      if (this.b == null)
        return; 
      this.a.post(new a(this, param1Int, param1Bundle));
    }
    
    public class a implements Runnable {
      public a(b.b this$0, int param2Int, Bundle param2Bundle) {}
      
      public void run() {
        this.c.b.c(this.a, this.b);
        throw null;
      }
    }
    
    public class b implements Runnable {
      public b(b.b this$0, String param2String, Bundle param2Bundle) {}
      
      public void run() {
        this.c.b.a(this.a, this.b);
        throw null;
      }
    }
    
    public class c implements Runnable {
      public c(b.b this$0, Bundle param2Bundle) {}
      
      public void run() {
        this.b.b.b(this.a);
        throw null;
      }
    }
    
    public class d implements Runnable {
      public d(b.b this$0, String param2String, Bundle param2Bundle) {}
      
      public void run() {
        this.c.b.d(this.a, this.b);
        throw null;
      }
    }
    
    public class e implements Runnable {
      public e(b.b this$0, int param2Int, Uri param2Uri, boolean param2Boolean, Bundle param2Bundle) {}
      
      public void run() {
        this.e.b.e(this.a, this.b, this.c, this.d);
        throw null;
      }
    }
  }
  
  public class a implements Runnable {
    public a(b this$0, int param1Int, Bundle param1Bundle) {}
    
    public void run() {
      this.c.b.c(this.a, this.b);
      throw null;
    }
  }
  
  public class b implements Runnable {
    public b(b this$0, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.c.b.a(this.a, this.b);
      throw null;
    }
  }
  
  public class c implements Runnable {
    public c(b this$0, Bundle param1Bundle) {}
    
    public void run() {
      this.b.b.b(this.a);
      throw null;
    }
  }
  
  public class d implements Runnable {
    public d(b this$0, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.c.b.d(this.a, this.b);
      throw null;
    }
  }
  
  public class e implements Runnable {
    public e(b this$0, int param1Int, Uri param1Uri, boolean param1Boolean, Bundle param1Bundle) {}
    
    public void run() {
      this.e.b.e(this.a, this.b, this.c, this.d);
      throw null;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\d\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */