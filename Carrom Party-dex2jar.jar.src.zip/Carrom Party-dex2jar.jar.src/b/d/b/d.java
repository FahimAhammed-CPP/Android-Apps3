package b.d.b;

import a.a.a.b;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

public abstract class d implements ServiceConnection {
  public abstract void a(ComponentName paramComponentName, b paramb);
  
  public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    a(paramComponentName, new a(this, b.a.a0(paramIBinder), paramComponentName));
  }
  
  public class a extends b {
    public a(d this$0, b param1b, ComponentName param1ComponentName) {
      super(param1b, param1ComponentName);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\d\b\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */