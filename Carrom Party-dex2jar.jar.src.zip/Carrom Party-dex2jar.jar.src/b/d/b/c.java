package b.d.b;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import b.h.e.e;
import java.util.ArrayList;

public final class c {
  public final Intent a;
  
  public final Bundle b;
  
  public c(Intent paramIntent, Bundle paramBundle) {
    this.a = paramIntent;
    this.b = paramBundle;
  }
  
  public void a(Context paramContext, Uri paramUri) {
    this.a.setData(paramUri);
    b.h.f.a.i(paramContext, this.a, this.b);
  }
  
  public static final class a {
    public final Intent a;
    
    public ArrayList<Bundle> b;
    
    public Bundle c;
    
    public ArrayList<Bundle> d;
    
    public boolean e;
    
    public a() {
      this(null);
    }
    
    public a(e param1e) {
      IBinder iBinder;
      Intent intent = new Intent("android.intent.action.VIEW");
      this.a = intent;
      e e1 = null;
      this.b = null;
      this.c = null;
      this.d = null;
      this.e = true;
      if (param1e != null)
        intent.setPackage(param1e.b().getPackageName()); 
      Bundle bundle = new Bundle();
      if (param1e == null) {
        param1e = e1;
      } else {
        iBinder = param1e.a();
      } 
      e.b(bundle, "android.support.customtabs.extra.SESSION", iBinder);
      intent.putExtras(bundle);
    }
    
    public c a() {
      ArrayList<Bundle> arrayList = this.b;
      if (arrayList != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", arrayList); 
      arrayList = this.d;
      if (arrayList != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", arrayList); 
      this.a.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.e);
      return new c(this.a, this.c);
    }
    
    public a b(boolean param1Boolean) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\d\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */