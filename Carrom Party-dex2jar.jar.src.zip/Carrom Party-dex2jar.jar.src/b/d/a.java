package b.d;

public final class a {
  public static final int a = 2131099726;
  
  public static final int b = 2131099727;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\d\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */