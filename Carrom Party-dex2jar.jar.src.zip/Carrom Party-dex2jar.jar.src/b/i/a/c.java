package b.i.a;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class c extends a {
  public int i;
  
  public int j;
  
  public LayoutInflater k;
  
  @Deprecated
  public c(Context paramContext, int paramInt, Cursor paramCursor, boolean paramBoolean) {
    super(paramContext, paramCursor, paramBoolean);
    this.j = paramInt;
    this.i = paramInt;
    this.k = (LayoutInflater)paramContext.getSystemService("layout_inflater");
  }
  
  public View g(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup) {
    return this.k.inflate(this.j, paramViewGroup, false);
  }
  
  public View h(Context paramContext, Cursor paramCursor, ViewGroup paramViewGroup) {
    return this.k.inflate(this.i, paramViewGroup, false);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\i\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */