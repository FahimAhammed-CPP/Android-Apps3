package b.c.a.a;

public abstract class c {
  public abstract void a(Runnable paramRunnable);
  
  public abstract boolean b();
  
  public abstract void c(Runnable paramRunnable);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\c\a\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */