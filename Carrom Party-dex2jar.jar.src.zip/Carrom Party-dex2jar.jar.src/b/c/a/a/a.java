package b.c.a.a;

import java.util.concurrent.Executor;

public class a extends c {
  public static volatile a c;
  
  public static final Executor d = new a();
  
  public c a;
  
  public c b;
  
  public a() {
    b b = new b();
    this.b = b;
    this.a = b;
  }
  
  public static Executor d() {
    return d;
  }
  
  public static a e() {
    // Byte code:
    //   0: getstatic b/c/a/a/a.c : Lb/c/a/a/a;
    //   3: ifnull -> 10
    //   6: getstatic b/c/a/a/a.c : Lb/c/a/a/a;
    //   9: areturn
    //   10: ldc b/c/a/a/a
    //   12: monitorenter
    //   13: getstatic b/c/a/a/a.c : Lb/c/a/a/a;
    //   16: ifnonnull -> 29
    //   19: new b/c/a/a/a
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: putstatic b/c/a/a/a.c : Lb/c/a/a/a;
    //   29: ldc b/c/a/a/a
    //   31: monitorexit
    //   32: getstatic b/c/a/a/a.c : Lb/c/a/a/a;
    //   35: areturn
    //   36: astore_0
    //   37: ldc b/c/a/a/a
    //   39: monitorexit
    //   40: aload_0
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   13	29	36	finally
    //   29	32	36	finally
    //   37	40	36	finally
  }
  
  public void a(Runnable paramRunnable) {
    this.a.a(paramRunnable);
  }
  
  public boolean b() {
    return this.a.b();
  }
  
  public void c(Runnable paramRunnable) {
    this.a.c(paramRunnable);
  }
  
  public static final class a implements Executor {
    public void execute(Runnable param1Runnable) {
      a.e().a(param1Runnable);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\c\a\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */