package b.c.a.b;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class b<K, V> implements Iterable<Map.Entry<K, V>> {
  public c<K, V> a;
  
  public c<K, V> b;
  
  public WeakHashMap<f<K, V>, Boolean> c = new WeakHashMap<f<K, V>, Boolean>();
  
  public int d = 0;
  
  public Map.Entry<K, V> a() {
    return this.a;
  }
  
  public c<K, V> b(K paramK) {
    c<K, V> c1;
    for (c1 = this.a; c1 != null; c1 = c1.c) {
      if (c1.a.equals(paramK))
        return c1; 
    } 
    return c1;
  }
  
  public d c() {
    d d = new d(this);
    this.c.put(d, Boolean.FALSE);
    return d;
  }
  
  public Map.Entry<K, V> d() {
    return this.b;
  }
  
  public Iterator<Map.Entry<K, V>> descendingIterator() {
    b<K, V> b1 = new b<K, V>(this.b, this.a);
    this.c.put(b1, Boolean.FALSE);
    return b1;
  }
  
  public c<K, V> e(K paramK, V paramV) {
    c<K, V> c1 = new c<K, V>(paramK, paramV);
    this.d++;
    c<K, V> c2 = this.b;
    if (c2 == null) {
      this.a = c1;
      this.b = c1;
      return c1;
    } 
    c2.c = c1;
    c1.d = c2;
    this.b = c1;
    return c1;
  }
  
  public boolean equals(Object<Map.Entry<K, V>> paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof b))
      return false; 
    b b1 = (b)paramObject;
    if (size() != b1.size())
      return false; 
    paramObject = (Object<Map.Entry<K, V>>)iterator();
    Iterator<Object> iterator = b1.iterator();
    while (paramObject.hasNext() && iterator.hasNext()) {
      Map.Entry entry = paramObject.next();
      Object object = iterator.next();
      if ((entry == null && object != null) || (entry != null && !entry.equals(object)))
        return false; 
    } 
    return (!paramObject.hasNext() && !iterator.hasNext());
  }
  
  public V g(K paramK, V paramV) {
    c<K, V> c1 = b(paramK);
    if (c1 != null)
      return c1.b; 
    e(paramK, paramV);
    return null;
  }
  
  public int hashCode() {
    Iterator<Map.Entry<K, V>> iterator = iterator();
    int i;
    for (i = 0; iterator.hasNext(); i += ((Map.Entry)iterator.next()).hashCode());
    return i;
  }
  
  public V i(K paramK) {
    c<K, V> c1 = b(paramK);
    if (c1 == null)
      return null; 
    this.d--;
    if (!this.c.isEmpty()) {
      Iterator<f<K, V>> iterator = this.c.keySet().iterator();
      while (iterator.hasNext())
        ((f<K, V>)iterator.next()).b(c1); 
    } 
    c<K, V> c2 = c1.d;
    if (c2 != null) {
      c2.c = c1.c;
    } else {
      this.a = c1.c;
    } 
    c<K, V> c3 = c1.c;
    if (c3 != null) {
      c3.d = c2;
    } else {
      this.b = c2;
    } 
    c1.c = null;
    c1.d = null;
    return c1.b;
  }
  
  public Iterator<Map.Entry<K, V>> iterator() {
    a<K, V> a = new a<K, V>(this.a, this.b);
    this.c.put(a, Boolean.FALSE);
    return a;
  }
  
  public int size() {
    return this.d;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    Iterator<Map.Entry<K, V>> iterator = iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(((Map.Entry)iterator.next()).toString());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  public static class a<K, V> extends e<K, V> {
    public a(b.c<K, V> param1c1, b.c<K, V> param1c2) {
      super(param1c1, param1c2);
    }
    
    public b.c<K, V> c(b.c<K, V> param1c) {
      return param1c.d;
    }
    
    public b.c<K, V> d(b.c<K, V> param1c) {
      return param1c.c;
    }
  }
  
  public static class b<K, V> extends e<K, V> {
    public b(b.c<K, V> param1c1, b.c<K, V> param1c2) {
      super(param1c1, param1c2);
    }
    
    public b.c<K, V> c(b.c<K, V> param1c) {
      return param1c.c;
    }
    
    public b.c<K, V> d(b.c<K, V> param1c) {
      return param1c.d;
    }
  }
  
  public static class c<K, V> implements Map.Entry<K, V> {
    public final K a;
    
    public final V b;
    
    public c<K, V> c;
    
    public c<K, V> d;
    
    public c(K param1K, V param1V) {
      this.a = param1K;
      this.b = param1V;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof c))
        return false; 
      param1Object = param1Object;
      return (this.a.equals(((c)param1Object).a) && this.b.equals(((c)param1Object).b));
    }
    
    public K getKey() {
      return this.a;
    }
    
    public V getValue() {
      return this.b;
    }
    
    public int hashCode() {
      return this.a.hashCode() ^ this.b.hashCode();
    }
    
    public V setValue(V param1V) {
      throw new UnsupportedOperationException("An entry modification is not supported");
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append("=");
      stringBuilder.append(this.b);
      return stringBuilder.toString();
    }
  }
  
  public class d implements Iterator<Map.Entry<K, V>>, f<K, V> {
    public b.c<K, V> a;
    
    public boolean b = true;
    
    public d(b this$0) {}
    
    public void b(b.c<K, V> param1c) {
      b.c<K, V> c1 = this.a;
      if (param1c == c1) {
        boolean bool;
        param1c = c1.d;
        this.a = param1c;
        if (param1c == null) {
          bool = true;
        } else {
          bool = false;
        } 
        this.b = bool;
      } 
    }
    
    public Map.Entry<K, V> c() {
      if (this.b) {
        this.b = false;
        this.a = this.c.a;
      } else {
        b.c<K, V> c1 = this.a;
        if (c1 != null) {
          c1 = c1.c;
        } else {
          c1 = null;
        } 
        this.a = c1;
      } 
      return this.a;
    }
    
    public boolean hasNext() {
      if (this.b)
        return (this.c.a != null); 
      b.c<K, V> c1 = this.a;
      return (c1 != null && c1.c != null);
    }
  }
  
  public static abstract class e<K, V> implements Iterator<Map.Entry<K, V>>, f<K, V> {
    public b.c<K, V> a;
    
    public b.c<K, V> b;
    
    public e(b.c<K, V> param1c1, b.c<K, V> param1c2) {
      this.a = param1c2;
      this.b = param1c1;
    }
    
    public void b(b.c<K, V> param1c) {
      if (this.a == param1c && param1c == this.b) {
        this.b = null;
        this.a = null;
      } 
      b.c<K, V> c1 = this.a;
      if (c1 == param1c)
        this.a = c(c1); 
      if (this.b == param1c)
        this.b = f(); 
    }
    
    public abstract b.c<K, V> c(b.c<K, V> param1c);
    
    public abstract b.c<K, V> d(b.c<K, V> param1c);
    
    public Map.Entry<K, V> e() {
      b.c<K, V> c1 = this.b;
      this.b = f();
      return c1;
    }
    
    public final b.c<K, V> f() {
      b.c<K, V> c1 = this.b;
      b.c<K, V> c2 = this.a;
      return (c1 == c2 || c2 == null) ? null : d(c1);
    }
    
    public boolean hasNext() {
      return (this.b != null);
    }
  }
  
  public static interface f<K, V> {
    void b(b.c<K, V> param1c);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\c\a\b\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */