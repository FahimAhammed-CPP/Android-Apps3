package b.c.a.b;

import java.util.HashMap;
import java.util.Map;

public class a<K, V> extends b<K, V> {
  public HashMap<K, b.c<K, V>> e = new HashMap<K, b.c<K, V>>();
  
  public b.c<K, V> b(K paramK) {
    return this.e.get(paramK);
  }
  
  public boolean contains(K paramK) {
    return this.e.containsKey(paramK);
  }
  
  public V g(K paramK, V paramV) {
    b.c<K, V> c = b(paramK);
    if (c != null)
      return c.b; 
    this.e.put(paramK, e(paramK, paramV));
    return null;
  }
  
  public V i(K paramK) {
    V v = super.i(paramK);
    this.e.remove(paramK);
    return v;
  }
  
  public Map.Entry<K, V> j(K paramK) {
    return contains(paramK) ? ((b.c)this.e.get(paramK)).d : null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\c\a\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */