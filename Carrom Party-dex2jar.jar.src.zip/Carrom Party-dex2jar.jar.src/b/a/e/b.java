package b.a.e;

import android.annotation.SuppressLint;

public abstract class b<I> {
  public void a(@SuppressLint({"UnknownNullness"}) I paramI) {
    b(paramI, null);
  }
  
  public abstract void b(@SuppressLint({"UnknownNullness"}) I paramI, b.h.e.b paramb);
  
  public abstract void c();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\a\e\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */