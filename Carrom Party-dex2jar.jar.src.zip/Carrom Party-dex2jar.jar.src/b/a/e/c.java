package b.a.e;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import androidx.activity.result.ActivityResult;
import b.a.e.e.a;
import b.n.d;
import b.n.e;
import b.n.f;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public abstract class c {
  public Random a = new Random();
  
  public final Map<Integer, String> b = new HashMap<Integer, String>();
  
  public final Map<String, Integer> c = new HashMap<String, Integer>();
  
  public final Map<String, c> d = new HashMap<String, c>();
  
  public final transient Map<String, b<?>> e = new HashMap<String, b<?>>();
  
  public final Map<String, Object> f = new HashMap<String, Object>();
  
  public final Bundle g = new Bundle();
  
  public final void a(int paramInt, String paramString) {
    this.b.put(Integer.valueOf(paramInt), paramString);
    this.c.put(paramString, Integer.valueOf(paramInt));
  }
  
  public final boolean b(int paramInt1, int paramInt2, Intent paramIntent) {
    String str = this.b.get(Integer.valueOf(paramInt1));
    if (str == null)
      return false; 
    d(str, paramInt2, paramIntent, this.e.get(str));
    return true;
  }
  
  public final <O> boolean c(int paramInt, @SuppressLint({"UnknownNullness"}) O paramO) {
    String str = this.b.get(Integer.valueOf(paramInt));
    if (str == null)
      return false; 
    b b = this.e.get(str);
    if (b != null) {
      a<O> a = b.a;
      if (a == null) {
        this.g.remove(str);
        this.f.put(str, paramO);
        return true;
      } 
      a.a(paramO);
      return true;
    } 
    this.g.remove(str);
    this.f.put(str, paramO);
    return true;
  }
  
  public final <O> void d(String paramString, int paramInt, Intent paramIntent, b<O> paramb) {
    if (paramb != null) {
      a<O> a = paramb.a;
      if (a != null) {
        a.a((O)paramb.b.c(paramInt, paramIntent));
        return;
      } 
    } 
    this.f.remove(paramString);
    this.g.putParcelable(paramString, (Parcelable)new ActivityResult(paramInt, paramIntent));
  }
  
  public final int e() {
    int i = this.a.nextInt(2147418112);
    while (true) {
      i += 65536;
      if (this.b.containsKey(Integer.valueOf(i))) {
        i = this.a.nextInt(2147418112);
        continue;
      } 
      return i;
    } 
  }
  
  public abstract <I, O> void f(int paramInt, a<I, O> parama, @SuppressLint({"UnknownNullness"}) I paramI, b.h.e.b paramb);
  
  public final void g(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    ArrayList<Integer> arrayList = paramBundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
    ArrayList<String> arrayList1 = paramBundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
    if (arrayList1 != null) {
      if (arrayList == null)
        return; 
      int j = arrayList1.size();
      for (int i = 0; i < j; i++)
        a(((Integer)arrayList.get(i)).intValue(), arrayList1.get(i)); 
      this.a = (Random)paramBundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
      this.g.putAll(paramBundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
    } 
  }
  
  public final void h(Bundle paramBundle) {
    paramBundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.b.keySet()));
    paramBundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.b.values()));
    paramBundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle)this.g.clone());
    paramBundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.a);
  }
  
  public final <I, O> b<I> i(String paramString, a<I, O> parama, a<O> parama1) {
    int i = j(paramString);
    this.e.put(paramString, new b(parama1, parama));
    if (this.f.containsKey(paramString)) {
      Object object = this.f.get(paramString);
      this.f.remove(paramString);
      parama1.a((O)object);
    } 
    ActivityResult activityResult = (ActivityResult)this.g.getParcelable(paramString);
    if (activityResult != null) {
      this.g.remove(paramString);
      parama1.a((O)parama.c(activityResult.d(), activityResult.c()));
    } 
    return new a(this, i, parama, paramString);
  }
  
  public final int j(String paramString) {
    Integer integer = this.c.get(paramString);
    if (integer != null)
      return integer.intValue(); 
    int i = e();
    a(i, paramString);
    return i;
  }
  
  public final void k(String paramString) {
    Integer integer = this.c.remove(paramString);
    if (integer != null)
      this.b.remove(integer); 
    this.e.remove(paramString);
    if (this.f.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.f.get(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.f.remove(paramString);
    } 
    if (this.g.containsKey(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Dropping pending result for request ");
      stringBuilder.append(paramString);
      stringBuilder.append(": ");
      stringBuilder.append(this.g.getParcelable(paramString));
      Log.w("ActivityResultRegistry", stringBuilder.toString());
      this.g.remove(paramString);
    } 
    c c1 = this.d.get(paramString);
    if (c1 != null) {
      c1.a();
      this.d.remove(paramString);
    } 
  }
  
  public class a extends b<I> {
    public a(c this$0, int param1Int, a param1a, String param1String) {}
    
    public void b(I param1I, b.h.e.b param1b) {
      this.d.f(this.a, this.b, param1I, param1b);
    }
    
    public void c() {
      this.d.k(this.c);
    }
  }
  
  public static class b<O> {
    public final a<O> a;
    
    public final a<?, O> b;
    
    public b(a<O> param1a, a<?, O> param1a1) {
      this.a = param1a;
      this.b = param1a1;
    }
  }
  
  public static class c {
    public final d a;
    
    public final ArrayList<e> b;
    
    public void a() {
      for (e e : this.b)
        this.a.c((f)e); 
      this.b.clear();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\a\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */