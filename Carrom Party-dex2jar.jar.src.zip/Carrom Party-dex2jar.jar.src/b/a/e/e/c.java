package b.a.e.e;

import android.content.Context;
import android.content.Intent;
import androidx.activity.result.ActivityResult;

public final class c extends a<Intent, ActivityResult> {
  public Intent d(Context paramContext, Intent paramIntent) {
    return paramIntent;
  }
  
  public ActivityResult e(int paramInt, Intent paramIntent) {
    return new ActivityResult(paramInt, paramIntent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\a\e\e\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */