package b.a.e;

import android.annotation.SuppressLint;

public interface a<O> {
  void a(@SuppressLint({"UnknownNullness"}) O paramO);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\a\e\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */