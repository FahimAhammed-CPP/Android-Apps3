package b.a;

import androidx.activity.OnBackPressedDispatcher;
import b.n.g;

public interface c extends g {
  OnBackPressedDispatcher c();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */