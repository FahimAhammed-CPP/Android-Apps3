package b.a;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class b {
  public boolean a;
  
  public CopyOnWriteArrayList<a> b = new CopyOnWriteArrayList<a>();
  
  public b(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public void a(a parama) {
    this.b.add(parama);
  }
  
  public abstract void b();
  
  public final boolean c() {
    return this.a;
  }
  
  public final void d() {
    Iterator<a> iterator = this.b.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).cancel(); 
  }
  
  public void e(a parama) {
    this.b.remove(parama);
  }
  
  public final void f(boolean paramBoolean) {
    this.a = paramBoolean;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */