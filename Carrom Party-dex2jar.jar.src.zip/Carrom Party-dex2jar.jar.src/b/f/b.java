package b.f;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class b<E> implements Collection<E>, Set<E> {
  public static final int[] e = new int[0];
  
  public static final Object[] f = new Object[0];
  
  public static Object[] g;
  
  public static int h;
  
  public static Object[] i;
  
  public static int j;
  
  public int[] a;
  
  public Object[] b;
  
  public int c;
  
  public f<E, E> d;
  
  public b() {
    this(0);
  }
  
  public b(int paramInt) {
    if (paramInt == 0) {
      this.a = e;
      this.b = f;
    } else {
      a(paramInt);
    } 
    this.c = 0;
  }
  
  public static void c(int[] paramArrayOfint, Object[] paramArrayOfObject, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: bipush #8
    //   4: if_icmpne -> 57
    //   7: ldc b/f/b
    //   9: monitorenter
    //   10: getstatic b/f/b.j : I
    //   13: bipush #10
    //   15: if_icmpge -> 47
    //   18: aload_1
    //   19: iconst_0
    //   20: getstatic b/f/b.i : [Ljava/lang/Object;
    //   23: aastore
    //   24: aload_1
    //   25: iconst_1
    //   26: aload_0
    //   27: aastore
    //   28: iload_2
    //   29: iconst_1
    //   30: isub
    //   31: istore_2
    //   32: goto -> 114
    //   35: aload_1
    //   36: putstatic b/f/b.i : [Ljava/lang/Object;
    //   39: getstatic b/f/b.j : I
    //   42: iconst_1
    //   43: iadd
    //   44: putstatic b/f/b.j : I
    //   47: ldc b/f/b
    //   49: monitorexit
    //   50: return
    //   51: astore_0
    //   52: ldc b/f/b
    //   54: monitorexit
    //   55: aload_0
    //   56: athrow
    //   57: aload_0
    //   58: arraylength
    //   59: iconst_4
    //   60: if_icmpne -> 113
    //   63: ldc b/f/b
    //   65: monitorenter
    //   66: getstatic b/f/b.h : I
    //   69: bipush #10
    //   71: if_icmpge -> 103
    //   74: aload_1
    //   75: iconst_0
    //   76: getstatic b/f/b.g : [Ljava/lang/Object;
    //   79: aastore
    //   80: aload_1
    //   81: iconst_1
    //   82: aload_0
    //   83: aastore
    //   84: iload_2
    //   85: iconst_1
    //   86: isub
    //   87: istore_2
    //   88: goto -> 130
    //   91: aload_1
    //   92: putstatic b/f/b.g : [Ljava/lang/Object;
    //   95: getstatic b/f/b.h : I
    //   98: iconst_1
    //   99: iadd
    //   100: putstatic b/f/b.h : I
    //   103: ldc b/f/b
    //   105: monitorexit
    //   106: return
    //   107: astore_0
    //   108: ldc b/f/b
    //   110: monitorexit
    //   111: aload_0
    //   112: athrow
    //   113: return
    //   114: iload_2
    //   115: iconst_2
    //   116: if_icmplt -> 35
    //   119: aload_1
    //   120: iload_2
    //   121: aconst_null
    //   122: aastore
    //   123: iload_2
    //   124: iconst_1
    //   125: isub
    //   126: istore_2
    //   127: goto -> 114
    //   130: iload_2
    //   131: iconst_2
    //   132: if_icmplt -> 91
    //   135: aload_1
    //   136: iload_2
    //   137: aconst_null
    //   138: aastore
    //   139: iload_2
    //   140: iconst_1
    //   141: isub
    //   142: istore_2
    //   143: goto -> 130
    // Exception table:
    //   from	to	target	type
    //   10	24	51	finally
    //   35	47	51	finally
    //   47	50	51	finally
    //   52	55	51	finally
    //   66	80	107	finally
    //   91	103	107	finally
    //   103	106	107	finally
    //   108	111	107	finally
  }
  
  public final void a(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: bipush #8
    //   3: if_icmpne -> 73
    //   6: ldc b/f/b
    //   8: monitorenter
    //   9: getstatic b/f/b.i : [Ljava/lang/Object;
    //   12: astore_2
    //   13: aload_2
    //   14: ifnull -> 61
    //   17: aload_0
    //   18: aload_2
    //   19: putfield b : [Ljava/lang/Object;
    //   22: aload_2
    //   23: iconst_0
    //   24: aaload
    //   25: checkcast [Ljava/lang/Object;
    //   28: putstatic b/f/b.i : [Ljava/lang/Object;
    //   31: aload_0
    //   32: aload_2
    //   33: iconst_1
    //   34: aaload
    //   35: checkcast [I
    //   38: putfield a : [I
    //   41: aload_2
    //   42: iconst_1
    //   43: aconst_null
    //   44: aastore
    //   45: aload_2
    //   46: iconst_0
    //   47: aconst_null
    //   48: aastore
    //   49: getstatic b/f/b.j : I
    //   52: iconst_1
    //   53: isub
    //   54: putstatic b/f/b.j : I
    //   57: ldc b/f/b
    //   59: monitorexit
    //   60: return
    //   61: ldc b/f/b
    //   63: monitorexit
    //   64: goto -> 145
    //   67: astore_2
    //   68: ldc b/f/b
    //   70: monitorexit
    //   71: aload_2
    //   72: athrow
    //   73: iload_1
    //   74: iconst_4
    //   75: if_icmpne -> 145
    //   78: ldc b/f/b
    //   80: monitorenter
    //   81: getstatic b/f/b.g : [Ljava/lang/Object;
    //   84: astore_2
    //   85: aload_2
    //   86: ifnull -> 133
    //   89: aload_0
    //   90: aload_2
    //   91: putfield b : [Ljava/lang/Object;
    //   94: aload_2
    //   95: iconst_0
    //   96: aaload
    //   97: checkcast [Ljava/lang/Object;
    //   100: putstatic b/f/b.g : [Ljava/lang/Object;
    //   103: aload_0
    //   104: aload_2
    //   105: iconst_1
    //   106: aaload
    //   107: checkcast [I
    //   110: putfield a : [I
    //   113: aload_2
    //   114: iconst_1
    //   115: aconst_null
    //   116: aastore
    //   117: aload_2
    //   118: iconst_0
    //   119: aconst_null
    //   120: aastore
    //   121: getstatic b/f/b.h : I
    //   124: iconst_1
    //   125: isub
    //   126: putstatic b/f/b.h : I
    //   129: ldc b/f/b
    //   131: monitorexit
    //   132: return
    //   133: ldc b/f/b
    //   135: monitorexit
    //   136: goto -> 145
    //   139: astore_2
    //   140: ldc b/f/b
    //   142: monitorexit
    //   143: aload_2
    //   144: athrow
    //   145: aload_0
    //   146: iload_1
    //   147: newarray int
    //   149: putfield a : [I
    //   152: aload_0
    //   153: iload_1
    //   154: anewarray java/lang/Object
    //   157: putfield b : [Ljava/lang/Object;
    //   160: return
    // Exception table:
    //   from	to	target	type
    //   9	13	67	finally
    //   17	41	67	finally
    //   49	60	67	finally
    //   61	64	67	finally
    //   68	71	67	finally
    //   81	85	139	finally
    //   89	113	139	finally
    //   121	132	139	finally
    //   133	136	139	finally
    //   140	143	139	finally
  }
  
  public boolean add(E paramE) {
    int j;
    if (paramE == null) {
      i = g();
      j = 0;
    } else {
      j = paramE.hashCode();
      i = e(paramE, j);
    } 
    if (i >= 0)
      return false; 
    int k = i ^ 0xFFFFFFFF;
    int m = this.c;
    int[] arrayOfInt = this.a;
    if (m >= arrayOfInt.length) {
      i = 4;
      if (m >= 8) {
        i = (m >> 1) + m;
      } else if (m >= 4) {
        i = 8;
      } 
      Object[] arrayOfObject = this.b;
      a(i);
      int[] arrayOfInt1 = this.a;
      if (arrayOfInt1.length > 0) {
        System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
        System.arraycopy(arrayOfObject, 0, this.b, 0, arrayOfObject.length);
      } 
      c(arrayOfInt, arrayOfObject, this.c);
    } 
    int i = this.c;
    if (k < i) {
      arrayOfInt = this.a;
      m = k + 1;
      System.arraycopy(arrayOfInt, k, arrayOfInt, m, i - k);
      Object[] arrayOfObject = this.b;
      System.arraycopy(arrayOfObject, k, arrayOfObject, m, this.c - k);
    } 
    this.a[k] = j;
    this.b[k] = paramE;
    this.c++;
    return true;
  }
  
  public boolean addAll(Collection<? extends E> paramCollection) {
    b(this.c + paramCollection.size());
    Iterator<? extends E> iterator = paramCollection.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= add(iterator.next()));
    return bool;
  }
  
  public void b(int paramInt) {
    int[] arrayOfInt = this.a;
    if (arrayOfInt.length < paramInt) {
      Object[] arrayOfObject = this.b;
      a(paramInt);
      paramInt = this.c;
      if (paramInt > 0) {
        System.arraycopy(arrayOfInt, 0, this.a, 0, paramInt);
        System.arraycopy(arrayOfObject, 0, this.b, 0, this.c);
      } 
      c(arrayOfInt, arrayOfObject, this.c);
    } 
  }
  
  public void clear() {
    int i = this.c;
    if (i != 0) {
      c(this.a, this.b, i);
      this.a = e;
      this.b = f;
      this.c = 0;
    } 
  }
  
  public boolean contains(Object paramObject) {
    return (indexOf(paramObject) >= 0);
  }
  
  public boolean containsAll(Collection<?> paramCollection) {
    Iterator<?> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      if (!contains(iterator.next()))
        return false; 
    } 
    return true;
  }
  
  public final f<E, E> d() {
    if (this.d == null)
      this.d = new a(this); 
    return this.d;
  }
  
  public final int e(Object paramObject, int paramInt) {
    int j = this.c;
    if (j == 0)
      return -1; 
    int k = c.a(this.a, j, paramInt);
    if (k < 0)
      return k; 
    if (paramObject.equals(this.b[k]))
      return k; 
    int i;
    for (i = k + 1; i < j && this.a[i] == paramInt; i++) {
      if (paramObject.equals(this.b[i]))
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.a[j] == paramInt; j--) {
      if (paramObject.equals(this.b[j]))
        return j; 
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof Set) {
      paramObject = paramObject;
      if (size() != paramObject.size())
        return false; 
      int i = 0;
      try {
        while (i < this.c) {
          boolean bool = paramObject.contains(j(i));
          if (!bool)
            return false; 
          i++;
        } 
        return true;
      } catch (NullPointerException|ClassCastException nullPointerException) {
        return false;
      } 
    } 
    return false;
  }
  
  public final int g() {
    int j = this.c;
    if (j == 0)
      return -1; 
    int k = c.a(this.a, j, 0);
    if (k < 0)
      return k; 
    if (this.b[k] == null)
      return k; 
    int i;
    for (i = k + 1; i < j && this.a[i] == 0; i++) {
      if (this.b[i] == null)
        return i; 
    } 
    for (j = k - 1; j >= 0 && this.a[j] == 0; j--) {
      if (this.b[j] == null)
        return j; 
    } 
    return i ^ 0xFFFFFFFF;
  }
  
  public int hashCode() {
    int[] arrayOfInt = this.a;
    int k = this.c;
    int i = 0;
    int j = 0;
    while (i < k) {
      j += arrayOfInt[i];
      i++;
    } 
    return j;
  }
  
  public E i(int paramInt) {
    Object[] arrayOfObject = this.b;
    Object object = arrayOfObject[paramInt];
    int j = this.c;
    if (j <= 1) {
      c(this.a, arrayOfObject, j);
      this.a = e;
      this.b = f;
      this.c = 0;
      return (E)object;
    } 
    int[] arrayOfInt = this.a;
    int k = arrayOfInt.length;
    int i = 8;
    if (k > 8 && j < arrayOfInt.length / 3) {
      if (j > 8)
        i = j + (j >> 1); 
      a(i);
      this.c--;
      if (paramInt > 0) {
        System.arraycopy(arrayOfInt, 0, this.a, 0, paramInt);
        System.arraycopy(arrayOfObject, 0, this.b, 0, paramInt);
      } 
      i = this.c;
      if (paramInt < i) {
        j = paramInt + 1;
        System.arraycopy(arrayOfInt, j, this.a, paramInt, i - paramInt);
        System.arraycopy(arrayOfObject, j, this.b, paramInt, this.c - paramInt);
        return (E)object;
      } 
    } else {
      i = j - 1;
      this.c = i;
      if (paramInt < i) {
        j = paramInt + 1;
        System.arraycopy(arrayOfInt, j, arrayOfInt, paramInt, i - paramInt);
        arrayOfObject = this.b;
        System.arraycopy(arrayOfObject, j, arrayOfObject, paramInt, this.c - paramInt);
      } 
      this.b[this.c] = null;
    } 
    return (E)object;
  }
  
  public int indexOf(Object paramObject) {
    return (paramObject == null) ? g() : e(paramObject, paramObject.hashCode());
  }
  
  public boolean isEmpty() {
    return (this.c <= 0);
  }
  
  public Iterator<E> iterator() {
    return d().m().iterator();
  }
  
  public E j(int paramInt) {
    return (E)this.b[paramInt];
  }
  
  public boolean remove(Object paramObject) {
    int i = indexOf(paramObject);
    if (i >= 0) {
      i(i);
      return true;
    } 
    return false;
  }
  
  public boolean removeAll(Collection<?> paramCollection) {
    Iterator<?> iterator = paramCollection.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= remove(iterator.next()));
    return bool;
  }
  
  public boolean retainAll(Collection<?> paramCollection) {
    int i = this.c - 1;
    boolean bool = false;
    while (i >= 0) {
      if (!paramCollection.contains(this.b[i])) {
        i(i);
        bool = true;
      } 
      i--;
    } 
    return bool;
  }
  
  public int size() {
    return this.c;
  }
  
  public Object[] toArray() {
    int i = this.c;
    Object[] arrayOfObject = new Object[i];
    System.arraycopy(this.b, 0, arrayOfObject, 0, i);
    return arrayOfObject;
  }
  
  public <T> T[] toArray(T[] paramArrayOfT) {
    T[] arrayOfT = paramArrayOfT;
    if (paramArrayOfT.length < this.c)
      arrayOfT = (T[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), this.c); 
    System.arraycopy(this.b, 0, arrayOfT, 0, this.c);
    int i = arrayOfT.length;
    int j = this.c;
    if (i > j)
      arrayOfT[j] = null; 
    return arrayOfT;
  }
  
  public String toString() {
    if (isEmpty())
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.c * 14);
    stringBuilder.append('{');
    for (int i = 0; i < this.c; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      E e = j(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Set)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public class a extends f<E, E> {
    public a(b this$0) {}
    
    public void a() {
      this.d.clear();
    }
    
    public Object b(int param1Int1, int param1Int2) {
      return this.d.b[param1Int1];
    }
    
    public Map<E, E> c() {
      throw new UnsupportedOperationException("not a map");
    }
    
    public int d() {
      return this.d.c;
    }
    
    public int e(Object param1Object) {
      return this.d.indexOf(param1Object);
    }
    
    public int f(Object param1Object) {
      return this.d.indexOf(param1Object);
    }
    
    public void g(E param1E1, E param1E2) {
      this.d.add(param1E1);
    }
    
    public void h(int param1Int) {
      this.d.i(param1Int);
    }
    
    public E i(int param1Int, E param1E) {
      throw new UnsupportedOperationException("not a map");
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */