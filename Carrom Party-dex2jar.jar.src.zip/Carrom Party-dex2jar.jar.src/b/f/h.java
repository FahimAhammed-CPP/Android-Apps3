package b.f;

public class h<E> implements Cloneable {
  public static final Object e = new Object();
  
  public boolean a = false;
  
  public int[] b;
  
  public Object[] c;
  
  public int d;
  
  public h() {
    this(10);
  }
  
  public h(int paramInt) {
    if (paramInt == 0) {
      this.b = c.a;
      this.c = c.c;
      return;
    } 
    paramInt = c.e(paramInt);
    this.b = new int[paramInt];
    this.c = new Object[paramInt];
  }
  
  public void c(int paramInt, E paramE) {
    int i = this.d;
    if (i != 0 && paramInt <= this.b[i - 1]) {
      s(paramInt, paramE);
      return;
    } 
    if (this.a && i >= this.b.length)
      h(); 
    i = this.d;
    if (i >= this.b.length) {
      int j = c.e(i + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.b;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.c;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.b = arrayOfInt1;
      this.c = arrayOfObject1;
    } 
    this.b[i] = paramInt;
    this.c[i] = paramE;
    this.d = i + 1;
  }
  
  public void e() {
    int j = this.d;
    Object[] arrayOfObject = this.c;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.d = 0;
    this.a = false;
  }
  
  public h<E> f() {
    try {
      h<E> h1 = (h)super.clone();
      h1.b = (int[])this.b.clone();
      h1.c = (Object[])this.c.clone();
      return h1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public final void h() {
    int k = this.d;
    int[] arrayOfInt = this.b;
    Object[] arrayOfObject = this.c;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != e) {
        if (i != j) {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.a = false;
    this.d = j;
  }
  
  public E o(int paramInt) {
    return q(paramInt, null);
  }
  
  public E q(int paramInt, E paramE) {
    paramInt = c.a(this.b, this.d, paramInt);
    if (paramInt >= 0) {
      Object[] arrayOfObject = this.c;
      return (E)((arrayOfObject[paramInt] == e) ? (Object)paramE : arrayOfObject[paramInt]);
    } 
    return paramE;
  }
  
  public int r(int paramInt) {
    if (this.a)
      h(); 
    return this.b[paramInt];
  }
  
  public void s(int paramInt, E paramE) {
    int i = c.a(this.b, this.d, paramInt);
    if (i >= 0) {
      this.c[i] = paramE;
      return;
    } 
    int j = i ^ 0xFFFFFFFF;
    int k = this.d;
    if (j < k) {
      Object[] arrayOfObject = this.c;
      if (arrayOfObject[j] == e) {
        this.b[j] = paramInt;
        arrayOfObject[j] = paramE;
        return;
      } 
    } 
    i = j;
    if (this.a) {
      i = j;
      if (k >= this.b.length) {
        h();
        i = c.a(this.b, this.d, paramInt) ^ 0xFFFFFFFF;
      } 
    } 
    j = this.d;
    if (j >= this.b.length) {
      j = c.e(j + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.b;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.c;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.b = arrayOfInt1;
      this.c = arrayOfObject1;
    } 
    j = this.d;
    if (j - i != 0) {
      int[] arrayOfInt = this.b;
      k = i + 1;
      System.arraycopy(arrayOfInt, i, arrayOfInt, k, j - i);
      Object[] arrayOfObject = this.c;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.d - i);
    } 
    this.b[i] = paramInt;
    this.c[i] = paramE;
    this.d++;
  }
  
  public int t() {
    if (this.a)
      h(); 
    return this.d;
  }
  
  public String toString() {
    if (t() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.d * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.d; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(r(i));
      stringBuilder.append('=');
      E e = u(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public E u(int paramInt) {
    if (this.a)
      h(); 
    return (E)this.c[paramInt];
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\f\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */