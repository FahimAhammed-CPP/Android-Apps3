package b.k;

public final class b {
  public static final int a = 2131296402;
  
  public static final int b = 2131296497;
  
  public static final int c = 2131296543;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */