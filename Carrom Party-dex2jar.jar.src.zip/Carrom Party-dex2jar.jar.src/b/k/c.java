package b.k;

public final class c {
  public static final int[] a = new int[] { 16842755, 16842960, 16842961 };
  
  public static final int b = 0;
  
  public static final int c = 1;
  
  public static final int d = 2;
  
  public static final int[] e = new int[] { 16842755, 16842961 };
  
  public static final int f = 0;
  
  public static final int g = 1;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */