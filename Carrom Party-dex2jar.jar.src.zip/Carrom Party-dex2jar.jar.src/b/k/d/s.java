package b.k.d;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import b.h.e.o;
import b.h.n.p;
import b.h.n.r;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class s {
  public static final int[] a = new int[] { 
      0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 
      10 };
  
  public static final u b;
  
  public static final u c = x();
  
  public static void A(u paramu, Object paramObject1, Object paramObject2, b.f.a<String, View> parama, boolean paramBoolean, a parama1) {
    ArrayList<String> arrayList = parama1.m;
    if (arrayList != null && !arrayList.isEmpty()) {
      String str;
      if (paramBoolean) {
        str = parama1.n.get(0);
      } else {
        str = ((r)str).m.get(0);
      } 
      View view = (View)parama.get(str);
      paramu.v(paramObject1, view);
      if (paramObject2 != null)
        paramu.v(paramObject2, view); 
    } 
  }
  
  public static void B(ArrayList<View> paramArrayList, int paramInt) {
    if (paramArrayList == null)
      return; 
    for (int i = paramArrayList.size() - 1; i >= 0; i--)
      ((View)paramArrayList.get(i)).setVisibility(paramInt); 
  }
  
  public static void C(Context paramContext, f paramf, ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, boolean paramBoolean, g paramg) {
    SparseArray<h> sparseArray = new SparseArray();
    int i;
    for (i = paramInt1; i < paramInt2; i++) {
      a a = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue()) {
        e(a, sparseArray, paramBoolean);
      } else {
        c(a, sparseArray, paramBoolean);
      } 
    } 
    if (sparseArray.size() != 0) {
      View view = new View(paramContext);
      int j = sparseArray.size();
      for (i = 0; i < j; i++) {
        int k = sparseArray.keyAt(i);
        b.f.a<String, String> a = d(k, paramArrayList, paramArrayList1, paramInt1, paramInt2);
        h h = (h)sparseArray.valueAt(i);
        if (paramf.g()) {
          ViewGroup viewGroup = (ViewGroup)paramf.e(k);
          if (viewGroup != null)
            if (paramBoolean) {
              o(viewGroup, h, view, a, paramg);
            } else {
              n(viewGroup, h, view, a, paramg);
            }  
        } 
      } 
    } 
  }
  
  public static void a(ArrayList<View> paramArrayList, b.f.a<String, View> parama, Collection<String> paramCollection) {
    for (int i = parama.size() - 1; i >= 0; i--) {
      View view = (View)parama.m(i);
      if (paramCollection.contains(r.v(view)))
        paramArrayList.add(view); 
    } 
  }
  
  public static void b(a parama, r.a parama1, SparseArray<h> paramSparseArray, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Landroidx/fragment/app/Fragment;
    //   4: astore #12
    //   6: aload #12
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload #12
    //   14: getfield I : I
    //   17: istore #8
    //   19: iload #8
    //   21: ifne -> 25
    //   24: return
    //   25: iload_3
    //   26: ifeq -> 42
    //   29: getstatic b/k/d/s.a : [I
    //   32: aload_1
    //   33: getfield a : I
    //   36: iaload
    //   37: istore #5
    //   39: goto -> 48
    //   42: aload_1
    //   43: getfield a : I
    //   46: istore #5
    //   48: iconst_0
    //   49: istore #10
    //   51: iconst_0
    //   52: istore #9
    //   54: iconst_1
    //   55: istore #6
    //   57: iload #5
    //   59: iconst_1
    //   60: if_icmpeq -> 288
    //   63: iload #5
    //   65: iconst_3
    //   66: if_icmpeq -> 200
    //   69: iload #5
    //   71: iconst_4
    //   72: if_icmpeq -> 149
    //   75: iload #5
    //   77: iconst_5
    //   78: if_icmpeq -> 107
    //   81: iload #5
    //   83: bipush #6
    //   85: if_icmpeq -> 200
    //   88: iload #5
    //   90: bipush #7
    //   92: if_icmpeq -> 288
    //   95: iconst_0
    //   96: istore #5
    //   98: iconst_0
    //   99: istore #7
    //   101: iconst_0
    //   102: istore #6
    //   104: goto -> 335
    //   107: iload #4
    //   109: ifeq -> 139
    //   112: aload #12
    //   114: getfield X : Z
    //   117: ifeq -> 325
    //   120: aload #12
    //   122: getfield K : Z
    //   125: ifne -> 325
    //   128: aload #12
    //   130: getfield l : Z
    //   133: ifeq -> 325
    //   136: goto -> 319
    //   139: aload #12
    //   141: getfield K : Z
    //   144: istore #9
    //   146: goto -> 328
    //   149: iload #4
    //   151: ifeq -> 181
    //   154: aload #12
    //   156: getfield X : Z
    //   159: ifeq -> 246
    //   162: aload #12
    //   164: getfield l : Z
    //   167: ifeq -> 246
    //   170: aload #12
    //   172: getfield K : Z
    //   175: ifeq -> 246
    //   178: goto -> 240
    //   181: aload #12
    //   183: getfield l : Z
    //   186: ifeq -> 246
    //   189: aload #12
    //   191: getfield K : Z
    //   194: ifne -> 246
    //   197: goto -> 178
    //   200: iload #4
    //   202: ifeq -> 252
    //   205: aload #12
    //   207: getfield l : Z
    //   210: ifne -> 246
    //   213: aload #12
    //   215: getfield S : Landroid/view/View;
    //   218: astore_1
    //   219: aload_1
    //   220: ifnull -> 246
    //   223: aload_1
    //   224: invokevirtual getVisibility : ()I
    //   227: ifne -> 246
    //   230: aload #12
    //   232: getfield Y : F
    //   235: fconst_0
    //   236: fcmpl
    //   237: iflt -> 246
    //   240: iconst_1
    //   241: istore #5
    //   243: goto -> 271
    //   246: iconst_0
    //   247: istore #5
    //   249: goto -> 271
    //   252: aload #12
    //   254: getfield l : Z
    //   257: ifeq -> 246
    //   260: aload #12
    //   262: getfield K : Z
    //   265: ifne -> 246
    //   268: goto -> 240
    //   271: iload #5
    //   273: istore #6
    //   275: iconst_1
    //   276: istore #7
    //   278: iconst_0
    //   279: istore #5
    //   281: iload #10
    //   283: istore #9
    //   285: goto -> 335
    //   288: iload #4
    //   290: ifeq -> 303
    //   293: aload #12
    //   295: getfield W : Z
    //   298: istore #9
    //   300: goto -> 328
    //   303: aload #12
    //   305: getfield l : Z
    //   308: ifne -> 325
    //   311: aload #12
    //   313: getfield K : Z
    //   316: ifne -> 325
    //   319: iconst_1
    //   320: istore #9
    //   322: goto -> 328
    //   325: iconst_0
    //   326: istore #9
    //   328: iload #6
    //   330: istore #5
    //   332: goto -> 98
    //   335: aload_2
    //   336: iload #8
    //   338: invokevirtual get : (I)Ljava/lang/Object;
    //   341: checkcast b/k/d/s$h
    //   344: astore #11
    //   346: aload #11
    //   348: astore_1
    //   349: iload #9
    //   351: ifeq -> 379
    //   354: aload #11
    //   356: aload_2
    //   357: iload #8
    //   359: invokestatic p : (Lb/k/d/s$h;Landroid/util/SparseArray;I)Lb/k/d/s$h;
    //   362: astore_1
    //   363: aload_1
    //   364: aload #12
    //   366: putfield a : Landroidx/fragment/app/Fragment;
    //   369: aload_1
    //   370: iload_3
    //   371: putfield b : Z
    //   374: aload_1
    //   375: aload_0
    //   376: putfield c : Lb/k/d/a;
    //   379: iload #4
    //   381: ifne -> 446
    //   384: iload #5
    //   386: ifeq -> 446
    //   389: aload_1
    //   390: ifnull -> 407
    //   393: aload_1
    //   394: getfield d : Landroidx/fragment/app/Fragment;
    //   397: aload #12
    //   399: if_acmpne -> 407
    //   402: aload_1
    //   403: aconst_null
    //   404: putfield d : Landroidx/fragment/app/Fragment;
    //   407: aload_0
    //   408: getfield o : Z
    //   411: ifne -> 446
    //   414: aload_0
    //   415: getfield q : Landroidx/fragment/app/FragmentManager;
    //   418: astore #11
    //   420: aload #11
    //   422: aload #12
    //   424: invokevirtual w : (Landroidx/fragment/app/Fragment;)Lb/k/d/p;
    //   427: astore #13
    //   429: aload #11
    //   431: invokevirtual r0 : ()Lb/k/d/q;
    //   434: aload #13
    //   436: invokevirtual p : (Lb/k/d/p;)V
    //   439: aload #11
    //   441: aload #12
    //   443: invokevirtual O0 : (Landroidx/fragment/app/Fragment;)V
    //   446: aload_1
    //   447: astore #11
    //   449: iload #6
    //   451: ifeq -> 496
    //   454: aload_1
    //   455: ifnull -> 468
    //   458: aload_1
    //   459: astore #11
    //   461: aload_1
    //   462: getfield d : Landroidx/fragment/app/Fragment;
    //   465: ifnonnull -> 496
    //   468: aload_1
    //   469: aload_2
    //   470: iload #8
    //   472: invokestatic p : (Lb/k/d/s$h;Landroid/util/SparseArray;I)Lb/k/d/s$h;
    //   475: astore #11
    //   477: aload #11
    //   479: aload #12
    //   481: putfield d : Landroidx/fragment/app/Fragment;
    //   484: aload #11
    //   486: iload_3
    //   487: putfield e : Z
    //   490: aload #11
    //   492: aload_0
    //   493: putfield f : Lb/k/d/a;
    //   496: iload #4
    //   498: ifne -> 527
    //   501: iload #7
    //   503: ifeq -> 527
    //   506: aload #11
    //   508: ifnull -> 527
    //   511: aload #11
    //   513: getfield a : Landroidx/fragment/app/Fragment;
    //   516: aload #12
    //   518: if_acmpne -> 527
    //   521: aload #11
    //   523: aconst_null
    //   524: putfield a : Landroidx/fragment/app/Fragment;
    //   527: return
  }
  
  public static void c(a parama, SparseArray<h> paramSparseArray, boolean paramBoolean) {
    int j = parama.a.size();
    for (int i = 0; i < j; i++)
      b(parama, parama.a.get(i), paramSparseArray, false, paramBoolean); 
  }
  
  public static b.f.a<String, String> d(int paramInt1, ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt2, int paramInt3) {
    b.f.a<String, String> a = new b.f.a();
    while (--paramInt3 >= paramInt2) {
      a a1 = paramArrayList.get(paramInt3);
      if (a1.u(paramInt1)) {
        boolean bool = ((Boolean)paramArrayList1.get(paramInt3)).booleanValue();
        ArrayList<String> arrayList = a1.m;
        if (arrayList != null) {
          ArrayList<String> arrayList1;
          int j = arrayList.size();
          if (bool) {
            arrayList1 = a1.m;
            arrayList = a1.n;
          } else {
            arrayList = a1.m;
            arrayList1 = a1.n;
          } 
          int i;
          for (i = 0; i < j; i++) {
            String str1 = arrayList.get(i);
            String str2 = arrayList1.get(i);
            String str3 = (String)a.remove(str2);
            if (str3 != null) {
              a.put(str1, str3);
            } else {
              a.put(str1, str2);
            } 
          } 
        } 
      } 
      paramInt3--;
    } 
    return a;
  }
  
  public static void e(a parama, SparseArray<h> paramSparseArray, boolean paramBoolean) {
    if (!parama.q.o0().g())
      return; 
    for (int i = parama.a.size() - 1; i >= 0; i--)
      b(parama, parama.a.get(i), paramSparseArray, true, paramBoolean); 
  }
  
  public static void f(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean1, b.f.a<String, View> parama, boolean paramBoolean2) {
    o o;
    if (paramBoolean1) {
      o = paramFragment2.v();
    } else {
      o = o.v();
    } 
    if (o != null) {
      int i;
      ArrayList<Object> arrayList1 = new ArrayList();
      ArrayList<Object> arrayList2 = new ArrayList();
      int j = 0;
      if (parama == null) {
        i = 0;
      } else {
        i = parama.size();
      } 
      while (j < i) {
        arrayList2.add(parama.i(j));
        arrayList1.add(parama.m(j));
        j++;
      } 
      if (paramBoolean2) {
        o.c(arrayList2, arrayList1, null);
        return;
      } 
      o.b(arrayList2, arrayList1, null);
    } 
  }
  
  public static boolean g(u paramu, List<Object> paramList) {
    int j = paramList.size();
    for (int i = 0; i < j; i++) {
      if (!paramu.e(paramList.get(i)))
        return false; 
    } 
    return true;
  }
  
  public static b.f.a<String, View> h(u paramu, b.f.a<String, String> parama, Object paramObject, h paramh) {
    ArrayList<String> arrayList;
    Fragment fragment = paramh.a;
    View view = fragment.W();
    if (parama.isEmpty() || paramObject == null || view == null) {
      parama.clear();
      return null;
    } 
    b.f.a<String, View> a2 = new b.f.a();
    paramu.j((Map<String, View>)a2, view);
    a a1 = paramh.c;
    if (paramh.b) {
      paramObject = fragment.x();
      arrayList = a1.m;
    } else {
      paramObject = fragment.v();
      arrayList = ((r)arrayList).n;
    } 
    if (arrayList != null) {
      a2.o(arrayList);
      a2.o(parama.values());
    } 
    if (paramObject != null) {
      paramObject.a(arrayList, (Map)a2);
      int i;
      for (i = arrayList.size() - 1; i >= 0; i--) {
        String str = arrayList.get(i);
        paramObject = a2.get(str);
        if (paramObject == null) {
          paramObject = q(parama, str);
          if (paramObject != null)
            parama.remove(paramObject); 
        } else if (!str.equals(r.v((View)paramObject))) {
          str = q(parama, str);
          if (str != null)
            parama.put(str, r.v((View)paramObject)); 
        } 
      } 
    } else {
      y(parama, a2);
    } 
    return a2;
  }
  
  public static b.f.a<String, View> i(u paramu, b.f.a<String, String> parama, Object paramObject, h paramh) {
    ArrayList<String> arrayList;
    if (parama.isEmpty() || paramObject == null) {
      parama.clear();
      return null;
    } 
    paramObject = paramh.d;
    b.f.a<String, View> a2 = new b.f.a();
    paramu.j((Map<String, View>)a2, paramObject.x1());
    a a1 = paramh.f;
    if (paramh.e) {
      paramObject = paramObject.v();
      arrayList = a1.n;
    } else {
      paramObject = paramObject.x();
      arrayList = ((r)arrayList).m;
    } 
    if (arrayList != null)
      a2.o(arrayList); 
    if (paramObject != null) {
      paramObject.a(arrayList, (Map)a2);
      int i;
      for (i = arrayList.size() - 1; i >= 0; i--) {
        String str = arrayList.get(i);
        paramObject = a2.get(str);
        if (paramObject == null) {
          parama.remove(str);
        } else if (!str.equals(r.v((View)paramObject))) {
          str = (String)parama.remove(str);
          parama.put(r.v((View)paramObject), str);
        } 
      } 
    } else {
      parama.o(a2.keySet());
    } 
    return a2;
  }
  
  public static u j(Fragment paramFragment1, Fragment paramFragment2) {
    ArrayList<Object> arrayList = new ArrayList();
    if (paramFragment1 != null) {
      Object object2 = paramFragment1.w();
      if (object2 != null)
        arrayList.add(object2); 
      object2 = paramFragment1.M();
      if (object2 != null)
        arrayList.add(object2); 
      Object object1 = paramFragment1.O();
      if (object1 != null)
        arrayList.add(object1); 
    } 
    if (paramFragment2 != null) {
      Object object = paramFragment2.u();
      if (object != null)
        arrayList.add(object); 
      object = paramFragment2.J();
      if (object != null)
        arrayList.add(object); 
      object = paramFragment2.N();
      if (object != null)
        arrayList.add(object); 
    } 
    if (arrayList.isEmpty())
      return null; 
    u u1 = b;
    if (u1 != null && g(u1, arrayList))
      return u1; 
    u u2 = c;
    if (u2 != null && g(u2, arrayList))
      return u2; 
    if (u1 == null && u2 == null)
      return null; 
    throw new IllegalArgumentException("Invalid Transition types");
  }
  
  public static ArrayList<View> k(u paramu, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList, View paramView) {
    if (paramObject != null) {
      ArrayList<View> arrayList2 = new ArrayList();
      View view = paramFragment.W();
      if (view != null)
        paramu.f(arrayList2, view); 
      if (paramArrayList != null)
        arrayList2.removeAll(paramArrayList); 
      ArrayList<View> arrayList1 = arrayList2;
      if (!arrayList2.isEmpty()) {
        arrayList2.add(paramView);
        paramu.b(paramObject, arrayList2);
        return arrayList2;
      } 
    } else {
      paramFragment = null;
    } 
    return (ArrayList<View>)paramFragment;
  }
  
  public static Object l(u paramu, ViewGroup paramViewGroup, View paramView, b.f.a<String, String> parama, h paramh, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    Fragment fragment1 = paramh.a;
    Fragment fragment2 = paramh.d;
    if (fragment1 != null) {
      Object object;
      if (fragment2 == null)
        return null; 
      boolean bool = paramh.b;
      if (parama.isEmpty()) {
        object = null;
      } else {
        object = u(paramu, fragment1, fragment2, bool);
      } 
      b.f.a<String, View> a1 = i(paramu, parama, object, paramh);
      if (parama.isEmpty()) {
        object = null;
      } else {
        paramArrayList1.addAll(a1.values());
      } 
      if (paramObject1 == null && paramObject2 == null && object == null)
        return null; 
      f(fragment1, fragment2, bool, a1, true);
      if (object != null) {
        Rect rect = new Rect();
        paramu.z(object, paramView, paramArrayList1);
        A(paramu, object, paramObject2, a1, paramh.e, paramh.f);
        paramObject2 = rect;
        if (paramObject1 != null) {
          paramu.u(paramObject1, rect);
          paramObject2 = rect;
        } 
      } else {
        paramObject2 = null;
      } 
      p.a((View)paramViewGroup, new f(paramu, parama, object, paramh, paramArrayList2, paramView, fragment1, fragment2, bool, paramArrayList1, paramObject1, (Rect)paramObject2));
      return object;
    } 
    return null;
  }
  
  public static Object m(u paramu, ViewGroup paramViewGroup, View paramView, b.f.a<String, String> parama, h paramh, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    Fragment fragment1 = paramh.a;
    Fragment fragment2 = paramh.d;
    if (fragment1 != null)
      fragment1.x1().setVisibility(0); 
    if (fragment1 != null) {
      Object object1;
      View view1;
      View view2;
      Object object2;
      if (fragment2 == null)
        return null; 
      boolean bool = paramh.b;
      if (parama.isEmpty()) {
        object2 = null;
      } else {
        object2 = u(paramu, fragment1, fragment2, bool);
      } 
      b.f.a<String, View> a2 = i(paramu, parama, object2, paramh);
      b.f.a<String, View> a1 = h(paramu, parama, object2, paramh);
      if (parama.isEmpty()) {
        if (a2 != null)
          a2.clear(); 
        if (a1 != null)
          a1.clear(); 
        parama = null;
      } else {
        a(paramArrayList1, a2, parama.keySet());
        a(paramArrayList2, a1, parama.values());
        object1 = object2;
      } 
      if (paramObject1 == null && paramObject2 == null && object1 == null)
        return null; 
      f(fragment1, fragment2, bool, a2, true);
      if (object1 != null) {
        paramArrayList2.add(paramView);
        paramu.z(object1, paramView, paramArrayList1);
        A(paramu, object1, paramObject2, a2, paramh.e, paramh.f);
        Rect rect1 = new Rect();
        view1 = t(a1, paramh, paramObject1, bool);
        if (view1 != null)
          paramu.u(paramObject1, rect1); 
        Rect rect2 = rect1;
      } else {
        paramView = null;
        view2 = paramView;
        view1 = paramView;
      } 
      p.a((View)paramViewGroup, new e(fragment1, fragment2, bool, a1, view1, paramu, (Rect)view2));
      return object1;
    } 
    return null;
  }
  
  public static void n(ViewGroup paramViewGroup, h paramh, View paramView, b.f.a<String, String> parama, g paramg) {
    Fragment fragment1 = paramh.a;
    Fragment fragment2 = paramh.d;
    u u1 = j(fragment2, fragment1);
    if (u1 == null)
      return; 
    boolean bool1 = paramh.b;
    boolean bool2 = paramh.e;
    Object object3 = r(u1, fragment1, bool1);
    Object object2 = s(u1, fragment2, bool2);
    ArrayList<View> arrayList3 = new ArrayList();
    ArrayList<View> arrayList1 = new ArrayList();
    Object object4 = l(u1, paramViewGroup, paramView, parama, paramh, arrayList3, arrayList1, object3, object2);
    if (object3 == null && object4 == null && object2 == null)
      return; 
    ArrayList<View> arrayList2 = k(u1, object2, fragment2, arrayList3, paramView);
    if (arrayList2 == null || arrayList2.isEmpty())
      object2 = null; 
    u1.a(object3, paramView);
    Object object1 = v(u1, object3, object2, object4, fragment1, paramh.b);
    if (fragment2 != null && arrayList2 != null && (arrayList2.size() > 0 || arrayList3.size() > 0)) {
      b.h.j.b b = new b.h.j.b();
      paramg.b(fragment2, b);
      u1.w(fragment2, object1, b, new c(paramg, fragment2, b));
    } 
    if (object1 != null) {
      ArrayList<View> arrayList = new ArrayList();
      u1.t(object1, object3, arrayList, object2, arrayList2, object4, arrayList1);
      z(u1, paramViewGroup, fragment1, paramView, arrayList1, object3, arrayList, object2, arrayList2);
      u1.x((View)paramViewGroup, arrayList1, (Map<String, String>)parama);
      u1.c(paramViewGroup, object1);
      u1.s(paramViewGroup, arrayList1, (Map<String, String>)parama);
    } 
  }
  
  public static void o(ViewGroup paramViewGroup, h paramh, View paramView, b.f.a<String, String> parama, g paramg) {
    Fragment fragment2 = paramh.a;
    Fragment fragment1 = paramh.d;
    u u1 = j(fragment1, fragment2);
    if (u1 == null)
      return; 
    boolean bool1 = paramh.b;
    boolean bool2 = paramh.e;
    ArrayList<View> arrayList2 = new ArrayList();
    ArrayList<View> arrayList3 = new ArrayList();
    Object object3 = r(u1, fragment2, bool1);
    Object<View> object2 = (Object<View>)s(u1, fragment1, bool2);
    Object object4 = m(u1, paramViewGroup, paramView, parama, paramh, arrayList3, arrayList2, object3, object2);
    if (object3 == null && object4 == null && object2 == null)
      return; 
    Object<View> object1 = object2;
    object2 = (Object<View>)k(u1, object1, fragment1, arrayList3, paramView);
    ArrayList<View> arrayList1 = k(u1, object3, fragment2, arrayList2, paramView);
    B(arrayList1, 4);
    Object object5 = v(u1, object3, object1, object4, fragment2, bool1);
    if (fragment1 != null && object2 != null && (object2.size() > 0 || arrayList3.size() > 0)) {
      b.h.j.b b = new b.h.j.b();
      paramg.b(fragment1, b);
      u1.w(fragment1, object5, b, new a(paramg, fragment1, b));
    } 
    if (object5 != null) {
      w(u1, object1, fragment1, (ArrayList<View>)object2);
      ArrayList<String> arrayList = u1.o(arrayList2);
      u1.t(object5, object3, arrayList1, object1, (ArrayList<View>)object2, object4, arrayList2);
      u1.c(paramViewGroup, object5);
      u1.y((View)paramViewGroup, arrayList3, arrayList2, arrayList, (Map<String, String>)parama);
      B(arrayList1, 0);
      u1.A(object4, arrayList3, arrayList2);
    } 
  }
  
  public static h p(h paramh, SparseArray<h> paramSparseArray, int paramInt) {
    h h1 = paramh;
    if (paramh == null) {
      h1 = new h();
      paramSparseArray.put(paramInt, h1);
    } 
    return h1;
  }
  
  public static String q(b.f.a<String, String> parama, String paramString) {
    int j = parama.size();
    for (int i = 0; i < j; i++) {
      if (paramString.equals(parama.m(i)))
        return (String)parama.i(i); 
    } 
    return null;
  }
  
  public static Object r(u paramu, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.J();
    } else {
      object = object.u();
    } 
    return paramu.g(object);
  }
  
  public static Object s(u paramu, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.M();
    } else {
      object = object.w();
    } 
    return paramu.g(object);
  }
  
  public static View t(b.f.a<String, View> parama, h paramh, Object<String> paramObject, boolean paramBoolean) {
    a a1 = paramh.c;
    if (paramObject != null && parama != null) {
      paramObject = (Object<String>)a1.m;
      if (paramObject != null && !paramObject.isEmpty()) {
        String str;
        if (paramBoolean) {
          str = a1.m.get(0);
        } else {
          str = ((r)str).n.get(0);
        } 
        return (View)parama.get(str);
      } 
    } 
    return null;
  }
  
  public static Object u(u paramu, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean) {
    Object object;
    if (paramFragment1 == null || paramFragment2 == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment2.O();
    } else {
      object = object.N();
    } 
    return paramu.B(paramu.g(object));
  }
  
  public static Object v(u paramu, Object paramObject1, Object paramObject2, Object paramObject3, Fragment paramFragment, boolean paramBoolean) {
    if (paramObject1 != null && paramObject2 != null && paramFragment != null) {
      if (paramBoolean) {
        paramBoolean = paramFragment.o();
      } else {
        paramBoolean = paramFragment.n();
      } 
    } else {
      paramBoolean = true;
    } 
    return paramBoolean ? paramu.n(paramObject2, paramObject1, paramObject3) : paramu.m(paramObject2, paramObject1, paramObject3);
  }
  
  public static void w(u paramu, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList) {
    if (paramFragment != null && paramObject != null && paramFragment.l && paramFragment.K && paramFragment.X) {
      paramFragment.G1(true);
      paramu.r(paramObject, paramFragment.W(), paramArrayList);
      p.a((View)paramFragment.R, new b(paramArrayList));
    } 
  }
  
  public static u x() {
    try {
      return Class.forName("androidx.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static void y(b.f.a<String, String> parama, b.f.a<String, View> parama1) {
    for (int i = parama.size() - 1; i >= 0; i--) {
      if (!parama1.containsKey(parama.m(i)))
        parama.k(i); 
    } 
  }
  
  public static void z(u paramu, ViewGroup paramViewGroup, Fragment paramFragment, View paramView, ArrayList<View> paramArrayList1, Object paramObject1, ArrayList<View> paramArrayList2, Object paramObject2, ArrayList<View> paramArrayList3) {
    p.a((View)paramViewGroup, new d(paramObject1, paramu, paramView, paramFragment, paramArrayList1, paramArrayList2, paramArrayList3, paramObject2));
  }
  
  static {
    u u1;
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 21) {
      u1 = new t();
    } else {
      u1 = null;
    } 
    b = u1;
  }
  
  public class a implements Runnable {
    public a(s this$0, Fragment param1Fragment, b.h.j.b param1b) {}
    
    public void run() {
      this.a.a(this.b, this.c);
    }
  }
  
  public class b implements Runnable {
    public b(s this$0) {}
    
    public void run() {
      s.B(this.a, 4);
    }
  }
  
  public class c implements Runnable {
    public c(s this$0, Fragment param1Fragment, b.h.j.b param1b) {}
    
    public void run() {
      this.a.a(this.b, this.c);
    }
  }
  
  public class d implements Runnable {
    public d(s this$0, u param1u, View param1View, Fragment param1Fragment, ArrayList param1ArrayList1, ArrayList param1ArrayList2, ArrayList param1ArrayList3, Object param1Object1) {}
    
    public void run() {
      Object<View> object = (Object<View>)this.a;
      if (object != null) {
        this.b.p(object, this.c);
        object = (Object<View>)s.k(this.b, this.a, this.d, this.e, this.c);
        this.f.addAll((Collection<? extends View>)object);
      } 
      if (this.g != null) {
        if (this.h != null) {
          object = (Object<View>)new ArrayList();
          object.add(this.c);
          this.b.q(this.h, this.g, (ArrayList<View>)object);
        } 
        this.g.clear();
        this.g.add(this.c);
      } 
    }
  }
  
  public class e implements Runnable {
    public e(s this$0, Fragment param1Fragment1, boolean param1Boolean, b.f.a param1a, View param1View, u param1u, Rect param1Rect) {}
    
    public void run() {
      s.f(this.a, this.b, this.c, this.d, false);
      View view = this.e;
      if (view != null)
        this.f.k(view, this.g); 
    }
  }
  
  public class f implements Runnable {
    public f(s this$0, b.f.a param1a, Object param1Object1, s.h param1h, ArrayList param1ArrayList1, View param1View, Fragment param1Fragment1, Fragment param1Fragment2, boolean param1Boolean, ArrayList param1ArrayList2, Object param1Object2, Rect param1Rect) {}
    
    public void run() {
      b.f.a<String, View> a1 = s.h(this.a, this.b, this.c, this.d);
      if (a1 != null) {
        this.e.addAll(a1.values());
        this.e.add(this.f);
      } 
      s.f(this.g, this.h, this.i, a1, false);
      Object object = this.c;
      if (object != null) {
        this.a.A(object, this.j, this.e);
        View view = s.t(a1, this.d, this.k, this.i);
        if (view != null)
          this.a.k(view, this.l); 
      } 
    }
  }
  
  public static interface g {
    void a(Fragment param1Fragment, b.h.j.b param1b);
    
    void b(Fragment param1Fragment, b.h.j.b param1b);
  }
  
  public static class h {
    public Fragment a;
    
    public boolean b;
    
    public a c;
    
    public Fragment d;
    
    public boolean e;
    
    public a f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */