package b.k.d;

import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import b.n.d;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public abstract class r {
  public ArrayList<a> a = new ArrayList<a>();
  
  public int b;
  
  public int c;
  
  public int d;
  
  public int e;
  
  public int f;
  
  public boolean g;
  
  public String h;
  
  public int i;
  
  public CharSequence j;
  
  public int k;
  
  public CharSequence l;
  
  public ArrayList<String> m;
  
  public ArrayList<String> n;
  
  public boolean o = false;
  
  public ArrayList<Runnable> p;
  
  public r(h paramh, ClassLoader paramClassLoader) {}
  
  public r b(int paramInt, Fragment paramFragment, String paramString) {
    j(paramInt, paramFragment, paramString, 1);
    return this;
  }
  
  public r c(ViewGroup paramViewGroup, Fragment paramFragment, String paramString) {
    paramFragment.R = paramViewGroup;
    b(paramViewGroup.getId(), paramFragment, paramString);
    return this;
  }
  
  public r d(Fragment paramFragment, String paramString) {
    j(0, paramFragment, paramString, 1);
    return this;
  }
  
  public void e(a parama) {
    this.a.add(parama);
    parama.c = this.b;
    parama.d = this.c;
    parama.e = this.d;
    parama.f = this.e;
  }
  
  public abstract int f();
  
  public abstract int g();
  
  public abstract void h();
  
  public r i() {
    if (!this.g)
      return this; 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  public void j(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    Class<?> clazz = paramFragment.getClass();
    int i = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(i) && (!clazz.isMemberClass() || Modifier.isStatic(i))) {
      if (paramString != null) {
        String str = paramFragment.J;
        if (str == null || paramString.equals(str)) {
          paramFragment.J = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(": was ");
          stringBuilder2.append(paramFragment.J);
          stringBuilder2.append(" now ");
          stringBuilder2.append(paramString);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          i = paramFragment.H;
          if (i == 0 || i == paramInt1) {
            paramFragment.H = paramInt1;
            paramFragment.I = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramFragment);
            stringBuilder.append(": was ");
            stringBuilder.append(paramFragment.H);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      e(new a(paramInt2, paramFragment));
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  public r k(Fragment paramFragment) {
    e(new a(3, paramFragment));
    return this;
  }
  
  public r l(boolean paramBoolean) {
    this.o = paramBoolean;
    return this;
  }
  
  public static final class a {
    public int a;
    
    public Fragment b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public d.c g;
    
    public d.c h;
    
    public a() {}
    
    public a(int param1Int, Fragment param1Fragment) {
      this.a = param1Int;
      this.b = param1Fragment;
      d.c c1 = d.c.e;
      this.g = c1;
      this.h = c1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */