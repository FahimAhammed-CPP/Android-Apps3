package b.k.d;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentState;
import b.h.n.r;
import b.n.d;

public class p {
  public final k a;
  
  public final q b;
  
  public final Fragment c;
  
  public boolean d = false;
  
  public int e = -1;
  
  public p(k paramk, q paramq, Fragment paramFragment) {
    this.a = paramk;
    this.b = paramq;
    this.c = paramFragment;
  }
  
  public p(k paramk, q paramq, Fragment paramFragment, FragmentState paramFragmentState) {
    this.a = paramk;
    this.b = paramq;
    this.c = paramFragment;
    paramFragment.c = null;
    paramFragment.d = null;
    paramFragment.C = 0;
    paramFragment.o = false;
    paramFragment.l = false;
    Fragment fragment = paramFragment.h;
    if (fragment != null) {
      String str = fragment.f;
    } else {
      fragment = null;
    } 
    paramFragment.i = (String)fragment;
    paramFragment.h = null;
    Bundle bundle = paramFragmentState.m;
    if (bundle != null) {
      paramFragment.b = bundle;
      return;
    } 
    paramFragment.b = new Bundle();
  }
  
  public p(k paramk, q paramq, ClassLoader paramClassLoader, h paramh, FragmentState paramFragmentState) {
    this.a = paramk;
    this.b = paramq;
    Fragment fragment = paramh.a(paramClassLoader, paramFragmentState.a);
    this.c = fragment;
    Bundle bundle = paramFragmentState.j;
    if (bundle != null)
      bundle.setClassLoader(paramClassLoader); 
    fragment.D1(paramFragmentState.j);
    fragment.f = paramFragmentState.b;
    fragment.n = paramFragmentState.c;
    fragment.p = true;
    fragment.H = paramFragmentState.d;
    fragment.I = paramFragmentState.e;
    fragment.J = paramFragmentState.f;
    fragment.M = paramFragmentState.g;
    fragment.m = paramFragmentState.h;
    fragment.L = paramFragmentState.i;
    fragment.K = paramFragmentState.k;
    fragment.b0 = d.c.values()[paramFragmentState.l];
    bundle = paramFragmentState.m;
    if (bundle != null) {
      fragment.b = bundle;
    } else {
      fragment.b = new Bundle();
    } 
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Instantiated fragment ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void a() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto ACTIVITY_CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment1 = this.c;
    fragment1.W0(fragment1.b);
    k k1 = this.a;
    Fragment fragment2 = this.c;
    k1.a(fragment2, fragment2.b, false);
  }
  
  public void b() {
    int i = this.b.j(this.c);
    Fragment fragment = this.c;
    fragment.R.addView(fragment.S, i);
  }
  
  public void c() {
    StringBuilder stringBuilder;
    if (FragmentManager.E0(3)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("moveto ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    Fragment fragment3 = fragment2.h;
    p p1 = null;
    if (fragment3 != null) {
      p1 = this.b.m(fragment3.f);
      if (p1 != null) {
        fragment2 = this.c;
        fragment2.i = fragment2.h.f;
        fragment2.h = null;
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" declared target fragment ");
        stringBuilder.append(this.c.h);
        stringBuilder.append(" that does not belong to this FragmentManager!");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      String str = fragment2.i;
      if (str != null) {
        p1 = this.b.m(str);
        if (p1 == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" declared target fragment ");
          stringBuilder.append(this.c.i);
          stringBuilder.append(" that does not belong to this FragmentManager!");
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
    } 
    if (stringBuilder != null && (FragmentManager.P || (stringBuilder.k()).a < 1))
      stringBuilder.m(); 
    Fragment fragment1 = this.c;
    fragment1.E = fragment1.D.t0();
    fragment1 = this.c;
    fragment1.G = fragment1.D.w0();
    this.a.g(this.c, false);
    this.c.X0();
    this.a.b(this.c, false);
  }
  
  public int d() {
    x.e.b b;
    Fragment fragment2 = this.c;
    if (fragment2.D == null)
      return fragment2.a; 
    int j = this.e;
    int m = b.a[fragment2.b0.ordinal()];
    int i = j;
    if (m != 1)
      if (m != 2) {
        if (m != 3) {
          if (m != 4) {
            i = Math.min(j, -1);
          } else {
            i = Math.min(j, 0);
          } 
        } else {
          i = Math.min(j, 1);
        } 
      } else {
        i = Math.min(j, 5);
      }  
    fragment2 = this.c;
    j = i;
    if (fragment2.n) {
      View view;
      if (fragment2.o) {
        i = Math.max(this.e, 2);
        view = this.c.S;
        j = i;
        if (view != null) {
          j = i;
          if (view.getParent() == null)
            j = Math.min(i, 2); 
        } 
      } else if (this.e < 4) {
        j = Math.min(i, ((Fragment)view).a);
      } else {
        j = Math.min(i, 1);
      } 
    } 
    m = j;
    if (!this.c.l)
      m = Math.min(j, 1); 
    Fragment fragment3 = null;
    fragment2 = fragment3;
    if (FragmentManager.P) {
      Fragment fragment = this.c;
      ViewGroup viewGroup = fragment.R;
      fragment2 = fragment3;
      if (viewGroup != null)
        b = x.n(viewGroup, fragment.H()).l(this); 
    } 
    if (b == x.e.b.b) {
      i = Math.min(m, 6);
    } else if (b == x.e.b.c) {
      i = Math.max(m, 3);
    } else {
      Fragment fragment = this.c;
      i = m;
      if (fragment.m)
        if (fragment.f0()) {
          i = Math.min(m, 1);
        } else {
          i = Math.min(m, -1);
        }  
    } 
    Fragment fragment1 = this.c;
    j = i;
    if (fragment1.T) {
      j = i;
      if (fragment1.a < 5)
        j = Math.min(i, 4); 
    } 
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("computeExpectedState() of ");
      stringBuilder.append(j);
      stringBuilder.append(" for ");
      stringBuilder.append(this.c);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    return j;
  }
  
  public void e() {
    k k1;
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    if (!fragment.a0) {
      this.a.h(fragment, fragment.b, false);
      fragment = this.c;
      fragment.a1(fragment.b);
      k1 = this.a;
      Fragment fragment1 = this.c;
      k1.c(fragment1, fragment1.b, false);
      return;
    } 
    k1.y1(((Fragment)k1).b);
    this.c.a = 1;
  }
  
  public void f() {
    StringBuilder stringBuilder;
    if (this.c.n)
      return; 
    if (FragmentManager.E0(3)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("moveto CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment1 = this.c;
    LayoutInflater layoutInflater = fragment1.g1(fragment1.b);
    fragment1 = null;
    Fragment fragment3 = this.c;
    ViewGroup viewGroup = fragment3.R;
    if (viewGroup != null) {
      ViewGroup viewGroup1 = viewGroup;
    } else {
      int i = fragment3.I;
      if (i != 0)
        if (i != -1) {
          viewGroup = (ViewGroup)fragment3.D.o0().e(this.c.I);
          ViewGroup viewGroup1 = viewGroup;
          if (viewGroup == null) {
            ViewGroup viewGroup2;
            Fragment fragment = this.c;
            if (fragment.p) {
              viewGroup2 = viewGroup;
            } else {
              String str;
              try {
                str = viewGroup2.K().getResourceName(this.c.I);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                str = "unknown";
              } 
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("No view found for id 0x");
              stringBuilder1.append(Integer.toHexString(this.c.I));
              stringBuilder1.append(" (");
              stringBuilder1.append(str);
              stringBuilder1.append(") for fragment ");
              stringBuilder1.append(this.c);
              throw new IllegalArgumentException(stringBuilder1.toString());
            } 
          } 
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot create fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" for a container view with no id");
          throw new IllegalArgumentException(stringBuilder.toString());
        }  
    } 
    Fragment fragment2 = this.c;
    fragment2.R = (ViewGroup)stringBuilder;
    fragment2.c1(layoutInflater, (ViewGroup)stringBuilder, fragment2.b);
    View view = this.c.S;
    if (view != null) {
      boolean bool = false;
      view.setSaveFromParentEnabled(false);
      Fragment fragment5 = this.c;
      fragment5.S.setTag(b.k.b.a, fragment5);
      if (stringBuilder != null)
        b(); 
      Fragment fragment4 = this.c;
      if (fragment4.K)
        fragment4.S.setVisibility(8); 
      if (r.A(this.c.S)) {
        r.M(this.c.S);
      } else {
        View view1 = this.c.S;
        view1.addOnAttachStateChangeListener(new a(this, view1));
      } 
      this.c.t1();
      k k1 = this.a;
      fragment5 = this.c;
      k1.m(fragment5, fragment5.S, fragment5.b, false);
      int i = this.c.S.getVisibility();
      float f = this.c.S.getAlpha();
      if (FragmentManager.P) {
        this.c.L1(f);
        Fragment fragment = this.c;
        if (fragment.R != null && i == 0) {
          View view1 = fragment.S.findFocus();
          if (view1 != null) {
            this.c.E1(view1);
            if (FragmentManager.E0(2)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("requestFocus: Saved focused view ");
              stringBuilder1.append(view1);
              stringBuilder1.append(" for Fragment ");
              stringBuilder1.append(this.c);
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
          } 
          this.c.S.setAlpha(0.0F);
        } 
      } else {
        Fragment fragment = this.c;
        boolean bool1 = bool;
        if (i == 0) {
          bool1 = bool;
          if (fragment.R != null)
            bool1 = true; 
        } 
        fragment.W = bool1;
      } 
    } 
    this.c.a = 2;
  }
  
  public void g() {
    boolean bool1;
    boolean bool2;
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    boolean bool4 = fragment.m;
    boolean bool3 = true;
    if (bool4 && !fragment.f0()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1 || this.b.o().o(this.c)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2) {
      int i;
      i i1 = this.c.E;
      if (i1 instanceof b.n.v) {
        bool3 = this.b.o().l();
      } else if (i1.k() instanceof Activity) {
        i = true ^ ((Activity)i1.k()).isChangingConfigurations();
      } 
      if (bool1 || i != 0)
        this.b.o().f(this.c); 
      this.c.d1();
      this.a.d(this.c, false);
      for (p p1 : this.b.k()) {
        if (p1 != null) {
          Fragment fragment2 = p1.k();
          if (this.c.f.equals(fragment2.i)) {
            fragment2.h = this.c;
            fragment2.i = null;
          } 
        } 
      } 
      Fragment fragment1 = this.c;
      String str1 = fragment1.i;
      if (str1 != null)
        fragment1.h = this.b.f(str1); 
      this.b.q(this);
      return;
    } 
    String str = this.c.i;
    if (str != null) {
      Fragment fragment1 = this.b.f(str);
      if (fragment1 != null && fragment1.M)
        this.c.h = fragment1; 
    } 
    this.c.a = 0;
  }
  
  public void h() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    ViewGroup viewGroup = fragment2.R;
    if (viewGroup != null) {
      View view = fragment2.S;
      if (view != null)
        viewGroup.removeView(view); 
    } 
    this.c.e1();
    this.a.n(this.c, false);
    Fragment fragment1 = this.c;
    fragment1.R = null;
    fragment1.S = null;
    fragment1.d0 = null;
    fragment1.e0.n(null);
    this.c.o = false;
  }
  
  public void i() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.f1();
    k k1 = this.a;
    Fragment fragment2 = this.c;
    boolean bool2 = false;
    k1.e(fragment2, false);
    Fragment fragment1 = this.c;
    fragment1.a = -1;
    fragment1.E = null;
    fragment1.G = null;
    fragment1.D = null;
    boolean bool1 = bool2;
    if (fragment1.m) {
      bool1 = bool2;
      if (!fragment1.f0())
        bool1 = true; 
    } 
    if (bool1 || this.b.o().o(this.c)) {
      if (FragmentManager.E0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("initState called for fragment: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      this.c.Z();
    } 
  }
  
  public void j() {
    Fragment fragment = this.c;
    if (fragment.n && fragment.o && !fragment.q) {
      if (FragmentManager.E0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("moveto CREATE_VIEW: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      fragment = this.c;
      fragment.c1(fragment.g1(fragment.b), null, this.c.b);
      View view = this.c.S;
      if (view != null) {
        view.setSaveFromParentEnabled(false);
        Fragment fragment1 = this.c;
        fragment1.S.setTag(b.k.b.a, fragment1);
        fragment1 = this.c;
        if (fragment1.K)
          fragment1.S.setVisibility(8); 
        this.c.t1();
        k k1 = this.a;
        Fragment fragment2 = this.c;
        k1.m(fragment2, fragment2.S, fragment2.b, false);
        this.c.a = 2;
      } 
    } 
  }
  
  public Fragment k() {
    return this.c;
  }
  
  public final boolean l(View paramView) {
    if (paramView == this.c.S)
      return true; 
    for (ViewParent viewParent = paramView.getParent(); viewParent != null; viewParent = viewParent.getParent()) {
      if (viewParent == this.c.S)
        return true; 
    } 
    return false;
  }
  
  public void m() {
    if (this.d) {
      if (FragmentManager.E0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring re-entrant call to moveToExpectedState() for ");
        stringBuilder.append(k());
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    try {
      this.d = true;
      while (true) {
        int i = d();
        Fragment fragment = this.c;
        int j = fragment.a;
        if (i != j) {
          if (i > j) {
            switch (j + 1) {
              case 7:
                p();
                continue;
              case 6:
                fragment.a = 6;
                continue;
              case 5:
                u();
                continue;
              case 4:
                if (fragment.S != null) {
                  ViewGroup viewGroup = fragment.R;
                  if (viewGroup != null)
                    x.n(viewGroup, fragment.H()).b(x.e.c.f(this.c.S.getVisibility()), this); 
                } 
                this.c.a = 4;
                continue;
              case 3:
                a();
                continue;
              case 2:
                j();
                f();
                continue;
              case 1:
                e();
                continue;
              case 0:
                c();
                continue;
            } 
            continue;
          } 
        } else {
          if (FragmentManager.P && fragment.X) {
            if (fragment.S != null) {
              ViewGroup viewGroup = fragment.R;
              if (viewGroup != null) {
                x x = x.n(viewGroup, fragment.H());
                if (this.c.K) {
                  x.c(this);
                } else {
                  x.e(this);
                } 
              } 
            } 
            fragment = this.c;
            fragment.X = false;
            fragment.F0(fragment.K);
          } 
          return;
        } 
        switch (j - 1) {
          case 6:
            n();
          case 5:
            fragment.a = 5;
          case 4:
            v();
          case 3:
            if (FragmentManager.E0(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom ACTIVITY_CREATED: ");
              stringBuilder.append(this.c);
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            fragment = this.c;
            if (fragment.S != null && fragment.c == null)
              s(); 
            fragment = this.c;
            if (fragment.S != null) {
              ViewGroup viewGroup = fragment.R;
              if (viewGroup != null)
                x.n(viewGroup, fragment.H()).d(this); 
            } 
            this.c.a = 3;
          case 2:
            fragment.o = false;
            fragment.a = 2;
          case 1:
            h();
            this.c.a = 1;
          case 0:
            g();
          case -1:
            i();
        } 
      } 
    } finally {
      this.d = false;
    } 
  }
  
  public void n() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.l1();
    this.a.f(this.c, false);
  }
  
  public void o(ClassLoader paramClassLoader) {
    Bundle bundle = this.c.b;
    if (bundle == null)
      return; 
    bundle.setClassLoader(paramClassLoader);
    Fragment fragment = this.c;
    fragment.c = fragment.b.getSparseParcelableArray("android:view_state");
    fragment = this.c;
    fragment.d = fragment.b.getBundle("android:view_registry_state");
    fragment = this.c;
    fragment.i = fragment.b.getString("android:target_state");
    fragment = this.c;
    if (fragment.i != null)
      fragment.j = fragment.b.getInt("android:target_req_state", 0); 
    fragment = this.c;
    Boolean bool = fragment.e;
    if (bool != null) {
      fragment.U = bool.booleanValue();
      this.c.e = null;
    } else {
      fragment.U = fragment.b.getBoolean("android:user_visible_hint", true);
    } 
    fragment = this.c;
    if (!fragment.U)
      fragment.T = true; 
  }
  
  public void p() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    View view = this.c.y();
    if (view != null && l(view)) {
      boolean bool = view.requestFocus();
      if (FragmentManager.E0(2)) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("requestFocus: Restoring focused view ");
        stringBuilder.append(view);
        stringBuilder.append(" ");
        if (bool) {
          str = "succeeded";
        } else {
          str = "failed";
        } 
        stringBuilder.append(str);
        stringBuilder.append(" on Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" resulting in focused view ");
        stringBuilder.append(this.c.S.findFocus());
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    this.c.E1(null);
    this.c.p1();
    this.a.i(this.c, false);
    Fragment fragment = this.c;
    fragment.b = null;
    fragment.c = null;
    fragment.d = null;
  }
  
  public final Bundle q() {
    Bundle bundle2 = new Bundle();
    this.c.q1(bundle2);
    this.a.j(this.c, bundle2, false);
    Bundle bundle1 = bundle2;
    if (bundle2.isEmpty())
      bundle1 = null; 
    if (this.c.S != null)
      s(); 
    bundle2 = bundle1;
    if (this.c.c != null) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putSparseParcelableArray("android:view_state", this.c.c);
    } 
    bundle1 = bundle2;
    if (this.c.d != null) {
      bundle1 = bundle2;
      if (bundle2 == null)
        bundle1 = new Bundle(); 
      bundle1.putBundle("android:view_registry_state", this.c.d);
    } 
    bundle2 = bundle1;
    if (!this.c.U) {
      bundle2 = bundle1;
      if (bundle1 == null)
        bundle2 = new Bundle(); 
      bundle2.putBoolean("android:user_visible_hint", this.c.U);
    } 
    return bundle2;
  }
  
  public FragmentState r() {
    Bundle bundle;
    FragmentState fragmentState = new FragmentState(this.c);
    Fragment fragment = this.c;
    if (fragment.a > -1 && fragmentState.m == null) {
      bundle = q();
      fragmentState.m = bundle;
      if (this.c.i != null) {
        if (bundle == null)
          fragmentState.m = new Bundle(); 
        fragmentState.m.putString("android:target_state", this.c.i);
        int i = this.c.j;
        if (i != 0) {
          fragmentState.m.putInt("android:target_req_state", i);
          return fragmentState;
        } 
      } 
    } else {
      fragmentState.m = ((Fragment)bundle).b;
    } 
    return fragmentState;
  }
  
  public void s() {
    if (this.c.S == null)
      return; 
    SparseArray sparseArray = new SparseArray();
    this.c.S.saveHierarchyState(sparseArray);
    if (sparseArray.size() > 0)
      this.c.c = sparseArray; 
    Bundle bundle = new Bundle();
    this.c.d0.g(bundle);
    if (!bundle.isEmpty())
      this.c.d = bundle; 
  }
  
  public void t(int paramInt) {
    this.e = paramInt;
  }
  
  public void u() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.r1();
    this.a.k(this.c, false);
  }
  
  public void v() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.s1();
    this.a.l(this.c, false);
  }
  
  public class a implements View.OnAttachStateChangeListener {
    public a(p this$0, View param1View) {}
    
    public void onViewAttachedToWindow(View param1View) {
      this.a.removeOnAttachStateChangeListener(this);
      r.M(this.a);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */