package b.k.d;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentState;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class q {
  public final ArrayList<Fragment> a = new ArrayList<Fragment>();
  
  public final HashMap<String, p> b = new HashMap<String, p>();
  
  public m c;
  
  public void a(Fragment paramFragment) {
    if (!this.a.contains(paramFragment))
      synchronized (this.a) {
        this.a.add(paramFragment);
        paramFragment.l = true;
        return;
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment already added: ");
    stringBuilder.append(paramFragment);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void b() {
    this.b.values().removeAll(Collections.singleton(null));
  }
  
  public boolean c(String paramString) {
    return (this.b.get(paramString) != null);
  }
  
  public void d(int paramInt) {
    for (p p : this.b.values()) {
      if (p != null)
        p.t(paramInt); 
    } 
  }
  
  public void e(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("    ");
    String str = stringBuilder.toString();
    if (!this.b.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("Active Fragments:");
      for (p p : this.b.values()) {
        paramPrintWriter.print(paramString);
        if (p != null) {
          Fragment fragment = p.k();
          paramPrintWriter.println(fragment);
          fragment.i(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          continue;
        } 
        paramPrintWriter.println("null");
      } 
    } 
    int i = this.a.size();
    if (i > 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Added Fragments:");
      int j;
      for (j = 0; j < i; j++) {
        Fragment fragment = this.a.get(j);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(j);
        paramPrintWriter.print(": ");
        paramPrintWriter.println(fragment.toString());
      } 
    } 
  }
  
  public Fragment f(String paramString) {
    p p = this.b.get(paramString);
    return (p != null) ? p.k() : null;
  }
  
  public Fragment g(int paramInt) {
    for (int i = this.a.size() - 1; i >= 0; i--) {
      Fragment fragment = this.a.get(i);
      if (fragment != null && fragment.H == paramInt)
        return fragment; 
    } 
    for (p p : this.b.values()) {
      if (p != null) {
        Fragment fragment = p.k();
        if (fragment.H == paramInt)
          return fragment; 
      } 
    } 
    return null;
  }
  
  public Fragment h(String paramString) {
    if (paramString != null)
      for (int i = this.a.size() - 1; i >= 0; i--) {
        Fragment fragment = this.a.get(i);
        if (fragment != null && paramString.equals(fragment.J))
          return fragment; 
      }  
    if (paramString != null)
      for (p p : this.b.values()) {
        if (p != null) {
          Fragment fragment = p.k();
          if (paramString.equals(fragment.J))
            return fragment; 
        } 
      }  
    return null;
  }
  
  public Fragment i(String paramString) {
    for (p p : this.b.values()) {
      if (p != null) {
        Fragment fragment = p.k().l(paramString);
        if (fragment != null)
          return fragment; 
      } 
    } 
    return null;
  }
  
  public int j(Fragment paramFragment) {
    int j;
    ViewGroup viewGroup = paramFragment.R;
    if (viewGroup == null)
      return -1; 
    int k = this.a.indexOf(paramFragment);
    int i = k - 1;
    while (true) {
      j = k;
      if (i >= 0) {
        paramFragment = this.a.get(i);
        if (paramFragment.R == viewGroup) {
          View view = paramFragment.S;
          if (view != null)
            return viewGroup.indexOfChild(view) + 1; 
        } 
        i--;
        continue;
      } 
      break;
    } 
    while (true) {
      if (++j < this.a.size()) {
        paramFragment = this.a.get(j);
        if (paramFragment.R == viewGroup) {
          View view = paramFragment.S;
          if (view != null)
            return viewGroup.indexOfChild(view); 
        } 
        continue;
      } 
      return -1;
    } 
  }
  
  public List<p> k() {
    ArrayList<p> arrayList = new ArrayList();
    for (p p : this.b.values()) {
      if (p != null)
        arrayList.add(p); 
    } 
    return arrayList;
  }
  
  public List<Fragment> l() {
    ArrayList<Fragment> arrayList = new ArrayList();
    for (p p : this.b.values()) {
      if (p != null) {
        arrayList.add(p.k());
        continue;
      } 
      arrayList.add(null);
    } 
    return arrayList;
  }
  
  public p m(String paramString) {
    return this.b.get(paramString);
  }
  
  public List<Fragment> n() {
    if (this.a.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.a) {
      return new ArrayList<Fragment>(this.a);
    } 
  }
  
  public m o() {
    return this.c;
  }
  
  public void p(p paramp) {
    Fragment fragment = paramp.k();
    if (c(fragment.f))
      return; 
    this.b.put(fragment.f, paramp);
    if (fragment.N) {
      if (fragment.M) {
        this.c.e(fragment);
      } else {
        this.c.m(fragment);
      } 
      fragment.N = false;
    } 
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Added fragment to active set ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void q(p paramp) {
    Fragment fragment = paramp.k();
    if (fragment.M)
      this.c.m(fragment); 
    if ((p)this.b.put(fragment.f, null) == null)
      return; 
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removed fragment from active set ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void r() {
    for (Fragment fragment : this.a) {
      p p = this.b.get(fragment.f);
      if (p != null)
        p.m(); 
    } 
    for (p p : this.b.values()) {
      if (p != null) {
        boolean bool;
        p.m();
        Fragment fragment = p.k();
        if (fragment.m && !fragment.f0()) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool)
          q(p); 
      } 
    } 
  }
  
  public void s(Fragment paramFragment) {
    synchronized (this.a) {
      this.a.remove(paramFragment);
      paramFragment.l = false;
      return;
    } 
  }
  
  public void t() {
    this.b.clear();
  }
  
  public void u(List<String> paramList) {
    this.a.clear();
    if (paramList != null) {
      Iterator<String> iterator = paramList.iterator();
      while (iterator.hasNext()) {
        String str = iterator.next();
        Fragment fragment = f(str);
        if (fragment != null) {
          if (FragmentManager.E0(2)) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("restoreSaveState: added (");
            stringBuilder1.append(str);
            stringBuilder1.append("): ");
            stringBuilder1.append(fragment);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          a(fragment);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No instantiated fragment for (");
        stringBuilder.append(str);
        stringBuilder.append(")");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  public ArrayList<FragmentState> v() {
    ArrayList<FragmentState> arrayList = new ArrayList(this.b.size());
    for (p p : this.b.values()) {
      if (p != null) {
        Fragment fragment = p.k();
        FragmentState fragmentState = p.r();
        arrayList.add(fragmentState);
        if (FragmentManager.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Saved state of ");
          stringBuilder.append(fragment);
          stringBuilder.append(": ");
          stringBuilder.append(fragmentState.m);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
    return arrayList;
  }
  
  public ArrayList<String> w() {
    synchronized (this.a) {
      if (this.a.isEmpty())
        return null; 
      ArrayList<String> arrayList = new ArrayList(this.a.size());
      for (Fragment fragment : this.a) {
        arrayList.add(fragment.f);
        if (FragmentManager.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("saveAllState: adding fragment (");
          stringBuilder.append(fragment.f);
          stringBuilder.append("): ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
      return arrayList;
    } 
  }
  
  public void x(m paramm) {
    this.c = paramm;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */