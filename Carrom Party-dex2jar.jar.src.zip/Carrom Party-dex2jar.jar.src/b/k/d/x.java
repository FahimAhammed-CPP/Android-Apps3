package b.k.d;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import b.h.n.r;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public abstract class x {
  public final ViewGroup a;
  
  public final ArrayList<e> b = new ArrayList<e>();
  
  public final ArrayList<e> c = new ArrayList<e>();
  
  public boolean d = false;
  
  public boolean e = false;
  
  public x(ViewGroup paramViewGroup) {
    this.a = paramViewGroup;
  }
  
  public static x n(ViewGroup paramViewGroup, FragmentManager paramFragmentManager) {
    return o(paramViewGroup, paramFragmentManager.y0());
  }
  
  public static x o(ViewGroup paramViewGroup, y paramy) {
    int i = b.k.b.b;
    Object object = paramViewGroup.getTag(i);
    if (object instanceof x)
      return (x)object; 
    x x1 = paramy.a(paramViewGroup);
    paramViewGroup.setTag(i, x1);
    return x1;
  }
  
  public final void a(e.c paramc, e.b paramb, p paramp) {
    synchronized (this.b) {
      b.h.j.b b1 = new b.h.j.b();
      e e = h(paramp.k());
      if (e != null) {
        e.k(paramc, paramb);
        return;
      } 
      d d = new d(paramc, paramb, paramp, b1);
      this.b.add(d);
      d.a(new a(this, d));
      d.a(new b(this, d));
      return;
    } 
  }
  
  public void b(e.c paramc, p paramp) {
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing add operation for fragment ");
      stringBuilder.append(paramp.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    a(paramc, e.b.b, paramp);
  }
  
  public void c(p paramp) {
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing hide operation for fragment ");
      stringBuilder.append(paramp.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    a(e.c.c, e.b.a, paramp);
  }
  
  public void d(p paramp) {
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing remove operation for fragment ");
      stringBuilder.append(paramp.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    a(e.c.a, e.b.c, paramp);
  }
  
  public void e(p paramp) {
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing show operation for fragment ");
      stringBuilder.append(paramp.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    a(e.c.b, e.b.a, paramp);
  }
  
  public abstract void f(List<e> paramList, boolean paramBoolean);
  
  public void g() {
    if (this.e)
      return; 
    if (!r.A((View)this.a)) {
      j();
      this.d = false;
      return;
    } 
    synchronized (this.b) {
      if (!this.b.isEmpty()) {
        ArrayList<e> arrayList = new ArrayList<e>(this.c);
        this.c.clear();
        for (e e : arrayList) {
          if (FragmentManager.E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Cancelling operation ");
            stringBuilder.append(e);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          e.b();
          if (!e.i())
            this.c.add(e); 
        } 
        q();
        arrayList = new ArrayList<e>(this.b);
        this.b.clear();
        this.c.addAll(arrayList);
        Iterator<e> iterator = arrayList.iterator();
        while (iterator.hasNext())
          ((e)iterator.next()).l(); 
        f(arrayList, this.d);
        this.d = false;
      } 
      return;
    } 
  }
  
  public final e h(Fragment paramFragment) {
    for (e e : this.b) {
      if (e.f().equals(paramFragment) && !e.h())
        return e; 
    } 
    return null;
  }
  
  public final e i(Fragment paramFragment) {
    for (e e : this.c) {
      if (e.f().equals(paramFragment) && !e.h())
        return e; 
    } 
    return null;
  }
  
  public void j() {
    boolean bool = r.A((View)this.a);
    synchronized (this.b) {
      q();
      Iterator<e> iterator = this.b.iterator();
      while (iterator.hasNext())
        ((e)iterator.next()).l(); 
      for (e e : new ArrayList(this.c)) {
        if (FragmentManager.E0(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.a);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling running operation ");
          stringBuilder.append(e);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        e.b();
      } 
      for (e e : new ArrayList(this.b)) {
        if (FragmentManager.E0(2)) {
          String str;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: ");
          if (bool) {
            str = "";
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Container ");
            stringBuilder1.append(this.a);
            stringBuilder1.append(" is not attached to window. ");
            str = stringBuilder1.toString();
          } 
          stringBuilder.append(str);
          stringBuilder.append("Cancelling pending operation ");
          stringBuilder.append(e);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        e.b();
      } 
      return;
    } 
  }
  
  public void k() {
    if (this.e) {
      this.e = false;
      g();
    } 
  }
  
  public e.b l(p paramp) {
    e e2 = h(paramp.k());
    if (e2 != null)
      return e2.g(); 
    e e1 = i(paramp.k());
    return (e1 != null) ? e1.g() : null;
  }
  
  public ViewGroup m() {
    return this.a;
  }
  
  public void p() {
    synchronized (this.b) {
      q();
      this.e = false;
      int i = this.b.size() - 1;
      while (true) {
        if (i >= 0) {
          e e = this.b.get(i);
          e.c c1 = e.c.h((e.f()).S);
          e.c c2 = e.e();
          e.c c3 = e.c.b;
          if (c2 == c3 && c1 != c3) {
            this.e = e.f().i0();
          } else {
            i--;
            continue;
          } 
        } 
        return;
      } 
    } 
  }
  
  public final void q() {
    for (e e : this.b) {
      if (e.g() == e.b.b)
        e.k(e.c.f(e.f().x1().getVisibility()), e.b.a); 
    } 
  }
  
  public void r(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  public class a implements Runnable {
    public a(x this$0, x.d param1d) {}
    
    public void run() {
      if (this.b.b.contains(this.a))
        this.a.e().a((this.a.f()).S); 
    }
  }
  
  public class b implements Runnable {
    public b(x this$0, x.d param1d) {}
    
    public void run() {
      this.b.b.remove(this.a);
      this.b.c.remove(this.a);
    }
  }
  
  public static class d extends e {
    public final p h;
    
    public d(x.e.c param1c, x.e.b param1b, p param1p, b.h.j.b param1b1) {
      super(param1c, param1b, param1p.k(), param1b1);
      this.h = param1p;
    }
    
    public void c() {
      super.c();
      this.h.m();
    }
    
    public void l() {
      Fragment fragment = this.h.k();
      View view = fragment.S.findFocus();
      if (view != null) {
        fragment.E1(view);
        if (FragmentManager.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("requestFocus: Saved focused view ");
          stringBuilder.append(view);
          stringBuilder.append(" for Fragment ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
      if (g() == x.e.b.b) {
        view = f().x1();
        if (view.getParent() == null) {
          this.h.b();
          view.setAlpha(0.0F);
        } 
        if (view.getAlpha() == 0.0F && view.getVisibility() == 0)
          view.setVisibility(4); 
        view.setAlpha(fragment.I());
      } 
    }
  }
  
  public static class e {
    public c a;
    
    public b b;
    
    public final Fragment c;
    
    public final List<Runnable> d = new ArrayList<Runnable>();
    
    public final HashSet<b.h.j.b> e = new HashSet<b.h.j.b>();
    
    public boolean f = false;
    
    public boolean g = false;
    
    public e(c param1c, b param1b, Fragment param1Fragment, b.h.j.b param1b1) {
      this.a = param1c;
      this.b = param1b;
      this.c = param1Fragment;
      param1b1.c(new a(this));
    }
    
    public final void a(Runnable param1Runnable) {
      this.d.add(param1Runnable);
    }
    
    public final void b() {
      if (h())
        return; 
      this.f = true;
      if (this.e.isEmpty()) {
        c();
        return;
      } 
      Iterator<?> iterator = (new ArrayList(this.e)).iterator();
      while (iterator.hasNext())
        ((b.h.j.b)iterator.next()).a(); 
    }
    
    public void c() {
      if (this.g)
        return; 
      if (FragmentManager.E0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SpecialEffectsController: ");
        stringBuilder.append(this);
        stringBuilder.append(" has called complete.");
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      this.g = true;
      Iterator<Runnable> iterator = this.d.iterator();
      while (iterator.hasNext())
        ((Runnable)iterator.next()).run(); 
    }
    
    public final void d(b.h.j.b param1b) {
      if (this.e.remove(param1b) && this.e.isEmpty())
        c(); 
    }
    
    public c e() {
      return this.a;
    }
    
    public final Fragment f() {
      return this.c;
    }
    
    public b g() {
      return this.b;
    }
    
    public final boolean h() {
      return this.f;
    }
    
    public final boolean i() {
      return this.g;
    }
    
    public final void j(b.h.j.b param1b) {
      l();
      this.e.add(param1b);
    }
    
    public final void k(c param1c, b param1b) {
      int i = x.c.b[param1b.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          if (this.a != c.a) {
            if (FragmentManager.E0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: For fragment ");
              stringBuilder.append(this.c);
              stringBuilder.append(" mFinalState = ");
              stringBuilder.append(this.a);
              stringBuilder.append(" -> ");
              stringBuilder.append(param1c);
              stringBuilder.append(". ");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            this.a = param1c;
            return;
          } 
        } else {
          if (FragmentManager.E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: For fragment ");
            stringBuilder.append(this.c);
            stringBuilder.append(" mFinalState = ");
            stringBuilder.append(this.a);
            stringBuilder.append(" -> REMOVED. mLifecycleImpact  = ");
            stringBuilder.append(this.b);
            stringBuilder.append(" to REMOVING.");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          this.a = c.a;
          this.b = b.c;
          return;
        } 
      } else if (this.a == c.a) {
        if (FragmentManager.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: For fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = ");
          stringBuilder.append(this.b);
          stringBuilder.append(" to ADDING.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.a = c.b;
        this.b = b.b;
      } 
    }
    
    public void l() {}
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Operation ");
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFinalState = ");
      stringBuilder.append(this.a);
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mLifecycleImpact = ");
      stringBuilder.append(this.b);
      stringBuilder.append("} ");
      stringBuilder.append("{");
      stringBuilder.append("mFragment = ");
      stringBuilder.append(this.c);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public class a implements b.h.j.b.a {
      public a(x.e this$0) {}
      
      public void a() {
        this.a.b();
      }
    }
    
    public enum b {
      a, b, c;
      
      static {
        b b1 = new b("NONE", 0);
        a = b1;
        b b2 = new b("ADDING", 1);
        b = b2;
        b b3 = new b("REMOVING", 2);
        c = b3;
        d = new b[] { b1, b2, b3 };
      }
    }
    
    public enum c {
      a, b, c, d;
      
      static {
        c c1 = new c("REMOVED", 0);
        a = c1;
        c c2 = new c("VISIBLE", 1);
        b = c2;
        c c3 = new c("GONE", 2);
        c = c3;
        c c4 = new c("INVISIBLE", 3);
        d = c4;
        e = new c[] { c1, c2, c3, c4 };
      }
      
      public static c f(int param2Int) {
        if (param2Int != 0) {
          if (param2Int != 4) {
            if (param2Int == 8)
              return c; 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown visibility ");
            stringBuilder.append(param2Int);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
          return d;
        } 
        return b;
      }
      
      public static c h(View param2View) {
        return (param2View.getAlpha() == 0.0F && param2View.getVisibility() == 0) ? d : f(param2View.getVisibility());
      }
      
      public void a(View param2View) {
        int i = x.c.a[ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              if (i != 4)
                return; 
              if (FragmentManager.E0(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SpecialEffectsController: Setting view ");
                stringBuilder.append(param2View);
                stringBuilder.append(" to INVISIBLE");
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              param2View.setVisibility(4);
              return;
            } 
            if (FragmentManager.E0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param2View);
              stringBuilder.append(" to GONE");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            param2View.setVisibility(8);
            return;
          } 
          if (FragmentManager.E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param2View);
            stringBuilder.append(" to VISIBLE");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          param2View.setVisibility(0);
          return;
        } 
        ViewGroup viewGroup = (ViewGroup)param2View.getParent();
        if (viewGroup != null) {
          if (FragmentManager.E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Removing view ");
            stringBuilder.append(param2View);
            stringBuilder.append(" from container ");
            stringBuilder.append(viewGroup);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          viewGroup.removeView(param2View);
        } 
      }
    }
  }
  
  public class a implements b.h.j.b.a {
    public a(x this$0) {}
    
    public void a() {
      this.a.b();
    }
  }
  
  public enum b {
    a, b, c;
    
    static {
      b b1 = new b("NONE", 0);
      a = b1;
      b b2 = new b("ADDING", 1);
      b = b2;
      b b3 = new b("REMOVING", 2);
      c = b3;
      d = new b[] { b1, b2, b3 };
    }
  }
  
  public enum c {
    a, b, c, d;
    
    static {
      c c1 = new c("REMOVED", 0);
      a = c1;
      c c2 = new c("VISIBLE", 1);
      b = c2;
      c c3 = new c("GONE", 2);
      c = c3;
      c c4 = new c("INVISIBLE", 3);
      d = c4;
      e = new c[] { c1, c2, c3, c4 };
    }
    
    public static c f(int param1Int) {
      if (param1Int != 0) {
        if (param1Int != 4) {
          if (param1Int == 8)
            return c; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown visibility ");
          stringBuilder.append(param1Int);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        return d;
      } 
      return b;
    }
    
    public static c h(View param1View) {
      return (param1View.getAlpha() == 0.0F && param1View.getVisibility() == 0) ? d : f(param1View.getVisibility());
    }
    
    public void a(View param1View) {
      int i = x.c.a[ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 4)
              return; 
            if (FragmentManager.E0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param1View);
              stringBuilder.append(" to INVISIBLE");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            param1View.setVisibility(4);
            return;
          } 
          if (FragmentManager.E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param1View);
            stringBuilder.append(" to GONE");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          param1View.setVisibility(8);
          return;
        } 
        if (FragmentManager.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: Setting view ");
          stringBuilder.append(param1View);
          stringBuilder.append(" to VISIBLE");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        param1View.setVisibility(0);
        return;
      } 
      ViewGroup viewGroup = (ViewGroup)param1View.getParent();
      if (viewGroup != null) {
        if (FragmentManager.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: Removing view ");
          stringBuilder.append(param1View);
          stringBuilder.append(" from container ");
          stringBuilder.append(viewGroup);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        viewGroup.removeView(param1View);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */