package b.k.d;

import android.view.ViewGroup;

public interface y {
  x a(ViewGroup paramViewGroup);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */