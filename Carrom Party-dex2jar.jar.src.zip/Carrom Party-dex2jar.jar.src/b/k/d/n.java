package b.k.d;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public interface n {
  void b(FragmentManager paramFragmentManager, Fragment paramFragment);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */