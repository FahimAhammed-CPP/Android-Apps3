package b.k.d;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import androidx.fragment.app.Fragment;
import b.h.n.p;

public class e {
  public static void a(Fragment paramFragment, d paramd, s.g paramg) {
    e e1;
    View view = paramFragment.S;
    ViewGroup viewGroup = paramFragment.R;
    viewGroup.startViewTransition(view);
    b.h.j.b b = new b.h.j.b();
    b.c(new a(paramFragment));
    paramg.b(paramFragment, b);
    if (paramd.a != null) {
      e1 = new e(paramd.a, viewGroup, view);
      paramFragment.B1(paramFragment.S);
      e1.setAnimationListener(new b(viewGroup, paramFragment, paramg, b));
      paramFragment.S.startAnimation((Animation)e1);
      return;
    } 
    Animator animator = ((d)e1).b;
    paramFragment.C1(animator);
    animator.addListener((Animator.AnimatorListener)new c(viewGroup, view, paramFragment, paramg, b));
    animator.setTarget(paramFragment.S);
    animator.start();
  }
  
  public static d b(Context paramContext, Fragment paramFragment, boolean paramBoolean) {
    int k = paramFragment.F();
    int j = paramFragment.E();
    boolean bool = false;
    paramFragment.I1(0);
    ViewGroup viewGroup = paramFragment.R;
    if (viewGroup != null) {
      int m = b.k.b.c;
      if (viewGroup.getTag(m) != null)
        paramFragment.R.setTag(m, null); 
    } 
    viewGroup = paramFragment.R;
    if (viewGroup != null && viewGroup.getLayoutTransition() != null)
      return null; 
    Animation animation = paramFragment.w0(k, paramBoolean, j);
    if (animation != null)
      return new d(animation); 
    Animator animator = paramFragment.x0(k, paramBoolean, j);
    if (animator != null)
      return new d(animator); 
    int i = j;
    if (j == 0) {
      i = j;
      if (k != 0)
        i = c(k, paramBoolean); 
    } 
    if (i != 0) {
      paramBoolean = "anim".equals(paramContext.getResources().getResourceTypeName(i));
      j = bool;
      if (paramBoolean)
        try {
          Animation animation1 = AnimationUtils.loadAnimation(paramContext, i);
          if (animation1 != null)
            return new d(animation1); 
          j = 1;
        } catch (android.content.res.Resources.NotFoundException notFoundException) {
          throw notFoundException;
        } catch (RuntimeException runtimeException) {
          j = bool;
        }  
      if (j == 0)
        try {
          animator = AnimatorInflater.loadAnimator((Context)notFoundException, i);
          if (animator != null)
            return new d(animator); 
        } catch (RuntimeException runtimeException) {
          if (!paramBoolean) {
            Animation animation1 = AnimationUtils.loadAnimation((Context)notFoundException, i);
            if (animation1 != null)
              return new d(animation1); 
          } else {
            throw runtimeException;
          } 
        }  
    } 
    return null;
  }
  
  public static int c(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? b.k.a.a : b.k.a.b)) : (paramBoolean ? b.k.a.c : b.k.a.d)) : (paramBoolean ? b.k.a.e : b.k.a.f);
  }
  
  public class a implements b.h.j.b.a {
    public a(e this$0) {}
    
    public void a() {
      if (this.a.p() != null) {
        View view = this.a.p();
        this.a.B1(null);
        view.clearAnimation();
      } 
      this.a.C1(null);
    }
  }
  
  public class b implements Animation.AnimationListener {
    public b(e this$0, Fragment param1Fragment, s.g param1g, b.h.j.b param1b) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      this.a.post(new a(this));
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
    
    public class a implements Runnable {
      public a(e.b this$0) {}
      
      public void run() {
        if (this.a.b.p() != null) {
          this.a.b.B1(null);
          e.b b1 = this.a;
          b1.c.a(b1.b, b1.d);
        } 
      }
    }
  }
  
  public class a implements Runnable {
    public a(e this$0) {}
    
    public void run() {
      if (this.a.b.p() != null) {
        this.a.b.B1(null);
        e.b b1 = this.a;
        b1.c.a(b1.b, b1.d);
      } 
    }
  }
  
  public class c extends AnimatorListenerAdapter {
    public c(e this$0, View param1View, Fragment param1Fragment, s.g param1g, b.h.j.b param1b) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator = this.c.q();
      this.c.C1(null);
      if (param1Animator != null && this.a.indexOfChild(this.b) < 0)
        this.d.a(this.c, this.e); 
    }
  }
  
  public static class d {
    public final Animation a = null;
    
    public final Animator b;
    
    public d(Animator param1Animator) {
      this.b = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    public d(Animation param1Animation) {
      this.b = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  public static class e extends AnimationSet implements Runnable {
    public final ViewGroup a;
    
    public final View b;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e = true;
    
    public e(Animation param1Animation, ViewGroup param1ViewGroup, View param1View) {
      super(false);
      this.a = param1ViewGroup;
      this.b = param1View;
      addAnimation(param1Animation);
      param1ViewGroup.post(this);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      this.e = true;
      if (this.c)
        return this.d ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.c = true;
        p.a((View)this.a, this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      this.e = true;
      if (this.c)
        return this.d ^ true; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.c = true;
        p.a((View)this.a, this);
      } 
      return true;
    }
    
    public void run() {
      if (!this.c && this.e) {
        this.e = false;
        this.a.post(this);
        return;
      } 
      this.a.endViewTransition(this.b);
      this.d = true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */