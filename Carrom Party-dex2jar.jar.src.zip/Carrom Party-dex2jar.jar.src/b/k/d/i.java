package b.k.d;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import b.h.f.a;
import b.h.m.h;

public abstract class i<E> extends f {
  public final Activity a;
  
  public final Context b;
  
  public final Handler c;
  
  public final FragmentManager d = new l();
  
  public i(Activity paramActivity, Context paramContext, Handler paramHandler, int paramInt) {
    this.a = paramActivity;
    h.c(paramContext, "context == null");
    this.b = paramContext;
    h.c(paramHandler, "handler == null");
    this.c = paramHandler;
  }
  
  public i(d paramd) {
    this((Activity)paramd, (Context)paramd, new Handler(), 0);
  }
  
  public View e(int paramInt) {
    return null;
  }
  
  public boolean g() {
    return true;
  }
  
  public Activity i() {
    return this.a;
  }
  
  public Context k() {
    return this.b;
  }
  
  public Handler l() {
    return this.c;
  }
  
  public abstract E m();
  
  public LayoutInflater n() {
    return LayoutInflater.from(this.b);
  }
  
  public boolean o(Fragment paramFragment) {
    return true;
  }
  
  public void p(Fragment paramFragment, @SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (paramInt == -1) {
      a.i(this.b, paramIntent, paramBundle);
      return;
    } 
    throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
  }
  
  public void q() {}
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */