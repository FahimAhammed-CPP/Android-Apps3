package b.k.d;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import b.n.g;
import b.n.n;

public class c extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
  public Handler j0;
  
  public Runnable k0 = new a(this);
  
  public DialogInterface.OnCancelListener l0 = new b(this);
  
  public DialogInterface.OnDismissListener m0 = new c(this);
  
  public int n0 = 0;
  
  public int o0 = 0;
  
  public boolean p0 = true;
  
  public boolean q0 = true;
  
  public int r0 = -1;
  
  public boolean s0;
  
  public n<g> t0 = new d(this);
  
  public Dialog u0;
  
  public boolean v0;
  
  public boolean w0;
  
  public boolean x0;
  
  public boolean y0 = false;
  
  public void C0() {
    super.C0();
    Dialog dialog = this.u0;
    if (dialog != null) {
      this.v0 = true;
      dialog.setOnDismissListener(null);
      this.u0.dismiss();
      if (!this.w0)
        onDismiss((DialogInterface)this.u0); 
      this.u0 = null;
      this.y0 = false;
    } 
  }
  
  public void D0() {
    super.D0();
    if (!this.x0 && !this.w0)
      this.w0 = true; 
    X().m(this.t0);
  }
  
  public LayoutInflater E0(Bundle paramBundle) {
    String str;
    LayoutInflater layoutInflater2 = super.E0(paramBundle);
    if (!this.q0 || this.s0) {
      if (FragmentManager.E0(2)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("getting layout inflater for DialogFragment ");
        stringBuilder1.append(this);
        str = stringBuilder1.toString();
        if (!this.q0) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("mShowsDialog = false: ");
          stringBuilder.append(str);
          Log.d("FragmentManager", stringBuilder.toString());
          return layoutInflater2;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("mCreatingDialog = true: ");
        stringBuilder2.append(str);
        Log.d("FragmentManager", stringBuilder2.toString());
      } 
      return layoutInflater2;
    } 
    d2((Bundle)str);
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("get layout inflater for DialogFragment ");
      stringBuilder.append(this);
      stringBuilder.append(" from dialog context");
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Dialog dialog = this.u0;
    LayoutInflater layoutInflater1 = layoutInflater2;
    if (dialog != null)
      layoutInflater1 = layoutInflater2.cloneInContext(dialog.getContext()); 
    return layoutInflater1;
  }
  
  public void R0(Bundle paramBundle) {
    super.R0(paramBundle);
    Dialog dialog = this.u0;
    if (dialog != null) {
      Bundle bundle = dialog.onSaveInstanceState();
      bundle.putBoolean("android:dialogShowing", false);
      paramBundle.putBundle("android:savedDialogState", bundle);
    } 
    int i = this.n0;
    if (i != 0)
      paramBundle.putInt("android:style", i); 
    i = this.o0;
    if (i != 0)
      paramBundle.putInt("android:theme", i); 
    boolean bool = this.p0;
    if (!bool)
      paramBundle.putBoolean("android:cancelable", bool); 
    bool = this.q0;
    if (!bool)
      paramBundle.putBoolean("android:showsDialog", bool); 
    i = this.r0;
    if (i != -1)
      paramBundle.putInt("android:backStackId", i); 
  }
  
  public void S0() {
    super.S0();
    Dialog dialog = this.u0;
    if (dialog != null) {
      this.v0 = false;
      dialog.show();
    } 
  }
  
  public void T0() {
    super.T0();
    Dialog dialog = this.u0;
    if (dialog != null)
      dialog.hide(); 
  }
  
  public void V0(Bundle paramBundle) {
    super.V0(paramBundle);
    if (this.u0 != null && paramBundle != null) {
      paramBundle = paramBundle.getBundle("android:savedDialogState");
      if (paramBundle != null)
        this.u0.onRestoreInstanceState(paramBundle); 
    } 
  }
  
  public final void X1(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.w0)
      return; 
    this.w0 = true;
    this.x0 = false;
    Dialog dialog = this.u0;
    if (dialog != null) {
      dialog.setOnDismissListener(null);
      this.u0.dismiss();
      if (!paramBoolean2)
        if (Looper.myLooper() == this.j0.getLooper()) {
          onDismiss((DialogInterface)this.u0);
        } else {
          this.j0.post(this.k0);
        }  
    } 
    this.v0 = true;
    if (this.r0 >= 0) {
      H().S0(this.r0, 1);
      this.r0 = -1;
      return;
    } 
    r r = H().m();
    r.k(this);
    if (paramBoolean1) {
      r.g();
      return;
    } 
    r.f();
  }
  
  public Dialog Y1() {
    return this.u0;
  }
  
  public int Z1() {
    return this.o0;
  }
  
  public Dialog a2(Bundle paramBundle) {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCreateDialog called for DialogFragment ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    return new Dialog(w1(), Z1());
  }
  
  public View b2(int paramInt) {
    Dialog dialog = this.u0;
    return (dialog != null) ? dialog.findViewById(paramInt) : null;
  }
  
  public void c1(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    super.c1(paramLayoutInflater, paramViewGroup, paramBundle);
    if (this.S == null && this.u0 != null && paramBundle != null) {
      Bundle bundle = paramBundle.getBundle("android:savedDialogState");
      if (bundle != null)
        this.u0.onRestoreInstanceState(bundle); 
    } 
  }
  
  public boolean c2() {
    return this.y0;
  }
  
  public final void d2(Bundle paramBundle) {
    if (!this.q0)
      return; 
    if (!this.y0)
      try {
        this.s0 = true;
        Dialog dialog = a2(paramBundle);
        this.u0 = dialog;
        if (this.q0) {
          f2(dialog, this.n0);
          Context context = t();
          if (context instanceof Activity)
            this.u0.setOwnerActivity((Activity)context); 
          this.u0.setCancelable(this.p0);
          this.u0.setOnCancelListener(this.l0);
          this.u0.setOnDismissListener(this.m0);
          this.y0 = true;
        } else {
          this.u0 = null;
        } 
        return;
      } finally {
        this.s0 = false;
      }  
  }
  
  public void e2(boolean paramBoolean) {
    this.q0 = paramBoolean;
  }
  
  public void f2(Dialog paramDialog, int paramInt) {
    if (paramInt != 1 && paramInt != 2) {
      if (paramInt != 3)
        return; 
      Window window = paramDialog.getWindow();
      if (window != null)
        window.addFlags(24); 
    } 
    paramDialog.requestWindowFeature(1);
  }
  
  public f g() {
    return new e(this, super.g());
  }
  
  public void g2(FragmentManager paramFragmentManager, String paramString) {
    this.w0 = false;
    this.x0 = true;
    r r = paramFragmentManager.m();
    r.d(this, paramString);
    r.f();
  }
  
  public void onCancel(DialogInterface paramDialogInterface) {}
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    if (!this.v0) {
      if (FragmentManager.E0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onDismiss called for DialogFragment ");
        stringBuilder.append(this);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      X1(true, true);
    } 
  }
  
  public void s0(Context paramContext) {
    super.s0(paramContext);
    X().i(this.t0);
    if (!this.x0)
      this.w0 = false; 
  }
  
  public void v0(Bundle paramBundle) {
    boolean bool;
    super.v0(paramBundle);
    this.j0 = new Handler();
    if (this.I == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.q0 = bool;
    if (paramBundle != null) {
      this.n0 = paramBundle.getInt("android:style", 0);
      this.o0 = paramBundle.getInt("android:theme", 0);
      this.p0 = paramBundle.getBoolean("android:cancelable", true);
      this.q0 = paramBundle.getBoolean("android:showsDialog", this.q0);
      this.r0 = paramBundle.getInt("android:backStackId", -1);
    } 
  }
  
  public class a implements Runnable {
    public a(c this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void run() {
      c.V1(this.a).onDismiss((DialogInterface)c.U1(this.a));
    }
  }
  
  public class b implements DialogInterface.OnCancelListener {
    public b(c this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void onCancel(DialogInterface param1DialogInterface) {
      if (c.U1(this.a) != null) {
        c c1 = this.a;
        c1.onCancel((DialogInterface)c.U1(c1));
      } 
    }
  }
  
  public class c implements DialogInterface.OnDismissListener {
    public c(c this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void onDismiss(DialogInterface param1DialogInterface) {
      if (c.U1(this.a) != null) {
        c c1 = this.a;
        c1.onDismiss((DialogInterface)c.U1(c1));
      } 
    }
  }
  
  public class d implements n<g> {
    public d(c this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void b(g param1g) {
      if (param1g != null && c.W1(this.a)) {
        View view = this.a.x1();
        if (view.getParent() == null) {
          if (c.U1(this.a) != null) {
            if (FragmentManager.E0(3)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("DialogFragment ");
              stringBuilder.append(this);
              stringBuilder.append(" setting the content view on ");
              stringBuilder.append(c.U1(this.a));
              Log.d("FragmentManager", stringBuilder.toString());
            } 
            c.U1(this.a).setContentView(view);
            return;
          } 
        } else {
          throw new IllegalStateException("DialogFragment can not be attached to a container view");
        } 
      } 
    }
  }
  
  public class e extends f {
    public e(c this$0, f param1f) {}
    
    public View e(int param1Int) {
      View view = this.b.b2(param1Int);
      return (view != null) ? view : (this.a.g() ? this.a.e(param1Int) : null);
    }
    
    public boolean g() {
      return (this.b.c2() || this.a.g());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */