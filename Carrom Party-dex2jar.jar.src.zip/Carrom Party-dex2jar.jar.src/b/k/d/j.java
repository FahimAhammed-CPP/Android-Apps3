package b.k.d;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import b.k.c;

public class j implements LayoutInflater.Factory2 {
  public final FragmentManager a;
  
  public j(FragmentManager paramFragmentManager) {
    this.a = paramFragmentManager;
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (FragmentContainerView.class.getName().equals(paramString))
      return (View)new FragmentContainerView(paramContext, paramAttributeSet, this.a); 
    boolean bool = "fragment".equals(paramString);
    paramString = null;
    if (!bool)
      return null; 
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c.a);
    String str2 = str1;
    if (str1 == null)
      str2 = typedArray.getString(c.b); 
    int i = typedArray.getResourceId(c.c, -1);
    String str3 = typedArray.getString(c.d);
    typedArray.recycle();
    if (str2 != null) {
      p p;
      boolean bool1;
      if (!h.b(paramContext.getClassLoader(), str2))
        return null; 
      if (paramView != null) {
        bool1 = paramView.getId();
      } else {
        bool1 = false;
      } 
      if (bool1 != -1 || i != -1 || str3 != null) {
        StringBuilder stringBuilder2;
        Fragment fragment2;
        if (i != -1)
          fragment1 = this.a.h0(i); 
        Fragment fragment3 = fragment1;
        if (fragment1 == null) {
          fragment3 = fragment1;
          if (str3 != null)
            fragment3 = this.a.i0(str3); 
        } 
        Fragment fragment1 = fragment3;
        if (fragment3 == null) {
          fragment1 = fragment3;
          if (bool1 != -1)
            fragment1 = this.a.h0(bool1); 
        } 
        if (fragment1 == null) {
          boolean bool2;
          fragment1 = this.a.q0().a(paramContext.getClassLoader(), str2);
          fragment1.n = true;
          if (i != 0) {
            bool2 = i;
          } else {
            bool2 = bool1;
          } 
          fragment1.H = bool2;
          fragment1.I = bool1;
          fragment1.J = str3;
          fragment1.o = true;
          FragmentManager fragmentManager = this.a;
          fragment1.D = fragmentManager;
          fragment1.E = fragmentManager.t0();
          fragment1.H0(this.a.t0().k(), paramAttributeSet, fragment1.b);
          p p1 = this.a.w(fragment1);
          this.a.g(fragment1);
          fragment2 = fragment1;
          p = p1;
          if (FragmentManager.E0(2)) {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Fragment ");
            stringBuilder3.append(fragment1);
            stringBuilder3.append(" has been inflated via the <fragment> tag: id=0x");
            stringBuilder3.append(Integer.toHexString(i));
            Log.v("FragmentManager", stringBuilder3.toString());
            Fragment fragment = fragment1;
            p = p1;
          } 
        } else if (!fragment1.o) {
          fragment1.o = true;
          FragmentManager fragmentManager = this.a;
          fragment1.D = fragmentManager;
          fragment1.E = fragmentManager.t0();
          fragment1.H0(this.a.t0().k(), (AttributeSet)p, fragment1.b);
          p p1 = this.a.w(fragment1);
          fragment2 = fragment1;
          p = p1;
          if (FragmentManager.E0(2)) {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Retained Fragment ");
            stringBuilder3.append(fragment1);
            stringBuilder3.append(" has been re-attached via the <fragment> tag: id=0x");
            stringBuilder3.append(Integer.toHexString(i));
            Log.v("FragmentManager", stringBuilder3.toString());
            p = p1;
            fragment2 = fragment1;
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append(p.getPositionDescription());
          stringBuilder2.append(": Duplicate id 0x");
          stringBuilder2.append(Integer.toHexString(i));
          stringBuilder2.append(", tag ");
          stringBuilder2.append(str3);
          stringBuilder2.append(", or parent id 0x");
          stringBuilder2.append(Integer.toHexString(bool1));
          stringBuilder2.append(" with another fragment for ");
          stringBuilder2.append(str2);
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
        fragment2.R = (ViewGroup)stringBuilder2;
        p.m();
        p.j();
        View view = fragment2.S;
        if (view != null) {
          if (i != 0)
            view.setId(i); 
          if (fragment2.S.getTag() == null)
            fragment2.S.setTag(str3); 
          return fragment2.S;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Fragment ");
        stringBuilder1.append(str2);
        stringBuilder1.append(" did not create a view.");
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(p.getPositionDescription());
      stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
      stringBuilder.append(str2);
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    return null;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */