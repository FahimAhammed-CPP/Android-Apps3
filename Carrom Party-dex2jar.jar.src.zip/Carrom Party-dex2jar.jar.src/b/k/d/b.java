package b.k.d;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import b.h.e.o;
import b.h.n.p;
import b.h.n.r;
import b.h.n.t;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class b extends x {
  public b(ViewGroup paramViewGroup) {
    super(paramViewGroup);
  }
  
  public void f(List<x.e> paramList, boolean paramBoolean) {
    Iterator<x.e> iterator2 = paramList.iterator();
    x.e e2 = null;
    x.e e1 = null;
    while (iterator2.hasNext()) {
      x.e e = iterator2.next();
      x.e.c c = x.e.c.h((e.f()).S);
      int i = a.a[e.e().ordinal()];
      if (i != 1 && i != 2 && i != 3) {
        if (i == 4 && c != x.e.c.b)
          e1 = e; 
        continue;
      } 
      if (c == x.e.c.b && e2 == null)
        e2 = e; 
    } 
    ArrayList<k> arrayList1 = new ArrayList();
    ArrayList<m> arrayList2 = new ArrayList();
    ArrayList<x.e> arrayList = new ArrayList<x.e>(paramList);
    for (x.e e : paramList) {
      b.h.j.b b1 = new b.h.j.b();
      e.j(b1);
      arrayList1.add(new k(e, b1));
      b1 = new b.h.j.b();
      e.j(b1);
      boolean bool = false;
      if (paramBoolean ? (e == e2) : (e == e1))
        bool = true; 
      arrayList2.add(new m(e, b1, paramBoolean, bool));
      e.a(new b(this, arrayList, e));
    } 
    Map<x.e, Boolean> map = x(arrayList2, paramBoolean, e2, e1);
    w(arrayList1, arrayList, map.containsValue(Boolean.TRUE), map);
    Iterator<x.e> iterator1 = arrayList.iterator();
    while (iterator1.hasNext())
      s(iterator1.next()); 
    arrayList.clear();
  }
  
  public void s(x.e parame) {
    View view = (parame.f()).S;
    parame.e().a(view);
  }
  
  public void t(ArrayList<View> paramArrayList, View paramView) {
    ViewGroup viewGroup;
    if (paramView instanceof ViewGroup) {
      viewGroup = (ViewGroup)paramView;
      if (t.a(viewGroup)) {
        paramArrayList.add(viewGroup);
        return;
      } 
      int j = viewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = viewGroup.getChildAt(i);
        if (view.getVisibility() == 0)
          t(paramArrayList, view); 
      } 
    } else {
      paramArrayList.add(viewGroup);
    } 
  }
  
  public void u(Map<String, View> paramMap, View paramView) {
    String str = r.v(paramView);
    if (str != null)
      paramMap.put(str, paramView); 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int j = viewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = viewGroup.getChildAt(i);
        if (view.getVisibility() == 0)
          u(paramMap, view); 
      } 
    } 
  }
  
  public void v(b.f.a<String, View> parama, Collection<String> paramCollection) {
    Iterator<Map.Entry> iterator = parama.entrySet().iterator();
    while (iterator.hasNext()) {
      if (!paramCollection.contains(r.v((View)((Map.Entry)iterator.next()).getValue())))
        iterator.remove(); 
    } 
  }
  
  public final void w(List<k> paramList, List<x.e> paramList1, boolean paramBoolean, Map<x.e, Boolean> paramMap) {
    ViewGroup viewGroup = m();
    Context context = viewGroup.getContext();
    ArrayList<k> arrayList = new ArrayList();
    null = paramList.iterator();
    boolean bool;
    for (bool = false; null.hasNext(); bool = true) {
      boolean bool1;
      StringBuilder stringBuilder;
      k k = null.next();
      if (k.d()) {
        k.a();
        continue;
      } 
      e.d d = k.e(context);
      if (d == null) {
        k.a();
        continue;
      } 
      Animator animator = d.b;
      if (animator == null) {
        arrayList.add(k);
        continue;
      } 
      x.e e = k.b();
      Fragment fragment = e.f();
      if (Boolean.TRUE.equals(paramMap.get(e))) {
        if (FragmentManager.E0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animator set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as this Fragment was involved in a Transition.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        k.a();
        continue;
      } 
      if (e.e() == x.e.c.c) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1)
        paramList1.remove(e); 
      View view = fragment.S;
      viewGroup.startViewTransition(view);
      stringBuilder.addListener((Animator.AnimatorListener)new c(this, viewGroup, view, bool1, e, k));
      stringBuilder.setTarget(view);
      stringBuilder.start();
      k.c().c(new d(this, (Animator)stringBuilder));
    } 
    for (k k : arrayList) {
      StringBuilder stringBuilder;
      x.e e = k.b();
      Fragment fragment = e.f();
      if (paramBoolean) {
        if (FragmentManager.E0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animation set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as Animations cannot run alongside Transitions.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        k.a();
        continue;
      } 
      if (bool) {
        if (FragmentManager.E0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animation set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as Animations cannot run alongside Animators.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        k.a();
        continue;
      } 
      View view = fragment.S;
      e.d d = k.e(context);
      b.h.m.h.b(d);
      Animation animation = d.a;
      b.h.m.h.b(animation);
      animation = animation;
      if (stringBuilder.e() != x.e.c.a) {
        view.startAnimation(animation);
        k.a();
      } else {
        viewGroup.startViewTransition(view);
        e.e e1 = new e.e(animation, viewGroup, view);
        e1.setAnimationListener(new e(this, viewGroup, view, k));
        view.startAnimation((Animation)e1);
      } 
      k.c().c(new f(this, view, viewGroup, k));
    } 
  }
  
  public final Map<x.e, Boolean> x(List<m> paramList, boolean paramBoolean, x.e parame1, x.e parame2) {
    StringBuilder stringBuilder;
    x.e e2 = parame1;
    x.e e1 = parame2;
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<m> iterator1 = paramList.iterator();
    u u1 = null;
    while (iterator1.hasNext()) {
      m m1 = iterator1.next();
      if (m1.d())
        continue; 
      u u = m1.e();
      if (u1 == null) {
        u1 = u;
        continue;
      } 
      if (u == null || u1 == u)
        continue; 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Mixing framework transitions and AndroidX transitions is not allowed. Fragment ");
      stringBuilder.append(m1.b().f());
      stringBuilder.append(" returned Transition ");
      stringBuilder.append(m1.h());
      stringBuilder.append(" which uses a different Transition  type than other Fragments.");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (u1 == null) {
      for (m m : stringBuilder) {
        hashMap.put(m.b(), Boolean.FALSE);
        m.a();
      } 
      return (Map)hashMap;
    } 
    View view3 = new View(m().getContext());
    Rect rect = new Rect();
    ArrayList<View> arrayList1 = new ArrayList();
    ArrayList<View> arrayList2 = new ArrayList();
    b.f.a<String, String> a = new b.f.a();
    Iterator<m> iterator2 = stringBuilder.iterator();
    ArrayList arrayList = null;
    View view2 = null;
    boolean bool = false;
    u u2 = u1;
    View view1 = view3;
    while (true) {
      m m2;
      x.e e3;
      ArrayList<View> arrayList6;
      Object object3;
      boolean bool1 = paramBoolean;
      if (iterator2.hasNext()) {
        m m3;
        x.e e4;
        x.e e5;
        m m4;
        m m6 = iterator2.next();
        if (m6.i() && e2 != null && e1 != null) {
          o o1;
          o o2;
          Object object = u2.B(u2.g(m6.g()));
          ArrayList<String> arrayList10 = parame2.f().P();
          arrayList = m.f().P();
          ArrayList arrayList11 = m.f().Q();
          int i;
          for (i = 0; i < arrayList11.size(); i++) {
            int k = arrayList10.indexOf(arrayList11.get(i));
            if (k != -1)
              arrayList10.set(k, arrayList.get(i)); 
          } 
          ArrayList<String> arrayList12 = parame2.f().Q();
          if (!bool1) {
            o2 = m.f().x();
            o1 = parame2.f().v();
          } else {
            o2 = m.f().v();
            o1 = parame2.f().x();
          } 
          i = arrayList10.size();
          int j;
          for (j = 0; j < i; j++)
            a.put(arrayList10.get(j), arrayList12.get(j)); 
          b.f.a<String, View> a1 = new b.f.a();
          u((Map<String, View>)a1, (m.f()).S);
          a1.o(arrayList10);
          if (o2 != null) {
            o2.a(arrayList10, (Map)a1);
            for (i = arrayList10.size() - 1; i >= 0; i--) {
              String str = arrayList10.get(i);
              View view = (View)a1.get(str);
              if (view == null) {
                a.remove(str);
              } else if (!str.equals(r.v(view))) {
                str = (String)a.remove(str);
                a.put(r.v(view), str);
              } 
            } 
          } else {
            a.o(a1.keySet());
          } 
          object3 = new b.f.a();
          u((Map<String, View>)object3, (parame2.f()).S);
          object3.o(arrayList12);
          object3.o(a.values());
          if (o1 != null) {
            o1.a(arrayList12, (Map)object3);
            for (i = arrayList12.size() - 1; i >= 0; i--) {
              String str1;
              String str2 = arrayList12.get(i);
              View view = (View)object3.get(str2);
              if (view == null) {
                str1 = s.q(a, str2);
                if (str1 != null)
                  a.remove(str1); 
              } else if (!str2.equals(r.v((View)str1))) {
                str2 = s.q(a, str2);
                if (str2 != null)
                  a.put(str2, r.v((View)str1)); 
              } 
            } 
          } else {
            s.y(a, (b.f.a<String, View>)object3);
          } 
          v(a1, a.keySet());
          v((b.f.a<String, View>)object3, a.values());
          if (a.isEmpty()) {
            arrayList1.clear();
            arrayList2.clear();
            m3 = m;
            object3 = null;
            e5 = parame2;
          } else {
            s.f(parame2.f(), m.f(), bool1, a1, true);
            p.a((View)m(), new g(this, parame2, (x.e)m, paramBoolean, (b.f.a)object3));
            Iterator<View> iterator4 = a1.values().iterator();
            while (iterator4.hasNext())
              t(arrayList1, iterator4.next()); 
            if (!m3.isEmpty()) {
              view2 = (View)a1.get(m3.get(0));
              u2.v(object, view2);
            } 
            Iterator<View> iterator3 = object3.values().iterator();
            while (iterator3.hasNext())
              t(arrayList2, iterator3.next()); 
            if (!arrayList12.isEmpty()) {
              View view = (View)object3.get(arrayList12.get(0));
              if (view != null) {
                p.a((View)m(), new h(this, u2, view, rect));
                bool = true;
              } 
            } 
            u2.z(object, view1, arrayList1);
            u2.t(object, null, null, null, null, object, arrayList2);
            Boolean bool2 = Boolean.TRUE;
            m3 = m;
            hashMap.put(m3, bool2);
            e5 = parame2;
            hashMap.put(e5, bool2);
            object3 = object;
          } 
        } else {
          x.e e6 = e5;
          m4 = m3;
          e4 = e6;
        } 
        ArrayList<View> arrayList9 = arrayList1;
        m m5 = m4;
        e3 = e4;
        m2 = m5;
        arrayList6 = arrayList9;
        continue;
      } 
      Object object1 = view2;
      ArrayList<View> arrayList4 = arrayList2;
      ArrayList<View> arrayList7 = arrayList6;
      view3 = view1;
      ArrayList<View> arrayList8 = new ArrayList();
      Iterator<m> iterator = stringBuilder.iterator();
      parame2 = null;
      View view5 = null;
      View view4 = (View)object1;
      m m1 = m2;
      object1 = view5;
      ArrayList<View> arrayList5 = arrayList7;
      while (iterator.hasNext()) {
        boolean bool2;
        m m3 = iterator.next();
        if (m3.d()) {
          hashMap.put(m3.b(), Boolean.FALSE);
          m3.a();
          continue;
        } 
        Object object = u2.g(m3.h());
        x.e e4 = m3.b();
        if (object3 != null && (e4 == e3 || e4 == m1)) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        if (object == null) {
          if (!bool2) {
            hashMap.put(e4, Boolean.FALSE);
            m3.a();
          } 
          continue;
        } 
        ArrayList<View> arrayList9 = new ArrayList();
        t(arrayList9, (e4.f()).S);
        if (bool2)
          if (e4 == e3) {
            arrayList9.removeAll(arrayList5);
          } else {
            arrayList9.removeAll(arrayList4);
          }  
        if (arrayList9.isEmpty()) {
          u2.a(object, view3);
        } else {
          u2.b(object, arrayList9);
          x.e e5 = e4;
          u2.t(object, object, arrayList9, null, null, null, null);
          if (e5.e() == x.e.c.c) {
            u2.r(object, (e5.f()).S, arrayList9);
            p.a((View)m(), new i(this, arrayList9));
          } 
        } 
        if (e4.e() == x.e.c.b) {
          arrayList8.addAll(arrayList9);
          if (bool)
            u2.u(object, rect); 
        } else {
          u2.v(object, view4);
        } 
        hashMap.put(e4, Boolean.TRUE);
        if (m3.j()) {
          object1 = u2.n(object1, object, null);
          continue;
        } 
        object2 = u2.n(parame2, object, null);
      } 
      object1 = u2.m(object1, object2, object3);
      for (Object object2 : stringBuilder) {
        if (object2.d())
          continue; 
        Object object = object2.h();
        x.e e4 = object2.b();
        if (object3 != null && (e4 == e3 || e4 == m1)) {
          bool = true;
        } else {
          bool = false;
        } 
        if (object != null || bool)
          u2.w(object2.b().f(), object1, object2.c(), new j(this, (m)object2)); 
      } 
      s.B(arrayList8, 4);
      ArrayList<String> arrayList3 = u2.o(arrayList4);
      u2.c(m(), object1);
      u2.y((View)m(), arrayList5, arrayList4, arrayList3, (Map<String, String>)a);
      s.B(arrayList8, 0);
      u2.A(object3, arrayList5, arrayList4);
      return (Map)hashMap;
    } 
  }
  
  public class b implements Runnable {
    public b(b this$0, List param1List, x.e param1e) {}
    
    public void run() {
      if (this.a.contains(this.b)) {
        this.a.remove(this.b);
        this.c.s(this.b);
      } 
    }
  }
  
  public class c extends AnimatorListenerAdapter {
    public c(b this$0, ViewGroup param1ViewGroup, View param1View, boolean param1Boolean, x.e param1e, b.k param1k) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      if (this.c)
        this.d.e().a(this.b); 
      this.e.a();
    }
  }
  
  public class d implements b.h.j.b.a {
    public d(b this$0, Animator param1Animator) {}
    
    public void a() {
      this.a.end();
    }
  }
  
  public class e implements Animation.AnimationListener {
    public e(b this$0, ViewGroup param1ViewGroup, View param1View, b.k param1k) {}
    
    public void onAnimationEnd(Animation param1Animation) {
      this.a.post(new a(this));
    }
    
    public void onAnimationRepeat(Animation param1Animation) {}
    
    public void onAnimationStart(Animation param1Animation) {}
    
    public class a implements Runnable {
      public a(b.e this$0) {}
      
      public void run() {
        b.e e1 = this.a;
        e1.a.endViewTransition(e1.b);
        this.a.c.a();
      }
    }
  }
  
  public class a implements Runnable {
    public a(b this$0) {}
    
    public void run() {
      b.e e1 = this.a;
      e1.a.endViewTransition(e1.b);
      this.a.c.a();
    }
  }
  
  public class f implements b.h.j.b.a {
    public f(b this$0, View param1View, ViewGroup param1ViewGroup, b.k param1k) {}
    
    public void a() {
      this.a.clearAnimation();
      this.b.endViewTransition(this.a);
      this.c.a();
    }
  }
  
  public class g implements Runnable {
    public g(b this$0, x.e param1e1, x.e param1e2, boolean param1Boolean, b.f.a param1a) {}
    
    public void run() {
      s.f(this.a.f(), this.b.f(), this.c, this.d, false);
    }
  }
  
  public class h implements Runnable {
    public h(b this$0, u param1u, View param1View, Rect param1Rect) {}
    
    public void run() {
      this.a.k(this.b, this.c);
    }
  }
  
  public class i implements Runnable {
    public i(b this$0, ArrayList param1ArrayList) {}
    
    public void run() {
      s.B(this.a, 4);
    }
  }
  
  public class j implements Runnable {
    public j(b this$0, b.m param1m) {}
    
    public void run() {
      this.a.a();
    }
  }
  
  public static class k extends l {
    public boolean c = false;
    
    public e.d d;
    
    public k(x.e param1e, b.h.j.b param1b) {
      super(param1e, param1b);
    }
    
    public e.d e(Context param1Context) {
      boolean bool;
      if (this.c)
        return this.d; 
      Fragment fragment = b().f();
      if (b().e() == x.e.c.b) {
        bool = true;
      } else {
        bool = false;
      } 
      e.d d1 = e.b(param1Context, fragment, bool);
      this.d = d1;
      this.c = true;
      return d1;
    }
  }
  
  public static class l {
    public final x.e a;
    
    public final b.h.j.b b;
    
    public l(x.e param1e, b.h.j.b param1b) {
      this.a = param1e;
      this.b = param1b;
    }
    
    public void a() {
      this.a.d(this.b);
    }
    
    public x.e b() {
      return this.a;
    }
    
    public b.h.j.b c() {
      return this.b;
    }
    
    public boolean d() {
      x.e.c c1 = x.e.c.h((this.a.f()).S);
      x.e.c c2 = this.a.e();
      if (c1 != c2) {
        x.e.c c = x.e.c.b;
        if (c1 == c || c2 == c)
          return false; 
      } 
      return true;
    }
  }
  
  public static class m extends l {
    public final Object c;
    
    public final boolean d;
    
    public final Object e;
    
    public m(x.e param1e, b.h.j.b param1b, boolean param1Boolean1, boolean param1Boolean2) {
      super(param1e, param1b);
      if (param1e.e() == x.e.c.b) {
        Object object;
        boolean bool;
        if (param1Boolean1) {
          object = param1e.f().J();
        } else {
          object = param1e.f().u();
        } 
        this.c = object;
        if (param1Boolean1) {
          bool = param1e.f().o();
        } else {
          bool = param1e.f().n();
        } 
        this.d = bool;
      } else {
        Object object;
        if (param1Boolean1) {
          object = param1e.f().M();
        } else {
          object = param1e.f().w();
        } 
        this.c = object;
        this.d = true;
      } 
      if (param1Boolean2) {
        if (param1Boolean1) {
          this.e = param1e.f().O();
          return;
        } 
        this.e = param1e.f().N();
        return;
      } 
      this.e = null;
    }
    
    public u e() {
      u u1 = f(this.c);
      u u2 = f(this.e);
      if (u1 == null || u2 == null || u1 == u2)
        return (u1 != null) ? u1 : u2; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Mixing framework transitions and AndroidX transitions is not allowed. Fragment ");
      stringBuilder.append(b().f());
      stringBuilder.append(" returned Transition ");
      stringBuilder.append(this.c);
      stringBuilder.append(" which uses a different Transition  type than its shared element transition ");
      stringBuilder.append(this.e);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public final u f(Object param1Object) {
      if (param1Object == null)
        return null; 
      u u = s.b;
      if (u != null && u.e(param1Object))
        return u; 
      u = s.c;
      if (u != null && u.e(param1Object))
        return u; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Transition ");
      stringBuilder.append(param1Object);
      stringBuilder.append(" for fragment ");
      stringBuilder.append(b().f());
      stringBuilder.append(" is not a valid framework Transition or AndroidX Transition");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Object g() {
      return this.e;
    }
    
    public Object h() {
      return this.c;
    }
    
    public boolean i() {
      return (this.e != null);
    }
    
    public boolean j() {
      return this.d;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */