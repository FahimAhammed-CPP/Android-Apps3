package b.k.d;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.util.concurrent.CopyOnWriteArrayList;

public class k {
  public final CopyOnWriteArrayList<a> a = new CopyOnWriteArrayList<a>();
  
  public final FragmentManager b;
  
  public k(FragmentManager paramFragmentManager) {
    this.b = paramFragmentManager;
  }
  
  public void a(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().a(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.a(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void b(Fragment paramFragment, boolean paramBoolean) {
    Context context = this.b.t0().k();
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().b(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.b(this.b, paramFragment, context); 
    } 
  }
  
  public void c(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().c(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.c(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void d(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().d(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.d(this.b, paramFragment); 
    } 
  }
  
  public void e(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().e(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.e(this.b, paramFragment); 
    } 
  }
  
  public void f(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().f(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.f(this.b, paramFragment); 
    } 
  }
  
  public void g(Fragment paramFragment, boolean paramBoolean) {
    Context context = this.b.t0().k();
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().g(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.g(this.b, paramFragment, context); 
    } 
  }
  
  public void h(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().h(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.h(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void i(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().i(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.i(this.b, paramFragment); 
    } 
  }
  
  public void j(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().j(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.j(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void k(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().k(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.k(this.b, paramFragment); 
    } 
  }
  
  public void l(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().l(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.l(this.b, paramFragment); 
    } 
  }
  
  public void m(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().m(paramFragment, paramView, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.m(this.b, paramFragment, paramView, paramBundle); 
    } 
  }
  
  public void n(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.w0();
    if (fragment != null)
      fragment.H().v0().n(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.n(this.b, paramFragment); 
    } 
  }
  
  public static final class a {
    public final FragmentManager.l a;
    
    public final boolean b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */