package b.k.d;

import android.util.Log;
import java.io.Writer;

public final class w extends Writer {
  public final String a;
  
  public StringBuilder b = new StringBuilder(128);
  
  public w(String paramString) {
    this.a = paramString;
  }
  
  public final void a() {
    if (this.b.length() > 0) {
      Log.d(this.a, this.b.toString());
      StringBuilder stringBuilder = this.b;
      stringBuilder.delete(0, stringBuilder.length());
    } 
  }
  
  public void close() {
    a();
  }
  
  public void flush() {
    a();
  }
  
  public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
    int i;
    for (i = 0; i < paramInt2; i++) {
      char c = paramArrayOfchar[paramInt1 + i];
      if (c == '\n') {
        a();
      } else {
        this.b.append(c);
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */