package b.k.d;

import android.util.Log;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import b.n.s;
import b.n.t;
import b.n.u;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public final class m extends s {
  public static final t.a i = new a();
  
  public final HashMap<String, Fragment> b = new HashMap<String, Fragment>();
  
  public final HashMap<String, m> c = new HashMap<String, m>();
  
  public final HashMap<String, u> d = new HashMap<String, u>();
  
  public final boolean e;
  
  public boolean f = false;
  
  public boolean g = false;
  
  public boolean h = false;
  
  public m(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public static m i(u paramu) {
    return (m)(new t(paramu, i)).a(m.class);
  }
  
  public void d() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCleared called for ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.f = true;
  }
  
  public void e(Fragment paramFragment) {
    if (this.h) {
      if (FragmentManager.E0(2))
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.b.containsKey(paramFragment.f))
      return; 
    this.b.put(paramFragment.f, paramFragment);
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject != null) {
      if (m.class != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      return (this.b.equals(((m)paramObject).b) && this.c.equals(((m)paramObject).c) && this.d.equals(((m)paramObject).d));
    } 
    return false;
  }
  
  public void f(Fragment paramFragment) {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing non-config state for ");
      stringBuilder.append(paramFragment);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    m m1 = this.c.get(paramFragment.f);
    if (m1 != null) {
      m1.d();
      this.c.remove(paramFragment.f);
    } 
    u u = this.d.get(paramFragment.f);
    if (u != null) {
      u.a();
      this.d.remove(paramFragment.f);
    } 
  }
  
  public Fragment g(String paramString) {
    return this.b.get(paramString);
  }
  
  public m h(Fragment paramFragment) {
    m m2 = this.c.get(paramFragment.f);
    m m1 = m2;
    if (m2 == null) {
      m1 = new m(this.e);
      this.c.put(paramFragment.f, m1);
    } 
    return m1;
  }
  
  public int hashCode() {
    return (this.b.hashCode() * 31 + this.c.hashCode()) * 31 + this.d.hashCode();
  }
  
  public Collection<Fragment> j() {
    return new ArrayList<Fragment>(this.b.values());
  }
  
  public u k(Fragment paramFragment) {
    u u2 = this.d.get(paramFragment.f);
    u u1 = u2;
    if (u2 == null) {
      u1 = new u();
      this.d.put(paramFragment.f, u1);
    } 
    return u1;
  }
  
  public boolean l() {
    return this.f;
  }
  
  public void m(Fragment paramFragment) {
    boolean bool;
    if (this.h) {
      if (FragmentManager.E0(2))
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.b.remove(paramFragment.f) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool && FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void n(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  public boolean o(Fragment paramFragment) {
    return !this.b.containsKey(paramFragment.f) ? true : (this.e ? this.f : (this.g ^ true));
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("FragmentManagerViewModel{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("} Fragments (");
    Iterator<String> iterator = this.b.values().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") Child Non Config (");
    iterator = this.c.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") ViewModelStores (");
    iterator = this.d.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public class a implements t.a {
    public <T extends s> T a(Class<T> param1Class) {
      return (T)new m(true);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */