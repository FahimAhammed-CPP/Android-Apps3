package b.k.d;

import android.util.Log;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.PrintWriter;
import java.util.ArrayList;

public final class a extends r implements FragmentManager.n {
  public final FragmentManager q;
  
  public boolean r;
  
  public int s;
  
  public a(FragmentManager paramFragmentManager) {
    super(h, classLoader);
    ClassLoader classLoader;
    this.s = -1;
    this.q = paramFragmentManager;
  }
  
  public static boolean w(r.a parama) {
    Fragment fragment = parama.b;
    return (fragment != null && fragment.l && fragment.S != null && !fragment.L && !fragment.K && fragment.i0());
  }
  
  public Fragment A(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = this.a.size() - 1;
    while (i >= 0) {
      r.a a1 = this.a.get(i);
      int j = a1.a;
      if (j != 1)
        if (j != 3) {
          switch (j) {
            case 10:
              a1.h = a1.g;
              break;
            case 9:
              paramFragment = a1.b;
              break;
            case 8:
              paramFragment = null;
              break;
            case 6:
              paramArrayList.add(a1.b);
              break;
            case 7:
              paramArrayList.remove(a1.b);
              break;
          } 
          i--;
        }  
    } 
    return paramFragment;
  }
  
  public boolean a(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.FALSE);
    if (this.g)
      this.q.e(this); 
    return true;
  }
  
  public int f() {
    return n(false);
  }
  
  public int g() {
    return n(true);
  }
  
  public void h() {
    i();
    this.q.c0(this, true);
  }
  
  public void j(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    super.j(paramInt1, paramFragment, paramString, paramInt2);
    paramFragment.D = this.q;
  }
  
  public r k(Fragment paramFragment) {
    FragmentManager fragmentManager = paramFragment.D;
    if (fragmentManager == null || fragmentManager == this.q) {
      super.k(paramFragment);
      return this;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
    stringBuilder.append(paramFragment.toString());
    stringBuilder.append(" is already attached to a FragmentManager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void m(int paramInt) {
    if (!this.g)
      return; 
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      r.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.C += paramInt;
        if (FragmentManager.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(a1.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a1.b.C);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  public int n(boolean paramBoolean) {
    if (!this.r) {
      if (FragmentManager.E0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter(new w("FragmentManager"));
        o("  ", printWriter);
        printWriter.close();
      } 
      this.r = true;
      if (this.g) {
        this.s = this.q.j();
      } else {
        this.s = -1;
      } 
      this.q.Z(this, paramBoolean);
      return this.s;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public void o(String paramString, PrintWriter paramPrintWriter) {
    p(paramString, paramPrintWriter, true);
  }
  
  public void p(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.h);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.s);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.r);
      if (this.f != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.f));
      } 
      if (this.b != 0 || this.c != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.b));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.c));
      } 
      if (this.d != 0 || this.e != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.d));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.e));
      } 
      if (this.i != 0 || this.j != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.i));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.j);
      } 
      if (this.k != 0 || this.l != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.k));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.l);
      } 
    } 
    if (!this.a.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      int j = this.a.size();
      int i;
      for (i = 0; i < j; i++) {
        StringBuilder stringBuilder;
        String str;
        r.a a1 = this.a.get(i);
        switch (a1.a) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("cmd=");
            stringBuilder.append(a1.a);
            str = stringBuilder.toString();
            break;
          case 10:
            str = "OP_SET_MAX_LIFECYCLE";
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(i);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a1.b);
        if (paramBoolean) {
          if (a1.c != 0 || a1.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.d));
          } 
          if (a1.e != 0 || a1.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.f));
          } 
        } 
      } 
    } 
  }
  
  public void q() {
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      StringBuilder stringBuilder;
      r.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.J1(this.f);
        fragment.N1(this.m, this.n);
      } 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.q.h1((Fragment)stringBuilder, a1.h);
          break;
        case 9:
          this.q.i1(null);
          break;
        case 8:
          this.q.i1((Fragment)stringBuilder);
          break;
        case 7:
          stringBuilder.I1(a1.c);
          this.q.g1((Fragment)stringBuilder, false);
          this.q.l((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.I1(a1.d);
          this.q.y((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.I1(a1.c);
          this.q.g1((Fragment)stringBuilder, false);
          this.q.k1((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.I1(a1.d);
          this.q.C0((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.I1(a1.d);
          this.q.Y0((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.I1(a1.c);
          this.q.g1((Fragment)stringBuilder, false);
          this.q.g((Fragment)stringBuilder);
          break;
      } 
      if (!this.o && a1.a != 1 && stringBuilder != null && !FragmentManager.P)
        this.q.M0((Fragment)stringBuilder); 
    } 
    if (!this.o && !FragmentManager.P) {
      FragmentManager fragmentManager = this.q;
      fragmentManager.N0(fragmentManager.q, true);
    } 
  }
  
  public void r(boolean paramBoolean) {
    for (int i = this.a.size() - 1; i >= 0; i--) {
      StringBuilder stringBuilder;
      r.a a1 = this.a.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.J1(FragmentManager.d1(this.f));
        fragment.N1(this.n, this.m);
      } 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.q.h1((Fragment)stringBuilder, a1.g);
          break;
        case 9:
          this.q.i1((Fragment)stringBuilder);
          break;
        case 8:
          this.q.i1(null);
          break;
        case 7:
          stringBuilder.I1(a1.f);
          this.q.g1((Fragment)stringBuilder, true);
          this.q.y((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.I1(a1.e);
          this.q.l((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.I1(a1.f);
          this.q.g1((Fragment)stringBuilder, true);
          this.q.C0((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.I1(a1.e);
          this.q.k1((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.I1(a1.e);
          this.q.g((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.I1(a1.f);
          this.q.g1((Fragment)stringBuilder, true);
          this.q.Y0((Fragment)stringBuilder);
          break;
      } 
      if (!this.o && a1.a != 3 && stringBuilder != null && !FragmentManager.P)
        this.q.M0((Fragment)stringBuilder); 
    } 
    if (!this.o && paramBoolean && !FragmentManager.P) {
      FragmentManager fragmentManager = this.q;
      fragmentManager.N0(fragmentManager.q, true);
    } 
  }
  
  public Fragment s(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = 0;
    Fragment fragment;
    for (fragment = paramFragment; i < this.a.size(); fragment = paramFragment) {
      Fragment fragment1;
      r.a a1 = this.a.get(i);
      int j = a1.a;
      if (j != 1)
        if (j != 2) {
          if (j != 3 && j != 6) {
            if (j != 7) {
              if (j != 8) {
                paramFragment = fragment;
                j = i;
              } else {
                this.a.add(i, new r.a(9, fragment));
                j = i + 1;
                paramFragment = a1.b;
              } 
              continue;
            } 
          } else {
            paramArrayList.remove(a1.b);
            fragment1 = a1.b;
            paramFragment = fragment;
            j = i;
            if (fragment1 == fragment) {
              this.a.add(i, new r.a(9, fragment1));
              j = i + 1;
              paramFragment = null;
            } 
            continue;
          } 
        } else {
          Fragment fragment2 = ((r.a)fragment1).b;
          int m = fragment2.I;
          int k = paramArrayList.size() - 1;
          boolean bool = false;
          j = i;
          paramFragment = fragment;
          while (k >= 0) {
            Fragment fragment3 = paramArrayList.get(k);
            fragment = paramFragment;
            i = j;
            boolean bool1 = bool;
            if (fragment3.I == m)
              if (fragment3 == fragment2) {
                bool1 = true;
                fragment = paramFragment;
                i = j;
              } else {
                fragment = paramFragment;
                i = j;
                if (fragment3 == paramFragment) {
                  this.a.add(j, new r.a(9, fragment3));
                  i = j + 1;
                  fragment = null;
                } 
                r.a a2 = new r.a(3, fragment3);
                a2.c = ((r.a)fragment1).c;
                a2.e = ((r.a)fragment1).e;
                a2.d = ((r.a)fragment1).d;
                a2.f = ((r.a)fragment1).f;
                this.a.add(i, a2);
                paramArrayList.remove(fragment3);
                i++;
                bool1 = bool;
              }  
            k--;
            paramFragment = fragment;
            j = i;
            bool = bool1;
          } 
          if (bool) {
            this.a.remove(j);
            j--;
          } else {
            ((r.a)fragment1).a = 1;
            paramArrayList.add(fragment2);
          } 
          continue;
        }  
      paramArrayList.add(((r.a)fragment1).b);
      j = i;
      paramFragment = fragment;
      continue;
      i = SYNTHETIC_LOCAL_VARIABLE_3 + 1;
    } 
    return fragment;
  }
  
  public String t() {
    return this.h;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.s >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.s);
    } 
    if (this.h != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.h);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public boolean u(int paramInt) {
    int j = this.a.size();
    for (int i = 0; i < j; i++) {
      int k;
      Fragment fragment = ((r.a)this.a.get(i)).b;
      if (fragment != null) {
        k = fragment.I;
      } else {
        k = 0;
      } 
      if (k && k == paramInt)
        return true; 
    } 
    return false;
  }
  
  public boolean v(ArrayList<a> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int k = this.a.size();
    int j = -1;
    int i = 0;
    while (i < k) {
      int m;
      Fragment fragment = ((r.a)this.a.get(i)).b;
      if (fragment != null) {
        m = fragment.I;
      } else {
        m = 0;
      } 
      int i1 = j;
      if (m) {
        i1 = j;
        if (m != j) {
          for (j = paramInt1; j < paramInt2; j++) {
            a a1 = paramArrayList.get(j);
            int i2 = a1.a.size();
            for (i1 = 0; i1 < i2; i1++) {
              int i3;
              Fragment fragment1 = ((r.a)a1.a.get(i1)).b;
              if (fragment1 != null) {
                i3 = fragment1.I;
              } else {
                i3 = 0;
              } 
              if (i3 == m)
                return true; 
            } 
          } 
          i1 = m;
        } 
      } 
      i++;
      j = i1;
    } 
    return false;
  }
  
  public boolean x() {
    for (int i = 0; i < this.a.size(); i++) {
      if (w(this.a.get(i)))
        return true; 
    } 
    return false;
  }
  
  public void y() {
    if (this.p != null) {
      for (int i = 0; i < this.p.size(); i++)
        ((Runnable)this.p.get(i)).run(); 
      this.p = null;
    } 
  }
  
  public void z(Fragment.g paramg) {
    for (int i = 0; i < this.a.size(); i++) {
      r.a a1 = this.a.get(i);
      if (w(a1))
        a1.b.K1(paramg); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */