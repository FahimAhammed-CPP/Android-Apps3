package b.k.d;

import android.os.Bundle;
import androidx.savedstate.SavedStateRegistry;
import b.n.d;
import b.n.g;
import b.n.h;
import b.s.b;
import b.s.c;

public class v implements c {
  public h a = null;
  
  public b b = null;
  
  public d a() {
    d();
    return (d)this.a;
  }
  
  public void b(d.b paramb) {
    this.a.h(paramb);
  }
  
  public void d() {
    if (this.a == null) {
      this.a = new h((g)this);
      this.b = b.a(this);
    } 
  }
  
  public boolean e() {
    return (this.a != null);
  }
  
  public void f(Bundle paramBundle) {
    this.b.c(paramBundle);
  }
  
  public void g(Bundle paramBundle) {
    this.b.d(paramBundle);
  }
  
  public void h(d.c paramc) {
    this.a.o(paramc);
  }
  
  public SavedStateRegistry j() {
    return this.b.b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */