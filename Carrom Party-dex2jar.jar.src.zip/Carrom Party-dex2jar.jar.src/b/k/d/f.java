package b.k.d;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;

public abstract class f {
  @Deprecated
  public Fragment d(Context paramContext, String paramString, Bundle paramBundle) {
    return Fragment.a0(paramContext, paramString, paramBundle);
  }
  
  public abstract View e(int paramInt);
  
  public abstract boolean g();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */