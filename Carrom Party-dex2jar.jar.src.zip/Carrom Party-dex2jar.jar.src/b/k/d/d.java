package b.k.d;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.savedstate.SavedStateRegistry;
import b.h.e.a;
import b.n.g;
import b.n.h;
import b.n.u;
import b.n.v;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class d extends ComponentActivity implements a.c, a.e {
  public final g i = g.b(new c(this));
  
  public final h j = new h((g)this);
  
  public boolean k;
  
  public boolean l;
  
  public boolean m = true;
  
  public d() {
    t();
  }
  
  public static boolean v(FragmentManager paramFragmentManager, b.n.d.c paramc) {
    Iterator<Fragment> iterator = paramFragmentManager.s0().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment == null)
        continue; 
      boolean bool1 = bool;
      if (fragment.A() != null)
        bool1 = bool | v(fragment.s(), paramc); 
      v v = fragment.d0;
      bool = bool1;
      if (v != null) {
        bool = bool1;
        if (v.a().b().a(b.n.d.c.d)) {
          fragment.d0.h(paramc);
          bool = true;
        } 
      } 
      if (fragment.c0.b().a(b.n.d.c.d)) {
        fragment.c0.o(paramc);
        bool = true;
      } 
    } 
    return bool;
  }
  
  @Deprecated
  public final void b(int paramInt) {}
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.k);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.l);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.m);
    if (getApplication() != null)
      b.o.a.a.b((g)this).a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.i.t().X(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    this.i.u();
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.i.u();
    this.i.d(paramConfiguration);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.j.h(b.n.d.b.ON_CREATE);
    this.i.f();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt == 0) ? (super.onCreatePanelMenu(paramInt, paramMenu) | this.i.g(paramMenu, getMenuInflater())) : super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = q(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = q(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.i.h();
    this.j.h(b.n.d.b.ON_DESTROY);
  }
  
  public void onLowMemory() {
    super.onLowMemory();
    this.i.i();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt != 0) ? ((paramInt != 6) ? false : this.i.e(paramMenuItem)) : this.i.k(paramMenuItem));
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    this.i.j(paramBoolean);
  }
  
  public void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.i.u();
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    if (paramInt == 0)
      this.i.l(paramMenu); 
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPause() {
    super.onPause();
    this.l = false;
    this.i.m();
    this.j.h(b.n.d.b.ON_PAUSE);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    this.i.n(paramBoolean);
  }
  
  public void onPostResume() {
    super.onPostResume();
    y();
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0) ? (x(paramView, paramMenu) | this.i.o(paramMenu)) : super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.i.u();
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint);
  }
  
  public void onResume() {
    super.onResume();
    this.l = true;
    this.i.u();
    this.i.s();
  }
  
  public void onStart() {
    super.onStart();
    this.m = false;
    if (!this.k) {
      this.k = true;
      this.i.c();
    } 
    this.i.u();
    this.i.s();
    this.j.h(b.n.d.b.ON_START);
    this.i.q();
  }
  
  public void onStateNotSaved() {
    this.i.u();
  }
  
  public void onStop() {
    super.onStop();
    this.m = true;
    u();
    this.i.r();
    this.j.h(b.n.d.b.ON_STOP);
  }
  
  public final View q(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.i.v(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public FragmentManager r() {
    return this.i.t();
  }
  
  @Deprecated
  public b.o.a.a s() {
    return b.o.a.a.b((g)this);
  }
  
  public final void t() {
    j().d("android:support:fragments", new a(this));
    m(new b(this));
  }
  
  public void u() {
    do {
    
    } while (v(r(), b.n.d.c.c));
  }
  
  @Deprecated
  public void w(Fragment paramFragment) {}
  
  @Deprecated
  public boolean x(View paramView, Menu paramMenu) {
    return super.onPreparePanel(0, paramView, paramMenu);
  }
  
  public void y() {
    this.j.h(b.n.d.b.ON_RESUME);
    this.i.p();
  }
  
  @Deprecated
  public void z() {
    invalidateOptionsMenu();
  }
  
  public class a implements SavedStateRegistry.b {
    public a(d this$0) {}
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      this.a.u();
      this.a.j.h(b.n.d.b.ON_STOP);
      Parcelable parcelable = this.a.i.x();
      if (parcelable != null)
        bundle.putParcelable("android:support:fragments", parcelable); 
      return bundle;
    }
  }
  
  public class b implements b.a.d.b {
    public b(d this$0) {}
    
    public void a(Context param1Context) {
      this.a.i.a(null);
      Bundle bundle = this.a.j().a("android:support:fragments");
      if (bundle != null) {
        Parcelable parcelable = bundle.getParcelable("android:support:fragments");
        this.a.i.w(parcelable);
      } 
    }
  }
  
  public class c extends i<d> implements v, b.a.c, b.a.e.d, n {
    public c(d this$0) {
      super(this$0);
    }
    
    public b.n.d a() {
      return (b.n.d)this.e.j;
    }
    
    public void b(FragmentManager param1FragmentManager, Fragment param1Fragment) {
      this.e.w(param1Fragment);
    }
    
    public OnBackPressedDispatcher c() {
      return this.e.c();
    }
    
    public View e(int param1Int) {
      return this.e.findViewById(param1Int);
    }
    
    public b.a.e.c f() {
      return this.e.f();
    }
    
    public boolean g() {
      Window window = this.e.getWindow();
      return (window != null && window.peekDecorView() != null);
    }
    
    public u h() {
      return this.e.h();
    }
    
    public LayoutInflater n() {
      return this.e.getLayoutInflater().cloneInContext((Context)this.e);
    }
    
    public boolean o(Fragment param1Fragment) {
      return this.e.isFinishing() ^ true;
    }
    
    public void q() {
      this.e.z();
    }
    
    public d r() {
      return this.e;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */