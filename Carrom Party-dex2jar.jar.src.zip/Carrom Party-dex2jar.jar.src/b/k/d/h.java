package b.k.d;

import androidx.fragment.app.Fragment;
import b.f.g;

public class h {
  public static final g<ClassLoader, g<String, Class<?>>> a = new g();
  
  public static boolean b(ClassLoader paramClassLoader, String paramString) {
    try {
      return Fragment.class.isAssignableFrom(c(paramClassLoader, paramString));
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } 
  }
  
  public static Class<?> c(ClassLoader paramClassLoader, String paramString) {
    g<ClassLoader, g<String, Class<?>>> g3 = a;
    g g2 = (g)g3.get(paramClassLoader);
    g g1 = g2;
    if (g2 == null) {
      g1 = new g();
      g3.put(paramClassLoader, g1);
    } 
    Class<?> clazz2 = (Class)g1.get(paramString);
    Class<?> clazz1 = clazz2;
    if (clazz2 == null) {
      clazz1 = Class.forName(paramString, false, paramClassLoader);
      g1.put(paramString, clazz1);
    } 
    return clazz1;
  }
  
  public static Class<? extends Fragment> d(ClassLoader paramClassLoader, String paramString) {
    try {
      return (Class)c(paramClassLoader, paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists");
      throw new Fragment.e(stringBuilder.toString(), classNotFoundException);
    } catch (ClassCastException classCastException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class is a valid subclass of Fragment");
      throw new Fragment.e(stringBuilder.toString(), classCastException);
    } 
  }
  
  public Fragment a(ClassLoader paramClassLoader, String paramString) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */