package b.k.d;

import android.util.AndroidRuntimeException;

public final class z extends AndroidRuntimeException {
  public z(String paramString) {
    super(paramString);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */