package b.k.d;

import android.os.Bundle;

public interface o {
  void a(String paramString, Bundle paramBundle);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */