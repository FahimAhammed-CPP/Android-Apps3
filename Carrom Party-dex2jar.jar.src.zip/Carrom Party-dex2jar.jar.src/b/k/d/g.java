package b.k.d;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import b.h.m.h;

public class g {
  public final i<?> a;
  
  public g(i<?> parami) {
    this.a = parami;
  }
  
  public static g b(i<?> parami) {
    h.c(parami, "callbacks == null");
    return new g(parami);
  }
  
  public void a(Fragment paramFragment) {
    i<?> i1 = this.a;
    i1.d.k(i1, i1, paramFragment);
  }
  
  public void c() {
    this.a.d.z();
  }
  
  public void d(Configuration paramConfiguration) {
    this.a.d.B(paramConfiguration);
  }
  
  public boolean e(MenuItem paramMenuItem) {
    return this.a.d.C(paramMenuItem);
  }
  
  public void f() {
    this.a.d.D();
  }
  
  public boolean g(Menu paramMenu, MenuInflater paramMenuInflater) {
    return this.a.d.E(paramMenu, paramMenuInflater);
  }
  
  public void h() {
    this.a.d.F();
  }
  
  public void i() {
    this.a.d.H();
  }
  
  public void j(boolean paramBoolean) {
    this.a.d.I(paramBoolean);
  }
  
  public boolean k(MenuItem paramMenuItem) {
    return this.a.d.K(paramMenuItem);
  }
  
  public void l(Menu paramMenu) {
    this.a.d.L(paramMenu);
  }
  
  public void m() {
    this.a.d.N();
  }
  
  public void n(boolean paramBoolean) {
    this.a.d.O(paramBoolean);
  }
  
  public boolean o(Menu paramMenu) {
    return this.a.d.P(paramMenu);
  }
  
  public void p() {
    this.a.d.R();
  }
  
  public void q() {
    this.a.d.S();
  }
  
  public void r() {
    this.a.d.U();
  }
  
  public boolean s() {
    return this.a.d.b0(true);
  }
  
  public FragmentManager t() {
    return this.a.d;
  }
  
  public void u() {
    this.a.d.Q0();
  }
  
  public View v(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.a.d.u0().onCreateView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void w(Parcelable paramParcelable) {
    i<?> i1 = this.a;
    if (i1 instanceof b.n.v) {
      i1.d.c1(paramParcelable);
      return;
    } 
    throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
  }
  
  public Parcelable x() {
    return this.a.d.e1();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\d\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */