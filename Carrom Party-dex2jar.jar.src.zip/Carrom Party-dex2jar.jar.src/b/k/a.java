package b.k;

public final class a {
  public static final int a = 2130837504;
  
  public static final int b = 2130837505;
  
  public static final int c = 2130837506;
  
  public static final int d = 2130837507;
  
  public static final int e = 2130837508;
  
  public static final int f = 2130837509;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\k\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */