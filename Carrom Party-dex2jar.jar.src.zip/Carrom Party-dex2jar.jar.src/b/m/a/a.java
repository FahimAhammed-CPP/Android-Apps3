package b.m.a;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.util.Log;
import android.util.SparseArray;

@Deprecated
public abstract class a extends BroadcastReceiver {
  public static final SparseArray<PowerManager.WakeLock> a = new SparseArray();
  
  public static int b = 1;
  
  public static boolean b(Intent paramIntent) {
    int i = paramIntent.getIntExtra("androidx.contentpager.content.wakelockid", 0);
    if (i == 0)
      return false; 
    synchronized (a) {
      PowerManager.WakeLock wakeLock = (PowerManager.WakeLock)null.get(i);
      if (wakeLock != null) {
        wakeLock.release();
        null.remove(i);
        return true;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("No active wake lock id #");
      stringBuilder.append(i);
      Log.w("WakefulBroadcastReceiv.", stringBuilder.toString());
      return true;
    } 
  }
  
  public static ComponentName c(Context paramContext, Intent paramIntent) {
    synchronized (a) {
      int i = b;
      int j = i + 1;
      b = j;
      if (j <= 0)
        b = 1; 
      paramIntent.putExtra("androidx.contentpager.content.wakelockid", i);
      ComponentName componentName = paramContext.startService(paramIntent);
      if (componentName == null)
        return null; 
      PowerManager powerManager = (PowerManager)paramContext.getSystemService("power");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("androidx.core:wake:");
      stringBuilder.append(componentName.flattenToShortString());
      PowerManager.WakeLock wakeLock = powerManager.newWakeLock(1, stringBuilder.toString());
      wakeLock.setReferenceCounted(false);
      wakeLock.acquire(60000L);
      null.put(i, wakeLock);
      return componentName;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\m\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */