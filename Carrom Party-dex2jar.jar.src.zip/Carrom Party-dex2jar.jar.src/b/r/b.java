package b.r;

import b.t.a.f;

public abstract class b<T> extends o {
  public b(i parami) {
    super(parami);
  }
  
  public abstract void g(f paramf, T paramT);
  
  public final void h(T paramT) {
    f f = a();
    try {
      g(f, paramT);
      f.Z1();
      return;
    } finally {
      f(f);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */