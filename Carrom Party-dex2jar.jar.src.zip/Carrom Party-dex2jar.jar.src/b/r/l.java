package b.r;

import b.t.a.d;
import b.t.a.e;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class l implements e, d {
  public static final TreeMap<Integer, l> i = new TreeMap<Integer, l>();
  
  public volatile String a;
  
  public final long[] b;
  
  public final double[] c;
  
  public final String[] d;
  
  public final byte[][] e;
  
  public final int[] f;
  
  public final int g;
  
  public int h;
  
  public l(int paramInt) {
    this.g = paramInt;
    this.f = new int[++paramInt];
    this.b = new long[paramInt];
    this.c = new double[paramInt];
    this.d = new String[paramInt];
    this.e = new byte[paramInt][];
  }
  
  public static l c(String paramString, int paramInt) {
    TreeMap<Integer, l> treeMap;
    l l1;
    synchronized (i) {
      Map.Entry<Integer, l> entry = treeMap.ceilingEntry(Integer.valueOf(paramInt));
      if (entry != null) {
        treeMap.remove(entry.getKey());
        l l2 = entry.getValue();
        l2.d(paramString, paramInt);
        return l2;
      } 
      l1 = new l(paramInt);
      l1.d(paramString, paramInt);
      return l1;
    } 
  }
  
  public static void e() {
    TreeMap<Integer, l> treeMap = i;
    if (treeMap.size() > 15) {
      int i = treeMap.size() - 10;
      Iterator iterator = treeMap.descendingKeySet().iterator();
      while (i > 0) {
        iterator.next();
        iterator.remove();
        i--;
      } 
    } 
  }
  
  public void D0(int paramInt, byte[] paramArrayOfbyte) {
    this.f[paramInt] = 5;
    this.e[paramInt] = paramArrayOfbyte;
  }
  
  public void I(int paramInt, String paramString) {
    this.f[paramInt] = 4;
    this.d[paramInt] = paramString;
  }
  
  public void Z(int paramInt, double paramDouble) {
    this.f[paramInt] = 3;
    this.c[paramInt] = paramDouble;
  }
  
  public String a() {
    return this.a;
  }
  
  public void b(d paramd) {
    for (int i = 1; i <= this.h; i++) {
      int j = this.f[i];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            if (j != 4) {
              if (j == 5)
                paramd.D0(i, this.e[i]); 
            } else {
              paramd.I(i, this.d[i]);
            } 
          } else {
            paramd.Z(i, this.c[i]);
          } 
        } else {
          paramd.t0(i, this.b[i]);
        } 
      } else {
        paramd.l1(i);
      } 
    } 
  }
  
  public void close() {}
  
  public void d(String paramString, int paramInt) {
    this.a = paramString;
    this.h = paramInt;
  }
  
  public void f() {
    synchronized (i) {
      null.put(Integer.valueOf(this.g), this);
      e();
      return;
    } 
  }
  
  public void l1(int paramInt) {
    this.f[paramInt] = 1;
  }
  
  public void t0(int paramInt, long paramLong) {
    this.f[paramInt] = 2;
    this.b[paramInt] = paramLong;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */