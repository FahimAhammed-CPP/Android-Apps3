package b.r;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface c extends IInterface {
  void A1(String[] paramArrayOfString);
  
  public static abstract class a extends Binder implements c {
    public a() {
      attachInterface(this, "androidx.room.IMultiInstanceInvalidationCallback");
    }
    
    public static c a0(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("androidx.room.IMultiInstanceInvalidationCallback");
      return (iInterface != null && iInterface instanceof c) ? (c)iInterface : new a(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      if (param1Int1 != 1) {
        if (param1Int1 != 1598968902)
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
        param1Parcel2.writeString("androidx.room.IMultiInstanceInvalidationCallback");
        return true;
      } 
      param1Parcel1.enforceInterface("androidx.room.IMultiInstanceInvalidationCallback");
      A1(param1Parcel1.createStringArray());
      return true;
    }
    
    public static class a implements c {
      public IBinder a;
      
      public a(IBinder param2IBinder) {
        this.a = param2IBinder;
      }
      
      public void A1(String[] param2ArrayOfString) {
        Parcel parcel = Parcel.obtain();
        try {
          parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
          parcel.writeStringArray(param2ArrayOfString);
          this.a.transact(1, parcel, null, 1);
          return;
        } finally {
          parcel.recycle();
        } 
      }
      
      public IBinder asBinder() {
        return this.a;
      }
    }
  }
  
  public static class a implements c {
    public IBinder a;
    
    public a(IBinder param1IBinder) {
      this.a = param1IBinder;
    }
    
    public void A1(String[] param1ArrayOfString) {
      Parcel parcel = Parcel.obtain();
      try {
        parcel.writeInterfaceToken("androidx.room.IMultiInstanceInvalidationCallback");
        parcel.writeStringArray(param1ArrayOfString);
        this.a.transact(1, parcel, null, 1);
        return;
      } finally {
        parcel.recycle();
      } 
    }
    
    public IBinder asBinder() {
      return this.a;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */