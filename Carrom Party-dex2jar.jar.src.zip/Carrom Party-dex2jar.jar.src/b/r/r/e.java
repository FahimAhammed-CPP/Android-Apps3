package b.r.r;

public class e {
  static {
  
  }
  
  public static void a(StringBuilder paramStringBuilder, int paramInt) {
    for (int i = 0; i < paramInt; i++) {
      paramStringBuilder.append("?");
      if (i < paramInt - 1)
        paramStringBuilder.append(","); 
    } 
  }
  
  public static StringBuilder b() {
    return new StringBuilder();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\r\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */