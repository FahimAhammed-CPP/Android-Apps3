package b.r.r;

import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.os.Build;
import android.os.CancellationSignal;
import b.r.i;
import b.t.a.b;
import b.t.a.e;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

public class c {
  public static void a(b paramb) {
    ArrayList<String> arrayList = new ArrayList();
    Cursor cursor = paramb.M0("SELECT name FROM sqlite_master WHERE type = 'trigger'");
    try {
      while (cursor.moveToNext())
        arrayList.add(cursor.getString(0)); 
      cursor.close();
      return;
    } finally {
      cursor.close();
    } 
  }
  
  public static Cursor b(i parami, e parame, boolean paramBoolean, CancellationSignal paramCancellationSignal) {
    AbstractWindowedCursor abstractWindowedCursor;
    Cursor cursor = parami.q(parame, paramCancellationSignal);
    null = cursor;
    if (paramBoolean) {
      null = cursor;
      if (cursor instanceof AbstractWindowedCursor) {
        int j;
        abstractWindowedCursor = (AbstractWindowedCursor)cursor;
        int k = abstractWindowedCursor.getCount();
        if (abstractWindowedCursor.hasWindow()) {
          j = abstractWindowedCursor.getWindow().getNumRows();
        } else {
          j = k;
        } 
        if (Build.VERSION.SDK_INT >= 23) {
          null = cursor;
          return (j < k) ? b.a((Cursor)abstractWindowedCursor) : null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return b.a((Cursor)abstractWindowedCursor);
  }
  
  public static int c(File paramFile) {
    FileChannel fileChannel2 = null;
    FileChannel fileChannel1 = fileChannel2;
    try {
      ByteBuffer byteBuffer = ByteBuffer.allocate(4);
      fileChannel1 = fileChannel2;
      FileChannel fileChannel = (new FileInputStream(paramFile)).getChannel();
      fileChannel1 = fileChannel;
      fileChannel.tryLock(60L, 4L, true);
      fileChannel1 = fileChannel;
      fileChannel.position(60L);
      fileChannel1 = fileChannel;
      if (fileChannel.read(byteBuffer) == 4) {
        fileChannel1 = fileChannel;
        byteBuffer.rewind();
        fileChannel1 = fileChannel;
        return byteBuffer.getInt();
      } 
      fileChannel1 = fileChannel;
      throw new IOException("Bad database header, unable to read 4 bytes at offset 60");
    } finally {
      if (fileChannel1 != null)
        fileChannel1.close(); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\r\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */