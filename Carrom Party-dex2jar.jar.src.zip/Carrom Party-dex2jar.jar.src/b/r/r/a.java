package b.r.r;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class a {
  public static final Map<String, Lock> e = new HashMap<String, Lock>();
  
  public final File a;
  
  public final Lock b;
  
  public final boolean c;
  
  public FileChannel d;
  
  public a(String paramString, File paramFile, boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(".lck");
    File file = new File(paramFile, stringBuilder.toString());
    this.a = file;
    this.b = a(file.getAbsolutePath());
    this.c = paramBoolean;
  }
  
  public static Lock a(String paramString) {
    synchronized (e) {
      Lock lock2 = null.get(paramString);
      Lock lock1 = lock2;
      if (lock2 == null) {
        lock1 = new ReentrantLock();
        null.put(paramString, lock1);
      } 
      return lock1;
    } 
  }
  
  public void b() {
    this.b.lock();
    if (this.c)
      try {
        FileChannel fileChannel = (new FileOutputStream(this.a)).getChannel();
        this.d = fileChannel;
        fileChannel.lock();
        return;
      } catch (IOException iOException) {
        throw new IllegalStateException("Unable to grab copy lock.", iOException);
      }  
  }
  
  public void c() {
    FileChannel fileChannel = this.d;
    if (fileChannel != null)
      try {
        fileChannel.close();
      } catch (IOException iOException) {} 
    this.b.unlock();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\r\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */