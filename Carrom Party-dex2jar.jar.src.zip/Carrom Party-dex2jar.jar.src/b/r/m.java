package b.r;

import android.content.Context;
import b.r.r.a;
import b.r.r.d;
import b.t.a.b;
import b.t.a.c;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class m implements c {
  public final Context a;
  
  public final String b;
  
  public final File c;
  
  public final int d;
  
  public final c e;
  
  public a f;
  
  public boolean g;
  
  public m(Context paramContext, String paramString, File paramFile, int paramInt, c paramc) {
    this.a = paramContext;
    this.b = paramString;
    this.c = paramFile;
    this.d = paramInt;
    this.e = paramc;
  }
  
  public b K0() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield g : Z
    //   6: ifne -> 18
    //   9: aload_0
    //   10: invokevirtual c : ()V
    //   13: aload_0
    //   14: iconst_1
    //   15: putfield g : Z
    //   18: aload_0
    //   19: getfield e : Lb/t/a/c;
    //   22: invokeinterface K0 : ()Lb/t/a/b;
    //   27: astore_1
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_1
    //   31: areturn
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	32	finally
    //   18	28	32	finally
  }
  
  public final void a(File paramFile) {
    ReadableByteChannel readableByteChannel;
    if (this.b != null) {
      readableByteChannel = Channels.newChannel(this.a.getAssets().open(this.b));
    } else if (this.c != null) {
      readableByteChannel = (new FileInputStream(this.c)).getChannel();
    } else {
      throw new IllegalStateException("copyFromAssetPath and copyFromFile == null!");
    } 
    File file2 = File.createTempFile("room-copy-helper", ".tmp", this.a.getCacheDir());
    file2.deleteOnExit();
    d.a(readableByteChannel, (new FileOutputStream(file2)).getChannel());
    File file1 = paramFile.getParentFile();
    if (file1 == null || file1.exists() || file1.mkdirs()) {
      if (file2.renameTo(paramFile))
        return; 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Failed to move intermediate file (");
      stringBuilder1.append(file2.getAbsolutePath());
      stringBuilder1.append(") to destination (");
      stringBuilder1.append(paramFile.getAbsolutePath());
      stringBuilder1.append(").");
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Failed to create directories for ");
    stringBuilder.append(paramFile.getAbsolutePath());
    throw new IOException(stringBuilder.toString());
  }
  
  public void b(a parama) {
    this.f = parama;
  }
  
  public final void c() {
    boolean bool;
    null = getDatabaseName();
    File file = this.a.getDatabasePath(null);
    a a2 = this.f;
    if (a2 == null || a2.j) {
      bool = true;
    } else {
      bool = false;
    } 
    a a1 = new a(null, this.a.getFilesDir(), bool);
    try {
      a1.b();
      bool = file.exists();
      if (!bool)
        try {
          a(file);
          return;
        } catch (IOException iOException) {
          throw new RuntimeException("Unable to copy database file.", iOException);
        }  
      a a3 = this.f;
      if (a3 == null)
        return; 
    } finally {
      a1.c();
    } 
  }
  
  public void close() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield e : Lb/t/a/c;
    //   6: invokeinterface close : ()V
    //   11: aload_0
    //   12: iconst_0
    //   13: putfield g : Z
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: astore_1
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_1
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	19	finally
  }
  
  public String getDatabaseName() {
    return this.e.getDatabaseName();
  }
  
  public void setWriteAheadLoggingEnabled(boolean paramBoolean) {
    this.e.setWriteAheadLoggingEnabled(paramBoolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */