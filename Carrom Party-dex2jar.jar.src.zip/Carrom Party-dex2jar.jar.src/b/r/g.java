package b.r;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import androidx.room.MultiInstanceInvalidationService;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

public class g {
  public final Context a;
  
  public final String b;
  
  public int c;
  
  public final f d;
  
  public final f.c e;
  
  public d f;
  
  public final Executor g;
  
  public final c h = new a(this);
  
  public final AtomicBoolean i = new AtomicBoolean(false);
  
  public final ServiceConnection j;
  
  public final Runnable k;
  
  public final Runnable l;
  
  public g(Context paramContext, String paramString, f paramf, Executor paramExecutor) {
    b b = new b(this);
    this.j = b;
    this.k = new c(this);
    this.l = new d(this);
    paramContext = paramContext.getApplicationContext();
    this.a = paramContext;
    this.b = paramString;
    this.d = paramf;
    this.g = paramExecutor;
    this.e = new e(this, (String[])paramf.a.keySet().toArray((Object[])new String[0]));
    paramContext.bindService(new Intent(paramContext, MultiInstanceInvalidationService.class), b, 1);
  }
  
  public class a extends c.a {
    public a(g this$0) {}
    
    public void A1(String[] param1ArrayOfString) {
      this.a.g.execute(new a(this, param1ArrayOfString));
    }
    
    public class a implements Runnable {
      public a(g.a this$0, String[] param2ArrayOfString) {}
      
      public void run() {
        this.b.a.d.e(this.a);
      }
    }
  }
  
  public class a implements Runnable {
    public a(g this$0, String[] param1ArrayOfString) {}
    
    public void run() {
      this.b.a.d.e(this.a);
    }
  }
  
  public class b implements ServiceConnection {
    public b(g this$0) {}
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      this.a.f = d.a.a0(param1IBinder);
      g g1 = this.a;
      g1.g.execute(g1.k);
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      g g1 = this.a;
      g1.g.execute(g1.l);
      this.a.f = null;
    }
  }
  
  public class c implements Runnable {
    public c(g this$0) {}
    
    public void run() {
      try {
        g g1 = this.a;
        d d = g1.f;
        if (d != null) {
          g1.c = d.m2(g1.h, g1.b);
          g1 = this.a;
          g1.d.a(g1.e);
          return;
        } 
      } catch (RemoteException remoteException) {
        Log.w("ROOM", "Cannot register multi-instance invalidation callback", (Throwable)remoteException);
      } 
    }
  }
  
  public class d implements Runnable {
    public d(g this$0) {}
    
    public void run() {
      g g1 = this.a;
      g1.d.g(g1.e);
    }
  }
  
  public class e extends f.c {
    public e(g this$0, String[] param1ArrayOfString) {
      super(param1ArrayOfString);
    }
    
    public boolean a() {
      return true;
    }
    
    public void b(Set<String> param1Set) {
      if (this.b.i.get())
        return; 
      try {
        g g1 = this.b;
        d d = g1.f;
        if (d != null) {
          d.e6(g1.c, param1Set.<String>toArray(new String[0]));
          return;
        } 
      } catch (RemoteException remoteException) {
        Log.w("ROOM", "Cannot broadcast invalidation", (Throwable)remoteException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */