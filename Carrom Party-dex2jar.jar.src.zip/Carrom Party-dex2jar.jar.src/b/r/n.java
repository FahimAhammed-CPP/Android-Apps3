package b.r;

import b.t.a.c;
import java.io.File;

public class n implements c.c {
  public final String a;
  
  public final File b;
  
  public final c.c c;
  
  public n(String paramString, File paramFile, c.c paramc) {
    this.a = paramString;
    this.b = paramFile;
    this.c = paramc;
  }
  
  public c a(c.b paramb) {
    return new m(paramb.a, this.a, this.b, paramb.c.a, this.c.a(paramb));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */