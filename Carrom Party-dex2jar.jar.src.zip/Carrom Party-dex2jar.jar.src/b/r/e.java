package b.r;

import java.util.Collections;
import java.util.IdentityHashMap;

public class e {
  public e(i parami) {
    Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>());
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */