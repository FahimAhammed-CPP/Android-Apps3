package b.r;

import b.t.a.f;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class o {
  public final AtomicBoolean a = new AtomicBoolean(false);
  
  public final i b;
  
  public volatile f c;
  
  public o(i parami) {
    this.b = parami;
  }
  
  public f a() {
    b();
    return e(this.a.compareAndSet(false, true));
  }
  
  public void b() {
    this.b.a();
  }
  
  public final f c() {
    String str = d();
    return this.b.d(str);
  }
  
  public abstract String d();
  
  public final f e(boolean paramBoolean) {
    if (paramBoolean) {
      if (this.c == null)
        this.c = c(); 
      return this.c;
    } 
    return c();
  }
  
  public void f(f paramf) {
    if (paramf == this.c)
      this.a.set(false); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */