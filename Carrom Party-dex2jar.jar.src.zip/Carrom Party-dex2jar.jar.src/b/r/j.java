package b.r;

public class j {
  public static String a(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '");
    stringBuilder.append(paramString);
    stringBuilder.append("')");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */