package b.r.q;

import b.t.a.b;

public abstract class a {
  public final int a;
  
  public final int b;
  
  public a(int paramInt1, int paramInt2) {
    this.a = paramInt1;
    this.b = paramInt2;
  }
  
  public abstract void a(b paramb);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\q\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */