package b.r;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import b.t.a.e;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;

public class f {
  public static final String[] k = new String[] { "UPDATE", "DELETE", "INSERT" };
  
  public final HashMap<String, Integer> a;
  
  public final String[] b;
  
  public Map<String, Set<String>> c;
  
  public final i d;
  
  public AtomicBoolean e;
  
  public volatile boolean f;
  
  public volatile b.t.a.f g;
  
  public b h;
  
  @SuppressLint({"RestrictedApi"})
  public final b.c.a.b.b<c, d> i;
  
  public Runnable j;
  
  public f(i parami, Map<String, String> paramMap, Map<String, Set<String>> paramMap1, String... paramVarArgs) {
    int j = 0;
    this.e = new AtomicBoolean(false);
    this.f = false;
    this.i = new b.c.a.b.b();
    this.j = new a(this);
    this.d = parami;
    this.h = new b(paramVarArgs.length);
    this.a = new HashMap<String, Integer>();
    this.c = paramMap1;
    new e(parami);
    int k = paramVarArgs.length;
    this.b = new String[k];
    while (j < k) {
      String str1 = paramVarArgs[j];
      Locale locale = Locale.US;
      str1 = str1.toLowerCase(locale);
      this.a.put(str1, Integer.valueOf(j));
      String str2 = paramMap.get(paramVarArgs[j]);
      if (str2 != null) {
        this.b[j] = str2.toLowerCase(locale);
      } else {
        this.b[j] = str1;
      } 
      j++;
    } 
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      String str = (String)entry.getValue();
      Locale locale = Locale.US;
      str = str.toLowerCase(locale);
      if (this.a.containsKey(str)) {
        String str1 = ((String)entry.getKey()).toLowerCase(locale);
        HashMap<String, Integer> hashMap = this.a;
        hashMap.put(str1, hashMap.get(str));
      } 
    } 
  }
  
  public static void b(StringBuilder paramStringBuilder, String paramString1, String paramString2) {
    paramStringBuilder.append("`");
    paramStringBuilder.append("room_table_modification_trigger_");
    paramStringBuilder.append(paramString1);
    paramStringBuilder.append("_");
    paramStringBuilder.append(paramString2);
    paramStringBuilder.append("`");
  }
  
  @SuppressLint({"RestrictedApi"})
  public void a(c paramc) {
    String[] arrayOfString = h(paramc.a);
    int[] arrayOfInt = new int[arrayOfString.length];
    int k = arrayOfString.length;
    int j = 0;
    while (j < k) {
      Integer integer = this.a.get(arrayOfString[j].toLowerCase(Locale.US));
      if (integer != null) {
        arrayOfInt[j] = integer.intValue();
        j++;
        continue;
      } 
      null = new StringBuilder();
      null.append("There is no table with name ");
      null.append(arrayOfString[j]);
      throw new IllegalArgumentException(null.toString());
    } 
    d d = new d((c)null, arrayOfInt, arrayOfString);
    synchronized (this.i) {
      d d1 = (d)this.i.g(null, d);
      if (d1 == null && this.h.b(arrayOfInt))
        l(); 
      return;
    } 
  }
  
  public boolean c() {
    if (!this.d.o())
      return false; 
    if (!this.f)
      this.d.i().K0(); 
    if (!this.f) {
      Log.e("ROOM", "database is not initialized even though it is open");
      return false;
    } 
    return true;
  }
  
  public void d(b.t.a.b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Z
    //   6: ifeq -> 20
    //   9: ldc 'ROOM'
    //   11: ldc 'Invalidation tracker is initialized twice :/.'
    //   13: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   16: pop
    //   17: aload_0
    //   18: monitorexit
    //   19: return
    //   20: aload_1
    //   21: ldc 'PRAGMA temp_store = MEMORY;'
    //   23: invokeinterface H : (Ljava/lang/String;)V
    //   28: aload_1
    //   29: ldc 'PRAGMA recursive_triggers='ON';'
    //   31: invokeinterface H : (Ljava/lang/String;)V
    //   36: aload_1
    //   37: ldc 'CREATE TEMP TABLE room_table_modification_log(table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)'
    //   39: invokeinterface H : (Ljava/lang/String;)V
    //   44: aload_0
    //   45: aload_1
    //   46: invokevirtual m : (Lb/t/a/b;)V
    //   49: aload_0
    //   50: aload_1
    //   51: ldc 'UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1 '
    //   53: invokeinterface M : (Ljava/lang/String;)Lb/t/a/f;
    //   58: putfield g : Lb/t/a/f;
    //   61: aload_0
    //   62: iconst_1
    //   63: putfield f : Z
    //   66: aload_0
    //   67: monitorexit
    //   68: return
    //   69: astore_1
    //   70: aload_0
    //   71: monitorexit
    //   72: aload_1
    //   73: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	69	finally
    //   20	68	69	finally
    //   70	72	69	finally
  }
  
  public void e(String... paramVarArgs) {
    synchronized (this.i) {
      for (Map.Entry entry : this.i) {
        if (!((c)entry.getKey()).a())
          ((d)entry.getValue()).b(paramVarArgs); 
      } 
      return;
    } 
  }
  
  public void f() {
    if (this.e.compareAndSet(false, true))
      this.d.j().execute(this.j); 
  }
  
  @SuppressLint({"RestrictedApi"})
  public void g(c paramc) {
    synchronized (this.i) {
      d d = (d)this.i.i(paramc);
      if (d != null && this.h.c(d.a))
        l(); 
      return;
    } 
  }
  
  public final String[] h(String[] paramArrayOfString) {
    HashSet<String> hashSet = new HashSet();
    int k = paramArrayOfString.length;
    for (int j = 0; j < k; j++) {
      String str1 = paramArrayOfString[j];
      String str2 = str1.toLowerCase(Locale.US);
      if (this.c.containsKey(str2)) {
        hashSet.addAll(this.c.get(str2));
      } else {
        hashSet.add(str1);
      } 
    } 
    return hashSet.<String>toArray(new String[hashSet.size()]);
  }
  
  public void i(Context paramContext, String paramString) {
    new g(paramContext, paramString, this, this.d.j());
  }
  
  public final void j(b.t.a.b paramb, int paramInt) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("INSERT OR IGNORE INTO room_table_modification_log VALUES(");
    stringBuilder1.append(paramInt);
    stringBuilder1.append(", 0)");
    paramb.H(stringBuilder1.toString());
    String str = this.b[paramInt];
    StringBuilder stringBuilder2 = new StringBuilder();
    for (String str1 : k) {
      stringBuilder2.setLength(0);
      stringBuilder2.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
      b(stringBuilder2, str, str1);
      stringBuilder2.append(" AFTER ");
      stringBuilder2.append(str1);
      stringBuilder2.append(" ON `");
      stringBuilder2.append(str);
      stringBuilder2.append("` BEGIN UPDATE ");
      stringBuilder2.append("room_table_modification_log");
      stringBuilder2.append(" SET ");
      stringBuilder2.append("invalidated");
      stringBuilder2.append(" = 1");
      stringBuilder2.append(" WHERE ");
      stringBuilder2.append("table_id");
      stringBuilder2.append(" = ");
      stringBuilder2.append(paramInt);
      stringBuilder2.append(" AND ");
      stringBuilder2.append("invalidated");
      stringBuilder2.append(" = 0");
      stringBuilder2.append("; END");
      paramb.H(stringBuilder2.toString());
    } 
  }
  
  public final void k(b.t.a.b paramb, int paramInt) {
    String str = this.b[paramInt];
    StringBuilder stringBuilder = new StringBuilder();
    String[] arrayOfString = k;
    int j = arrayOfString.length;
    for (paramInt = 0; paramInt < j; paramInt++) {
      String str1 = arrayOfString[paramInt];
      stringBuilder.setLength(0);
      stringBuilder.append("DROP TRIGGER IF EXISTS ");
      b(stringBuilder, str, str1);
      paramb.H(stringBuilder.toString());
    } 
  }
  
  public void l() {
    if (!this.d.o())
      return; 
    m(this.d.i().K0());
  }
  
  public void m(b.t.a.b paramb) {
    if (paramb.s1())
      return; 
    label38: while (true) {
      try {
        Lock lock = this.d.h();
        lock.lock();
        try {
          int j;
          int[] arrayOfInt = this.h.a();
          if (arrayOfInt == null)
            return; 
          int k = arrayOfInt.length;
          paramb.v();
        } finally {
          lock.unlock();
        } 
        break;
      } catch (IllegalStateException illegalStateException) {
      
      } catch (SQLiteException sQLiteException) {}
      Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", (Throwable)sQLiteException);
      return;
    } 
  }
  
  public class a implements Runnable {
    public a(f this$0) {}
    
    public final Set<Integer> a() {
      null = new HashSet();
      Cursor cursor = this.a.d.p((e)new b.t.a.a("SELECT * FROM room_table_modification_log WHERE invalidated = 1;"));
      try {
        while (cursor.moveToNext())
          null.add(Integer.valueOf(cursor.getInt(0))); 
        cursor.close();
        return null;
      } finally {
        cursor.close();
      } 
    }
    
    public void run() {
      Lock lock = this.a.d.h();
      Set<Integer> set4 = null;
      Set<Integer> set5 = null;
      Set<Integer> set3 = null;
      Set<Integer> set2 = set4;
      Set<Integer> set1 = set5;
      try {
        lock.lock();
        set2 = set4;
        set1 = set5;
        boolean bool = this.a.c();
        if (!bool) {
          lock.unlock();
          return;
        } 
        set2 = set4;
        set1 = set5;
        bool = this.a.e.compareAndSet(true, false);
        if (!bool) {
          lock.unlock();
          return;
        } 
        set2 = set4;
        set1 = set5;
        bool = this.a.d.k();
        if (bool) {
          lock.unlock();
          return;
        } 
        set2 = set4;
        set1 = set5;
        i i = this.a.d;
        set2 = set4;
        set1 = set5;
        if (i.f) {
          set2 = set4;
          set1 = set5;
          b.t.a.b b = i.i().K0();
          set2 = set4;
          set1 = set5;
          b.v();
          try {
            set4 = a();
            set3 = set4;
          } finally {
            set2 = set3;
            set1 = set3;
            b.R0();
            set2 = set3;
            set1 = set3;
          } 
        } else {
          set2 = set4;
          set1 = set5;
          set3 = a();
          set1 = set3;
        } 
      } catch (IllegalStateException illegalStateException) {
        Log.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", illegalStateException);
      } catch (SQLiteException sQLiteException2) {
        IllegalStateException illegalStateException1 = illegalStateException;
        SQLiteException sQLiteException1 = sQLiteException2;
      } finally {}
      lock.unlock();
      if (set1 != null && !set1.isEmpty())
        synchronized (this.a.i) {
          Iterator<Map.Entry> iterator = this.a.i.iterator();
          while (iterator.hasNext())
            ((f.d)((Map.Entry)iterator.next()).getValue()).a(set1); 
          return;
        }  
    }
  }
  
  public static class b {
    public final long[] a;
    
    public final boolean[] b;
    
    public final int[] c;
    
    public boolean d;
    
    public boolean e;
    
    public b(int param1Int) {
      long[] arrayOfLong = new long[param1Int];
      this.a = arrayOfLong;
      boolean[] arrayOfBoolean = new boolean[param1Int];
      this.b = arrayOfBoolean;
      this.c = new int[param1Int];
      Arrays.fill(arrayOfLong, 0L);
      Arrays.fill(arrayOfBoolean, false);
    }
    
    public int[] a() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield d : Z
      //   6: ifeq -> 111
      //   9: aload_0
      //   10: getfield e : Z
      //   13: ifeq -> 19
      //   16: goto -> 111
      //   19: aload_0
      //   20: getfield a : [J
      //   23: arraylength
      //   24: istore_3
      //   25: iconst_0
      //   26: istore_1
      //   27: iconst_1
      //   28: istore_2
      //   29: iload_1
      //   30: iload_3
      //   31: if_icmpge -> 90
      //   34: aload_0
      //   35: getfield a : [J
      //   38: iload_1
      //   39: laload
      //   40: lconst_0
      //   41: lcmp
      //   42: ifle -> 128
      //   45: iconst_1
      //   46: istore #4
      //   48: goto -> 51
      //   51: aload_0
      //   52: getfield b : [Z
      //   55: astore #5
      //   57: iload #4
      //   59: aload #5
      //   61: iload_1
      //   62: baload
      //   63: if_icmpeq -> 80
      //   66: aload_0
      //   67: getfield c : [I
      //   70: astore #6
      //   72: iload #4
      //   74: ifeq -> 134
      //   77: goto -> 136
      //   80: aload_0
      //   81: getfield c : [I
      //   84: iload_1
      //   85: iconst_0
      //   86: iastore
      //   87: goto -> 141
      //   90: aload_0
      //   91: iconst_1
      //   92: putfield e : Z
      //   95: aload_0
      //   96: iconst_0
      //   97: putfield d : Z
      //   100: aload_0
      //   101: getfield c : [I
      //   104: astore #5
      //   106: aload_0
      //   107: monitorexit
      //   108: aload #5
      //   110: areturn
      //   111: aload_0
      //   112: monitorexit
      //   113: aconst_null
      //   114: areturn
      //   115: astore #5
      //   117: aload_0
      //   118: monitorexit
      //   119: goto -> 125
      //   122: aload #5
      //   124: athrow
      //   125: goto -> 122
      //   128: iconst_0
      //   129: istore #4
      //   131: goto -> 51
      //   134: iconst_2
      //   135: istore_2
      //   136: aload #6
      //   138: iload_1
      //   139: iload_2
      //   140: iastore
      //   141: aload #5
      //   143: iload_1
      //   144: iload #4
      //   146: bastore
      //   147: iload_1
      //   148: iconst_1
      //   149: iadd
      //   150: istore_1
      //   151: goto -> 27
      // Exception table:
      //   from	to	target	type
      //   2	16	115	finally
      //   19	25	115	finally
      //   34	45	115	finally
      //   51	57	115	finally
      //   66	72	115	finally
      //   80	87	115	finally
      //   90	108	115	finally
      //   111	113	115	finally
      //   117	119	115	finally
    }
    
    public boolean b(int... param1VarArgs) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: arraylength
      //   4: istore_3
      //   5: iconst_0
      //   6: istore_2
      //   7: iconst_0
      //   8: istore #5
      //   10: iload_2
      //   11: iload_3
      //   12: if_icmpge -> 60
      //   15: aload_1
      //   16: iload_2
      //   17: iaload
      //   18: istore #4
      //   20: aload_0
      //   21: getfield a : [J
      //   24: astore #8
      //   26: aload #8
      //   28: iload #4
      //   30: laload
      //   31: lstore #6
      //   33: aload #8
      //   35: iload #4
      //   37: lconst_1
      //   38: lload #6
      //   40: ladd
      //   41: lastore
      //   42: lload #6
      //   44: lconst_0
      //   45: lcmp
      //   46: ifne -> 76
      //   49: aload_0
      //   50: iconst_1
      //   51: putfield d : Z
      //   54: iconst_1
      //   55: istore #5
      //   57: goto -> 76
      //   60: aload_0
      //   61: monitorexit
      //   62: iload #5
      //   64: ireturn
      //   65: astore_1
      //   66: aload_0
      //   67: monitorexit
      //   68: goto -> 73
      //   71: aload_1
      //   72: athrow
      //   73: goto -> 71
      //   76: iload_2
      //   77: iconst_1
      //   78: iadd
      //   79: istore_2
      //   80: goto -> 10
      // Exception table:
      //   from	to	target	type
      //   2	5	65	finally
      //   20	26	65	finally
      //   49	54	65	finally
      //   60	62	65	finally
      //   66	68	65	finally
    }
    
    public boolean c(int... param1VarArgs) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: arraylength
      //   4: istore_3
      //   5: iconst_0
      //   6: istore_2
      //   7: iconst_0
      //   8: istore #5
      //   10: iload_2
      //   11: iload_3
      //   12: if_icmpge -> 60
      //   15: aload_1
      //   16: iload_2
      //   17: iaload
      //   18: istore #4
      //   20: aload_0
      //   21: getfield a : [J
      //   24: astore #8
      //   26: aload #8
      //   28: iload #4
      //   30: laload
      //   31: lstore #6
      //   33: aload #8
      //   35: iload #4
      //   37: lload #6
      //   39: lconst_1
      //   40: lsub
      //   41: lastore
      //   42: lload #6
      //   44: lconst_1
      //   45: lcmp
      //   46: ifne -> 76
      //   49: aload_0
      //   50: iconst_1
      //   51: putfield d : Z
      //   54: iconst_1
      //   55: istore #5
      //   57: goto -> 76
      //   60: aload_0
      //   61: monitorexit
      //   62: iload #5
      //   64: ireturn
      //   65: astore_1
      //   66: aload_0
      //   67: monitorexit
      //   68: goto -> 73
      //   71: aload_1
      //   72: athrow
      //   73: goto -> 71
      //   76: iload_2
      //   77: iconst_1
      //   78: iadd
      //   79: istore_2
      //   80: goto -> 10
      // Exception table:
      //   from	to	target	type
      //   2	5	65	finally
      //   20	26	65	finally
      //   49	54	65	finally
      //   60	62	65	finally
      //   66	68	65	finally
    }
    
    public void d() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: iconst_0
      //   4: putfield e : Z
      //   7: aload_0
      //   8: monitorexit
      //   9: return
      //   10: astore_1
      //   11: aload_0
      //   12: monitorexit
      //   13: aload_1
      //   14: athrow
      // Exception table:
      //   from	to	target	type
      //   2	9	10	finally
      //   11	13	10	finally
    }
  }
  
  public static abstract class c {
    public final String[] a;
    
    public c(String[] param1ArrayOfString) {
      this.a = Arrays.<String>copyOf(param1ArrayOfString, param1ArrayOfString.length);
    }
    
    public boolean a() {
      return false;
    }
    
    public abstract void b(Set<String> param1Set);
  }
  
  public static class d {
    public final int[] a;
    
    public final String[] b;
    
    public final f.c c;
    
    public final Set<String> d;
    
    public d(f.c param1c, int[] param1ArrayOfint, String[] param1ArrayOfString) {
      this.c = param1c;
      this.a = param1ArrayOfint;
      this.b = param1ArrayOfString;
      if (param1ArrayOfint.length == 1) {
        HashSet<String> hashSet = new HashSet();
        hashSet.add(param1ArrayOfString[0]);
        this.d = Collections.unmodifiableSet(hashSet);
        return;
      } 
      this.d = null;
    }
    
    public void a(Set<Integer> param1Set) {
      int j = this.a.length;
      Set<String> set = null;
      int i = 0;
      while (i < j) {
        Set<String> set1 = set;
        if (param1Set.contains(Integer.valueOf(this.a[i])))
          if (j == 1) {
            set1 = this.d;
          } else {
            set1 = set;
            if (set == null)
              set1 = new HashSet<String>(j); 
            set1.add(this.b[i]);
          }  
        i++;
        set = set1;
      } 
      if (set != null)
        this.c.b(set); 
    }
    
    public void b(String[] param1ArrayOfString) {
      Set<String> set1;
      int i = this.b.length;
      Set<String> set2 = null;
      if (i == 1) {
        int j = param1ArrayOfString.length;
        i = 0;
        while (true) {
          set1 = set2;
          if (i < j) {
            if (param1ArrayOfString[i].equalsIgnoreCase(this.b[0])) {
              set1 = this.d;
              break;
            } 
            i++;
            continue;
          } 
          break;
        } 
      } else {
        HashSet<String> hashSet = new HashSet();
        int j = param1ArrayOfString.length;
        for (i = 0; i < j; i++) {
          String str = param1ArrayOfString[i];
          for (String str1 : this.b) {
            if (str1.equalsIgnoreCase(str)) {
              hashSet.add(str1);
              break;
            } 
          } 
        } 
        set1 = set2;
        if (hashSet.size() > 0)
          set1 = hashSet; 
      } 
      if (set1 != null)
        this.c.b(set1); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */