package b.r;

import android.database.Cursor;
import b.t.a.c;
import b.t.a.e;

public class k extends c.a {
  public a b;
  
  public final a c;
  
  public final String d;
  
  public final String e;
  
  public k(a parama, a parama1, String paramString1, String paramString2) {
    super(parama1.a);
    this.b = parama;
    this.c = parama1;
    this.d = paramString1;
    this.e = paramString2;
  }
  
  public static boolean j(b.t.a.b paramb) {
    Cursor cursor = paramb.M0("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
    try {
      boolean bool = cursor.moveToFirst();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        int i = cursor.getInt(0);
        bool1 = bool2;
        if (i == 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
    } 
  }
  
  public static boolean k(b.t.a.b paramb) {
    Cursor cursor = paramb.M0("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name='room_master_table'");
    try {
      boolean bool = cursor.moveToFirst();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (bool) {
        int i = cursor.getInt(0);
        bool1 = bool2;
        if (i != 0)
          bool1 = true; 
      } 
      return bool1;
    } finally {
      cursor.close();
    } 
  }
  
  public void b(b.t.a.b paramb) {
    super.b(paramb);
  }
  
  public void d(b.t.a.b paramb) {
    StringBuilder stringBuilder;
    boolean bool = j(paramb);
    this.c.a(paramb);
    if (!bool) {
      b b1 = this.c.g(paramb);
      if (!b1.a) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Pre-packaged database has an invalid schema: ");
        stringBuilder.append(b1.b);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
    l((b.t.a.b)stringBuilder);
    this.c.c((b.t.a.b)stringBuilder);
  }
  
  public void e(b.t.a.b paramb, int paramInt1, int paramInt2) {
    g(paramb, paramInt1, paramInt2);
  }
  
  public void f(b.t.a.b paramb) {
    super.f(paramb);
    h(paramb);
    this.c.d(paramb);
    this.b = null;
  }
  
  public void g(b.t.a.b paramb, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Lb/r/a;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnull -> 146
    //   11: aload #5
    //   13: getfield d : Lb/r/i$d;
    //   16: iload_2
    //   17: iload_3
    //   18: invokevirtual c : (II)Ljava/util/List;
    //   21: astore #5
    //   23: aload #5
    //   25: ifnull -> 146
    //   28: aload_0
    //   29: getfield c : Lb/r/k$a;
    //   32: aload_1
    //   33: invokevirtual f : (Lb/t/a/b;)V
    //   36: aload #5
    //   38: invokeinterface iterator : ()Ljava/util/Iterator;
    //   43: astore #5
    //   45: aload #5
    //   47: invokeinterface hasNext : ()Z
    //   52: ifeq -> 72
    //   55: aload #5
    //   57: invokeinterface next : ()Ljava/lang/Object;
    //   62: checkcast b/r/q/a
    //   65: aload_1
    //   66: invokevirtual a : (Lb/t/a/b;)V
    //   69: goto -> 45
    //   72: aload_0
    //   73: getfield c : Lb/r/k$a;
    //   76: aload_1
    //   77: invokevirtual g : (Lb/t/a/b;)Lb/r/k$b;
    //   80: astore #5
    //   82: aload #5
    //   84: getfield a : Z
    //   87: ifeq -> 109
    //   90: aload_0
    //   91: getfield c : Lb/r/k$a;
    //   94: aload_1
    //   95: invokevirtual e : (Lb/t/a/b;)V
    //   98: aload_0
    //   99: aload_1
    //   100: invokevirtual l : (Lb/t/a/b;)V
    //   103: iconst_1
    //   104: istore #4
    //   106: goto -> 149
    //   109: new java/lang/StringBuilder
    //   112: dup
    //   113: invokespecial <init> : ()V
    //   116: astore_1
    //   117: aload_1
    //   118: ldc 'Migration didn't properly handle: '
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: pop
    //   124: aload_1
    //   125: aload #5
    //   127: getfield b : Ljava/lang/String;
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: pop
    //   134: new java/lang/IllegalStateException
    //   137: dup
    //   138: aload_1
    //   139: invokevirtual toString : ()Ljava/lang/String;
    //   142: invokespecial <init> : (Ljava/lang/String;)V
    //   145: athrow
    //   146: iconst_0
    //   147: istore #4
    //   149: iload #4
    //   151: ifne -> 245
    //   154: aload_0
    //   155: getfield b : Lb/r/a;
    //   158: astore #5
    //   160: aload #5
    //   162: ifnull -> 192
    //   165: aload #5
    //   167: iload_2
    //   168: iload_3
    //   169: invokevirtual a : (II)Z
    //   172: ifne -> 192
    //   175: aload_0
    //   176: getfield c : Lb/r/k$a;
    //   179: aload_1
    //   180: invokevirtual b : (Lb/t/a/b;)V
    //   183: aload_0
    //   184: getfield c : Lb/r/k$a;
    //   187: aload_1
    //   188: invokevirtual a : (Lb/t/a/b;)V
    //   191: return
    //   192: new java/lang/StringBuilder
    //   195: dup
    //   196: invokespecial <init> : ()V
    //   199: astore_1
    //   200: aload_1
    //   201: ldc 'A migration from '
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: pop
    //   207: aload_1
    //   208: iload_2
    //   209: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   212: pop
    //   213: aload_1
    //   214: ldc ' to '
    //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: pop
    //   220: aload_1
    //   221: iload_3
    //   222: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload_1
    //   227: ldc ' was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(Migration ...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* methods.'
    //   229: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: pop
    //   233: new java/lang/IllegalStateException
    //   236: dup
    //   237: aload_1
    //   238: invokevirtual toString : ()Ljava/lang/String;
    //   241: invokespecial <init> : (Ljava/lang/String;)V
    //   244: athrow
    //   245: return
  }
  
  public final void h(b.t.a.b paramb) {
    if (k(paramb)) {
      b.t.a.b b1 = null;
      Cursor cursor = paramb.k1((e)new b.t.a.a("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1"));
      paramb = b1;
      try {
        String str;
        if (cursor.moveToFirst())
          str = cursor.getString(0); 
        cursor.close();
      } finally {
        cursor.close();
      } 
    } else {
      b b1 = this.c.g(paramb);
      if (b1.a) {
        this.c.e(paramb);
        l(paramb);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Pre-packaged database has an invalid schema: ");
      stringBuilder.append(b1.b);
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  public final void i(b.t.a.b paramb) {
    paramb.H("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
  }
  
  public final void l(b.t.a.b paramb) {
    i(paramb);
    paramb.H(j.a(this.d));
  }
  
  public static abstract class a {
    public final int a;
    
    public a(int param1Int) {
      this.a = param1Int;
    }
    
    public abstract void a(b.t.a.b param1b);
    
    public abstract void b(b.t.a.b param1b);
    
    public abstract void c(b.t.a.b param1b);
    
    public abstract void d(b.t.a.b param1b);
    
    public abstract void e(b.t.a.b param1b);
    
    public abstract void f(b.t.a.b param1b);
    
    public abstract k.b g(b.t.a.b param1b);
  }
  
  public static class b {
    public final boolean a;
    
    public final String b;
    
    public b(boolean param1Boolean, String param1String) {
      this.a = param1Boolean;
      this.b = param1String;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\r\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */