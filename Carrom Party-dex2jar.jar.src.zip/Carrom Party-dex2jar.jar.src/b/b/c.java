package b.b;

public final class c {
  public static final int a = 2131034119;
  
  public static final int b = 2131034130;
  
  public static final int c = 2131034131;
  
  public static final int d = 2131034132;
  
  public static final int e = 2131034133;
  
  public static final int f = 2131034134;
  
  public static final int g = 2131034135;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */