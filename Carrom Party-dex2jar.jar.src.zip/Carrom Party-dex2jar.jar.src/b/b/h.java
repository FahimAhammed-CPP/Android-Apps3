package b.b;

public final class h {
  public static final int a = 2131623937;
  
  public static final int b = 2131623940;
  
  public static final int c = 2131623944;
  
  public static final int d = 2131623945;
  
  public static final int e = 2131623946;
  
  public static final int f = 2131623947;
  
  public static final int g = 2131623948;
  
  public static final int h = 2131623949;
  
  public static final int i = 2131623950;
  
  public static final int j = 2131623951;
  
  public static final int k = 2131623952;
  
  public static final int l = 2131623953;
  
  public static final int m = 2131623957;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */