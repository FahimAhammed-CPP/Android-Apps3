package b.b;

public final class f {
  public static final int A = 2131296468;
  
  public static final int B = 2131296469;
  
  public static final int C = 2131296470;
  
  public static final int D = 2131296473;
  
  public static final int E = 2131296474;
  
  public static final int F = 2131296475;
  
  public static final int G = 2131296476;
  
  public static final int H = 2131296477;
  
  public static final int I = 2131296478;
  
  public static final int J = 2131296479;
  
  public static final int K = 2131296480;
  
  public static final int L = 2131296490;
  
  public static final int M = 2131296496;
  
  public static final int N = 2131296498;
  
  public static final int O = 2131296506;
  
  public static final int P = 2131296507;
  
  public static final int Q = 2131296526;
  
  public static final int R = 2131296527;
  
  public static final int S = 2131296529;
  
  public static final int T = 2131296530;
  
  public static final int U = 2131296531;
  
  public static final int V = 2131296533;
  
  public static final int a = 2131296297;
  
  public static final int b = 2131296298;
  
  public static final int c = 2131296299;
  
  public static final int d = 2131296302;
  
  public static final int e = 2131296303;
  
  public static final int f = 2131296305;
  
  public static final int g = 2131296309;
  
  public static final int h = 2131296311;
  
  public static final int i = 2131296312;
  
  public static final int j = 2131296315;
  
  public static final int k = 2131296331;
  
  public static final int l = 2131296349;
  
  public static final int m = 2131296379;
  
  public static final int n = 2131296380;
  
  public static final int o = 2131296381;
  
  public static final int p = 2131296382;
  
  public static final int q = 2131296384;
  
  public static final int r = 2131296385;
  
  public static final int s = 2131296393;
  
  public static final int t = 2131296396;
  
  public static final int u = 2131296403;
  
  public static final int v = 2131296406;
  
  public static final int w = 2131296410;
  
  public static final int x = 2131296420;
  
  public static final int y = 2131296422;
  
  public static final int z = 2131296455;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */