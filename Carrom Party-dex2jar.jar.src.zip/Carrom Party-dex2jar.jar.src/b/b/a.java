package b.b;

public final class a {
  public static final int A = 2130903200;
  
  public static final int B = 2130903228;
  
  public static final int C = 2130903249;
  
  public static final int D = 2130903250;
  
  public static final int E = 2130903275;
  
  public static final int F = 2130903286;
  
  public static final int G = 2130903287;
  
  public static final int H = 2130903293;
  
  public static final int I = 2130903294;
  
  public static final int J = 2130903305;
  
  public static final int K = 2130903331;
  
  public static final int L = 2130903353;
  
  public static final int M = 2130903354;
  
  public static final int a = 2130903042;
  
  public static final int b = 2130903043;
  
  public static final int c = 2130903045;
  
  public static final int d = 2130903047;
  
  public static final int e = 2130903048;
  
  public static final int f = 2130903049;
  
  public static final int g = 2130903050;
  
  public static final int h = 2130903052;
  
  public static final int i = 2130903063;
  
  public static final int j = 2130903067;
  
  public static final int k = 2130903069;
  
  public static final int l = 2130903070;
  
  public static final int m = 2130903078;
  
  public static final int n = 2130903079;
  
  public static final int o = 2130903080;
  
  public static final int p = 2130903086;
  
  public static final int q = 2130903109;
  
  public static final int r = 2130903120;
  
  public static final int s = 2130903128;
  
  public static final int t = 2130903130;
  
  public static final int u = 2130903131;
  
  public static final int v = 2130903132;
  
  public static final int w = 2130903133;
  
  public static final int x = 2130903138;
  
  public static final int y = 2130903180;
  
  public static final int z = 2130903196;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */