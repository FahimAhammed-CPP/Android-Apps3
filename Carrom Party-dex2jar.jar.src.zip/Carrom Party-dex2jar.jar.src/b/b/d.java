package b.b;

public final class d {
  public static final int a = 2131099657;
  
  public static final int b = 2131099658;
  
  public static final int c = 2131099670;
  
  public static final int d = 2131099671;
  
  public static final int e = 2131099689;
  
  public static final int f = 2131099690;
  
  public static final int g = 2131099702;
  
  public static final int h = 2131099703;
  
  public static final int i = 2131099787;
  
  public static final int j = 2131099788;
  
  public static final int k = 2131099790;
  
  public static final int l = 2131099791;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */