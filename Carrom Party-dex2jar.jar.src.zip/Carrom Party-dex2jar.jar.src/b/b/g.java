package b.b;

public final class g {
  public static final int a = 2131492864;
  
  public static final int b = 2131492866;
  
  public static final int c = 2131492867;
  
  public static final int d = 2131492869;
  
  public static final int e = 2131492870;
  
  public static final int f = 2131492871;
  
  public static final int g = 2131492875;
  
  public static final int h = 2131492876;
  
  public static final int i = 2131492877;
  
  public static final int j = 2131492878;
  
  public static final int k = 2131492879;
  
  public static final int l = 2131492880;
  
  public static final int m = 2131492881;
  
  public static final int n = 2131492882;
  
  public static final int o = 2131492883;
  
  public static final int p = 2131492885;
  
  public static final int q = 2131492886;
  
  public static final int r = 2131492887;
  
  public static final int s = 2131492888;
  
  public static final int t = 2131492889;
  
  public static final int u = 2131492891;
  
  public static final int v = 2131492952;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */