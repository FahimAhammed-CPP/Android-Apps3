package b.b;

public final class j {
  public static final int A = 3;
  
  public static final int A0 = 84;
  
  public static final int A1 = 9;
  
  public static final int A2 = 2;
  
  public static final int A3 = 27;
  
  public static final int B = 4;
  
  public static final int B0 = 114;
  
  public static final int B1 = 10;
  
  public static final int B2 = 3;
  
  public static final int B3 = 28;
  
  public static final int C = 5;
  
  public static final int C0 = 115;
  
  public static final int C1 = 11;
  
  public static final int C2 = 4;
  
  public static final int C3 = 29;
  
  public static final int[] D;
  
  public static final int D0 = 116;
  
  public static final int D1 = 12;
  
  public static final int D2 = 5;
  
  public static final int[] D3;
  
  public static final int E = 0;
  
  public static final int E0 = 117;
  
  public static final int E1 = 13;
  
  public static final int E2 = 6;
  
  public static final int E3 = 0;
  
  public static final int F = 1;
  
  public static final int F0 = 118;
  
  public static final int F1 = 14;
  
  public static final int F2 = 7;
  
  public static final int F3 = 4;
  
  public static final int[] G;
  
  public static final int G0 = 119;
  
  public static final int G1 = 15;
  
  public static final int G2 = 8;
  
  public static final int[] G3;
  
  public static final int H = 0;
  
  public static final int H0 = 120;
  
  public static final int H1 = 16;
  
  public static final int H2 = 9;
  
  public static final int H3 = 0;
  
  public static final int I = 1;
  
  public static final int I0 = 121;
  
  public static final int I1 = 17;
  
  public static final int I2 = 10;
  
  public static final int I3 = 1;
  
  public static final int J = 2;
  
  public static final int J0 = 122;
  
  public static final int J1 = 18;
  
  public static final int J2 = 11;
  
  public static final int J3 = 2;
  
  public static final int K = 3;
  
  public static final int K0 = 123;
  
  public static final int K1 = 19;
  
  public static final int K2 = 12;
  
  public static final int[] K3;
  
  public static final int L = 4;
  
  public static final int L0 = 124;
  
  public static final int L1 = 20;
  
  public static final int L2 = 13;
  
  public static final int L3 = 0;
  
  public static final int M = 5;
  
  public static final int[] M0;
  
  public static final int M1 = 21;
  
  public static final int[] M2;
  
  public static final int M3 = 1;
  
  public static final int N = 6;
  
  public static final int N0 = 0;
  
  public static final int N1 = 22;
  
  public static final int N2 = 0;
  
  public static final int N3 = 2;
  
  public static final int O = 7;
  
  public static final int[] O0;
  
  public static final int[] O1;
  
  public static final int O2 = 1;
  
  public static final int[] P;
  
  public static final int P0 = 0;
  
  public static final int P1 = 1;
  
  public static final int P2 = 2;
  
  public static final int Q = 1;
  
  public static final int Q0 = 1;
  
  public static final int Q1 = 5;
  
  public static final int Q2 = 3;
  
  public static final int R = 2;
  
  public static final int R0 = 2;
  
  public static final int R1 = 7;
  
  public static final int R2 = 4;
  
  public static final int S = 3;
  
  public static final int S0 = 3;
  
  public static final int S1 = 8;
  
  public static final int S2 = 5;
  
  public static final int[] T;
  
  public static final int[] T0;
  
  public static final int[] T1;
  
  public static final int T2 = 10;
  
  public static final int U = 0;
  
  public static final int U0 = 0;
  
  public static final int U1 = 0;
  
  public static final int U2 = 11;
  
  public static final int V = 1;
  
  public static final int V0 = 1;
  
  public static final int V1 = 2;
  
  public static final int V2 = 12;
  
  public static final int W = 2;
  
  public static final int W0 = 2;
  
  public static final int[] W1;
  
  public static final int W2 = 13;
  
  public static final int X = 3;
  
  public static final int X0 = 3;
  
  public static final int X1 = 0;
  
  public static final int X2 = 14;
  
  public static final int[] Y;
  
  public static final int Y0 = 4;
  
  public static final int Y1 = 1;
  
  public static final int Y2 = 15;
  
  public static final int Z = 0;
  
  public static final int Z0 = 5;
  
  public static final int[] Z1;
  
  public static final int[] Z2;
  
  public static final int[] a = new int[] { 
      2130903092, 2130903093, 2130903094, 2130903155, 2130903156, 2130903157, 2130903158, 2130903159, 2130903160, 2130903176, 
      2130903181, 2130903182, 2130903201, 2130903218, 2130903219, 2130903220, 2130903221, 2130903222, 2130903229, 2130903232, 
      2130903258, 2130903266, 2130903278, 2130903281, 2130903282, 2130903312, 2130903315, 2130903343, 2130903352 };
  
  public static final int a0 = 1;
  
  public static final int a1 = 6;
  
  public static final int a2 = 0;
  
  public static final int a3 = 0;
  
  public static final int b = 0;
  
  public static final int b0 = 2;
  
  public static final int b1 = 7;
  
  public static final int b2 = 1;
  
  public static final int b3 = 2;
  
  public static final int c = 1;
  
  public static final int c0 = 3;
  
  public static final int c1 = 8;
  
  public static final int c2 = 2;
  
  public static final int c3 = 3;
  
  public static final int d = 2;
  
  public static final int d0 = 4;
  
  public static final int[] d1;
  
  public static final int d2 = 3;
  
  public static final int d3 = 4;
  
  public static final int e = 3;
  
  public static final int e0 = 5;
  
  public static final int e1 = 0;
  
  public static final int e2 = 4;
  
  public static final int e3 = 5;
  
  public static final int f = 7;
  
  public static final int f0 = 6;
  
  public static final int f1 = 3;
  
  public static final int f2 = 5;
  
  public static final int f3 = 6;
  
  public static final int g = 9;
  
  public static final int[] g0;
  
  public static final int[] g1;
  
  public static final int g2 = 6;
  
  public static final int g3 = 7;
  
  public static final int h = 10;
  
  public static final int h0 = 1;
  
  public static final int h1 = 0;
  
  public static final int h2 = 7;
  
  public static final int h3 = 8;
  
  public static final int i = 12;
  
  public static final int i0 = 2;
  
  public static final int i1 = 1;
  
  public static final int i2 = 8;
  
  public static final int i3 = 9;
  
  public static final int j = 13;
  
  public static final int j0 = 3;
  
  public static final int[] j1;
  
  public static final int j2 = 9;
  
  public static final int j3 = 10;
  
  public static final int k = 14;
  
  public static final int k0 = 4;
  
  public static final int k1 = 0;
  
  public static final int k2 = 10;
  
  public static final int k3 = 11;
  
  public static final int l = 15;
  
  public static final int l0 = 5;
  
  public static final int l1 = 1;
  
  public static final int l2 = 11;
  
  public static final int l3 = 12;
  
  public static final int m = 17;
  
  public static final int m0 = 6;
  
  public static final int m1 = 2;
  
  public static final int m2 = 12;
  
  public static final int m3 = 13;
  
  public static final int n = 20;
  
  public static final int n0 = 7;
  
  public static final int n1 = 3;
  
  public static final int n2 = 13;
  
  public static final int n3 = 14;
  
  public static final int o = 22;
  
  public static final int o0 = 8;
  
  public static final int o1 = 4;
  
  public static final int o2 = 14;
  
  public static final int o3 = 15;
  
  public static final int p = 25;
  
  public static final int p0 = 9;
  
  public static final int p1 = 5;
  
  public static final int p2 = 15;
  
  public static final int p3 = 16;
  
  public static final int q = 26;
  
  public static final int q0 = 10;
  
  public static final int[] q1;
  
  public static final int q2 = 16;
  
  public static final int q3 = 17;
  
  public static final int r = 27;
  
  public static final int r0 = 11;
  
  public static final int r1 = 0;
  
  public static final int[] r2;
  
  public static final int r3 = 18;
  
  public static final int s = 28;
  
  public static final int s0 = 12;
  
  public static final int s1 = 1;
  
  public static final int s2 = 0;
  
  public static final int s3 = 19;
  
  public static final int[] t = new int[] { 16842931 };
  
  public static final int t0 = 13;
  
  public static final int t1 = 2;
  
  public static final int t2 = 1;
  
  public static final int t3 = 20;
  
  public static final int u = 0;
  
  public static final int u0 = 14;
  
  public static final int u1 = 3;
  
  public static final int u2 = 2;
  
  public static final int u3 = 21;
  
  public static final int[] v = new int[] { 16843071 };
  
  public static final int v0 = 17;
  
  public static final int v1 = 4;
  
  public static final int v2 = 3;
  
  public static final int v3 = 22;
  
  public static final int w = 0;
  
  public static final int w0 = 18;
  
  public static final int w1 = 5;
  
  public static final int w2 = 4;
  
  public static final int w3 = 23;
  
  public static final int[] x = new int[] { 2130903092, 2130903093, 2130903124, 2130903218, 2130903315, 2130903352 };
  
  public static final int[] x0;
  
  public static final int x1 = 6;
  
  public static final int[] x2;
  
  public static final int x3 = 24;
  
  public static final int y = 0;
  
  public static final int y0 = 0;
  
  public static final int y1 = 7;
  
  public static final int y2 = 0;
  
  public static final int y3 = 25;
  
  public static final int z = 2;
  
  public static final int z0 = 1;
  
  public static final int z1 = 8;
  
  public static final int z2 = 1;
  
  public static final int z3 = 26;
  
  static {
    D = new int[] { 2130903202, 2130903230 };
    G = new int[] { 16842994, 2130903106, 2130903107, 2130903247, 2130903248, 2130903263, 2130903301, 2130903302 };
    P = new int[] { 16843033, 2130903307, 2130903341, 2130903342 };
    T = new int[] { 16843074, 2130903338, 2130903339, 2130903340 };
    Y = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    g0 = new int[] { 
        16842804, 2130903087, 2130903088, 2130903089, 2130903090, 2130903091, 2130903186, 2130903187, 2130903188, 2130903189, 
        2130903191, 2130903192, 2130903193, 2130903194, 2130903203, 2130903205, 2130903214, 2130903234, 2130903242, 2130903321, 
        2130903332 };
    x0 = new int[] { 
        16842839, 16842926, 2130903040, 2130903041, 2130903042, 2130903043, 2130903044, 2130903045, 2130903046, 2130903047, 
        2130903048, 2130903049, 2130903050, 2130903051, 2130903052, 2130903054, 2130903055, 2130903056, 2130903057, 2130903058, 
        2130903059, 2130903060, 2130903061, 2130903062, 2130903063, 2130903064, 2130903065, 2130903066, 2130903067, 2130903068, 
        2130903069, 2130903070, 2130903073, 2130903077, 2130903078, 2130903079, 2130903080, 2130903086, 2130903098, 2130903099, 
        2130903100, 2130903101, 2130903102, 2130903103, 2130903109, 2130903110, 2130903120, 2130903121, 2130903128, 2130903129, 
        2130903130, 2130903131, 2130903132, 2130903133, 2130903134, 2130903135, 2130903136, 2130903138, 2130903166, 2130903178, 
        2130903179, 2130903180, 2130903183, 2130903185, 2130903196, 2130903197, 2130903198, 2130903199, 2130903200, 2130903220, 
        2130903228, 2130903243, 2130903244, 2130903245, 2130903246, 2130903249, 2130903250, 2130903251, 2130903252, 2130903253, 
        2130903254, 2130903255, 2130903256, 2130903257, 2130903274, 2130903275, 2130903276, 2130903277, 2130903279, 2130903286, 
        2130903287, 2130903288, 2130903289, 2130903293, 2130903294, 2130903295, 2130903296, 2130903304, 2130903305, 2130903319, 
        2130903322, 2130903323, 2130903324, 2130903325, 2130903326, 2130903327, 2130903328, 2130903329, 2130903330, 2130903331, 
        2130903353, 2130903354, 2130903355, 2130903356, 2130903362, 2130903364, 2130903365, 2130903366, 2130903367, 2130903368, 
        2130903369, 2130903370, 2130903371, 2130903372, 2130903373 };
    M0 = new int[] { 2130903081 };
    O0 = new int[] { 16843015, 2130903104, 2130903111, 2130903112 };
    T0 = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130903182, 2130903184, 2130903261, 2130903299 };
    d1 = new int[] { 16842931, 16842996, 16842997, 16843137 };
    g1 = new int[] { 16843436, 16843437 };
    j1 = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    q1 = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130903053, 2130903071, 2130903072, 2130903083, 2130903154, 2130903223, 2130903224, 
        2130903268, 2130903298, 2130903357 };
    O1 = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130903280, 2130903310 };
    T1 = new int[] { 16843126, 16843465, 2130903269 };
    W1 = new int[] { 2130903270, 2130903273 };
    Z1 = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130903123, 2130903153, 2130903177, 2130903217, 2130903225, 2130903235, 
        2130903283, 2130903284, 2130903291, 2130903292, 2130903311, 2130903316, 2130903363 };
    r2 = new int[] { 16842930, 16843126, 16843131, 16843362, 2130903278 };
    x2 = new int[] { 
        16843044, 16843045, 16843074, 2130903300, 2130903306, 2130903317, 2130903318, 2130903320, 2130903335, 2130903336, 
        2130903337, 2130903358, 2130903359, 2130903360 };
    M2 = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 16844165, 2130903205, 2130903214, 2130903321, 2130903332 };
    Z2 = new int[] { 
        16842927, 16843072, 2130903105, 2130903125, 2130903126, 2130903155, 2130903156, 2130903157, 2130903158, 2130903159, 
        2130903160, 2130903258, 2130903259, 2130903260, 2130903262, 2130903264, 2130903265, 2130903278, 2130903312, 2130903313, 
        2130903314, 2130903343, 2130903344, 2130903345, 2130903346, 2130903347, 2130903348, 2130903349, 2130903350, 2130903351 };
    D3 = new int[] { 16842752, 16842970, 2130903271, 2130903272, 2130903333 };
    G3 = new int[] { 16842964, 2130903095, 2130903096 };
    K3 = new int[] { 16842960, 16842994, 16842995 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */