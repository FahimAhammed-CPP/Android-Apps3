package b.b;

public final class e {
  public static final int A = 2131165250;
  
  public static final int B = 2131165251;
  
  public static final int C = 2131165252;
  
  public static final int D = 2131165253;
  
  public static final int E = 2131165254;
  
  public static final int F = 2131165255;
  
  public static final int G = 2131165256;
  
  public static final int H = 2131165257;
  
  public static final int I = 2131165259;
  
  public static final int J = 2131165260;
  
  public static final int K = 2131165261;
  
  public static final int L = 2131165262;
  
  public static final int M = 2131165263;
  
  public static final int N = 2131165264;
  
  public static final int O = 2131165265;
  
  public static final int P = 2131165266;
  
  public static final int Q = 2131165267;
  
  public static final int R = 2131165268;
  
  public static final int S = 2131165269;
  
  public static final int T = 2131165270;
  
  public static final int a = 2131165186;
  
  public static final int b = 2131165188;
  
  public static final int c = 2131165189;
  
  public static final int d = 2131165190;
  
  public static final int e = 2131165193;
  
  public static final int f = 2131165194;
  
  public static final int g = 2131165195;
  
  public static final int h = 2131165196;
  
  public static final int i = 2131165201;
  
  public static final int j = 2131165202;
  
  public static final int k = 2131165203;
  
  public static final int l = 2131165205;
  
  public static final int m = 2131165206;
  
  public static final int n = 2131165207;
  
  public static final int o = 2131165210;
  
  public static final int p = 2131165212;
  
  public static final int q = 2131165213;
  
  public static final int r = 2131165215;
  
  public static final int s = 2131165216;
  
  public static final int t = 2131165217;
  
  public static final int u = 2131165229;
  
  public static final int v = 2131165240;
  
  public static final int w = 2131165241;
  
  public static final int x = 2131165242;
  
  public static final int y = 2131165243;
  
  public static final int z = 2131165244;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */