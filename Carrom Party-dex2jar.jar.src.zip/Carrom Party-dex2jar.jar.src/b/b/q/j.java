package b.b.q;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import b.h.g.l.c;

public class j {
  public static final int[] c = new int[] { 16843067, 16843068 };
  
  public final ProgressBar a;
  
  public Bitmap b;
  
  public j(ProgressBar paramProgressBar) {
    this.a = paramProgressBar;
  }
  
  public final Shape a() {
    return (Shape)new RoundRectShape(new float[] { 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }, null, null);
  }
  
  public Bitmap b() {
    return this.b;
  }
  
  public void c(AttributeSet paramAttributeSet, int paramInt) {
    g0 g0 = g0.t(this.a.getContext(), paramAttributeSet, c, paramInt, 0);
    Drawable drawable = g0.g(0);
    if (drawable != null)
      this.a.setIndeterminateDrawable(e(drawable)); 
    drawable = g0.g(1);
    if (drawable != null)
      this.a.setProgressDrawable(d(drawable, false)); 
    g0.u();
  }
  
  public final Drawable d(Drawable paramDrawable, boolean paramBoolean) {
    ClipDrawable clipDrawable;
    if (paramDrawable instanceof c) {
      c c = (c)paramDrawable;
      Drawable drawable = c.b();
      if (drawable != null) {
        c.a(d(drawable, paramBoolean));
        return paramDrawable;
      } 
    } else {
      LayerDrawable layerDrawable;
      if (paramDrawable instanceof LayerDrawable) {
        layerDrawable = (LayerDrawable)paramDrawable;
        int k = layerDrawable.getNumberOfLayers();
        Drawable[] arrayOfDrawable = new Drawable[k];
        boolean bool = false;
        int i;
        for (i = 0; i < k; i++) {
          int m = layerDrawable.getId(i);
          Drawable drawable = layerDrawable.getDrawable(i);
          if (m == 16908301 || m == 16908303) {
            paramBoolean = true;
          } else {
            paramBoolean = false;
          } 
          arrayOfDrawable[i] = d(drawable, paramBoolean);
        } 
        LayerDrawable layerDrawable1 = new LayerDrawable(arrayOfDrawable);
        for (i = bool; i < k; i++)
          layerDrawable1.setId(i, layerDrawable.getId(i)); 
        return (Drawable)layerDrawable1;
      } 
      if (layerDrawable instanceof BitmapDrawable) {
        BitmapDrawable bitmapDrawable = (BitmapDrawable)layerDrawable;
        Bitmap bitmap = bitmapDrawable.getBitmap();
        if (this.b == null)
          this.b = bitmap; 
        ShapeDrawable shapeDrawable2 = new ShapeDrawable(a());
        BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP);
        shapeDrawable2.getPaint().setShader((Shader)bitmapShader);
        shapeDrawable2.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
        ShapeDrawable shapeDrawable1 = shapeDrawable2;
        if (paramBoolean)
          clipDrawable = new ClipDrawable((Drawable)shapeDrawable2, 3, 1); 
        return (Drawable)clipDrawable;
      } 
    } 
    return (Drawable)clipDrawable;
  }
  
  public final Drawable e(Drawable paramDrawable) {
    AnimationDrawable animationDrawable;
    Drawable drawable = paramDrawable;
    if (paramDrawable instanceof AnimationDrawable) {
      AnimationDrawable animationDrawable1 = (AnimationDrawable)paramDrawable;
      int k = animationDrawable1.getNumberOfFrames();
      animationDrawable = new AnimationDrawable();
      animationDrawable.setOneShot(animationDrawable1.isOneShot());
      for (int i = 0; i < k; i++) {
        Drawable drawable1 = d(animationDrawable1.getFrame(i), true);
        drawable1.setLevel(10000);
        animationDrawable.addFrame(drawable1, animationDrawable1.getDuration(i));
      } 
      animationDrawable.setLevel(10000);
    } 
    return (Drawable)animationDrawable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */