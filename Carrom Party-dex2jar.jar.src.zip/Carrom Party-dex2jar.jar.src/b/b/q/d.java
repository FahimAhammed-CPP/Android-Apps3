package b.b.q;

import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;

public class d extends DataSetObservable {
  public Intent a(int paramInt) {
    throw null;
  }
  
  public ResolveInfo b(int paramInt) {
    throw null;
  }
  
  public int c() {
    throw null;
  }
  
  public ResolveInfo d() {
    throw null;
  }
  
  public void e(int paramInt) {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */