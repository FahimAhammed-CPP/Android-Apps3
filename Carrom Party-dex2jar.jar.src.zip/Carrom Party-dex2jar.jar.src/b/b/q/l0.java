package b.b.q;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import java.lang.ref.WeakReference;

public class l0 extends Resources {
  public static boolean b = false;
  
  public final WeakReference<Context> a;
  
  public l0(Context paramContext, Resources paramResources) {
    super(paramResources.getAssets(), paramResources.getDisplayMetrics(), paramResources.getConfiguration());
    this.a = new WeakReference<Context>(paramContext);
  }
  
  public static boolean a() {
    return b;
  }
  
  public static boolean b() {
    return (a() && Build.VERSION.SDK_INT <= 20);
  }
  
  public final Drawable c(int paramInt) {
    return super.getDrawable(paramInt);
  }
  
  public Drawable getDrawable(int paramInt) {
    Context context = this.a.get();
    return (context != null) ? w.h().t(context, this, paramInt) : super.getDrawable(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\l0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */