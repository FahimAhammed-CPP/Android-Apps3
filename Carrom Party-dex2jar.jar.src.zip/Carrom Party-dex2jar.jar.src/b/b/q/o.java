package b.b.q;

import android.view.Menu;
import android.view.Window;
import b.b.p.j.m;

public interface o {
  void a(Menu paramMenu, m.a parama);
  
  boolean b();
  
  void c();
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  void h(int paramInt);
  
  void i();
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */