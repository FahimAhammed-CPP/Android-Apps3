package b.b.q;

import android.graphics.Rect;

public interface s {
  void setOnFitSystemWindowsListener(a parama);
  
  public static interface a {
    void a(Rect param1Rect);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */