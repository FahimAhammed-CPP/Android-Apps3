package b.b.q;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;
import b.b.j;
import b.h.n.r;
import b.h.n.v;
import b.h.n.w;

public abstract class a extends ViewGroup {
  public final a a = new a(this);
  
  public final Context b;
  
  public ActionMenuView c;
  
  public c d;
  
  public int e;
  
  public v f;
  
  public boolean g;
  
  public boolean h;
  
  public a(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public a(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue typedValue = new TypedValue();
    if (paramContext.getTheme().resolveAttribute(b.b.a.a, typedValue, true) && typedValue.resourceId != 0) {
      this.b = (Context)new ContextThemeWrapper(paramContext, typedValue.resourceId);
      return;
    } 
    this.b = paramContext;
  }
  
  public static int d(int paramInt1, int paramInt2, boolean paramBoolean) {
    return paramBoolean ? (paramInt1 - paramInt2) : (paramInt1 + paramInt2);
  }
  
  public int c(View paramView, int paramInt1, int paramInt2, int paramInt3) {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3);
  }
  
  public int e(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 += (paramInt3 - j) / 2;
    if (paramBoolean) {
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    } else {
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    } 
    paramInt1 = i;
    if (paramBoolean)
      paramInt1 = -i; 
    return paramInt1;
  }
  
  public v f(int paramInt, long paramLong) {
    v v1 = this.f;
    if (v1 != null)
      v1.b(); 
    if (paramInt == 0) {
      if (getVisibility() != 0)
        setAlpha(0.0F); 
      v1 = r.b((View)this);
      v1.a(1.0F);
      v1.d(paramLong);
      a a2 = this.a;
      a2.d(v1, paramInt);
      v1.f(a2);
      return v1;
    } 
    v1 = r.b((View)this);
    v1.a(0.0F);
    v1.d(paramLong);
    a a1 = this.a;
    a1.d(v1, paramInt);
    v1.f(a1);
    return v1;
  }
  
  public int getAnimatedVisibility() {
    return (this.f != null) ? this.a.b : getVisibility();
  }
  
  public int getContentHeight() {
    return this.e;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray typedArray = getContext().obtainStyledAttributes(null, j.a, b.b.a.c, 0);
    setContentHeight(typedArray.getLayoutDimension(j.j, 0));
    typedArray.recycle();
    c c1 = this.d;
    if (c1 != null)
      c1.F(paramConfiguration); 
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.h = false; 
    if (!this.h) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.h = true; 
    } 
    if (i == 10 || i == 3)
      this.h = false; 
    return true;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.g = false; 
    if (!this.g) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.g = true; 
    } 
    if (i == 1 || i == 3)
      this.g = false; 
    return true;
  }
  
  public abstract void setContentHeight(int paramInt);
  
  public void setVisibility(int paramInt) {
    if (paramInt != getVisibility()) {
      v v1 = this.f;
      if (v1 != null)
        v1.b(); 
      super.setVisibility(paramInt);
    } 
  }
  
  public class a implements w {
    public boolean a = false;
    
    public int b;
    
    public a(a this$0) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (this.a)
        return; 
      a a1 = this.c;
      a1.f = null;
      a.b(a1, this.b);
    }
    
    public void c(View param1View) {
      a.a(this.c, 0);
      this.a = false;
    }
    
    public a d(v param1v, int param1Int) {
      this.c.f = param1v;
      this.b = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */