package b.b.q;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.TextView;
import b.b.j;
import b.h.f.e.f;
import b.h.o.b;
import java.lang.ref.WeakReference;

public class m {
  public final TextView a;
  
  public e0 b;
  
  public e0 c;
  
  public e0 d;
  
  public e0 e;
  
  public e0 f;
  
  public e0 g;
  
  public e0 h;
  
  public final n i;
  
  public int j = 0;
  
  public int k = -1;
  
  public Typeface l;
  
  public boolean m;
  
  public m(TextView paramTextView) {
    this.a = paramTextView;
    this.i = new n(paramTextView);
  }
  
  public static e0 d(Context paramContext, g paramg, int paramInt) {
    ColorStateList colorStateList = paramg.f(paramContext, paramInt);
    if (colorStateList != null) {
      e0 e01 = new e0();
      e01.d = true;
      e01.a = colorStateList;
      return e01;
    } 
    return null;
  }
  
  public final void A(int paramInt, float paramFloat) {
    this.i.y(paramInt, paramFloat);
  }
  
  public void B(Typeface paramTypeface) {
    if (this.m) {
      this.a.setTypeface(paramTypeface);
      this.l = paramTypeface;
    } 
  }
  
  public final void C(Context paramContext, g0 paramg0) {
    this.j = paramg0.j(j.P2, this.j);
    int j = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (j >= 28) {
      int k = paramg0.j(j.U2, -1);
      this.k = k;
      if (k != -1)
        this.j = this.j & 0x2 | 0x0; 
    } 
    int i = j.T2;
    if (paramg0.q(i) || paramg0.q(j.V2)) {
      this.l = null;
      int k = j.V2;
      if (paramg0.q(k))
        i = k; 
      k = this.k;
      int i1 = this.j;
      if (!paramContext.isRestricted()) {
        a a = new a(this, k, i1);
        try {
          boolean bool1;
          Typeface typeface = paramg0.i(i, this.j, a);
          if (typeface != null)
            if (j >= 28 && this.k != -1) {
              typeface = Typeface.create(typeface, 0);
              k = this.k;
              if ((this.j & 0x2) != 0) {
                bool1 = true;
              } else {
                bool1 = false;
              } 
              this.l = Typeface.create(typeface, k, bool1);
            } else {
              this.l = typeface;
            }  
          if (this.l == null) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          this.m = bool1;
        } catch (UnsupportedOperationException|android.content.res.Resources.NotFoundException unsupportedOperationException) {}
      } 
      if (this.l == null) {
        String str = paramg0.n(i);
        if (str != null) {
          Typeface typeface;
          if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
            typeface = Typeface.create(str, 0);
            i = this.k;
            boolean bool1 = bool;
            if ((this.j & 0x2) != 0)
              bool1 = true; 
            this.l = Typeface.create(typeface, i, bool1);
            return;
          } 
          this.l = Typeface.create((String)typeface, this.j);
        } 
      } 
      return;
    } 
    i = j.O2;
    if (paramg0.q(i)) {
      this.m = false;
      i = paramg0.j(i, 1);
      if (i != 1) {
        if (i != 2) {
          if (i != 3)
            return; 
          this.l = Typeface.MONOSPACE;
          return;
        } 
        this.l = Typeface.SERIF;
        return;
      } 
      this.l = Typeface.SANS_SERIF;
    } 
  }
  
  public final void a(Drawable paramDrawable, e0 parame0) {
    if (paramDrawable != null && parame0 != null)
      g.i(paramDrawable, parame0, this.a.getDrawableState()); 
  }
  
  public void b() {
    if (this.b != null || this.c != null || this.d != null || this.e != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.b);
      a(arrayOfDrawable[1], this.c);
      a(arrayOfDrawable[2], this.d);
      a(arrayOfDrawable[3], this.e);
    } 
    if (Build.VERSION.SDK_INT >= 17 && (this.f != null || this.g != null)) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      a(arrayOfDrawable[0], this.f);
      a(arrayOfDrawable[2], this.g);
    } 
  }
  
  public void c() {
    this.i.b();
  }
  
  public int e() {
    return this.i.j();
  }
  
  public int f() {
    return this.i.k();
  }
  
  public int g() {
    return this.i.l();
  }
  
  public int[] h() {
    return this.i.m();
  }
  
  public int i() {
    return this.i.n();
  }
  
  public ColorStateList j() {
    e0 e01 = this.h;
    return (e01 != null) ? e01.a : null;
  }
  
  public PorterDuff.Mode k() {
    e0 e01 = this.h;
    return (e01 != null) ? e01.b : null;
  }
  
  public boolean l() {
    return this.i.s();
  }
  
  @SuppressLint({"NewApi"})
  public void m(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/TextView;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: astore #16
    //   9: invokestatic b : ()Lb/b/q/g;
    //   12: astore #15
    //   14: aload #16
    //   16: aload_1
    //   17: getstatic b/b/j.Y : [I
    //   20: iload_2
    //   21: iconst_0
    //   22: invokestatic t : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Lb/b/q/g0;
    //   25: astore #8
    //   27: aload #8
    //   29: getstatic b/b/j.Z : I
    //   32: iconst_m1
    //   33: invokevirtual m : (II)I
    //   36: istore_3
    //   37: getstatic b/b/j.c0 : I
    //   40: istore #4
    //   42: aload #8
    //   44: iload #4
    //   46: invokevirtual q : (I)Z
    //   49: ifeq -> 71
    //   52: aload_0
    //   53: aload #16
    //   55: aload #15
    //   57: aload #8
    //   59: iload #4
    //   61: iconst_0
    //   62: invokevirtual m : (II)I
    //   65: invokestatic d : (Landroid/content/Context;Lb/b/q/g;I)Lb/b/q/e0;
    //   68: putfield b : Lb/b/q/e0;
    //   71: getstatic b/b/j.a0 : I
    //   74: istore #4
    //   76: aload #8
    //   78: iload #4
    //   80: invokevirtual q : (I)Z
    //   83: ifeq -> 105
    //   86: aload_0
    //   87: aload #16
    //   89: aload #15
    //   91: aload #8
    //   93: iload #4
    //   95: iconst_0
    //   96: invokevirtual m : (II)I
    //   99: invokestatic d : (Landroid/content/Context;Lb/b/q/g;I)Lb/b/q/e0;
    //   102: putfield c : Lb/b/q/e0;
    //   105: getstatic b/b/j.d0 : I
    //   108: istore #4
    //   110: aload #8
    //   112: iload #4
    //   114: invokevirtual q : (I)Z
    //   117: ifeq -> 139
    //   120: aload_0
    //   121: aload #16
    //   123: aload #15
    //   125: aload #8
    //   127: iload #4
    //   129: iconst_0
    //   130: invokevirtual m : (II)I
    //   133: invokestatic d : (Landroid/content/Context;Lb/b/q/g;I)Lb/b/q/e0;
    //   136: putfield d : Lb/b/q/e0;
    //   139: getstatic b/b/j.b0 : I
    //   142: istore #4
    //   144: aload #8
    //   146: iload #4
    //   148: invokevirtual q : (I)Z
    //   151: ifeq -> 173
    //   154: aload_0
    //   155: aload #16
    //   157: aload #15
    //   159: aload #8
    //   161: iload #4
    //   163: iconst_0
    //   164: invokevirtual m : (II)I
    //   167: invokestatic d : (Landroid/content/Context;Lb/b/q/g;I)Lb/b/q/e0;
    //   170: putfield e : Lb/b/q/e0;
    //   173: getstatic android/os/Build$VERSION.SDK_INT : I
    //   176: istore #4
    //   178: iload #4
    //   180: bipush #17
    //   182: if_icmplt -> 253
    //   185: getstatic b/b/j.e0 : I
    //   188: istore #5
    //   190: aload #8
    //   192: iload #5
    //   194: invokevirtual q : (I)Z
    //   197: ifeq -> 219
    //   200: aload_0
    //   201: aload #16
    //   203: aload #15
    //   205: aload #8
    //   207: iload #5
    //   209: iconst_0
    //   210: invokevirtual m : (II)I
    //   213: invokestatic d : (Landroid/content/Context;Lb/b/q/g;I)Lb/b/q/e0;
    //   216: putfield f : Lb/b/q/e0;
    //   219: getstatic b/b/j.f0 : I
    //   222: istore #5
    //   224: aload #8
    //   226: iload #5
    //   228: invokevirtual q : (I)Z
    //   231: ifeq -> 253
    //   234: aload_0
    //   235: aload #16
    //   237: aload #15
    //   239: aload #8
    //   241: iload #5
    //   243: iconst_0
    //   244: invokevirtual m : (II)I
    //   247: invokestatic d : (Landroid/content/Context;Lb/b/q/g;I)Lb/b/q/e0;
    //   250: putfield g : Lb/b/q/e0;
    //   253: aload #8
    //   255: invokevirtual u : ()V
    //   258: aload_0
    //   259: getfield a : Landroid/widget/TextView;
    //   262: invokevirtual getTransformationMethod : ()Landroid/text/method/TransformationMethod;
    //   265: instanceof android/text/method/PasswordTransformationMethod
    //   268: istore #7
    //   270: iload_3
    //   271: iconst_m1
    //   272: if_icmpeq -> 523
    //   275: aload #16
    //   277: iload_3
    //   278: getstatic b/b/j.M2 : [I
    //   281: invokestatic r : (Landroid/content/Context;I[I)Lb/b/q/g0;
    //   284: astore #13
    //   286: iload #7
    //   288: ifne -> 318
    //   291: getstatic b/b/j.X2 : I
    //   294: istore_3
    //   295: aload #13
    //   297: iload_3
    //   298: invokevirtual q : (I)Z
    //   301: ifeq -> 318
    //   304: aload #13
    //   306: iload_3
    //   307: iconst_0
    //   308: invokevirtual a : (IZ)Z
    //   311: istore #6
    //   313: iconst_1
    //   314: istore_3
    //   315: goto -> 323
    //   318: iconst_0
    //   319: istore #6
    //   321: iconst_0
    //   322: istore_3
    //   323: aload_0
    //   324: aload #16
    //   326: aload #13
    //   328: invokevirtual C : (Landroid/content/Context;Lb/b/q/g0;)V
    //   331: iload #4
    //   333: bipush #23
    //   335: if_icmpge -> 431
    //   338: getstatic b/b/j.Q2 : I
    //   341: istore #5
    //   343: aload #13
    //   345: iload #5
    //   347: invokevirtual q : (I)Z
    //   350: ifeq -> 365
    //   353: aload #13
    //   355: iload #5
    //   357: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   360: astore #9
    //   362: goto -> 368
    //   365: aconst_null
    //   366: astore #9
    //   368: getstatic b/b/j.R2 : I
    //   371: istore #5
    //   373: aload #13
    //   375: iload #5
    //   377: invokevirtual q : (I)Z
    //   380: ifeq -> 395
    //   383: aload #13
    //   385: iload #5
    //   387: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   390: astore #12
    //   392: goto -> 398
    //   395: aconst_null
    //   396: astore #12
    //   398: getstatic b/b/j.S2 : I
    //   401: istore #5
    //   403: aload #13
    //   405: iload #5
    //   407: invokevirtual q : (I)Z
    //   410: ifeq -> 425
    //   413: aload #13
    //   415: iload #5
    //   417: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   420: astore #8
    //   422: goto -> 440
    //   425: aconst_null
    //   426: astore #8
    //   428: goto -> 440
    //   431: aconst_null
    //   432: astore #8
    //   434: aconst_null
    //   435: astore #9
    //   437: aconst_null
    //   438: astore #12
    //   440: getstatic b/b/j.Y2 : I
    //   443: istore #5
    //   445: aload #13
    //   447: iload #5
    //   449: invokevirtual q : (I)Z
    //   452: ifeq -> 467
    //   455: aload #13
    //   457: iload #5
    //   459: invokevirtual n : (I)Ljava/lang/String;
    //   462: astore #11
    //   464: goto -> 470
    //   467: aconst_null
    //   468: astore #11
    //   470: iload #4
    //   472: bipush #26
    //   474: if_icmplt -> 504
    //   477: getstatic b/b/j.W2 : I
    //   480: istore #5
    //   482: aload #13
    //   484: iload #5
    //   486: invokevirtual q : (I)Z
    //   489: ifeq -> 504
    //   492: aload #13
    //   494: iload #5
    //   496: invokevirtual n : (I)Ljava/lang/String;
    //   499: astore #10
    //   501: goto -> 507
    //   504: aconst_null
    //   505: astore #10
    //   507: aload #13
    //   509: invokevirtual u : ()V
    //   512: aload #8
    //   514: astore #13
    //   516: aload #12
    //   518: astore #8
    //   520: goto -> 543
    //   523: aconst_null
    //   524: astore #13
    //   526: aconst_null
    //   527: astore #10
    //   529: aconst_null
    //   530: astore #9
    //   532: aconst_null
    //   533: astore #11
    //   535: aconst_null
    //   536: astore #8
    //   538: iconst_0
    //   539: istore #6
    //   541: iconst_0
    //   542: istore_3
    //   543: aload #16
    //   545: aload_1
    //   546: getstatic b/b/j.M2 : [I
    //   549: iload_2
    //   550: iconst_0
    //   551: invokestatic t : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Lb/b/q/g0;
    //   554: astore #17
    //   556: iload #7
    //   558: ifne -> 591
    //   561: getstatic b/b/j.X2 : I
    //   564: istore #5
    //   566: aload #17
    //   568: iload #5
    //   570: invokevirtual q : (I)Z
    //   573: ifeq -> 591
    //   576: aload #17
    //   578: iload #5
    //   580: iconst_0
    //   581: invokevirtual a : (IZ)Z
    //   584: istore #6
    //   586: iconst_1
    //   587: istore_3
    //   588: goto -> 591
    //   591: aload #9
    //   593: astore #12
    //   595: aload #8
    //   597: astore #14
    //   599: iload #4
    //   601: bipush #23
    //   603: if_icmpge -> 689
    //   606: getstatic b/b/j.Q2 : I
    //   609: istore #5
    //   611: aload #17
    //   613: iload #5
    //   615: invokevirtual q : (I)Z
    //   618: ifeq -> 630
    //   621: aload #17
    //   623: iload #5
    //   625: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   628: astore #9
    //   630: getstatic b/b/j.R2 : I
    //   633: istore #5
    //   635: aload #17
    //   637: iload #5
    //   639: invokevirtual q : (I)Z
    //   642: ifeq -> 654
    //   645: aload #17
    //   647: iload #5
    //   649: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   652: astore #8
    //   654: getstatic b/b/j.S2 : I
    //   657: istore #5
    //   659: aload #9
    //   661: astore #12
    //   663: aload #8
    //   665: astore #14
    //   667: aload #17
    //   669: iload #5
    //   671: invokevirtual q : (I)Z
    //   674: ifeq -> 689
    //   677: aload #17
    //   679: iload #5
    //   681: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   684: astore #12
    //   686: goto -> 701
    //   689: aload #14
    //   691: astore #8
    //   693: aload #12
    //   695: astore #9
    //   697: aload #13
    //   699: astore #12
    //   701: getstatic b/b/j.Y2 : I
    //   704: istore #5
    //   706: aload #17
    //   708: iload #5
    //   710: invokevirtual q : (I)Z
    //   713: ifeq -> 725
    //   716: aload #17
    //   718: iload #5
    //   720: invokevirtual n : (I)Ljava/lang/String;
    //   723: astore #11
    //   725: aload #10
    //   727: astore #13
    //   729: iload #4
    //   731: bipush #26
    //   733: if_icmplt -> 764
    //   736: getstatic b/b/j.W2 : I
    //   739: istore #5
    //   741: aload #10
    //   743: astore #13
    //   745: aload #17
    //   747: iload #5
    //   749: invokevirtual q : (I)Z
    //   752: ifeq -> 764
    //   755: aload #17
    //   757: iload #5
    //   759: invokevirtual n : (I)Ljava/lang/String;
    //   762: astore #13
    //   764: iload #4
    //   766: bipush #28
    //   768: if_icmplt -> 809
    //   771: getstatic b/b/j.N2 : I
    //   774: istore #5
    //   776: aload #17
    //   778: iload #5
    //   780: invokevirtual q : (I)Z
    //   783: ifeq -> 809
    //   786: aload #17
    //   788: iload #5
    //   790: iconst_m1
    //   791: invokevirtual e : (II)I
    //   794: ifne -> 809
    //   797: aload_0
    //   798: getfield a : Landroid/widget/TextView;
    //   801: iconst_0
    //   802: fconst_0
    //   803: invokevirtual setTextSize : (IF)V
    //   806: goto -> 809
    //   809: aload_0
    //   810: aload #16
    //   812: aload #17
    //   814: invokevirtual C : (Landroid/content/Context;Lb/b/q/g0;)V
    //   817: aload #17
    //   819: invokevirtual u : ()V
    //   822: aload #9
    //   824: ifnull -> 836
    //   827: aload_0
    //   828: getfield a : Landroid/widget/TextView;
    //   831: aload #9
    //   833: invokevirtual setTextColor : (Landroid/content/res/ColorStateList;)V
    //   836: aload #8
    //   838: ifnull -> 850
    //   841: aload_0
    //   842: getfield a : Landroid/widget/TextView;
    //   845: aload #8
    //   847: invokevirtual setHintTextColor : (Landroid/content/res/ColorStateList;)V
    //   850: aload #12
    //   852: ifnull -> 864
    //   855: aload_0
    //   856: getfield a : Landroid/widget/TextView;
    //   859: aload #12
    //   861: invokevirtual setLinkTextColor : (Landroid/content/res/ColorStateList;)V
    //   864: iload #7
    //   866: ifne -> 879
    //   869: iload_3
    //   870: ifeq -> 879
    //   873: aload_0
    //   874: iload #6
    //   876: invokevirtual r : (Z)V
    //   879: aload_0
    //   880: getfield l : Landroid/graphics/Typeface;
    //   883: astore #8
    //   885: aload #8
    //   887: ifnull -> 923
    //   890: aload_0
    //   891: getfield k : I
    //   894: iconst_m1
    //   895: if_icmpne -> 914
    //   898: aload_0
    //   899: getfield a : Landroid/widget/TextView;
    //   902: aload #8
    //   904: aload_0
    //   905: getfield j : I
    //   908: invokevirtual setTypeface : (Landroid/graphics/Typeface;I)V
    //   911: goto -> 923
    //   914: aload_0
    //   915: getfield a : Landroid/widget/TextView;
    //   918: aload #8
    //   920: invokevirtual setTypeface : (Landroid/graphics/Typeface;)V
    //   923: aload #13
    //   925: ifnull -> 938
    //   928: aload_0
    //   929: getfield a : Landroid/widget/TextView;
    //   932: aload #13
    //   934: invokevirtual setFontVariationSettings : (Ljava/lang/String;)Z
    //   937: pop
    //   938: aload #11
    //   940: ifnull -> 999
    //   943: iload #4
    //   945: bipush #24
    //   947: if_icmplt -> 965
    //   950: aload_0
    //   951: getfield a : Landroid/widget/TextView;
    //   954: aload #11
    //   956: invokestatic forLanguageTags : (Ljava/lang/String;)Landroid/os/LocaleList;
    //   959: invokevirtual setTextLocales : (Landroid/os/LocaleList;)V
    //   962: goto -> 999
    //   965: iload #4
    //   967: bipush #21
    //   969: if_icmplt -> 999
    //   972: aload #11
    //   974: iconst_0
    //   975: aload #11
    //   977: bipush #44
    //   979: invokevirtual indexOf : (I)I
    //   982: invokevirtual substring : (II)Ljava/lang/String;
    //   985: astore #8
    //   987: aload_0
    //   988: getfield a : Landroid/widget/TextView;
    //   991: aload #8
    //   993: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   996: invokevirtual setTextLocale : (Ljava/util/Locale;)V
    //   999: aload_0
    //   1000: getfield i : Lb/b/q/n;
    //   1003: aload_1
    //   1004: iload_2
    //   1005: invokevirtual t : (Landroid/util/AttributeSet;I)V
    //   1008: getstatic b/h/o/b.r : Z
    //   1011: ifeq -> 1096
    //   1014: aload_0
    //   1015: getfield i : Lb/b/q/n;
    //   1018: invokevirtual n : ()I
    //   1021: ifeq -> 1096
    //   1024: aload_0
    //   1025: getfield i : Lb/b/q/n;
    //   1028: invokevirtual m : ()[I
    //   1031: astore #8
    //   1033: aload #8
    //   1035: arraylength
    //   1036: ifle -> 1096
    //   1039: aload_0
    //   1040: getfield a : Landroid/widget/TextView;
    //   1043: invokevirtual getAutoSizeStepGranularity : ()I
    //   1046: i2f
    //   1047: ldc_w -1.0
    //   1050: fcmpl
    //   1051: ifeq -> 1086
    //   1054: aload_0
    //   1055: getfield a : Landroid/widget/TextView;
    //   1058: aload_0
    //   1059: getfield i : Lb/b/q/n;
    //   1062: invokevirtual k : ()I
    //   1065: aload_0
    //   1066: getfield i : Lb/b/q/n;
    //   1069: invokevirtual j : ()I
    //   1072: aload_0
    //   1073: getfield i : Lb/b/q/n;
    //   1076: invokevirtual l : ()I
    //   1079: iconst_0
    //   1080: invokevirtual setAutoSizeTextTypeUniformWithConfiguration : (IIII)V
    //   1083: goto -> 1096
    //   1086: aload_0
    //   1087: getfield a : Landroid/widget/TextView;
    //   1090: aload #8
    //   1092: iconst_0
    //   1093: invokevirtual setAutoSizeTextTypeUniformWithPresetSizes : ([II)V
    //   1096: aload #16
    //   1098: aload_1
    //   1099: getstatic b/b/j.g0 : [I
    //   1102: invokestatic s : (Landroid/content/Context;Landroid/util/AttributeSet;[I)Lb/b/q/g0;
    //   1105: astore #13
    //   1107: aload #13
    //   1109: getstatic b/b/j.o0 : I
    //   1112: iconst_m1
    //   1113: invokevirtual m : (II)I
    //   1116: istore_2
    //   1117: iload_2
    //   1118: iconst_m1
    //   1119: if_icmpeq -> 1134
    //   1122: aload #15
    //   1124: aload #16
    //   1126: iload_2
    //   1127: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1130: astore_1
    //   1131: goto -> 1136
    //   1134: aconst_null
    //   1135: astore_1
    //   1136: aload #13
    //   1138: getstatic b/b/j.t0 : I
    //   1141: iconst_m1
    //   1142: invokevirtual m : (II)I
    //   1145: istore_2
    //   1146: iload_2
    //   1147: iconst_m1
    //   1148: if_icmpeq -> 1164
    //   1151: aload #15
    //   1153: aload #16
    //   1155: iload_2
    //   1156: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1159: astore #8
    //   1161: goto -> 1167
    //   1164: aconst_null
    //   1165: astore #8
    //   1167: aload #13
    //   1169: getstatic b/b/j.p0 : I
    //   1172: iconst_m1
    //   1173: invokevirtual m : (II)I
    //   1176: istore_2
    //   1177: iload_2
    //   1178: iconst_m1
    //   1179: if_icmpeq -> 1195
    //   1182: aload #15
    //   1184: aload #16
    //   1186: iload_2
    //   1187: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1190: astore #9
    //   1192: goto -> 1198
    //   1195: aconst_null
    //   1196: astore #9
    //   1198: aload #13
    //   1200: getstatic b/b/j.m0 : I
    //   1203: iconst_m1
    //   1204: invokevirtual m : (II)I
    //   1207: istore_2
    //   1208: iload_2
    //   1209: iconst_m1
    //   1210: if_icmpeq -> 1226
    //   1213: aload #15
    //   1215: aload #16
    //   1217: iload_2
    //   1218: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1221: astore #10
    //   1223: goto -> 1229
    //   1226: aconst_null
    //   1227: astore #10
    //   1229: aload #13
    //   1231: getstatic b/b/j.q0 : I
    //   1234: iconst_m1
    //   1235: invokevirtual m : (II)I
    //   1238: istore_2
    //   1239: iload_2
    //   1240: iconst_m1
    //   1241: if_icmpeq -> 1257
    //   1244: aload #15
    //   1246: aload #16
    //   1248: iload_2
    //   1249: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1252: astore #11
    //   1254: goto -> 1260
    //   1257: aconst_null
    //   1258: astore #11
    //   1260: aload #13
    //   1262: getstatic b/b/j.n0 : I
    //   1265: iconst_m1
    //   1266: invokevirtual m : (II)I
    //   1269: istore_2
    //   1270: iload_2
    //   1271: iconst_m1
    //   1272: if_icmpeq -> 1288
    //   1275: aload #15
    //   1277: aload #16
    //   1279: iload_2
    //   1280: invokevirtual c : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   1283: astore #12
    //   1285: goto -> 1291
    //   1288: aconst_null
    //   1289: astore #12
    //   1291: aload_0
    //   1292: aload_1
    //   1293: aload #8
    //   1295: aload #9
    //   1297: aload #10
    //   1299: aload #11
    //   1301: aload #12
    //   1303: invokevirtual x : (Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    //   1306: getstatic b/b/j.r0 : I
    //   1309: istore_2
    //   1310: aload #13
    //   1312: iload_2
    //   1313: invokevirtual q : (I)Z
    //   1316: ifeq -> 1334
    //   1319: aload #13
    //   1321: iload_2
    //   1322: invokevirtual c : (I)Landroid/content/res/ColorStateList;
    //   1325: astore_1
    //   1326: aload_0
    //   1327: getfield a : Landroid/widget/TextView;
    //   1330: aload_1
    //   1331: invokestatic f : (Landroid/widget/TextView;Landroid/content/res/ColorStateList;)V
    //   1334: getstatic b/b/j.s0 : I
    //   1337: istore_2
    //   1338: aload #13
    //   1340: iload_2
    //   1341: invokevirtual q : (I)Z
    //   1344: ifeq -> 1370
    //   1347: aload #13
    //   1349: iload_2
    //   1350: iconst_m1
    //   1351: invokevirtual j : (II)I
    //   1354: aconst_null
    //   1355: invokestatic e : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   1358: astore_1
    //   1359: aload_0
    //   1360: getfield a : Landroid/widget/TextView;
    //   1363: aload_1
    //   1364: invokestatic g : (Landroid/widget/TextView;Landroid/graphics/PorterDuff$Mode;)V
    //   1367: goto -> 1370
    //   1370: aload #13
    //   1372: getstatic b/b/j.u0 : I
    //   1375: iconst_m1
    //   1376: invokevirtual e : (II)I
    //   1379: istore_2
    //   1380: aload #13
    //   1382: getstatic b/b/j.v0 : I
    //   1385: iconst_m1
    //   1386: invokevirtual e : (II)I
    //   1389: istore_3
    //   1390: aload #13
    //   1392: getstatic b/b/j.w0 : I
    //   1395: iconst_m1
    //   1396: invokevirtual e : (II)I
    //   1399: istore #4
    //   1401: aload #13
    //   1403: invokevirtual u : ()V
    //   1406: iload_2
    //   1407: iconst_m1
    //   1408: if_icmpeq -> 1419
    //   1411: aload_0
    //   1412: getfield a : Landroid/widget/TextView;
    //   1415: iload_2
    //   1416: invokestatic h : (Landroid/widget/TextView;I)V
    //   1419: iload_3
    //   1420: iconst_m1
    //   1421: if_icmpeq -> 1432
    //   1424: aload_0
    //   1425: getfield a : Landroid/widget/TextView;
    //   1428: iload_3
    //   1429: invokestatic i : (Landroid/widget/TextView;I)V
    //   1432: iload #4
    //   1434: iconst_m1
    //   1435: if_icmpeq -> 1447
    //   1438: aload_0
    //   1439: getfield a : Landroid/widget/TextView;
    //   1442: iload #4
    //   1444: invokestatic j : (Landroid/widget/TextView;I)V
    //   1447: return
  }
  
  public void n(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!b.r)
      c(); 
  }
  
  public void o() {
    b();
  }
  
  public void p(Context paramContext, int paramInt) {
    g0 g0 = g0.r(paramContext, paramInt, j.M2);
    paramInt = j.X2;
    if (g0.q(paramInt))
      r(g0.a(paramInt, false)); 
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 23) {
      int j = j.Q2;
      if (g0.q(j)) {
        ColorStateList colorStateList = g0.c(j);
        if (colorStateList != null)
          this.a.setTextColor(colorStateList); 
      } 
    } 
    int i = j.N2;
    if (g0.q(i) && g0.e(i, -1) == 0)
      this.a.setTextSize(0, 0.0F); 
    C(paramContext, g0);
    if (paramInt >= 26) {
      paramInt = j.W2;
      if (g0.q(paramInt)) {
        String str = g0.n(paramInt);
        if (str != null)
          this.a.setFontVariationSettings(str); 
      } 
    } 
    g0.u();
    Typeface typeface = this.l;
    if (typeface != null)
      this.a.setTypeface(typeface, this.j); 
  }
  
  public void q(Runnable paramRunnable) {
    this.a.post(paramRunnable);
  }
  
  public void r(boolean paramBoolean) {
    this.a.setAllCaps(paramBoolean);
  }
  
  public void s(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.i.u(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void t(int[] paramArrayOfint, int paramInt) {
    this.i.v(paramArrayOfint, paramInt);
  }
  
  public void u(int paramInt) {
    this.i.w(paramInt);
  }
  
  public void v(ColorStateList paramColorStateList) {
    boolean bool;
    if (this.h == null)
      this.h = new e0(); 
    e0 e01 = this.h;
    e01.a = paramColorStateList;
    if (paramColorStateList != null) {
      bool = true;
    } else {
      bool = false;
    } 
    e01.d = bool;
    y();
  }
  
  public void w(PorterDuff.Mode paramMode) {
    boolean bool;
    if (this.h == null)
      this.h = new e0(); 
    e0 e01 = this.h;
    e01.b = paramMode;
    if (paramMode != null) {
      bool = true;
    } else {
      bool = false;
    } 
    e01.c = bool;
    y();
  }
  
  public final void x(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4, Drawable paramDrawable5, Drawable paramDrawable6) {
    TextView textView;
    Drawable[] arrayOfDrawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 17 && (paramDrawable5 != null || paramDrawable6 != null)) {
      arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      textView = this.a;
      if (paramDrawable5 == null)
        paramDrawable5 = arrayOfDrawable[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable[1]; 
      if (paramDrawable6 == null)
        paramDrawable6 = arrayOfDrawable[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable[3]; 
      textView.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable5, paramDrawable2, paramDrawable6, paramDrawable4);
      return;
    } 
    if (textView != null || paramDrawable2 != null || arrayOfDrawable != null || paramDrawable4 != null) {
      Drawable drawable1;
      Drawable drawable2;
      if (i >= 17) {
        Drawable[] arrayOfDrawable2 = this.a.getCompoundDrawablesRelative();
        if (arrayOfDrawable2[0] != null || arrayOfDrawable2[2] != null) {
          textView = this.a;
          drawable2 = arrayOfDrawable2[0];
          if (paramDrawable2 == null)
            paramDrawable2 = arrayOfDrawable2[1]; 
          paramDrawable6 = arrayOfDrawable2[2];
          if (paramDrawable4 == null)
            paramDrawable4 = arrayOfDrawable2[3]; 
          textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable2, paramDrawable2, paramDrawable6, paramDrawable4);
          return;
        } 
      } 
      Drawable[] arrayOfDrawable1 = this.a.getCompoundDrawables();
      TextView textView1 = this.a;
      if (textView == null)
        drawable1 = arrayOfDrawable1[0]; 
      if (paramDrawable2 == null)
        paramDrawable2 = arrayOfDrawable1[1]; 
      if (drawable2 == null)
        drawable2 = arrayOfDrawable1[2]; 
      if (paramDrawable4 == null)
        paramDrawable4 = arrayOfDrawable1[3]; 
      textView1.setCompoundDrawablesWithIntrinsicBounds(drawable1, paramDrawable2, drawable2, paramDrawable4);
    } 
  }
  
  public final void y() {
    e0 e01 = this.h;
    this.b = e01;
    this.c = e01;
    this.d = e01;
    this.e = e01;
    this.f = e01;
    this.g = e01;
  }
  
  public void z(int paramInt, float paramFloat) {
    if (!b.r && !l())
      A(paramInt, paramFloat); 
  }
  
  public static class a extends f.c {
    public final WeakReference<m> a;
    
    public final int b;
    
    public final int c;
    
    public a(m param1m, int param1Int1, int param1Int2) {
      this.a = new WeakReference<m>(param1m);
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public void d(int param1Int) {}
    
    public void e(Typeface param1Typeface) {
      m m = this.a.get();
      if (m == null)
        return; 
      Typeface typeface = param1Typeface;
      if (Build.VERSION.SDK_INT >= 28) {
        int i = this.b;
        typeface = param1Typeface;
        if (i != -1) {
          boolean bool;
          if ((this.c & 0x2) != 0) {
            bool = true;
          } else {
            bool = false;
          } 
          typeface = Typeface.create(param1Typeface, i, bool);
        } 
      } 
      m.q(new a(this, this.a, typeface));
    }
    
    public class a implements Runnable {
      public final WeakReference<m> a;
      
      public final Typeface b;
      
      public a(m.a this$0, WeakReference<m> param2WeakReference, Typeface param2Typeface) {
        this.a = param2WeakReference;
        this.b = param2Typeface;
      }
      
      public void run() {
        m m = this.a.get();
        if (m == null)
          return; 
        m.B(this.b);
      }
    }
  }
  
  public class a implements Runnable {
    public final WeakReference<m> a;
    
    public final Typeface b;
    
    public a(m this$0, WeakReference<m> param1WeakReference, Typeface param1Typeface) {
      this.a = param1WeakReference;
      this.b = param1Typeface;
    }
    
    public void run() {
      m m = this.a.get();
      if (m == null)
        return; 
      m.B(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */