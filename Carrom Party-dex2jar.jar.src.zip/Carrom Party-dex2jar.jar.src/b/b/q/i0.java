package b.b.q;

import android.os.Build;
import android.view.View;

public class i0 {
  public static void a(View paramView, CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26) {
      paramView.setTooltipText(paramCharSequence);
      return;
    } 
    j0.f(paramView, paramCharSequence);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */