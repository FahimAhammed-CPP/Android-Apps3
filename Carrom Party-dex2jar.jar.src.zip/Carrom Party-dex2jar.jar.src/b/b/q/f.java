package b.b.q;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import b.h.g.l.a;
import b.h.o.c;

public class f {
  public final CompoundButton a;
  
  public ColorStateList b = null;
  
  public PorterDuff.Mode c = null;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public boolean f;
  
  public f(CompoundButton paramCompoundButton) {
    this.a = paramCompoundButton;
  }
  
  public void a() {
    Drawable drawable = c.a(this.a);
    if (drawable != null && (this.d || this.e)) {
      drawable = a.q(drawable).mutate();
      if (this.d)
        a.n(drawable, this.b); 
      if (this.e)
        a.o(drawable, this.c); 
      if (drawable.isStateful())
        drawable.setState(this.a.getDrawableState()); 
      this.a.setButtonDrawable(drawable);
    } 
  }
  
  public int b(int paramInt) {
    int i = paramInt;
    if (Build.VERSION.SDK_INT < 17) {
      Drawable drawable = c.a(this.a);
      i = paramInt;
      if (drawable != null)
        i = paramInt + drawable.getIntrinsicWidth(); 
    } 
    return i;
  }
  
  public ColorStateList c() {
    return this.b;
  }
  
  public PorterDuff.Mode d() {
    return this.c;
  }
  
  public void e(AttributeSet paramAttributeSet, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/widget/CompoundButton;
    //   4: invokevirtual getContext : ()Landroid/content/Context;
    //   7: aload_1
    //   8: getstatic b/b/j.O0 : [I
    //   11: iload_2
    //   12: iconst_0
    //   13: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   16: astore_1
    //   17: getstatic b/b/j.Q0 : I
    //   20: istore_2
    //   21: aload_1
    //   22: iload_2
    //   23: invokevirtual hasValue : (I)Z
    //   26: ifeq -> 62
    //   29: aload_1
    //   30: iload_2
    //   31: iconst_0
    //   32: invokevirtual getResourceId : (II)I
    //   35: istore_2
    //   36: iload_2
    //   37: ifeq -> 62
    //   40: aload_0
    //   41: getfield a : Landroid/widget/CompoundButton;
    //   44: astore_3
    //   45: aload_3
    //   46: aload_3
    //   47: invokevirtual getContext : ()Landroid/content/Context;
    //   50: iload_2
    //   51: invokestatic d : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   54: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   57: iconst_1
    //   58: istore_2
    //   59: goto -> 64
    //   62: iconst_0
    //   63: istore_2
    //   64: iload_2
    //   65: ifne -> 108
    //   68: getstatic b/b/j.P0 : I
    //   71: istore_2
    //   72: aload_1
    //   73: iload_2
    //   74: invokevirtual hasValue : (I)Z
    //   77: ifeq -> 108
    //   80: aload_1
    //   81: iload_2
    //   82: iconst_0
    //   83: invokevirtual getResourceId : (II)I
    //   86: istore_2
    //   87: iload_2
    //   88: ifeq -> 108
    //   91: aload_0
    //   92: getfield a : Landroid/widget/CompoundButton;
    //   95: astore_3
    //   96: aload_3
    //   97: aload_3
    //   98: invokevirtual getContext : ()Landroid/content/Context;
    //   101: iload_2
    //   102: invokestatic d : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   105: invokevirtual setButtonDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   108: getstatic b/b/j.R0 : I
    //   111: istore_2
    //   112: aload_1
    //   113: iload_2
    //   114: invokevirtual hasValue : (I)Z
    //   117: ifeq -> 132
    //   120: aload_0
    //   121: getfield a : Landroid/widget/CompoundButton;
    //   124: aload_1
    //   125: iload_2
    //   126: invokevirtual getColorStateList : (I)Landroid/content/res/ColorStateList;
    //   129: invokestatic b : (Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V
    //   132: getstatic b/b/j.S0 : I
    //   135: istore_2
    //   136: aload_1
    //   137: iload_2
    //   138: invokevirtual hasValue : (I)Z
    //   141: ifeq -> 161
    //   144: aload_0
    //   145: getfield a : Landroid/widget/CompoundButton;
    //   148: aload_1
    //   149: iload_2
    //   150: iconst_m1
    //   151: invokevirtual getInt : (II)I
    //   154: aconst_null
    //   155: invokestatic e : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
    //   158: invokestatic c : (Landroid/widget/CompoundButton;Landroid/graphics/PorterDuff$Mode;)V
    //   161: aload_1
    //   162: invokevirtual recycle : ()V
    //   165: return
    //   166: astore_3
    //   167: aload_1
    //   168: invokevirtual recycle : ()V
    //   171: aload_3
    //   172: athrow
    //   173: astore_3
    //   174: goto -> 62
    // Exception table:
    //   from	to	target	type
    //   17	36	166	finally
    //   40	57	173	android/content/res/Resources$NotFoundException
    //   40	57	166	finally
    //   68	87	166	finally
    //   91	108	166	finally
    //   108	132	166	finally
    //   132	161	166	finally
  }
  
  public void f() {
    if (this.f) {
      this.f = false;
      return;
    } 
    this.f = true;
    a();
  }
  
  public void g(ColorStateList paramColorStateList) {
    this.b = paramColorStateList;
    this.d = true;
    a();
  }
  
  public void h(PorterDuff.Mode paramMode) {
    this.c = paramMode;
    this.e = true;
    a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */