package b.b.q;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

public class f0 extends x {
  public final WeakReference<Context> b;
  
  public f0(Context paramContext, Resources paramResources) {
    super(paramResources);
    this.b = new WeakReference<Context>(paramContext);
  }
  
  public Drawable getDrawable(int paramInt) {
    Drawable drawable = super.getDrawable(paramInt);
    Context context = this.b.get();
    if (drawable != null && context != null)
      w.h().x(context, paramInt, drawable); 
    return drawable;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\f0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */