package b.b.q;

import android.view.MenuItem;
import b.b.p.j.g;

public interface u {
  void c(g paramg, MenuItem paramMenuItem);
  
  void f(g paramg, MenuItem paramMenuItem);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */