package b.b.q;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.transition.Transition;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.ListMenuItemView;
import androidx.appcompat.widget.ListPopupWindow;
import b.b.p.j.f;
import b.b.p.j.g;
import b.b.p.j.i;
import java.lang.reflect.Method;

public class v extends ListPopupWindow implements u {
  public static Method U;
  
  public u T;
  
  static {
    try {
      if (Build.VERSION.SDK_INT <= 28) {
        U = PopupWindow.class.getDeclaredMethod("setTouchModal", new Class[] { boolean.class });
        return;
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
    } 
  }
  
  public v(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
  }
  
  public void M(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      this.P.setEnterTransition((Transition)paramObject); 
  }
  
  public void N(Object paramObject) {
    if (Build.VERSION.SDK_INT >= 23)
      this.P.setExitTransition((Transition)paramObject); 
  }
  
  public void O(u paramu) {
    this.T = paramu;
  }
  
  public void P(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = U;
      if (method != null)
        try {
          method.invoke(this.P, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("MenuPopupWindow", "Could not invoke setTouchModal() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      this.P.setTouchModal(paramBoolean);
    } 
  }
  
  public void c(g paramg, MenuItem paramMenuItem) {
    u u1 = this.T;
    if (u1 != null)
      u1.c(paramg, paramMenuItem); 
  }
  
  public void f(g paramg, MenuItem paramMenuItem) {
    u u1 = this.T;
    if (u1 != null)
      u1.f(paramg, paramMenuItem); 
  }
  
  public r r(Context paramContext, boolean paramBoolean) {
    a a = new a(paramContext, paramBoolean);
    a.setHoverListener(this);
    return a;
  }
  
  public static class a extends r {
    public MenuItem C;
    
    public final int o;
    
    public final int p;
    
    public u q;
    
    public a(Context param1Context, boolean param1Boolean) {
      super(param1Context, param1Boolean);
      Configuration configuration = param1Context.getResources().getConfiguration();
      if (Build.VERSION.SDK_INT >= 17 && 1 == configuration.getLayoutDirection()) {
        this.o = 21;
        this.p = 22;
        return;
      } 
      this.o = 22;
      this.p = 21;
    }
    
    public boolean onHoverEvent(MotionEvent param1MotionEvent) {
      if (this.q != null) {
        int i;
        f f;
        ListAdapter listAdapter = getAdapter();
        if (listAdapter instanceof HeaderViewListAdapter) {
          HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter)listAdapter;
          i = headerViewListAdapter.getHeadersCount();
          f = (f)headerViewListAdapter.getWrappedAdapter();
        } else {
          i = 0;
          f = f;
        } 
        i i2 = null;
        i i1 = i2;
        if (param1MotionEvent.getAction() != 10) {
          int j = pointToPosition((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY());
          i1 = i2;
          if (j != -1) {
            i = j - i;
            i1 = i2;
            if (i >= 0) {
              i1 = i2;
              if (i < f.getCount())
                i1 = f.c(i); 
            } 
          } 
        } 
        MenuItem menuItem = this.C;
        if (menuItem != i1) {
          g g = f.b();
          if (menuItem != null)
            this.q.f(g, menuItem); 
          this.C = (MenuItem)i1;
          if (i1 != null)
            this.q.c(g, (MenuItem)i1); 
        } 
      } 
      return super.onHoverEvent(param1MotionEvent);
    }
    
    public boolean onKeyDown(int param1Int, KeyEvent param1KeyEvent) {
      ListMenuItemView listMenuItemView = (ListMenuItemView)getSelectedView();
      if (listMenuItemView != null && param1Int == this.o) {
        if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu())
          performItemClick((View)listMenuItemView, getSelectedItemPosition(), getSelectedItemId()); 
        return true;
      } 
      if (listMenuItemView != null && param1Int == this.p) {
        setSelection(-1);
        ((f)getAdapter()).b().e(false);
        return true;
      } 
      return super.onKeyDown(param1Int, param1KeyEvent);
    }
    
    public void setHoverListener(u param1u) {
      this.q = param1u;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */