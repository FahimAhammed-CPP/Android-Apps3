package b.b.q;

public interface n0 {
  CharSequence a();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\n0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */