package b.b.q;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;
import b.b.j;
import b.b.l.a.a;
import b.h.o.e;

public class i {
  public final ImageView a;
  
  public e0 b;
  
  public e0 c;
  
  public e0 d;
  
  public i(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  public final boolean a(Drawable paramDrawable) {
    if (this.d == null)
      this.d = new e0(); 
    e0 e01 = this.d;
    e01.a();
    ColorStateList colorStateList = e.a(this.a);
    if (colorStateList != null) {
      e01.d = true;
      e01.a = colorStateList;
    } 
    PorterDuff.Mode mode = e.b(this.a);
    if (mode != null) {
      e01.c = true;
      e01.b = mode;
    } 
    if (e01.d || e01.c) {
      g.i(paramDrawable, e01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  public void b() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      q.b(drawable); 
    if (drawable != null) {
      if (j() && a(drawable))
        return; 
      e0 e01 = this.c;
      if (e01 != null) {
        g.i(drawable, e01, this.a.getDrawableState());
        return;
      } 
      e01 = this.b;
      if (e01 != null)
        g.i(drawable, e01, this.a.getDrawableState()); 
    } 
  }
  
  public ColorStateList c() {
    e0 e01 = this.c;
    return (e01 != null) ? e01.a : null;
  }
  
  public PorterDuff.Mode d() {
    e0 e01 = this.c;
    return (e01 != null) ? e01.b : null;
  }
  
  public boolean e() {
    Drawable drawable = this.a.getBackground();
    return !(Build.VERSION.SDK_INT >= 21 && drawable instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void f(AttributeSet paramAttributeSet, int paramInt) {
    g0 g0 = g0.t(this.a.getContext(), paramAttributeSet, j.P, paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = g0.m(j.Q, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.d(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        q.b(drawable1); 
      paramInt = j.R;
      if (g0.q(paramInt))
        e.c(this.a, g0.c(paramInt)); 
      paramInt = j.S;
      if (g0.q(paramInt))
        e.d(this.a, q.e(g0.j(paramInt, -1), null)); 
      return;
    } finally {
      g0.u();
    } 
  }
  
  public void g(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.d(this.a.getContext(), paramInt);
      if (drawable != null)
        q.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    b();
  }
  
  public void h(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new e0(); 
    e0 e01 = this.c;
    e01.a = paramColorStateList;
    e01.d = true;
    b();
  }
  
  public void i(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new e0(); 
    e0 e01 = this.c;
    e01.b = paramMode;
    e01.c = true;
    b();
  }
  
  public final boolean j() {
    int j = Build.VERSION.SDK_INT;
    return (j > 21) ? ((this.b != null)) : ((j == 21));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */