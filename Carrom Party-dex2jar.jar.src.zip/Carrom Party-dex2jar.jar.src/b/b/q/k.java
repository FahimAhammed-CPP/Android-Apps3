package b.b.q;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import b.b.j;
import b.h.g.l.a;
import b.h.n.r;

public class k extends j {
  public final SeekBar d;
  
  public Drawable e;
  
  public ColorStateList f = null;
  
  public PorterDuff.Mode g = null;
  
  public boolean h = false;
  
  public boolean i = false;
  
  public k(SeekBar paramSeekBar) {
    super((ProgressBar)paramSeekBar);
    this.d = paramSeekBar;
  }
  
  public void c(AttributeSet paramAttributeSet, int paramInt) {
    super.c(paramAttributeSet, paramInt);
    g0 g0 = g0.t(this.d.getContext(), paramAttributeSet, j.T, paramInt, 0);
    Drawable drawable = g0.g(j.U);
    if (drawable != null)
      this.d.setThumb(drawable); 
    j(g0.f(j.V));
    paramInt = j.X;
    if (g0.q(paramInt)) {
      this.g = q.e(g0.j(paramInt, -1), this.g);
      this.i = true;
    } 
    paramInt = j.W;
    if (g0.q(paramInt)) {
      this.f = g0.c(paramInt);
      this.h = true;
    } 
    g0.u();
    f();
  }
  
  public final void f() {
    Drawable drawable = this.e;
    if (drawable != null && (this.h || this.i)) {
      drawable = a.q(drawable.mutate());
      this.e = drawable;
      if (this.h)
        a.n(drawable, this.f); 
      if (this.i)
        a.o(this.e, this.g); 
      if (this.e.isStateful())
        this.e.setState(this.d.getDrawableState()); 
    } 
  }
  
  public void g(Canvas paramCanvas) {
    if (this.e != null) {
      int m = this.d.getMax();
      int i = 1;
      if (m > 1) {
        int n = this.e.getIntrinsicWidth();
        int i1 = this.e.getIntrinsicHeight();
        if (n >= 0) {
          n /= 2;
        } else {
          n = 1;
        } 
        if (i1 >= 0)
          i = i1 / 2; 
        this.e.setBounds(-n, -i, n, i);
        float f = (this.d.getWidth() - this.d.getPaddingLeft() - this.d.getPaddingRight()) / m;
        i = paramCanvas.save();
        paramCanvas.translate(this.d.getPaddingLeft(), (this.d.getHeight() / 2));
        for (n = 0; n <= m; n++) {
          this.e.draw(paramCanvas);
          paramCanvas.translate(f, 0.0F);
        } 
        paramCanvas.restoreToCount(i);
      } 
    } 
  }
  
  public void h() {
    Drawable drawable = this.e;
    if (drawable != null && drawable.isStateful() && drawable.setState(this.d.getDrawableState()))
      this.d.invalidateDrawable(drawable); 
  }
  
  public void i() {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
  }
  
  public void j(Drawable paramDrawable) {
    Drawable drawable = this.e;
    if (drawable != null)
      drawable.setCallback(null); 
    this.e = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this.d);
      a.l(paramDrawable, r.q((View)this.d));
      if (paramDrawable.isStateful())
        paramDrawable.setState(this.d.getDrawableState()); 
      f();
    } 
    this.d.invalidate();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */