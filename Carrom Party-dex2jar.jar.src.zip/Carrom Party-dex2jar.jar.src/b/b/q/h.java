package b.b.q;

import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

public class h {
  public static InputConnection a(InputConnection paramInputConnection, EditorInfo paramEditorInfo, View paramView) {
    if (paramInputConnection != null && paramEditorInfo.hintText == null)
      for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
        if (viewParent instanceof n0) {
          paramEditorInfo.hintText = ((n0)viewParent).a();
          return paramInputConnection;
        } 
      }  
    return paramInputConnection;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */