package b.b.q;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import b.h.m.h;

public final class l {
  public TextView a;
  
  public TextClassifier b;
  
  public l(TextView paramTextView) {
    h.b(paramTextView);
    this.a = paramTextView;
  }
  
  public TextClassifier a() {
    TextClassifier textClassifier2 = this.b;
    TextClassifier textClassifier1 = textClassifier2;
    if (textClassifier2 == null) {
      TextClassificationManager textClassificationManager = (TextClassificationManager)this.a.getContext().getSystemService(TextClassificationManager.class);
      if (textClassificationManager != null)
        return textClassificationManager.getTextClassifier(); 
      textClassifier1 = TextClassifier.NO_OP;
    } 
    return textClassifier1;
  }
  
  public void b(TextClassifier paramTextClassifier) {
    this.b = paramTextClassifier;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */