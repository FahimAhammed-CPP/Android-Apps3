package b.b.q;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Build;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class d0 extends ContextWrapper {
  public static final Object c = new Object();
  
  public static ArrayList<WeakReference<d0>> d;
  
  public final Resources a;
  
  public final Resources.Theme b;
  
  public d0(Context paramContext) {
    super(paramContext);
    if (l0.b()) {
      l0 l0 = new l0((Context)this, paramContext.getResources());
      this.a = l0;
      Resources.Theme theme = l0.newTheme();
      this.b = theme;
      theme.setTo(paramContext.getTheme());
      return;
    } 
    this.a = new f0((Context)this, paramContext.getResources());
    this.b = null;
  }
  
  public static boolean a(Context paramContext) {
    boolean bool1 = paramContext instanceof d0;
    boolean bool = false;
    null = bool;
    if (!bool1) {
      null = bool;
      if (!(paramContext.getResources() instanceof f0)) {
        if (paramContext.getResources() instanceof l0)
          return false; 
        if (Build.VERSION.SDK_INT >= 21) {
          null = bool;
          return l0.b() ? true : null;
        } 
      } else {
        return null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public static Context b(Context paramContext) {
    if (a(paramContext))
      synchronized (c) {
        ArrayList<WeakReference<d0>> arrayList = d;
        if (arrayList == null) {
          d = new ArrayList<WeakReference<d0>>();
        } else {
          for (int i = arrayList.size() - 1;; i--) {
            if (i >= 0) {
              WeakReference weakReference = d.get(i);
              if (weakReference == null || weakReference.get() == null)
                d.remove(i); 
            } else {
              for (i = d.size() - 1;; i--) {
                if (i >= 0) {
                  WeakReference<d0> weakReference = d.get(i);
                  if (weakReference != null) {
                    d0 d02 = weakReference.get();
                  } else {
                    weakReference = null;
                  } 
                  if (weakReference != null && weakReference.getBaseContext() == paramContext)
                    return (Context)weakReference; 
                } else {
                  d01 = new d0(paramContext);
                  d.add(new WeakReference<d0>(d01));
                  return (Context)d01;
                } 
              } 
            } 
          } 
          i--;
        } 
        d0 d01 = new d0((Context)d01);
        d.add(new WeakReference<d0>(d01));
        return (Context)d01;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.a.getAssets();
  }
  
  public Resources getResources() {
    return this.a;
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme2 = this.b;
    Resources.Theme theme1 = theme2;
    if (theme2 == null)
      theme1 = super.getTheme(); 
    return theme1;
  }
  
  public void setTheme(int paramInt) {
    Resources.Theme theme = this.b;
    if (theme == null) {
      super.setTheme(paramInt);
      return;
    } 
    theme.applyStyle(paramInt, true);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */