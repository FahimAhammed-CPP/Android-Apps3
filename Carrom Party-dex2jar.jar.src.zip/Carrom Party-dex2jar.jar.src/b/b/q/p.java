package b.b.q;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import b.b.p.j.m;
import b.h.n.v;

public interface p {
  void a(Menu paramMenu, m.a parama);
  
  boolean b();
  
  void c();
  
  void collapseActionView();
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  Context getContext();
  
  CharSequence getTitle();
  
  void h();
  
  void i(z paramz);
  
  boolean j();
  
  void k(int paramInt);
  
  void l(int paramInt);
  
  int m();
  
  v n(int paramInt, long paramLong);
  
  void o(int paramInt);
  
  ViewGroup p();
  
  void q(boolean paramBoolean);
  
  int r();
  
  void s();
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
  
  void t();
  
  void u(boolean paramBoolean);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */