package b.b.q;

import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import b.h.n.r;
import b.h.n.s;

public class j0 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  public static j0 j;
  
  public static j0 k;
  
  public final View a;
  
  public final CharSequence b;
  
  public final int c;
  
  public final Runnable d = new a(this);
  
  public final Runnable e = new b(this);
  
  public int f;
  
  public int g;
  
  public k0 h;
  
  public boolean i;
  
  public j0(View paramView, CharSequence paramCharSequence) {
    this.a = paramView;
    this.b = paramCharSequence;
    this.c = s.a(ViewConfiguration.get(paramView.getContext()));
    b();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  public static void e(j0 paramj0) {
    j0 j01 = j;
    if (j01 != null)
      j01.a(); 
    j = paramj0;
    if (paramj0 != null)
      paramj0.d(); 
  }
  
  public static void f(View paramView, CharSequence paramCharSequence) {
    j0 j01;
    j0 j02 = j;
    if (j02 != null && j02.a == paramView)
      e(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      j01 = k;
      if (j01 != null && j01.a == paramView)
        j01.c(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new j0(paramView, (CharSequence)j01);
  }
  
  public final void a() {
    this.a.removeCallbacks(this.d);
  }
  
  public final void b() {
    this.f = Integer.MAX_VALUE;
    this.g = Integer.MAX_VALUE;
  }
  
  public void c() {
    if (k == this) {
      k = null;
      k0 k01 = this.h;
      if (k01 != null) {
        k01.c();
        this.h = null;
        b();
        this.a.removeOnAttachStateChangeListener(this);
      } else {
        Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
      } 
    } 
    if (j == this)
      e(null); 
    this.a.removeCallbacks(this.e);
  }
  
  public final void d() {
    this.a.postDelayed(this.d, ViewConfiguration.getLongPressTimeout());
  }
  
  public void g(boolean paramBoolean) {
    long l;
    if (!r.A(this.a))
      return; 
    e(null);
    j0 j01 = k;
    if (j01 != null)
      j01.c(); 
    k = this;
    this.i = paramBoolean;
    k0 k01 = new k0(this.a.getContext());
    this.h = k01;
    k01.e(this.a, this.f, this.g, this.i, this.b);
    this.a.addOnAttachStateChangeListener(this);
    if (this.i) {
      l = 2500L;
    } else {
      int i;
      if ((r.w(this.a) & 0x1) == 1) {
        l = 3000L;
        i = ViewConfiguration.getLongPressTimeout();
      } else {
        l = 15000L;
        i = ViewConfiguration.getLongPressTimeout();
      } 
      l -= i;
    } 
    this.a.removeCallbacks(this.e);
    this.a.postDelayed(this.e, l);
  }
  
  public final boolean h(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (Math.abs(i - this.f) <= this.c && Math.abs(j - this.g) <= this.c)
      return false; 
    this.f = i;
    this.g = j;
    return true;
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.h != null && this.i)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.a.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      b();
      c();
      return false;
    } 
    if (this.a.isEnabled() && this.h == null && h(paramMotionEvent))
      e(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.f = paramView.getWidth() / 2;
    this.g = paramView.getHeight() / 2;
    g(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    c();
  }
  
  public class a implements Runnable {
    public a(j0 this$0) {}
    
    public void run() {
      this.a.g(false);
    }
  }
  
  public class b implements Runnable {
    public b(j0 this$0) {}
    
    public void run() {
      this.a.c();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\j0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */