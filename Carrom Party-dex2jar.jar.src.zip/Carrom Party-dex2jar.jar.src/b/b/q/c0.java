package b.b.q;

import android.content.res.Resources;
import android.widget.SpinnerAdapter;

public interface c0 extends SpinnerAdapter {
  Resources.Theme getDropDownViewTheme();
  
  void setDropDownViewTheme(Resources.Theme paramTheme);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\c0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */