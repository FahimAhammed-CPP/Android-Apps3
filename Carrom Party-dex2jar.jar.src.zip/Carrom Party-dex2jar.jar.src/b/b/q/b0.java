package b.b.q;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.TypedValue;
import b.h.g.a;

public class b0 {
  public static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static final int[] b = new int[] { -16842910 };
  
  public static final int[] c = new int[] { 16842908 };
  
  public static final int[] d = new int[] { 16842919 };
  
  public static final int[] e = new int[] { 16842912 };
  
  public static final int[] f = new int[0];
  
  public static final int[] g = new int[1];
  
  public static int a(Context paramContext, int paramInt) {
    ColorStateList colorStateList = d(paramContext, paramInt);
    if (colorStateList != null && colorStateList.isStateful())
      return colorStateList.getColorForState(b, colorStateList.getDefaultColor()); 
    TypedValue typedValue = e();
    paramContext.getTheme().resolveAttribute(16842803, typedValue, true);
    return c(paramContext, paramInt, typedValue.getFloat());
  }
  
  public static int b(Context paramContext, int paramInt) {
    null = g;
    null[0] = paramInt;
    g0 g0 = g0.s(paramContext, null, null);
    try {
      paramInt = g0.b(0, 0);
      return paramInt;
    } finally {
      g0.u();
    } 
  }
  
  public static int c(Context paramContext, int paramInt, float paramFloat) {
    paramInt = b(paramContext, paramInt);
    return a.d(paramInt, Math.round(Color.alpha(paramInt) * paramFloat));
  }
  
  public static ColorStateList d(Context paramContext, int paramInt) {
    null = g;
    null[0] = paramInt;
    g0 g0 = g0.s(paramContext, null, null);
    try {
      return g0.c(0);
    } finally {
      g0.u();
    } 
  }
  
  public static TypedValue e() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */