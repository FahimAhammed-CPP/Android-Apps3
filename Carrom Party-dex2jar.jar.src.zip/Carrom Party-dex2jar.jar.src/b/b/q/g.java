package b.b.q;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import b.b.c;
import b.b.e;

public final class g {
  public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;
  
  public static g c;
  
  public w a;
  
  public static g b() {
    // Byte code:
    //   0: ldc b/b/q/g
    //   2: monitorenter
    //   3: getstatic b/b/q/g.c : Lb/b/q/g;
    //   6: ifnonnull -> 12
    //   9: invokestatic h : ()V
    //   12: getstatic b/b/q/g.c : Lb/b/q/g;
    //   15: astore_0
    //   16: ldc b/b/q/g
    //   18: monitorexit
    //   19: aload_0
    //   20: areturn
    //   21: astore_0
    //   22: ldc b/b/q/g
    //   24: monitorexit
    //   25: aload_0
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   3	12	21	finally
    //   12	16	21	finally
  }
  
  public static PorterDuffColorFilter e(int paramInt, PorterDuff.Mode paramMode) {
    // Byte code:
    //   0: ldc b/b/q/g
    //   2: monitorenter
    //   3: iload_0
    //   4: aload_1
    //   5: invokestatic l : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    //   8: astore_1
    //   9: ldc b/b/q/g
    //   11: monitorexit
    //   12: aload_1
    //   13: areturn
    //   14: astore_1
    //   15: ldc b/b/q/g
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	9	14	finally
  }
  
  public static void h() {
    // Byte code:
    //   0: ldc b/b/q/g
    //   2: monitorenter
    //   3: getstatic b/b/q/g.c : Lb/b/q/g;
    //   6: ifnonnull -> 44
    //   9: new b/b/q/g
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore_0
    //   17: aload_0
    //   18: putstatic b/b/q/g.c : Lb/b/q/g;
    //   21: aload_0
    //   22: invokestatic h : ()Lb/b/q/w;
    //   25: putfield a : Lb/b/q/w;
    //   28: getstatic b/b/q/g.c : Lb/b/q/g;
    //   31: getfield a : Lb/b/q/w;
    //   34: new b/b/q/g$a
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: invokevirtual u : (Lb/b/q/w$e;)V
    //   44: ldc b/b/q/g
    //   46: monitorexit
    //   47: return
    //   48: astore_0
    //   49: ldc b/b/q/g
    //   51: monitorexit
    //   52: aload_0
    //   53: athrow
    // Exception table:
    //   from	to	target	type
    //   3	44	48	finally
  }
  
  public static void i(Drawable paramDrawable, e0 parame0, int[] paramArrayOfint) {
    w.w(paramDrawable, parame0, paramArrayOfint);
  }
  
  public Drawable c(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Lb/b/q/w;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual j : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public Drawable d(Context paramContext, int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Lb/b/q/w;
    //   6: aload_1
    //   7: iload_2
    //   8: iload_3
    //   9: invokevirtual k : (Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  public ColorStateList f(Context paramContext, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Lb/b/q/w;
    //   6: aload_1
    //   7: iload_2
    //   8: invokevirtual m : (Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public void g(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Lb/b/q/w;
    //   6: aload_1
    //   7: invokevirtual s : (Landroid/content/Context;)V
    //   10: aload_0
    //   11: monitorexit
    //   12: return
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	13	finally
  }
  
  public static final class a implements w.e {
    public final int[] a = new int[] { e.S, e.Q, e.a };
    
    public final int[] b = new int[] { e.o, e.B, e.t, e.p, e.q, e.s, e.r };
    
    public final int[] c = new int[] { e.P, e.R, e.k, e.I, e.J, e.L, e.N, e.K, e.M, e.O };
    
    public final int[] d = new int[] { e.w, e.i, e.v };
    
    public final int[] e = new int[] { e.H, e.T };
    
    public final int[] f = new int[] { e.c, e.g, e.d, e.h };
    
    public boolean a(Context param1Context, int param1Int, Drawable param1Drawable) {
      // Byte code:
      //   0: invokestatic a : ()Landroid/graphics/PorterDuff$Mode;
      //   3: astore #7
      //   5: aload_0
      //   6: aload_0
      //   7: getfield a : [I
      //   10: iload_2
      //   11: invokevirtual f : ([II)Z
      //   14: istore #6
      //   16: ldc 16842801
      //   18: istore #4
      //   20: iload #6
      //   22: ifeq -> 38
      //   25: getstatic b/b/a.w : I
      //   28: istore_2
      //   29: iconst_m1
      //   30: istore #4
      //   32: iconst_1
      //   33: istore #5
      //   35: goto -> 121
      //   38: aload_0
      //   39: aload_0
      //   40: getfield c : [I
      //   43: iload_2
      //   44: invokevirtual f : ([II)Z
      //   47: ifeq -> 57
      //   50: getstatic b/b/a.u : I
      //   53: istore_2
      //   54: goto -> 29
      //   57: aload_0
      //   58: aload_0
      //   59: getfield d : [I
      //   62: iload_2
      //   63: invokevirtual f : ([II)Z
      //   66: ifeq -> 80
      //   69: getstatic android/graphics/PorterDuff$Mode.MULTIPLY : Landroid/graphics/PorterDuff$Mode;
      //   72: astore #7
      //   74: iload #4
      //   76: istore_2
      //   77: goto -> 29
      //   80: iload_2
      //   81: getstatic b/b/e.u : I
      //   84: if_icmpne -> 100
      //   87: ldc 16842800
      //   89: istore_2
      //   90: ldc 40.8
      //   92: invokestatic round : (F)I
      //   95: istore #4
      //   97: goto -> 32
      //   100: iload_2
      //   101: getstatic b/b/e.l : I
      //   104: if_icmpne -> 113
      //   107: iload #4
      //   109: istore_2
      //   110: goto -> 29
      //   113: iconst_m1
      //   114: istore #4
      //   116: iconst_0
      //   117: istore #5
      //   119: iconst_0
      //   120: istore_2
      //   121: iload #5
      //   123: ifeq -> 172
      //   126: aload_3
      //   127: astore #8
      //   129: aload_3
      //   130: invokestatic a : (Landroid/graphics/drawable/Drawable;)Z
      //   133: ifeq -> 142
      //   136: aload_3
      //   137: invokevirtual mutate : ()Landroid/graphics/drawable/Drawable;
      //   140: astore #8
      //   142: aload #8
      //   144: aload_1
      //   145: iload_2
      //   146: invokestatic b : (Landroid/content/Context;I)I
      //   149: aload #7
      //   151: invokestatic e : (ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
      //   154: invokevirtual setColorFilter : (Landroid/graphics/ColorFilter;)V
      //   157: iload #4
      //   159: iconst_m1
      //   160: if_icmpeq -> 170
      //   163: aload #8
      //   165: iload #4
      //   167: invokevirtual setAlpha : (I)V
      //   170: iconst_1
      //   171: ireturn
      //   172: iconst_0
      //   173: ireturn
    }
    
    public PorterDuff.Mode b(int param1Int) {
      return (param1Int == e.F) ? PorterDuff.Mode.MULTIPLY : null;
    }
    
    public Drawable c(w param1w, Context param1Context, int param1Int) {
      return (Drawable)((param1Int == e.j) ? new LayerDrawable(new Drawable[] { param1w.j(param1Context, e.i), param1w.j(param1Context, e.k) }) : null);
    }
    
    public ColorStateList d(Context param1Context, int param1Int) {
      return (param1Int == e.m) ? b.b.l.a.a.c(param1Context, c.d) : ((param1Int == e.G) ? b.b.l.a.a.c(param1Context, c.g) : ((param1Int == e.F) ? k(param1Context) : ((param1Int == e.f) ? j(param1Context) : ((param1Int == e.b) ? g(param1Context) : ((param1Int == e.e) ? i(param1Context) : ((param1Int == e.D || param1Int == e.E) ? b.b.l.a.a.c(param1Context, c.f) : (f(this.b, param1Int) ? b0.d(param1Context, b.b.a.w) : (f(this.e, param1Int) ? b.b.l.a.a.c(param1Context, c.c) : (f(this.f, param1Int) ? b.b.l.a.a.c(param1Context, c.b) : ((param1Int == e.A) ? b.b.l.a.a.c(param1Context, c.e) : null))))))))));
    }
    
    public boolean e(Context param1Context, int param1Int, Drawable param1Drawable) {
      LayerDrawable layerDrawable;
      if (param1Int == e.C) {
        layerDrawable = (LayerDrawable)param1Drawable;
        Drawable drawable = layerDrawable.findDrawableByLayerId(16908288);
        param1Int = b.b.a.w;
        l(drawable, b0.b(param1Context, param1Int), g.a());
        l(layerDrawable.findDrawableByLayerId(16908303), b0.b(param1Context, param1Int), g.a());
        l(layerDrawable.findDrawableByLayerId(16908301), b0.b(param1Context, b.b.a.u), g.a());
        return true;
      } 
      if (param1Int == e.y || param1Int == e.x || param1Int == e.z) {
        layerDrawable = layerDrawable;
        l(layerDrawable.findDrawableByLayerId(16908288), b0.a(param1Context, b.b.a.w), g.a());
        Drawable drawable = layerDrawable.findDrawableByLayerId(16908303);
        param1Int = b.b.a.u;
        l(drawable, b0.b(param1Context, param1Int), g.a());
        l(layerDrawable.findDrawableByLayerId(16908301), b0.b(param1Context, param1Int), g.a());
        return true;
      } 
      return false;
    }
    
    public final boolean f(int[] param1ArrayOfint, int param1Int) {
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++) {
        if (param1ArrayOfint[i] == param1Int)
          return true; 
      } 
      return false;
    }
    
    public final ColorStateList g(Context param1Context) {
      return h(param1Context, 0);
    }
    
    public final ColorStateList h(Context param1Context, int param1Int) {
      int k = b0.b(param1Context, b.b.a.v);
      int i = b0.a(param1Context, b.b.a.t);
      int[] arrayOfInt1 = b0.b;
      int[] arrayOfInt2 = b0.d;
      int j = b.h.g.a.b(k, param1Int);
      int[] arrayOfInt3 = b0.c;
      k = b.h.g.a.b(k, param1Int);
      return new ColorStateList(new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, b0.f }, new int[] { i, j, k, param1Int });
    }
    
    public final ColorStateList i(Context param1Context) {
      return h(param1Context, b0.b(param1Context, b.b.a.s));
    }
    
    public final ColorStateList j(Context param1Context) {
      return h(param1Context, b0.b(param1Context, b.b.a.t));
    }
    
    public final ColorStateList k(Context param1Context) {
      int[][] arrayOfInt = new int[3][];
      int[] arrayOfInt1 = new int[3];
      int i = b.b.a.x;
      ColorStateList colorStateList = b0.d(param1Context, i);
      if (colorStateList != null && colorStateList.isStateful()) {
        arrayOfInt[0] = b0.b;
        arrayOfInt1[0] = colorStateList.getColorForState(arrayOfInt[0], 0);
        arrayOfInt[1] = b0.e;
        arrayOfInt1[1] = b0.b(param1Context, b.b.a.u);
        arrayOfInt[2] = b0.f;
        arrayOfInt1[2] = colorStateList.getDefaultColor();
      } else {
        arrayOfInt[0] = b0.b;
        arrayOfInt1[0] = b0.a(param1Context, i);
        arrayOfInt[1] = b0.e;
        arrayOfInt1[1] = b0.b(param1Context, b.b.a.u);
        arrayOfInt[2] = b0.f;
        arrayOfInt1[2] = b0.b(param1Context, i);
      } 
      return new ColorStateList(arrayOfInt, arrayOfInt1);
    }
    
    public final void l(Drawable param1Drawable, int param1Int, PorterDuff.Mode param1Mode) {
      Drawable drawable = param1Drawable;
      if (q.a(param1Drawable))
        drawable = param1Drawable.mutate(); 
      PorterDuff.Mode mode = param1Mode;
      if (param1Mode == null)
        mode = g.a(); 
      drawable.setColorFilter((ColorFilter)g.e(param1Int, mode));
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */