package b.b.q;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public class e0 {
  public ColorStateList a;
  
  public PorterDuff.Mode b;
  
  public boolean c;
  
  public boolean d;
  
  public void a() {
    this.a = null;
    this.d = false;
    this.b = null;
    this.c = false;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */