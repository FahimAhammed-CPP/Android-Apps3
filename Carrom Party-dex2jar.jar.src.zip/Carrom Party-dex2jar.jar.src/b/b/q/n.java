package b.b.q;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;
import b.b.j;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

public class n {
  public static final RectF k = new RectF();
  
  public static ConcurrentHashMap<String, Method> l = new ConcurrentHashMap<String, Method>();
  
  public static ConcurrentHashMap<String, Field> m = new ConcurrentHashMap<String, Field>();
  
  public int a = 0;
  
  public boolean b = false;
  
  public float c = -1.0F;
  
  public float d = -1.0F;
  
  public float e = -1.0F;
  
  public int[] f = new int[0];
  
  public boolean g = false;
  
  public TextPaint h;
  
  public final TextView i;
  
  public final Context j;
  
  public n(TextView paramTextView) {
    this.i = paramTextView;
    this.j = paramTextView.getContext();
  }
  
  public static <T> T a(Object paramObject, String paramString, T paramT) {
    try {
      Field field = o(paramString);
      return (T)((field == null) ? (Object)paramT : field.get(paramObject));
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to access TextView#");
      stringBuilder.append(paramString);
      stringBuilder.append(" member");
      Log.w("ACTVAutoSizeHelper", stringBuilder.toString(), illegalAccessException);
      return paramT;
    } 
  }
  
  public static Field o(String paramString) {
    try {
      Field field2 = m.get(paramString);
      Field field1 = field2;
      if (field2 == null) {
        field2 = TextView.class.getDeclaredField(paramString);
        field1 = field2;
        if (field2 != null) {
          field2.setAccessible(true);
          m.put(paramString, field2);
          field1 = field2;
        } 
      } 
      return field1;
    } catch (NoSuchFieldException noSuchFieldException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to access TextView#");
      stringBuilder.append(paramString);
      stringBuilder.append(" member");
      Log.w("ACTVAutoSizeHelper", stringBuilder.toString(), noSuchFieldException);
      return null;
    } 
  }
  
  public static Method p(String paramString) {
    try {
      Method method2 = l.get(paramString);
      Method method1 = method2;
      if (method2 == null) {
        method2 = TextView.class.getDeclaredMethod(paramString, new Class[0]);
        method1 = method2;
        if (method2 != null) {
          method2.setAccessible(true);
          l.put(paramString, method2);
          method1 = method2;
        } 
      } 
      return method1;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to retrieve TextView#");
      stringBuilder.append(paramString);
      stringBuilder.append("() method");
      Log.w("ACTVAutoSizeHelper", stringBuilder.toString(), exception);
      return null;
    } 
  }
  
  public static <T> T r(Object paramObject, String paramString, T paramT) {
    try {
      return (T)p(paramString).invoke(paramObject, new Object[0]);
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to invoke TextView#");
      stringBuilder.append(paramString);
      stringBuilder.append("() method");
      Log.w("ACTVAutoSizeHelper", stringBuilder.toString(), exception);
      return paramT;
    } finally {}
    throw paramObject;
  }
  
  public final void A(TypedArray paramTypedArray) {
    int i = paramTypedArray.length();
    int[] arrayOfInt = new int[i];
    if (i > 0) {
      for (int j = 0; j < i; j++)
        arrayOfInt[j] = paramTypedArray.getDimensionPixelSize(j, -1); 
      this.f = c(arrayOfInt);
      B();
    } 
  }
  
  public final boolean B() {
    boolean bool;
    int[] arrayOfInt = this.f;
    int i = arrayOfInt.length;
    if (i > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.g = bool;
    if (bool) {
      this.a = 1;
      this.d = arrayOfInt[0];
      this.e = arrayOfInt[i - 1];
      this.c = -1.0F;
    } 
    return bool;
  }
  
  public final boolean C(int paramInt, RectF paramRectF) {
    byte b;
    CharSequence charSequence2 = this.i.getText();
    TransformationMethod transformationMethod = this.i.getTransformationMethod();
    CharSequence charSequence1 = charSequence2;
    if (transformationMethod != null) {
      CharSequence charSequence = transformationMethod.getTransformation(charSequence2, (View)this.i);
      charSequence1 = charSequence2;
      if (charSequence != null)
        charSequence1 = charSequence; 
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      b = this.i.getMaxLines();
    } else {
      b = -1;
    } 
    q(paramInt);
    StaticLayout staticLayout = e(charSequence1, r(this.i, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL), Math.round(paramRectF.right), b);
    return (b != -1 && (staticLayout.getLineCount() > b || staticLayout.getLineEnd(staticLayout.getLineCount() - 1) != charSequence1.length())) ? false : (!(staticLayout.getHeight() > paramRectF.bottom));
  }
  
  public final boolean D() {
    return this.i instanceof androidx.appcompat.widget.AppCompatEditText ^ true;
  }
  
  public final void E(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat1 > 0.0F) {
      if (paramFloat2 > paramFloat1) {
        if (paramFloat3 > 0.0F) {
          this.a = 1;
          this.d = paramFloat1;
          this.e = paramFloat2;
          this.c = paramFloat3;
          this.g = false;
          return;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("The auto-size step granularity (");
        stringBuilder2.append(paramFloat3);
        stringBuilder2.append("px) is less or equal to (0px)");
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Maximum auto-size text size (");
      stringBuilder1.append(paramFloat2);
      stringBuilder1.append("px) is less or equal to minimum auto-size text size (");
      stringBuilder1.append(paramFloat1);
      stringBuilder1.append("px)");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Minimum auto-size text size (");
    stringBuilder.append(paramFloat1);
    stringBuilder.append("px) is less or equal to (0px)");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void b() {
    if (!s())
      return; 
    if (this.b)
      if (this.i.getMeasuredHeight() > 0) {
        int i;
        boolean bool;
        if (this.i.getMeasuredWidth() <= 0)
          return; 
        if (Build.VERSION.SDK_INT >= 29) {
          bool = this.i.isHorizontallyScrollable();
        } else {
          bool = ((Boolean)r(this.i, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
        } 
        if (bool) {
          i = 1048576;
        } else {
          i = this.i.getMeasuredWidth() - this.i.getTotalPaddingLeft() - this.i.getTotalPaddingRight();
        } 
        int j = this.i.getHeight() - this.i.getCompoundPaddingBottom() - this.i.getCompoundPaddingTop();
        if (i > 0) {
          if (j <= 0)
            return; 
          synchronized (k) {
            null.setEmpty();
            null.right = i;
            null.bottom = j;
            float f = i(null);
            if (f != this.i.getTextSize())
              y(0, f); 
          } 
        } else {
          return;
        } 
      } else {
        return;
      }  
    this.b = true;
  }
  
  public final int[] c(int[] paramArrayOfint) {
    int j = paramArrayOfint.length;
    if (j == 0)
      return paramArrayOfint; 
    Arrays.sort(paramArrayOfint);
    ArrayList<? extends Comparable<? super Integer>> arrayList = new ArrayList();
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++) {
      int k = paramArrayOfint[i];
      if (k > 0 && Collections.binarySearch(arrayList, Integer.valueOf(k)) < 0)
        arrayList.add(Integer.valueOf(k)); 
    } 
    if (j == arrayList.size())
      return paramArrayOfint; 
    j = arrayList.size();
    paramArrayOfint = new int[j];
    for (i = bool; i < j; i++)
      paramArrayOfint[i] = ((Integer)arrayList.get(i)).intValue(); 
    return paramArrayOfint;
  }
  
  public final void d() {
    this.a = 0;
    this.d = -1.0F;
    this.e = -1.0F;
    this.c = -1.0F;
    this.f = new int[0];
    this.b = false;
  }
  
  public StaticLayout e(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt1, int paramInt2) {
    int i = Build.VERSION.SDK_INT;
    return (i >= 23) ? f(paramCharSequence, paramAlignment, paramInt1, paramInt2) : ((i >= 16) ? h(paramCharSequence, paramAlignment, paramInt1) : g(paramCharSequence, paramAlignment, paramInt1));
  }
  
  public final StaticLayout f(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt1, int paramInt2) {
    StaticLayout.Builder builder2 = StaticLayout.Builder.obtain(paramCharSequence, 0, paramCharSequence.length(), this.h, paramInt1);
    StaticLayout.Builder builder1 = builder2.setAlignment(paramAlignment).setLineSpacing(this.i.getLineSpacingExtra(), this.i.getLineSpacingMultiplier()).setIncludePad(this.i.getIncludeFontPadding()).setBreakStrategy(this.i.getBreakStrategy()).setHyphenationFrequency(this.i.getHyphenationFrequency());
    paramInt1 = paramInt2;
    if (paramInt2 == -1)
      paramInt1 = Integer.MAX_VALUE; 
    builder1.setMaxLines(paramInt1);
    try {
      TextDirectionHeuristic textDirectionHeuristic;
      if (Build.VERSION.SDK_INT >= 29) {
        textDirectionHeuristic = this.i.getTextDirectionHeuristic();
      } else {
        textDirectionHeuristic = r(this.i, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR);
      } 
      builder2.setTextDirection(textDirectionHeuristic);
    } catch (ClassCastException classCastException) {
      Log.w("ACTVAutoSizeHelper", "Failed to obtain TextDirectionHeuristic, auto size may be incorrect");
    } 
    return builder2.build();
  }
  
  public final StaticLayout g(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt) {
    float f1 = ((Float)a(this.i, "mSpacingMult", Float.valueOf(1.0F))).floatValue();
    float f2 = ((Float)a(this.i, "mSpacingAdd", Float.valueOf(0.0F))).floatValue();
    boolean bool = ((Boolean)a(this.i, "mIncludePad", Boolean.TRUE)).booleanValue();
    return new StaticLayout(paramCharSequence, this.h, paramInt, paramAlignment, f1, f2, bool);
  }
  
  public final StaticLayout h(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt) {
    float f1 = this.i.getLineSpacingMultiplier();
    float f2 = this.i.getLineSpacingExtra();
    boolean bool = this.i.getIncludeFontPadding();
    return new StaticLayout(paramCharSequence, this.h, paramInt, paramAlignment, f1, f2, bool);
  }
  
  public final int i(RectF paramRectF) {
    int i = this.f.length;
    if (i != 0) {
      int k = i - 1;
      i = 1;
      int j = 0;
      while (i <= k) {
        int m = (i + k) / 2;
        if (C(this.f[m], paramRectF)) {
          j = i;
          i = m + 1;
          continue;
        } 
        j = m - 1;
        k = j;
      } 
      return this.f[j];
    } 
    IllegalStateException illegalStateException = new IllegalStateException("No available text sizes to choose from.");
    throw illegalStateException;
  }
  
  public int j() {
    return Math.round(this.e);
  }
  
  public int k() {
    return Math.round(this.d);
  }
  
  public int l() {
    return Math.round(this.c);
  }
  
  public int[] m() {
    return this.f;
  }
  
  public int n() {
    return this.a;
  }
  
  public void q(int paramInt) {
    TextPaint textPaint = this.h;
    if (textPaint == null) {
      this.h = new TextPaint();
    } else {
      textPaint.reset();
    } 
    this.h.set(this.i.getPaint());
    this.h.setTextSize(paramInt);
  }
  
  public boolean s() {
    return (D() && this.a != 0);
  }
  
  public void t(AttributeSet paramAttributeSet, int paramInt) {
    float f1;
    float f2;
    float f3;
    TypedArray typedArray = this.j.obtainStyledAttributes(paramAttributeSet, j.g0, paramInt, 0);
    paramInt = j.l0;
    if (typedArray.hasValue(paramInt))
      this.a = typedArray.getInt(paramInt, 0); 
    paramInt = j.k0;
    if (typedArray.hasValue(paramInt)) {
      f1 = typedArray.getDimension(paramInt, -1.0F);
    } else {
      f1 = -1.0F;
    } 
    paramInt = j.i0;
    if (typedArray.hasValue(paramInt)) {
      f2 = typedArray.getDimension(paramInt, -1.0F);
    } else {
      f2 = -1.0F;
    } 
    paramInt = j.h0;
    if (typedArray.hasValue(paramInt)) {
      f3 = typedArray.getDimension(paramInt, -1.0F);
    } else {
      f3 = -1.0F;
    } 
    paramInt = j.j0;
    if (typedArray.hasValue(paramInt)) {
      paramInt = typedArray.getResourceId(paramInt, 0);
      if (paramInt > 0) {
        TypedArray typedArray1 = typedArray.getResources().obtainTypedArray(paramInt);
        A(typedArray1);
        typedArray1.recycle();
      } 
    } 
    typedArray.recycle();
    if (D()) {
      if (this.a == 1) {
        if (!this.g) {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          float f = f2;
          if (f2 == -1.0F)
            f = TypedValue.applyDimension(2, 12.0F, displayMetrics); 
          f2 = f3;
          if (f3 == -1.0F)
            f2 = TypedValue.applyDimension(2, 112.0F, displayMetrics); 
          f3 = f1;
          if (f1 == -1.0F)
            f3 = 1.0F; 
          E(f, f2, f3);
        } 
        z();
        return;
      } 
    } else {
      this.a = 0;
    } 
  }
  
  public void u(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (D()) {
      DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
      E(TypedValue.applyDimension(paramInt4, paramInt1, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt2, displayMetrics), TypedValue.applyDimension(paramInt4, paramInt3, displayMetrics));
      if (z())
        b(); 
    } 
  }
  
  public void v(int[] paramArrayOfint, int paramInt) {
    if (D()) {
      int j = paramArrayOfint.length;
      int i = 0;
      if (j > 0) {
        int[] arrayOfInt1;
        int[] arrayOfInt2 = new int[j];
        if (paramInt == 0) {
          arrayOfInt1 = Arrays.copyOf(paramArrayOfint, j);
        } else {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          while (true) {
            arrayOfInt1 = arrayOfInt2;
            if (i < j) {
              arrayOfInt2[i] = Math.round(TypedValue.applyDimension(paramInt, paramArrayOfint[i], displayMetrics));
              i++;
              continue;
            } 
            break;
          } 
        } 
        this.f = c(arrayOfInt1);
        if (!B()) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("None of the preset sizes is valid: ");
          stringBuilder.append(Arrays.toString(paramArrayOfint));
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        this.g = false;
      } 
      if (z())
        b(); 
    } 
  }
  
  public void w(int paramInt) {
    if (D())
      if (paramInt != 0) {
        if (paramInt == 1) {
          DisplayMetrics displayMetrics = this.j.getResources().getDisplayMetrics();
          E(TypedValue.applyDimension(2, 12.0F, displayMetrics), TypedValue.applyDimension(2, 112.0F, displayMetrics), 1.0F);
          if (z()) {
            b();
            return;
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown auto-size text type: ");
          stringBuilder.append(paramInt);
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
      } else {
        d();
      }  
  }
  
  public final void x(float paramFloat) {
    if (paramFloat != this.i.getPaint().getTextSize()) {
      boolean bool;
      this.i.getPaint().setTextSize(paramFloat);
      if (Build.VERSION.SDK_INT >= 18) {
        bool = this.i.isInLayout();
      } else {
        bool = false;
      } 
      if (this.i.getLayout() != null) {
        this.b = false;
        try {
          Method method = p("nullLayouts");
          if (method != null)
            method.invoke(this.i, new Object[0]); 
        } catch (Exception exception) {
          Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", exception);
        } 
        if (!bool) {
          this.i.requestLayout();
        } else {
          this.i.forceLayout();
        } 
        this.i.invalidate();
      } 
    } 
  }
  
  public void y(int paramInt, float paramFloat) {
    Resources resources;
    Context context = this.j;
    if (context == null) {
      resources = Resources.getSystem();
    } else {
      resources = resources.getResources();
    } 
    x(TypedValue.applyDimension(paramInt, paramFloat, resources.getDisplayMetrics()));
  }
  
  public final boolean z() {
    boolean bool = D();
    int i = 0;
    if (bool && this.a == 1) {
      if (!this.g || this.f.length == 0) {
        int j = (int)Math.floor(((this.e - this.d) / this.c)) + 1;
        int[] arrayOfInt = new int[j];
        while (i < j) {
          arrayOfInt[i] = Math.round(this.d + i * this.c);
          i++;
        } 
        this.f = c(arrayOfInt);
      } 
      this.b = true;
    } else {
      this.b = false;
    } 
    return this.b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */