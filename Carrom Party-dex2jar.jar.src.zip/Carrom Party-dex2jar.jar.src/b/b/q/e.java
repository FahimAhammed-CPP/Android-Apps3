package b.b.q;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import b.b.j;
import b.h.n.r;

public class e {
  public final View a;
  
  public final g b;
  
  public int c = -1;
  
  public e0 d;
  
  public e0 e;
  
  public e0 f;
  
  public e(View paramView) {
    this.a = paramView;
    this.b = g.b();
  }
  
  public final boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new e0(); 
    e0 e01 = this.f;
    e01.a();
    ColorStateList colorStateList = r.k(this.a);
    if (colorStateList != null) {
      e01.d = true;
      e01.a = colorStateList;
    } 
    PorterDuff.Mode mode = r.l(this.a);
    if (mode != null) {
      e01.c = true;
      e01.b = mode;
    } 
    if (e01.d || e01.c) {
      g.i(paramDrawable, e01, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  public void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      e0 e01 = this.e;
      if (e01 != null) {
        g.i(drawable, e01, this.a.getDrawableState());
        return;
      } 
      e01 = this.d;
      if (e01 != null)
        g.i(drawable, e01, this.a.getDrawableState()); 
    } 
  }
  
  public ColorStateList c() {
    e0 e01 = this.e;
    return (e01 != null) ? e01.a : null;
  }
  
  public PorterDuff.Mode d() {
    e0 e01 = this.e;
    return (e01 != null) ? e01.b : null;
  }
  
  public void e(AttributeSet paramAttributeSet, int paramInt) {
    g0 g0 = g0.t(this.a.getContext(), paramAttributeSet, j.G3, paramInt, 0);
    try {
      paramInt = j.H3;
      if (g0.q(paramInt)) {
        this.c = g0.m(paramInt, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.I3;
      if (g0.q(paramInt))
        r.Q(this.a, g0.c(paramInt)); 
      paramInt = j.J3;
      if (g0.q(paramInt))
        r.R(this.a, q.e(g0.j(paramInt, -1), null)); 
      return;
    } finally {
      g0.u();
    } 
  }
  
  public void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  public void g(int paramInt) {
    this.c = paramInt;
    g g1 = this.b;
    if (g1 != null) {
      ColorStateList colorStateList = g1.f(this.a.getContext(), paramInt);
    } else {
      g1 = null;
    } 
    h((ColorStateList)g1);
    b();
  }
  
  public void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new e0(); 
      e0 e01 = this.d;
      e01.a = paramColorStateList;
      e01.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  public void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new e0(); 
    e0 e01 = this.e;
    e01.a = paramColorStateList;
    e01.d = true;
    b();
  }
  
  public void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new e0(); 
    e0 e01 = this.e;
    e01.b = paramMode;
    e01.c = true;
    b();
  }
  
  public final boolean k() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.d != null)) : ((i == 21));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\q\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */