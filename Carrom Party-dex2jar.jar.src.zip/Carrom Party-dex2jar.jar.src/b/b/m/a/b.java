package b.b.m.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.SystemClock;
import android.util.SparseArray;

public class b extends Drawable implements Drawable.Callback {
  public c a;
  
  public Rect b;
  
  public Drawable c;
  
  public Drawable d;
  
  public int e = 255;
  
  public boolean f;
  
  public int g = -1;
  
  public boolean h;
  
  public Runnable i;
  
  public long j;
  
  public long k;
  
  public b l;
  
  public static int f(Resources paramResources, int paramInt) {
    if (paramResources != null)
      paramInt = (paramResources.getDisplayMetrics()).densityDpi; 
    int i = paramInt;
    if (paramInt == 0)
      i = 160; 
    return i;
  }
  
  public void a(boolean paramBoolean) {
    boolean bool2 = true;
    this.f = true;
    long l = SystemClock.uptimeMillis();
    Drawable drawable = this.c;
    if (drawable != null) {
      long l1 = this.j;
      if (l1 != 0L)
        if (l1 <= l) {
          drawable.setAlpha(this.e);
          this.j = 0L;
        } else {
          drawable.setAlpha((255 - (int)((l1 - l) * 255L) / this.a.A) * this.e / 255);
          boolean bool = true;
          drawable = this.d;
        }  
    } else {
      this.j = 0L;
    } 
    boolean bool1 = false;
    drawable = this.d;
  }
  
  public void applyTheme(Resources.Theme paramTheme) {
    this.a.b(paramTheme);
  }
  
  public c b() {
    throw null;
  }
  
  public int c() {
    return this.g;
  }
  
  public boolean canApplyTheme() {
    return this.a.canApplyTheme();
  }
  
  public final void d(Drawable paramDrawable) {
    if (this.l == null)
      this.l = new b(); 
    null = this.l;
    null.b(paramDrawable.getCallback());
    paramDrawable.setCallback(null);
    try {
      if (this.a.A <= 0 && this.f)
        paramDrawable.setAlpha(this.e); 
      c c1 = this.a;
      if (c1.E) {
        paramDrawable.setColorFilter(c1.D);
      } else {
        if (c1.H)
          b.h.g.l.a.n(paramDrawable, c1.F); 
        c1 = this.a;
        if (c1.I)
          b.h.g.l.a.o(paramDrawable, c1.G); 
      } 
      paramDrawable.setVisible(isVisible(), true);
      paramDrawable.setDither(this.a.x);
      paramDrawable.setState(getState());
      paramDrawable.setLevel(getLevel());
      paramDrawable.setBounds(getBounds());
      int i = Build.VERSION.SDK_INT;
      if (i >= 23)
        paramDrawable.setLayoutDirection(getLayoutDirection()); 
      if (i >= 19)
        paramDrawable.setAutoMirrored(this.a.C); 
      Rect rect = this.b;
      if (i >= 21 && rect != null)
        paramDrawable.setHotspotBounds(rect.left, rect.top, rect.right, rect.bottom); 
      return;
    } finally {
      paramDrawable.setCallback(this.l.a());
    } 
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable = this.c;
    if (drawable != null)
      drawable.draw(paramCanvas); 
    drawable = this.d;
    if (drawable != null)
      drawable.draw(paramCanvas); 
  }
  
  public final boolean e() {
    return (isAutoMirrored() && b.h.g.l.a.e(this) == 1);
  }
  
  public boolean g(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: getfield g : I
    //   5: if_icmpne -> 10
    //   8: iconst_0
    //   9: ireturn
    //   10: invokestatic uptimeMillis : ()J
    //   13: lstore_2
    //   14: aload_0
    //   15: getfield a : Lb/b/m/a/b$c;
    //   18: getfield B : I
    //   21: ifle -> 90
    //   24: aload_0
    //   25: getfield d : Landroid/graphics/drawable/Drawable;
    //   28: astore #4
    //   30: aload #4
    //   32: ifnull -> 43
    //   35: aload #4
    //   37: iconst_0
    //   38: iconst_0
    //   39: invokevirtual setVisible : (ZZ)Z
    //   42: pop
    //   43: aload_0
    //   44: getfield c : Landroid/graphics/drawable/Drawable;
    //   47: astore #4
    //   49: aload #4
    //   51: ifnull -> 77
    //   54: aload_0
    //   55: aload #4
    //   57: putfield d : Landroid/graphics/drawable/Drawable;
    //   60: aload_0
    //   61: aload_0
    //   62: getfield a : Lb/b/m/a/b$c;
    //   65: getfield B : I
    //   68: i2l
    //   69: lload_2
    //   70: ladd
    //   71: putfield k : J
    //   74: goto -> 109
    //   77: aload_0
    //   78: aconst_null
    //   79: putfield d : Landroid/graphics/drawable/Drawable;
    //   82: aload_0
    //   83: lconst_0
    //   84: putfield k : J
    //   87: goto -> 109
    //   90: aload_0
    //   91: getfield c : Landroid/graphics/drawable/Drawable;
    //   94: astore #4
    //   96: aload #4
    //   98: ifnull -> 109
    //   101: aload #4
    //   103: iconst_0
    //   104: iconst_0
    //   105: invokevirtual setVisible : (ZZ)Z
    //   108: pop
    //   109: iload_1
    //   110: iflt -> 181
    //   113: aload_0
    //   114: getfield a : Lb/b/m/a/b$c;
    //   117: astore #4
    //   119: iload_1
    //   120: aload #4
    //   122: getfield h : I
    //   125: if_icmpge -> 181
    //   128: aload #4
    //   130: iload_1
    //   131: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   134: astore #4
    //   136: aload_0
    //   137: aload #4
    //   139: putfield c : Landroid/graphics/drawable/Drawable;
    //   142: aload_0
    //   143: iload_1
    //   144: putfield g : I
    //   147: aload #4
    //   149: ifnull -> 191
    //   152: aload_0
    //   153: getfield a : Lb/b/m/a/b$c;
    //   156: getfield A : I
    //   159: istore_1
    //   160: iload_1
    //   161: ifle -> 172
    //   164: aload_0
    //   165: lload_2
    //   166: iload_1
    //   167: i2l
    //   168: ladd
    //   169: putfield j : J
    //   172: aload_0
    //   173: aload #4
    //   175: invokevirtual d : (Landroid/graphics/drawable/Drawable;)V
    //   178: goto -> 191
    //   181: aload_0
    //   182: aconst_null
    //   183: putfield c : Landroid/graphics/drawable/Drawable;
    //   186: aload_0
    //   187: iconst_m1
    //   188: putfield g : I
    //   191: aload_0
    //   192: getfield j : J
    //   195: lconst_0
    //   196: lcmp
    //   197: ifne -> 209
    //   200: aload_0
    //   201: getfield k : J
    //   204: lconst_0
    //   205: lcmp
    //   206: ifeq -> 246
    //   209: aload_0
    //   210: getfield i : Ljava/lang/Runnable;
    //   213: astore #4
    //   215: aload #4
    //   217: ifnonnull -> 235
    //   220: aload_0
    //   221: new b/b/m/a/b$a
    //   224: dup
    //   225: aload_0
    //   226: invokespecial <init> : (Lb/b/m/a/b;)V
    //   229: putfield i : Ljava/lang/Runnable;
    //   232: goto -> 241
    //   235: aload_0
    //   236: aload #4
    //   238: invokevirtual unscheduleSelf : (Ljava/lang/Runnable;)V
    //   241: aload_0
    //   242: iconst_1
    //   243: invokevirtual a : (Z)V
    //   246: aload_0
    //   247: invokevirtual invalidateSelf : ()V
    //   250: iconst_1
    //   251: ireturn
  }
  
  public int getAlpha() {
    return this.e;
  }
  
  public int getChangingConfigurations() {
    return super.getChangingConfigurations() | this.a.getChangingConfigurations();
  }
  
  public final Drawable.ConstantState getConstantState() {
    if (this.a.c()) {
      this.a.d = getChangingConfigurations();
      return this.a;
    } 
    return null;
  }
  
  public Drawable getCurrent() {
    return this.c;
  }
  
  public void getHotspotBounds(Rect paramRect) {
    Rect rect = this.b;
    if (rect != null) {
      paramRect.set(rect);
      return;
    } 
    super.getHotspotBounds(paramRect);
  }
  
  public int getIntrinsicHeight() {
    if (this.a.q())
      return this.a.i(); 
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.getIntrinsicHeight() : -1;
  }
  
  public int getIntrinsicWidth() {
    if (this.a.q())
      return this.a.m(); 
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.getIntrinsicWidth() : -1;
  }
  
  public int getMinimumHeight() {
    if (this.a.q())
      return this.a.j(); 
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.getMinimumHeight() : 0;
  }
  
  public int getMinimumWidth() {
    if (this.a.q())
      return this.a.k(); 
    Drawable drawable = this.c;
    return (drawable != null) ? drawable.getMinimumWidth() : 0;
  }
  
  public int getOpacity() {
    Drawable drawable = this.c;
    return (drawable == null || !drawable.isVisible()) ? -2 : this.a.n();
  }
  
  public void getOutline(Outline paramOutline) {
    Drawable drawable = this.c;
    if (drawable != null)
      drawable.getOutline(paramOutline); 
  }
  
  public boolean getPadding(Rect paramRect) {
    boolean bool;
    Rect rect = this.a.l();
    if (rect != null) {
      paramRect.set(rect);
      int i = rect.left;
      int j = rect.top;
      int k = rect.bottom;
      if ((rect.right | i | j | k) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
    } else {
      Drawable drawable = this.c;
      if (drawable != null) {
        bool = drawable.getPadding(paramRect);
      } else {
        bool = super.getPadding(paramRect);
      } 
    } 
    if (e()) {
      int i = paramRect.left;
      paramRect.left = paramRect.right;
      paramRect.right = i;
    } 
    return bool;
  }
  
  public void h(c paramc) {
    this.a = paramc;
    int i = this.g;
    if (i >= 0) {
      Drawable drawable = paramc.g(i);
      this.c = drawable;
      if (drawable != null)
        d(drawable); 
    } 
    this.d = null;
  }
  
  public final void i(Resources paramResources) {
    this.a.y(paramResources);
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    c c1 = this.a;
    if (c1 != null)
      c1.p(); 
    if (paramDrawable == this.c && getCallback() != null)
      getCallback().invalidateDrawable(this); 
  }
  
  public boolean isAutoMirrored() {
    return this.a.C;
  }
  
  public void jumpToCurrentState() {
    boolean bool1;
    Drawable drawable = this.d;
    boolean bool2 = true;
    if (drawable != null) {
      drawable.jumpToCurrentState();
      this.d = null;
      bool1 = true;
    } else {
      bool1 = false;
    } 
    drawable = this.c;
    if (drawable != null) {
      drawable.jumpToCurrentState();
      if (this.f)
        this.c.setAlpha(this.e); 
    } 
    if (this.k != 0L) {
      this.k = 0L;
      bool1 = true;
    } 
    if (this.j != 0L) {
      this.j = 0L;
      bool1 = bool2;
    } 
    if (bool1)
      invalidateSelf(); 
  }
  
  public Drawable mutate() {
    if (!this.h && super.mutate() == this) {
      c c1 = b();
      c1.r();
      h(c1);
      this.h = true;
    } 
    return this;
  }
  
  public void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.d;
    if (drawable != null)
      drawable.setBounds(paramRect); 
    drawable = this.c;
    if (drawable != null)
      drawable.setBounds(paramRect); 
  }
  
  public boolean onLayoutDirectionChanged(int paramInt) {
    return this.a.w(paramInt, c());
  }
  
  public boolean onLevelChange(int paramInt) {
    Drawable drawable = this.d;
    if (drawable != null)
      return drawable.setLevel(paramInt); 
    drawable = this.c;
    return (drawable != null) ? drawable.setLevel(paramInt) : false;
  }
  
  public boolean onStateChange(int[] paramArrayOfint) {
    Drawable drawable = this.d;
    if (drawable != null)
      return drawable.setState(paramArrayOfint); 
    drawable = this.c;
    return (drawable != null) ? drawable.setState(paramArrayOfint) : false;
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    if (paramDrawable == this.c && getCallback() != null)
      getCallback().scheduleDrawable(this, paramRunnable, paramLong); 
  }
  
  public void setAlpha(int paramInt) {
    if (!this.f || this.e != paramInt) {
      this.f = true;
      this.e = paramInt;
      Drawable drawable = this.c;
      if (drawable != null) {
        if (this.j == 0L) {
          drawable.setAlpha(paramInt);
          return;
        } 
        a(false);
      } 
    } 
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    c c1 = this.a;
    if (c1.C != paramBoolean) {
      c1.C = paramBoolean;
      Drawable drawable = this.c;
      if (drawable != null)
        b.h.g.l.a.i(drawable, paramBoolean); 
    } 
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    c c1 = this.a;
    c1.E = true;
    if (c1.D != paramColorFilter) {
      c1.D = paramColorFilter;
      Drawable drawable = this.c;
      if (drawable != null)
        drawable.setColorFilter(paramColorFilter); 
    } 
  }
  
  public void setDither(boolean paramBoolean) {
    c c1 = this.a;
    if (c1.x != paramBoolean) {
      c1.x = paramBoolean;
      Drawable drawable = this.c;
      if (drawable != null)
        drawable.setDither(paramBoolean); 
    } 
  }
  
  public void setHotspot(float paramFloat1, float paramFloat2) {
    Drawable drawable = this.c;
    if (drawable != null)
      b.h.g.l.a.j(drawable, paramFloat1, paramFloat2); 
  }
  
  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Rect rect = this.b;
    if (rect == null) {
      this.b = new Rect(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      rect.set(paramInt1, paramInt2, paramInt3, paramInt4);
    } 
    Drawable drawable = this.c;
    if (drawable != null)
      b.h.g.l.a.k(drawable, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    c c1 = this.a;
    c1.H = true;
    if (c1.F != paramColorStateList) {
      c1.F = paramColorStateList;
      b.h.g.l.a.n(this.c, paramColorStateList);
    } 
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    c c1 = this.a;
    c1.I = true;
    if (c1.G != paramMode) {
      c1.G = paramMode;
      b.h.g.l.a.o(this.c, paramMode);
    } 
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    Drawable drawable = this.d;
    if (drawable != null)
      drawable.setVisible(paramBoolean1, paramBoolean2); 
    drawable = this.c;
    if (drawable != null)
      drawable.setVisible(paramBoolean1, paramBoolean2); 
    return bool;
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    if (paramDrawable == this.c && getCallback() != null)
      getCallback().unscheduleDrawable(this, paramRunnable); 
  }
  
  public class a implements Runnable {
    public a(b this$0) {}
    
    public void run() {
      this.a.a(true);
      this.a.invalidateSelf();
    }
  }
  
  public static class b implements Drawable.Callback {
    public Drawable.Callback a;
    
    public Drawable.Callback a() {
      Drawable.Callback callback = this.a;
      this.a = null;
      return callback;
    }
    
    public b b(Drawable.Callback param1Callback) {
      this.a = param1Callback;
      return this;
    }
    
    public void invalidateDrawable(Drawable param1Drawable) {}
    
    public void scheduleDrawable(Drawable param1Drawable, Runnable param1Runnable, long param1Long) {
      Drawable.Callback callback = this.a;
      if (callback != null)
        callback.scheduleDrawable(param1Drawable, param1Runnable, param1Long); 
    }
    
    public void unscheduleDrawable(Drawable param1Drawable, Runnable param1Runnable) {
      Drawable.Callback callback = this.a;
      if (callback != null)
        callback.unscheduleDrawable(param1Drawable, param1Runnable); 
    }
  }
  
  public static abstract class c extends Drawable.ConstantState {
    public int A;
    
    public int B;
    
    public boolean C;
    
    public ColorFilter D;
    
    public boolean E;
    
    public ColorStateList F;
    
    public PorterDuff.Mode G;
    
    public boolean H;
    
    public boolean I;
    
    public final b a;
    
    public Resources b;
    
    public int c = 160;
    
    public int d;
    
    public int e;
    
    public SparseArray<Drawable.ConstantState> f;
    
    public Drawable[] g;
    
    public int h;
    
    public boolean i;
    
    public boolean j;
    
    public Rect k;
    
    public boolean l;
    
    public boolean m;
    
    public int n;
    
    public int o;
    
    public int p;
    
    public int q;
    
    public boolean r;
    
    public int s;
    
    public boolean t;
    
    public boolean u;
    
    public boolean v;
    
    public boolean w;
    
    public boolean x;
    
    public boolean y;
    
    public int z;
    
    public c(c param1c, b param1b, Resources param1Resources) {
      boolean bool = false;
      this.i = false;
      this.l = false;
      this.x = true;
      this.A = 0;
      this.B = 0;
      this.a = param1b;
      if (param1Resources != null) {
        Resources resources = param1Resources;
      } else if (param1c != null) {
        Resources resources = param1c.b;
      } else {
        param1b = null;
      } 
      this.b = (Resources)param1b;
      if (param1c != null) {
        i = param1c.c;
      } else {
        i = 0;
      } 
      int i = b.f(param1Resources, i);
      this.c = i;
      if (param1c != null) {
        this.d = param1c.d;
        this.e = param1c.e;
        this.v = true;
        this.w = true;
        this.i = param1c.i;
        this.l = param1c.l;
        this.x = param1c.x;
        this.y = param1c.y;
        this.z = param1c.z;
        this.A = param1c.A;
        this.B = param1c.B;
        this.C = param1c.C;
        this.D = param1c.D;
        this.E = param1c.E;
        this.F = param1c.F;
        this.G = param1c.G;
        this.H = param1c.H;
        this.I = param1c.I;
        if (param1c.c == i) {
          if (param1c.j) {
            this.k = new Rect(param1c.k);
            this.j = true;
          } 
          if (param1c.m) {
            this.n = param1c.n;
            this.o = param1c.o;
            this.p = param1c.p;
            this.q = param1c.q;
            this.m = true;
          } 
        } 
        if (param1c.r) {
          this.s = param1c.s;
          this.r = true;
        } 
        if (param1c.t) {
          this.u = param1c.u;
          this.t = true;
        } 
        Drawable[] arrayOfDrawable = param1c.g;
        this.g = new Drawable[arrayOfDrawable.length];
        this.h = param1c.h;
        SparseArray<Drawable.ConstantState> sparseArray = param1c.f;
        if (sparseArray != null) {
          this.f = sparseArray.clone();
        } else {
          this.f = new SparseArray(this.h);
        } 
        int j = this.h;
        for (i = bool; i < j; i++) {
          if (arrayOfDrawable[i] != null) {
            Drawable.ConstantState constantState = arrayOfDrawable[i].getConstantState();
            if (constantState != null) {
              this.f.put(i, constantState);
            } else {
              this.g[i] = arrayOfDrawable[i];
            } 
          } 
        } 
      } else {
        this.g = new Drawable[10];
        this.h = 0;
      } 
    }
    
    public final int a(Drawable param1Drawable) {
      int i = this.h;
      if (i >= this.g.length)
        o(i, i + 10); 
      param1Drawable.mutate();
      param1Drawable.setVisible(false, true);
      param1Drawable.setCallback(this.a);
      this.g[i] = param1Drawable;
      this.h++;
      int j = this.e;
      this.e = param1Drawable.getChangingConfigurations() | j;
      p();
      this.k = null;
      this.j = false;
      this.m = false;
      this.v = false;
      return i;
    }
    
    public final void b(Resources.Theme param1Theme) {
      if (param1Theme != null) {
        e();
        int j = this.h;
        Drawable[] arrayOfDrawable = this.g;
        for (int i = 0; i < j; i++) {
          if (arrayOfDrawable[i] != null && arrayOfDrawable[i].canApplyTheme()) {
            arrayOfDrawable[i].applyTheme(param1Theme);
            this.e |= arrayOfDrawable[i].getChangingConfigurations();
          } 
        } 
        y(param1Theme.getResources());
      } 
    }
    
    public boolean c() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield v : Z
      //   6: ifeq -> 18
      //   9: aload_0
      //   10: getfield w : Z
      //   13: istore_3
      //   14: aload_0
      //   15: monitorexit
      //   16: iload_3
      //   17: ireturn
      //   18: aload_0
      //   19: invokevirtual e : ()V
      //   22: aload_0
      //   23: iconst_1
      //   24: putfield v : Z
      //   27: aload_0
      //   28: getfield h : I
      //   31: istore_2
      //   32: aload_0
      //   33: getfield g : [Landroid/graphics/drawable/Drawable;
      //   36: astore #4
      //   38: iconst_0
      //   39: istore_1
      //   40: iload_1
      //   41: iload_2
      //   42: if_icmpge -> 71
      //   45: aload #4
      //   47: iload_1
      //   48: aaload
      //   49: invokevirtual getConstantState : ()Landroid/graphics/drawable/Drawable$ConstantState;
      //   52: ifnonnull -> 64
      //   55: aload_0
      //   56: iconst_0
      //   57: putfield w : Z
      //   60: aload_0
      //   61: monitorexit
      //   62: iconst_0
      //   63: ireturn
      //   64: iload_1
      //   65: iconst_1
      //   66: iadd
      //   67: istore_1
      //   68: goto -> 40
      //   71: aload_0
      //   72: iconst_1
      //   73: putfield w : Z
      //   76: aload_0
      //   77: monitorexit
      //   78: iconst_1
      //   79: ireturn
      //   80: astore #4
      //   82: aload_0
      //   83: monitorexit
      //   84: goto -> 90
      //   87: aload #4
      //   89: athrow
      //   90: goto -> 87
      // Exception table:
      //   from	to	target	type
      //   2	14	80	finally
      //   18	38	80	finally
      //   45	60	80	finally
      //   71	76	80	finally
    }
    
    public boolean canApplyTheme() {
      int j = this.h;
      Drawable[] arrayOfDrawable = this.g;
      for (int i = 0; i < j; i++) {
        Drawable drawable = arrayOfDrawable[i];
        if (drawable != null) {
          if (drawable.canApplyTheme())
            return true; 
        } else {
          Drawable.ConstantState constantState = (Drawable.ConstantState)this.f.get(i);
          if (constantState != null && constantState.canApplyTheme())
            return true; 
        } 
      } 
      return false;
    }
    
    public void d() {
      this.m = true;
      e();
      int j = this.h;
      Drawable[] arrayOfDrawable = this.g;
      this.o = -1;
      this.n = -1;
      int i = 0;
      this.q = 0;
      this.p = 0;
      while (i < j) {
        Drawable drawable = arrayOfDrawable[i];
        int k = drawable.getIntrinsicWidth();
        if (k > this.n)
          this.n = k; 
        k = drawable.getIntrinsicHeight();
        if (k > this.o)
          this.o = k; 
        k = drawable.getMinimumWidth();
        if (k > this.p)
          this.p = k; 
        k = drawable.getMinimumHeight();
        if (k > this.q)
          this.q = k; 
        i++;
      } 
    }
    
    public final void e() {
      SparseArray<Drawable.ConstantState> sparseArray = this.f;
      if (sparseArray != null) {
        int j = sparseArray.size();
        for (int i = 0; i < j; i++) {
          int k = this.f.keyAt(i);
          Drawable.ConstantState constantState = (Drawable.ConstantState)this.f.valueAt(i);
          this.g[k] = s(constantState.newDrawable(this.b));
        } 
        this.f = null;
      } 
    }
    
    public final int f() {
      return this.g.length;
    }
    
    public final Drawable g(int param1Int) {
      Drawable drawable = this.g[param1Int];
      if (drawable != null)
        return drawable; 
      SparseArray<Drawable.ConstantState> sparseArray = this.f;
      if (sparseArray != null) {
        int i = sparseArray.indexOfKey(param1Int);
        if (i >= 0) {
          Drawable drawable1 = s(((Drawable.ConstantState)this.f.valueAt(i)).newDrawable(this.b));
          this.g[param1Int] = drawable1;
          this.f.removeAt(i);
          if (this.f.size() == 0)
            this.f = null; 
          return drawable1;
        } 
      } 
      return null;
    }
    
    public int getChangingConfigurations() {
      return this.d | this.e;
    }
    
    public final int h() {
      return this.h;
    }
    
    public final int i() {
      if (!this.m)
        d(); 
      return this.o;
    }
    
    public final int j() {
      if (!this.m)
        d(); 
      return this.q;
    }
    
    public final int k() {
      if (!this.m)
        d(); 
      return this.p;
    }
    
    public final Rect l() {
      boolean bool = this.i;
      Rect rect1 = null;
      if (bool)
        return null; 
      Rect rect2 = this.k;
      if (rect2 == null) {
        if (this.j)
          return rect2; 
        e();
        Rect rect = new Rect();
        int j = this.h;
        Drawable[] arrayOfDrawable = this.g;
        int i = 0;
        while (i < j) {
          Rect rect3 = rect1;
          if (arrayOfDrawable[i].getPadding(rect)) {
            rect2 = rect1;
            if (rect1 == null)
              rect2 = new Rect(0, 0, 0, 0); 
            int k = rect.left;
            if (k > rect2.left)
              rect2.left = k; 
            k = rect.top;
            if (k > rect2.top)
              rect2.top = k; 
            k = rect.right;
            if (k > rect2.right)
              rect2.right = k; 
            k = rect.bottom;
            rect3 = rect2;
            if (k > rect2.bottom) {
              rect2.bottom = k;
              rect3 = rect2;
            } 
          } 
          i++;
          rect1 = rect3;
        } 
        this.j = true;
        this.k = rect1;
        return rect1;
      } 
      return rect2;
    }
    
    public final int m() {
      if (!this.m)
        d(); 
      return this.n;
    }
    
    public final int n() {
      int i;
      if (this.r)
        return this.s; 
      e();
      int k = this.h;
      Drawable[] arrayOfDrawable = this.g;
      if (k > 0) {
        i = arrayOfDrawable[0].getOpacity();
      } else {
        i = -2;
      } 
      for (int j = 1; j < k; j++)
        i = Drawable.resolveOpacity(i, arrayOfDrawable[j].getOpacity()); 
      this.s = i;
      this.r = true;
      return i;
    }
    
    public void o(int param1Int1, int param1Int2) {
      Drawable[] arrayOfDrawable = new Drawable[param1Int2];
      System.arraycopy(this.g, 0, arrayOfDrawable, 0, param1Int1);
      this.g = arrayOfDrawable;
    }
    
    public void p() {
      this.r = false;
      this.t = false;
    }
    
    public final boolean q() {
      return this.l;
    }
    
    public abstract void r();
    
    public final Drawable s(Drawable param1Drawable) {
      if (Build.VERSION.SDK_INT >= 23)
        param1Drawable.setLayoutDirection(this.z); 
      param1Drawable = param1Drawable.mutate();
      param1Drawable.setCallback(this.a);
      return param1Drawable;
    }
    
    public final void t(boolean param1Boolean) {
      this.l = param1Boolean;
    }
    
    public final void u(int param1Int) {
      this.A = param1Int;
    }
    
    public final void v(int param1Int) {
      this.B = param1Int;
    }
    
    public final boolean w(int param1Int1, int param1Int2) {
      int j = this.h;
      Drawable[] arrayOfDrawable = this.g;
      int i = 0;
      boolean bool;
      for (bool = false; i < j; bool = bool1) {
        boolean bool1 = bool;
        if (arrayOfDrawable[i] != null) {
          boolean bool2;
          if (Build.VERSION.SDK_INT >= 23) {
            bool2 = arrayOfDrawable[i].setLayoutDirection(param1Int1);
          } else {
            bool2 = false;
          } 
          bool1 = bool;
          if (i == param1Int2)
            bool1 = bool2; 
        } 
        i++;
      } 
      this.z = param1Int1;
      return bool;
    }
    
    public final void x(boolean param1Boolean) {
      this.i = param1Boolean;
    }
    
    public final void y(Resources param1Resources) {
      if (param1Resources != null) {
        this.b = param1Resources;
        int i = b.f(param1Resources, this.c);
        int j = this.c;
        this.c = i;
        if (j != i) {
          this.m = false;
          this.j = false;
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\m\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */