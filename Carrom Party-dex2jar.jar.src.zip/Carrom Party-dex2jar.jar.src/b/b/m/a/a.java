package b.b.m.a;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.StateSet;
import b.b.q.w;
import b.f.h;
import b.h.g.l.b;
import b.w.a.a.h;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@SuppressLint({"RestrictedAPI"})
public class a extends d implements b {
  public int C = -1;
  
  public boolean D;
  
  public c o;
  
  public g p;
  
  public int q = -1;
  
  public a() {
    this(null, null);
  }
  
  public a(c paramc, Resources paramResources) {
    super(null);
    h(new c(paramc, this, paramResources));
    onStateChange(getState());
    jumpToCurrentState();
  }
  
  public static a m(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    a a1;
    String str = paramXmlPullParser.getName();
    if (str.equals("animated-selector")) {
      a1 = new a();
      a1.n(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return a1;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid animated-selector tag ");
    stringBuilder.append((String)a1);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  public void h(b.c paramc) {
    super.h(paramc);
    if (paramc instanceof c)
      this.o = (c)paramc; 
  }
  
  public boolean isStateful() {
    return true;
  }
  
  public void jumpToCurrentState() {
    super.jumpToCurrentState();
    g g1 = this.p;
    if (g1 != null) {
      g1.d();
      this.p = null;
      g(this.q);
      this.q = -1;
      this.C = -1;
    } 
  }
  
  public c l() {
    return new c(this.o, this, null);
  }
  
  public Drawable mutate() {
    if (!this.D) {
      super.mutate();
      this.o.r();
      this.D = true;
    } 
    return this;
  }
  
  public void n(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    TypedArray typedArray = b.h.f.e.g.k(paramResources, paramTheme, paramAttributeSet, b.b.n.b.a);
    setVisible(typedArray.getBoolean(b.b.n.b.c, true), true);
    t(typedArray);
    i(paramResources);
    typedArray.recycle();
    o(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    p();
  }
  
  public final void o(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    int i = paramXmlPullParser.getDepth() + 1;
    while (true) {
      int j = paramXmlPullParser.next();
      if (j != 1) {
        int k = paramXmlPullParser.getDepth();
        if (k >= i || j != 3) {
          if (j != 2 || k > i)
            continue; 
          if (paramXmlPullParser.getName().equals("item")) {
            q(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
            continue;
          } 
          if (paramXmlPullParser.getName().equals("transition"))
            r(paramContext, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
          continue;
        } 
      } 
      break;
    } 
  }
  
  public boolean onStateChange(int[] paramArrayOfint) {
    boolean bool1;
    int i = this.o.F(paramArrayOfint);
    if (i != c() && (s(i) || g(i))) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    Drawable drawable = getCurrent();
    boolean bool2 = bool1;
    if (drawable != null)
      bool2 = bool1 | drawable.setState(paramArrayOfint); 
    return bool2;
  }
  
  public final void p() {
    onStateChange(getState());
  }
  
  public final int q(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    XmlPullParserException xmlPullParserException2;
    Context context;
    TypedArray typedArray = b.h.f.e.g.k(paramResources, paramTheme, paramAttributeSet, b.b.n.b.h);
    int i = typedArray.getResourceId(b.b.n.b.i, 0);
    int j = typedArray.getResourceId(b.b.n.b.j, -1);
    if (j > 0) {
      context = (Context)w.h().j(paramContext, j);
    } else {
      context = null;
    } 
    typedArray.recycle();
    int[] arrayOfInt = k(paramAttributeSet);
    paramContext = context;
    if (context == null)
      while (true) {
        j = paramXmlPullParser.next();
        if (j == 4)
          continue; 
        if (j == 2) {
          if (paramXmlPullParser.getName().equals("vector")) {
            h h = h.c(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
            break;
          } 
          if (Build.VERSION.SDK_INT >= 21) {
            Drawable drawable = Drawable.createFromXmlInner(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
          } else {
            Drawable drawable = Drawable.createFromXmlInner(paramResources, paramXmlPullParser, paramAttributeSet);
          } 
        } else {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramXmlPullParser.getPositionDescription());
          stringBuilder1.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
          throw new XmlPullParserException(stringBuilder1.toString());
        } 
        if (stringBuilder1 != null)
          return this.o.B(arrayOfInt, (Drawable)stringBuilder1, i); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(paramXmlPullParser.getPositionDescription());
        stringBuilder1.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
        xmlPullParserException2 = new XmlPullParserException(stringBuilder1.toString());
        throw xmlPullParserException2;
      }  
    if (xmlPullParserException2 != null)
      return this.o.B(arrayOfInt, (Drawable)xmlPullParserException2, i); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": <item> tag requires a 'drawable' attribute or child tag defining a drawable");
    XmlPullParserException xmlPullParserException1 = new XmlPullParserException(stringBuilder.toString());
    throw xmlPullParserException1;
  }
  
  public final int r(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_2
    //   1: aload #5
    //   3: aload #4
    //   5: getstatic b/b/n/b.k : [I
    //   8: invokestatic k : (Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   11: astore #10
    //   13: aload #10
    //   15: getstatic b/b/n/b.n : I
    //   18: iconst_m1
    //   19: invokevirtual getResourceId : (II)I
    //   22: istore #6
    //   24: aload #10
    //   26: getstatic b/b/n/b.m : I
    //   29: iconst_m1
    //   30: invokevirtual getResourceId : (II)I
    //   33: istore #7
    //   35: aload #10
    //   37: getstatic b/b/n/b.l : I
    //   40: iconst_m1
    //   41: invokevirtual getResourceId : (II)I
    //   44: istore #8
    //   46: iload #8
    //   48: ifle -> 65
    //   51: invokestatic h : ()Lb/b/q/w;
    //   54: aload_1
    //   55: iload #8
    //   57: invokevirtual j : (Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    //   60: astore #11
    //   62: goto -> 68
    //   65: aconst_null
    //   66: astore #11
    //   68: aload #10
    //   70: getstatic b/b/n/b.o : I
    //   73: iconst_0
    //   74: invokevirtual getBoolean : (IZ)Z
    //   77: istore #9
    //   79: aload #10
    //   81: invokevirtual recycle : ()V
    //   84: aload #11
    //   86: astore #10
    //   88: aload #11
    //   90: ifnonnull -> 219
    //   93: aload_3
    //   94: invokeinterface next : ()I
    //   99: istore #8
    //   101: iload #8
    //   103: iconst_4
    //   104: if_icmpne -> 110
    //   107: goto -> 93
    //   110: iload #8
    //   112: iconst_2
    //   113: if_icmpne -> 180
    //   116: aload_3
    //   117: invokeinterface getName : ()Ljava/lang/String;
    //   122: ldc_w 'animated-vector'
    //   125: invokevirtual equals : (Ljava/lang/Object;)Z
    //   128: ifeq -> 146
    //   131: aload_1
    //   132: aload_2
    //   133: aload_3
    //   134: aload #4
    //   136: aload #5
    //   138: invokestatic a : (Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Lb/w/a/a/b;
    //   141: astore #10
    //   143: goto -> 219
    //   146: getstatic android/os/Build$VERSION.SDK_INT : I
    //   149: bipush #21
    //   151: if_icmplt -> 168
    //   154: aload_2
    //   155: aload_3
    //   156: aload #4
    //   158: aload #5
    //   160: invokestatic createFromXmlInner : (Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    //   163: astore #10
    //   165: goto -> 219
    //   168: aload_2
    //   169: aload_3
    //   170: aload #4
    //   172: invokestatic createFromXmlInner : (Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;)Landroid/graphics/drawable/Drawable;
    //   175: astore #10
    //   177: goto -> 219
    //   180: new java/lang/StringBuilder
    //   183: dup
    //   184: invokespecial <init> : ()V
    //   187: astore_1
    //   188: aload_1
    //   189: aload_3
    //   190: invokeinterface getPositionDescription : ()Ljava/lang/String;
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: pop
    //   199: aload_1
    //   200: ldc_w ': <transition> tag requires a 'drawable' attribute or child tag defining a drawable'
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: pop
    //   207: new org/xmlpull/v1/XmlPullParserException
    //   210: dup
    //   211: aload_1
    //   212: invokevirtual toString : ()Ljava/lang/String;
    //   215: invokespecial <init> : (Ljava/lang/String;)V
    //   218: athrow
    //   219: aload #10
    //   221: ifnull -> 291
    //   224: iload #6
    //   226: iconst_m1
    //   227: if_icmpeq -> 252
    //   230: iload #7
    //   232: iconst_m1
    //   233: if_icmpeq -> 252
    //   236: aload_0
    //   237: getfield o : Lb/b/m/a/a$c;
    //   240: iload #6
    //   242: iload #7
    //   244: aload #10
    //   246: iload #9
    //   248: invokevirtual C : (IILandroid/graphics/drawable/Drawable;Z)I
    //   251: ireturn
    //   252: new java/lang/StringBuilder
    //   255: dup
    //   256: invokespecial <init> : ()V
    //   259: astore_1
    //   260: aload_1
    //   261: aload_3
    //   262: invokeinterface getPositionDescription : ()Ljava/lang/String;
    //   267: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: pop
    //   271: aload_1
    //   272: ldc_w ': <transition> tag requires 'fromId' & 'toId' attributes'
    //   275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   278: pop
    //   279: new org/xmlpull/v1/XmlPullParserException
    //   282: dup
    //   283: aload_1
    //   284: invokevirtual toString : ()Ljava/lang/String;
    //   287: invokespecial <init> : (Ljava/lang/String;)V
    //   290: athrow
    //   291: new java/lang/StringBuilder
    //   294: dup
    //   295: invokespecial <init> : ()V
    //   298: astore_1
    //   299: aload_1
    //   300: aload_3
    //   301: invokeinterface getPositionDescription : ()Ljava/lang/String;
    //   306: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: pop
    //   310: aload_1
    //   311: ldc_w ': <transition> tag requires a 'drawable' attribute or child tag defining a drawable'
    //   314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: pop
    //   318: new org/xmlpull/v1/XmlPullParserException
    //   321: dup
    //   322: aload_1
    //   323: invokevirtual toString : ()Ljava/lang/String;
    //   326: invokespecial <init> : (Ljava/lang/String;)V
    //   329: astore_1
    //   330: goto -> 335
    //   333: aload_1
    //   334: athrow
    //   335: goto -> 333
  }
  
  public final boolean s(int paramInt) {
    int i;
    g g1 = this.p;
    if (g1 != null) {
      if (paramInt == this.q)
        return true; 
      if (paramInt == this.C && g1.a()) {
        g1.b();
        this.q = this.C;
        this.C = paramInt;
        return true;
      } 
      i = this.q;
      g1.d();
    } else {
      i = c();
    } 
    this.p = null;
    this.C = -1;
    this.q = -1;
    c c1 = this.o;
    int j = c1.E(i);
    int k = c1.E(paramInt);
    if (k != 0) {
      b b1;
      if (j == 0)
        return false; 
      int m = c1.G(j, k);
      if (m < 0)
        return false; 
      boolean bool = c1.I(j, k);
      g(m);
      Drawable drawable = getCurrent();
      if (drawable instanceof AnimationDrawable) {
        boolean bool1 = c1.H(j, k);
        e e = new e((AnimationDrawable)drawable, bool1, bool);
      } else if (drawable instanceof b.w.a.a.b) {
        d d1 = new d((b.w.a.a.b)drawable);
      } else {
        if (drawable instanceof Animatable) {
          b1 = new b((Animatable)drawable);
          b1.c();
          this.p = b1;
          this.C = i;
          this.q = paramInt;
          return true;
        } 
        return false;
      } 
      b1.c();
      this.p = b1;
      this.C = i;
      this.q = paramInt;
      return true;
    } 
    return false;
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    g g1 = this.p;
    if (g1 != null && (bool || paramBoolean2)) {
      if (paramBoolean1) {
        g1.c();
        return bool;
      } 
      jumpToCurrentState();
    } 
    return bool;
  }
  
  public final void t(TypedArray paramTypedArray) {
    c c1 = this.o;
    if (Build.VERSION.SDK_INT >= 21)
      c1.d |= paramTypedArray.getChangingConfigurations(); 
    c1.x(paramTypedArray.getBoolean(b.b.n.b.d, c1.i));
    c1.t(paramTypedArray.getBoolean(b.b.n.b.e, c1.l));
    c1.u(paramTypedArray.getInt(b.b.n.b.f, c1.A));
    c1.v(paramTypedArray.getInt(b.b.n.b.g, c1.B));
    setDither(paramTypedArray.getBoolean(b.b.n.b.b, c1.x));
  }
  
  public static class b extends g {
    public final Animatable a;
    
    public b(Animatable param1Animatable) {
      super(null);
      this.a = param1Animatable;
    }
    
    public void c() {
      this.a.start();
    }
    
    public void d() {
      this.a.stop();
    }
  }
  
  public static class c extends d.a {
    public b.f.d<Long> K;
    
    public h<Integer> L;
    
    public c(c param1c, a param1a, Resources param1Resources) {
      super(param1c, param1a, param1Resources);
      if (param1c != null) {
        this.K = param1c.K;
        this.L = param1c.L;
        return;
      } 
      this.K = new b.f.d();
      this.L = new h();
    }
    
    public static long D(int param1Int1, int param1Int2) {
      long l = param1Int1;
      return param1Int2 | l << 32L;
    }
    
    public int B(int[] param1ArrayOfint, Drawable param1Drawable, int param1Int) {
      int i = z(param1ArrayOfint, param1Drawable);
      this.L.s(i, Integer.valueOf(param1Int));
      return i;
    }
    
    public int C(int param1Int1, int param1Int2, Drawable param1Drawable, boolean param1Boolean) {
      long l1;
      int i = a(param1Drawable);
      long l2 = D(param1Int1, param1Int2);
      if (param1Boolean) {
        l1 = 8589934592L;
      } else {
        l1 = 0L;
      } 
      b.f.d<Long> d1 = this.K;
      long l3 = i;
      d1.c(l2, Long.valueOf(l3 | l1));
      if (param1Boolean) {
        l2 = D(param1Int2, param1Int1);
        this.K.c(l2, Long.valueOf(0x100000000L | l3 | l1));
      } 
      return i;
    }
    
    public int E(int param1Int) {
      return (param1Int < 0) ? 0 : ((Integer)this.L.q(param1Int, Integer.valueOf(0))).intValue();
    }
    
    public int F(int[] param1ArrayOfint) {
      int i = A(param1ArrayOfint);
      return (i >= 0) ? i : A(StateSet.WILD_CARD);
    }
    
    public int G(int param1Int1, int param1Int2) {
      long l = D(param1Int1, param1Int2);
      return (int)((Long)this.K.r(l, Long.valueOf(-1L))).longValue();
    }
    
    public boolean H(int param1Int1, int param1Int2) {
      long l = D(param1Int1, param1Int2);
      return ((((Long)this.K.r(l, Long.valueOf(-1L))).longValue() & 0x100000000L) != 0L);
    }
    
    public boolean I(int param1Int1, int param1Int2) {
      long l = D(param1Int1, param1Int2);
      return ((((Long)this.K.r(l, Long.valueOf(-1L))).longValue() & 0x200000000L) != 0L);
    }
    
    public Drawable newDrawable() {
      return new a(this, null);
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      return new a(this, param1Resources);
    }
    
    public void r() {
      this.K = this.K.f();
      this.L = this.L.f();
    }
  }
  
  public static class d extends g {
    public final b.w.a.a.b a;
    
    public d(b.w.a.a.b param1b) {
      super(null);
      this.a = param1b;
    }
    
    public void c() {
      this.a.start();
    }
    
    public void d() {
      this.a.stop();
    }
  }
  
  public static class e extends g {
    public final ObjectAnimator a;
    
    public final boolean b;
    
    public e(AnimationDrawable param1AnimationDrawable, boolean param1Boolean1, boolean param1Boolean2) {
      super(null);
      boolean bool;
      int i = param1AnimationDrawable.getNumberOfFrames();
      if (param1Boolean1) {
        bool = i - 1;
      } else {
        bool = false;
      } 
      if (param1Boolean1) {
        i = 0;
      } else {
        i--;
      } 
      a.f f = new a.f(param1AnimationDrawable, param1Boolean1);
      ObjectAnimator objectAnimator = ObjectAnimator.ofInt(param1AnimationDrawable, "currentIndex", new int[] { bool, i });
      if (Build.VERSION.SDK_INT >= 18)
        objectAnimator.setAutoCancel(true); 
      objectAnimator.setDuration(f.a());
      objectAnimator.setInterpolator(f);
      this.b = param1Boolean2;
      this.a = objectAnimator;
    }
    
    public boolean a() {
      return this.b;
    }
    
    public void b() {
      this.a.reverse();
    }
    
    public void c() {
      this.a.start();
    }
    
    public void d() {
      this.a.cancel();
    }
  }
  
  public static class f implements TimeInterpolator {
    public int[] a;
    
    public int b;
    
    public int c;
    
    public f(AnimationDrawable param1AnimationDrawable, boolean param1Boolean) {
      b(param1AnimationDrawable, param1Boolean);
    }
    
    public int a() {
      return this.c;
    }
    
    public int b(AnimationDrawable param1AnimationDrawable, boolean param1Boolean) {
      int k = param1AnimationDrawable.getNumberOfFrames();
      this.b = k;
      int[] arrayOfInt = this.a;
      if (arrayOfInt == null || arrayOfInt.length < k)
        this.a = new int[k]; 
      arrayOfInt = this.a;
      int i = 0;
      int j = 0;
      while (i < k) {
        if (param1Boolean) {
          m = k - i - 1;
        } else {
          m = i;
        } 
        int m = param1AnimationDrawable.getDuration(m);
        arrayOfInt[i] = m;
        j += m;
        i++;
      } 
      this.c = j;
      return j;
    }
    
    public float getInterpolation(float param1Float) {
      int j = (int)(param1Float * this.c + 0.5F);
      int k = this.b;
      int[] arrayOfInt = this.a;
      int i;
      for (i = 0; i < k && j >= arrayOfInt[i]; i++)
        j -= arrayOfInt[i]; 
      if (i < k) {
        param1Float = j / this.c;
      } else {
        param1Float = 0.0F;
      } 
      return i / k + param1Float;
    }
  }
  
  public static abstract class g {
    public g() {}
    
    public boolean a() {
      return false;
    }
    
    public void b() {}
    
    public abstract void c();
    
    public abstract void d();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\m\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */