package b.b.m.a;

import android.annotation.SuppressLint;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.StateSet;

@SuppressLint({"RestrictedAPI"})
public class d extends b {
  public a m;
  
  public boolean n;
  
  public d(a parama) {
    if (parama != null)
      h(parama); 
  }
  
  public d(a parama, Resources paramResources) {
    h(new a(parama, this, paramResources));
    onStateChange(getState());
  }
  
  public void applyTheme(Resources.Theme paramTheme) {
    super.applyTheme(paramTheme);
    onStateChange(getState());
  }
  
  public void h(b.c paramc) {
    super.h(paramc);
    if (paramc instanceof a)
      this.m = (a)paramc; 
  }
  
  public boolean isStateful() {
    return true;
  }
  
  public a j() {
    return new a(this.m, this, null);
  }
  
  public int[] k(AttributeSet paramAttributeSet) {
    int k = paramAttributeSet.getAttributeCount();
    int[] arrayOfInt = new int[k];
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      int n = paramAttributeSet.getAttributeNameResource(i);
      int m = j;
      if (n != 0) {
        m = j;
        if (n != 16842960) {
          m = j;
          if (n != 16843161) {
            if (paramAttributeSet.getAttributeBooleanValue(i, false)) {
              m = n;
            } else {
              m = -n;
            } 
            arrayOfInt[j] = m;
            m = j + 1;
          } 
        } 
      } 
      i++;
    } 
    return StateSet.trimStateSet(arrayOfInt, j);
  }
  
  public Drawable mutate() {
    if (!this.n) {
      super.mutate();
      this.m.r();
      this.n = true;
    } 
    return this;
  }
  
  public boolean onStateChange(int[] paramArrayOfint) {
    boolean bool = super.onStateChange(paramArrayOfint);
    int j = this.m.A(paramArrayOfint);
    int i = j;
    if (j < 0)
      i = this.m.A(StateSet.WILD_CARD); 
    return (g(i) || bool);
  }
  
  public static class a extends b.c {
    public int[][] J;
    
    public a(a param1a, d param1d, Resources param1Resources) {
      super(param1a, param1d, param1Resources);
      if (param1a != null) {
        this.J = param1a.J;
        return;
      } 
      this.J = new int[f()][];
    }
    
    public int A(int[] param1ArrayOfint) {
      int[][] arrayOfInt = this.J;
      int j = h();
      for (int i = 0; i < j; i++) {
        if (StateSet.stateSetMatches(arrayOfInt[i], param1ArrayOfint))
          return i; 
      } 
      return -1;
    }
    
    public Drawable newDrawable() {
      return new d(this, null);
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      return new d(this, param1Resources);
    }
    
    public void o(int param1Int1, int param1Int2) {
      super.o(param1Int1, param1Int2);
      int[][] arrayOfInt = new int[param1Int2][];
      System.arraycopy(this.J, 0, arrayOfInt, 0, param1Int1);
      this.J = arrayOfInt;
    }
    
    public void r() {
      int[][] arrayOfInt1 = this.J;
      int[][] arrayOfInt2 = new int[arrayOfInt1.length][];
      for (int i = arrayOfInt1.length - 1; i >= 0; i--) {
        arrayOfInt1 = this.J;
        if (arrayOfInt1[i] != null) {
          int[] arrayOfInt = (int[])arrayOfInt1[i].clone();
        } else {
          arrayOfInt1 = null;
        } 
        arrayOfInt2[i] = (int[])arrayOfInt1;
      } 
      this.J = arrayOfInt2;
    }
    
    public int z(int[] param1ArrayOfint, Drawable param1Drawable) {
      int i = a(param1Drawable);
      this.J[i] = param1ArrayOfint;
      return i;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\m\a\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */