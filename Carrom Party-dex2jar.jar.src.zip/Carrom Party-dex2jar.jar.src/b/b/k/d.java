package b.b.k;

import b.b.p.b;

public interface d {
  void d(b paramb);
  
  void e(b paramb);
  
  b i(b.a parama);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\k\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */