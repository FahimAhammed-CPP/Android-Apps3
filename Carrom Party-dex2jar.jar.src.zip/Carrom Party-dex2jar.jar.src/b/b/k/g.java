package b.b.k;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import b.b.p.b;
import b.h.n.e;

public class g extends Dialog implements d {
  public e a;
  
  public final e.a b = new a(this);
  
  public g(Context paramContext, int paramInt) {
    super(paramContext, b(paramContext, paramInt));
    e e1 = a();
    e1.C(b(paramContext, paramInt));
    e1.q(null);
  }
  
  public static int b(Context paramContext, int paramInt) {
    int i = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      paramContext.getTheme().resolveAttribute(b.b.a.y, typedValue, true);
      i = typedValue.resourceId;
    } 
    return i;
  }
  
  public e a() {
    if (this.a == null)
      this.a = e.f(this, this); 
    return this.a;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a().c(paramView, paramLayoutParams);
  }
  
  public boolean c(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public void d(b paramb) {}
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return e.e(this.b, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public void e(b paramb) {}
  
  public boolean f(int paramInt) {
    return a().y(paramInt);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return a().g(paramInt);
  }
  
  public b i(b.a parama) {
    return null;
  }
  
  public void invalidateOptionsMenu() {
    a().m();
  }
  
  public void onCreate(Bundle paramBundle) {
    a().l();
    super.onCreate(paramBundle);
    a().q(paramBundle);
  }
  
  public void onStop() {
    super.onStop();
    a().w();
  }
  
  public void setContentView(int paramInt) {
    a().z(paramInt);
  }
  
  public void setContentView(View paramView) {
    a().A(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    a().B(paramView, paramLayoutParams);
  }
  
  public void setTitle(int paramInt) {
    super.setTitle(paramInt);
    a().D(getContext().getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    a().D(paramCharSequence);
  }
  
  public class a implements e.a {
    public a(g this$0) {}
    
    public boolean k(KeyEvent param1KeyEvent) {
      return this.a.c(param1KeyEvent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\k\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */