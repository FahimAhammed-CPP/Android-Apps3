package b.b.k;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import b.f.b;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public abstract class e {
  public static int a = -100;
  
  public static final b<WeakReference<e>> b = new b();
  
  public static final Object c = new Object();
  
  public static e e(Activity paramActivity, d paramd) {
    return new f(paramActivity, paramd);
  }
  
  public static e f(Dialog paramDialog, d paramd) {
    return new f(paramDialog, paramd);
  }
  
  public static int h() {
    return a;
  }
  
  public static void n(e parame) {
    synchronized (c) {
      x(parame);
      b.add(new WeakReference<e>(parame));
      return;
    } 
  }
  
  public static void o(e parame) {
    synchronized (c) {
      x(parame);
      return;
    } 
  }
  
  public static void x(e parame) {
    synchronized (c) {
      Iterator<WeakReference<e>> iterator = b.iterator();
      while (iterator.hasNext()) {
        e e1 = ((WeakReference<e>)iterator.next()).get();
        if (e1 == parame || e1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  public abstract void A(View paramView);
  
  public abstract void B(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public void C(int paramInt) {}
  
  public abstract void D(CharSequence paramCharSequence);
  
  public abstract void c(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public void d(Context paramContext) {}
  
  public abstract <T extends View> T g(int paramInt);
  
  public int i() {
    return -100;
  }
  
  public abstract MenuInflater j();
  
  public abstract a k();
  
  public abstract void l();
  
  public abstract void m();
  
  public abstract void p(Configuration paramConfiguration);
  
  public abstract void q(Bundle paramBundle);
  
  public abstract void r();
  
  public abstract void s(Bundle paramBundle);
  
  public abstract void t();
  
  public abstract void u(Bundle paramBundle);
  
  public abstract void v();
  
  public abstract void w();
  
  public abstract boolean y(int paramInt);
  
  public abstract void z(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\k\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */