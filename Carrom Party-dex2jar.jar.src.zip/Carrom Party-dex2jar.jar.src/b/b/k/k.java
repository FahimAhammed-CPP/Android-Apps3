package b.b.k;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import b.b.f;
import b.b.j;
import b.b.p.g;
import b.b.p.h;
import b.b.p.j.g;
import b.b.q.p;
import b.b.q.z;
import b.h.n.r;
import b.h.n.v;
import b.h.n.w;
import b.h.n.x;
import b.h.n.y;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class k extends a implements ActionBarOverlayLayout.d {
  public static final Interpolator B = (Interpolator)new AccelerateInterpolator();
  
  public static final Interpolator C = (Interpolator)new DecelerateInterpolator();
  
  public final y A;
  
  public Context a;
  
  public Context b;
  
  public ActionBarOverlayLayout c;
  
  public ActionBarContainer d;
  
  public p e;
  
  public ActionBarContextView f;
  
  public View g;
  
  public z h;
  
  public boolean i;
  
  public d j;
  
  public b.b.p.b k;
  
  public b.b.p.b.a l;
  
  public boolean m;
  
  public ArrayList<a.b> n;
  
  public boolean o;
  
  public int p;
  
  public boolean q;
  
  public boolean r;
  
  public boolean s;
  
  public boolean t;
  
  public boolean u;
  
  public h v;
  
  public boolean w;
  
  public boolean x;
  
  public final w y;
  
  public final w z;
  
  public k(Activity paramActivity, boolean paramBoolean) {
    new ArrayList();
    this.n = new ArrayList<a.b>();
    this.p = 0;
    this.q = true;
    this.u = true;
    this.y = (w)new a(this);
    this.z = (w)new b(this);
    this.A = new c(this);
    View view = paramActivity.getWindow().getDecorView();
    C(view);
    if (!paramBoolean)
      this.g = view.findViewById(16908290); 
  }
  
  public k(Dialog paramDialog) {
    new ArrayList();
    this.n = new ArrayList<a.b>();
    this.p = 0;
    this.q = true;
    this.u = true;
    this.y = (w)new a(this);
    this.z = (w)new b(this);
    this.A = new c(this);
    C(paramDialog.getWindow().getDecorView());
  }
  
  public static boolean v(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  public int A() {
    return this.e.m();
  }
  
  public final void B() {
    if (this.t) {
      this.t = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.c;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      L(false);
    } 
  }
  
  public final void C(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.q);
    this.c = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.e = z(paramView.findViewById(f.a));
    this.f = (ActionBarContextView)paramView.findViewById(f.f);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.c);
    this.d = actionBarContainer;
    p p1 = this.e;
    if (p1 != null && this.f != null && actionBarContainer != null) {
      boolean bool;
      this.a = p1.getContext();
      if ((this.e.r() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.i = true; 
      b.b.p.a a1 = b.b.p.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      I(bool);
      G(a1.g());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.a, b.b.a.c, 0);
      if (typedArray.getBoolean(j.k, false))
        H(true); 
      int i = typedArray.getDimensionPixelSize(j.i, 0);
      if (i != 0)
        F(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(k.class.getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void D(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    E(bool, 4);
  }
  
  public void E(int paramInt1, int paramInt2) {
    int i = this.e.r();
    if ((paramInt2 & 0x4) != 0)
      this.i = true; 
    this.e.k(paramInt1 & paramInt2 | (paramInt2 ^ 0xFFFFFFFF) & i);
  }
  
  public void F(float paramFloat) {
    r.S((View)this.d, paramFloat);
  }
  
  public final void G(boolean paramBoolean) {
    this.o = paramBoolean;
    if (!paramBoolean) {
      this.e.i(null);
      this.d.setTabContainer(this.h);
    } else {
      this.d.setTabContainer(null);
      this.e.i(this.h);
    } 
    int i = A();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    z z1 = this.h;
    if (z1 != null) {
      ActionBarOverlayLayout actionBarOverlayLayout1;
      if (i != 0) {
        z1.setVisibility(0);
        actionBarOverlayLayout1 = this.c;
        if (actionBarOverlayLayout1 != null)
          r.M((View)actionBarOverlayLayout1); 
      } else {
        actionBarOverlayLayout1.setVisibility(8);
      } 
    } 
    p p1 = this.e;
    if (!this.o && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    p1.u(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.c;
    if (!this.o && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  public void H(boolean paramBoolean) {
    if (!paramBoolean || this.c.w()) {
      this.x = paramBoolean;
      this.c.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void I(boolean paramBoolean) {
    this.e.q(paramBoolean);
  }
  
  public final boolean J() {
    return r.B((View)this.d);
  }
  
  public final void K() {
    if (!this.t) {
      this.t = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.c;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      L(false);
    } 
  }
  
  public final void L(boolean paramBoolean) {
    if (v(this.r, this.s, this.t)) {
      if (!this.u) {
        this.u = true;
        y(paramBoolean);
        return;
      } 
    } else if (this.u) {
      this.u = false;
      x(paramBoolean);
    } 
  }
  
  public void a() {
    if (this.s) {
      this.s = false;
      L(true);
    } 
  }
  
  public void b() {}
  
  public void c(boolean paramBoolean) {
    this.q = paramBoolean;
  }
  
  public void d() {
    if (!this.s) {
      this.s = true;
      L(true);
    } 
  }
  
  public void e() {
    h h1 = this.v;
    if (h1 != null) {
      h1.a();
      this.v = null;
    } 
  }
  
  public boolean g() {
    p p1 = this.e;
    if (p1 != null && p1.j()) {
      this.e.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void h(boolean paramBoolean) {
    if (paramBoolean == this.m)
      return; 
    this.m = paramBoolean;
    int j = this.n.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.n.get(i)).a(paramBoolean); 
  }
  
  public int i() {
    return this.e.r();
  }
  
  public Context j() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(b.b.a.g, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void l(Configuration paramConfiguration) {
    G(b.b.p.a.b(this.a).g());
  }
  
  public boolean n(int paramInt, KeyEvent paramKeyEvent) {
    d d1 = this.j;
    if (d1 == null)
      return false; 
    Menu menu = d1.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    this.p = paramInt;
  }
  
  public void q(boolean paramBoolean) {
    if (!this.i)
      D(paramBoolean); 
  }
  
  public void r(boolean paramBoolean) {
    this.w = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.v;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void s(CharSequence paramCharSequence) {
    this.e.setWindowTitle(paramCharSequence);
  }
  
  public b.b.p.b t(b.b.p.b.a parama) {
    d d2 = this.j;
    if (d2 != null)
      d2.c(); 
    this.c.setHideOnContentScrollEnabled(false);
    this.f.k();
    d d1 = new d(this, this.f.getContext(), parama);
    if (d1.t()) {
      this.j = d1;
      d1.k();
      this.f.h(d1);
      u(true);
      this.f.sendAccessibilityEvent(32);
      return d1;
    } 
    return null;
  }
  
  public void u(boolean paramBoolean) {
    if (paramBoolean) {
      K();
    } else {
      B();
    } 
    if (J()) {
      v v1;
      v v2;
      if (paramBoolean) {
        v2 = this.e.n(4, 100L);
        v1 = this.f.f(0, 200L);
      } else {
        v1 = this.e.n(0, 200L);
        v2 = this.f.f(8, 100L);
      } 
      h h1 = new h();
      h1.d(v2, v1);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.e.o(4);
      this.f.setVisibility(0);
      return;
    } 
    this.e.o(0);
    this.f.setVisibility(8);
  }
  
  public void w() {
    b.b.p.b.a a1 = this.l;
    if (a1 != null) {
      a1.a(this.k);
      this.k = null;
      this.l = null;
    } 
  }
  
  public void x(boolean paramBoolean) {
    h h1 = this.v;
    if (h1 != null)
      h1.a(); 
    if (this.p == 0 && (this.w || paramBoolean)) {
      this.d.setAlpha(1.0F);
      this.d.setTransitioning(true);
      h1 = new h();
      float f2 = -this.d.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.d.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      v v = r.b((View)this.d);
      v.k(f1);
      v.i(this.A);
      h1.c(v);
      if (this.q) {
        View view = this.g;
        if (view != null) {
          v v1 = r.b(view);
          v1.k(f1);
          h1.c(v1);
        } 
      } 
      h1.f(B);
      h1.e(250L);
      h1.g(this.y);
      this.v = h1;
      h1.h();
      return;
    } 
    this.y.b(null);
  }
  
  public void y(boolean paramBoolean) {
    h h1 = this.v;
    if (h1 != null)
      h1.a(); 
    this.d.setVisibility(0);
    if (this.p == 0 && (this.w || paramBoolean)) {
      this.d.setTranslationY(0.0F);
      float f2 = -this.d.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.d.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.d.setTranslationY(f1);
      h1 = new h();
      v v = r.b((View)this.d);
      v.k(0.0F);
      v.i(this.A);
      h1.c(v);
      if (this.q) {
        View view = this.g;
        if (view != null) {
          view.setTranslationY(f1);
          v v1 = r.b(this.g);
          v1.k(0.0F);
          h1.c(v1);
        } 
      } 
      h1.f(C);
      h1.e(250L);
      h1.g(this.z);
      this.v = h1;
      h1.h();
    } else {
      this.d.setAlpha(1.0F);
      this.d.setTranslationY(0.0F);
      if (this.q) {
        View view = this.g;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.z.b(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.c;
    if (actionBarOverlayLayout != null)
      r.M((View)actionBarOverlayLayout); 
  }
  
  public final p z(View paramView) {
    String str;
    if (paramView instanceof p)
      return (p)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public class a extends x {
    public a(k this$0) {}
    
    public void b(View param1View) {
      k k1 = this.a;
      if (k1.q) {
        View view = k1.g;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.d.setTranslationY(0.0F);
        } 
      } 
      this.a.d.setVisibility(8);
      this.a.d.setTransitioning(false);
      k1 = this.a;
      k1.v = null;
      k1.w();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.c;
      if (actionBarOverlayLayout != null)
        r.M((View)actionBarOverlayLayout); 
    }
  }
  
  public class b extends x {
    public b(k this$0) {}
    
    public void b(View param1View) {
      k k1 = this.a;
      k1.v = null;
      k1.d.requestLayout();
    }
  }
  
  public class c implements y {
    public c(k this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.d.getParent()).invalidate();
    }
  }
  
  public class d extends b.b.p.b implements g.a {
    public final Context c;
    
    public final g d;
    
    public b.b.p.b.a e;
    
    public WeakReference<View> f;
    
    public d(k this$0, Context param1Context, b.b.p.b.a param1a) {
      this.c = param1Context;
      this.e = param1a;
      g g1 = new g(param1Context);
      g1.S(1);
      this.d = g1;
      g1.R(this);
    }
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      b.b.p.b.a a1 = this.e;
      return (a1 != null) ? a1.d(this, param1MenuItem) : false;
    }
    
    public void b(g param1g) {
      if (this.e == null)
        return; 
      k();
      this.g.f.l();
    }
    
    public void c() {
      k k1 = this.g;
      if (k1.j != this)
        return; 
      if (!k.v(k1.r, k1.s, false)) {
        k1 = this.g;
        k1.k = this;
        k1.l = this.e;
      } else {
        this.e.a(this);
      } 
      this.e = null;
      this.g.u(false);
      this.g.f.g();
      this.g.e.p().sendAccessibilityEvent(32);
      k1 = this.g;
      k1.c.setHideOnContentScrollEnabled(k1.x);
      this.g.j = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.f;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.d;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.c);
    }
    
    public CharSequence g() {
      return this.g.f.getSubtitle();
    }
    
    public CharSequence i() {
      return this.g.f.getTitle();
    }
    
    public void k() {
      if (this.g.j != this)
        return; 
      this.d.d0();
      try {
        this.e.c(this, (Menu)this.d);
        return;
      } finally {
        this.d.c0();
      } 
    }
    
    public boolean l() {
      return this.g.f.j();
    }
    
    public void m(View param1View) {
      this.g.f.setCustomView(param1View);
      this.f = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.g.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.g.f.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.g.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.g.f.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.g.f.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.d.d0();
      try {
        return this.e.b(this, (Menu)this.d);
      } finally {
        this.d.c0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\k\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */