package b.b.k;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import b.b.p.b;
import b.b.q.l0;
import b.h.e.a;
import b.h.e.g;
import b.h.e.p;
import b.k.d.d;

public class c extends d implements d, p.a {
  public e n;
  
  public Resources o;
  
  public e A() {
    if (this.n == null)
      this.n = e.e((Activity)this, this); 
    return this.n;
  }
  
  public a B() {
    return A().k();
  }
  
  public void C(p paramp) {
    paramp.b((Activity)this);
  }
  
  public void D(int paramInt) {}
  
  public void E(p paramp) {}
  
  @Deprecated
  public void F() {}
  
  public boolean G() {
    Intent intent = g();
    if (intent != null) {
      if (J(intent)) {
        p p = p.d((Context)this);
        C(p);
        E(p);
        p.i();
        try {
          a.k((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        I((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  public final boolean H(int paramInt, KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  public void I(Intent paramIntent) {
    g.e((Activity)this, paramIntent);
  }
  
  public boolean J(Intent paramIntent) {
    return g.f((Activity)this, paramIntent);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    A().c(paramView, paramLayoutParams);
  }
  
  public void attachBaseContext(Context paramContext) {
    super.attachBaseContext(paramContext);
    A().d(paramContext);
  }
  
  public void closeOptionsMenu() {
    a a1 = B();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.f()))
      super.closeOptionsMenu(); 
  }
  
  public void d(b paramb) {}
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a1 = B();
    return (i == 82 && a1 != null && a1.o(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public void e(b paramb) {}
  
  public <T extends View> T findViewById(int paramInt) {
    return A().g(paramInt);
  }
  
  public Intent g() {
    return g.a((Activity)this);
  }
  
  public MenuInflater getMenuInflater() {
    return A().j();
  }
  
  public Resources getResources() {
    if (this.o == null && l0.b())
      this.o = (Resources)new l0((Context)this, super.getResources()); 
    Resources resources2 = this.o;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public b i(b.a parama) {
    return null;
  }
  
  public void invalidateOptionsMenu() {
    A().m();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (this.o != null) {
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.o.updateConfiguration(paramConfiguration, displayMetrics);
    } 
    A().p(paramConfiguration);
  }
  
  public void onContentChanged() {
    F();
  }
  
  public void onCreate(Bundle paramBundle) {
    e e1 = A();
    e1.l();
    e1.q(paramBundle);
    super.onCreate(paramBundle);
  }
  
  public void onDestroy() {
    super.onDestroy();
    A().r();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return H(paramInt, paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a1 = B();
    return (paramMenuItem.getItemId() == 16908332 && a1 != null && (a1.i() & 0x4) != 0) ? G() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    A().s(paramBundle);
  }
  
  public void onPostResume() {
    super.onPostResume();
    A().t();
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    A().u(paramBundle);
  }
  
  public void onStart() {
    super.onStart();
    A().v();
  }
  
  public void onStop() {
    super.onStop();
    A().w();
  }
  
  public void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    A().D(paramCharSequence);
  }
  
  public void openOptionsMenu() {
    a a1 = B();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.p()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    A().z(paramInt);
  }
  
  public void setContentView(View paramView) {
    A().A(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    A().B(paramView, paramLayoutParams);
  }
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    A().C(paramInt);
  }
  
  public void z() {
    A().m();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\k\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */