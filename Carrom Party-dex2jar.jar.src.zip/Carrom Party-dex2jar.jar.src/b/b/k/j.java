package b.b.k;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;
import b.h.f.c;
import java.util.Calendar;

public class j {
  public static j d;
  
  public final Context a;
  
  public final LocationManager b;
  
  public final a c = new a();
  
  public j(Context paramContext, LocationManager paramLocationManager) {
    this.a = paramContext;
    this.b = paramLocationManager;
  }
  
  public static j a(Context paramContext) {
    if (d == null) {
      paramContext = paramContext.getApplicationContext();
      d = new j(paramContext, (LocationManager)paramContext.getSystemService("location"));
    } 
    return d;
  }
  
  @SuppressLint({"MissingPermission"})
  public final Location b() {
    Location location1;
    int i = c.b(this.a, "android.permission.ACCESS_COARSE_LOCATION");
    Location location2 = null;
    if (i == 0) {
      location1 = c("network");
    } else {
      location1 = null;
    } 
    if (c.b(this.a, "android.permission.ACCESS_FINE_LOCATION") == 0)
      location2 = c("gps"); 
    if (location2 != null && location1 != null) {
      Location location = location1;
      if (location2.getTime() > location1.getTime())
        location = location2; 
      return location;
    } 
    if (location2 != null)
      location1 = location2; 
    return location1;
  }
  
  public final Location c(String paramString) {
    try {
      if (this.b.isProviderEnabled(paramString))
        return this.b.getLastKnownLocation(paramString); 
    } catch (Exception exception) {
      Log.d("TwilightManager", "Failed to get last known location", exception);
    } 
    return null;
  }
  
  public boolean d() {
    a a1 = this.c;
    if (e())
      return a1.a; 
    Location location = b();
    if (location != null) {
      f(location);
      return a1.a;
    } 
    Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
    int i = Calendar.getInstance().get(11);
    return (i < 6 || i >= 22);
  }
  
  public final boolean e() {
    return (this.c.f > System.currentTimeMillis());
  }
  
  public final void f(Location paramLocation) {
    boolean bool;
    a a1 = this.c;
    long l1 = System.currentTimeMillis();
    i i = i.b();
    i.a(l1 - 86400000L, paramLocation.getLatitude(), paramLocation.getLongitude());
    long l2 = i.a;
    i.a(l1, paramLocation.getLatitude(), paramLocation.getLongitude());
    if (i.c == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    long l3 = i.b;
    long l4 = i.a;
    i.a(86400000L + l1, paramLocation.getLatitude(), paramLocation.getLongitude());
    long l5 = i.b;
    if (l3 == -1L || l4 == -1L) {
      l1 = 43200000L + l1;
    } else {
      if (l1 > l4) {
        l1 = 0L + l5;
      } else if (l1 > l3) {
        l1 = 0L + l4;
      } else {
        l1 = 0L + l3;
      } 
      l1 += 60000L;
    } 
    a1.a = bool;
    a1.b = l2;
    a1.c = l3;
    a1.d = l4;
    a1.e = l5;
    a1.f = l1;
  }
  
  public static class a {
    public boolean a;
    
    public long b;
    
    public long c;
    
    public long d;
    
    public long e;
    
    public long f;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\k\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */