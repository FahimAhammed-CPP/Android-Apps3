package b.b.k;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatViewInflater;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import b.b.p.j.g;
import b.b.q.g0;
import b.b.q.l0;
import b.b.q.m0;
import b.b.q.s;
import b.h.n.r;
import b.h.n.v;
import b.h.n.w;
import b.h.n.x;
import b.h.n.z;
import java.util.List;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;

public class f extends e implements g.a, LayoutInflater.Factory2 {
  public static final Map<Class<?>, Integer> l0 = (Map<Class<?>, Integer>)new b.f.a();
  
  public static final boolean m0;
  
  public static final int[] n0 = new int[] { 16842836 };
  
  public static boolean o0;
  
  public static final boolean p0;
  
  public Runnable C;
  
  public v D = null;
  
  public boolean E = true;
  
  public boolean F;
  
  public ViewGroup G;
  
  public TextView H;
  
  public View I;
  
  public boolean J;
  
  public boolean K;
  
  public boolean L;
  
  public boolean M;
  
  public boolean N;
  
  public boolean O;
  
  public boolean P;
  
  public boolean Q;
  
  public o[] R;
  
  public o S;
  
  public boolean T;
  
  public boolean U;
  
  public boolean V;
  
  public boolean W;
  
  public boolean X;
  
  public int Y = -100;
  
  public int Z;
  
  public boolean a0;
  
  public boolean b0;
  
  public l c0;
  
  public final Object d;
  
  public l d0;
  
  public final Context e;
  
  public boolean e0;
  
  public Window f;
  
  public int f0;
  
  public j g;
  
  public final Runnable g0 = new b(this);
  
  public final d h;
  
  public boolean h0;
  
  public a i;
  
  public Rect i0;
  
  public MenuInflater j;
  
  public Rect j0;
  
  public CharSequence k;
  
  public AppCompatViewInflater k0;
  
  public b.b.q.o l;
  
  public h m;
  
  public p n;
  
  public b.b.p.b o;
  
  public ActionBarContextView p;
  
  public PopupWindow q;
  
  static {
    boolean bool2 = bool3;
    if (i >= 21) {
      bool2 = bool3;
      if (i <= 25)
        bool2 = true; 
    } 
    p0 = bool2;
    if (bool1 && !o0) {
      Thread.setDefaultUncaughtExceptionHandler(new a(Thread.getDefaultUncaughtExceptionHandler()));
      o0 = true;
    } 
  }
  
  public f(Activity paramActivity, d paramd) {
    this((Context)paramActivity, null, paramd, paramActivity);
  }
  
  public f(Dialog paramDialog, d paramd) {
    this(paramDialog.getContext(), paramDialog.getWindow(), paramd, paramDialog);
  }
  
  public f(Context paramContext, Window paramWindow, d paramd, Object paramObject) {
    this.e = paramContext;
    this.h = paramd;
    this.d = paramObject;
    if (paramObject instanceof Dialog) {
      c c = F0();
      if (c != null)
        this.Y = c.A().i(); 
    } 
    if (this.Y == -100) {
      Map<Class<?>, Integer> map = l0;
      Integer integer = map.get(paramObject.getClass());
      if (integer != null) {
        this.Y = integer.intValue();
        map.remove(paramObject.getClass());
      } 
    } 
    if (paramWindow != null)
      H(paramWindow); 
    b.b.q.g.h();
  }
  
  public void A(View paramView) {
    U();
    ViewGroup viewGroup = (ViewGroup)this.G.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.g.a().onContentChanged();
  }
  
  public final boolean A0() {
    if (this.F) {
      ViewGroup viewGroup = this.G;
      if (viewGroup != null && r.B((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  public void B(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    U();
    ViewGroup viewGroup = (ViewGroup)this.G.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.g.a().onContentChanged();
  }
  
  public final boolean B0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.f.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (r.A((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  public void C(int paramInt) {
    this.Z = paramInt;
  }
  
  public b.b.p.b C0(b.b.p.b.a parama) {
    if (parama != null) {
      b.b.p.b b1 = this.o;
      if (b1 != null)
        b1.c(); 
      parama = new i(this, parama);
      a a1 = k();
      if (a1 != null) {
        b.b.p.b b2 = a1.t(parama);
        this.o = b2;
        if (b2 != null) {
          d d1 = this.h;
          if (d1 != null)
            d1.d(b2); 
        } 
      } 
      if (this.o == null)
        this.o = D0(parama); 
      return this.o;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  public final void D(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    b.b.q.o o1 = this.l;
    if (o1 != null) {
      o1.setWindowTitle(paramCharSequence);
      return;
    } 
    if (v0() != null) {
      v0().s(paramCharSequence);
      return;
    } 
    TextView textView = this.H;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public b.b.p.b D0(b.b.p.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual T : ()V
    //   4: aload_0
    //   5: getfield o : Lb/b/p/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof b/b/k/f$i
    //   27: ifne -> 41
    //   30: new b/b/k/f$i
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Lb/b/k/f;Lb/b/p/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield h : Lb/b/k/d;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield X : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface i : (Lb/b/p/b$a;)Lb/b/p/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield o : Lb/b/p/b;
    //   80: goto -> 576
    //   83: aload_0
    //   84: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield O : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield e : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic b/b/a.f : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield e : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new b/b/p/d
    //   169: dup
    //   170: aload_0
    //   171: getfield e : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield e : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic b/b/a.i : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield q : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield q : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield q : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic b/b/a.b : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield q : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new b/b/k/f$f
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Lb/b/k/f;)V
    //   309: putfield C : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield G : Landroid/view/ViewGroup;
    //   319: getstatic b/b/f.h : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual X : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 576
    //   362: aload_0
    //   363: invokevirtual T : ()V
    //   366: aload_0
    //   367: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield q : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new b/b/p/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Lb/b/p/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface b : (Lb/b/p/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 571
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Lb/b/p/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield o : Lb/b/p/b;
    //   445: aload_0
    //   446: invokevirtual A0 : ()Z
    //   449: ifeq -> 495
    //   452: aload_0
    //   453: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic b : (Landroid/view/View;)Lb/h/n/v;
    //   467: astore_1
    //   468: aload_1
    //   469: fconst_1
    //   470: invokevirtual a : (F)Lb/h/n/v;
    //   473: pop
    //   474: aload_0
    //   475: aload_1
    //   476: putfield D : Lb/h/n/v;
    //   479: aload_1
    //   480: new b/b/k/f$g
    //   483: dup
    //   484: aload_0
    //   485: invokespecial <init> : (Lb/b/k/f;)V
    //   488: invokevirtual f : (Lb/h/n/w;)Lb/h/n/v;
    //   491: pop
    //   492: goto -> 546
    //   495: aload_0
    //   496: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   499: fconst_1
    //   500: invokevirtual setAlpha : (F)V
    //   503: aload_0
    //   504: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   507: iconst_0
    //   508: invokevirtual setVisibility : (I)V
    //   511: aload_0
    //   512: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   515: bipush #32
    //   517: invokevirtual sendAccessibilityEvent : (I)V
    //   520: aload_0
    //   521: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   524: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   527: instanceof android/view/View
    //   530: ifeq -> 546
    //   533: aload_0
    //   534: getfield p : Landroidx/appcompat/widget/ActionBarContextView;
    //   537: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   540: checkcast android/view/View
    //   543: invokestatic M : (Landroid/view/View;)V
    //   546: aload_0
    //   547: getfield q : Landroid/widget/PopupWindow;
    //   550: ifnull -> 576
    //   553: aload_0
    //   554: getfield f : Landroid/view/Window;
    //   557: invokevirtual getDecorView : ()Landroid/view/View;
    //   560: aload_0
    //   561: getfield C : Ljava/lang/Runnable;
    //   564: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   567: pop
    //   568: goto -> 576
    //   571: aload_0
    //   572: aconst_null
    //   573: putfield o : Lb/b/p/b;
    //   576: aload_0
    //   577: getfield o : Lb/b/p/b;
    //   580: astore_1
    //   581: aload_1
    //   582: ifnull -> 604
    //   585: aload_0
    //   586: getfield h : Lb/b/k/d;
    //   589: astore #4
    //   591: aload #4
    //   593: ifnull -> 604
    //   596: aload #4
    //   598: aload_1
    //   599: invokeinterface d : (Lb/b/p/b;)V
    //   604: aload_0
    //   605: getfield o : Lb/b/p/b;
    //   608: areturn
    //   609: astore_1
    //   610: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	609	java/lang/AbstractMethodError
  }
  
  public boolean E() {
    return F(true);
  }
  
  public final void E0() {
    if (!this.F)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  public final boolean F(boolean paramBoolean) {
    if (this.X)
      return false; 
    int i = I();
    paramBoolean = G0(k0(i), paramBoolean);
    if (i == 0) {
      Z().e();
    } else {
      l l2 = this.c0;
      if (l2 != null)
        l2.a(); 
    } 
    if (i == 3) {
      Y().e();
      return paramBoolean;
    } 
    l l1 = this.d0;
    if (l1 != null)
      l1.a(); 
    return paramBoolean;
  }
  
  public final c F0() {
    Context context = this.e;
    while (context != null) {
      if (context instanceof c)
        return (c)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  public final void G() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.G.findViewById(16908290);
    View view = this.f.getDecorView();
    contentFrameLayout.b(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.e.obtainStyledAttributes(b.b.j.x0);
    typedArray.getValue(b.b.j.J0, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(b.b.j.K0, contentFrameLayout.getMinWidthMinor());
    int i = b.b.j.H0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMajor()); 
    i = b.b.j.I0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedWidthMinor()); 
    i = b.b.j.F0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMajor()); 
    i = b.b.j.G0;
    if (typedArray.hasValue(i))
      typedArray.getValue(i, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  public final boolean G0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroid/content/Context;
    //   4: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   7: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   10: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   13: getfield uiMode : I
    //   16: bipush #48
    //   18: iand
    //   19: istore #4
    //   21: iconst_1
    //   22: istore #7
    //   24: iload_1
    //   25: iconst_1
    //   26: if_icmpeq -> 46
    //   29: iload_1
    //   30: iconst_2
    //   31: if_icmpeq -> 40
    //   34: iload #4
    //   36: istore_3
    //   37: goto -> 49
    //   40: bipush #32
    //   42: istore_3
    //   43: goto -> 49
    //   46: bipush #16
    //   48: istore_3
    //   49: aload_0
    //   50: invokevirtual i0 : ()Z
    //   53: istore #8
    //   55: getstatic b/b/k/f.p0 : Z
    //   58: istore #5
    //   60: iconst_0
    //   61: istore #6
    //   63: iload #5
    //   65: ifne -> 78
    //   68: iload #6
    //   70: istore #5
    //   72: iload_3
    //   73: iload #4
    //   75: if_icmpeq -> 184
    //   78: iload #6
    //   80: istore #5
    //   82: iload #8
    //   84: ifne -> 184
    //   87: iload #6
    //   89: istore #5
    //   91: getstatic android/os/Build$VERSION.SDK_INT : I
    //   94: bipush #17
    //   96: if_icmplt -> 184
    //   99: iload #6
    //   101: istore #5
    //   103: aload_0
    //   104: getfield U : Z
    //   107: ifne -> 184
    //   110: iload #6
    //   112: istore #5
    //   114: aload_0
    //   115: getfield d : Ljava/lang/Object;
    //   118: instanceof android/view/ContextThemeWrapper
    //   121: ifeq -> 184
    //   124: new android/content/res/Configuration
    //   127: dup
    //   128: invokespecial <init> : ()V
    //   131: astore #9
    //   133: aload #9
    //   135: aload #9
    //   137: getfield uiMode : I
    //   140: bipush #-49
    //   142: iand
    //   143: iload_3
    //   144: ior
    //   145: putfield uiMode : I
    //   148: aload_0
    //   149: getfield d : Ljava/lang/Object;
    //   152: checkcast android/view/ContextThemeWrapper
    //   155: aload #9
    //   157: invokevirtual applyOverrideConfiguration : (Landroid/content/res/Configuration;)V
    //   160: iconst_1
    //   161: istore #5
    //   163: goto -> 184
    //   166: astore #9
    //   168: ldc_w 'AppCompatDelegate'
    //   171: ldc_w 'updateForNightMode. Calling applyOverrideConfiguration() failed with an exception. Will fall back to using Resources.updateConfiguration()'
    //   174: aload #9
    //   176: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   179: pop
    //   180: iload #6
    //   182: istore #5
    //   184: aload_0
    //   185: getfield e : Landroid/content/Context;
    //   188: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   191: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   194: getfield uiMode : I
    //   197: bipush #48
    //   199: iand
    //   200: istore #4
    //   202: iload #5
    //   204: istore #6
    //   206: iload #5
    //   208: ifne -> 297
    //   211: iload #5
    //   213: istore #6
    //   215: iload #4
    //   217: iload_3
    //   218: if_icmpeq -> 297
    //   221: iload #5
    //   223: istore #6
    //   225: iload_2
    //   226: ifeq -> 297
    //   229: iload #5
    //   231: istore #6
    //   233: iload #8
    //   235: ifne -> 297
    //   238: iload #5
    //   240: istore #6
    //   242: aload_0
    //   243: getfield U : Z
    //   246: ifeq -> 297
    //   249: getstatic android/os/Build$VERSION.SDK_INT : I
    //   252: bipush #17
    //   254: if_icmpge -> 268
    //   257: iload #5
    //   259: istore #6
    //   261: aload_0
    //   262: getfield V : Z
    //   265: ifeq -> 297
    //   268: aload_0
    //   269: getfield d : Ljava/lang/Object;
    //   272: astore #9
    //   274: iload #5
    //   276: istore #6
    //   278: aload #9
    //   280: instanceof android/app/Activity
    //   283: ifeq -> 297
    //   286: aload #9
    //   288: checkcast android/app/Activity
    //   291: invokestatic l : (Landroid/app/Activity;)V
    //   294: iconst_1
    //   295: istore #6
    //   297: iload #6
    //   299: ifne -> 322
    //   302: iload #4
    //   304: iload_3
    //   305: if_icmpeq -> 322
    //   308: aload_0
    //   309: iload_3
    //   310: iload #8
    //   312: invokevirtual H0 : (IZ)V
    //   315: iload #7
    //   317: istore #6
    //   319: goto -> 322
    //   322: iload #6
    //   324: ifeq -> 350
    //   327: aload_0
    //   328: getfield d : Ljava/lang/Object;
    //   331: astore #9
    //   333: aload #9
    //   335: instanceof b/b/k/c
    //   338: ifeq -> 350
    //   341: aload #9
    //   343: checkcast b/b/k/c
    //   346: iload_1
    //   347: invokevirtual D : (I)V
    //   350: iload #6
    //   352: ireturn
    // Exception table:
    //   from	to	target	type
    //   148	160	166	java/lang/IllegalStateException
  }
  
  public final void H(Window paramWindow) {
    if (this.f == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof j)) {
        j j1 = new j(this, callback);
        this.g = j1;
        paramWindow.setCallback((Window.Callback)j1);
        g0 g0 = g0.s(this.e, null, n0);
        Drawable drawable = g0.g(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        g0.u();
        this.f = paramWindow;
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  public final void H0(int paramInt, boolean paramBoolean) {
    Resources resources = this.e.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    resources.updateConfiguration(configuration, null);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 26)
      h.a(resources); 
    int i = this.Z;
    if (i != 0) {
      this.e.setTheme(i);
      if (paramInt >= 23)
        this.e.getTheme().applyStyle(this.Z, true); 
    } 
    if (paramBoolean) {
      Object object = this.d;
      if (object instanceof Activity) {
        object = object;
        if (object instanceof b.n.g) {
          if (((b.n.g)object).a().b().a(b.n.d.c.d)) {
            object.onConfigurationChanged(configuration);
            return;
          } 
        } else if (this.W) {
          object.onConfigurationChanged(configuration);
        } 
      } 
    } 
  }
  
  public final int I() {
    int i = this.Y;
    return (i != -100) ? i : e.h();
  }
  
  public int I0(int paramInt) {
    int i;
    boolean bool1;
    ActionBarContextView actionBarContextView = this.p;
    boolean bool2 = false;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.p.getLayoutParams();
      boolean bool3 = this.p.isShown();
      i = 1;
      int k = 1;
      if (bool3) {
        if (this.i0 == null) {
          this.i0 = new Rect();
          this.j0 = new Rect();
        } 
        Rect rect1 = this.i0;
        Rect rect2 = this.j0;
        rect1.set(0, paramInt, 0, 0);
        m0.a((View)this.G, rect1, rect2);
        if (rect2.top == 0) {
          bool = paramInt;
        } else {
          bool = false;
        } 
        if (marginLayoutParams.topMargin != bool) {
          marginLayoutParams.topMargin = paramInt;
          View view1 = this.I;
          if (view1 == null) {
            view1 = new View(this.e);
            this.I = view1;
            view1.setBackgroundColor(this.e.getResources().getColor(b.b.c.a));
            this.G.addView(this.I, -1, new ViewGroup.LayoutParams(-1, paramInt));
          } else {
            ViewGroup.LayoutParams layoutParams = view1.getLayoutParams();
            if (layoutParams.height != paramInt) {
              layoutParams.height = paramInt;
              this.I.setLayoutParams(layoutParams);
            } 
          } 
          bool = true;
        } else {
          bool = false;
        } 
        if (this.I == null)
          k = 0; 
        i = paramInt;
        if (!this.N) {
          i = paramInt;
          if (k)
            i = 0; 
        } 
        paramInt = bool;
        bool = k;
        k = paramInt;
        paramInt = i;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
        k = i;
      } else {
        bool = false;
        k = 0;
      } 
      bool1 = bool;
      i = paramInt;
      if (k != 0) {
        this.p.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        bool1 = bool;
        i = paramInt;
      } 
    } else {
      bool1 = false;
      i = paramInt;
    } 
    View view = this.I;
    if (view != null) {
      if (bool1) {
        paramInt = bool2;
      } else {
        paramInt = 8;
      } 
      view.setVisibility(paramInt);
    } 
    return i;
  }
  
  public void J(int paramInt, o paramo, Menu paramMenu) {
    g g;
    o o1 = paramo;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      o o2 = paramo;
      if (paramo == null) {
        o2 = paramo;
        if (paramInt >= 0) {
          o[] arrayOfO = this.R;
          o2 = paramo;
          if (paramInt < arrayOfO.length)
            o2 = arrayOfO[paramInt]; 
        } 
      } 
      o1 = o2;
      menu = paramMenu;
      if (o2 != null) {
        g = o2.j;
        o1 = o2;
      } 
    } 
    if (o1 != null && !o1.o)
      return; 
    if (!this.X)
      this.g.a().onPanelClosed(paramInt, (Menu)g); 
  }
  
  public void K(g paramg) {
    if (this.Q)
      return; 
    this.Q = true;
    this.l.i();
    Window.Callback callback = c0();
    if (callback != null && !this.X)
      callback.onPanelClosed(108, (Menu)paramg); 
    this.Q = false;
  }
  
  public final void L() {
    l l1 = this.c0;
    if (l1 != null)
      l1.a(); 
    l1 = this.d0;
    if (l1 != null)
      l1.a(); 
  }
  
  public void M(int paramInt) {
    N(a0(paramInt, true), true);
  }
  
  public void N(o paramo, boolean paramBoolean) {
    if (paramBoolean && paramo.a == 0) {
      b.b.q.o o1 = this.l;
      if (o1 != null && o1.b()) {
        K(paramo.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.e.getSystemService("window");
    if (windowManager != null && paramo.o) {
      ViewGroup viewGroup = paramo.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          J(paramo.a, paramo, null); 
      } 
    } 
    paramo.m = false;
    paramo.n = false;
    paramo.o = false;
    paramo.h = null;
    paramo.q = true;
    if (this.S == paramo)
      this.S = null; 
  }
  
  public final ViewGroup O() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.e.obtainStyledAttributes(b.b.j.x0);
    int i = b.b.j.C0;
    if (typedArray.hasValue(i)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(b.b.j.L0, false)) {
        y(1);
      } else if (typedArray.getBoolean(i, false)) {
        y(108);
      } 
      if (typedArray.getBoolean(b.b.j.D0, false))
        y(109); 
      if (typedArray.getBoolean(b.b.j.E0, false))
        y(10); 
      this.O = typedArray.getBoolean(b.b.j.y0, false);
      typedArray.recycle();
      V();
      this.f.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.e);
      if (!this.P) {
        if (this.O) {
          viewGroup = (ViewGroup)layoutInflater.inflate(b.b.g.h, null);
          this.M = false;
          this.L = false;
        } else if (this.L) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.e.getTheme().resolveAttribute(b.b.a.f, typedValue, true);
          if (typedValue.resourceId != 0) {
            b.b.p.d d1 = new b.b.p.d(this.e, typedValue.resourceId);
          } else {
            context = this.e;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(b.b.g.r, null);
          b.b.q.o o1 = (b.b.q.o)viewGroup1.findViewById(b.b.f.q);
          this.l = o1;
          o1.setWindowCallback(c0());
          if (this.M)
            this.l.h(109); 
          if (this.J)
            this.l.h(2); 
          viewGroup = viewGroup1;
          if (this.K) {
            this.l.h(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else {
        if (this.N) {
          viewGroup = (ViewGroup)layoutInflater.inflate(b.b.g.q, null);
        } else {
          viewGroup = (ViewGroup)viewGroup.inflate(b.b.g.p, null);
        } 
        if (Build.VERSION.SDK_INT >= 21) {
          r.V((View)viewGroup, new c(this));
        } else {
          ((s)viewGroup).setOnFitSystemWindowsListener(new d(this));
        } 
      } 
      if (viewGroup != null) {
        if (this.l == null)
          this.H = (TextView)viewGroup.findViewById(b.b.f.S); 
        m0.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(b.b.f.b);
        ViewGroup viewGroup1 = (ViewGroup)this.f.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.f.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new e(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.L);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.M);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.O);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.N);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.P);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    IllegalStateException illegalStateException = new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
    throw illegalStateException;
  }
  
  public View P(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    AppCompatViewInflater appCompatViewInflater = this.k0;
    boolean bool1 = false;
    if (appCompatViewInflater == null) {
      String str = this.e.obtainStyledAttributes(b.b.j.x0).getString(b.b.j.B0);
      if (str == null || AppCompatViewInflater.class.getName().equals(str)) {
        this.k0 = new AppCompatViewInflater();
      } else {
        try {
          this.k0 = Class.forName(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), exception);
        } 
      } 
    } 
    boolean bool2 = m0;
    if (bool2) {
      if (paramAttributeSet instanceof XmlPullParser) {
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = B0((ViewParent)paramView);
      } 
    } else {
      bool1 = false;
    } 
    return this.k0.q(paramView, paramString, paramContext, paramAttributeSet, bool1, bool2, true, l0.b());
  }
  
  public void Q() {
    b.b.q.o o2 = this.l;
    if (o2 != null)
      o2.i(); 
    if (this.q != null) {
      this.f.getDecorView().removeCallbacks(this.C);
      if (this.q.isShowing())
        try {
          this.q.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.q = null;
    } 
    T();
    o o1 = a0(0, false);
    if (o1 != null) {
      g g = o1.j;
      if (g != null)
        g.close(); 
    } 
  }
  
  public boolean R(KeyEvent paramKeyEvent) {
    Object object = this.d;
    boolean bool1 = object instanceof b.h.n.e.a;
    boolean bool = true;
    if (bool1 || object instanceof g) {
      object = this.f.getDecorView();
      if (object != null && b.h.n.e.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.g.a().dispatchKeyEvent(paramKeyEvent))
      return true; 
    int i = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? m0(i, paramKeyEvent) : p0(i, paramKeyEvent);
  }
  
  public void S(int paramInt) {
    o o1 = a0(paramInt, true);
    if (o1.j != null) {
      Bundle bundle = new Bundle();
      o1.j.Q(bundle);
      if (bundle.size() > 0)
        o1.s = bundle; 
      o1.j.d0();
      o1.j.clear();
    } 
    o1.r = true;
    o1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.l != null) {
      o1 = a0(0, false);
      if (o1 != null) {
        o1.m = false;
        x0(o1, null);
      } 
    } 
  }
  
  public void T() {
    v v1 = this.D;
    if (v1 != null)
      v1.b(); 
  }
  
  public final void U() {
    if (!this.F) {
      this.G = O();
      CharSequence charSequence = b0();
      if (!TextUtils.isEmpty(charSequence)) {
        b.b.q.o o2 = this.l;
        if (o2 != null) {
          o2.setWindowTitle(charSequence);
        } else if (v0() != null) {
          v0().s(charSequence);
        } else {
          TextView textView = this.H;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      G();
      t0(this.G);
      this.F = true;
      o o1 = a0(0, false);
      if (!this.X && (o1 == null || o1.j == null))
        h0(108); 
    } 
  }
  
  public final void V() {
    if (this.f == null) {
      Object object = this.d;
      if (object instanceof Activity)
        H(((Activity)object).getWindow()); 
    } 
    if (this.f != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  public o W(Menu paramMenu) {
    byte b1;
    o[] arrayOfO = this.R;
    int i = 0;
    if (arrayOfO != null) {
      b1 = arrayOfO.length;
    } else {
      b1 = 0;
    } 
    while (i < b1) {
      o o1 = arrayOfO[i];
      if (o1 != null && o1.j == paramMenu)
        return o1; 
      i++;
    } 
    return null;
  }
  
  public final Context X() {
    Context context;
    a a1 = k();
    if (a1 != null) {
      Context context1 = a1.j();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.e; 
    return context;
  }
  
  public final l Y() {
    if (this.d0 == null)
      this.d0 = new k(this, this.e); 
    return this.d0;
  }
  
  public final l Z() {
    if (this.c0 == null)
      this.c0 = new m(this, j.a(this.e)); 
    return this.c0;
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    Window.Callback callback = c0();
    if (callback != null && !this.X) {
      o o1 = W((Menu)paramg.D());
      if (o1 != null)
        return callback.onMenuItemSelected(o1.a, paramMenuItem); 
    } 
    return false;
  }
  
  public o a0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield R : [Lb/b/k/f$o;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray b/b/k/f$o
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield R : [Lb/b/k/f$o;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new b/b/k/f$o
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  public void b(g paramg) {
    y0(paramg, true);
  }
  
  public final CharSequence b0() {
    Object object = this.d;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.k;
  }
  
  public void c(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    U();
    ((ViewGroup)this.G.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.g.a().onContentChanged();
  }
  
  public final Window.Callback c0() {
    return this.f.getCallback();
  }
  
  public void d(Context paramContext) {
    F(false);
    this.U = true;
  }
  
  public final void d0() {
    U();
    if (this.L) {
      if (this.i != null)
        return; 
      Object object = this.d;
      if (object instanceof Activity) {
        this.i = new k((Activity)this.d, this.M);
      } else if (object instanceof Dialog) {
        this.i = new k((Dialog)this.d);
      } 
      object = this.i;
      if (object != null)
        object.q(this.h0); 
    } 
  }
  
  public final boolean e0(o paramo) {
    View view = paramo.i;
    if (view != null) {
      paramo.h = view;
      return true;
    } 
    if (paramo.j == null)
      return false; 
    if (this.n == null)
      this.n = new p(this); 
    view = (View)paramo.a(this.n);
    paramo.h = view;
    return (view != null);
  }
  
  public final boolean f0(o paramo) {
    paramo.d(X());
    paramo.g = (ViewGroup)new n(this, paramo.l);
    paramo.c = 81;
    return true;
  }
  
  public <T extends View> T g(int paramInt) {
    U();
    return (T)this.f.findViewById(paramInt);
  }
  
  public final boolean g0(o paramo) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield l : Lb/b/q/o;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic b/b/a.f : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aconst_null
    //   63: astore_3
    //   64: aload #6
    //   66: getfield resourceId : I
    //   69: ifeq -> 111
    //   72: aload #5
    //   74: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   77: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   80: astore_3
    //   81: aload_3
    //   82: aload #7
    //   84: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   87: aload_3
    //   88: aload #6
    //   90: getfield resourceId : I
    //   93: iconst_1
    //   94: invokevirtual applyStyle : (IZ)V
    //   97: aload_3
    //   98: getstatic b/b/a.g : I
    //   101: aload #6
    //   103: iconst_1
    //   104: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   107: pop
    //   108: goto -> 123
    //   111: aload #7
    //   113: getstatic b/b/a.g : I
    //   116: aload #6
    //   118: iconst_1
    //   119: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   122: pop
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new b/b/p/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new b/b/p/j/g
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual R : (Lb/b/p/j/g$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Lb/b/p/j/g;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  public final void h0(int paramInt) {
    this.f0 = 1 << paramInt | this.f0;
    if (!this.e0) {
      r.K(this.f.getDecorView(), this.g0);
      this.e0 = true;
    } 
  }
  
  public int i() {
    return this.Y;
  }
  
  public final boolean i0() {
    if (!this.b0 && this.d instanceof Activity) {
      PackageManager packageManager = this.e.getPackageManager();
      if (packageManager == null)
        return false; 
      try {
        boolean bool;
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(this.e, this.d.getClass()), 0);
        if (activityInfo != null && (activityInfo.configChanges & 0x200) != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.a0 = bool;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        this.a0 = false;
      } 
    } 
    this.b0 = true;
    return this.a0;
  }
  
  public MenuInflater j() {
    if (this.j == null) {
      Context context;
      d0();
      a a1 = this.i;
      if (a1 != null) {
        context = a1.j();
      } else {
        context = this.e;
      } 
      this.j = (MenuInflater)new b.b.p.g(context);
    } 
    return this.j;
  }
  
  public boolean j0() {
    return this.E;
  }
  
  public a k() {
    d0();
    return this.i;
  }
  
  public int k0(int paramInt) {
    if (paramInt != -100) {
      int i = paramInt;
      if (paramInt != -1)
        if (paramInt != 0) {
          i = paramInt;
          if (paramInt != 1) {
            i = paramInt;
            if (paramInt != 2) {
              if (paramInt == 3)
                return Y().c(); 
              throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
            } 
          } 
        } else {
          if (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)this.e.getSystemService(UiModeManager.class)).getNightMode() == 0)
            return -1; 
          i = Z().c();
        }  
      return i;
    } 
    return -1;
  }
  
  public void l() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.e);
    if (layoutInflater.getFactory() == null) {
      b.h.n.f.b(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof f))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  public boolean l0() {
    b.b.p.b b1 = this.o;
    if (b1 != null) {
      b1.c();
      return true;
    } 
    a a1 = k();
    return (a1 != null && a1.g());
  }
  
  public void m() {
    a a1 = k();
    if (a1 != null && a1.k())
      return; 
    h0(0);
  }
  
  public boolean m0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      n0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.T = bool;
    return false;
  }
  
  public final boolean n0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      o o1 = a0(paramInt, true);
      if (!o1.o)
        return x0(o1, paramKeyEvent); 
    } 
    return false;
  }
  
  public boolean o0(int paramInt, KeyEvent paramKeyEvent) {
    o o1;
    a a1 = k();
    if (a1 != null && a1.n(paramInt, paramKeyEvent))
      return true; 
    o o2 = this.S;
    if (o2 != null && w0(o2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      o1 = this.S;
      if (o1 != null)
        o1.n = true; 
      return true;
    } 
    if (this.S == null) {
      o2 = a0(0, true);
      x0(o2, (KeyEvent)o1);
      boolean bool = w0(o2, o1.getKeyCode(), (KeyEvent)o1, 1);
      o2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return P(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void p(Configuration paramConfiguration) {
    if (this.L && this.F) {
      a a1 = k();
      if (a1 != null)
        a1.l(paramConfiguration); 
    } 
    b.b.q.g.b().g(this.e);
    F(false);
  }
  
  public boolean p0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      q0(0, paramKeyEvent);
      return true;
    } 
    boolean bool = this.T;
    this.T = false;
    o o1 = a0(0, false);
    if (o1 != null && o1.o) {
      if (!bool)
        N(o1, true); 
      return true;
    } 
    return l0();
  }
  
  public void q(Bundle paramBundle) {
    this.U = true;
    F(false);
    V();
    Object object = this.d;
    if (object instanceof Activity) {
      Object object1;
      paramBundle = null;
      try {
        object = b.h.e.g.c((Activity)object);
        object1 = object;
      } catch (IllegalArgumentException illegalArgumentException) {}
      if (object1 != null) {
        object1 = v0();
        if (object1 == null) {
          this.h0 = true;
        } else {
          object1.q(true);
        } 
      } 
    } 
    this.V = true;
  }
  
  public final boolean q0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Lb/b/p/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual a0 : (IZ)Lb/b/k/f$o;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield l : Lb/b/q/o;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface d : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield e : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield l : Lb/b/q/o;
    //   62: invokeinterface b : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield X : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokevirtual x0 : (Lb/b/k/f$o;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield l : Lb/b/q/o;
    //   91: invokeinterface g : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield l : Lb/b/q/o;
    //   104: invokeinterface f : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokevirtual x0 : (Lb/b/k/f$o;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokevirtual u0 : (Lb/b/k/f$o;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual N : (Lb/b/k/f$o;Z)V
    //   198: iload_3
    //   199: ifeq -> 237
    //   202: aload_0
    //   203: getfield e : Landroid/content/Context;
    //   206: ldc_w 'audio'
    //   209: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   212: checkcast android/media/AudioManager
    //   215: astore_2
    //   216: aload_2
    //   217: ifnull -> 227
    //   220: aload_2
    //   221: iconst_0
    //   222: invokevirtual playSoundEffect : (I)V
    //   225: iload_3
    //   226: ireturn
    //   227: ldc_w 'AppCompatDelegate'
    //   230: ldc_w 'Couldn't get audio manager'
    //   233: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   236: pop
    //   237: iload_3
    //   238: ireturn
  }
  
  public void r() {
    e.o(this);
    if (this.e0)
      this.f.getDecorView().removeCallbacks(this.g0); 
    this.W = false;
    this.X = true;
    a a1 = this.i;
    if (a1 != null)
      a1.m(); 
    L();
  }
  
  public void r0(int paramInt) {
    if (paramInt == 108) {
      a a1 = k();
      if (a1 != null)
        a1.h(true); 
    } 
  }
  
  public void s(Bundle paramBundle) {
    U();
  }
  
  public void s0(int paramInt) {
    if (paramInt == 108) {
      a a1 = k();
      if (a1 != null) {
        a1.h(false);
        return;
      } 
    } else if (paramInt == 0) {
      o o1 = a0(paramInt, true);
      if (o1.o)
        N(o1, false); 
    } 
  }
  
  public void t() {
    a a1 = k();
    if (a1 != null)
      a1.r(true); 
  }
  
  public void t0(ViewGroup paramViewGroup) {}
  
  public void u(Bundle paramBundle) {
    if (this.Y != -100)
      l0.put(this.d.getClass(), Integer.valueOf(this.Y)); 
  }
  
  public final void u0(o paramo, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 397
    //   7: aload_0
    //   8: getfield X : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield e : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual c0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Lb/b/p/j/g;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual N : (Lb/b/k/f$o;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield e : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokevirtual x0 : (Lb/b/k/f$o;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 329
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 329
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 329
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 332
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokevirtual f0 : (Lb/b/k/f$o;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokevirtual e0 : (Lb/b/k/f$o;)Z
    //   217: ifeq -> 397
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 228
    //   227: return
    //   228: aload_1
    //   229: getfield h : Landroid/view/View;
    //   232: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   235: astore #4
    //   237: aload #4
    //   239: astore_2
    //   240: aload #4
    //   242: ifnonnull -> 257
    //   245: new android/view/ViewGroup$LayoutParams
    //   248: dup
    //   249: bipush #-2
    //   251: bipush #-2
    //   253: invokespecial <init> : (II)V
    //   256: astore_2
    //   257: aload_1
    //   258: getfield b : I
    //   261: istore_3
    //   262: aload_1
    //   263: getfield g : Landroid/view/ViewGroup;
    //   266: iload_3
    //   267: invokevirtual setBackgroundResource : (I)V
    //   270: aload_1
    //   271: getfield h : Landroid/view/View;
    //   274: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   277: astore #4
    //   279: aload #4
    //   281: instanceof android/view/ViewGroup
    //   284: ifeq -> 299
    //   287: aload #4
    //   289: checkcast android/view/ViewGroup
    //   292: aload_1
    //   293: getfield h : Landroid/view/View;
    //   296: invokevirtual removeView : (Landroid/view/View;)V
    //   299: aload_1
    //   300: getfield g : Landroid/view/ViewGroup;
    //   303: aload_1
    //   304: getfield h : Landroid/view/View;
    //   307: aload_2
    //   308: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   311: aload_1
    //   312: getfield h : Landroid/view/View;
    //   315: invokevirtual hasFocus : ()Z
    //   318: ifne -> 329
    //   321: aload_1
    //   322: getfield h : Landroid/view/View;
    //   325: invokevirtual requestFocus : ()Z
    //   328: pop
    //   329: bipush #-2
    //   331: istore_3
    //   332: aload_1
    //   333: iconst_0
    //   334: putfield n : Z
    //   337: new android/view/WindowManager$LayoutParams
    //   340: dup
    //   341: iload_3
    //   342: bipush #-2
    //   344: aload_1
    //   345: getfield d : I
    //   348: aload_1
    //   349: getfield e : I
    //   352: sipush #1002
    //   355: ldc_w 8519680
    //   358: bipush #-3
    //   360: invokespecial <init> : (IIIIIII)V
    //   363: astore_2
    //   364: aload_2
    //   365: aload_1
    //   366: getfield c : I
    //   369: putfield gravity : I
    //   372: aload_2
    //   373: aload_1
    //   374: getfield f : I
    //   377: putfield windowAnimations : I
    //   380: aload #5
    //   382: aload_1
    //   383: getfield g : Landroid/view/ViewGroup;
    //   386: aload_2
    //   387: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   392: aload_1
    //   393: iconst_1
    //   394: putfield o : Z
    //   397: return
  }
  
  public void v() {
    this.W = true;
    E();
    e.n(this);
  }
  
  public final a v0() {
    return this.i;
  }
  
  public void w() {
    this.W = false;
    e.o(this);
    a a1 = k();
    if (a1 != null)
      a1.r(false); 
    if (this.d instanceof Dialog)
      L(); 
  }
  
  public final boolean w0(o paramo, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokevirtual x0 : (Lb/b/k/f$o;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Lb/b/p/j/g;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield l : Lb/b/q/o;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual N : (Lb/b/k/f$o;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  public final boolean x0(o paramo, KeyEvent paramKeyEvent) {
    b.b.q.o o1;
    if (this.X)
      return false; 
    if (paramo.m)
      return true; 
    o o2 = this.S;
    if (o2 != null && o2 != paramo)
      N(o2, false); 
    Window.Callback callback = c0();
    if (callback != null)
      paramo.i = callback.onCreatePanelView(paramo.a); 
    int i = paramo.a;
    if (i == 0 || i == 108) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      b.b.q.o o3 = this.l;
      if (o3 != null)
        o3.c(); 
    } 
    if (paramo.i == null) {
      b.b.q.o o3;
      boolean bool;
      if (i != 0)
        v0(); 
      g g = paramo.j;
      if (g == null || paramo.r) {
        if (g == null && (!g0(paramo) || paramo.j == null))
          return false; 
        if (i != 0) {
          b.b.q.o o4 = this.l;
          if (o4 != null) {
            if (this.m == null)
              this.m = new h(this); 
            o4.a((Menu)paramo.j, this.m);
          } 
        } 
        paramo.j.d0();
        if (!callback.onCreatePanelMenu(paramo.a, (Menu)paramo.j)) {
          paramo.c(null);
          if (i != 0) {
            o1 = this.l;
            if (o1 != null)
              o1.a(null, this.m); 
          } 
          return false;
        } 
        ((o)o1).r = false;
      } 
      ((o)o1).j.d0();
      Bundle bundle = ((o)o1).s;
      if (bundle != null) {
        ((o)o1).j.P(bundle);
        ((o)o1).s = null;
      } 
      if (!callback.onPreparePanel(0, ((o)o1).i, (Menu)((o)o1).j)) {
        if (i != 0) {
          o3 = this.l;
          if (o3 != null)
            o3.a(null, this.m); 
        } 
        ((o)o1).j.c0();
        return false;
      } 
      if (o3 != null) {
        i = o3.getDeviceId();
      } else {
        i = -1;
      } 
      if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((o)o1).p = bool;
      ((o)o1).j.setQwertyMode(bool);
      ((o)o1).j.c0();
    } 
    ((o)o1).m = true;
    ((o)o1).n = false;
    this.S = (o)o1;
    return true;
  }
  
  public boolean y(int paramInt) {
    paramInt = z0(paramInt);
    if (this.P && paramInt == 108)
      return false; 
    if (this.L && paramInt == 1)
      this.L = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.f.requestFeature(paramInt); 
              E0();
              this.M = true;
              return true;
            } 
            E0();
            this.L = true;
            return true;
          } 
          E0();
          this.N = true;
          return true;
        } 
        E0();
        this.K = true;
        return true;
      } 
      E0();
      this.J = true;
      return true;
    } 
    E0();
    this.P = true;
    return true;
  }
  
  public final void y0(g paramg, boolean paramBoolean) {
    b.b.q.o o2 = this.l;
    if (o2 != null && o2.d() && (!ViewConfiguration.get(this.e).hasPermanentMenuKey() || this.l.e())) {
      Window.Callback callback = c0();
      if (!this.l.b() || !paramBoolean) {
        if (callback != null && !this.X) {
          if (this.e0 && (this.f0 & 0x1) != 0) {
            this.f.getDecorView().removeCallbacks(this.g0);
            this.g0.run();
          } 
          o o3 = a0(0, true);
          g g1 = o3.j;
          if (g1 != null && !o3.r && callback.onPreparePanel(0, o3.i, (Menu)g1)) {
            callback.onMenuOpened(108, (Menu)o3.j);
            this.l.g();
          } 
        } 
        return;
      } 
      this.l.f();
      if (!this.X) {
        callback.onPanelClosed(108, (Menu)(a0(0, true)).j);
        return;
      } 
      return;
    } 
    o o1 = a0(0, true);
    o1.q = true;
    N(o1, false);
    u0(o1, null);
  }
  
  public void z(int paramInt) {
    U();
    ViewGroup viewGroup = (ViewGroup)this.G.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.e).inflate(paramInt, viewGroup);
    this.g.a().onContentChanged();
  }
  
  public final int z0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int i = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      i = 109;
    } 
    return i;
  }
  
  static {
    boolean bool1;
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    boolean bool3 = false;
    if (i < 21) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    m0 = bool1;
  }
  
  public static final class a implements Thread.UncaughtExceptionHandler {
    public a(Thread.UncaughtExceptionHandler param1UncaughtExceptionHandler) {}
    
    public final boolean a(Throwable param1Throwable) {
      boolean bool1 = param1Throwable instanceof Resources.NotFoundException;
      boolean bool = false;
      null = bool;
      if (bool1) {
        String str = param1Throwable.getMessage();
        null = bool;
        if (str != null) {
          if (!str.contains("drawable")) {
            null = bool;
            return str.contains("Drawable") ? true : null;
          } 
        } else {
          return null;
        } 
      } else {
        return null;
      } 
      return true;
    }
    
    public void uncaughtException(Thread param1Thread, Throwable param1Throwable) {
      if (a(param1Throwable)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(param1Throwable.getMessage());
        stringBuilder.append(". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
        Resources.NotFoundException notFoundException = new Resources.NotFoundException(stringBuilder.toString());
        notFoundException.initCause(param1Throwable.getCause());
        notFoundException.setStackTrace(param1Throwable.getStackTrace());
        this.a.uncaughtException(param1Thread, (Throwable)notFoundException);
        return;
      } 
      this.a.uncaughtException(param1Thread, param1Throwable);
    }
  }
  
  public class b implements Runnable {
    public b(f this$0) {}
    
    public void run() {
      f f1 = this.a;
      if ((f1.f0 & 0x1) != 0)
        f1.S(0); 
      f1 = this.a;
      if ((f1.f0 & 0x1000) != 0)
        f1.S(108); 
      f1 = this.a;
      f1.e0 = false;
      f1.f0 = 0;
    }
  }
  
  public class c implements b.h.n.o {
    public c(f this$0) {}
    
    public z a(View param1View, z param1z) {
      int i = param1z.k();
      int j = this.a.I0(i);
      z z1 = param1z;
      if (i != j)
        z1 = param1z.m(param1z.i(), j, param1z.j(), param1z.h()); 
      return r.G(param1View, z1);
    }
  }
  
  public class d implements s.a {
    public d(f this$0) {}
    
    public void a(Rect param1Rect) {
      param1Rect.top = this.a.I0(param1Rect.top);
    }
  }
  
  public class e implements ContentFrameLayout.a {
    public e(f this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.Q();
    }
  }
  
  public class f implements Runnable {
    public f(f this$0) {}
    
    public void run() {
      f f1 = this.a;
      f1.q.showAtLocation((View)f1.p, 55, 0, 0);
      this.a.T();
      if (this.a.A0()) {
        this.a.p.setAlpha(0.0F);
        f1 = this.a;
        v v = r.b((View)f1.p);
        v.a(1.0F);
        f1.D = v;
        this.a.D.f((w)new a(this));
        return;
      } 
      this.a.p.setAlpha(1.0F);
      this.a.p.setVisibility(0);
    }
    
    public class a extends x {
      public a(f.f this$0) {}
      
      public void b(View param2View) {
        this.a.a.p.setAlpha(1.0F);
        this.a.a.D.f(null);
        this.a.a.D = null;
      }
      
      public void c(View param2View) {
        this.a.a.p.setVisibility(0);
      }
    }
  }
  
  public class a extends x {
    public a(f this$0) {}
    
    public void b(View param1View) {
      this.a.a.p.setAlpha(1.0F);
      this.a.a.D.f(null);
      this.a.a.D = null;
    }
    
    public void c(View param1View) {
      this.a.a.p.setVisibility(0);
    }
  }
  
  public class g extends x {
    public g(f this$0) {}
    
    public void b(View param1View) {
      this.a.p.setAlpha(1.0F);
      this.a.D.f(null);
      this.a.D = null;
    }
    
    public void c(View param1View) {
      this.a.p.setVisibility(0);
      this.a.p.sendAccessibilityEvent(32);
      if (this.a.p.getParent() instanceof View)
        r.M((View)this.a.p.getParent()); 
    }
  }
  
  public final class h implements b.b.p.j.m.a {
    public h(f this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      this.a.K(param1g);
    }
    
    public boolean c(g param1g) {
      Window.Callback callback = this.a.c0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1g); 
      return true;
    }
  }
  
  public class i implements b.b.p.b.a {
    public b.b.p.b.a a;
    
    public i(f this$0, b.b.p.b.a param1a) {
      this.a = param1a;
    }
    
    public void a(b.b.p.b param1b) {
      this.a.a(param1b);
      f f1 = this.b;
      if (f1.q != null)
        f1.f.getDecorView().removeCallbacks(this.b.C); 
      f1 = this.b;
      if (f1.p != null) {
        f1.T();
        f1 = this.b;
        v v = r.b((View)f1.p);
        v.a(0.0F);
        f1.D = v;
        this.b.D.f((w)new a(this));
      } 
      f1 = this.b;
      d d = f1.h;
      if (d != null)
        d.e(f1.o); 
      this.b.o = null;
    }
    
    public boolean b(b.b.p.b param1b, Menu param1Menu) {
      return this.a.b(param1b, param1Menu);
    }
    
    public boolean c(b.b.p.b param1b, Menu param1Menu) {
      return this.a.c(param1b, param1Menu);
    }
    
    public boolean d(b.b.p.b param1b, MenuItem param1MenuItem) {
      return this.a.d(param1b, param1MenuItem);
    }
    
    public class a extends x {
      public a(f.i this$0) {}
      
      public void b(View param2View) {
        this.a.b.p.setVisibility(8);
        f f = this.a.b;
        PopupWindow popupWindow = f.q;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (f.p.getParent() instanceof View) {
          r.M((View)this.a.b.p.getParent());
        } 
        this.a.b.p.removeAllViews();
        this.a.b.D.f(null);
        this.a.b.D = null;
      }
    }
  }
  
  public class a extends x {
    public a(f this$0) {}
    
    public void b(View param1View) {
      this.a.b.p.setVisibility(8);
      f f = this.a.b;
      PopupWindow popupWindow = f.q;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (f.p.getParent() instanceof View) {
        r.M((View)this.a.b.p.getParent());
      } 
      this.a.b.p.removeAllViews();
      this.a.b.D.f(null);
      this.a.b.D = null;
    }
  }
  
  public class j extends b.b.p.i {
    public j(f this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public final ActionMode b(ActionMode.Callback param1Callback) {
      b.b.p.f.a a = new b.b.p.f.a(this.b.e, param1Callback);
      b.b.p.b b = this.b.C0((b.b.p.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.b.R(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.b.o0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    public void onContentChanged() {}
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof g)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.b.r0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      super.onPanelClosed(param1Int, param1Menu);
      this.b.s0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      g g;
      if (param1Menu instanceof g) {
        g = (g)param1Menu;
      } else {
        g = null;
      } 
      if (param1Int == 0 && g == null)
        return false; 
      if (g != null)
        g.a0(true); 
      boolean bool = super.onPreparePanel(param1Int, param1View, param1Menu);
      if (g != null)
        g.a0(false); 
      return bool;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      f.o o = this.b.a0(0, true);
      if (o != null) {
        g g = o.j;
        if (g != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)g, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.b.j0() ? b(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.b.j0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : b(param1Callback);
    }
  }
  
  public class k extends l {
    public final PowerManager c;
    
    public k(f this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getSystemService("power");
    }
    
    public IntentFilter b() {
      if (Build.VERSION.SDK_INT >= 21) {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
        return intentFilter;
      } 
      return null;
    }
    
    public int c() {
      int i = Build.VERSION.SDK_INT;
      byte b2 = 1;
      byte b1 = b2;
      if (i >= 21) {
        b1 = b2;
        if (this.c.isPowerSaveMode())
          b1 = 2; 
      } 
      return b1;
    }
    
    public void d() {
      this.d.E();
    }
  }
  
  public abstract class l {
    public BroadcastReceiver a;
    
    public l(f this$0) {}
    
    public void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.e.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    public abstract IntentFilter b();
    
    public abstract int c();
    
    public abstract void d();
    
    public void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.e.registerReceiver(this.a, intentFilter);
      } 
    }
    
    public class a extends BroadcastReceiver {
      public a(f.l this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  public class a extends BroadcastReceiver {
    public a(f this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  public class m extends l {
    public final j c;
    
    public m(f this$0, j param1j) {
      super(this$0);
      this.c = param1j;
    }
    
    public IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.E();
    }
  }
  
  public class n extends ContentFrameLayout {
    public n(f this$0, Context param1Context) {
      super(param1Context);
    }
    
    public final boolean c(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.i.R(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && c((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.i.M(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(b.b.l.a.a.d(getContext(), param1Int));
    }
  }
  
  public static final class o {
    public int a;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public ViewGroup g;
    
    public View h;
    
    public View i;
    
    public g j;
    
    public b.b.p.j.e k;
    
    public Context l;
    
    public boolean m;
    
    public boolean n;
    
    public boolean o;
    
    public boolean p;
    
    public boolean q;
    
    public boolean r;
    
    public Bundle s;
    
    public o(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    public b.b.p.j.n a(b.b.p.j.m.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        b.b.p.j.e e1 = new b.b.p.j.e(this.l, b.b.g.l);
        this.k = e1;
        e1.g(param1a);
        this.j.b((b.b.p.j.m)this.k);
      } 
      return this.k.i(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    public void c(g param1g) {
      g g1 = this.j;
      if (param1g == g1)
        return; 
      if (g1 != null)
        g1.O((b.b.p.j.m)this.k); 
      this.j = param1g;
      if (param1g != null) {
        b.b.p.j.e e1 = this.k;
        if (e1 != null)
          param1g.b((b.b.p.j.m)e1); 
      } 
    }
    
    public void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(b.b.a.a, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(b.b.a.E, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(b.b.i.b, true);
      } 
      b.b.p.d d = new b.b.p.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(b.b.j.x0);
      this.b = typedArray.getResourceId(b.b.j.A0, 0);
      this.f = typedArray.getResourceId(b.b.j.z0, 0);
      typedArray.recycle();
    }
  }
  
  public final class p implements b.b.p.j.m.a {
    public p(f this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {
      boolean bool;
      g g1 = param1g.D();
      if (g1 != param1g) {
        bool = true;
      } else {
        bool = false;
      } 
      f f1 = this.a;
      if (bool)
        param1g = g1; 
      f.o o = f1.W((Menu)param1g);
      if (o != null) {
        if (bool) {
          this.a.J(o.a, o, (Menu)g1);
          this.a.N(o, true);
          return;
        } 
        this.a.N(o, param1Boolean);
      } 
    }
    
    public boolean c(g param1g) {
      if (param1g == null) {
        f f1 = this.a;
        if (f1.L) {
          Window.Callback callback = f1.c0();
          if (callback != null && !this.a.X)
            callback.onMenuOpened(108, (Menu)param1g); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\k\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */