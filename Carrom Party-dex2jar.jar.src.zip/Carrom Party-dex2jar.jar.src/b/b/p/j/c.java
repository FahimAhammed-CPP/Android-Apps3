package b.b.p.j;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import b.f.a;
import b.h.h.a.b;
import java.util.Iterator;
import java.util.Map;

public abstract class c {
  public final Context a;
  
  public Map<b, MenuItem> b;
  
  public Map<b.h.h.a.c, SubMenu> c;
  
  public c(Context paramContext) {
    this.a = paramContext;
  }
  
  public final MenuItem c(MenuItem paramMenuItem) {
    MenuItem menuItem = paramMenuItem;
    if (paramMenuItem instanceof b) {
      b b = (b)paramMenuItem;
      if (this.b == null)
        this.b = (Map<b, MenuItem>)new a(); 
      paramMenuItem = this.b.get(paramMenuItem);
      menuItem = paramMenuItem;
      if (paramMenuItem == null) {
        menuItem = new j(this.a, b);
        this.b.put(b, menuItem);
      } 
    } 
    return menuItem;
  }
  
  public final SubMenu d(SubMenu paramSubMenu) {
    if (paramSubMenu instanceof b.h.h.a.c) {
      b.h.h.a.c c1 = (b.h.h.a.c)paramSubMenu;
      if (this.c == null)
        this.c = (Map<b.h.h.a.c, SubMenu>)new a(); 
      SubMenu subMenu = this.c.get(c1);
      paramSubMenu = subMenu;
      if (subMenu == null) {
        paramSubMenu = new s(this.a, c1);
        this.c.put(c1, paramSubMenu);
      } 
      return paramSubMenu;
    } 
    return paramSubMenu;
  }
  
  public final void e() {
    Map<b, MenuItem> map1 = this.b;
    if (map1 != null)
      map1.clear(); 
    Map<b.h.h.a.c, SubMenu> map = this.c;
    if (map != null)
      map.clear(); 
  }
  
  public final void f(int paramInt) {
    Map<b, MenuItem> map = this.b;
    if (map == null)
      return; 
    Iterator<MenuItem> iterator = map.keySet().iterator();
    while (iterator.hasNext()) {
      if (paramInt == ((MenuItem)iterator.next()).getGroupId())
        iterator.remove(); 
    } 
  }
  
  public final void g(int paramInt) {
    Map<b, MenuItem> map = this.b;
    if (map == null)
      return; 
    Iterator<MenuItem> iterator = map.keySet().iterator();
    while (iterator.hasNext()) {
      if (paramInt == ((MenuItem)iterator.next()).getItemId()) {
        iterator.remove();
        break;
      } 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\p\j\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */