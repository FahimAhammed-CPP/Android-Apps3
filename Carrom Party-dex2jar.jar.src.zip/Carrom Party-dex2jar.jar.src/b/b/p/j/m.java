package b.b.p.j;

import android.content.Context;

public interface m {
  void b(g paramg, boolean paramBoolean);
  
  void c(boolean paramBoolean);
  
  boolean d();
  
  boolean e(g paramg, i parami);
  
  boolean f(g paramg, i parami);
  
  void g(a parama);
  
  void h(Context paramContext, g paramg);
  
  boolean j(r paramr);
  
  public static interface a {
    void b(g param1g, boolean param1Boolean);
    
    boolean c(g param1g);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\p\j\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */