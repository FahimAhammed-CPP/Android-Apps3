package b.b.p.j;

import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import b.b.d;
import b.b.g;
import b.b.q.v;
import b.h.n.r;

public final class q extends k implements PopupWindow.OnDismissListener, AdapterView.OnItemClickListener, m, View.OnKeyListener {
  public static final int G = g.o;
  
  public boolean C;
  
  public int D;
  
  public int E = 0;
  
  public boolean F;
  
  public final Context b;
  
  public final g c;
  
  public final f d;
  
  public final boolean e;
  
  public final int f;
  
  public final int g;
  
  public final int h;
  
  public final v i;
  
  public final ViewTreeObserver.OnGlobalLayoutListener j = new a(this);
  
  public final View.OnAttachStateChangeListener k = new b(this);
  
  public PopupWindow.OnDismissListener l;
  
  public View m;
  
  public View n;
  
  public m.a o;
  
  public ViewTreeObserver p;
  
  public boolean q;
  
  public q(Context paramContext, g paramg, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.b = paramContext;
    this.c = paramg;
    this.e = paramBoolean;
    this.d = new f(paramg, LayoutInflater.from(paramContext), paramBoolean, G);
    this.g = paramInt1;
    this.h = paramInt2;
    Resources resources = paramContext.getResources();
    this.f = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.m = paramView;
    this.i = new v(paramContext, null, paramInt1, paramInt2);
    paramg.c(this, paramContext);
  }
  
  public boolean a() {
    return (!this.q && this.i.a());
  }
  
  public void b(g paramg, boolean paramBoolean) {
    if (paramg != this.c)
      return; 
    dismiss();
    m.a a1 = this.o;
    if (a1 != null)
      a1.b(paramg, paramBoolean); 
  }
  
  public void c(boolean paramBoolean) {
    this.C = false;
    f f1 = this.d;
    if (f1 != null)
      f1.notifyDataSetChanged(); 
  }
  
  public boolean d() {
    return false;
  }
  
  public void dismiss() {
    if (a())
      this.i.dismiss(); 
  }
  
  public void g(m.a parama) {
    this.o = parama;
  }
  
  public ListView i() {
    return this.i.i();
  }
  
  public boolean j(r paramr) {
    if (paramr.hasVisibleItems()) {
      l l = new l(this.b, paramr, this.n, this.e, this.g, this.h);
      l.j(this.o);
      l.g(k.w(paramr));
      l.i(this.l);
      this.l = null;
      this.c.e(false);
      int j = this.i.b();
      int n = this.i.n();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.E, r.q(this.m)) & 0x7) == 5)
        i = j + this.m.getWidth(); 
      if (l.n(i, n)) {
        m.a a1 = this.o;
        if (a1 != null)
          a1.c(paramr); 
        return true;
      } 
    } 
    return false;
  }
  
  public void k(g paramg) {}
  
  public void o(View paramView) {
    this.m = paramView;
  }
  
  public void onDismiss() {
    this.q = true;
    this.c.close();
    ViewTreeObserver viewTreeObserver = this.p;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.p = this.n.getViewTreeObserver(); 
      this.p.removeGlobalOnLayoutListener(this.j);
      this.p = null;
    } 
    this.n.removeOnAttachStateChangeListener(this.k);
    PopupWindow.OnDismissListener onDismissListener = this.l;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void q(boolean paramBoolean) {
    this.d.d(paramBoolean);
  }
  
  public void r(int paramInt) {
    this.E = paramInt;
  }
  
  public void s(int paramInt) {
    this.i.d(paramInt);
  }
  
  public void show() {
    if (y())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void t(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.l = paramOnDismissListener;
  }
  
  public void u(boolean paramBoolean) {
    this.F = paramBoolean;
  }
  
  public void v(int paramInt) {
    this.i.k(paramInt);
  }
  
  public final boolean y() {
    if (a())
      return true; 
    if (!this.q) {
      boolean bool;
      View view = this.m;
      if (view == null)
        return false; 
      this.n = view;
      this.i.F(this);
      this.i.G(this);
      this.i.E(true);
      view = this.n;
      if (this.p == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.p = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.j); 
      view.addOnAttachStateChangeListener(this.k);
      this.i.y(view);
      this.i.B(this.E);
      if (!this.C) {
        this.D = k.n((ListAdapter)this.d, null, this.b, this.f);
        this.C = true;
      } 
      this.i.A(this.D);
      this.i.D(2);
      this.i.C(m());
      this.i.show();
      ListView listView = this.i.i();
      listView.setOnKeyListener(this);
      if (this.F && this.c.x() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.b).inflate(g.n, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.c.x()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.i.o((ListAdapter)this.d);
      this.i.show();
      return true;
    } 
    return false;
  }
  
  public class a implements ViewTreeObserver.OnGlobalLayoutListener {
    public a(q this$0) {}
    
    public void onGlobalLayout() {
      if (this.a.a() && !this.a.i.w()) {
        View view = this.a.n;
        if (view == null || !view.isShown()) {
          this.a.dismiss();
          return;
        } 
        this.a.i.show();
        return;
      } 
    }
  }
  
  public class b implements View.OnAttachStateChangeListener {
    public b(q this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.a.p;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.a.p = param1View.getViewTreeObserver(); 
        q q1 = this.a;
        q1.p.removeGlobalOnLayoutListener(q1.j);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\p\j\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */