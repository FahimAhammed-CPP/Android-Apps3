package b.b.p;

public interface c {
  void c();
  
  void d();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\p\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */