package b.b.p;

import android.view.View;
import android.view.animation.Interpolator;
import b.h.n.v;
import b.h.n.w;
import b.h.n.x;
import java.util.ArrayList;
import java.util.Iterator;

public class h {
  public final ArrayList<v> a = new ArrayList<v>();
  
  public long b = -1L;
  
  public Interpolator c;
  
  public w d;
  
  public boolean e;
  
  public final x f = new a(this);
  
  public void a() {
    if (!this.e)
      return; 
    Iterator<v> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((v)iterator.next()).b(); 
    this.e = false;
  }
  
  public void b() {
    this.e = false;
  }
  
  public h c(v paramv) {
    if (!this.e)
      this.a.add(paramv); 
    return this;
  }
  
  public h d(v paramv1, v paramv2) {
    this.a.add(paramv1);
    paramv2.h(paramv1.c());
    this.a.add(paramv2);
    return this;
  }
  
  public h e(long paramLong) {
    if (!this.e)
      this.b = paramLong; 
    return this;
  }
  
  public h f(Interpolator paramInterpolator) {
    if (!this.e)
      this.c = paramInterpolator; 
    return this;
  }
  
  public h g(w paramw) {
    if (!this.e)
      this.d = paramw; 
    return this;
  }
  
  public void h() {
    if (this.e)
      return; 
    for (v v : this.a) {
      long l = this.b;
      if (l >= 0L)
        v.d(l); 
      Interpolator interpolator = this.c;
      if (interpolator != null)
        v.e(interpolator); 
      if (this.d != null)
        v.f((w)this.f); 
      v.j();
    } 
    this.e = true;
  }
  
  public class a extends x {
    public boolean a = false;
    
    public int b = 0;
    
    public a(h this$0) {}
    
    public void b(View param1View) {
      int i = this.b + 1;
      this.b = i;
      if (i == this.c.a.size()) {
        w w = this.c.d;
        if (w != null)
          w.b(null); 
        d();
      } 
    }
    
    public void c(View param1View) {
      if (this.a)
        return; 
      this.a = true;
      w w = this.c.d;
      if (w != null)
        w.c(null); 
    }
    
    public void d() {
      this.b = 0;
      this.a = false;
      this.c.b();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\p\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */