package b.b.n;

public final class b {
  public static final int[] a = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
  
  public static final int b = 0;
  
  public static final int c = 1;
  
  public static final int d = 2;
  
  public static final int e = 3;
  
  public static final int f = 4;
  
  public static final int g = 5;
  
  public static final int[] h = new int[] { 16842960, 16843161 };
  
  public static final int i = 0;
  
  public static final int j = 1;
  
  public static final int[] k = new int[] { 16843161, 16843849, 16843850, 16843851 };
  
  public static final int l = 0;
  
  public static final int m = 1;
  
  public static final int n = 2;
  
  public static final int o = 3;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\b\n\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */