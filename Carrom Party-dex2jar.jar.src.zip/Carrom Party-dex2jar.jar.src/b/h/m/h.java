package b.h.m;

import java.util.Objects;

public final class h {
  public static int a(int paramInt) {
    if (paramInt >= 0)
      return paramInt; 
    throw new IllegalArgumentException();
  }
  
  public static <T> T b(T paramT) {
    Objects.requireNonNull(paramT);
    return paramT;
  }
  
  public static <T> T c(T paramT, Object paramObject) {
    if (paramT != null)
      return paramT; 
    throw new NullPointerException(String.valueOf(paramObject));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\m\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */