package b.h.o;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.ImageView;

public class e {
  public static ColorStateList a(ImageView paramImageView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramImageView.getImageTintList() : ((paramImageView instanceof l) ? ((l)paramImageView).getSupportImageTintList() : null);
  }
  
  public static PorterDuff.Mode b(ImageView paramImageView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramImageView.getImageTintMode() : ((paramImageView instanceof l) ? ((l)paramImageView).getSupportImageTintMode() : null);
  }
  
  public static void c(ImageView paramImageView, ColorStateList paramColorStateList) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      paramImageView.setImageTintList(paramColorStateList);
      if (i == 21) {
        drawable = paramImageView.getDrawable();
        if (drawable != null && paramImageView.getImageTintList() != null) {
          if (drawable.isStateful())
            drawable.setState(paramImageView.getDrawableState()); 
          paramImageView.setImageDrawable(drawable);
          return;
        } 
      } 
    } else if (paramImageView instanceof l) {
      ((l)paramImageView).setSupportImageTintList((ColorStateList)drawable);
    } 
  }
  
  public static void d(ImageView paramImageView, PorterDuff.Mode paramMode) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      paramImageView.setImageTintMode(paramMode);
      if (i == 21) {
        drawable = paramImageView.getDrawable();
        if (drawable != null && paramImageView.getImageTintList() != null) {
          if (drawable.isStateful())
            drawable.setState(paramImageView.getDrawableState()); 
          paramImageView.setImageDrawable(drawable);
          return;
        } 
      } 
    } else if (paramImageView instanceof l) {
      ((l)paramImageView).setSupportImageTintMode((PorterDuff.Mode)drawable);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\o\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */