package b.h.o;

import android.os.Build;

public interface b {
  public static final boolean r;
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 27) {
      bool = true;
    } else {
      bool = false;
    } 
    r = bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\o\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */