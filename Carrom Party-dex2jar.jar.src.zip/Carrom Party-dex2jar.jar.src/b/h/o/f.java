package b.h.o;

import android.view.View;
import android.widget.ListView;

public class f extends a {
  public final ListView D;
  
  public f(ListView paramListView) {
    super((View)paramListView);
    this.D = paramListView;
  }
  
  public boolean a(int paramInt) {
    return false;
  }
  
  public boolean b(int paramInt) {
    ListView listView = this.D;
    int i = listView.getCount();
    if (i == 0)
      return false; 
    int j = listView.getChildCount();
    int k = listView.getFirstVisiblePosition();
    if (paramInt > 0) {
      if (k + j >= i && listView.getChildAt(j - 1).getBottom() <= listView.getHeight())
        return false; 
    } else {
      return (paramInt < 0) ? (!(k <= 0 && listView.getChildAt(0).getTop() >= 0)) : false;
    } 
    return true;
  }
  
  public void j(int paramInt1, int paramInt2) {
    g.a(this.D, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\o\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */