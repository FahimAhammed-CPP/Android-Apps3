package b.h.o;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public interface j {
  void setSupportButtonTintList(ColorStateList paramColorStateList);
  
  void setSupportButtonTintMode(PorterDuff.Mode paramMode);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\o\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */