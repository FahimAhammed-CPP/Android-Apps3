package b.h.o;

import android.content.res.Resources;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import b.h.n.r;

public abstract class a implements View.OnTouchListener {
  public static final int C = ViewConfiguration.getTapTimeout();
  
  public final a a = new a();
  
  public final Interpolator b = (Interpolator)new AccelerateInterpolator();
  
  public final View c;
  
  public Runnable d;
  
  public float[] e = new float[] { 0.0F, 0.0F };
  
  public float[] f = new float[] { Float.MAX_VALUE, Float.MAX_VALUE };
  
  public int g;
  
  public int h;
  
  public float[] i = new float[] { 0.0F, 0.0F };
  
  public float[] j = new float[] { 0.0F, 0.0F };
  
  public float[] k = new float[] { Float.MAX_VALUE, Float.MAX_VALUE };
  
  public boolean l;
  
  public boolean m;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public boolean q;
  
  public a(View paramView) {
    this.c = paramView;
    float f = (Resources.getSystem().getDisplayMetrics()).density;
    int i = (int)(1575.0F * f + 0.5F);
    int j = (int)(f * 315.0F + 0.5F);
    f = i;
    o(f, f);
    f = j;
    p(f, f);
    l(1);
    n(Float.MAX_VALUE, Float.MAX_VALUE);
    s(0.2F, 0.2F);
    t(1.0F, 1.0F);
    k(C);
    r(500);
    q(500);
  }
  
  public static float e(float paramFloat1, float paramFloat2, float paramFloat3) {
    return (paramFloat1 > paramFloat3) ? paramFloat3 : ((paramFloat1 < paramFloat2) ? paramFloat2 : paramFloat1);
  }
  
  public static int f(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 > paramInt3) ? paramInt3 : ((paramInt1 < paramInt2) ? paramInt2 : paramInt1);
  }
  
  public abstract boolean a(int paramInt);
  
  public abstract boolean b(int paramInt);
  
  public void c() {
    long l = SystemClock.uptimeMillis();
    MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
    this.c.onTouchEvent(motionEvent);
    motionEvent.recycle();
  }
  
  public final float d(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
    paramFloat1 = h(this.e[paramInt], paramFloat2, this.f[paramInt], paramFloat1);
    if (paramFloat1 == 0.0F)
      return 0.0F; 
    float f2 = this.i[paramInt];
    paramFloat2 = this.j[paramInt];
    float f1 = this.k[paramInt];
    paramFloat3 = f2 * paramFloat3;
    return (paramFloat1 > 0.0F) ? e(paramFloat1 * paramFloat3, paramFloat2, f1) : -e(-paramFloat1 * paramFloat3, paramFloat2, f1);
  }
  
  public final float g(float paramFloat1, float paramFloat2) {
    if (paramFloat2 == 0.0F)
      return 0.0F; 
    int i = this.g;
    if (i != 0 && i != 1) {
      if (i != 2)
        return 0.0F; 
      if (paramFloat1 < 0.0F)
        return paramFloat1 / -paramFloat2; 
    } else if (paramFloat1 < paramFloat2) {
      if (paramFloat1 >= 0.0F)
        return 1.0F - paramFloat1 / paramFloat2; 
      if (this.o && i == 1)
        return 1.0F; 
    } 
    return 0.0F;
  }
  
  public final float h(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    paramFloat1 = e(paramFloat1 * paramFloat2, 0.0F, paramFloat3);
    paramFloat3 = g(paramFloat4, paramFloat1);
    paramFloat1 = g(paramFloat2 - paramFloat4, paramFloat1) - paramFloat3;
    if (paramFloat1 < 0.0F) {
      paramFloat1 = -this.b.getInterpolation(-paramFloat1);
    } else {
      if (paramFloat1 > 0.0F) {
        paramFloat1 = this.b.getInterpolation(paramFloat1);
        return e(paramFloat1, -1.0F, 1.0F);
      } 
      return 0.0F;
    } 
    return e(paramFloat1, -1.0F, 1.0F);
  }
  
  public final void i() {
    if (this.m) {
      this.o = false;
      return;
    } 
    this.a.i();
  }
  
  public abstract void j(int paramInt1, int paramInt2);
  
  public a k(int paramInt) {
    this.h = paramInt;
    return this;
  }
  
  public a l(int paramInt) {
    this.g = paramInt;
    return this;
  }
  
  public a m(boolean paramBoolean) {
    if (this.p && !paramBoolean)
      i(); 
    this.p = paramBoolean;
    return this;
  }
  
  public a n(float paramFloat1, float paramFloat2) {
    float[] arrayOfFloat = this.f;
    arrayOfFloat[0] = paramFloat1;
    arrayOfFloat[1] = paramFloat2;
    return this;
  }
  
  public a o(float paramFloat1, float paramFloat2) {
    float[] arrayOfFloat = this.k;
    arrayOfFloat[0] = paramFloat1 / 1000.0F;
    arrayOfFloat[1] = paramFloat2 / 1000.0F;
    return this;
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield p : Z
    //   4: istore #6
    //   6: iconst_0
    //   7: istore #7
    //   9: iload #6
    //   11: ifne -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_2
    //   17: invokevirtual getActionMasked : ()I
    //   20: istore #5
    //   22: iload #5
    //   24: ifeq -> 55
    //   27: iload #5
    //   29: iconst_1
    //   30: if_icmpeq -> 48
    //   33: iload #5
    //   35: iconst_2
    //   36: if_icmpeq -> 65
    //   39: iload #5
    //   41: iconst_3
    //   42: if_icmpeq -> 48
    //   45: goto -> 140
    //   48: aload_0
    //   49: invokevirtual i : ()V
    //   52: goto -> 140
    //   55: aload_0
    //   56: iconst_1
    //   57: putfield n : Z
    //   60: aload_0
    //   61: iconst_0
    //   62: putfield l : Z
    //   65: aload_0
    //   66: iconst_0
    //   67: aload_2
    //   68: invokevirtual getX : ()F
    //   71: aload_1
    //   72: invokevirtual getWidth : ()I
    //   75: i2f
    //   76: aload_0
    //   77: getfield c : Landroid/view/View;
    //   80: invokevirtual getWidth : ()I
    //   83: i2f
    //   84: invokevirtual d : (IFFF)F
    //   87: fstore_3
    //   88: aload_0
    //   89: iconst_1
    //   90: aload_2
    //   91: invokevirtual getY : ()F
    //   94: aload_1
    //   95: invokevirtual getHeight : ()I
    //   98: i2f
    //   99: aload_0
    //   100: getfield c : Landroid/view/View;
    //   103: invokevirtual getHeight : ()I
    //   106: i2f
    //   107: invokevirtual d : (IFFF)F
    //   110: fstore #4
    //   112: aload_0
    //   113: getfield a : Lb/h/o/a$a;
    //   116: fload_3
    //   117: fload #4
    //   119: invokevirtual l : (FF)V
    //   122: aload_0
    //   123: getfield o : Z
    //   126: ifne -> 140
    //   129: aload_0
    //   130: invokevirtual u : ()Z
    //   133: ifeq -> 140
    //   136: aload_0
    //   137: invokevirtual v : ()V
    //   140: iload #7
    //   142: istore #6
    //   144: aload_0
    //   145: getfield q : Z
    //   148: ifeq -> 165
    //   151: iload #7
    //   153: istore #6
    //   155: aload_0
    //   156: getfield o : Z
    //   159: ifeq -> 165
    //   162: iconst_1
    //   163: istore #6
    //   165: iload #6
    //   167: ireturn
  }
  
  public a p(float paramFloat1, float paramFloat2) {
    float[] arrayOfFloat = this.j;
    arrayOfFloat[0] = paramFloat1 / 1000.0F;
    arrayOfFloat[1] = paramFloat2 / 1000.0F;
    return this;
  }
  
  public a q(int paramInt) {
    this.a.j(paramInt);
    return this;
  }
  
  public a r(int paramInt) {
    this.a.k(paramInt);
    return this;
  }
  
  public a s(float paramFloat1, float paramFloat2) {
    float[] arrayOfFloat = this.e;
    arrayOfFloat[0] = paramFloat1;
    arrayOfFloat[1] = paramFloat2;
    return this;
  }
  
  public a t(float paramFloat1, float paramFloat2) {
    float[] arrayOfFloat = this.i;
    arrayOfFloat[0] = paramFloat1 / 1000.0F;
    arrayOfFloat[1] = paramFloat2 / 1000.0F;
    return this;
  }
  
  public boolean u() {
    a a1 = this.a;
    int i = a1.f();
    int j = a1.d();
    return ((i != 0 && b(i)) || (j != 0 && a(j)));
  }
  
  public final void v() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ljava/lang/Runnable;
    //   4: ifnonnull -> 19
    //   7: aload_0
    //   8: new b/h/o/a$b
    //   11: dup
    //   12: aload_0
    //   13: invokespecial <init> : (Lb/h/o/a;)V
    //   16: putfield d : Ljava/lang/Runnable;
    //   19: aload_0
    //   20: iconst_1
    //   21: putfield o : Z
    //   24: aload_0
    //   25: iconst_1
    //   26: putfield m : Z
    //   29: aload_0
    //   30: getfield l : Z
    //   33: ifne -> 61
    //   36: aload_0
    //   37: getfield h : I
    //   40: istore_1
    //   41: iload_1
    //   42: ifle -> 61
    //   45: aload_0
    //   46: getfield c : Landroid/view/View;
    //   49: aload_0
    //   50: getfield d : Ljava/lang/Runnable;
    //   53: iload_1
    //   54: i2l
    //   55: invokestatic L : (Landroid/view/View;Ljava/lang/Runnable;J)V
    //   58: goto -> 70
    //   61: aload_0
    //   62: getfield d : Ljava/lang/Runnable;
    //   65: invokeinterface run : ()V
    //   70: aload_0
    //   71: iconst_1
    //   72: putfield l : Z
    //   75: return
  }
  
  public static class a {
    public int a;
    
    public int b;
    
    public float c;
    
    public float d;
    
    public long e = Long.MIN_VALUE;
    
    public long f = 0L;
    
    public int g = 0;
    
    public int h = 0;
    
    public long i = -1L;
    
    public float j;
    
    public int k;
    
    public void a() {
      if (this.f != 0L) {
        long l1 = AnimationUtils.currentAnimationTimeMillis();
        float f = g(e(l1));
        long l2 = this.f;
        this.f = l1;
        f = (float)(l1 - l2) * f;
        this.g = (int)(this.c * f);
        this.h = (int)(f * this.d);
        return;
      } 
      throw new RuntimeException("Cannot compute scroll delta before calling start()");
    }
    
    public int b() {
      return this.g;
    }
    
    public int c() {
      return this.h;
    }
    
    public int d() {
      float f = this.c;
      return (int)(f / Math.abs(f));
    }
    
    public final float e(long param1Long) {
      long l1 = this.e;
      if (param1Long < l1)
        return 0.0F; 
      long l2 = this.i;
      if (l2 < 0L || param1Long < l2)
        return a.e((float)(param1Long - l1) / this.a, 0.0F, 1.0F) * 0.5F; 
      float f = this.j;
      return 1.0F - f + f * a.e((float)(param1Long - l2) / this.k, 0.0F, 1.0F);
    }
    
    public int f() {
      float f = this.d;
      return (int)(f / Math.abs(f));
    }
    
    public final float g(float param1Float) {
      return -4.0F * param1Float * param1Float + param1Float * 4.0F;
    }
    
    public boolean h() {
      return (this.i > 0L && AnimationUtils.currentAnimationTimeMillis() > this.i + this.k);
    }
    
    public void i() {
      long l = AnimationUtils.currentAnimationTimeMillis();
      this.k = a.f((int)(l - this.e), 0, this.b);
      this.j = e(l);
      this.i = l;
    }
    
    public void j(int param1Int) {
      this.b = param1Int;
    }
    
    public void k(int param1Int) {
      this.a = param1Int;
    }
    
    public void l(float param1Float1, float param1Float2) {
      this.c = param1Float1;
      this.d = param1Float2;
    }
    
    public void m() {
      long l = AnimationUtils.currentAnimationTimeMillis();
      this.e = l;
      this.i = -1L;
      this.f = l;
      this.j = 0.5F;
      this.g = 0;
      this.h = 0;
    }
  }
  
  public class b implements Runnable {
    public b(a this$0) {}
    
    public void run() {
      a a2 = this.a;
      if (!a2.o)
        return; 
      if (a2.m) {
        a2.m = false;
        a2.a.m();
      } 
      a.a a1 = this.a.a;
      if (a1.h() || !this.a.u()) {
        this.a.o = false;
        return;
      } 
      a a3 = this.a;
      if (a3.n) {
        a3.n = false;
        a3.c();
      } 
      a1.a();
      int i = a1.b();
      int j = a1.c();
      this.a.j(i, j);
      r.K(this.a.c, this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\o\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */