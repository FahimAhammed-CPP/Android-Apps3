package b.h.j;

public class i extends RuntimeException {}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\j\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */