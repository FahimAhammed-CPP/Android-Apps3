package b.h.j;

import java.util.Locale;

public interface g {
  Object a();
  
  Locale get(int paramInt);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\j\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */