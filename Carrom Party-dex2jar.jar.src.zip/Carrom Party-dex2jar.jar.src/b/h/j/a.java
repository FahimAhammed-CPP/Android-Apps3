package b.h.j;

import android.os.Build;

public class a {
  public static boolean a(String paramString1, String paramString2) {
    boolean bool1 = "REL".equals(paramString2);
    boolean bool = false;
    if (bool1)
      return false; 
    if (paramString2.compareTo(paramString1) >= 0)
      bool = true; 
    return bool;
  }
  
  @Deprecated
  public static boolean b() {
    return (Build.VERSION.SDK_INT >= 30);
  }
  
  public static boolean c() {
    return (Build.VERSION.SDK_INT >= 31 || a("S", Build.VERSION.CODENAME));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\j\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */