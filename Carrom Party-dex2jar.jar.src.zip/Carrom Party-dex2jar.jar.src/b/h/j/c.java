package b.h.j;

import android.content.res.Configuration;
import android.os.Build;
import java.util.Locale;

public final class c {
  public static e a(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? e.d(paramConfiguration.getLocales()) : e.a(new Locale[] { paramConfiguration.locale });
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\j\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */