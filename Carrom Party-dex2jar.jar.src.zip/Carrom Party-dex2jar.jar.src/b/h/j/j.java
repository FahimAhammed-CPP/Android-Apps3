package b.h.j;

import android.content.Context;
import android.os.Build;
import android.os.UserManager;

public class j {
  public static boolean a(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? ((UserManager)paramContext.getSystemService(UserManager.class)).isUserUnlocked() : true;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\j\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */