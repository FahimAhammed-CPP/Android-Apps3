package b.h.j;

import android.os.LocaleList;
import java.util.Locale;

public final class h implements g {
  public final LocaleList a;
  
  public h(LocaleList paramLocaleList) {
    this.a = paramLocaleList;
  }
  
  public Object a() {
    return this.a;
  }
  
  public boolean equals(Object paramObject) {
    return this.a.equals(((g)paramObject).a());
  }
  
  public Locale get(int paramInt) {
    return this.a.get(paramInt);
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    return this.a.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\j\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */