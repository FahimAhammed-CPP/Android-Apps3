package b.h.j;

import android.os.Build;
import android.os.LocaleList;
import java.util.Locale;

public final class e {
  public g a;
  
  static {
    a(new Locale[0]);
  }
  
  public e(g paramg) {
    this.a = paramg;
  }
  
  public static e a(Locale... paramVarArgs) {
    return (Build.VERSION.SDK_INT >= 24) ? d(new LocaleList(paramVarArgs)) : new e(new f(paramVarArgs));
  }
  
  public static Locale b(String paramString) {
    if (paramString.contains("-")) {
      String[] arrayOfString = paramString.split("-", -1);
      if (arrayOfString.length > 2)
        return new Locale(arrayOfString[0], arrayOfString[1], arrayOfString[2]); 
      if (arrayOfString.length > 1)
        return new Locale(arrayOfString[0], arrayOfString[1]); 
      if (arrayOfString.length == 1)
        return new Locale(arrayOfString[0]); 
    } else {
      if (paramString.contains("_")) {
        String[] arrayOfString = paramString.split("_", -1);
        if (arrayOfString.length > 2)
          return new Locale(arrayOfString[0], arrayOfString[1], arrayOfString[2]); 
        if (arrayOfString.length > 1)
          return new Locale(arrayOfString[0], arrayOfString[1]); 
        if (arrayOfString.length == 1)
          return new Locale(arrayOfString[0]); 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Can not parse language tag: [");
        stringBuilder1.append(paramString);
        stringBuilder1.append("]");
        throw new IllegalArgumentException(stringBuilder1.toString());
      } 
      return new Locale(paramString);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can not parse language tag: [");
    stringBuilder.append(paramString);
    stringBuilder.append("]");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static e d(LocaleList paramLocaleList) {
    return new e(new h(paramLocaleList));
  }
  
  public Locale c(int paramInt) {
    return this.a.get(paramInt);
  }
  
  public boolean equals(Object paramObject) {
    return (paramObject instanceof e && this.a.equals(((e)paramObject).a));
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    return this.a.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\j\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */