package b.h;

public final class c {
  public static final int a = 2131296263;
  
  public static final int b = 2131296509;
  
  public static final int c = 2131296510;
  
  public static final int d = 2131296511;
  
  public static final int e = 2131296512;
  
  public static final int f = 2131296513;
  
  public static final int g = 2131296516;
  
  public static final int h = 2131296517;
  
  public static final int i = 2131296518;
  
  public static final int j = 2131296519;
  
  public static final int k = 2131296520;
  
  public static final int l = 2131296521;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */