package b.h.n;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

public class z {
  public final l a;
  
  static {
    if (Build.VERSION.SDK_INT >= 30) {
      z z2 = k.r;
      return;
    } 
    z z1 = l.b;
  }
  
  public z(WindowInsets paramWindowInsets) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 30) {
      this.a = new k(this, paramWindowInsets);
      return;
    } 
    if (i >= 29) {
      this.a = new j(this, paramWindowInsets);
      return;
    } 
    if (i >= 28) {
      this.a = new i(this, paramWindowInsets);
      return;
    } 
    if (i >= 21) {
      this.a = new h(this, paramWindowInsets);
      return;
    } 
    if (i >= 20) {
      this.a = new g(this, paramWindowInsets);
      return;
    } 
    this.a = new l(this);
  }
  
  public z(z paramz) {
    if (paramz != null) {
      l l1 = paramz.a;
      int i = Build.VERSION.SDK_INT;
      if (i >= 30 && l1 instanceof k) {
        this.a = new k(this, (k)l1);
      } else if (i >= 29 && l1 instanceof j) {
        this.a = new j(this, (j)l1);
      } else if (i >= 28 && l1 instanceof i) {
        this.a = new i(this, (i)l1);
      } else if (i >= 21 && l1 instanceof h) {
        this.a = new h(this, (h)l1);
      } else if (i >= 20 && l1 instanceof g) {
        this.a = new g(this, (g)l1);
      } else {
        this.a = new l(this);
      } 
      l1.e(this);
      return;
    } 
    this.a = new l(this);
  }
  
  public static z s(WindowInsets paramWindowInsets) {
    return t(paramWindowInsets, null);
  }
  
  public static z t(WindowInsets paramWindowInsets, View paramView) {
    b.h.m.h.b(paramWindowInsets);
    z z1 = new z(paramWindowInsets);
    if (paramView != null && paramView.isAttachedToWindow()) {
      z1.p(r.t(paramView));
      z1.d(paramView.getRootView());
    } 
    return z1;
  }
  
  @Deprecated
  public z a() {
    return this.a.a();
  }
  
  @Deprecated
  public z b() {
    return this.a.b();
  }
  
  @Deprecated
  public z c() {
    return this.a.c();
  }
  
  public void d(View paramView) {
    this.a.d(paramView);
  }
  
  public c e() {
    return this.a.f();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof z))
      return false; 
    paramObject = paramObject;
    return b.h.m.c.a(this.a, ((z)paramObject).a);
  }
  
  public b.h.g.b f(int paramInt) {
    return this.a.g(paramInt);
  }
  
  @Deprecated
  public b.h.g.b g() {
    return this.a.i();
  }
  
  @Deprecated
  public int h() {
    return (this.a.k()).d;
  }
  
  public int hashCode() {
    l l1 = this.a;
    return (l1 == null) ? 0 : l1.hashCode();
  }
  
  @Deprecated
  public int i() {
    return (this.a.k()).a;
  }
  
  @Deprecated
  public int j() {
    return (this.a.k()).c;
  }
  
  @Deprecated
  public int k() {
    return (this.a.k()).b;
  }
  
  public boolean l() {
    return this.a.m();
  }
  
  @Deprecated
  public z m(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    b b = new b(this);
    b.c(b.h.g.b.b(paramInt1, paramInt2, paramInt3, paramInt4));
    return b.a();
  }
  
  public void n(b.h.g.b[] paramArrayOfb) {
    this.a.o(paramArrayOfb);
  }
  
  public void o(b.h.g.b paramb) {
    this.a.p(paramb);
  }
  
  public void p(z paramz) {
    this.a.q(paramz);
  }
  
  public void q(b.h.g.b paramb) {
    this.a.r(paramb);
  }
  
  public WindowInsets r() {
    l l1 = this.a;
    return (l1 instanceof g) ? ((g)l1).c : null;
  }
  
  public static class a {
    public static Field a;
    
    public static Field b;
    
    public static Field c;
    
    public static boolean d;
    
    static {
      try {
        Field field2 = View.class.getDeclaredField("mAttachInfo");
        a = field2;
        field2.setAccessible(true);
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        Field field3 = clazz.getDeclaredField("mStableInsets");
        b = field3;
        field3.setAccessible(true);
        Field field1 = clazz.getDeclaredField("mContentInsets");
        c = field1;
        field1.setAccessible(true);
        d = true;
        return;
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets from AttachInfo ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.w("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
        return;
      } 
    }
    
    public static z a(View param1View) {
      if (d) {
        if (!param1View.isAttachedToWindow())
          return null; 
        View view = param1View.getRootView();
        try {
          Object object = a.get(view);
          if (object != null) {
            Rect rect = (Rect)b.get(object);
            object = c.get(object);
            if (rect != null && object != null) {
              z.b b = new z.b();
              b.b(b.h.g.b.c(rect));
              b.c(b.h.g.b.c((Rect)object));
              z z = b.a();
              z.p(z);
              z.d(param1View.getRootView());
              return z;
            } 
          } 
        } catch (IllegalAccessException illegalAccessException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to get insets from AttachInfo. ");
          stringBuilder.append(illegalAccessException.getMessage());
          Log.w("WindowInsetsCompat", stringBuilder.toString(), illegalAccessException);
        } 
      } 
      return null;
    }
  }
  
  public static final class b {
    public final z.f a;
    
    public b() {
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        this.a = new z.e();
        return;
      } 
      if (i >= 29) {
        this.a = new z.d();
        return;
      } 
      if (i >= 20) {
        this.a = new z.c();
        return;
      } 
      this.a = new z.f();
    }
    
    public b(z param1z) {
      int i = Build.VERSION.SDK_INT;
      if (i >= 30) {
        this.a = new z.e(param1z);
        return;
      } 
      if (i >= 29) {
        this.a = new z.d(param1z);
        return;
      } 
      if (i >= 20) {
        this.a = new z.c(param1z);
        return;
      } 
      this.a = new z.f(param1z);
    }
    
    public z a() {
      return this.a.b();
    }
    
    @Deprecated
    public b b(b.h.g.b param1b) {
      this.a.d(param1b);
      return this;
    }
    
    @Deprecated
    public b c(b.h.g.b param1b) {
      this.a.f(param1b);
      return this;
    }
  }
  
  public static class c extends f {
    public static Field e;
    
    public static boolean f = false;
    
    public static Constructor<WindowInsets> g;
    
    public static boolean h = false;
    
    public WindowInsets c = h();
    
    public b.h.g.b d;
    
    public c() {}
    
    public c(z param1z) {
      super(param1z);
    }
    
    public static WindowInsets h() {
      if (!f) {
        try {
          e = WindowInsets.class.getDeclaredField("CONSUMED");
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", reflectiveOperationException);
        } 
        f = true;
      } 
      Field field = e;
      if (field != null)
        try {
          WindowInsets windowInsets = (WindowInsets)field.get(null);
          if (windowInsets != null)
            return new WindowInsets(windowInsets); 
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", reflectiveOperationException);
        }  
      if (!h) {
        try {
          g = WindowInsets.class.getConstructor(new Class[] { Rect.class });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", reflectiveOperationException);
        } 
        h = true;
      } 
      Constructor<WindowInsets> constructor = g;
      if (constructor != null)
        try {
          return constructor.newInstance(new Object[] { new Rect() });
        } catch (ReflectiveOperationException reflectiveOperationException) {
          Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", reflectiveOperationException);
        }  
      return null;
    }
    
    public z b() {
      a();
      z z = z.s(this.c);
      z.n(this.b);
      z.q(this.d);
      return z;
    }
    
    public void d(b.h.g.b param1b) {
      this.d = param1b;
    }
    
    public void f(b.h.g.b param1b) {
      WindowInsets windowInsets = this.c;
      if (windowInsets != null)
        this.c = windowInsets.replaceSystemWindowInsets(param1b.a, param1b.b, param1b.c, param1b.d); 
    }
  }
  
  public static class d extends f {
    public final WindowInsets.Builder c;
    
    public d() {
      this.c = new WindowInsets.Builder();
    }
    
    public d(z param1z) {
      super(param1z);
      WindowInsets.Builder builder;
      WindowInsets windowInsets = param1z.r();
      if (windowInsets != null) {
        builder = new WindowInsets.Builder(windowInsets);
      } else {
        builder = new WindowInsets.Builder();
      } 
      this.c = builder;
    }
    
    public z b() {
      a();
      z z = z.s(this.c.build());
      z.n(this.b);
      return z;
    }
    
    public void c(b.h.g.b param1b) {
      this.c.setMandatorySystemGestureInsets(param1b.e());
    }
    
    public void d(b.h.g.b param1b) {
      this.c.setStableInsets(param1b.e());
    }
    
    public void e(b.h.g.b param1b) {
      this.c.setSystemGestureInsets(param1b.e());
    }
    
    public void f(b.h.g.b param1b) {
      this.c.setSystemWindowInsets(param1b.e());
    }
    
    public void g(b.h.g.b param1b) {
      this.c.setTappableElementInsets(param1b.e());
    }
  }
  
  public static class e extends d {
    public e() {}
    
    public e(z param1z) {
      super(param1z);
    }
  }
  
  public static class f {
    public final z a;
    
    public b.h.g.b[] b;
    
    public f() {
      this(new z(null));
    }
    
    public f(z param1z) {
      this.a = param1z;
    }
    
    public final void a() {
      b.h.g.b[] arrayOfB = this.b;
      if (arrayOfB != null) {
        b.h.g.b b3 = arrayOfB[z.m.a(1)];
        b.h.g.b b2 = this.b[z.m.a(2)];
        b.h.g.b b1 = b2;
        if (b2 == null)
          b1 = this.a.f(2); 
        b2 = b3;
        if (b3 == null)
          b2 = this.a.f(1); 
        f(b.h.g.b.a(b2, b1));
        b1 = this.b[z.m.a(16)];
        if (b1 != null)
          e(b1); 
        b1 = this.b[z.m.a(32)];
        if (b1 != null)
          c(b1); 
        b1 = this.b[z.m.a(64)];
        if (b1 != null)
          g(b1); 
      } 
    }
    
    public z b() {
      a();
      return this.a;
    }
    
    public void c(b.h.g.b param1b) {}
    
    public void d(b.h.g.b param1b) {}
    
    public void e(b.h.g.b param1b) {}
    
    public void f(b.h.g.b param1b) {}
    
    public void g(b.h.g.b param1b) {}
  }
  
  public static class g extends l {
    public static boolean h = false;
    
    public static Method i;
    
    public static Class<?> j;
    
    public static Class<?> k;
    
    public static Field l;
    
    public static Field m;
    
    public final WindowInsets c;
    
    public b.h.g.b[] d;
    
    public b.h.g.b e = null;
    
    public z f;
    
    public b.h.g.b g;
    
    public g(z param1z, WindowInsets param1WindowInsets) {
      super(param1z);
      this.c = param1WindowInsets;
    }
    
    public g(z param1z, g param1g) {
      this(param1z, new WindowInsets(param1g.c));
    }
    
    @SuppressLint({"PrivateApi"})
    public static void w() {
      try {
        i = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
        j = Class.forName("android.view.ViewRootImpl");
        Class<?> clazz = Class.forName("android.view.View$AttachInfo");
        k = clazz;
        l = clazz.getDeclaredField("mVisibleInsets");
        m = j.getDeclaredField("mAttachInfo");
        l.setAccessible(true);
        m.setAccessible(true);
      } catch (ReflectiveOperationException reflectiveOperationException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to get visible insets. (Reflection error). ");
        stringBuilder.append(reflectiveOperationException.getMessage());
        Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
      } 
      h = true;
    }
    
    public void d(View param1View) {
      b.h.g.b b2 = v(param1View);
      b.h.g.b b1 = b2;
      if (b2 == null)
        b1 = b.h.g.b.e; 
      p(b1);
    }
    
    public void e(z param1z) {
      param1z.p(this.f);
      param1z.o(this.g);
    }
    
    public boolean equals(Object param1Object) {
      if (!super.equals(param1Object))
        return false; 
      param1Object = param1Object;
      return Objects.equals(this.g, ((g)param1Object).g);
    }
    
    public b.h.g.b g(int param1Int) {
      return s(param1Int, false);
    }
    
    public final b.h.g.b k() {
      if (this.e == null)
        this.e = b.h.g.b.b(this.c.getSystemWindowInsetLeft(), this.c.getSystemWindowInsetTop(), this.c.getSystemWindowInsetRight(), this.c.getSystemWindowInsetBottom()); 
      return this.e;
    }
    
    public boolean n() {
      return this.c.isRound();
    }
    
    public void o(b.h.g.b[] param1ArrayOfb) {
      this.d = param1ArrayOfb;
    }
    
    public void p(b.h.g.b param1b) {
      this.g = param1b;
    }
    
    public void q(z param1z) {
      this.f = param1z;
    }
    
    @SuppressLint({"WrongConstant"})
    public final b.h.g.b s(int param1Int, boolean param1Boolean) {
      b.h.g.b b1 = b.h.g.b.e;
      for (int i = 1; i <= 256; i <<= 1) {
        if ((param1Int & i) != 0)
          b1 = b.h.g.b.a(b1, t(i, param1Boolean)); 
      } 
      return b1;
    }
    
    public b.h.g.b t(int param1Int, boolean param1Boolean) {
      if (param1Int != 1) {
        b.h.g.b b1;
        z z1 = null;
        z z2 = null;
        if (param1Int != 2) {
          if (param1Int != 8) {
            if (param1Int != 16) {
              if (param1Int != 32) {
                if (param1Int != 64) {
                  c c;
                  if (param1Int != 128)
                    return b.h.g.b.e; 
                  z1 = this.f;
                  if (z1 != null) {
                    c = z1.e();
                  } else {
                    c = f();
                  } 
                  return (c != null) ? b.h.g.b.b(c.b(), c.d(), c.c(), c.a()) : b.h.g.b.e;
                } 
                return l();
              } 
              return h();
            } 
            return j();
          } 
          b.h.g.b[] arrayOfB = this.d;
          z1 = z2;
          if (arrayOfB != null)
            b1 = arrayOfB[z.m.a(8)]; 
          if (b1 != null)
            return b1; 
          b.h.g.b b3 = k();
          b1 = u();
          param1Int = b3.d;
          if (param1Int > b1.d)
            return b.h.g.b.b(0, 0, 0, param1Int); 
          b3 = this.g;
          if (b3 != null && !b3.equals(b.h.g.b.e)) {
            param1Int = this.g.d;
            if (param1Int > b1.d)
              return b.h.g.b.b(0, 0, 0, param1Int); 
          } 
          return b.h.g.b.e;
        } 
        if (param1Boolean) {
          b1 = u();
          b.h.g.b b3 = i();
          return b.h.g.b.b(Math.max(b1.a, b3.a), 0, Math.max(b1.c, b3.c), Math.max(b1.d, b3.d));
        } 
        b.h.g.b b2 = k();
        z z3 = this.f;
        if (z3 != null)
          b1 = z3.g(); 
        int i = b2.d;
        param1Int = i;
        if (b1 != null)
          param1Int = Math.min(i, b1.d); 
        return b.h.g.b.b(b2.a, 0, b2.c, param1Int);
      } 
      return param1Boolean ? b.h.g.b.b(0, Math.max((u()).b, (k()).b), 0, 0) : b.h.g.b.b(0, (k()).b, 0, 0);
    }
    
    public final b.h.g.b u() {
      z z1 = this.f;
      return (z1 != null) ? z1.g() : b.h.g.b.e;
    }
    
    public final b.h.g.b v(View param1View) {
      if (Build.VERSION.SDK_INT < 30) {
        if (!h)
          w(); 
        Method method = i;
        StringBuilder stringBuilder = null;
        if (method != null && k != null) {
          if (l == null)
            return null; 
          try {
            Object object = method.invoke(param1View, new Object[0]);
            if (object == null) {
              Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
              return null;
            } 
            object = m.get(object);
            Rect rect = (Rect)l.get(object);
            object = stringBuilder;
            if (rect != null)
              object = b.h.g.b.c(rect); 
            return (b.h.g.b)object;
          } catch (ReflectiveOperationException reflectiveOperationException) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to get visible insets. (Reflection error). ");
            stringBuilder.append(reflectiveOperationException.getMessage());
            Log.e("WindowInsetsCompat", stringBuilder.toString(), reflectiveOperationException);
          } 
        } 
        return null;
      } 
      throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }
  }
  
  public static class h extends g {
    public b.h.g.b n = null;
    
    public h(z param1z, WindowInsets param1WindowInsets) {
      super(param1z, param1WindowInsets);
    }
    
    public h(z param1z, h param1h) {
      super(param1z, param1h);
      this.n = param1h.n;
    }
    
    public z b() {
      return z.s(this.c.consumeStableInsets());
    }
    
    public z c() {
      return z.s(this.c.consumeSystemWindowInsets());
    }
    
    public final b.h.g.b i() {
      if (this.n == null)
        this.n = b.h.g.b.b(this.c.getStableInsetLeft(), this.c.getStableInsetTop(), this.c.getStableInsetRight(), this.c.getStableInsetBottom()); 
      return this.n;
    }
    
    public boolean m() {
      return this.c.isConsumed();
    }
    
    public void r(b.h.g.b param1b) {
      this.n = param1b;
    }
  }
  
  public static class i extends h {
    public i(z param1z, WindowInsets param1WindowInsets) {
      super(param1z, param1WindowInsets);
    }
    
    public i(z param1z, i param1i) {
      super(param1z, param1i);
    }
    
    public z a() {
      return z.s(this.c.consumeDisplayCutout());
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof i))
        return false; 
      param1Object = param1Object;
      return (Objects.equals(this.c, ((z.g)param1Object).c) && Objects.equals(this.g, ((z.g)param1Object).g));
    }
    
    public c f() {
      return c.e(this.c.getDisplayCutout());
    }
    
    public int hashCode() {
      return this.c.hashCode();
    }
  }
  
  public static class j extends i {
    public b.h.g.b o = null;
    
    public b.h.g.b p = null;
    
    public b.h.g.b q = null;
    
    public j(z param1z, WindowInsets param1WindowInsets) {
      super(param1z, param1WindowInsets);
    }
    
    public j(z param1z, j param1j) {
      super(param1z, param1j);
    }
    
    public b.h.g.b h() {
      if (this.p == null)
        this.p = b.h.g.b.d(this.c.getMandatorySystemGestureInsets()); 
      return this.p;
    }
    
    public b.h.g.b j() {
      if (this.o == null)
        this.o = b.h.g.b.d(this.c.getSystemGestureInsets()); 
      return this.o;
    }
    
    public b.h.g.b l() {
      if (this.q == null)
        this.q = b.h.g.b.d(this.c.getTappableElementInsets()); 
      return this.q;
    }
    
    public void r(b.h.g.b param1b) {}
  }
  
  public static class k extends j {
    public static final z r = z.s(WindowInsets.CONSUMED);
    
    public k(z param1z, WindowInsets param1WindowInsets) {
      super(param1z, param1WindowInsets);
    }
    
    public k(z param1z, k param1k) {
      super(param1z, param1k);
    }
    
    public final void d(View param1View) {}
    
    public b.h.g.b g(int param1Int) {
      return b.h.g.b.d(this.c.getInsets(z.n.a(param1Int)));
    }
  }
  
  public static class l {
    public static final z b = (new z.b()).a().a().b().c();
    
    public final z a;
    
    public l(z param1z) {
      this.a = param1z;
    }
    
    public z a() {
      return this.a;
    }
    
    public z b() {
      return this.a;
    }
    
    public z c() {
      return this.a;
    }
    
    public void d(View param1View) {}
    
    public void e(z param1z) {}
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof l))
        return false; 
      param1Object = param1Object;
      return (n() == param1Object.n() && m() == param1Object.m() && b.h.m.c.a(k(), param1Object.k()) && b.h.m.c.a(i(), param1Object.i()) && b.h.m.c.a(f(), param1Object.f()));
    }
    
    public c f() {
      return null;
    }
    
    public b.h.g.b g(int param1Int) {
      return b.h.g.b.e;
    }
    
    public b.h.g.b h() {
      return k();
    }
    
    public int hashCode() {
      return b.h.m.c.b(new Object[] { Boolean.valueOf(n()), Boolean.valueOf(m()), k(), i(), f() });
    }
    
    public b.h.g.b i() {
      return b.h.g.b.e;
    }
    
    public b.h.g.b j() {
      return k();
    }
    
    public b.h.g.b k() {
      return b.h.g.b.e;
    }
    
    public b.h.g.b l() {
      return k();
    }
    
    public boolean m() {
      return false;
    }
    
    public boolean n() {
      return false;
    }
    
    public void o(b.h.g.b[] param1ArrayOfb) {}
    
    public void p(b.h.g.b param1b) {}
    
    public void q(z param1z) {}
    
    public void r(b.h.g.b param1b) {}
  }
  
  public static final class m {
    public static int a(int param1Int) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 4) {
            if (param1Int != 8) {
              if (param1Int != 16) {
                if (param1Int != 32) {
                  if (param1Int != 64) {
                    if (param1Int != 128) {
                      if (param1Int == 256)
                        return 8; 
                      StringBuilder stringBuilder = new StringBuilder();
                      stringBuilder.append("type needs to be >= FIRST and <= LAST, type=");
                      stringBuilder.append(param1Int);
                      throw new IllegalArgumentException(stringBuilder.toString());
                    } 
                    return 7;
                  } 
                  return 6;
                } 
                return 5;
              } 
              return 4;
            } 
            return 3;
          } 
          return 2;
        } 
        return 1;
      } 
      return 0;
    }
  }
  
  public static final class n {
    public static int a(int param1Int) {
      int j = 0;
      int i = 1;
      while (i <= 256) {
        int k = j;
        if ((param1Int & i) != 0)
          if (i != 1) {
            if (i != 2) {
              if (i != 4) {
                if (i != 8) {
                  if (i != 16) {
                    if (i != 32) {
                      if (i != 64) {
                        if (i != 128) {
                          k = j;
                        } else {
                          k = WindowInsets.Type.displayCutout();
                          k = j | k;
                        } 
                      } else {
                        k = WindowInsets.Type.tappableElement();
                        k = j | k;
                      } 
                    } else {
                      k = WindowInsets.Type.mandatorySystemGestures();
                      k = j | k;
                    } 
                  } else {
                    k = WindowInsets.Type.systemGestures();
                    k = j | k;
                  } 
                } else {
                  k = WindowInsets.Type.ime();
                  k = j | k;
                } 
              } else {
                k = WindowInsets.Type.captionBar();
                k = j | k;
              } 
            } else {
              k = WindowInsets.Type.navigationBars();
              k = j | k;
            } 
          } else {
            k = WindowInsets.Type.statusBars();
            k = j | k;
          }  
        i <<= 1;
        j = k;
      } 
      return j;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */