package b.h.n.a0;

public class c {
  public final Object a;
  
  public c(Object paramObject) {
    this.a = paramObject;
  }
  
  public Object a() {
    return this.a;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\a0\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */