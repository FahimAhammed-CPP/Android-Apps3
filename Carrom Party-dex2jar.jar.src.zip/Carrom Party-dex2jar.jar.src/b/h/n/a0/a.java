package b.h.n.a0;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

public final class a extends ClickableSpan {
  public final int a;
  
  public final b b;
  
  public final int c;
  
  public a(int paramInt1, b paramb, int paramInt2) {
    this.a = paramInt1;
    this.b = paramb;
    this.c = paramInt2;
  }
  
  public void onClick(View paramView) {
    Bundle bundle = new Bundle();
    bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.a);
    this.b.L(this.c, bundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\a0\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */