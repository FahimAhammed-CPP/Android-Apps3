package b.h.n;

import android.os.Build;
import android.view.DisplayCutout;

public final class c {
  public final Object a;
  
  public c(Object paramObject) {
    this.a = paramObject;
  }
  
  public static c e(Object paramObject) {
    return (paramObject == null) ? null : new c(paramObject);
  }
  
  public int a() {
    return (Build.VERSION.SDK_INT >= 28) ? ((DisplayCutout)this.a).getSafeInsetBottom() : 0;
  }
  
  public int b() {
    return (Build.VERSION.SDK_INT >= 28) ? ((DisplayCutout)this.a).getSafeInsetLeft() : 0;
  }
  
  public int c() {
    return (Build.VERSION.SDK_INT >= 28) ? ((DisplayCutout)this.a).getSafeInsetRight() : 0;
  }
  
  public int d() {
    return (Build.VERSION.SDK_INT >= 28) ? ((DisplayCutout)this.a).getSafeInsetTop() : 0;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null || c.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return b.h.m.c.a(this.a, ((c)paramObject).a);
  }
  
  public int hashCode() {
    Object object = this.a;
    return (object == null) ? 0 : object.hashCode();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DisplayCutoutCompat{");
    stringBuilder.append(this.a);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */