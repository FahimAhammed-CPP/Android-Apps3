package b.h.n;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.os.Build;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

public final class v {
  public WeakReference<View> a;
  
  public Runnable b = null;
  
  public Runnable c = null;
  
  public int d = -1;
  
  public v(View paramView) {
    this.a = new WeakReference<View>(paramView);
  }
  
  public v a(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().alpha(paramFloat); 
    return this;
  }
  
  public void b() {
    View view = this.a.get();
    if (view != null)
      view.animate().cancel(); 
  }
  
  public long c() {
    View view = this.a.get();
    return (view != null) ? view.animate().getDuration() : 0L;
  }
  
  public v d(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setDuration(paramLong); 
    return this;
  }
  
  public v e(Interpolator paramInterpolator) {
    View view = this.a.get();
    if (view != null)
      view.animate().setInterpolator((TimeInterpolator)paramInterpolator); 
    return this;
  }
  
  public v f(w paramw) {
    View view = this.a.get();
    if (view != null) {
      if (Build.VERSION.SDK_INT >= 16) {
        g(view, paramw);
        return this;
      } 
      view.setTag(2113929216, paramw);
      g(view, new c(this));
    } 
    return this;
  }
  
  public final void g(View paramView, w paramw) {
    if (paramw != null) {
      paramView.animate().setListener((Animator.AnimatorListener)new a(this, paramw, paramView));
      return;
    } 
    paramView.animate().setListener(null);
  }
  
  public v h(long paramLong) {
    View view = this.a.get();
    if (view != null)
      view.animate().setStartDelay(paramLong); 
    return this;
  }
  
  public v i(y paramy) {
    View view = this.a.get();
    if (view != null && Build.VERSION.SDK_INT >= 19) {
      b b = null;
      if (paramy != null)
        b = new b(this, paramy, view); 
      view.animate().setUpdateListener(b);
    } 
    return this;
  }
  
  public void j() {
    View view = this.a.get();
    if (view != null)
      view.animate().start(); 
  }
  
  public v k(float paramFloat) {
    View view = this.a.get();
    if (view != null)
      view.animate().translationY(paramFloat); 
    return this;
  }
  
  public class a extends AnimatorListenerAdapter {
    public a(v this$0, w param1w, View param1View) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      this.a.a(this.b);
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.b(this.b);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.c(this.b);
    }
  }
  
  public class b implements ValueAnimator.AnimatorUpdateListener {
    public b(v this$0, y param1y, View param1View) {}
    
    public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
      this.a.a(this.b);
    }
  }
  
  public static class c implements w {
    public v a;
    
    public boolean b;
    
    public c(v param1v) {
      this.a = param1v;
    }
    
    public void a(View param1View) {
      Object object = param1View.getTag(2113929216);
      if (object instanceof w) {
        object = object;
      } else {
        object = null;
      } 
      if (object != null)
        object.a(param1View); 
    }
    
    @SuppressLint({"WrongConstant"})
    public void b(View param1View) {
      int i = this.a.d;
      w w1 = null;
      if (i > -1) {
        param1View.setLayerType(i, null);
        this.a.d = -1;
      } 
      if (Build.VERSION.SDK_INT >= 16 || !this.b) {
        v v1 = this.a;
        Runnable runnable = v1.c;
        if (runnable != null) {
          v1.c = null;
          runnable.run();
        } 
        Object object = param1View.getTag(2113929216);
        if (object instanceof w)
          w1 = (w)object; 
        if (w1 != null)
          w1.b(param1View); 
        this.b = true;
      } 
    }
    
    public void c(View param1View) {
      this.b = false;
      int i = this.a.d;
      w w1 = null;
      if (i > -1)
        param1View.setLayerType(2, null); 
      v v1 = this.a;
      Runnable runnable = v1.b;
      if (runnable != null) {
        v1.b = null;
        runnable.run();
      } 
      Object object = param1View.getTag(2113929216);
      if (object instanceof w)
        w1 = (w)object; 
      if (w1 != null)
        w1.c(param1View); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */