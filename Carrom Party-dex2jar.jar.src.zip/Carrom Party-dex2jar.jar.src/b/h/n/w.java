package b.h.n;

import android.view.View;

public interface w {
  void a(View paramView);
  
  void b(View paramView);
  
  void c(View paramView);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */