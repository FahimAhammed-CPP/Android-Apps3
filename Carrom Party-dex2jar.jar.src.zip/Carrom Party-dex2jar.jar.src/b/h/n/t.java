package b.h.n;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import b.h.c;

public final class t {
  public static boolean a(ViewGroup paramViewGroup) {
    if (Build.VERSION.SDK_INT >= 21)
      return paramViewGroup.isTransitionGroup(); 
    Boolean bool = (Boolean)paramViewGroup.getTag(c.i);
    return ((bool != null && bool.booleanValue()) || paramViewGroup.getBackground() != null || r.v((View)paramViewGroup) != null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */