package b.h.n;

public interface i {
  void stopNestedScroll();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */