package b.h.n;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Build;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class e {
  public static boolean a = false;
  
  public static Method b;
  
  public static boolean c = false;
  
  public static Field d;
  
  public static boolean a(ActionBar paramActionBar, KeyEvent paramKeyEvent) {
    if (!a) {
      try {
        b = paramActionBar.getClass().getMethod("onMenuKeyEvent", new Class[] { KeyEvent.class });
      } catch (NoSuchMethodException noSuchMethodException) {}
      a = true;
    } 
    Method method = b;
    if (method != null)
      try {
        return ((Boolean)method.invoke(paramActionBar, new Object[] { paramKeyEvent })).booleanValue();
      } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
        return false;
      }  
    return false;
  }
  
  public static boolean b(Activity paramActivity, KeyEvent paramKeyEvent) {
    paramActivity.onUserInteraction();
    Window window = paramActivity.getWindow();
    if (window.hasFeature(8)) {
      ActionBar actionBar = paramActivity.getActionBar();
      if (paramKeyEvent.getKeyCode() == 82 && actionBar != null && a(actionBar, paramKeyEvent))
        return true; 
    } 
    if (window.superDispatchKeyEvent(paramKeyEvent))
      return true; 
    View view = window.getDecorView();
    if (r.e(view, paramKeyEvent))
      return true; 
    if (view != null) {
      KeyEvent.DispatcherState dispatcherState = view.getKeyDispatcherState();
    } else {
      view = null;
    } 
    return paramKeyEvent.dispatch((KeyEvent.Callback)paramActivity, (KeyEvent.DispatcherState)view, paramActivity);
  }
  
  public static boolean c(Dialog paramDialog, KeyEvent paramKeyEvent) {
    DialogInterface.OnKeyListener onKeyListener = f(paramDialog);
    if (onKeyListener != null && onKeyListener.onKey((DialogInterface)paramDialog, paramKeyEvent.getKeyCode(), paramKeyEvent))
      return true; 
    Window window = paramDialog.getWindow();
    if (window.superDispatchKeyEvent(paramKeyEvent))
      return true; 
    View view = window.getDecorView();
    if (r.e(view, paramKeyEvent))
      return true; 
    if (view != null) {
      KeyEvent.DispatcherState dispatcherState = view.getKeyDispatcherState();
    } else {
      view = null;
    } 
    return paramKeyEvent.dispatch((KeyEvent.Callback)paramDialog, (KeyEvent.DispatcherState)view, paramDialog);
  }
  
  public static boolean d(View paramView, KeyEvent paramKeyEvent) {
    return r.f(paramView, paramKeyEvent);
  }
  
  public static boolean e(a parama, View paramView, Window.Callback paramCallback, KeyEvent paramKeyEvent) {
    boolean bool = false;
    if (parama == null)
      return false; 
    if (Build.VERSION.SDK_INT >= 28)
      return parama.k(paramKeyEvent); 
    if (paramCallback instanceof Activity)
      return b((Activity)paramCallback, paramKeyEvent); 
    if (paramCallback instanceof Dialog)
      return c((Dialog)paramCallback, paramKeyEvent); 
    if ((paramView != null && r.e(paramView, paramKeyEvent)) || parama.k(paramKeyEvent))
      bool = true; 
    return bool;
  }
  
  public static DialogInterface.OnKeyListener f(Dialog paramDialog) {
    if (!c) {
      try {
        Field field1 = Dialog.class.getDeclaredField("mOnKeyListener");
        d = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      c = true;
    } 
    Field field = d;
    if (field != null)
      try {
        return (DialogInterface.OnKeyListener)field.get(paramDialog);
      } catch (IllegalAccessException illegalAccessException) {} 
    return null;
  }
  
  public static interface a {
    boolean k(KeyEvent param1KeyEvent);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */