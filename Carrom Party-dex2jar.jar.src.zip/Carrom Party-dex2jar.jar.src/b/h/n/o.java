package b.h.n;

import android.view.View;

public interface o {
  z a(View paramView, z paramz);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */