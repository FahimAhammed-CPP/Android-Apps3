package b.h.n;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class r {
  public static Field a;
  
  public static boolean b;
  
  public static WeakHashMap<View, String> c;
  
  public static WeakHashMap<View, v> d = null;
  
  public static Field e;
  
  public static boolean f = false;
  
  public static ThreadLocal<Rect> g;
  
  static {
    new e();
  }
  
  public static boolean A(View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? paramView.isAttachedToWindow() : ((paramView.getWindowToken() != null));
  }
  
  public static boolean B(View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? paramView.isLaidOut() : ((paramView.getWidth() > 0 && paramView.getHeight() > 0));
  }
  
  public static boolean C(View paramView) {
    Boolean bool = N().d(paramView);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  public static void D(View paramView, int paramInt) {
    boolean bool;
    AccessibilityEvent accessibilityEvent;
    AccessibilityManager accessibilityManager = (AccessibilityManager)paramView.getContext().getSystemService("accessibility");
    if (!accessibilityManager.isEnabled())
      return; 
    if (j(paramView) != null && paramView.getVisibility() == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = i(paramView);
    char c = ' ';
    if (i != 0 || bool) {
      accessibilityEvent = AccessibilityEvent.obtain();
      if (!bool)
        c = 'ࠀ'; 
      accessibilityEvent.setEventType(c);
      accessibilityEvent.setContentChangeTypes(paramInt);
      if (bool) {
        accessibilityEvent.getText().add(j(paramView));
        Y(paramView);
      } 
      paramView.sendAccessibilityEventUnchecked(accessibilityEvent);
      return;
    } 
    if (paramInt == 32) {
      AccessibilityEvent accessibilityEvent1 = AccessibilityEvent.obtain();
      paramView.onInitializeAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.setEventType(32);
      accessibilityEvent1.setContentChangeTypes(paramInt);
      accessibilityEvent1.setSource(paramView);
      paramView.onPopulateAccessibilityEvent(accessibilityEvent1);
      accessibilityEvent1.getText().add(j(paramView));
      accessibilityEvent.sendAccessibilityEvent(accessibilityEvent1);
      return;
    } 
    if (paramView.getParent() != null)
      try {
        paramView.getParent().notifySubtreeAccessibilityStateChanged(paramView, paramView, paramInt);
        return;
      } catch (AbstractMethodError abstractMethodError) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramView.getParent().getClass().getSimpleName());
        stringBuilder.append(" does not fully implement ViewParent");
        Log.e("ViewCompat", stringBuilder.toString(), abstractMethodError);
        return;
      }  
  }
  
  public static void E(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      paramView.offsetLeftAndRight(paramInt);
      return;
    } 
    if (i >= 21) {
      Rect rect = n();
      i = 0;
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
      } 
      c(paramView, paramInt);
      if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())) {
        ((View)viewParent).invalidate(rect);
        return;
      } 
    } else {
      c(paramView, paramInt);
    } 
  }
  
  public static void F(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23) {
      paramView.offsetTopAndBottom(paramInt);
      return;
    } 
    if (i >= 21) {
      Rect rect = n();
      i = 0;
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        i = rect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()) ^ true;
      } 
      d(paramView, paramInt);
      if (i != 0 && rect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())) {
        ((View)viewParent).invalidate(rect);
        return;
      } 
    } else {
      d(paramView, paramInt);
    } 
  }
  
  public static z G(View paramView, z paramz) {
    if (Build.VERSION.SDK_INT >= 21) {
      WindowInsets windowInsets = paramz.r();
      if (windowInsets != null) {
        WindowInsets windowInsets1 = paramView.onApplyWindowInsets(windowInsets);
        if (!windowInsets1.equals(windowInsets))
          return z.t(windowInsets1, paramView); 
      } 
    } 
    return paramz;
  }
  
  public static f<CharSequence> H() {
    return new b(b.h.c.e, CharSequence.class, 8, 28);
  }
  
  public static void I(View paramView) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.postInvalidateOnAnimation();
      return;
    } 
    paramView.postInvalidate();
  }
  
  public static void J(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.postInvalidateOnAnimation(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    paramView.postInvalidate(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static void K(View paramView, Runnable paramRunnable) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.postOnAnimation(paramRunnable);
      return;
    } 
    paramView.postDelayed(paramRunnable, ValueAnimator.getFrameDelay());
  }
  
  public static void L(View paramView, Runnable paramRunnable, long paramLong) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.postOnAnimationDelayed(paramRunnable, paramLong);
      return;
    } 
    paramView.postDelayed(paramRunnable, ValueAnimator.getFrameDelay() + paramLong);
  }
  
  public static void M(View paramView) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 20) {
      paramView.requestApplyInsets();
      return;
    } 
    if (i >= 16)
      paramView.requestFitSystemWindows(); 
  }
  
  public static f<Boolean> N() {
    return new a(b.h.c.g, Boolean.class, 28);
  }
  
  public static void O(View paramView, a parama) {
    View.AccessibilityDelegate accessibilityDelegate;
    a a1 = parama;
    if (parama == null) {
      a1 = parama;
      if (g(paramView) instanceof a.a)
        a1 = new a(); 
    } 
    if (a1 == null) {
      parama = null;
    } else {
      accessibilityDelegate = a1.d();
    } 
    paramView.setAccessibilityDelegate(accessibilityDelegate);
  }
  
  public static void P(View paramView, Drawable paramDrawable) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramView.setBackground(paramDrawable);
      return;
    } 
    paramView.setBackgroundDrawable(paramDrawable);
  }
  
  public static void Q(View paramView, ColorStateList paramColorStateList) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      paramView.setBackgroundTintList(paramColorStateList);
      if (i == 21) {
        drawable = paramView.getBackground();
        if (paramView.getBackgroundTintList() != null || paramView.getBackgroundTintMode() != null) {
          i = 1;
        } else {
          i = 0;
        } 
        if (drawable != null && i != 0) {
          if (drawable.isStateful())
            drawable.setState(paramView.getDrawableState()); 
          paramView.setBackground(drawable);
          return;
        } 
      } 
    } else if (paramView instanceof q) {
      ((q)paramView).setSupportBackgroundTintList((ColorStateList)drawable);
    } 
  }
  
  public static void R(View paramView, PorterDuff.Mode paramMode) {
    Drawable drawable;
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      paramView.setBackgroundTintMode(paramMode);
      if (i == 21) {
        drawable = paramView.getBackground();
        if (paramView.getBackgroundTintList() != null || paramView.getBackgroundTintMode() != null) {
          i = 1;
        } else {
          i = 0;
        } 
        if (drawable != null && i != 0) {
          if (drawable.isStateful())
            drawable.setState(paramView.getDrawableState()); 
          paramView.setBackground(drawable);
          return;
        } 
      } 
    } else if (paramView instanceof q) {
      ((q)paramView).setSupportBackgroundTintMode((PorterDuff.Mode)drawable);
    } 
  }
  
  public static void S(View paramView, float paramFloat) {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setElevation(paramFloat); 
  }
  
  public static void T(View paramView, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19) {
      paramView.setImportantForAccessibility(paramInt);
      return;
    } 
    if (i >= 16) {
      i = paramInt;
      if (paramInt == 4)
        i = 2; 
      paramView.setImportantForAccessibility(i);
    } 
  }
  
  public static void U(View paramView, Paint paramPaint) {
    if (Build.VERSION.SDK_INT >= 17) {
      paramView.setLayerPaint(paramPaint);
      return;
    } 
    paramView.setLayerType(paramView.getLayerType(), paramPaint);
    paramView.invalidate();
  }
  
  public static void V(View paramView, o paramo) {
    if (Build.VERSION.SDK_INT >= 21)
      g.c(paramView, paramo); 
  }
  
  public static void W(View paramView, int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 23)
      paramView.setScrollIndicators(paramInt1, paramInt2); 
  }
  
  public static void X(View paramView, String paramString) {
    if (Build.VERSION.SDK_INT >= 21) {
      paramView.setTransitionName(paramString);
      return;
    } 
    if (c == null)
      c = new WeakHashMap<View, String>(); 
    c.put(paramView, paramString);
  }
  
  public static void Y(View paramView) {
    if (p(paramView) == 0)
      T(paramView, 1); 
    for (ViewParent viewParent = paramView.getParent(); viewParent instanceof View; viewParent = viewParent.getParent()) {
      if (p((View)viewParent) == 4) {
        T(paramView, 2);
        return;
      } 
    } 
  }
  
  public static f<CharSequence> Z() {
    return new c(b.h.c.h, CharSequence.class, 64, 30);
  }
  
  public static f<Boolean> a() {
    return new d(b.h.c.d, Boolean.class, 28);
  }
  
  public static void a0(View paramView) {
    if (Build.VERSION.SDK_INT >= 21) {
      paramView.stopNestedScroll();
      return;
    } 
    if (paramView instanceof i)
      ((i)paramView).stopNestedScroll(); 
  }
  
  public static v b(View paramView) {
    if (d == null)
      d = new WeakHashMap<View, v>(); 
    v v2 = d.get(paramView);
    v v1 = v2;
    if (v2 == null) {
      v1 = new v(paramView);
      d.put(paramView, v1);
    } 
    return v1;
  }
  
  public static void b0(View paramView) {
    float f = paramView.getTranslationY();
    paramView.setTranslationY(1.0F + f);
    paramView.setTranslationY(f);
  }
  
  public static void c(View paramView, int paramInt) {
    paramView.offsetLeftAndRight(paramInt);
    if (paramView.getVisibility() == 0) {
      b0(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        b0((View)viewParent); 
    } 
  }
  
  public static void d(View paramView, int paramInt) {
    paramView.offsetTopAndBottom(paramInt);
    if (paramView.getVisibility() == 0) {
      b0(paramView);
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View)
        b0((View)viewParent); 
    } 
  }
  
  public static boolean e(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : j.a(paramView).b(paramView, paramKeyEvent);
  }
  
  public static boolean f(View paramView, KeyEvent paramKeyEvent) {
    return (Build.VERSION.SDK_INT >= 28) ? false : j.a(paramView).f(paramKeyEvent);
  }
  
  public static View.AccessibilityDelegate g(View paramView) {
    return (Build.VERSION.SDK_INT >= 29) ? paramView.getAccessibilityDelegate() : h(paramView);
  }
  
  public static View.AccessibilityDelegate h(View paramView) {
    // Byte code:
    //   0: getstatic b/h/n/r.f : Z
    //   3: ifeq -> 8
    //   6: aconst_null
    //   7: areturn
    //   8: getstatic b/h/n/r.e : Ljava/lang/reflect/Field;
    //   11: ifnonnull -> 41
    //   14: ldc android/view/View
    //   16: ldc_w 'mAccessibilityDelegate'
    //   19: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   22: astore_1
    //   23: aload_1
    //   24: putstatic b/h/n/r.e : Ljava/lang/reflect/Field;
    //   27: aload_1
    //   28: iconst_1
    //   29: invokevirtual setAccessible : (Z)V
    //   32: goto -> 41
    //   35: iconst_1
    //   36: putstatic b/h/n/r.f : Z
    //   39: aconst_null
    //   40: areturn
    //   41: getstatic b/h/n/r.e : Ljava/lang/reflect/Field;
    //   44: aload_0
    //   45: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   48: astore_0
    //   49: aload_0
    //   50: instanceof android/view/View$AccessibilityDelegate
    //   53: ifeq -> 63
    //   56: aload_0
    //   57: checkcast android/view/View$AccessibilityDelegate
    //   60: astore_0
    //   61: aload_0
    //   62: areturn
    //   63: aconst_null
    //   64: areturn
    //   65: iconst_1
    //   66: putstatic b/h/n/r.f : Z
    //   69: aconst_null
    //   70: areturn
    //   71: astore_0
    //   72: goto -> 35
    //   75: astore_0
    //   76: goto -> 65
    // Exception table:
    //   from	to	target	type
    //   14	32	71	finally
    //   41	61	75	finally
  }
  
  public static int i(View paramView) {
    return (Build.VERSION.SDK_INT >= 19) ? paramView.getAccessibilityLiveRegion() : 0;
  }
  
  public static CharSequence j(View paramView) {
    return H().d(paramView);
  }
  
  public static ColorStateList k(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramView.getBackgroundTintList() : ((paramView instanceof q) ? ((q)paramView).getSupportBackgroundTintList() : null);
  }
  
  public static PorterDuff.Mode l(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramView.getBackgroundTintMode() : ((paramView instanceof q) ? ((q)paramView).getSupportBackgroundTintMode() : null);
  }
  
  public static float m(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramView.getElevation() : 0.0F;
  }
  
  public static Rect n() {
    if (g == null)
      g = new ThreadLocal<Rect>(); 
    Rect rect2 = g.get();
    Rect rect1 = rect2;
    if (rect2 == null) {
      rect1 = new Rect();
      g.set(rect1);
    } 
    rect1.setEmpty();
    return rect1;
  }
  
  public static boolean o(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.getFitsSystemWindows() : false;
  }
  
  public static int p(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.getImportantForAccessibility() : 0;
  }
  
  public static int q(View paramView) {
    return (Build.VERSION.SDK_INT >= 17) ? paramView.getLayoutDirection() : 0;
  }
  
  public static int r(View paramView) {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.getMinimumHeight(); 
    if (!b) {
      try {
        Field field1 = View.class.getDeclaredField("mMinHeight");
        a = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      b = true;
    } 
    Field field = a;
    if (field != null)
      try {
        return ((Integer)field.get(paramView)).intValue();
      } catch (Exception exception) {} 
    return 0;
  }
  
  public static ViewParent s(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.getParentForAccessibility() : paramView.getParent();
  }
  
  public static z t(View paramView) {
    int i = Build.VERSION.SDK_INT;
    return (i >= 23) ? h.a(paramView) : ((i >= 21) ? g.b(paramView) : null);
  }
  
  public static final CharSequence u(View paramView) {
    return Z().d(paramView);
  }
  
  public static String v(View paramView) {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getTransitionName(); 
    WeakHashMap<View, String> weakHashMap = c;
    return (weakHashMap == null) ? null : weakHashMap.get(paramView);
  }
  
  public static int w(View paramView) {
    return (Build.VERSION.SDK_INT >= 16) ? paramView.getWindowSystemUiVisibility() : 0;
  }
  
  public static float x(View paramView) {
    return (Build.VERSION.SDK_INT >= 21) ? paramView.getZ() : 0.0F;
  }
  
  public static boolean y(View paramView) {
    return (Build.VERSION.SDK_INT >= 15) ? paramView.hasOnClickListeners() : false;
  }
  
  public static boolean z(View paramView) {
    Boolean bool = a().d(paramView);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  static {
    new AtomicInteger(1);
  }
  
  public class a extends f<Boolean> {
    public a(r this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    public Boolean e(View param1View) {
      return Boolean.valueOf(param1View.isScreenReaderFocusable());
    }
  }
  
  public class b extends f<CharSequence> {
    public b(r this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    public CharSequence e(View param1View) {
      return param1View.getAccessibilityPaneTitle();
    }
  }
  
  public class c extends f<CharSequence> {
    public c(r this$0, Class<CharSequence> param1Class, int param1Int1, int param1Int2) {
      super(this$0, param1Class, param1Int1, param1Int2);
    }
    
    public CharSequence e(View param1View) {
      return param1View.getStateDescription();
    }
  }
  
  public class d extends f<Boolean> {
    public d(r this$0, Class<Boolean> param1Class, int param1Int1) {
      super(this$0, param1Class, param1Int1);
    }
    
    public Boolean e(View param1View) {
      return Boolean.valueOf(param1View.isAccessibilityHeading());
    }
  }
  
  public static class e implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {
    public WeakHashMap<View, Boolean> a = new WeakHashMap<View, Boolean>();
    
    public final void a(View param1View, boolean param1Boolean) {
      boolean bool;
      if (param1View.getVisibility() == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1Boolean != bool) {
        byte b;
        if (bool) {
          b = 16;
        } else {
          b = 32;
        } 
        r.D(param1View, b);
        this.a.put(param1View, Boolean.valueOf(bool));
      } 
    }
    
    public final void b(View param1View) {
      param1View.getViewTreeObserver().addOnGlobalLayoutListener(this);
    }
    
    public void onGlobalLayout() {
      if (Build.VERSION.SDK_INT < 28)
        for (Map.Entry<View, Boolean> entry : this.a.entrySet())
          a((View)entry.getKey(), ((Boolean)entry.getValue()).booleanValue());  
    }
    
    public void onViewAttachedToWindow(View param1View) {
      b(param1View);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
  
  public static abstract class f<T> {
    public final int a;
    
    public final Class<T> b;
    
    public final int c;
    
    public f(int param1Int1, Class<T> param1Class, int param1Int2) {
      this(param1Int1, param1Class, 0, param1Int2);
    }
    
    public f(int param1Int1, Class<T> param1Class, int param1Int2, int param1Int3) {
      this.a = param1Int1;
      this.b = param1Class;
      this.c = param1Int3;
    }
    
    public final boolean a() {
      return (Build.VERSION.SDK_INT >= 19);
    }
    
    public final boolean b() {
      return (Build.VERSION.SDK_INT >= this.c);
    }
    
    public abstract T c(View param1View);
    
    public T d(View param1View) {
      if (b())
        return c(param1View); 
      if (a()) {
        Object object = param1View.getTag(this.a);
        if (this.b.isInstance(object))
          return (T)object; 
      } 
      return null;
    }
  }
  
  public static class g {
    public static void a(WindowInsets param1WindowInsets, View param1View) {
      View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener)param1View.getTag(b.h.c.l);
      if (onApplyWindowInsetsListener != null)
        onApplyWindowInsetsListener.onApplyWindowInsets(param1View, param1WindowInsets); 
    }
    
    public static z b(View param1View) {
      return z.a.a(param1View);
    }
    
    public static void c(View param1View, o param1o) {
      if (Build.VERSION.SDK_INT < 30)
        param1View.setTag(b.h.c.f, param1o); 
      if (param1o == null) {
        param1View.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener)param1View.getTag(b.h.c.l));
        return;
      } 
      param1View.setOnApplyWindowInsetsListener(new a(param1View, param1o));
    }
    
    public class a implements View.OnApplyWindowInsetsListener {
      public z a = null;
      
      public a(r.g this$0, o param2o) {}
      
      public WindowInsets onApplyWindowInsets(View param2View, WindowInsets param2WindowInsets) {
        z z2 = z.t(param2WindowInsets, param2View);
        int i = Build.VERSION.SDK_INT;
        if (i < 30) {
          r.g.a(param2WindowInsets, this.b);
          if (z2.equals(this.a))
            return this.c.a(param2View, z2).r(); 
        } 
        this.a = z2;
        z z1 = this.c.a(param2View, z2);
        if (i >= 30)
          return z1.r(); 
        r.M(param2View);
        return z1.r();
      }
    }
  }
  
  public class a implements View.OnApplyWindowInsetsListener {
    public z a = null;
    
    public a(r this$0, o param1o) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      z z2 = z.t(param1WindowInsets, param1View);
      int i = Build.VERSION.SDK_INT;
      if (i < 30) {
        r.g.a(param1WindowInsets, this.b);
        if (z2.equals(this.a))
          return this.c.a(param1View, z2).r(); 
      } 
      this.a = z2;
      z z1 = this.c.a(param1View, z2);
      if (i >= 30)
        return z1.r(); 
      r.M(param1View);
      return z1.r();
    }
  }
  
  public static class h {
    public static z a(View param1View) {
      WindowInsets windowInsets = param1View.getRootWindowInsets();
      if (windowInsets == null)
        return null; 
      z z = z.s(windowInsets);
      z.p(z);
      z.d(param1View.getRootView());
      return z;
    }
  }
  
  public static interface i {
    boolean a(View param1View, KeyEvent param1KeyEvent);
  }
  
  public static class j {
    public static final ArrayList<WeakReference<View>> d = new ArrayList<WeakReference<View>>();
    
    public WeakHashMap<View, Boolean> a = null;
    
    public SparseArray<WeakReference<View>> b = null;
    
    public WeakReference<KeyEvent> c = null;
    
    public static j a(View param1View) {
      int i = b.h.c.j;
      j j2 = (j)param1View.getTag(i);
      j j1 = j2;
      if (j2 == null) {
        j1 = new j();
        param1View.setTag(i, j1);
      } 
      return j1;
    }
    
    public boolean b(View param1View, KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getAction() == 0)
        g(); 
      param1View = c(param1View, param1KeyEvent);
      if (param1KeyEvent.getAction() == 0) {
        int i = param1KeyEvent.getKeyCode();
        if (param1View != null && !KeyEvent.isModifierKey(i))
          d().put(i, new WeakReference<View>(param1View)); 
      } 
      return (param1View != null);
    }
    
    public final View c(View param1View, KeyEvent param1KeyEvent) {
      WeakHashMap<View, Boolean> weakHashMap = this.a;
      if (weakHashMap != null) {
        if (!weakHashMap.containsKey(param1View))
          return null; 
        if (param1View instanceof ViewGroup) {
          ViewGroup viewGroup = (ViewGroup)param1View;
          for (int i = viewGroup.getChildCount() - 1; i >= 0; i--) {
            View view = c(viewGroup.getChildAt(i), param1KeyEvent);
            if (view != null)
              return view; 
          } 
        } 
        if (e(param1View, param1KeyEvent))
          return param1View; 
      } 
      return null;
    }
    
    public final SparseArray<WeakReference<View>> d() {
      if (this.b == null)
        this.b = new SparseArray(); 
      return this.b;
    }
    
    public final boolean e(View param1View, KeyEvent param1KeyEvent) {
      ArrayList<r.i> arrayList = (ArrayList)param1View.getTag(b.h.c.k);
      if (arrayList != null)
        for (int i = arrayList.size() - 1; i >= 0; i--) {
          if (((r.i)arrayList.get(i)).a(param1View, param1KeyEvent))
            return true; 
        }  
      return false;
    }
    
    public boolean f(KeyEvent param1KeyEvent) {
      WeakReference<KeyEvent> weakReference1 = this.c;
      if (weakReference1 != null && weakReference1.get() == param1KeyEvent)
        return false; 
      this.c = new WeakReference<KeyEvent>(param1KeyEvent);
      WeakReference<KeyEvent> weakReference2 = null;
      SparseArray<WeakReference<View>> sparseArray = d();
      weakReference1 = weakReference2;
      if (param1KeyEvent.getAction() == 1) {
        int i = sparseArray.indexOfKey(param1KeyEvent.getKeyCode());
        weakReference1 = weakReference2;
        if (i >= 0) {
          weakReference1 = (WeakReference<KeyEvent>)sparseArray.valueAt(i);
          sparseArray.removeAt(i);
        } 
      } 
      weakReference2 = weakReference1;
      if (weakReference1 == null)
        weakReference2 = (WeakReference<KeyEvent>)sparseArray.get(param1KeyEvent.getKeyCode()); 
      if (weakReference2 != null) {
        View view = (View)weakReference2.get();
        if (view != null && r.A(view))
          e(view, param1KeyEvent); 
        return true;
      } 
      return false;
    }
    
    public final void g() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Ljava/util/WeakHashMap;
      //   4: astore_2
      //   5: aload_2
      //   6: ifnull -> 13
      //   9: aload_2
      //   10: invokevirtual clear : ()V
      //   13: getstatic b/h/n/r$j.d : Ljava/util/ArrayList;
      //   16: astore_3
      //   17: aload_3
      //   18: invokevirtual isEmpty : ()Z
      //   21: ifeq -> 25
      //   24: return
      //   25: aload_3
      //   26: monitorenter
      //   27: aload_0
      //   28: getfield a : Ljava/util/WeakHashMap;
      //   31: ifnonnull -> 45
      //   34: aload_0
      //   35: new java/util/WeakHashMap
      //   38: dup
      //   39: invokespecial <init> : ()V
      //   42: putfield a : Ljava/util/WeakHashMap;
      //   45: aload_3
      //   46: invokevirtual size : ()I
      //   49: iconst_1
      //   50: isub
      //   51: istore_1
      //   52: iload_1
      //   53: iflt -> 141
      //   56: getstatic b/h/n/r$j.d : Ljava/util/ArrayList;
      //   59: astore_2
      //   60: aload_2
      //   61: iload_1
      //   62: invokevirtual get : (I)Ljava/lang/Object;
      //   65: checkcast java/lang/ref/WeakReference
      //   68: invokevirtual get : ()Ljava/lang/Object;
      //   71: checkcast android/view/View
      //   74: astore #4
      //   76: aload #4
      //   78: ifnonnull -> 90
      //   81: aload_2
      //   82: iload_1
      //   83: invokevirtual remove : (I)Ljava/lang/Object;
      //   86: pop
      //   87: goto -> 155
      //   90: aload_0
      //   91: getfield a : Ljava/util/WeakHashMap;
      //   94: aload #4
      //   96: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   99: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   102: pop
      //   103: aload #4
      //   105: invokevirtual getParent : ()Landroid/view/ViewParent;
      //   108: astore_2
      //   109: aload_2
      //   110: instanceof android/view/View
      //   113: ifeq -> 155
      //   116: aload_0
      //   117: getfield a : Ljava/util/WeakHashMap;
      //   120: aload_2
      //   121: checkcast android/view/View
      //   124: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
      //   127: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   130: pop
      //   131: aload_2
      //   132: invokeinterface getParent : ()Landroid/view/ViewParent;
      //   137: astore_2
      //   138: goto -> 109
      //   141: aload_3
      //   142: monitorexit
      //   143: return
      //   144: astore_2
      //   145: aload_3
      //   146: monitorexit
      //   147: goto -> 152
      //   150: aload_2
      //   151: athrow
      //   152: goto -> 150
      //   155: iload_1
      //   156: iconst_1
      //   157: isub
      //   158: istore_1
      //   159: goto -> 52
      // Exception table:
      //   from	to	target	type
      //   27	45	144	finally
      //   45	52	144	finally
      //   56	76	144	finally
      //   81	87	144	finally
      //   90	109	144	finally
      //   109	138	144	finally
      //   141	143	144	finally
      //   145	147	144	finally
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */