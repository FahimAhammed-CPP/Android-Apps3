package b.h.n;

import android.view.View;
import android.view.ViewTreeObserver;
import java.util.Objects;

public final class p implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {
  public final View a;
  
  public ViewTreeObserver b;
  
  public final Runnable c;
  
  public p(View paramView, Runnable paramRunnable) {
    this.a = paramView;
    this.b = paramView.getViewTreeObserver();
    this.c = paramRunnable;
  }
  
  public static p a(View paramView, Runnable paramRunnable) {
    Objects.requireNonNull(paramView, "view == null");
    Objects.requireNonNull(paramRunnable, "runnable == null");
    p p1 = new p(paramView, paramRunnable);
    paramView.getViewTreeObserver().addOnPreDrawListener(p1);
    paramView.addOnAttachStateChangeListener(p1);
    return p1;
  }
  
  public void b() {
    if (this.b.isAlive()) {
      this.b.removeOnPreDrawListener(this);
    } else {
      this.a.getViewTreeObserver().removeOnPreDrawListener(this);
    } 
    this.a.removeOnAttachStateChangeListener(this);
  }
  
  public boolean onPreDraw() {
    b();
    this.c.run();
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {
    this.b = paramView.getViewTreeObserver();
  }
  
  public void onViewDetachedFromWindow(View paramView) {
    b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */