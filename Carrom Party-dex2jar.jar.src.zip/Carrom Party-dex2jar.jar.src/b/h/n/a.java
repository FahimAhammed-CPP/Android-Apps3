package b.h.n;

import android.os.Build;
import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import b.h.c;
import b.h.n.a0.b;
import b.h.n.a0.c;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;

public class a {
  public static final View.AccessibilityDelegate c = new View.AccessibilityDelegate();
  
  public final View.AccessibilityDelegate a;
  
  public final View.AccessibilityDelegate b;
  
  public a() {
    this(c);
  }
  
  public a(View.AccessibilityDelegate paramAccessibilityDelegate) {
    this.a = paramAccessibilityDelegate;
    this.b = new a(this);
  }
  
  public static List<b.a> c(View paramView) {
    List<?> list2 = (List)paramView.getTag(c.b);
    List<?> list1 = list2;
    if (list2 == null)
      list1 = Collections.emptyList(); 
    return (List)list1;
  }
  
  public boolean a(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return this.a.dispatchPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public c b(View paramView) {
    if (Build.VERSION.SDK_INT >= 16) {
      AccessibilityNodeProvider accessibilityNodeProvider = this.a.getAccessibilityNodeProvider(paramView);
      if (accessibilityNodeProvider != null)
        return new c(accessibilityNodeProvider); 
    } 
    return null;
  }
  
  public View.AccessibilityDelegate d() {
    return this.b;
  }
  
  public final boolean e(ClickableSpan paramClickableSpan, View paramView) {
    if (paramClickableSpan != null) {
      ClickableSpan[] arrayOfClickableSpan = b.n(paramView.createAccessibilityNodeInfo().getText());
      for (int i = 0; arrayOfClickableSpan != null && i < arrayOfClickableSpan.length; i++) {
        if (paramClickableSpan.equals(arrayOfClickableSpan[i]))
          return true; 
      } 
    } 
    return false;
  }
  
  public void f(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.a.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public void g(View paramView, b paramb) {
    this.a.onInitializeAccessibilityNodeInfo(paramView, paramb.m0());
  }
  
  public void h(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.a.onPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }
  
  public boolean i(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent) {
    return this.a.onRequestSendAccessibilityEvent(paramViewGroup, paramView, paramAccessibilityEvent);
  }
  
  public boolean j(View paramView, int paramInt, Bundle paramBundle) {
    List<b.a> list = c(paramView);
    boolean bool2 = false;
    int i = 0;
    while (true) {
      bool1 = bool2;
      if (i < list.size()) {
        b.a a1 = list.get(i);
        if (a1.a() == paramInt) {
          bool1 = a1.c(paramView, paramBundle);
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    bool2 = bool1;
    if (!bool1) {
      bool2 = bool1;
      if (Build.VERSION.SDK_INT >= 16)
        bool2 = this.a.performAccessibilityAction(paramView, paramInt, paramBundle); 
    } 
    boolean bool1 = bool2;
    if (!bool2) {
      bool1 = bool2;
      if (paramInt == c.a)
        bool1 = k(paramBundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1), paramView); 
    } 
    return bool1;
  }
  
  public final boolean k(int paramInt, View paramView) {
    SparseArray sparseArray = (SparseArray)paramView.getTag(c.c);
    if (sparseArray != null) {
      WeakReference<ClickableSpan> weakReference = (WeakReference)sparseArray.get(paramInt);
      if (weakReference != null) {
        ClickableSpan clickableSpan = weakReference.get();
        if (e(clickableSpan, paramView)) {
          clickableSpan.onClick(paramView);
          return true;
        } 
      } 
    } 
    return false;
  }
  
  public void l(View paramView, int paramInt) {
    this.a.sendAccessibilityEvent(paramView, paramInt);
  }
  
  public void m(View paramView, AccessibilityEvent paramAccessibilityEvent) {
    this.a.sendAccessibilityEventUnchecked(paramView, paramAccessibilityEvent);
  }
  
  public static final class a extends View.AccessibilityDelegate {
    public final a a;
    
    public a(a param1a) {
      this.a = param1a;
    }
    
    public boolean dispatchPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return this.a.a(param1View, param1AccessibilityEvent);
    }
    
    public AccessibilityNodeProvider getAccessibilityNodeProvider(View param1View) {
      c c = this.a.b(param1View);
      return (c != null) ? (AccessibilityNodeProvider)c.a() : null;
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.f(param1View, param1AccessibilityEvent);
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      b b = b.n0(param1AccessibilityNodeInfo);
      b.g0(r.C(param1View));
      b.a0(r.z(param1View));
      b.e0(r.j(param1View));
      b.k0(r.u(param1View));
      this.a.g(param1View, b);
      b.e(param1AccessibilityNodeInfo.getText(), param1View);
      List<b.a> list = a.c(param1View);
      for (int i = 0; i < list.size(); i++)
        b.b(list.get(i)); 
    }
    
    public void onPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.h(param1View, param1AccessibilityEvent);
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return this.a.i(param1ViewGroup, param1View, param1AccessibilityEvent);
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      return this.a.j(param1View, param1Int, param1Bundle);
    }
    
    public void sendAccessibilityEvent(View param1View, int param1Int) {
      this.a.l(param1View, param1Int);
    }
    
    public void sendAccessibilityEventUnchecked(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      this.a.m(param1View, param1AccessibilityEvent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */