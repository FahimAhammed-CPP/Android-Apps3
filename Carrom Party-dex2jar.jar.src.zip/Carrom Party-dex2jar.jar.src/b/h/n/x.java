package b.h.n;

import android.view.View;

public class x implements w {
  public void a(View paramView) {}
  
  public void c(View paramView) {}
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\n\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */