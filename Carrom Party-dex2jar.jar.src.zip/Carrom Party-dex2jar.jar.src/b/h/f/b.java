package b.h.f;

import android.content.LocusId;

public final class b {
  public LocusId a() {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\f\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */