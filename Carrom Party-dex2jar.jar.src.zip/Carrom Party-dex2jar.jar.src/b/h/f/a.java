package b.h.f;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.util.TypedValue;
import b.h.f.e.f;
import java.io.File;

public class a {
  public static final Object a = new Object();
  
  public static final Object b = new Object();
  
  public static TypedValue c;
  
  public static int a(Context paramContext, String paramString) {
    if (paramString != null)
      return paramContext.checkPermission(paramString, Process.myPid(), Process.myUid()); 
    throw new IllegalArgumentException("permission is null");
  }
  
  public static Context b(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? d.a(paramContext) : null;
  }
  
  public static File c(File paramFile) {
    synchronized (b) {
      if (!paramFile.exists()) {
        if (paramFile.mkdirs())
          return paramFile; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to create files subdir ");
        stringBuilder.append(paramFile.getPath());
        Log.w("ContextCompat", stringBuilder.toString());
      } 
      return paramFile;
    } 
  }
  
  public static int d(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 23) ? c.a(paramContext, paramInt) : paramContext.getResources().getColor(paramInt);
  }
  
  public static ColorStateList e(Context paramContext, int paramInt) {
    return f.c(paramContext.getResources(), paramInt, paramContext.getTheme());
  }
  
  public static Drawable f(Context paramContext, int paramInt) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21)
      return b.b(paramContext, paramInt); 
    if (i >= 16)
      return paramContext.getResources().getDrawable(paramInt); 
    synchronized (a) {
      if (c == null)
        c = new TypedValue(); 
      paramContext.getResources().getValue(paramInt, c, true);
      paramInt = c.resourceId;
      return paramContext.getResources().getDrawable(paramInt);
    } 
  }
  
  public static File g(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 21)
      return b.c(paramContext); 
    File file = new File((paramContext.getApplicationInfo()).dataDir, "no_backup");
    c(file);
    return file;
  }
  
  public static boolean h(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      a.a(paramContext, paramArrayOfIntent, paramBundle);
    } else {
      paramContext.startActivities(paramArrayOfIntent);
    } 
    return true;
  }
  
  public static void i(Context paramContext, Intent paramIntent, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      a.b(paramContext, paramIntent, paramBundle);
      return;
    } 
    paramContext.startActivity(paramIntent);
  }
  
  public static void j(Context paramContext, Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 26) {
      e.a(paramContext, paramIntent);
      return;
    } 
    paramContext.startService(paramIntent);
  }
  
  public static class a {
    public static void a(Context param1Context, Intent[] param1ArrayOfIntent, Bundle param1Bundle) {
      param1Context.startActivities(param1ArrayOfIntent, param1Bundle);
    }
    
    public static void b(Context param1Context, Intent param1Intent, Bundle param1Bundle) {
      param1Context.startActivity(param1Intent, param1Bundle);
    }
  }
  
  public static class b {
    public static File a(Context param1Context) {
      return param1Context.getCodeCacheDir();
    }
    
    public static Drawable b(Context param1Context, int param1Int) {
      return param1Context.getDrawable(param1Int);
    }
    
    public static File c(Context param1Context) {
      return param1Context.getNoBackupFilesDir();
    }
  }
  
  public static class c {
    public static int a(Context param1Context, int param1Int) {
      return param1Context.getColor(param1Int);
    }
    
    public static ColorStateList b(Context param1Context, int param1Int) {
      return param1Context.getColorStateList(param1Int);
    }
    
    public static <T> T c(Context param1Context, Class<T> param1Class) {
      return (T)param1Context.getSystemService(param1Class);
    }
    
    public static String d(Context param1Context, Class<?> param1Class) {
      return param1Context.getSystemServiceName(param1Class);
    }
  }
  
  public static class d {
    public static Context a(Context param1Context) {
      return param1Context.createDeviceProtectedStorageContext();
    }
    
    public static File b(Context param1Context) {
      return param1Context.getDataDir();
    }
    
    public static boolean c(Context param1Context) {
      return param1Context.isDeviceProtectedStorage();
    }
  }
  
  public static class e {
    public static ComponentName a(Context param1Context, Intent param1Intent) {
      return param1Context.startForegroundService(param1Intent);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\f\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */