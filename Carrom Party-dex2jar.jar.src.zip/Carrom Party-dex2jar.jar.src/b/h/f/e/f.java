package b.h.f.e;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import b.h.g.d;
import java.io.IOException;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class f {
  public static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static final WeakHashMap<b, SparseArray<a>> b = new WeakHashMap<b, SparseArray<a>>(0);
  
  public static final Object c = new Object();
  
  public static void a(b paramb, int paramInt, ColorStateList paramColorStateList) {
    synchronized (c) {
      WeakHashMap<b, SparseArray<a>> weakHashMap = b;
      SparseArray<a> sparseArray2 = weakHashMap.get(paramb);
      SparseArray<a> sparseArray1 = sparseArray2;
      if (sparseArray2 == null) {
        sparseArray1 = new SparseArray();
        weakHashMap.put(paramb, sparseArray1);
      } 
      sparseArray1.append(paramInt, new a(paramColorStateList, paramb.a.getConfiguration()));
      return;
    } 
  }
  
  public static ColorStateList b(b paramb, int paramInt) {
    synchronized (c) {
      SparseArray sparseArray = b.get(paramb);
      if (sparseArray != null && sparseArray.size() > 0) {
        a a = (a)sparseArray.get(paramInt);
        if (a != null) {
          if (a.b.equals(paramb.a.getConfiguration()))
            return a.a; 
          sparseArray.remove(paramInt);
        } 
      } 
      return null;
    } 
  }
  
  public static ColorStateList c(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    if (Build.VERSION.SDK_INT >= 23)
      return paramResources.getColorStateList(paramInt, paramTheme); 
    b b = new b(paramResources, paramTheme);
    ColorStateList colorStateList2 = b(b, paramInt);
    if (colorStateList2 != null)
      return colorStateList2; 
    ColorStateList colorStateList1 = g(paramResources, paramInt, paramTheme);
    if (colorStateList1 != null) {
      a(b, paramInt, colorStateList1);
      return colorStateList1;
    } 
    return paramResources.getColorStateList(paramInt);
  }
  
  public static Drawable d(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    return (Build.VERSION.SDK_INT >= 21) ? paramResources.getDrawable(paramInt, paramTheme) : paramResources.getDrawable(paramInt);
  }
  
  public static Typeface e(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, c paramc) {
    return paramContext.isRestricted() ? null : i(paramContext, paramInt1, paramTypedValue, paramInt2, paramc, null, true, false);
  }
  
  public static TypedValue f() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
  
  public static ColorStateList g(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    if (h(paramResources, paramInt))
      return null; 
    XmlResourceParser xmlResourceParser = paramResources.getXml(paramInt);
    try {
      return a.a(paramResources, (XmlPullParser)xmlResourceParser, paramTheme);
    } catch (Exception exception) {
      Log.e("ResourcesCompat", "Failed to inflate ColorStateList, leaving it to the framework", exception);
      return null;
    } 
  }
  
  public static boolean h(Resources paramResources, int paramInt) {
    TypedValue typedValue = f();
    paramResources.getValue(paramInt, typedValue, true);
    paramInt = typedValue.type;
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  public static Typeface i(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, c paramc, Handler paramHandler, boolean paramBoolean1, boolean paramBoolean2) {
    StringBuilder stringBuilder;
    Resources resources = paramContext.getResources();
    resources.getValue(paramInt1, paramTypedValue, true);
    Typeface typeface = j(paramContext, resources, paramTypedValue, paramInt1, paramInt2, paramc, paramHandler, paramBoolean1, paramBoolean2);
    if (typeface == null && paramc == null) {
      if (paramBoolean2)
        return typeface; 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Font resource ID #0x");
      stringBuilder.append(Integer.toHexString(paramInt1));
      stringBuilder.append(" could not be retrieved.");
      throw new Resources.NotFoundException(stringBuilder.toString());
    } 
    return (Typeface)stringBuilder;
  }
  
  public static Typeface j(Context paramContext, Resources paramResources, TypedValue paramTypedValue, int paramInt1, int paramInt2, c paramc, Handler paramHandler, boolean paramBoolean1, boolean paramBoolean2) {
    StringBuilder stringBuilder;
    String str;
    CharSequence charSequence = paramTypedValue.string;
    if (charSequence != null) {
      str = charSequence.toString();
      if (!str.startsWith("res/")) {
        if (paramc != null)
          paramc.a(-3, paramHandler); 
        return null;
      } 
      Typeface typeface = d.f(paramResources, paramInt1, paramInt2);
      if (typeface != null) {
        if (paramc != null)
          paramc.b(typeface, paramHandler); 
        return typeface;
      } 
      if (paramBoolean2)
        return null; 
      try {
        if (str.toLowerCase().endsWith(".xml")) {
          c.a a = c.b((XmlPullParser)paramResources.getXml(paramInt1), paramResources);
          if (a == null) {
            Log.e("ResourcesCompat", "Failed to find font-family tag");
            if (paramc != null) {
              paramc.a(-3, paramHandler);
              return null;
            } 
          } else {
            return d.c(paramContext, a, paramResources, paramInt1, paramInt2, paramc, paramHandler, paramBoolean1);
          } 
        } else {
          Typeface typeface1 = d.d(paramContext, paramResources, paramInt1, str, paramInt2);
          if (paramc != null) {
            if (typeface1 != null) {
              paramc.b(typeface1, paramHandler);
              return typeface1;
            } 
            paramc.a(-3, paramHandler);
          } 
          return typeface1;
        } 
      } catch (XmlPullParserException xmlPullParserException) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to parse xml resource ");
        stringBuilder.append(str);
        Log.e("ResourcesCompat", stringBuilder.toString(), (Throwable)xmlPullParserException);
        if (paramc != null)
          paramc.a(-3, paramHandler); 
        return null;
      } catch (IOException iOException) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to read xml resource ");
        stringBuilder.append(str);
        Log.e("ResourcesCompat", stringBuilder.toString(), iOException);
      } 
    } else {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Resource \"");
      stringBuilder1.append(stringBuilder.getResourceName(paramInt1));
      stringBuilder1.append("\" (");
      stringBuilder1.append(Integer.toHexString(paramInt1));
      stringBuilder1.append(") is not a Font: ");
      stringBuilder1.append(str);
      throw new Resources.NotFoundException(stringBuilder1.toString());
    } 
    return null;
  }
  
  public static class a {
    public final ColorStateList a;
    
    public final Configuration b;
    
    public a(ColorStateList param1ColorStateList, Configuration param1Configuration) {
      this.a = param1ColorStateList;
      this.b = param1Configuration;
    }
  }
  
  public static final class b {
    public final Resources a;
    
    public final Resources.Theme b;
    
    public b(Resources param1Resources, Resources.Theme param1Theme) {
      this.a = param1Resources;
      this.b = param1Theme;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (b.class != param1Object.getClass())
          return false; 
        param1Object = param1Object;
        return (this.a.equals(((b)param1Object).a) && b.h.m.c.a(this.b, ((b)param1Object).b));
      } 
      return false;
    }
    
    public int hashCode() {
      return b.h.m.c.b(new Object[] { this.a, this.b });
    }
  }
  
  public static abstract class c {
    public static Handler c(Handler param1Handler) {
      Handler handler = param1Handler;
      if (param1Handler == null)
        handler = new Handler(Looper.getMainLooper()); 
      return handler;
    }
    
    public final void a(int param1Int, Handler param1Handler) {
      c(param1Handler).post(new b(this, param1Int));
    }
    
    public final void b(Typeface param1Typeface, Handler param1Handler) {
      c(param1Handler).post(new a(this, param1Typeface));
    }
    
    public abstract void d(int param1Int);
    
    public abstract void e(Typeface param1Typeface);
    
    public class a implements Runnable {
      public a(f.c this$0, Typeface param2Typeface) {}
      
      public void run() {
        this.b.e(this.a);
      }
    }
    
    public class b implements Runnable {
      public b(f.c this$0, int param2Int) {}
      
      public void run() {
        this.b.d(this.a);
      }
    }
  }
  
  public class a implements Runnable {
    public a(f this$0, Typeface param1Typeface) {}
    
    public void run() {
      this.b.e(this.a);
    }
  }
  
  public class b implements Runnable {
    public b(f this$0, int param1Int) {}
    
    public void run() {
      this.b.d(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\f\e\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */