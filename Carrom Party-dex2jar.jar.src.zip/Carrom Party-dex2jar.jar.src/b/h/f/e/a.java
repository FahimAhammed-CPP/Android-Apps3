package b.h.f.e;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.StateSet;
import android.util.TypedValue;
import android.util.Xml;
import b.h.d;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class a {
  public static final ThreadLocal<TypedValue> a = new ThreadLocal<TypedValue>();
  
  public static ColorStateList a(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme) {
    int i;
    AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
    while (true) {
      i = paramXmlPullParser.next();
      if (i != 2 && i != 1)
        continue; 
      break;
    } 
    if (i == 2)
      return b(paramResources, paramXmlPullParser, attributeSet, paramTheme); 
    XmlPullParserException xmlPullParserException = new XmlPullParserException("No start tag found");
    throw xmlPullParserException;
  }
  
  public static ColorStateList b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
      return e(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramXmlPullParser.getPositionDescription());
    stringBuilder.append(": invalid color state list tag ");
    stringBuilder.append(str);
    throw new XmlPullParserException(stringBuilder.toString());
  }
  
  public static TypedValue c() {
    ThreadLocal<TypedValue> threadLocal = a;
    TypedValue typedValue2 = threadLocal.get();
    TypedValue typedValue1 = typedValue2;
    if (typedValue2 == null) {
      typedValue1 = new TypedValue();
      threadLocal.set(typedValue1);
    } 
    return typedValue1;
  }
  
  public static ColorStateList d(Resources paramResources, int paramInt, Resources.Theme paramTheme) {
    try {
      return a(paramResources, (XmlPullParser)paramResources.getXml(paramInt), paramTheme);
    } catch (Exception exception) {
      Log.e("CSLCompat", "Failed to inflate ColorStateList.", exception);
      return null;
    } 
  }
  
  public static ColorStateList e(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    int j = paramXmlPullParser.getDepth() + 1;
    int[][] arrayOfInt = new int[20][];
    int[] arrayOfInt1 = new int[20];
    int i = 0;
    while (true) {
      int k = paramXmlPullParser.next();
      if (k != 1) {
        int m = paramXmlPullParser.getDepth();
        if (m >= j || k != 3) {
          int[] arrayOfInt5 = arrayOfInt1;
          int[][] arrayOfInt4 = arrayOfInt;
          int n = i;
          if (k == 2) {
            arrayOfInt5 = arrayOfInt1;
            arrayOfInt4 = arrayOfInt;
            n = i;
            if (m <= j)
              if (!paramXmlPullParser.getName().equals("item")) {
                arrayOfInt5 = arrayOfInt1;
                arrayOfInt4 = arrayOfInt;
                n = i;
              } else {
                TypedArray typedArray = h(paramResources, paramTheme, paramAttributeSet, d.a);
                n = d.b;
                k = typedArray.getResourceId(n, -1);
                if (k != -1 && !f(paramResources, k)) {
                  try {
                    n = a(paramResources, (XmlPullParser)paramResources.getXml(k), paramTheme).getDefaultColor();
                  } catch (Exception exception) {
                    n = typedArray.getColor(d.b, -65281);
                  } 
                } else {
                  n = typedArray.getColor(n, -65281);
                } 
                float f = 1.0F;
                k = d.c;
                if (typedArray.hasValue(k)) {
                  f = typedArray.getFloat(k, 1.0F);
                } else {
                  k = d.d;
                  if (typedArray.hasValue(k))
                    f = typedArray.getFloat(k, 1.0F); 
                } 
                typedArray.recycle();
                int i1 = paramAttributeSet.getAttributeCount();
                int[] arrayOfInt6 = new int[i1];
                k = 0;
                for (m = 0; k < i1; m = i2) {
                  int i3 = paramAttributeSet.getAttributeNameResource(k);
                  int i2 = m;
                  if (i3 != 16843173) {
                    i2 = m;
                    if (i3 != 16843551) {
                      i2 = m;
                      if (i3 != b.h.a.a) {
                        if (paramAttributeSet.getAttributeBooleanValue(k, false)) {
                          i2 = i3;
                        } else {
                          i2 = -i3;
                        } 
                        arrayOfInt6[m] = i2;
                        i2 = m + 1;
                      } 
                    } 
                  } 
                  k++;
                } 
                arrayOfInt6 = StateSet.trimStateSet(arrayOfInt6, m);
                arrayOfInt5 = e.a(arrayOfInt1, i, g(n, f));
                arrayOfInt4 = e.<int[]>b(arrayOfInt, i, arrayOfInt6);
                n = i + 1;
              }  
          } 
          arrayOfInt1 = arrayOfInt5;
          arrayOfInt = arrayOfInt4;
          i = n;
          continue;
        } 
      } 
      int[] arrayOfInt2 = new int[i];
      int[][] arrayOfInt3 = new int[i][];
      System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, i);
      System.arraycopy(arrayOfInt, 0, arrayOfInt3, 0, i);
      return new ColorStateList(arrayOfInt3, arrayOfInt2);
    } 
  }
  
  public static boolean f(Resources paramResources, int paramInt) {
    TypedValue typedValue = c();
    paramResources.getValue(paramInt, typedValue, true);
    paramInt = typedValue.type;
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  public static int g(int paramInt, float paramFloat) {
    return paramInt & 0xFFFFFF | Math.round(Color.alpha(paramInt) * paramFloat) << 24;
  }
  
  public static TypedArray h(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int[] paramArrayOfint) {
    return (paramTheme == null) ? paramResources.obtainAttributes(paramAttributeSet, paramArrayOfint) : paramTheme.obtainStyledAttributes(paramAttributeSet, paramArrayOfint, 0, 0);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\f\e\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */