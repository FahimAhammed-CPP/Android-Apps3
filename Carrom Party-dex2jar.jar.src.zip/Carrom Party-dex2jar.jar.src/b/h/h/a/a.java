package b.h.h.a;

import android.view.Menu;

public interface a extends Menu {}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\h\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */