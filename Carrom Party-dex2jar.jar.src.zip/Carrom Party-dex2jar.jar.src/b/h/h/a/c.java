package b.h.h.a;

import android.view.SubMenu;

public interface c extends a, SubMenu {}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\h\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */