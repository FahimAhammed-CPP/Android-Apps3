package b.h.g.l;

import android.graphics.drawable.Drawable;

public interface c {
  void a(Drawable paramDrawable);
  
  Drawable b();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\g\l\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */