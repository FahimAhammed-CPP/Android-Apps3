package b.h.g.l;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public interface b {
  void setTint(int paramInt);
  
  void setTintList(ColorStateList paramColorStateList);
  
  void setTintMode(PorterDuff.Mode paramMode);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\g\l\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */