package b.h.g.l;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import java.lang.reflect.Method;

public class e extends d {
  public static Method h;
  
  public e(Drawable paramDrawable) {
    super(paramDrawable);
    g();
  }
  
  public e(f paramf, Resources paramResources) {
    super(paramf, paramResources);
    g();
  }
  
  public boolean c() {
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    null = bool;
    if (i == 21) {
      Drawable drawable = this.f;
      if (!(drawable instanceof android.graphics.drawable.GradientDrawable) && !(drawable instanceof android.graphics.drawable.DrawableContainer) && !(drawable instanceof android.graphics.drawable.InsetDrawable)) {
        null = bool;
        return (drawable instanceof android.graphics.drawable.RippleDrawable) ? true : null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public final void g() {
    if (h == null)
      try {
        h = Drawable.class.getDeclaredMethod("isProjected", new Class[0]);
        return;
      } catch (Exception exception) {
        Log.w("WrappedDrawableApi21", "Failed to retrieve Drawable#isProjected() method", exception);
      }  
  }
  
  public Rect getDirtyBounds() {
    return this.f.getDirtyBounds();
  }
  
  public void getOutline(Outline paramOutline) {
    this.f.getOutline(paramOutline);
  }
  
  public boolean isProjected() {
    Drawable drawable = this.f;
    if (drawable != null) {
      Method method = h;
      if (method != null)
        try {
          return ((Boolean)method.invoke(drawable, new Object[0])).booleanValue();
        } catch (Exception exception) {
          Log.w("WrappedDrawableApi21", "Error calling Drawable#isProjected() method", exception);
        }  
    } 
    return false;
  }
  
  public void setHotspot(float paramFloat1, float paramFloat2) {
    this.f.setHotspot(paramFloat1, paramFloat2);
  }
  
  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.f.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean setState(int[] paramArrayOfint) {
    if (super.setState(paramArrayOfint)) {
      invalidateSelf();
      return true;
    } 
    return false;
  }
  
  public void setTint(int paramInt) {
    if (c()) {
      super.setTint(paramInt);
      return;
    } 
    this.f.setTint(paramInt);
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    if (c()) {
      super.setTintList(paramColorStateList);
      return;
    } 
    this.f.setTintList(paramColorStateList);
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    if (c()) {
      super.setTintMode(paramMode);
      return;
    } 
    this.f.setTintMode(paramMode);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\g\l\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */