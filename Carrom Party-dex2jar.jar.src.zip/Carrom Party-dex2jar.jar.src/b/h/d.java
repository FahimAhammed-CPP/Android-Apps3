package b.h;

public final class d {
  public static final int A = 2;
  
  public static final int B = 3;
  
  public static final int C = 4;
  
  public static final int D = 5;
  
  public static final int E = 6;
  
  public static final int F = 7;
  
  public static final int G = 8;
  
  public static final int H = 9;
  
  public static final int I = 10;
  
  public static final int J = 11;
  
  public static final int[] K;
  
  public static final int L = 0;
  
  public static final int M = 1;
  
  public static final int[] a = new int[] { 16843173, 16843551, 2130903082 };
  
  public static final int b = 0;
  
  public static final int c = 1;
  
  public static final int d = 2;
  
  public static final int[] e = new int[] { 2130903206, 2130903207, 2130903208, 2130903209, 2130903210, 2130903211, 2130903212 };
  
  public static final int f = 0;
  
  public static final int g = 1;
  
  public static final int h = 2;
  
  public static final int i = 3;
  
  public static final int j = 4;
  
  public static final int k = 5;
  
  public static final int l = 6;
  
  public static final int[] m = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903204, 2130903213, 2130903214, 2130903215, 2130903361 };
  
  public static final int n = 0;
  
  public static final int o = 1;
  
  public static final int p = 2;
  
  public static final int q = 3;
  
  public static final int r = 4;
  
  public static final int s = 5;
  
  public static final int t = 6;
  
  public static final int u = 7;
  
  public static final int v = 8;
  
  public static final int w = 9;
  
  public static final int[] x = new int[] { 
      16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
      16844050, 16844051 };
  
  public static final int y = 0;
  
  public static final int z = 1;
  
  static {
    K = new int[] { 16843173, 16844052 };
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */