package b.h.e;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;

public final class p implements Iterable<Intent> {
  public final ArrayList<Intent> a = new ArrayList<Intent>();
  
  public final Context b;
  
  public p(Context paramContext) {
    this.b = paramContext;
  }
  
  public static p d(Context paramContext) {
    return new p(paramContext);
  }
  
  public p a(Intent paramIntent) {
    this.a.add(paramIntent);
    return this;
  }
  
  public p b(Activity paramActivity) {
    Intent intent1;
    if (paramActivity instanceof a) {
      intent1 = ((a)paramActivity).g();
    } else {
      intent1 = null;
    } 
    Intent intent2 = intent1;
    if (intent1 == null)
      intent2 = g.a(paramActivity); 
    if (intent2 != null) {
      ComponentName componentName2 = intent2.getComponent();
      ComponentName componentName1 = componentName2;
      if (componentName2 == null)
        componentName1 = intent2.resolveActivity(this.b.getPackageManager()); 
      c(componentName1);
      a(intent2);
    } 
    return this;
  }
  
  public p c(ComponentName paramComponentName) {
    int i = this.a.size();
    try {
      for (Intent intent = g.b(this.b, paramComponentName); intent != null; intent = g.b(this.b, intent.getComponent()))
        this.a.add(i, intent); 
      return this;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
      IllegalArgumentException illegalArgumentException = new IllegalArgumentException((Throwable)nameNotFoundException);
      throw illegalArgumentException;
    } 
  }
  
  public PendingIntent e(int paramInt1, int paramInt2) {
    return g(paramInt1, paramInt2, null);
  }
  
  public PendingIntent g(int paramInt1, int paramInt2, Bundle paramBundle) {
    if (!this.a.isEmpty()) {
      ArrayList<Intent> arrayList = this.a;
      Intent[] arrayOfIntent = arrayList.<Intent>toArray(new Intent[arrayList.size()]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      return (Build.VERSION.SDK_INT >= 16) ? PendingIntent.getActivities(this.b, paramInt1, arrayOfIntent, paramInt2, paramBundle) : PendingIntent.getActivities(this.b, paramInt1, arrayOfIntent, paramInt2);
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot getPendingIntent");
  }
  
  public void i() {
    j(null);
  }
  
  @Deprecated
  public Iterator<Intent> iterator() {
    return this.a.iterator();
  }
  
  public void j(Bundle paramBundle) {
    if (!this.a.isEmpty()) {
      ArrayList<Intent> arrayList = this.a;
      Intent[] arrayOfIntent = arrayList.<Intent>toArray(new Intent[arrayList.size()]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      if (!b.h.f.a.h(this.b, arrayOfIntent, paramBundle)) {
        Intent intent = new Intent(arrayOfIntent[arrayOfIntent.length - 1]);
        intent.addFlags(268435456);
        this.b.startActivity(intent);
      } 
      return;
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
  }
  
  public static interface a {
    Intent g();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\e\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */