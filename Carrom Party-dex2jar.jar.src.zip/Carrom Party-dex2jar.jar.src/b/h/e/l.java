package b.h.e;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import java.util.HashSet;

public final class l {
  public final Context a;
  
  public final NotificationManager b;
  
  static {
    new HashSet();
  }
  
  public l(Context paramContext) {
    this.a = paramContext;
    this.b = (NotificationManager)paramContext.getSystemService("notification");
  }
  
  public static l b(Context paramContext) {
    return new l(paramContext);
  }
  
  public boolean a() {
    int i = Build.VERSION.SDK_INT;
    if (i >= 24)
      return this.b.areNotificationsEnabled(); 
    boolean bool = true;
    if (i >= 19) {
      AppOpsManager appOpsManager = (AppOpsManager)this.a.getSystemService("appops");
      ApplicationInfo applicationInfo = this.a.getApplicationInfo();
      String str = this.a.getApplicationContext().getPackageName();
      i = applicationInfo.uid;
      try {
        Class<?> clazz = Class.forName(AppOpsManager.class.getName());
        Class<int> clazz1 = int.class;
        i = ((Integer)clazz.getMethod("checkOpNoThrow", new Class[] { clazz1, clazz1, String.class }).invoke(appOpsManager, new Object[] { Integer.valueOf(((Integer)clazz.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue()), Integer.valueOf(i), str })).intValue();
        return (i == 0);
      } catch (ClassNotFoundException|NoSuchMethodException|NoSuchFieldException|java.lang.reflect.InvocationTargetException|IllegalAccessException|RuntimeException classNotFoundException) {
        return true;
      } 
    } 
    return bool;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\e\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */