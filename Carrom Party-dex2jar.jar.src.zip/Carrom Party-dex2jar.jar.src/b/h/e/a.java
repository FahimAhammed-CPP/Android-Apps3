package b.h.e;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import b.h.f.a;
import java.util.Arrays;

public class a extends a {
  public static d d;
  
  public static void k(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramActivity.finishAffinity();
      return;
    } 
    paramActivity.finish();
  }
  
  public static void l(Activity paramActivity) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 28) {
      paramActivity.recreate();
      return;
    } 
    if (i <= 23) {
      (new Handler(paramActivity.getMainLooper())).post(new b(paramActivity));
      return;
    } 
    if (!c.i(paramActivity))
      paramActivity.recreate(); 
  }
  
  public static void m(Activity paramActivity, String[] paramArrayOfString, int paramInt) {
    StringBuilder stringBuilder;
    d d1 = d;
    if (d1 != null && d1.a(paramActivity, paramArrayOfString, paramInt))
      return; 
    int j = paramArrayOfString.length;
    int i = 0;
    while (i < j) {
      if (!TextUtils.isEmpty(paramArrayOfString[i])) {
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Permission request for permissions ");
      stringBuilder.append(Arrays.toString((Object[])paramArrayOfString));
      stringBuilder.append(" must not contain null or empty values");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (stringBuilder instanceof e)
        ((e)stringBuilder).b(paramInt); 
      stringBuilder.requestPermissions(paramArrayOfString, paramInt);
      return;
    } 
    if (stringBuilder instanceof c)
      (new Handler(Looper.getMainLooper())).post(new a(paramArrayOfString, (Activity)stringBuilder, paramInt)); 
  }
  
  public static boolean n(Activity paramActivity, String paramString) {
    return (Build.VERSION.SDK_INT >= 23) ? paramActivity.shouldShowRequestPermissionRationale(paramString) : false;
  }
  
  public static void o(Activity paramActivity, Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramActivity.startActivityForResult(paramIntent, paramInt, paramBundle);
      return;
    } 
    paramActivity.startActivityForResult(paramIntent, paramInt);
  }
  
  public static void p(Activity paramActivity, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 16) {
      paramActivity.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
      return;
    } 
    paramActivity.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public class a implements Runnable {
    public a(a this$0, Activity param1Activity, int param1Int) {}
    
    public void run() {
      int[] arrayOfInt = new int[this.a.length];
      PackageManager packageManager = this.b.getPackageManager();
      String str = this.b.getPackageName();
      int j = this.a.length;
      for (int i = 0; i < j; i++)
        arrayOfInt[i] = packageManager.checkPermission(this.a[i], str); 
      ((a.c)this.b).onRequestPermissionsResult(this.c, this.a, arrayOfInt);
    }
  }
  
  public class b implements Runnable {
    public b(a this$0) {}
    
    public void run() {
      if (!this.a.isFinishing() && !c.i(this.a))
        this.a.recreate(); 
    }
  }
  
  public static interface c {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface d {
    boolean a(Activity param1Activity, String[] param1ArrayOfString, int param1Int);
  }
  
  public static interface e {
    void b(int param1Int);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\e\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */