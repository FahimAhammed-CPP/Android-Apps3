package b.h.e;

import android.app.Notification;

public interface h {
  Notification.Builder a();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\e\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */