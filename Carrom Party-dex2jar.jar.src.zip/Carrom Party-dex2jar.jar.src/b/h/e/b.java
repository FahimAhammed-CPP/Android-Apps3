package b.h.e;

import android.os.Bundle;

public class b {
  public Bundle a() {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\e\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */