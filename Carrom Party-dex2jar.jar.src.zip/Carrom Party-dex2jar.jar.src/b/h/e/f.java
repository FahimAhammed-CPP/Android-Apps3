package b.h.e;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import b.f.g;
import b.h.n.e;
import b.n.d;
import b.n.g;
import b.n.h;
import b.n.p;

public class f extends Activity implements g, e.a {
  public h a;
  
  public f() {
    new g();
    this.a = new h(this);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && e.d(view, paramKeyEvent)) ? true : e.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && e.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public boolean k(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  @SuppressLint({"RestrictedApi"})
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    p.f(this);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    this.a.j(d.c.c);
    super.onSaveInstanceState(paramBundle);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\e\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */