package b.h.e;

import android.app.Person;
import android.graphics.drawable.Icon;
import androidx.core.graphics.drawable.IconCompat;

public class m {
  public CharSequence a;
  
  public IconCompat b;
  
  public String c;
  
  public String d;
  
  public boolean e;
  
  public boolean f;
  
  public IconCompat a() {
    return this.b;
  }
  
  public String b() {
    return this.d;
  }
  
  public CharSequence c() {
    return this.a;
  }
  
  public String d() {
    return this.c;
  }
  
  public boolean e() {
    return this.e;
  }
  
  public boolean f() {
    return this.f;
  }
  
  public String g() {
    String str = this.c;
    if (str != null)
      return str; 
    if (this.a != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("name:");
      stringBuilder.append(this.a);
      return stringBuilder.toString();
    } 
    return "";
  }
  
  public Person h() {
    Icon icon;
    Person.Builder builder = (new Person.Builder()).setName(c());
    if (a() != null) {
      icon = a().p();
    } else {
      icon = null;
    } 
    return builder.setIcon(icon).setUri(d()).setKey(b()).setBot(e()).setImportant(f()).build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\e\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */