package b.h.e;

import android.app.RemoteInput;
import android.os.Build;
import android.os.Bundle;
import java.util.Iterator;
import java.util.Set;

public final class n {
  public static RemoteInput a(n paramn) {
    RemoteInput.Builder builder = (new RemoteInput.Builder(paramn.i())).setLabel(paramn.h()).setChoices(paramn.e()).setAllowFreeFormInput(paramn.c()).addExtras(paramn.g());
    if (Build.VERSION.SDK_INT >= 26) {
      Set<String> set = paramn.d();
      if (set != null) {
        Iterator<String> iterator = set.iterator();
        while (iterator.hasNext())
          builder.setAllowDataType(iterator.next(), true); 
      } 
    } 
    if (Build.VERSION.SDK_INT >= 29)
      builder.setEditChoicesBeforeSending(paramn.f()); 
    return builder.build();
  }
  
  public static RemoteInput[] b(n[] paramArrayOfn) {
    if (paramArrayOfn == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfn.length];
    for (int i = 0; i < paramArrayOfn.length; i++)
      arrayOfRemoteInput[i] = a(paramArrayOfn[i]); 
    return arrayOfRemoteInput;
  }
  
  public boolean c() {
    throw null;
  }
  
  public Set<String> d() {
    throw null;
  }
  
  public CharSequence[] e() {
    throw null;
  }
  
  public int f() {
    throw null;
  }
  
  public Bundle g() {
    throw null;
  }
  
  public CharSequence h() {
    throw null;
  }
  
  public String i() {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\e\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */