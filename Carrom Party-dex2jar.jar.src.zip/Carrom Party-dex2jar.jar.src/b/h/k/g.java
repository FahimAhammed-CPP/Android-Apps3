package b.h.k;

import android.os.Handler;
import android.os.Process;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class g {
  public static ThreadPoolExecutor a(String paramString, int paramInt1, int paramInt2) {
    a a = new a(paramString, paramInt1);
    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, paramInt2, TimeUnit.MILLISECONDS, new LinkedBlockingDeque<Runnable>(), a);
    threadPoolExecutor.allowCoreThreadTimeOut(true);
    return threadPoolExecutor;
  }
  
  public static <T> void b(Executor paramExecutor, Callable<T> paramCallable, b.h.m.a<T> parama) {
    paramExecutor.execute(new b<T>(b.a(), paramCallable, parama));
  }
  
  public static <T> T c(ExecutorService paramExecutorService, Callable<T> paramCallable, int paramInt) {
    Future<T> future = paramExecutorService.submit(paramCallable);
    long l = paramInt;
    try {
      return future.get(l, TimeUnit.MILLISECONDS);
    } catch (ExecutionException executionException) {
      throw new RuntimeException(executionException);
    } catch (InterruptedException interruptedException) {
      throw interruptedException;
    } catch (TimeoutException timeoutException) {
      throw new InterruptedException("timeout");
    } 
  }
  
  public static class a implements ThreadFactory {
    public String a;
    
    public int b;
    
    public a(String param1String, int param1Int) {
      this.a = param1String;
      this.b = param1Int;
    }
    
    public Thread newThread(Runnable param1Runnable) {
      return new a(param1Runnable, this.a, this.b);
    }
    
    public static class a extends Thread {
      public final int a;
      
      public a(Runnable param2Runnable, String param2String, int param2Int) {
        super(param2Runnable, param2String);
        this.a = param2Int;
      }
      
      public void run() {
        Process.setThreadPriority(this.a);
        super.run();
      }
    }
  }
  
  public static class a extends Thread {
    public final int a;
    
    public a(Runnable param1Runnable, String param1String, int param1Int) {
      super(param1Runnable, param1String);
      this.a = param1Int;
    }
    
    public void run() {
      Process.setThreadPriority(this.a);
      super.run();
    }
  }
  
  public static class b<T> implements Runnable {
    public Callable<T> a;
    
    public b.h.m.a<T> b;
    
    public Handler c;
    
    public b(Handler param1Handler, Callable<T> param1Callable, b.h.m.a<T> param1a) {
      this.a = param1Callable;
      this.b = param1a;
      this.c = param1Handler;
    }
    
    public void run() {
      try {
        T t = this.a.call();
      } catch (Exception exception) {
        exception = null;
      } 
      b.h.m.a<T> a1 = this.b;
      this.c.post(new a(this, a1, exception));
    }
    
    public class a implements Runnable {
      public a(g.b this$0, b.h.m.a param2a, Object param2Object) {}
      
      public void run() {
        this.a.a(this.b);
      }
    }
  }
  
  public class a implements Runnable {
    public a(g this$0, b.h.m.a param1a, Object param1Object) {}
    
    public void run() {
      this.a.a(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\k\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */