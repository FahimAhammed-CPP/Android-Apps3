package b.h.k;

import android.graphics.Typeface;
import android.os.Handler;

public class a {
  public final f.c a;
  
  public final Handler b;
  
  public a(f.c paramc, Handler paramHandler) {
    this.a = paramc;
    this.b = paramHandler;
  }
  
  public final void a(int paramInt) {
    f.c c1 = this.a;
    this.b.post(new b(this, c1, paramInt));
  }
  
  public void b(e.e parame) {
    if (parame.a()) {
      c(parame.a);
      return;
    } 
    a(parame.b);
  }
  
  public final void c(Typeface paramTypeface) {
    f.c c1 = this.a;
    this.b.post(new a(this, c1, paramTypeface));
  }
  
  public class a implements Runnable {
    public a(a this$0, f.c param1c, Typeface param1Typeface) {}
    
    public void run() {
      this.a.b(this.b);
    }
  }
  
  public class b implements Runnable {
    public b(a this$0, f.c param1c, int param1Int) {}
    
    public void run() {
      this.a.a(this.b);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\k\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */