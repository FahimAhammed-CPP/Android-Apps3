package b.h.k;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import b.f.g;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public class e {
  public static final b.f.e<String, Typeface> a = new b.f.e(16);
  
  public static final ExecutorService b = g.a("fonts-androidx", 10, 10000);
  
  public static final Object c = new Object();
  
  public static final g<String, ArrayList<b.h.m.a<e>>> d = new g();
  
  public static String a(d paramd, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramd.d());
    stringBuilder.append("-");
    stringBuilder.append(paramInt);
    return stringBuilder.toString();
  }
  
  @SuppressLint({"WrongConstant"})
  public static int b(f.a parama) {
    int i = parama.c();
    int j = 1;
    if (i != 0)
      return (parama.c() != 1) ? -3 : -2; 
    f.b[] arrayOfB = parama.b();
    if (arrayOfB != null) {
      if (arrayOfB.length == 0)
        return 1; 
      int k = arrayOfB.length;
      byte b = 0;
      i = 0;
      while (true) {
        j = b;
        if (i < k) {
          j = arrayOfB[i].b();
          if (j != 0)
            return (j < 0) ? -3 : j; 
          i++;
          continue;
        } 
        break;
      } 
    } 
    return j;
  }
  
  public static e c(String paramString, Context paramContext, d paramd, int paramInt) {
    b.f.e<String, Typeface> e1 = a;
    Typeface typeface = (Typeface)e1.c(paramString);
    if (typeface != null)
      return new e(typeface); 
    try {
      f.a a = c.d(paramContext, paramd, null);
      int i = b(a);
      if (i != 0)
        return new e(i); 
      Typeface typeface1 = b.h.g.d.b(paramContext, null, a.b(), paramInt);
      if (typeface1 != null) {
        e1.d(paramString, typeface1);
        return new e(typeface1);
      } 
      return new e(-3);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return new e(-1);
    } 
  }
  
  public static Typeface d(Context paramContext, d paramd, int paramInt, Executor paramExecutor, a parama) {
    String str = a(paramd, paramInt);
    Typeface typeface = (Typeface)a.c(str);
    if (typeface != null) {
      parama.b(new e(typeface));
      return typeface;
    } 
    b b = new b(parama);
    synchronized (c) {
      g<String, ArrayList<b.h.m.a<e>>> g1 = d;
      ArrayList<b> arrayList = (ArrayList)g1.get(str);
      if (arrayList != null) {
        arrayList.add(b);
        return null;
      } 
      arrayList = new ArrayList<b>();
      arrayList.add(b);
      g1.put(str, arrayList);
      c c = new c(str, paramContext, paramd, paramInt);
      Executor executor = paramExecutor;
      if (paramExecutor == null)
        executor = b; 
      g.b(executor, c, new d(str));
      return null;
    } 
  }
  
  public static Typeface e(Context paramContext, d paramd, a parama, int paramInt1, int paramInt2) {
    e e1;
    String str = a(paramd, paramInt1);
    Typeface typeface = (Typeface)a.c(str);
    if (typeface != null) {
      parama.b(new e(typeface));
      return typeface;
    } 
    if (paramInt2 == -1) {
      e1 = c(str, paramContext, paramd, paramInt1);
      parama.b(e1);
      return e1.a;
    } 
    a a1 = new a(str, (Context)e1, paramd, paramInt1);
    try {
      e e2 = g.<e>c(b, a1, paramInt2);
      parama.b(e2);
      return e2.a;
    } catch (InterruptedException interruptedException) {
      parama.b(new e(-3));
      return null;
    } 
  }
  
  public class a implements Callable<e> {
    public a(e this$0, Context param1Context, d param1d, int param1Int) {}
    
    public e.e a() {
      return e.c(this.a, this.b, this.c, this.d);
    }
  }
  
  public class b implements b.h.m.a<e> {
    public b(e this$0) {}
    
    public void b(e.e param1e) {
      this.a.b(param1e);
    }
  }
  
  public class c implements Callable<e> {
    public c(e this$0, Context param1Context, d param1d, int param1Int) {}
    
    public e.e a() {
      return e.c(this.a, this.b, this.c, this.d);
    }
  }
  
  public class d implements b.h.m.a<e> {
    public d(e this$0) {}
    
    public void b(e.e param1e) {
      synchronized (e.c) {
        g<String, ArrayList<b.h.m.a<e.e>>> g = e.d;
        ArrayList<b.h.m.a> arrayList = (ArrayList)g.get(this.a);
        if (arrayList == null)
          return; 
        g.remove(this.a);
        for (int i = 0; i < arrayList.size(); i++)
          ((b.h.m.a)arrayList.get(i)).a(param1e); 
        return;
      } 
    }
  }
  
  public static final class e {
    public final Typeface a = null;
    
    public final int b;
    
    public e(int param1Int) {
      this.b = param1Int;
    }
    
    @SuppressLint({"WrongConstant"})
    public e(Typeface param1Typeface) {
      this.b = 0;
    }
    
    @SuppressLint({"WrongConstant"})
    public boolean a() {
      return (this.b == 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\k\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */