package b.h.k;

import android.os.Handler;
import android.os.Looper;

public class b {
  public static Handler a() {
    return (Looper.myLooper() == null) ? new Handler(Looper.getMainLooper()) : new Handler();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\k\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */