package b.h.k;

import android.util.Base64;
import b.h.m.h;
import java.util.List;

public final class d {
  public final String a;
  
  public final String b;
  
  public final String c;
  
  public final List<List<byte[]>> d;
  
  public final int e;
  
  public final String f;
  
  public d(String paramString1, String paramString2, String paramString3, List<List<byte[]>> paramList) {
    h.b(paramString1);
    this.a = paramString1;
    h.b(paramString2);
    this.b = paramString2;
    h.b(paramString3);
    this.c = paramString3;
    h.b(paramList);
    this.d = paramList;
    this.e = 0;
    this.f = a(paramString1, paramString2, paramString3);
  }
  
  public final String a(String paramString1, String paramString2, String paramString3) {
    StringBuilder stringBuilder = new StringBuilder(paramString1);
    stringBuilder.append("-");
    stringBuilder.append(paramString2);
    stringBuilder.append("-");
    stringBuilder.append(paramString3);
    return stringBuilder.toString();
  }
  
  public List<List<byte[]>> b() {
    return this.d;
  }
  
  public int c() {
    return this.e;
  }
  
  public String d() {
    return this.f;
  }
  
  public String e() {
    return this.a;
  }
  
  public String f() {
    return this.b;
  }
  
  public String g() {
    return this.c;
  }
  
  public String toString() {
    StringBuilder stringBuilder1 = new StringBuilder();
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("FontRequest {mProviderAuthority: ");
    stringBuilder2.append(this.a);
    stringBuilder2.append(", mProviderPackage: ");
    stringBuilder2.append(this.b);
    stringBuilder2.append(", mQuery: ");
    stringBuilder2.append(this.c);
    stringBuilder2.append(", mCertificates:");
    stringBuilder1.append(stringBuilder2.toString());
    for (int i = 0; i < this.d.size(); i++) {
      stringBuilder1.append(" [");
      List<byte[]> list = this.d.get(i);
      for (int j = 0; j < list.size(); j++) {
        stringBuilder1.append(" \"");
        stringBuilder1.append(Base64.encodeToString(list.get(j), 0));
        stringBuilder1.append("\"");
      } 
      stringBuilder1.append(" ]");
    } 
    stringBuilder1.append("}");
    stringBuilder2 = new StringBuilder();
    stringBuilder2.append("mCertificatesArray: ");
    stringBuilder2.append(this.e);
    stringBuilder1.append(stringBuilder2.toString());
    return stringBuilder1.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\h\k\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */