package b.n;

import java.util.HashMap;

public class l {
  public l() {
    new HashMap<Object, Object>();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */