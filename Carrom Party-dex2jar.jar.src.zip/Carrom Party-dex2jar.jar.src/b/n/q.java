package b.n;

import androidx.savedstate.SavedStateRegistry;

public final class q {
  public SavedStateRegistry.b a() {
    throw null;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */