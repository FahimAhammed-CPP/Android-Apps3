package b.n;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;

public class p extends Fragment {
  public a a;
  
  public static void a(Activity paramActivity, d.b paramb) {
    if (paramActivity instanceof i) {
      ((i)paramActivity).a().h(paramb);
      return;
    } 
    if (paramActivity instanceof g) {
      d d = ((g)paramActivity).a();
      if (d instanceof h)
        ((h)d).h(paramb); 
    } 
  }
  
  public static void f(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 29)
      b.registerIn(paramActivity); 
    FragmentManager fragmentManager = paramActivity.getFragmentManager();
    if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
      fragmentManager.beginTransaction().add(new p(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
      fragmentManager.executePendingTransactions();
    } 
  }
  
  public final void b(d.b paramb) {
    if (Build.VERSION.SDK_INT < 29)
      a(getActivity(), paramb); 
  }
  
  public final void c(a parama) {
    if (parama != null)
      parama.a(); 
  }
  
  public final void d(a parama) {
    if (parama != null)
      parama.onResume(); 
  }
  
  public final void e(a parama) {
    if (parama != null)
      parama.onStart(); 
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
    c(this.a);
    b(d.b.ON_CREATE);
  }
  
  public void onDestroy() {
    super.onDestroy();
    b(d.b.ON_DESTROY);
    this.a = null;
  }
  
  public void onPause() {
    super.onPause();
    b(d.b.ON_PAUSE);
  }
  
  public void onResume() {
    super.onResume();
    d(this.a);
    b(d.b.ON_RESUME);
  }
  
  public void onStart() {
    super.onStart();
    e(this.a);
    b(d.b.ON_START);
  }
  
  public void onStop() {
    super.onStop();
    b(d.b.ON_STOP);
  }
  
  public static interface a {
    void a();
    
    void onResume();
    
    void onStart();
  }
  
  public static class b implements Application.ActivityLifecycleCallbacks {
    public static void registerIn(Activity param1Activity) {
      param1Activity.registerActivityLifecycleCallbacks(new b());
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityDestroyed(Activity param1Activity) {}
    
    public void onActivityPaused(Activity param1Activity) {}
    
    public void onActivityPostCreated(Activity param1Activity, Bundle param1Bundle) {
      p.a(param1Activity, d.b.ON_CREATE);
    }
    
    public void onActivityPostResumed(Activity param1Activity) {
      p.a(param1Activity, d.b.ON_RESUME);
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      p.a(param1Activity, d.b.ON_START);
    }
    
    public void onActivityPreDestroyed(Activity param1Activity) {
      p.a(param1Activity, d.b.ON_DESTROY);
    }
    
    public void onActivityPrePaused(Activity param1Activity) {
      p.a(param1Activity, d.b.ON_PAUSE);
    }
    
    public void onActivityPreStopped(Activity param1Activity) {
      p.a(param1Activity, d.b.ON_STOP);
    }
    
    public void onActivityResumed(Activity param1Activity) {}
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {}
    
    public void onActivityStarted(Activity param1Activity) {}
    
    public void onActivityStopped(Activity param1Activity) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */