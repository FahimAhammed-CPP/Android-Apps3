package b.n;

import android.view.View;
import b.n.z.a;

public class x {
  public static void a(View paramView, v paramv) {
    paramView.setTag(a.a, paramv);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */