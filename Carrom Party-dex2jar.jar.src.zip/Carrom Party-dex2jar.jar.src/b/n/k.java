package b.n;

import androidx.lifecycle.CompositeGeneratedAdaptersObserver;
import androidx.lifecycle.FullLifecycleObserverAdapter;
import androidx.lifecycle.ReflectiveGenericLifecycleObserver;
import androidx.lifecycle.SingleGeneratedAdapterObserver;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class k {
  public static Map<Class<?>, Integer> a = new HashMap<Class<?>, Integer>();
  
  public static Map<Class<?>, List<Constructor<? extends c>>> b = new HashMap<Class<?>, List<Constructor<? extends c>>>();
  
  public static c a(Constructor<? extends c> paramConstructor, Object paramObject) {
    try {
      return paramConstructor.newInstance(new Object[] { paramObject });
    } catch (IllegalAccessException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } catch (InstantiationException instantiationException) {
      throw new RuntimeException(instantiationException);
    } catch (InvocationTargetException invocationTargetException) {
      throw new RuntimeException(invocationTargetException);
    } 
  }
  
  public static Constructor<? extends c> b(Class<?> paramClass) {
    try {
      String str1;
      Package package_ = paramClass.getPackage();
      String str2 = paramClass.getCanonicalName();
      if (package_ != null) {
        str1 = package_.getName();
      } else {
        str1 = "";
      } 
      if (!str1.isEmpty())
        str2 = str2.substring(str1.length() + 1); 
      str2 = c(str2);
      if (str1.isEmpty()) {
        str1 = str2;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str1);
        stringBuilder.append(".");
        stringBuilder.append(str2);
        str1 = stringBuilder.toString();
      } 
      Constructor<?> constructor = Class.forName(str1).getDeclaredConstructor(new Class[] { paramClass });
      if (!constructor.isAccessible())
        constructor.setAccessible(true); 
      return (Constructor)constructor;
    } catch (ClassNotFoundException classNotFoundException) {
      return null;
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new RuntimeException(noSuchMethodException);
    } 
  }
  
  public static String c(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString.replace(".", "_"));
    stringBuilder.append("_LifecycleAdapter");
    return stringBuilder.toString();
  }
  
  public static int d(Class<?> paramClass) {
    Integer integer = a.get(paramClass);
    if (integer != null)
      return integer.intValue(); 
    int i = g(paramClass);
    a.put(paramClass, Integer.valueOf(i));
    return i;
  }
  
  public static boolean e(Class<?> paramClass) {
    return (paramClass != null && f.class.isAssignableFrom(paramClass));
  }
  
  public static e f(Object paramObject) {
    boolean bool1 = paramObject instanceof e;
    boolean bool2 = paramObject instanceof b;
    if (bool1 && bool2)
      return (e)new FullLifecycleObserverAdapter((b)paramObject, (e)paramObject); 
    if (bool2)
      return (e)new FullLifecycleObserverAdapter((b)paramObject, null); 
    if (bool1)
      return (e)paramObject; 
    Class<?> clazz = paramObject.getClass();
    if (d(clazz) == 2) {
      List<Constructor<? extends c>> list = b.get(clazz);
      int j = list.size();
      int i = 0;
      if (j == 1)
        return (e)new SingleGeneratedAdapterObserver(a(list.get(0), paramObject)); 
      c[] arrayOfC = new c[list.size()];
      while (i < list.size()) {
        arrayOfC[i] = a(list.get(i), paramObject);
        i++;
      } 
      return (e)new CompositeGeneratedAdaptersObserver(arrayOfC);
    } 
    return (e)new ReflectiveGenericLifecycleObserver(paramObject);
  }
  
  public static int g(Class<?> paramClass) {
    ArrayList<Constructor<? extends c>> arrayList;
    if (paramClass.getCanonicalName() == null)
      return 1; 
    Constructor<? extends c> constructor = b(paramClass);
    if (constructor != null) {
      b.put(paramClass, Collections.singletonList(constructor));
      return 2;
    } 
    if (a.c.d(paramClass))
      return 1; 
    Class<?> clazz = paramClass.getSuperclass();
    constructor = null;
    if (e(clazz)) {
      if (d(clazz) == 1)
        return 1; 
      arrayList = new ArrayList(b.get(clazz));
    } 
    for (Class<?> clazz1 : paramClass.getInterfaces()) {
      if (e(clazz1)) {
        if (d(clazz1) == 1)
          return 1; 
        ArrayList<Constructor<? extends c>> arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList1.addAll(b.get(clazz1));
        arrayList = arrayList1;
      } 
    } 
    if (arrayList != null) {
      b.put(paramClass, arrayList);
      return 2;
    } 
    return 1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */