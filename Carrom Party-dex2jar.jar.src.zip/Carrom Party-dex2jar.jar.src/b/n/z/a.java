package b.n.z;

public final class a {
  public static final int a = 2131296542;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\z\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */