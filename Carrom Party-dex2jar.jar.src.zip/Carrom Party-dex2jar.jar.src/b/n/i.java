package b.n;

@Deprecated
public interface i extends g {
  h a();
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */