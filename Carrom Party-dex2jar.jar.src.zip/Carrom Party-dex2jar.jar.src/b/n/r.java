package b.n;

import android.os.Handler;

public class r {
  public final h a;
  
  public final Handler b;
  
  public a c;
  
  public r(g paramg) {
    this.a = new h(paramg);
    this.b = new Handler();
  }
  
  public d a() {
    return this.a;
  }
  
  public void b() {
    f(d.b.ON_START);
  }
  
  public void c() {
    f(d.b.ON_CREATE);
  }
  
  public void d() {
    f(d.b.ON_STOP);
    f(d.b.ON_DESTROY);
  }
  
  public void e() {
    f(d.b.ON_START);
  }
  
  public final void f(d.b paramb) {
    a a2 = this.c;
    if (a2 != null)
      a2.run(); 
    a a1 = new a(this.a, paramb);
    this.c = a1;
    this.b.postAtFrontOfQueue(a1);
  }
  
  public static class a implements Runnable {
    public final h a;
    
    public final d.b b;
    
    public boolean c = false;
    
    public a(h param1h, d.b param1b) {
      this.a = param1h;
      this.b = param1b;
    }
    
    public void run() {
      if (!this.c) {
        this.a.h(this.b);
        this.c = true;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */