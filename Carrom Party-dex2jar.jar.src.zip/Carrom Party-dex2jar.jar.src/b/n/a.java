package b.n;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class a {
  public static a c = new a();
  
  public final Map<Class<?>, a> a = new HashMap<Class<?>, a>();
  
  public final Map<Class<?>, Boolean> b = new HashMap<Class<?>, Boolean>();
  
  public final a a(Class<?> paramClass, Method[] paramArrayOfMethod) {
    Class<?> clazz = paramClass.getSuperclass();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (clazz != null) {
      a a2 = c(clazz);
      if (a2 != null)
        hashMap.putAll(a2.b); 
    } 
    Class[] arrayOfClass = paramClass.getInterfaces();
    int j = arrayOfClass.length;
    int i;
    for (i = 0; i < j; i++) {
      for (Map.Entry<b, d.b> entry : (c(arrayOfClass[i])).b.entrySet())
        e((Map)hashMap, (b)entry.getKey(), (d.b)entry.getValue(), paramClass); 
    } 
    if (paramArrayOfMethod == null)
      paramArrayOfMethod = b(paramClass); 
    int k = paramArrayOfMethod.length;
    j = 0;
    boolean bool = false;
    while (j < k) {
      Method method = paramArrayOfMethod[j];
      o o = method.<o>getAnnotation(o.class);
      if (o != null) {
        Class[] arrayOfClass1 = method.getParameterTypes();
        if (arrayOfClass1.length > 0) {
          if (arrayOfClass1[0].isAssignableFrom(g.class)) {
            i = 1;
          } else {
            throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
          } 
        } else {
          i = 0;
        } 
        d.b b = o.value();
        if (arrayOfClass1.length > 1)
          if (arrayOfClass1[1].isAssignableFrom(d.b.class)) {
            if (b == d.b.ON_ANY) {
              i = 2;
            } else {
              throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
            } 
          } else {
            throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
          }  
        if (arrayOfClass1.length <= 2) {
          e((Map)hashMap, new b(i, method), b, paramClass);
          bool = true;
        } else {
          throw new IllegalArgumentException("cannot have more than 2 params");
        } 
      } 
      j++;
    } 
    a a1 = new a((Map)hashMap);
    this.a.put(paramClass, a1);
    this.b.put(paramClass, Boolean.valueOf(bool));
    return a1;
  }
  
  public final Method[] b(Class<?> paramClass) {
    try {
      return paramClass.getDeclaredMethods();
    } catch (NoClassDefFoundError noClassDefFoundError) {
      throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", noClassDefFoundError);
    } 
  }
  
  public a c(Class<?> paramClass) {
    a a1 = this.a.get(paramClass);
    return (a1 != null) ? a1 : a(paramClass, null);
  }
  
  public boolean d(Class<?> paramClass) {
    Boolean bool = this.b.get(paramClass);
    if (bool != null)
      return bool.booleanValue(); 
    Method[] arrayOfMethod = b(paramClass);
    int j = arrayOfMethod.length;
    for (int i = 0; i < j; i++) {
      if ((o)arrayOfMethod[i].<o>getAnnotation(o.class) != null) {
        a(paramClass, arrayOfMethod);
        return true;
      } 
    } 
    this.b.put(paramClass, Boolean.FALSE);
    return false;
  }
  
  public final void e(Map<b, d.b> paramMap, b paramb, d.b paramb1, Class<?> paramClass) {
    d.b b1 = paramMap.get(paramb);
    if (b1 == null || paramb1 == b1) {
      if (b1 == null)
        paramMap.put(paramb, paramb1); 
      return;
    } 
    Method method = paramb.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Method ");
    stringBuilder.append(method.getName());
    stringBuilder.append(" in ");
    stringBuilder.append(paramClass.getName());
    stringBuilder.append(" already declared with different @OnLifecycleEvent value: previous value ");
    stringBuilder.append(b1);
    stringBuilder.append(", new value ");
    stringBuilder.append(paramb1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public static class a {
    public final Map<d.b, List<a.b>> a;
    
    public final Map<a.b, d.b> b;
    
    public a(Map<a.b, d.b> param1Map) {
      this.b = param1Map;
      this.a = new HashMap<d.b, List<a.b>>();
      for (Map.Entry<a.b, d.b> entry : param1Map.entrySet()) {
        d.b b = (d.b)entry.getValue();
        List<a.b> list2 = this.a.get(b);
        List<a.b> list1 = list2;
        if (list2 == null) {
          list1 = new ArrayList();
          this.a.put(b, list1);
        } 
        list1.add((a.b)entry.getKey());
      } 
    }
    
    public static void b(List<a.b> param1List, g param1g, d.b param1b, Object param1Object) {
      if (param1List != null) {
        int i;
        for (i = param1List.size() - 1; i >= 0; i--)
          ((a.b)param1List.get(i)).a(param1g, param1b, param1Object); 
      } 
    }
    
    public void a(g param1g, d.b param1b, Object param1Object) {
      b(this.a.get(param1b), param1g, param1b, param1Object);
      b(this.a.get(d.b.ON_ANY), param1g, param1b, param1Object);
    }
  }
  
  public static final class b {
    public final int a;
    
    public final Method b;
    
    public b(int param1Int, Method param1Method) {
      this.a = param1Int;
      this.b = param1Method;
      param1Method.setAccessible(true);
    }
    
    public void a(g param1g, d.b param1b, Object param1Object) {
      try {
        int i = this.a;
        if (i != 0) {
          if (i != 1) {
            if (i != 2)
              return; 
            this.b.invoke(param1Object, new Object[] { param1g, param1b });
            return;
          } 
          this.b.invoke(param1Object, new Object[] { param1g });
          return;
        } 
        this.b.invoke(param1Object, new Object[0]);
        return;
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException("Failed to call observer method", invocationTargetException.getCause());
      } catch (IllegalAccessException illegalAccessException) {
        throw new RuntimeException(illegalAccessException);
      } 
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      param1Object = param1Object;
      return (this.a == ((b)param1Object).a && this.b.getName().equals(((b)param1Object).b.getName()));
    }
    
    public int hashCode() {
      return this.a * 31 + this.b.getName().hashCode();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */