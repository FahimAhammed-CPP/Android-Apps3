package b.n;

import android.view.View;
import b.n.y.a;

public class w {
  public static void a(View paramView, g paramg) {
    paramView.setTag(a.a, paramg);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */