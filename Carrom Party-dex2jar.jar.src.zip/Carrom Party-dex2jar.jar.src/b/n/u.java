package b.n;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class u {
  public final HashMap<String, s> a = new HashMap<String, s>();
  
  public final void a() {
    Iterator<s> iterator = this.a.values().iterator();
    while (iterator.hasNext())
      ((s)iterator.next()).a(); 
    this.a.clear();
  }
  
  public final s b(String paramString) {
    return this.a.get(paramString);
  }
  
  public Set<String> c() {
    return new HashSet<String>(this.a.keySet());
  }
  
  public final void d(String paramString, s params) {
    s s1 = this.a.put(paramString, params);
    if (s1 != null)
      s1.d(); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */