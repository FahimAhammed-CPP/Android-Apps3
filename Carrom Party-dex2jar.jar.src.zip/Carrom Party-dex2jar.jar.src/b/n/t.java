package b.n;

public class t {
  public final a a;
  
  public final u b;
  
  public t(u paramu, a parama) {
    this.a = parama;
    this.b = paramu;
  }
  
  public <T extends s> T a(Class<T> paramClass) {
    String str = paramClass.getCanonicalName();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      stringBuilder.append(str);
      return b(stringBuilder.toString(), paramClass);
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public <T extends s> T b(String paramString, Class<T> paramClass) {
    a a1;
    s s = this.b.b(paramString);
    if (paramClass.isInstance(s)) {
      a1 = this.a;
      if (a1 instanceof c)
        ((c)a1).b(s); 
      return (T)s;
    } 
    a a2 = this.a;
    if (a2 instanceof b) {
      paramClass = ((b)a2).c((String)a1, (Class)paramClass);
    } else {
      paramClass = a2.a((Class)paramClass);
    } 
    this.b.d((String)a1, (s)paramClass);
    return (T)paramClass;
  }
  
  public static interface a {
    <T extends s> T a(Class<T> param1Class);
  }
  
  public static abstract class b extends c implements a {
    public <T extends s> T a(Class<T> param1Class) {
      throw new UnsupportedOperationException("create(String, Class<?>) must be called on implementaions of KeyedFactory");
    }
    
    public abstract <T extends s> T c(String param1String, Class<T> param1Class);
  }
  
  public static class c {
    public void b(s param1s) {}
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */