package b.n;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class j extends Service implements g {
  public final r a = new r(this);
  
  public d a() {
    return this.a.a();
  }
  
  public IBinder onBind(Intent paramIntent) {
    this.a.b();
    return null;
  }
  
  public void onCreate() {
    this.a.c();
    super.onCreate();
  }
  
  public void onDestroy() {
    this.a.d();
    super.onDestroy();
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    this.a.e();
    super.onStart(paramIntent, paramInt);
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */