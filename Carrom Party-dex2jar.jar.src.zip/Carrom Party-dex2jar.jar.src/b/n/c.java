package b.n;

public interface c {
  void a(g paramg, d.b paramb, boolean paramBoolean, l paraml);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */