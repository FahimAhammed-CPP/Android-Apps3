package b.n;

import android.annotation.SuppressLint;
import b.c.a.b.b;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class h extends d {
  public b.c.a.b.a<f, a> a = new b.c.a.b.a();
  
  public d.c b;
  
  public final WeakReference<g> c;
  
  public int d = 0;
  
  public boolean e = false;
  
  public boolean f = false;
  
  public ArrayList<d.c> g = new ArrayList<d.c>();
  
  public final boolean h;
  
  public h(g paramg) {
    this(paramg, true);
  }
  
  public h(g paramg, boolean paramBoolean) {
    this.c = new WeakReference<g>(paramg);
    this.b = d.c.b;
    this.h = paramBoolean;
  }
  
  public static d.c k(d.c paramc1, d.c paramc2) {
    d.c c1 = paramc1;
    if (paramc2 != null) {
      c1 = paramc1;
      if (paramc2.compareTo(paramc1) < 0)
        c1 = paramc2; 
    } 
    return c1;
  }
  
  public void a(f paramf) {
    boolean bool;
    f("addObserver");
    d.c c2 = this.b;
    d.c c1 = d.c.a;
    if (c2 != c1)
      c1 = d.c.b; 
    a a1 = new a(paramf, c1);
    if ((a)this.a.g(paramf, a1) != null)
      return; 
    g g = this.c.get();
    if (g == null)
      return; 
    if (this.d != 0 || this.e) {
      bool = true;
    } else {
      bool = false;
    } 
    c1 = e(paramf);
    this.d++;
    while (a1.a.compareTo(c1) < 0 && this.a.contains(paramf)) {
      n(a1.a);
      d.b b = d.b.h(a1.a);
      if (b != null) {
        a1.a(g, b);
        m();
        d.c c3 = e(paramf);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("no event up from ");
      stringBuilder.append(a1.a);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    if (!bool)
      p(); 
    this.d--;
  }
  
  public d.c b() {
    return this.b;
  }
  
  public void c(f paramf) {
    f("removeObserver");
    this.a.i(paramf);
  }
  
  public final void d(g paramg) {
    Iterator<Map.Entry> iterator = this.a.descendingIterator();
    while (iterator.hasNext() && !this.f) {
      Map.Entry entry = iterator.next();
      a a1 = (a)entry.getValue();
      while (a1.a.compareTo(this.b) > 0 && !this.f && this.a.contains(entry.getKey())) {
        d.b b = d.b.a(a1.a);
        if (b != null) {
          n(b.f());
          a1.a(paramg, b);
          m();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event down from ");
        stringBuilder.append(a1.a);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  public final d.c e(f paramf) {
    d.c c1;
    Map.Entry entry = this.a.j(paramf);
    ArrayList<d.c> arrayList = null;
    if (entry != null) {
      d.c c2 = ((a)entry.getValue()).a;
    } else {
      entry = null;
    } 
    if (!this.g.isEmpty()) {
      arrayList = this.g;
      c1 = arrayList.get(arrayList.size() - 1);
    } 
    return k(k(this.b, (d.c)entry), c1);
  }
  
  @SuppressLint({"RestrictedApi"})
  public final void f(String paramString) {
    if (this.h) {
      if (b.c.a.a.a.e().b())
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Method ");
      stringBuilder.append(paramString);
      stringBuilder.append(" must be called on the main thread");
      throw new IllegalStateException(stringBuilder.toString());
    } 
  }
  
  public final void g(g paramg) {
    b.d<Map.Entry> d1 = this.a.c();
    while (d1.hasNext() && !this.f) {
      Map.Entry entry = d1.next();
      a a1 = (a)entry.getValue();
      while (a1.a.compareTo(this.b) < 0 && !this.f && this.a.contains(entry.getKey())) {
        n(a1.a);
        d.b b = d.b.h(a1.a);
        if (b != null) {
          a1.a(paramg, b);
          m();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event up from ");
        stringBuilder.append(a1.a);
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  public void h(d.b paramb) {
    f("handleLifecycleEvent");
    l(paramb.f());
  }
  
  public final boolean i() {
    if (this.a.size() == 0)
      return true; 
    d.c c1 = ((a)this.a.a().getValue()).a;
    d.c c2 = ((a)this.a.d().getValue()).a;
    return (c1 == c2 && this.b == c2);
  }
  
  @Deprecated
  public void j(d.c paramc) {
    f("markState");
    o(paramc);
  }
  
  public final void l(d.c paramc) {
    if (this.b == paramc)
      return; 
    this.b = paramc;
    if (this.e || this.d != 0) {
      this.f = true;
      return;
    } 
    this.e = true;
    p();
    this.e = false;
  }
  
  public final void m() {
    ArrayList<d.c> arrayList = this.g;
    arrayList.remove(arrayList.size() - 1);
  }
  
  public final void n(d.c paramc) {
    this.g.add(paramc);
  }
  
  public void o(d.c paramc) {
    f("setCurrentState");
    l(paramc);
  }
  
  public final void p() {
    g g = this.c.get();
    if (g != null) {
      while (!i()) {
        this.f = false;
        if (this.b.compareTo(((a)this.a.a().getValue()).a) < 0)
          d(g); 
        Map.Entry entry = this.a.d();
        if (!this.f && entry != null && this.b.compareTo(((a)entry.getValue()).a) > 0)
          g(g); 
      } 
      this.f = false;
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
    throw illegalStateException;
  }
  
  public static class a {
    public d.c a;
    
    public e b;
    
    public a(f param1f, d.c param1c) {
      this.b = k.f(param1f);
      this.a = param1c;
    }
    
    public void a(g param1g, d.b param1b) {
      d.c c1 = param1b.f();
      this.a = h.k(this.a, c1);
      this.b.c(param1g, param1b);
      this.a = c1;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */