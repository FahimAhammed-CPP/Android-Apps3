package b.n;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public abstract class s {
  public final Map<String, Object> a = new HashMap<String, Object>();
  
  public static void b(Object paramObject) {
    if (paramObject instanceof Closeable)
      try {
        ((Closeable)paramObject).close();
        return;
      } catch (IOException iOException) {
        throw new RuntimeException(iOException);
      }  
  }
  
  public final void a() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Ljava/util/Map;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnull -> 57
    //   9: aload_1
    //   10: monitorenter
    //   11: aload_0
    //   12: getfield a : Ljava/util/Map;
    //   15: invokeinterface values : ()Ljava/util/Collection;
    //   20: invokeinterface iterator : ()Ljava/util/Iterator;
    //   25: astore_2
    //   26: aload_2
    //   27: invokeinterface hasNext : ()Z
    //   32: ifeq -> 47
    //   35: aload_2
    //   36: invokeinterface next : ()Ljava/lang/Object;
    //   41: invokestatic b : (Ljava/lang/Object;)V
    //   44: goto -> 26
    //   47: aload_1
    //   48: monitorexit
    //   49: goto -> 57
    //   52: astore_2
    //   53: aload_1
    //   54: monitorexit
    //   55: aload_2
    //   56: athrow
    //   57: aload_0
    //   58: invokevirtual d : ()V
    //   61: return
    // Exception table:
    //   from	to	target	type
    //   11	26	52	finally
    //   26	44	52	finally
    //   47	49	52	finally
    //   53	55	52	finally
  }
  
  public <T> T c(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Ljava/util/Map;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnonnull -> 11
    //   9: aconst_null
    //   10: areturn
    //   11: aload_2
    //   12: monitorenter
    //   13: aload_0
    //   14: getfield a : Ljava/util/Map;
    //   17: aload_1
    //   18: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   23: astore_1
    //   24: aload_2
    //   25: monitorexit
    //   26: aload_1
    //   27: areturn
    //   28: astore_1
    //   29: aload_2
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   13	26	28	finally
    //   29	31	28	finally
  }
  
  public void d() {}
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\n\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */