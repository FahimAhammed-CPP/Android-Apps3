package b.g.c;

import b.f.g;
import b.h.m.e;
import b.h.m.f;
import java.util.ArrayList;
import java.util.HashSet;

public final class a<T> {
  public final e<ArrayList<T>> a = (e<ArrayList<T>>)new f(10);
  
  public final g<T, ArrayList<T>> b = new g();
  
  public final ArrayList<T> c = new ArrayList<T>();
  
  public final HashSet<T> d = new HashSet<T>();
  
  public void a(T paramT1, T paramT2) {
    if (this.b.containsKey(paramT1) && this.b.containsKey(paramT2)) {
      ArrayList<T> arrayList2 = (ArrayList)this.b.get(paramT1);
      ArrayList<T> arrayList1 = arrayList2;
      if (arrayList2 == null) {
        arrayList1 = f();
        this.b.put(paramT1, arrayList1);
      } 
      arrayList1.add(paramT2);
      return;
    } 
    throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
  }
  
  public void b(T paramT) {
    if (!this.b.containsKey(paramT))
      this.b.put(paramT, null); 
  }
  
  public void c() {
    int j = this.b.size();
    for (int i = 0; i < j; i++) {
      ArrayList<T> arrayList = (ArrayList)this.b.m(i);
      if (arrayList != null)
        i(arrayList); 
    } 
    this.b.clear();
  }
  
  public boolean d(T paramT) {
    return this.b.containsKey(paramT);
  }
  
  public final void e(T paramT, ArrayList<T> paramArrayList, HashSet<T> paramHashSet) {
    if (paramArrayList.contains(paramT))
      return; 
    if (!paramHashSet.contains(paramT)) {
      paramHashSet.add(paramT);
      ArrayList<T> arrayList = (ArrayList)this.b.get(paramT);
      if (arrayList != null) {
        int i = 0;
        int j = arrayList.size();
        while (i < j) {
          e(arrayList.get(i), paramArrayList, paramHashSet);
          i++;
        } 
      } 
      paramHashSet.remove(paramT);
      paramArrayList.add(paramT);
      return;
    } 
    RuntimeException runtimeException = new RuntimeException("This graph contains cyclic dependencies");
    throw runtimeException;
  }
  
  public final ArrayList<T> f() {
    ArrayList<T> arrayList2 = (ArrayList)this.a.b();
    ArrayList<T> arrayList1 = arrayList2;
    if (arrayList2 == null)
      arrayList1 = new ArrayList(); 
    return arrayList1;
  }
  
  public ArrayList<T> g() {
    this.c.clear();
    this.d.clear();
    int j = this.b.size();
    for (int i = 0; i < j; i++)
      e((T)this.b.i(i), this.c, this.d); 
    return this.c;
  }
  
  public boolean h(T paramT) {
    int j = this.b.size();
    for (int i = 0; i < j; i++) {
      ArrayList arrayList = (ArrayList)this.b.m(i);
      if (arrayList != null && arrayList.contains(paramT))
        return true; 
    } 
    return false;
  }
  
  public final void i(ArrayList<T> paramArrayList) {
    paramArrayList.clear();
    this.a.a(paramArrayList);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\g\c\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */