package b.g;

public final class a {
  public static final int a = 2131689851;
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\b\g\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */