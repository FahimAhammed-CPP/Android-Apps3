package androidx.media;

import b.x.a;

public final class AudioAttributesImplBaseParcelizer {
  public static AudioAttributesImplBase read(a parama) {
    AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
    audioAttributesImplBase.a = parama.p(audioAttributesImplBase.a, 1);
    audioAttributesImplBase.b = parama.p(audioAttributesImplBase.b, 2);
    audioAttributesImplBase.c = parama.p(audioAttributesImplBase.c, 3);
    audioAttributesImplBase.d = parama.p(audioAttributesImplBase.d, 4);
    return audioAttributesImplBase;
  }
  
  public static void write(AudioAttributesImplBase paramAudioAttributesImplBase, a parama) {
    parama.x(false, false);
    parama.F(paramAudioAttributesImplBase.a, 1);
    parama.F(paramAudioAttributesImplBase.b, 2);
    parama.F(paramAudioAttributesImplBase.c, 3);
    parama.F(paramAudioAttributesImplBase.d, 4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\media\AudioAttributesImplBaseParcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */