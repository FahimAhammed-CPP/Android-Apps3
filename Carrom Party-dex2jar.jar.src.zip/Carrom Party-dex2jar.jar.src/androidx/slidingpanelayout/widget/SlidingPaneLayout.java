package androidx.slidingpanelayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import androidx.customview.view.AbsSavedState;
import b.h.n.r;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class SlidingPaneLayout extends ViewGroup {
  public boolean C = true;
  
  public final Rect D = new Rect();
  
  public final ArrayList<b> E = new ArrayList<b>();
  
  public Method F;
  
  public Field G;
  
  public boolean H;
  
  public int a = -858993460;
  
  public int b;
  
  public Drawable c;
  
  public Drawable d;
  
  public final int e;
  
  public boolean f;
  
  public View g;
  
  public float h;
  
  public float i;
  
  public int j;
  
  public boolean k;
  
  public int l;
  
  public float m;
  
  public float n;
  
  public e o;
  
  public final b.j.a.a p;
  
  public boolean q;
  
  public SlidingPaneLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.e = (int)(32.0F * f + 0.5F);
    setWillNotDraw(false);
    r.O((View)this, new a(this));
    r.T((View)this, 1);
    b.j.a.a a1 = b.j.a.a.o(this, 0.5F, new c(this));
    this.p = a1;
    a1.M(f * 400.0F);
  }
  
  public static boolean s(View paramView) {
    if (paramView.isOpaque())
      return true; 
    if (Build.VERSION.SDK_INT >= 18)
      return false; 
    Drawable drawable = paramView.getBackground();
    return (drawable != null) ? ((drawable.getOpacity() == -1)) : false;
  }
  
  public boolean a() {
    return b(this.g, 0);
  }
  
  public final boolean b(View paramView, int paramInt) {
    if (this.C || q(0.0F, paramInt)) {
      this.q = false;
      return true;
    } 
    return false;
  }
  
  public final void c(View paramView, float paramFloat, int paramInt) {
    d d = (d)paramView.getLayoutParams();
    if (paramFloat > 0.0F && paramInt != 0) {
      int i = (int)(((0xFF000000 & paramInt) >>> 24) * paramFloat);
      if (d.d == null)
        d.d = new Paint(); 
      d.d.setColorFilter((ColorFilter)new PorterDuffColorFilter(i << 24 | paramInt & 0xFFFFFF, PorterDuff.Mode.SRC_OVER));
      if (paramView.getLayerType() != 2)
        paramView.setLayerType(2, d.d); 
      g(paramView);
      return;
    } 
    if (paramView.getLayerType() != 0) {
      Paint paint = d.d;
      if (paint != null)
        paint.setColorFilter(null); 
      b b = new b(this, paramView);
      this.E.add(b);
      r.K((View)this, b);
    } 
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof d && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll() {
    if (this.p.n(true)) {
      if (!this.f) {
        this.p.a();
        return;
      } 
      r.I((View)this);
    } 
  }
  
  public void d(View paramView) {
    e e1 = this.o;
    if (e1 != null)
      e1.c(paramView); 
    sendAccessibilityEvent(32);
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable;
    View view;
    super.draw(paramCanvas);
    if (i()) {
      drawable = this.d;
    } else {
      drawable = this.c;
    } 
    if (getChildCount() > 1) {
      view = getChildAt(1);
    } else {
      view = null;
    } 
    if (view != null) {
      int i;
      int j;
      if (drawable == null)
        return; 
      int m = view.getTop();
      int n = view.getBottom();
      int k = drawable.getIntrinsicWidth();
      if (i()) {
        i = view.getRight();
        j = k + i;
      } else {
        j = view.getLeft();
        i = j;
        k = j - k;
        j = i;
        i = k;
      } 
      drawable.setBounds(i, m, j, n);
      drawable.draw(paramCanvas);
    } 
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    d d = (d)paramView.getLayoutParams();
    int i = paramCanvas.save();
    if (this.f && !d.b && this.g != null) {
      paramCanvas.getClipBounds(this.D);
      if (i()) {
        Rect rect = this.D;
        rect.left = Math.max(rect.left, this.g.getRight());
      } else {
        Rect rect = this.D;
        rect.right = Math.min(rect.right, this.g.getLeft());
      } 
      paramCanvas.clipRect(this.D);
    } 
    boolean bool = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(i);
    return bool;
  }
  
  public void e(View paramView) {
    e e1 = this.o;
    if (e1 != null)
      e1.b(paramView); 
    sendAccessibilityEvent(32);
  }
  
  public void f(View paramView) {
    e e1 = this.o;
    if (e1 != null)
      e1.a(paramView, this.h); 
  }
  
  public void g(View paramView) {
    // Byte code:
    //   0: getstatic android/os/Build$VERSION.SDK_INT : I
    //   3: istore_2
    //   4: iload_2
    //   5: bipush #17
    //   7: if_icmplt -> 25
    //   10: aload_1
    //   11: aload_1
    //   12: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   15: checkcast androidx/slidingpanelayout/widget/SlidingPaneLayout$d
    //   18: getfield d : Landroid/graphics/Paint;
    //   21: invokestatic U : (Landroid/view/View;Landroid/graphics/Paint;)V
    //   24: return
    //   25: iload_2
    //   26: bipush #16
    //   28: if_icmplt -> 163
    //   31: aload_0
    //   32: getfield H : Z
    //   35: ifne -> 105
    //   38: aload_0
    //   39: ldc android/view/View
    //   41: ldc_w 'getDisplayList'
    //   44: aconst_null
    //   45: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   48: putfield F : Ljava/lang/reflect/Method;
    //   51: goto -> 66
    //   54: astore_3
    //   55: ldc_w 'SlidingPaneLayout'
    //   58: ldc_w 'Couldn't fetch getDisplayList method; dimming won't work right.'
    //   61: aload_3
    //   62: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   65: pop
    //   66: ldc android/view/View
    //   68: ldc_w 'mRecreateDisplayList'
    //   71: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   74: astore_3
    //   75: aload_0
    //   76: aload_3
    //   77: putfield G : Ljava/lang/reflect/Field;
    //   80: aload_3
    //   81: iconst_1
    //   82: invokevirtual setAccessible : (Z)V
    //   85: goto -> 100
    //   88: astore_3
    //   89: ldc_w 'SlidingPaneLayout'
    //   92: ldc_w 'Couldn't fetch mRecreateDisplayList field; dimming will be slow.'
    //   95: aload_3
    //   96: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   99: pop
    //   100: aload_0
    //   101: iconst_1
    //   102: putfield H : Z
    //   105: aload_0
    //   106: getfield F : Ljava/lang/reflect/Method;
    //   109: ifnull -> 158
    //   112: aload_0
    //   113: getfield G : Ljava/lang/reflect/Field;
    //   116: astore_3
    //   117: aload_3
    //   118: ifnonnull -> 124
    //   121: goto -> 158
    //   124: aload_3
    //   125: aload_1
    //   126: iconst_1
    //   127: invokevirtual setBoolean : (Ljava/lang/Object;Z)V
    //   130: aload_0
    //   131: getfield F : Ljava/lang/reflect/Method;
    //   134: aload_1
    //   135: aconst_null
    //   136: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   139: pop
    //   140: goto -> 163
    //   143: astore_3
    //   144: ldc_w 'SlidingPaneLayout'
    //   147: ldc_w 'Error refreshing display list state'
    //   150: aload_3
    //   151: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   154: pop
    //   155: goto -> 163
    //   158: aload_1
    //   159: invokevirtual invalidate : ()V
    //   162: return
    //   163: aload_0
    //   164: aload_1
    //   165: invokevirtual getLeft : ()I
    //   168: aload_1
    //   169: invokevirtual getTop : ()I
    //   172: aload_1
    //   173: invokevirtual getRight : ()I
    //   176: aload_1
    //   177: invokevirtual getBottom : ()I
    //   180: invokestatic J : (Landroid/view/View;IIII)V
    //   183: return
    // Exception table:
    //   from	to	target	type
    //   38	51	54	java/lang/NoSuchMethodException
    //   66	85	88	java/lang/NoSuchFieldException
    //   124	140	143	java/lang/Exception
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new d();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new d(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new d((ViewGroup.MarginLayoutParams)paramLayoutParams) : new d(paramLayoutParams));
  }
  
  public int getCoveredFadeColor() {
    return this.b;
  }
  
  public int getParallaxDistance() {
    return this.l;
  }
  
  public int getSliderFadeColor() {
    return this.a;
  }
  
  public boolean h(View paramView) {
    boolean bool2 = false;
    if (paramView == null)
      return false; 
    d d = (d)paramView.getLayoutParams();
    boolean bool1 = bool2;
    if (this.f) {
      bool1 = bool2;
      if (d.c) {
        bool1 = bool2;
        if (this.h > 0.0F)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public boolean i() {
    return (r.q((View)this) == 1);
  }
  
  public boolean j() {
    return (!this.f || this.h == 1.0F);
  }
  
  public boolean k() {
    return this.f;
  }
  
  public void l(int paramInt) {
    if (this.g == null) {
      this.h = 0.0F;
      return;
    } 
    boolean bool = i();
    d d = (d)this.g.getLayoutParams();
    int j = this.g.getWidth();
    int i = paramInt;
    if (bool)
      i = getWidth() - paramInt - j; 
    if (bool) {
      paramInt = getPaddingRight();
    } else {
      paramInt = getPaddingLeft();
    } 
    if (bool) {
      j = d.rightMargin;
    } else {
      j = d.leftMargin;
    } 
    float f = (i - paramInt + j) / this.j;
    this.h = f;
    if (this.l != 0)
      o(f); 
    if (d.c)
      c(this.g, this.h, this.a); 
    f(this.g);
  }
  
  public boolean m() {
    return n(this.g, 0);
  }
  
  public final boolean n(View paramView, int paramInt) {
    if (this.C || q(1.0F, paramInt)) {
      this.q = true;
      return true;
    } 
    return false;
  }
  
  public final void o(float paramFloat) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual i : ()Z
    //   4: istore #8
    //   6: aload_0
    //   7: getfield g : Landroid/view/View;
    //   10: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   13: checkcast androidx/slidingpanelayout/widget/SlidingPaneLayout$d
    //   16: astore #10
    //   18: aload #10
    //   20: getfield c : Z
    //   23: istore #9
    //   25: iconst_0
    //   26: istore #4
    //   28: iload #9
    //   30: ifeq -> 62
    //   33: iload #8
    //   35: ifeq -> 47
    //   38: aload #10
    //   40: getfield rightMargin : I
    //   43: istore_3
    //   44: goto -> 53
    //   47: aload #10
    //   49: getfield leftMargin : I
    //   52: istore_3
    //   53: iload_3
    //   54: ifgt -> 62
    //   57: iconst_1
    //   58: istore_3
    //   59: goto -> 64
    //   62: iconst_0
    //   63: istore_3
    //   64: aload_0
    //   65: invokevirtual getChildCount : ()I
    //   68: istore #7
    //   70: iload #4
    //   72: iload #7
    //   74: if_icmpge -> 202
    //   77: aload_0
    //   78: iload #4
    //   80: invokevirtual getChildAt : (I)Landroid/view/View;
    //   83: astore #10
    //   85: aload #10
    //   87: aload_0
    //   88: getfield g : Landroid/view/View;
    //   91: if_acmpne -> 97
    //   94: goto -> 193
    //   97: aload_0
    //   98: getfield i : F
    //   101: fstore_2
    //   102: aload_0
    //   103: getfield l : I
    //   106: istore #5
    //   108: fconst_1
    //   109: fload_2
    //   110: fsub
    //   111: iload #5
    //   113: i2f
    //   114: fmul
    //   115: f2i
    //   116: istore #6
    //   118: aload_0
    //   119: fload_1
    //   120: putfield i : F
    //   123: iload #6
    //   125: fconst_1
    //   126: fload_1
    //   127: fsub
    //   128: iload #5
    //   130: i2f
    //   131: fmul
    //   132: f2i
    //   133: isub
    //   134: istore #6
    //   136: iload #6
    //   138: istore #5
    //   140: iload #8
    //   142: ifeq -> 150
    //   145: iload #6
    //   147: ineg
    //   148: istore #5
    //   150: aload #10
    //   152: iload #5
    //   154: invokevirtual offsetLeftAndRight : (I)V
    //   157: iload_3
    //   158: ifeq -> 193
    //   161: aload_0
    //   162: getfield i : F
    //   165: fstore_2
    //   166: iload #8
    //   168: ifeq -> 178
    //   171: fload_2
    //   172: fconst_1
    //   173: fsub
    //   174: fstore_2
    //   175: goto -> 182
    //   178: fconst_1
    //   179: fload_2
    //   180: fsub
    //   181: fstore_2
    //   182: aload_0
    //   183: aload #10
    //   185: fload_2
    //   186: aload_0
    //   187: getfield b : I
    //   190: invokevirtual c : (Landroid/view/View;FI)V
    //   193: iload #4
    //   195: iconst_1
    //   196: iadd
    //   197: istore #4
    //   199: goto -> 70
    //   202: return
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.C = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.C = true;
    int j = this.E.size();
    for (int i = 0; i < j; i++)
      ((b)this.E.get(i)).run(); 
    this.E.clear();
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: getfield f : Z
    //   10: istore #6
    //   12: iconst_1
    //   13: istore #5
    //   15: iload #6
    //   17: ifne -> 70
    //   20: iload #4
    //   22: ifne -> 70
    //   25: aload_0
    //   26: invokevirtual getChildCount : ()I
    //   29: iconst_1
    //   30: if_icmple -> 70
    //   33: aload_0
    //   34: iconst_1
    //   35: invokevirtual getChildAt : (I)Landroid/view/View;
    //   38: astore #7
    //   40: aload #7
    //   42: ifnull -> 70
    //   45: aload_0
    //   46: aload_0
    //   47: getfield p : Lb/j/a/a;
    //   50: aload #7
    //   52: aload_1
    //   53: invokevirtual getX : ()F
    //   56: f2i
    //   57: aload_1
    //   58: invokevirtual getY : ()F
    //   61: f2i
    //   62: invokevirtual E : (Landroid/view/View;II)Z
    //   65: iconst_1
    //   66: ixor
    //   67: putfield q : Z
    //   70: aload_0
    //   71: getfield f : Z
    //   74: ifeq -> 280
    //   77: aload_0
    //   78: getfield k : Z
    //   81: ifeq -> 92
    //   84: iload #4
    //   86: ifeq -> 92
    //   89: goto -> 280
    //   92: iload #4
    //   94: iconst_3
    //   95: if_icmpeq -> 271
    //   98: iload #4
    //   100: iconst_1
    //   101: if_icmpne -> 107
    //   104: goto -> 271
    //   107: iload #4
    //   109: ifeq -> 184
    //   112: iload #4
    //   114: iconst_2
    //   115: if_icmpeq -> 121
    //   118: goto -> 244
    //   121: aload_1
    //   122: invokevirtual getX : ()F
    //   125: fstore_3
    //   126: aload_1
    //   127: invokevirtual getY : ()F
    //   130: fstore_2
    //   131: fload_3
    //   132: aload_0
    //   133: getfield m : F
    //   136: fsub
    //   137: invokestatic abs : (F)F
    //   140: fstore_3
    //   141: fload_2
    //   142: aload_0
    //   143: getfield n : F
    //   146: fsub
    //   147: invokestatic abs : (F)F
    //   150: fstore_2
    //   151: fload_3
    //   152: aload_0
    //   153: getfield p : Lb/j/a/a;
    //   156: invokevirtual z : ()I
    //   159: i2f
    //   160: fcmpl
    //   161: ifle -> 244
    //   164: fload_2
    //   165: fload_3
    //   166: fcmpl
    //   167: ifle -> 244
    //   170: aload_0
    //   171: getfield p : Lb/j/a/a;
    //   174: invokevirtual b : ()V
    //   177: aload_0
    //   178: iconst_1
    //   179: putfield k : Z
    //   182: iconst_0
    //   183: ireturn
    //   184: aload_0
    //   185: iconst_0
    //   186: putfield k : Z
    //   189: aload_1
    //   190: invokevirtual getX : ()F
    //   193: fstore_2
    //   194: aload_1
    //   195: invokevirtual getY : ()F
    //   198: fstore_3
    //   199: aload_0
    //   200: fload_2
    //   201: putfield m : F
    //   204: aload_0
    //   205: fload_3
    //   206: putfield n : F
    //   209: aload_0
    //   210: getfield p : Lb/j/a/a;
    //   213: aload_0
    //   214: getfield g : Landroid/view/View;
    //   217: fload_2
    //   218: f2i
    //   219: fload_3
    //   220: f2i
    //   221: invokevirtual E : (Landroid/view/View;II)Z
    //   224: ifeq -> 244
    //   227: aload_0
    //   228: aload_0
    //   229: getfield g : Landroid/view/View;
    //   232: invokevirtual h : (Landroid/view/View;)Z
    //   235: ifeq -> 244
    //   238: iconst_1
    //   239: istore #4
    //   241: goto -> 247
    //   244: iconst_0
    //   245: istore #4
    //   247: aload_0
    //   248: getfield p : Lb/j/a/a;
    //   251: aload_1
    //   252: invokevirtual O : (Landroid/view/MotionEvent;)Z
    //   255: ifne -> 268
    //   258: iload #4
    //   260: ifeq -> 265
    //   263: iconst_1
    //   264: ireturn
    //   265: iconst_0
    //   266: istore #5
    //   268: iload #5
    //   270: ireturn
    //   271: aload_0
    //   272: getfield p : Lb/j/a/a;
    //   275: invokevirtual b : ()V
    //   278: iconst_0
    //   279: ireturn
    //   280: aload_0
    //   281: getfield p : Lb/j/a/a;
    //   284: invokevirtual b : ()V
    //   287: aload_0
    //   288: aload_1
    //   289: invokespecial onInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   292: ireturn
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual i : ()Z
    //   4: istore #14
    //   6: iload #14
    //   8: ifeq -> 22
    //   11: aload_0
    //   12: getfield p : Lb/j/a/a;
    //   15: iconst_2
    //   16: invokevirtual L : (I)V
    //   19: goto -> 30
    //   22: aload_0
    //   23: getfield p : Lb/j/a/a;
    //   26: iconst_1
    //   27: invokevirtual L : (I)V
    //   30: iload #4
    //   32: iload_2
    //   33: isub
    //   34: istore #9
    //   36: iload #14
    //   38: ifeq -> 49
    //   41: aload_0
    //   42: invokevirtual getPaddingRight : ()I
    //   45: istore_2
    //   46: goto -> 54
    //   49: aload_0
    //   50: invokevirtual getPaddingLeft : ()I
    //   53: istore_2
    //   54: iload #14
    //   56: ifeq -> 68
    //   59: aload_0
    //   60: invokevirtual getPaddingLeft : ()I
    //   63: istore #5
    //   65: goto -> 74
    //   68: aload_0
    //   69: invokevirtual getPaddingRight : ()I
    //   72: istore #5
    //   74: aload_0
    //   75: invokevirtual getPaddingTop : ()I
    //   78: istore #11
    //   80: aload_0
    //   81: invokevirtual getChildCount : ()I
    //   84: istore #10
    //   86: aload_0
    //   87: getfield C : Z
    //   90: ifeq -> 122
    //   93: aload_0
    //   94: getfield f : Z
    //   97: ifeq -> 113
    //   100: aload_0
    //   101: getfield q : Z
    //   104: ifeq -> 113
    //   107: fconst_1
    //   108: fstore #6
    //   110: goto -> 116
    //   113: fconst_0
    //   114: fstore #6
    //   116: aload_0
    //   117: fload #6
    //   119: putfield h : F
    //   122: iload_2
    //   123: istore_3
    //   124: iconst_0
    //   125: istore #7
    //   127: iload #7
    //   129: iload #10
    //   131: if_icmpge -> 427
    //   134: aload_0
    //   135: iload #7
    //   137: invokevirtual getChildAt : (I)Landroid/view/View;
    //   140: astore #15
    //   142: aload #15
    //   144: invokevirtual getVisibility : ()I
    //   147: bipush #8
    //   149: if_icmpne -> 155
    //   152: goto -> 418
    //   155: aload #15
    //   157: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   160: checkcast androidx/slidingpanelayout/widget/SlidingPaneLayout$d
    //   163: astore #16
    //   165: aload #15
    //   167: invokevirtual getMeasuredWidth : ()I
    //   170: istore #12
    //   172: aload #16
    //   174: getfield b : Z
    //   177: ifeq -> 316
    //   180: aload #16
    //   182: getfield leftMargin : I
    //   185: istore #4
    //   187: aload #16
    //   189: getfield rightMargin : I
    //   192: istore #13
    //   194: iload #9
    //   196: iload #5
    //   198: isub
    //   199: istore #8
    //   201: iload_2
    //   202: iload #8
    //   204: aload_0
    //   205: getfield e : I
    //   208: isub
    //   209: invokestatic min : (II)I
    //   212: iload_3
    //   213: isub
    //   214: iload #4
    //   216: iload #13
    //   218: iadd
    //   219: isub
    //   220: istore #13
    //   222: aload_0
    //   223: iload #13
    //   225: putfield j : I
    //   228: iload #14
    //   230: ifeq -> 243
    //   233: aload #16
    //   235: getfield rightMargin : I
    //   238: istore #4
    //   240: goto -> 250
    //   243: aload #16
    //   245: getfield leftMargin : I
    //   248: istore #4
    //   250: iload_3
    //   251: iload #4
    //   253: iadd
    //   254: iload #13
    //   256: iadd
    //   257: iload #12
    //   259: iconst_2
    //   260: idiv
    //   261: iadd
    //   262: iload #8
    //   264: if_icmple -> 272
    //   267: iconst_1
    //   268: istore_1
    //   269: goto -> 274
    //   272: iconst_0
    //   273: istore_1
    //   274: aload #16
    //   276: iload_1
    //   277: putfield c : Z
    //   280: iload #13
    //   282: i2f
    //   283: aload_0
    //   284: getfield h : F
    //   287: fmul
    //   288: f2i
    //   289: istore #8
    //   291: iload_3
    //   292: iload #4
    //   294: iload #8
    //   296: iadd
    //   297: iadd
    //   298: istore_3
    //   299: aload_0
    //   300: iload #8
    //   302: i2f
    //   303: iload #13
    //   305: i2f
    //   306: fdiv
    //   307: putfield h : F
    //   310: iconst_0
    //   311: istore #4
    //   313: goto -> 354
    //   316: aload_0
    //   317: getfield f : Z
    //   320: ifeq -> 349
    //   323: aload_0
    //   324: getfield l : I
    //   327: istore_3
    //   328: iload_3
    //   329: ifeq -> 349
    //   332: fconst_1
    //   333: aload_0
    //   334: getfield h : F
    //   337: fsub
    //   338: iload_3
    //   339: i2f
    //   340: fmul
    //   341: f2i
    //   342: istore #4
    //   344: iload_2
    //   345: istore_3
    //   346: goto -> 354
    //   349: iload_2
    //   350: istore_3
    //   351: iconst_0
    //   352: istore #4
    //   354: iload #14
    //   356: ifeq -> 378
    //   359: iload #9
    //   361: iload_3
    //   362: isub
    //   363: iload #4
    //   365: iadd
    //   366: istore #8
    //   368: iload #8
    //   370: iload #12
    //   372: isub
    //   373: istore #4
    //   375: goto -> 391
    //   378: iload_3
    //   379: iload #4
    //   381: isub
    //   382: istore #4
    //   384: iload #4
    //   386: iload #12
    //   388: iadd
    //   389: istore #8
    //   391: aload #15
    //   393: iload #4
    //   395: iload #11
    //   397: iload #8
    //   399: aload #15
    //   401: invokevirtual getMeasuredHeight : ()I
    //   404: iload #11
    //   406: iadd
    //   407: invokevirtual layout : (IIII)V
    //   410: iload_2
    //   411: aload #15
    //   413: invokevirtual getWidth : ()I
    //   416: iadd
    //   417: istore_2
    //   418: iload #7
    //   420: iconst_1
    //   421: iadd
    //   422: istore #7
    //   424: goto -> 127
    //   427: aload_0
    //   428: getfield C : Z
    //   431: ifeq -> 528
    //   434: aload_0
    //   435: getfield f : Z
    //   438: ifeq -> 491
    //   441: aload_0
    //   442: getfield l : I
    //   445: ifeq -> 456
    //   448: aload_0
    //   449: aload_0
    //   450: getfield h : F
    //   453: invokevirtual o : (F)V
    //   456: aload_0
    //   457: getfield g : Landroid/view/View;
    //   460: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   463: checkcast androidx/slidingpanelayout/widget/SlidingPaneLayout$d
    //   466: getfield c : Z
    //   469: ifeq -> 520
    //   472: aload_0
    //   473: aload_0
    //   474: getfield g : Landroid/view/View;
    //   477: aload_0
    //   478: getfield h : F
    //   481: aload_0
    //   482: getfield a : I
    //   485: invokevirtual c : (Landroid/view/View;FI)V
    //   488: goto -> 520
    //   491: iconst_0
    //   492: istore_2
    //   493: iload_2
    //   494: iload #10
    //   496: if_icmpge -> 520
    //   499: aload_0
    //   500: aload_0
    //   501: iload_2
    //   502: invokevirtual getChildAt : (I)Landroid/view/View;
    //   505: fconst_0
    //   506: aload_0
    //   507: getfield a : I
    //   510: invokevirtual c : (Landroid/view/View;FI)V
    //   513: iload_2
    //   514: iconst_1
    //   515: iadd
    //   516: istore_2
    //   517: goto -> 493
    //   520: aload_0
    //   521: aload_0
    //   522: getfield g : Landroid/view/View;
    //   525: invokevirtual r : (Landroid/view/View;)V
    //   528: aload_0
    //   529: iconst_0
    //   530: putfield C : Z
    //   533: return
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int k;
    int n;
    int m = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (m != 1073741824) {
      if (isInEditMode()) {
        if (m == Integer.MIN_VALUE) {
          k = i;
          n = j;
          paramInt1 = paramInt2;
        } else {
          k = i;
          n = j;
          paramInt1 = paramInt2;
          if (m == 0) {
            k = 300;
            n = j;
            paramInt1 = paramInt2;
          } 
        } 
      } else {
        throw new IllegalStateException("Width must have an exact value or MATCH_PARENT");
      } 
    } else {
      k = i;
      n = j;
      paramInt1 = paramInt2;
      if (j == 0)
        if (isInEditMode()) {
          k = i;
          n = j;
          paramInt1 = paramInt2;
          if (j == 0) {
            n = Integer.MIN_VALUE;
            paramInt1 = 300;
            k = i;
          } 
        } else {
          throw new IllegalStateException("Height must not be UNSPECIFIED");
        }  
    } 
    if (n != Integer.MIN_VALUE) {
      if (n != 1073741824) {
        paramInt1 = 0;
        paramInt2 = 0;
      } else {
        paramInt1 = paramInt1 - getPaddingTop() - getPaddingBottom();
        paramInt2 = paramInt1;
      } 
    } else {
      paramInt2 = paramInt1 - getPaddingTop() - getPaddingBottom();
      paramInt1 = 0;
    } 
    int i2 = k - getPaddingLeft() - getPaddingRight();
    int i3 = getChildCount();
    if (i3 > 2)
      Log.e("SlidingPaneLayout", "onMeasure: More than two child views are not supported."); 
    this.g = null;
    m = i2;
    int i1 = 0;
    int i4 = 0;
    float f = 0.0F;
    for (i = paramInt1; i1 < i3; i = paramInt1) {
      byte b;
      View view = getChildAt(i1);
      d d = (d)view.getLayoutParams();
      if (view.getVisibility() == 8) {
        d.c = false;
        paramInt1 = i;
        continue;
      } 
      float f2 = d.a;
      float f1 = f;
      if (f2 > 0.0F) {
        f += f2;
        f1 = f;
        if (d.width == 0) {
          paramInt1 = i;
          continue;
        } 
      } 
      paramInt1 = d.leftMargin + d.rightMargin;
      j = d.width;
      if (j == -2) {
        paramInt1 = View.MeasureSpec.makeMeasureSpec(i2 - paramInt1, -2147483648);
      } else if (j == -1) {
        paramInt1 = View.MeasureSpec.makeMeasureSpec(i2 - paramInt1, 1073741824);
      } else {
        paramInt1 = View.MeasureSpec.makeMeasureSpec(j, 1073741824);
      } 
      j = d.height;
      if (j == -2) {
        j = View.MeasureSpec.makeMeasureSpec(paramInt2, -2147483648);
      } else if (j == -1) {
        j = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
      } else {
        j = View.MeasureSpec.makeMeasureSpec(j, 1073741824);
      } 
      view.measure(paramInt1, j);
      j = view.getMeasuredWidth();
      int i5 = view.getMeasuredHeight();
      paramInt1 = i;
      if (n == Integer.MIN_VALUE) {
        paramInt1 = i;
        if (i5 > i)
          paramInt1 = Math.min(i5, paramInt2); 
      } 
      m -= j;
      if (m < 0) {
        b = 1;
      } else {
        b = 0;
      } 
      d.b = b;
      i4 |= b;
      if (b != 0)
        this.g = view; 
      f = f1;
      continue;
      i1++;
    } 
    if (i4 != 0 || f > 0.0F) {
      j = i2 - this.e;
      for (n = 0; n < i3; n++) {
        View view = getChildAt(n);
        if (view.getVisibility() != 8) {
          d d = (d)view.getLayoutParams();
          if (view.getVisibility() != 8) {
            if (d.width == 0 && d.a > 0.0F) {
              paramInt1 = 1;
            } else {
              paramInt1 = 0;
            } 
            if (paramInt1 != 0) {
              i1 = 0;
            } else {
              i1 = view.getMeasuredWidth();
            } 
            if (i4 != 0 && view != this.g) {
              if (d.width < 0 && (i1 > j || d.a > 0.0F)) {
                if (paramInt1 != 0) {
                  paramInt1 = d.height;
                  if (paramInt1 == -2) {
                    paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt2, -2147483648);
                  } else if (paramInt1 == -1) {
                    paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
                  } else {
                    paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
                  } 
                } else {
                  paramInt1 = View.MeasureSpec.makeMeasureSpec(view.getMeasuredHeight(), 1073741824);
                } 
                view.measure(View.MeasureSpec.makeMeasureSpec(j, 1073741824), paramInt1);
              } 
            } else if (d.a > 0.0F) {
              if (d.width == 0) {
                paramInt1 = d.height;
                if (paramInt1 == -2) {
                  paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt2, -2147483648);
                } else if (paramInt1 == -1) {
                  paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
                } else {
                  paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
                } 
              } else {
                paramInt1 = View.MeasureSpec.makeMeasureSpec(view.getMeasuredHeight(), 1073741824);
              } 
              if (i4 != 0) {
                int i5 = i2 - d.leftMargin + d.rightMargin;
                int i6 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
                if (i1 != i5)
                  view.measure(i6, paramInt1); 
              } else {
                int i5 = Math.max(0, m);
                view.measure(View.MeasureSpec.makeMeasureSpec(i1 + (int)(d.a * i5 / f), 1073741824), paramInt1);
              } 
            } 
          } 
        } 
      } 
    } 
    setMeasuredDimension(k, i + getPaddingTop() + getPaddingBottom());
    this.f = i4;
    if (this.p.A() != 0 && i4 == 0)
      this.p.a(); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.c());
    if (savedState.c) {
      m();
    } else {
      a();
    } 
    this.q = savedState.c;
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    if (k()) {
      bool = j();
    } else {
      bool = this.q;
    } 
    savedState.c = bool;
    return (Parcelable)savedState;
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3)
      this.C = true; 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (!this.f)
      return super.onTouchEvent(paramMotionEvent); 
    this.p.F(paramMotionEvent);
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i != 1)
        return true; 
      if (h(this.g)) {
        float f1 = paramMotionEvent.getX();
        float f2 = paramMotionEvent.getY();
        float f3 = f1 - this.m;
        float f4 = f2 - this.n;
        i = this.p.z();
        if (f3 * f3 + f4 * f4 < (i * i) && this.p.E(this.g, (int)f1, (int)f2)) {
          b(this.g, 0);
          return true;
        } 
      } 
    } else {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      this.m = f1;
      this.n = f2;
    } 
    return true;
  }
  
  public void p() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (view.getVisibility() == 4)
        view.setVisibility(0); 
    } 
  }
  
  public boolean q(float paramFloat, int paramInt) {
    if (!this.f)
      return false; 
    boolean bool = i();
    d d = (d)this.g.getLayoutParams();
    if (bool) {
      paramInt = getPaddingRight();
      int i = d.rightMargin;
      int j = this.g.getWidth();
      paramInt = (int)(getWidth() - (paramInt + i) + paramFloat * this.j + j);
    } else {
      paramInt = (int)((getPaddingLeft() + d.leftMargin) + paramFloat * this.j);
    } 
    b.j.a.a a1 = this.p;
    View view = this.g;
    if (a1.P(view, paramInt, view.getTop())) {
      p();
      r.I((View)this);
      return true;
    } 
    return false;
  }
  
  public void r(View paramView) {
    int i;
    int j;
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    boolean bool = i();
    if (bool) {
      i = getWidth() - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    if (bool) {
      j = getPaddingLeft();
    } else {
      j = getWidth() - getPaddingRight();
    } 
    int m = getPaddingTop();
    int n = getHeight();
    int i1 = getPaddingBottom();
    if (paramView != null && s(paramView)) {
      b1 = paramView.getLeft();
      b2 = paramView.getRight();
      b3 = paramView.getTop();
      b4 = paramView.getBottom();
    } else {
      b1 = 0;
      b2 = 0;
      b3 = 0;
      b4 = 0;
    } 
    int i2 = getChildCount();
    int k;
    for (k = 0; k < i2; k++) {
      View view = getChildAt(k);
      if (view == paramView)
        return; 
      if (view.getVisibility() != 8) {
        if (bool) {
          i3 = j;
        } else {
          i3 = i;
        } 
        int i4 = Math.max(i3, view.getLeft());
        int i5 = Math.max(m, view.getTop());
        if (bool) {
          i3 = i;
        } else {
          i3 = j;
        } 
        int i3 = Math.min(i3, view.getRight());
        int i6 = Math.min(n - i1, view.getBottom());
        if (i4 >= b1 && i5 >= b3 && i3 <= b2 && i6 <= b4) {
          i3 = 4;
        } else {
          i3 = 0;
        } 
        view.setVisibility(i3);
      } 
    } 
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    super.requestChildFocus(paramView1, paramView2);
    if (!isInTouchMode() && !this.f) {
      boolean bool;
      if (paramView1 == this.g) {
        bool = true;
      } else {
        bool = false;
      } 
      this.q = bool;
    } 
  }
  
  public void setCoveredFadeColor(int paramInt) {
    this.b = paramInt;
  }
  
  public void setPanelSlideListener(e parame) {
    this.o = parame;
  }
  
  public void setParallaxDistance(int paramInt) {
    this.l = paramInt;
    requestLayout();
  }
  
  @Deprecated
  public void setShadowDrawable(Drawable paramDrawable) {
    setShadowDrawableLeft(paramDrawable);
  }
  
  public void setShadowDrawableLeft(Drawable paramDrawable) {
    this.c = paramDrawable;
  }
  
  public void setShadowDrawableRight(Drawable paramDrawable) {
    this.d = paramDrawable;
  }
  
  @Deprecated
  public void setShadowResource(int paramInt) {
    setShadowDrawable(getResources().getDrawable(paramInt));
  }
  
  public void setShadowResourceLeft(int paramInt) {
    setShadowDrawableLeft(b.h.f.a.f(getContext(), paramInt));
  }
  
  public void setShadowResourceRight(int paramInt) {
    setShadowDrawableRight(b.h.f.a.f(getContext(), paramInt));
  }
  
  public void setSliderFadeColor(int paramInt) {
    this.a = paramInt;
  }
  
  public static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    public boolean c;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.c = bool;
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator<SavedState> {
      public SlidingPaneLayout.SavedState a(Parcel param2Parcel) {
        return new SlidingPaneLayout.SavedState(param2Parcel, null);
      }
      
      public SlidingPaneLayout.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new SlidingPaneLayout.SavedState(param2Parcel, null);
      }
      
      public SlidingPaneLayout.SavedState[] c(int param2Int) {
        return new SlidingPaneLayout.SavedState[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<SavedState> {
    public SlidingPaneLayout.SavedState a(Parcel param1Parcel) {
      return new SlidingPaneLayout.SavedState(param1Parcel, null);
    }
    
    public SlidingPaneLayout.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new SlidingPaneLayout.SavedState(param1Parcel, null);
    }
    
    public SlidingPaneLayout.SavedState[] c(int param1Int) {
      return new SlidingPaneLayout.SavedState[param1Int];
    }
  }
  
  public class a extends b.h.n.a {
    public final Rect d = new Rect();
    
    public a(SlidingPaneLayout this$0) {}
    
    public void f(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.f(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(SlidingPaneLayout.class.getName());
    }
    
    public void g(View param1View, b.h.n.a0.b param1b) {
      b.h.n.a0.b b1 = b.h.n.a0.b.K(param1b);
      super.g(param1View, b1);
      n(param1b, b1);
      b1.M();
      param1b.U(SlidingPaneLayout.class.getName());
      param1b.j0(param1View);
      ViewParent viewParent = r.s(param1View);
      if (viewParent instanceof View)
        param1b.f0((View)viewParent); 
      int j = this.e.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = this.e.getChildAt(i);
        if (!o(view) && view.getVisibility() == 0) {
          r.T(view, 1);
          param1b.c(view);
        } 
      } 
    }
    
    public boolean i(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return !o(param1View) ? super.i(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
    
    public final void n(b.h.n.a0.b param1b1, b.h.n.a0.b param1b2) {
      Rect rect = this.d;
      param1b2.k(rect);
      param1b1.R(rect);
      param1b2.l(rect);
      param1b1.S(rect);
      param1b1.l0(param1b2.J());
      param1b1.d0(param1b2.s());
      param1b1.U(param1b2.m());
      param1b1.W(param1b2.o());
      param1b1.X(param1b2.C());
      param1b1.V(param1b2.B());
      param1b1.Y(param1b2.D());
      param1b1.Z(param1b2.E());
      param1b1.P(param1b2.y());
      param1b1.i0(param1b2.I());
      param1b1.b0(param1b2.F());
      param1b1.a(param1b2.j());
      param1b1.c0(param1b2.q());
    }
    
    public boolean o(View param1View) {
      return this.e.h(param1View);
    }
  }
  
  public class b implements Runnable {
    public final View a;
    
    public b(SlidingPaneLayout this$0, View param1View) {
      this.a = param1View;
    }
    
    public void run() {
      if (this.a.getParent() == this.b) {
        this.a.setLayerType(0, null);
        this.b.g(this.a);
      } 
      this.b.E.remove(this);
    }
  }
  
  public class c extends b.j.a.a.c {
    public c(SlidingPaneLayout this$0) {}
    
    public int a(View param1View, int param1Int1, int param1Int2) {
      SlidingPaneLayout.d d = (SlidingPaneLayout.d)this.a.g.getLayoutParams();
      if (this.a.i()) {
        param1Int2 = this.a.getWidth() - this.a.getPaddingRight() + d.rightMargin + this.a.g.getWidth();
        int j = this.a.j;
        return Math.max(Math.min(param1Int1, param1Int2), param1Int2 - j);
      } 
      param1Int2 = this.a.getPaddingLeft() + d.leftMargin;
      int i = this.a.j;
      return Math.min(Math.max(param1Int1, param1Int2), i + param1Int2);
    }
    
    public int b(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public int d(View param1View) {
      return this.a.j;
    }
    
    public void f(int param1Int1, int param1Int2) {
      SlidingPaneLayout slidingPaneLayout = this.a;
      slidingPaneLayout.p.c(slidingPaneLayout.g, param1Int2);
    }
    
    public void i(View param1View, int param1Int) {
      this.a.p();
    }
    
    public void j(int param1Int) {
      if (this.a.p.A() == 0) {
        SlidingPaneLayout slidingPaneLayout = this.a;
        if (slidingPaneLayout.h == 0.0F) {
          slidingPaneLayout.r(slidingPaneLayout.g);
          slidingPaneLayout = this.a;
          slidingPaneLayout.d(slidingPaneLayout.g);
          this.a.q = false;
          return;
        } 
        slidingPaneLayout.e(slidingPaneLayout.g);
        this.a.q = true;
      } 
    }
    
    public void k(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a.l(param1Int1);
      this.a.invalidate();
    }
    
    public void l(View param1View, float param1Float1, float param1Float2) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   4: checkcast androidx/slidingpanelayout/widget/SlidingPaneLayout$d
      //   7: astore #6
      //   9: aload_0
      //   10: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   13: invokevirtual i : ()Z
      //   16: ifeq -> 109
      //   19: aload_0
      //   20: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   23: invokevirtual getPaddingRight : ()I
      //   26: aload #6
      //   28: getfield rightMargin : I
      //   31: iadd
      //   32: istore #5
      //   34: fload_2
      //   35: fconst_0
      //   36: fcmpg
      //   37: iflt -> 67
      //   40: iload #5
      //   42: istore #4
      //   44: fload_2
      //   45: fconst_0
      //   46: fcmpl
      //   47: ifne -> 79
      //   50: iload #5
      //   52: istore #4
      //   54: aload_0
      //   55: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   58: getfield h : F
      //   61: ldc 0.5
      //   63: fcmpl
      //   64: ifle -> 79
      //   67: iload #5
      //   69: aload_0
      //   70: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   73: getfield j : I
      //   76: iadd
      //   77: istore #4
      //   79: aload_0
      //   80: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   83: getfield g : Landroid/view/View;
      //   86: invokevirtual getWidth : ()I
      //   89: istore #5
      //   91: aload_0
      //   92: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   95: invokevirtual getWidth : ()I
      //   98: iload #4
      //   100: isub
      //   101: iload #5
      //   103: isub
      //   104: istore #4
      //   106: goto -> 173
      //   109: aload_0
      //   110: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   113: invokevirtual getPaddingLeft : ()I
      //   116: istore #4
      //   118: aload #6
      //   120: getfield leftMargin : I
      //   123: iload #4
      //   125: iadd
      //   126: istore #5
      //   128: fload_2
      //   129: fconst_0
      //   130: fcmpl
      //   131: ifgt -> 161
      //   134: iload #5
      //   136: istore #4
      //   138: fload_2
      //   139: fconst_0
      //   140: fcmpl
      //   141: ifne -> 173
      //   144: iload #5
      //   146: istore #4
      //   148: aload_0
      //   149: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   152: getfield h : F
      //   155: ldc 0.5
      //   157: fcmpl
      //   158: ifle -> 173
      //   161: iload #5
      //   163: aload_0
      //   164: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   167: getfield j : I
      //   170: iadd
      //   171: istore #4
      //   173: aload_0
      //   174: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   177: getfield p : Lb/j/a/a;
      //   180: iload #4
      //   182: aload_1
      //   183: invokevirtual getTop : ()I
      //   186: invokevirtual N : (II)Z
      //   189: pop
      //   190: aload_0
      //   191: getfield a : Landroidx/slidingpanelayout/widget/SlidingPaneLayout;
      //   194: invokevirtual invalidate : ()V
      //   197: return
    }
    
    public boolean m(View param1View, int param1Int) {
      return this.a.k ? false : ((SlidingPaneLayout.d)param1View.getLayoutParams()).b;
    }
  }
  
  public static class d extends ViewGroup.MarginLayoutParams {
    public static final int[] e = new int[] { 16843137 };
    
    public float a = 0.0F;
    
    public boolean b;
    
    public boolean c;
    
    public Paint d;
    
    public d() {
      super(-1, -1);
    }
    
    public d(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, e);
      this.a = typedArray.getFloat(0, 0.0F);
      typedArray.recycle();
    }
    
    public d(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public d(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static interface e {
    void a(View param1View, float param1Float);
    
    void b(View param1View);
    
    void c(View param1View);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\slidingpanelayout\widget\SlidingPaneLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */