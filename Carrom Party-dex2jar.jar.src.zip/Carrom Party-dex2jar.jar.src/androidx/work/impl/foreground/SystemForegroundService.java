package androidx.work.impl.foreground;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import b.n.j;
import b.y.l;
import b.y.y.n.b;

public class SystemForegroundService extends j implements b.b {
  public static final String f = l.f("SystemFgService");
  
  public Handler b;
  
  public boolean c;
  
  public b d;
  
  public NotificationManager e;
  
  public void d(int paramInt1, int paramInt2, Notification paramNotification) {
    this.b.post(new a(this, paramInt1, paramNotification, paramInt2));
  }
  
  public void e(int paramInt, Notification paramNotification) {
    this.b.post(new b(this, paramInt, paramNotification));
  }
  
  public void f(int paramInt) {
    this.b.post(new c(this, paramInt));
  }
  
  public final void g() {
    this.b = new Handler(Looper.getMainLooper());
    this.e = (NotificationManager)getApplicationContext().getSystemService("notification");
    b b1 = new b(getApplicationContext());
    this.d = b1;
    b1.m(this);
  }
  
  public void onCreate() {
    super.onCreate();
    g();
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.d.k();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.c) {
      l.c().d(f, "Re-initializing SystemForegroundService after a request to shut-down.", new Throwable[0]);
      this.d.k();
      g();
      this.c = false;
    } 
    if (paramIntent != null)
      this.d.l(paramIntent); 
    return 3;
  }
  
  public void stop() {
    this.c = true;
    l.c().a(f, "All commands completed.", new Throwable[0]);
    if (Build.VERSION.SDK_INT >= 26)
      stopForeground(true); 
    stopSelf();
  }
  
  public class a implements Runnable {
    public a(SystemForegroundService this$0, int param1Int1, Notification param1Notification, int param1Int2) {}
    
    public void run() {
      if (Build.VERSION.SDK_INT >= 29) {
        this.d.startForeground(this.a, this.b, this.c);
        return;
      } 
      this.d.startForeground(this.a, this.b);
    }
  }
  
  public class b implements Runnable {
    public b(SystemForegroundService this$0, int param1Int, Notification param1Notification) {}
    
    public void run() {
      this.c.e.notify(this.a, this.b);
    }
  }
  
  public class c implements Runnable {
    public c(SystemForegroundService this$0, int param1Int) {}
    
    public void run() {
      this.b.e.cancel(this.a);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\impl\foreground\SystemForegroundService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */