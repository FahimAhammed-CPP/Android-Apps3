package androidx.work.impl.workers;

import android.content.Context;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import b.y.l;
import b.y.y.j;
import b.y.y.m.c;
import b.y.y.m.d;
import b.y.y.o.p;
import b.y.y.p.q.c;
import java.util.Collections;
import java.util.List;

public class ConstraintTrackingWorker extends ListenableWorker implements c {
  public static final String k = l.f("ConstraintTrkngWrkr");
  
  public WorkerParameters f;
  
  public final Object g;
  
  public volatile boolean h;
  
  public c<ListenableWorker.a> i;
  
  public ListenableWorker j;
  
  public ConstraintTrackingWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
    this.f = paramWorkerParameters;
    this.g = new Object();
    this.h = false;
    this.i = c.u();
  }
  
  public WorkDatabase a() {
    return j.m(getApplicationContext()).q();
  }
  
  public void b(List<String> paramList) {
    l.c().a(k, String.format("Constraints changed for %s", new Object[] { paramList }), new Throwable[0]);
    synchronized (this.g) {
      this.h = true;
      return;
    } 
  }
  
  public void c() {
    this.i.q(ListenableWorker.a.a());
  }
  
  public void d() {
    this.i.q(ListenableWorker.a.b());
  }
  
  public void e() {
    String str = getInputData().j("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
    if (TextUtils.isEmpty(str)) {
      l.c().b(k, "No worker to delegate to.", new Throwable[0]);
      c();
      return;
    } 
    ListenableWorker listenableWorker = getWorkerFactory().b(getApplicationContext(), str, this.f);
    this.j = listenableWorker;
    if (listenableWorker == null) {
      l.c().a(k, "No worker to delegate to.", new Throwable[0]);
      c();
      return;
    } 
    p p = a().B().o(getId().toString());
    if (p == null) {
      c();
      return;
    } 
    d d = new d(getApplicationContext(), getTaskExecutor(), this);
    d.d(Collections.singletonList(p));
    if (d.c(getId().toString())) {
      l.c().a(k, String.format("Constraints met for delegate %s", new Object[] { str }), new Throwable[0]);
      try {
        return;
      } finally {
        d = null;
        l l = l.c();
        null = k;
        l.a(null, String.format("Delegated worker %s threw exception in startWork.", new Object[] { str }), new Throwable[] { (Throwable)d });
      } 
    } 
    l.c().a(k, String.format("Constraints not met for delegate %s. Requesting retry.", new Object[] { str }), new Throwable[0]);
    d();
  }
  
  public void f(List<String> paramList) {}
  
  public b.y.y.p.r.a getTaskExecutor() {
    return j.m(getApplicationContext()).r();
  }
  
  public boolean isRunInForeground() {
    ListenableWorker listenableWorker = this.j;
    return (listenableWorker != null && listenableWorker.isRunInForeground());
  }
  
  public void onStopped() {
    super.onStopped();
    ListenableWorker listenableWorker = this.j;
    if (listenableWorker != null && !listenableWorker.isStopped())
      this.j.stop(); 
  }
  
  public c.f.c.a.a.a<ListenableWorker.a> startWork() {
    getBackgroundExecutor().execute(new a(this));
    return (c.f.c.a.a.a<ListenableWorker.a>)this.i;
  }
  
  public class a implements Runnable {
    public a(ConstraintTrackingWorker this$0) {}
    
    public void run() {
      this.a.e();
    }
  }
  
  public class b implements Runnable {
    public b(ConstraintTrackingWorker this$0, c.f.c.a.a.a param1a) {}
    
    public void run() {
      synchronized (this.b.g) {
        if (this.b.h) {
          this.b.d();
        } else {
          this.b.i.s(this.a);
        } 
        return;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\impl\workers\ConstraintTrackingWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */