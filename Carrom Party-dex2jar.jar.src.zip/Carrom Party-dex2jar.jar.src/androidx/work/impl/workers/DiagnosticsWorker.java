package androidx.work.impl.workers;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import b.y.l;
import b.y.y.j;
import b.y.y.o.g;
import b.y.y.o.h;
import b.y.y.o.k;
import b.y.y.o.p;
import b.y.y.o.q;
import b.y.y.o.t;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class DiagnosticsWorker extends Worker {
  public static final String g = l.f("DiagnosticsWrkr");
  
  public DiagnosticsWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public static String a(p paramp, String paramString1, Integer paramInteger, String paramString2) {
    return String.format("\n%s\t %s\t %s\t %s\t %s\t %s\t", new Object[] { paramp.a, paramp.c, paramInteger, paramp.b.name(), paramString1, paramString2 });
  }
  
  public static String c(k paramk, t paramt, h paramh, List<p> paramList) {
    String str;
    StringBuilder stringBuilder = new StringBuilder();
    if (Build.VERSION.SDK_INT >= 23) {
      str = "Job Id";
    } else {
      str = "Alarm Id";
    } 
    stringBuilder.append(String.format("\n Id \t Class Name\t %s\t State\t Unique Name\t Tags\t", new Object[] { str }));
    for (p p : paramList) {
      Integer integer;
      paramList = null;
      g g = paramh.c(p.a);
      if (g != null)
        integer = Integer.valueOf(g.b); 
      List list1 = paramk.b(p.a);
      List list2 = paramt.b(p.a);
      stringBuilder.append(a(p, TextUtils.join(",", list1), integer, TextUtils.join(",", list2)));
    } 
    return stringBuilder.toString();
  }
  
  public ListenableWorker.a doWork() {
    WorkDatabase workDatabase = j.m(getApplicationContext()).q();
    q q = workDatabase.B();
    k k = workDatabase.z();
    t t = workDatabase.C();
    h h = workDatabase.y();
    List<p> list3 = q.f(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1L));
    List<p> list2 = q.k();
    List<p> list1 = q.v(200);
    if (list3 != null && !list3.isEmpty()) {
      l l = l.c();
      String str = g;
      l.d(str, "Recently completed work:\n\n", new Throwable[0]);
      l.c().d(str, c(k, t, h, list3), new Throwable[0]);
    } 
    if (list2 != null && !list2.isEmpty()) {
      l l = l.c();
      String str = g;
      l.d(str, "Running work:\n\n", new Throwable[0]);
      l.c().d(str, c(k, t, h, list2), new Throwable[0]);
    } 
    if (list1 != null && !list1.isEmpty()) {
      l l = l.c();
      String str = g;
      l.d(str, "Enqueued work:\n\n", new Throwable[0]);
      l.c().d(str, c(k, t, h, list1), new Throwable[0]);
    } 
    return ListenableWorker.a.c();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\impl\workers\DiagnosticsWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */