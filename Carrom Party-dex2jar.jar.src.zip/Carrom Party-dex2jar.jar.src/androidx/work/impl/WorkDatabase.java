package androidx.work.impl;

import android.content.Context;
import b.r.h;
import b.r.i;
import b.t.a.c;
import b.t.a.g.c;
import b.y.y.h;
import b.y.y.i;
import b.y.y.o.e;
import b.y.y.o.h;
import b.y.y.o.k;
import b.y.y.o.n;
import b.y.y.o.q;
import b.y.y.o.t;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

public abstract class WorkDatabase extends i {
  public static final long j = TimeUnit.DAYS.toMillis(1L);
  
  public static WorkDatabase s(Context paramContext, Executor paramExecutor, boolean paramBoolean) {
    i.a a;
    if (paramBoolean) {
      a = h.c(paramContext, WorkDatabase.class);
      a.c();
    } else {
      a = h.a(paramContext, WorkDatabase.class, i.d());
      a.f(new a(paramContext));
    } 
    a.g(paramExecutor);
    a.a(u());
    a.b(new b.r.q.a[] { h.a });
    a.b(new b.r.q.a[] { (b.r.q.a)new h.h(paramContext, 2, 3) });
    a.b(new b.r.q.a[] { h.b });
    a.b(new b.r.q.a[] { h.c });
    a.b(new b.r.q.a[] { (b.r.q.a)new h.h(paramContext, 5, 6) });
    a.b(new b.r.q.a[] { h.d });
    a.b(new b.r.q.a[] { h.e });
    a.b(new b.r.q.a[] { h.f });
    a.b(new b.r.q.a[] { (b.r.q.a)new h.i(paramContext) });
    a.b(new b.r.q.a[] { (b.r.q.a)new h.h(paramContext, 10, 11) });
    a.b(new b.r.q.a[] { h.g });
    a.e();
    return (WorkDatabase)a.d();
  }
  
  public static i.b u() {
    return new b();
  }
  
  public static long v() {
    return System.currentTimeMillis() - j;
  }
  
  public static String w() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DELETE FROM workspec WHERE state IN (2, 3, 5) AND (period_start_time + minimum_retention_duration) < ");
    stringBuilder.append(v());
    stringBuilder.append(" AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))");
    return stringBuilder.toString();
  }
  
  public abstract n A();
  
  public abstract q B();
  
  public abstract t C();
  
  public abstract b.y.y.o.b t();
  
  public abstract e x();
  
  public abstract h y();
  
  public abstract k z();
  
  public class a implements c.c {
    public a(WorkDatabase this$0) {}
    
    public c a(c.b param1b) {
      c.b.a a1 = c.b.a(this.a);
      a1.c(param1b.b);
      a1.b(param1b.c);
      a1.d(true);
      return (new c()).a(a1.a());
    }
  }
  
  public class b extends i.b {
    public void c(b.t.a.b param1b) {
      super.c(param1b);
      param1b.v();
      try {
        param1b.H(WorkDatabase.w());
        param1b.v0();
        return;
      } finally {
        param1b.R0();
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\impl\WorkDatabase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */