package androidx.work.impl;

import b.r.f;
import b.r.i;
import b.r.k;
import b.r.r.c;
import b.r.r.f;
import b.t.a.b;
import b.t.a.c;
import b.y.y.o.b;
import b.y.y.o.e;
import b.y.y.o.h;
import b.y.y.o.k;
import b.y.y.o.n;
import b.y.y.o.q;
import b.y.y.o.t;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public final class WorkDatabase_Impl extends WorkDatabase {
  public volatile q k;
  
  public volatile b l;
  
  public volatile t m;
  
  public volatile h n;
  
  public volatile k o;
  
  public volatile n p;
  
  public volatile e q;
  
  public n A() {
    // Byte code:
    //   0: aload_0
    //   1: getfield p : Lb/y/y/o/n;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield p : Lb/y/y/o/n;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield p : Lb/y/y/o/n;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new b/y/y/o/o
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lb/r/i;)V
    //   30: putfield p : Lb/y/y/o/n;
    //   33: aload_0
    //   34: getfield p : Lb/y/y/o/n;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public q B() {
    // Byte code:
    //   0: aload_0
    //   1: getfield k : Lb/y/y/o/q;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield k : Lb/y/y/o/q;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield k : Lb/y/y/o/q;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new b/y/y/o/r
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lb/r/i;)V
    //   30: putfield k : Lb/y/y/o/q;
    //   33: aload_0
    //   34: getfield k : Lb/y/y/o/q;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public t C() {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Lb/y/y/o/t;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield m : Lb/y/y/o/t;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield m : Lb/y/y/o/t;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new b/y/y/o/u
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lb/r/i;)V
    //   30: putfield m : Lb/y/y/o/t;
    //   33: aload_0
    //   34: getfield m : Lb/y/y/o/t;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public f e() {
    return new f(this, new HashMap<Object, Object>(0), new HashMap<Object, Object>(0), new String[] { "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference" });
  }
  
  public c f(b.r.a parama) {
    k k1 = new k(parama, new a(this, 12), "c103703e120ae8cc73c9248622f3cd1e", "49f946663a8deb7054212b8adda248c6");
    c.b.a a1 = c.b.a(parama.b);
    a1.c(parama.c);
    a1.b((c.a)k1);
    c.b b1 = a1.a();
    return parama.a.a(b1);
  }
  
  public b t() {
    // Byte code:
    //   0: aload_0
    //   1: getfield l : Lb/y/y/o/b;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield l : Lb/y/y/o/b;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield l : Lb/y/y/o/b;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new b/y/y/o/c
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lb/r/i;)V
    //   30: putfield l : Lb/y/y/o/b;
    //   33: aload_0
    //   34: getfield l : Lb/y/y/o/b;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public e x() {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Lb/y/y/o/e;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield q : Lb/y/y/o/e;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield q : Lb/y/y/o/e;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new b/y/y/o/f
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lb/r/i;)V
    //   30: putfield q : Lb/y/y/o/e;
    //   33: aload_0
    //   34: getfield q : Lb/y/y/o/e;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public h y() {
    // Byte code:
    //   0: aload_0
    //   1: getfield n : Lb/y/y/o/h;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield n : Lb/y/y/o/h;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield n : Lb/y/y/o/h;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new b/y/y/o/i
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lb/r/i;)V
    //   30: putfield n : Lb/y/y/o/h;
    //   33: aload_0
    //   34: getfield n : Lb/y/y/o/h;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public k z() {
    // Byte code:
    //   0: aload_0
    //   1: getfield o : Lb/y/y/o/k;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield o : Lb/y/y/o/k;
    //   11: areturn
    //   12: aload_0
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield o : Lb/y/y/o/k;
    //   18: ifnonnull -> 33
    //   21: aload_0
    //   22: new b/y/y/o/l
    //   25: dup
    //   26: aload_0
    //   27: invokespecial <init> : (Lb/r/i;)V
    //   30: putfield o : Lb/y/y/o/k;
    //   33: aload_0
    //   34: getfield o : Lb/y/y/o/k;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   14	33	42	finally
    //   33	40	42	finally
    //   43	45	42	finally
  }
  
  public class a extends k.a {
    public a(WorkDatabase_Impl this$0, int param1Int) {
      super(param1Int);
    }
    
    public void a(b param1b) {
      param1b.H("CREATE TABLE IF NOT EXISTS `Dependency` (`work_spec_id` TEXT NOT NULL, `prerequisite_id` TEXT NOT NULL, PRIMARY KEY(`work_spec_id`, `prerequisite_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE , FOREIGN KEY(`prerequisite_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1b.H("CREATE INDEX IF NOT EXISTS `index_Dependency_work_spec_id` ON `Dependency` (`work_spec_id`)");
      param1b.H("CREATE INDEX IF NOT EXISTS `index_Dependency_prerequisite_id` ON `Dependency` (`prerequisite_id`)");
      param1b.H("CREATE TABLE IF NOT EXISTS `WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `period_start_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `required_network_type` INTEGER, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB, PRIMARY KEY(`id`))");
      param1b.H("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
      param1b.H("CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `WorkSpec` (`period_start_time`)");
      param1b.H("CREATE TABLE IF NOT EXISTS `WorkTag` (`tag` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`tag`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1b.H("CREATE INDEX IF NOT EXISTS `index_WorkTag_work_spec_id` ON `WorkTag` (`work_spec_id`)");
      param1b.H("CREATE TABLE IF NOT EXISTS `SystemIdInfo` (`work_spec_id` TEXT NOT NULL, `system_id` INTEGER NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1b.H("CREATE TABLE IF NOT EXISTS `WorkName` (`name` TEXT NOT NULL, `work_spec_id` TEXT NOT NULL, PRIMARY KEY(`name`, `work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1b.H("CREATE INDEX IF NOT EXISTS `index_WorkName_work_spec_id` ON `WorkName` (`work_spec_id`)");
      param1b.H("CREATE TABLE IF NOT EXISTS `WorkProgress` (`work_spec_id` TEXT NOT NULL, `progress` BLOB NOT NULL, PRIMARY KEY(`work_spec_id`), FOREIGN KEY(`work_spec_id`) REFERENCES `WorkSpec`(`id`) ON UPDATE CASCADE ON DELETE CASCADE )");
      param1b.H("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
      param1b.H("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
      param1b.H("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'c103703e120ae8cc73c9248622f3cd1e')");
    }
    
    public void b(b param1b) {
      param1b.H("DROP TABLE IF EXISTS `Dependency`");
      param1b.H("DROP TABLE IF EXISTS `WorkSpec`");
      param1b.H("DROP TABLE IF EXISTS `WorkTag`");
      param1b.H("DROP TABLE IF EXISTS `SystemIdInfo`");
      param1b.H("DROP TABLE IF EXISTS `WorkName`");
      param1b.H("DROP TABLE IF EXISTS `WorkProgress`");
      param1b.H("DROP TABLE IF EXISTS `Preference`");
      if (WorkDatabase_Impl.D(this.b) != null) {
        int i = 0;
        int j = WorkDatabase_Impl.E(this.b).size();
        while (i < j) {
          ((i.b)WorkDatabase_Impl.G(this.b).get(i)).b(param1b);
          i++;
        } 
      } 
    }
    
    public void c(b param1b) {
      if (WorkDatabase_Impl.H(this.b) != null) {
        int i = 0;
        int j = WorkDatabase_Impl.I(this.b).size();
        while (i < j) {
          ((i.b)WorkDatabase_Impl.J(this.b).get(i)).a(param1b);
          i++;
        } 
      } 
    }
    
    public void d(b param1b) {
      WorkDatabase_Impl.K(this.b, param1b);
      param1b.H("PRAGMA foreign_keys = ON");
      WorkDatabase_Impl.L(this.b, param1b);
      if (WorkDatabase_Impl.M(this.b) != null) {
        int i = 0;
        int j = WorkDatabase_Impl.N(this.b).size();
        while (i < j) {
          ((i.b)WorkDatabase_Impl.F(this.b).get(i)).c(param1b);
          i++;
        } 
      } 
    }
    
    public void e(b param1b) {}
    
    public void f(b param1b) {
      c.a(param1b);
    }
    
    public k.b g(b param1b) {
      StringBuilder stringBuilder;
      HashMap<Object, Object> hashMap7 = new HashMap<Object, Object>(2);
      hashMap7.put("work_spec_id", new f.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap7.put("prerequisite_id", new f.a("prerequisite_id", "TEXT", true, 2, null, 1));
      HashSet<f.b> hashSet5 = new HashSet(2);
      hashSet5.add(new f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet5.add(new f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "prerequisite_id" }, ), Arrays.asList(new String[] { "id" })));
      HashSet<f.d> hashSet6 = new HashSet(2);
      hashSet6.add(new f.d("index_Dependency_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      hashSet6.add(new f.d("index_Dependency_prerequisite_id", false, Arrays.asList(new String[] { "prerequisite_id" })));
      f f8 = new f("Dependency", hashMap7, hashSet5, hashSet6);
      f f14 = f.a(param1b, "Dependency");
      if (!f8.equals(f14)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Dependency(androidx.work.impl.model.Dependency).\n Expected:\n");
        stringBuilder.append(f8);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(f14);
        return new k.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap6 = new HashMap<Object, Object>(25);
      hashMap6.put("id", new f.a("id", "TEXT", true, 1, null, 1));
      hashMap6.put("state", new f.a("state", "INTEGER", true, 0, null, 1));
      hashMap6.put("worker_class_name", new f.a("worker_class_name", "TEXT", true, 0, null, 1));
      hashMap6.put("input_merger_class_name", new f.a("input_merger_class_name", "TEXT", false, 0, null, 1));
      hashMap6.put("input", new f.a("input", "BLOB", true, 0, null, 1));
      hashMap6.put("output", new f.a("output", "BLOB", true, 0, null, 1));
      hashMap6.put("initial_delay", new f.a("initial_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("interval_duration", new f.a("interval_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("flex_duration", new f.a("flex_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("run_attempt_count", new f.a("run_attempt_count", "INTEGER", true, 0, null, 1));
      hashMap6.put("backoff_policy", new f.a("backoff_policy", "INTEGER", true, 0, null, 1));
      hashMap6.put("backoff_delay_duration", new f.a("backoff_delay_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("period_start_time", new f.a("period_start_time", "INTEGER", true, 0, null, 1));
      hashMap6.put("minimum_retention_duration", new f.a("minimum_retention_duration", "INTEGER", true, 0, null, 1));
      hashMap6.put("schedule_requested_at", new f.a("schedule_requested_at", "INTEGER", true, 0, null, 1));
      hashMap6.put("run_in_foreground", new f.a("run_in_foreground", "INTEGER", true, 0, null, 1));
      hashMap6.put("out_of_quota_policy", new f.a("out_of_quota_policy", "INTEGER", true, 0, null, 1));
      hashMap6.put("required_network_type", new f.a("required_network_type", "INTEGER", false, 0, null, 1));
      hashMap6.put("requires_charging", new f.a("requires_charging", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_device_idle", new f.a("requires_device_idle", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_battery_not_low", new f.a("requires_battery_not_low", "INTEGER", true, 0, null, 1));
      hashMap6.put("requires_storage_not_low", new f.a("requires_storage_not_low", "INTEGER", true, 0, null, 1));
      hashMap6.put("trigger_content_update_delay", new f.a("trigger_content_update_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("trigger_max_content_delay", new f.a("trigger_max_content_delay", "INTEGER", true, 0, null, 1));
      hashMap6.put("content_uri_triggers", new f.a("content_uri_triggers", "BLOB", false, 0, null, 1));
      HashSet hashSet = new HashSet(0);
      hashSet6 = new HashSet<f.d>(2);
      hashSet6.add(new f.d("index_WorkSpec_schedule_requested_at", false, Arrays.asList(new String[] { "schedule_requested_at" })));
      hashSet6.add(new f.d("index_WorkSpec_period_start_time", false, Arrays.asList(new String[] { "period_start_time" })));
      f f7 = new f("WorkSpec", hashMap6, hashSet, hashSet6);
      f f13 = f.a((b)stringBuilder, "WorkSpec");
      if (!f7.equals(f13)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkSpec(androidx.work.impl.model.WorkSpec).\n Expected:\n");
        stringBuilder.append(f7);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(f13);
        return new k.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap5 = new HashMap<Object, Object>(2);
      hashMap5.put("tag", new f.a("tag", "TEXT", true, 1, null, 1));
      hashMap5.put("work_spec_id", new f.a("work_spec_id", "TEXT", true, 2, null, 1));
      HashSet<f.b> hashSet4 = new HashSet(1);
      hashSet4.add(new f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet6 = new HashSet<f.d>(1);
      hashSet6.add(new f.d("index_WorkTag_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      f f6 = new f("WorkTag", hashMap5, hashSet4, hashSet6);
      f f12 = f.a((b)stringBuilder, "WorkTag");
      if (!f6.equals(f12)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkTag(androidx.work.impl.model.WorkTag).\n Expected:\n");
        stringBuilder.append(f6);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(f12);
        return new k.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap4 = new HashMap<Object, Object>(2);
      hashMap4.put("work_spec_id", new f.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap4.put("system_id", new f.a("system_id", "INTEGER", true, 0, null, 1));
      HashSet<f.b> hashSet3 = new HashSet(1);
      hashSet3.add(new f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      f f5 = new f("SystemIdInfo", hashMap4, hashSet3, new HashSet(0));
      f f11 = f.a((b)stringBuilder, "SystemIdInfo");
      if (!f5.equals(f11)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("SystemIdInfo(androidx.work.impl.model.SystemIdInfo).\n Expected:\n");
        stringBuilder.append(f5);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(f11);
        return new k.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap3 = new HashMap<Object, Object>(2);
      hashMap3.put("name", new f.a("name", "TEXT", true, 1, null, 1));
      hashMap3.put("work_spec_id", new f.a("work_spec_id", "TEXT", true, 2, null, 1));
      HashSet<f.b> hashSet2 = new HashSet(1);
      hashSet2.add(new f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      hashSet6 = new HashSet<f.d>(1);
      hashSet6.add(new f.d("index_WorkName_work_spec_id", false, Arrays.asList(new String[] { "work_spec_id" })));
      f f4 = new f("WorkName", hashMap3, hashSet2, hashSet6);
      f f10 = f.a((b)stringBuilder, "WorkName");
      if (!f4.equals(f10)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkName(androidx.work.impl.model.WorkName).\n Expected:\n");
        stringBuilder.append(f4);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(f10);
        return new k.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>(2);
      hashMap2.put("work_spec_id", new f.a("work_spec_id", "TEXT", true, 1, null, 1));
      hashMap2.put("progress", new f.a("progress", "BLOB", true, 0, null, 1));
      HashSet<f.b> hashSet1 = new HashSet(1);
      hashSet1.add(new f.b("WorkSpec", "CASCADE", "CASCADE", Arrays.asList(new String[] { "work_spec_id" }, ), Arrays.asList(new String[] { "id" })));
      f f3 = new f("WorkProgress", hashMap2, hashSet1, new HashSet(0));
      f f9 = f.a((b)stringBuilder, "WorkProgress");
      if (!f3.equals(f9)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("WorkProgress(androidx.work.impl.model.WorkProgress).\n Expected:\n");
        stringBuilder.append(f3);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(f9);
        return new k.b(false, stringBuilder.toString());
      } 
      HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>(2);
      hashMap1.put("key", new f.a("key", "TEXT", true, 1, null, 1));
      hashMap1.put("long_value", new f.a("long_value", "INTEGER", false, 0, null, 1));
      f f2 = new f("Preference", hashMap1, new HashSet(0), new HashSet(0));
      f f1 = f.a((b)stringBuilder, "Preference");
      if (!f2.equals(f1)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Preference(androidx.work.impl.model.Preference).\n Expected:\n");
        stringBuilder1.append(f2);
        stringBuilder1.append("\n Found:\n");
        stringBuilder1.append(f1);
        return new k.b(false, stringBuilder1.toString());
      } 
      return new k.b(true, null);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\impl\WorkDatabase_Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */