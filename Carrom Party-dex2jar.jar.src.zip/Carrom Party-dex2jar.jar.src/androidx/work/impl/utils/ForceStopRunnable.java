package androidx.work.impl.utils;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.ApplicationExitInfo;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteAccessPermException;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.database.sqlite.SQLiteTableLockedException;
import android.os.Build;
import android.text.TextUtils;
import androidx.work.impl.WorkDatabase;
import b.h.j.a;
import b.y.b;
import b.y.i;
import b.y.l;
import b.y.u;
import b.y.y.f;
import b.y.y.i;
import b.y.y.j;
import b.y.y.l.c.b;
import b.y.y.o.n;
import b.y.y.o.p;
import b.y.y.o.q;
import b.y.y.p.f;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ForceStopRunnable implements Runnable {
  public static final String d = l.f("ForceStopRunnable");
  
  public static final long e = TimeUnit.DAYS.toMillis(3650L);
  
  public final Context a;
  
  public final j b;
  
  public int c;
  
  public ForceStopRunnable(Context paramContext, j paramj) {
    this.a = paramContext.getApplicationContext();
    this.b = paramj;
    this.c = 0;
  }
  
  public static Intent c(Context paramContext) {
    Intent intent = new Intent();
    intent.setComponent(new ComponentName(paramContext, BroadcastReceiver.class));
    intent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
    return intent;
  }
  
  public static PendingIntent d(Context paramContext, int paramInt) {
    return PendingIntent.getBroadcast(paramContext, -1, c(paramContext), paramInt);
  }
  
  @SuppressLint({"ClassVerificationFailure"})
  public static void g(Context paramContext) {
    int i;
    AlarmManager alarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    if (a.c()) {
      i = 167772160;
    } else {
      i = 134217728;
    } 
    PendingIntent pendingIntent = d(paramContext, i);
    long l = System.currentTimeMillis() + e;
    if (alarmManager != null) {
      if (Build.VERSION.SDK_INT >= 19) {
        alarmManager.setExact(0, l, pendingIntent);
        return;
      } 
      alarmManager.set(0, l, pendingIntent);
    } 
  }
  
  public boolean a() {
    boolean bool1;
    int i = Build.VERSION.SDK_INT;
    boolean bool2 = false;
    if (i >= 23) {
      bool1 = b.i(this.a, this.b);
    } else {
      bool1 = false;
    } 
    WorkDatabase workDatabase = this.b.q();
    null = workDatabase.B();
    n n = workDatabase.A();
    workDatabase.c();
    try {
      List list = null.k();
      if (list != null && !list.isEmpty()) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0)
        for (p p : list) {
          null.b(u.a.a, new String[] { p.a });
          null.d(p.a, -1L);
        }  
      n.b();
      workDatabase.r();
      workDatabase.g();
      return bool2;
    } finally {
      workDatabase.g();
    } 
  }
  
  public void b() {
    boolean bool = a();
    if (h()) {
      l.c().a(d, "Rescheduling Workers.", new Throwable[0]);
      this.b.u();
      this.b.n().c(false);
      return;
    } 
    if (e()) {
      l.c().a(d, "Application was force-stopped, rescheduling.", new Throwable[0]);
      this.b.u();
      return;
    } 
    if (bool) {
      l.c().a(d, "Found unfinished work, scheduling it.", new Throwable[0]);
      f.b(this.b.k(), this.b.q(), this.b.p());
    } 
  }
  
  @SuppressLint({"ClassVerificationFailure"})
  public boolean e() {
    int i = 536870912;
    try {
      List<ApplicationExitInfo> list;
      if (a.c())
        i = 570425344; 
      PendingIntent pendingIntent = d(this.a, i);
      if (Build.VERSION.SDK_INT >= 30) {
        if (pendingIntent != null)
          pendingIntent.cancel(); 
        list = ((ActivityManager)this.a.getSystemService("activity")).getHistoricalProcessExitReasons(null, 0, 0);
        if (list != null && !list.isEmpty())
          for (i = 0;; i++) {
            if (i < list.size()) {
              if (((ApplicationExitInfo)list.get(i)).getReason() == 10)
                return true; 
            } else {
              return false;
            } 
          }  
      } else if (list == null) {
        g(this.a);
        return true;
      } 
      return false;
    } catch (SecurityException securityException) {
    
    } catch (IllegalArgumentException illegalArgumentException) {}
    l.c().h(d, "Ignoring exception", new Throwable[] { illegalArgumentException });
    return true;
  }
  
  public boolean f() {
    b b = this.b.k();
    if (TextUtils.isEmpty(b.c())) {
      l.c().a(d, "The default process name was not specified.", new Throwable[0]);
      return true;
    } 
    boolean bool = f.b(this.a, b);
    l.c().a(d, String.format("Is default app process = %s", new Object[] { Boolean.valueOf(bool) }), new Throwable[0]);
    return bool;
  }
  
  public boolean h() {
    return this.b.n().a();
  }
  
  public void i(long paramLong) {
    try {
      Thread.sleep(paramLong);
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } 
  }
  
  public void run() {
    try {
      boolean bool = f();
      if (!bool)
        return; 
      while (true) {
        i.e(this.a);
        l.c().a(d, "Performing cleanup operations.", new Throwable[0]);
        try {
          b();
        } catch (SQLiteCantOpenDatabaseException sQLiteCantOpenDatabaseException) {
          IllegalStateException illegalStateException;
          int i = this.c + 1;
          this.c = i;
          if (i >= 3) {
            l l = l.c();
            String str = d;
            l.b(str, "The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", new Throwable[] { (Throwable)sQLiteCantOpenDatabaseException });
            illegalStateException = new IllegalStateException("The file system on the device is in a bad state. WorkManager cannot access the app's internal data store.", (Throwable)sQLiteCantOpenDatabaseException);
            i i1 = this.b.k().d();
            if (i1 != null) {
              l.c().a(str, "Routing exception to the specified exception handler", new Throwable[] { illegalStateException });
              i1.a(illegalStateException);
            } else {
              throw illegalStateException;
            } 
          } else {
            long l = i;
            l.c().a(d, String.format("Retrying after %s", new Object[] { Long.valueOf(l * 300L) }), new Throwable[] { illegalStateException });
            i(this.c * 300L);
            continue;
          } 
        } catch (SQLiteDatabaseCorruptException sQLiteDatabaseCorruptException) {
        
        } catch (SQLiteDatabaseLockedException sQLiteDatabaseLockedException) {
        
        } catch (SQLiteTableLockedException sQLiteTableLockedException) {
        
        } catch (SQLiteConstraintException sQLiteConstraintException) {
        
        } catch (SQLiteAccessPermException sQLiteAccessPermException) {}
        return;
      } 
    } finally {
      this.b.t();
    } 
  }
  
  public static class BroadcastReceiver extends android.content.BroadcastReceiver {
    public static final String a = l.f("ForceStopRunnable$Rcvr");
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Intent != null && "ACTION_FORCE_STOP_RESCHEDULE".equals(param1Intent.getAction())) {
        l.c().g(a, "Rescheduling alarm that keeps track of force-stops.", new Throwable[0]);
        ForceStopRunnable.g(param1Context);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\imp\\utils\ForceStopRunnable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */