package androidx.work.impl.background.systemalarm;

import android.content.Context;
import android.content.Intent;
import b.n.j;
import b.y.l;
import b.y.y.l.b.e;
import b.y.y.p.l;

public class SystemAlarmService extends j implements e.c {
  public static final String d = l.f("SystemAlarmService");
  
  public e b;
  
  public boolean c;
  
  public void b() {
    this.c = true;
    l.c().a(d, "All commands completed in dispatcher", new Throwable[0]);
    l.a();
    stopSelf();
  }
  
  public final void g() {
    e e1 = new e((Context)this);
    this.b = e1;
    e1.m(this);
  }
  
  public void onCreate() {
    super.onCreate();
    g();
    this.c = false;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.c = true;
    this.b.j();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    if (this.c) {
      l.c().d(d, "Re-initializing SystemAlarmDispatcher after a request to shut-down.", new Throwable[0]);
      this.b.j();
      g();
      this.c = false;
    } 
    if (paramIntent != null)
      this.b.a(paramIntent, paramInt2); 
    return 3;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\impl\background\systemalarm\SystemAlarmService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */