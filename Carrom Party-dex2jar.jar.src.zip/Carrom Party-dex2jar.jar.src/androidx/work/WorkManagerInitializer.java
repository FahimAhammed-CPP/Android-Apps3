package androidx.work;

import android.content.Context;
import b.u.b;
import b.y.b;
import b.y.l;
import b.y.v;
import java.util.Collections;
import java.util.List;

public final class WorkManagerInitializer implements b<v> {
  public static final String a = l.f("WrkMgrInitializer");
  
  public List<Class<? extends b<?>>> a() {
    return Collections.emptyList();
  }
  
  public v c(Context paramContext) {
    l.c().a(a, "Initializing WorkManager with default configuration.", new Throwable[0]);
    v.g(paramContext, (new b.b()).a());
    return v.e(paramContext);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\WorkManagerInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */