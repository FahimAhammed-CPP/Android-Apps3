package androidx.work;

import b.y.e;
import b.y.j;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public final class OverwritingInputMerger extends j {
  public e b(List<e> paramList) {
    e.a a = new e.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<e> iterator = paramList.iterator();
    while (iterator.hasNext())
      hashMap.putAll(((e)iterator.next()).i()); 
    a.d(hashMap);
    return a.a();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\OverwritingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */