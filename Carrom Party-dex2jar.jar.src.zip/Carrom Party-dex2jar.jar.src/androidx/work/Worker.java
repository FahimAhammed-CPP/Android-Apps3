package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import b.y.y.p.q.c;

public abstract class Worker extends ListenableWorker {
  public c<ListenableWorker.a> f;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public Worker(Context paramContext, WorkerParameters paramWorkerParameters) {
    super(paramContext, paramWorkerParameters);
  }
  
  public abstract ListenableWorker.a doWork();
  
  public final c.f.c.a.a.a<ListenableWorker.a> startWork() {
    this.f = c.u();
    getBackgroundExecutor().execute(new a(this));
    return (c.f.c.a.a.a<ListenableWorker.a>)this.f;
  }
  
  public class a implements Runnable {
    public a(Worker this$0) {}
    
    public void run() {
      try {
        return;
      } finally {
        Exception exception = null;
        this.a.f.r(exception);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\Worker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */