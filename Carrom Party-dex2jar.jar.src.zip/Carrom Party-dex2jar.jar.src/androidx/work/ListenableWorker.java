package androidx.work;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.annotation.Keep;
import b.y.e;
import b.y.g;
import b.y.x;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public abstract class ListenableWorker {
  public Context a;
  
  public WorkerParameters b;
  
  public volatile boolean c;
  
  public boolean d;
  
  public boolean e;
  
  @SuppressLint({"BanKeepAnnotation"})
  @Keep
  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters) {
    if (paramContext != null) {
      if (paramWorkerParameters != null) {
        this.a = paramContext;
        this.b = paramWorkerParameters;
        return;
      } 
      throw new IllegalArgumentException("WorkerParameters is null");
    } 
    throw new IllegalArgumentException("Application Context is null");
  }
  
  public final Context getApplicationContext() {
    return this.a;
  }
  
  public Executor getBackgroundExecutor() {
    return this.b.a();
  }
  
  public c.f.c.a.a.a<g> getForegroundInfoAsync() {
    b.y.y.p.q.c c = b.y.y.p.q.c.u();
    c.r(new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
    return (c.f.c.a.a.a<g>)c;
  }
  
  public final UUID getId() {
    return this.b.c();
  }
  
  public final e getInputData() {
    return this.b.d();
  }
  
  public final Network getNetwork() {
    return this.b.e();
  }
  
  public final int getRunAttemptCount() {
    return this.b.g();
  }
  
  public final Set<String> getTags() {
    return this.b.h();
  }
  
  public b.y.y.p.r.a getTaskExecutor() {
    return this.b.i();
  }
  
  public final List<String> getTriggeredContentAuthorities() {
    return this.b.j();
  }
  
  public final List<Uri> getTriggeredContentUris() {
    return this.b.k();
  }
  
  public x getWorkerFactory() {
    return this.b.l();
  }
  
  public boolean isRunInForeground() {
    return this.e;
  }
  
  public final boolean isStopped() {
    return this.c;
  }
  
  public final boolean isUsed() {
    return this.d;
  }
  
  public void onStopped() {}
  
  public final c.f.c.a.a.a<Void> setForegroundAsync(g paramg) {
    this.e = true;
    return this.b.b().a(getApplicationContext(), getId(), paramg);
  }
  
  public c.f.c.a.a.a<Void> setProgressAsync(e parame) {
    return this.b.f().a(getApplicationContext(), getId(), parame);
  }
  
  public void setRunInForeground(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public final void setUsed() {
    this.d = true;
  }
  
  public abstract c.f.c.a.a.a<a> startWork();
  
  public final void stop() {
    this.c = true;
    onStopped();
  }
  
  public static abstract class a {
    public static a a() {
      return new a();
    }
    
    public static a b() {
      return new b();
    }
    
    public static a c() {
      return new c();
    }
    
    public static a d(e param1e) {
      return new c(param1e);
    }
    
    public static final class a extends a {
      public final e a;
      
      public a() {
        this(e.c);
      }
      
      public a(e param2e) {
        this.a = param2e;
      }
      
      public e e() {
        return this.a;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || a.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((a)param2Object).a);
      }
      
      public int hashCode() {
        return a.class.getName().hashCode() * 31 + this.a.hashCode();
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failure {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
    
    public static final class b extends a {
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : ((param2Object != null && b.class == param2Object.getClass()));
      }
      
      public int hashCode() {
        return b.class.getName().hashCode();
      }
      
      public String toString() {
        return "Retry";
      }
    }
    
    public static final class c extends a {
      public final e a;
      
      public c() {
        this(e.c);
      }
      
      public c(e param2e) {
        this.a = param2e;
      }
      
      public e e() {
        return this.a;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (param2Object == null || c.class != param2Object.getClass())
          return false; 
        param2Object = param2Object;
        return this.a.equals(((c)param2Object).a);
      }
      
      public int hashCode() {
        return c.class.getName().hashCode() * 31 + this.a.hashCode();
      }
      
      public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Success {mOutputData=");
        stringBuilder.append(this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
      }
    }
  }
  
  public static final class a extends a {
    public final e a;
    
    public a() {
      this(e.c);
    }
    
    public a(e param1e) {
      this.a = param1e;
    }
    
    public e e() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || a.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((a)param1Object).a);
    }
    
    public int hashCode() {
      return a.class.getName().hashCode() * 31 + this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failure {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
  
  public static final class b extends a {
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : ((param1Object != null && b.class == param1Object.getClass()));
    }
    
    public int hashCode() {
      return b.class.getName().hashCode();
    }
    
    public String toString() {
      return "Retry";
    }
  }
  
  public static final class c extends a {
    public final e a;
    
    public c() {
      this(e.c);
    }
    
    public c(e param1e) {
      this.a = param1e;
    }
    
    public e e() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null || c.class != param1Object.getClass())
        return false; 
      param1Object = param1Object;
      return this.a.equals(((c)param1Object).a);
    }
    
    public int hashCode() {
      return c.class.getName().hashCode() * 31 + this.a.hashCode();
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Success {mOutputData=");
      stringBuilder.append(this.a);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\ListenableWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */