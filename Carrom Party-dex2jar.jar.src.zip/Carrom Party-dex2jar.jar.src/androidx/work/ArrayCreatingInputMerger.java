package androidx.work;

import b.y.e;
import b.y.j;
import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public final class ArrayCreatingInputMerger extends j {
  public e b(List<e> paramList) {
    e.a a = new e.a();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Iterator<e> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      for (Object object1 : ((e)iterator.next()).i().entrySet()) {
        String str = (String)object1.getKey();
        object1 = object1.getValue();
        Class<?> clazz = object1.getClass();
        Object object2 = hashMap.get(str);
        if (object2 == null) {
          if (!clazz.isArray())
            object1 = f(object1); 
        } else {
          Class<?> clazz1 = object2.getClass();
          if (clazz1.equals(clazz)) {
            if (clazz1.isArray()) {
              object1 = d(object2, object1);
            } else {
              object1 = e(object2, object1);
            } 
          } else if (clazz1.isArray() && clazz1.getComponentType().equals(clazz)) {
            object1 = c(object2, object1);
          } else if (clazz.isArray() && clazz.getComponentType().equals(clazz1)) {
            object1 = c(object1, object2);
          } else {
            throw new IllegalArgumentException();
          } 
        } 
        hashMap.put(str, object1);
      } 
    } 
    a.d(hashMap);
    return a.a();
  }
  
  public final Object c(Object paramObject1, Object paramObject2) {
    int i = Array.getLength(paramObject1);
    Object object = Array.newInstance(paramObject2.getClass(), i + 1);
    System.arraycopy(paramObject1, 0, object, 0, i);
    Array.set(object, i, paramObject2);
    return object;
  }
  
  public final Object d(Object paramObject1, Object paramObject2) {
    int i = Array.getLength(paramObject1);
    int k = Array.getLength(paramObject2);
    Object object = Array.newInstance(paramObject1.getClass().getComponentType(), i + k);
    System.arraycopy(paramObject1, 0, object, 0, i);
    System.arraycopy(paramObject2, 0, object, i, k);
    return object;
  }
  
  public final Object e(Object paramObject1, Object paramObject2) {
    Object object = Array.newInstance(paramObject1.getClass(), 2);
    Array.set(object, 0, paramObject1);
    Array.set(object, 1, paramObject2);
    return object;
  }
  
  public final Object f(Object paramObject) {
    Object object = Array.newInstance(paramObject.getClass(), 1);
    Array.set(object, 0, paramObject);
    return object;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\work\ArrayCreatingInputMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */