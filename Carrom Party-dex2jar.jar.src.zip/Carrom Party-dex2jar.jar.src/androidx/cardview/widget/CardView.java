package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import b.e.b;
import b.e.d;
import b.e.e;
import b.e.f.b;
import b.e.f.c;
import b.e.f.d;
import b.e.f.e;

public class CardView extends FrameLayout {
  public static final int[] h = new int[] { 16842801 };
  
  public static final e i;
  
  public boolean a;
  
  public boolean b;
  
  public int c;
  
  public int d;
  
  public final Rect e;
  
  public final Rect f;
  
  public final d g;
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21) {
      i = (e)new b();
    } else if (i >= 17) {
      i = (e)new b.e.f.a();
    } else {
      i = (e)new c();
    } 
    i.i();
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, b.e.a.a);
  }
  
  public CardView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    ColorStateList colorStateList;
    Rect rect = new Rect();
    this.e = rect;
    this.f = new Rect();
    a a = new a(this);
    this.g = a;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, e.a, paramInt, d.a);
    paramInt = e.d;
    if (typedArray.hasValue(paramInt)) {
      colorStateList = typedArray.getColorStateList(paramInt);
    } else {
      TypedArray typedArray1 = getContext().obtainStyledAttributes(h);
      paramInt = typedArray1.getColor(0, 0);
      typedArray1.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(paramInt, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F) {
        paramInt = getResources().getColor(b.b);
      } else {
        paramInt = getResources().getColor(b.a);
      } 
      colorStateList = ColorStateList.valueOf(paramInt);
    } 
    float f3 = typedArray.getDimension(e.e, 0.0F);
    float f2 = typedArray.getDimension(e.f, 0.0F);
    float f1 = typedArray.getDimension(e.g, 0.0F);
    this.a = typedArray.getBoolean(e.i, false);
    this.b = typedArray.getBoolean(e.h, true);
    paramInt = typedArray.getDimensionPixelSize(e.j, 0);
    rect.left = typedArray.getDimensionPixelSize(e.l, paramInt);
    rect.top = typedArray.getDimensionPixelSize(e.n, paramInt);
    rect.right = typedArray.getDimensionPixelSize(e.m, paramInt);
    rect.bottom = typedArray.getDimensionPixelSize(e.k, paramInt);
    if (f2 > f1)
      f1 = f2; 
    this.c = typedArray.getDimensionPixelSize(e.b, 0);
    this.d = typedArray.getDimensionPixelSize(e.c, 0);
    typedArray.recycle();
    i.a(a, paramContext, colorStateList, f3, f2, f1);
  }
  
  public ColorStateList getCardBackgroundColor() {
    return i.h(this.g);
  }
  
  public float getCardElevation() {
    return i.c(this.g);
  }
  
  public int getContentPaddingBottom() {
    return this.e.bottom;
  }
  
  public int getContentPaddingLeft() {
    return this.e.left;
  }
  
  public int getContentPaddingRight() {
    return this.e.right;
  }
  
  public int getContentPaddingTop() {
    return this.e.top;
  }
  
  public float getMaxCardElevation() {
    return i.g(this.g);
  }
  
  public boolean getPreventCornerOverlap() {
    return this.b;
  }
  
  public float getRadius() {
    return i.d(this.g);
  }
  
  public boolean getUseCompatPadding() {
    return this.a;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    e e1 = i;
    if (!(e1 instanceof b)) {
      int i = View.MeasureSpec.getMode(paramInt1);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(e1.k(this.g)), View.MeasureSpec.getSize(paramInt1)), i); 
      i = View.MeasureSpec.getMode(paramInt2);
      if (i == Integer.MIN_VALUE || i == 1073741824)
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(e1.j(this.g)), View.MeasureSpec.getSize(paramInt2)), i); 
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCardBackgroundColor(int paramInt) {
    i.m(this.g, ColorStateList.valueOf(paramInt));
  }
  
  public void setCardBackgroundColor(ColorStateList paramColorStateList) {
    i.m(this.g, paramColorStateList);
  }
  
  public void setCardElevation(float paramFloat) {
    i.f(this.g, paramFloat);
  }
  
  public void setMaxCardElevation(float paramFloat) {
    i.n(this.g, paramFloat);
  }
  
  public void setMinimumHeight(int paramInt) {
    this.d = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setMinimumWidth(int paramInt) {
    this.c = paramInt;
    super.setMinimumWidth(paramInt);
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void setPreventCornerOverlap(boolean paramBoolean) {
    if (paramBoolean != this.b) {
      this.b = paramBoolean;
      i.l(this.g);
    } 
  }
  
  public void setRadius(float paramFloat) {
    i.b(this.g, paramFloat);
  }
  
  public void setUseCompatPadding(boolean paramBoolean) {
    if (this.a != paramBoolean) {
      this.a = paramBoolean;
      i.e(this.g);
    } 
  }
  
  public class a implements d {
    public Drawable a;
    
    public a(CardView this$0) {}
    
    public void a(int param1Int1, int param1Int2) {
      CardView cardView = this.b;
      if (param1Int1 > cardView.c)
        CardView.b(cardView, param1Int1); 
      cardView = this.b;
      if (param1Int2 > cardView.d)
        CardView.c(cardView, param1Int2); 
    }
    
    public void b(Drawable param1Drawable) {
      this.a = param1Drawable;
      this.b.setBackgroundDrawable(param1Drawable);
    }
    
    public boolean c() {
      return this.b.getPreventCornerOverlap();
    }
    
    public boolean d() {
      return this.b.getUseCompatPadding();
    }
    
    public Drawable e() {
      return this.a;
    }
    
    public View f() {
      return (View)this.b;
    }
    
    public void g(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.b.f.set(param1Int1, param1Int2, param1Int3, param1Int4);
      CardView cardView = this.b;
      Rect rect = cardView.e;
      CardView.a(cardView, param1Int1 + rect.left, param1Int2 + rect.top, param1Int3 + rect.right, param1Int4 + rect.bottom);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\cardview\widget\CardView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */