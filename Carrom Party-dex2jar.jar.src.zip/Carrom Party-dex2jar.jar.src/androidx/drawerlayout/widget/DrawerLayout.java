package androidx.drawerlayout.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import androidx.customview.view.AbsSavedState;
import b.h.n.r;
import java.util.ArrayList;
import java.util.List;

public class DrawerLayout extends ViewGroup {
  public static final int[] V = new int[] { 16843828 };
  
  public static final int[] W = new int[] { 16842931 };
  
  public static final boolean a0;
  
  public static final boolean b0;
  
  public boolean C;
  
  public d D;
  
  public List<d> E;
  
  public float F;
  
  public float G;
  
  public Drawable H;
  
  public Drawable I;
  
  public Drawable J;
  
  public CharSequence K;
  
  public CharSequence L;
  
  public Object M;
  
  public boolean N;
  
  public Drawable O = null;
  
  public Drawable P = null;
  
  public Drawable Q = null;
  
  public Drawable R = null;
  
  public final ArrayList<View> S;
  
  public Rect T;
  
  public Matrix U;
  
  public final c a = new c();
  
  public float b;
  
  public int c;
  
  public int d = -1728053248;
  
  public float e;
  
  public Paint f = new Paint();
  
  public final b.j.a.a g;
  
  public final b.j.a.a h;
  
  public final f i;
  
  public final f j;
  
  public int k;
  
  public boolean l;
  
  public boolean m = true;
  
  public int n = 3;
  
  public int o = 3;
  
  public int p = 3;
  
  public int q = 3;
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 19) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    a0 = bool1;
    if (i >= 21) {
      bool1 = bool2;
    } else {
      bool1 = false;
    } 
    b0 = bool1;
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setDescendantFocusability(262144);
    float f2 = (getResources().getDisplayMetrics()).density;
    this.c = (int)(64.0F * f2 + 0.5F);
    float f3 = 400.0F * f2;
    f f4 = new f(this, 3);
    this.i = f4;
    f f1 = new f(this, 5);
    this.j = f1;
    b.j.a.a a2 = b.j.a.a.o(this, 1.0F, f4);
    this.g = a2;
    a2.L(1);
    a2.M(f3);
    f4.q(a2);
    b.j.a.a a1 = b.j.a.a.o(this, 1.0F, f1);
    this.h = a1;
    a1.L(2);
    a1.M(f3);
    f1.q(a1);
    setFocusableInTouchMode(true);
    r.T((View)this, 1);
    r.O((View)this, new b(this));
    setMotionEventSplittingEnabled(false);
    if (r.o((View)this))
      if (Build.VERSION.SDK_INT >= 21) {
        setOnApplyWindowInsetsListener(new a(this));
        setSystemUiVisibility(1280);
        TypedArray typedArray = paramContext.obtainStyledAttributes(V);
        try {
          this.H = typedArray.getDrawable(0);
        } finally {
          typedArray.recycle();
        } 
      } else {
        this.H = null;
      }  
    this.b = f2 * 10.0F;
    this.S = new ArrayList<View>();
  }
  
  public static String u(int paramInt) {
    return ((paramInt & 0x3) == 3) ? "LEFT" : (((paramInt & 0x5) == 5) ? "RIGHT" : Integer.toHexString(paramInt));
  }
  
  public static boolean v(View paramView) {
    Drawable drawable = paramView.getBackground();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (drawable != null) {
      bool1 = bool2;
      if (drawable.getOpacity() == -1)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public static boolean y(View paramView) {
    return (r.p(paramView) != 4 && r.p(paramView) != 2);
  }
  
  public boolean A(View paramView) {
    if (B(paramView))
      return ((((e)paramView.getLayoutParams()).d & 0x1) == 1); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean B(View paramView) {
    int i = b.h.n.d.b(((e)paramView.getLayoutParams()).a, r.q(paramView));
    return ((i & 0x3) != 0) ? true : (((i & 0x5) != 0));
  }
  
  public boolean C(View paramView) {
    if (B(paramView))
      return (((e)paramView.getLayoutParams()).b > 0.0F); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public final boolean D(float paramFloat1, float paramFloat2, View paramView) {
    if (this.T == null)
      this.T = new Rect(); 
    paramView.getHitRect(this.T);
    return this.T.contains((int)paramFloat1, (int)paramFloat2);
  }
  
  public final boolean E(Drawable paramDrawable, int paramInt) {
    if (paramDrawable == null || !b.h.g.l.a.g(paramDrawable))
      return false; 
    b.h.g.l.a.l(paramDrawable, paramInt);
    return true;
  }
  
  public void F(View paramView, float paramFloat) {
    float f1 = s(paramView);
    float f2 = paramView.getWidth();
    int i = (int)(f1 * f2);
    i = (int)(f2 * paramFloat) - i;
    if (!c(paramView, 3))
      i = -i; 
    paramView.offsetLeftAndRight(i);
    O(paramView, paramFloat);
  }
  
  public void G(View paramView) {
    H(paramView, true);
  }
  
  public void H(View paramView, boolean paramBoolean) {
    if (B(paramView)) {
      e e = (e)paramView.getLayoutParams();
      if (this.m) {
        e.b = 1.0F;
        e.d = 1;
        P(paramView, true);
      } else if (paramBoolean) {
        e.d |= 0x2;
        if (c(paramView, 3)) {
          this.g.P(paramView, 0, paramView.getTop());
        } else {
          this.h.P(paramView, getWidth() - paramView.getWidth(), paramView.getTop());
        } 
      } else {
        F(paramView, 1.0F);
        Q(e.a, 0, paramView);
        paramView.setVisibility(0);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void I(d paramd) {
    if (paramd == null)
      return; 
    List<d> list = this.E;
    if (list == null)
      return; 
    list.remove(paramd);
  }
  
  public final Drawable J() {
    int i = r.q((View)this);
    if (i == 0) {
      Drawable drawable = this.O;
      if (drawable != null) {
        E(drawable, i);
        return this.O;
      } 
    } else {
      Drawable drawable = this.P;
      if (drawable != null) {
        E(drawable, i);
        return this.P;
      } 
    } 
    return this.Q;
  }
  
  public final Drawable K() {
    int i = r.q((View)this);
    if (i == 0) {
      Drawable drawable = this.P;
      if (drawable != null) {
        E(drawable, i);
        return this.P;
      } 
    } else {
      Drawable drawable = this.O;
      if (drawable != null) {
        E(drawable, i);
        return this.O;
      } 
    } 
    return this.R;
  }
  
  public final void L() {
    if (b0)
      return; 
    this.I = J();
    this.J = K();
  }
  
  public void M(Object paramObject, boolean paramBoolean) {
    this.M = paramObject;
    this.N = paramBoolean;
    if (!paramBoolean && getBackground() == null) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    setWillNotDraw(paramBoolean);
    requestLayout();
  }
  
  public void N(int paramInt1, int paramInt2) {
    int i = b.h.n.d.b(paramInt2, r.q((View)this));
    if (paramInt2 != 3) {
      if (paramInt2 != 5) {
        if (paramInt2 != 8388611) {
          if (paramInt2 == 8388613)
            this.q = paramInt1; 
        } else {
          this.p = paramInt1;
        } 
      } else {
        this.o = paramInt1;
      } 
    } else {
      this.n = paramInt1;
    } 
    if (paramInt1 != 0) {
      b.j.a.a a1;
      if (i == 3) {
        a1 = this.g;
      } else {
        a1 = this.h;
      } 
      a1.b();
    } 
    if (paramInt1 != 1) {
      if (paramInt1 != 2)
        return; 
      View view = l(i);
      if (view != null) {
        G(view);
        return;
      } 
    } else {
      View view = l(i);
      if (view != null)
        d(view); 
    } 
  }
  
  public void O(View paramView, float paramFloat) {
    e e = (e)paramView.getLayoutParams();
    if (paramFloat == e.b)
      return; 
    e.b = paramFloat;
    j(paramView, paramFloat);
  }
  
  public final void P(View paramView, boolean paramBoolean) {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if ((!paramBoolean && !B(view)) || (paramBoolean && view == paramView)) {
        r.T(view, 1);
      } else {
        r.T(view, 4);
      } 
    } 
  }
  
  public void Q(int paramInt1, int paramInt2, View paramView) {
    int i = this.g.A();
    int j = this.h.A();
    byte b = 2;
    if (i == 1 || j == 1) {
      paramInt1 = 1;
    } else {
      paramInt1 = b;
      if (i != 2)
        if (j == 2) {
          paramInt1 = b;
        } else {
          paramInt1 = 0;
        }  
    } 
    if (paramView != null && paramInt2 == 0) {
      float f1 = ((e)paramView.getLayoutParams()).b;
      if (f1 == 0.0F) {
        h(paramView);
      } else if (f1 == 1.0F) {
        i(paramView);
      } 
    } 
    if (paramInt1 != this.k) {
      this.k = paramInt1;
      List<d> list = this.E;
      if (list != null)
        for (paramInt2 = list.size() - 1; paramInt2 >= 0; paramInt2--)
          ((d)this.E.get(paramInt2)).c(paramInt1);  
    } 
  }
  
  public void a(d paramd) {
    if (paramd == null)
      return; 
    if (this.E == null)
      this.E = new ArrayList<d>(); 
    this.E.add(paramd);
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    if (getDescendantFocusability() == 393216)
      return; 
    int k = getChildCount();
    boolean bool = false;
    int i = 0;
    int j = 0;
    while (i < k) {
      View view = getChildAt(i);
      if (B(view)) {
        if (A(view)) {
          view.addFocusables(paramArrayList, paramInt1, paramInt2);
          j = 1;
        } 
      } else {
        this.S.add(view);
      } 
      i++;
    } 
    if (!j) {
      j = this.S.size();
      for (i = bool; i < j; i++) {
        View view = this.S.get(i);
        if (view.getVisibility() == 0)
          view.addFocusables(paramArrayList, paramInt1, paramInt2); 
      } 
    } 
    this.S.clear();
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (m() != null || B(paramView)) {
      r.T(paramView, 4);
    } else {
      r.T(paramView, 1);
    } 
    if (!a0)
      r.O(paramView, this.a); 
  }
  
  public void b() {
    if (!this.C) {
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      int j = getChildCount();
      for (int i = 0; i < j; i++)
        getChildAt(i).dispatchTouchEvent(motionEvent); 
      motionEvent.recycle();
      this.C = true;
    } 
  }
  
  public boolean c(View paramView, int paramInt) {
    return ((r(paramView) & paramInt) == paramInt);
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll() {
    int j = getChildCount();
    float f1 = 0.0F;
    for (int i = 0; i < j; i++)
      f1 = Math.max(f1, ((e)getChildAt(i).getLayoutParams()).b); 
    this.e = f1;
    boolean bool1 = this.g.n(true);
    boolean bool2 = this.h.n(true);
    if (bool1 || bool2)
      r.I((View)this); 
  }
  
  public void d(View paramView) {
    e(paramView, true);
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) == 0 || paramMotionEvent.getAction() == 10 || this.e <= 0.0F)
      return super.dispatchGenericMotionEvent(paramMotionEvent); 
    int i = getChildCount();
    if (i != 0) {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      while (--i >= 0) {
        View view = getChildAt(i);
        if (D(f1, f2, view) && !z(view) && k(paramMotionEvent, view))
          return true; 
        i--;
      } 
    } 
    return false;
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    int n = getHeight();
    boolean bool1 = z(paramView);
    int i = getWidth();
    int m = paramCanvas.save();
    int k = 0;
    int j = i;
    if (bool1) {
      int i1 = getChildCount();
      k = 0;
      for (j = 0; k < i1; j = i3) {
        View view = getChildAt(k);
        int i2 = i;
        int i3 = j;
        if (view != paramView) {
          i2 = i;
          i3 = j;
          if (view.getVisibility() == 0) {
            i2 = i;
            i3 = j;
            if (v(view)) {
              i2 = i;
              i3 = j;
              if (B(view))
                if (view.getHeight() < n) {
                  i2 = i;
                  i3 = j;
                } else if (c(view, 3)) {
                  int i4 = view.getRight();
                  i2 = i;
                  i3 = j;
                  if (i4 > j) {
                    i3 = i4;
                    i2 = i;
                  } 
                } else {
                  int i4 = view.getLeft();
                  i2 = i;
                  i3 = j;
                  if (i4 < i) {
                    i2 = i4;
                    i3 = j;
                  } 
                }  
            } 
          } 
        } 
        k++;
        i = i2;
      } 
      paramCanvas.clipRect(j, 0, i, getHeight());
      k = j;
      j = i;
    } 
    boolean bool2 = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(m);
    float f1 = this.e;
    if (f1 > 0.0F && bool1) {
      i = this.d;
      int i1 = (int)(((0xFF000000 & i) >>> 24) * f1);
      this.f.setColor(i & 0xFFFFFF | i1 << 24);
      paramCanvas.drawRect(k, 0.0F, j, getHeight(), this.f);
      return bool2;
    } 
    if (this.I != null && c(paramView, 3)) {
      i = this.I.getIntrinsicWidth();
      j = paramView.getRight();
      k = this.g.x();
      f1 = Math.max(0.0F, Math.min(j / k, 1.0F));
      this.I.setBounds(j, paramView.getTop(), i + j, paramView.getBottom());
      this.I.setAlpha((int)(f1 * 255.0F));
      this.I.draw(paramCanvas);
      return bool2;
    } 
    if (this.J != null && c(paramView, 5)) {
      i = this.J.getIntrinsicWidth();
      j = paramView.getLeft();
      k = getWidth();
      int i1 = this.h.x();
      f1 = Math.max(0.0F, Math.min((k - j) / i1, 1.0F));
      this.J.setBounds(j - i, paramView.getTop(), j, paramView.getBottom());
      this.J.setAlpha((int)(f1 * 255.0F));
      this.J.draw(paramCanvas);
    } 
    return bool2;
  }
  
  public void e(View paramView, boolean paramBoolean) {
    if (B(paramView)) {
      e e = (e)paramView.getLayoutParams();
      if (this.m) {
        e.b = 0.0F;
        e.d = 0;
      } else if (paramBoolean) {
        e.d |= 0x4;
        if (c(paramView, 3)) {
          this.g.P(paramView, -paramView.getWidth(), paramView.getTop());
        } else {
          this.h.P(paramView, getWidth(), paramView.getTop());
        } 
      } else {
        F(paramView, 0.0F);
        Q(e.a, 0, paramView);
        paramView.setVisibility(4);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void f() {
    g(false);
  }
  
  public void g(boolean paramBoolean) {
    int j;
    int m = getChildCount();
    int i = 0;
    int k = 0;
    while (i < m) {
      int n;
      View view = getChildAt(i);
      e e = (e)view.getLayoutParams();
      int i1 = k;
      if (B(view))
        if (paramBoolean && !e.c) {
          i1 = k;
        } else {
          int i2;
          i1 = view.getWidth();
          if (c(view, 3)) {
            i2 = this.g.P(view, -i1, view.getTop());
          } else {
            i2 = this.h.P(view, getWidth(), view.getTop());
          } 
          n = k | i2;
          e.c = false;
        }  
      i++;
      j = n;
    } 
    this.i.p();
    this.j.p();
    if (j != 0)
      invalidate(); 
  }
  
  public ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new e(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new e(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  public float getDrawerElevation() {
    return b0 ? this.b : 0.0F;
  }
  
  public Drawable getStatusBarBackgroundDrawable() {
    return this.H;
  }
  
  public void h(View paramView) {
    e e = (e)paramView.getLayoutParams();
    if ((e.d & 0x1) == 1) {
      e.d = 0;
      List<d> list = this.E;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--)
          ((d)this.E.get(i)).b(paramView);  
      P(paramView, false);
      if (hasWindowFocus()) {
        paramView = getRootView();
        if (paramView != null)
          paramView.sendAccessibilityEvent(32); 
      } 
    } 
  }
  
  public void i(View paramView) {
    e e = (e)paramView.getLayoutParams();
    if ((e.d & 0x1) == 0) {
      e.d = 1;
      List<d> list = this.E;
      if (list != null)
        for (int i = list.size() - 1; i >= 0; i--)
          ((d)this.E.get(i)).a(paramView);  
      P(paramView, true);
      if (hasWindowFocus())
        sendAccessibilityEvent(32); 
    } 
  }
  
  public void j(View paramView, float paramFloat) {
    List<d> list = this.E;
    if (list != null)
      for (int i = list.size() - 1; i >= 0; i--)
        ((d)this.E.get(i)).d(paramView, paramFloat);  
  }
  
  public final boolean k(MotionEvent paramMotionEvent, View paramView) {
    if (!paramView.getMatrix().isIdentity()) {
      paramMotionEvent = t(paramMotionEvent, paramView);
      boolean bool1 = paramView.dispatchGenericMotionEvent(paramMotionEvent);
      paramMotionEvent.recycle();
      return bool1;
    } 
    float f1 = (getScrollX() - paramView.getLeft());
    float f2 = (getScrollY() - paramView.getTop());
    paramMotionEvent.offsetLocation(f1, f2);
    boolean bool = paramView.dispatchGenericMotionEvent(paramMotionEvent);
    paramMotionEvent.offsetLocation(-f1, -f2);
    return bool;
  }
  
  public View l(int paramInt) {
    int i = b.h.n.d.b(paramInt, r.q((View)this));
    int j = getChildCount();
    for (paramInt = 0; paramInt < j; paramInt++) {
      View view = getChildAt(paramInt);
      if ((r(view) & 0x7) == (i & 0x7))
        return view; 
    } 
    return null;
  }
  
  public View m() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if ((((e)view.getLayoutParams()).d & 0x1) == 1)
        return view; 
    } 
    return null;
  }
  
  public View n() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (B(view) && C(view))
        return view; 
    } 
    return null;
  }
  
  public int o(int paramInt) {
    int i = r.q((View)this);
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 8388611) {
          if (paramInt == 8388613) {
            paramInt = this.q;
            if (paramInt != 3)
              return paramInt; 
            if (i == 0) {
              paramInt = this.o;
            } else {
              paramInt = this.n;
            } 
            if (paramInt != 3)
              return paramInt; 
          } 
        } else {
          paramInt = this.p;
          if (paramInt != 3)
            return paramInt; 
          if (i == 0) {
            paramInt = this.n;
          } else {
            paramInt = this.o;
          } 
          if (paramInt != 3)
            return paramInt; 
        } 
      } else {
        paramInt = this.o;
        if (paramInt != 3)
          return paramInt; 
        if (i == 0) {
          paramInt = this.q;
        } else {
          paramInt = this.p;
        } 
        if (paramInt != 3)
          return paramInt; 
      } 
    } else {
      paramInt = this.n;
      if (paramInt != 3)
        return paramInt; 
      if (i == 0) {
        paramInt = this.p;
      } else {
        paramInt = this.q;
      } 
      if (paramInt != 3)
        return paramInt; 
    } 
    return 0;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.m = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.m = true;
  }
  
  public void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onDraw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: getfield N : Z
    //   9: ifeq -> 75
    //   12: aload_0
    //   13: getfield H : Landroid/graphics/drawable/Drawable;
    //   16: ifnull -> 75
    //   19: getstatic android/os/Build$VERSION.SDK_INT : I
    //   22: bipush #21
    //   24: if_icmplt -> 47
    //   27: aload_0
    //   28: getfield M : Ljava/lang/Object;
    //   31: astore_3
    //   32: aload_3
    //   33: ifnull -> 47
    //   36: aload_3
    //   37: checkcast android/view/WindowInsets
    //   40: invokevirtual getSystemWindowInsetTop : ()I
    //   43: istore_2
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_2
    //   49: iload_2
    //   50: ifle -> 75
    //   53: aload_0
    //   54: getfield H : Landroid/graphics/drawable/Drawable;
    //   57: iconst_0
    //   58: iconst_0
    //   59: aload_0
    //   60: invokevirtual getWidth : ()I
    //   63: iload_2
    //   64: invokevirtual setBounds : (IIII)V
    //   67: aload_0
    //   68: getfield H : Landroid/graphics/drawable/Drawable;
    //   71: aload_1
    //   72: invokevirtual draw : (Landroid/graphics/Canvas;)V
    //   75: return
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore #4
    //   6: aload_0
    //   7: getfield g : Lb/j/a/a;
    //   10: aload_1
    //   11: invokevirtual O : (Landroid/view/MotionEvent;)Z
    //   14: istore #7
    //   16: aload_0
    //   17: getfield h : Lb/j/a/a;
    //   20: aload_1
    //   21: invokevirtual O : (Landroid/view/MotionEvent;)Z
    //   24: istore #8
    //   26: iconst_1
    //   27: istore #6
    //   29: iload #4
    //   31: ifeq -> 99
    //   34: iload #4
    //   36: iconst_1
    //   37: if_icmpeq -> 83
    //   40: iload #4
    //   42: iconst_2
    //   43: if_icmpeq -> 55
    //   46: iload #4
    //   48: iconst_3
    //   49: if_icmpeq -> 83
    //   52: goto -> 93
    //   55: aload_0
    //   56: getfield g : Lb/j/a/a;
    //   59: iconst_3
    //   60: invokevirtual e : (I)Z
    //   63: ifeq -> 93
    //   66: aload_0
    //   67: getfield i : Landroidx/drawerlayout/widget/DrawerLayout$f;
    //   70: invokevirtual p : ()V
    //   73: aload_0
    //   74: getfield j : Landroidx/drawerlayout/widget/DrawerLayout$f;
    //   77: invokevirtual p : ()V
    //   80: goto -> 93
    //   83: aload_0
    //   84: iconst_1
    //   85: invokevirtual g : (Z)V
    //   88: aload_0
    //   89: iconst_0
    //   90: putfield C : Z
    //   93: iconst_0
    //   94: istore #4
    //   96: goto -> 166
    //   99: aload_1
    //   100: invokevirtual getX : ()F
    //   103: fstore_2
    //   104: aload_1
    //   105: invokevirtual getY : ()F
    //   108: fstore_3
    //   109: aload_0
    //   110: fload_2
    //   111: putfield F : F
    //   114: aload_0
    //   115: fload_3
    //   116: putfield G : F
    //   119: aload_0
    //   120: getfield e : F
    //   123: fconst_0
    //   124: fcmpl
    //   125: ifle -> 158
    //   128: aload_0
    //   129: getfield g : Lb/j/a/a;
    //   132: fload_2
    //   133: f2i
    //   134: fload_3
    //   135: f2i
    //   136: invokevirtual u : (II)Landroid/view/View;
    //   139: astore_1
    //   140: aload_1
    //   141: ifnull -> 158
    //   144: aload_0
    //   145: aload_1
    //   146: invokevirtual z : (Landroid/view/View;)Z
    //   149: ifeq -> 158
    //   152: iconst_1
    //   153: istore #4
    //   155: goto -> 161
    //   158: iconst_0
    //   159: istore #4
    //   161: aload_0
    //   162: iconst_0
    //   163: putfield C : Z
    //   166: iload #6
    //   168: istore #5
    //   170: iload #7
    //   172: iload #8
    //   174: ior
    //   175: ifne -> 210
    //   178: iload #6
    //   180: istore #5
    //   182: iload #4
    //   184: ifne -> 210
    //   187: iload #6
    //   189: istore #5
    //   191: aload_0
    //   192: invokevirtual w : ()Z
    //   195: ifne -> 210
    //   198: aload_0
    //   199: getfield C : Z
    //   202: ifeq -> 207
    //   205: iconst_1
    //   206: ireturn
    //   207: iconst_0
    //   208: istore #5
    //   210: iload #5
    //   212: ireturn
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4 && x()) {
      paramKeyEvent.startTracking();
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    View view;
    if (paramInt == 4) {
      view = n();
      if (view != null && p(view) == 0)
        f(); 
      return (view != null);
    } 
    return super.onKeyUp(paramInt, (KeyEvent)view);
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.l = true;
    int i = paramInt3 - paramInt1;
    int j = getChildCount();
    for (paramInt3 = 0; paramInt3 < j; paramInt3++) {
      View view = getChildAt(paramInt3);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        if (z(view)) {
          paramInt1 = e.leftMargin;
          view.layout(paramInt1, e.topMargin, view.getMeasuredWidth() + paramInt1, e.topMargin + view.getMeasuredHeight());
        } else {
          float f1;
          int k;
          boolean bool;
          int m = view.getMeasuredWidth();
          int n = view.getMeasuredHeight();
          if (c(view, 3)) {
            paramInt1 = -m;
            f1 = m;
            k = paramInt1 + (int)(e.b * f1);
            f1 = (m + k) / f1;
          } else {
            f1 = m;
            k = i - (int)(e.b * f1);
            f1 = (i - k) / f1;
          } 
          if (f1 != e.b) {
            bool = true;
          } else {
            bool = false;
          } 
          paramInt1 = e.a & 0x70;
          if (paramInt1 != 16) {
            if (paramInt1 != 80) {
              paramInt1 = e.topMargin;
              view.layout(k, paramInt1, m + k, n + paramInt1);
            } else {
              paramInt1 = paramInt4 - paramInt2;
              view.layout(k, paramInt1 - e.bottomMargin - view.getMeasuredHeight(), m + k, paramInt1 - e.bottomMargin);
            } 
          } else {
            int i2 = paramInt4 - paramInt2;
            int i1 = (i2 - n) / 2;
            paramInt1 = e.topMargin;
            if (i1 >= paramInt1) {
              int i3 = e.bottomMargin;
              paramInt1 = i1;
              if (i1 + n > i2 - i3)
                paramInt1 = i2 - i3 - n; 
            } 
            view.layout(k, paramInt1, m + k, n + paramInt1);
          } 
          if (bool)
            O(view, f1); 
          if (e.b > 0.0F) {
            paramInt1 = 0;
          } else {
            paramInt1 = 4;
          } 
          if (view.getVisibility() != paramInt1)
            view.setVisibility(paramInt1); 
        } 
      } 
    } 
    this.l = false;
    this.m = false;
  }
  
  @SuppressLint({"WrongConstant"})
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore #10
    //   6: iload_2
    //   7: invokestatic getMode : (I)I
    //   10: istore #9
    //   12: iload_1
    //   13: invokestatic getSize : (I)I
    //   16: istore #5
    //   18: iload_2
    //   19: invokestatic getSize : (I)I
    //   22: istore #6
    //   24: iload #10
    //   26: ldc_w 1073741824
    //   29: if_icmpne -> 48
    //   32: iload #5
    //   34: istore #7
    //   36: iload #6
    //   38: istore #8
    //   40: iload #9
    //   42: ldc_w 1073741824
    //   45: if_icmpeq -> 117
    //   48: aload_0
    //   49: invokevirtual isInEditMode : ()Z
    //   52: ifeq -> 820
    //   55: iload #10
    //   57: ldc_w -2147483648
    //   60: if_icmpne -> 66
    //   63: goto -> 76
    //   66: iload #10
    //   68: ifne -> 76
    //   71: sipush #300
    //   74: istore #5
    //   76: iload #9
    //   78: ldc_w -2147483648
    //   81: if_icmpne -> 95
    //   84: iload #5
    //   86: istore #7
    //   88: iload #6
    //   90: istore #8
    //   92: goto -> 117
    //   95: iload #5
    //   97: istore #7
    //   99: iload #6
    //   101: istore #8
    //   103: iload #9
    //   105: ifne -> 117
    //   108: sipush #300
    //   111: istore #8
    //   113: iload #5
    //   115: istore #7
    //   117: aload_0
    //   118: iload #7
    //   120: iload #8
    //   122: invokevirtual setMeasuredDimension : (II)V
    //   125: aload_0
    //   126: getfield M : Ljava/lang/Object;
    //   129: ifnull -> 145
    //   132: aload_0
    //   133: invokestatic o : (Landroid/view/View;)Z
    //   136: ifeq -> 145
    //   139: iconst_1
    //   140: istore #9
    //   142: goto -> 148
    //   145: iconst_0
    //   146: istore #9
    //   148: aload_0
    //   149: invokestatic q : (Landroid/view/View;)I
    //   152: istore #12
    //   154: aload_0
    //   155: invokevirtual getChildCount : ()I
    //   158: istore #13
    //   160: iconst_0
    //   161: istore #10
    //   163: iconst_0
    //   164: istore #6
    //   166: iconst_0
    //   167: istore #5
    //   169: iload #10
    //   171: iload #13
    //   173: if_icmpge -> 819
    //   176: aload_0
    //   177: iload #10
    //   179: invokevirtual getChildAt : (I)Landroid/view/View;
    //   182: astore #17
    //   184: aload #17
    //   186: invokevirtual getVisibility : ()I
    //   189: bipush #8
    //   191: if_icmpne -> 197
    //   194: goto -> 501
    //   197: aload #17
    //   199: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   202: checkcast androidx/drawerlayout/widget/DrawerLayout$e
    //   205: astore #18
    //   207: iload #9
    //   209: ifeq -> 447
    //   212: aload #18
    //   214: getfield a : I
    //   217: iload #12
    //   219: invokestatic b : (II)I
    //   222: istore #11
    //   224: aload #17
    //   226: invokestatic o : (Landroid/view/View;)Z
    //   229: ifeq -> 325
    //   232: getstatic android/os/Build$VERSION.SDK_INT : I
    //   235: bipush #21
    //   237: if_icmplt -> 447
    //   240: aload_0
    //   241: getfield M : Ljava/lang/Object;
    //   244: checkcast android/view/WindowInsets
    //   247: astore #16
    //   249: iload #11
    //   251: iconst_3
    //   252: if_icmpne -> 281
    //   255: aload #16
    //   257: aload #16
    //   259: invokevirtual getSystemWindowInsetLeft : ()I
    //   262: aload #16
    //   264: invokevirtual getSystemWindowInsetTop : ()I
    //   267: iconst_0
    //   268: aload #16
    //   270: invokevirtual getSystemWindowInsetBottom : ()I
    //   273: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   276: astore #15
    //   278: goto -> 314
    //   281: aload #16
    //   283: astore #15
    //   285: iload #11
    //   287: iconst_5
    //   288: if_icmpne -> 314
    //   291: aload #16
    //   293: iconst_0
    //   294: aload #16
    //   296: invokevirtual getSystemWindowInsetTop : ()I
    //   299: aload #16
    //   301: invokevirtual getSystemWindowInsetRight : ()I
    //   304: aload #16
    //   306: invokevirtual getSystemWindowInsetBottom : ()I
    //   309: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   312: astore #15
    //   314: aload #17
    //   316: aload #15
    //   318: invokevirtual dispatchApplyWindowInsets : (Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    //   321: pop
    //   322: goto -> 447
    //   325: getstatic android/os/Build$VERSION.SDK_INT : I
    //   328: bipush #21
    //   330: if_icmplt -> 447
    //   333: aload_0
    //   334: getfield M : Ljava/lang/Object;
    //   337: checkcast android/view/WindowInsets
    //   340: astore #16
    //   342: iload #11
    //   344: iconst_3
    //   345: if_icmpne -> 374
    //   348: aload #16
    //   350: aload #16
    //   352: invokevirtual getSystemWindowInsetLeft : ()I
    //   355: aload #16
    //   357: invokevirtual getSystemWindowInsetTop : ()I
    //   360: iconst_0
    //   361: aload #16
    //   363: invokevirtual getSystemWindowInsetBottom : ()I
    //   366: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   369: astore #15
    //   371: goto -> 407
    //   374: aload #16
    //   376: astore #15
    //   378: iload #11
    //   380: iconst_5
    //   381: if_icmpne -> 407
    //   384: aload #16
    //   386: iconst_0
    //   387: aload #16
    //   389: invokevirtual getSystemWindowInsetTop : ()I
    //   392: aload #16
    //   394: invokevirtual getSystemWindowInsetRight : ()I
    //   397: aload #16
    //   399: invokevirtual getSystemWindowInsetBottom : ()I
    //   402: invokevirtual replaceSystemWindowInsets : (IIII)Landroid/view/WindowInsets;
    //   405: astore #15
    //   407: aload #18
    //   409: aload #15
    //   411: invokevirtual getSystemWindowInsetLeft : ()I
    //   414: putfield leftMargin : I
    //   417: aload #18
    //   419: aload #15
    //   421: invokevirtual getSystemWindowInsetTop : ()I
    //   424: putfield topMargin : I
    //   427: aload #18
    //   429: aload #15
    //   431: invokevirtual getSystemWindowInsetRight : ()I
    //   434: putfield rightMargin : I
    //   437: aload #18
    //   439: aload #15
    //   441: invokevirtual getSystemWindowInsetBottom : ()I
    //   444: putfield bottomMargin : I
    //   447: aload_0
    //   448: aload #17
    //   450: invokevirtual z : (Landroid/view/View;)Z
    //   453: ifeq -> 504
    //   456: aload #17
    //   458: iload #7
    //   460: aload #18
    //   462: getfield leftMargin : I
    //   465: isub
    //   466: aload #18
    //   468: getfield rightMargin : I
    //   471: isub
    //   472: ldc_w 1073741824
    //   475: invokestatic makeMeasureSpec : (II)I
    //   478: iload #8
    //   480: aload #18
    //   482: getfield topMargin : I
    //   485: isub
    //   486: aload #18
    //   488: getfield bottomMargin : I
    //   491: isub
    //   492: ldc_w 1073741824
    //   495: invokestatic makeMeasureSpec : (II)I
    //   498: invokevirtual measure : (II)V
    //   501: goto -> 736
    //   504: aload_0
    //   505: aload #17
    //   507: invokevirtual B : (Landroid/view/View;)Z
    //   510: ifeq -> 745
    //   513: getstatic androidx/drawerlayout/widget/DrawerLayout.b0 : Z
    //   516: ifeq -> 545
    //   519: aload #17
    //   521: invokestatic m : (Landroid/view/View;)F
    //   524: fstore_3
    //   525: aload_0
    //   526: getfield b : F
    //   529: fstore #4
    //   531: fload_3
    //   532: fload #4
    //   534: fcmpl
    //   535: ifeq -> 545
    //   538: aload #17
    //   540: fload #4
    //   542: invokestatic S : (Landroid/view/View;F)V
    //   545: aload_0
    //   546: aload #17
    //   548: invokevirtual r : (Landroid/view/View;)I
    //   551: bipush #7
    //   553: iand
    //   554: istore #14
    //   556: iload #14
    //   558: iconst_3
    //   559: if_icmpne -> 568
    //   562: iconst_1
    //   563: istore #11
    //   565: goto -> 571
    //   568: iconst_0
    //   569: istore #11
    //   571: iload #11
    //   573: ifeq -> 581
    //   576: iload #6
    //   578: ifne -> 594
    //   581: iload #11
    //   583: ifne -> 672
    //   586: iload #5
    //   588: ifne -> 594
    //   591: goto -> 672
    //   594: new java/lang/StringBuilder
    //   597: dup
    //   598: invokespecial <init> : ()V
    //   601: astore #15
    //   603: aload #15
    //   605: ldc_w 'Child drawer has absolute gravity '
    //   608: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   611: pop
    //   612: aload #15
    //   614: iload #14
    //   616: invokestatic u : (I)Ljava/lang/String;
    //   619: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   622: pop
    //   623: aload #15
    //   625: ldc_w ' but this '
    //   628: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   631: pop
    //   632: aload #15
    //   634: ldc_w 'DrawerLayout'
    //   637: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   640: pop
    //   641: aload #15
    //   643: ldc_w ' already has a '
    //   646: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   649: pop
    //   650: aload #15
    //   652: ldc_w 'drawer view along that edge'
    //   655: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   658: pop
    //   659: new java/lang/IllegalStateException
    //   662: dup
    //   663: aload #15
    //   665: invokevirtual toString : ()Ljava/lang/String;
    //   668: invokespecial <init> : (Ljava/lang/String;)V
    //   671: athrow
    //   672: iload #11
    //   674: ifeq -> 683
    //   677: iconst_1
    //   678: istore #6
    //   680: goto -> 686
    //   683: iconst_1
    //   684: istore #5
    //   686: aload #17
    //   688: iload_1
    //   689: aload_0
    //   690: getfield c : I
    //   693: aload #18
    //   695: getfield leftMargin : I
    //   698: iadd
    //   699: aload #18
    //   701: getfield rightMargin : I
    //   704: iadd
    //   705: aload #18
    //   707: getfield width : I
    //   710: invokestatic getChildMeasureSpec : (III)I
    //   713: iload_2
    //   714: aload #18
    //   716: getfield topMargin : I
    //   719: aload #18
    //   721: getfield bottomMargin : I
    //   724: iadd
    //   725: aload #18
    //   727: getfield height : I
    //   730: invokestatic getChildMeasureSpec : (III)I
    //   733: invokevirtual measure : (II)V
    //   736: iload #10
    //   738: iconst_1
    //   739: iadd
    //   740: istore #10
    //   742: goto -> 169
    //   745: new java/lang/StringBuilder
    //   748: dup
    //   749: invokespecial <init> : ()V
    //   752: astore #15
    //   754: aload #15
    //   756: ldc_w 'Child '
    //   759: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   762: pop
    //   763: aload #15
    //   765: aload #17
    //   767: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   770: pop
    //   771: aload #15
    //   773: ldc_w ' at index '
    //   776: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   779: pop
    //   780: aload #15
    //   782: iload #10
    //   784: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   787: pop
    //   788: aload #15
    //   790: ldc_w ' does not have a valid layout_gravity - must be Gravity.LEFT, '
    //   793: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   796: pop
    //   797: aload #15
    //   799: ldc_w 'Gravity.RIGHT or Gravity.NO_GRAVITY'
    //   802: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   805: pop
    //   806: new java/lang/IllegalStateException
    //   809: dup
    //   810: aload #15
    //   812: invokevirtual toString : ()Ljava/lang/String;
    //   815: invokespecial <init> : (Ljava/lang/String;)V
    //   818: athrow
    //   819: return
    //   820: new java/lang/IllegalArgumentException
    //   823: dup
    //   824: ldc_w 'DrawerLayout must be measured with MeasureSpec.EXACTLY.'
    //   827: invokespecial <init> : (Ljava/lang/String;)V
    //   830: astore #15
    //   832: goto -> 838
    //   835: aload #15
    //   837: athrow
    //   838: goto -> 835
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.c());
    int i = savedState.c;
    if (i != 0) {
      View view = l(i);
      if (view != null)
        G(view); 
    } 
    i = savedState.d;
    if (i != 3)
      N(i, 3); 
    i = savedState.e;
    if (i != 3)
      N(i, 5); 
    i = savedState.f;
    if (i != 3)
      N(i, 8388611); 
    i = savedState.g;
    if (i != 3)
      N(i, 8388613); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    L();
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool1;
      e e = (e)getChildAt(i).getLayoutParams();
      int k = e.d;
      boolean bool2 = true;
      if (k == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (k != 2)
        bool2 = false; 
      if (bool1 || bool2) {
        savedState.c = e.a;
        break;
      } 
    } 
    savedState.d = this.n;
    savedState.e = this.o;
    savedState.f = this.p;
    savedState.g = this.q;
    return (Parcelable)savedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    View view;
    this.g.F(paramMotionEvent);
    this.h.F(paramMotionEvent);
    int i = paramMotionEvent.getAction() & 0xFF;
    boolean bool = false;
    if (i != 0) {
      if (i != 1) {
        if (i != 3)
          return true; 
        g(true);
        this.C = false;
        return true;
      } 
      float f2 = paramMotionEvent.getX();
      float f1 = paramMotionEvent.getY();
      view = this.g.u((int)f2, (int)f1);
      if (view != null && z(view)) {
        f2 -= this.F;
        f1 -= this.G;
        i = this.g.z();
        if (f2 * f2 + f1 * f1 < (i * i)) {
          view = m();
          if (view == null || p(view) == 2) {
            bool = true;
            g(bool);
            return true;
          } 
          g(bool);
          return true;
        } 
      } 
    } else {
      float f1 = view.getX();
      float f2 = view.getY();
      this.F = f1;
      this.G = f2;
      this.C = false;
      return true;
    } 
    bool = true;
    g(bool);
    return true;
  }
  
  public int p(View paramView) {
    if (B(paramView))
      return o(((e)paramView.getLayoutParams()).a); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public CharSequence q(int paramInt) {
    paramInt = b.h.n.d.b(paramInt, r.q((View)this));
    return (paramInt == 3) ? this.K : ((paramInt == 5) ? this.L : null);
  }
  
  public int r(View paramView) {
    return b.h.n.d.b(((e)paramView.getLayoutParams()).a, r.q((View)this));
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean)
      g(true); 
  }
  
  public void requestLayout() {
    if (!this.l)
      super.requestLayout(); 
  }
  
  public float s(View paramView) {
    return ((e)paramView.getLayoutParams()).b;
  }
  
  public void setDrawerElevation(float paramFloat) {
    this.b = paramFloat;
    for (int i = 0; i < getChildCount(); i++) {
      View view = getChildAt(i);
      if (B(view))
        r.S(view, this.b); 
    } 
  }
  
  @Deprecated
  public void setDrawerListener(d paramd) {
    d d1 = this.D;
    if (d1 != null)
      I(d1); 
    if (paramd != null)
      a(paramd); 
    this.D = paramd;
  }
  
  public void setDrawerLockMode(int paramInt) {
    N(paramInt, 3);
    N(paramInt, 5);
  }
  
  public void setScrimColor(int paramInt) {
    this.d = paramInt;
    invalidate();
  }
  
  public void setStatusBarBackground(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = b.h.f.a.f(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    this.H = drawable;
    invalidate();
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    this.H = paramDrawable;
    invalidate();
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    this.H = (Drawable)new ColorDrawable(paramInt);
    invalidate();
  }
  
  public final MotionEvent t(MotionEvent paramMotionEvent, View paramView) {
    float f1 = (getScrollX() - paramView.getLeft());
    float f2 = (getScrollY() - paramView.getTop());
    paramMotionEvent = MotionEvent.obtain(paramMotionEvent);
    paramMotionEvent.offsetLocation(f1, f2);
    Matrix matrix = paramView.getMatrix();
    if (!matrix.isIdentity()) {
      if (this.U == null)
        this.U = new Matrix(); 
      matrix.invert(this.U);
      paramMotionEvent.transform(this.U);
    } 
    return paramMotionEvent;
  }
  
  public final boolean w() {
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      if (((e)getChildAt(i).getLayoutParams()).c)
        return true; 
    } 
    return false;
  }
  
  public final boolean x() {
    return (n() != null);
  }
  
  public boolean z(View paramView) {
    return (((e)paramView.getLayoutParams()).a == 0);
  }
  
  static {
    boolean bool1;
    boolean bool2 = true;
  }
  
  public static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    public int c = 0;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.c = param1Parcel.readInt();
      this.d = param1Parcel.readInt();
      this.e = param1Parcel.readInt();
      this.f = param1Parcel.readInt();
      this.g = param1Parcel.readInt();
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.c);
      param1Parcel.writeInt(this.d);
      param1Parcel.writeInt(this.e);
      param1Parcel.writeInt(this.f);
      param1Parcel.writeInt(this.g);
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator<SavedState> {
      public DrawerLayout.SavedState a(Parcel param2Parcel) {
        return new DrawerLayout.SavedState(param2Parcel, null);
      }
      
      public DrawerLayout.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new DrawerLayout.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public DrawerLayout.SavedState[] c(int param2Int) {
        return new DrawerLayout.SavedState[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<SavedState> {
    public DrawerLayout.SavedState a(Parcel param1Parcel) {
      return new DrawerLayout.SavedState(param1Parcel, null);
    }
    
    public DrawerLayout.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new DrawerLayout.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public DrawerLayout.SavedState[] c(int param1Int) {
      return new DrawerLayout.SavedState[param1Int];
    }
  }
  
  public class a implements View.OnApplyWindowInsetsListener {
    public a(DrawerLayout this$0) {}
    
    public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
      boolean bool;
      DrawerLayout drawerLayout = (DrawerLayout)param1View;
      if (param1WindowInsets.getSystemWindowInsetTop() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      drawerLayout.M(param1WindowInsets, bool);
      return param1WindowInsets.consumeSystemWindowInsets();
    }
  }
  
  public class b extends b.h.n.a {
    public final Rect d = new Rect();
    
    public b(DrawerLayout this$0) {}
    
    public boolean a(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      List<CharSequence> list;
      CharSequence charSequence;
      if (param1AccessibilityEvent.getEventType() == 32) {
        list = param1AccessibilityEvent.getText();
        View view = this.e.n();
        if (view != null) {
          int i = this.e.r(view);
          charSequence = this.e.q(i);
          if (charSequence != null)
            list.add(charSequence); 
        } 
        return true;
      } 
      return super.a((View)list, (AccessibilityEvent)charSequence);
    }
    
    public void f(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.f(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(DrawerLayout.class.getName());
    }
    
    public void g(View param1View, b.h.n.a0.b param1b) {
      if (DrawerLayout.a0) {
        super.g(param1View, param1b);
      } else {
        b.h.n.a0.b b1 = b.h.n.a0.b.K(param1b);
        super.g(param1View, b1);
        param1b.j0(param1View);
        ViewParent viewParent = r.s(param1View);
        if (viewParent instanceof View)
          param1b.f0((View)viewParent); 
        o(param1b, b1);
        b1.M();
        n(param1b, (ViewGroup)param1View);
      } 
      param1b.U(DrawerLayout.class.getName());
      param1b.Y(false);
      param1b.Z(false);
      param1b.N(b.h.n.a0.b.a.d);
      param1b.N(b.h.n.a0.b.a.e);
    }
    
    public boolean i(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return (DrawerLayout.a0 || DrawerLayout.y(param1View)) ? super.i(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
    
    public final void n(b.h.n.a0.b param1b, ViewGroup param1ViewGroup) {
      int j = param1ViewGroup.getChildCount();
      for (int i = 0; i < j; i++) {
        View view = param1ViewGroup.getChildAt(i);
        if (DrawerLayout.y(view))
          param1b.c(view); 
      } 
    }
    
    public final void o(b.h.n.a0.b param1b1, b.h.n.a0.b param1b2) {
      Rect rect = this.d;
      param1b2.k(rect);
      param1b1.R(rect);
      param1b2.l(rect);
      param1b1.S(rect);
      param1b1.l0(param1b2.J());
      param1b1.d0(param1b2.s());
      param1b1.U(param1b2.m());
      param1b1.W(param1b2.o());
      param1b1.X(param1b2.C());
      param1b1.V(param1b2.B());
      param1b1.Y(param1b2.D());
      param1b1.Z(param1b2.E());
      param1b1.P(param1b2.y());
      param1b1.i0(param1b2.I());
      param1b1.b0(param1b2.F());
      param1b1.a(param1b2.j());
    }
  }
  
  public static final class c extends b.h.n.a {
    public void g(View param1View, b.h.n.a0.b param1b) {
      super.g(param1View, param1b);
      if (!DrawerLayout.y(param1View))
        param1b.f0(null); 
    }
  }
  
  public static interface d {
    void a(View param1View);
    
    void b(View param1View);
    
    void c(int param1Int);
    
    void d(View param1View, float param1Float);
  }
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public int a = 0;
    
    public float b;
    
    public boolean c;
    
    public int d;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, DrawerLayout.W);
      this.a = typedArray.getInt(0, 0);
      typedArray.recycle();
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public e(e param1e) {
      super(param1e);
      this.a = param1e.a;
    }
  }
  
  public class f extends b.j.a.a.c {
    public final int a;
    
    public b.j.a.a b;
    
    public final Runnable c = new a(this);
    
    public f(DrawerLayout this$0, int param1Int) {
      this.a = param1Int;
    }
    
    public int a(View param1View, int param1Int1, int param1Int2) {
      if (this.d.c(param1View, 3))
        return Math.max(-param1View.getWidth(), Math.min(param1Int1, 0)); 
      param1Int2 = this.d.getWidth();
      return Math.max(param1Int2 - param1View.getWidth(), Math.min(param1Int1, param1Int2));
    }
    
    public int b(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public int d(View param1View) {
      return this.d.B(param1View) ? param1View.getWidth() : 0;
    }
    
    public void f(int param1Int1, int param1Int2) {
      View view;
      if ((param1Int1 & 0x1) == 1) {
        view = this.d.l(3);
      } else {
        view = this.d.l(5);
      } 
      if (view != null && this.d.p(view) == 0)
        this.b.c(view, param1Int2); 
    }
    
    public boolean g(int param1Int) {
      return false;
    }
    
    public void h(int param1Int1, int param1Int2) {
      this.d.postDelayed(this.c, 160L);
    }
    
    public void i(View param1View, int param1Int) {
      ((DrawerLayout.e)param1View.getLayoutParams()).c = false;
      n();
    }
    
    public void j(int param1Int) {
      this.d.Q(this.a, param1Int, this.b.w());
    }
    
    public void k(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      float f1;
      param1Int2 = param1View.getWidth();
      if (this.d.c(param1View, 3)) {
        f1 = (param1Int1 + param1Int2);
      } else {
        f1 = (this.d.getWidth() - param1Int1);
      } 
      f1 /= param1Int2;
      this.d.O(param1View, f1);
      if (f1 == 0.0F) {
        param1Int1 = 4;
      } else {
        param1Int1 = 0;
      } 
      param1View.setVisibility(param1Int1);
      this.d.invalidate();
    }
    
    public void l(View param1View, float param1Float1, float param1Float2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   4: aload_1
      //   5: invokevirtual s : (Landroid/view/View;)F
      //   8: fstore_3
      //   9: aload_1
      //   10: invokevirtual getWidth : ()I
      //   13: istore #6
      //   15: aload_0
      //   16: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   19: aload_1
      //   20: iconst_3
      //   21: invokevirtual c : (Landroid/view/View;I)Z
      //   24: ifeq -> 63
      //   27: fload_2
      //   28: fconst_0
      //   29: fcmpl
      //   30: ifgt -> 57
      //   33: fload_2
      //   34: fconst_0
      //   35: fcmpl
      //   36: ifne -> 49
      //   39: fload_3
      //   40: ldc 0.5
      //   42: fcmpl
      //   43: ifle -> 49
      //   46: goto -> 57
      //   49: iload #6
      //   51: ineg
      //   52: istore #4
      //   54: goto -> 106
      //   57: iconst_0
      //   58: istore #4
      //   60: goto -> 106
      //   63: aload_0
      //   64: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   67: invokevirtual getWidth : ()I
      //   70: istore #5
      //   72: fload_2
      //   73: fconst_0
      //   74: fcmpg
      //   75: iflt -> 99
      //   78: iload #5
      //   80: istore #4
      //   82: fload_2
      //   83: fconst_0
      //   84: fcmpl
      //   85: ifne -> 106
      //   88: iload #5
      //   90: istore #4
      //   92: fload_3
      //   93: ldc 0.5
      //   95: fcmpl
      //   96: ifle -> 106
      //   99: iload #5
      //   101: iload #6
      //   103: isub
      //   104: istore #4
      //   106: aload_0
      //   107: getfield b : Lb/j/a/a;
      //   110: iload #4
      //   112: aload_1
      //   113: invokevirtual getTop : ()I
      //   116: invokevirtual N : (II)Z
      //   119: pop
      //   120: aload_0
      //   121: getfield d : Landroidx/drawerlayout/widget/DrawerLayout;
      //   124: invokevirtual invalidate : ()V
      //   127: return
    }
    
    public boolean m(View param1View, int param1Int) {
      return (this.d.B(param1View) && this.d.c(param1View, this.a) && this.d.p(param1View) == 0);
    }
    
    public final void n() {
      int i = this.a;
      byte b = 3;
      if (i == 3)
        b = 5; 
      View view = this.d.l(b);
      if (view != null)
        this.d.d(view); 
    }
    
    public void o() {
      View view;
      int k = this.b.x();
      int i = this.a;
      int j = 0;
      if (i == 3) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i != 0) {
        view = this.d.l(3);
        if (view != null)
          j = -view.getWidth(); 
        j += k;
      } else {
        view = this.d.l(5);
        j = this.d.getWidth() - k;
      } 
      if (view != null && ((i != 0 && view.getLeft() < j) || (i == 0 && view.getLeft() > j)) && this.d.p(view) == 0) {
        DrawerLayout.e e = (DrawerLayout.e)view.getLayoutParams();
        this.b.P(view, j, view.getTop());
        e.c = true;
        this.d.invalidate();
        n();
        this.d.b();
      } 
    }
    
    public void p() {
      this.d.removeCallbacks(this.c);
    }
    
    public void q(b.j.a.a param1a) {
      this.b = param1a;
    }
    
    public class a implements Runnable {
      public a(DrawerLayout.f this$0) {}
      
      public void run() {
        this.a.o();
      }
    }
  }
  
  public class a implements Runnable {
    public a(DrawerLayout this$0) {}
    
    public void run() {
      this.a.o();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\drawerlayout\widget\DrawerLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */