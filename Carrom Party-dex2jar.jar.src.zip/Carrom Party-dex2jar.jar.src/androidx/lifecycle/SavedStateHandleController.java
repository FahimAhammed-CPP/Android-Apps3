package androidx.lifecycle;

import androidx.savedstate.SavedStateRegistry;
import b.n.d;
import b.n.e;
import b.n.f;
import b.n.g;
import b.n.q;
import b.n.s;
import b.n.u;
import b.n.v;
import b.s.c;
import java.util.Iterator;

public final class SavedStateHandleController implements e {
  public boolean a;
  
  public final q b;
  
  public static void h(s params, SavedStateRegistry paramSavedStateRegistry, d paramd) {
    SavedStateHandleController savedStateHandleController = (SavedStateHandleController)params.c("androidx.lifecycle.savedstate.vm.tag");
    if (savedStateHandleController != null) {
      if (savedStateHandleController.j())
        return; 
      savedStateHandleController.i(paramSavedStateRegistry, paramd);
      throw null;
    } 
  }
  
  public void c(g paramg, d.b paramb) {
    if (paramb == d.b.ON_DESTROY) {
      this.a = false;
      paramg.a().c((f)this);
    } 
  }
  
  public void i(SavedStateRegistry paramSavedStateRegistry, d paramd) {
    if (this.a)
      throw new IllegalStateException("Already attached to lifecycleOwner"); 
    this.a = true;
    paramd.a((f)this);
    this.b.a();
    throw null;
  }
  
  public boolean j() {
    return this.a;
  }
  
  public static final class a implements SavedStateRegistry.a {
    public void a(c param1c) {
      if (param1c instanceof v) {
        u u = ((v)param1c).h();
        SavedStateRegistry savedStateRegistry = param1c.j();
        Iterator<String> iterator = u.c().iterator();
        while (iterator.hasNext())
          SavedStateHandleController.h(u.b(iterator.next()), savedStateRegistry, param1c.a()); 
        if (!u.c().isEmpty())
          savedStateRegistry.e(a.class); 
        return;
      } 
      IllegalStateException illegalStateException = new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
      throw illegalStateException;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */