package androidx.lifecycle;

import androidx.savedstate.SavedStateRegistry;
import b.n.d;
import b.n.e;
import b.n.f;
import b.n.g;

public class SavedStateHandleController$1 implements e {
  public void c(g paramg, d.b paramb) {
    if (paramb == d.b.ON_START) {
      this.a.c((f)this);
      this.b.e(SavedStateHandleController.a.class);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\lifecycle\SavedStateHandleController$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */