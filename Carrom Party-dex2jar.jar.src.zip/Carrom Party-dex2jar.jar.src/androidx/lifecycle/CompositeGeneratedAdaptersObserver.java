package androidx.lifecycle;

import b.n.c;
import b.n.d;
import b.n.e;
import b.n.g;
import b.n.l;

public class CompositeGeneratedAdaptersObserver implements e {
  public final c[] a;
  
  public CompositeGeneratedAdaptersObserver(c[] paramArrayOfc) {
    this.a = paramArrayOfc;
  }
  
  public void c(g paramg, d.b paramb) {
    l l = new l();
    c[] arrayOfC = this.a;
    int j = arrayOfC.length;
    boolean bool = false;
    int i;
    for (i = 0; i < j; i++)
      arrayOfC[i].a(paramg, paramb, false, l); 
    arrayOfC = this.a;
    j = arrayOfC.length;
    for (i = bool; i < j; i++)
      arrayOfC[i].a(paramg, paramb, true, l); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */