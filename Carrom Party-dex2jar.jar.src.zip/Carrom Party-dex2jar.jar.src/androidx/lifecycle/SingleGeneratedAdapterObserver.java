package androidx.lifecycle;

import b.n.c;
import b.n.d;
import b.n.e;
import b.n.g;

public class SingleGeneratedAdapterObserver implements e {
  public final c a;
  
  public SingleGeneratedAdapterObserver(c paramc) {
    this.a = paramc;
  }
  
  public void c(g paramg, d.b paramb) {
    this.a.a(paramg, paramb, false, null);
    this.a.a(paramg, paramb, true, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\lifecycle\SingleGeneratedAdapterObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */