package androidx.lifecycle;

import b.n.a;
import b.n.d;
import b.n.e;
import b.n.g;

public class ReflectiveGenericLifecycleObserver implements e {
  public final Object a;
  
  public final a.a b;
  
  public ReflectiveGenericLifecycleObserver(Object paramObject) {
    this.a = paramObject;
    this.b = a.c.c(paramObject.getClass());
  }
  
  public void c(g paramg, d.b paramb) {
    this.b.a(paramg, paramb, this.a);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\lifecycle\ReflectiveGenericLifecycleObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */