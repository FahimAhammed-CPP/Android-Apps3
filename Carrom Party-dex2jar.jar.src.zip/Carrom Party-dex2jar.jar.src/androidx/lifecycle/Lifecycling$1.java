package androidx.lifecycle;

import b.n.d;
import b.n.e;
import b.n.g;

public class Lifecycling$1 implements e {
  public void c(g paramg, d.b paramb) {
    this.a.c(paramg, paramb);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\lifecycle\Lifecycling$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */