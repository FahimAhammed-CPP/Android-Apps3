package androidx.lifecycle;

import b.n.d;
import b.n.e;
import b.n.f;
import b.n.g;
import b.n.n;
import java.util.Map;

public abstract class LiveData<T> {
  public static final Object k = new Object();
  
  public final Object a = new Object();
  
  public b.c.a.b.b<n<? super T>, c> b = new b.c.a.b.b();
  
  public int c = 0;
  
  public boolean d;
  
  public volatile Object e;
  
  public volatile Object f;
  
  public int g;
  
  public boolean h;
  
  public boolean i;
  
  public final Runnable j;
  
  public LiveData() {
    Object object = k;
    this.f = object;
    this.j = new a(this);
    this.e = object;
    this.g = -1;
  }
  
  public static void b(String paramString) {
    if (b.c.a.a.a.e().b())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void c(int paramInt) {
    int i = this.c;
    this.c = paramInt + i;
    if (this.d)
      return; 
    this.d = true;
    while (true) {
      int j;
      try {
        j = this.c;
      } finally {
        this.d = false;
      } 
      if (i > 0 && j == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (paramInt != 0) {
        j();
      } else if (i != 0) {
        k();
      } 
      i = j;
    } 
  }
  
  public final void d(c paramc) {
    if (!paramc.b)
      return; 
    if (!paramc.k()) {
      paramc.h(false);
      return;
    } 
    int i = paramc.c;
    int j = this.g;
    if (i >= j)
      return; 
    paramc.c = j;
    paramc.a.a(this.e);
  }
  
  public void e(c paramc) {
    if (this.h) {
      this.i = true;
      return;
    } 
    this.h = true;
    while (true) {
      c c1;
      this.i = false;
      if (paramc != null) {
        d(paramc);
        c1 = null;
      } else {
        b.c.a.b.b.d<Map.Entry> d = this.b.c();
        while (true) {
          c1 = paramc;
          if (d.hasNext()) {
            d((c)((Map.Entry)d.next()).getValue());
            if (this.i) {
              c1 = paramc;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramc = c1;
      if (!this.i) {
        this.h = false;
        return;
      } 
    } 
  }
  
  public T f() {
    Object object = this.e;
    return (T)((object != k) ? object : null);
  }
  
  public boolean g() {
    return (this.c > 0);
  }
  
  public void h(g paramg, n<? super T> paramn) {
    b("observe");
    if (paramg.a().b() == d.c.a)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, paramg, paramn);
    c c = (c)this.b.g(paramn, lifecycleBoundObserver);
    if (c == null || c.j(paramg)) {
      if (c != null)
        return; 
      paramg.a().a((f)lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void i(n<? super T> paramn) {
    b("observeForever");
    b b1 = new b(this, paramn);
    c c = (c)this.b.g(paramn, b1);
    if (!(c instanceof LifecycleBoundObserver)) {
      if (c != null)
        return; 
      b1.h(true);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void j() {}
  
  public void k() {}
  
  public void l(T paramT) {
    synchronized (this.a) {
      boolean bool;
      if (this.f == k) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = paramT;
      if (!bool)
        return; 
      b.c.a.a.a.e().c(this.j);
      return;
    } 
  }
  
  public void m(n<? super T> paramn) {
    b("removeObserver");
    c c = (c)this.b.i(paramn);
    if (c == null)
      return; 
    c.i();
    c.h(false);
  }
  
  public void n(T paramT) {
    b("setValue");
    this.g++;
    this.e = paramT;
    e(null);
  }
  
  public class LifecycleBoundObserver extends c implements e {
    public final g e;
    
    public LifecycleBoundObserver(LiveData this$0, g param1g, n<? super T> param1n) {
      super(this$0, param1n);
      this.e = param1g;
    }
    
    public void c(g param1g, d.b param1b) {
      d.c c1 = this.e.a().b();
      if (c1 == d.c.a) {
        this.f.m(this.a);
        return;
      } 
      param1b = null;
      while (param1b != c1) {
        h(k());
        d.c c3 = this.e.a().b();
        d.c c2 = c1;
        c1 = c3;
      } 
    }
    
    public void i() {
      this.e.a().c((f)this);
    }
    
    public boolean j(g param1g) {
      return (this.e == param1g);
    }
    
    public boolean k() {
      return this.e.a().b().a(d.c.d);
    }
  }
  
  public class a implements Runnable {
    public a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.a.a) {
        Object object = this.a.f;
        this.a.f = LiveData.k;
        this.a.n(object);
        return;
      } 
    }
  }
  
  public class b extends c {
    public b(LiveData this$0, n<? super T> param1n) {
      super(this$0, param1n);
    }
    
    public boolean k() {
      return true;
    }
  }
  
  public abstract class c {
    public final n<? super T> a;
    
    public boolean b;
    
    public int c = -1;
    
    public c(LiveData this$0, n<? super T> param1n) {
      this.a = param1n;
    }
    
    public void h(boolean param1Boolean) {
      byte b;
      if (param1Boolean == this.b)
        return; 
      this.b = param1Boolean;
      LiveData liveData = this.d;
      if (param1Boolean) {
        b = 1;
      } else {
        b = -1;
      } 
      liveData.c(b);
      if (this.b)
        this.d.e(this); 
    }
    
    public void i() {}
    
    public boolean j(g param1g) {
      return false;
    }
    
    public abstract boolean k();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */