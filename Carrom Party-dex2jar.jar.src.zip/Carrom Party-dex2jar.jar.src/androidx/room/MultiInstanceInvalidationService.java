package androidx.room;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;
import b.r.c;
import b.r.d;
import java.util.HashMap;

public class MultiInstanceInvalidationService extends Service {
  public int a = 0;
  
  public final HashMap<Integer, String> b = new HashMap<Integer, String>();
  
  public final RemoteCallbackList<c> c = new a(this);
  
  public final d.a d = new b(this);
  
  public IBinder onBind(Intent paramIntent) {
    return (IBinder)this.d;
  }
  
  public class a extends RemoteCallbackList<c> {
    public a(MultiInstanceInvalidationService this$0) {}
    
    public void a(c param1c, Object param1Object) {
      this.a.b.remove(Integer.valueOf(((Integer)param1Object).intValue()));
    }
  }
  
  public class b extends d.a {
    public b(MultiInstanceInvalidationService this$0) {}
    
    public void B6(c param1c, int param1Int) {
      synchronized (this.a.c) {
        this.a.c.unregister((IInterface)param1c);
        this.a.b.remove(Integer.valueOf(param1Int));
        return;
      } 
    }
    
    public void e6(int param1Int, String[] param1ArrayOfString) {
      synchronized (this.a.c) {
        String str = this.a.b.get(Integer.valueOf(param1Int));
        if (str == null) {
          Log.w("ROOM", "Remote invalidation client ID not registered");
          return;
        } 
        int j = this.a.c.beginBroadcast();
        int i = 0;
        while (i < j) {
          try {
            int k = ((Integer)this.a.c.getBroadcastCookie(i)).intValue();
            String str1 = this.a.b.get(Integer.valueOf(k));
            if (param1Int != k) {
              boolean bool = str.equals(str1);
              if (bool)
                try {
                  ((c)this.a.c.getBroadcastItem(i)).A1(param1ArrayOfString);
                } catch (RemoteException remoteException) {
                  Log.w("ROOM", "Error invoking a remote callback", (Throwable)remoteException);
                }  
            } 
          } finally {
            this.a.c.finishBroadcast();
          } 
        } 
        this.a.c.finishBroadcast();
        return;
      } 
    }
    
    public int m2(c param1c, String param1String) {
      if (param1String == null)
        return 0; 
      synchronized (this.a.c) {
        MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.a;
        int i = multiInstanceInvalidationService2.a + 1;
        multiInstanceInvalidationService2.a = i;
        if (multiInstanceInvalidationService2.c.register((IInterface)param1c, Integer.valueOf(i))) {
          this.a.b.put(Integer.valueOf(i), param1String);
          return i;
        } 
        MultiInstanceInvalidationService multiInstanceInvalidationService1 = this.a;
        multiInstanceInvalidationService1.a--;
        return 0;
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\room\MultiInstanceInvalidationService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */