package androidx.fragment.app;

import android.os.Bundle;
import b.k.d.o;
import b.n.d;
import b.n.e;
import b.n.f;
import b.n.g;

public class FragmentManager$6 implements e {
  public void c(g paramg, d.b paramb) {
    if (paramb == d.b.ON_START) {
      Bundle bundle = (Bundle)FragmentManager.a(this.d).get(this.a);
      if (bundle != null) {
        this.b.a(this.a, bundle);
        this.d.r(this.a);
      } 
    } 
    if (paramb == d.b.ON_DESTROY) {
      this.c.c((f)this);
      FragmentManager.b(this.d).remove(this.a);
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\fragment\app\FragmentManager$6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */