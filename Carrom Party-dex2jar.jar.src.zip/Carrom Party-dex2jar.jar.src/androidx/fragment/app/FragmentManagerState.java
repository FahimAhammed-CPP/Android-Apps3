package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
public final class FragmentManagerState implements Parcelable {
  public static final Parcelable.Creator<FragmentManagerState> CREATOR = new a();
  
  public ArrayList<FragmentState> a;
  
  public ArrayList<String> b;
  
  public BackStackState[] c;
  
  public int d;
  
  public String e = null;
  
  public ArrayList<String> f = new ArrayList<String>();
  
  public ArrayList<Bundle> g = new ArrayList<Bundle>();
  
  public ArrayList<FragmentManager.LaunchedFragmentInfo> h;
  
  public FragmentManagerState() {}
  
  public FragmentManagerState(Parcel paramParcel) {
    this.a = paramParcel.createTypedArrayList(FragmentState.CREATOR);
    this.b = paramParcel.createStringArrayList();
    this.c = (BackStackState[])paramParcel.createTypedArray(BackStackState.CREATOR);
    this.d = paramParcel.readInt();
    this.e = paramParcel.readString();
    this.f = paramParcel.createStringArrayList();
    this.g = paramParcel.createTypedArrayList(Bundle.CREATOR);
    this.h = paramParcel.createTypedArrayList(FragmentManager.LaunchedFragmentInfo.CREATOR);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeTypedList(this.a);
    paramParcel.writeStringList(this.b);
    paramParcel.writeTypedArray((Parcelable[])this.c, paramInt);
    paramParcel.writeInt(this.d);
    paramParcel.writeString(this.e);
    paramParcel.writeStringList(this.f);
    paramParcel.writeTypedList(this.g);
    paramParcel.writeTypedList(this.h);
  }
  
  public class a implements Parcelable.Creator<FragmentManagerState> {
    public FragmentManagerState a(Parcel param1Parcel) {
      return new FragmentManagerState(param1Parcel);
    }
    
    public FragmentManagerState[] b(int param1Int) {
      return new FragmentManagerState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\fragment\app\FragmentManagerState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */