package androidx.fragment.app;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.lifecycle.LiveData;
import androidx.savedstate.SavedStateRegistry;
import b.h.e.o;
import b.k.d.h;
import b.k.d.i;
import b.k.d.l;
import b.k.d.v;
import b.k.d.x;
import b.k.d.z;
import b.n.g;
import b.n.h;
import b.n.m;
import b.n.u;
import b.n.v;
import b.n.w;
import b.n.x;
import b.s.c;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, g, v, c {
  public static final Object i0 = new Object();
  
  public int C;
  
  public FragmentManager D;
  
  public i<?> E;
  
  public FragmentManager F = (FragmentManager)new l();
  
  public Fragment G;
  
  public int H;
  
  public int I;
  
  public String J;
  
  public boolean K;
  
  public boolean L;
  
  public boolean M;
  
  public boolean N;
  
  public boolean O;
  
  public boolean P = true;
  
  public boolean Q;
  
  public ViewGroup R;
  
  public View S;
  
  public boolean T;
  
  public boolean U = true;
  
  public d V;
  
  public boolean W;
  
  public boolean X;
  
  public float Y;
  
  public LayoutInflater Z;
  
  public int a = -1;
  
  public boolean a0;
  
  public Bundle b;
  
  public b.n.d.c b0 = b.n.d.c.e;
  
  public SparseArray<Parcelable> c;
  
  public h c0;
  
  public Bundle d;
  
  public v d0;
  
  public Boolean e;
  
  public m<g> e0 = new m();
  
  public String f = UUID.randomUUID().toString();
  
  public b.s.b f0;
  
  public Bundle g;
  
  public int g0;
  
  public Fragment h;
  
  public final ArrayList<f> h0;
  
  public String i = null;
  
  public int j;
  
  public Boolean k = null;
  
  public boolean l;
  
  public boolean m;
  
  public boolean n;
  
  public boolean o;
  
  public boolean p;
  
  public boolean q;
  
  public Fragment() {
    new AtomicInteger();
    this.h0 = new ArrayList<f>();
    Y();
  }
  
  @Deprecated
  public static Fragment a0(Context paramContext, String paramString, Bundle paramBundle) {
    try {
      Fragment fragment = h.d(paramContext.getClassLoader(), paramString).getConstructor(new Class[0]).newInstance(new Object[0]);
      if (paramBundle != null) {
        paramBundle.setClassLoader(fragment.getClass().getClassLoader());
        fragment.D1(paramBundle);
      } 
      return fragment;
    } catch (InstantiationException instantiationException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an empty constructor that is public");
      throw new e(stringBuilder.toString(), instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists, is public, and has an empty constructor that is public");
      throw new e(stringBuilder.toString(), illegalAccessException);
    } catch (NoSuchMethodException noSuchMethodException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": could not find Fragment constructor");
      throw new e(stringBuilder.toString(), noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": calling Fragment constructor caused an exception");
      throw new e(stringBuilder.toString(), invocationTargetException);
    } 
  }
  
  public final Object A() {
    i<?> i1 = this.E;
    return (i1 == null) ? null : i1.m();
  }
  
  public void A0() {
    this.Q = true;
  }
  
  public final void A1(Bundle paramBundle) {
    SparseArray<Parcelable> sparseArray = this.c;
    if (sparseArray != null) {
      this.S.restoreHierarchyState(sparseArray);
      this.c = null;
    } 
    if (this.S != null) {
      this.d0.f(this.d);
      this.d = null;
    } 
    this.Q = false;
    V0(paramBundle);
    if (this.Q) {
      if (this.S != null)
        this.d0.b(b.n.d.b.ON_CREATE); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onViewStateRestored()");
    throw new z(stringBuilder.toString());
  }
  
  public final int B() {
    return this.H;
  }
  
  public void B0() {}
  
  public void B1(View paramView) {
    (k()).a = paramView;
  }
  
  @Deprecated
  public LayoutInflater C(Bundle paramBundle) {
    i<?> i1 = this.E;
    if (i1 != null) {
      LayoutInflater layoutInflater = i1.n();
      b.h.n.f.b(layoutInflater, this.F.u0());
      return layoutInflater;
    } 
    throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
  }
  
  public void C0() {
    this.Q = true;
  }
  
  public void C1(Animator paramAnimator) {
    (k()).b = paramAnimator;
  }
  
  public final int D() {
    b.n.d.c c1 = this.b0;
    return (c1 == b.n.d.c.b || this.G == null) ? c1.ordinal() : Math.min(c1.ordinal(), this.G.D());
  }
  
  public void D0() {
    this.Q = true;
  }
  
  public void D1(Bundle paramBundle) {
    if (this.D == null || !m0()) {
      this.g = paramBundle;
      return;
    } 
    throw new IllegalStateException("Fragment already added and state has been saved");
  }
  
  public int E() {
    d d1 = this.V;
    return (d1 == null) ? 0 : d1.c;
  }
  
  public LayoutInflater E0(Bundle paramBundle) {
    return C(paramBundle);
  }
  
  public void E1(View paramView) {
    (k()).r = paramView;
  }
  
  public int F() {
    d d1 = this.V;
    return (d1 == null) ? 0 : d1.d;
  }
  
  public void F0(boolean paramBoolean) {}
  
  public void F1(boolean paramBoolean) {
    if (this.O != paramBoolean) {
      this.O = paramBoolean;
      if (b0() && !d0())
        this.E.q(); 
    } 
  }
  
  public final Fragment G() {
    return this.G;
  }
  
  @Deprecated
  public void G0(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle) {
    this.Q = true;
  }
  
  public void G1(boolean paramBoolean) {
    (k()).u = paramBoolean;
  }
  
  public final FragmentManager H() {
    FragmentManager fragmentManager = this.D;
    if (fragmentManager != null)
      return fragmentManager; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not associated with a fragment manager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void H0(Context paramContext, AttributeSet paramAttributeSet, Bundle paramBundle) {
    Activity activity;
    this.Q = true;
    i<?> i1 = this.E;
    if (i1 == null) {
      i1 = null;
    } else {
      activity = i1.i();
    } 
    if (activity != null) {
      this.Q = false;
      G0(activity, paramAttributeSet, paramBundle);
    } 
  }
  
  public void H1(boolean paramBoolean) {
    if (this.P != paramBoolean) {
      this.P = paramBoolean;
      if (this.O && b0() && !d0())
        this.E.q(); 
    } 
  }
  
  public float I() {
    d d1 = this.V;
    return (d1 == null) ? 1.0F : d1.q;
  }
  
  public void I0(boolean paramBoolean) {}
  
  public void I1(int paramInt) {
    if (this.V == null && paramInt == 0)
      return; 
    (k()).c = paramInt;
  }
  
  public Object J() {
    d d1 = this.V;
    if (d1 == null)
      return null; 
    Object object2 = d1.j;
    Object object1 = object2;
    if (object2 == i0)
      object1 = w(); 
    return object1;
  }
  
  public boolean J0(MenuItem paramMenuItem) {
    return false;
  }
  
  public void J1(int paramInt) {
    if (this.V == null && paramInt == 0)
      return; 
    k();
    this.V.d = paramInt;
  }
  
  public final Resources K() {
    return w1().getResources();
  }
  
  public void K0(Menu paramMenu) {}
  
  public void K1(g paramg) {
    k();
    d d1 = this.V;
    g g1 = d1.t;
    if (paramg == g1)
      return; 
    if (paramg == null || g1 == null) {
      if (d1.s)
        d1.t = paramg; 
      if (paramg != null)
        paramg.a(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to set a replacement startPostponedEnterTransition on ");
    stringBuilder.append(this);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  @Deprecated
  public final boolean L() {
    return this.M;
  }
  
  public void L0() {
    this.Q = true;
  }
  
  public void L1(float paramFloat) {
    (k()).q = paramFloat;
  }
  
  public Object M() {
    d d1 = this.V;
    if (d1 == null)
      return null; 
    Object object2 = d1.h;
    Object object1 = object2;
    if (object2 == i0)
      object1 = u(); 
    return object1;
  }
  
  public void M0(boolean paramBoolean) {}
  
  @Deprecated
  public void M1(boolean paramBoolean) {
    this.M = paramBoolean;
    FragmentManager fragmentManager = this.D;
    if (fragmentManager != null) {
      if (paramBoolean) {
        fragmentManager.i(this);
        return;
      } 
      fragmentManager.a1(this);
      return;
    } 
    this.N = true;
  }
  
  public Object N() {
    d d1 = this.V;
    return (d1 == null) ? null : d1.k;
  }
  
  public void N0(Menu paramMenu) {}
  
  public void N1(ArrayList<String> paramArrayList1, ArrayList<String> paramArrayList2) {
    k();
    d d1 = this.V;
    d1.e = paramArrayList1;
    d1.f = paramArrayList2;
  }
  
  public Object O() {
    d d1 = this.V;
    if (d1 == null)
      return null; 
    Object object2 = d1.l;
    Object object1 = object2;
    if (object2 == i0)
      object1 = N(); 
    return object1;
  }
  
  public void O0(boolean paramBoolean) {}
  
  @Deprecated
  public void O1(boolean paramBoolean) {
    boolean bool;
    if (!this.U && paramBoolean && this.a < 5 && this.D != null && b0() && this.a0) {
      FragmentManager fragmentManager = this.D;
      fragmentManager.R0(fragmentManager.w(this));
    } 
    this.U = paramBoolean;
    if (this.a < 5 && !paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    this.T = bool;
    if (this.b != null)
      this.e = Boolean.valueOf(paramBoolean); 
  }
  
  public ArrayList<String> P() {
    d d1 = this.V;
    if (d1 != null) {
      ArrayList<String> arrayList = d1.e;
      if (arrayList != null)
        return arrayList; 
    } 
    return new ArrayList<String>();
  }
  
  @Deprecated
  public void P0(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {}
  
  public void P1(@SuppressLint({"UnknownNullness"}) Intent paramIntent) {
    Q1(paramIntent, null);
  }
  
  public ArrayList<String> Q() {
    d d1 = this.V;
    if (d1 != null) {
      ArrayList<String> arrayList = d1.f;
      if (arrayList != null)
        return arrayList; 
    } 
    return new ArrayList<String>();
  }
  
  public void Q0() {
    this.Q = true;
  }
  
  public void Q1(@SuppressLint({"UnknownNullness"}) Intent paramIntent, Bundle paramBundle) {
    i<?> i1 = this.E;
    if (i1 != null) {
      i1.p(this, paramIntent, -1, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final String R(int paramInt) {
    return K().getString(paramInt);
  }
  
  public void R0(Bundle paramBundle) {}
  
  @Deprecated
  public void R1(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (this.E != null) {
      H().K0(this, paramIntent, paramInt, paramBundle);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to Activity");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public final String S() {
    return this.J;
  }
  
  public void S0() {
    this.Q = true;
  }
  
  public void S1() {
    if (this.V != null) {
      if (!(k()).s)
        return; 
      if (this.E == null) {
        (k()).s = false;
        return;
      } 
      if (Looper.myLooper() != this.E.l().getLooper()) {
        this.E.l().postAtFrontOfQueue(new a(this));
        return;
      } 
      f(true);
    } 
  }
  
  @Deprecated
  public final Fragment T() {
    Fragment fragment = this.h;
    if (fragment != null)
      return fragment; 
    FragmentManager fragmentManager = this.D;
    if (fragmentManager != null) {
      String str = this.i;
      if (str != null)
        return fragmentManager.g0(str); 
    } 
    return null;
  }
  
  public void T0() {
    this.Q = true;
  }
  
  public void T1(View paramView) {
    paramView.setOnCreateContextMenuListener(null);
  }
  
  @Deprecated
  public final int U() {
    return this.j;
  }
  
  public void U0(View paramView, Bundle paramBundle) {}
  
  @Deprecated
  public boolean V() {
    return this.U;
  }
  
  public void V0(Bundle paramBundle) {
    this.Q = true;
  }
  
  public View W() {
    return this.S;
  }
  
  public void W0(Bundle paramBundle) {
    this.F.Q0();
    this.a = 3;
    this.Q = false;
    p0(paramBundle);
    if (this.Q) {
      z1();
      this.F.z();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onActivityCreated()");
    throw new z(stringBuilder.toString());
  }
  
  public LiveData<g> X() {
    return (LiveData<g>)this.e0;
  }
  
  public void X0() {
    Iterator<f> iterator = this.h0.iterator();
    while (iterator.hasNext())
      ((f)iterator.next()).a(); 
    this.h0.clear();
    this.F.k(this.E, g(), this);
    this.a = 0;
    this.Q = false;
    s0(this.E.k());
    if (this.Q) {
      this.D.J(this);
      this.F.A();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onAttach()");
    z z = new z(stringBuilder.toString());
    throw z;
  }
  
  public final void Y() {
    this.c0 = new h(this);
    this.f0 = b.s.b.a(this);
  }
  
  public void Y0(Configuration paramConfiguration) {
    onConfigurationChanged(paramConfiguration);
    this.F.B(paramConfiguration);
  }
  
  public void Z() {
    Y();
    this.f = UUID.randomUUID().toString();
    this.l = false;
    this.m = false;
    this.n = false;
    this.o = false;
    this.p = false;
    this.C = 0;
    this.D = null;
    this.F = (FragmentManager)new l();
    this.E = null;
    this.H = 0;
    this.I = 0;
    this.J = null;
    this.K = false;
    this.L = false;
  }
  
  public boolean Z0(MenuItem paramMenuItem) {
    return !this.K ? (u0(paramMenuItem) ? true : this.F.C(paramMenuItem)) : false;
  }
  
  public b.n.d a() {
    return (b.n.d)this.c0;
  }
  
  public void a1(Bundle paramBundle) {
    this.F.Q0();
    this.a = 1;
    this.Q = false;
    if (Build.VERSION.SDK_INT >= 19)
      this.c0.a((b.n.f)new b.n.e(this) {
            public void c(g param1g, b.n.d.b param1b) {
              if (param1b == b.n.d.b.ON_STOP) {
                View view = this.a.S;
                if (view != null)
                  view.cancelPendingInputEvents(); 
              } 
            }
          }); 
    this.f0.c(paramBundle);
    v0(paramBundle);
    this.a0 = true;
    if (this.Q) {
      this.c0.h(b.n.d.b.ON_CREATE);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onCreate()");
    throw new z(stringBuilder.toString());
  }
  
  public final boolean b0() {
    return (this.E != null && this.l);
  }
  
  public boolean b1(Menu paramMenu, MenuInflater paramMenuInflater) {
    boolean bool3 = this.K;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.O) {
        bool = bool1;
        if (this.P) {
          bool = true;
          y0(paramMenu, paramMenuInflater);
        } 
      } 
      bool2 = bool | this.F.E(paramMenu, paramMenuInflater);
    } 
    return bool2;
  }
  
  public final boolean c0() {
    return this.L;
  }
  
  public void c1(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    this.F.Q0();
    this.q = true;
    this.d0 = new v();
    View view = z0(paramLayoutInflater, paramViewGroup, paramBundle);
    this.S = view;
    if (view != null) {
      this.d0.d();
      w.a(this.S, (g)this.d0);
      x.a(this.S, this);
      b.s.d.a(this.S, (c)this.d0);
      this.e0.n(this.d0);
      return;
    } 
    if (!this.d0.e()) {
      this.d0 = null;
      return;
    } 
    throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
  }
  
  public final boolean d0() {
    return this.K;
  }
  
  public void d1() {
    this.F.F();
    this.c0.h(b.n.d.b.ON_DESTROY);
    this.a = 0;
    this.Q = false;
    this.a0 = false;
    A0();
    if (this.Q)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroy()");
    throw new z(stringBuilder.toString());
  }
  
  public boolean e0() {
    d d1 = this.V;
    return (d1 == null) ? false : d1.u;
  }
  
  public void e1() {
    this.F.G();
    if (this.S != null && this.d0.a().b().a(b.n.d.c.c))
      this.d0.b(b.n.d.b.ON_DESTROY); 
    this.a = 1;
    this.Q = false;
    C0();
    if (this.Q) {
      b.o.a.a.b(this).d();
      this.q = false;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDestroyView()");
    throw new z(stringBuilder.toString());
  }
  
  public final boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  public void f(boolean paramBoolean) {
    d d1 = this.V;
    g g1 = null;
    if (d1 != null) {
      d1.s = false;
      g1 = d1.t;
      d1.t = null;
    } 
    if (g1 != null) {
      g1.b();
      return;
    } 
    if (FragmentManager.P && this.S != null) {
      ViewGroup viewGroup = this.R;
      if (viewGroup != null) {
        FragmentManager fragmentManager = this.D;
        if (fragmentManager != null) {
          x x = x.n(viewGroup, fragmentManager);
          x.p();
          if (paramBoolean) {
            this.E.l().post(new b(this, x));
            return;
          } 
          x.g();
        } 
      } 
    } 
  }
  
  public final boolean f0() {
    return (this.C > 0);
  }
  
  public void f1() {
    this.a = -1;
    this.Q = false;
    D0();
    this.Z = null;
    if (this.Q) {
      if (!this.F.D0()) {
        this.F.F();
        this.F = (FragmentManager)new l();
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onDetach()");
    throw new z(stringBuilder.toString());
  }
  
  public b.k.d.f g() {
    return new c(this);
  }
  
  public final boolean g0() {
    return this.o;
  }
  
  public LayoutInflater g1(Bundle paramBundle) {
    LayoutInflater layoutInflater = E0(paramBundle);
    this.Z = layoutInflater;
    return layoutInflater;
  }
  
  public u h() {
    if (this.D != null) {
      if (D() != b.n.d.c.b.ordinal())
        return this.D.A0(this); 
      throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
    } 
    throw new IllegalStateException("Can't access ViewModels from detached fragment");
  }
  
  public final boolean h0() {
    if (this.P) {
      FragmentManager fragmentManager = this.D;
      if (fragmentManager == null || fragmentManager.G0(this.G))
        return true; 
    } 
    return false;
  }
  
  public void h1() {
    onLowMemory();
    this.F.H();
  }
  
  public final int hashCode() {
    return super.hashCode();
  }
  
  public void i(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.H));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.I));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.J);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.a);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.f);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.C);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.l);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.m);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.n);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.o);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.K);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.L);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.P);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.O);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.M);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.U);
    if (this.D != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.D);
    } 
    if (this.E != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.E);
    } 
    if (this.G != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.G);
    } 
    if (this.g != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.g);
    } 
    if (this.b != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.b);
    } 
    if (this.c != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.c);
    } 
    if (this.d != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewRegistryState=");
      paramPrintWriter.println(this.d);
    } 
    Fragment fragment = T();
    if (fragment != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(fragment);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.j);
    } 
    if (E() != 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mNextAnim=");
      paramPrintWriter.println(E());
    } 
    if (this.R != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.R);
    } 
    if (this.S != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.S);
    } 
    if (p() != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(p());
    } 
    if (t() != null)
      b.o.a.a.b(this).a(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Child ");
    stringBuilder1.append(this.F);
    stringBuilder1.append(":");
    paramPrintWriter.println(stringBuilder1.toString());
    FragmentManager fragmentManager = this.F;
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("  ");
    fragmentManager.X(stringBuilder2.toString(), paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public boolean i0() {
    d d1 = this.V;
    return (d1 == null) ? false : d1.s;
  }
  
  public void i1(boolean paramBoolean) {
    I0(paramBoolean);
    this.F.I(paramBoolean);
  }
  
  public final SavedStateRegistry j() {
    return this.f0.b();
  }
  
  public final boolean j0() {
    return this.m;
  }
  
  public boolean j1(MenuItem paramMenuItem) {
    return !this.K ? ((this.O && this.P && J0(paramMenuItem)) ? true : this.F.K(paramMenuItem)) : false;
  }
  
  public final d k() {
    if (this.V == null)
      this.V = new d(); 
    return this.V;
  }
  
  public final boolean k0() {
    Fragment fragment = G();
    return (fragment != null && (fragment.j0() || fragment.k0()));
  }
  
  public void k1(Menu paramMenu) {
    if (!this.K) {
      if (this.O && this.P)
        K0(paramMenu); 
      this.F.L(paramMenu);
    } 
  }
  
  public Fragment l(String paramString) {
    return paramString.equals(this.f) ? this : this.F.j0(paramString);
  }
  
  public final boolean l0() {
    return (this.a >= 7);
  }
  
  public void l1() {
    this.F.N();
    if (this.S != null)
      this.d0.b(b.n.d.b.ON_PAUSE); 
    this.c0.h(b.n.d.b.ON_PAUSE);
    this.a = 6;
    this.Q = false;
    L0();
    if (this.Q)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onPause()");
    throw new z(stringBuilder.toString());
  }
  
  public final b.k.d.d m() {
    i<?> i1 = this.E;
    return (i1 == null) ? null : (b.k.d.d)i1.i();
  }
  
  public final boolean m0() {
    FragmentManager fragmentManager = this.D;
    return (fragmentManager == null) ? false : fragmentManager.J0();
  }
  
  public void m1(boolean paramBoolean) {
    M0(paramBoolean);
    this.F.O(paramBoolean);
  }
  
  public boolean n() {
    d d1 = this.V;
    if (d1 != null) {
      Boolean bool = d1.n;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public final boolean n0() {
    if (b0() && !d0()) {
      View view = this.S;
      if (view != null && view.getWindowToken() != null && this.S.getVisibility() == 0)
        return true; 
    } 
    return false;
  }
  
  public boolean n1(Menu paramMenu) {
    boolean bool3 = this.K;
    boolean bool2 = false;
    boolean bool1 = false;
    if (!bool3) {
      boolean bool = bool1;
      if (this.O) {
        bool = bool1;
        if (this.P) {
          bool = true;
          N0(paramMenu);
        } 
      } 
      bool2 = bool | this.F.P(paramMenu);
    } 
    return bool2;
  }
  
  public boolean o() {
    d d1 = this.V;
    if (d1 != null) {
      Boolean bool = d1.m;
      if (bool != null)
        return bool.booleanValue(); 
    } 
    return true;
  }
  
  public void o0() {
    this.F.Q0();
  }
  
  public void o1() {
    boolean bool = this.D.H0(this);
    Boolean bool1 = this.k;
    if (bool1 == null || bool1.booleanValue() != bool) {
      this.k = Boolean.valueOf(bool);
      O0(bool);
      this.F.Q();
    } 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    this.Q = true;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    v1().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onLowMemory() {
    this.Q = true;
  }
  
  public View p() {
    d d1 = this.V;
    return (d1 == null) ? null : d1.a;
  }
  
  @Deprecated
  public void p0(Bundle paramBundle) {
    this.Q = true;
  }
  
  public void p1() {
    this.F.Q0();
    this.F.b0(true);
    this.a = 7;
    this.Q = false;
    Q0();
    if (this.Q) {
      h h1 = this.c0;
      b.n.d.b b1 = b.n.d.b.ON_RESUME;
      h1.h(b1);
      if (this.S != null)
        this.d0.b(b1); 
      this.F.R();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onResume()");
    throw new z(stringBuilder.toString());
  }
  
  public Animator q() {
    d d1 = this.V;
    return (d1 == null) ? null : d1.b;
  }
  
  @Deprecated
  public void q0(int paramInt1, int paramInt2, Intent paramIntent) {
    if (FragmentManager.E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this);
      stringBuilder.append(" received the following in onActivityResult(): requestCode: ");
      stringBuilder.append(paramInt1);
      stringBuilder.append(" resultCode: ");
      stringBuilder.append(paramInt2);
      stringBuilder.append(" data: ");
      stringBuilder.append(paramIntent);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void q1(Bundle paramBundle) {
    R0(paramBundle);
    this.f0.d(paramBundle);
    Parcelable parcelable = this.F.e1();
    if (parcelable != null)
      paramBundle.putParcelable("android:support:fragments", parcelable); 
  }
  
  public final Bundle r() {
    return this.g;
  }
  
  @Deprecated
  public void r0(Activity paramActivity) {
    this.Q = true;
  }
  
  public void r1() {
    this.F.Q0();
    this.F.b0(true);
    this.a = 5;
    this.Q = false;
    S0();
    if (this.Q) {
      h h1 = this.c0;
      b.n.d.b b1 = b.n.d.b.ON_START;
      h1.h(b1);
      if (this.S != null)
        this.d0.b(b1); 
      this.F.S();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStart()");
    throw new z(stringBuilder.toString());
  }
  
  public final FragmentManager s() {
    if (this.E != null)
      return this.F; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" has not been attached yet.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void s0(Context paramContext) {
    Activity activity;
    this.Q = true;
    i<?> i1 = this.E;
    if (i1 == null) {
      i1 = null;
    } else {
      activity = i1.i();
    } 
    if (activity != null) {
      this.Q = false;
      r0(activity);
    } 
  }
  
  public void s1() {
    this.F.U();
    if (this.S != null)
      this.d0.b(b.n.d.b.ON_STOP); 
    this.c0.h(b.n.d.b.ON_STOP);
    this.a = 4;
    this.Q = false;
    T0();
    if (this.Q)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not call through to super.onStop()");
    throw new z(stringBuilder.toString());
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    R1(paramIntent, paramInt, null);
  }
  
  public Context t() {
    i<?> i1 = this.E;
    return (i1 == null) ? null : i1.k();
  }
  
  @Deprecated
  public void t0(Fragment paramFragment) {}
  
  public void t1() {
    U0(this.S, this.b);
    this.F.V();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append("{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("}");
    stringBuilder.append(" (");
    stringBuilder.append(this.f);
    stringBuilder.append(")");
    if (this.H != 0) {
      stringBuilder.append(" id=0x");
      stringBuilder.append(Integer.toHexString(this.H));
    } 
    if (this.J != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.J);
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public Object u() {
    d d1 = this.V;
    return (d1 == null) ? null : d1.g;
  }
  
  public boolean u0(MenuItem paramMenuItem) {
    return false;
  }
  
  public void u1(View paramView) {
    paramView.setOnCreateContextMenuListener(this);
  }
  
  public o v() {
    d d1 = this.V;
    return (d1 == null) ? null : d1.o;
  }
  
  public void v0(Bundle paramBundle) {
    this.Q = true;
    y1(paramBundle);
    if (!this.F.I0(1))
      this.F.D(); 
  }
  
  public final b.k.d.d v1() {
    b.k.d.d d1 = m();
    if (d1 != null)
      return d1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to an activity.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public Object w() {
    d d1 = this.V;
    return (d1 == null) ? null : d1.i;
  }
  
  public Animation w0(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public final Context w1() {
    Context context = t();
    if (context != null)
      return context; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" not attached to a context.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public o x() {
    d d1 = this.V;
    return (d1 == null) ? null : d1.p;
  }
  
  public Animator x0(int paramInt1, boolean paramBoolean, int paramInt2) {
    return null;
  }
  
  public final View x1() {
    View view = W();
    if (view != null)
      return view; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(this);
    stringBuilder.append(" did not return a View from onCreateView() or this was called before onCreateView().");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public View y() {
    d d1 = this.V;
    return (d1 == null) ? null : d1.r;
  }
  
  public void y0(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  public void y1(Bundle paramBundle) {
    if (paramBundle != null) {
      Parcelable parcelable = paramBundle.getParcelable("android:support:fragments");
      if (parcelable != null) {
        this.F.c1(parcelable);
        this.F.D();
      } 
    } 
  }
  
  @Deprecated
  public final FragmentManager z() {
    return this.D;
  }
  
  public View z0(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    int j = this.g0;
    return (j != 0) ? paramLayoutInflater.inflate(j, paramViewGroup, false) : null;
  }
  
  public final void z1() {
    if (FragmentManager.E0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESTORE_VIEW_STATE: ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    if (this.S != null)
      A1(this.b); 
    this.b = null;
  }
  
  public class a implements Runnable {
    public a(Fragment this$0) {}
    
    public void run() {
      this.a.f(false);
    }
  }
  
  public class b implements Runnable {
    public b(Fragment this$0, x param1x) {}
    
    public void run() {
      this.a.g();
    }
  }
  
  public class c extends b.k.d.f {
    public c(Fragment this$0) {}
    
    public View e(int param1Int) {
      View view = this.a.S;
      if (view != null)
        return view.findViewById(param1Int); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(this.a);
      stringBuilder.append(" does not have a view");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public boolean g() {
      return (this.a.S != null);
    }
  }
  
  public static class d {
    public View a;
    
    public Animator b;
    
    public int c;
    
    public int d;
    
    public ArrayList<String> e;
    
    public ArrayList<String> f;
    
    public Object g = null;
    
    public Object h;
    
    public Object i;
    
    public Object j;
    
    public Object k;
    
    public Object l;
    
    public Boolean m;
    
    public Boolean n;
    
    public o o;
    
    public o p;
    
    public float q;
    
    public View r;
    
    public boolean s;
    
    public Fragment.g t;
    
    public boolean u;
    
    public d() {
      Object object = Fragment.i0;
      this.h = object;
      this.i = null;
      this.j = object;
      this.k = null;
      this.l = object;
      this.q = 1.0F;
      this.r = null;
    }
  }
  
  public static class e extends RuntimeException {
    public e(String param1String, Exception param1Exception) {
      super(param1String, param1Exception);
    }
  }
  
  public static abstract class f {
    public abstract void a();
  }
  
  public static interface g {
    void a();
    
    void b();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\fragment\app\Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */