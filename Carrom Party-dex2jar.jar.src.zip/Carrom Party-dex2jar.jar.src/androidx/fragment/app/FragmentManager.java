package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.IntentSenderRequest;
import b.k.d.q;
import b.k.d.r;
import b.k.d.s;
import b.k.d.w;
import b.k.d.x;
import b.k.d.y;
import b.n.u;
import b.n.v;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class FragmentManager {
  public static boolean O = false;
  
  public static boolean P = true;
  
  public b.a.e.b<IntentSenderRequest> A;
  
  public b.a.e.b<String[]> B;
  
  public ArrayDeque<LaunchedFragmentInfo> C = new ArrayDeque<LaunchedFragmentInfo>();
  
  public boolean D;
  
  public boolean E;
  
  public boolean F;
  
  public boolean G;
  
  public boolean H;
  
  public ArrayList<b.k.d.a> I;
  
  public ArrayList<Boolean> J;
  
  public ArrayList<Fragment> K;
  
  public ArrayList<p> L;
  
  public b.k.d.m M;
  
  public Runnable N = new g(this);
  
  public final ArrayList<n> a = new ArrayList<n>();
  
  public boolean b;
  
  public final q c = new q();
  
  public ArrayList<b.k.d.a> d;
  
  public ArrayList<Fragment> e;
  
  public final b.k.d.j f = new b.k.d.j(this);
  
  public OnBackPressedDispatcher g;
  
  public final b.a.b h = new c(this, false);
  
  public final AtomicInteger i = new AtomicInteger();
  
  public final Map<String, Bundle> j = Collections.synchronizedMap(new HashMap<String, Bundle>());
  
  public final Map<String, Object> k = Collections.synchronizedMap(new HashMap<String, Object>());
  
  public ArrayList<m> l;
  
  public Map<Fragment, HashSet<b.h.j.b>> m = Collections.synchronizedMap(new HashMap<Fragment, HashSet<b.h.j.b>>());
  
  public final s.g n = new d(this);
  
  public final b.k.d.k o = new b.k.d.k(this);
  
  public final CopyOnWriteArrayList<b.k.d.n> p = new CopyOnWriteArrayList<b.k.d.n>();
  
  public int q = -1;
  
  public b.k.d.i<?> r;
  
  public b.k.d.f s;
  
  public Fragment t;
  
  public Fragment u;
  
  public b.k.d.h v = null;
  
  public b.k.d.h w = new e(this);
  
  public y x = null;
  
  public y y = new f(this);
  
  public b.a.e.b<Intent> z;
  
  public static boolean E0(int paramInt) {
    return (O || Log.isLoggable("FragmentManager", paramInt));
  }
  
  public static void d0(ArrayList<b.k.d.a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      b.k.d.a a = paramArrayList.get(paramInt1);
      boolean bool1 = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool = true;
      if (bool1) {
        a.m(-1);
        if (paramInt1 != paramInt2 - 1)
          bool = false; 
        a.r(bool);
      } else {
        a.m(1);
        a.q();
      } 
      paramInt1++;
    } 
  }
  
  public static int d1(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != 8194) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  public static Fragment z0(View paramView) {
    Object object = paramView.getTag(b.k.b.a);
    return (object instanceof Fragment) ? (Fragment)object : null;
  }
  
  public void A() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    T(0);
  }
  
  public u A0(Fragment paramFragment) {
    return this.M.k(paramFragment);
  }
  
  public void B(Configuration paramConfiguration) {
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.Y0(paramConfiguration); 
    } 
  }
  
  public void B0() {
    b0(true);
    if (this.h.c()) {
      T0();
      return;
    } 
    this.g.c();
  }
  
  public boolean C(MenuItem paramMenuItem) {
    if (this.q < 1)
      return false; 
    for (Fragment fragment : this.c.n()) {
      if (fragment != null && fragment.Z0(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void C0(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.K) {
      paramFragment.K = true;
      paramFragment.X = true ^ paramFragment.X;
      j1(paramFragment);
    } 
  }
  
  public void D() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    T(1);
  }
  
  public boolean D0() {
    return this.G;
  }
  
  public boolean E(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i1 = this.q;
    int n = 0;
    if (i1 < 1)
      return false; 
    ArrayList<Fragment> arrayList = null;
    Iterator<Fragment> iterator = this.c.n().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment != null && G0(fragment) && fragment.b1(paramMenu, paramMenuInflater)) {
        ArrayList<Fragment> arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList1.add(fragment);
        bool = true;
        arrayList = arrayList1;
      } 
    } 
    if (this.e != null)
      while (n < this.e.size()) {
        Fragment fragment = this.e.get(n);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.B0(); 
        n++;
      }  
    this.e = arrayList;
    return bool;
  }
  
  public void F() {
    this.G = true;
    b0(true);
    Y();
    T(-1);
    this.r = null;
    this.s = null;
    this.t = null;
    if (this.g != null) {
      this.h.d();
      this.g = null;
    } 
    b.a.e.b<Intent> b1 = this.z;
    if (b1 != null) {
      b1.c();
      this.A.c();
      this.B.c();
    } 
  }
  
  public final boolean F0(Fragment paramFragment) {
    return ((paramFragment.O && paramFragment.P) || paramFragment.F.o());
  }
  
  public void G() {
    T(1);
  }
  
  public boolean G0(Fragment paramFragment) {
    return (paramFragment == null) ? true : paramFragment.h0();
  }
  
  public void H() {
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.h1(); 
    } 
  }
  
  public boolean H0(Fragment paramFragment) {
    if (paramFragment == null)
      return true; 
    FragmentManager fragmentManager = paramFragment.D;
    return (paramFragment.equals(fragmentManager.x0()) && H0(fragmentManager.t));
  }
  
  public void I(boolean paramBoolean) {
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.i1(paramBoolean); 
    } 
  }
  
  public boolean I0(int paramInt) {
    return (this.q >= paramInt);
  }
  
  public void J(Fragment paramFragment) {
    Iterator<b.k.d.n> iterator = this.p.iterator();
    while (iterator.hasNext())
      ((b.k.d.n)iterator.next()).b(this, paramFragment); 
  }
  
  public boolean J0() {
    return (this.E || this.F);
  }
  
  public boolean K(MenuItem paramMenuItem) {
    if (this.q < 1)
      return false; 
    for (Fragment fragment : this.c.n()) {
      if (fragment != null && fragment.j1(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void K0(Fragment paramFragment, @SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    LaunchedFragmentInfo launchedFragmentInfo;
    if (this.z != null) {
      launchedFragmentInfo = new LaunchedFragmentInfo(paramFragment.f, paramInt);
      this.C.addLast(launchedFragmentInfo);
      if (paramIntent != null && paramBundle != null)
        paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle); 
      this.z.a(paramIntent);
      return;
    } 
    this.r.p((Fragment)launchedFragmentInfo, paramIntent, paramInt, paramBundle);
  }
  
  public void L(Menu paramMenu) {
    if (this.q < 1)
      return; 
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.k1(paramMenu); 
    } 
  }
  
  public final void L0(b.f.b<Fragment> paramb) {
    int i1 = paramb.size();
    for (int n = 0; n < i1; n++) {
      Fragment fragment = (Fragment)paramb.j(n);
      if (!fragment.l) {
        View view = fragment.x1();
        fragment.Y = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  public final void M(Fragment paramFragment) {
    if (paramFragment != null && paramFragment.equals(g0(paramFragment.f)))
      paramFragment.o1(); 
  }
  
  public void M0(Fragment paramFragment) {
    if (!this.c.c(paramFragment.f)) {
      if (E0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring moving ");
        stringBuilder.append(paramFragment);
        stringBuilder.append(" to state ");
        stringBuilder.append(this.q);
        stringBuilder.append("since it is not added to ");
        stringBuilder.append(this);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    O0(paramFragment);
    View view = paramFragment.S;
    if (view != null && paramFragment.W && paramFragment.R != null) {
      float f1 = paramFragment.Y;
      if (f1 > 0.0F)
        view.setAlpha(f1); 
      paramFragment.Y = 0.0F;
      paramFragment.W = false;
      b.k.d.e.d d = b.k.d.e.b(this.r.k(), paramFragment, true);
      if (d != null) {
        Animation animation = d.a;
        if (animation != null) {
          paramFragment.S.startAnimation(animation);
        } else {
          d.b.setTarget(paramFragment.S);
          d.b.start();
        } 
      } 
    } 
    if (paramFragment.X)
      v(paramFragment); 
  }
  
  public void N() {
    T(5);
  }
  
  public void N0(int paramInt, boolean paramBoolean) {
    if (this.r != null || paramInt == -1) {
      if (!paramBoolean && paramInt == this.q)
        return; 
      this.q = paramInt;
      if (P) {
        this.c.r();
      } else {
        null = this.c.n().iterator();
        while (null.hasNext())
          M0(null.next()); 
        for (b.k.d.p p : this.c.k()) {
          Fragment fragment = p.k();
          if (!fragment.W)
            M0(fragment); 
          if (fragment.m && !fragment.f0()) {
            paramInt = 1;
          } else {
            paramInt = 0;
          } 
          if (paramInt != 0)
            this.c.q(p); 
        } 
      } 
      l1();
      if (this.D) {
        b.k.d.i<?> i1 = this.r;
        if (i1 != null && this.q == 7) {
          i1.q();
          this.D = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  public void O(boolean paramBoolean) {
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.m1(paramBoolean); 
    } 
  }
  
  public void O0(Fragment paramFragment) {
    P0(paramFragment, this.q);
  }
  
  public boolean P(Menu paramMenu) {
    int n = this.q;
    boolean bool = false;
    if (n < 1)
      return false; 
    for (Fragment fragment : this.c.n()) {
      if (fragment != null && G0(fragment) && fragment.n1(paramMenu))
        bool = true; 
    } 
    return bool;
  }
  
  public void P0(Fragment paramFragment, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Lb/k/d/q;
    //   4: aload_1
    //   5: getfield f : Ljava/lang/String;
    //   8: invokevirtual m : (Ljava/lang/String;)Lb/k/d/p;
    //   11: astore #7
    //   13: iconst_1
    //   14: istore #4
    //   16: aload #7
    //   18: astore #6
    //   20: aload #7
    //   22: ifnonnull -> 49
    //   25: new b/k/d/p
    //   28: dup
    //   29: aload_0
    //   30: getfield o : Lb/k/d/k;
    //   33: aload_0
    //   34: getfield c : Lb/k/d/q;
    //   37: aload_1
    //   38: invokespecial <init> : (Lb/k/d/k;Lb/k/d/q;Landroidx/fragment/app/Fragment;)V
    //   41: astore #6
    //   43: aload #6
    //   45: iconst_1
    //   46: invokevirtual t : (I)V
    //   49: iload_2
    //   50: istore_3
    //   51: aload_1
    //   52: getfield n : Z
    //   55: ifeq -> 83
    //   58: iload_2
    //   59: istore_3
    //   60: aload_1
    //   61: getfield o : Z
    //   64: ifeq -> 83
    //   67: iload_2
    //   68: istore_3
    //   69: aload_1
    //   70: getfield a : I
    //   73: iconst_2
    //   74: if_icmpne -> 83
    //   77: iload_2
    //   78: iconst_2
    //   79: invokestatic max : (II)I
    //   82: istore_3
    //   83: iload_3
    //   84: aload #6
    //   86: invokevirtual d : ()I
    //   89: invokestatic min : (II)I
    //   92: istore_2
    //   93: aload_1
    //   94: getfield a : I
    //   97: istore #5
    //   99: iload #5
    //   101: iload_2
    //   102: if_icmpgt -> 243
    //   105: iload #5
    //   107: iload_2
    //   108: if_icmpge -> 128
    //   111: aload_0
    //   112: getfield m : Ljava/util/Map;
    //   115: invokeinterface isEmpty : ()Z
    //   120: ifne -> 128
    //   123: aload_0
    //   124: aload_1
    //   125: invokevirtual n : (Landroidx/fragment/app/Fragment;)V
    //   128: aload_1
    //   129: getfield a : I
    //   132: istore_3
    //   133: iload_3
    //   134: iconst_m1
    //   135: if_icmpeq -> 167
    //   138: iload_3
    //   139: ifeq -> 177
    //   142: iload_3
    //   143: iconst_1
    //   144: if_icmpeq -> 186
    //   147: iload_3
    //   148: iconst_2
    //   149: if_icmpeq -> 206
    //   152: iload_3
    //   153: iconst_4
    //   154: if_icmpeq -> 216
    //   157: iload_3
    //   158: iconst_5
    //   159: if_icmpeq -> 226
    //   162: iload_2
    //   163: istore_3
    //   164: goto -> 690
    //   167: iload_2
    //   168: iconst_m1
    //   169: if_icmple -> 177
    //   172: aload #6
    //   174: invokevirtual c : ()V
    //   177: iload_2
    //   178: ifle -> 186
    //   181: aload #6
    //   183: invokevirtual e : ()V
    //   186: iload_2
    //   187: iconst_m1
    //   188: if_icmple -> 196
    //   191: aload #6
    //   193: invokevirtual j : ()V
    //   196: iload_2
    //   197: iconst_1
    //   198: if_icmple -> 206
    //   201: aload #6
    //   203: invokevirtual f : ()V
    //   206: iload_2
    //   207: iconst_2
    //   208: if_icmple -> 216
    //   211: aload #6
    //   213: invokevirtual a : ()V
    //   216: iload_2
    //   217: iconst_4
    //   218: if_icmple -> 226
    //   221: aload #6
    //   223: invokevirtual u : ()V
    //   226: iload_2
    //   227: istore_3
    //   228: iload_2
    //   229: iconst_5
    //   230: if_icmple -> 690
    //   233: aload #6
    //   235: invokevirtual p : ()V
    //   238: iload_2
    //   239: istore_3
    //   240: goto -> 690
    //   243: iload_2
    //   244: istore_3
    //   245: iload #5
    //   247: iload_2
    //   248: if_icmple -> 690
    //   251: iload #5
    //   253: ifeq -> 679
    //   256: iload #5
    //   258: iconst_1
    //   259: if_icmpeq -> 650
    //   262: iload #5
    //   264: iconst_2
    //   265: if_icmpeq -> 391
    //   268: iload #5
    //   270: iconst_4
    //   271: if_icmpeq -> 313
    //   274: iload #5
    //   276: iconst_5
    //   277: if_icmpeq -> 303
    //   280: iload #5
    //   282: bipush #7
    //   284: if_icmpeq -> 292
    //   287: iload_2
    //   288: istore_3
    //   289: goto -> 690
    //   292: iload_2
    //   293: bipush #7
    //   295: if_icmpge -> 303
    //   298: aload #6
    //   300: invokevirtual n : ()V
    //   303: iload_2
    //   304: iconst_5
    //   305: if_icmpge -> 313
    //   308: aload #6
    //   310: invokevirtual v : ()V
    //   313: iload_2
    //   314: iconst_4
    //   315: if_icmpge -> 391
    //   318: iconst_3
    //   319: invokestatic E0 : (I)Z
    //   322: ifeq -> 361
    //   325: new java/lang/StringBuilder
    //   328: dup
    //   329: invokespecial <init> : ()V
    //   332: astore #7
    //   334: aload #7
    //   336: ldc_w 'movefrom ACTIVITY_CREATED: '
    //   339: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   342: pop
    //   343: aload #7
    //   345: aload_1
    //   346: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   349: pop
    //   350: ldc 'FragmentManager'
    //   352: aload #7
    //   354: invokevirtual toString : ()Ljava/lang/String;
    //   357: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   360: pop
    //   361: aload_1
    //   362: getfield S : Landroid/view/View;
    //   365: ifnull -> 391
    //   368: aload_0
    //   369: getfield r : Lb/k/d/i;
    //   372: aload_1
    //   373: invokevirtual o : (Landroidx/fragment/app/Fragment;)Z
    //   376: ifeq -> 391
    //   379: aload_1
    //   380: getfield c : Landroid/util/SparseArray;
    //   383: ifnonnull -> 391
    //   386: aload #6
    //   388: invokevirtual s : ()V
    //   391: iload_2
    //   392: iconst_2
    //   393: if_icmpge -> 650
    //   396: aconst_null
    //   397: astore #8
    //   399: aload_1
    //   400: getfield S : Landroid/view/View;
    //   403: astore #7
    //   405: aload #7
    //   407: ifnull -> 632
    //   410: aload_1
    //   411: getfield R : Landroid/view/ViewGroup;
    //   414: astore #9
    //   416: aload #9
    //   418: ifnull -> 632
    //   421: aload #9
    //   423: aload #7
    //   425: invokevirtual endViewTransition : (Landroid/view/View;)V
    //   428: aload_1
    //   429: getfield S : Landroid/view/View;
    //   432: invokevirtual clearAnimation : ()V
    //   435: aload_1
    //   436: invokevirtual k0 : ()Z
    //   439: ifne -> 632
    //   442: aload #8
    //   444: astore #7
    //   446: aload_0
    //   447: getfield q : I
    //   450: iconst_m1
    //   451: if_icmple -> 506
    //   454: aload #8
    //   456: astore #7
    //   458: aload_0
    //   459: getfield G : Z
    //   462: ifne -> 506
    //   465: aload #8
    //   467: astore #7
    //   469: aload_1
    //   470: getfield S : Landroid/view/View;
    //   473: invokevirtual getVisibility : ()I
    //   476: ifne -> 506
    //   479: aload #8
    //   481: astore #7
    //   483: aload_1
    //   484: getfield Y : F
    //   487: fconst_0
    //   488: fcmpl
    //   489: iflt -> 506
    //   492: aload_0
    //   493: getfield r : Lb/k/d/i;
    //   496: invokevirtual k : ()Landroid/content/Context;
    //   499: aload_1
    //   500: iconst_0
    //   501: invokestatic b : (Landroid/content/Context;Landroidx/fragment/app/Fragment;Z)Lb/k/d/e$d;
    //   504: astore #7
    //   506: aload_1
    //   507: fconst_0
    //   508: putfield Y : F
    //   511: aload_1
    //   512: getfield R : Landroid/view/ViewGroup;
    //   515: astore #8
    //   517: aload_1
    //   518: getfield S : Landroid/view/View;
    //   521: astore #9
    //   523: aload #7
    //   525: ifnull -> 538
    //   528: aload_1
    //   529: aload #7
    //   531: aload_0
    //   532: getfield n : Lb/k/d/s$g;
    //   535: invokestatic a : (Landroidx/fragment/app/Fragment;Lb/k/d/e$d;Lb/k/d/s$g;)V
    //   538: aload #8
    //   540: aload #9
    //   542: invokevirtual removeView : (Landroid/view/View;)V
    //   545: iconst_2
    //   546: invokestatic E0 : (I)Z
    //   549: ifeq -> 622
    //   552: new java/lang/StringBuilder
    //   555: dup
    //   556: invokespecial <init> : ()V
    //   559: astore #7
    //   561: aload #7
    //   563: ldc_w 'Removing view '
    //   566: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   569: pop
    //   570: aload #7
    //   572: aload #9
    //   574: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   577: pop
    //   578: aload #7
    //   580: ldc_w ' for fragment '
    //   583: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   586: pop
    //   587: aload #7
    //   589: aload_1
    //   590: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   593: pop
    //   594: aload #7
    //   596: ldc_w ' from container '
    //   599: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   602: pop
    //   603: aload #7
    //   605: aload #8
    //   607: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   610: pop
    //   611: ldc 'FragmentManager'
    //   613: aload #7
    //   615: invokevirtual toString : ()Ljava/lang/String;
    //   618: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   621: pop
    //   622: aload #8
    //   624: aload_1
    //   625: getfield R : Landroid/view/ViewGroup;
    //   628: if_acmpeq -> 632
    //   631: return
    //   632: aload_0
    //   633: getfield m : Ljava/util/Map;
    //   636: aload_1
    //   637: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   642: ifnonnull -> 650
    //   645: aload #6
    //   647: invokevirtual h : ()V
    //   650: iload_2
    //   651: iconst_1
    //   652: if_icmpge -> 679
    //   655: aload_0
    //   656: getfield m : Ljava/util/Map;
    //   659: aload_1
    //   660: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   665: ifnull -> 674
    //   668: iload #4
    //   670: istore_2
    //   671: goto -> 679
    //   674: aload #6
    //   676: invokevirtual g : ()V
    //   679: iload_2
    //   680: ifge -> 688
    //   683: aload #6
    //   685: invokevirtual i : ()V
    //   688: iload_2
    //   689: istore_3
    //   690: aload_1
    //   691: getfield a : I
    //   694: iload_3
    //   695: if_icmpeq -> 781
    //   698: iconst_3
    //   699: invokestatic E0 : (I)Z
    //   702: ifeq -> 776
    //   705: new java/lang/StringBuilder
    //   708: dup
    //   709: invokespecial <init> : ()V
    //   712: astore #6
    //   714: aload #6
    //   716: ldc_w 'moveToState: Fragment state for '
    //   719: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   722: pop
    //   723: aload #6
    //   725: aload_1
    //   726: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   729: pop
    //   730: aload #6
    //   732: ldc_w ' not updated inline; expected state '
    //   735: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   738: pop
    //   739: aload #6
    //   741: iload_3
    //   742: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   745: pop
    //   746: aload #6
    //   748: ldc_w ' found '
    //   751: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   754: pop
    //   755: aload #6
    //   757: aload_1
    //   758: getfield a : I
    //   761: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   764: pop
    //   765: ldc 'FragmentManager'
    //   767: aload #6
    //   769: invokevirtual toString : ()Ljava/lang/String;
    //   772: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   775: pop
    //   776: aload_1
    //   777: iload_3
    //   778: putfield a : I
    //   781: return
  }
  
  public void Q() {
    m1();
    M(this.u);
  }
  
  public void Q0() {
    if (this.r == null)
      return; 
    this.E = false;
    this.F = false;
    this.M.n(false);
    for (Fragment fragment : this.c.n()) {
      if (fragment != null)
        fragment.o0(); 
    } 
  }
  
  public void R() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    T(7);
  }
  
  public void R0(b.k.d.p paramp) {
    Fragment fragment = paramp.k();
    if (fragment.T) {
      if (this.b) {
        this.H = true;
        return;
      } 
      fragment.T = false;
      if (P) {
        paramp.m();
        return;
      } 
      O0(fragment);
    } 
  }
  
  public void S() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    T(5);
  }
  
  public void S0(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      Z(new o(this, null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public final void T(int paramInt) {
    try {
      this.b = true;
      this.c.d(paramInt);
      N0(paramInt, false);
      if (P) {
        Iterator<x> iterator = s().iterator();
        while (iterator.hasNext())
          ((x)iterator.next()).j(); 
      } 
      this.b = false;
      return;
    } finally {
      this.b = false;
    } 
  }
  
  public boolean T0() {
    return U0(null, -1, 0);
  }
  
  public void U() {
    this.F = true;
    this.M.n(true);
    T(4);
  }
  
  public final boolean U0(String paramString, int paramInt1, int paramInt2) {
    b0(false);
    a0(true);
    Fragment fragment = this.u;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.s().T0())
      return true; 
    boolean bool = V0(this.I, this.J, paramString, paramInt1, paramInt2);
    if (bool) {
      this.b = true;
      try {
        Z0(this.I, this.J);
      } finally {
        q();
      } 
    } 
    m1();
    W();
    this.c.b();
    return bool;
  }
  
  public void V() {
    T(2);
  }
  
  public boolean V0(ArrayList<b.k.d.a> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ljava/util/ArrayList;
    //   4: astore #8
    //   6: aload #8
    //   8: ifnonnull -> 13
    //   11: iconst_0
    //   12: ireturn
    //   13: aload_3
    //   14: ifnonnull -> 69
    //   17: iload #4
    //   19: ifge -> 69
    //   22: iload #5
    //   24: iconst_1
    //   25: iand
    //   26: ifne -> 69
    //   29: aload #8
    //   31: invokevirtual size : ()I
    //   34: iconst_1
    //   35: isub
    //   36: istore #4
    //   38: iload #4
    //   40: ifge -> 45
    //   43: iconst_0
    //   44: ireturn
    //   45: aload_1
    //   46: aload_0
    //   47: getfield d : Ljava/util/ArrayList;
    //   50: iload #4
    //   52: invokevirtual remove : (I)Ljava/lang/Object;
    //   55: invokevirtual add : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_2
    //   60: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   63: invokevirtual add : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: iconst_1
    //   68: ireturn
    //   69: aload_3
    //   70: ifnonnull -> 87
    //   73: iload #4
    //   75: iflt -> 81
    //   78: goto -> 87
    //   81: iconst_m1
    //   82: istore #4
    //   84: goto -> 262
    //   87: aload #8
    //   89: invokevirtual size : ()I
    //   92: iconst_1
    //   93: isub
    //   94: istore #6
    //   96: iload #6
    //   98: iflt -> 161
    //   101: aload_0
    //   102: getfield d : Ljava/util/ArrayList;
    //   105: iload #6
    //   107: invokevirtual get : (I)Ljava/lang/Object;
    //   110: checkcast b/k/d/a
    //   113: astore #8
    //   115: aload_3
    //   116: ifnull -> 134
    //   119: aload_3
    //   120: aload #8
    //   122: invokevirtual t : ()Ljava/lang/String;
    //   125: invokevirtual equals : (Ljava/lang/Object;)Z
    //   128: ifeq -> 134
    //   131: goto -> 161
    //   134: iload #4
    //   136: iflt -> 152
    //   139: iload #4
    //   141: aload #8
    //   143: getfield s : I
    //   146: if_icmpne -> 152
    //   149: goto -> 161
    //   152: iload #6
    //   154: iconst_1
    //   155: isub
    //   156: istore #6
    //   158: goto -> 96
    //   161: iload #6
    //   163: ifge -> 168
    //   166: iconst_0
    //   167: ireturn
    //   168: iload #6
    //   170: istore #7
    //   172: iload #5
    //   174: iconst_1
    //   175: iand
    //   176: ifeq -> 258
    //   179: iload #6
    //   181: iconst_1
    //   182: isub
    //   183: istore #5
    //   185: iload #5
    //   187: istore #7
    //   189: iload #5
    //   191: iflt -> 258
    //   194: aload_0
    //   195: getfield d : Ljava/util/ArrayList;
    //   198: iload #5
    //   200: invokevirtual get : (I)Ljava/lang/Object;
    //   203: checkcast b/k/d/a
    //   206: astore #8
    //   208: aload_3
    //   209: ifnull -> 228
    //   212: iload #5
    //   214: istore #6
    //   216: aload_3
    //   217: aload #8
    //   219: invokevirtual t : ()Ljava/lang/String;
    //   222: invokevirtual equals : (Ljava/lang/Object;)Z
    //   225: ifne -> 179
    //   228: iload #5
    //   230: istore #7
    //   232: iload #4
    //   234: iflt -> 258
    //   237: iload #5
    //   239: istore #7
    //   241: iload #4
    //   243: aload #8
    //   245: getfield s : I
    //   248: if_icmpne -> 258
    //   251: iload #5
    //   253: istore #6
    //   255: goto -> 179
    //   258: iload #7
    //   260: istore #4
    //   262: iload #4
    //   264: aload_0
    //   265: getfield d : Ljava/util/ArrayList;
    //   268: invokevirtual size : ()I
    //   271: iconst_1
    //   272: isub
    //   273: if_icmpne -> 278
    //   276: iconst_0
    //   277: ireturn
    //   278: aload_0
    //   279: getfield d : Ljava/util/ArrayList;
    //   282: invokevirtual size : ()I
    //   285: iconst_1
    //   286: isub
    //   287: istore #5
    //   289: iload #5
    //   291: iload #4
    //   293: if_icmple -> 327
    //   296: aload_1
    //   297: aload_0
    //   298: getfield d : Ljava/util/ArrayList;
    //   301: iload #5
    //   303: invokevirtual remove : (I)Ljava/lang/Object;
    //   306: invokevirtual add : (Ljava/lang/Object;)Z
    //   309: pop
    //   310: aload_2
    //   311: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   314: invokevirtual add : (Ljava/lang/Object;)Z
    //   317: pop
    //   318: iload #5
    //   320: iconst_1
    //   321: isub
    //   322: istore #5
    //   324: goto -> 289
    //   327: iconst_1
    //   328: ireturn
  }
  
  public final void W() {
    if (this.H) {
      this.H = false;
      l1();
    } 
  }
  
  public final int W0(ArrayList<b.k.d.a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, b.f.b<Fragment> paramb) {
    int n = paramInt2 - 1;
    int i1;
    for (i1 = paramInt2; n >= paramInt1; i1 = i2) {
      boolean bool;
      b.k.d.a a = paramArrayList.get(n);
      boolean bool1 = ((Boolean)paramArrayList1.get(n)).booleanValue();
      if (a.x() && !a.v(paramArrayList, n + 1, paramInt2)) {
        bool = true;
      } else {
        bool = false;
      } 
      int i2 = i1;
      if (bool) {
        if (this.L == null)
          this.L = new ArrayList<p>(); 
        p p = new p(a, bool1);
        this.L.add(p);
        a.z(p);
        if (bool1) {
          a.q();
        } else {
          a.r(false);
        } 
        i2 = i1 - 1;
        if (n != i2) {
          paramArrayList.remove(n);
          paramArrayList.add(i2, a);
        } 
        d(paramb);
      } 
      n--;
    } 
    return i1;
  }
  
  public void X(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("    ");
    String str = stringBuilder2.toString();
    this.c.e(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    ArrayList<Fragment> arrayList1 = this.e;
    byte b1 = 0;
    if (arrayList1 != null) {
      int n = arrayList1.size();
      if (n > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        int i1;
        for (i1 = 0; i1 < n; i1++) {
          Fragment fragment = this.e.get(i1);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i1);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(fragment.toString());
        } 
      } 
    } 
    ArrayList<b.k.d.a> arrayList = this.d;
    if (arrayList != null) {
      int n = arrayList.size();
      if (n > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        int i1;
        for (i1 = 0; i1 < n; i1++) {
          b.k.d.a a = this.d.get(i1);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i1);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(a.toString());
          a.o(str, paramPrintWriter);
        } 
      } 
    } 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Back Stack Index: ");
    stringBuilder1.append(this.i.get());
    paramPrintWriter.println(stringBuilder1.toString());
    synchronized (this.a) {
      int n = this.a.size();
      if (n > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Pending Actions:");
        int i1;
        for (i1 = b1; i1 < n; i1++) {
          n n1 = this.a.get(i1);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(i1);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(n1);
        } 
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("FragmentManager misc state:");
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mHost=");
      paramPrintWriter.println(this.r);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mContainer=");
      paramPrintWriter.println(this.s);
      if (this.t != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mParent=");
        paramPrintWriter.println(this.t);
      } 
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mCurState=");
      paramPrintWriter.print(this.q);
      paramPrintWriter.print(" mStateSaved=");
      paramPrintWriter.print(this.E);
      paramPrintWriter.print(" mStopped=");
      paramPrintWriter.print(this.F);
      paramPrintWriter.print(" mDestroyed=");
      paramPrintWriter.println(this.G);
      if (this.D) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  mNeedMenuInvalidate=");
        paramPrintWriter.println(this.D);
      } 
      return;
    } 
  }
  
  public void X0(Fragment paramFragment, b.h.j.b paramb) {
    HashSet hashSet = this.m.get(paramFragment);
    if (hashSet != null && hashSet.remove(paramb) && hashSet.isEmpty()) {
      this.m.remove(paramFragment);
      if (paramFragment.a < 5) {
        x(paramFragment);
        O0(paramFragment);
      } 
    } 
  }
  
  public final void Y() {
    if (P) {
      Iterator<x> iterator = s().iterator();
      while (iterator.hasNext())
        ((x)iterator.next()).j(); 
    } else if (!this.m.isEmpty()) {
      for (Fragment fragment : this.m.keySet()) {
        n(fragment);
        O0(fragment);
      } 
    } 
  }
  
  public void Y0(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.C);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.f0();
    if (!paramFragment.L || (bool ^ true) != 0) {
      this.c.s(paramFragment);
      if (F0(paramFragment))
        this.D = true; 
      paramFragment.m = true;
      j1(paramFragment);
    } 
  }
  
  public void Z(n paramn, boolean paramBoolean) {
    if (!paramBoolean) {
      if (this.r == null) {
        if (this.G)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      p();
    } 
    synchronized (this.a) {
      if (this.r == null) {
        if (paramBoolean)
          return; 
        throw new IllegalStateException("Activity has been destroyed");
      } 
      this.a.add(paramn);
      f1();
      return;
    } 
  }
  
  public final void Z0(ArrayList<b.k.d.a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList.isEmpty())
      return; 
    if (paramArrayList.size() == paramArrayList1.size()) {
      f0(paramArrayList, paramArrayList1);
      int i2 = paramArrayList.size();
      int n = 0;
      int i1;
      for (i1 = 0; n < i2; i1 = i3) {
        int i4 = n;
        int i3 = i1;
        if (!((r)paramArrayList.get(n)).o) {
          if (i1 != n)
            e0(paramArrayList, paramArrayList1, i1, n); 
          i1 = n + 1;
          i3 = i1;
          if (((Boolean)paramArrayList1.get(n)).booleanValue())
            while (true) {
              i3 = i1;
              if (i1 < i2) {
                i3 = i1;
                if (((Boolean)paramArrayList1.get(i1)).booleanValue()) {
                  i3 = i1;
                  if (!((r)paramArrayList.get(i1)).o) {
                    i1++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          e0(paramArrayList, paramArrayList1, n, i3);
          i4 = i3 - 1;
        } 
        n = i4 + 1;
      } 
      if (i1 != i2)
        e0(paramArrayList, paramArrayList1, i1, i2); 
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Internal error with the back stack records");
    throw illegalStateException;
  }
  
  public final void a0(boolean paramBoolean) {
    if (!this.b) {
      if (this.r == null) {
        if (this.G)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (Looper.myLooper() == this.r.l().getLooper()) {
        if (!paramBoolean)
          p(); 
        if (this.I == null) {
          this.I = new ArrayList<b.k.d.a>();
          this.J = new ArrayList<Boolean>();
        } 
        this.b = true;
        try {
          f0(null, null);
          return;
        } finally {
          this.b = false;
        } 
      } 
      throw new IllegalStateException("Must be called from main thread of fragment host");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  public void a1(Fragment paramFragment) {
    this.M.m(paramFragment);
  }
  
  public boolean b0(boolean paramBoolean) {
    a0(paramBoolean);
    paramBoolean = false;
    while (l0(this.I, this.J)) {
      this.b = true;
      try {
        Z0(this.I, this.J);
        q();
      } finally {
        q();
      } 
    } 
    m1();
    W();
    this.c.b();
    return paramBoolean;
  }
  
  public final void b1() {
    if (this.l != null)
      for (int n = 0; n < this.l.size(); n++)
        ((m)this.l.get(n)).a();  
  }
  
  public void c0(n paramn, boolean paramBoolean) {
    if (paramBoolean && (this.r == null || this.G))
      return; 
    a0(paramBoolean);
    if (paramn.a(this.I, this.J)) {
      this.b = true;
      try {
        Z0(this.I, this.J);
      } finally {
        q();
      } 
    } 
    m1();
    W();
    this.c.b();
  }
  
  public void c1(Parcelable paramParcelable) {
    if (paramParcelable == null)
      return; 
    FragmentManagerState fragmentManagerState = (FragmentManagerState)paramParcelable;
    if (fragmentManagerState.a == null)
      return; 
    this.c.t();
    for (Parcelable paramParcelable : fragmentManagerState.a) {
      if (paramParcelable != null) {
        b.k.d.p p;
        Fragment fragment = this.M.g(((FragmentState)paramParcelable).b);
        if (fragment != null) {
          if (E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: re-attaching retained ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          p = new b.k.d.p(this.o, this.c, fragment, (FragmentState)paramParcelable);
        } else {
          p = new b.k.d.p(this.o, this.c, this.r.k().getClassLoader(), q0(), (FragmentState)p);
        } 
        fragment = p.k();
        fragment.D = this;
        if (E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreSaveState: active (");
          stringBuilder.append(fragment.f);
          stringBuilder.append("): ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        p.o(this.r.k().getClassLoader());
        this.c.p(p);
        p.t(this.q);
      } 
    } 
    for (Fragment fragment : this.M.j()) {
      if (!this.c.c(fragment.f)) {
        if (E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Discarding retained Fragment ");
          stringBuilder.append(fragment);
          stringBuilder.append(" that was not found in the set of active Fragments ");
          stringBuilder.append(fragmentManagerState.a);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.M.m(fragment);
        fragment.D = this;
        b.k.d.p p = new b.k.d.p(this.o, this.c, fragment);
        p.t(1);
        p.m();
        fragment.m = true;
        p.m();
      } 
    } 
    this.c.u(fragmentManagerState.b);
    BackStackState[] arrayOfBackStackState = fragmentManagerState.c;
    byte b1 = 0;
    if (arrayOfBackStackState != null) {
      this.d = new ArrayList<b.k.d.a>(fragmentManagerState.c.length);
      int n = 0;
      while (true) {
        arrayOfBackStackState = fragmentManagerState.c;
        if (n < arrayOfBackStackState.length) {
          b.k.d.a a = arrayOfBackStackState[n].c(this);
          if (E0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreAllState: back stack #");
            stringBuilder.append(n);
            stringBuilder.append(" (index ");
            stringBuilder.append(a.s);
            stringBuilder.append("): ");
            stringBuilder.append(a);
            Log.v("FragmentManager", stringBuilder.toString());
            PrintWriter printWriter = new PrintWriter((Writer)new w("FragmentManager"));
            a.p("  ", printWriter, false);
            printWriter.close();
          } 
          this.d.add(a);
          n++;
          continue;
        } 
        break;
      } 
    } else {
      this.d = null;
    } 
    this.i.set(fragmentManagerState.d);
    String str = fragmentManagerState.e;
    if (str != null) {
      Fragment fragment = g0(str);
      this.u = fragment;
      M(fragment);
    } 
    ArrayList<String> arrayList = fragmentManagerState.f;
    if (arrayList != null)
      for (int n = b1; n < arrayList.size(); n++)
        this.j.put(arrayList.get(n), fragmentManagerState.g.get(n));  
    this.C = new ArrayDeque<LaunchedFragmentInfo>(fragmentManagerState.h);
  }
  
  public final void d(b.f.b<Fragment> paramb) {
    int n = this.q;
    if (n < 1)
      return; 
    n = Math.min(n, 5);
    for (Fragment fragment : this.c.n()) {
      if (fragment.a < n) {
        P0(fragment, n);
        if (fragment.S != null && !fragment.K && fragment.W)
          paramb.add(fragment); 
      } 
    } 
  }
  
  public void e(b.k.d.a parama) {
    if (this.d == null)
      this.d = new ArrayList<b.k.d.a>(); 
    this.d.add(parama);
  }
  
  public final void e0(ArrayList<b.k.d.a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    boolean bool1 = ((r)paramArrayList.get(paramInt1)).o;
    ArrayList<Fragment> arrayList = this.K;
    if (arrayList == null) {
      this.K = new ArrayList<Fragment>();
    } else {
      arrayList.clear();
    } 
    this.K.addAll(this.c.n());
    Fragment fragment = x0();
    int n = paramInt1;
    boolean bool = false;
    while (n < paramInt2) {
      b.k.d.a a = paramArrayList.get(n);
      if (!((Boolean)paramArrayList1.get(n)).booleanValue()) {
        fragment = a.s(this.K, fragment);
      } else {
        fragment = a.A(this.K, fragment);
      } 
      if (bool || ((r)a).g) {
        bool = true;
      } else {
        bool = false;
      } 
      n++;
    } 
    this.K.clear();
    if (!bool1 && this.q >= 1)
      if (P) {
        for (n = paramInt1; n < paramInt2; n++) {
          Iterator iterator = ((r)paramArrayList.get(n)).a.iterator();
          while (iterator.hasNext()) {
            Fragment fragment1 = ((r.a)iterator.next()).b;
            if (fragment1 != null && fragment1.D != null) {
              b.k.d.p p = w(fragment1);
              this.c.p(p);
            } 
          } 
        } 
      } else {
        s.C(this.r.k(), this.s, paramArrayList, paramArrayList1, paramInt1, paramInt2, false, this.n);
      }  
    d0(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (P) {
      bool1 = ((Boolean)paramArrayList1.get(paramInt2 - 1)).booleanValue();
      for (n = paramInt1; n < paramInt2; n++) {
        b.k.d.a a = paramArrayList.get(n);
        if (bool1) {
          int i1;
          for (i1 = ((r)a).a.size() - 1; i1 >= 0; i1--) {
            Fragment fragment1 = ((r.a)((r)a).a.get(i1)).b;
            if (fragment1 != null)
              w(fragment1).m(); 
          } 
        } else {
          Iterator iterator = ((r)a).a.iterator();
          while (iterator.hasNext()) {
            Fragment fragment1 = ((r.a)iterator.next()).b;
            if (fragment1 != null)
              w(fragment1).m(); 
          } 
        } 
      } 
      N0(this.q, true);
      for (x x : t(paramArrayList, paramInt1, paramInt2)) {
        x.r(bool1);
        x.p();
        x.g();
      } 
    } else {
      if (bool1) {
        b.f.b<Fragment> b1 = new b.f.b();
        d(b1);
        n = W0(paramArrayList, paramArrayList1, paramInt1, paramInt2, b1);
        L0(b1);
      } else {
        n = paramInt2;
      } 
      ArrayList<Boolean> arrayList1 = paramArrayList1;
      if (n != paramInt1 && bool1) {
        if (this.q >= 1)
          s.C(this.r.k(), this.s, paramArrayList, paramArrayList1, paramInt1, n, true, this.n); 
        paramArrayList1 = arrayList1;
        N0(this.q, true);
      } else {
        paramArrayList1 = arrayList1;
      } 
    } 
    while (paramInt1 < paramInt2) {
      b.k.d.a a = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue() && a.s >= 0)
        a.s = -1; 
      a.y();
      paramInt1++;
    } 
    if (bool)
      b1(); 
  }
  
  public Parcelable e1() {
    StringBuilder stringBuilder;
    k0();
    Y();
    b0(true);
    this.E = true;
    this.M.n(true);
    ArrayList<FragmentState> arrayList = this.c.v();
    boolean bool = arrayList.isEmpty();
    BackStackState[] arrayOfBackStackState2 = null;
    if (bool) {
      if (E0(2))
        Log.v("FragmentManager", "saveAllState: no fragments!"); 
      return null;
    } 
    ArrayList<String> arrayList1 = this.c.w();
    ArrayList<b.k.d.a> arrayList2 = this.d;
    BackStackState[] arrayOfBackStackState1 = arrayOfBackStackState2;
    if (arrayList2 != null) {
      int n = arrayList2.size();
      arrayOfBackStackState1 = arrayOfBackStackState2;
      if (n > 0) {
        arrayOfBackStackState2 = new BackStackState[n];
        int i1 = 0;
        while (true) {
          arrayOfBackStackState1 = arrayOfBackStackState2;
          if (i1 < n) {
            arrayOfBackStackState2[i1] = new BackStackState(this.d.get(i1));
            if (E0(2)) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding back stack #");
              stringBuilder.append(i1);
              stringBuilder.append(": ");
              stringBuilder.append(this.d.get(i1));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            i1++;
            continue;
          } 
          break;
        } 
      } 
    } 
    FragmentManagerState fragmentManagerState = new FragmentManagerState();
    fragmentManagerState.a = arrayList;
    fragmentManagerState.b = arrayList1;
    fragmentManagerState.c = (BackStackState[])stringBuilder;
    fragmentManagerState.d = this.i.get();
    Fragment fragment = this.u;
    if (fragment != null)
      fragmentManagerState.e = fragment.f; 
    fragmentManagerState.f.addAll(this.j.keySet());
    fragmentManagerState.g.addAll(this.j.values());
    fragmentManagerState.h = new ArrayList<LaunchedFragmentInfo>(this.C);
    return fragmentManagerState;
  }
  
  public void f(Fragment paramFragment, b.h.j.b paramb) {
    if (this.m.get(paramFragment) == null)
      this.m.put(paramFragment, new HashSet<b.h.j.b>()); 
    ((HashSet<b.h.j.b>)this.m.get(paramFragment)).add(paramb);
  }
  
  public final void f0(ArrayList<b.k.d.a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: getfield L : Ljava/util/ArrayList;
    //   4: astore #7
    //   6: aload #7
    //   8: ifnonnull -> 16
    //   11: iconst_0
    //   12: istore_3
    //   13: goto -> 22
    //   16: aload #7
    //   18: invokevirtual size : ()I
    //   21: istore_3
    //   22: iconst_0
    //   23: istore #4
    //   25: iload_3
    //   26: istore #6
    //   28: iload #4
    //   30: iload #6
    //   32: if_icmpge -> 260
    //   35: aload_0
    //   36: getfield L : Ljava/util/ArrayList;
    //   39: iload #4
    //   41: invokevirtual get : (I)Ljava/lang/Object;
    //   44: checkcast androidx/fragment/app/FragmentManager$p
    //   47: astore #7
    //   49: aload_1
    //   50: ifnull -> 123
    //   53: aload #7
    //   55: getfield a : Z
    //   58: ifne -> 123
    //   61: aload_1
    //   62: aload #7
    //   64: getfield b : Lb/k/d/a;
    //   67: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   70: istore_3
    //   71: iload_3
    //   72: iconst_m1
    //   73: if_icmpeq -> 123
    //   76: aload_2
    //   77: ifnull -> 123
    //   80: aload_2
    //   81: iload_3
    //   82: invokevirtual get : (I)Ljava/lang/Object;
    //   85: checkcast java/lang/Boolean
    //   88: invokevirtual booleanValue : ()Z
    //   91: ifeq -> 123
    //   94: aload_0
    //   95: getfield L : Ljava/util/ArrayList;
    //   98: iload #4
    //   100: invokevirtual remove : (I)Ljava/lang/Object;
    //   103: pop
    //   104: iload #4
    //   106: iconst_1
    //   107: isub
    //   108: istore #5
    //   110: iload #6
    //   112: iconst_1
    //   113: isub
    //   114: istore_3
    //   115: aload #7
    //   117: invokevirtual c : ()V
    //   120: goto -> 248
    //   123: aload #7
    //   125: invokevirtual e : ()Z
    //   128: ifne -> 166
    //   131: iload #6
    //   133: istore_3
    //   134: iload #4
    //   136: istore #5
    //   138: aload_1
    //   139: ifnull -> 248
    //   142: iload #6
    //   144: istore_3
    //   145: iload #4
    //   147: istore #5
    //   149: aload #7
    //   151: getfield b : Lb/k/d/a;
    //   154: aload_1
    //   155: iconst_0
    //   156: aload_1
    //   157: invokevirtual size : ()I
    //   160: invokevirtual v : (Ljava/util/ArrayList;II)Z
    //   163: ifeq -> 248
    //   166: aload_0
    //   167: getfield L : Ljava/util/ArrayList;
    //   170: iload #4
    //   172: invokevirtual remove : (I)Ljava/lang/Object;
    //   175: pop
    //   176: iload #4
    //   178: iconst_1
    //   179: isub
    //   180: istore #5
    //   182: iload #6
    //   184: iconst_1
    //   185: isub
    //   186: istore_3
    //   187: aload_1
    //   188: ifnull -> 243
    //   191: aload #7
    //   193: getfield a : Z
    //   196: ifne -> 243
    //   199: aload_1
    //   200: aload #7
    //   202: getfield b : Lb/k/d/a;
    //   205: invokevirtual indexOf : (Ljava/lang/Object;)I
    //   208: istore #4
    //   210: iload #4
    //   212: iconst_m1
    //   213: if_icmpeq -> 243
    //   216: aload_2
    //   217: ifnull -> 243
    //   220: aload_2
    //   221: iload #4
    //   223: invokevirtual get : (I)Ljava/lang/Object;
    //   226: checkcast java/lang/Boolean
    //   229: invokevirtual booleanValue : ()Z
    //   232: ifeq -> 243
    //   235: aload #7
    //   237: invokevirtual c : ()V
    //   240: goto -> 248
    //   243: aload #7
    //   245: invokevirtual d : ()V
    //   248: iload #5
    //   250: iconst_1
    //   251: iadd
    //   252: istore #4
    //   254: iload_3
    //   255: istore #6
    //   257: goto -> 28
    //   260: return
  }
  
  public void f1() {
    boolean bool1;
    boolean bool2;
    synchronized (this.a) {
      ArrayList<p> arrayList = this.L;
      bool2 = false;
      if (arrayList != null && !arrayList.isEmpty()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (this.a.size() == 1)
        bool2 = true; 
    } 
    if (bool1 || bool2) {
      this.r.l().removeCallbacks(this.N);
      this.r.l().post(this.N);
      m1();
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_3} */
  }
  
  public void g(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    b.k.d.p p = w(paramFragment);
    paramFragment.D = this;
    this.c.p(p);
    if (!paramFragment.L) {
      this.c.a(paramFragment);
      paramFragment.m = false;
      if (paramFragment.S == null)
        paramFragment.X = false; 
      if (F0(paramFragment))
        this.D = true; 
    } 
  }
  
  public Fragment g0(String paramString) {
    return this.c.f(paramString);
  }
  
  public void g1(Fragment paramFragment, boolean paramBoolean) {
    ViewGroup viewGroup = p0(paramFragment);
    if (viewGroup != null && viewGroup instanceof FragmentContainerView)
      ((FragmentContainerView)viewGroup).setDrawDisappearingViewsLast(paramBoolean ^ true); 
  }
  
  public void h(b.k.d.n paramn) {
    this.p.add(paramn);
  }
  
  public Fragment h0(int paramInt) {
    return this.c.g(paramInt);
  }
  
  public void h1(Fragment paramFragment, b.n.d.c paramc) {
    if (paramFragment.equals(g0(paramFragment.f)) && (paramFragment.E == null || paramFragment.D == this)) {
      paramFragment.b0 = paramc;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void i(Fragment paramFragment) {
    this.M.e(paramFragment);
  }
  
  public Fragment i0(String paramString) {
    return this.c.h(paramString);
  }
  
  public void i1(Fragment paramFragment) {
    if (paramFragment == null || (paramFragment.equals(g0(paramFragment.f)) && (paramFragment.E == null || paramFragment.D == this))) {
      Fragment fragment = this.u;
      this.u = paramFragment;
      M(fragment);
      M(this.u);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public int j() {
    return this.i.getAndIncrement();
  }
  
  public Fragment j0(String paramString) {
    return this.c.i(paramString);
  }
  
  public final void j1(Fragment paramFragment) {
    ViewGroup viewGroup = p0(paramFragment);
    if (viewGroup != null && paramFragment.E() > 0) {
      int n = b.k.b.c;
      if (viewGroup.getTag(n) == null)
        viewGroup.setTag(n, paramFragment); 
      ((Fragment)viewGroup.getTag(n)).I1(paramFragment.E());
    } 
  }
  
  @SuppressLint({"SyntheticAccessor"})
  public void k(b.k.d.i<?> parami, b.k.d.f paramf, Fragment paramFragment) {
    if (this.r == null) {
      this.r = parami;
      this.s = paramf;
      this.t = paramFragment;
      if (paramFragment != null) {
        h(new i(this, paramFragment));
      } else if (parami instanceof b.k.d.n) {
        h((b.k.d.n)parami);
      } 
      if (this.t != null)
        m1(); 
      if (parami instanceof b.a.c) {
        Fragment fragment;
        b.a.c c = (b.a.c)parami;
        OnBackPressedDispatcher onBackPressedDispatcher = c.c();
        this.g = onBackPressedDispatcher;
        if (paramFragment != null)
          fragment = paramFragment; 
        onBackPressedDispatcher.a(fragment, this.h);
      } 
      if (paramFragment != null) {
        this.M = paramFragment.D.n0(paramFragment);
      } else if (parami instanceof v) {
        this.M = b.k.d.m.i(((v)parami).h());
      } else {
        this.M = new b.k.d.m(false);
      } 
      this.M.n(J0());
      this.c.x(this.M);
      parami = this.r;
      if (parami instanceof b.a.e.d) {
        b.a.e.c c = ((b.a.e.d)parami).f();
        if (paramFragment != null) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramFragment.f);
          stringBuilder1.append(":");
          str = stringBuilder1.toString();
        } else {
          str = "";
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentManager:");
        stringBuilder.append(str);
        String str = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartActivityForResult");
        this.z = c.i(stringBuilder.toString(), (b.a.e.e.a)new b.a.e.e.c(), new j(this));
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartIntentSenderForResult");
        this.A = c.i(stringBuilder.toString(), new k(), new a(this));
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("RequestPermissions");
        this.B = c.i(stringBuilder.toString(), (b.a.e.e.a)new b.a.e.e.b(), new b(this));
      } 
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public final void k0() {
    if (P) {
      Iterator<x> iterator = s().iterator();
      while (iterator.hasNext())
        ((x)iterator.next()).k(); 
    } else if (this.L != null) {
      while (!this.L.isEmpty())
        ((p)this.L.remove(0)).d(); 
    } 
  }
  
  public void k1(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.K) {
      paramFragment.K = false;
      paramFragment.X ^= 0x1;
    } 
  }
  
  public void l(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.L) {
      paramFragment.L = false;
      if (!paramFragment.l) {
        this.c.a(paramFragment);
        if (E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("add from attach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (F0(paramFragment))
          this.D = true; 
      } 
    } 
  }
  
  public final boolean l0(ArrayList<b.k.d.a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    synchronized (this.a) {
      boolean bool = this.a.isEmpty();
      int n = 0;
      if (bool)
        return false; 
      int i1 = this.a.size();
      bool = false;
      while (n < i1) {
        bool |= ((n)this.a.get(n)).a(paramArrayList, paramArrayList1);
        n++;
      } 
      this.a.clear();
      this.r.l().removeCallbacks(this.N);
      return bool;
    } 
  }
  
  public final void l1() {
    Iterator<b.k.d.p> iterator = this.c.k().iterator();
    while (iterator.hasNext())
      R0(iterator.next()); 
  }
  
  public r m() {
    return (r)new b.k.d.a(this);
  }
  
  public int m0() {
    ArrayList<b.k.d.a> arrayList = this.d;
    return (arrayList != null) ? arrayList.size() : 0;
  }
  
  public final void m1() {
    ArrayList<n> arrayList;
    b.a.b b1;
    synchronized (this.a) {
      boolean bool1 = this.a.isEmpty();
      boolean bool = true;
      if (!bool1) {
        this.h.f(true);
        return;
      } 
      b1 = this.h;
      if (m0() <= 0 || !H0(this.t))
        bool = false; 
      b1.f(bool);
      return;
    } 
  }
  
  public final void n(Fragment paramFragment) {
    HashSet hashSet = this.m.get(paramFragment);
    if (hashSet != null) {
      Iterator<b.h.j.b> iterator = hashSet.iterator();
      while (iterator.hasNext())
        ((b.h.j.b)iterator.next()).a(); 
      hashSet.clear();
      x(paramFragment);
      this.m.remove(paramFragment);
    } 
  }
  
  public final b.k.d.m n0(Fragment paramFragment) {
    return this.M.h(paramFragment);
  }
  
  public boolean o() {
    Iterator<Fragment> iterator = this.c.l().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = F0(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  public b.k.d.f o0() {
    return this.s;
  }
  
  public final void p() {
    if (!J0())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  public final ViewGroup p0(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.R;
    if (viewGroup != null)
      return viewGroup; 
    if (paramFragment.I <= 0)
      return null; 
    if (this.s.g()) {
      View view = this.s.e(paramFragment.I);
      if (view instanceof ViewGroup)
        return (ViewGroup)view; 
    } 
    return null;
  }
  
  public final void q() {
    this.b = false;
    this.J.clear();
    this.I.clear();
  }
  
  public b.k.d.h q0() {
    b.k.d.h h1 = this.v;
    if (h1 != null)
      return h1; 
    Fragment fragment = this.t;
    return (fragment != null) ? fragment.D.q0() : this.w;
  }
  
  public final void r(String paramString) {
    this.j.remove(paramString);
  }
  
  public q r0() {
    return this.c;
  }
  
  public final Set<x> s() {
    HashSet<x> hashSet = new HashSet();
    Iterator iterator = this.c.k().iterator();
    while (iterator.hasNext()) {
      ViewGroup viewGroup = (((b.k.d.p)iterator.next()).k()).R;
      if (viewGroup != null)
        hashSet.add(x.o(viewGroup, y0())); 
    } 
    return hashSet;
  }
  
  public List<Fragment> s0() {
    return this.c.n();
  }
  
  public final Set<x> t(ArrayList<b.k.d.a> paramArrayList, int paramInt1, int paramInt2) {
    HashSet<x> hashSet = new HashSet();
    while (paramInt1 < paramInt2) {
      Iterator iterator = ((r)paramArrayList.get(paramInt1)).a.iterator();
      while (iterator.hasNext()) {
        Fragment fragment = ((r.a)iterator.next()).b;
        if (fragment != null) {
          ViewGroup viewGroup = fragment.R;
          if (viewGroup != null)
            hashSet.add(x.n(viewGroup, this)); 
        } 
      } 
      paramInt1++;
    } 
    return hashSet;
  }
  
  public b.k.d.i<?> t0() {
    return this.r;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.t;
    if (fragment != null) {
      stringBuilder.append(fragment.getClass().getSimpleName());
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this.t)));
      stringBuilder.append("}");
    } else {
      b.k.d.i<?> i1 = this.r;
      if (i1 != null) {
        stringBuilder.append(i1.getClass().getSimpleName());
        stringBuilder.append("{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this.r)));
        stringBuilder.append("}");
      } else {
        stringBuilder.append("null");
      } 
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void u(b.k.d.a parama, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      parama.r(paramBoolean3);
    } else {
      parama.q();
    } 
    ArrayList<b.k.d.a> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(parama);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2 && this.q >= 1)
      s.C(this.r.k(), this.s, arrayList, arrayList1, 0, 1, true, this.n); 
    if (paramBoolean3)
      N0(this.q, true); 
    for (Fragment fragment : this.c.l()) {
      if (fragment != null && fragment.S != null && fragment.W && parama.u(fragment.I)) {
        float f1 = fragment.Y;
        if (f1 > 0.0F)
          fragment.S.setAlpha(f1); 
        if (paramBoolean3) {
          fragment.Y = 0.0F;
          continue;
        } 
        fragment.Y = -1.0F;
        fragment.W = false;
      } 
    } 
  }
  
  public LayoutInflater.Factory2 u0() {
    return (LayoutInflater.Factory2)this.f;
  }
  
  public final void v(Fragment paramFragment) {
    // Byte code:
    //   0: aload_1
    //   1: getfield S : Landroid/view/View;
    //   4: ifnull -> 195
    //   7: aload_0
    //   8: getfield r : Lb/k/d/i;
    //   11: invokevirtual k : ()Landroid/content/Context;
    //   14: aload_1
    //   15: aload_1
    //   16: getfield K : Z
    //   19: iconst_1
    //   20: ixor
    //   21: invokestatic b : (Landroid/content/Context;Landroidx/fragment/app/Fragment;Z)Lb/k/d/e$d;
    //   24: astore_3
    //   25: aload_3
    //   26: ifnull -> 131
    //   29: aload_3
    //   30: getfield b : Landroid/animation/Animator;
    //   33: astore #4
    //   35: aload #4
    //   37: ifnull -> 131
    //   40: aload #4
    //   42: aload_1
    //   43: getfield S : Landroid/view/View;
    //   46: invokevirtual setTarget : (Ljava/lang/Object;)V
    //   49: aload_1
    //   50: getfield K : Z
    //   53: ifeq -> 113
    //   56: aload_1
    //   57: invokevirtual e0 : ()Z
    //   60: ifeq -> 71
    //   63: aload_1
    //   64: iconst_0
    //   65: invokevirtual G1 : (Z)V
    //   68: goto -> 121
    //   71: aload_1
    //   72: getfield R : Landroid/view/ViewGroup;
    //   75: astore #4
    //   77: aload_1
    //   78: getfield S : Landroid/view/View;
    //   81: astore #5
    //   83: aload #4
    //   85: aload #5
    //   87: invokevirtual startViewTransition : (Landroid/view/View;)V
    //   90: aload_3
    //   91: getfield b : Landroid/animation/Animator;
    //   94: new androidx/fragment/app/FragmentManager$h
    //   97: dup
    //   98: aload_0
    //   99: aload #4
    //   101: aload #5
    //   103: aload_1
    //   104: invokespecial <init> : (Landroidx/fragment/app/FragmentManager;Landroid/view/ViewGroup;Landroid/view/View;Landroidx/fragment/app/Fragment;)V
    //   107: invokevirtual addListener : (Landroid/animation/Animator$AnimatorListener;)V
    //   110: goto -> 121
    //   113: aload_1
    //   114: getfield S : Landroid/view/View;
    //   117: iconst_0
    //   118: invokevirtual setVisibility : (I)V
    //   121: aload_3
    //   122: getfield b : Landroid/animation/Animator;
    //   125: invokevirtual start : ()V
    //   128: goto -> 195
    //   131: aload_3
    //   132: ifnull -> 153
    //   135: aload_1
    //   136: getfield S : Landroid/view/View;
    //   139: aload_3
    //   140: getfield a : Landroid/view/animation/Animation;
    //   143: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   146: aload_3
    //   147: getfield a : Landroid/view/animation/Animation;
    //   150: invokevirtual start : ()V
    //   153: aload_1
    //   154: getfield K : Z
    //   157: ifeq -> 173
    //   160: aload_1
    //   161: invokevirtual e0 : ()Z
    //   164: ifne -> 173
    //   167: bipush #8
    //   169: istore_2
    //   170: goto -> 175
    //   173: iconst_0
    //   174: istore_2
    //   175: aload_1
    //   176: getfield S : Landroid/view/View;
    //   179: iload_2
    //   180: invokevirtual setVisibility : (I)V
    //   183: aload_1
    //   184: invokevirtual e0 : ()Z
    //   187: ifeq -> 195
    //   190: aload_1
    //   191: iconst_0
    //   192: invokevirtual G1 : (Z)V
    //   195: aload_1
    //   196: getfield l : Z
    //   199: ifeq -> 215
    //   202: aload_0
    //   203: aload_1
    //   204: invokevirtual F0 : (Landroidx/fragment/app/Fragment;)Z
    //   207: ifeq -> 215
    //   210: aload_0
    //   211: iconst_1
    //   212: putfield D : Z
    //   215: aload_1
    //   216: iconst_0
    //   217: putfield X : Z
    //   220: aload_1
    //   221: aload_1
    //   222: getfield K : Z
    //   225: invokevirtual F0 : (Z)V
    //   228: return
  }
  
  public b.k.d.k v0() {
    return this.o;
  }
  
  public b.k.d.p w(Fragment paramFragment) {
    b.k.d.p p2 = this.c.m(paramFragment.f);
    if (p2 != null)
      return p2; 
    b.k.d.p p1 = new b.k.d.p(this.o, this.c, paramFragment);
    p1.o(this.r.k().getClassLoader());
    p1.t(this.q);
    return p1;
  }
  
  public Fragment w0() {
    return this.t;
  }
  
  public final void x(Fragment paramFragment) {
    paramFragment.e1();
    this.o.n(paramFragment, false);
    paramFragment.R = null;
    paramFragment.S = null;
    paramFragment.d0 = null;
    paramFragment.e0.n(null);
    paramFragment.o = false;
  }
  
  public Fragment x0() {
    return this.u;
  }
  
  public void y(Fragment paramFragment) {
    if (E0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.L) {
      paramFragment.L = true;
      if (paramFragment.l) {
        if (E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.c.s(paramFragment);
        if (F0(paramFragment))
          this.D = true; 
        j1(paramFragment);
      } 
    } 
  }
  
  public y y0() {
    y y1 = this.x;
    if (y1 != null)
      return y1; 
    Fragment fragment = this.t;
    return (fragment != null) ? fragment.D.y0() : this.y;
  }
  
  public void z() {
    this.E = false;
    this.F = false;
    this.M.n(false);
    T(4);
  }
  
  @SuppressLint({"BanParcelableUsage"})
  public static class LaunchedFragmentInfo implements Parcelable {
    public static final Parcelable.Creator<LaunchedFragmentInfo> CREATOR = new a();
    
    public String a;
    
    public int b;
    
    public LaunchedFragmentInfo(Parcel param1Parcel) {
      this.a = param1Parcel.readString();
      this.b = param1Parcel.readInt();
    }
    
    public LaunchedFragmentInfo(String param1String, int param1Int) {
      this.a = param1String;
      this.b = param1Int;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.a);
      param1Parcel.writeInt(this.b);
    }
    
    public class a implements Parcelable.Creator<LaunchedFragmentInfo> {
      public FragmentManager.LaunchedFragmentInfo a(Parcel param2Parcel) {
        return new FragmentManager.LaunchedFragmentInfo(param2Parcel);
      }
      
      public FragmentManager.LaunchedFragmentInfo[] b(int param2Int) {
        return new FragmentManager.LaunchedFragmentInfo[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<LaunchedFragmentInfo> {
    public FragmentManager.LaunchedFragmentInfo a(Parcel param1Parcel) {
      return new FragmentManager.LaunchedFragmentInfo(param1Parcel);
    }
    
    public FragmentManager.LaunchedFragmentInfo[] b(int param1Int) {
      return new FragmentManager.LaunchedFragmentInfo[param1Int];
    }
  }
  
  public class a implements b.a.e.a<ActivityResult> {
    public a(FragmentManager this$0) {}
    
    public void b(ActivityResult param1ActivityResult) {
      StringBuilder stringBuilder;
      FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = this.a.C.pollFirst();
      if (launchedFragmentInfo == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No IntentSenders were started for ");
        stringBuilder.append(this);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      String str = launchedFragmentInfo.a;
      int i = launchedFragmentInfo.b;
      Fragment fragment = FragmentManager.c(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Intent Sender result delivered for unknown Fragment ");
        stringBuilder.append(str);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.q0(i, stringBuilder.d(), stringBuilder.c());
    }
  }
  
  public class b implements b.a.e.a<Map<String, Boolean>> {
    public b(FragmentManager this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void b(Map<String, Boolean> param1Map) {
      StringBuilder stringBuilder;
      String[] arrayOfString = (String[])param1Map.keySet().toArray((Object[])new String[0]);
      ArrayList<Boolean> arrayList = new ArrayList(param1Map.values());
      int[] arrayOfInt = new int[arrayList.size()];
      int i;
      for (i = 0; i < arrayList.size(); i++) {
        byte b1;
        if (((Boolean)arrayList.get(i)).booleanValue()) {
          b1 = 0;
        } else {
          b1 = -1;
        } 
        arrayOfInt[i] = b1;
      } 
      FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = this.a.C.pollFirst();
      if (launchedFragmentInfo == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No permissions were requested for ");
        stringBuilder.append(this);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      String str = launchedFragmentInfo.a;
      i = launchedFragmentInfo.b;
      Fragment fragment = FragmentManager.c(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Permission request result delivered for unknown Fragment ");
        stringBuilder.append(str);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.P0(i, arrayOfString, (int[])stringBuilder);
    }
  }
  
  public class c extends b.a.b {
    public c(FragmentManager this$0, boolean param1Boolean) {
      super(param1Boolean);
    }
    
    public void b() {
      this.c.B0();
    }
  }
  
  public class d implements s.g {
    public d(FragmentManager this$0) {}
    
    public void a(Fragment param1Fragment, b.h.j.b param1b) {
      if (!param1b.b())
        this.a.X0(param1Fragment, param1b); 
    }
    
    public void b(Fragment param1Fragment, b.h.j.b param1b) {
      this.a.f(param1Fragment, param1b);
    }
  }
  
  public class e extends b.k.d.h {
    public e(FragmentManager this$0) {}
    
    public Fragment a(ClassLoader param1ClassLoader, String param1String) {
      return this.b.t0().d(this.b.t0().k(), param1String, null);
    }
  }
  
  public class f implements y {
    public f(FragmentManager this$0) {}
    
    public x a(ViewGroup param1ViewGroup) {
      return (x)new b.k.d.b(param1ViewGroup);
    }
  }
  
  public class g implements Runnable {
    public g(FragmentManager this$0) {}
    
    public void run() {
      this.a.b0(true);
    }
  }
  
  public class h extends AnimatorListenerAdapter {
    public h(FragmentManager this$0, ViewGroup param1ViewGroup, View param1View, Fragment param1Fragment) {}
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.endViewTransition(this.b);
      param1Animator.removeListener((Animator.AnimatorListener)this);
      Fragment fragment = this.c;
      View view = fragment.S;
      if (view != null && fragment.K)
        view.setVisibility(8); 
    }
  }
  
  public class i implements b.k.d.n {
    public i(FragmentManager this$0, Fragment param1Fragment) {}
    
    public void b(FragmentManager param1FragmentManager, Fragment param1Fragment) {
      this.a.t0(param1Fragment);
    }
  }
  
  public class j implements b.a.e.a<ActivityResult> {
    public j(FragmentManager this$0) {}
    
    public void b(ActivityResult param1ActivityResult) {
      StringBuilder stringBuilder;
      FragmentManager.LaunchedFragmentInfo launchedFragmentInfo = this.a.C.pollFirst();
      if (launchedFragmentInfo == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No Activities were started for result for ");
        stringBuilder.append(this);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      String str = launchedFragmentInfo.a;
      int i = launchedFragmentInfo.b;
      Fragment fragment = FragmentManager.c(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result delivered for unknown Fragment ");
        stringBuilder.append(str);
        Log.w("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.q0(i, stringBuilder.d(), stringBuilder.c());
    }
  }
  
  public static class k extends b.a.e.e.a<IntentSenderRequest, ActivityResult> {
    public Intent d(Context param1Context, IntentSenderRequest param1IntentSenderRequest) {
      Intent intent1 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
      Intent intent2 = param1IntentSenderRequest.c();
      IntentSenderRequest intentSenderRequest = param1IntentSenderRequest;
      if (intent2 != null) {
        Bundle bundle = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intentSenderRequest = param1IntentSenderRequest;
        if (bundle != null) {
          intent1.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
          intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
          intentSenderRequest = param1IntentSenderRequest;
          if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
            IntentSenderRequest.b b = new IntentSenderRequest.b(param1IntentSenderRequest.h());
            b.b(null);
            b.c(param1IntentSenderRequest.f(), param1IntentSenderRequest.d());
            intentSenderRequest = b.a();
          } 
        } 
      } 
      intent1.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", (Parcelable)intentSenderRequest);
      if (FragmentManager.E0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CreateIntent created the following intent: ");
        stringBuilder.append(intent1);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return intent1;
    }
    
    public ActivityResult e(int param1Int, Intent param1Intent) {
      return new ActivityResult(param1Int, param1Intent);
    }
  }
  
  public static abstract class l {
    @Deprecated
    public abstract void a(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle);
    
    public abstract void b(FragmentManager param1FragmentManager, Fragment param1Fragment, Context param1Context);
    
    public abstract void c(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle);
    
    public abstract void d(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void e(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void f(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void g(FragmentManager param1FragmentManager, Fragment param1Fragment, Context param1Context);
    
    public abstract void h(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle);
    
    public abstract void i(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void j(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle);
    
    public abstract void k(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void l(FragmentManager param1FragmentManager, Fragment param1Fragment);
    
    public abstract void m(FragmentManager param1FragmentManager, Fragment param1Fragment, View param1View, Bundle param1Bundle);
    
    public abstract void n(FragmentManager param1FragmentManager, Fragment param1Fragment);
  }
  
  public static interface m {
    void a();
  }
  
  public static interface n {
    boolean a(ArrayList<b.k.d.a> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  public class o implements n {
    public final String a;
    
    public final int b;
    
    public final int c;
    
    public o(FragmentManager this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public boolean a(ArrayList<b.k.d.a> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      Fragment fragment = this.d.u;
      return (fragment != null && this.b < 0 && this.a == null && fragment.s().T0()) ? false : this.d.V0(param1ArrayList, param1ArrayList1, this.a, this.b, this.c);
    }
  }
  
  public static class p implements Fragment.g {
    public final boolean a;
    
    public final b.k.d.a b;
    
    public int c;
    
    public p(b.k.d.a param1a, boolean param1Boolean) {
      this.a = param1Boolean;
      this.b = param1a;
    }
    
    public void a() {
      this.c++;
    }
    
    public void b() {
      int i = this.c - 1;
      this.c = i;
      if (i != 0)
        return; 
      this.b.q.f1();
    }
    
    public void c() {
      b.k.d.a a1 = this.b;
      a1.q.u(a1, this.a, false, false);
    }
    
    public void d() {
      boolean bool;
      if (this.c > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      for (Fragment fragment : this.b.q.s0()) {
        fragment.K1(null);
        if (bool && fragment.i0())
          fragment.S1(); 
      } 
      b.k.d.a a1 = this.b;
      a1.q.u(a1, this.a, bool ^ true, true);
    }
    
    public boolean e() {
      return (this.c == 0);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\fragment\app\FragmentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */