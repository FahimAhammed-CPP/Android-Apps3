package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import b.k.d.r;
import b.n.d;
import java.util.ArrayList;

@SuppressLint({"BanParcelableUsage"})
public final class BackStackState implements Parcelable {
  public static final Parcelable.Creator<BackStackState> CREATOR = new a();
  
  public final int[] a;
  
  public final ArrayList<String> b;
  
  public final int[] c;
  
  public final int[] d;
  
  public final int e;
  
  public final String f;
  
  public final int g;
  
  public final int h;
  
  public final CharSequence i;
  
  public final int j;
  
  public final CharSequence k;
  
  public final ArrayList<String> l;
  
  public final ArrayList<String> m;
  
  public final boolean n;
  
  public BackStackState(Parcel paramParcel) {
    boolean bool;
    this.a = paramParcel.createIntArray();
    this.b = paramParcel.createStringArrayList();
    this.c = paramParcel.createIntArray();
    this.d = paramParcel.createIntArray();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readString();
    this.g = paramParcel.readInt();
    this.h = paramParcel.readInt();
    this.i = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.j = paramParcel.readInt();
    this.k = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.l = paramParcel.createStringArrayList();
    this.m = paramParcel.createStringArrayList();
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.n = bool;
  }
  
  public BackStackState(b.k.d.a parama) {
    int i = ((r)parama).a.size();
    this.a = new int[i * 5];
    if (((r)parama).g) {
      this.b = new ArrayList<String>(i);
      this.c = new int[i];
      this.d = new int[i];
      int j = 0;
      for (int k = 0; j < i; k++) {
        r.a a1 = ((r)parama).a.get(j);
        int[] arrayOfInt2 = this.a;
        int m = k + 1;
        arrayOfInt2[k] = a1.a;
        ArrayList<String> arrayList = this.b;
        Fragment fragment = a1.b;
        if (fragment != null) {
          String str = fragment.f;
        } else {
          fragment = null;
        } 
        arrayList.add(fragment);
        int[] arrayOfInt1 = this.a;
        k = m + 1;
        arrayOfInt1[m] = a1.c;
        m = k + 1;
        arrayOfInt1[k] = a1.d;
        k = m + 1;
        arrayOfInt1[m] = a1.e;
        arrayOfInt1[k] = a1.f;
        this.c[j] = a1.g.ordinal();
        this.d[j] = a1.h.ordinal();
        j++;
      } 
      this.e = ((r)parama).f;
      this.f = ((r)parama).h;
      this.g = parama.s;
      this.h = ((r)parama).i;
      this.i = ((r)parama).j;
      this.j = ((r)parama).k;
      this.k = ((r)parama).l;
      this.l = ((r)parama).m;
      this.m = ((r)parama).n;
      this.n = ((r)parama).o;
      return;
    } 
    IllegalStateException illegalStateException = new IllegalStateException("Not on back stack");
    throw illegalStateException;
  }
  
  public b.k.d.a c(FragmentManager paramFragmentManager) {
    b.k.d.a a = new b.k.d.a(paramFragmentManager);
    int j = 0;
    int i = 0;
    while (true) {
      int[] arrayOfInt = this.a;
      if (j < arrayOfInt.length) {
        r.a a1 = new r.a();
        int m = j + 1;
        a1.a = arrayOfInt[j];
        if (FragmentManager.E0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Instantiate ");
          stringBuilder.append(a);
          stringBuilder.append(" op #");
          stringBuilder.append(i);
          stringBuilder.append(" base fragment #");
          stringBuilder.append(this.a[m]);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        String str = this.b.get(i);
        if (str != null) {
          a1.b = paramFragmentManager.g0(str);
        } else {
          a1.b = null;
        } 
        a1.g = d.c.values()[this.c[i]];
        a1.h = d.c.values()[this.d[i]];
        int[] arrayOfInt1 = this.a;
        int k = m + 1;
        j = arrayOfInt1[m];
        a1.c = j;
        int n = k + 1;
        m = arrayOfInt1[k];
        a1.d = m;
        k = n + 1;
        n = arrayOfInt1[n];
        a1.e = n;
        int i1 = arrayOfInt1[k];
        a1.f = i1;
        ((r)a).b = j;
        ((r)a).c = m;
        ((r)a).d = n;
        ((r)a).e = i1;
        a.e(a1);
        i++;
        j = k + 1;
        continue;
      } 
      ((r)a).f = this.e;
      ((r)a).h = this.f;
      a.s = this.g;
      ((r)a).g = true;
      ((r)a).i = this.h;
      ((r)a).j = this.i;
      ((r)a).k = this.j;
      ((r)a).l = this.k;
      ((r)a).m = this.l;
      ((r)a).n = this.m;
      ((r)a).o = this.n;
      a.m(1);
      return a;
    } 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  public class a implements Parcelable.Creator<BackStackState> {
    public BackStackState a(Parcel param1Parcel) {
      return new BackStackState(param1Parcel);
    }
    
    public BackStackState[] b(int param1Int) {
      return new BackStackState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\fragment\app\BackStackState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */