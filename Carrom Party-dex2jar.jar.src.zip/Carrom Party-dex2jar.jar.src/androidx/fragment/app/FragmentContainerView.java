package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import b.k.c;
import b.k.d.r;
import java.util.ArrayList;

public final class FragmentContainerView extends FrameLayout {
  public ArrayList<View> a;
  
  public ArrayList<View> b;
  
  public boolean c = true;
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    if (paramAttributeSet != null) {
      String str1;
      String str2;
      String str3 = paramAttributeSet.getClassAttribute();
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c.e);
      if (str3 == null) {
        str2 = typedArray.getString(c.f);
        str1 = "android:name";
      } else {
        str1 = "class";
        str2 = str3;
      } 
      typedArray.recycle();
      if (str2 != null) {
        if (isInEditMode())
          return; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentContainerView must be within a FragmentActivity to use ");
        stringBuilder.append(str1);
        stringBuilder.append("=\"");
        stringBuilder.append(str2);
        stringBuilder.append("\"");
        throw new UnsupportedOperationException(stringBuilder.toString());
      } 
    } 
  }
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet, FragmentManager paramFragmentManager) {
    super(paramContext, paramAttributeSet);
    String str2 = paramAttributeSet.getClassAttribute();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c.e);
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(c.f); 
    str2 = typedArray.getString(c.g);
    typedArray.recycle();
    int i = getId();
    Fragment fragment = paramFragmentManager.h0(i);
    if (str1 != null && fragment == null) {
      String str;
      StringBuilder stringBuilder;
      if (i <= 0) {
        if (str2 != null) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" with tag ");
          stringBuilder1.append(str2);
          str = stringBuilder1.toString();
        } else {
          str = "";
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentContainerView must have an android:id to add Fragment ");
        stringBuilder.append(str1);
        stringBuilder.append(str);
        throw new IllegalStateException(stringBuilder.toString());
      } 
      Fragment fragment1 = paramFragmentManager.q0().a(str.getClassLoader(), str1);
      fragment1.H0((Context)str, (AttributeSet)stringBuilder, null);
      r r = paramFragmentManager.m();
      r.l(true);
      r.c((ViewGroup)this, fragment1, str2);
      r.h();
    } 
  }
  
  public final void a(View paramView) {
    ArrayList<View> arrayList = this.b;
    if (arrayList != null && arrayList.contains(paramView)) {
      if (this.a == null)
        this.a = new ArrayList<View>(); 
      this.a.add(paramView);
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (FragmentManager.z0(paramView) != null) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    if (FragmentManager.z0(paramView) != null)
      return super.addViewInLayout(paramView, paramInt, paramLayoutParams, paramBoolean); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    if (this.c && this.a != null)
      for (int i = 0; i < this.a.size(); i++)
        super.drawChild(paramCanvas, this.a.get(i), getDrawingTime());  
    super.dispatchDraw(paramCanvas);
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    if (this.c) {
      ArrayList<View> arrayList = this.a;
      if (arrayList != null && arrayList.size() > 0 && this.a.contains(paramView))
        return false; 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void endViewTransition(View paramView) {
    ArrayList<View> arrayList = this.b;
    if (arrayList != null) {
      arrayList.remove(paramView);
      arrayList = this.a;
      if (arrayList != null && arrayList.remove(paramView))
        this.c = true; 
    } 
    super.endViewTransition(paramView);
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    for (int i = 0; i < getChildCount(); i++)
      getChildAt(i).dispatchApplyWindowInsets(new WindowInsets(paramWindowInsets)); 
    return paramWindowInsets;
  }
  
  public void removeAllViewsInLayout() {
    for (int i = getChildCount() - 1; i >= 0; i--)
      a(getChildAt(i)); 
    super.removeAllViewsInLayout();
  }
  
  public void removeDetachedView(View paramView, boolean paramBoolean) {
    if (paramBoolean)
      a(paramView); 
    super.removeDetachedView(paramView, paramBoolean);
  }
  
  public void removeView(View paramView) {
    a(paramView);
    super.removeView(paramView);
  }
  
  public void removeViewAt(int paramInt) {
    a(getChildAt(paramInt));
    super.removeViewAt(paramInt);
  }
  
  public void removeViewInLayout(View paramView) {
    a(paramView);
    super.removeViewInLayout(paramView);
  }
  
  public void removeViews(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViews(paramInt1, paramInt2);
  }
  
  public void removeViewsInLayout(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++)
      a(getChildAt(i)); 
    super.removeViewsInLayout(paramInt1, paramInt2);
  }
  
  public void setDrawDisappearingViewsLast(boolean paramBoolean) {
    this.c = paramBoolean;
  }
  
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    if (Build.VERSION.SDK_INT < 18) {
      super.setLayoutTransition(paramLayoutTransition);
      return;
    } 
    throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
  }
  
  public void startViewTransition(View paramView) {
    if (paramView.getParent() == this) {
      if (this.b == null)
        this.b = new ArrayList<View>(); 
      this.b.add(paramView);
    } 
    super.startViewTransition(paramView);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\fragment\app\FragmentContainerView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */