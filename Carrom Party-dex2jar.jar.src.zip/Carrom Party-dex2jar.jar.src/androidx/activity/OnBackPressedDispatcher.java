package androidx.activity;

import android.annotation.SuppressLint;
import b.a.b;
import b.n.d;
import b.n.e;
import b.n.f;
import b.n.g;
import java.util.ArrayDeque;
import java.util.Iterator;

public final class OnBackPressedDispatcher {
  public final Runnable a;
  
  public final ArrayDeque<b> b = new ArrayDeque<b>();
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
  }
  
  @SuppressLint({"LambdaLast"})
  public void a(g paramg, b paramb) {
    d d = paramg.a();
    if (d.b() == d.c.a)
      return; 
    paramb.a(new LifecycleOnBackPressedCancellable(this, d, paramb));
  }
  
  public b.a.a b(b paramb) {
    this.b.add(paramb);
    a a = new a(this, paramb);
    paramb.a(a);
    return a;
  }
  
  public void c() {
    Iterator<b> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      b b = iterator.next();
      if (b.c()) {
        b.b();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  public class LifecycleOnBackPressedCancellable implements e, b.a.a {
    public final d a;
    
    public final b b;
    
    public b.a.a c;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, d param1d, b param1b) {
      this.a = param1d;
      this.b = param1b;
      param1d.a((f)this);
    }
    
    public void c(g param1g, d.b param1b) {
      if (param1b == d.b.ON_START) {
        this.c = this.d.b(this.b);
        return;
      } 
      if (param1b == d.b.ON_STOP) {
        b.a.a a1 = this.c;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1b == d.b.ON_DESTROY) {
        cancel();
      } 
    }
    
    public void cancel() {
      this.a.c((f)this);
      this.b.e(this);
      b.a.a a1 = this.c;
      if (a1 != null) {
        a1.cancel();
        this.c = null;
      } 
    }
  }
  
  public class a implements b.a.a {
    public final b a;
    
    public a(OnBackPressedDispatcher this$0, b param1b) {
      this.a = param1b;
    }
    
    public void cancel() {
      this.b.b.remove(this.a);
      this.a.e(this);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */