package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.IntentSenderRequest;
import androidx.savedstate.SavedStateRegistry;
import b.a.c;
import b.a.e.d;
import b.h.e.f;
import b.n.d;
import b.n.e;
import b.n.f;
import b.n.g;
import b.n.h;
import b.n.p;
import b.n.u;
import b.n.v;
import b.n.w;
import b.n.x;
import b.s.c;
import b.s.d;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class ComponentActivity extends f implements g, v, c, c, d {
  public final b.a.d.a b = new b.a.d.a();
  
  public final h c = new h(this);
  
  public final b.s.b d = b.s.b.a(this);
  
  public u e;
  
  public final OnBackPressedDispatcher f = new OnBackPressedDispatcher(new a(this));
  
  public int g;
  
  public b.a.e.c h;
  
  public ComponentActivity() {
    new AtomicInteger();
    this.h = new b(this);
    if (a() != null) {
      int i = Build.VERSION.SDK_INT;
      if (i >= 19)
        a().a((f)new e(this) {
              public void c(g param1g, d.b param1b) {
                if (param1b == d.b.ON_STOP) {
                  Window window = this.a.getWindow();
                  if (window != null) {
                    View view = window.peekDecorView();
                  } else {
                    window = null;
                  } 
                  if (window != null)
                    window.cancelPendingInputEvents(); 
                } 
              }
            }); 
      a().a((f)new e(this) {
            public void c(g param1g, d.b param1b) {
              if (param1b == d.b.ON_DESTROY) {
                this.a.b.b();
                if (!this.a.isChangingConfigurations())
                  this.a.h().a(); 
              } 
            }
          });
      a().a((f)new e(this) {
            public void c(g param1g, d.b param1b) {
              this.a.n();
              this.a.a().c((f)this);
            }
          });
      if (19 <= i && i <= 23)
        a().a((f)new ImmLeaksCleaner((Activity)this)); 
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public d a() {
    return (d)this.c;
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    o();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public final OnBackPressedDispatcher c() {
    return this.f;
  }
  
  public final b.a.e.c f() {
    return this.h;
  }
  
  public u h() {
    if (getApplication() != null) {
      n();
      return this.e;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public final SavedStateRegistry j() {
    return this.d.b();
  }
  
  public final void m(b.a.d.b paramb) {
    this.b.a(paramb);
  }
  
  public void n() {
    if (this.e == null) {
      c c1 = (c)getLastNonConfigurationInstance();
      if (c1 != null)
        this.e = c1.b; 
      if (this.e == null)
        this.e = new u(); 
    } 
  }
  
  public final void o() {
    w.a(getWindow().getDecorView(), this);
    x.a(getWindow().getDecorView(), this);
    d.a(getWindow().getDecorView(), this);
  }
  
  @Deprecated
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.h.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.f.c();
  }
  
  public void onCreate(Bundle paramBundle) {
    this.d.c(paramBundle);
    this.b.c((Context)this);
    super.onCreate(paramBundle);
    this.h.g(paramBundle);
    p.f((Activity)this);
    int i = this.g;
    if (i != 0)
      setContentView(i); 
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.h.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = p();
    u u2 = this.e;
    u u1 = u2;
    if (u2 == null) {
      c c2 = (c)getLastNonConfigurationInstance();
      u1 = u2;
      if (c2 != null)
        u1 = c2.b; 
    } 
    if (u1 == null && object == null)
      return null; 
    c c1 = new c();
    c1.a = object;
    c1.b = u1;
    return c1;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    d d1 = a();
    if (d1 instanceof h)
      ((h)d1).o(d.c.c); 
    super.onSaveInstanceState(paramBundle);
    this.d.d(paramBundle);
    this.h.h(paramBundle);
  }
  
  @Deprecated
  public Object p() {
    return null;
  }
  
  public void reportFullyDrawn() {
    try {
      if (b.v.a.d()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("reportFullyDrawn() for ");
        stringBuilder.append(getComponentName());
        b.v.a.a(stringBuilder.toString());
      } 
      int i = Build.VERSION.SDK_INT;
      if (i > 19) {
        super.reportFullyDrawn();
      } else if (i == 19 && b.h.f.a.a((Context)this, "android.permission.UPDATE_DEVICE_STATS") == 0) {
        super.reportFullyDrawn();
      } 
      return;
    } finally {
      b.v.a.b();
    } 
  }
  
  public void setContentView(int paramInt) {
    o();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    o();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    o();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public class a implements Runnable {
    public a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        ComponentActivity.l(this.a);
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  public class b extends b.a.e.c {
    public b(ComponentActivity this$0) {}
    
    public <I, O> void f(int param1Int, b.a.e.e.a<I, O> param1a, I param1I, b.h.e.b param1b) {
      String[] arrayOfString;
      ArrayList<String> arrayList;
      ComponentActivity componentActivity = this.h;
      b.a.e.e.a.a a1 = param1a.b((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.a((Context)componentActivity, param1I);
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } else if (param1b == null) {
        param1a = null;
      } else {
        param1b.a();
        throw null;
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        if (arrayOfString == null)
          return; 
        arrayList = new ArrayList();
        int j = arrayOfString.length;
        int i;
        for (i = 0; i < j; i++) {
          String str = arrayOfString[i];
          if (this.h.checkPermission(str, Process.myPid(), Process.myUid()) != 0)
            arrayList.add(str); 
        } 
        if (!arrayList.isEmpty()) {
          b.h.e.a.m((Activity)componentActivity, arrayList.<String>toArray(new String[0]), param1Int);
          return;
        } 
      } else {
        IntentSenderRequest intentSenderRequest;
        if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayList.getAction())) {
          intentSenderRequest = (IntentSenderRequest)arrayList.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
          try {
            b.h.e.a.p((Activity)componentActivity, intentSenderRequest.h(), param1Int, intentSenderRequest.c(), intentSenderRequest.d(), intentSenderRequest.f(), 0, (Bundle)arrayOfString);
            return;
          } catch (android.content.IntentSender.SendIntentException sendIntentException) {
            (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
            return;
          } 
        } 
        b.h.e.a.o((Activity)componentActivity, (Intent)intentSenderRequest, param1Int, (Bundle)sendIntentException);
      } 
    }
    
    public class a implements Runnable {
      public a(ComponentActivity.b this$0, int param2Int, b.a.e.e.a.a param2a) {}
      
      public void run() {
        this.c.c(this.a, this.b.a());
      }
    }
    
    public class b implements Runnable {
      public b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.c.b(this.a, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.b));
      }
    }
  }
  
  public class a implements Runnable {
    public a(ComponentActivity this$0, int param1Int, b.a.e.e.a.a param1a) {}
    
    public void run() {
      this.c.c(this.a, this.b.a());
    }
  }
  
  public class b implements Runnable {
    public b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.c.b(this.a, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.b));
    }
  }
  
  public static final class c {
    public Object a;
    
    public u b;
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */