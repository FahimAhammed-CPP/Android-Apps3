package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public final class IntentSenderRequest implements Parcelable {
  public static final Parcelable.Creator<IntentSenderRequest> CREATOR = new a();
  
  public final IntentSender a;
  
  public final Intent b;
  
  public final int c;
  
  public final int d;
  
  public IntentSenderRequest(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.a = paramIntentSender;
    this.b = paramIntent;
    this.c = paramInt1;
    this.d = paramInt2;
  }
  
  public IntentSenderRequest(Parcel paramParcel) {
    this.a = (IntentSender)paramParcel.readParcelable(IntentSender.class.getClassLoader());
    this.b = (Intent)paramParcel.readParcelable(Intent.class.getClassLoader());
    this.c = paramParcel.readInt();
    this.d = paramParcel.readInt();
  }
  
  public Intent c() {
    return this.b;
  }
  
  public int d() {
    return this.c;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public int f() {
    return this.d;
  }
  
  public IntentSender h() {
    return this.a;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable((Parcelable)this.a, paramInt);
    paramParcel.writeParcelable((Parcelable)this.b, paramInt);
    paramParcel.writeInt(this.c);
    paramParcel.writeInt(this.d);
  }
  
  public class a implements Parcelable.Creator<IntentSenderRequest> {
    public IntentSenderRequest a(Parcel param1Parcel) {
      return new IntentSenderRequest(param1Parcel);
    }
    
    public IntentSenderRequest[] b(int param1Int) {
      return new IntentSenderRequest[param1Int];
    }
  }
  
  public static final class b {
    public IntentSender a;
    
    public Intent b;
    
    public int c;
    
    public int d;
    
    public b(IntentSender param1IntentSender) {
      this.a = param1IntentSender;
    }
    
    public IntentSenderRequest a() {
      return new IntentSenderRequest(this.a, this.b, this.c, this.d);
    }
    
    public b b(Intent param1Intent) {
      this.b = param1Intent;
      return this;
    }
    
    public b c(int param1Int1, int param1Int2) {
      this.d = param1Int1;
      this.c = param1Int2;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\activity\result\IntentSenderRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */