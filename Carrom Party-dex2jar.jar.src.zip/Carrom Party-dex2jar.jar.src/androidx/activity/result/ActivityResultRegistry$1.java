package androidx.activity.result;

import b.a.e.a;
import b.a.e.c;
import b.a.e.e.a;
import b.n.d;
import b.n.e;
import b.n.g;

public class ActivityResultRegistry$1 implements e {
  public void c(g paramg, d.b paramb) {
    if (d.b.ON_START.equals(paramb)) {
      this.d.e.put(this.a, new c.b(this.b, this.c));
      if (this.d.f.containsKey(this.a)) {
        paramg = (g)this.d.f.get(this.a);
        this.d.f.remove(this.a);
        this.b.a(paramg);
      } 
      ActivityResult activityResult = (ActivityResult)this.d.g.getParcelable(this.a);
      if (activityResult != null) {
        this.d.g.remove(this.a);
        this.b.a(this.c.c(activityResult.d(), activityResult.c()));
        return;
      } 
    } else {
      if (d.b.ON_STOP.equals(paramb)) {
        this.d.e.remove(this.a);
        return;
      } 
      if (d.b.ON_DESTROY.equals(paramb))
        this.d.k(this.a); 
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\activity\result\ActivityResultRegistry$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */