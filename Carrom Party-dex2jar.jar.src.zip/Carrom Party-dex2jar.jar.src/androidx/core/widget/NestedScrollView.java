package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import b.h.n.a0.d;
import b.h.n.i;
import b.h.n.j;
import b.h.n.l;
import b.h.n.n;
import b.h.n.r;
import b.h.o.d;

public class NestedScrollView extends FrameLayout implements l, i {
  public static final a L = new a();
  
  public static final int[] M = new int[] { 16843130 };
  
  public final int[] C = new int[2];
  
  public final int[] D = new int[2];
  
  public int E;
  
  public int F;
  
  public SavedState G;
  
  public final n H;
  
  public final j I;
  
  public float J;
  
  public b K;
  
  public long a;
  
  public final Rect b = new Rect();
  
  public OverScroller c;
  
  public EdgeEffect d;
  
  public EdgeEffect e;
  
  public int f;
  
  public boolean g = true;
  
  public boolean h = false;
  
  public View i = null;
  
  public boolean j = false;
  
  public VelocityTracker k;
  
  public boolean l;
  
  public boolean m = true;
  
  public int n;
  
  public int o;
  
  public int p;
  
  public int q = -1;
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, b.h.a.b);
  }
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    x();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, M, paramInt, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.H = new n((ViewGroup)this);
    this.I = new j((View)this);
    setNestedScrollingEnabled(true);
    r.O((View)this, L);
  }
  
  public static boolean A(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && A((View)viewParent, paramView2));
  }
  
  public static int d(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.J == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.J = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.J;
  }
  
  public final boolean B(View paramView, int paramInt1, int paramInt2) {
    paramView.getDrawingRect(this.b);
    offsetDescendantRectToMyCoords(paramView, this.b);
    return (this.b.bottom + paramInt1 >= getScrollY() && this.b.top - paramInt1 <= getScrollY() + paramInt2);
  }
  
  public final void C(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int k = getScrollY();
    scrollBy(0, paramInt1);
    k = getScrollY() - k;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + k; 
    this.I.d(0, k, 0, paramInt1 - k, null, paramInt2, paramArrayOfint);
  }
  
  public final void D(MotionEvent paramMotionEvent) {
    int k = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(k) == this.q) {
      if (k == 0) {
        k = 1;
      } else {
        k = 0;
      } 
      this.f = (int)paramMotionEvent.getY(k);
      this.q = paramMotionEvent.getPointerId(k);
      VelocityTracker velocityTracker = this.k;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  public boolean E(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getOverScrollMode : ()I
    //   4: istore #12
    //   6: aload_0
    //   7: invokevirtual computeHorizontalScrollRange : ()I
    //   10: istore #10
    //   12: aload_0
    //   13: invokevirtual computeHorizontalScrollExtent : ()I
    //   16: istore #11
    //   18: iconst_0
    //   19: istore #14
    //   21: iload #10
    //   23: iload #11
    //   25: if_icmple -> 34
    //   28: iconst_1
    //   29: istore #10
    //   31: goto -> 37
    //   34: iconst_0
    //   35: istore #10
    //   37: aload_0
    //   38: invokevirtual computeVerticalScrollRange : ()I
    //   41: aload_0
    //   42: invokevirtual computeVerticalScrollExtent : ()I
    //   45: if_icmple -> 54
    //   48: iconst_1
    //   49: istore #11
    //   51: goto -> 57
    //   54: iconst_0
    //   55: istore #11
    //   57: iload #12
    //   59: ifeq -> 82
    //   62: iload #12
    //   64: iconst_1
    //   65: if_icmpne -> 76
    //   68: iload #10
    //   70: ifeq -> 76
    //   73: goto -> 82
    //   76: iconst_0
    //   77: istore #10
    //   79: goto -> 85
    //   82: iconst_1
    //   83: istore #10
    //   85: iload #12
    //   87: ifeq -> 110
    //   90: iload #12
    //   92: iconst_1
    //   93: if_icmpne -> 104
    //   96: iload #11
    //   98: ifeq -> 104
    //   101: goto -> 110
    //   104: iconst_0
    //   105: istore #11
    //   107: goto -> 113
    //   110: iconst_1
    //   111: istore #11
    //   113: iload_3
    //   114: iload_1
    //   115: iadd
    //   116: istore_3
    //   117: iload #10
    //   119: ifne -> 127
    //   122: iconst_0
    //   123: istore_1
    //   124: goto -> 130
    //   127: iload #7
    //   129: istore_1
    //   130: iload #4
    //   132: iload_2
    //   133: iadd
    //   134: istore #4
    //   136: iload #11
    //   138: ifne -> 146
    //   141: iconst_0
    //   142: istore_2
    //   143: goto -> 149
    //   146: iload #8
    //   148: istore_2
    //   149: iload_1
    //   150: ineg
    //   151: istore #7
    //   153: iload_1
    //   154: iload #5
    //   156: iadd
    //   157: istore_1
    //   158: iload_2
    //   159: ineg
    //   160: istore #5
    //   162: iload_2
    //   163: iload #6
    //   165: iadd
    //   166: istore #6
    //   168: iload_3
    //   169: iload_1
    //   170: if_icmple -> 181
    //   173: iconst_1
    //   174: istore #9
    //   176: iload_1
    //   177: istore_2
    //   178: goto -> 198
    //   181: iload_3
    //   182: iload #7
    //   184: if_icmpge -> 193
    //   187: iload #7
    //   189: istore_1
    //   190: goto -> 173
    //   193: iconst_0
    //   194: istore #9
    //   196: iload_3
    //   197: istore_2
    //   198: iload #4
    //   200: iload #6
    //   202: if_icmple -> 214
    //   205: iload #6
    //   207: istore_1
    //   208: iconst_1
    //   209: istore #13
    //   211: goto -> 233
    //   214: iload #4
    //   216: iload #5
    //   218: if_icmpge -> 227
    //   221: iload #5
    //   223: istore_1
    //   224: goto -> 208
    //   227: iconst_0
    //   228: istore #13
    //   230: iload #4
    //   232: istore_1
    //   233: iload #13
    //   235: ifeq -> 263
    //   238: aload_0
    //   239: iconst_1
    //   240: invokevirtual u : (I)Z
    //   243: ifne -> 263
    //   246: aload_0
    //   247: getfield c : Landroid/widget/OverScroller;
    //   250: iload_2
    //   251: iload_1
    //   252: iconst_0
    //   253: iconst_0
    //   254: iconst_0
    //   255: aload_0
    //   256: invokevirtual getScrollRange : ()I
    //   259: invokevirtual springBack : (IIIIII)Z
    //   262: pop
    //   263: aload_0
    //   264: iload_2
    //   265: iload_1
    //   266: iload #9
    //   268: iload #13
    //   270: invokevirtual onOverScrolled : (IIZZ)V
    //   273: iload #9
    //   275: ifne -> 287
    //   278: iload #14
    //   280: istore #9
    //   282: iload #13
    //   284: ifeq -> 290
    //   287: iconst_1
    //   288: istore #9
    //   290: iload #9
    //   292: ireturn
  }
  
  public boolean F(int paramInt) {
    if (paramInt == 130) {
      k = 1;
    } else {
      k = 0;
    } 
    int m = getHeight();
    if (k) {
      this.b.top = getScrollY() + m;
      k = getChildCount();
      if (k > 0) {
        View view = getChildAt(k - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        k = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.b;
        if (rect1.top + m > k)
          rect1.top = k - m; 
      } 
    } else {
      this.b.top = getScrollY() - m;
      Rect rect1 = this.b;
      if (rect1.top < 0)
        rect1.top = 0; 
    } 
    Rect rect = this.b;
    int k = rect.top;
    m += k;
    rect.bottom = m;
    return I(paramInt, k, m);
  }
  
  public final void G() {
    VelocityTracker velocityTracker = this.k;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.k = null;
    } 
  }
  
  public final void H(boolean paramBoolean) {
    if (paramBoolean) {
      P(2, 1);
    } else {
      Q(1);
    } 
    this.F = getScrollY();
    r.I((View)this);
  }
  
  public final boolean I(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1;
    NestedScrollView nestedScrollView;
    int m = getHeight();
    int k = getScrollY();
    m += k;
    boolean bool2 = false;
    if (paramInt1 == 33) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    View view2 = r(bool1, paramInt2, paramInt3);
    View view1 = view2;
    if (view2 == null)
      nestedScrollView = this; 
    if (paramInt2 >= k && paramInt3 <= m) {
      bool1 = bool2;
    } else {
      if (bool1) {
        paramInt2 -= k;
      } else {
        paramInt2 = paramInt3 - m;
      } 
      h(paramInt2);
      bool1 = true;
    } 
    if (nestedScrollView != findFocus())
      nestedScrollView.requestFocus(paramInt1); 
    return bool1;
  }
  
  public final void J(View paramView) {
    paramView.getDrawingRect(this.b);
    offsetDescendantRectToMyCoords(paramView, this.b);
    int k = e(this.b);
    if (k != 0)
      scrollBy(0, k); 
  }
  
  public final boolean K(Rect paramRect, boolean paramBoolean) {
    boolean bool;
    int k = e(paramRect);
    if (k != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, k);
        return bool;
      } 
      L(0, k);
    } 
    return bool;
  }
  
  public final void L(int paramInt1, int paramInt2) {
    M(paramInt1, paramInt2, 250, false);
  }
  
  public final void M(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.a > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int k = view.getHeight();
      int m = layoutParams.topMargin;
      int i1 = layoutParams.bottomMargin;
      int i2 = getHeight();
      int i3 = getPaddingTop();
      int i4 = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, k + m + i1 - i2 - i3 - i4)));
      this.c.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, paramInt3);
      H(paramBoolean);
    } else {
      if (!this.c.isFinished())
        a(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.a = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public void N(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    M(paramInt1 - getScrollX(), paramInt2 - getScrollY(), paramInt3, paramBoolean);
  }
  
  public void O(int paramInt1, int paramInt2, boolean paramBoolean) {
    N(paramInt1, paramInt2, 250, paramBoolean);
  }
  
  public boolean P(int paramInt1, int paramInt2) {
    return this.I.m(paramInt1, paramInt2);
  }
  
  public void Q(int paramInt) {
    this.I.n(paramInt);
  }
  
  public final void a() {
    this.c.abortAnimation();
    Q(1);
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public boolean b(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int k = getMaxScrollAmount();
    if (view2 != null && B(view2, k, getHeight())) {
      view2.getDrawingRect(this.b);
      offsetDescendantRectToMyCoords(view2, this.b);
      h(e(this.b));
      view2.requestFocus(paramInt);
    } else {
      int m;
      if (paramInt == 33 && getScrollY() < k) {
        m = getScrollY();
      } else {
        m = k;
        if (paramInt == 130) {
          m = k;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            m = Math.min(view2.getBottom() + layoutParams.bottomMargin - getScrollY() + getHeight() - getPaddingBottom(), k);
          } 
        } 
      } 
      if (m == 0)
        return false; 
      if (paramInt != 130)
        m = -m; 
      h(m);
    } 
    if (view1 != null && view1.isFocused() && z(view1)) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public final boolean c() {
    int k = getChildCount();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (k > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      bool1 = bool2;
      if (view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > getHeight() - getPaddingTop() - getPaddingBottom())
        bool1 = true; 
    } 
    return bool1;
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroid/widget/OverScroller;
    //   4: invokevirtual isFinished : ()Z
    //   7: ifeq -> 11
    //   10: return
    //   11: aload_0
    //   12: getfield c : Landroid/widget/OverScroller;
    //   15: invokevirtual computeScrollOffset : ()Z
    //   18: pop
    //   19: aload_0
    //   20: getfield c : Landroid/widget/OverScroller;
    //   23: invokevirtual getCurrY : ()I
    //   26: istore_2
    //   27: iload_2
    //   28: aload_0
    //   29: getfield F : I
    //   32: isub
    //   33: istore_1
    //   34: aload_0
    //   35: iload_2
    //   36: putfield F : I
    //   39: aload_0
    //   40: getfield D : [I
    //   43: astore #6
    //   45: iconst_0
    //   46: istore_3
    //   47: aload #6
    //   49: iconst_1
    //   50: iconst_0
    //   51: iastore
    //   52: aload_0
    //   53: iconst_0
    //   54: iload_1
    //   55: aload #6
    //   57: aconst_null
    //   58: iconst_1
    //   59: invokevirtual f : (II[I[II)Z
    //   62: pop
    //   63: iload_1
    //   64: aload_0
    //   65: getfield D : [I
    //   68: iconst_1
    //   69: iaload
    //   70: isub
    //   71: istore_2
    //   72: aload_0
    //   73: invokevirtual getScrollRange : ()I
    //   76: istore #4
    //   78: iload_2
    //   79: istore_1
    //   80: iload_2
    //   81: ifeq -> 153
    //   84: aload_0
    //   85: invokevirtual getScrollY : ()I
    //   88: istore_1
    //   89: aload_0
    //   90: iconst_0
    //   91: iload_2
    //   92: aload_0
    //   93: invokevirtual getScrollX : ()I
    //   96: iload_1
    //   97: iconst_0
    //   98: iload #4
    //   100: iconst_0
    //   101: iconst_0
    //   102: iconst_0
    //   103: invokevirtual E : (IIIIIIIIZ)Z
    //   106: pop
    //   107: aload_0
    //   108: invokevirtual getScrollY : ()I
    //   111: iload_1
    //   112: isub
    //   113: istore_1
    //   114: iload_2
    //   115: iload_1
    //   116: isub
    //   117: istore_2
    //   118: aload_0
    //   119: getfield D : [I
    //   122: astore #6
    //   124: aload #6
    //   126: iconst_1
    //   127: iconst_0
    //   128: iastore
    //   129: aload_0
    //   130: iconst_0
    //   131: iload_1
    //   132: iconst_0
    //   133: iload_2
    //   134: aload_0
    //   135: getfield C : [I
    //   138: iconst_1
    //   139: aload #6
    //   141: invokevirtual g : (IIII[II[I)V
    //   144: iload_2
    //   145: aload_0
    //   146: getfield D : [I
    //   149: iconst_1
    //   150: iaload
    //   151: isub
    //   152: istore_1
    //   153: iload_1
    //   154: ifeq -> 254
    //   157: aload_0
    //   158: invokevirtual getOverScrollMode : ()I
    //   161: istore #5
    //   163: iload #5
    //   165: ifeq -> 183
    //   168: iload_3
    //   169: istore_2
    //   170: iload #5
    //   172: iconst_1
    //   173: if_icmpne -> 185
    //   176: iload_3
    //   177: istore_2
    //   178: iload #4
    //   180: ifle -> 185
    //   183: iconst_1
    //   184: istore_2
    //   185: iload_2
    //   186: ifeq -> 250
    //   189: aload_0
    //   190: invokevirtual p : ()V
    //   193: iload_1
    //   194: ifge -> 225
    //   197: aload_0
    //   198: getfield d : Landroid/widget/EdgeEffect;
    //   201: invokevirtual isFinished : ()Z
    //   204: ifeq -> 250
    //   207: aload_0
    //   208: getfield d : Landroid/widget/EdgeEffect;
    //   211: aload_0
    //   212: getfield c : Landroid/widget/OverScroller;
    //   215: invokevirtual getCurrVelocity : ()F
    //   218: f2i
    //   219: invokevirtual onAbsorb : (I)V
    //   222: goto -> 250
    //   225: aload_0
    //   226: getfield e : Landroid/widget/EdgeEffect;
    //   229: invokevirtual isFinished : ()Z
    //   232: ifeq -> 250
    //   235: aload_0
    //   236: getfield e : Landroid/widget/EdgeEffect;
    //   239: aload_0
    //   240: getfield c : Landroid/widget/OverScroller;
    //   243: invokevirtual getCurrVelocity : ()F
    //   246: f2i
    //   247: invokevirtual onAbsorb : (I)V
    //   250: aload_0
    //   251: invokevirtual a : ()V
    //   254: aload_0
    //   255: getfield c : Landroid/widget/OverScroller;
    //   258: invokevirtual isFinished : ()Z
    //   261: ifne -> 269
    //   264: aload_0
    //   265: invokestatic I : (Landroid/view/View;)V
    //   268: return
    //   269: aload_0
    //   270: iconst_1
    //   271: invokevirtual Q : (I)V
    //   274: return
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int m = getChildCount();
    int k = getHeight() - getPaddingBottom() - getPaddingTop();
    if (m == 0)
      return k; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    m = view.getBottom() + layoutParams.bottomMargin;
    int i1 = getScrollY();
    int i2 = Math.max(0, m - k);
    if (i1 < 0)
      return m - i1; 
    k = m;
    if (i1 > i2)
      k = m + i1 - i2; 
    return k;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || q(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.I.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.I.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return f(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.I.e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: getfield d : Landroid/widget/EdgeEffect;
    //   9: ifnull -> 391
    //   12: aload_0
    //   13: invokevirtual getScrollY : ()I
    //   16: istore #9
    //   18: aload_0
    //   19: getfield d : Landroid/widget/EdgeEffect;
    //   22: invokevirtual isFinished : ()Z
    //   25: istore #12
    //   27: iconst_0
    //   28: istore #6
    //   30: iload #12
    //   32: ifne -> 199
    //   35: aload_1
    //   36: invokevirtual save : ()I
    //   39: istore #10
    //   41: aload_0
    //   42: invokevirtual getWidth : ()I
    //   45: istore_2
    //   46: aload_0
    //   47: invokevirtual getHeight : ()I
    //   50: istore #8
    //   52: iconst_0
    //   53: iload #9
    //   55: invokestatic min : (II)I
    //   58: istore #7
    //   60: getstatic android/os/Build$VERSION.SDK_INT : I
    //   63: istore #11
    //   65: iload #11
    //   67: bipush #21
    //   69: if_icmplt -> 87
    //   72: aload_0
    //   73: invokevirtual getClipToPadding : ()Z
    //   76: ifeq -> 82
    //   79: goto -> 87
    //   82: iconst_0
    //   83: istore_3
    //   84: goto -> 106
    //   87: iload_2
    //   88: aload_0
    //   89: invokevirtual getPaddingLeft : ()I
    //   92: aload_0
    //   93: invokevirtual getPaddingRight : ()I
    //   96: iadd
    //   97: isub
    //   98: istore_2
    //   99: aload_0
    //   100: invokevirtual getPaddingLeft : ()I
    //   103: iconst_0
    //   104: iadd
    //   105: istore_3
    //   106: iload #8
    //   108: istore #5
    //   110: iload #7
    //   112: istore #4
    //   114: iload #11
    //   116: bipush #21
    //   118: if_icmplt -> 159
    //   121: iload #8
    //   123: istore #5
    //   125: iload #7
    //   127: istore #4
    //   129: aload_0
    //   130: invokevirtual getClipToPadding : ()Z
    //   133: ifeq -> 159
    //   136: iload #8
    //   138: aload_0
    //   139: invokevirtual getPaddingTop : ()I
    //   142: aload_0
    //   143: invokevirtual getPaddingBottom : ()I
    //   146: iadd
    //   147: isub
    //   148: istore #5
    //   150: iload #7
    //   152: aload_0
    //   153: invokevirtual getPaddingTop : ()I
    //   156: iadd
    //   157: istore #4
    //   159: aload_1
    //   160: iload_3
    //   161: i2f
    //   162: iload #4
    //   164: i2f
    //   165: invokevirtual translate : (FF)V
    //   168: aload_0
    //   169: getfield d : Landroid/widget/EdgeEffect;
    //   172: iload_2
    //   173: iload #5
    //   175: invokevirtual setSize : (II)V
    //   178: aload_0
    //   179: getfield d : Landroid/widget/EdgeEffect;
    //   182: aload_1
    //   183: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   186: ifeq -> 193
    //   189: aload_0
    //   190: invokestatic I : (Landroid/view/View;)V
    //   193: aload_1
    //   194: iload #10
    //   196: invokevirtual restoreToCount : (I)V
    //   199: aload_0
    //   200: getfield e : Landroid/widget/EdgeEffect;
    //   203: invokevirtual isFinished : ()Z
    //   206: ifne -> 391
    //   209: aload_1
    //   210: invokevirtual save : ()I
    //   213: istore #10
    //   215: aload_0
    //   216: invokevirtual getWidth : ()I
    //   219: istore #4
    //   221: aload_0
    //   222: invokevirtual getHeight : ()I
    //   225: istore #7
    //   227: aload_0
    //   228: invokevirtual getScrollRange : ()I
    //   231: iload #9
    //   233: invokestatic max : (II)I
    //   236: iload #7
    //   238: iadd
    //   239: istore #8
    //   241: getstatic android/os/Build$VERSION.SDK_INT : I
    //   244: istore #9
    //   246: iload #9
    //   248: bipush #21
    //   250: if_icmplt -> 266
    //   253: iload #6
    //   255: istore_3
    //   256: iload #4
    //   258: istore_2
    //   259: aload_0
    //   260: invokevirtual getClipToPadding : ()Z
    //   263: ifeq -> 286
    //   266: iload #4
    //   268: aload_0
    //   269: invokevirtual getPaddingLeft : ()I
    //   272: aload_0
    //   273: invokevirtual getPaddingRight : ()I
    //   276: iadd
    //   277: isub
    //   278: istore_2
    //   279: iconst_0
    //   280: aload_0
    //   281: invokevirtual getPaddingLeft : ()I
    //   284: iadd
    //   285: istore_3
    //   286: iload #8
    //   288: istore #5
    //   290: iload #7
    //   292: istore #4
    //   294: iload #9
    //   296: bipush #21
    //   298: if_icmplt -> 339
    //   301: iload #8
    //   303: istore #5
    //   305: iload #7
    //   307: istore #4
    //   309: aload_0
    //   310: invokevirtual getClipToPadding : ()Z
    //   313: ifeq -> 339
    //   316: iload #7
    //   318: aload_0
    //   319: invokevirtual getPaddingTop : ()I
    //   322: aload_0
    //   323: invokevirtual getPaddingBottom : ()I
    //   326: iadd
    //   327: isub
    //   328: istore #4
    //   330: iload #8
    //   332: aload_0
    //   333: invokevirtual getPaddingBottom : ()I
    //   336: isub
    //   337: istore #5
    //   339: aload_1
    //   340: iload_3
    //   341: iload_2
    //   342: isub
    //   343: i2f
    //   344: iload #5
    //   346: i2f
    //   347: invokevirtual translate : (FF)V
    //   350: aload_1
    //   351: ldc_w 180.0
    //   354: iload_2
    //   355: i2f
    //   356: fconst_0
    //   357: invokevirtual rotate : (FFF)V
    //   360: aload_0
    //   361: getfield e : Landroid/widget/EdgeEffect;
    //   364: iload_2
    //   365: iload #4
    //   367: invokevirtual setSize : (II)V
    //   370: aload_0
    //   371: getfield e : Landroid/widget/EdgeEffect;
    //   374: aload_1
    //   375: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   378: ifeq -> 385
    //   381: aload_0
    //   382: invokestatic I : (Landroid/view/View;)V
    //   385: aload_1
    //   386: iload #10
    //   388: invokevirtual restoreToCount : (I)V
    //   391: return
  }
  
  public int e(Rect paramRect) {
    int k = getChildCount();
    boolean bool = false;
    if (k == 0)
      return 0; 
    int i2 = getHeight();
    int m = getScrollY();
    int i1 = m + i2;
    int i3 = getVerticalFadingEdgeLength();
    k = m;
    if (paramRect.top > 0)
      k = m + i3; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      m = i1 - i3;
    } else {
      m = i1;
    } 
    i3 = paramRect.bottom;
    if (i3 > m && paramRect.top > k) {
      if (paramRect.height() > i2) {
        k = paramRect.top - k;
      } else {
        k = paramRect.bottom - m;
      } 
      return Math.min(k + 0, view.getBottom() + layoutParams.bottomMargin - i1);
    } 
    i1 = bool;
    if (paramRect.top < k) {
      i1 = bool;
      if (i3 < m) {
        if (paramRect.height() > i2) {
          k = 0 - m - paramRect.bottom;
        } else {
          k = 0 - k - paramRect.top;
        } 
        i1 = Math.max(k, -getScrollY());
      } 
    } 
    return i1;
  }
  
  public boolean f(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.I.c(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public void g(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint1, int paramInt5, int[] paramArrayOfint2) {
    this.I.d(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint1, paramInt5, paramArrayOfint2);
  }
  
  public float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int k = getVerticalFadingEdgeLength();
    int m = getHeight();
    int i1 = getPaddingBottom();
    m = view.getBottom() + layoutParams.bottomMargin - getScrollY() - m - i1;
    return (m < k) ? (m / k) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.H.a();
  }
  
  public int getScrollRange() {
    int m = getChildCount();
    int k = 0;
    if (m > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      k = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return k;
  }
  
  public float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int k = getVerticalFadingEdgeLength();
    int m = getScrollY();
    return (m < k) ? (m / k) : 1.0F;
  }
  
  public final void h(int paramInt) {
    if (paramInt != 0) {
      if (this.m) {
        L(0, paramInt);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  public boolean hasNestedScrollingParent() {
    return u(0);
  }
  
  public final void i() {
    this.j = false;
    G();
    Q(0);
    EdgeEffect edgeEffect = this.d;
    if (edgeEffect != null) {
      edgeEffect.onRelease();
      this.e.onRelease();
    } 
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.I.j();
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    C(paramInt4, paramInt5, paramArrayOfint);
  }
  
  public void k(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    C(paramInt4, paramInt5, null);
  }
  
  public boolean l(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return ((paramInt1 & 0x2) != 0);
  }
  
  public void m(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.H.c(paramView1, paramView2, paramInt1, paramInt2);
    P(2, paramInt2);
  }
  
  public void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  public void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramView.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public void n(View paramView, int paramInt) {
    this.H.d(paramView, paramInt);
    Q(paramInt);
  }
  
  public void o(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    f(paramInt1, paramInt2, paramArrayOfint, null, paramInt3);
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.h = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getSource() & 0x2) != 0) {
      if (paramMotionEvent.getAction() != 8)
        return false; 
      if (!this.j) {
        float f = paramMotionEvent.getAxisValue(9);
        if (f != 0.0F) {
          int m = (int)(f * getVerticalScrollFactorCompat());
          int k = getScrollRange();
          int i1 = getScrollY();
          m = i1 - m;
          if (m < 0) {
            k = 0;
          } else if (m <= k) {
            k = m;
          } 
          if (k != i1) {
            super.scrollTo(getScrollX(), k);
            return true;
          } 
        } 
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    ViewParent viewParent;
    int k = paramMotionEvent.getAction();
    if (k == 2 && this.j)
      return true; 
    k &= 0xFF;
    if (k != 0) {
      if (k != 1)
        if (k != 2) {
          if (k != 3) {
            if (k == 6)
              D(paramMotionEvent); 
            return this.j;
          } 
        } else {
          k = this.q;
          if (k != -1) {
            StringBuilder stringBuilder;
            int m = paramMotionEvent.findPointerIndex(k);
            if (m == -1) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Invalid pointerId=");
              stringBuilder.append(k);
              stringBuilder.append(" in onInterceptTouchEvent");
              Log.e("NestedScrollView", stringBuilder.toString());
            } else {
              k = (int)stringBuilder.getY(m);
              if (Math.abs(k - this.f) > this.n && (0x2 & getNestedScrollAxes()) == 0) {
                this.j = true;
                this.f = k;
                y();
                this.k.addMovement((MotionEvent)stringBuilder);
                this.E = 0;
                viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
              } 
            } 
          } 
          return this.j;
        }  
      this.j = false;
      this.q = -1;
      G();
      if (this.c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
        r.I((View)this); 
      Q(0);
    } else {
      k = (int)viewParent.getY();
      if (!v((int)viewParent.getX(), k)) {
        this.j = false;
        G();
      } else {
        this.f = k;
        this.q = viewParent.getPointerId(0);
        w();
        this.k.addMovement((MotionEvent)viewParent);
        this.c.computeScrollOffset();
        this.j = this.c.isFinished() ^ true;
        P(2, 0);
      } 
    } 
    return this.j;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = 0;
    this.g = false;
    View view = this.i;
    if (view != null && A(view, (View)this))
      J(this.i); 
    this.i = null;
    if (!this.h) {
      if (this.G != null) {
        scrollTo(getScrollX(), this.G.a);
        this.G = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int k = getPaddingTop();
      int m = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = d(paramInt3, paramInt4 - paramInt2 - k - m, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.h = true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.l)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      paramInt2 = view.getMeasuredHeight();
      int k = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (paramInt2 < k)
        view.measure(FrameLayout.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(k, 1073741824)); 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      s((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    o(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    C(paramInt4, 0, null);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    m(paramView1, paramView2, paramInt, 0);
  }
  
  public void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int k;
    View view;
    if (paramInt == 2) {
      k = 130;
    } else {
      k = paramInt;
      if (paramInt == 1)
        k = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, k);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, k);
    } 
    return (view == null) ? false : (z(view) ? false : view.requestFocus(k, paramRect));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    this.G = savedState;
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    savedState.a = getScrollY();
    return (Parcelable)savedState;
  }
  
  public void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    b b1 = this.K;
    if (b1 != null)
      b1.a(this, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (B(view, 0, paramInt4)) {
        view.getDrawingRect(this.b);
        offsetDescendantRectToMyCoords(view, this.b);
        h(e(this.b));
      } 
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return l(paramView1, paramView2, paramInt, 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    n(paramView, 0);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    y();
    int k = paramMotionEvent.getActionMasked();
    if (k == 0)
      this.E = 0; 
    MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
    motionEvent.offsetLocation(0.0F, this.E);
    if (k != 0) {
      if (k != 1) {
        if (k != 2) {
          if (k != 3) {
            if (k != 5) {
              if (k == 6) {
                D(paramMotionEvent);
                this.f = (int)paramMotionEvent.getY(paramMotionEvent.findPointerIndex(this.q));
              } 
            } else {
              k = paramMotionEvent.getActionIndex();
              this.f = (int)paramMotionEvent.getY(k);
              this.q = paramMotionEvent.getPointerId(k);
            } 
          } else {
            if (this.j && getChildCount() > 0 && this.c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
              r.I((View)this); 
            this.q = -1;
            i();
          } 
        } else {
          StringBuilder stringBuilder;
          int m = paramMotionEvent.findPointerIndex(this.q);
          if (m == -1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid pointerId=");
            stringBuilder.append(this.q);
            stringBuilder.append(" in onTouchEvent");
            Log.e("NestedScrollView", stringBuilder.toString());
          } else {
            int i2 = (int)stringBuilder.getY(m);
            int i1 = this.f - i2;
            k = i1;
            if (!this.j) {
              k = i1;
              if (Math.abs(i1) > this.n) {
                ViewParent viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
                this.j = true;
                if (i1 > 0) {
                  k = i1 - this.n;
                } else {
                  k = i1 + this.n;
                } 
              } 
            } 
            i1 = k;
            if (this.j) {
              k = i1;
              if (f(0, i1, this.D, this.C, 0)) {
                k = i1 - this.D[1];
                this.E += this.C[1];
              } 
              this.f = i2 - this.C[1];
              int i3 = getScrollY();
              i2 = getScrollRange();
              i1 = getOverScrollMode();
              if (i1 == 0 || (i1 == 1 && i2 > 0)) {
                i1 = 1;
              } else {
                i1 = 0;
              } 
              if (E(0, k, 0, getScrollY(), 0, i2, 0, 0, true) && !u(0))
                this.k.clear(); 
              int i4 = getScrollY() - i3;
              int[] arrayOfInt = this.D;
              arrayOfInt[1] = 0;
              g(0, i4, 0, k - i4, this.C, 0, arrayOfInt);
              i4 = this.f;
              arrayOfInt = this.C;
              this.f = i4 - arrayOfInt[1];
              this.E += arrayOfInt[1];
              if (i1 != 0) {
                k -= this.D[1];
                p();
                i1 = i3 + k;
                if (i1 < 0) {
                  d.a(this.d, k / getHeight(), stringBuilder.getX(m) / getWidth());
                  if (!this.e.isFinished())
                    this.e.onRelease(); 
                } else if (i1 > i2) {
                  d.a(this.e, k / getHeight(), 1.0F - stringBuilder.getX(m) / getWidth());
                  if (!this.d.isFinished())
                    this.d.onRelease(); 
                } 
                EdgeEffect edgeEffect = this.d;
                if (edgeEffect != null && (!edgeEffect.isFinished() || !this.e.isFinished()))
                  r.I((View)this); 
              } 
            } 
          } 
        } 
      } else {
        velocityTracker = this.k;
        velocityTracker.computeCurrentVelocity(1000, this.p);
        k = (int)velocityTracker.getYVelocity(this.q);
        if (Math.abs(k) >= this.o) {
          k = -k;
          float f = k;
          if (!dispatchNestedPreFling(0.0F, f)) {
            dispatchNestedFling(0.0F, f, true);
            s(k);
          } 
        } else if (this.c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
          r.I((View)this);
        } 
        this.q = -1;
        i();
      } 
    } else {
      if (getChildCount() == 0)
        return false; 
      int m = this.c.isFinished() ^ true;
      this.j = m;
      if (m != 0) {
        ViewParent viewParent = getParent();
        if (viewParent != null)
          viewParent.requestDisallowInterceptTouchEvent(true); 
      } 
      if (!this.c.isFinished())
        a(); 
      this.f = (int)velocityTracker.getY();
      this.q = velocityTracker.getPointerId(0);
      P(2, 0);
    } 
    VelocityTracker velocityTracker = this.k;
    if (velocityTracker != null)
      velocityTracker.addMovement(motionEvent); 
    motionEvent.recycle();
    return true;
  }
  
  public final void p() {
    if (getOverScrollMode() != 2) {
      if (this.d == null) {
        Context context = getContext();
        this.d = new EdgeEffect(context);
        this.e = new EdgeEffect(context);
        return;
      } 
    } else {
      this.d = null;
      this.e = null;
    } 
  }
  
  public boolean q(KeyEvent paramKeyEvent) {
    View view;
    this.b.setEmpty();
    boolean bool3 = c();
    boolean bool1 = false;
    boolean bool2 = false;
    char c = '';
    if (!bool3) {
      bool1 = bool2;
      if (isFocused()) {
        bool1 = bool2;
        if (paramKeyEvent.getKeyCode() != 4) {
          View view1 = findFocus();
          view = view1;
          if (view1 == this)
            view = null; 
          view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view, 130);
          bool1 = bool2;
          if (view != null) {
            bool1 = bool2;
            if (view != this) {
              bool1 = bool2;
              if (view.requestFocus(130))
                bool1 = true; 
            } 
          } 
        } 
      } 
      return bool1;
    } 
    if (view.getAction() == 0) {
      int k = view.getKeyCode();
      if (k != 19) {
        if (k != 20) {
          if (k != 62)
            return false; 
          if (view.isShiftPressed())
            c = '!'; 
          F(c);
          return false;
        } 
        return !view.isAltPressed() ? b(130) : t(130);
      } 
      if (!view.isAltPressed())
        return b(33); 
      bool1 = t(33);
    } 
    return bool1;
  }
  
  public final View r(boolean paramBoolean, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_2
    //   2: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   5: astore #14
    //   7: aload #14
    //   9: invokeinterface size : ()I
    //   14: istore #9
    //   16: aconst_null
    //   17: astore #13
    //   19: iconst_0
    //   20: istore #6
    //   22: iconst_0
    //   23: istore #7
    //   25: iload #6
    //   27: iload #9
    //   29: if_icmpge -> 249
    //   32: aload #14
    //   34: iload #6
    //   36: invokeinterface get : (I)Ljava/lang/Object;
    //   41: checkcast android/view/View
    //   44: astore #12
    //   46: aload #12
    //   48: invokevirtual getTop : ()I
    //   51: istore #8
    //   53: aload #12
    //   55: invokevirtual getBottom : ()I
    //   58: istore #10
    //   60: aload #13
    //   62: astore #11
    //   64: iload #7
    //   66: istore #5
    //   68: iload_2
    //   69: iload #10
    //   71: if_icmpge -> 232
    //   74: aload #13
    //   76: astore #11
    //   78: iload #7
    //   80: istore #5
    //   82: iload #8
    //   84: iload_3
    //   85: if_icmpge -> 232
    //   88: iload_2
    //   89: iload #8
    //   91: if_icmpge -> 106
    //   94: iload #10
    //   96: iload_3
    //   97: if_icmpge -> 106
    //   100: iconst_1
    //   101: istore #4
    //   103: goto -> 109
    //   106: iconst_0
    //   107: istore #4
    //   109: aload #13
    //   111: ifnonnull -> 125
    //   114: aload #12
    //   116: astore #11
    //   118: iload #4
    //   120: istore #5
    //   122: goto -> 232
    //   125: iload_1
    //   126: ifeq -> 139
    //   129: iload #8
    //   131: aload #13
    //   133: invokevirtual getTop : ()I
    //   136: if_icmplt -> 153
    //   139: iload_1
    //   140: ifne -> 159
    //   143: iload #10
    //   145: aload #13
    //   147: invokevirtual getBottom : ()I
    //   150: if_icmple -> 159
    //   153: iconst_1
    //   154: istore #8
    //   156: goto -> 162
    //   159: iconst_0
    //   160: istore #8
    //   162: iload #7
    //   164: ifeq -> 196
    //   167: aload #13
    //   169: astore #11
    //   171: iload #7
    //   173: istore #5
    //   175: iload #4
    //   177: ifeq -> 232
    //   180: aload #13
    //   182: astore #11
    //   184: iload #7
    //   186: istore #5
    //   188: iload #8
    //   190: ifeq -> 232
    //   193: goto -> 224
    //   196: iload #4
    //   198: ifeq -> 211
    //   201: aload #12
    //   203: astore #11
    //   205: iconst_1
    //   206: istore #5
    //   208: goto -> 232
    //   211: aload #13
    //   213: astore #11
    //   215: iload #7
    //   217: istore #5
    //   219: iload #8
    //   221: ifeq -> 232
    //   224: aload #12
    //   226: astore #11
    //   228: iload #7
    //   230: istore #5
    //   232: iload #6
    //   234: iconst_1
    //   235: iadd
    //   236: istore #6
    //   238: aload #11
    //   240: astore #13
    //   242: iload #5
    //   244: istore #7
    //   246: goto -> 25
    //   249: aload #13
    //   251: areturn
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.g) {
      J(paramView2);
    } else {
      this.i = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    return K(paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      G(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.g = true;
    super.requestLayout();
  }
  
  public void s(int paramInt) {
    if (getChildCount() > 0) {
      this.c.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      H(true);
    } 
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i5 = getWidth();
      int i6 = getPaddingLeft();
      int i7 = getPaddingRight();
      int i8 = view.getWidth();
      int i9 = layoutParams.leftMargin;
      int i10 = layoutParams.rightMargin;
      int k = getHeight();
      int m = getPaddingTop();
      int i1 = getPaddingBottom();
      int i2 = view.getHeight();
      int i3 = layoutParams.topMargin;
      int i4 = layoutParams.bottomMargin;
      paramInt1 = d(paramInt1, i5 - i6 - i7, i8 + i9 + i10);
      paramInt2 = d(paramInt2, k - m - i1, i2 + i3 + i4);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.l) {
      this.l = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.I.k(paramBoolean);
  }
  
  public void setOnScrollChangeListener(b paramb) {
    this.K = paramb;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.m = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return P(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    Q(0);
  }
  
  public boolean t(int paramInt) {
    int k;
    if (paramInt == 130) {
      k = 1;
    } else {
      k = 0;
    } 
    int m = getHeight();
    Rect rect = this.b;
    rect.top = 0;
    rect.bottom = m;
    if (k) {
      k = getChildCount();
      if (k > 0) {
        View view = getChildAt(k - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        this.b.bottom = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.b;
        rect1.top = rect1.bottom - m;
      } 
    } 
    rect = this.b;
    return I(paramInt, rect.top, rect.bottom);
  }
  
  public boolean u(int paramInt) {
    return this.I.i(paramInt);
  }
  
  public final boolean v(int paramInt1, int paramInt2) {
    int k = getChildCount();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (k > 0) {
      k = getScrollY();
      View view = getChildAt(0);
      bool1 = bool2;
      if (paramInt2 >= view.getTop() - k) {
        bool1 = bool2;
        if (paramInt2 < view.getBottom() - k) {
          bool1 = bool2;
          if (paramInt1 >= view.getLeft()) {
            bool1 = bool2;
            if (paramInt1 < view.getRight())
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public final void w() {
    VelocityTracker velocityTracker = this.k;
    if (velocityTracker == null) {
      this.k = VelocityTracker.obtain();
      return;
    } 
    velocityTracker.clear();
  }
  
  public final void x() {
    this.c = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.n = viewConfiguration.getScaledTouchSlop();
    this.o = viewConfiguration.getScaledMinimumFlingVelocity();
    this.p = viewConfiguration.getScaledMaximumFlingVelocity();
  }
  
  public final void y() {
    if (this.k == null)
      this.k = VelocityTracker.obtain(); 
  }
  
  public final boolean z(View paramView) {
    return B(paramView, 0, getHeight()) ^ true;
  }
  
  public static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new a();
    
    public int a;
    
    public SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      this.a = param1Parcel.readInt();
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      stringBuilder.append(this.a);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.a);
    }
    
    public class a implements Parcelable.Creator<SavedState> {
      public NestedScrollView.SavedState a(Parcel param2Parcel) {
        return new NestedScrollView.SavedState(param2Parcel);
      }
      
      public NestedScrollView.SavedState[] b(int param2Int) {
        return new NestedScrollView.SavedState[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.Creator<SavedState> {
    public NestedScrollView.SavedState a(Parcel param1Parcel) {
      return new NestedScrollView.SavedState(param1Parcel);
    }
    
    public NestedScrollView.SavedState[] b(int param1Int) {
      return new NestedScrollView.SavedState[param1Int];
    }
  }
  
  public static class a extends b.h.n.a {
    public void f(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      super.f(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      d.a((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollX());
      d.b((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollRange());
    }
    
    public void g(View param1View, b.h.n.a0.b param1b) {
      super.g(param1View, param1b);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1b.U(ScrollView.class.getName());
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1b.h0(true);
          if (nestedScrollView.getScrollY() > 0) {
            param1b.b(b.h.n.a0.b.a.g);
            param1b.b(b.h.n.a0.b.a.h);
          } 
          if (nestedScrollView.getScrollY() < i) {
            param1b.b(b.h.n.a0.b.a.f);
            param1b.b(b.h.n.a0.b.a.i);
          } 
        } 
      } 
    }
    
    public boolean j(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.j(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      if (param1Int != 4096)
        if (param1Int != 8192 && param1Int != 16908344) {
          if (param1Int != 16908346)
            return false; 
        } else {
          param1Int = nestedScrollView.getHeight();
          int k = nestedScrollView.getPaddingBottom();
          int m = nestedScrollView.getPaddingTop();
          param1Int = Math.max(nestedScrollView.getScrollY() - param1Int - k - m, 0);
          if (param1Int != nestedScrollView.getScrollY()) {
            nestedScrollView.O(0, param1Int, true);
            return true;
          } 
          return false;
        }  
      param1Int = nestedScrollView.getHeight();
      int i = nestedScrollView.getPaddingBottom();
      int j = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + param1Int - i - j, nestedScrollView.getScrollRange());
      if (param1Int != nestedScrollView.getScrollY()) {
        nestedScrollView.O(0, param1Int, true);
        return true;
      } 
      return false;
    }
  }
  
  public static interface b {
    void a(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */