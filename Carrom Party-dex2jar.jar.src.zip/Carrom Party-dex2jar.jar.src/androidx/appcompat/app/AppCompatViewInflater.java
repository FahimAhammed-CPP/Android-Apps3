package androidx.appcompat.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatCheckedTextView;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.AppCompatToggleButton;
import b.b.j;
import b.b.p.d;
import b.h.n.r;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

public class AppCompatViewInflater {
  public static final Class<?>[] b = new Class[] { Context.class, AttributeSet.class };
  
  public static final int[] c = new int[] { 16843375 };
  
  public static final String[] d = new String[] { "android.widget.", "android.view.", "android.webkit." };
  
  public static final Map<String, Constructor<? extends View>> e = (Map<String, Constructor<? extends View>>)new b.f.a();
  
  public final Object[] a = new Object[2];
  
  public static Context t(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2) {
    int i;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.D3, 0, 0);
    if (paramBoolean1) {
      i = typedArray.getResourceId(j.E3, 0);
    } else {
      i = 0;
    } 
    int j = i;
    if (paramBoolean2) {
      j = i;
      if (!i) {
        i = typedArray.getResourceId(j.F3, 0);
        j = i;
        if (i != 0) {
          Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
          j = i;
        } 
      } 
    } 
    typedArray.recycle();
    Context context = paramContext;
    if (j != 0) {
      if (paramContext instanceof d) {
        context = paramContext;
        return (Context)((((d)paramContext).b() != j) ? new d(paramContext, j) : context);
      } 
    } else {
      return context;
    } 
    return (Context)new d(paramContext, j);
  }
  
  public final void a(View paramView, AttributeSet paramAttributeSet) {
    Context context = paramView.getContext();
    if (context instanceof ContextWrapper) {
      if (Build.VERSION.SDK_INT >= 15 && !r.y(paramView))
        return; 
      TypedArray typedArray = context.obtainStyledAttributes(paramAttributeSet, c);
      String str = typedArray.getString(0);
      if (str != null)
        paramView.setOnClickListener(new a(paramView, str)); 
      typedArray.recycle();
    } 
  }
  
  public AppCompatAutoCompleteTextView b(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  public AppCompatButton c(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatButton(paramContext, paramAttributeSet);
  }
  
  public AppCompatCheckBox d(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatCheckBox(paramContext, paramAttributeSet);
  }
  
  public AppCompatCheckedTextView e(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatCheckedTextView(paramContext, paramAttributeSet);
  }
  
  public AppCompatEditText f(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatEditText(paramContext, paramAttributeSet);
  }
  
  public AppCompatImageButton g(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageButton(paramContext, paramAttributeSet);
  }
  
  public AppCompatImageView h(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageView(paramContext, paramAttributeSet);
  }
  
  public AppCompatMultiAutoCompleteTextView i(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatMultiAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  public AppCompatRadioButton j(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatRadioButton(paramContext, paramAttributeSet);
  }
  
  public AppCompatRatingBar k(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatRatingBar(paramContext, paramAttributeSet);
  }
  
  public AppCompatSeekBar l(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatSeekBar(paramContext, paramAttributeSet);
  }
  
  public AppCompatSpinner m(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatSpinner(paramContext, paramAttributeSet);
  }
  
  public AppCompatTextView n(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatTextView(paramContext, paramAttributeSet);
  }
  
  public AppCompatToggleButton o(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatToggleButton(paramContext, paramAttributeSet);
  }
  
  public View p(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    return null;
  }
  
  public final View q(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: iload #5
    //   2: ifeq -> 18
    //   5: aload_1
    //   6: ifnull -> 18
    //   9: aload_1
    //   10: invokevirtual getContext : ()Landroid/content/Context;
    //   13: astore #10
    //   15: goto -> 21
    //   18: aload_3
    //   19: astore #10
    //   21: iload #6
    //   23: ifne -> 34
    //   26: aload #10
    //   28: astore_1
    //   29: iload #7
    //   31: ifeq -> 46
    //   34: aload #10
    //   36: aload #4
    //   38: iload #6
    //   40: iload #7
    //   42: invokestatic t : (Landroid/content/Context;Landroid/util/AttributeSet;ZZ)Landroid/content/Context;
    //   45: astore_1
    //   46: aload_1
    //   47: astore #10
    //   49: iload #8
    //   51: ifeq -> 60
    //   54: aload_1
    //   55: invokestatic b : (Landroid/content/Context;)Landroid/content/Context;
    //   58: astore #10
    //   60: aload_2
    //   61: invokevirtual hashCode : ()I
    //   64: pop
    //   65: iconst_m1
    //   66: istore #9
    //   68: aload_2
    //   69: invokevirtual hashCode : ()I
    //   72: lookupswitch default -> 196, -1946472170 -> 441, -1455429095 -> 423, -1346021293 -> 405, -938935918 -> 387, -937446323 -> 369, -658531749 -> 351, -339785223 -> 332, 776382189 -> 313, 799298502 -> 294, 1125864064 -> 275, 1413872058 -> 256, 1601505219 -> 237, 1666676343 -> 218, 2001146706 -> 199
    //   196: goto -> 456
    //   199: aload_2
    //   200: ldc 'Button'
    //   202: invokevirtual equals : (Ljava/lang/Object;)Z
    //   205: ifne -> 211
    //   208: goto -> 456
    //   211: bipush #13
    //   213: istore #9
    //   215: goto -> 456
    //   218: aload_2
    //   219: ldc 'EditText'
    //   221: invokevirtual equals : (Ljava/lang/Object;)Z
    //   224: ifne -> 230
    //   227: goto -> 456
    //   230: bipush #12
    //   232: istore #9
    //   234: goto -> 456
    //   237: aload_2
    //   238: ldc 'CheckBox'
    //   240: invokevirtual equals : (Ljava/lang/Object;)Z
    //   243: ifne -> 249
    //   246: goto -> 456
    //   249: bipush #11
    //   251: istore #9
    //   253: goto -> 456
    //   256: aload_2
    //   257: ldc 'AutoCompleteTextView'
    //   259: invokevirtual equals : (Ljava/lang/Object;)Z
    //   262: ifne -> 268
    //   265: goto -> 456
    //   268: bipush #10
    //   270: istore #9
    //   272: goto -> 456
    //   275: aload_2
    //   276: ldc 'ImageView'
    //   278: invokevirtual equals : (Ljava/lang/Object;)Z
    //   281: ifne -> 287
    //   284: goto -> 456
    //   287: bipush #9
    //   289: istore #9
    //   291: goto -> 456
    //   294: aload_2
    //   295: ldc 'ToggleButton'
    //   297: invokevirtual equals : (Ljava/lang/Object;)Z
    //   300: ifne -> 306
    //   303: goto -> 456
    //   306: bipush #8
    //   308: istore #9
    //   310: goto -> 456
    //   313: aload_2
    //   314: ldc 'RadioButton'
    //   316: invokevirtual equals : (Ljava/lang/Object;)Z
    //   319: ifne -> 325
    //   322: goto -> 456
    //   325: bipush #7
    //   327: istore #9
    //   329: goto -> 456
    //   332: aload_2
    //   333: ldc 'Spinner'
    //   335: invokevirtual equals : (Ljava/lang/Object;)Z
    //   338: ifne -> 344
    //   341: goto -> 456
    //   344: bipush #6
    //   346: istore #9
    //   348: goto -> 456
    //   351: aload_2
    //   352: ldc 'SeekBar'
    //   354: invokevirtual equals : (Ljava/lang/Object;)Z
    //   357: ifne -> 363
    //   360: goto -> 456
    //   363: iconst_5
    //   364: istore #9
    //   366: goto -> 456
    //   369: aload_2
    //   370: ldc 'ImageButton'
    //   372: invokevirtual equals : (Ljava/lang/Object;)Z
    //   375: ifne -> 381
    //   378: goto -> 456
    //   381: iconst_4
    //   382: istore #9
    //   384: goto -> 456
    //   387: aload_2
    //   388: ldc 'TextView'
    //   390: invokevirtual equals : (Ljava/lang/Object;)Z
    //   393: ifne -> 399
    //   396: goto -> 456
    //   399: iconst_3
    //   400: istore #9
    //   402: goto -> 456
    //   405: aload_2
    //   406: ldc 'MultiAutoCompleteTextView'
    //   408: invokevirtual equals : (Ljava/lang/Object;)Z
    //   411: ifne -> 417
    //   414: goto -> 456
    //   417: iconst_2
    //   418: istore #9
    //   420: goto -> 456
    //   423: aload_2
    //   424: ldc 'CheckedTextView'
    //   426: invokevirtual equals : (Ljava/lang/Object;)Z
    //   429: ifne -> 435
    //   432: goto -> 456
    //   435: iconst_1
    //   436: istore #9
    //   438: goto -> 456
    //   441: aload_2
    //   442: ldc 'RatingBar'
    //   444: invokevirtual equals : (Ljava/lang/Object;)Z
    //   447: ifne -> 453
    //   450: goto -> 456
    //   453: iconst_0
    //   454: istore #9
    //   456: iload #9
    //   458: tableswitch default -> 528, 0 -> 775, 1 -> 757, 2 -> 739, 3 -> 721, 4 -> 703, 5 -> 685, 6 -> 667, 7 -> 649, 8 -> 631, 9 -> 613, 10 -> 595, 11 -> 577, 12 -> 559, 13 -> 541
    //   528: aload_0
    //   529: aload #10
    //   531: aload_2
    //   532: aload #4
    //   534: invokevirtual p : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   537: astore_1
    //   538: goto -> 790
    //   541: aload_0
    //   542: aload #10
    //   544: aload #4
    //   546: invokevirtual c : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatButton;
    //   549: astore_1
    //   550: aload_0
    //   551: aload_1
    //   552: aload_2
    //   553: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   556: goto -> 790
    //   559: aload_0
    //   560: aload #10
    //   562: aload #4
    //   564: invokevirtual f : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatEditText;
    //   567: astore_1
    //   568: aload_0
    //   569: aload_1
    //   570: aload_2
    //   571: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   574: goto -> 790
    //   577: aload_0
    //   578: aload #10
    //   580: aload #4
    //   582: invokevirtual d : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatCheckBox;
    //   585: astore_1
    //   586: aload_0
    //   587: aload_1
    //   588: aload_2
    //   589: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   592: goto -> 790
    //   595: aload_0
    //   596: aload #10
    //   598: aload #4
    //   600: invokevirtual b : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatAutoCompleteTextView;
    //   603: astore_1
    //   604: aload_0
    //   605: aload_1
    //   606: aload_2
    //   607: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   610: goto -> 790
    //   613: aload_0
    //   614: aload #10
    //   616: aload #4
    //   618: invokevirtual h : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatImageView;
    //   621: astore_1
    //   622: aload_0
    //   623: aload_1
    //   624: aload_2
    //   625: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   628: goto -> 790
    //   631: aload_0
    //   632: aload #10
    //   634: aload #4
    //   636: invokevirtual o : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatToggleButton;
    //   639: astore_1
    //   640: aload_0
    //   641: aload_1
    //   642: aload_2
    //   643: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   646: goto -> 790
    //   649: aload_0
    //   650: aload #10
    //   652: aload #4
    //   654: invokevirtual j : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatRadioButton;
    //   657: astore_1
    //   658: aload_0
    //   659: aload_1
    //   660: aload_2
    //   661: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   664: goto -> 790
    //   667: aload_0
    //   668: aload #10
    //   670: aload #4
    //   672: invokevirtual m : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatSpinner;
    //   675: astore_1
    //   676: aload_0
    //   677: aload_1
    //   678: aload_2
    //   679: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   682: goto -> 790
    //   685: aload_0
    //   686: aload #10
    //   688: aload #4
    //   690: invokevirtual l : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatSeekBar;
    //   693: astore_1
    //   694: aload_0
    //   695: aload_1
    //   696: aload_2
    //   697: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   700: goto -> 790
    //   703: aload_0
    //   704: aload #10
    //   706: aload #4
    //   708: invokevirtual g : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatImageButton;
    //   711: astore_1
    //   712: aload_0
    //   713: aload_1
    //   714: aload_2
    //   715: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   718: goto -> 790
    //   721: aload_0
    //   722: aload #10
    //   724: aload #4
    //   726: invokevirtual n : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatTextView;
    //   729: astore_1
    //   730: aload_0
    //   731: aload_1
    //   732: aload_2
    //   733: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   736: goto -> 790
    //   739: aload_0
    //   740: aload #10
    //   742: aload #4
    //   744: invokevirtual i : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatMultiAutoCompleteTextView;
    //   747: astore_1
    //   748: aload_0
    //   749: aload_1
    //   750: aload_2
    //   751: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   754: goto -> 790
    //   757: aload_0
    //   758: aload #10
    //   760: aload #4
    //   762: invokevirtual e : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatCheckedTextView;
    //   765: astore_1
    //   766: aload_0
    //   767: aload_1
    //   768: aload_2
    //   769: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   772: goto -> 790
    //   775: aload_0
    //   776: aload #10
    //   778: aload #4
    //   780: invokevirtual k : (Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/appcompat/widget/AppCompatRatingBar;
    //   783: astore_1
    //   784: aload_0
    //   785: aload_1
    //   786: aload_2
    //   787: invokevirtual u : (Landroid/view/View;Ljava/lang/String;)V
    //   790: aload_1
    //   791: astore #11
    //   793: aload_1
    //   794: ifnonnull -> 817
    //   797: aload_1
    //   798: astore #11
    //   800: aload_3
    //   801: aload #10
    //   803: if_acmpeq -> 817
    //   806: aload_0
    //   807: aload #10
    //   809: aload_2
    //   810: aload #4
    //   812: invokevirtual s : (Landroid/content/Context;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    //   815: astore #11
    //   817: aload #11
    //   819: ifnull -> 830
    //   822: aload_0
    //   823: aload #11
    //   825: aload #4
    //   827: invokevirtual a : (Landroid/view/View;Landroid/util/AttributeSet;)V
    //   830: aload #11
    //   832: areturn
  }
  
  public final View r(Context paramContext, String paramString1, String paramString2) {
    Map<String, Constructor<? extends View>> map = e;
    Constructor constructor1 = map.get(paramString1);
    Constructor<? extends View> constructor = constructor1;
    if (constructor1 == null) {
      if (paramString2 != null)
        try {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramString2);
          stringBuilder.append(paramString1);
          paramString2 = stringBuilder.toString();
          constructor = Class.forName(paramString2, false, paramContext.getClassLoader()).<View>asSubclass(View.class).getConstructor(b);
          map.put(paramString1, constructor);
          constructor.setAccessible(true);
          return constructor.newInstance(this.a);
        } catch (Exception exception) {
          return null;
        }  
    } else {
      constructor.setAccessible(true);
      return constructor.newInstance(this.a);
    } 
    paramString2 = paramString1;
    constructor = Class.forName(paramString2, false, paramContext.getClassLoader()).<View>asSubclass(View.class).getConstructor(b);
    map.put(paramString1, constructor);
    constructor.setAccessible(true);
    return constructor.newInstance(this.a);
  }
  
  public final View s(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    String str = paramString;
    if (paramString.equals("view"))
      str = paramAttributeSet.getAttributeValue(null, "class"); 
    try {
      Object[] arrayOfObject1;
      Object[] arrayOfObject2 = this.a;
      arrayOfObject2[0] = paramContext;
      arrayOfObject2[1] = paramAttributeSet;
      if (-1 == str.indexOf('.')) {
        int i = 0;
        while (true) {
          String[] arrayOfString = d;
          if (i < arrayOfString.length) {
            View view = r(paramContext, str, arrayOfString[i]);
            if (view != null)
              return view; 
            i++;
            continue;
          } 
          return null;
        } 
      } 
      return r((Context)arrayOfObject1, str, null);
    } catch (Exception exception) {
      return null;
    } finally {
      Object[] arrayOfObject = this.a;
      arrayOfObject[0] = null;
      arrayOfObject[1] = null;
    } 
  }
  
  public final void u(View paramView, String paramString) {
    if (paramView != null)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(AppCompatViewInflater.class.getName());
    stringBuilder.append(" asked to inflate view for <");
    stringBuilder.append(paramString);
    stringBuilder.append(">, but returned null");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public static class a implements View.OnClickListener {
    public final View a;
    
    public final String b;
    
    public Method c;
    
    public Context d;
    
    public a(View param1View, String param1String) {
      this.a = param1View;
      this.b = param1String;
    }
    
    public final void a(Context param1Context, String param1String) {
      while (true) {
        String str;
        if (param1Context != null) {
          try {
            if (!param1Context.isRestricted()) {
              Method method = param1Context.getClass().getMethod(this.b, new Class[] { View.class });
              if (method != null) {
                this.c = method;
                this.d = param1Context;
                return;
              } 
            } 
          } catch (NoSuchMethodException noSuchMethodException) {}
          if (param1Context instanceof ContextWrapper) {
            param1Context = ((ContextWrapper)param1Context).getBaseContext();
            continue;
          } 
          param1Context = null;
          continue;
        } 
        int i = this.a.getId();
        if (i == -1) {
          str = "";
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" with id '");
          stringBuilder1.append(this.a.getContext().getResources().getResourceEntryName(i));
          stringBuilder1.append("'");
          str = stringBuilder1.toString();
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not find method ");
        stringBuilder.append(this.b);
        stringBuilder.append("(View) in a parent or ancestor Context for android:onClick attribute defined on view ");
        stringBuilder.append(this.a.getClass());
        stringBuilder.append(str);
        IllegalStateException illegalStateException = new IllegalStateException(stringBuilder.toString());
        throw illegalStateException;
      } 
    }
    
    public void onClick(View param1View) {
      if (this.c == null)
        a(this.a.getContext(), this.b); 
      try {
        this.c.invoke(this.d, new Object[] { param1View });
        return;
      } catch (IllegalAccessException illegalAccessException) {
        throw new IllegalStateException("Could not execute non-public method for android:onClick", illegalAccessException);
      } catch (InvocationTargetException invocationTargetException) {
        throw new IllegalStateException("Could not execute method for android:onClick", invocationTargetException);
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\app\AppCompatViewInflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */