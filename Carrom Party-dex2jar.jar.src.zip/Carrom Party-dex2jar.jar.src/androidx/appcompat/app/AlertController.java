package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.widget.NestedScrollView;
import b.b.j;
import b.h.n.r;
import java.lang.ref.WeakReference;

public class AlertController {
  public NestedScrollView A;
  
  public int B = 0;
  
  public Drawable C;
  
  public ImageView D;
  
  public TextView E;
  
  public TextView F;
  
  public View G;
  
  public ListAdapter H;
  
  public int I = -1;
  
  public int J;
  
  public int K;
  
  public int L;
  
  public int M;
  
  public int N;
  
  public int O;
  
  public boolean P;
  
  public int Q = 0;
  
  public Handler R;
  
  public final View.OnClickListener S = new a(this);
  
  public final Context a;
  
  public final b.b.k.g b;
  
  public final Window c;
  
  public final int d;
  
  public CharSequence e;
  
  public CharSequence f;
  
  public ListView g;
  
  public View h;
  
  public int i;
  
  public int j;
  
  public int k;
  
  public int l;
  
  public int m;
  
  public boolean n = false;
  
  public Button o;
  
  public CharSequence p;
  
  public Message q;
  
  public Drawable r;
  
  public Button s;
  
  public CharSequence t;
  
  public Message u;
  
  public Drawable v;
  
  public Button w;
  
  public CharSequence x;
  
  public Message y;
  
  public Drawable z;
  
  public AlertController(Context paramContext, b.b.k.g paramg, Window paramWindow) {
    this.a = paramContext;
    this.b = paramg;
    this.c = paramWindow;
    this.R = new g((DialogInterface)paramg);
    TypedArray typedArray = paramContext.obtainStyledAttributes(null, j.G, b.b.a.n, 0);
    this.J = typedArray.getResourceId(j.H, 0);
    this.K = typedArray.getResourceId(j.J, 0);
    this.L = typedArray.getResourceId(j.L, 0);
    this.M = typedArray.getResourceId(j.M, 0);
    this.N = typedArray.getResourceId(j.O, 0);
    this.O = typedArray.getResourceId(j.K, 0);
    this.P = typedArray.getBoolean(j.N, true);
    this.d = typedArray.getDimensionPixelSize(j.I, 0);
    typedArray.recycle();
    paramg.f(1);
  }
  
  public static boolean a(View paramView) {
    if (paramView.onCheckIsTextEditor())
      return true; 
    if (!(paramView instanceof ViewGroup))
      return false; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int i = viewGroup.getChildCount();
    while (i > 0) {
      int j = i - 1;
      i = j;
      if (a(viewGroup.getChildAt(j)))
        return true; 
    } 
    return false;
  }
  
  public static void f(View paramView1, View paramView2, View paramView3) {
    boolean bool = false;
    if (paramView2 != null) {
      byte b;
      if (paramView1.canScrollVertically(-1)) {
        b = 0;
      } else {
        b = 4;
      } 
      paramView2.setVisibility(b);
    } 
    if (paramView3 != null) {
      byte b;
      if (paramView1.canScrollVertically(1)) {
        b = bool;
      } else {
        b = 4;
      } 
      paramView3.setVisibility(b);
    } 
  }
  
  public static boolean z(Context paramContext) {
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(b.b.a.m, typedValue, true);
    return (typedValue.data != 0);
  }
  
  public final void b(Button paramButton) {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    layoutParams.gravity = 1;
    layoutParams.weight = 0.5F;
    paramButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  public int c(int paramInt) {
    TypedValue typedValue = new TypedValue();
    this.a.getTheme().resolveAttribute(paramInt, typedValue, true);
    return typedValue.resourceId;
  }
  
  public ListView d() {
    return this.g;
  }
  
  public void e() {
    int i = j();
    this.b.setContentView(i);
    y();
  }
  
  public boolean g(int paramInt, KeyEvent paramKeyEvent) {
    NestedScrollView nestedScrollView = this.A;
    return (nestedScrollView != null && nestedScrollView.q(paramKeyEvent));
  }
  
  public boolean h(int paramInt, KeyEvent paramKeyEvent) {
    NestedScrollView nestedScrollView = this.A;
    return (nestedScrollView != null && nestedScrollView.q(paramKeyEvent));
  }
  
  public final ViewGroup i(View paramView1, View paramView2) {
    if (paramView1 == null) {
      paramView1 = paramView2;
      if (paramView2 instanceof ViewStub)
        paramView1 = ((ViewStub)paramView2).inflate(); 
      return (ViewGroup)paramView1;
    } 
    if (paramView2 != null) {
      ViewParent viewParent = paramView2.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(paramView2); 
    } 
    paramView2 = paramView1;
    if (paramView1 instanceof ViewStub)
      paramView2 = ((ViewStub)paramView1).inflate(); 
    return (ViewGroup)paramView2;
  }
  
  public final int j() {
    int i = this.K;
    return (i == 0) ? this.J : ((this.Q == 1) ? i : this.J);
  }
  
  public void k(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage, Drawable paramDrawable) {
    Message message = paramMessage;
    if (paramMessage == null) {
      message = paramMessage;
      if (paramOnClickListener != null)
        message = this.R.obtainMessage(paramInt, paramOnClickListener); 
    } 
    if (paramInt != -3) {
      if (paramInt != -2) {
        if (paramInt == -1) {
          this.p = paramCharSequence;
          this.q = message;
          this.r = paramDrawable;
          return;
        } 
        throw new IllegalArgumentException("Button does not exist");
      } 
      this.t = paramCharSequence;
      this.u = message;
      this.v = paramDrawable;
      return;
    } 
    this.x = paramCharSequence;
    this.y = message;
    this.z = paramDrawable;
  }
  
  public void l(View paramView) {
    this.G = paramView;
  }
  
  public void m(int paramInt) {
    this.C = null;
    this.B = paramInt;
    ImageView imageView = this.D;
    if (imageView != null) {
      if (paramInt != 0) {
        imageView.setVisibility(0);
        this.D.setImageResource(this.B);
        return;
      } 
      imageView.setVisibility(8);
    } 
  }
  
  public void n(Drawable paramDrawable) {
    this.C = paramDrawable;
    this.B = 0;
    ImageView imageView = this.D;
    if (imageView != null) {
      if (paramDrawable != null) {
        imageView.setVisibility(0);
        this.D.setImageDrawable(paramDrawable);
        return;
      } 
      imageView.setVisibility(8);
    } 
  }
  
  public void o(CharSequence paramCharSequence) {
    this.f = paramCharSequence;
    TextView textView = this.F;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public final void p(ViewGroup paramViewGroup, View paramView, int paramInt1, int paramInt2) {
    View view1 = this.c.findViewById(b.b.f.B);
    View view2 = this.c.findViewById(b.b.f.A);
    if (Build.VERSION.SDK_INT >= 23) {
      r.W(paramView, paramInt1, paramInt2);
      if (view1 != null)
        paramViewGroup.removeView(view1); 
      if (view2 != null) {
        paramViewGroup.removeView(view2);
        return;
      } 
    } else {
      paramView = view1;
      if (view1 != null) {
        paramView = view1;
        if ((paramInt1 & 0x1) == 0) {
          paramViewGroup.removeView(view1);
          paramView = null;
        } 
      } 
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if ((paramInt1 & 0x2) == 0) {
          paramViewGroup.removeView(view2);
          view1 = null;
        } 
      } 
      if (paramView != null || view1 != null) {
        if (this.f != null) {
          this.A.setOnScrollChangeListener(new b(this, paramView, view1));
          this.A.post(new c(this, paramView, view1));
          return;
        } 
        ListView listView = this.g;
        if (listView != null) {
          listView.setOnScrollListener(new d(this, paramView, view1));
          this.g.post(new e(this, paramView, view1));
          return;
        } 
        if (paramView != null)
          paramViewGroup.removeView(paramView); 
        if (view1 != null)
          paramViewGroup.removeView(view1); 
      } 
    } 
  }
  
  public void q(CharSequence paramCharSequence) {
    this.e = paramCharSequence;
    TextView textView = this.E;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public void r(int paramInt) {
    this.h = null;
    this.i = paramInt;
    this.n = false;
  }
  
  public void s(View paramView) {
    this.h = paramView;
    this.i = 0;
    this.n = false;
  }
  
  public void t(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.h = paramView;
    this.i = 0;
    this.n = true;
    this.j = paramInt1;
    this.k = paramInt2;
    this.l = paramInt3;
    this.m = paramInt4;
  }
  
  public final void u(ViewGroup paramViewGroup) {
    int i;
    Button button = (Button)paramViewGroup.findViewById(16908313);
    this.o = button;
    button.setOnClickListener(this.S);
    boolean bool1 = TextUtils.isEmpty(this.p);
    boolean bool = true;
    if (bool1 && this.r == null) {
      this.o.setVisibility(8);
      i = 0;
    } else {
      this.o.setText(this.p);
      Drawable drawable = this.r;
      if (drawable != null) {
        int j = this.d;
        drawable.setBounds(0, 0, j, j);
        this.o.setCompoundDrawables(this.r, null, null, null);
      } 
      this.o.setVisibility(0);
      i = 1;
    } 
    button = (Button)paramViewGroup.findViewById(16908314);
    this.s = button;
    button.setOnClickListener(this.S);
    if (TextUtils.isEmpty(this.t) && this.v == null) {
      this.s.setVisibility(8);
    } else {
      this.s.setText(this.t);
      Drawable drawable = this.v;
      if (drawable != null) {
        int j = this.d;
        drawable.setBounds(0, 0, j, j);
        this.s.setCompoundDrawables(this.v, null, null, null);
      } 
      this.s.setVisibility(0);
      i |= 0x2;
    } 
    button = (Button)paramViewGroup.findViewById(16908315);
    this.w = button;
    button.setOnClickListener(this.S);
    if (TextUtils.isEmpty(this.x) && this.z == null) {
      this.w.setVisibility(8);
    } else {
      this.w.setText(this.x);
      Drawable drawable = this.r;
      if (drawable != null) {
        int j = this.d;
        drawable.setBounds(0, 0, j, j);
        this.o.setCompoundDrawables(this.r, null, null, null);
      } 
      this.w.setVisibility(0);
      i |= 0x4;
    } 
    if (z(this.a))
      if (i == 1) {
        b(this.o);
      } else if (i == 2) {
        b(this.s);
      } else if (i == 4) {
        b(this.w);
      }  
    if (i != 0) {
      i = bool;
    } else {
      i = 0;
    } 
    if (i == 0)
      paramViewGroup.setVisibility(8); 
  }
  
  public final void v(ViewGroup paramViewGroup) {
    NestedScrollView nestedScrollView = (NestedScrollView)this.c.findViewById(b.b.f.C);
    this.A = nestedScrollView;
    nestedScrollView.setFocusable(false);
    this.A.setNestedScrollingEnabled(false);
    TextView textView = (TextView)paramViewGroup.findViewById(16908299);
    this.F = textView;
    if (textView == null)
      return; 
    CharSequence charSequence = this.f;
    if (charSequence != null) {
      textView.setText(charSequence);
      return;
    } 
    textView.setVisibility(8);
    this.A.removeView((View)this.F);
    if (this.g != null) {
      paramViewGroup = (ViewGroup)this.A.getParent();
      int i = paramViewGroup.indexOfChild((View)this.A);
      paramViewGroup.removeViewAt(i);
      paramViewGroup.addView((View)this.g, i, new ViewGroup.LayoutParams(-1, -1));
      return;
    } 
    paramViewGroup.setVisibility(8);
  }
  
  public final void w(ViewGroup paramViewGroup) {
    View view = this.h;
    boolean bool = false;
    if (view == null)
      if (this.i != 0) {
        view = LayoutInflater.from(this.a).inflate(this.i, paramViewGroup, false);
      } else {
        view = null;
      }  
    if (view != null)
      bool = true; 
    if (!bool || !a(view))
      this.c.setFlags(131072, 131072); 
    if (bool) {
      FrameLayout frameLayout = (FrameLayout)this.c.findViewById(b.b.f.o);
      frameLayout.addView(view, new ViewGroup.LayoutParams(-1, -1));
      if (this.n)
        frameLayout.setPadding(this.j, this.k, this.l, this.m); 
      if (this.g != null) {
        ((LinearLayoutCompat.a)paramViewGroup.getLayoutParams()).a = 0.0F;
        return;
      } 
    } else {
      paramViewGroup.setVisibility(8);
    } 
  }
  
  public final void x(ViewGroup paramViewGroup) {
    Drawable drawable;
    if (this.G != null) {
      ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -2);
      paramViewGroup.addView(this.G, 0, layoutParams);
      this.c.findViewById(b.b.f.U).setVisibility(8);
      return;
    } 
    this.D = (ImageView)this.c.findViewById(16908294);
    if ((TextUtils.isEmpty(this.e) ^ true) != 0 && this.P) {
      TextView textView = (TextView)this.c.findViewById(b.b.f.k);
      this.E = textView;
      textView.setText(this.e);
      int i = this.B;
      if (i != 0) {
        this.D.setImageResource(i);
        return;
      } 
      drawable = this.C;
      if (drawable != null) {
        this.D.setImageDrawable(drawable);
        return;
      } 
      this.E.setPadding(this.D.getPaddingLeft(), this.D.getPaddingTop(), this.D.getPaddingRight(), this.D.getPaddingBottom());
      this.D.setVisibility(8);
      return;
    } 
    this.c.findViewById(b.b.f.U).setVisibility(8);
    this.D.setVisibility(8);
    drawable.setVisibility(8);
  }
  
  public final void y() {
    int m;
    boolean bool;
    View view4 = this.c.findViewById(b.b.f.z);
    int i = b.b.f.V;
    View view3 = view4.findViewById(i);
    int j = b.b.f.n;
    View view2 = view4.findViewById(j);
    int k = b.b.f.l;
    View view1 = view4.findViewById(k);
    ViewGroup viewGroup4 = (ViewGroup)view4.findViewById(b.b.f.p);
    w(viewGroup4);
    View view7 = viewGroup4.findViewById(i);
    View view6 = viewGroup4.findViewById(j);
    View view5 = viewGroup4.findViewById(k);
    ViewGroup viewGroup3 = i(view7, view3);
    ViewGroup viewGroup2 = i(view6, view2);
    ViewGroup viewGroup1 = i(view5, view1);
    v(viewGroup2);
    u(viewGroup1);
    x(viewGroup3);
    j = 0;
    if (viewGroup4 != null && viewGroup4.getVisibility() != 8) {
      i = 1;
    } else {
      i = 0;
    } 
    if (viewGroup3 != null && viewGroup3.getVisibility() != 8) {
      m = 1;
    } else {
      m = 0;
    } 
    if (viewGroup1 != null && viewGroup1.getVisibility() != 8) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && viewGroup2 != null) {
      View view = viewGroup2.findViewById(b.b.f.Q);
      if (view != null)
        view.setVisibility(0); 
    } 
    if (m) {
      View view;
      NestedScrollView nestedScrollView = this.A;
      if (nestedScrollView != null)
        nestedScrollView.setClipToPadding(true); 
      nestedScrollView = null;
      if (this.f != null || this.g != null)
        view = viewGroup3.findViewById(b.b.f.T); 
      if (view != null)
        view.setVisibility(0); 
    } else if (viewGroup2 != null) {
      View view = viewGroup2.findViewById(b.b.f.R);
      if (view != null)
        view.setVisibility(0); 
    } 
    ListView listView = this.g;
    if (listView instanceof RecycleListView)
      ((RecycleListView)listView).a(m, bool); 
    if (i == 0) {
      NestedScrollView nestedScrollView;
      listView = this.g;
      if (listView == null)
        nestedScrollView = this.A; 
      if (nestedScrollView != null) {
        i = j;
        if (bool)
          i = 2; 
        p(viewGroup2, (View)nestedScrollView, m | i, 3);
      } 
    } 
    listView = this.g;
    if (listView != null) {
      ListAdapter listAdapter = this.H;
      if (listAdapter != null) {
        listView.setAdapter(listAdapter);
        i = this.I;
        if (i > -1) {
          listView.setItemChecked(i, true);
          listView.setSelection(i);
        } 
      } 
    } 
  }
  
  public static class RecycleListView extends ListView {
    public final int a;
    
    public final int b;
    
    public RecycleListView(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, j.W1);
      this.b = typedArray.getDimensionPixelOffset(j.X1, -1);
      this.a = typedArray.getDimensionPixelOffset(j.Y1, -1);
    }
    
    public void a(boolean param1Boolean1, boolean param1Boolean2) {
      if (!param1Boolean2 || !param1Boolean1) {
        int i;
        int j;
        int k = getPaddingLeft();
        if (param1Boolean1) {
          i = getPaddingTop();
        } else {
          i = this.a;
        } 
        int m = getPaddingRight();
        if (param1Boolean2) {
          j = getPaddingBottom();
        } else {
          j = this.b;
        } 
        setPadding(k, i, m, j);
      } 
    }
  }
  
  public class a implements View.OnClickListener {
    public a(AlertController this$0) {}
    
    public void onClick(View param1View) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Landroidx/appcompat/app/AlertController;
      //   4: astore_2
      //   5: aload_1
      //   6: aload_2
      //   7: getfield o : Landroid/widget/Button;
      //   10: if_acmpne -> 30
      //   13: aload_2
      //   14: getfield q : Landroid/os/Message;
      //   17: astore_3
      //   18: aload_3
      //   19: ifnull -> 30
      //   22: aload_3
      //   23: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   26: astore_1
      //   27: goto -> 82
      //   30: aload_1
      //   31: aload_2
      //   32: getfield s : Landroid/widget/Button;
      //   35: if_acmpne -> 55
      //   38: aload_2
      //   39: getfield u : Landroid/os/Message;
      //   42: astore_3
      //   43: aload_3
      //   44: ifnull -> 55
      //   47: aload_3
      //   48: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   51: astore_1
      //   52: goto -> 82
      //   55: aload_1
      //   56: aload_2
      //   57: getfield w : Landroid/widget/Button;
      //   60: if_acmpne -> 80
      //   63: aload_2
      //   64: getfield y : Landroid/os/Message;
      //   67: astore_1
      //   68: aload_1
      //   69: ifnull -> 80
      //   72: aload_1
      //   73: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   76: astore_1
      //   77: goto -> 82
      //   80: aconst_null
      //   81: astore_1
      //   82: aload_1
      //   83: ifnull -> 90
      //   86: aload_1
      //   87: invokevirtual sendToTarget : ()V
      //   90: aload_0
      //   91: getfield a : Landroidx/appcompat/app/AlertController;
      //   94: astore_1
      //   95: aload_1
      //   96: getfield R : Landroid/os/Handler;
      //   99: iconst_1
      //   100: aload_1
      //   101: getfield b : Lb/b/k/g;
      //   104: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
      //   107: invokevirtual sendToTarget : ()V
      //   110: return
    }
  }
  
  public class b implements NestedScrollView.b {
    public b(AlertController this$0, View param1View1, View param1View2) {}
    
    public void a(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      AlertController.f((View)param1NestedScrollView, this.a, this.b);
    }
  }
  
  public class c implements Runnable {
    public c(AlertController this$0, View param1View1, View param1View2) {}
    
    public void run() {
      AlertController.f((View)this.c.A, this.a, this.b);
    }
  }
  
  public class d implements AbsListView.OnScrollListener {
    public d(AlertController this$0, View param1View1, View param1View2) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {
      AlertController.f((View)param1AbsListView, this.a, this.b);
    }
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {}
  }
  
  public class e implements Runnable {
    public e(AlertController this$0, View param1View1, View param1View2) {}
    
    public void run() {
      AlertController.f((View)this.c.g, this.a, this.b);
    }
  }
  
  public static class f {
    public int A;
    
    public int B;
    
    public int C;
    
    public int D;
    
    public boolean E = false;
    
    public boolean[] F;
    
    public boolean G;
    
    public boolean H;
    
    public int I = -1;
    
    public DialogInterface.OnMultiChoiceClickListener J;
    
    public Cursor K;
    
    public String L;
    
    public String M;
    
    public AdapterView.OnItemSelectedListener N;
    
    public e O;
    
    public final Context a;
    
    public final LayoutInflater b;
    
    public int c = 0;
    
    public Drawable d;
    
    public int e = 0;
    
    public CharSequence f;
    
    public View g;
    
    public CharSequence h;
    
    public CharSequence i;
    
    public Drawable j;
    
    public DialogInterface.OnClickListener k;
    
    public CharSequence l;
    
    public Drawable m;
    
    public DialogInterface.OnClickListener n;
    
    public CharSequence o;
    
    public Drawable p;
    
    public DialogInterface.OnClickListener q;
    
    public boolean r;
    
    public DialogInterface.OnCancelListener s;
    
    public DialogInterface.OnDismissListener t;
    
    public DialogInterface.OnKeyListener u;
    
    public CharSequence[] v;
    
    public ListAdapter w;
    
    public DialogInterface.OnClickListener x;
    
    public int y;
    
    public View z;
    
    public f(Context param1Context) {
      this.a = param1Context;
      this.r = true;
      this.b = (LayoutInflater)param1Context.getSystemService("layout_inflater");
    }
    
    public void a(AlertController param1AlertController) {
      View view2 = this.g;
      if (view2 != null) {
        param1AlertController.l(view2);
      } else {
        CharSequence charSequence1 = this.f;
        if (charSequence1 != null)
          param1AlertController.q(charSequence1); 
        Drawable drawable = this.d;
        if (drawable != null)
          param1AlertController.n(drawable); 
        int j = this.c;
        if (j != 0)
          param1AlertController.m(j); 
        j = this.e;
        if (j != 0)
          param1AlertController.m(param1AlertController.c(j)); 
      } 
      CharSequence charSequence = this.h;
      if (charSequence != null)
        param1AlertController.o(charSequence); 
      charSequence = this.i;
      if (charSequence != null || this.j != null)
        param1AlertController.k(-1, charSequence, this.k, null, this.j); 
      charSequence = this.l;
      if (charSequence != null || this.m != null)
        param1AlertController.k(-2, charSequence, this.n, null, this.m); 
      charSequence = this.o;
      if (charSequence != null || this.p != null)
        param1AlertController.k(-3, charSequence, this.q, null, this.p); 
      if (this.v != null || this.K != null || this.w != null)
        b(param1AlertController); 
      View view1 = this.z;
      if (view1 != null) {
        if (this.E) {
          param1AlertController.t(view1, this.A, this.B, this.C, this.D);
          return;
        } 
        param1AlertController.s(view1);
        return;
      } 
      int i = this.y;
      if (i != 0)
        param1AlertController.r(i); 
    }
    
    public final void b(AlertController param1AlertController) {
      AlertController.h h;
      AlertController.RecycleListView recycleListView = (AlertController.RecycleListView)this.b.inflate(param1AlertController.L, null);
      if (this.G) {
        if (this.K == null) {
          a a = new a(this, this.a, param1AlertController.M, 16908308, this.v, recycleListView);
        } else {
          b b = new b(this, this.a, this.K, false, recycleListView, param1AlertController);
        } 
      } else {
        int i;
        if (this.H) {
          i = param1AlertController.N;
        } else {
          i = param1AlertController.O;
        } 
        if (this.K != null) {
          SimpleCursorAdapter simpleCursorAdapter = new SimpleCursorAdapter(this.a, i, this.K, new String[] { this.L }, new int[] { 16908308 });
        } else {
          ListAdapter listAdapter = this.w;
          if (listAdapter == null)
            h = new AlertController.h(this.a, i, 16908308, this.v); 
        } 
      } 
      e e1 = this.O;
      if (e1 != null)
        e1.a(recycleListView); 
      param1AlertController.H = (ListAdapter)h;
      param1AlertController.I = this.I;
      if (this.x != null) {
        recycleListView.setOnItemClickListener(new c(this, param1AlertController));
      } else if (this.J != null) {
        recycleListView.setOnItemClickListener(new d(this, recycleListView, param1AlertController));
      } 
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.N;
      if (onItemSelectedListener != null)
        recycleListView.setOnItemSelectedListener(onItemSelectedListener); 
      if (this.H) {
        recycleListView.setChoiceMode(1);
      } else if (this.G) {
        recycleListView.setChoiceMode(2);
      } 
      param1AlertController.g = recycleListView;
    }
    
    public class a extends ArrayAdapter<CharSequence> {
      public a(AlertController.f this$0, Context param2Context, int param2Int1, int param2Int2, CharSequence[] param2ArrayOfCharSequence, AlertController.RecycleListView param2RecycleListView) {
        super(param2Context, param2Int1, param2Int2, (Object[])param2ArrayOfCharSequence);
      }
      
      public View getView(int param2Int, View param2View, ViewGroup param2ViewGroup) {
        param2View = super.getView(param2Int, param2View, param2ViewGroup);
        boolean[] arrayOfBoolean = this.b.F;
        if (arrayOfBoolean != null && arrayOfBoolean[param2Int])
          this.a.setItemChecked(param2Int, true); 
        return param2View;
      }
    }
    
    public class b extends CursorAdapter {
      public final int a;
      
      public final int b;
      
      public b(AlertController.f this$0, Context param2Context, Cursor param2Cursor, boolean param2Boolean, AlertController.RecycleListView param2RecycleListView, AlertController param2AlertController) {
        super(param2Context, param2Cursor, param2Boolean);
        Cursor cursor = getCursor();
        this.a = cursor.getColumnIndexOrThrow(this$0.L);
        this.b = cursor.getColumnIndexOrThrow(this$0.M);
      }
      
      public void bindView(View param2View, Context param2Context, Cursor param2Cursor) {
        ((CheckedTextView)param2View.findViewById(16908308)).setText(param2Cursor.getString(this.a));
        AlertController.RecycleListView recycleListView = this.c;
        int i = param2Cursor.getPosition();
        int j = param2Cursor.getInt(this.b);
        boolean bool = true;
        if (j != 1)
          bool = false; 
        recycleListView.setItemChecked(i, bool);
      }
      
      public View newView(Context param2Context, Cursor param2Cursor, ViewGroup param2ViewGroup) {
        return this.e.b.inflate(this.d.M, param2ViewGroup, false);
      }
    }
    
    public class c implements AdapterView.OnItemClickListener {
      public c(AlertController.f this$0, AlertController param2AlertController) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.b.x.onClick((DialogInterface)this.a.b, param2Int);
        if (!this.b.H)
          this.a.b.dismiss(); 
      }
    }
    
    public class d implements AdapterView.OnItemClickListener {
      public d(AlertController.f this$0, AlertController.RecycleListView param2RecycleListView, AlertController param2AlertController) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        boolean[] arrayOfBoolean = this.c.F;
        if (arrayOfBoolean != null)
          arrayOfBoolean[param2Int] = this.a.isItemChecked(param2Int); 
        this.c.J.onClick((DialogInterface)this.b.b, param2Int, this.a.isItemChecked(param2Int));
      }
    }
    
    public static interface e {
      void a(ListView param2ListView);
    }
  }
  
  public class a extends ArrayAdapter<CharSequence> {
    public a(AlertController this$0, Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence, AlertController.RecycleListView param1RecycleListView) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      param1View = super.getView(param1Int, param1View, param1ViewGroup);
      boolean[] arrayOfBoolean = this.b.F;
      if (arrayOfBoolean != null && arrayOfBoolean[param1Int])
        this.a.setItemChecked(param1Int, true); 
      return param1View;
    }
  }
  
  public class b extends CursorAdapter {
    public final int a;
    
    public final int b;
    
    public b(AlertController this$0, Context param1Context, Cursor param1Cursor, boolean param1Boolean, AlertController.RecycleListView param1RecycleListView, AlertController param1AlertController) {
      super(param1Context, param1Cursor, param1Boolean);
      Cursor cursor = getCursor();
      this.a = cursor.getColumnIndexOrThrow(((AlertController.f)this$0).L);
      this.b = cursor.getColumnIndexOrThrow(((AlertController.f)this$0).M);
    }
    
    public void bindView(View param1View, Context param1Context, Cursor param1Cursor) {
      ((CheckedTextView)param1View.findViewById(16908308)).setText(param1Cursor.getString(this.a));
      AlertController.RecycleListView recycleListView = this.c;
      int i = param1Cursor.getPosition();
      int j = param1Cursor.getInt(this.b);
      boolean bool = true;
      if (j != 1)
        bool = false; 
      recycleListView.setItemChecked(i, bool);
    }
    
    public View newView(Context param1Context, Cursor param1Cursor, ViewGroup param1ViewGroup) {
      return this.e.b.inflate(this.d.M, param1ViewGroup, false);
    }
  }
  
  public class c implements AdapterView.OnItemClickListener {
    public c(AlertController this$0, AlertController param1AlertController) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.b.x.onClick((DialogInterface)this.a.b, param1Int);
      if (!this.b.H)
        this.a.b.dismiss(); 
    }
  }
  
  public class d implements AdapterView.OnItemClickListener {
    public d(AlertController this$0, AlertController.RecycleListView param1RecycleListView, AlertController param1AlertController) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      boolean[] arrayOfBoolean = this.c.F;
      if (arrayOfBoolean != null)
        arrayOfBoolean[param1Int] = this.a.isItemChecked(param1Int); 
      this.c.J.onClick((DialogInterface)this.b.b, param1Int, this.a.isItemChecked(param1Int));
    }
  }
  
  public static interface e {
    void a(ListView param1ListView);
  }
  
  public static final class g extends Handler {
    public WeakReference<DialogInterface> a;
    
    public g(DialogInterface param1DialogInterface) {
      this.a = new WeakReference<DialogInterface>(param1DialogInterface);
    }
    
    public void handleMessage(Message param1Message) {
      int i = param1Message.what;
      if (i != -3 && i != -2 && i != -1) {
        if (i != 1)
          return; 
        ((DialogInterface)param1Message.obj).dismiss();
        return;
      } 
      ((DialogInterface.OnClickListener)param1Message.obj).onClick(this.a.get(), param1Message.what);
    }
  }
  
  public static class h extends ArrayAdapter<CharSequence> {
    public h(Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public boolean hasStableIds() {
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\app\AlertController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */