package androidx.appcompat.view.menu;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import b.b.p.j.g;
import b.b.p.j.i;
import b.b.p.j.n;
import b.b.q.g0;

public final class ExpandedMenuView extends ListView implements g.b, n, AdapterView.OnItemClickListener {
  public static final int[] c = new int[] { 16842964, 16843049 };
  
  public g a;
  
  public int b;
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842868);
  }
  
  public ExpandedMenuView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    setOnItemClickListener(this);
    g0 g0 = g0.t(paramContext, paramAttributeSet, c, paramInt, 0);
    if (g0.q(0))
      setBackgroundDrawable(g0.f(0)); 
    if (g0.q(1))
      setDivider(g0.f(1)); 
    g0.u();
  }
  
  public boolean a(i parami) {
    return this.a.L((MenuItem)parami, 0);
  }
  
  public void b(g paramg) {
    this.a = paramg;
  }
  
  public int getWindowAnimations() {
    return this.b;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    setChildrenDrawingCacheEnabled(false);
  }
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    a((i)getAdapter().getItem(paramInt));
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\view\menu\ExpandedMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */