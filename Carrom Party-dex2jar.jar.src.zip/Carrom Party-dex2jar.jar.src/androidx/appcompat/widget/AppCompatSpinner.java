package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import b.b.p.j.p;
import b.b.q.c0;
import b.b.q.m0;
import b.b.q.t;
import b.h.n.q;
import b.h.n.r;

public class AppCompatSpinner extends Spinner implements q {
  public static final int[] i = new int[] { 16843505 };
  
  public final b.b.q.e a;
  
  public final Context b;
  
  public t c;
  
  public SpinnerAdapter d;
  
  public final boolean e;
  
  public f f;
  
  public int g;
  
  public final Rect h;
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, b.b.a.J);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public AppCompatSpinner(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield h : Landroid/graphics/Rect;
    //   18: aload_1
    //   19: aload_2
    //   20: getstatic b/b/j.r2 : [I
    //   23: iload_3
    //   24: iconst_0
    //   25: invokestatic t : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Lb/b/q/g0;
    //   28: astore #10
    //   30: aload_0
    //   31: new b/b/q/e
    //   34: dup
    //   35: aload_0
    //   36: invokespecial <init> : (Landroid/view/View;)V
    //   39: putfield a : Lb/b/q/e;
    //   42: aload #5
    //   44: ifnull -> 64
    //   47: aload_0
    //   48: new b/b/p/d
    //   51: dup
    //   52: aload_1
    //   53: aload #5
    //   55: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/Resources$Theme;)V
    //   58: putfield b : Landroid/content/Context;
    //   61: goto -> 102
    //   64: aload #10
    //   66: getstatic b/b/j.w2 : I
    //   69: iconst_0
    //   70: invokevirtual m : (II)I
    //   73: istore #6
    //   75: iload #6
    //   77: ifeq -> 97
    //   80: aload_0
    //   81: new b/b/p/d
    //   84: dup
    //   85: aload_1
    //   86: iload #6
    //   88: invokespecial <init> : (Landroid/content/Context;I)V
    //   91: putfield b : Landroid/content/Context;
    //   94: goto -> 102
    //   97: aload_0
    //   98: aload_1
    //   99: putfield b : Landroid/content/Context;
    //   102: aconst_null
    //   103: astore #8
    //   105: iload #4
    //   107: istore #7
    //   109: iload #4
    //   111: iconst_m1
    //   112: if_icmpne -> 235
    //   115: aload_1
    //   116: aload_2
    //   117: getstatic androidx/appcompat/widget/AppCompatSpinner.i : [I
    //   120: iload_3
    //   121: iconst_0
    //   122: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   125: astore #5
    //   127: iload #4
    //   129: istore #6
    //   131: aload #5
    //   133: astore #8
    //   135: aload #5
    //   137: iconst_0
    //   138: invokevirtual hasValue : (I)Z
    //   141: ifeq -> 157
    //   144: aload #5
    //   146: astore #8
    //   148: aload #5
    //   150: iconst_0
    //   151: iconst_0
    //   152: invokevirtual getInt : (II)I
    //   155: istore #6
    //   157: iload #6
    //   159: istore #7
    //   161: aload #5
    //   163: ifnull -> 235
    //   166: iload #6
    //   168: istore #4
    //   170: aload #5
    //   172: invokevirtual recycle : ()V
    //   175: iload #4
    //   177: istore #7
    //   179: goto -> 235
    //   182: astore #9
    //   184: goto -> 196
    //   187: astore_1
    //   188: goto -> 223
    //   191: astore #9
    //   193: aconst_null
    //   194: astore #5
    //   196: aload #5
    //   198: astore #8
    //   200: ldc 'AppCompatSpinner'
    //   202: ldc 'Could not read android:spinnerMode'
    //   204: aload #9
    //   206: invokestatic i : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   209: pop
    //   210: iload #4
    //   212: istore #7
    //   214: aload #5
    //   216: ifnull -> 235
    //   219: goto -> 170
    //   222: astore_1
    //   223: aload #8
    //   225: ifnull -> 233
    //   228: aload #8
    //   230: invokevirtual recycle : ()V
    //   233: aload_1
    //   234: athrow
    //   235: iload #7
    //   237: ifeq -> 349
    //   240: iload #7
    //   242: iconst_1
    //   243: if_icmpeq -> 249
    //   246: goto -> 380
    //   249: new androidx/appcompat/widget/AppCompatSpinner$e
    //   252: dup
    //   253: aload_0
    //   254: aload_0
    //   255: getfield b : Landroid/content/Context;
    //   258: aload_2
    //   259: iload_3
    //   260: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   263: astore #5
    //   265: aload_0
    //   266: getfield b : Landroid/content/Context;
    //   269: aload_2
    //   270: getstatic b/b/j.r2 : [I
    //   273: iload_3
    //   274: iconst_0
    //   275: invokestatic t : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Lb/b/q/g0;
    //   278: astore #8
    //   280: aload_0
    //   281: aload #8
    //   283: getstatic b/b/j.v2 : I
    //   286: bipush #-2
    //   288: invokevirtual l : (II)I
    //   291: putfield g : I
    //   294: aload #5
    //   296: aload #8
    //   298: getstatic b/b/j.t2 : I
    //   301: invokevirtual f : (I)Landroid/graphics/drawable/Drawable;
    //   304: invokevirtual j : (Landroid/graphics/drawable/Drawable;)V
    //   307: aload #5
    //   309: aload #10
    //   311: getstatic b/b/j.u2 : I
    //   314: invokevirtual n : (I)Ljava/lang/String;
    //   317: invokevirtual h : (Ljava/lang/CharSequence;)V
    //   320: aload #8
    //   322: invokevirtual u : ()V
    //   325: aload_0
    //   326: aload #5
    //   328: putfield f : Landroidx/appcompat/widget/AppCompatSpinner$f;
    //   331: aload_0
    //   332: new androidx/appcompat/widget/AppCompatSpinner$a
    //   335: dup
    //   336: aload_0
    //   337: aload_0
    //   338: aload #5
    //   340: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;Landroid/view/View;Landroidx/appcompat/widget/AppCompatSpinner$e;)V
    //   343: putfield c : Lb/b/q/t;
    //   346: goto -> 380
    //   349: new androidx/appcompat/widget/AppCompatSpinner$c
    //   352: dup
    //   353: aload_0
    //   354: invokespecial <init> : (Landroidx/appcompat/widget/AppCompatSpinner;)V
    //   357: astore #5
    //   359: aload_0
    //   360: aload #5
    //   362: putfield f : Landroidx/appcompat/widget/AppCompatSpinner$f;
    //   365: aload #5
    //   367: aload #10
    //   369: getstatic b/b/j.u2 : I
    //   372: invokevirtual n : (I)Ljava/lang/String;
    //   375: invokeinterface h : (Ljava/lang/CharSequence;)V
    //   380: aload #10
    //   382: getstatic b/b/j.s2 : I
    //   385: invokevirtual p : (I)[Ljava/lang/CharSequence;
    //   388: astore #5
    //   390: aload #5
    //   392: ifnull -> 420
    //   395: new android/widget/ArrayAdapter
    //   398: dup
    //   399: aload_1
    //   400: ldc 17367048
    //   402: aload #5
    //   404: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   407: astore_1
    //   408: aload_1
    //   409: getstatic b/b/g.v : I
    //   412: invokevirtual setDropDownViewResource : (I)V
    //   415: aload_0
    //   416: aload_1
    //   417: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   420: aload #10
    //   422: invokevirtual u : ()V
    //   425: aload_0
    //   426: iconst_1
    //   427: putfield e : Z
    //   430: aload_0
    //   431: getfield d : Landroid/widget/SpinnerAdapter;
    //   434: astore_1
    //   435: aload_1
    //   436: ifnull -> 449
    //   439: aload_0
    //   440: aload_1
    //   441: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   444: aload_0
    //   445: aconst_null
    //   446: putfield d : Landroid/widget/SpinnerAdapter;
    //   449: aload_0
    //   450: getfield a : Lb/b/q/e;
    //   453: aload_2
    //   454: iload_3
    //   455: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   458: return
    // Exception table:
    //   from	to	target	type
    //   115	127	191	java/lang/Exception
    //   115	127	187	finally
    //   135	144	182	java/lang/Exception
    //   135	144	222	finally
    //   148	157	182	java/lang/Exception
    //   148	157	222	finally
    //   200	210	222	finally
  }
  
  public int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int k = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int m = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i1 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int j = Math.max(0, i - 15 - i1 - i);
    View view = null;
    i = 0;
    while (j < i1) {
      int i3 = paramSpinnerAdapter.getItemViewType(j);
      int i2 = k;
      if (i3 != k) {
        view = null;
        i2 = i3;
      } 
      view = paramSpinnerAdapter.getView(j, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(m, n);
      i = Math.max(i, view.getMeasuredWidth());
      j++;
      k = i2;
    } 
    j = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.h);
      Rect rect = this.h;
      j = i + rect.left + rect.right;
    } 
    return j;
  }
  
  public void b() {
    if (Build.VERSION.SDK_INT >= 17) {
      this.f.m(getTextDirection(), getTextAlignment());
      return;
    } 
    this.f.m(-1, -1);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    b.b.q.e e1 = this.a;
    if (e1 != null)
      e1.b(); 
  }
  
  public int getDropDownHorizontalOffset() {
    f f1 = this.f;
    return (f1 != null) ? f1.b() : ((Build.VERSION.SDK_INT >= 16) ? super.getDropDownHorizontalOffset() : 0);
  }
  
  public int getDropDownVerticalOffset() {
    f f1 = this.f;
    return (f1 != null) ? f1.n() : ((Build.VERSION.SDK_INT >= 16) ? super.getDropDownVerticalOffset() : 0);
  }
  
  public int getDropDownWidth() {
    return (this.f != null) ? this.g : ((Build.VERSION.SDK_INT >= 16) ? super.getDropDownWidth() : 0);
  }
  
  public final f getInternalPopup() {
    return this.f;
  }
  
  public Drawable getPopupBackground() {
    f f1 = this.f;
    return (f1 != null) ? f1.g() : ((Build.VERSION.SDK_INT >= 16) ? super.getPopupBackground() : null);
  }
  
  public Context getPopupContext() {
    return this.b;
  }
  
  public CharSequence getPrompt() {
    f f1 = this.f;
    return (f1 != null) ? f1.e() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    b.b.q.e e1 = this.a;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    b.b.q.e e1 = this.a;
    return (e1 != null) ? e1.d() : null;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    f f1 = this.f;
    if (f1 != null && f1.a())
      this.f.dismiss(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.f != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.a) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new b(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    f f1 = this.f;
    if (f1 != null && f1.a()) {
      bool = true;
    } else {
      bool = false;
    } 
    savedState.a = bool;
    return (Parcelable)savedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    t t1 = this.c;
    return (t1 != null && t1.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    f f1 = this.f;
    if (f1 != null) {
      if (!f1.a())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.e) {
      this.d = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.f != null) {
      Context context2 = this.b;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.f.o(new d(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    b.b.q.e e1 = this.a;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    b.b.q.e e1 = this.a;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    f f1 = this.f;
    if (f1 != null) {
      f1.l(paramInt);
      this.f.d(paramInt);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16)
      super.setDropDownHorizontalOffset(paramInt); 
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    f f1 = this.f;
    if (f1 != null) {
      f1.k(paramInt);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16)
      super.setDropDownVerticalOffset(paramInt); 
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.f != null) {
      this.g = paramInt;
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16)
      super.setDropDownWidth(paramInt); 
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    f f1 = this.f;
    if (f1 != null) {
      f1.j(paramDrawable);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16)
      super.setPopupBackgroundDrawable(paramDrawable); 
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(b.b.l.a.a.d(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    f f1 = this.f;
    if (f1 != null) {
      f1.h(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    b.b.q.e e1 = this.a;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    b.b.q.e e1 = this.a;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new a();
    
    public boolean a;
    
    public SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.a = bool;
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.a);
    }
    
    public static final class a implements Parcelable.Creator<SavedState> {
      public AppCompatSpinner.SavedState a(Parcel param2Parcel) {
        return new AppCompatSpinner.SavedState(param2Parcel);
      }
      
      public AppCompatSpinner.SavedState[] b(int param2Int) {
        return new AppCompatSpinner.SavedState[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.Creator<SavedState> {
    public AppCompatSpinner.SavedState a(Parcel param1Parcel) {
      return new AppCompatSpinner.SavedState(param1Parcel);
    }
    
    public AppCompatSpinner.SavedState[] b(int param1Int) {
      return new AppCompatSpinner.SavedState[param1Int];
    }
  }
  
  public class a extends t {
    public a(AppCompatSpinner this$0, View param1View, AppCompatSpinner.e param1e) {
      super(param1View);
    }
    
    public p b() {
      return this.j;
    }
    
    @SuppressLint({"SyntheticAccessor"})
    public boolean c() {
      if (!this.k.getInternalPopup().a())
        this.k.b(); 
      return true;
    }
  }
  
  public class b implements ViewTreeObserver.OnGlobalLayoutListener {
    public b(AppCompatSpinner this$0) {}
    
    public void onGlobalLayout() {
      if (!this.a.getInternalPopup().a())
        this.a.b(); 
      ViewTreeObserver viewTreeObserver = this.a.getViewTreeObserver();
      if (viewTreeObserver != null) {
        if (Build.VERSION.SDK_INT >= 16) {
          viewTreeObserver.removeOnGlobalLayoutListener(this);
          return;
        } 
        viewTreeObserver.removeGlobalOnLayoutListener(this);
      } 
    }
  }
  
  public class c implements f, DialogInterface.OnClickListener {
    public b.b.k.b a;
    
    public ListAdapter b;
    
    public CharSequence c;
    
    public c(AppCompatSpinner this$0) {}
    
    public boolean a() {
      b.b.k.b b1 = this.a;
      return (b1 != null) ? b1.isShowing() : false;
    }
    
    public int b() {
      return 0;
    }
    
    public void d(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }
    
    public void dismiss() {
      b.b.k.b b1 = this.a;
      if (b1 != null) {
        b1.dismiss();
        this.a = null;
      } 
    }
    
    public CharSequence e() {
      return this.c;
    }
    
    public Drawable g() {
      return null;
    }
    
    public void h(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
    }
    
    public void j(Drawable param1Drawable) {
      Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }
    
    public void k(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }
    
    public void l(int param1Int) {
      Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }
    
    public void m(int param1Int1, int param1Int2) {
      if (this.b == null)
        return; 
      b.b.k.b.a a = new b.b.k.b.a(this.d.getPopupContext());
      CharSequence charSequence = this.c;
      if (charSequence != null)
        a.h(charSequence); 
      a.g(this.b, this.d.getSelectedItemPosition(), this);
      b.b.k.b b1 = a.a();
      this.a = b1;
      ListView listView = b1.g();
      if (Build.VERSION.SDK_INT >= 17) {
        listView.setTextDirection(param1Int1);
        listView.setTextAlignment(param1Int2);
      } 
      this.a.show();
    }
    
    public int n() {
      return 0;
    }
    
    public void o(ListAdapter param1ListAdapter) {
      this.b = param1ListAdapter;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.d.setSelection(param1Int);
      if (this.d.getOnItemClickListener() != null)
        this.d.performItemClick(null, param1Int, this.b.getItemId(param1Int)); 
      dismiss();
    }
  }
  
  public static class d implements ListAdapter, SpinnerAdapter {
    public SpinnerAdapter a;
    
    public ListAdapter b;
    
    public d(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.a = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.b = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        ThemedSpinnerAdapter themedSpinnerAdapter;
        if (Build.VERSION.SDK_INT >= 23 && param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          themedSpinnerAdapter = (ThemedSpinnerAdapter)param1SpinnerAdapter;
          if (themedSpinnerAdapter.getDropDownViewTheme() != param1Theme) {
            themedSpinnerAdapter.setDropDownViewTheme(param1Theme);
            return;
          } 
        } else if (themedSpinnerAdapter instanceof c0) {
          c0 c0 = (c0)themedSpinnerAdapter;
          if (c0.getDropDownViewTheme() == null)
            c0.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.b;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.a;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.b;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.a;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.a;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  public class e extends ListPopupWindow implements f {
    public CharSequence T;
    
    public ListAdapter U;
    
    public final Rect V = new Rect();
    
    public int W;
    
    public e(AppCompatSpinner this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      y((View)this$0);
      E(true);
      J(0);
      G(new a(this, this$0));
    }
    
    public void N() {
      Drawable drawable = g();
      int i = 0;
      if (drawable != null) {
        drawable.getPadding(this.X.h);
        if (m0.b((View)this.X)) {
          i = this.X.h.right;
        } else {
          i = -this.X.h.left;
        } 
      } else {
        Rect rect = this.X.h;
        rect.right = 0;
        rect.left = 0;
      } 
      int k = this.X.getPaddingLeft();
      int m = this.X.getPaddingRight();
      int n = this.X.getWidth();
      AppCompatSpinner appCompatSpinner = this.X;
      int j = appCompatSpinner.g;
      if (j == -2) {
        int i1 = appCompatSpinner.a((SpinnerAdapter)this.U, g());
        j = (this.X.getContext().getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.X.h;
        int i2 = j - rect.left - rect.right;
        j = i1;
        if (i1 > i2)
          j = i2; 
        A(Math.max(j, n - k - m));
      } else if (j == -1) {
        A(n - k - m);
      } else {
        A(j);
      } 
      if (m0.b((View)this.X)) {
        i += n - m - u() - O();
      } else {
        i += k + O();
      } 
      d(i);
    }
    
    public int O() {
      return this.W;
    }
    
    public boolean P(View param1View) {
      return (r.A(param1View) && param1View.getGlobalVisibleRect(this.V));
    }
    
    public CharSequence e() {
      return this.T;
    }
    
    public void h(CharSequence param1CharSequence) {
      this.T = param1CharSequence;
    }
    
    public void l(int param1Int) {
      this.W = param1Int;
    }
    
    public void m(int param1Int1, int param1Int2) {
      boolean bool = a();
      N();
      D(2);
      show();
      ListView listView = i();
      listView.setChoiceMode(1);
      if (Build.VERSION.SDK_INT >= 17) {
        listView.setTextDirection(param1Int1);
        listView.setTextAlignment(param1Int2);
      } 
      K(this.X.getSelectedItemPosition());
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.X.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        F(new c(this, b));
      } 
    }
    
    public void o(ListAdapter param1ListAdapter) {
      super.o(param1ListAdapter);
      this.U = param1ListAdapter;
    }
    
    public class a implements AdapterView.OnItemClickListener {
      public a(AppCompatSpinner.e this$0, AppCompatSpinner param2AppCompatSpinner) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.a.X.setSelection(param2Int);
        if (this.a.X.getOnItemClickListener() != null) {
          AppCompatSpinner.e e1 = this.a;
          e1.X.performItemClick(param2View, param2Int, e1.U.getItemId(param2Int));
        } 
        this.a.dismiss();
      }
    }
    
    public class b implements ViewTreeObserver.OnGlobalLayoutListener {
      public b(AppCompatSpinner.e this$0) {}
      
      public void onGlobalLayout() {
        AppCompatSpinner.e e1 = this.a;
        if (!e1.P((View)e1.X)) {
          this.a.dismiss();
          return;
        } 
        this.a.N();
        AppCompatSpinner.e.M(this.a);
      }
    }
    
    public class c implements PopupWindow.OnDismissListener {
      public c(AppCompatSpinner.e this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.b.X.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.a); 
      }
    }
  }
  
  public class a implements AdapterView.OnItemClickListener {
    public a(AppCompatSpinner this$0, AppCompatSpinner param1AppCompatSpinner) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.a.X.setSelection(param1Int);
      if (this.a.X.getOnItemClickListener() != null) {
        AppCompatSpinner.e e1 = this.a;
        e1.X.performItemClick(param1View, param1Int, e1.U.getItemId(param1Int));
      } 
      this.a.dismiss();
    }
  }
  
  public class b implements ViewTreeObserver.OnGlobalLayoutListener {
    public b(AppCompatSpinner this$0) {}
    
    public void onGlobalLayout() {
      AppCompatSpinner.e e1 = this.a;
      if (!e1.P((View)e1.X)) {
        this.a.dismiss();
        return;
      } 
      this.a.N();
      AppCompatSpinner.e.M(this.a);
    }
  }
  
  public class c implements PopupWindow.OnDismissListener {
    public c(AppCompatSpinner this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.b.X.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.a); 
    }
  }
  
  public static interface f {
    boolean a();
    
    int b();
    
    void d(int param1Int);
    
    void dismiss();
    
    CharSequence e();
    
    Drawable g();
    
    void h(CharSequence param1CharSequence);
    
    void j(Drawable param1Drawable);
    
    void k(int param1Int);
    
    void l(int param1Int);
    
    void m(int param1Int1, int param1Int2);
    
    int n();
    
    void o(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\AppCompatSpinner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */