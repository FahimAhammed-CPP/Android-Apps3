package androidx.appcompat.widget;

import android.content.Context;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import b.b.j;
import b.b.p.j.p;
import b.b.q.g0;
import b.b.q.t;

public class ActivityChooserView extends ViewGroup {
  public int C;
  
  public final f a;
  
  public final g b;
  
  public final View c;
  
  public final Drawable d;
  
  public final FrameLayout e;
  
  public final ImageView f;
  
  public final FrameLayout g;
  
  public final ImageView h;
  
  public final int i;
  
  public b.h.n.b j;
  
  public final DataSetObserver k = new a(this);
  
  public final ViewTreeObserver.OnGlobalLayoutListener l = new b(this);
  
  public ListPopupWindow m;
  
  public PopupWindow.OnDismissListener n;
  
  public boolean o;
  
  public int p = 4;
  
  public boolean q;
  
  public ActivityChooserView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    int[] arrayOfInt = j.D;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, paramInt, 0);
    if (Build.VERSION.SDK_INT >= 29)
      saveAttributeDataForStyleable(paramContext, arrayOfInt, paramAttributeSet, typedArray, paramInt, 0); 
    this.p = typedArray.getInt(j.F, 4);
    Drawable drawable = typedArray.getDrawable(j.E);
    typedArray.recycle();
    LayoutInflater.from(getContext()).inflate(b.b.g.e, this, true);
    g g1 = new g(this);
    this.b = g1;
    View view = findViewById(b.b.f.j);
    this.c = view;
    this.d = view.getBackground();
    FrameLayout frameLayout = (FrameLayout)findViewById(b.b.f.r);
    this.g = frameLayout;
    frameLayout.setOnClickListener(g1);
    frameLayout.setOnLongClickListener(g1);
    paramInt = b.b.f.w;
    this.h = (ImageView)frameLayout.findViewById(paramInt);
    frameLayout = (FrameLayout)findViewById(b.b.f.t);
    frameLayout.setOnClickListener(g1);
    frameLayout.setAccessibilityDelegate(new c(this));
    frameLayout.setOnTouchListener((View.OnTouchListener)new d(this, (View)frameLayout));
    this.e = frameLayout;
    ImageView imageView = (ImageView)frameLayout.findViewById(paramInt);
    this.f = imageView;
    imageView.setImageDrawable(drawable);
    f f1 = new f(this);
    this.a = f1;
    f1.registerDataSetObserver(new e(this));
    Resources resources = paramContext.getResources();
    this.i = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(b.b.d.d));
  }
  
  public boolean a() {
    if (b()) {
      getListPopupWindow().dismiss();
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver.isAlive())
        viewTreeObserver.removeGlobalOnLayoutListener(this.l); 
    } 
    return true;
  }
  
  public boolean b() {
    return getListPopupWindow().a();
  }
  
  public boolean c() {
    if (!b()) {
      if (!this.q)
        return false; 
      this.o = false;
      d(this.p);
      throw null;
    } 
    return false;
  }
  
  public void d(int paramInt) {
    if (this.a.b() != null) {
      getViewTreeObserver().addOnGlobalLayoutListener(this.l);
      this.g.getVisibility();
      this.a.a();
      throw null;
    } 
    throw new IllegalStateException("No data model. Did you call #setDataModel?");
  }
  
  public void e() {
    this.a.getCount();
    throw null;
  }
  
  public b.b.q.d getDataModel() {
    return this.a.b();
  }
  
  public ListPopupWindow getListPopupWindow() {
    if (this.m == null) {
      ListPopupWindow listPopupWindow = new ListPopupWindow(getContext());
      this.m = listPopupWindow;
      listPopupWindow.o((ListAdapter)this.a);
      this.m.y((View)this);
      this.m.E(true);
      this.m.G(this.b);
      this.m.F(this.b);
    } 
    return this.m;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    b.b.q.d d = this.a.b();
    if (d != null)
      d.registerObserver(this.k); 
    this.q = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    b.b.q.d d = this.a.b();
    if (d != null)
      d.unregisterObserver(this.k); 
    ViewTreeObserver viewTreeObserver = getViewTreeObserver();
    if (viewTreeObserver.isAlive())
      viewTreeObserver.removeGlobalOnLayoutListener(this.l); 
    if (b())
      a(); 
    this.q = false;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.c.layout(0, 0, paramInt3 - paramInt1, paramInt4 - paramInt2);
    if (!b())
      a(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    View view = this.c;
    int i = paramInt2;
    if (this.g.getVisibility() != 0)
      i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt2), 1073741824); 
    measureChild(view, paramInt1, i);
    setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
  }
  
  public void setActivityChooserModel(b.b.q.d paramd) {
    this.a.e(paramd);
    if (b()) {
      a();
      c();
    } 
  }
  
  public void setDefaultActionButtonContentDescription(int paramInt) {
    this.C = paramInt;
  }
  
  public void setExpandActivityOverflowButtonContentDescription(int paramInt) {
    String str = getContext().getString(paramInt);
    this.f.setContentDescription(str);
  }
  
  public void setExpandActivityOverflowButtonDrawable(Drawable paramDrawable) {
    this.f.setImageDrawable(paramDrawable);
  }
  
  public void setInitialActivityCount(int paramInt) {
    this.p = paramInt;
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.n = paramOnDismissListener;
  }
  
  public void setProvider(b.h.n.b paramb) {
    this.j = paramb;
  }
  
  public static class InnerLayout extends LinearLayout {
    public static final int[] a = new int[] { 16842964 };
    
    public InnerLayout(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      g0 g0 = g0.s(param1Context, param1AttributeSet, a);
      setBackgroundDrawable(g0.f(0));
      g0.u();
    }
  }
  
  public class a extends DataSetObserver {
    public a(ActivityChooserView this$0) {}
    
    public void onChanged() {
      super.onChanged();
      this.a.a.notifyDataSetChanged();
    }
    
    public void onInvalidated() {
      super.onInvalidated();
      this.a.a.notifyDataSetInvalidated();
    }
  }
  
  public class b implements ViewTreeObserver.OnGlobalLayoutListener {
    public b(ActivityChooserView this$0) {}
    
    public void onGlobalLayout() {
      if (this.a.b()) {
        if (!this.a.isShown()) {
          this.a.getListPopupWindow().dismiss();
          return;
        } 
        this.a.getListPopupWindow().show();
        b.h.n.b b1 = this.a.j;
        if (b1 != null)
          b1.k(true); 
      } 
    }
  }
  
  public class c extends View.AccessibilityDelegate {
    public c(ActivityChooserView this$0) {}
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfo);
      b.h.n.a0.b.n0(param1AccessibilityNodeInfo).T(true);
    }
  }
  
  public class d extends t {
    public d(ActivityChooserView this$0, View param1View) {
      super(param1View);
    }
    
    public p b() {
      return this.j.getListPopupWindow();
    }
    
    public boolean c() {
      this.j.c();
      return true;
    }
    
    public boolean d() {
      this.j.a();
      return true;
    }
  }
  
  public class e extends DataSetObserver {
    public e(ActivityChooserView this$0) {}
    
    public void onChanged() {
      super.onChanged();
      this.a.e();
      throw null;
    }
  }
  
  public class f extends BaseAdapter {
    public b.b.q.d a;
    
    public int b = 4;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e;
    
    public f(ActivityChooserView this$0) {}
    
    public int a() {
      this.a.c();
      throw null;
    }
    
    public b.b.q.d b() {
      return this.a;
    }
    
    public ResolveInfo c() {
      this.a.d();
      throw null;
    }
    
    public boolean d() {
      return this.c;
    }
    
    public void e(b.b.q.d param1d) {
      b.b.q.d d1 = this.f.a.b();
      if (d1 != null && this.f.isShown())
        d1.unregisterObserver(this.f.k); 
      if (param1d != null && this.f.isShown())
        param1d.registerObserver(this.f.k); 
      notifyDataSetChanged();
    }
    
    public int getCount() {
      this.a.c();
      throw null;
    }
    
    public Object getItem(int param1Int) {
      int i = getItemViewType(param1Int);
      if (i != 0) {
        if (i == 1)
          return null; 
        throw new IllegalArgumentException();
      } 
      if (!this.c) {
        this.a.d();
        throw null;
      } 
      this.a.b(param1Int);
      throw null;
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public int getItemViewType(int param1Int) {
      if (!this.e)
        return 0; 
      getCount();
      throw null;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      // Byte code:
      //   0: aload_0
      //   1: iload_1
      //   2: invokevirtual getItemViewType : (I)I
      //   5: istore #4
      //   7: iload #4
      //   9: ifeq -> 97
      //   12: iload #4
      //   14: iconst_1
      //   15: if_icmpne -> 89
      //   18: aload_2
      //   19: ifnull -> 33
      //   22: aload_2
      //   23: astore #5
      //   25: aload_2
      //   26: invokevirtual getId : ()I
      //   29: iconst_1
      //   30: if_icmpeq -> 86
      //   33: aload_0
      //   34: getfield f : Landroidx/appcompat/widget/ActivityChooserView;
      //   37: invokevirtual getContext : ()Landroid/content/Context;
      //   40: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
      //   43: getstatic b/b/g.f : I
      //   46: aload_3
      //   47: iconst_0
      //   48: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
      //   51: astore #5
      //   53: aload #5
      //   55: iconst_1
      //   56: invokevirtual setId : (I)V
      //   59: aload #5
      //   61: getstatic b/b/f.S : I
      //   64: invokevirtual findViewById : (I)Landroid/view/View;
      //   67: checkcast android/widget/TextView
      //   70: aload_0
      //   71: getfield f : Landroidx/appcompat/widget/ActivityChooserView;
      //   74: invokevirtual getContext : ()Landroid/content/Context;
      //   77: getstatic b/b/h.b : I
      //   80: invokevirtual getString : (I)Ljava/lang/String;
      //   83: invokevirtual setText : (Ljava/lang/CharSequence;)V
      //   86: aload #5
      //   88: areturn
      //   89: new java/lang/IllegalArgumentException
      //   92: dup
      //   93: invokespecial <init> : ()V
      //   96: athrow
      //   97: aload_2
      //   98: ifnull -> 114
      //   101: aload_2
      //   102: astore #5
      //   104: aload_2
      //   105: invokevirtual getId : ()I
      //   108: getstatic b/b/f.x : I
      //   111: if_icmpeq -> 134
      //   114: aload_0
      //   115: getfield f : Landroidx/appcompat/widget/ActivityChooserView;
      //   118: invokevirtual getContext : ()Landroid/content/Context;
      //   121: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
      //   124: getstatic b/b/g.f : I
      //   127: aload_3
      //   128: iconst_0
      //   129: invokevirtual inflate : (ILandroid/view/ViewGroup;Z)Landroid/view/View;
      //   132: astore #5
      //   134: aload_0
      //   135: getfield f : Landroidx/appcompat/widget/ActivityChooserView;
      //   138: invokevirtual getContext : ()Landroid/content/Context;
      //   141: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
      //   144: astore_2
      //   145: aload #5
      //   147: getstatic b/b/f.v : I
      //   150: invokevirtual findViewById : (I)Landroid/view/View;
      //   153: checkcast android/widget/ImageView
      //   156: astore_3
      //   157: aload_0
      //   158: iload_1
      //   159: invokevirtual getItem : (I)Ljava/lang/Object;
      //   162: checkcast android/content/pm/ResolveInfo
      //   165: astore #6
      //   167: aload_3
      //   168: aload #6
      //   170: aload_2
      //   171: invokevirtual loadIcon : (Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;
      //   174: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
      //   177: aload #5
      //   179: getstatic b/b/f.S : I
      //   182: invokevirtual findViewById : (I)Landroid/view/View;
      //   185: checkcast android/widget/TextView
      //   188: aload #6
      //   190: aload_2
      //   191: invokevirtual loadLabel : (Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
      //   194: invokevirtual setText : (Ljava/lang/CharSequence;)V
      //   197: aload_0
      //   198: getfield c : Z
      //   201: ifeq -> 224
      //   204: iload_1
      //   205: ifne -> 224
      //   208: aload_0
      //   209: getfield d : Z
      //   212: ifeq -> 224
      //   215: aload #5
      //   217: iconst_1
      //   218: invokevirtual setActivated : (Z)V
      //   221: aload #5
      //   223: areturn
      //   224: aload #5
      //   226: iconst_0
      //   227: invokevirtual setActivated : (Z)V
      //   230: aload #5
      //   232: areturn
    }
    
    public int getViewTypeCount() {
      return 3;
    }
  }
  
  public class g implements AdapterView.OnItemClickListener, View.OnClickListener, View.OnLongClickListener, PopupWindow.OnDismissListener {
    public g(ActivityChooserView this$0) {}
    
    public final void a() {
      PopupWindow.OnDismissListener onDismissListener = this.a.n;
      if (onDismissListener != null)
        onDismissListener.onDismiss(); 
    }
    
    public void onClick(View param1View) {
      ActivityChooserView activityChooserView = this.a;
      if (param1View != activityChooserView.g) {
        if (param1View == activityChooserView.e) {
          activityChooserView.o = false;
          activityChooserView.d(activityChooserView.p);
          throw null;
        } 
        throw new IllegalArgumentException();
      } 
      activityChooserView.a();
      this.a.a.c();
      throw null;
    }
    
    public void onDismiss() {
      a();
      b.h.n.b b = this.a.j;
      if (b != null)
        b.k(false); 
    }
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      int i = ((ActivityChooserView.f)param1AdapterView.getAdapter()).getItemViewType(param1Int);
      if (i != 0) {
        if (i != 1)
          throw new IllegalArgumentException(); 
        this.a.d(2147483647);
        throw null;
      } 
      this.a.a();
      ActivityChooserView activityChooserView = this.a;
      if (activityChooserView.o) {
        if (param1Int <= 0)
          return; 
        activityChooserView.a.b().e(param1Int);
        throw null;
      } 
      if (!activityChooserView.a.d())
        param1Int++; 
      this.a.a.b().a(param1Int);
      throw null;
    }
    
    public boolean onLongClick(View param1View) {
      ActivityChooserView activityChooserView = this.a;
      if (param1View == activityChooserView.g) {
        activityChooserView.a.getCount();
        throw null;
      } 
      throw new IllegalArgumentException();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\ActivityChooserView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */