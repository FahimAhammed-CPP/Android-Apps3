package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import b.b.j;
import b.b.q.g0;
import b.b.q.m0;
import b.h.n.d;
import b.h.n.r;

public class LinearLayoutCompat extends ViewGroup {
  public boolean a = true;
  
  public int b = -1;
  
  public int c = 0;
  
  public int d;
  
  public int e = 8388659;
  
  public int f;
  
  public float g;
  
  public boolean h;
  
  public int[] i;
  
  public int[] j;
  
  public Drawable k;
  
  public int l;
  
  public int m;
  
  public int n;
  
  public int o;
  
  public LinearLayoutCompat(Context paramContext) {
    this(paramContext, null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    g0 g0 = g0.t(paramContext, paramAttributeSet, j.T0, paramInt, 0);
    paramInt = g0.j(j.V0, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = g0.j(j.U0, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = g0.a(j.W0, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.g = g0.h(j.Y0, -1.0F);
    this.b = g0.j(j.X0, -1);
    this.h = g0.a(j.b1, false);
    setDividerDrawable(g0.f(j.Z0));
    this.n = g0.j(j.c1, 0);
    this.o = g0.e(j.a1, 0);
    g0.u();
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof a;
  }
  
  public void e(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = m0.b((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = q(i);
      if (view != null && view.getVisibility() != 8 && r(i)) {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + a.rightMargin;
        } else {
          k = view.getLeft() - a.leftMargin - this.l;
        } 
        h(paramCanvas, k);
      } 
    } 
    if (r(j)) {
      View view = q(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.l;
          i -= k;
        } 
      } else {
        int k;
        a a = (a)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - a.leftMargin;
          k = this.l;
        } else {
          i = view.getRight() + a.rightMargin;
          h(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    h(paramCanvas, i);
  }
  
  public void f(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = q(i);
      if (view != null && view.getVisibility() != 8 && r(i)) {
        a a = (a)view.getLayoutParams();
        g(paramCanvas, view.getTop() - a.topMargin - this.m);
      } 
    } 
    if (r(j)) {
      View view = q(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.m;
      } else {
        a a = (a)view.getLayoutParams();
        i = view.getBottom() + a.bottomMargin;
      } 
      g(paramCanvas, i);
    } 
  }
  
  public void g(Canvas paramCanvas, int paramInt) {
    this.k.setBounds(getPaddingLeft() + this.o, paramInt, getWidth() - getPaddingRight() - this.o, this.m + paramInt);
    this.k.draw(paramCanvas);
  }
  
  public int getBaseline() {
    if (this.b < 0)
      return super.getBaseline(); 
    int i = getChildCount();
    int j = this.b;
    if (i > j) {
      View view = getChildAt(j);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.b == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.c;
      i = j;
      if (this.d == 1) {
        int m = this.e & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.f;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.f) / 2;
          }  
      } 
      return i + ((a)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.b;
  }
  
  public Drawable getDividerDrawable() {
    return this.k;
  }
  
  public int getDividerPadding() {
    return this.o;
  }
  
  public int getDividerWidth() {
    return this.l;
  }
  
  public int getGravity() {
    return this.e;
  }
  
  public int getOrientation() {
    return this.d;
  }
  
  public int getShowDividers() {
    return this.n;
  }
  
  public int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.g;
  }
  
  public void h(Canvas paramCanvas, int paramInt) {
    this.k.setBounds(paramInt, getPaddingTop() + this.o, this.l + paramInt, getHeight() - getPaddingBottom() - this.o);
    this.k.draw(paramCanvas);
  }
  
  public final void i(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = q(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.height == -1) {
          int k = a.width;
          a.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, j, 0);
          a.width = k;
        } 
      } 
    } 
  }
  
  public final void j(int paramInt1, int paramInt2) {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i = 0; i < paramInt1; i++) {
      View view = q(i);
      if (view.getVisibility() != 8) {
        a a = (a)view.getLayoutParams();
        if (a.width == -1) {
          int k = a.height;
          a.height = view.getMeasuredHeight();
          measureChildWithMargins(view, j, 0, paramInt2, 0);
          a.height = k;
        } 
      } 
    } 
  }
  
  public a k() {
    int i = this.d;
    return (i == 0) ? new a(-2, -2) : ((i == 1) ? new a(-1, -2) : null);
  }
  
  public a l(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  public a m(ViewGroup.LayoutParams paramLayoutParams) {
    return new a(paramLayoutParams);
  }
  
  public int n(View paramView, int paramInt) {
    return 0;
  }
  
  public int o(View paramView) {
    return 0;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (this.k == null)
      return; 
    if (this.d == 1) {
      f(paramCanvas);
      return;
    } 
    e(paramCanvas);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.d == 1) {
      t(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    s(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.d == 1) {
      x(paramInt1, paramInt2);
      return;
    } 
    v(paramInt1, paramInt2);
  }
  
  public int p(View paramView) {
    return 0;
  }
  
  public View q(int paramInt) {
    return getChildAt(paramInt);
  }
  
  public boolean r(int paramInt) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0) {
      if ((this.n & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      bool1 = bool2;
      if ((this.n & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    if ((this.n & 0x2) != 0)
      while (--paramInt >= 0) {
        if (getChildAt(paramInt).getVisibility() != 8)
          return true; 
        paramInt--;
      }  
    return false;
  }
  
  public void s(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool1 = m0.b((View)this);
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2;
    int n = getPaddingBottom();
    int i1 = getPaddingBottom();
    int j = getVirtualChildCount();
    paramInt2 = this.e;
    paramInt4 = paramInt2 & 0x70;
    boolean bool2 = this.a;
    int[] arrayOfInt1 = this.i;
    int[] arrayOfInt2 = this.j;
    paramInt2 = d.b(0x800007 & paramInt2, r.q((View)this));
    if (paramInt2 != 1) {
      if (paramInt2 != 5) {
        paramInt2 = getPaddingLeft();
      } else {
        paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.f;
      } 
    } else {
      paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.f) / 2;
    } 
    if (bool1) {
      b1 = j - 1;
      b2 = -1;
    } else {
      b1 = 0;
      b2 = 1;
    } 
    int i = 0;
    paramInt3 = paramInt4;
    paramInt4 = k;
    while (i < j) {
      int i2 = b1 + b2 * i;
      View view = q(i2);
      if (view == null) {
        paramInt2 += w(i2);
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        a a = (a)view.getLayoutParams();
        if (bool2 && a.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = a.b;
        paramInt1 = i4;
        if (i4 < 0)
          paramInt1 = paramInt3; 
        paramInt1 &= 0x70;
        if (paramInt1 != 16) {
          if (paramInt1 != 48) {
            if (paramInt1 != 80) {
              paramInt1 = paramInt4;
            } else {
              i4 = m - n - i6 - a.bottomMargin;
              paramInt1 = i4;
              if (i3 != -1) {
                paramInt1 = view.getMeasuredHeight();
                paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
              } 
            } 
          } else {
            i4 = a.topMargin + paramInt4;
            paramInt1 = i4;
            if (i3 != -1)
              paramInt1 = i4 + arrayOfInt1[1] - i3; 
          } 
        } else {
          paramInt1 = (m - k - i1 - i6) / 2 + paramInt4 + a.topMargin - a.bottomMargin;
        } 
        int i3 = paramInt2;
        if (r(i2))
          i3 = paramInt2 + this.l; 
        paramInt2 = a.leftMargin + i3;
        y(view, paramInt2 + o(view), paramInt1, i5, i6);
        paramInt1 = a.rightMargin;
        i3 = p(view);
        i += n(view, i2);
        paramInt2 += i5 + paramInt1 + i3;
      } 
      i++;
    } 
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.b = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.k)
      return; 
    this.k = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.l = paramDrawable.getIntrinsicWidth();
      this.m = paramDrawable.getIntrinsicHeight();
    } else {
      this.l = 0;
      this.m = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.o = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.e != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.e = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.e;
    if ((0x800007 & i) != paramInt) {
      this.e = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.h = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.d != paramInt) {
      this.d = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.n)
      requestLayout(); 
    this.n = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.e;
    if ((i & 0x70) != paramInt) {
      this.e = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.g = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public void t(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int j = paramInt3 - paramInt1;
    int k = getPaddingRight();
    int m = getPaddingRight();
    int n = getVirtualChildCount();
    int i1 = this.e;
    paramInt1 = i1 & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.f;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.f) / 2;
    } 
    paramInt2 = 0;
    while (paramInt2 < n) {
      View view = q(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + w(paramInt2);
        paramInt4 = paramInt2;
      } else {
        paramInt3 = paramInt1;
        paramInt4 = paramInt2;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          a a = (a)view.getLayoutParams();
          paramInt4 = a.b;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = i1 & 0x800007; 
          paramInt3 = d.b(paramInt3, r.q((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = a.leftMargin + i;
            } else {
              paramInt3 = j - k - i3;
              paramInt4 = a.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (j - i - m - i3) / 2 + i + a.leftMargin;
            paramInt4 = a.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (r(paramInt2))
            paramInt4 = paramInt1 + this.m; 
          paramInt1 = paramInt4 + a.topMargin;
          y(view, paramInt3, paramInt1 + o(view), i3, i2);
          paramInt3 = a.bottomMargin;
          i3 = p(view);
          paramInt4 = paramInt2 + n(view, paramInt2);
          paramInt3 = paramInt1 + i2 + paramInt3 + i3;
        } 
      } 
      paramInt2 = paramInt4 + 1;
      paramInt1 = paramInt3;
    } 
  }
  
  public void u(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public void v(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield f : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #22
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #21
    //   23: aload_0
    //   24: getfield i : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield j : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield i : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield j : [I
    //   51: aload_0
    //   52: getfield i : [I
    //   55: astore #28
    //   57: aload_0
    //   58: getfield j : [I
    //   61: astore #26
    //   63: aload #28
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #28
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #28
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #28
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #26
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #26
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #26
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #26
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield a : Z
    //   107: istore #24
    //   109: aload_0
    //   110: getfield h : Z
    //   113: istore #25
    //   115: iload #22
    //   117: ldc_w 1073741824
    //   120: if_icmpne -> 129
    //   123: iconst_1
    //   124: istore #15
    //   126: goto -> 132
    //   129: iconst_0
    //   130: istore #15
    //   132: fconst_0
    //   133: fstore_3
    //   134: iconst_0
    //   135: istore #8
    //   137: iconst_0
    //   138: istore #7
    //   140: iconst_0
    //   141: istore #13
    //   143: iconst_0
    //   144: istore #6
    //   146: iconst_0
    //   147: istore #11
    //   149: iconst_0
    //   150: istore #12
    //   152: iconst_0
    //   153: istore #9
    //   155: iconst_1
    //   156: istore #5
    //   158: iconst_0
    //   159: istore #10
    //   161: iload #8
    //   163: iload #16
    //   165: if_icmpge -> 848
    //   168: aload_0
    //   169: iload #8
    //   171: invokevirtual q : (I)Landroid/view/View;
    //   174: astore #27
    //   176: aload #27
    //   178: ifnonnull -> 199
    //   181: aload_0
    //   182: aload_0
    //   183: getfield f : I
    //   186: aload_0
    //   187: iload #8
    //   189: invokevirtual w : (I)I
    //   192: iadd
    //   193: putfield f : I
    //   196: goto -> 839
    //   199: aload #27
    //   201: invokevirtual getVisibility : ()I
    //   204: bipush #8
    //   206: if_icmpne -> 225
    //   209: iload #8
    //   211: aload_0
    //   212: aload #27
    //   214: iload #8
    //   216: invokevirtual n : (Landroid/view/View;I)I
    //   219: iadd
    //   220: istore #8
    //   222: goto -> 196
    //   225: aload_0
    //   226: iload #8
    //   228: invokevirtual r : (I)Z
    //   231: ifeq -> 247
    //   234: aload_0
    //   235: aload_0
    //   236: getfield f : I
    //   239: aload_0
    //   240: getfield l : I
    //   243: iadd
    //   244: putfield f : I
    //   247: aload #27
    //   249: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   252: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   255: astore #29
    //   257: aload #29
    //   259: getfield a : F
    //   262: fstore #4
    //   264: fload_3
    //   265: fload #4
    //   267: fadd
    //   268: fstore_3
    //   269: iload #22
    //   271: ldc_w 1073741824
    //   274: if_icmpne -> 383
    //   277: aload #29
    //   279: getfield width : I
    //   282: ifne -> 383
    //   285: fload #4
    //   287: fconst_0
    //   288: fcmpl
    //   289: ifle -> 383
    //   292: iload #15
    //   294: ifeq -> 320
    //   297: aload_0
    //   298: aload_0
    //   299: getfield f : I
    //   302: aload #29
    //   304: getfield leftMargin : I
    //   307: aload #29
    //   309: getfield rightMargin : I
    //   312: iadd
    //   313: iadd
    //   314: putfield f : I
    //   317: goto -> 349
    //   320: aload_0
    //   321: getfield f : I
    //   324: istore #14
    //   326: aload_0
    //   327: iload #14
    //   329: aload #29
    //   331: getfield leftMargin : I
    //   334: iload #14
    //   336: iadd
    //   337: aload #29
    //   339: getfield rightMargin : I
    //   342: iadd
    //   343: invokestatic max : (II)I
    //   346: putfield f : I
    //   349: iload #24
    //   351: ifeq -> 377
    //   354: iconst_0
    //   355: iconst_0
    //   356: invokestatic makeMeasureSpec : (II)I
    //   359: istore #14
    //   361: aload #27
    //   363: iload #14
    //   365: iload #14
    //   367: invokevirtual measure : (II)V
    //   370: iload #7
    //   372: istore #14
    //   374: goto -> 564
    //   377: iconst_1
    //   378: istore #12
    //   380: goto -> 568
    //   383: aload #29
    //   385: getfield width : I
    //   388: ifne -> 411
    //   391: fload #4
    //   393: fconst_0
    //   394: fcmpl
    //   395: ifle -> 411
    //   398: aload #29
    //   400: bipush #-2
    //   402: putfield width : I
    //   405: iconst_0
    //   406: istore #14
    //   408: goto -> 416
    //   411: ldc_w -2147483648
    //   414: istore #14
    //   416: fload_3
    //   417: fconst_0
    //   418: fcmpl
    //   419: ifne -> 431
    //   422: aload_0
    //   423: getfield f : I
    //   426: istore #17
    //   428: goto -> 434
    //   431: iconst_0
    //   432: istore #17
    //   434: aload_0
    //   435: aload #27
    //   437: iload #8
    //   439: iload_1
    //   440: iload #17
    //   442: iload_2
    //   443: iconst_0
    //   444: invokevirtual u : (Landroid/view/View;IIIII)V
    //   447: iload #14
    //   449: ldc_w -2147483648
    //   452: if_icmpeq -> 462
    //   455: aload #29
    //   457: iload #14
    //   459: putfield width : I
    //   462: aload #27
    //   464: invokevirtual getMeasuredWidth : ()I
    //   467: istore #17
    //   469: iload #15
    //   471: ifeq -> 507
    //   474: aload_0
    //   475: aload_0
    //   476: getfield f : I
    //   479: aload #29
    //   481: getfield leftMargin : I
    //   484: iload #17
    //   486: iadd
    //   487: aload #29
    //   489: getfield rightMargin : I
    //   492: iadd
    //   493: aload_0
    //   494: aload #27
    //   496: invokevirtual p : (Landroid/view/View;)I
    //   499: iadd
    //   500: iadd
    //   501: putfield f : I
    //   504: goto -> 546
    //   507: aload_0
    //   508: getfield f : I
    //   511: istore #14
    //   513: aload_0
    //   514: iload #14
    //   516: iload #14
    //   518: iload #17
    //   520: iadd
    //   521: aload #29
    //   523: getfield leftMargin : I
    //   526: iadd
    //   527: aload #29
    //   529: getfield rightMargin : I
    //   532: iadd
    //   533: aload_0
    //   534: aload #27
    //   536: invokevirtual p : (Landroid/view/View;)I
    //   539: iadd
    //   540: invokestatic max : (II)I
    //   543: putfield f : I
    //   546: iload #7
    //   548: istore #14
    //   550: iload #25
    //   552: ifeq -> 564
    //   555: iload #17
    //   557: iload #7
    //   559: invokestatic max : (II)I
    //   562: istore #14
    //   564: iload #14
    //   566: istore #7
    //   568: iload #8
    //   570: istore #18
    //   572: iload #21
    //   574: ldc_w 1073741824
    //   577: if_icmpeq -> 598
    //   580: aload #29
    //   582: getfield height : I
    //   585: iconst_m1
    //   586: if_icmpne -> 598
    //   589: iconst_1
    //   590: istore #8
    //   592: iconst_1
    //   593: istore #10
    //   595: goto -> 601
    //   598: iconst_0
    //   599: istore #8
    //   601: aload #29
    //   603: getfield topMargin : I
    //   606: aload #29
    //   608: getfield bottomMargin : I
    //   611: iadd
    //   612: istore #14
    //   614: aload #27
    //   616: invokevirtual getMeasuredHeight : ()I
    //   619: iload #14
    //   621: iadd
    //   622: istore #17
    //   624: iload #9
    //   626: aload #27
    //   628: invokevirtual getMeasuredState : ()I
    //   631: invokestatic combineMeasuredStates : (II)I
    //   634: istore #19
    //   636: iload #24
    //   638: ifeq -> 723
    //   641: aload #27
    //   643: invokevirtual getBaseline : ()I
    //   646: istore #23
    //   648: iload #23
    //   650: iconst_m1
    //   651: if_icmpeq -> 723
    //   654: aload #29
    //   656: getfield b : I
    //   659: istore #20
    //   661: iload #20
    //   663: istore #9
    //   665: iload #20
    //   667: ifge -> 676
    //   670: aload_0
    //   671: getfield e : I
    //   674: istore #9
    //   676: iload #9
    //   678: bipush #112
    //   680: iand
    //   681: iconst_4
    //   682: ishr
    //   683: bipush #-2
    //   685: iand
    //   686: iconst_1
    //   687: ishr
    //   688: istore #9
    //   690: aload #28
    //   692: iload #9
    //   694: aload #28
    //   696: iload #9
    //   698: iaload
    //   699: iload #23
    //   701: invokestatic max : (II)I
    //   704: iastore
    //   705: aload #26
    //   707: iload #9
    //   709: aload #26
    //   711: iload #9
    //   713: iaload
    //   714: iload #17
    //   716: iload #23
    //   718: isub
    //   719: invokestatic max : (II)I
    //   722: iastore
    //   723: iload #13
    //   725: iload #17
    //   727: invokestatic max : (II)I
    //   730: istore #13
    //   732: iload #5
    //   734: ifeq -> 752
    //   737: aload #29
    //   739: getfield height : I
    //   742: iconst_m1
    //   743: if_icmpne -> 752
    //   746: iconst_1
    //   747: istore #5
    //   749: goto -> 755
    //   752: iconst_0
    //   753: istore #5
    //   755: aload #29
    //   757: getfield a : F
    //   760: fconst_0
    //   761: fcmpl
    //   762: ifle -> 789
    //   765: iload #8
    //   767: ifeq -> 773
    //   770: goto -> 777
    //   773: iload #17
    //   775: istore #14
    //   777: iload #11
    //   779: iload #14
    //   781: invokestatic max : (II)I
    //   784: istore #8
    //   786: goto -> 814
    //   789: iload #8
    //   791: ifeq -> 797
    //   794: goto -> 801
    //   797: iload #17
    //   799: istore #14
    //   801: iload #6
    //   803: iload #14
    //   805: invokestatic max : (II)I
    //   808: istore #6
    //   810: iload #11
    //   812: istore #8
    //   814: aload_0
    //   815: aload #27
    //   817: iload #18
    //   819: invokevirtual n : (Landroid/view/View;I)I
    //   822: iload #18
    //   824: iadd
    //   825: istore #14
    //   827: iload #19
    //   829: istore #9
    //   831: iload #8
    //   833: istore #11
    //   835: iload #14
    //   837: istore #8
    //   839: iload #8
    //   841: iconst_1
    //   842: iadd
    //   843: istore #8
    //   845: goto -> 161
    //   848: aload_0
    //   849: getfield f : I
    //   852: ifle -> 877
    //   855: aload_0
    //   856: iload #16
    //   858: invokevirtual r : (I)Z
    //   861: ifeq -> 877
    //   864: aload_0
    //   865: aload_0
    //   866: getfield f : I
    //   869: aload_0
    //   870: getfield l : I
    //   873: iadd
    //   874: putfield f : I
    //   877: aload #28
    //   879: iconst_1
    //   880: iaload
    //   881: iconst_m1
    //   882: if_icmpne -> 919
    //   885: aload #28
    //   887: iconst_0
    //   888: iaload
    //   889: iconst_m1
    //   890: if_icmpne -> 919
    //   893: aload #28
    //   895: iconst_2
    //   896: iaload
    //   897: iconst_m1
    //   898: if_icmpne -> 919
    //   901: aload #28
    //   903: iconst_3
    //   904: iaload
    //   905: iconst_m1
    //   906: if_icmpeq -> 912
    //   909: goto -> 919
    //   912: iload #13
    //   914: istore #8
    //   916: goto -> 977
    //   919: iload #13
    //   921: aload #28
    //   923: iconst_3
    //   924: iaload
    //   925: aload #28
    //   927: iconst_0
    //   928: iaload
    //   929: aload #28
    //   931: iconst_1
    //   932: iaload
    //   933: aload #28
    //   935: iconst_2
    //   936: iaload
    //   937: invokestatic max : (II)I
    //   940: invokestatic max : (II)I
    //   943: invokestatic max : (II)I
    //   946: aload #26
    //   948: iconst_3
    //   949: iaload
    //   950: aload #26
    //   952: iconst_0
    //   953: iaload
    //   954: aload #26
    //   956: iconst_1
    //   957: iaload
    //   958: aload #26
    //   960: iconst_2
    //   961: iaload
    //   962: invokestatic max : (II)I
    //   965: invokestatic max : (II)I
    //   968: invokestatic max : (II)I
    //   971: iadd
    //   972: invokestatic max : (II)I
    //   975: istore #8
    //   977: iload #9
    //   979: istore #13
    //   981: iload #8
    //   983: istore #14
    //   985: iload #25
    //   987: ifeq -> 1179
    //   990: iload #22
    //   992: ldc_w -2147483648
    //   995: if_icmpeq -> 1007
    //   998: iload #8
    //   1000: istore #14
    //   1002: iload #22
    //   1004: ifne -> 1179
    //   1007: aload_0
    //   1008: iconst_0
    //   1009: putfield f : I
    //   1012: iconst_0
    //   1013: istore #9
    //   1015: iload #8
    //   1017: istore #14
    //   1019: iload #9
    //   1021: iload #16
    //   1023: if_icmpge -> 1179
    //   1026: aload_0
    //   1027: iload #9
    //   1029: invokevirtual q : (I)Landroid/view/View;
    //   1032: astore #27
    //   1034: aload #27
    //   1036: ifnonnull -> 1057
    //   1039: aload_0
    //   1040: aload_0
    //   1041: getfield f : I
    //   1044: aload_0
    //   1045: iload #9
    //   1047: invokevirtual w : (I)I
    //   1050: iadd
    //   1051: putfield f : I
    //   1054: goto -> 1080
    //   1057: aload #27
    //   1059: invokevirtual getVisibility : ()I
    //   1062: bipush #8
    //   1064: if_icmpne -> 1083
    //   1067: iload #9
    //   1069: aload_0
    //   1070: aload #27
    //   1072: iload #9
    //   1074: invokevirtual n : (Landroid/view/View;I)I
    //   1077: iadd
    //   1078: istore #9
    //   1080: goto -> 1170
    //   1083: aload #27
    //   1085: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1088: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1091: astore #29
    //   1093: iload #15
    //   1095: ifeq -> 1131
    //   1098: aload_0
    //   1099: aload_0
    //   1100: getfield f : I
    //   1103: aload #29
    //   1105: getfield leftMargin : I
    //   1108: iload #7
    //   1110: iadd
    //   1111: aload #29
    //   1113: getfield rightMargin : I
    //   1116: iadd
    //   1117: aload_0
    //   1118: aload #27
    //   1120: invokevirtual p : (Landroid/view/View;)I
    //   1123: iadd
    //   1124: iadd
    //   1125: putfield f : I
    //   1128: goto -> 1080
    //   1131: aload_0
    //   1132: getfield f : I
    //   1135: istore #14
    //   1137: aload_0
    //   1138: iload #14
    //   1140: iload #14
    //   1142: iload #7
    //   1144: iadd
    //   1145: aload #29
    //   1147: getfield leftMargin : I
    //   1150: iadd
    //   1151: aload #29
    //   1153: getfield rightMargin : I
    //   1156: iadd
    //   1157: aload_0
    //   1158: aload #27
    //   1160: invokevirtual p : (Landroid/view/View;)I
    //   1163: iadd
    //   1164: invokestatic max : (II)I
    //   1167: putfield f : I
    //   1170: iload #9
    //   1172: iconst_1
    //   1173: iadd
    //   1174: istore #9
    //   1176: goto -> 1015
    //   1179: aload_0
    //   1180: getfield f : I
    //   1183: aload_0
    //   1184: invokevirtual getPaddingLeft : ()I
    //   1187: aload_0
    //   1188: invokevirtual getPaddingRight : ()I
    //   1191: iadd
    //   1192: iadd
    //   1193: istore #8
    //   1195: aload_0
    //   1196: iload #8
    //   1198: putfield f : I
    //   1201: iload #8
    //   1203: aload_0
    //   1204: invokevirtual getSuggestedMinimumWidth : ()I
    //   1207: invokestatic max : (II)I
    //   1210: iload_1
    //   1211: iconst_0
    //   1212: invokestatic resolveSizeAndState : (III)I
    //   1215: istore #18
    //   1217: ldc_w 16777215
    //   1220: iload #18
    //   1222: iand
    //   1223: aload_0
    //   1224: getfield f : I
    //   1227: isub
    //   1228: istore #17
    //   1230: iload #12
    //   1232: ifne -> 1371
    //   1235: iload #17
    //   1237: ifeq -> 1249
    //   1240: fload_3
    //   1241: fconst_0
    //   1242: fcmpl
    //   1243: ifle -> 1249
    //   1246: goto -> 1371
    //   1249: iload #6
    //   1251: iload #11
    //   1253: invokestatic max : (II)I
    //   1256: istore #9
    //   1258: iload #25
    //   1260: ifeq -> 1356
    //   1263: iload #22
    //   1265: ldc_w 1073741824
    //   1268: if_icmpeq -> 1356
    //   1271: iconst_0
    //   1272: istore #6
    //   1274: iload #6
    //   1276: iload #16
    //   1278: if_icmpge -> 1356
    //   1281: aload_0
    //   1282: iload #6
    //   1284: invokevirtual q : (I)Landroid/view/View;
    //   1287: astore #26
    //   1289: aload #26
    //   1291: ifnull -> 1347
    //   1294: aload #26
    //   1296: invokevirtual getVisibility : ()I
    //   1299: bipush #8
    //   1301: if_icmpne -> 1307
    //   1304: goto -> 1347
    //   1307: aload #26
    //   1309: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1312: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1315: getfield a : F
    //   1318: fconst_0
    //   1319: fcmpl
    //   1320: ifle -> 1347
    //   1323: aload #26
    //   1325: iload #7
    //   1327: ldc_w 1073741824
    //   1330: invokestatic makeMeasureSpec : (II)I
    //   1333: aload #26
    //   1335: invokevirtual getMeasuredHeight : ()I
    //   1338: ldc_w 1073741824
    //   1341: invokestatic makeMeasureSpec : (II)I
    //   1344: invokevirtual measure : (II)V
    //   1347: iload #6
    //   1349: iconst_1
    //   1350: iadd
    //   1351: istore #6
    //   1353: goto -> 1274
    //   1356: iload #16
    //   1358: istore #8
    //   1360: iload #14
    //   1362: istore #7
    //   1364: iload #9
    //   1366: istore #6
    //   1368: goto -> 2116
    //   1371: aload_0
    //   1372: getfield g : F
    //   1375: fstore #4
    //   1377: fload #4
    //   1379: fconst_0
    //   1380: fcmpl
    //   1381: ifle -> 1387
    //   1384: fload #4
    //   1386: fstore_3
    //   1387: aload #28
    //   1389: iconst_3
    //   1390: iconst_m1
    //   1391: iastore
    //   1392: aload #28
    //   1394: iconst_2
    //   1395: iconst_m1
    //   1396: iastore
    //   1397: aload #28
    //   1399: iconst_1
    //   1400: iconst_m1
    //   1401: iastore
    //   1402: aload #28
    //   1404: iconst_0
    //   1405: iconst_m1
    //   1406: iastore
    //   1407: aload #26
    //   1409: iconst_3
    //   1410: iconst_m1
    //   1411: iastore
    //   1412: aload #26
    //   1414: iconst_2
    //   1415: iconst_m1
    //   1416: iastore
    //   1417: aload #26
    //   1419: iconst_1
    //   1420: iconst_m1
    //   1421: iastore
    //   1422: aload #26
    //   1424: iconst_0
    //   1425: iconst_m1
    //   1426: iastore
    //   1427: aload_0
    //   1428: iconst_0
    //   1429: putfield f : I
    //   1432: iload #13
    //   1434: istore #9
    //   1436: iconst_m1
    //   1437: istore #11
    //   1439: iconst_0
    //   1440: istore #13
    //   1442: iload #5
    //   1444: istore #8
    //   1446: iload #16
    //   1448: istore #7
    //   1450: iload #9
    //   1452: istore #5
    //   1454: iload #6
    //   1456: istore #9
    //   1458: iload #17
    //   1460: istore #6
    //   1462: iload #13
    //   1464: iload #7
    //   1466: if_icmpge -> 1978
    //   1469: aload_0
    //   1470: iload #13
    //   1472: invokevirtual q : (I)Landroid/view/View;
    //   1475: astore #27
    //   1477: aload #27
    //   1479: ifnull -> 1969
    //   1482: aload #27
    //   1484: invokevirtual getVisibility : ()I
    //   1487: bipush #8
    //   1489: if_icmpne -> 1495
    //   1492: goto -> 1969
    //   1495: aload #27
    //   1497: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1500: checkcast androidx/appcompat/widget/LinearLayoutCompat$a
    //   1503: astore #29
    //   1505: aload #29
    //   1507: getfield a : F
    //   1510: fstore #4
    //   1512: fload #4
    //   1514: fconst_0
    //   1515: fcmpl
    //   1516: ifle -> 1682
    //   1519: iload #6
    //   1521: i2f
    //   1522: fload #4
    //   1524: fmul
    //   1525: fload_3
    //   1526: fdiv
    //   1527: f2i
    //   1528: istore #14
    //   1530: iload_2
    //   1531: aload_0
    //   1532: invokevirtual getPaddingTop : ()I
    //   1535: aload_0
    //   1536: invokevirtual getPaddingBottom : ()I
    //   1539: iadd
    //   1540: aload #29
    //   1542: getfield topMargin : I
    //   1545: iadd
    //   1546: aload #29
    //   1548: getfield bottomMargin : I
    //   1551: iadd
    //   1552: aload #29
    //   1554: getfield height : I
    //   1557: invokestatic getChildMeasureSpec : (III)I
    //   1560: istore #17
    //   1562: aload #29
    //   1564: getfield width : I
    //   1567: ifne -> 1614
    //   1570: iload #22
    //   1572: ldc_w 1073741824
    //   1575: if_icmpeq -> 1581
    //   1578: goto -> 1614
    //   1581: iload #14
    //   1583: ifle -> 1593
    //   1586: iload #14
    //   1588: istore #12
    //   1590: goto -> 1596
    //   1593: iconst_0
    //   1594: istore #12
    //   1596: aload #27
    //   1598: iload #12
    //   1600: ldc_w 1073741824
    //   1603: invokestatic makeMeasureSpec : (II)I
    //   1606: iload #17
    //   1608: invokevirtual measure : (II)V
    //   1611: goto -> 1651
    //   1614: aload #27
    //   1616: invokevirtual getMeasuredWidth : ()I
    //   1619: iload #14
    //   1621: iadd
    //   1622: istore #16
    //   1624: iload #16
    //   1626: istore #12
    //   1628: iload #16
    //   1630: ifge -> 1636
    //   1633: iconst_0
    //   1634: istore #12
    //   1636: aload #27
    //   1638: iload #12
    //   1640: ldc_w 1073741824
    //   1643: invokestatic makeMeasureSpec : (II)I
    //   1646: iload #17
    //   1648: invokevirtual measure : (II)V
    //   1651: iload #5
    //   1653: aload #27
    //   1655: invokevirtual getMeasuredState : ()I
    //   1658: ldc_w -16777216
    //   1661: iand
    //   1662: invokestatic combineMeasuredStates : (II)I
    //   1665: istore #5
    //   1667: fload_3
    //   1668: fload #4
    //   1670: fsub
    //   1671: fstore_3
    //   1672: iload #6
    //   1674: iload #14
    //   1676: isub
    //   1677: istore #6
    //   1679: goto -> 1682
    //   1682: iload #15
    //   1684: ifeq -> 1723
    //   1687: aload_0
    //   1688: aload_0
    //   1689: getfield f : I
    //   1692: aload #27
    //   1694: invokevirtual getMeasuredWidth : ()I
    //   1697: aload #29
    //   1699: getfield leftMargin : I
    //   1702: iadd
    //   1703: aload #29
    //   1705: getfield rightMargin : I
    //   1708: iadd
    //   1709: aload_0
    //   1710: aload #27
    //   1712: invokevirtual p : (Landroid/view/View;)I
    //   1715: iadd
    //   1716: iadd
    //   1717: putfield f : I
    //   1720: goto -> 1765
    //   1723: aload_0
    //   1724: getfield f : I
    //   1727: istore #12
    //   1729: aload_0
    //   1730: iload #12
    //   1732: aload #27
    //   1734: invokevirtual getMeasuredWidth : ()I
    //   1737: iload #12
    //   1739: iadd
    //   1740: aload #29
    //   1742: getfield leftMargin : I
    //   1745: iadd
    //   1746: aload #29
    //   1748: getfield rightMargin : I
    //   1751: iadd
    //   1752: aload_0
    //   1753: aload #27
    //   1755: invokevirtual p : (Landroid/view/View;)I
    //   1758: iadd
    //   1759: invokestatic max : (II)I
    //   1762: putfield f : I
    //   1765: iload #21
    //   1767: ldc_w 1073741824
    //   1770: if_icmpeq -> 1788
    //   1773: aload #29
    //   1775: getfield height : I
    //   1778: iconst_m1
    //   1779: if_icmpne -> 1788
    //   1782: iconst_1
    //   1783: istore #12
    //   1785: goto -> 1791
    //   1788: iconst_0
    //   1789: istore #12
    //   1791: aload #29
    //   1793: getfield topMargin : I
    //   1796: aload #29
    //   1798: getfield bottomMargin : I
    //   1801: iadd
    //   1802: istore #17
    //   1804: aload #27
    //   1806: invokevirtual getMeasuredHeight : ()I
    //   1809: iload #17
    //   1811: iadd
    //   1812: istore #16
    //   1814: iload #11
    //   1816: iload #16
    //   1818: invokestatic max : (II)I
    //   1821: istore #14
    //   1823: iload #12
    //   1825: ifeq -> 1835
    //   1828: iload #17
    //   1830: istore #11
    //   1832: goto -> 1839
    //   1835: iload #16
    //   1837: istore #11
    //   1839: iload #9
    //   1841: iload #11
    //   1843: invokestatic max : (II)I
    //   1846: istore #11
    //   1848: iload #8
    //   1850: ifeq -> 1868
    //   1853: aload #29
    //   1855: getfield height : I
    //   1858: iconst_m1
    //   1859: if_icmpne -> 1868
    //   1862: iconst_1
    //   1863: istore #8
    //   1865: goto -> 1871
    //   1868: iconst_0
    //   1869: istore #8
    //   1871: iload #24
    //   1873: ifeq -> 1958
    //   1876: aload #27
    //   1878: invokevirtual getBaseline : ()I
    //   1881: istore #17
    //   1883: iload #17
    //   1885: iconst_m1
    //   1886: if_icmpeq -> 1958
    //   1889: aload #29
    //   1891: getfield b : I
    //   1894: istore #12
    //   1896: iload #12
    //   1898: istore #9
    //   1900: iload #12
    //   1902: ifge -> 1911
    //   1905: aload_0
    //   1906: getfield e : I
    //   1909: istore #9
    //   1911: iload #9
    //   1913: bipush #112
    //   1915: iand
    //   1916: iconst_4
    //   1917: ishr
    //   1918: bipush #-2
    //   1920: iand
    //   1921: iconst_1
    //   1922: ishr
    //   1923: istore #9
    //   1925: aload #28
    //   1927: iload #9
    //   1929: aload #28
    //   1931: iload #9
    //   1933: iaload
    //   1934: iload #17
    //   1936: invokestatic max : (II)I
    //   1939: iastore
    //   1940: aload #26
    //   1942: iload #9
    //   1944: aload #26
    //   1946: iload #9
    //   1948: iaload
    //   1949: iload #16
    //   1951: iload #17
    //   1953: isub
    //   1954: invokestatic max : (II)I
    //   1957: iastore
    //   1958: iload #11
    //   1960: istore #9
    //   1962: iload #14
    //   1964: istore #11
    //   1966: goto -> 1969
    //   1969: iload #13
    //   1971: iconst_1
    //   1972: iadd
    //   1973: istore #13
    //   1975: goto -> 1462
    //   1978: aload_0
    //   1979: aload_0
    //   1980: getfield f : I
    //   1983: aload_0
    //   1984: invokevirtual getPaddingLeft : ()I
    //   1987: aload_0
    //   1988: invokevirtual getPaddingRight : ()I
    //   1991: iadd
    //   1992: iadd
    //   1993: putfield f : I
    //   1996: aload #28
    //   1998: iconst_1
    //   1999: iaload
    //   2000: iconst_m1
    //   2001: if_icmpne -> 2038
    //   2004: aload #28
    //   2006: iconst_0
    //   2007: iaload
    //   2008: iconst_m1
    //   2009: if_icmpne -> 2038
    //   2012: aload #28
    //   2014: iconst_2
    //   2015: iaload
    //   2016: iconst_m1
    //   2017: if_icmpne -> 2038
    //   2020: aload #28
    //   2022: iconst_3
    //   2023: iaload
    //   2024: iconst_m1
    //   2025: if_icmpeq -> 2031
    //   2028: goto -> 2038
    //   2031: iload #11
    //   2033: istore #6
    //   2035: goto -> 2096
    //   2038: iload #11
    //   2040: aload #28
    //   2042: iconst_3
    //   2043: iaload
    //   2044: aload #28
    //   2046: iconst_0
    //   2047: iaload
    //   2048: aload #28
    //   2050: iconst_1
    //   2051: iaload
    //   2052: aload #28
    //   2054: iconst_2
    //   2055: iaload
    //   2056: invokestatic max : (II)I
    //   2059: invokestatic max : (II)I
    //   2062: invokestatic max : (II)I
    //   2065: aload #26
    //   2067: iconst_3
    //   2068: iaload
    //   2069: aload #26
    //   2071: iconst_0
    //   2072: iaload
    //   2073: aload #26
    //   2075: iconst_1
    //   2076: iaload
    //   2077: aload #26
    //   2079: iconst_2
    //   2080: iaload
    //   2081: invokestatic max : (II)I
    //   2084: invokestatic max : (II)I
    //   2087: invokestatic max : (II)I
    //   2090: iadd
    //   2091: invokestatic max : (II)I
    //   2094: istore #6
    //   2096: iload #5
    //   2098: istore #13
    //   2100: iload #8
    //   2102: istore #5
    //   2104: iload #7
    //   2106: istore #8
    //   2108: iload #6
    //   2110: istore #7
    //   2112: iload #9
    //   2114: istore #6
    //   2116: iload #5
    //   2118: ifne -> 2132
    //   2121: iload #21
    //   2123: ldc_w 1073741824
    //   2126: if_icmpeq -> 2132
    //   2129: goto -> 2136
    //   2132: iload #7
    //   2134: istore #6
    //   2136: aload_0
    //   2137: iload #18
    //   2139: iload #13
    //   2141: ldc_w -16777216
    //   2144: iand
    //   2145: ior
    //   2146: iload #6
    //   2148: aload_0
    //   2149: invokevirtual getPaddingTop : ()I
    //   2152: aload_0
    //   2153: invokevirtual getPaddingBottom : ()I
    //   2156: iadd
    //   2157: iadd
    //   2158: aload_0
    //   2159: invokevirtual getSuggestedMinimumHeight : ()I
    //   2162: invokestatic max : (II)I
    //   2165: iload_2
    //   2166: iload #13
    //   2168: bipush #16
    //   2170: ishl
    //   2171: invokestatic resolveSizeAndState : (III)I
    //   2174: invokevirtual setMeasuredDimension : (II)V
    //   2177: iload #10
    //   2179: ifeq -> 2189
    //   2182: aload_0
    //   2183: iload #8
    //   2185: iload_1
    //   2186: invokevirtual i : (II)V
    //   2189: return
  }
  
  public int w(int paramInt) {
    return 0;
  }
  
  public void x(int paramInt1, int paramInt2) {
    this.f = 0;
    int i2 = getVirtualChildCount();
    int i7 = View.MeasureSpec.getMode(paramInt1);
    int i5 = View.MeasureSpec.getMode(paramInt2);
    int i8 = this.b;
    boolean bool1 = this.h;
    float f = 0.0F;
    int i = 0;
    int i4 = 0;
    int n = 0;
    int j = 0;
    int m = 0;
    int i1 = 0;
    int i3 = 0;
    int k = 1;
    boolean bool = false;
    while (i1 < i2) {
      View view = q(i1);
      if (view == null) {
        this.f += w(i1);
      } else if (view.getVisibility() == 8) {
        i1 += n(view, i1);
      } else {
        if (r(i1))
          this.f += this.m; 
        a a = (a)view.getLayoutParams();
        float f1 = a.a;
        f += f1;
        if (i5 == 1073741824 && a.height == 0 && f1 > 0.0F) {
          i3 = this.f;
          this.f = Math.max(i3, a.topMargin + i3 + a.bottomMargin);
          i3 = 1;
        } else {
          if (a.height == 0 && f1 > 0.0F) {
            a.height = -2;
            i10 = 0;
          } else {
            i10 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i11 = this.f;
          } else {
            i11 = 0;
          } 
          u(view, i1, paramInt1, 0, paramInt2, i11);
          if (i10 != Integer.MIN_VALUE)
            a.height = i10; 
          int i10 = view.getMeasuredHeight();
          int i11 = this.f;
          this.f = Math.max(i11, i11 + i10 + a.topMargin + a.bottomMargin + p(view));
          if (bool1)
            n = Math.max(i10, n); 
        } 
        int i9 = i1;
        if (i8 >= 0 && i8 == i9 + 1)
          this.c = this.f; 
        if (i9 >= i8 || a.a <= 0.0F) {
          if (i7 != 1073741824 && a.width == -1) {
            i1 = 1;
            bool = true;
          } else {
            i1 = 0;
          } 
          int i10 = a.leftMargin + a.rightMargin;
          int i11 = view.getMeasuredWidth() + i10;
          i4 = Math.max(i4, i11);
          int i12 = View.combineMeasuredStates(i, view.getMeasuredState());
          if (k && a.width == -1) {
            i = 1;
          } else {
            i = 0;
          } 
          if (a.a > 0.0F) {
            if (i1 == 0)
              i10 = i11; 
            j = Math.max(j, i10);
            k = m;
          } else {
            if (i1 == 0)
              i10 = i11; 
            k = Math.max(m, i10);
          } 
          i1 = n(view, i9);
          m = k;
          i10 = i12;
          i1 += i9;
          k = i;
          i = i10;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i1++;
    } 
    if (this.f > 0 && r(i2))
      this.f += this.m; 
    if (bool1 && (i5 == Integer.MIN_VALUE || i5 == 0)) {
      this.f = 0;
      for (i1 = 0; i1 < i2; i1++) {
        View view = q(i1);
        if (view == null) {
          this.f += w(i1);
        } else if (view.getVisibility() == 8) {
          i1 += n(view, i1);
        } else {
          a a = (a)view.getLayoutParams();
          int i9 = this.f;
          this.f = Math.max(i9, i9 + n + a.topMargin + a.bottomMargin + p(view));
        } 
      } 
    } 
    i1 = this.f + getPaddingTop() + getPaddingBottom();
    this.f = i1;
    int i6 = View.resolveSizeAndState(Math.max(i1, getSuggestedMinimumHeight()), paramInt2, 0);
    i1 = (0xFFFFFF & i6) - this.f;
    if (i3 != 0 || (i1 != 0 && f > 0.0F)) {
      float f1 = this.g;
      if (f1 > 0.0F)
        f = f1; 
      this.f = 0;
      j = i1;
      i1 = 0;
      n = i4;
      while (i1 < i2) {
        View view = q(i1);
        if (view.getVisibility() != 8) {
          a a = (a)view.getLayoutParams();
          f1 = a.a;
          if (f1 > 0.0F) {
            i4 = (int)(j * f1 / f);
            int i10 = getPaddingLeft();
            int i11 = getPaddingRight();
            int i12 = a.leftMargin;
            i8 = a.rightMargin;
            int i13 = a.width;
            i3 = j - i4;
            i10 = ViewGroup.getChildMeasureSpec(paramInt1, i10 + i11 + i12 + i8, i13);
            if (a.height != 0 || i5 != 1073741824) {
              i4 = view.getMeasuredHeight() + i4;
              j = i4;
              if (i4 < 0)
                j = 0; 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } else {
              if (i4 > 0) {
                j = i4;
              } else {
                j = 0;
              } 
              view.measure(i10, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } 
            i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFFFFFF00);
            f -= f1;
            j = i3;
          } 
          i4 = a.leftMargin + a.rightMargin;
          int i9 = view.getMeasuredWidth() + i4;
          i3 = Math.max(n, i9);
          if (i7 != 1073741824 && a.width == -1) {
            n = 1;
          } else {
            n = 0;
          } 
          if (n != 0) {
            n = i4;
          } else {
            n = i9;
          } 
          m = Math.max(m, n);
          if (k != 0 && a.width == -1) {
            k = 1;
          } else {
            k = 0;
          } 
          n = this.f;
          this.f = Math.max(n, view.getMeasuredHeight() + n + a.topMargin + a.bottomMargin + p(view));
          n = i3;
        } 
        i1++;
      } 
      this.f += getPaddingTop() + getPaddingBottom();
      j = i;
      i = m;
    } else {
      m = Math.max(m, j);
      if (bool1 && i5 != 1073741824)
        for (j = 0; j < i2; j++) {
          View view = q(j);
          if (view != null && view.getVisibility() != 8 && ((a)view.getLayoutParams()).a > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824)); 
        }  
      j = i;
      i = m;
      n = i4;
    } 
    if (k != 0 || i7 == 1073741824)
      i = n; 
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, j), i6);
    if (bool)
      j(i2, paramInt2); 
  }
  
  public final void y(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  public static class a extends ViewGroup.MarginLayoutParams {
    public float a;
    
    public int b = -1;
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 0.0F;
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, j.d1);
      this.a = typedArray.getFloat(j.f1, 0.0F);
      this.b = typedArray.getInt(j.e1, -1);
      typedArray.recycle();
    }
    
    public a(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */