package androidx.appcompat.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.TextView;
import b.b.j;
import b.b.q.g0;
import b.b.q.m;
import b.b.q.m0;
import b.b.q.q;
import b.h.n.r;
import b.h.o.i;

public class SwitchCompat extends CompoundButton {
  public static final Property<SwitchCompat, Float> b0 = new a(Float.class, "thumbPos");
  
  public static final int[] c0 = new int[] { 16842912 };
  
  public int C;
  
  public int D;
  
  public float E;
  
  public float F;
  
  public VelocityTracker G = VelocityTracker.obtain();
  
  public int H;
  
  public float I;
  
  public int J;
  
  public int K;
  
  public int L;
  
  public int M;
  
  public int N;
  
  public int O;
  
  public int P;
  
  public final TextPaint Q;
  
  public ColorStateList R;
  
  public Layout S;
  
  public Layout T;
  
  public TransformationMethod U;
  
  public ObjectAnimator V;
  
  public final m W;
  
  public Drawable a;
  
  public final Rect a0 = new Rect();
  
  public ColorStateList b = null;
  
  public PorterDuff.Mode c = null;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public Drawable f;
  
  public ColorStateList g = null;
  
  public PorterDuff.Mode h = null;
  
  public boolean i = false;
  
  public boolean j = false;
  
  public int k;
  
  public int l;
  
  public int m;
  
  public boolean n;
  
  public CharSequence o;
  
  public CharSequence p;
  
  public boolean q;
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TextPaint textPaint = new TextPaint(1);
    this.Q = textPaint;
    textPaint.density = (getResources().getDisplayMetrics()).density;
    g0 g0 = g0.t(paramContext, paramAttributeSet, j.x2, paramInt, 0);
    Drawable drawable = g0.f(j.A2);
    this.a = drawable;
    if (drawable != null)
      drawable.setCallback((Drawable.Callback)this); 
    drawable = g0.f(j.J2);
    this.f = drawable;
    if (drawable != null)
      drawable.setCallback((Drawable.Callback)this); 
    this.o = g0.o(j.y2);
    this.p = g0.o(j.z2);
    this.q = g0.a(j.B2, true);
    this.k = g0.e(j.G2, 0);
    this.l = g0.e(j.D2, 0);
    this.m = g0.e(j.E2, 0);
    this.n = g0.a(j.C2, false);
    ColorStateList colorStateList2 = g0.c(j.H2);
    if (colorStateList2 != null) {
      this.b = colorStateList2;
      this.d = true;
    } 
    PorterDuff.Mode mode2 = q.e(g0.j(j.I2, -1), null);
    if (this.c != mode2) {
      this.c = mode2;
      this.e = true;
    } 
    if (this.d || this.e)
      b(); 
    ColorStateList colorStateList1 = g0.c(j.K2);
    if (colorStateList1 != null) {
      this.g = colorStateList1;
      this.i = true;
    } 
    PorterDuff.Mode mode1 = q.e(g0.j(j.L2, -1), null);
    if (this.h != mode1) {
      this.h = mode1;
      this.j = true;
    } 
    if (this.i || this.j)
      c(); 
    int i = g0.m(j.F2, 0);
    if (i != 0)
      i(paramContext, i); 
    m m1 = new m((TextView)this);
    this.W = m1;
    m1.m(paramAttributeSet, paramInt);
    g0.u();
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    this.D = viewConfiguration.getScaledTouchSlop();
    this.H = viewConfiguration.getScaledMinimumFlingVelocity();
    refreshDrawableState();
    setChecked(isChecked());
  }
  
  public static float f(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat1 < paramFloat2)
      return paramFloat2; 
    paramFloat2 = paramFloat1;
    if (paramFloat1 > paramFloat3)
      paramFloat2 = paramFloat3; 
    return paramFloat2;
  }
  
  private boolean getTargetCheckedState() {
    return (this.I > 0.5F);
  }
  
  private int getThumbOffset() {
    float f;
    if (m0.b((View)this)) {
      f = 1.0F - this.I;
    } else {
      f = this.I;
    } 
    return (int)(f * getThumbScrollRange() + 0.5F);
  }
  
  private int getThumbScrollRange() {
    Drawable drawable = this.f;
    if (drawable != null) {
      Rect rect1;
      Rect rect2 = this.a0;
      drawable.getPadding(rect2);
      drawable = this.a;
      if (drawable != null) {
        rect1 = q.d(drawable);
      } else {
        rect1 = q.c;
      } 
      return this.J - this.L - rect2.left - rect2.right - rect1.left - rect1.right;
    } 
    return 0;
  }
  
  public final void a(boolean paramBoolean) {
    float f;
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(this, b0, new float[] { f });
    this.V = objectAnimator;
    objectAnimator.setDuration(250L);
    if (Build.VERSION.SDK_INT >= 18)
      this.V.setAutoCancel(true); 
    this.V.start();
  }
  
  public final void b() {
    Drawable drawable = this.a;
    if (drawable != null && (this.d || this.e)) {
      drawable = b.h.g.l.a.q(drawable).mutate();
      this.a = drawable;
      if (this.d)
        b.h.g.l.a.n(drawable, this.b); 
      if (this.e)
        b.h.g.l.a.o(this.a, this.c); 
      if (this.a.isStateful())
        this.a.setState(getDrawableState()); 
    } 
  }
  
  public final void c() {
    Drawable drawable = this.f;
    if (drawable != null && (this.i || this.j)) {
      drawable = b.h.g.l.a.q(drawable).mutate();
      this.f = drawable;
      if (this.i)
        b.h.g.l.a.n(drawable, this.g); 
      if (this.j)
        b.h.g.l.a.o(this.f, this.h); 
      if (this.f.isStateful())
        this.f.setState(getDrawableState()); 
    } 
  }
  
  public final void d() {
    ObjectAnimator objectAnimator = this.V;
    if (objectAnimator != null)
      objectAnimator.cancel(); 
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a0 : Landroid/graphics/Rect;
    //   4: astore #14
    //   6: aload_0
    //   7: getfield M : I
    //   10: istore #5
    //   12: aload_0
    //   13: getfield N : I
    //   16: istore #8
    //   18: aload_0
    //   19: getfield O : I
    //   22: istore #6
    //   24: aload_0
    //   25: getfield P : I
    //   28: istore #9
    //   30: aload_0
    //   31: invokespecial getThumbOffset : ()I
    //   34: iload #5
    //   36: iadd
    //   37: istore_3
    //   38: aload_0
    //   39: getfield a : Landroid/graphics/drawable/Drawable;
    //   42: astore #13
    //   44: aload #13
    //   46: ifnull -> 59
    //   49: aload #13
    //   51: invokestatic d : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Rect;
    //   54: astore #13
    //   56: goto -> 64
    //   59: getstatic b/b/q/q.c : Landroid/graphics/Rect;
    //   62: astore #13
    //   64: aload_0
    //   65: getfield f : Landroid/graphics/drawable/Drawable;
    //   68: astore #15
    //   70: iload_3
    //   71: istore_2
    //   72: aload #15
    //   74: ifnull -> 274
    //   77: aload #15
    //   79: aload #14
    //   81: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   84: pop
    //   85: aload #14
    //   87: getfield left : I
    //   90: istore #4
    //   92: iload_3
    //   93: iload #4
    //   95: iadd
    //   96: istore #10
    //   98: aload #13
    //   100: ifnull -> 238
    //   103: aload #13
    //   105: getfield left : I
    //   108: istore_3
    //   109: iload #5
    //   111: istore_2
    //   112: iload_3
    //   113: iload #4
    //   115: if_icmple -> 126
    //   118: iload #5
    //   120: iload_3
    //   121: iload #4
    //   123: isub
    //   124: iadd
    //   125: istore_2
    //   126: aload #13
    //   128: getfield top : I
    //   131: istore_3
    //   132: aload #14
    //   134: getfield top : I
    //   137: istore #4
    //   139: iload_3
    //   140: iload #4
    //   142: if_icmple -> 156
    //   145: iload_3
    //   146: iload #4
    //   148: isub
    //   149: iload #8
    //   151: iadd
    //   152: istore_3
    //   153: goto -> 159
    //   156: iload #8
    //   158: istore_3
    //   159: aload #13
    //   161: getfield right : I
    //   164: istore #5
    //   166: aload #14
    //   168: getfield right : I
    //   171: istore #7
    //   173: iload #6
    //   175: istore #4
    //   177: iload #5
    //   179: iload #7
    //   181: if_icmple -> 194
    //   184: iload #6
    //   186: iload #5
    //   188: iload #7
    //   190: isub
    //   191: isub
    //   192: istore #4
    //   194: aload #13
    //   196: getfield bottom : I
    //   199: istore #11
    //   201: aload #14
    //   203: getfield bottom : I
    //   206: istore #12
    //   208: iload_2
    //   209: istore #5
    //   211: iload #4
    //   213: istore #6
    //   215: iload_3
    //   216: istore #7
    //   218: iload #11
    //   220: iload #12
    //   222: if_icmple -> 242
    //   225: iload #9
    //   227: iload #11
    //   229: iload #12
    //   231: isub
    //   232: isub
    //   233: istore #7
    //   235: goto -> 258
    //   238: iload #8
    //   240: istore #7
    //   242: iload #9
    //   244: istore_2
    //   245: iload #7
    //   247: istore_3
    //   248: iload_2
    //   249: istore #7
    //   251: iload #6
    //   253: istore #4
    //   255: iload #5
    //   257: istore_2
    //   258: aload_0
    //   259: getfield f : Landroid/graphics/drawable/Drawable;
    //   262: iload_2
    //   263: iload_3
    //   264: iload #4
    //   266: iload #7
    //   268: invokevirtual setBounds : (IIII)V
    //   271: iload #10
    //   273: istore_2
    //   274: aload_0
    //   275: getfield a : Landroid/graphics/drawable/Drawable;
    //   278: astore #13
    //   280: aload #13
    //   282: ifnull -> 349
    //   285: aload #13
    //   287: aload #14
    //   289: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   292: pop
    //   293: iload_2
    //   294: aload #14
    //   296: getfield left : I
    //   299: isub
    //   300: istore_3
    //   301: iload_2
    //   302: aload_0
    //   303: getfield L : I
    //   306: iadd
    //   307: aload #14
    //   309: getfield right : I
    //   312: iadd
    //   313: istore_2
    //   314: aload_0
    //   315: getfield a : Landroid/graphics/drawable/Drawable;
    //   318: iload_3
    //   319: iload #8
    //   321: iload_2
    //   322: iload #9
    //   324: invokevirtual setBounds : (IIII)V
    //   327: aload_0
    //   328: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   331: astore #13
    //   333: aload #13
    //   335: ifnull -> 349
    //   338: aload #13
    //   340: iload_3
    //   341: iload #8
    //   343: iload_2
    //   344: iload #9
    //   346: invokestatic k : (Landroid/graphics/drawable/Drawable;IIII)V
    //   349: aload_0
    //   350: aload_1
    //   351: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   354: return
  }
  
  public void drawableHotspotChanged(float paramFloat1, float paramFloat2) {
    if (Build.VERSION.SDK_INT >= 21)
      super.drawableHotspotChanged(paramFloat1, paramFloat2); 
    Drawable drawable = this.a;
    if (drawable != null)
      b.h.g.l.a.j(drawable, paramFloat1, paramFloat2); 
    drawable = this.f;
    if (drawable != null)
      b.h.g.l.a.j(drawable, paramFloat1, paramFloat2); 
  }
  
  public void drawableStateChanged() {
    boolean bool;
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.a;
    int j = 0;
    int i = j;
    if (drawable != null) {
      i = j;
      if (drawable.isStateful())
        i = false | drawable.setState(arrayOfInt); 
    } 
    drawable = this.f;
    j = i;
    if (drawable != null) {
      j = i;
      if (drawable.isStateful())
        bool = i | drawable.setState(arrayOfInt); 
    } 
    if (bool)
      invalidate(); 
  }
  
  public final void e(MotionEvent paramMotionEvent) {
    paramMotionEvent = MotionEvent.obtain(paramMotionEvent);
    paramMotionEvent.setAction(3);
    super.onTouchEvent(paramMotionEvent);
    paramMotionEvent.recycle();
  }
  
  public final boolean g(float paramFloat1, float paramFloat2) {
    Drawable drawable = this.a;
    boolean bool2 = false;
    if (drawable == null)
      return false; 
    int k = getThumbOffset();
    this.a.getPadding(this.a0);
    int i = this.N;
    int j = this.D;
    k = this.M + k - j;
    int n = this.L;
    Rect rect = this.a0;
    int i1 = rect.left;
    int i2 = rect.right;
    int i3 = this.P;
    boolean bool1 = bool2;
    if (paramFloat1 > k) {
      bool1 = bool2;
      if (paramFloat1 < (n + k + i1 + i2 + j)) {
        bool1 = bool2;
        if (paramFloat2 > (i - j)) {
          bool1 = bool2;
          if (paramFloat2 < (i3 + j))
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  public int getCompoundPaddingLeft() {
    if (!m0.b((View)this))
      return super.getCompoundPaddingLeft(); 
    int j = super.getCompoundPaddingLeft() + this.J;
    int i = j;
    if (!TextUtils.isEmpty(getText()))
      i = j + this.m; 
    return i;
  }
  
  public int getCompoundPaddingRight() {
    if (m0.b((View)this))
      return super.getCompoundPaddingRight(); 
    int j = super.getCompoundPaddingRight() + this.J;
    int i = j;
    if (!TextUtils.isEmpty(getText()))
      i = j + this.m; 
    return i;
  }
  
  public boolean getShowText() {
    return this.q;
  }
  
  public boolean getSplitTrack() {
    return this.n;
  }
  
  public int getSwitchMinWidth() {
    return this.l;
  }
  
  public int getSwitchPadding() {
    return this.m;
  }
  
  public CharSequence getTextOff() {
    return this.p;
  }
  
  public CharSequence getTextOn() {
    return this.o;
  }
  
  public Drawable getThumbDrawable() {
    return this.a;
  }
  
  public int getThumbTextPadding() {
    return this.k;
  }
  
  public ColorStateList getThumbTintList() {
    return this.b;
  }
  
  public PorterDuff.Mode getThumbTintMode() {
    return this.c;
  }
  
  public Drawable getTrackDrawable() {
    return this.f;
  }
  
  public ColorStateList getTrackTintList() {
    return this.g;
  }
  
  public PorterDuff.Mode getTrackTintMode() {
    return this.h;
  }
  
  public final Layout h(CharSequence paramCharSequence) {
    boolean bool;
    TransformationMethod transformationMethod = this.U;
    CharSequence charSequence = paramCharSequence;
    if (transformationMethod != null)
      charSequence = transformationMethod.getTransformation(paramCharSequence, (View)this); 
    TextPaint textPaint = this.Q;
    if (charSequence != null) {
      bool = (int)Math.ceil(Layout.getDesiredWidth(charSequence, textPaint));
    } else {
      bool = false;
    } 
    return (Layout)new StaticLayout(charSequence, textPaint, bool, Layout.Alignment.ALIGN_NORMAL, 1.0F, 0.0F, true);
  }
  
  public void i(Context paramContext, int paramInt) {
    g0 g0 = g0.r(paramContext, paramInt, j.M2);
    ColorStateList colorStateList = g0.c(j.Q2);
    if (colorStateList != null) {
      this.R = colorStateList;
    } else {
      this.R = getTextColors();
    } 
    paramInt = g0.e(j.N2, 0);
    if (paramInt != 0) {
      float f = paramInt;
      if (f != this.Q.getTextSize()) {
        this.Q.setTextSize(f);
        requestLayout();
      } 
    } 
    k(g0.j(j.O2, -1), g0.j(j.P2, -1));
    if (g0.a(j.X2, false)) {
      this.U = (TransformationMethod)new b.b.o.a(getContext());
    } else {
      this.U = null;
    } 
    g0.u();
  }
  
  public void j(Typeface paramTypeface, int paramInt) {
    TextPaint textPaint;
    float f = 0.0F;
    boolean bool = false;
    if (paramInt > 0) {
      boolean bool1;
      if (paramTypeface == null) {
        paramTypeface = Typeface.defaultFromStyle(paramInt);
      } else {
        paramTypeface = Typeface.create(paramTypeface, paramInt);
      } 
      setSwitchTypeface(paramTypeface);
      if (paramTypeface != null) {
        bool1 = paramTypeface.getStyle();
      } else {
        bool1 = false;
      } 
      paramInt = (bool1 ^ 0xFFFFFFFF) & paramInt;
      textPaint = this.Q;
      if ((paramInt & 0x1) != 0)
        bool = true; 
      textPaint.setFakeBoldText(bool);
      textPaint = this.Q;
      if ((paramInt & 0x2) != 0)
        f = -0.25F; 
      textPaint.setTextSkewX(f);
      return;
    } 
    this.Q.setFakeBoldText(false);
    this.Q.setTextSkewX(0.0F);
    setSwitchTypeface((Typeface)textPaint);
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    Drawable drawable = this.a;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    drawable = this.f;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    ObjectAnimator objectAnimator = this.V;
    if (objectAnimator != null && objectAnimator.isStarted()) {
      this.V.end();
      this.V = null;
    } 
  }
  
  public final void k(int paramInt1, int paramInt2) {
    Typeface typeface;
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3) {
          typeface = null;
        } else {
          typeface = Typeface.MONOSPACE;
        } 
      } else {
        typeface = Typeface.SERIF;
      } 
    } else {
      typeface = Typeface.SANS_SERIF;
    } 
    j(typeface, paramInt2);
  }
  
  public final void l(MotionEvent paramMotionEvent) {
    this.C = 0;
    int i = paramMotionEvent.getAction();
    boolean bool1 = true;
    if (i == 1 && isEnabled()) {
      i = 1;
    } else {
      i = 0;
    } 
    boolean bool2 = isChecked();
    if (i != 0) {
      this.G.computeCurrentVelocity(1000);
      float f = this.G.getXVelocity();
      if (Math.abs(f) > this.H) {
        if (m0.b((View)this) ? (f < 0.0F) : (f > 0.0F))
          bool1 = false; 
      } else {
        bool1 = getTargetCheckedState();
      } 
    } else {
      bool1 = bool2;
    } 
    if (bool1 != bool2)
      playSoundEffect(0); 
    setChecked(bool1);
    e(paramMotionEvent);
  }
  
  public int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 1);
    if (isChecked())
      CompoundButton.mergeDrawableStates(arrayOfInt, c0); 
    return arrayOfInt;
  }
  
  public void onDraw(Canvas paramCanvas) {
    Layout layout;
    super.onDraw(paramCanvas);
    Rect rect = this.a0;
    Drawable drawable2 = this.f;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
    } else {
      rect.setEmpty();
    } 
    int j = this.N;
    int k = this.P;
    int n = rect.top;
    int i1 = rect.bottom;
    Drawable drawable1 = this.a;
    if (drawable2 != null)
      if (this.n && drawable1 != null) {
        Rect rect1 = q.d(drawable1);
        drawable1.copyBounds(rect);
        rect.left += rect1.left;
        rect.right -= rect1.right;
        int i2 = paramCanvas.save();
        paramCanvas.clipRect(rect, Region.Op.DIFFERENCE);
        drawable2.draw(paramCanvas);
        paramCanvas.restoreToCount(i2);
      } else {
        drawable2.draw(paramCanvas);
      }  
    int i = paramCanvas.save();
    if (drawable1 != null)
      drawable1.draw(paramCanvas); 
    if (getTargetCheckedState()) {
      layout = this.S;
    } else {
      layout = this.T;
    } 
    if (layout != null) {
      int i2;
      int[] arrayOfInt = getDrawableState();
      ColorStateList colorStateList = this.R;
      if (colorStateList != null)
        this.Q.setColor(colorStateList.getColorForState(arrayOfInt, 0)); 
      this.Q.drawableState = arrayOfInt;
      if (drawable1 != null) {
        Rect rect1 = drawable1.getBounds();
        i2 = rect1.left + rect1.right;
      } else {
        i2 = getWidth();
      } 
      i2 /= 2;
      int i3 = layout.getWidth() / 2;
      j = (j + n + k - i1) / 2;
      k = layout.getHeight() / 2;
      paramCanvas.translate((i2 - i3), (j - k));
      layout.draw(paramCanvas);
    } 
    paramCanvas.restoreToCount(i);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("android.widget.Switch");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    CharSequence charSequence;
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("android.widget.Switch");
    if (isChecked()) {
      charSequence = this.o;
    } else {
      charSequence = this.p;
    } 
    if (!TextUtils.isEmpty(charSequence)) {
      CharSequence charSequence1 = paramAccessibilityNodeInfo.getText();
      if (TextUtils.isEmpty(charSequence1)) {
        paramAccessibilityNodeInfo.setText(charSequence);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(charSequence1);
      stringBuilder.append(' ');
      stringBuilder.append(charSequence);
      paramAccessibilityNodeInfo.setText(stringBuilder);
    } 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    Drawable drawable = this.a;
    paramInt1 = 0;
    if (drawable != null) {
      Rect rect1 = this.a0;
      Drawable drawable1 = this.f;
      if (drawable1 != null) {
        drawable1.getPadding(rect1);
      } else {
        rect1.setEmpty();
      } 
      Rect rect2 = q.d(this.a);
      paramInt2 = Math.max(0, rect2.left - rect1.left);
      paramInt1 = Math.max(0, rect2.right - rect1.right);
    } else {
      paramInt2 = 0;
    } 
    if (m0.b((View)this)) {
      paramInt3 = getPaddingLeft() + paramInt2;
      paramInt1 = this.J + paramInt3 - paramInt2 - paramInt1;
      paramInt2 = paramInt3;
      paramInt3 = paramInt1;
    } else {
      paramInt3 = getWidth() - getPaddingRight() - paramInt1;
      paramInt2 = paramInt3 - this.J + paramInt2 + paramInt1;
    } 
    paramInt1 = getGravity() & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
        paramInt4 = this.K;
      } else {
        paramInt4 = getHeight() - getPaddingBottom();
        paramInt1 = paramInt4 - this.K;
        this.M = paramInt2;
        this.N = paramInt1;
        this.P = paramInt4;
        this.O = paramInt3;
      } 
    } else {
      paramInt1 = (getPaddingTop() + getHeight() - getPaddingBottom()) / 2;
      paramInt4 = this.K;
      paramInt1 -= paramInt4 / 2;
    } 
    paramInt4 += paramInt1;
    this.M = paramInt2;
    this.N = paramInt1;
    this.P = paramInt4;
    this.O = paramInt3;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int j;
    if (this.q) {
      if (this.S == null)
        this.S = h(this.o); 
      if (this.T == null)
        this.T = h(this.p); 
    } 
    Rect rect = this.a0;
    Drawable drawable2 = this.a;
    int n = 0;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
      j = this.a.getIntrinsicWidth() - rect.left - rect.right;
      i = this.a.getIntrinsicHeight();
    } else {
      j = 0;
      i = 0;
    } 
    if (this.q) {
      k = Math.max(this.S.getWidth(), this.T.getWidth()) + this.k * 2;
    } else {
      k = 0;
    } 
    this.L = Math.max(k, j);
    drawable2 = this.f;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
      j = this.f.getIntrinsicHeight();
    } else {
      rect.setEmpty();
      j = n;
    } 
    int i2 = rect.left;
    int i1 = rect.right;
    Drawable drawable1 = this.a;
    n = i1;
    int k = i2;
    if (drawable1 != null) {
      Rect rect1 = q.d(drawable1);
      k = Math.max(i2, rect1.left);
      n = Math.max(i1, rect1.right);
    } 
    k = Math.max(this.l, this.L * 2 + k + n);
    int i = Math.max(j, i);
    this.J = k;
    this.K = i;
    super.onMeasure(paramInt1, paramInt2);
    if (getMeasuredHeight() < i)
      setMeasuredDimension(getMeasuredWidthAndState(), i); 
  }
  
  public void onPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    CharSequence charSequence;
    super.onPopulateAccessibilityEvent(paramAccessibilityEvent);
    if (isChecked()) {
      charSequence = this.o;
    } else {
      charSequence = this.p;
    } 
    if (charSequence != null)
      paramAccessibilityEvent.getText().add(charSequence); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    this.G.addMovement(paramMotionEvent);
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3)
            return super.onTouchEvent(paramMotionEvent); 
        } else {
          i = this.C;
          if (i != 1) {
            if (i == 2) {
              float f3 = paramMotionEvent.getX();
              i = getThumbScrollRange();
              float f1 = f3 - this.E;
              if (i != 0) {
                f1 /= i;
              } else if (f1 > 0.0F) {
                f1 = 1.0F;
              } else {
                f1 = -1.0F;
              } 
              float f2 = f1;
              if (m0.b((View)this))
                f2 = -f1; 
              f1 = f(this.I + f2, 0.0F, 1.0F);
              if (f1 != this.I) {
                this.E = f3;
                setThumbPosition(f1);
              } 
              return true;
            } 
          } else {
            float f1 = paramMotionEvent.getX();
            float f2 = paramMotionEvent.getY();
            if (Math.abs(f1 - this.E) > this.D || Math.abs(f2 - this.F) > this.D) {
              this.C = 2;
              getParent().requestDisallowInterceptTouchEvent(true);
              this.E = f1;
              this.F = f2;
              return true;
            } 
          } 
          return super.onTouchEvent(paramMotionEvent);
        }  
      if (this.C == 2) {
        l(paramMotionEvent);
        super.onTouchEvent(paramMotionEvent);
        return true;
      } 
      this.C = 0;
      this.G.clear();
    } else {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      if (isEnabled() && g(f1, f2)) {
        this.C = 1;
        this.E = f1;
        this.F = f2;
      } 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setChecked(boolean paramBoolean) {
    float f;
    super.setChecked(paramBoolean);
    paramBoolean = isChecked();
    if (getWindowToken() != null && r.B((View)this)) {
      a(paramBoolean);
      return;
    } 
    d();
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    setThumbPosition(f);
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(i.m((TextView)this, paramCallback));
  }
  
  public void setShowText(boolean paramBoolean) {
    if (this.q != paramBoolean) {
      this.q = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setSplitTrack(boolean paramBoolean) {
    this.n = paramBoolean;
    invalidate();
  }
  
  public void setSwitchMinWidth(int paramInt) {
    this.l = paramInt;
    requestLayout();
  }
  
  public void setSwitchPadding(int paramInt) {
    this.m = paramInt;
    requestLayout();
  }
  
  public void setSwitchTypeface(Typeface paramTypeface) {
    if ((this.Q.getTypeface() != null && !this.Q.getTypeface().equals(paramTypeface)) || (this.Q.getTypeface() == null && paramTypeface != null)) {
      this.Q.setTypeface(paramTypeface);
      requestLayout();
      invalidate();
    } 
  }
  
  public void setTextOff(CharSequence paramCharSequence) {
    this.p = paramCharSequence;
    requestLayout();
  }
  
  public void setTextOn(CharSequence paramCharSequence) {
    this.o = paramCharSequence;
    requestLayout();
  }
  
  public void setThumbDrawable(Drawable paramDrawable) {
    Drawable drawable = this.a;
    if (drawable != null)
      drawable.setCallback(null); 
    this.a = paramDrawable;
    if (paramDrawable != null)
      paramDrawable.setCallback((Drawable.Callback)this); 
    requestLayout();
  }
  
  public void setThumbPosition(float paramFloat) {
    this.I = paramFloat;
    invalidate();
  }
  
  public void setThumbResource(int paramInt) {
    setThumbDrawable(b.b.l.a.a.d(getContext(), paramInt));
  }
  
  public void setThumbTextPadding(int paramInt) {
    this.k = paramInt;
    requestLayout();
  }
  
  public void setThumbTintList(ColorStateList paramColorStateList) {
    this.b = paramColorStateList;
    this.d = true;
    b();
  }
  
  public void setThumbTintMode(PorterDuff.Mode paramMode) {
    this.c = paramMode;
    this.e = true;
    b();
  }
  
  public void setTrackDrawable(Drawable paramDrawable) {
    Drawable drawable = this.f;
    if (drawable != null)
      drawable.setCallback(null); 
    this.f = paramDrawable;
    if (paramDrawable != null)
      paramDrawable.setCallback((Drawable.Callback)this); 
    requestLayout();
  }
  
  public void setTrackResource(int paramInt) {
    setTrackDrawable(b.b.l.a.a.d(getContext(), paramInt));
  }
  
  public void setTrackTintList(ColorStateList paramColorStateList) {
    this.g = paramColorStateList;
    this.i = true;
    c();
  }
  
  public void setTrackTintMode(PorterDuff.Mode paramMode) {
    this.h = paramMode;
    this.j = true;
    c();
  }
  
  public void toggle() {
    setChecked(isChecked() ^ true);
  }
  
  public boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.a || paramDrawable == this.f);
  }
  
  public static final class a extends Property<SwitchCompat, Float> {
    public a(Class param1Class, String param1String) {
      super(param1Class, param1String);
    }
    
    public Float a(SwitchCompat param1SwitchCompat) {
      return Float.valueOf(param1SwitchCompat.I);
    }
    
    public void b(SwitchCompat param1SwitchCompat, Float param1Float) {
      param1SwitchCompat.setThumbPosition(param1Float.floatValue());
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\SwitchCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */