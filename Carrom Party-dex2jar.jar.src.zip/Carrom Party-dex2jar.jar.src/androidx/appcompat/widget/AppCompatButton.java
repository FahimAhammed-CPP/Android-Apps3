package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import b.b.a;
import b.b.q.d0;
import b.b.q.e;
import b.b.q.m;
import b.h.n.q;
import b.h.o.b;
import b.h.o.i;

public class AppCompatButton extends Button implements q, b {
  public final e a;
  
  public final m b;
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.q);
  }
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(d0.b(paramContext), paramAttributeSet, paramInt);
    e e1 = new e((View)this);
    this.a = e1;
    e1.e(paramAttributeSet, paramInt);
    m m1 = new m((TextView)this);
    this.b = m1;
    m1.m(paramAttributeSet, paramInt);
    m1.b();
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.a;
    if (e1 != null)
      e1.b(); 
    m m1 = this.b;
    if (m1 != null)
      m1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (b.r)
      return super.getAutoSizeMaxTextSize(); 
    m m1 = this.b;
    return (m1 != null) ? m1.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (b.r)
      return super.getAutoSizeMinTextSize(); 
    m m1 = this.b;
    return (m1 != null) ? m1.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (b.r)
      return super.getAutoSizeStepGranularity(); 
    m m1 = this.b;
    return (m1 != null) ? m1.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (b.r)
      return super.getAutoSizeTextAvailableSizes(); 
    m m1 = this.b;
    return (m1 != null) ? m1.h() : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = b.r;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    m m1 = this.b;
    return (m1 != null) ? m1.i() : 0;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.a;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.a;
    return (e1 != null) ? e1.d() : null;
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(Button.class.getName());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(Button.class.getName());
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    m m1 = this.b;
    if (m1 != null)
      m1.n(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    m m1 = this.b;
    if (m1 != null && !b.r && m1.l())
      this.b.c(); 
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (b.r) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    m m1 = this.b;
    if (m1 != null)
      m1.s(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) {
    if (b.r) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
      return;
    } 
    m m1 = this.b;
    if (m1 != null)
      m1.t(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (b.r) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    } 
    m m1 = this.b;
    if (m1 != null)
      m1.u(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.a;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.a;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(i.m((TextView)this, paramCallback));
  }
  
  public void setSupportAllCaps(boolean paramBoolean) {
    m m1 = this.b;
    if (m1 != null)
      m1.r(paramBoolean); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.a;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.a;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    m m1 = this.b;
    if (m1 != null)
      m1.p(paramContext, paramInt); 
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (b.r) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    m m1 = this.b;
    if (m1 != null)
      m1.z(paramInt, paramFloat); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\AppCompatButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */