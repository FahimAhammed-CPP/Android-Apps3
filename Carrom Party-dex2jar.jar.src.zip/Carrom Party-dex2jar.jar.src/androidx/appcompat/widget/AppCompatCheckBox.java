package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import b.b.a;
import b.b.l.a.a;
import b.b.q.d0;
import b.b.q.e;
import b.b.q.f;
import b.b.q.m;
import b.h.n.q;
import b.h.o.j;

public class AppCompatCheckBox extends CheckBox implements j, q {
  public final f a;
  
  public final e b;
  
  public final m c;
  
  public AppCompatCheckBox(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.r);
  }
  
  public AppCompatCheckBox(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(d0.b(paramContext), paramAttributeSet, paramInt);
    f f1 = new f((CompoundButton)this);
    this.a = f1;
    f1.e(paramAttributeSet, paramInt);
    e e1 = new e((View)this);
    this.b = e1;
    e1.e(paramAttributeSet, paramInt);
    m m1 = new m((TextView)this);
    this.c = m1;
    m1.m(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    e e1 = this.b;
    if (e1 != null)
      e1.b(); 
    m m1 = this.c;
    if (m1 != null)
      m1.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int k = super.getCompoundPaddingLeft();
    f f1 = this.a;
    int i = k;
    if (f1 != null)
      i = f1.b(k); 
    return i;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    e e1 = this.b;
    return (e1 != null) ? e1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    e e1 = this.b;
    return (e1 != null) ? e1.d() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    f f1 = this.a;
    return (f1 != null) ? f1.c() : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    f f1 = this.a;
    return (f1 != null) ? f1.d() : null;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    e e1 = this.b;
    if (e1 != null)
      e1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    e e1 = this.b;
    if (e1 != null)
      e1.g(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.d(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    f f1 = this.a;
    if (f1 != null)
      f1.f(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    e e1 = this.b;
    if (e1 != null)
      e1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    e e1 = this.b;
    if (e1 != null)
      e1.j(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    f f1 = this.a;
    if (f1 != null)
      f1.g(paramColorStateList); 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    f f1 = this.a;
    if (f1 != null)
      f1.h(paramMode); 
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\AppCompatCheckBox.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */