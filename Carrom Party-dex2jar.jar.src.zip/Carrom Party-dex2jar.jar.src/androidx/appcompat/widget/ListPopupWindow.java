package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import b.b.j;
import b.b.p.j.p;
import b.b.q.r;
import b.h.n.r;
import b.h.o.h;
import java.lang.reflect.Method;

public class ListPopupWindow implements p {
  public static Method Q;
  
  public static Method R;
  
  public static Method S;
  
  public DataSetObserver C;
  
  public View D;
  
  public Drawable E;
  
  public AdapterView.OnItemClickListener F;
  
  public AdapterView.OnItemSelectedListener G;
  
  public final f H = new f(this);
  
  public final e I = new e(this);
  
  public final d J = new d(this);
  
  public final b K = new b(this);
  
  public final Handler L;
  
  public final Rect M = new Rect();
  
  public Rect N;
  
  public boolean O;
  
  public PopupWindow P;
  
  public Context a;
  
  public ListAdapter b;
  
  public r c;
  
  public int d = -2;
  
  public int e = -2;
  
  public int f;
  
  public int g;
  
  public int h = 1002;
  
  public boolean i;
  
  public boolean j;
  
  public boolean k;
  
  public int l = 0;
  
  public boolean m = false;
  
  public boolean n = false;
  
  public int o = Integer.MAX_VALUE;
  
  public View p;
  
  public int q = 0;
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        Q = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
      } 
      try {
        S = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
      } 
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        R = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
      }  
  }
  
  public ListPopupWindow(Context paramContext) {
    this(paramContext, null, b.b.a.D);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.a = paramContext;
    this.L = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.g1, paramInt1, paramInt2);
    this.f = typedArray.getDimensionPixelOffset(j.h1, 0);
    int i = typedArray.getDimensionPixelOffset(j.i1, 0);
    this.g = i;
    if (i != 0)
      this.i = true; 
    typedArray.recycle();
    AppCompatPopupWindow appCompatPopupWindow = new AppCompatPopupWindow(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.P = appCompatPopupWindow;
    appCompatPopupWindow.setInputMethodMode(1);
  }
  
  public void A(int paramInt) {
    Drawable drawable = this.P.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.M);
      Rect rect = this.M;
      this.e = rect.left + rect.right + paramInt;
      return;
    } 
    L(paramInt);
  }
  
  public void B(int paramInt) {
    this.l = paramInt;
  }
  
  public void C(Rect paramRect) {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    } 
    this.N = paramRect;
  }
  
  public void D(int paramInt) {
    this.P.setInputMethodMode(paramInt);
  }
  
  public void E(boolean paramBoolean) {
    this.O = paramBoolean;
    this.P.setFocusable(paramBoolean);
  }
  
  public void F(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.P.setOnDismissListener(paramOnDismissListener);
  }
  
  public void G(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.F = paramOnItemClickListener;
  }
  
  public void H(boolean paramBoolean) {
    this.k = true;
    this.j = paramBoolean;
  }
  
  public final void I(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = Q;
      if (method != null)
        try {
          method.invoke(this.P, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
          return;
        }  
    } else {
      this.P.setIsClippedToScreen(paramBoolean);
    } 
  }
  
  public void J(int paramInt) {
    this.q = paramInt;
  }
  
  public void K(int paramInt) {
    r r1 = this.c;
    if (a() && r1 != null) {
      r1.setListSelectionHidden(false);
      r1.setSelection(paramInt);
      if (r1.getChoiceMode() != 0)
        r1.setItemChecked(paramInt, true); 
    } 
  }
  
  public void L(int paramInt) {
    this.e = paramInt;
  }
  
  public boolean a() {
    return this.P.isShowing();
  }
  
  public int b() {
    return this.f;
  }
  
  public void d(int paramInt) {
    this.f = paramInt;
  }
  
  public void dismiss() {
    this.P.dismiss();
    x();
    this.P.setContentView(null);
    this.c = null;
    this.L.removeCallbacks(this.H);
  }
  
  public Drawable g() {
    return this.P.getBackground();
  }
  
  public ListView i() {
    return (ListView)this.c;
  }
  
  public void j(Drawable paramDrawable) {
    this.P.setBackgroundDrawable(paramDrawable);
  }
  
  public void k(int paramInt) {
    this.g = paramInt;
    this.i = true;
  }
  
  public int n() {
    return !this.i ? 0 : this.g;
  }
  
  public void o(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.C;
    if (dataSetObserver == null) {
      this.C = new c(this);
    } else {
      ListAdapter listAdapter = this.b;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.b = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.C); 
    r r1 = this.c;
    if (r1 != null)
      r1.setAdapter(this.b); 
  }
  
  public final int p() {
    byte b1;
    byte b2;
    r r1 = this.c;
    boolean bool = true;
    if (r1 == null) {
      LinearLayout.LayoutParams layoutParams1;
      LinearLayout.LayoutParams layoutParams2;
      Context context = this.a;
      r r3 = r(context, this.O ^ true);
      this.c = r3;
      Drawable drawable1 = this.E;
      if (drawable1 != null)
        r3.setSelector(drawable1); 
      this.c.setAdapter(this.b);
      this.c.setOnItemClickListener(this.F);
      this.c.setFocusable(true);
      this.c.setFocusableInTouchMode(true);
      this.c.setOnItemSelectedListener(new a(this));
      this.c.setOnScrollListener(this.J);
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.G;
      if (onItemSelectedListener != null)
        this.c.setOnItemSelectedListener(onItemSelectedListener); 
      r r2 = this.c;
      View view = this.p;
      if (view != null) {
        boolean bool1;
        StringBuilder stringBuilder;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        b1 = this.q;
        if (b1 != 0) {
          if (b1 != 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid hint position ");
            stringBuilder.append(this.q);
            Log.e("ListPopupWindow", stringBuilder.toString());
          } else {
            linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
            linearLayout.addView(view);
          } 
        } else {
          linearLayout.addView(view);
          linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
        } 
        b1 = this.e;
        if (b1 >= 0) {
          bool1 = true;
        } else {
          b1 = 0;
          bool1 = false;
        } 
        view.measure(View.MeasureSpec.makeMeasureSpec(b1, bool1), 0);
        layoutParams2 = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
      } else {
        b1 = 0;
        layoutParams1 = layoutParams2;
      } 
      this.P.setContentView((View)layoutParams1);
    } else {
      ViewGroup viewGroup = (ViewGroup)this.P.getContentView();
      View view = this.p;
      if (view != null) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        b1 = 0;
      } 
    } 
    Drawable drawable = this.P.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.M);
      Rect rect = this.M;
      int m = rect.top;
      int k = rect.bottom + m;
      b2 = k;
      if (!this.i) {
        this.g = -m;
        b2 = k;
      } 
    } else {
      this.M.setEmpty();
      b2 = 0;
    } 
    if (this.P.getInputMethodMode() != 2)
      bool = false; 
    int j = t(s(), this.g, bool);
    if (this.m || this.d == -1)
      return j + b2; 
    int i = this.e;
    if (i != -2) {
      if (i != -1) {
        i = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
      } else {
        i = (this.a.getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.M;
        i = View.MeasureSpec.makeMeasureSpec(i - rect.left + rect.right, 1073741824);
      } 
    } else {
      i = (this.a.getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.M;
      i = View.MeasureSpec.makeMeasureSpec(i - rect.left + rect.right, -2147483648);
    } 
    j = this.c.d(i, 0, -1, j - b1, -1);
    i = b1;
    if (j > 0)
      i = b1 + b2 + this.c.getPaddingTop() + this.c.getPaddingBottom(); 
    return j + i;
  }
  
  public void q() {
    r r1 = this.c;
    if (r1 != null) {
      r1.setListSelectionHidden(true);
      r1.requestLayout();
    } 
  }
  
  public r r(Context paramContext, boolean paramBoolean) {
    return new r(paramContext, paramBoolean);
  }
  
  public View s() {
    return this.D;
  }
  
  public void show() {
    int i;
    int j = p();
    boolean bool1 = v();
    h.b(this.P, this.h);
    boolean bool2 = this.P.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!r.A(s()))
        return; 
      int m = this.e;
      if (m == -1) {
        i = -1;
      } else {
        i = m;
        if (m == -2)
          i = s().getWidth(); 
      } 
      m = this.d;
      if (m == -1) {
        if (!bool1)
          j = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.P;
          if (this.e == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.P.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.P;
          if (this.e == -1) {
            m = -1;
          } else {
            m = 0;
          } 
          popupWindow2.setWidth(m);
          this.P.setHeight(-1);
        } 
      } else if (m != -2) {
        j = m;
      } 
      PopupWindow popupWindow1 = this.P;
      if (this.n || this.m)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.P;
      View view = s();
      m = this.f;
      int n = this.g;
      if (i < 0)
        i = -1; 
      if (j < 0)
        j = -1; 
      popupWindow1.update(view, m, n, i, j);
      return;
    } 
    int k = this.e;
    if (k == -1) {
      i = -1;
    } else {
      i = k;
      if (k == -2)
        i = s().getWidth(); 
    } 
    k = this.d;
    if (k == -1) {
      j = -1;
    } else if (k != -2) {
      j = k;
    } 
    this.P.setWidth(i);
    this.P.setHeight(j);
    I(true);
    PopupWindow popupWindow = this.P;
    if (!this.n && !this.m) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.P.setTouchInterceptor(this.I);
    if (this.k)
      h.a(this.P, this.j); 
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = S;
      if (method != null)
        try {
          method.invoke(this.P, new Object[] { this.N });
        } catch (Exception exception) {
          Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", exception);
        }  
    } else {
      this.P.setEpicenterBounds(this.N);
    } 
    h.c(this.P, s(), this.f, this.g, this.l);
    this.c.setSelection(-1);
    if (!this.O || this.c.isInTouchMode())
      q(); 
    if (!this.O)
      this.L.post(this.K); 
  }
  
  public final int t(View paramView, int paramInt, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 23) {
      Method method = R;
      if (method != null)
        try {
          return ((Integer)method.invoke(this.P, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        } catch (Exception exception) {
          Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
        }  
      return this.P.getMaxAvailableHeight(paramView, paramInt);
    } 
    return this.P.getMaxAvailableHeight(paramView, paramInt, paramBoolean);
  }
  
  public int u() {
    return this.e;
  }
  
  public boolean v() {
    return (this.P.getInputMethodMode() == 2);
  }
  
  public boolean w() {
    return this.O;
  }
  
  public final void x() {
    View view = this.p;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.p); 
    } 
  }
  
  public void y(View paramView) {
    this.D = paramView;
  }
  
  public void z(int paramInt) {
    this.P.setAnimationStyle(paramInt);
  }
  
  public class a implements AdapterView.OnItemSelectedListener {
    public a(ListPopupWindow this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        r r = this.a.c;
        if (r != null)
          r.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  public class b implements Runnable {
    public b(ListPopupWindow this$0) {}
    
    public void run() {
      this.a.q();
    }
  }
  
  public class c extends DataSetObserver {
    public c(ListPopupWindow this$0) {}
    
    public void onChanged() {
      if (this.a.a())
        this.a.show(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  public class d implements AbsListView.OnScrollListener {
    public d(ListPopupWindow this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.v() && this.a.P.getContentView() != null) {
        ListPopupWindow listPopupWindow = this.a;
        listPopupWindow.L.removeCallbacks(listPopupWindow.H);
        this.a.H.run();
      } 
    }
  }
  
  public class e implements View.OnTouchListener {
    public e(ListPopupWindow this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.a.P;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.a.P.getWidth() && k >= 0 && k < this.a.P.getHeight()) {
          ListPopupWindow listPopupWindow = this.a;
          listPopupWindow.L.postDelayed(listPopupWindow.H, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        ListPopupWindow listPopupWindow = this.a;
        listPopupWindow.L.removeCallbacks(listPopupWindow.H);
      } 
      return false;
    }
  }
  
  public class f implements Runnable {
    public f(ListPopupWindow this$0) {}
    
    public void run() {
      r r = this.a.c;
      if (r != null && r.A((View)r) && this.a.c.getCount() > this.a.c.getChildCount()) {
        int i = this.a.c.getChildCount();
        ListPopupWindow listPopupWindow = this.a;
        if (i <= listPopupWindow.o) {
          listPopupWindow.P.setInputMethodMode(2);
          this.a.show();
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\ListPopupWindow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */