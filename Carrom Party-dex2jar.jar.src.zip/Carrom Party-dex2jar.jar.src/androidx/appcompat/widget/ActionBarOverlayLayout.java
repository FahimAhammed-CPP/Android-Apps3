package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;
import b.b.f;
import b.b.p.j.m;
import b.b.q.m0;
import b.b.q.o;
import b.b.q.p;
import b.h.n.k;
import b.h.n.l;
import b.h.n.m;
import b.h.n.n;
import b.h.n.r;

public class ActionBarOverlayLayout extends ViewGroup implements o, m, k, l {
  public static final int[] M = new int[] { b.b.a.b, 16842841 };
  
  public final Rect C = new Rect();
  
  public final Rect D = new Rect();
  
  public final Rect E = new Rect();
  
  public d F;
  
  public OverScroller G;
  
  public ViewPropertyAnimator H;
  
  public final AnimatorListenerAdapter I = new a(this);
  
  public final Runnable J = new b(this);
  
  public final Runnable K = new c(this);
  
  public final n L;
  
  public int a;
  
  public int b = 0;
  
  public ContentFrameLayout c;
  
  public ActionBarContainer d;
  
  public p e;
  
  public Drawable f;
  
  public boolean g;
  
  public boolean h;
  
  public boolean i;
  
  public boolean j;
  
  public boolean k;
  
  public int l;
  
  public int m;
  
  public final Rect n = new Rect();
  
  public final Rect o = new Rect();
  
  public final Rect p = new Rect();
  
  public final Rect q = new Rect();
  
  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    v(paramContext);
    this.L = new n(this);
  }
  
  public final void A() {
    u();
    this.J.run();
  }
  
  public final boolean B(float paramFloat1, float paramFloat2) {
    this.G.fling(0, 0, 0, (int)paramFloat2, 0, 0, -2147483648, 2147483647);
    return (this.G.getFinalY() > this.d.getHeight());
  }
  
  public void a(Menu paramMenu, m.a parama) {
    z();
    this.e.a(paramMenu, parama);
  }
  
  public boolean b() {
    z();
    return this.e.b();
  }
  
  public void c() {
    z();
    this.e.c();
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof e;
  }
  
  public boolean d() {
    z();
    return this.e.d();
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    if (this.f != null && !this.g) {
      byte b;
      if (this.d.getVisibility() == 0) {
        b = (int)(this.d.getBottom() + this.d.getTranslationY() + 0.5F);
      } else {
        b = 0;
      } 
      this.f.setBounds(0, b, getWidth(), this.f.getIntrinsicHeight() + b);
      this.f.draw(paramCanvas);
    } 
  }
  
  public boolean e() {
    z();
    return this.e.e();
  }
  
  public boolean f() {
    z();
    return this.e.f();
  }
  
  public boolean fitSystemWindows(Rect paramRect) {
    z();
    r.w((View)this);
    boolean bool = q((View)this.d, paramRect, true, true, false, true);
    this.q.set(paramRect);
    m0.a((View)this, this.q, this.n);
    if (!this.C.equals(this.q)) {
      this.C.set(this.q);
      bool = true;
    } 
    if (!this.o.equals(this.n)) {
      this.o.set(this.n);
      bool = true;
    } 
    if (bool)
      requestLayout(); 
    return true;
  }
  
  public boolean g() {
    z();
    return this.e.g();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new e(paramLayoutParams);
  }
  
  public int getActionBarHideOffset() {
    ActionBarContainer actionBarContainer = this.d;
    return (actionBarContainer != null) ? -((int)actionBarContainer.getTranslationY()) : 0;
  }
  
  public int getNestedScrollAxes() {
    return this.L.a();
  }
  
  public CharSequence getTitle() {
    z();
    return this.e.getTitle();
  }
  
  public void h(int paramInt) {
    z();
    if (paramInt != 2) {
      if (paramInt != 5) {
        if (paramInt != 109)
          return; 
        setOverlayMode(true);
        return;
      } 
      this.e.t();
      return;
    } 
    this.e.s();
  }
  
  public void i() {
    z();
    this.e.h();
  }
  
  public void j(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    k(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public void k(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    if (paramInt5 == 0)
      onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public boolean l(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    return (paramInt2 == 0 && onStartNestedScroll(paramView1, paramView2, paramInt1));
  }
  
  public void m(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    if (paramInt2 == 0)
      onNestedScrollAccepted(paramView1, paramView2, paramInt1); 
  }
  
  public void n(View paramView, int paramInt) {
    if (paramInt == 0)
      onStopNestedScroll(paramView); 
  }
  
  public void o(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    if (paramInt3 == 0)
      onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    v(getContext());
    r.M((View)this);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    u();
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt2 = getChildCount();
    paramInt3 = getPaddingLeft();
    getPaddingRight();
    paramInt4 = getPaddingTop();
    getPaddingBottom();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = getChildAt(paramInt1);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        int i = view.getMeasuredWidth();
        int j = view.getMeasuredHeight();
        int i1 = e.leftMargin + paramInt3;
        int i2 = e.topMargin + paramInt4;
        view.layout(i1, i2, i + i1, j + i2);
      } 
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    z();
    measureChildWithMargins((View)this.d, paramInt1, 0, paramInt2, 0);
    e e = (e)this.d.getLayoutParams();
    int i4 = Math.max(0, this.d.getMeasuredWidth() + e.leftMargin + e.rightMargin);
    int i3 = Math.max(0, this.d.getMeasuredHeight() + e.topMargin + e.bottomMargin);
    int i2 = View.combineMeasuredStates(0, this.d.getMeasuredState());
    if ((r.w((View)this) & 0x100) != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j) {
      int i5 = this.a;
      i = i5;
      if (this.i) {
        i = i5;
        if (this.d.getTabContainer() != null)
          i = i5 + this.a; 
      } 
    } else if (this.d.getVisibility() != 8) {
      i = this.d.getMeasuredHeight();
    } else {
      i = 0;
    } 
    this.p.set(this.n);
    this.D.set(this.q);
    if (!this.h && !j) {
      Rect rect = this.p;
      rect.top += i;
      rect.bottom += 0;
    } else {
      Rect rect = this.D;
      rect.top += i;
      rect.bottom += 0;
    } 
    q((View)this.c, this.p, true, true, true, true);
    if (!this.E.equals(this.D)) {
      this.E.set(this.D);
      this.c.a(this.D);
    } 
    measureChildWithMargins((View)this.c, paramInt1, 0, paramInt2, 0);
    e = (e)this.c.getLayoutParams();
    int i = Math.max(i4, this.c.getMeasuredWidth() + e.leftMargin + e.rightMargin);
    int j = Math.max(i3, this.c.getMeasuredHeight() + e.topMargin + e.bottomMargin);
    int i1 = View.combineMeasuredStates(i2, this.c.getMeasuredState());
    i2 = getPaddingLeft();
    i3 = getPaddingRight();
    j = Math.max(j + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight());
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + i2 + i3, getSuggestedMinimumWidth()), paramInt1, i1), View.resolveSizeAndState(j, paramInt2, i1 << 16));
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!this.j || !paramBoolean)
      return false; 
    if (B(paramFloat1, paramFloat2)) {
      p();
    } else {
      A();
    } 
    this.k = true;
    return true;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return false;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {}
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt1 = this.l + paramInt2;
    this.l = paramInt1;
    setActionBarHideOffset(paramInt1);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.L.b(paramView1, paramView2, paramInt);
    this.l = getActionBarHideOffset();
    u();
    d d1 = this.F;
    if (d1 != null)
      d1.e(); 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) == 0 || this.d.getVisibility() != 0) ? false : this.j;
  }
  
  public void onStopNestedScroll(View paramView) {
    if (this.j && !this.k)
      if (this.l <= this.d.getHeight()) {
        y();
      } else {
        x();
      }  
    d d1 = this.F;
    if (d1 != null)
      d1.b(); 
  }
  
  public void onWindowSystemUiVisibilityChanged(int paramInt) {
    boolean bool1;
    if (Build.VERSION.SDK_INT >= 16)
      super.onWindowSystemUiVisibilityChanged(paramInt); 
    z();
    int i = this.m;
    this.m = paramInt;
    boolean bool2 = false;
    if ((paramInt & 0x4) == 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if ((paramInt & 0x100) != 0)
      bool2 = true; 
    d d1 = this.F;
    if (d1 != null) {
      d1.c(bool2 ^ true);
      if (bool1 || !bool2) {
        this.F.a();
      } else {
        this.F.d();
      } 
    } 
    if (((i ^ paramInt) & 0x100) != 0 && this.F != null)
      r.M((View)this); 
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    super.onWindowVisibilityChanged(paramInt);
    this.b = paramInt;
    d d1 = this.F;
    if (d1 != null)
      d1.onWindowVisibilityChanged(paramInt); 
  }
  
  public final void p() {
    u();
    this.K.run();
  }
  
  public final boolean q(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/appcompat/widget/ActionBarOverlayLayout$e
    //   7: astore_1
    //   8: iload_3
    //   9: ifeq -> 43
    //   12: aload_1
    //   13: getfield leftMargin : I
    //   16: istore #7
    //   18: aload_2
    //   19: getfield left : I
    //   22: istore #8
    //   24: iload #7
    //   26: iload #8
    //   28: if_icmpeq -> 43
    //   31: aload_1
    //   32: iload #8
    //   34: putfield leftMargin : I
    //   37: iconst_1
    //   38: istore #9
    //   40: goto -> 46
    //   43: iconst_0
    //   44: istore #9
    //   46: iload #9
    //   48: istore_3
    //   49: iload #4
    //   51: ifeq -> 84
    //   54: aload_1
    //   55: getfield topMargin : I
    //   58: istore #7
    //   60: aload_2
    //   61: getfield top : I
    //   64: istore #8
    //   66: iload #9
    //   68: istore_3
    //   69: iload #7
    //   71: iload #8
    //   73: if_icmpeq -> 84
    //   76: aload_1
    //   77: iload #8
    //   79: putfield topMargin : I
    //   82: iconst_1
    //   83: istore_3
    //   84: iload_3
    //   85: istore #4
    //   87: iload #6
    //   89: ifeq -> 123
    //   92: aload_1
    //   93: getfield rightMargin : I
    //   96: istore #7
    //   98: aload_2
    //   99: getfield right : I
    //   102: istore #8
    //   104: iload_3
    //   105: istore #4
    //   107: iload #7
    //   109: iload #8
    //   111: if_icmpeq -> 123
    //   114: aload_1
    //   115: iload #8
    //   117: putfield rightMargin : I
    //   120: iconst_1
    //   121: istore #4
    //   123: iload #5
    //   125: ifeq -> 155
    //   128: aload_1
    //   129: getfield bottomMargin : I
    //   132: istore #7
    //   134: aload_2
    //   135: getfield bottom : I
    //   138: istore #8
    //   140: iload #7
    //   142: iload #8
    //   144: if_icmpeq -> 155
    //   147: aload_1
    //   148: iload #8
    //   150: putfield bottomMargin : I
    //   153: iconst_1
    //   154: ireturn
    //   155: iload #4
    //   157: ireturn
  }
  
  public e r() {
    return new e(-1, -1);
  }
  
  public e s(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  public void setActionBarHideOffset(int paramInt) {
    u();
    paramInt = Math.max(0, Math.min(paramInt, this.d.getHeight()));
    this.d.setTranslationY(-paramInt);
  }
  
  public void setActionBarVisibilityCallback(d paramd) {
    this.F = paramd;
    if (getWindowToken() != null) {
      this.F.onWindowVisibilityChanged(this.b);
      int i = this.m;
      if (i != 0) {
        onWindowSystemUiVisibilityChanged(i);
        r.M((View)this);
      } 
    } 
  }
  
  public void setHasNonEmbeddedTabs(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (paramBoolean != this.j) {
      this.j = paramBoolean;
      if (!paramBoolean) {
        u();
        setActionBarHideOffset(0);
      } 
    } 
  }
  
  public void setIcon(int paramInt) {
    z();
    this.e.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    z();
    this.e.setIcon(paramDrawable);
  }
  
  public void setLogo(int paramInt) {
    z();
    this.e.l(paramInt);
  }
  
  public void setOverlayMode(boolean paramBoolean) {
    this.h = paramBoolean;
    if (paramBoolean && (getContext().getApplicationInfo()).targetSdkVersion < 19) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    this.g = paramBoolean;
  }
  
  public void setShowingForActionMode(boolean paramBoolean) {}
  
  public void setUiOptions(int paramInt) {}
  
  public void setWindowCallback(Window.Callback paramCallback) {
    z();
    this.e.setWindowCallback(paramCallback);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    z();
    this.e.setWindowTitle(paramCharSequence);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public final p t(View paramView) {
    if (paramView instanceof p)
      return (p)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    stringBuilder.append(paramView.getClass().getSimpleName());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void u() {
    removeCallbacks(this.J);
    removeCallbacks(this.K);
    ViewPropertyAnimator viewPropertyAnimator = this.H;
    if (viewPropertyAnimator != null)
      viewPropertyAnimator.cancel(); 
  }
  
  public final void v(Context paramContext) {
    TypedArray typedArray = getContext().getTheme().obtainStyledAttributes(M);
    boolean bool2 = false;
    this.a = typedArray.getDimensionPixelSize(0, 0);
    Drawable drawable = typedArray.getDrawable(1);
    this.f = drawable;
    if (drawable == null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    setWillNotDraw(bool1);
    typedArray.recycle();
    boolean bool1 = bool2;
    if ((paramContext.getApplicationInfo()).targetSdkVersion < 19)
      bool1 = true; 
    this.g = bool1;
    this.G = new OverScroller(paramContext);
  }
  
  public boolean w() {
    return this.h;
  }
  
  public final void x() {
    u();
    postDelayed(this.K, 600L);
  }
  
  public final void y() {
    u();
    postDelayed(this.J, 600L);
  }
  
  public void z() {
    if (this.c == null) {
      this.c = (ContentFrameLayout)findViewById(f.b);
      this.d = (ActionBarContainer)findViewById(f.c);
      this.e = t(findViewById(f.a));
    } 
  }
  
  public class a extends AnimatorListenerAdapter {
    public a(ActionBarOverlayLayout this$0) {}
    
    public void onAnimationCancel(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.H = null;
      actionBarOverlayLayout.k = false;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.H = null;
      actionBarOverlayLayout.k = false;
    }
  }
  
  public class b implements Runnable {
    public b(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.a.u();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.H = actionBarOverlayLayout.d.animate().translationY(0.0F).setListener((Animator.AnimatorListener)this.a.I);
    }
  }
  
  public class c implements Runnable {
    public c(ActionBarOverlayLayout this$0) {}
    
    public void run() {
      this.a.u();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a;
      actionBarOverlayLayout.H = actionBarOverlayLayout.d.animate().translationY(-this.a.d.getHeight()).setListener((Animator.AnimatorListener)this.a.I);
    }
  }
  
  public static interface d {
    void a();
    
    void b();
    
    void c(boolean param1Boolean);
    
    void d();
    
    void e();
    
    void onWindowVisibilityChanged(int param1Int);
  }
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\ActionBarOverlayLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */