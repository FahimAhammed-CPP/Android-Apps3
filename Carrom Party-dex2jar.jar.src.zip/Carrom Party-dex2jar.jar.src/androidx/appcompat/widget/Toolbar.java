package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.customview.view.AbsSavedState;
import b.b.j;
import b.b.p.g;
import b.b.p.j.g;
import b.b.p.j.i;
import b.b.p.j.m;
import b.b.p.j.r;
import b.b.q.g0;
import b.b.q.h0;
import b.b.q.m0;
import b.b.q.p;
import b.b.q.y;
import b.h.n.g;
import b.h.n.r;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup {
  public int C;
  
  public int D;
  
  public y E;
  
  public int F;
  
  public int G;
  
  public int H = 8388627;
  
  public CharSequence I;
  
  public CharSequence J;
  
  public ColorStateList K;
  
  public ColorStateList L;
  
  public boolean M;
  
  public boolean N;
  
  public final ArrayList<View> O = new ArrayList<View>();
  
  public final ArrayList<View> P = new ArrayList<View>();
  
  public final int[] Q = new int[2];
  
  public f R;
  
  public final ActionMenuView.e S = new a(this);
  
  public h0 T;
  
  public b.b.q.c U;
  
  public d V;
  
  public m.a W;
  
  public ActionMenuView a;
  
  public g.a a0;
  
  public TextView b;
  
  public boolean b0;
  
  public TextView c;
  
  public final Runnable c0 = new b(this);
  
  public ImageButton d;
  
  public ImageView e;
  
  public Drawable f;
  
  public CharSequence g;
  
  public ImageButton h;
  
  public View i;
  
  public Context j;
  
  public int k;
  
  public int l;
  
  public int m;
  
  public int n;
  
  public int o;
  
  public int p;
  
  public int q;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, b.b.a.M);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    g0 g0 = g0.t(getContext(), paramAttributeSet, j.Z2, paramInt, 0);
    this.l = g0.m(j.B3, 0);
    this.m = g0.m(j.s3, 0);
    this.H = g0.k(j.a3, this.H);
    this.n = g0.k(j.b3, 48);
    int i = g0.d(j.v3, 0);
    int j = j.A3;
    paramInt = i;
    if (g0.q(j))
      paramInt = g0.d(j, i); 
    this.D = paramInt;
    this.C = paramInt;
    this.q = paramInt;
    this.p = paramInt;
    paramInt = g0.d(j.y3, -1);
    if (paramInt >= 0)
      this.p = paramInt; 
    paramInt = g0.d(j.x3, -1);
    if (paramInt >= 0)
      this.q = paramInt; 
    paramInt = g0.d(j.z3, -1);
    if (paramInt >= 0)
      this.C = paramInt; 
    paramInt = g0.d(j.w3, -1);
    if (paramInt >= 0)
      this.D = paramInt; 
    this.o = g0.e(j.m3, -1);
    paramInt = g0.d(j.i3, -2147483648);
    i = g0.d(j.e3, -2147483648);
    j = g0.e(j.g3, 0);
    int k = g0.e(j.h3, 0);
    h();
    this.E.e(j, k);
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.E.g(paramInt, i); 
    this.F = g0.d(j.j3, -2147483648);
    this.G = g0.d(j.f3, -2147483648);
    this.f = g0.f(j.d3);
    this.g = g0.o(j.c3);
    CharSequence charSequence3 = g0.o(j.u3);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = g0.o(j.r3);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.j = getContext();
    setPopupTheme(g0.m(j.q3, 0));
    Drawable drawable2 = g0.f(j.p3);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = g0.o(j.o3);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = g0.f(j.k3);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = g0.o(j.l3);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = j.C3;
    if (g0.q(paramInt))
      setTitleTextColor(g0.c(paramInt)); 
    paramInt = j.t3;
    if (g0.q(paramInt))
      setSubtitleTextColor(g0.c(paramInt)); 
    paramInt = j.n3;
    if (g0.q(paramInt))
      x(g0.m(paramInt, 0)); 
    g0.u();
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new g(getContext());
  }
  
  public boolean A() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.H());
  }
  
  public final int B(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + i + ((ViewGroup.MarginLayoutParams)e1).rightMargin;
  }
  
  public final int C(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    e e1 = (e)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)e1).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)e1).leftMargin;
  }
  
  public final int D(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int j = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfint[0] = Math.max(0, -i);
    paramArrayOfint[1] = Math.max(0, -j);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + k + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + k;
  }
  
  public final void E(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  public final void F() {
    removeCallbacks(this.c0);
    post(this.c0);
  }
  
  public void G() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((e)view.getLayoutParams()).b != 2 && view != this.a) {
        removeViewAt(i);
        this.P.add(view);
      } 
    } 
  }
  
  public void H(int paramInt1, int paramInt2) {
    h();
    this.E.g(paramInt1, paramInt2);
  }
  
  public void I(g paramg, b.b.q.c paramc) {
    if (paramg == null && this.a == null)
      return; 
    k();
    g g1 = this.a.L();
    if (g1 == paramg)
      return; 
    if (g1 != null) {
      g1.O((m)this.U);
      g1.O(this.V);
    } 
    if (this.V == null)
      this.V = new d(this); 
    paramc.G(true);
    if (paramg != null) {
      paramg.c((m)paramc, this.j);
      paramg.c(this.V, this.j);
    } else {
      paramc.h(this.j, null);
      this.V.h(this.j, null);
      paramc.c(true);
      this.V.c(true);
    } 
    this.a.setPopupTheme(this.k);
    this.a.setPresenter(paramc);
    this.U = paramc;
  }
  
  public void J(Context paramContext, int paramInt) {
    this.m = paramInt;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void K(Context paramContext, int paramInt) {
    this.l = paramInt;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public final boolean L() {
    if (!this.b0)
      return false; 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (M(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  public final boolean M(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  public boolean N() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.N());
  }
  
  public void a() {
    for (int i = this.P.size() - 1; i >= 0; i--)
      addView(this.P.get(i)); 
    this.P.clear();
  }
  
  public final void b(List<View> paramList, int paramInt) {
    int i = r.q((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = b.h.n.d.b(paramInt, r.q((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && M(view) && p(e1.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        e e1 = (e)view.getLayoutParams();
        if (e1.b == 0 && M(view) && p(e1.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  public final void c(View paramView, boolean paramBoolean) {
    e e1;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      e1 = m();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)e1)) {
      e1 = o((ViewGroup.LayoutParams)e1);
    } else {
      e1 = e1;
    } 
    e1.b = 1;
    if (paramBoolean && this.i != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.P.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)e1);
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof e);
  }
  
  public boolean d() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.a;
      if (actionMenuView != null && actionMenuView.I())
        return true; 
    } 
    return false;
  }
  
  public void e() {
    i i;
    d d1 = this.V;
    if (d1 == null) {
      d1 = null;
    } else {
      i = d1.b;
    } 
    if (i != null)
      i.collapseActionView(); 
  }
  
  public void f() {
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null)
      actionMenuView.z(); 
  }
  
  public void g() {
    if (this.h == null) {
      AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, b.b.a.L);
      this.h = appCompatImageButton;
      appCompatImageButton.setImageDrawable(this.f);
      this.h.setContentDescription(this.g);
      e e1 = m();
      e1.a = 0x800003 | this.n & 0x70;
      e1.b = 2;
      this.h.setLayoutParams((ViewGroup.LayoutParams)e1);
      this.h.setOnClickListener(new c(this));
    } 
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.h;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    y y1 = this.E;
    return (y1 != null) ? y1.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.G;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    y y1 = this.E;
    return (y1 != null) ? y1.b() : 0;
  }
  
  public int getContentInsetRight() {
    y y1 = this.E;
    return (y1 != null) ? y1.c() : 0;
  }
  
  public int getContentInsetStart() {
    y y1 = this.E;
    return (y1 != null) ? y1.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.F;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual L : ()Lb/b/p/j/g;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield G : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (r.q((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (r.q((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.F, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.e;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    j();
    return this.a.getMenu();
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.d;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public b.b.q.c getOuterActionMenuPresenter() {
    return this.U;
  }
  
  public Drawable getOverflowIcon() {
    j();
    return this.a.getOverflowIcon();
  }
  
  public Context getPopupContext() {
    return this.j;
  }
  
  public int getPopupTheme() {
    return this.k;
  }
  
  public CharSequence getSubtitle() {
    return this.J;
  }
  
  public final TextView getSubtitleTextView() {
    return this.c;
  }
  
  public CharSequence getTitle() {
    return this.I;
  }
  
  public int getTitleMarginBottom() {
    return this.D;
  }
  
  public int getTitleMarginEnd() {
    return this.q;
  }
  
  public int getTitleMarginStart() {
    return this.p;
  }
  
  public int getTitleMarginTop() {
    return this.C;
  }
  
  public final TextView getTitleTextView() {
    return this.b;
  }
  
  public p getWrapper() {
    if (this.T == null)
      this.T = new h0(this, true); 
    return (p)this.T;
  }
  
  public final void h() {
    if (this.E == null)
      this.E = new y(); 
  }
  
  public final void i() {
    if (this.e == null)
      this.e = new AppCompatImageView(getContext()); 
  }
  
  public final void j() {
    k();
    if (this.a.L() == null) {
      g g = (g)this.a.getMenu();
      if (this.V == null)
        this.V = new d(this); 
      this.a.setExpandedActionViewsExclusive(true);
      g.c(this.V, this.j);
    } 
  }
  
  public final void k() {
    if (this.a == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.a = actionMenuView;
      actionMenuView.setPopupTheme(this.k);
      this.a.setOnMenuItemClickListener(this.S);
      this.a.M(this.W, this.a0);
      e e1 = m();
      e1.a = 0x800005 | this.n & 0x70;
      this.a.setLayoutParams((ViewGroup.LayoutParams)e1);
      c((View)this.a, false);
    } 
  }
  
  public final void l() {
    if (this.d == null) {
      this.d = new AppCompatImageButton(getContext(), null, b.b.a.L);
      e e1 = m();
      e1.a = 0x800003 | this.n & 0x70;
      this.d.setLayoutParams((ViewGroup.LayoutParams)e1);
    } 
  }
  
  public e m() {
    return new e(-2, -2);
  }
  
  public e n(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  public e o(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof b.b.k.a.a) ? new e((b.b.k.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams)));
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.c0);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.N = false; 
    if (!this.N) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.N = true; 
    } 
    if (i == 10 || i == 3)
      this.N = false; 
    return true;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (r.q((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    int i = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.Q;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = r.r((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (M((View)this.d)) {
      if (k) {
        j = C((View)this.d, m, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = B((View)this.d, i, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      paramInt3 = i;
      j = m;
    } 
    paramInt1 = paramInt3;
    paramInt2 = j;
    if (M((View)this.h))
      if (k) {
        paramInt2 = C((View)this.h, j, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = B((View)this.h, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    paramInt3 = paramInt2;
    if (M((View)this.a))
      if (k) {
        j = B((View)this.a, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = C((View)this.a, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - paramInt3);
    paramInt2 = Math.max(j, paramInt2);
    paramInt3 = Math.min(paramInt3, m - paramInt1);
    paramInt1 = paramInt2;
    j = paramInt3;
    if (M(this.i))
      if (k) {
        j = C(this.i, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = B(this.i, paramInt2, arrayOfInt, paramInt4);
        j = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = j;
    if (M((View)this.e))
      if (k) {
        paramInt2 = C((View)this.e, j, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = B((View)this.e, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    paramBoolean = M((View)this.b);
    boolean bool = M((View)this.c);
    if (paramBoolean) {
      e e1 = (e)this.b.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)e1).topMargin + this.b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      e e1 = (e)this.c.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)e1).topMargin + this.c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.b;
      } else {
        textView1 = this.c;
      } 
      if (bool) {
        textView2 = this.c;
      } else {
        textView2 = this.b;
      } 
      e e1 = (e)textView1.getLayoutParams();
      e e2 = (e)textView2.getLayoutParams();
      if ((paramBoolean && this.b.getMeasuredWidth() > 0) || (bool && this.c.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.H & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)e1).topMargin;
          int i6 = this.C;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
            i5 = this.D;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)e2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)e2).bottomMargin - this.D - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)e1).topMargin + this.C;
      } 
      if (k) {
        if (j != 0) {
          k = this.p;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[1];
        paramInt2 -= Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.b.getLayoutParams();
          m = paramInt2 - this.b.getMeasuredWidth();
          k = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(m, paramInt1, paramInt2, k);
          paramInt1 = m - this.q;
          m = k + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          e1 = (e)this.c.getLayoutParams();
          k = m + ((ViewGroup.MarginLayoutParams)e1).topMargin;
          m = this.c.getMeasuredWidth();
          i2 = this.c.getMeasuredHeight();
          this.c.layout(paramInt2 - m, k, paramInt2, i2 + k);
          k = paramInt2 - this.q;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, k); 
        paramInt1 = paramInt3;
      } else {
        if (j != 0) {
          k = this.p;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[0];
        paramInt3 += Math.max(0, k);
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          e1 = (e)this.b.getLayoutParams();
          k = this.b.getMeasuredWidth() + paramInt3;
          m = this.b.getMeasuredHeight() + paramInt1;
          this.b.layout(paramInt3, paramInt1, k, m);
          k += this.q;
          paramInt1 = m + ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          k = paramInt3;
        } 
        if (bool) {
          e1 = (e)this.c.getLayoutParams();
          paramInt1 += ((ViewGroup.MarginLayoutParams)e1).topMargin;
          m = this.c.getMeasuredWidth() + paramInt3;
          i2 = this.c.getMeasuredHeight();
          this.c.layout(paramInt3, paramInt1, m, i2 + paramInt1);
          m += this.q;
          paramInt1 = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
        } else {
          m = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (j != 0) {
          paramInt1 = Math.max(k, m);
          paramInt3 = paramInt2;
        } 
        j = i;
        i = 0;
        b(this.O, 3);
        k = this.O.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    j = i;
    i = 0;
    b(this.O, 3);
    int k = this.O.size();
    paramInt2 = 0;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int[] arrayOfInt = this.Q;
    boolean bool1 = m0.b((View)this);
    boolean bool = false;
    if (bool1) {
      i1 = 1;
      n = 0;
    } else {
      i1 = 0;
      n = 1;
    } 
    if (M((View)this.d)) {
      E((View)this.d, paramInt1, 0, paramInt2, 0, this.o);
      i = this.d.getMeasuredWidth() + s((View)this.d);
      m = Math.max(0, this.d.getMeasuredHeight() + t((View)this.d));
      k = View.combineMeasuredStates(0, this.d.getMeasuredState());
    } else {
      i = 0;
      m = 0;
      k = 0;
    } 
    int i2 = i;
    int j = m;
    int i = k;
    if (M((View)this.h)) {
      E((View)this.h, paramInt1, 0, paramInt2, 0, this.o);
      i2 = this.h.getMeasuredWidth() + s((View)this.h);
      j = Math.max(m, this.h.getMeasuredHeight() + t((View)this.h));
      i = View.combineMeasuredStates(k, this.h.getMeasuredState());
    } 
    int k = getCurrentContentInsetStart();
    int m = 0 + Math.max(k, i2);
    arrayOfInt[i1] = Math.max(0, k - i2);
    if (M((View)this.a)) {
      E((View)this.a, paramInt1, m, paramInt2, 0, this.o);
      k = this.a.getMeasuredWidth() + s((View)this.a);
      j = Math.max(j, this.a.getMeasuredHeight() + t((View)this.a));
      i = View.combineMeasuredStates(i, this.a.getMeasuredState());
    } else {
      k = 0;
    } 
    i2 = getCurrentContentInsetEnd();
    int i1 = m + Math.max(i2, k);
    arrayOfInt[n] = Math.max(0, i2 - k);
    int n = j;
    k = i;
    m = i1;
    if (M(this.i)) {
      m = i1 + D(this.i, paramInt1, i1, paramInt2, 0, arrayOfInt);
      n = Math.max(j, this.i.getMeasuredHeight() + t(this.i));
      k = View.combineMeasuredStates(i, this.i.getMeasuredState());
    } 
    j = n;
    i = k;
    i1 = m;
    if (M((View)this.e)) {
      i1 = m + D((View)this.e, paramInt1, m, paramInt2, 0, arrayOfInt);
      j = Math.max(n, this.e.getMeasuredHeight() + t((View)this.e));
      i = View.combineMeasuredStates(k, this.e.getMeasuredState());
    } 
    int i3 = getChildCount();
    k = 0;
    m = j;
    j = k;
    while (j < i3) {
      View view = getChildAt(j);
      i2 = m;
      n = i;
      k = i1;
      if (((e)view.getLayoutParams()).b == 0)
        if (!M(view)) {
          i2 = m;
          n = i;
          k = i1;
        } else {
          k = i1 + D(view, paramInt1, i1, paramInt2, 0, arrayOfInt);
          i2 = Math.max(m, view.getMeasuredHeight() + t(view));
          n = View.combineMeasuredStates(i, view.getMeasuredState());
        }  
      j++;
      m = i2;
      i = n;
      i1 = k;
    } 
    n = this.C + this.D;
    i2 = this.p + this.q;
    if (M((View)this.b)) {
      D((View)this.b, paramInt1, i1 + i2, paramInt2, n, arrayOfInt);
      j = this.b.getMeasuredWidth();
      i3 = s((View)this.b);
      k = this.b.getMeasuredHeight();
      int i4 = t((View)this.b);
      i = View.combineMeasuredStates(i, this.b.getMeasuredState());
      k += i4;
      j += i3;
    } else {
      j = 0;
      k = 0;
    } 
    if (M((View)this.c)) {
      j = Math.max(j, D((View)this.c, paramInt1, i1 + i2, paramInt2, k + n, arrayOfInt));
      k += this.c.getMeasuredHeight() + t((View)this.c);
      i = View.combineMeasuredStates(i, this.c.getMeasuredState());
    } 
    k = Math.max(m, k);
    i2 = getPaddingLeft();
    i3 = getPaddingRight();
    m = getPaddingTop();
    n = getPaddingBottom();
    j = View.resolveSizeAndState(Math.max(i1 + j + i2 + i3, getSuggestedMinimumWidth()), paramInt1, 0xFF000000 & i);
    paramInt1 = View.resolveSizeAndState(Math.max(k + m + n, getSuggestedMinimumHeight()), paramInt2, i << 16);
    if (L())
      paramInt1 = bool; 
    setMeasuredDimension(j, paramInt1);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.c());
    ActionMenuView actionMenuView = this.a;
    if (actionMenuView != null) {
      g g = actionMenuView.L();
    } else {
      actionMenuView = null;
    } 
    int i = savedState.c;
    if (i != 0 && this.V != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (savedState.d)
      F(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    if (Build.VERSION.SDK_INT >= 17)
      super.onRtlPropertiesChanged(paramInt); 
    h();
    y y1 = this.E;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    y1.f(bool);
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    d d1 = this.V;
    if (d1 != null) {
      i i = d1.b;
      if (i != null)
        savedState.c = i.getItemId(); 
    } 
    savedState.d = A();
    return (Parcelable)savedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.M = false; 
    if (!this.M) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.M = true; 
    } 
    if (i == 1 || i == 3)
      this.M = false; 
    return true;
  }
  
  public final int p(int paramInt) {
    int i = r.q((View)this);
    int j = b.h.n.d.b(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  public final int q(View paramView, int paramInt) {
    e e1 = (e)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = r(e1.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - k - m - j) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)e1).topMargin;
        if (i >= paramInt) {
          j = n - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)e1).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)e1).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  public final int r(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.H & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  public final int s(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return g.b(marginLayoutParams) + g.a(marginLayoutParams);
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(b.b.l.a.a.d(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      this.h.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.h;
    if (imageButton != null)
      imageButton.setImageDrawable(this.f); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.b0 = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.G) {
      this.G = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.F) {
      this.F = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(b.b.l.a.a.d(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      i();
      if (!y((View)this.e))
        c((View)this.e, true); 
    } else {
      ImageView imageView1 = this.e;
      if (imageView1 != null && y((View)imageView1)) {
        removeView((View)this.e);
        this.P.remove(this.e);
      } 
    } 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      i(); 
    ImageView imageView = this.e;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      l(); 
    ImageButton imageButton = this.d;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(b.b.l.a.a.d(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      l();
      if (!y((View)this.d))
        c((View)this.d, true); 
    } else {
      ImageButton imageButton1 = this.d;
      if (imageButton1 != null && y((View)imageButton1)) {
        removeView((View)this.d);
        this.P.remove(this.d);
      } 
    } 
    ImageButton imageButton = this.d;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    l();
    this.d.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(f paramf) {
    this.R = paramf;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    j();
    this.a.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.k != paramInt) {
      this.k = paramInt;
      if (paramInt == 0) {
        this.j = getContext();
        return;
      } 
      this.j = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.c == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.c = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.c.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.m;
        if (i != 0)
          this.c.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.L;
        if (colorStateList != null)
          this.c.setTextColor(colorStateList); 
      } 
      if (!y((View)this.c))
        c((View)this.c, true); 
    } else {
      TextView textView1 = this.c;
      if (textView1 != null && y((View)textView1)) {
        removeView((View)this.c);
        this.P.remove(this.c);
      } 
    } 
    TextView textView = this.c;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.J = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.L = paramColorStateList;
    TextView textView = this.c;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.b == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.b = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.b.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.l;
        if (i != 0)
          this.b.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.K;
        if (colorStateList != null)
          this.b.setTextColor(colorStateList); 
      } 
      if (!y((View)this.b))
        c((View)this.b, true); 
    } else {
      TextView textView1 = this.b;
      if (textView1 != null && y((View)textView1)) {
        removeView((View)this.b);
        this.P.remove(this.b);
      } 
    } 
    TextView textView = this.b;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.I = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.D = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.q = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.p = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.C = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.K = paramColorStateList;
    TextView textView = this.b;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public final int t(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  public final int u(List<View> paramList, int[] paramArrayOfint) {
    int m = paramArrayOfint[0];
    int k = paramArrayOfint[1];
    int n = paramList.size();
    int i = 0;
    int j = 0;
    while (i < n) {
      View view = paramList.get(i);
      e e1 = (e)view.getLayoutParams();
      m = ((ViewGroup.MarginLayoutParams)e1).leftMargin - m;
      k = ((ViewGroup.MarginLayoutParams)e1).rightMargin - k;
      int i1 = Math.max(0, m);
      int i2 = Math.max(0, k);
      m = Math.max(0, -m);
      k = Math.max(0, -k);
      j += i1 + view.getMeasuredWidth() + i2;
      i++;
    } 
    return j;
  }
  
  public boolean v() {
    d d1 = this.V;
    return (d1 != null && d1.b != null);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.F());
  }
  
  public void x(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public final boolean y(View paramView) {
    return (paramView.getParent() == this || this.P.contains(paramView));
  }
  
  public boolean z() {
    ActionMenuView actionMenuView = this.a;
    return (actionMenuView != null && actionMenuView.G());
  }
  
  public static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    public int c;
    
    public boolean d;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.c = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.d = bool;
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    public static final class a implements Parcelable.ClassLoaderCreator<SavedState> {
      public Toolbar.SavedState a(Parcel param2Parcel) {
        return new Toolbar.SavedState(param2Parcel, null);
      }
      
      public Toolbar.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.SavedState[] c(int param2Int) {
        return new Toolbar.SavedState[param2Int];
      }
    }
  }
  
  public static final class a implements Parcelable.ClassLoaderCreator<SavedState> {
    public Toolbar.SavedState a(Parcel param1Parcel) {
      return new Toolbar.SavedState(param1Parcel, null);
    }
    
    public Toolbar.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.SavedState[] c(int param1Int) {
      return new Toolbar.SavedState[param1Int];
    }
  }
  
  public class a implements ActionMenuView.e {
    public a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      Toolbar.f f = this.a.R;
      return (f != null) ? f.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  public class b implements Runnable {
    public b(Toolbar this$0) {}
    
    public void run() {
      this.a.N();
    }
  }
  
  public class c implements View.OnClickListener {
    public c(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.a.e();
    }
  }
  
  public class d implements m {
    public g a;
    
    public i b;
    
    public d(Toolbar this$0) {}
    
    public void b(g param1g, boolean param1Boolean) {}
    
    public void c(boolean param1Boolean) {
      if (this.b != null) {
        g g1 = this.a;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (g1 != null) {
          int k = g1.size();
          int j = 0;
          while (true) {
            bool1 = bool2;
            if (j < k) {
              if (this.a.getItem(j) == this.b) {
                bool1 = true;
                break;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          e(this.a, this.b); 
      } 
    }
    
    public boolean d() {
      return false;
    }
    
    public boolean e(g param1g, i param1i) {
      View view = this.c.i;
      if (view instanceof b.b.p.c)
        ((b.b.p.c)view).d(); 
      Toolbar toolbar = this.c;
      toolbar.removeView(toolbar.i);
      toolbar = this.c;
      toolbar.removeView((View)toolbar.h);
      toolbar = this.c;
      toolbar.i = null;
      toolbar.a();
      this.b = null;
      this.c.requestLayout();
      param1i.r(false);
      return true;
    }
    
    public boolean f(g param1g, i param1i) {
      this.c.g();
      ViewParent viewParent = this.c.h.getParent();
      Toolbar toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.h); 
        Toolbar toolbar1 = this.c;
        toolbar1.addView((View)toolbar1.h);
      } 
      this.c.i = param1i.getActionView();
      this.b = param1i;
      viewParent = this.c.i.getParent();
      toolbar = this.c;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.i); 
        Toolbar.e e = this.c.m();
        toolbar = this.c;
        e.a = 0x800003 | toolbar.n & 0x70;
        e.b = 2;
        toolbar.i.setLayoutParams((ViewGroup.LayoutParams)e);
        Toolbar toolbar1 = this.c;
        toolbar1.addView(toolbar1.i);
      } 
      this.c.G();
      this.c.requestLayout();
      param1i.r(true);
      View view = this.c.i;
      if (view instanceof b.b.p.c)
        ((b.b.p.c)view).c(); 
      return true;
    }
    
    public void h(Context param1Context, g param1g) {
      g g1 = this.a;
      if (g1 != null) {
        i i1 = this.b;
        if (i1 != null)
          g1.f(i1); 
      } 
      this.a = param1g;
    }
    
    public boolean j(r param1r) {
      return false;
    }
  }
  
  public static class e extends b.b.k.a.a {
    public int b = 0;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public e(e param1e) {
      super(param1e);
      this.b = param1e.b;
    }
    
    public e(b.b.k.a.a param1a) {
      super(param1a);
    }
    
    public void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface f {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */