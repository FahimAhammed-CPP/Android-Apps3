package a.a.a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public interface a extends IInterface {
  void L4(String paramString, Bundle paramBundle);
  
  void c6(String paramString, Bundle paramBundle);
  
  void j6(Bundle paramBundle);
  
  void n6(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle);
  
  void q5(int paramInt, Bundle paramBundle);
  
  public static abstract class a extends Binder implements a {
    public a() {
      attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) {
      Bundle bundle1;
      Uri uri1 = null;
      Uri uri3 = null;
      Uri uri2 = null;
      Uri uri4 = null;
      Bundle bundle2 = null;
      if (param1Int1 != 2) {
        if (param1Int1 != 3) {
          if (param1Int1 != 4) {
            if (param1Int1 != 5) {
              boolean bool;
              if (param1Int1 != 6) {
                if (param1Int1 != 1598968902)
                  return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2); 
                param1Parcel2.writeString("android.support.customtabs.ICustomTabsCallback");
                return true;
              } 
              param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
              param1Int1 = param1Parcel1.readInt();
              if (param1Parcel1.readInt() != 0) {
                uri1 = (Uri)Uri.CREATOR.createFromParcel(param1Parcel1);
              } else {
                uri1 = null;
              } 
              if (param1Parcel1.readInt() != 0) {
                bool = true;
              } else {
                bool = false;
              } 
              if (param1Parcel1.readInt() != 0)
                bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
              n6(param1Int1, uri1, bool, bundle2);
              param1Parcel2.writeNoException();
              return true;
            } 
            param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            String str1 = param1Parcel1.readString();
            if (param1Parcel1.readInt() != 0)
              bundle1 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
            c6(str1, bundle1);
            param1Parcel2.writeNoException();
            return true;
          } 
          param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
          uri1 = uri3;
          if (param1Parcel1.readInt() != 0)
            bundle1 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
          j6(bundle1);
          param1Parcel2.writeNoException();
          return true;
        } 
        param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
        String str = param1Parcel1.readString();
        uri1 = uri2;
        if (param1Parcel1.readInt() != 0)
          bundle1 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
        L4(str, bundle1);
        param1Parcel2.writeNoException();
        return true;
      } 
      param1Parcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
      param1Int1 = param1Parcel1.readInt();
      uri1 = uri4;
      if (param1Parcel1.readInt() != 0)
        bundle1 = (Bundle)Bundle.CREATOR.createFromParcel(param1Parcel1); 
      q5(param1Int1, bundle1);
      param1Parcel2.writeNoException();
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */