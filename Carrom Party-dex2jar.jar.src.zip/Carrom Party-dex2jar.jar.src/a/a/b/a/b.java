package a.a.b.a;

import android.support.v4.media.MediaBrowserCompat;

public abstract class b {
  public abstract void a(String paramString);
  
  public abstract void b(MediaBrowserCompat.MediaItem paramMediaItem);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\b\a\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */