package a.a.b.a.g;

import android.media.session.MediaSession;

public class f {
  public static Object a(Object paramObject) {
    return ((MediaSession.QueueItem)paramObject).getDescription();
  }
  
  public static long b(Object paramObject) {
    return ((MediaSession.QueueItem)paramObject).getQueueId();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\b\a\g\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */