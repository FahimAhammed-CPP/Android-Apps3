package a.a.b.a.g;

import android.media.session.PlaybackState;
import android.os.Bundle;

public class h {
  public static Bundle a(Object paramObject) {
    return ((PlaybackState)paramObject).getExtras();
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\b\a\g\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */