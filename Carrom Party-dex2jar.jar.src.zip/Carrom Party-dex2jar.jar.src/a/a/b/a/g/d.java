package a.a.b.a.g;

public final class d {
  public d(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\b\a\g\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */