package a.a.b.a.g;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.ParcelableVolumeInfo;
import android.support.v4.media.session.PlaybackStateCompat;
import java.lang.ref.WeakReference;
import java.util.List;

public abstract class c implements IBinder.DeathRecipient {
  public final Object a;
  
  public a b;
  
  public a c;
  
  public c() {
    if (Build.VERSION.SDK_INT >= 21) {
      this.a = e.a(new b(this));
      return;
    } 
    this.c = new c(this);
  }
  
  public void a(d paramd) {}
  
  public void b(Bundle paramBundle) {}
  
  public void binderDied() {
    i(8, null, null);
  }
  
  public void c(MediaMetadataCompat paramMediaMetadataCompat) {}
  
  public void d(PlaybackStateCompat paramPlaybackStateCompat) {}
  
  public void e(List<MediaSessionCompat.QueueItem> paramList) {}
  
  public void f(CharSequence paramCharSequence) {}
  
  public void g() {}
  
  public void h(String paramString, Bundle paramBundle) {}
  
  public void i(int paramInt, Object paramObject, Bundle paramBundle) {
    a a1 = this.b;
    if (a1 != null) {
      paramObject = a1.obtainMessage(paramInt, paramObject);
      paramObject.setData(paramBundle);
      paramObject.sendToTarget();
    } 
  }
  
  public class a extends Handler {}
  
  public static class b implements e.a {
    public final WeakReference<c> a;
    
    public b(c param1c) {
      this.a = new WeakReference<c>(param1c);
    }
    
    public void E(Bundle param1Bundle) {
      c c = this.a.get();
      if (c != null)
        c.b(param1Bundle); 
    }
    
    public void G(List<?> param1List) {
      c c = this.a.get();
      if (c != null)
        c.e(MediaSessionCompat.QueueItem.d(param1List)); 
    }
    
    public void U(CharSequence param1CharSequence) {
      c c = this.a.get();
      if (c != null)
        c.f(param1CharSequence); 
    }
    
    public void V() {
      c c = this.a.get();
      if (c != null)
        c.g(); 
    }
    
    public void a(Object param1Object) {
      c c = this.a.get();
      if (c != null)
        c.c(MediaMetadataCompat.c(param1Object)); 
    }
    
    public void b(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      c c = this.a.get();
      if (c != null)
        c.a(new d(param1Int1, param1Int2, param1Int3, param1Int4, param1Int5)); 
    }
    
    public void c(Object param1Object) {
      c c = this.a.get();
      if (c != null) {
        if (c.c != null)
          return; 
        c.d(PlaybackStateCompat.c(param1Object));
      } 
    }
    
    public void d(String param1String, Bundle param1Bundle) {
      c c = this.a.get();
      if (c != null) {
        if (c.c != null && Build.VERSION.SDK_INT < 23)
          return; 
        c.h(param1String, param1Bundle);
      } 
    }
  }
  
  public static class c extends a.a {
    public final WeakReference<c> a;
    
    public c(c param1c) {
      this.a = new WeakReference<c>(param1c);
    }
    
    public void E(Bundle param1Bundle) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(7, param1Bundle, null); 
    }
    
    public void F6(PlaybackStateCompat param1PlaybackStateCompat) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(2, param1PlaybackStateCompat, null); 
    }
    
    public void G(List<MediaSessionCompat.QueueItem> param1List) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(5, param1List, null); 
    }
    
    public void M6(ParcelableVolumeInfo param1ParcelableVolumeInfo) {
      c c1 = this.a.get();
      if (c1 != null) {
        if (param1ParcelableVolumeInfo != null) {
          d d = new d(param1ParcelableVolumeInfo.a, param1ParcelableVolumeInfo.b, param1ParcelableVolumeInfo.c, param1ParcelableVolumeInfo.d, param1ParcelableVolumeInfo.e);
        } else {
          param1ParcelableVolumeInfo = null;
        } 
        c1.i(4, param1ParcelableVolumeInfo, null);
      } 
    }
    
    public void Q1() {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(13, null, null); 
    }
    
    public void S3(boolean param1Boolean) {}
    
    public void U(CharSequence param1CharSequence) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(6, param1CharSequence, null); 
    }
    
    public void V() {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(8, null, null); 
    }
    
    public void d5(int param1Int) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(12, Integer.valueOf(param1Int), null); 
    }
    
    public void j4(MediaMetadataCompat param1MediaMetadataCompat) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(3, param1MediaMetadataCompat, null); 
    }
    
    public void l3(boolean param1Boolean) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(11, Boolean.valueOf(param1Boolean), null); 
    }
    
    public void q0(String param1String, Bundle param1Bundle) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(1, param1String, param1Bundle); 
    }
    
    public void w4(int param1Int) {
      c c1 = this.a.get();
      if (c1 != null)
        c1.i(9, Integer.valueOf(param1Int), null); 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\b\a\g\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */