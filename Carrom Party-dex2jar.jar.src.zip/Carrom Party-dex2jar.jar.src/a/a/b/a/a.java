package a.a.b.a;

import android.os.Bundle;

public abstract class a {
  public abstract void a(String paramString, Bundle paramBundle1, Bundle paramBundle2);
  
  public abstract void b(String paramString, Bundle paramBundle1, Bundle paramBundle2);
  
  public abstract void c(String paramString, Bundle paramBundle1, Bundle paramBundle2);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\b\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */