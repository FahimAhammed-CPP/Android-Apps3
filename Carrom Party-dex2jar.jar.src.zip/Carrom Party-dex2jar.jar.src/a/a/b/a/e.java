package a.a.b.a;

import android.media.MediaDescription;
import android.net.Uri;

public class e {
  public static Uri a(Object paramObject) {
    return ((MediaDescription)paramObject).getMediaUri();
  }
  
  public static class a {
    public static void a(Object param1Object, Uri param1Uri) {
      ((MediaDescription.Builder)param1Object).setMediaUri(param1Uri);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\b\a\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */