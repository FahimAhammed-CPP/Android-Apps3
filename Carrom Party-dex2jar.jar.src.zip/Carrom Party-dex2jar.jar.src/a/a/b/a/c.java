package a.a.b.a;

import android.os.Bundle;
import android.support.v4.media.MediaBrowserCompat;
import java.util.List;

public abstract class c {
  public abstract void a(String paramString, Bundle paramBundle);
  
  public abstract void b(String paramString, Bundle paramBundle, List<MediaBrowserCompat.MediaItem> paramList);
}


/* Location:              C:\soft\dex2jar-2.0\Carrom Party-dex2jar.jar!\a\a\b\a\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */